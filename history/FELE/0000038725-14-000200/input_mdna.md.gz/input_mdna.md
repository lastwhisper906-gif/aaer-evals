# FELE MD&A — 0000038725-14-000200


## mdna

[0000038725-14-000200:mdna:1]
[same as prior period, unchanged from 0000038725-14-000166:mdna:1]

[0000038725-14-000200:mdna:2]
Third Quarter 2014 vs. Third Quarter 2013

[0000038725-14-000200:mdna:3]
[same as prior period, unchanged from 0000038725-14-000166:mdna:3]

[0000038725-14-000200:mdna:4]
Sales in the third quarter of 2014 were up 11 percent from last year.  The sales increase was attributable to the Company's acquisitions, price and volume increases and was partially offset by the negative impact of foreign currency translation. The Company's consolidated gross profit was $89.2 million for the third quarter of 2014, an increase of $2.2 million or about 3 percent from the prior year’s third quarter. The Company's diluted earnings per share (EPS) were $0.46, a decrease of 10 percent compared to 2013 third quarter diluted EPS of $0.51, primarily attributable to a sales mix shift which reduced operating margins and due to increased fixed costs from acquisitions.

[0000038725-14-000200:mdna:5]
[same as prior period, unchanged from 0000038725-14-000166:mdna:5]

[0000038725-14-000200:mdna:6]
[same as prior period, unchanged from 0000038725-14-000166:mdna:6]

[0000038725-14-000200:mdna:7]
Net sales for the third quarter of 2014 were $278.1 million, an increase of $28.3 million or 11 percent compared to 2013 third quarter sales of $249.8 million.  The incremental impact of sales from businesses acquired since the third quarter of 2013 was $10.0 million or about 4 percent.  Sales revenue decreased by $2.6 million or about 1 percent in the third quarter of 2014 due to foreign currency translation. The sales change for the third quarter of 2014, excluding acquisitions and foreign currency translation, was an increase of $20.9 million or about 8 percent.

[0000038725-14-000200:mdna:8]
|  | Net Sales |
| (In millions) | Q3 2014 |  | Q3 2013 |  | 2014 v 2013 |
| Water Systems | $ | 216.6 |  |  | $ | 197.9 |  |  | $ | 18.7 |  |
| Fueling Systems | 61.5 |  |  | 51.9 |  |  | 9.6 |  |
| Consolidated | $ | 278.1 |  |  | $ | 249.8 |  |  | $ | 28.3 |  |

[0000038725-14-000200:mdna:9]
[same as prior period, unchanged from 0000038725-14-000166:mdna:9]

[0000038725-14-000200:mdna:10]
Water Systems revenues were $216.6 million in the third quarter 2014, an increase of $18.7 million or about 9 percent versus the third quarter 2013. Sales from businesses acquired since the third quarter of 2013 were $9.9 million or 5 percent. Water Systems sales were reduced by $2.9 million or about 1 percent in the quarter due to foreign currency translation. Water Systems sales growth, excluding acquisitions and foreign currency translation, was 6 percent.

[0000038725-14-000200:mdna:11]
Water Systems sales in the U.S. and Canada represented about 41 percent of consolidated sales and grew by about 5 percent compared to the prior year.  Water Systems sales in the U.S. and Canada were reduced by about 1 percent in the quarter due to foreign currency translation and there were no acquisition related sales. U.S. and Canada sales growth, excluding acquisitions and foreign currency translation, was about 6 percent. U.S. and Canada sales of Pioneer branded mobile pumping equipment increased by over 75 percent in the third quarter of 2014 compared to the prior year due to overall higher demand, driven in part by the United Rental acquisition of National Pump.  Sales of surface water pumping equipment grew by 6 percent in the third quarter.  These sales increases in the U.S and Canada were partially offset by lower sales of groundwater pumping equipment which declined about 16 percent in the quarter due, in part, to weaker demand in the agriculture sector as a result of less favorable weather and to a lesser extent, the continuing inventory reset which has resulted from distributor changes in the channel.

[0000038725-14-000200:mdna:12]
Water Systems sales in Latin America were about 14 percent of consolidated sales for the third quarter and increased by about 34 percent compared to the third quarter of the prior year. Foreign currency translation had an insignificant impact on Latin American sales compared to the third quarter prior year.  Acquisition related sales were about 27 percent, and after excluding acquisitions and the impact of foreign currency translation, Latin American sales increased 7 percent.  Sales in Brazil were up 10 percent in the quarter and Company distribution outlets in Chile and Colombia contributed to significantly increased sales in these markets compared to the third quarter 2013.

[0000038725-14-000200:mdna:13]
Water Systems sales in the Middle East and Africa were about 10 percent of consolidated sales and were flat compared to the third quarter 2013.  Excluding the impact of foreign currency translation, sales increased by about 6 percent compared to the third quarter 2013. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-14-000200:mdna:14]
Water Systems sales in Europe were about 7 percent of consolidated sales and declined by about 5 percent compared to the third quarter 2013. Acquisition related sales were about 1 percent.  The impact of foreign currency translation decreased sales by about 1 percent compared to the third quarter 2013.  Excluding acquisitions and the impact of foreign currency translation, European sales decreased about 5 percent compared to the third quarter 2013. Sales were flat across the Franklin branded Water Systems products in Europe but down in the Pioneer branded mobile pumping equipment products in the third quarter 2014.

[0000038725-14-000200:mdna:15]
Water Systems sales in the Asia Pacific region were about 6 percent of consolidated sales and increased by about 38 percent compared to the third quarter prior year. Sales from businesses acquired since the third quarter of 2013 were $1.7 million or about 14 percent. Foreign currency translation had no impact on Asia Pacific sales in the third quarter.  Excluding acquisitions and the impact of foreign currency translation, Asia Pacific sales were up $3.0 million or about 24 percent compared to the third quarter 2013. Sales in Australia grew by 68 percent led by improved Pioneer product sales in the region and aided in part by the launch of new products in the water well pumping systems.  Sales in Southeast Asia grew by 48 percent compared to the third quarter prior year, as the Company continues to benefit from the improved customer service levels attributable to having Company owned inventory in the region.  These sales increases were partially offset by smaller declines in sales in Japan and China.

[0000038725-14-000200:mdna:16]
[same as prior period, unchanged from 0000038725-14-000166:mdna:20]

[0000038725-14-000200:mdna:17]
Fueling Systems sales represented about 22 percent of consolidated sales and were $61.5 million in the third quarter 2014, an increase of $9.6 million or about 19 percent versus the third quarter 2013 sales of $51.9 million. Sales from businesses acquired since the third quarter of 2013 were $0.1 million or less than one percent. Fueling Systems sales increased by $0.3 million or less than one percent in the quarter due to the impact of foreign currency translation. Fueling Systems sales growth, excluding acquisitions and foreign currency translation, was about 18 percent.

[0000038725-14-000200:mdna:18]
During the third quarter, Fueling Systems shipped about $3.5 million of equipment to India to partially fill a large customer order. Excluding the impact of these India sales, Fueling Systems sales grew by about 11 percent. Sales growth was across all product lines and all regions of the world.

[0000038725-14-000200:mdna:19]
[same as prior period, unchanged from 0000038725-14-000166:mdna:23]

[0000038725-14-000200:mdna:20]
Cost of sales as a percent of net sales for the third quarter of 2014 and 2013 was 67.9 percent and 65.2 percent, respectively. Correspondingly, the gross profit margin decreased to 32.1 percent from 34.8 percent, a 270 basis point decline. The Company’s consolidated gross profit was $89.2 million for the third quarter of 2014, an increase of $2.2 million, or about 3 percent, from the third quarter of 2013 gross profit of $87.0 million. Sales revenue mix shift in the Water Systems segment contributed significantly to lower gross profit margins in the third quarter. Pioneer branded mobile pumping equipment sales have had a surge in demand during the last two quarters and the Company has temporarily outsourced certain operations to meet the increased demand. Additional gross profit margin decreases were primarily due to higher material cost of sales and loss of operating leverage on fixed costs.  Direct material cost, as a percent of sales, was 44.7 percent, up 110 basis points from the 43.6 percent in the third quarter of 2013.  This increase was almost entirely attributable to the higher mix of surface water pumping equipment in the quarter.

[0000038725-14-000200:mdna:21]
[same as prior period, unchanged from 0000038725-14-000166:mdna:25]

[0000038725-14-000200:mdna:22]
Selling, general, and administrative (SG&A) expenses were $55.6 million in the third quarter of 2014 compared to $48.4 million from the third quarter of prior year, an increase of $7.2 million or about 15 percent. In the third quarter of 2014, increases in SG&A from acquired businesses were $3.2 million.  Excluding the acquisitions, the Company’s overall SG&A expenses in the third quarter of 2014 increased by $4.0 million or up 8 percent to prior year third quarter.  The remaining increases in SG&A were primarily driven by higher commissions, sales, marketing and selling related costs in support of higher sales and increases in Research Development and Engineering ("RD&E") spending.

[0000038725-14-000200:mdna:23]
[same as prior period, unchanged from 0000038725-14-000166:mdna:27]

[0000038725-14-000200:mdna:24]
Restructuring expenses for the third quarter of 2014 were $1.1 million or about $0.01 diluted earnings per share. Restructuring expenses for the third quarter 2014 included $0.4 million of expenses related to equipment transfers, freight and relocation cost incurred in Brazil moving into the new manufacturing facility and in Europe related to the transfer of production activities from Germany to the Czech Republic, $0.4 million of other restructuring costs related to Europe and other continued manufacturing realignments, $0.2 million in severance cost and $0.1 million in asset write-offs. Restructuring expenses for the third quarter of 2013 were $0.8 million or about $0.01 diluted earnings per share. Restructuring expenses for the third quarter 2013 included $0.6 million of expenses primarily related to relocation to the new corporate headquarters and engineering center in Fort Wayne, Indiana, and $0.2 million other restructuring costs related to continued manufacturing realignments and integration costs of the previously announced Flexing acquisition in Franklin Fueling Systems.

[0000038725-14-000200:mdna:25]
[same as prior period, unchanged from 0000038725-14-000166:mdna:29]

[0000038725-14-000200:mdna:26]
Operating income was $32.4 million in the third quarter of 2014, down $5.3 million or 14 percent from $37.7 million for the third quarter 2013.

[0000038725-14-000200:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2014 |  | Q3 2013 |  | 2014 v 2013 |
| Water Systems |  | $ | 28.3 |  |  | $ | 36.0 |  |  | $ | (7.7 | ) |
| Fueling Systems |  | 15.4 |  |  | 14.0 |  |  | 1.4 |  |
| Other |  | (11.3 | ) |  | (12.3 | ) |  | 1.0 |  |
| Consolidated |  | $ | 32.4 |  |  | $ | 37.7 |  |  | $ | (5.3 | ) |

[0000038725-14-000200:mdna:28]
There were a number of specific items in the third quarter of 2014 and 2013 that impacted operating income that were not operational in nature.  In the third quarter of 2014 they were as follows:

[0000038725-14-000200:mdna:29]
| • | There were $1.1 million of restructuring charges; $0.9 million primarily related to the relocation of the Wittlich, Germany manufacturing facility to Brno in the Czech Republic and the opening of the new manufacturing facility in Brazil and $0.2 million in severance cost, related to the European restructuring as well as continued manufacturing realignments and integration costs. |

[0000038725-14-000200:mdna:30]
| • | Software write-offs related to Pioneer rental totaled $1.1 million. |

[0000038725-14-000200:mdna:31]
| • | Other miscellaneous costs related to closed and pending acquisitions were $0.8 million. |

[0000038725-14-000200:mdna:32]
In the third quarter of 2013 they were as follows:

[0000038725-14-000200:mdna:33]
| • | There were $0.8 million of restructuring charges; $0.6 million primarily related to relocation to the new corporate headquarters and engineering center in Fort Wayne, Indiana and $0.2 million related to other restructuring costs related to continued manufacturing realignments and integration costs of the previously announced Flexing acquisition by Franklin Fueling Systems. |

[0000038725-14-000200:mdna:34]
| • | A benefit of $1.6 million from the reversal of a reserve for legal claims established in prior years that was favorably resolved in the third quarter in Franklin Fueling Systems. |

[0000038725-14-000200:mdna:35]
| • | Other miscellaneous costs related to acquisitions were $0.1 million. |

[0000038725-14-000200:mdna:36]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income after non-GAAP adjustments to net sales.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-14-000200:mdna:37]
[same as prior period, unchanged from 0000038725-14-000166:mdna:37]

[0000038725-14-000200:mdna:38]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (In millions) | For the Third Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 28.3 |  | $ | 15.4 |  | $ | (11.3 | ) | $ | 32.4 |  |
| % Operating Income To Net Sales | 13.1 | % | 25.0 | % |  | 11.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.0 |  | $ | 0.1 |  | $ | — |  | $ | 1.1 |  |
| Non-GAAP | $ | 1.7 |  | $ | 0.2 |  | $ | — |  | $ | 1.9 |  |
| Operating Income after Non-GAAP Adjustments | $ | 31.0 |  | $ | 15.7 |  | $ | (11.3 | ) | $ | 35.4 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.3 | % | 25.5 | % |  | 12.7 | % |
|  | For the Third Quarter 2013 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 36.0 |  | $ | 14.0 |  | $ | (12.3 | ) | $ | 37.7 |  |
| % Operating Income To Net Sales | 18.2 | % | 27.0 | % |  | 15.1 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.7 |  | $ | 0.1 |  | $ | — |  | $ | 0.8 |  |
| Non-GAAP | $ | 0.1 |  | $ | (1.6 | ) | $ | — |  | $ | (1.5 | ) |
| Operating Income after Non-GAAP Adjustments | $ | 36.8 |  | $ | 12.5 |  | $ | (12.3 | ) | $ | 37.0 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 18.6 | % | 24.1 | % |  | 14.8 | % |

[0000038725-14-000200:mdna:39]
[same as prior period, unchanged from 0000038725-14-000166:mdna:35]

[0000038725-14-000200:mdna:40]
Water Systems operating income, after non-GAAP adjustments, was $31.0 million in the third quarter 2014, a decrease of about 16 percent versus the third quarter 2013. The third quarter operating income margin after non-GAAP adjustments was 14.3 percent, down 430 basis points from 18.6 percent in the third quarter of 2013.  Water Systems adjusted operating income margin declined in the third quarter due, in part, to two global shifts in sales mix. The first being a shift from 65 percent groundwater pumping equipment to 59 percent.  Additionally, within this shift away from groundwater pumping equipment, sales of agricultural related ground water products were lower by 6 percent in the third quarter of 2014 versus the same period 2013.  The second sales mix shift was a larger portion of Pioneer branded mobile pumping equipment sales which increased 60 percent globally in the third quarter of 2014.  Additionally, new acquisitions including Bombas Leao and Pluga contributed lower operating income margins.  Water Systems margins also declined in the quarter due to higher fixed costs.

[0000038725-14-000200:mdna:41]
[same as prior period, unchanged from 0000038725-14-000166:mdna:39]

[0000038725-14-000200:mdna:42]
Fueling Systems operating income after non-GAAP adjustments was $15.7 million in the third quarter of 2014 compared to $12.5 million after non-GAAP adjustments in the third quarter of 2013, an increase of about 26 percent. The third quarter operating income margin after non-GAAP adjustments was 25.5 percent, an increase of 140 basis points from the 24.1 percent of net sales in the third quarter of 2013. The increase was primarily driven by fixed cost leverage on higher sales.

[0000038725-14-000200:mdna:43]
[same as prior period, unchanged from 0000038725-14-000166:mdna:41]

[0000038725-14-000200:mdna:44]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses decreased primarily due to lower projected incentive compensation expense.

[0000038725-14-000200:mdna:45]
[same as prior period, unchanged from 0000038725-14-000166:mdna:43]

[0000038725-14-000200:mdna:46]
Interest expense for the third quarters of 2014 and 2013 was $2.7 million.

[0000038725-14-000200:mdna:47]
[same as prior period, unchanged from 0000038725-14-000166:mdna:45]

[0000038725-14-000200:mdna:48]
Other income was $0.4 million in the third quarter of 2014 and $0.3 million in the third quarter of 2013.  Included in other

[0000038725-14-000200:mdna:49]
income for the third quarter of 2014 was interest income of $0.5 million, primarily derived from the investment of cash balances in short-term securities. Included in other income for the third quarter of 2013 was interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-14-000200:mdna:50]
[same as prior period, unchanged from 0000038725-14-000166:mdna:47]

[0000038725-14-000200:mdna:51]
Foreign currency-based transactions produced a loss for the third quarter of 2014 of $0.5 million. The loss was primarily due to rate changes in the Turkish lira relative to the U.S. dollar.  Foreign currency-based transactions produced a loss for the third quarter of 2013 of $0.5 million. The loss was primarily due to rate changes in the euro and Czech koruna relative to the U.S. dollar.

[0000038725-14-000200:mdna:52]
[same as prior period, unchanged from 0000038725-14-000166:mdna:49]

[0000038725-14-000200:mdna:53]
The provision for income taxes in the third quarter of 2014 and 2013 was $6.7 million and $9.6 million, respectively. The tax rate as a percentage of pre-tax earnings for the third quarter of 2014 was about 23 percent, a decrease of about 5 percent from the third quarter of 2013 tax rate of about 28 percent, primarily due to the income mix by jurisdictions and the expiration of the statute of limitation for uncertain tax positions. The effective tax rate before the impact of discrete events for the third quarter of 2014 was about 25 percent. The full year 2014 rate is estimated to be about 23 percent after the impact of discrete tax events. The projected tax rate is less than the 2013 overall tax rate of 26 percent and lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-14-000200:mdna:54]
[same as prior period, unchanged from 0000038725-14-000166:mdna:51]

[0000038725-14-000200:mdna:55]
Net income for the third quarter of 2014 was $22.8 million compared to 2013 third quarter net income of $25.3 million.  Net income attributable to the Company for the third quarter of 2014 was $22.7 million, or $0.46 per diluted share, compared to 2013 third quarter net income attributable to the Company of $25.1 million or $0.51 per diluted share. Earnings after non-GAAP adjustments for the third quarter of 2014 were $24.0 million, or $0.50 per diluted share, compared to the prior year third quarter earnings after non-GAAP adjustments of $24.4 million or $0.50 per diluted share.

[0000038725-14-000200:mdna:56]
There were specific items in the third quarter of 2014 and 2013 that impacted net income attributable to the Company that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-14-000200:mdna:57]
| Earnings Before and After Non-GAAP Adjustments | For the Third Quarter Ended |
| (In millions) | 2014 | 2013 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 22.7 |  | $ | 25.1 |  | (10 | )% |
| Allocated Undistributed Earnings | $ | (0.6 | ) | $ | (0.3 | ) |  |
| Adjusted Earnings for EPS Calculations | $ | 22.1 |  | $ | 24.8 |  | (11 | )% |
| Non-GAAP adjustments, before tax: |  |  |  |
| Restructuring | $ | 1.1 |  | $ | 0.8 |  |  |
| Non-GAAP items | $ | 1.9 |  | $ | (1.5 | ) |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 0.7 |  | $ | 0.5 |  |  |
| Non-GAAP items | $ | 1.2 |  | $ | (0.9 | ) |  |
| Net Income attributable to Franklin Electric Co., Inc. after Non-GAAP Adjustments (Adjusted Net Income) | $ | 24.0 |  | $ | 24.4 |  | (2 | )% |

[0000038725-14-000200:mdna:58]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the Third Quarter Ended |
| (In millions, except per share data) | 2014 | 2013 | Change |
| Average Fully Diluted Shares Outstanding | 48.1 |  | $ | 48.2 |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.46 |  | $ | 0.51 |  | (10 | )% |
| Restructuring per Share, net of tax | $ | 0.01 |  | $ | 0.01 |  |  |
| Non-GAAP items | $ | 0.03 |  | $ | (0.02 | ) |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.50 |  | $ | 0.50 |  | — | % |

[0000038725-14-000200:mdna:59]
First Nine Months of 2014 vs. First Nine Months of 2013

[0000038725-14-000200:mdna:60]
[same as prior period, unchanged from 0000038725-14-000166:mdna:58]

[0000038725-14-000200:mdna:61]
Sales and adjusted earnings in the first nine months of 2014 were up from the same period last year.  The sales increase was attributable to the Company's acquisitions, as well as sales volume and price increases, and was partially offset by the impact of foreign currency translation. The Company's consolidated gross profit was $266.7 million for the first nine months of 2014, an increase of $11.2 million or about 4 percent from the first nine months of 2013. The Company's diluted earnings per share (EPS) were $1.36, a decrease of 4 percent compared to 2013 third quarter diluted EPS of $1.41.

[0000038725-14-000200:mdna:62]
[same as prior period, unchanged from 0000038725-14-000166:mdna:60]

[0000038725-14-000200:mdna:63]
[same as prior period, unchanged from 0000038725-14-000166:mdna:61]

[0000038725-14-000200:mdna:64]
Net sales in the first nine months of 2014 were $793.9 million, an increase of $58.1 million or about 8 percent compared to 2013 first nine months sales of $735.8 million.  The incremental impact of sales from acquired businesses was $13.1 million or about 2 percent.  Sales revenue decreased by $14.1 million or about 2 percent in the first nine months of 2014 due to foreign currency translation. The sales change in the first nine months of 2014, excluding acquisitions and foreign currency translation, was an increase of $59.1 million or about 8 percent.

[0000038725-14-000200:mdna:65]
| (In millions) | YTD September 27, 2014 |  | YTDSeptember 28, 2013 |  | 2014 v 2013 |
|  | Net Sales |
| Water Systems | $ | 627.8 |  |  | $ | 588.1 |  |  | $ | 39.7 |  |
| Fueling Systems | 166.1 |  |  | 147.7 |  |  | 18.4 |  |
| Consolidated | $ | 793.9 |  |  | $ | 735.8 |  |  | $ | 58.1 |  |

[0000038725-14-000200:mdna:66]
[same as prior period, unchanged from 0000038725-14-000166:mdna:65]

[0000038725-14-000200:mdna:67]
Water Systems sales were $627.8 million in the first nine months of 2014, an increase of $39.7 million or about 7 percent versus the first nine months of 2013. The incremental impact of sales from acquired businesses was $13.0 million or about 2 percent. Foreign currency translation rate changes decreased sales $15.8 million, or about 3 percent, compared to sales in the first nine months of 2013. The Water Systems sales change in the first nine months of 2014, excluding acquisitions and foreign currency translation, was an increase of $42.5 million or about 7 percent.

[0000038725-14-000200:mdna:68]
Water Systems sales in the U.S. and Canada were 41 percent of consolidated sales and grew by 5 percent compared to the first nine months of 2013. Sales revenue decreased by $2.3 million or about 1 percent in the first nine months of 2014 due to foreign currency translation. The sales change in the first nine months of 2014, excluding acquisitions and foreign currency translation, was an increase of $17.0 million or about 6 percent.

[0000038725-14-000200:mdna:69]
Leading the Company's growth in the U.S. and Canada were sales of Pioneer branded mobile pumping equipment which increased by over 90 percent in the first nine months of 2014 compared to the prior year.  Sales of surface water pumping

[0000038725-14-000200:mdna:70]
equipment grew by about 5 percent in the first nine months.  These sales increases in the U.S and Canada were partially offset by lower sales of groundwater pumping equipment which declined about 13 percent in the first nine months of 2014 due, in part, to weaker demand in the agriculture sector as a result of less favorable weather and to a lesser extent, the continuing inventory reset which has resulted from distributor changes in the channel.

[0000038725-14-000200:mdna:71]
Water Systems sales in Latin America were about 13 percent of consolidated sales for the first nine months and grew by 12 percent compared to the prior year first nine months.  The incremental impact of sales from acquired businesses was $9.7 million or about 11 percent. Sales revenue decreased by $4.8 million or about 5 percent in the first nine months of 2014 due to foreign currency translation. The sales change in the first nine months of 2014, excluding acquisitions and foreign currency translation, was an increase of $6.2 million or about 7 percent. The first nine months year-on-year sales increase in Brazil, in local currency, was 12 percent. The sales growth in Brazil is a result of increasing demand for Franklin submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions.  New distribution outlets in Chile and Colombia contributed to significantly increased sales in these markets compared to 2013.  These sales increases were partially offset with lower sales in Mexico.

[0000038725-14-000200:mdna:72]
Water Systems sales in the Middle East and Africa were about 11 percent of consolidated sales and increased by about 3 percent compared to the first nine months of 2013. Water Systems sales in the Middle East and Africa were reduced by $9.0 million or about 10 percent in the quarter due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, sales were up about 13 percent compared to the first nine months of 2013. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-14-000200:mdna:73]
Water Systems sales in Europe were about 8 percent of consolidated sales and grew by about 14 percent compared to the first nine months of 2013. The incremental impact of sales from acquired businesses was $1.6 million or about 3 percent.  Sales revenue increased by $1.2 million or about 2 percent in the first nine months of 2014 due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, European sales increased about 9 percent compared to the first nine months of 2013. Sales improvements in Europe were broad based and include the Pioneer rental business in the United Kingdom which had nominal sales in the first half of 2013.

[0000038725-14-000200:mdna:74]
Water Systems sales in the Asia Pacific region were 6 percent of consolidated sales and grew by about 8 percent compared to the first nine months of the prior year. The incremental impact of sales from acquired businesses was $1.7 million or about 4 percent.  Sales revenue decreased by $0.9 million or about 2 percent in the first nine months of 2014 due to foreign currency translation. The sales change in the first nine months of 2014, excluding acquisitions and foreign currency translation, was an increase of $3.0 million or about 6 percent. Sales in Australia grew by 27 percent led by improved Pioneer product sales in the region and aided in part by the launch of the new solar powered water well pumping system.  Sales in Taiwan and Southeast Asia grew by about 5 percent compared to the third quarter prior year, as the Company continues to benefit from the improved customer service levels attributable to a new distribution center in Singapore.  These sales increases were partially offset by smaller declines in sales in Thailand, Japan and China.

[0000038725-14-000200:mdna:75]
[same as prior period, unchanged from 0000038725-14-000166:mdna:73]

[0000038725-14-000200:mdna:76]
Fueling Systems sales were $166.1 million or about 21 percent of consolidated sales in the first nine months of 2014 and increased $18.4 million or about 12 percent from the first nine months of 2013. The incremental impact of sales from acquired businesses was $0.1 million. Foreign currency translation rate changes increased sales $1.7 million or about 1 percent compared to sales in the first nine months of 2013. The Fueling Systems sales change in the first nine months of 2014, excluding acquisitions and foreign currency translation, was an increase of $16.6 million or about 11 percent.

[0000038725-14-000200:mdna:77]
This growth was led by sales increases in developing markets, which grew by 17 percent compared to the nine months of the prior year, as customers outside North America continue to invest in the Company’s pressure pumping systems for transferring gasoline from underground tanks. As well, adoption of the Company’s electronic fuel management products is increasing among international customers. Fueling sales in the developed markets were up by about 10 percent compared to prior year.

[0000038725-14-000200:mdna:78]
[same as prior period, unchanged from 0000038725-14-000166:mdna:77]

[0000038725-14-000200:mdna:79]
Cost of sales as a percent of net sales for the first nine months of 2014 and 2013 was 66.4 percent and 65.3 percent, respectively. Correspondingly, the gross profit margin was 33.6 percent and 34.7 percent for both the first nine months of the year. The Company's consolidated gross profit was $266.7 million for the first nine months of 2014, up $11.2 million from the gross profit of $255.5 million in the first nine months of 2013.  Sales revenue mix shift in the Water Systems segment contributed to lower gross profit margins.  Direct material cost, as a percent of sales, was 46.0 percent, up 170 basis points from the 44.3 percent in the first nine months of 2013. This increase was almost entirely attributable to the higher mix of Pioneer branded mobile pumping equipment and surface water pumping equipment.  Pioneer branded mobile pumping equipment sales have had higher demand during 2014 and the Company has temporarily outsourced certain operations to meet the increased

[0000038725-14-000200:mdna:80]
demand.

[0000038725-14-000200:mdna:81]
[same as prior period, unchanged from 0000038725-14-000166:mdna:79]

[0000038725-14-000200:mdna:82]
Selling, general, and administrative expenses were $167.6 million in the first nine months of 2014 and increased by $15.9 million or about 10 percent compared to the first nine months of last year. In the first nine months of 2014, increases in SG&A expenses from acquired businesses were $3.7 million or about 2 percent.  Other increases in SG&A were $2.5 million related to executive transition and $1.1 million of cost attributable to pending or closed acquisitions.  Additional increases in SG&A cost during the first nine months of 2014 resulted from increased cost for marketing and selling-related expenses of $3.7 million and higher RD&E expenses of $1.5 million.

[0000038725-14-000200:mdna:83]
[same as prior period, unchanged from 0000038725-14-000166:mdna:81]

[0000038725-14-000200:mdna:84]
Restructuring expenses for the first nine months of 2014 were $1.5 million and reduced diluted earnings per share by approximately $0.01. Restructuring expenses in the first nine months of 2014 were $0.5 million in severance cost, $0.4 million expenses related to equipment transfers, freight and relocation cost incurred in Brazil moving into the new manufacturing facility and in Europe related to the transfer of production activities from Germany to the Czech Republic, $0.4 million of other restructuring costs related to Europe and other continued manufacturing realignments, and $0.2 million in asset write-offs.  Restructuring expenses for the first nine months of 2013 were $2.2 million and reduced diluted earnings per share by approximately $0.03. Restructuring expenses in the first nine months of 2013 were severance costs and expenses related to relocation to the new Global Corporate Headquarters and Engineering Center of Excellence in Fort Wayne, Indiana.

[0000038725-14-000200:mdna:85]
[same as prior period, unchanged from 0000038725-14-000166:mdna:83]

[0000038725-14-000200:mdna:86]
Operating income was $97.5 million in the first nine months of 2014, down $4.1 million from $101.6 million in the first nine months of 2013.

[0000038725-14-000200:mdna:87]
| (In millions) |  | YTDSeptember 27, 2014 |  | YTDSeptember 28, 2013 |  | 2014 v 2013 |
|  |  | Operating income (loss) |
| Water Systems |  | $ | 99.3 |  |  | $ | 107.3 |  |  | $ | (8.0 | ) |
| Fueling Systems |  | 37.9 |  |  | 31.1 |  |  | 6.8 |  |
| Other |  | (39.7 | ) |  | (36.8 | ) |  | (2.9 | ) |
| Consolidated |  | $ | 97.5 |  |  | $ | 101.6 |  |  | $ | (4.1 | ) |

[0000038725-14-000200:mdna:88]
There were specific items in the first nine months of 2014 and 2013 that impacted operating income that were not operational in nature.

[0000038725-14-000200:mdna:89]
In the first nine months of 2014 they were as follows:

[0000038725-14-000200:mdna:90]
| • | There were $1.5 million of restructuring charges. These restructuring expenses included $0.5 million in severance cost, $0.4 million expenses related to equipment transfers, freight and relocation cost incurred in Brazil moving into the new manufacturing facility and in Europe related to the transfer of production activities from Germany to the Czech Republic, $0.4 million of other restructuring costs related to Europe and other continued manufacturing realignments, and $0.2 million in asset write-offs. |

[0000038725-14-000200:mdna:91]
| • | Executive transition costs were $2.5 million. |

[0000038725-14-000200:mdna:92]
| • | Other miscellaneous costs related to closed and pending acquisitions were $1.7 million. |

[0000038725-14-000200:mdna:93]
| • | Software write-offs related to Pioneer rental were $1.1 million. |

[0000038725-14-000200:mdna:94]
In the first nine months of 2013 they were as follows:

[0000038725-14-000200:mdna:95]
| • | There were $2.2 million of restructuring charges. These restructuring expenses were primarily severance expenses of $1.1 million, $0.1 million in other miscellaneous manufacturing realignment activities, and $1.0 million related to relocation to the new corporate headquarters and engineering center in Fort Wayne, Indiana. |

[0000038725-14-000200:mdna:96]
| • | A net $1.1 million of benefit from the $1.6 million reversal of a reserve for legal claims established in prior years that was favorably resolved in the third quarter of 2013, offset by $0.5 million of legal fees incurred by Franklin Fueling Systems. |

[0000038725-14-000200:mdna:97]
| • | Other miscellaneous costs related to pending acquisitions were $0.1 million. |

[0000038725-14-000200:mdna:98]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income after non-GAAP adjustments to net sales.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-14-000200:mdna:99]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the First Nine Months of 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 99.3 |  | $ | 37.9 |  | $ | (39.7 | ) | $ | 97.5 |  |
| % Operating Income To Net Sales | 15.8 | % | 22.8 | % |  | 12.3 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.4 |  | $ | 0.1 |  | $ | — |  | $ | 1.5 |  |
| Non-GAAP | $ | 2.2 |  | $ | 0.6 |  | $ | 2.5 |  | $ | 5.3 |  |
| Operating Income after Non-GAAP Adjustments | $ | 102.9 |  | $ | 38.6 |  | $ | (37.2 | ) | $ | 104.3 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 16.4 | % | 23.2 | % |  | 13.1 | % |
|  | For the First Nine Months of 2013 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 107.3 |  | $ | 31.1 |  | $ | (36.8 | ) | $ | 101.6 |  |
| % Operating Income To Net Sales | 18.2 | % | 21.1 | % |  | 13.8 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.7 |  | $ | 0.5 |  | $ | — |  | $ | 2.2 |  |
| Non-GAAP | $ | 0.1 |  | $ | (1.1 | ) | $ | — |  | $ | (1.0 | ) |
| Operating Income after Non-GAAP Adjustments | $ | 109.1 |  | $ | 30.5 |  | $ | (36.8 | ) | $ | 102.8 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 18.6 | % | 20.6 | % |  | 14.0 | % |

[0000038725-14-000200:mdna:100]
[same as prior period, unchanged from 0000038725-14-000166:mdna:98]

[0000038725-14-000200:mdna:101]
Water Systems operating income after non-GAAP adjustments was $102.9 million in the first nine months of 2014, a decrease of about 6 percent versus the first nine months of 2013. The first nine months operating income margin after non-GAAP adjustments was 16.4 percent and decreased by 220 basis points compared to the first nine months of 2013. Water Systems adjusted operating income margin declined in the first nine months of 2014 was primarily due to two global shifts in sales mix. A shift from groundwater pumping equipment to surface pumping equipment, additionally, within this shift away from groundwater pumping equipment, sales of agricultural related ground water products were lower by 9 percent in the first nine months of 2014 versus the same period 2013.  The second sales mix shift was a larger portion of Pioneer branded mobile pumping equipment sales.  Additionally, new acquisitions including Bombas Leao and Pluga contributed lower operating income margins.  Water Systems margins also declined in the year due to higher fixed costs.

[0000038725-14-000200:mdna:102]
[same as prior period, unchanged from 0000038725-14-000166:mdna:100]

[0000038725-14-000200:mdna:103]
Fueling Systems operating income after non-GAAP adjustments was $38.6 million in the first nine months of 2014 compared to $30.5 million after non-GAAP adjustments in the first nine months of 2013, an increase of 27 percent. The first nine months operating income margin after non-GAAP adjustments was 23.2 percent and increased by 260 basis points compared to the 20.6 percent of net sales in the first nine months of 2013 due to sales growth and expense control.

[0000038725-14-000200:mdna:104]
[same as prior period, unchanged from 0000038725-14-000166:mdna:102]

[0000038725-14-000200:mdna:105]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative

[0000038725-14-000200:mdna:106]
expenses were higher due to $2.5 million of cost included in non-GAAP adjustments related to executive transition.

[0000038725-14-000200:mdna:107]
[same as prior period, unchanged from 0000038725-14-000166:mdna:104]

[0000038725-14-000200:mdna:108]
Interest expense for the first nine months of 2014 and 2013 was $8.0 million and $7.8 million, respectively. The increase was primarily due to increased debt.

[0000038725-14-000200:mdna:109]
[same as prior period, unchanged from 0000038725-14-000166:mdna:106]

[0000038725-14-000200:mdna:110]
Other income or expense was a gain of $1.6 million in the first nine months of 2014 and a gain of $1.1 million in the first nine months of 2013.  Included in other income in the first nine months of 2014 was interest income of $1.5 million, primarily derived from the investment of cash balances in short-term securities.  Included in other income in the first nine months of 2013 was interest income of $1.1 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-14-000200:mdna:111]
[same as prior period, unchanged from 0000038725-14-000166:mdna:109]

[0000038725-14-000200:mdna:112]
Foreign currency-based transactions produced a loss for the first nine months of 2014 of $0.6 million, primarily due to the Turkish lira and Canadian dollar relative to the U.S. dollar.  Foreign currency-based transactions produced a loss in the first nine months of 2013 of $1.2 million, primarily due to the euro, South African rand and Canadian dollar relative to the U.S. dollar.

[0000038725-14-000200:mdna:113]
[same as prior period, unchanged from 0000038725-14-000166:mdna:111]

[0000038725-14-000200:mdna:114]
The provision for income taxes in the first nine months of 2014 and 2013 was $22.7 million and $24.4 million, respectively. The tax rate as a percentage of pre-tax earnings for the first nine months of 2014 was about 25 percent, a decrease of about 100 basis points from the first nine months of 2013 tax rate of about 26 percent, primarily due to the income mix by jurisdictions. The effective tax rate before the impact of discrete events for the first nine months of 2014 was about 27 percent, which is a reasonable estimate of the full year 2014 rate. The projected tax rate is consistent with the 2013 tax rate and lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-14-000200:mdna:115]
[same as prior period, unchanged from 0000038725-14-000166:mdna:113]

[0000038725-14-000200:mdna:116]
Net income for the first nine months of 2014 was $67.7 million compared to 2013 first nine months net income of $69.4 million.  Net income attributable to the Company for the first nine months of 2014 was $66.7 million, or $1.36 per diluted share, compared to 2013 first nine months net income attributable to the Company of $68.7 million or $1.41 per diluted share. Earnings after non-GAAP adjustments for the first nine months of 2014 were $69.5 million, or $1.45 per diluted share, compared to the prior year first nine months earnings after non-GAAP adjustments of $68.5 million or $1.43 per diluted share.

[0000038725-14-000200:mdna:117]
There were specific items in the third quarter of 2014 and 2013 that impacted net income attributable to the Company that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-14-000200:mdna:118]
| Earnings Before and After Non-GAAP Adjustments | For the First Nine Months |
| (in millions) | 2014 | 2013 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 66.7 |  | $ | 68.7 |  | (3 | )% |
| Allocated Undistributed Earnings | $ | (1.3 | ) | $ | (0.9 | ) |  |
| Adjusted Earnings for EPS Calculation | $ | 65.4 |  | $ | 67.8 |  | (4 | )% |
| Non-GAAP adjustments (before tax): |  |  |  |
| Restructuring | $ | 1.5 |  | $ | 2.2 |  |  |
| Non-GAAP items | $ | 5.3 |  | $ | (1.0 | ) |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 0.9 |  | $ | 1.3 |  |  |
| Non-GAAP items | $ | 3.2 |  | $ | (0.6 | ) |  |
| Earnings after Non-GAAP Adjustments | $ | 69.5 |  | $ | 68.5 |  | 1 | % |

[0000038725-14-000200:mdna:119]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the First Nine Months |
| (in millions except Earnings Per Share) | 2014 | 2013 | Change |
| Average Fully Diluted Shares Outstanding | 48.2 |  | 48.1 |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 1.36 |  | $ | 1.41 |  | (4 | )% |
| Restructuring Per Share, net of tax | $ | 0.01 |  | $ | 0.03 |  |  |
| Non-GAAP items | $ | 0.08 |  | $ | (0.01 | ) |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 1.45 |  | $ | 1.43 |  | 1 | % |

[0000038725-14-000200:mdna:120]
[same as prior period, unchanged from 0000038725-14-000166:mdna:118]

[0000038725-14-000200:mdna:121]
[same as prior period, unchanged from 0000038725-14-000166:mdna:119]

[0000038725-14-000200:mdna:122]
The Company has a committed, unsecured, revolving credit agreement maturing on December 14, 2016 (the “Revolver”) in the amount of $150.0 million. As of September 27, 2014, the Company had $99.2 million borrowing capacity under the Revolver as $5.1 million in letters of credit were outstanding and undrawn and $45.7 million of revolver borrowing had been drawn and was outstanding at the end of the quarter.

[0000038725-14-000200:mdna:123]
The Company also has an amended and restated uncommitted note purchase and private shelf agreement (the “Prudential Agreement”) in the amount of $200.0 million, with $150.0 million of notes issued thereunder beginning to mature in 2015. The Company has no scheduled principal payments under the Prudential Agreement until 2015 at which time it amortizes for 5 years at an amount of $30.0 million per year. As of September 27, 2014, the Company had $50.0 million borrowing capacity under the Prudential Agreement.

[0000038725-14-000200:mdna:124]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).” The aggregate principal amount of the Project Bonds that were issued, authenticated, and outstanding thereunder was limited to $25.0 million. The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation, and equipping of the new Global Corporate Headquarters and Engineering Center of Excellence. The Project Notes (tax increment financing debt) bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due

[0000038725-14-000200:mdna:125]
34

[0000038725-14-000200:mdna:126]
and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033. The use of the proceeds from the Project Notes was limited to assist in the financing of the new Global Corporate Headquarters and Engineering Center of Excellence.

[0000038725-14-000200:mdna:127]
The Revolver, the Prudential Agreement, and the tax increment financing debt contain customary affirmative and negative covenants. The affirmative covenants include financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans or advances, investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Revolver, the Prudential Agreement, and the tax increment financing debt, but only if the Company is defaulting on an obligation exceeding $10.0 million. As of September 27, 2014, the Company was in compliance with all covenants.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-14-000200:mdna:128]
At September 27, 2014, the Company had $77.4 million of cash and equivalents at various locations worldwide. Approximately 21 percent of the cash and equivalents was in U.S. and Canada entities and readily accessible.  Approximately 45 percent was in various European subsidiaries, and 22 percent was in Mexico and Brazil. The Company reviews international cash balances on a regular basis and based on forecasted expenditures and taking tax effects into consideration, will reposition cash among its global entities if appropriate. Cash investments worldwide are invested according to a written policy and are generally in bank demand accounts and bank time deposits with the preservation of principal as the highest priority. Also, historically the Company has generally sourced inputs and sold outputs both in the local currency of operations on a country by country basis, thereby insulating local cash balances from currency volatility.

[0000038725-14-000200:mdna:129]
Net cash provided by operating activities was $3.5 million for the nine months ended September 27, 2014 compared to $55.0 million for the nine months ended September 28, 2013.  The reduction in net cash provided by operations during the first nine months of 2014 is primarily due to an increased use of cash for inventory and receivables compared to the first nine months of 2013.  Outstanding inventory balances were higher at September 27, 2014 primarily due to an anticipated demand increase for Pioneer products, various new product launches, and higher than normal seasonal inventory build.  Receivable balances were elevated due to higher sales, especially in some emerging markets, along with some extended credit terms in the first nine months of 2014 compared to 2013.

[0000038725-14-000200:mdna:130]
Net cash used in investing activities was $68.4 million for the nine months ended September 27, 2014, compared to $52.6 million for the nine months ended September 28, 2013.  The increase in cash used can be attributed to increased spending for acquisitions and equity investments during the first nine months of 2014, with a partial offset from a reduction in cash used for capital spending.  During the second quarter of 2014, the Company completed the acquisition of Bombas Leao with cash on hand and short-term borrowings.  During the third quarter of 2014, the Company acquired controlling interests in two entities in India in separate transactions.  In evaluating potential future acquisitions that impact cash from investing, the Company reviews opportunities with an emphasis on increasing global distribution and also with an emphasis on adding complementary product lines that can be effectively marketed through existing global distribution. Additions to property, plant and equipment were significantly lower in the first nine months of 2014 compared to the first nine months of 2013.  During 2013, the Company's higher capital spending was due to the Global Corporate Headquarters and Engineering Center of Excellence project.

[0000038725-14-000200:mdna:131]
Net cash provided by financing activities was $11.4 million for the nine months ended September 27, 2014, compared to $14.1 million for the nine months ended September 28, 2013. The reduction in cash provided by financing activities in the first nine months of 2014 was primarily due to lower stock option exercises in the first nine months of 2014 compared to the first nine months of 2013.  This reduction was partially offset by a net increase in cash provided by the retirement of some third-party bank loans in Turkey and Brazil during the first nine months of 2014, a portion of such payoffs financed through the Revolver.

[0000038725-14-000200:mdna:132]
[same as prior period, unchanged from 0000038725-14-000166:mdna:128]

[0000038725-14-000200:mdna:133]
This quarterly report on Form 10-Q contains certain forward-looking information, such as statements about the Company’s financial goals, acquisition strategies, financial expectations including anticipated revenue or expense levels, business prospects, market positioning, product development, manufacturing re-alignment, capital expenditures, tax benefits and expenses, and the effect of contingencies or changes in accounting policies. Forward-looking statements are typically identified by words or phrases such as “believe,” “expect,” “anticipate,” “intend,” “estimate,” “may increase,” “may fluctuate,” “plan,” “goal,” “target,” “strategy,” and similar expressions or future or conditional verbs such as “may,” “will,” “should,” “would,” and “could.” While the Company believes that the assumptions underlying such forward-looking statements are reasonable based on present conditions, forward-looking statements made by the Company involve risks and uncertainties and are not
