# FELE notes — 0000038725-14-000200


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-14-000200:notes:1]
[same as prior period, unchanged from 0000038725-14-000166:notes:1]

[0000038725-14-000200:notes:2]
During the third quarter ended September 27, 2014, the Company acquired controlling interests in two entities in India in separate transactions.  Neither of the acquisitions was individually material, and the combined purchase price paid was approximately $6.6 million.  The results of the two businesses from their respective dates of acquisition through September 27, 2014 were not material.

[0000038725-14-000200:notes:3]
[same as prior period, unchanged from 0000038725-14-000166:notes:2]

[0000038725-14-000200:notes:4]
[same as prior period, unchanged from 0000038725-14-000166:notes:3]

[0000038725-14-000200:notes:5]
The Bombas Leao intangible assets of $23.5 million consist primarily of customer relationships, which will be amortized utilizing the straight line method over 20 years, and trade names, which are classified as indefinite lived assets and will not be amortized.  Preliminary intangible asset values decreased by $3.0 million during the third quarter ended September 27, 2014, primarily due to purchase accounting adjustments resulting from additional information provided for the provisional valuation and working capital adjustments.

[0000038725-14-000200:notes:6]
The preliminary goodwill of $3.0 million resulting from the Bombas Leao acquisition consists primarily of broadened product offerings and expanded customer base.  All of the goodwill was recorded as part of the Water Systems segment and is not expected to be deductible for tax purposes.  Preliminary goodwill decreased by $2.2 million during the third quarter ended September 27, 2014, primarily due to purchase accounting adjustments to property, plant, and equipment and intangible assets resulting from additional information provided for the provisional valuation.

[0000038725-14-000200:notes:7]
[same as prior period, unchanged from 0000038725-14-000166:notes:6]

[0000038725-14-000200:notes:8]
| (In millions) |  |
| Assets: |  |
| Cash acquired | $ | 1.1 |  |
| Current assets | 13.8 |  |
| Property, plant, and equipment | 6.5 |  |
| Intangible assets | 23.5 |  |
| Goodwill | 3.0 |  |
| Other assets | 3.1 |  |
| Total assets | 51.0 |  |
| Liabilities | (20.3 | ) |
| Total consideration paid | $ | 30.7 |  |

[0000038725-14-000200:notes:9]
The fair values of the Bombas Leao identifiable intangible assets and property, plant and equipment are provisional amounts as of September 27, 2014, pending final valuations and purchase accounting adjustments.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation process.

[0000038725-14-000200:notes:10]
The results of operations of Bombas Leao were included in the Company's condensed consolidated statement of income from the acquisition date through the third quarter ended September 27, 2014. The difference between actual sales for the Company and proforma sales including Bombas Leao as if it was acquired at the beginning of each period was not material as a component of the Company's consolidated sales for the nine months ended September 27, 2014 and September 28, 2013, respectively. Due to the immaterial nature of the acquisition, the Company has not included full year proforma statements of income for the acquisition year or previous year.

[0000038725-14-000200:notes:11]
Transaction costs for all acquisition related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations.  Transaction costs included in selling, general, and administrative expenses in the Company’s condensed consolidated statements of income for the nine months ended September 27, 2014 and September 28, 2013 were $1.1 million and $0.3 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000038725-14-000200:notes:12]
CONTINGENCIES AND COMMITMENTS

[0000038725-14-000200:notes:13]
In August 2010, the California Air Resources Board (“CARB”) and South Coast Air Quality Management District (“SCAQMD”) filed civil complaints in the Los Angeles Superior Court against the Company and Franklin Fueling Systems, Inc.  The complaints related to a third-party-supplied component part of the Company's Healy 900 Series nozzle, which is part of the Company's Enhanced Vapor Recovery (“EVR”) Systems installed in California gasoline filling stations.  This part, a diaphragm, was the subject of a retrofit during the first half of 2008.  As the Company previously reported, in October 2008 CARB issued a Notice of Violation to the Company alleging that the circumstances leading to the retrofit program violated California statutes and regulations.

[0000038725-14-000200:notes:14]
The claims in the complaints mirrored those that CARB presented to the Company in the Notice of Violation, and included claims that the Company negligently and intentionally sold nozzles with a modified diaphragm without required CARB certification. Those complaints were consolidated into one case in the Superior Court of California, County of Los Angeles (People of the State of California vs. Franklin Fueling Systems, Inc. et al.) which was tried in the later part of December 2012 and early part of January 2013 (“CARB Case”).

[0000038725-14-000200:notes:15]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company has until December 12, 2014 to file its response brief.  If a hearing is held on the appeal it will likely occur sometime late in the second quarter of 2015.

[0000038725-14-000200:notes:16]
Neither of these suits has had any effect on CARB's certification of the Company's EVR System or any other products of the Company or its subsidiaries, and did not interfere with continuing sales.  CARB has never decertified the Company's EVR System and has never proposed to do so.

[0000038725-14-000200:notes:17]
The Company is defending various other claims and legal actions, including environmental matters, which have arisen in the

[0000038725-14-000200:notes:18]
ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with

[0000038725-14-000200:notes:19]
counsel, these claims and legal actions can be successfully defended or resolved without a material adverse effect on the

[0000038725-14-000200:notes:20]
Company’s financial position, results of operations, and net cash flows.

[0000038725-14-000200:notes:21]
At September 27, 2014, the Company had $8.7 million of commitments primarily for the purchase of raw materials to be used in production.

[0000038725-14-000200:notes:22]
The company provides warranties on most of its products.  The warranty terms vary but are generally 2 years from date of manufacture or 1 year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to 5 years from date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-14-000200:notes:23]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 27, 2014, are as follows:

[0000038725-14-000200:notes:24]
| (In millions) |  |  |
| Balance as of December 28, 2013 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 6.3 |  |
| Reductions for payments made |  | (6.9 | ) |
| Balance as of September 27, 2014 |  | $ | 8.9 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-14-000200:notes:25]
[same as prior period, unchanged from 0000038725-14-000166:notes:24]

[0000038725-14-000200:notes:26]
Changes in accumulated other comprehensive income (loss) by component for the nine months ended September 27, 2014 and September 28, 2013, are summarized below:

[0000038725-14-000200:notes:27]
| (In millions) |  |  |  |  |  |
| For the nine months ended September 27, 2014: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance as of December 28, 2013 | $ | (16.0 | ) |  | $ | (38.7 | ) |  | $ | (54.7 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (18.2 | ) |  | — |  |  | (18.2 | ) |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (18.2 | ) |  | — |  |  | (18.2 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 2.2 |  | (1) | 2.2 |  |
| Income tax expense | — |  |  | (0.7 | ) |  | (0.7 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 1.5 |  |  | 1.5 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (18.2 | ) |  | 1.5 |  |  | (16.7 | ) |
| Other comprehensive (income)/loss attributable to noncontrolling interest | 0.4 |  |  | — |  |  | 0.4 |  |
| Balance as of September 27, 2014 | $ | (33.8 | ) |  | $ | (37.2 | ) |  | $ | (71.0 | ) |
| For the nine months ended September 28, 2013: |  |  |  |  |  |
| Balance as of December 29, 2012 | $ | (0.3 | ) |  | $ | (56.8 | ) |  | $ | (57.1 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (12.2 | ) |  | — |  |  | (12.2 | ) |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (12.2 | ) |  | — |  |  | (12.2 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 3.1 |  | (1) | 3.1 |  |
| Income tax expense | — |  |  | (1.1 | ) |  | (1.1 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 2.0 |  |  | 2.0 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (12.2 | ) |  | 2.0 |  |  | (10.2 | ) |
| Other comprehensive (income)/loss attributable to noncontrolling interest | 0.1 |  |  | — |  |  | 0.1 |  |
| Balance as of September 28, 2013 | $ | (12.4 | ) |  | $ | (54.8 | ) |  | $ | (67.2 | ) |

[0000038725-14-000200:notes:28]
[same as prior period, unchanged from 0000038725-14-000166:notes:27]


## us-gaap:DebtDisclosureTextBlock

[0000038725-14-000200:notes:29]
DEBT

[0000038725-14-000200:notes:30]
Debt consisted of the following:

[0000038725-14-000200:notes:31]
| (In millions) |  | September 27, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.7 |  |  | 24.6 |  |
| Revolver |  | 45.7 |  |  | — |  |
| Capital leases |  | 0.8 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 7.2 |  |  | 14.2 |  |
|  |  | 227.4 |  |  | 189.6 |  |
| Less current maturities |  | (82.7 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 144.7 |  |  | $ | 174.2 |  |

[0000038725-14-000200:notes:32]
Foreign subsidiary debt denoted in the table above is predominately comprised of debt at Impo and Bombas Leao.

[0000038725-14-000200:notes:33]
During the third quarter ended September 27, 2014, a portion of the Revolver borrowing was used to retire $16.5 million of third-party bank loans in Turkey and Brazil.

[0000038725-14-000200:notes:34]
On June 6, 2014, the Company assumed debt relating to the acquisition of Bombas Leao (see Note 3) of BRL 12.6 million, $5.6 million at the then current exchange rate.  The debt instruments bear interest rates ranging from 2.5 percent to 19.4 percent, with due dates ranging from November 2014 to November 2017.  There are no financial covenants associated with these debt instruments.  The value of the debt assumed in the Bombas Leao acquisition increased by BRL 0.2 million ($0.1 million) during the third quarter ended September 27, 2014 resulting from additional information provided for the provisional valuation and working capital adjustments.

[0000038725-14-000200:notes:35]
The total estimated fair value of debt was $241.4 million and $203.7 million at September 27, 2014 and December 28, 2013, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its long-term debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as a Level 2 within the valuations hierarchy.

[0000038725-14-000200:notes:36]
The following debt payments are expected to be paid in accordance with the following schedule:

[0000038725-14-000200:notes:37]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 226.6 |  |  | $ | 82.4 |  |  | $ | 31.6 |  |  | $ | 31.3 |  |  | $ | 31.4 |  |  | $ | 31.1 |  |  | $ | 18.8 |  |
| Capital leases |  | 0.8 |  |  | 0.3 |  |  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 227.4 |  |  | $ | 82.7 |  |  | $ | 31.7 |  |  | $ | 31.5 |  |  | $ | 31.5 |  |  | $ | 31.2 |  |  | $ | 18.8 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-14-000200:notes:38]
[same as prior period, unchanged from 0000038725-14-000166:notes:36]

[0000038725-14-000200:notes:39]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  During February 2014, the Company entered into a share swap transaction agreement ("the swap") to mitigate the Company’s exposure to these fluctuations in the Company's stock price.  The swap was not designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  The swap has a notional value based on 147,750 shares.  For the third quarter and nine months ended September 27, 2014, the swap transaction resulted in losses of $0.8 million and $1.1 million, respectively, which were offset by gains on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-14-000200:notes:40]
[same as prior period, unchanged from 0000038725-14-000166:notes:38]

[0000038725-14-000200:notes:41]
[same as prior period, unchanged from 0000038725-14-000166:notes:39]

[0000038725-14-000200:notes:42]
[same as prior period, unchanged from 0000038725-14-000166:notes:40]

[0000038725-14-000200:notes:43]
[same as prior period, unchanged from 0000038725-14-000166:notes:41]

[0000038725-14-000200:notes:44]
[same as prior period, unchanged from 0000038725-14-000166:notes:42]

[0000038725-14-000200:notes:45]
[same as prior period, unchanged from 0000038725-14-000166:notes:43]

[0000038725-14-000200:notes:46]
[same as prior period, unchanged from 0000038725-14-000166:notes:44]

[0000038725-14-000200:notes:47]
[same as prior period, unchanged from 0000038725-14-000166:notes:45]

[0000038725-14-000200:notes:48]
[same as prior period, unchanged from 0000038725-14-000166:notes:46]

[0000038725-14-000200:notes:49]
[same as prior period, unchanged from 0000038725-14-000166:notes:47]

[0000038725-14-000200:notes:50]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the nine months ended September 27, 2014 and September 28, 2013, are as follows:

[0000038725-14-000200:notes:51]
|  |  | September 27, 2014 |  | September 28, 2013 |
| Risk-free interest rate |  | 1.68 | % |  | 1.03 | % |
| Dividend yield |  | 0.70 | % |  | 0.89 | % |
| Volatility factor |  | 0.387 |  |  | 0.394 |  |
| Expected term |  | 5.6 years |  |  | 6.0 years |  |
| Forfeiture rate |  | 3.81 | % |  | 4.52 | % |

[0000038725-14-000200:notes:52]
There were no stock options granted during the third quarters ended September 27, 2014 and September 28, 2013.

[0000038725-14-000200:notes:53]
A summary of the Company’s outstanding stock option activity and related information for the nine months ended September 27, 2014 and September 28, 2013 is as follows:

[0000038725-14-000200:notes:54]
| (Shares in thousands) |  | September 27, 2014 |  | September 28, 2013 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,476 |  |  | $ | 19.01 |  |  | 2,184 |  |  | $ | 16.69 |  |
| Granted |  | 115 |  |  | 42.24 |  |  | 176 |  |  | 32.53 |  |
| Exercised |  | (76 | ) |  | 17.68 |  |  | (807 | ) |  | 16.06 |  |
| Forfeited |  | (4 | ) |  | 27.12 |  |  | (4 | ) |  | 14.37 |  |
| Expired |  | (17 | ) |  | 16.34 |  |  | — |  |  | — |  |
| Outstanding at end of period |  | 1,494 |  |  | $ | 20.88 |  |  | 1,549 |  |  | $ | 18.83 |  |
| Expected to vest after applying forfeiture rate |  | 1,479 |  |  | $ | 20.73 |  |  | 1,527 |  |  | $ | 18.68 |  |
| Vested and exercisable at end of period |  | 1,180 |  |  | $ | 17.69 |  |  | 1,017 |  |  | $ | 15.43 |  |

[0000038725-14-000200:notes:55]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value for the nine months ended September 27, 2014 is as follows:

[0000038725-14-000200:notes:56]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.40 years |  | $ | 22,234 |  |
| Expected to vest after applying forfeiture rate |  | 5.36 years |  | $ | 22,184 |  |
| Vested and exercisable at end of period |  | 4.60 years |  | $ | 20,689 |  |

[0000038725-14-000200:notes:57]
The total intrinsic value of options exercised during the third quarters ended September 27, 2014 and September 28, 2013, was $1.8 million and $14.6 million, respectively.

[0000038725-14-000200:notes:58]
As of September 27, 2014, there was $1.8 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements related to stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.45 years.

[0000038725-14-000200:notes:59]
[same as prior period, unchanged from 0000038725-14-000166:notes:57]

[0000038725-14-000200:notes:60]
A summary of the Company’s restricted stock/stock unit award activity and related information for the nine months ended September 27, 2014 and September 28, 2013 is as follows:

[0000038725-14-000200:notes:61]
| (Shares in thousands) |  | September 27, 2014 |  | September 28, 2013 |
| Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 551 |  |  | $ | 24.75 |  |  | 458 |  |  | $ | 20.90 |  |
| Awarded |  | 208 |  |  | 42.39 |  |  | 165 |  |  | 32.90 |  |
| Vested |  | (124 | ) |  | 16.76 |  |  | (62 | ) |  | 18.86 |  |
| Forfeited |  | (65 | ) |  | 28.79 |  |  | (6 | ) |  | 20.05 |  |
| Non-vested at end of period |  | 570 |  |  | $ | 32.46 |  |  | 555 |  |  | $ | 24.70 |  |

[0000038725-14-000200:notes:62]
As of September 27, 2014, there was $9.8 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements related to stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.48 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-14-000200:notes:63]
[same as prior period, unchanged from 0000038725-14-000166:notes:61]

[0000038725-14-000200:notes:64]
[same as prior period, unchanged from 0000038725-14-000166:notes:62]

[0000038725-14-000200:notes:65]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-14-000200:notes:66]
[same as prior period, unchanged from 0000038725-14-000166:notes:64]

[0000038725-14-000200:notes:67]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions, except per share amounts) | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 22.7 |  |  | $ | 25.1 |  |  | $ | 66.7 |  |  | $ | 68.7 |  |
| Less: Undistributed earnings allocated to participating securities | 0.2 |  |  | 0.3 |  |  | 0.7 |  |  | 0.9 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | 0.4 |  |  | — |  |  | 0.6 |  |  | — |  |
|  | $ | 22.1 |  |  | $ | 24.8 |  |  | $ | 65.4 |  |  | $ | 67.8 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  |  |  |  |  |
| Weighted average common shares | 47.6 |  |  | 47.6 |  |  | 47.7 |  |  | 47.4 |  |
| Diluted |  |  |  |  |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee and director incentive stock options and performance awards | 0.5 |  |  | 0.6 |  |  | 0.5 |  |  | 0.7 |  |
| Adjusted weighted average common shares | 48.1 |  |  | 48.2 |  |  | 48.2 |  |  | 48.1 |  |
| Basic earnings per share | $ | 0.46 |  |  | $ | 0.52 |  |  | $ | 1.37 |  |  | $ | 1.43 |  |
| Diluted earnings per share | $ | 0.46 |  |  | $ | 0.51 |  |  | $ | 1.36 |  |  | $ | 1.41 |  |
| Anti-dilutive stock options | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-14-000200:notes:68]
As of September 27, 2014 and December 28, 2013, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below.

[0000038725-14-000200:notes:69]
| (In millions) | September 27, 2014 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) | Recognized Loss |
| Cash equivalents | $ | 5.2 |  | $ | 5.2 |  | $ | — |  | $ | — |  | $ | — |  |
|  | December 28, 2013 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) | Recognized Loss |
| Cash equivalents | $ | 6.6 |  | $ | 6.6 |  | $ | — |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-14-000200:notes:70]
[same as prior period, unchanged from 0000038725-14-000166:notes:68]

[0000038725-14-000200:notes:71]
[same as prior period, unchanged from 0000038725-14-000166:notes:69]

[0000038725-14-000200:notes:72]
[same as prior period, unchanged from 0000038725-14-000166:notes:70]

[0000038725-14-000200:notes:73]
[same as prior period, unchanged from 0000038725-14-000166:notes:71]

[0000038725-14-000200:notes:74]
[same as prior period, unchanged from 0000038725-14-000166:notes:72]

[0000038725-14-000200:notes:75]
The Company's Level 1 assets consist of cash equivalents which are generally comprised of foreign bank guaranteed certificates of deposit.

[0000038725-14-000200:notes:76]
[same as prior period, unchanged from 0000038725-14-000166:notes:74]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-14-000200:notes:77]
[same as prior period, unchanged from 0000038725-14-000166:notes:75]

[0000038725-14-000200:notes:78]
[same as prior period, unchanged from 0000038725-14-000166:notes:76]

[0000038725-14-000200:notes:79]
| (In millions) |  | September 27, 2014 |  | December 28, 2013 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.7 |  |  | $ | (6.1 | ) |  | $ | 7.8 |  |  | $ | (5.9 | ) |
| Supply agreements |  | 4.4 |  |  | (4.4 | ) |  | 4.4 |  |  | (4.4 | ) |
| Technology |  | 7.5 |  |  | (4.1 | ) |  | 7.5 |  |  | (3.8 | ) |
| Customer relationships |  | 142.8 |  |  | (34.9 | ) |  | 125.1 |  |  | (29.7 | ) |
| Software |  | 2.7 |  |  | (0.9 | ) |  | 2.1 |  |  | (0.4 | ) |
| Other |  | 1.2 |  |  | (1.2 | ) |  | 1.3 |  |  | (1.2 | ) |
| Total |  | $ | 166.3 |  |  | $ | (51.6 | ) |  | $ | 148.2 |  |  | $ | (45.4 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 51.9 |  |  | — |  |  | 45.9 |  |  | — |  |
| Total intangibles |  | $ | 218.2 |  |  | $ | (51.6 | ) |  | $ | 194.1 |  |  | $ | (45.4 | ) |

[0000038725-14-000200:notes:80]
Amortization expense related to intangible assets for the third quarters ended September 27, 2014 and September 28, 2013 was $2.7 million and $1.9 million, respectively, and $6.8 million and $5.9 million for the nine months ended September 27, 2014 and September 28, 2013, respectively.

[0000038725-14-000200:notes:81]
[same as prior period, unchanged from 0000038725-14-000166:notes:79]

[0000038725-14-000200:notes:82]
| (In millions) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |
|  |  | $ | 8.7 |  |  | $ | 9.1 |  |  | $ | 9.1 |  |  | $ | 8.9 |  |  | $ | 8.7 |  |

[0000038725-14-000200:notes:83]
The change in the carrying amount of goodwill by reporting segment for the nine months ended September 27, 2014, is as follows:

[0000038725-14-000200:notes:84]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of December 28, 2013 |  | $ | 144.1 |  |  | $ | 63.1 |  |  | $ | 207.2 |  |
| Acquisitions |  | 6.4 |  |  | 0.7 |  |  | 7.1 |  |
| Foreign currency translation |  | (3.0 | ) |  | (0.1 | ) |  | (3.1 | ) |
| Balance as of September 27, 2014 |  | $ | 147.5 |  |  | $ | 63.7 |  |  | $ | 211.2 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-14-000200:notes:85]
[same as prior period, unchanged from 0000038725-14-000166:notes:83]

[0000038725-14-000200:notes:86]
The effective tax rate continues to be lower than the U.S. statutory rate of 35.0 percent primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate as well as recognition of U.S. and foreign tax credits.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its operations as well as cash on hand and available credit.

[0000038725-14-000200:notes:87]
The Company's net unrecognized tax benefits decreased $2.2 million for federal and state income tax liabilities of prior years based on the expiration of the statute of limitations and foreign currency fluctuations during the third quarter ended September 27, 2014.

[0000038725-14-000200:notes:88]
If recognized, the effective tax rate would be affected by the net unrecognized tax benefits of $6.9 million as of September 27, 2014.

[0000038725-14-000200:notes:89]
It is reasonably possible that the amounts of unrecognized tax benefits could change in the next twelve months by an amount up to $1.7 million due to the expiration of various statutes of limitation.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000038725-14-000200:notes:90]
[same as prior period, unchanged from 0000038725-14-000166:notes:86]

[0000038725-14-000200:notes:91]
During the third quarter ended September 27, 2014, the Company completed two acquisitions that each contained a noncontrolling interest and a redemption feature.  The combination of the noncontrolling interest and the redemption feature resulted in the classification as a redeemable noncontrolling interest.  The total redeemable noncontrolling interest recorded for these acquisitions during the third quarter ended September 27, 2014 was $3.1 million, and represents the fair value estimates of the redeemable noncontrolling interests as of the respective acquisition dates.  The noncontrolling interests become redeemable after the passage of time, and therefore the Company records the carrying amount of the noncontrolling interests at the greater of (1) the initial carrying amount, increased or decreased for each noncontrolling interest's share of net income or loss and its share of other comprehensive income or loss and dividends ("carrying amount") or (2) the redemption value which is determined based on the greater of the redemption floor value or the then-current specified earnings multiple.  As of September 27, 2014, the redeemable noncontrolling interests related to these acquisitions were recorded at carrying value.

[0000038725-14-000200:notes:92]
[same as prior period, unchanged from 0000038725-14-000166:notes:87]

[0000038725-14-000200:notes:93]
During the second quarter of 2014, the Company redeemed 10 percent of the noncontrolling interest of Impo, increasing the Company's ownership to 90 percent for approximately TRY 6.2 million, $2.9 million at the then current exchange rate.  The 10 percent redemption value was calculated using a specified formula and resulted in a carrying value adjustment of TRY 0.2 million ($0.1 million).  The redemption reduced the "Redeemable noncontrolling interest" line in the Company's condensed consolidated balance sheet.  The remaining 10 percent noncontrolling interest will continue to be recorded as a redeemable noncontrolling interest on the balance sheet.  Due to the immaterial nature of the redemption, the Company has not included full year proforma statements of income for the acquisition year or previous year.

[0000038725-14-000200:notes:94]
The remaining redeemable noncontrolling interest in Impo is redeemable at other than fair value as the redemption value is determined based on a specified formula.  The noncontrolling interest becomes redeemable after the passage of time, and therefore the Company records the carrying amount of the noncontrolling interest at the greater of (1) the initial carrying amount, increased or decreased for each noncontrolling interest's share of net income or loss and its share of other comprehensive income or loss and dividends or (2) the redemption value which is determined based on the greater of the redemption floor value or the then-current specified earnings multiple.  As of September 27, 2014, the Impo redeemable noncontrolling interest was recorded at the redemption value.

[0000038725-14-000200:notes:95]
According to FASB ASC Topic 810, Consolidation and Emerging Issues Task Force ("EITF") Topic No. D-98, Classification and Measurement of Redeemable Securities, if redeemable noncontrolling interests are issued in the form of common securities, to the extent that the noncontrolling interest holder has a contractual right to receive an amount upon share redemption, then the noncontrolling interest holder has, in substance, received a dividend distribution that is different from other common shareholders.  Therefore, adjustments to the noncontrolling interest to reflect the redemption amount should be reflected in the computation of earnings per share using the two-class method.  Under the two-class method, the Company has elected to treat as a dividend only the portion of the periodic redemption value adjustment (if any) that reflects a redemption value in excess of carrying value.  Adjustments for both the redeemed and redeemable Impo noncontrolling interests were $0.4 million and $0.6 million for the third quarter and nine months ended September 27, 2014, respectively.  Adjustments of less than $0.1 million were necessary for the third quarter and nine months ended September 28, 2013.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-14-000200:notes:96]
ACCOUNTING PRONOUNCEMENTS

[0000038725-14-000200:notes:97]
In April 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2014-08 Presentation of Financial Statements and Property, Plant and Equipment: Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity.  ASU 2014-08 raises the threshold for a disposal to qualify as a discontinued operation and requires new disclosures of both discontinued operations and certain other disposals that do not meet the definition of a discontinued operation. ASU 2014-08 is effective for annual periods beginning after December 15, 2014, and interim periods within annual periods beginning on or after December 15, 2015, with early adoption permitted.  The Company has adopted this standard with no impact on the Company’s consolidated financial position, results of operations, or cash flows.

[0000038725-14-000200:notes:98]
In May 2014, the FASB issued ASU 2014-09 Revenue from Contracts with Customers.  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  The ASU is effective for annual reporting periods beginning after December 15, 2016 and early adoption is not permitted.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt the new ASU.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, and cash flows.

[0000038725-14-000200:notes:99]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide That the Performance Target Could Be Achieved After the Requisite Service Period.  The amendments in the ASU require that a performance target that affects vesting and that could be achieved after the requisite service period be treated as a performance condition.  A reporting entity should apply existing guidance in Topic 718, Compensation - Stock Compensation, as it relates to awards with performance conditions that affect vesting to account for such awards.  The amendments in the ASU are effective for annual periods beginning after December 15, 2015, and interim periods within annual periods beginning on or after December 15, 2015, with early adoption permitted.  The Company has adopted this standard with no impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-14-000200:notes:100]
[same as prior period, unchanged from 0000038725-14-000166:notes:96]

[0000038725-14-000200:notes:101]
The accompanying condensed consolidated balance sheet as of December 28, 2013, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 27, 2014, and for the third quarters and nine months ended September 27, 2014 and September 28, 2013, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the third quarter and nine months ended September 27, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending January 3, 2015.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K/A for the year ended December 28, 2013.

[0000038725-14-000200:notes:102]
Certain prior year amounts in the investing activities section on the condensed consolidated statement of cash flows were reclassified into the "Other, net" line to conform with the current year presentation.  The reclassification within the investing activities section of the condensed consolidated statement of cash flows had no impact on the operating cash flows or any other financial statement.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000038725-14-000200:notes:103]
[same as prior period, unchanged from 0000038725-14-000166:notes:99]

[0000038725-14-000200:notes:104]
The Company has equity interests in various companies for strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s condensed consolidated balance sheet.  The carrying amount of the investments are adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income, net" line of the Company's condensed consolidated statements of income, was immaterial for the third quarter and nine months ended September 27, 2014.

[0000038725-14-000200:notes:105]
The Company has a loan agreement with the parent company of a customer.  The current maturity is included in "Receivables" and the long-term portion is included in "Other assets, net" on the Company's condensed consolidated balance sheet.  The agreement provides for interest on the loan at a variable market interest rate with the debtor to repay the loan plus interest in semi-annual installments.  The Company has a long-term relationship with the customer and considers the loan fully collectible.   The loan is not considered material to the Company’s financial position.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-14-000200:notes:106]
[same as prior period, unchanged from 0000038725-14-000166:notes:102]

[0000038725-14-000200:notes:107]
Defined Benefit Plans - As of September 27, 2014, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 28, 2013 measurement date for these plans.

[0000038725-14-000200:notes:108]
[same as prior period, unchanged from 0000038725-14-000166:notes:104]

[0000038725-14-000200:notes:109]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the third quarters and nine months ended September 27, 2014 and September 28, 2013, respectively:

[0000038725-14-000200:notes:110]
| (In millions) | Pension Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Service cost | $ | 0.3 |  |  | $ | 0.5 |  |  | $ | 1.0 |  |  | $ | 1.5 |  |
| Interest cost | 2.1 |  |  | 2.2 |  |  | 6.2 |  |  | 6.0 |  |
| Expected return on assets | (2.7 | ) |  | (3.0 | ) |  | (7.9 | ) |  | (8.0 | ) |
| Amortization of prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of loss | 0.7 |  |  | 1.0 |  |  | 1.9 |  |  | 2.7 |  |
| Net periodic benefit cost | $ | 0.4 |  |  | $ | 0.7 |  |  | $ | 1.2 |  |  | $ | 2.2 |  |
| Settlement cost | 0.3 |  |  | — |  |  | 0.7 |  |  | — |  |
| Total net periodic benefit cost | $ | 0.7 |  |  | $ | 0.7 |  |  | $ | 1.9 |  |  | $ | 2.2 |  |

[0000038725-14-000200:notes:111]
In the nine months ended September 27, 2014, the Company made contributions of $5.4 million to the funded plans.  The amount of contributions to be made to the plans during the calendar year 2014 was finalized September 15, 2014, based upon the plan's year-end valuation at December 28, 2013, and the funding level required for the plan year ended December 28, 2013.

[0000038725-14-000200:notes:112]
The following table sets forth the aggregated net periodic benefit cost for the postretirement benefit plan for the third quarters and nine months ended September 27, 2014 and September 28, 2013, respectively:

[0000038725-14-000200:notes:113]
|  | Other Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | 0.1 |  |
| Interest cost | 0.2 |  |  | 0.2 |  |  | 0.4 |  |  | 0.4 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Amortization of loss | — |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Net periodic benefit cost | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.8 |  |  | $ | 1.0 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.8 |  |  | $ | 1.0 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-14-000200:notes:114]
[same as prior period, unchanged from 0000038725-14-000166:notes:110]

[0000038725-14-000200:notes:115]
On July 1, 2014, the Company announced a plan to close its Wittlich, Germany manufacturing facility.  As part of this action, the Company will transfer the existing Wittlich manufacturing activity to its Brno, Czech Republic facility.  The Company will maintain its European Water Systems headquarters and distribution center in Wittlich, only the manufacturing operations will be relocating.  The realignment began in the third quarter of 2014 and is estimated to conclude by the end of 2016.  Charges for the realignment are expected to include severance expenses, professional service fees, asset write-offs, and temporarily leased facilities costs.  The Company will provide actual costs incurred each reporting period and update the project estimates as information is available.

[0000038725-14-000200:notes:116]
Costs incurred in the third quarter and nine months ended September 27, 2014, included in the “Restructuring expense” line of the Company's condensed consolidated statements of income, are as follows:

[0000038725-14-000200:notes:117]
|  |  | Third Quarter Ended |
|  |  | September 27, 2014 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.2 |  |
| Equipment relocation |  | 0.4 |  |  | — |  |  | — |  |  | 0.4 |  |
| Asset write-off |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Other |  | 0.4 |  |  | — |  |  | — |  |  | 0.4 |  |
| Total |  | $ | 1.0 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 1.1 |  |
|  |  | Nine Months Ended |
|  |  | September 27, 2014 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.4 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.5 |  |
| Equipment relocation |  | 0.4 |  |  | — |  |  | — |  |  | 0.4 |  |
| Asset write-off |  | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |
| Other |  | 0.4 |  |  | — |  |  | — |  |  | 0.4 |  |
| Total |  | $ | 1.4 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 1.5 |  |

[0000038725-14-000200:notes:118]
Restructuring expenses for the third quarter ended September 28, 2013 were approximately $0.8 million, and primarily related to the relocation of the Company to the new Global Corporate Headquarters and Engineering Center of Excellence in Fort Wayne, Indiana.  Restructuring expenses of $2.2 million were incurred in the nine months ended September 28, 2013, primarily relating to severance due to other miscellaneous manufacturing realignments, and expenses related to relocation to the new Global Corporate Headquarters and Engineering Center of Excellence in Fort Wayne, Indiana.

[0000038725-14-000200:notes:119]
As of September 27, 2014, there was $0.3 million in restructuring reserves primarily for severance.  As of September 28, 2013, there were no restructuring reserves.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-14-000200:notes:120]
[same as prior period, unchanged from 0000038725-14-000166:notes:115]

[0000038725-14-000200:notes:121]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions) | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
|  | Net sales to external customers |
| Water Systems | $ | 216.6 |  |  | $ | 197.9 |  |  | $ | 627.8 |  |  | $ | 588.1 |  |
| Fueling Systems | 61.5 |  |  | 51.9 |  |  | 166.1 |  |  | 147.7 |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |
| Consolidated | $ | 278.1 |  |  | $ | 249.8 |  |  | $ | 793.9 |  |  | $ | 735.8 |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
|  | Operating income (loss) |
| Water Systems | $ | 28.3 |  |  | $ | 36.0 |  |  | $ | 99.3 |  |  | $ | 107.3 |  |
| Fueling Systems | 15.4 |  |  | 14.0 |  |  | 37.9 |  |  | 31.1 |  |
| Other | (11.3 | ) |  | (12.3 | ) |  | (39.7 | ) |  | (36.8 | ) |
| Consolidated | $ | 32.4 |  |  | $ | 37.7 |  |  | $ | 97.5 |  |  | $ | 101.6 |  |
|  | September 27, 2014 |  | December 28, 2013 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 811.9 |  |  | $ | 714.7 |  |  |  |  |  |
| Fueling Systems | 259.5 |  |  | 247.9 |  |  |  |  |  |
| Other | 74.0 |  |  | 89.3 |  |  |  |  |  |
| Consolidated | $ | 1,145.4 |  |  | $ | 1,051.9 |  |  |  |  |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-14-000200:notes:122]
The schedule below sets forth equity changes in the nine months ended September 27, 2014:

[0000038725-14-000200:notes:123]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 28, 2013 | $ | 4,771 |  |  | $ | 194,810 |  |  | $ | 450,855 |  |  | $ | (38,707 | ) |  | $ | (16,022 | ) |  | $ | 2,509 |  |  | $ | 598,216 |  |  | $ | 5,171 |  |
| Net income |  |  |  |  | 66,704 |  |  |  |  |  |  | 525 |  |  | 67,229 |  |  | 455 |  |
| Adjustment to Impo redemption value |  |  |  |  | (621 | ) |  |  |  |  |  |  |  | (621 | ) |  | 621 |  |
| Dividends on common stock |  |  |  |  | (12,319 | ) |  |  |  |  |  |  |  | (12,319 | ) |  |  |
| Common stock issued | 8 |  |  | 1,343 |  |  |  |  |  |  |  |  |  |  | 1,351 |  |  |  |
| Common stock repurchased or received for stock options exercised | (23 | ) |  |  |  | (8,619 | ) |  |  |  |  |  |  |  | (8,642 | ) |  |  |
| Share-based compensation | — |  |  | 6,314 |  |  |  |  |  |  |  |  |  |  | 6,314 |  |  |  |
| Tax benefit of stock options exercised |  |  | 1,590 |  |  |  |  |  |  |  |  |  |  | 1,590 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (800 | ) |  | (800 | ) |  |  |
| Acquisitions |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3,078 |  |
| Purchase of redeemable non-controlling shares |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2,875 | ) |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (17,779 | ) |  | (144 | ) |  | (17,923 | ) |  | (189 | ) |
| Pension liability, net of tax |  |  |  |  |  |  | 1,460 |  |  |  |  |  |  | 1,460 |  |  |  |
| Balance as of September 27, 2014 | $ | 4,756 |  |  | $ | 204,057 |  |  | $ | 496,000 |  |  | $ | (37,247 | ) |  | $ | (33,801 | ) |  | $ | 2,090 |  |  | $ | 635,855 |  |  | $ | 6,261 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-14-000200:notes:124]
[same as prior period, unchanged from 0000038725-14-000166:notes:119]

[0000038725-14-000200:notes:125]
Property, plant, and equipment is the major asset group in "Other" of total assets at September 27, 2014.  Cash is the major asset group in “Other” of total assets at December 28, 2013.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-14-000200:notes:126]
[same as prior period, unchanged from 0000038725-14-000166:notes:121]
