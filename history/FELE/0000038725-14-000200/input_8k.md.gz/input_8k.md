# FELE 8-K — 0000038725-14-000189 filed 2014-10-29

## item codes, every 8-K on or before 2014-11-06

- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2014-11-06

- none on or before 2014-11-06

## item 2.02 — earnings release, exhibit 99.1

[0000038725-14-000189:8k_2_02:1]
EX-99.1
2
a20141029exhibit991.htm
EXHIBIT

[0000038725-14-000189:8k_2_02:2]
2014.10.29. Exhibit 99.1

[0000038725-14-000189:8k_2_02:3]
Exhibit 99.1

[0000038725-14-000189:8k_2_02:4]
For Immediate Release

[0000038725-14-000189:8k_2_02:5]
For Further Information

[0000038725-14-000189:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-14-000189:8k_2_02:7]
260-824-2900

[0000038725-14-000189:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS RECORD THIRD QUARTER

[0000038725-14-000189:8k_2_02:9]
2014 SALES AND EARNINGS

[0000038725-14-000189:8k_2_02:10]
Fort Wayne, Indiana - October 29, 2014 - Franklin Electric Co., Inc. (NASDAQ:FELE) reported third quarter 2014 adjusted earnings per share (EPS) of $0.50 compared to 2013 third quarter adjusted EPS of $0.50, flat to last year (see table below for a reconciliation of GAAP EPS to the adjusted EPS).  In the third quarter of 2014, the Company’s GAAP fully diluted EPS was $0.46, which was down 10 percent to the GAAP fully diluted EPS from the third quarter of 2013.

[0000038725-14-000189:8k_2_02:11]
Third quarter 2014 sales were $278.1 million, an increase of 11 percent compared to 2013 third quarter sales of $249.8 million and a record for any third quarter in the Company’s history.  The Company’s organic sales growth was about 8 percent excluding acquisitions and the impact of foreign currency translation.

[0000038725-14-000189:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chief Executive Officer, commented:

[0000038725-14-000189:8k_2_02:13]
“Despite an unfavorable sales mix shift in our Water businesses, we are pleased to report record sales for the third quarter of 2014 and adjusted earnings per share equal to last year’s third quarter, which were the highest adjusted earnings per share for any third quarter in the Company’s history.

[0000038725-14-000189:8k_2_02:14]
“Our Fueling Systems business contributed solid results in the quarter with revenues growing by nearly 20 percent and adjusted operating income increasing by 26 percent.

[0000038725-14-000189:8k_2_02:15]
“During the third quarter we announced two acquisitions in India, one in Water and one in Fueling.  Both of these acquisitions, along with the Bombas Leao acquisition in Brazil during the second quarter, will further expand our reach and distribution channels into developing regions and markets.  Sales in developing regions were about 40 percent of our consolidated revenues and were another solid achievement in the quarter, growing by 20 percent from the third quarter of the prior year.”

[0000038725-14-000189:8k_2_02:16]
Key Performance Indicators:

[0000038725-14-000189:8k_2_02:17]
| Earnings Before and After Non-GAAP Adjustments |  | For the Third Quarter |
| (in millions) |  | 2014 | 2013 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 22.7 |  | $ | 25.1 |  | (10 | )% |
| Allocated Undistributed Earnings |  | $ | (0.6 | ) | $ | (0.3 | ) |  |
| Adjusted Earnings for EPS Calculations |  | $ | 22.1 |  | $ | 24.8 |  | (11 | )% |
| Non-GAAP adjustments (before tax): |  |  |  |  |
| Restructuring |  | $ | 1.1 |  | $ | 0.8 |  |  |
| Non-GAAP items |  | $ | 1.9 |  | $ | (1.5 | ) |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |
| Restructuring |  | $ | 0.7 |  | $ | 0.5 |  |  |
| Non-GAAP items |  | $ | 1.2 |  | $ | (0.9 | ) |  |
| Earnings after Non-GAAP Adjustments |  | $ | 24.0 |  | $ | 24.4 |  | (2 | )% |
| Earnings Per Share |  | For the Third Quarter |
| Before and After Non-GAAP Adjustments |  | 2014 | 2013 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 48.1 |  | 48.2 |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.46 |  | $ | 0.51 |  | (10 | )% |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | 0.01 |  |  |
| Non-GAAP items |  | $ | 0.03 |  | $ | (0.02 | ) |  |
| Fully Diluted EPS after Non-GAAP Adjustments(Adjusted EPS) |  | $ | 0.50 |  | $ | 0.50 |  | — | % |

[0000038725-14-000189:8k_2_02:18]
| Net Sales | For the Third Quarter |
| (in millions) | Water | Fueling | Consolidated |
| Sales for 2013 | $ | 197.9 |  | $ | 51.9 |  | $ | 249.8 |  |
| Acquisitions | $ | 9.9 |  | $ | 0.1 |  | $ | 10.0 |  |
| Foreign Exchange | $ | (2.9 | ) | $ | 0.3 |  | $ | (2.6 | ) |
| Volume/Price Change | $ | 11.7 |  | $ | 9.2 |  | $ | 20.9 |  |
| Sales for 2014 | $ | 216.6 |  | $ | 61.5 |  | $ | 278.1 |  |

[0000038725-14-000189:8k_2_02:19]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Third Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 28.3 |  | $ | 15.4 |  | $ | (11.3 | ) | $ | 32.4 |  |
| % Operating Income To Net Sales | 13.1 | % | 25.0 | % |  | 11.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.0 |  | $ | 0.1 |  | $ | — |  | $ | 1.1 |  |
| Non-GAAP | $ | 1.7 |  | $ | 0.2 |  |  | $ | 1.9 |  |
| Operating Income after Non-GAAP Adjustments | $ | 31.0 |  | $ | 15.7 |  | $ | (11.3 | ) | $ | 35.4 |  |
| % Operating Income to Net Sales After non-GAAP adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.3 | % | 25.5 | % |  | 12.7 | % |
|  | For the Third Quarter 2013 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 36.0 |  | $ | 14.0 |  | $ | (12.3 | ) | $ | 37.7 |  |
| % Operating Income To Net Sales | 18.2 | % | 27.0 | % |  | 15.1 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.7 |  | $ | 0.1 |  | $ | — |  | $ | 0.8 |  |
| Non-GAAP | $ | 0.1 |  | $ | (1.6 | ) | $ | — |  | $ | (1.5 | ) |
| Operating Income after Non-GAAP Adjustments | $ | 36.8 |  | $ | 12.5 |  | $ | (12.3 | ) | $ | 37.0 |  |
| % Operating Income to Net Sales After non-GAAP adjustments (Operating Income Margin after Non-GAAP Adjustments) | 18.6 | % | 24.1 | % |  | 14.8 | % |

[0000038725-14-000189:8k_2_02:20]
Water Systems

[0000038725-14-000189:8k_2_02:21]
Water Systems sales were $216.6 million in the third quarter 2014, an increase of $18.7 million or about 9 percent versus the third quarter 2013 sales of $197.9 million.  Sales from businesses acquired since the third quarter of 2013 were $9.9 million or about 5 percent.  Water Systems sales were reduced by $2.9 million or about 1 percent in the quarter due to foreign currency translation.  Water Systems sales growth, excluding acquisitions and foreign currency translation, was about 6 percent.

[0000038725-14-000189:8k_2_02:22]
Water Systems sales in the U.S. and Canada represented 41 percent of consolidated sales and increased by about 5 percent compared to the prior year.  U.S. and Canada sales of Pioneer branded mobile pumping equipment increased by over 75 percent in the third quarter of 2014 compared to the prior year.  Sales of surface water pumping equipment grew by 6 percent in the third quarter.  These sales increases in the U.S and Canada were partially offset by lower sales of groundwater pumping equipment which declined about 16 percent in the quarter due principally to weaker demand in the agriculture sector as a result of less favorable weather and, to a lesser extent, the continuing inventory reset which has resulted from distributor changes in the channel.

[0000038725-14-000189:8k_2_02:23]
Water Systems sales in Latin America were about 14 percent of consolidated sales for the third quarter and increased by about 34 percent compared to the third quarter 2013.  Foreign currency translation had an insignificant impact on Latin American sales compared to the third quarter prior year.  Acquisition related sales were about 27 percent, and after excluding acquisitions and the impact of foreign currency translation, Latin American sales increased 7 percent.  Sales in Brazil were up 10 percent in the quarter and distribution outlets in Chile and Colombia also contributed to increased sales in these markets compared to the third quarter 2013.

[0000038725-14-000189:8k_2_02:24]
Water Systems sales in the Middle East and Africa were about 10 percent of consolidated sales and were flat compared to the third quarter 2013.  Excluding the impact of foreign currency translation, sales increased by about 6 percent compared to the third quarter 2013. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-14-000189:8k_2_02:25]
Water Systems sales in Europe were about 7 percent of consolidated sales and declined by about 5 percent compared to the third quarter 2013.  Acquisition related sales were about 1 percent.  The impact of foreign currency translation decreased sales by about 1 percent compared to the third quarter 2013.  Excluding acquisitions and the impact of foreign currency translation, European sales decreased about 5 percent compared to the third quarter 2013. Sales were flat across the Franklin branded Water Systems products in Europe but down in the Pioneer branded mobile pumping equipment products in the third quarter 2014.

[0000038725-14-000189:8k_2_02:26]
Water Systems sales in the Asia Pacific region were about 6 percent of consolidated sales and increased by about 38 percent compared to the third quarter 2013.  Excluding acquisitions, Asia Pacific sales increased by about 24 percent compared to the third quarter prior year.  Sales in Australia grew by 68 percent led by improved Pioneer product sales in the region and aided in part by the launch of the new solar powered water well pumping system.  Sales in Southeast Asia grew by 48 percent compared to the third quarter prior year, as the Company continues to benefit from improved customer service levels attributable to Company owned inventory in the region.

[0000038725-14-000189:8k_2_02:27]
Water Systems operating income, after non-GAAP adjustments, was $31.0 million in the third quarter 2014, a decrease of about 16 percent versus the third quarter 2013. The third quarter operating income margin after non-GAAP adjustments was 14.3 percent, down 430 basis points from 18.6 percent in the third quarter of 2013.

[0000038725-14-000189:8k_2_02:28]
Water Systems adjusted operating income margin declined primarily due to a sales mix shift during the third quarter. Historical Water Systems sales mix is 65 percent groundwater and 35 percent surface pumping equipment. During the third quarter 2014, the actual sales mix was 59 percent groundwater and 41 percent surface water pumping equipment. The shift primarily occurred because of a decline in the sale of pumps for agricultural irrigation and rapid growth of the Pioneer branded mobile pumping equipment products. The profit margin on agricultural irrigation pumps is higher than that on surface pumps.  Water Systems margins also declined in the quarter due to higher fixed costs, in part from recent acquisitions.

[0000038725-14-000189:8k_2_02:29]
Fueling Systems

[0000038725-14-000189:8k_2_02:30]
Fueling Systems sales represented 22 percent of consolidated sales and were $61.5 million in the third quarter 2014, an increase of $9.6 million or about 19 percent versus the third quarter 2013 sales of $51.9 million. Fueling Systems sales increased by $0.3 million or less than 1 percent in the quarter due to foreign currency translation. Fueling Systems acquisition related sales in the third quarter were less than 1 percent.  Excluding acquisitions and the impact of foreign currency translation, Fueling Systems sales increased about 18 percent compared to the third quarter 2013.

[0000038725-14-000189:8k_2_02:31]
During the third quarter, Fueling Systems shipped about $3.5 million of equipment to India to partially fill a large customer order. Excluding the impact of these India sales, Fueling Systems sales grew by about 11 percent. Sales growth was across all product lines and all regions of the world.

[0000038725-14-000189:8k_2_02:32]
Fueling Systems operating income after non-GAAP adjustments was $15.7 million in the third quarter of 2014 compared to $12.5 million after non-GAAP adjustments in the third quarter of 2013, an increase of about 26 percent. The third quarter operating income margin after non-GAAP adjustments was 25.5 percent, an increase of 140 basis points from the 24.1 percent of net sales in the third quarter of 2013. The increase was primarily driven by fixed cost leverage on higher sales.

[0000038725-14-000189:8k_2_02:33]
Overall

[0000038725-14-000189:8k_2_02:34]
The Company’s consolidated gross profit was $89.2 million for the third quarter of 2014, an increase of $2.2 million, or about 3 percent, from the third quarter of 2013 gross profit of $87.0 million. The gross profit as a percent of net sales was 32.1 percent in the third quarter of 2014 down about 270 basis points versus 34.8 percent during the third quarter 2013.  The previously discussed mix shift in the Water Systems segment contributed significantly to lower gross profit margins in the quarter.

[0000038725-14-000189:8k_2_02:35]
Selling, general, and administrative (SG&A) expenses were $55.6 million in the third quarter of 2014 compared to $48.4 million in the third quarter of prior year, an increase of $7.2 million or about 15 percent.  The increase in SG&A expenses from acquired businesses was $3.2 million.  Excluding the acquisitions, the Company’s overall SG&A expenses in the third quarter of 2014 increased by $4.0 million or 8 percent to prior year third quarter.  The remaining increases in SG&A were primarily driven by higher commissions, sales, marketing and selling related costs in support of higher sales and increases in Research Development and Engineering spending.

[0000038725-14-000189:8k_2_02:36]
The Company ended the third quarter of 2014 with a cash balance of $77.4 million, which was $57.1 million lower than at the end of 2013.  The cash balance decrease is primarily attributable to increased working capital needs and acquisitions.

[0000038725-14-000189:8k_2_02:37]
Commenting on the outlook for the fourth quarter of 2014, Mr. Sengstack said:

[0000038725-14-000189:8k_2_02:38]
“As we look forward to the fourth quarter, our Water Systems outlook assumes the continuation of many of the same factors we experienced in the third quarter.  Although we believe organic revenue growth will be solid, product sales mix will continue to negatively affect our adjusted operating income as we expect

[0000038725-14-000189:8k_2_02:39]
ground water equipment sales to be lower in the U.S., due principally to the decline in the sale of agricultural irrigation pumping equipment.  As a result, we are projecting that our fourth quarter 2014 global Water Systems sales will increase by 8 to 10 percent, but our adjusted operating income will decline 10 to 12 percent. It is important to note that as we move into 2015, we expect our Water Systems sales mix to return to more historical levels, restoring the operating margin profile the Company has consistently achieved.

[0000038725-14-000189:8k_2_02:40]
We estimate that our Fueling Systems sales and adjusted operating earnings will grow in the fourth quarter of 2014 by 4 to 6 percent as compared to a record 2013 fourth quarter.

[0000038725-14-000189:8k_2_02:41]
Finally, our consolidated adjusted earnings per share growth will be in the 3 to 5 percent range, due in part, to the continued benefit of tax planning with respect to our foreign operations.”

[0000038725-14-000189:8k_2_02:42]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The third quarter 2014 earnings call will be available via a live webcast.  The webcast will be available in a listen only mode by going to:

[0000038725-14-000189:8k_2_02:43]
http://www.media-server.com/m/p/3zfvbr2d

[0000038725-14-000189:8k_2_02:44]
If you intend to ask questions during the call, please dial in using (877) 643-7158 for domestic calls and (914) 495-8565 for international calls.

[0000038725-14-000189:8k_2_02:45]
A replay of the conference call will be available Wednesday, October 29, 2014 at 12:00 noon EDT through midnight EST on Wednesday, November 5, 2014, by dialing (855) 859-2056 for domestic calls and (404) 537-3406 for international calls. The replay passcode is: 21476932

[0000038725-14-000189:8k_2_02:46]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and automotive fuels. Recognized as a technical leader in its specialties, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-14-000189:8k_2_02:47]
The Company presents the non-GAAP financial measures of earnings after non-GAAP adjustments, fully diluted earnings per share after non-GAAP adjustments (or adjusted EPS), operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments (or operating income margin after non-GAAP adjustments) because the Company believes the information helps investors understand underlying trends in the Company's business more easily.  The differences between these measures and the most comparable GAAP measures are reconciled in the tables above.

[0000038725-14-000189:8k_2_02:48]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 27, 2014 |  | September 28, 2013 |  | September 27, 2014 |  | September 28, 2013 |
| Net sales | $ | 278,053 |  |  | $ | 249,844 |  |  | $ | 793,940 |  |  | $ | 735,811 |  |
| Cost of sales | 188,902 |  |  | 162,873 |  |  | 527,284 |  |  | 480,308 |  |
| Gross profit | 89,151 |  |  | 86,971 |  |  | 266,656 |  |  | 255,503 |  |
| Selling, general, and administrative expenses | 55,635 |  |  | 48,415 |  |  | 167,621 |  |  | 151,668 |  |
| Restructuring (income)/expense | 1,086 |  |  | 828 |  |  | 1,517 |  |  | 2,235 |  |
| Operating income | 32,430 |  |  | 37,728 |  |  | 97,518 |  |  | 101,600 |  |
| Interest expense | (2,744 | ) |  | (2,665 | ) |  | (8,038 | ) |  | (7,811 | ) |
| Other income/(expense) | 355 |  |  | 296 |  |  | 1,551 |  |  | 1,107 |  |
| Foreign exchange income/(expense) | (510 | ) |  | (466 | ) |  | (602 | ) |  | (1,178 | ) |
| Income before income taxes | 29,531 |  |  | 34,893 |  |  | 90,429 |  |  | 93,718 |  |
| Income taxes | 6,726 |  |  | 9,596 |  |  | 22,745 |  |  | 24,367 |  |
| Net income | $ | 22,805 |  |  | $ | 25,297 |  |  | $ | 67,684 |  |  | $ | 69,351 |  |
| Less: Net income attributable to noncontrolling interests | (132 | ) |  | (236 | ) |  | (980 | ) |  | (699 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 22,673 |  |  | $ | 25,061 |  |  | $ | 66,704 |  |  | $ | 68,652 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.46 |  |  | $ | 0.52 |  |  | $ | 1.37 |  |  | $ | 1.43 |  |
| Diluted | $ | 0.46 |  |  | $ | 0.51 |  |  | $ | 1.36 |  |  | $ | 1.41 |  |

[0000038725-14-000189:8k_2_02:49]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | September 27, 2014 |  | December 28, 2013 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 77,420 |  |  | $ | 134,553 |  |
| Receivables | 167,849 |  |  | 115,127 |  |
| Inventories | 243,225 |  |  | 191,561 |  |
| Other current assets | 38,216 |  |  | 31,113 |  |
| Total current assets | 526,710 |  |  | 472,354 |  |
| Property, plant, and equipment, net | 212,131 |  |  | 208,596 |  |
| Goodwill and other assets | 406,557 |  |  | 370,923 |  |
| Total assets | $ | 1,145,398 |  |  | $ | 1,051,873 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 75,921 |  |  | $ | 57,755 |  |
| Accrued expenses and other current liabilities | 85,827 |  |  | 65,356 |  |
| Current maturities of long-term debt and short-term borrowings | 82,656 |  |  | 15,363 |  |
| Total current liabilities | 244,404 |  |  | 138,474 |  |
| Long-term debt | 144,666 |  |  | 174,166 |  |
| Deferred income taxes | 57,253 |  |  | 54,618 |  |
| Employee benefit plans | 34,164 |  |  | 41,685 |  |
| Other long-term liabilities | 22,795 |  |  | 39,543 |  |
| Redeemable noncontrolling interest | 6,261 |  |  | 5,171 |  |
| Total equity | 635,855 |  |  | 598,216 |  |
| Total liabilities and equity | $ | 1,145,398 |  |  | $ | 1,051,873 |  |

[0000038725-14-000189:8k_2_02:50]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Nine Months Ended |
| (In thousands) | September 27, 2014 |  | September 28, 2013 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 67,684 |  |  | $ | 69,351 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 27,791 |  |  | 22,806 |  |
| Share-based compensation | 6,314 |  |  | 4,372 |  |
| Other | 926 |  |  | (1,101 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (50,070 | ) |  | (30,723 | ) |
| Inventory | (49,888 | ) |  | (15,028 | ) |
| Accounts payable and accrued expenses | 12,469 |  |  | 968 |  |
| Other | (11,745 | ) |  | 4,366 |  |
| Net cash flows from operating activities | 3,481 |  |  | 55,011 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (25,094 | ) |  | (50,783 | ) |
| Proceeds from sale of property, plant, and equipment | 1,592 |  |  | 64 |  |
| Acquisitions and investments | (42,619 | ) |  | (2,236 | ) |
| Other investing activities | (2,244 | ) |  | 307 |  |
| Net cash flows from investing activities | (68,365 | ) |  | (52,648 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 32,925 |  |  | 26,011 |  |
| Proceeds from issuance of common stock | 1,351 |  |  | 12,955 |  |
| Excess tax from share-based payment arrangements | 1,800 |  |  | 4,466 |  |
| Purchases of common stock | (8,642 | ) |  | (12,175 | ) |
| Dividends paid | (13,119 | ) |  | (11,590 | ) |
| Purchase of redeemable non-controlling shares | (2,875 | ) |  | — |  |
| Payment of contingent consideration liability | — |  |  | (5,555 | ) |
| Net cash flows from financing activities | 11,440 |  |  | 14,112 |  |
| Effect of exchange rate changes on cash | (3,689 | ) |  | (1,748 | ) |
| Net change in cash and equivalents | (57,133 | ) |  | 14,727 |  |
| Cash and equivalents at beginning of period | 134,553 |  |  | 103,338 |  |
| Cash and equivalents at end of period | $ | 77,420 |  |  | $ | 118,065 |  |
