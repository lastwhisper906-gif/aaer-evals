# FELE note change history — 0000038725-14-000166 → 0000038725-14-000200


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0000038725-14-000200:note_history:1]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company has until December 12, 2014 to file its response brief.  If a hearing is held on the appeal it will likely occur sometime late in the second quarter of 2015.
  (was, 2014-08-07, similarity 0.9567):
[0000038725-14-000166:note_history:1]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014.  On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company has until September 29, 2014 to file its response brief.  If a hearing is held on the appeal it will likely occur sometime late in the fourth quarter 2014 or early first quarter 2015.

- changed (2014-11-06):
[0000038725-14-000200:note_history:2]
At September 27, 2014, the Company had $8.7 million of commitments primarily for the purchase of raw materials to be used in production.
  (was, 2014-08-07, similarity 0.9562):
[0000038725-14-000166:note_history:2]
At June 28, 2014, the Company had $12.3 million of commitments primarily for the purchase of raw materials to be used in production.

- changed (2014-11-06):
[0000038725-14-000200:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 27, 2014, are as follows:
  (was, 2014-08-07, similarity 0.8747):
[0000038725-14-000166:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in "Accrued expenses" in the Company's condensed consolidated balance sheet for the six months ended June 28, 2014, are as follows:

- changed (2014-11-06):
[0000038725-14-000200:note_history:4]
| (In millions) |  |  |
| Balance as of December 28, 2013 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 6.3 |  |
| Reductions for payments made |  | (6.9 | ) |
| Balance as of September 27, 2014 |  | $ | 8.9 |  |
  (was, 2014-08-07, similarity 0.9726):
[0000038725-14-000166:note_history:4]
| (In millions) |  |  |
| Balance as of December 28, 2013 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 3.4 |  |
| Reductions for payments made |  | (4.4 | ) |
| Balance as of June 28, 2014 |  | $ | 8.5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0000038725-14-000200:note_history:5]
The accompanying condensed consolidated balance sheet as of December 28, 2013, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 27, 2014, and for the third quarters and nine months ended September 27, 2014 and September 28, 2013, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the third quarter and nine months ended September 27, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending January 3, 2015.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K/A for the year ended December 28, 2013.
  (was, 2014-08-07, similarity 0.9358):
[0000038725-14-000166:note_history:5]
The accompanying condensed consolidated balance sheet as of December 28, 2013, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 28, 2014, and for the second quarters ended June 28, 2014 and June 29, 2013, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the second quarter ended June 28, 2014, are not necessarily indicative of the results that may be expected for the fiscal year ending January 3, 2015.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K/A for the year ended December 28, 2013.

- changed (2014-11-06):
[0000038725-14-000200:note_history:6]
Certain prior year amounts in the investing activities section on the condensed consolidated statement of cash flows were reclassified into the "Other, net" line to conform with the current year presentation.  The reclassification within the investing activities section of the condensed consolidated statement of cash flows had no impact on the operating cash flows or any other financial statement.
  (was, 2014-08-07, similarity 0.9975):
[0000038725-14-000166:note_history:6]
Certain prior year amounts in the “investing activities” section on the condensed consolidated statement of cash flows were reclassified into the "Other, net" line to conform with the current year presentation.  The reclassification within the investing activities section of the condensed consolidated statement of cash flows had no impact on the operating cash flows or any other financial statement.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0000038725-14-000200:note_history:7]
| (In millions) |  | September 27, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.7 |  |  | 24.6 |  |
| Revolver |  | 45.7 |  |  | — |  |
| Capital leases |  | 0.8 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 7.2 |  |  | 14.2 |  |
|  |  | 227.4 |  |  | 189.6 |  |
| Less current maturities |  | (82.7 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 144.7 |  |  | $ | 174.2 |  |
  (was, 2014-08-07, similarity 0.9829):
[0000038725-14-000166:note_history:7]
| (In millions) |  | June 28, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.1 |  |  | 24.6 |  |
| Revolver |  | 48.2 |  |  | — |  |
| Capital leases |  | 1.0 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 21.9 |  |  | 14.2 |  |
|  |  | 245.2 |  |  | 189.6 |  |
| Less current maturities |  | (69.8 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 175.4 |  |  | $ | 174.2 |  |

- added (2014-11-06):
[0000038725-14-000200:note_history:8]
During the third quarter ended September 27, 2014, a portion of the Revolver borrowing was used to retire $16.5 million of third-party bank loans in Turkey and Brazil.

- changed (2014-11-06):
[0000038725-14-000200:note_history:9]
On June 6, 2014, the Company assumed debt relating to the acquisition of Bombas Leao (see Note 3) of BRL 12.6 million, $5.6 million at the then current exchange rate.  The debt instruments bear interest rates ranging from 2.5 percent to 19.4 percent, with due dates ranging from November 2014 to November 2017.  There are no financial covenants associated with these debt instruments.  The value of the debt assumed in the Bombas Leao acquisition increased by BRL 0.2 million ($0.1 million) during the third quarter ended September 27, 2014 resulting from additional information provided for the provisional valuation and working capital adjustments.
  (was, 2014-08-07, similarity 0.7344):
[0000038725-14-000166:note_history:9]
On June 6, 2014, the Company assumed debt relating to the acquisition of Bombas Leao (see Note 3) of BRL 12.4 million, $5.5 million at the then current exchange rate.  The debt instruments bear interest rates ranging from 2.50 percent to 19.42 percent, with due dates ranging from November 2014 - November 2017.  There are no financial covenants associated with these debt instruments.

- changed (2014-11-06):
[0000038725-14-000200:note_history:10]
The total estimated fair value of debt was $241.4 million and $203.7 million at September 27, 2014 and December 28, 2013, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its long-term debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as a Level 2 within the valuations hierarchy.
  (was, 2014-08-07, similarity 0.9906):
[0000038725-14-000166:note_history:10]
The total estimated fair value of debt was $259.9 million and $203.7 million at June 28, 2014 and December 28, 2013, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its long-term debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as a Level 2 within the valuations hierarchy.

- changed (2014-11-06):
[0000038725-14-000200:note_history:11]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 226.6 |  |  | $ | 82.4 |  |  | $ | 31.6 |  |  | $ | 31.3 |  |  | $ | 31.4 |  |  | $ | 31.1 |  |  | $ | 18.8 |  |
| Capital leases |  | 0.8 |  |  | 0.3 |  |  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 227.4 |  |  | $ | 82.7 |  |  | $ | 31.7 |  |  | $ | 31.5 |  |  | $ | 31.5 |  |  | $ | 31.2 |  |  | $ | 18.8 |  |
  (was, 2014-08-07, similarity 0.8978):
[0000038725-14-000166:note_history:11]
| (In millions) |  | Total |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | More than 5 years |
| Debt |  | $ | 244.2 |  |  | $ | 69.4 |  |  | $ | 31.2 |  |  | $ | 32.2 |  |  | $ | 31.1 |  |  | $ | 31.0 |  |  | $ | 49.3 |  |
| Capital leases |  | 1.0 |  |  | 0.4 |  |  | 0.2 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 245.2 |  |  | $ | 69.8 |  |  | $ | 31.4 |  |  | $ | 32.4 |  |  | $ | 31.2 |  |  | $ | 31.1 |  |  | $ | 49.3 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0000038725-14-000200:note_history:12]
| (In millions) |  | September 27, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.7 |  |  | 24.6 |  |
| Revolver |  | 45.7 |  |  | — |  |
| Capital leases |  | 0.8 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 7.2 |  |  | 14.2 |  |
|  |  | 227.4 |  |  | 189.6 |  |
| Less current maturities |  | (82.7 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 144.7 |  |  | $ | 174.2 |  |
  (was, 2014-08-07, similarity 0.9829):
[0000038725-14-000166:note_history:12]
| (In millions) |  | June 28, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.1 |  |  | 24.6 |  |
| Revolver |  | 48.2 |  |  | — |  |
| Capital leases |  | 1.0 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 21.9 |  |  | 14.2 |  |
|  |  | 245.2 |  |  | 189.6 |  |
| Less current maturities |  | (69.8 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 175.4 |  |  | $ | 174.2 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-06):
[0000038725-14-000200:note_history:13]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 226.6 |  |  | $ | 82.4 |  |  | $ | 31.6 |  |  | $ | 31.3 |  |  | $ | 31.4 |  |  | $ | 31.1 |  |  | $ | 18.8 |  |
| Capital leases |  | 0.8 |  |  | 0.3 |  |  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 227.4 |  |  | $ | 82.7 |  |  | $ | 31.7 |  |  | $ | 31.5 |  |  | $ | 31.5 |  |  | $ | 31.2 |  |  | $ | 18.8 |  |
  (was, 2014-08-07, similarity 0.8978):
[0000038725-14-000166:note_history:13]
| (In millions) |  | Total |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | More than 5 years |
| Debt |  | $ | 244.2 |  |  | $ | 69.4 |  |  | $ | 31.2 |  |  | $ | 32.2 |  |  | $ | 31.1 |  |  | $ | 31.0 |  |  | $ | 49.3 |  |
| Capital leases |  | 1.0 |  |  | 0.4 |  |  | 0.2 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 245.2 |  |  | $ | 69.8 |  |  | $ | 31.4 |  |  | $ | 32.4 |  |  | $ | 31.2 |  |  | $ | 31.1 |  |  | $ | 49.3 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2014-11-06):
[0000038725-14-000166:note_history:14]
SUBSEQUENT EVENTS

- removed (2014-11-06):
[0000038725-14-000166:note_history:15]
On July 1, 2014, the Company announced a plan to close its Wittlich, Germany manufacturing facility.  As part of this action, the Company will transfer the existing Wittlich manufacturing activity to its Brno, Czech Republic facility.  The Company will maintain its European Water Systems Headquarters and distribution center in Wittlich, only the manufacturing operations will be relocating
