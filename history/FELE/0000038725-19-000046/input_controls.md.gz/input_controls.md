# FELE 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000038725-19-000046:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0000038725-19-000046:item_9a:2]
As of the end of the period covered by this report (the “Evaluation Date”), the Company carried out an evaluation, under the supervision and with the participation of the Company’s management, including the Company’s Chief Executive Officer and the Company’s Chief Financial Officer, of the effectiveness of the design and operation of the Company’s disclosure controls and procedures pursuant to Exchange Act Rules 13a-15.  Based upon that evaluation, the Company’s Chief Executive Officer and the Company’s Chief Financial Officer concluded that, as of the Evaluation Date, the Company’s disclosure controls and procedures were effective.

[0000038725-19-000046:item_9a:3]
In the third quarter of 2016, the Company began the process of a multi-year implementation of a global enterprise resource planning (“ERP”) system. The new ERP system was designed to better support the Company's business needs in response to the changing operating environment and for many business units within the Company is an update to a legacy system product.  The implementation of a worldwide ERP system affects the processes that constitute the Company's internal control over financial reporting and requires testing for effectiveness as the implementation progresses. The Company expects that the new ERP system will enhance the overall system of internal controls over financial reporting through further automation and integration of business processes, although it is not being implemented in response to any identified deficiency in the Company’s internal controls over financial reporting. The Conversion will happen in two stages. The first stage involved converting the primary legacy ERP system. As of the first quarter of 2018, all business units previously on the primary legacy system have converted to the new ERP system. The second stage will convert those companies that remained on their local ERP system after the date of acquisition. The second stage is ongoing as of December 31, 2018. Additionally, early in the fourth quarter of 2018, the Company migrated the Distribution segment to a common ERP system. The implementation did not result in any material changes to the Company’s internal control over financial reporting. The implementation was not completed in response to any identified deficiencies in the Company’s internal control over financial reporting.

[0000038725-19-000046:item_9a:4]
Other than the ERP implementations, there have been no changes in the Company’s internal control over financial reporting identified in connection with the evaluation required by Rules 13a-15 under the Exchange Act during the last fiscal quarter that have materially affected, or are reasonably likely to materially affect the Company’s internal control over financial reporting.

[0000038725-19-000046:item_9a:5]
MANAGEMENT’S REPORT ON INTERNAL CONTROL OVER FINANCIAL REPORTING

[0000038725-19-000046:item_9a:6]
Management is responsible for establishing and maintaining an adequate system of internal control over financial reporting of the Company.  This system is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with accounting principles generally accepted in the United States of America.

[0000038725-19-000046:item_9a:7]
The Company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the financial statements.

[0000038725-19-000046:item_9a:8]
Because of its inherent limitations, internal control over financial reporting can provide only reasonable assurance with respect to financial statement preparation and may not prevent or detect misstatements.  Further, because of changes in conditions, effectiveness of internal controls over financial reporting may vary over time.

[0000038725-19-000046:item_9a:9]
Management conducted an evaluation of the effectiveness of the system of internal control over financial reporting based on the framework in the Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.  Management excluded Valley Farms, Industrias Rotor Pump, and the asset acquisition of SPD of Midtronics, Inc (Note 3 - Acquisitions) from its assessment of internal controls over financial reporting as these acquisitions occurred in 2018. This exclusion is in accordance with the general guidance from the Staff of the Securities and Exchange Commission that an assessment of a recently acquired business may be omitted from the scope of management’s assessment of internal control over financial reporting for one year following the acquisition.  The net sales and total assets of current year

[0000038725-19-000046:item_9a:10]
68

[0000038725-19-000046:item_9a:11]
acquisitions represented was approximately 3.0 percent and 5.2 percent, respectively, of the consolidated financial statement amounts as of and for the year ended December 31, 2018.  Based on its evaluation, management concluded that the Company’s system of internal control over financial reporting was effective as of December 31, 2018.

[0000038725-19-000046:item_9a:12]
Our independent registered public accounting firm has issued an audit report on the effectiveness of the Company’s internal control over financial reporting as of December 31, 2018.  This report appears on page 70.

[0000038725-19-000046:item_9a:13]
69

[0000038725-19-000046:item_9a:14]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000038725-19-000046:item_9a:15]
To the Shareholders and the Board of Directors of Franklin Electric Co., Inc.

[0000038725-19-000046:item_9a:16]
Fort Wayne, Indiana

[0000038725-19-000046:item_9a:17]
Opinion on Internal Control over Financial Reporting

[0000038725-19-000046:item_9a:18]
We have audited the internal control over financial reporting of Franklin Electric Co., Inc. and subsidiaries (the “Company”) as of December 31, 2018, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2018, based on criteria established in Internal Control - Integrated Framework (2013) issued by COSO.

[0000038725-19-000046:item_9a:19]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements and financial statement schedule as of and for the year ended December 31, 2018, of the Company and our report dated February 28, 2019, expressed an unqualified opinion on those financial statements.

[0000038725-19-000046:item_9a:20]
As described in Management’s Report on Internal Control over Financial Reporting, management excluded Valley Farms Supply, Inc., ("Valley Farms"), and Industrias Rotor Pump S.A. (“Industrias Rotor Pump”), and the asset acquisition of the Stationary Power Division (“SPD”) of Midtronics, from its assessment of internal control over financial reporting as these acquisitions occurred in 2018. The combined net sales and total assets of these acquisitions represented approximately 3.0 percent and 5.2 percent, respectively, of the consolidated financial statement amounts as of and for the year ended December 31, 2018. Accordingly, our audit did not include the internal control over financial reporting at these acquired companies.

[0000038725-19-000046:item_9a:21]
Basis for Opinion

[0000038725-19-000046:item_9a:22]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000038725-19-000046:item_9a:23]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000038725-19-000046:item_9a:24]
Definition and Limitations of Internal Control over Financial Reporting

[0000038725-19-000046:item_9a:25]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000038725-19-000046:item_9a:26]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000038725-19-000046:item_9a:27]
/s/  DELOITTE & TOUCHE LLP

[0000038725-19-000046:item_9a:28]
Chicago, Illinois

[0000038725-19-000046:item_9a:29]
February 28, 2019
