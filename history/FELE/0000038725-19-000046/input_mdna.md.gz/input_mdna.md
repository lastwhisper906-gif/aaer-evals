# FELE MD&A — 0000038725-19-000046


## mdna

[0000038725-19-000046:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-19-000046:mdna:2]
2018 vs. 2017

[0000038725-19-000046:mdna:3]
OVERVIEW

[0000038725-19-000046:mdna:4]
Sales in 2018 increased by 15 percent from the prior year.  The sales increase was led by acquisition related sales, as well as volume and price increases from all three segments. The impact of foreign currency translation decreased sales by about 1 percent. The Company's consolidated gross profit was $432.4 million for 2018, an increase of $55.4 million or about 15 percent from 2017. The gross profit as a percent of net sales decreased 20 basis points to 33.3 percent in 2018 from 33.5 percent in 2017. The decline in gross profit margin percentage is primarily due to product and geographic sales mix shifts. For 2018, diluted earnings per share were $2.23, up from 2017 diluted earnings per share of $1.65. In 2017, the Company recorded a net tax expense of $10.2 million, or $0.21 in diluted earnings per share related to the enactment of the U.S. Tax Cuts and Jobs Act of 2017. For 2018, diluted earnings per share were $2.23, up from 2017 diluted earnings per share of $1.86, before the impact of the U.S. Tax Cuts and Jobs Act of 2017 or an increase of about 20 percent.

[0000038725-19-000046:mdna:5]
RESULTS OF OPERATIONS

[0000038725-19-000046:mdna:6]
Net Sales

[0000038725-19-000046:mdna:7]
Net sales in 2018 were $1,298.1 million, an increase of $173.2 million or about 15 percent compared to 2017 sales of $1,124.9 million.  The incremental impact of sales from acquired businesses was $99.2 million or about 9 percent.  Sales revenue decreased by $13.1 million or about 1 percent in 2018 due to foreign currency translation. The sales change in 2018, excluding acquisitions and foreign currency translation, was an increase of $87.1 million or about 8 percent.

[0000038725-19-000046:mdna:8]
|  | Net Sales |
| (In millions) | 2018 |  | 2017 |  | 2018 v 2017 |
| Water Systems | $ | 796.5 |  |  | $ | 743.3 |  |  | $ | 53.2 |  |
| Fueling Systems | 288.2 |  |  | 245.7 |  |  | 42.5 |  |
| Distribution | 269.6 |  |  | 176.7 |  |  | 92.9 |  |
| Eliminations/Other | (56.2 | ) |  | (40.8 | ) |  | (15.4 | ) |
| Consolidated | $ | 1,298.1 |  |  | $ | 1,124.9 |  |  | $ | 173.2 |  |

[0000038725-19-000046:mdna:9]
Net Sales-Water Systems

[0000038725-19-000046:mdna:10]
Water Systems sales were $796.5 million in 2018, an increase of $53.2 million or about 7 percent versus 2017. The incremental impact of sales from acquired businesses was $8.3 million or about 1 percent.  Foreign currency translation changes decreased sales $15.4 million, or about 2 percent, compared to sales in 2017. The Water Systems organic sales change in 2018 was an increase of $60.3 million or about 8 percent.

[0000038725-19-000046:mdna:11]
Water Systems sales in the U.S. and Canada increased by about 17 percent compared to 2017. Sales revenue increased by $0.5 million or less than 1 percent in 2018 due to foreign currency translation. In 2018, sales of Pioneer branded dewatering equipment increased by about 90 percent when compared to the prior year due to strength in North American oil and gas markets and continued diversification of product sales channels and geographies. Sales of groundwater pumping equipment increased by about 8 percent on stronger residential and agricultural system sales primarily to the Headwater Companies, versus 2017. Sales of other surface pumping equipment increased by about 5 percent in part due to wet weather conditions in the upper Midwest and Canada.

[0000038725-19-000046:mdna:12]
Water Systems sales in markets outside the U.S. and Canada decreased by about 2 percent compared to 2017. Sales revenue decreased by $15.9 million or about 4 percent in 2018 due to foreign currency translation. The incremental impact of sales from acquired businesses was $8.3 million or about 2 percent. International Water Systems local currency sales improved in Europe, the Middle East and Africa, but declined in Asia Pacific and Brazil in 2018 compared to last year. Combined, sales in Latin America and Asia Pacific declined by about 6 percent. In Latin America, the sales decline was primarily in Brazil. The sales decline in Brazil was due to an overall slowdown of the economic environment. In Asia Pacific, the Company’s sales in Korea declined due to an overall slowdown of the economic environment, and in Thailand, sales were adversely impacted by declines in government funding for water related projects and by weather.

[0000038725-19-000046:mdna:13]
Net Sales-Fueling Systems

[0000038725-19-000046:mdna:14]
Fueling Systems sales were $288.2 million in 2018, an increase of $42.5 million or about 17 percent from 2017. The incremental impact of sales from acquired businesses was $3.5 million or about 1 percent. Foreign currency translation changes increased sales $2.3 million or about 1 percent compared to sales in 2017. The Fueling Systems organic sales change in 2018 was an increase of $36.7 million or about 15 percent.

[0000038725-19-000046:mdna:15]
Fueling Systems sales in the U.S. and Canada grew by about 10 percent during 2018 with most of the sales growth coming from fuel management systems and piping. Internationally, Fueling Systems revenues grew by about 27 percent led by stronger sales in China, partially offset by lower sales in India. China sales were about $52 million in 2018 compared to 2017 Fueling Systems China sales of about $25 million due primarily to China’s underground piping upgrade.

[0000038725-19-000046:mdna:16]
Net Sales-Distribution

[0000038725-19-000046:mdna:17]
Distribution sales were $269.6 million in 2018, versus 2017 sales of $176.7 million. The incremental impact of sales from acquired businesses was $87.4 million. Distribution segment organic sales increased about 3 percent compared to 2017.

[0000038725-19-000046:mdna:18]
Cost of Sales

[0000038725-19-000046:mdna:19]
Cost of sales as a percent of net sales for 2018 and 2017 was 66.7 percent and 66.5 percent, respectively. Correspondingly, the gross profit margin was 33.3 percent and 33.5 percent for both years. The Company’s consolidated gross profit was $432.4 million for 2018, up $55.4 million from the gross profit of $377.0 million in 2017. The gross profit increase was primarily due to higher sales. The decline in gross profit margin percentage is partially attributable to product and geographic sales mix shifts.

[0000038725-19-000046:mdna:20]
Selling, General and Administrative (“SG&A”)

[0000038725-19-000046:mdna:21]
Selling, general, and administrative expenses were $298.7 million in 2018 and increased by $33.3 million or about 13 percent in 2018 compared to $265.4 million last year. The increase in SG&A expenses from acquired businesses were $27.2 million. Excluding the acquired entities, the Company’s SG&A expenses in 2018 were $271.5 and increased by $6.1 million or about 2 percent in 2018 compared to last year.

[0000038725-19-000046:mdna:22]
Restructuring Expenses

[0000038725-19-000046:mdna:23]
Restructuring expenses for 2018 were $1.7 million. Restructuring expenses were $0.6 million in the Water Systems segment, $0.3 million in the Fueling Systems segment and $0.8 million in the Distribution segment. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and distribution branch closings and consolidations. Restructuring expenses for 2017 were $4.3 million. Restructuring expenses were $2.7 million in the Water segment primarily related to the continuing Brazilian manufacturing realignments. Restructuring expenses were primarily severance expenses and other miscellaneous manufacturing realignment activities. The Fueling Systems segment restructuring expenses in 2017 were $1.6 million. The Company wrote off its ownership share in a Fueling Systems joint venture in India.

[0000038725-19-000046:mdna:24]
Operating Income

[0000038725-19-000046:mdna:25]
Operating income was $132.0 million in 2018, up $24.8 million or 23 percent from $107.2 million in 2017.

[0000038725-19-000046:mdna:26]
|  |  | Operating income (loss) |
| (In millions) |  | 2018 |  | 2017 |  | 2018 v 2017 |
| Water Systems |  | $ | 112.9 |  |  | $ | 102.0 |  |  | $ | 10.9 |  |
| Fueling Systems |  | 70.4 |  |  | 60.0 |  |  | 10.4 |  |
| Distribution |  | 3.4 |  |  | 3.7 |  |  | (0.3 | ) |
| Eliminations/Other |  | (54.7 | ) |  | (58.5 | ) |  | 3.8 |  |
| Consolidated |  | $ | 132.0 |  |  | $ | 107.2 |  |  | $ | 24.8 |  |

[0000038725-19-000046:mdna:27]
Operating Income-Water Systems

[0000038725-19-000046:mdna:28]
Water Systems operating income was $112.9 million in 2018 compared to $102.0 million in 2017, an increase of 11 percent. Operating income margin for 2018 was 14.2 percent compared to 2017 operating income margin of 13.7%. Operating income margin increased in Water Systems primarily from leverage on fixed cost from higher sales volume and price.

[0000038725-19-000046:mdna:29]
Operating Income-Fueling Systems

[0000038725-19-000046:mdna:30]
Fueling Systems operating income was $70.4 million in 2018 compared to $60.0 million in 2017. The operating income margin was 24.4 percent of net sales in both years.  The increase in operating income was primarily due to higher sales.

[0000038725-19-000046:mdna:31]
Operating Income-Distribution

[0000038725-19-000046:mdna:32]
Distribution operating income was $3.4 million in 2018 and operating income margin was 1.3 percent. Distribution operating income was $3.7 million in 2017 and operating income margin was 2.1 percent. The Distribution segment’s operations are seasonal and product sales are significantly slower during the fourth and first quarters, i.e., the winter months in North America. The 2017 results did not include the first quarter seasonality impact as the acquisitions of the Distribution entities occurred after the first quarter of 2017.

[0000038725-19-000046:mdna:33]
Operating Income-Eliminations/Other

[0000038725-19-000046:mdna:34]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in 2018 was a $0.6 million gain or $6.1 million improvement to the prior year as the Distribution segment decreased inventory of Water Systems products on hand. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses were higher by $2.3 million or about 4 percent to last year.

[0000038725-19-000046:mdna:35]
Interest Expense

[0000038725-19-000046:mdna:36]
Interest expense for 2018 and 2017 was $9.8 million and $10.3 million, respectively.

[0000038725-19-000046:mdna:37]
Other Income or Expense

[0000038725-19-000046:mdna:38]
Other income or expense was a loss of $1.0 million in 2018. Included in other income in 2018 was interest income of $0.6 million, primarily derived from the investment of cash balances in short-term securities. Also included in other expense in 2018 was a loss of $0.3 million related to a tax indemnification write-off. Other expense also included $0.4 million related to non-operational pension cost.

[0000038725-19-000046:mdna:39]
Other income or expense was income of $6.7 million in 2017. Included in other income in 2017 was a gain of $5.2 million related to the acquisition of controlling interests in three Distribution entities previously held as equity investments. Also, included in other income in 2017 was minority income of $0.6 million and interest income of $0.9 million, primarily derived from the investment of cash balances in short-term securities. Other expense also included $0.2 million related to non-operational pension cost.

[0000038725-19-000046:mdna:40]
Foreign Exchange

[0000038725-19-000046:mdna:41]
Foreign currency-based transactions for 2018 was a loss of $0.7 million due to movements in several currencies relative to the U.S. dollar, with the Turkish Lira, South African Rand, Argentinian Peso and Mexican Peso being the most significant. Foreign currency-based transactions for 2017 was a gain of $1.0 million, due to movements in several currencies relative to the U.S. dollar, with the Turkish Lira being the most significant.

[0000038725-19-000046:mdna:42]
Income Taxes

[0000038725-19-000046:mdna:43]
The provision for income taxes in 2018 and 2017 was $14.9 million and $26.0 million, respectively. The effective tax rate for 2017 was about 25 percent both before and after the impact of discrete events. The effective tax rate for 2018 was about 12 percent and before the impact of discrete events was about 19 percent. The decrease in the effective tax rate was primarily affected by the U.S. Tax Cuts and Jobs Act of 2017 (Tax Act), which reduced the U.S. federal corporate income tax rate from 35 percent to 21 percent effective January 1, 2018. The tax rate was lower than the statutory rate of 21 percent primarily due to foreign earnings taxed at lower statutory rates, as well as recognition of the deduction for Foreign Derived Intangible Income, and certain discrete events. Discrete events in 2018 include a net benefit related to the release of valuation allowances on deferred taxes in multiple jurisdictions.  Discrete events in 2017 included the net impact of the Tax Act offset by the benefit of a realized foreign currency translation loss and of a non-taxable gain recorded on the previously held equity investments. In 2019, the Company estimates its effective tax rate will be about 18 to 20 percent.

[0000038725-19-000046:mdna:44]
Net Income

[0000038725-19-000046:mdna:45]
Net income for 2018 was $105.5 million compared to 2017 net income of $78.6 million.  Net income attributable to Franklin Electric Co., Inc. for 2018 was $105.9 million, or $2.23 per diluted share, compared to 2017 net income attributable to Franklin Electric Co., Inc. of $78.2 million or $1.65 per diluted share.

[0000038725-19-000046:mdna:46]
2017 vs. 2016

[0000038725-19-000046:mdna:47]
OVERVIEW

[0000038725-19-000046:mdna:48]
Sales in 2017 were up from the prior year. Net sales in 2017 were $1,124.9 million, an increase of $175.0 million or about 18 percent compared to 2016 sales of $949.9 million. The sales increase was primarily related to acquisitions. In 2017, the Company acquired a controlling interest in several distribution companies. The distribution companies are reported collectively as a new segment. The Company's consolidated gross profit was $377.0 million for 2017, an increase of $45.6 million or about 14 percent from 2016. The gross profit as a percent of net sales decreased 140 basis points to 33.5 percent in 2017 from 34.9 percent in 2016. The decline in gross profit margin percentage is primarily due to product and geographic sales mix shifts and higher raw material costs. For 2017, diluted earnings per share were $1.65, flat to 2016 diluted earnings per share of $1.65. The Company recorded a net tax expense of $10.2 million, or $0.21 in diluted earnings per share related to the enactment of the U.S. Tax Cuts and Jobs Act of 2017. Before the impact of the U.S. Tax Cuts and Jobs Act of 2017, diluted earnings per share for 2017 were $1.86 compared to the 2016 diluted earnings per share of $1.65 or an increase of about 13 percent.

[0000038725-19-000046:mdna:49]
RESULTS OF OPERATIONS

[0000038725-19-000046:mdna:50]
Net Sales

[0000038725-19-000046:mdna:51]
Net sales in 2017 were $1,124.9 million, an increase of $175.0 million or about 18 percent compared to sales in 2016 of $949.9 million.  The sales increase was primarily from acquisition related sales.  Sales revenue increased by $2.7 million or less than 1 percent in 2017 due to foreign currency translation. The sales change in 2017, excluding acquisitions and foreign currency translation, was a decrease of $4.4 million or less than 1 percent.

[0000038725-19-000046:mdna:52]
|  |  | Net Sales |
| (In millions) |  | 2017 |  | 2016 |  | 2017 v 2016 |
| Water Systems |  | $ | 743.3 |  |  | $ | 723.2 |  |  | $ | 20.1 |  |
| Fueling Systems |  | 245.7 |  |  | 226.7 |  |  | 19.0 |  |
| Distribution |  | 176.7 |  |  | — |  |  | 176.7 |  |
| Eliminations/Other |  | (40.8 | ) |  | — |  |  | (40.8 | ) |
| Consolidated |  | $ | 1,124.9 |  |  | $ | 949.9 |  |  | $ | 175.0 |  |

[0000038725-19-000046:mdna:53]
Net Sales-Water Systems

[0000038725-19-000046:mdna:54]
Water Systems sales were $743.3 million in 2017 and increased by $20.1 million or about 3 percent versus 2016. Foreign currency translation rate changes increased sales $2.0 million compared to sales in 2016. The Water Systems sales change in 2017, excluding foreign currency translation, was an increase of $18.1 million or about 3 percent.

[0000038725-19-000046:mdna:55]
Water Systems sales in the U.S. and Canada were up about 3 percent compared to 2016. The impact of foreign currency translation was not significant. Sales of Pioneer branded dewatering equipment increased by about 50 percent in 2017 when compared to the prior year resulting from the continued diversification of customers and strengthening in U.S. oil and gas end markets. Sales of other surface pumping equipment increased by 2 percent primarily in wastewater related products. Sales of groundwater pumping equipment were down by about 2 percent overall with flat residential water systems offset with declines in agricultural systems.

[0000038725-19-000046:mdna:56]
Water Systems sales in markets outside the U.S. and Canada overall increased by about 4 percent. The impact of foreign currency translation was not significant. International Water Systems sales were led by improved sales in Europe, including higher sales of Pioneer branded equipment, and the Middle East and Africa, but were offset by lower sales, in local currency, in the Latin American markets compared to last year.

[0000038725-19-000046:mdna:57]
Net Sales-Fueling Systems

[0000038725-19-000046:mdna:58]
Fueling Systems sales were $245.7 million in 2017 and increased $19.0 million or about 8 percent from 2016. Foreign currency translation rate changes increased sales $0.7 million or less than 1 percent compared to sales in 2016. The Fueling Systems sales change in 2017, excluding foreign currency translation, was an increase of $18.3 million or about 8 percent.

[0000038725-19-000046:mdna:59]
Fueling Systems sales in the U.S. and Canada grew by about 4 percent during 2017 with sales growth coming from all product lines. Outside the U.S. and Canada, Fueling Systems revenues were up by about 14 percent overall with increased sales in China and Europe partially offset by lower sales in India.

[0000038725-19-000046:mdna:60]
Net Sales-Distribution

[0000038725-19-000046:mdna:61]
Distribution sales were $176.7 million in 2017 and were all acquisition related. Management estimates Distribution sales declined by about 6 percent from 2016 primarily driven by supply chain disruptions and weak end market conditions in the Southeast region of the United States.

[0000038725-19-000046:mdna:62]
Cost of Sales

[0000038725-19-000046:mdna:63]
Cost of sales as a percent of net sales for 2017 and 2016 was 66.5 percent and 65.1 percent, respectively. Correspondingly, the gross profit margin was 33.5 percent and 34.9 percent for both years. The Company’s consolidated gross profit was $377.0 million for 2017, up $45.6 million from the gross profit of $331.4 million in 2016. The gross profit increase was primarily due to higher sales. The decline in gross profit margin percentage is partially attributable to the inclusion of the Distribution segment which impacted the margin by about 20 basis points and the balance is due to product and geographic sales mix shifts and higher raw material costs.

[0000038725-19-000046:mdna:64]
Selling, General and Administrative (“SG&A”)

[0000038725-19-000046:mdna:65]
Selling, general, and administrative expenses were $265.7 million in 2017 and increased by $44.5 million or 20 percent in 2017 compared to $221.2 million last year. The increase in SG&A expenses from acquired businesses were $45.1 million. Excluding the acquired entities, the Company’s SG&A expenses in 2017 were $220.6 and decreased by $0.6 million or flat to last year.

[0000038725-19-000046:mdna:66]
Restructuring Expenses

[0000038725-19-000046:mdna:67]
Restructuring expenses for 2017 were $4.3 million. Restructuring expenses were $2.7 million in the Water segment primarily related to the continuing Brazilian manufacturing realignments. Restructuring expenses were primarily severance expenses and other miscellaneous manufacturing realignment activities. The Fueling segment restructuring expenses in 2017 were $1.6 million. The Company wrote off its ownership share in a Fueling Systems joint venture in India. Restructuring charges for 2016 resulted in a net gain of $0.6 million. Restructuring expenses for 2016 included a gain of $2.0 million from the sale of land and building in Brazil and $1.4 million in expenses related to severance, equipment transfers, freight and relocation cost related to the transfer of production activities and other restructuring costs from continued manufacturing realignments.

[0000038725-19-000046:mdna:68]
Operating Income

[0000038725-19-000046:mdna:69]
Operating income was $107.2 million in 2017, down $4.9 million or about 4 percent from $112.1 million in 2016.

[0000038725-19-000046:mdna:70]
|  |  | Operating income (loss) |
| (In millions) |  | 2017 |  | 2016 |  | 2017 v 2016 |
| Water Systems |  | $ | 102.0 |  |  | $ | 108.2 |  |  | $ | (6.2 | ) |
| Fueling Systems |  | 60.0 |  |  | 56.3 |  |  | 3.7 |  |
| Distribution |  | 3.7 |  |  | — |  |  | 3.7 |  |
| Eliminations/Other |  | (58.5 | ) |  | (52.4 | ) |  | (6.1 | ) |
| Consolidated |  | $ | 107.2 |  |  | $ | 112.1 |  |  | $ | (4.9 | ) |

[0000038725-19-000046:mdna:71]
Operating Income-Water Systems

[0000038725-19-000046:mdna:72]
Water Systems operating income was $102.0 million in 2017, down $6.2 million or about 6 percent versus 2016 of $108.2 million and operating income margin was 13.6 percent in 2017 compared to the 15.0 percent in 2016. As mentioned above Water Systems operating income was negatively impacted by $2.7 million in restructuring expenses in 2017 and favorably impacted by $1.2 million in the prior year. Water Systems operating income before restructuring was $104.7 million in 2017 and $107.0 million in 2016 and operating income margin before restructuring was 14.0 percent compared to the 14.8 percent in 2016. The decline in operating income margin is primarily related to product and geographic sales mix shifts and higher raw material costs.

[0000038725-19-000046:mdna:73]
Operating Income-Fueling Systems

[0000038725-19-000046:mdna:74]
Fueling Systems operating income was $60.0 million in 2017, up $3.7 million or about 7 percent compared to $56.3 million in 2016. The 2017 operating income margin was 24.4 percent compared to the 24.8 percent of net sales in 2016. As mentioned above Fueling Systems operating income was negatively impacted by $1.6 million in restructuring expenses in 2017 and impacted by $0.6 million in the prior year. Fueling Systems operating income before restructuring was $61.6 million in 2017 and $56.9 million in 2016 and operating income margin before restructuring was 25.1 percent in both 2017 and 2016. The increase in operating income was primarily due to higher sales.

[0000038725-19-000046:mdna:75]
Operating Income-Distribution

[0000038725-19-000046:mdna:76]
Distribution operating income was $3.7 million in 2017 and the operating income margin was 2.1 percent.

[0000038725-19-000046:mdna:77]
Operating Income-Eliminations/Other

[0000038725-19-000046:mdna:78]
Operating Income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in 2017 was $5.5 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses were higher by $0.6 million or about 1 percent compared to 2016.

[0000038725-19-000046:mdna:79]
Interest Expense

[0000038725-19-000046:mdna:80]
Interest expense for 2017 and 2016 was $10.3 million and $8.7 million, respectively. The increase in interest expense in 2017 is due to interest charges on prior years VAT taxes as a result of an audit in an international jurisdiction and due to higher average borrowings resulting from the Headwater acquisitions.

[0000038725-19-000046:mdna:81]
Other Income or Expense

[0000038725-19-000046:mdna:82]
Other income or expense was income of $6.7 million in 2017. Included in other income in 2017 was a gain of $5.2 million related to the acquisition of controlling interests in three Distribution entities previously held as equity investments. Also, included in other income in 2017 was minority income of $0.6 million and interest income of $0.9 million, primarily derived from the investment of cash balances in short-term securities. Other expense had $0.2 million related to non-operational pension cost.

[0000038725-19-000046:mdna:83]
Other income or expense for 2016 was a loss of $0.3 million. Included in other income in 2016 was minority income $1.7 million and interest income of $1.0 million, primarily derived from the investment of cash balances in short-term securities. In 2016, other expenses also included the reversal of an indemnification receivable related to a contingent tax liability for $1.9 million recorded at the time of a foreign acquisition.  The contingent tax liability was for the same amount and was also reversed in 2016 and the benefit was recorded in the income tax provision. Also, included in other expense in 2016 was $1.3 million related to non-operational pension cost.

[0000038725-19-000046:mdna:84]
Foreign Exchange

[0000038725-19-000046:mdna:85]
Foreign currency-based transactions produced a gain for 2017 and 2016 of $1.0 million and $1.1 million, respectively.

[0000038725-19-000046:mdna:86]
Income Taxes

[0000038725-19-000046:mdna:87]
The provision for income taxes in 2017 and 2016 was $26.0 million and $24.8 million, respectively. The effective tax rate for 2016 was about 24 percent and, before the impact of discrete events, was about 26 percent. The effective tax rate for 2017 was about 25 percent, both before and after the impact of discrete events.  The tax rate was lower than the statutory rate of 35 percent primarily due to foreign earnings taxed at lower statutory rates and the recognition of US incentives.  The Company recorded a provisional net tax expense of $10.2 million relating to the enactment of the U.S. Tax Cuts and Jobs Act of 2017. This expense was primarily derived from the recognition of a U.S. tax liability for the deemed repatriation of foreign earnings partially offset by the revaluation of other deferred tax liabilities.  Other discrete benefits of $10.3 million offset the expense including a foreign currency translation loss on the repayment of an intercompany loan that was a long-term-investment in nature, a tax restructuring in a foreign tax jurisdiction that released a valuation allowance on a deferred tax asset, a tax benefit on the non-taxable gain recorded on the previously held equity investments, excess tax benefits from share-based compensation and the statute expiration on foreign uncertain tax positions.

[0000038725-19-000046:mdna:88]
Net Income

[0000038725-19-000046:mdna:89]
Net income for 2017 was $78.6 million compared to 2016 net income of $79.3 million.  Net income attributable to Franklin Electric Co., Inc. for 2017 was $78.2 million, or $1.65 per diluted share, compared to 2016 net income attributable to Franklin Electric Co., Inc. of $78.7 million or $1.65 per diluted share.

[0000038725-19-000046:mdna:90]
CAPITAL RESOURCES AND LIQUIDITY

[0000038725-19-000046:mdna:91]
Sources of Liquidity

[0000038725-19-000046:mdna:92]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at December 31, 2018 is adequate to meet projected needs. The Company expects that ongoing requirements for operations, capital expenditures,

[0000038725-19-000046:mdna:93]
pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-19-000046:mdna:94]
As of December 31, 2018, the Company had a $300.0 million revolving credit facility. The facility is scheduled to mature on October 28, 2021. As of December 31, 2018, the Company had $218.2 million borrowing capacity under the Credit Agreement as $5.5 million in letters of commercial and standby letters of credit were outstanding and undrawn and $76.3 million revolver borrowing was drawn and outstanding as of the end of the year.

[0000038725-19-000046:mdna:95]
The Company also has other long-term debt borrowings outstanding as of December 31, 2018. See Footnote 11 for additional specifics regarding these obligations and future maturities.

[0000038725-19-000046:mdna:96]
At December 31, 2018, the Company had $43.9 million of cash and cash equivalents held in foreign jurisdictions, which the company intends to use to fund foreign operations. There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-19-000046:mdna:97]
Cash Flows

[0000038725-19-000046:mdna:98]
The following table summarizes significant sources and uses of cash and cash equivalents:

[0000038725-19-000046:mdna:99]
| (in thousands) | 2018 |  | 2017 |  | 2016 |
| Net cash provided by operating activities | $ | 128.4 |  |  | $ | 66.8 |  |  | $ | 115.4 |  |
| Net cash used in investing activities | (66.3 | ) |  | (84.7 | ) |  | (33.8 | ) |
| Net cash used in financing activities | (66.8 | ) |  | (22.6 | ) |  | (51.7 | ) |
| Impact of exchange rates on cash and cash equivalents | (3.4 | ) |  | 3.4 |  |  | (7.1 | ) |
| Change in cash and cash equivalents | $ | (8.1 | ) |  | $ | (37.1 | ) |  | $ | 22.8 |  |

[0000038725-19-000046:mdna:100]
Cash Flows Provided by Operating Activities

[0000038725-19-000046:mdna:101]
2018 vs. 2017

[0000038725-19-000046:mdna:102]
Net cash provided by operating activities was $128.4 million for 2018 compared to $66.8 million for 2017. The increase in cash provided by operations in 2018 was largely attributable to an increase in net income of $22 million before the prior year non-cash gain on equity investments and the impacts of the U.S. Tax Cuts and Jobs Act. The Company also had a reduction in prepaid assets, a decrease in working capital, primarily related to inventory consistent with increased sales, and a reduction in other assets, which consisted primarily of prepaid assets. These increases were partially offset by tax payments for the U.S. Tax Cuts and Jobs Act during the current year.

[0000038725-19-000046:mdna:103]
2017 vs. 2016

[0000038725-19-000046:mdna:104]
Net cash provided by operating activities was $66.8 million for 2017 compared to $115.4 million for 2016. A decrease in cash provided by operations in 2017 was largely attributable to an increase in inventory. Inventory increased primarily as actual shipments were less than sales projections for 2017 as well as advance purchases of strategic inventory products.  The Company also had higher uses of cash related to payments to vendors and reduction of other accrued liabilities, primarily payments of incentive compensation.

[0000038725-19-000046:mdna:105]
Cash Flows Used in Investing Activities

[0000038725-19-000046:mdna:106]
2018 vs. 2017

[0000038725-19-000046:mdna:107]
Net cash used in investing activities was $66.3 million in 2018 compared to $84.7 million in 2017. The decrease was attributable to decreased capital expenditures and a decrease in the cash paid for acquisitions.

[0000038725-19-000046:mdna:108]
2017 vs. 2016

[0000038725-19-000046:mdna:109]
Net cash used in investing activities was $84.7 million in 2017 compared to $33.8 million in 2016.  The increase was almost entirely attributable to cash paid related to the Distribution acquisitions during the second quarter of 2017.  The remainder of the change was partially offset by decreased capital expenditures in 2017.

[0000038725-19-000046:mdna:110]
Cash Flows Used in Financing Activities

[0000038725-19-000046:mdna:111]
2018 vs. 2017

[0000038725-19-000046:mdna:112]
Net cash used in financing activities was $66.8 million in 2018 compared to $22.6 million in 2017. The increase of cash used in financing activities was attributable to increased repayments relative to overall borrowings in the current year, increased common stock repurchases under the Company’s stock repurchase program, and increased dividend payments. These increases were partially offset by proceeds from the issuance of common stock as well as the Company’s purchase of redeemable noncontrolling shares that occurred in the prior year.

[0000038725-19-000046:mdna:113]
2017 vs. 2016

[0000038725-19-000046:mdna:114]
Net cash flows from financing activities were uses of cash of $22.6 million in 2017 compared to $51.7 million in 2016.  The decrease of cash used in financing activities in 2017 was primarily attributable to decreased repayment relative to debt proceeds in 2017.

[0000038725-19-000046:mdna:115]
AGGREGATE CONTRACTUAL OBLIGATIONS

[0000038725-19-000046:mdna:116]
The majority of the Company’s contractual obligations to third parties relate to debt obligations.  In addition, the Company has certain contractual obligations for future lease payments and purchase obligations.  The payment schedule for these contractual obligations is as follows:

[0000038725-19-000046:mdna:117]
| (In millions) |  |  |  |  |  |  |  |  | More than |
|  | Total |  | 2019 |  | 2020-2021 |  | 2022-2023 |  | 5 years |
| Debt | $ | 206.5 |  |  | $ | 112.0 |  |  | $ | 2.5 |  |  | $ | 2.6 |  |  | $ | 89.4 |  |
| Debt interest | 30.9 |  |  | 7.6 |  |  | 7.4 |  |  | 7.2 |  |  | 8.7 |  |
| Capital leases | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |
| Operating leases | 27.1 |  |  | 8.9 |  |  | 9.4 |  |  | 3.1 |  |  | 5.7 |  |
| Purchase obligations | 8.1 |  |  | 7.6 |  |  | 0.5 |  |  | — |  |  | — |  |
| Income Taxes-U.S. Tax Cuts and Jobs Act transition tax | $ | 17.8 |  |  | $ | 1.5 |  |  | $ | 3.1 |  |  | $ | 4.5 |  |  | $ | 8.7 |  |
|  | $ | 290.5 |  |  | $ | 137.6 |  |  | $ | 23.0 |  |  | $ | 17.4 |  |  | $ | 112.5 |  |

[0000038725-19-000046:mdna:118]
The Company has pension and other post-retirement benefit obligations not included in the table above which will result in estimated future payments of approximately $1 million in 2019.  The Company also has unrecognized tax benefits, none of which are included in the table above.  The unrecognized tax benefits of approximately $1.1 million have been recorded as liabilities and the Company is uncertain as to if or when such amounts may be settled.  Related to the unrecognized tax benefits, the Company has also recorded a liability for potential penalties and interest of $0.3 million.

[0000038725-19-000046:mdna:119]
ACCOUNTING PRONOUNCEMENTS

[0000038725-19-000046:mdna:120]
Adoption of New Accounting Standards

[0000038725-19-000046:mdna:121]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2017-07, Compensation - Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  This ASU requires entities to present only the service cost component of net periodic benefit cost as an operating expense (consistent with the presentation of other employee compensation costs).  The other components of net periodic benefit cost are to be presented as a non-operating expense. The Company adopted ASU 2017-07 during the first quarter ended March 31, 2018, on a retrospective basis. The non-service cost component of net periodic benefit costs for fiscal years ended December 31, 2017 and December 31, 2016 was approximately $0.2 million and $1.3 million, respectively.  The Company has included current year non-service costs as non-operating expense. The adoption of this pronouncement did not have a material impact to the Company’s consolidated financial position, results of operations, or cash flows.

[0000038725-19-000046:mdna:122]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) as modified by subsequently issued ASUs 2015-14, 2016-08, 2016-10, 2016-12 and 2016-20 (collectively ASU 2014-09).  Topic 606 supersedes the revenue recognition requirements in Accounting Standards Codification (“ASC”) Topic 605, Revenue Recognition (“Topic 605”), and requires the recognition of revenue when promised goods or services are transferred to customers in an amount that reflects the considerations to which the entity expects to be entitled to in exchange for those goods or services.  The Company made the accounting policy election allowed by ASC 606-10-32-2A to continue to present sales tax on a net basis, consistent with current guidance in ASC 605-45-15-2(e).  The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method).  The Company adopted ASU 2014-09 during the first quarter ended March 31, 2018 utilizing the modified retrospective approach. The adoption of this ASU did not have a material impact to the Company’s condensed consolidated financial position, results of operations, or cash flow; however, the adoption of this ASU requires the Company to disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company completed its assessment of the additional disclosure requirements with the following results:

[0000038725-19-000046:mdna:123]
Disaggregation of Revenue

[0000038725-19-000046:mdna:124]
The adoption of this ASU requires the Company to disaggregate revenue into categories to depict how the nature, timing, and uncertainty of revenue and cash flows are affected by economic factors.  As evidenced in Footnote 16 Segment and Geographic Information, the Company’s business consists of the Water, Fueling, Distribution, and Other segments. The Other segment includes unallocated corporate expenses and intersegment eliminations. A reconciliation of disaggregated revenue to segment revenue as well as Water Segment revenue by geographical regions is provided in Footnote 16, consistent with how the Company evaluates financial performance.

[0000038725-19-000046:mdna:125]
Performance Obligations

[0000038725-19-000046:mdna:126]
A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in ASC Topic 606.  The Company typically sells its products to customers by purchase order, and does not have any additional performance obligations included in contracts to customers other than the shipment of products. The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience. The Company typically ships products FOB shipping at which point control of the products passes to the customers. Any shipping and handling fees prior to shipment are considered activities required to fulfill the Company’s promise to transfer goods, and do not qualify as a separate performance obligation. Shipping and handling costs are recorded as a component of cost of sales.  Additionally, the Company offers assurance-type warranties (vs. service warranties) which do not qualify as a separate performance obligation. Therefore, the Company allocates the transaction price based on a single performance obligation.  The Company offers normal and customary trade terms to its customers, no significant part of which is of an extended nature.  The Company considers the performance obligation satisfied and recognizes revenue at a point in time, the time of shipment.  The Company does not generally allow for refunds or returns to customers and does not have outstanding performance obligations for contracts with original durations of greater than one year at the end of the reporting period.

[0000038725-19-000046:mdna:127]
Contract Costs

[0000038725-19-000046:mdna:128]
The Company does not have outstanding contracts with an original term greater than one year; therefore, the Company expenses costs to obtain a contract as incurred.

[0000038725-19-000046:mdna:129]
Accounting Standards Issued But Not Yet Adopted

[0000038725-19-000046:mdna:130]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which modifies the disclosure requirements for employers that sponsor defined benefit pension or other postretirement plans. The amendments remove disclosures that no longer are considered cost beneficial, including the estimated amounts in accumulated other comprehensive income expected to be recognized as components of net periodic expense over the next fiscal year. The amendments clarify the specific requirements of disclosures, and add disclosure requirements identified as relevant, including the reasons for significant gains and losses related to change in the benefit obligation for the period.  The ASU should be applied retrospectively and is effective for interim and annual periods beginning after December 15, 2020. The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-19-000046:mdna:131]
In August 2018, the FASB issued ASU 2018-15, Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. This ASU aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include internal-use software license). The ASU should be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption and is effective for interim and annual periods beginning after December 15, 2019 with early adoption permitted. The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-19-000046:mdna:132]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 ("Tax Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The ASU is effective for interim and annual periods beginning after December 15, 2018, with early adoption permitted, and may be applied either at the beginning of the period of adoption or retrospectively to each

[0000038725-19-000046:mdna:133]
period in which the effect of the change in the U.S. federal corporate income tax rate in the Tax Act is recognized. The Company will adopt the standard effective January 1, 2019.  The Company will not reclassify tax effects stranded in accumulated other comprehensive loss.  As such, there is no impact on the Company’s consolidated financial position, results of operations, and cash flows as a result of the adoption of the ASU.

[0000038725-19-000046:mdna:134]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-19-000046:mdna:135]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification (“ASC”) Topic 840.  This ASU requires lessees to present right-of-use (“ROU”) assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases and ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-10 clarifies certain aspects of Topic 842, including the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options, variable payments that depend on an index or rate and certain transition adjustments, among other things. ASU 2018-11 allows entities adopting ASU 2016-02 to choose an additional (and optional) transition method of adoption, under which an entity initially applies the new lease standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. Additionally, ASU 2018-11 allows lessors to not separate non-lease components from the associated lease component if certain conditions are met. The guidance is to be applied using either the transition method prescribed in ASU 2018-11 or a modified retrospective approach at the beginning of the earliest comparative period in the financial statements.

[0000038725-19-000046:mdna:136]
The Company will adopt the standard effective January 1, 2019 utilizing the optional transition method prescribed in ASU 2018-11. The Company intends to utilize the transition practical expedients, per ASC 842-10-65-11, that are permitted with the new standard when elected as a package. The Company intends to utilize other available practical expedients, including the election not to separate non-lease components and the election to use hindsight when determining the lease terms. Finally, the Company will make an accounting policy election that will not record leases with an initial term of 12 months or less (short-term leases) on the balance sheet.

[0000038725-19-000046:mdna:137]
The Company anticipates that the majority of its outstanding operating leases would be recognized as ROU assets and lease liabilities upon adoption. At adoption, the Company currently anticipates that it will recognize additional operating liabilities of approximately $22 million with corresponding ROU assets of the same amount based on the present value of the remaining minimum rental payments. The impact of this ASU is non-cash in nature and will not affect the Company’s cash position.  The Company does not estimate a material impact to the consolidated results of operations or cash flows.

[0000038725-19-000046:mdna:138]
CRITICAL ACCOUNTING ESTIMATES

[0000038725-19-000046:mdna:139]
Management’s discussion and analysis of its financial condition and results of operations are based upon the Company’s consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires management to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and the related disclosure of contingent assets and liabilities.  Management evaluates estimates on an ongoing basis.  Estimates are based on historical experience and on other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions.  There were no material changes to estimates or methodologies used to develop those estimates in 2018.

[0000038725-19-000046:mdna:140]
The Company’s critical accounting estimates are identified below:

[0000038725-19-000046:mdna:141]
Inventory Valuation

[0000038725-19-000046:mdna:142]
The Company uses certain estimates and judgments to value inventory. Inventory is recorded at the lower of cost or market. The Company reviews its inventories for excess or obsolete products or components. Based on an analysis of historical usage, management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts, carrying values are adjusted.  The carrying value is reduced regularly to reflect the age and current anticipated product demand. If actual demand differs from the estimates, additional reductions would be necessary in the period such determination is made.  Excess and obsolete inventory is periodically disposed of through sale to third parties, scrapping, or other means.

[0000038725-19-000046:mdna:143]
Business Combinations

[0000038725-19-000046:mdna:144]
The Company follows the guidance under FASB Accounting Standards Codification (“ASC”) Topic 805, Business Combinations.  The acquisition purchase price is allocated to the assets acquired and liabilities assumed based upon their respective fair values.  The Company shall report in its financial statements provisional amounts for the items for which accounting is incomplete.  Goodwill is adjusted for any changes to provisional amounts made within the measurement period.  The Company utilizes management estimates and an independent third-party valuation firm to assist in determining the fair values of assets acquired and liabilities assumed.  Such estimates and valuations require the Company to make significant assumptions, including projections of future events and operating performance.  The Company has not made any material changes to the method of valuing fair values of assets acquired and liabilities assumed during the last three years.

[0000038725-19-000046:mdna:145]
Trade Names and Goodwill

[0000038725-19-000046:mdna:146]
According to FASB ASC Topic 350, Intangibles - Goodwill and Other, intangible assets with indefinite lives must be tested for impairment at least annually or more frequently as warranted by triggering events that indicate potential impairment.  The Company uses a variety of methodologies in conducting impairment assessments including income and market approaches.  For indefinite-lived assets apart from goodwill, primarily trade names for the Company, if the fair value is less than the carrying amount, an impairment charge is recognized in an amount equal to that excess.  The Company has not made any material changes to the method of evaluating impairments during the last three years.

[0000038725-19-000046:mdna:147]
In compliance with FASB ASC Topic 350, goodwill is not amortized. Goodwill is tested at the reporting unit level for impairment annually or more frequently as warranted by triggering events that indicate potential impairment.  Reporting units are operating segments or one level below, known as components, which can be aggregated for testing purposes.  The Company’s goodwill is allocated to the North America Water Systems, International Water, and Fueling Systems units, as components within the North America Water Systems and International Water reporting units can be aggregated.  In 2017, as a result of the Headwater acquisition, the Company added a Distribution reporting unit. The Distribution reporting unit was subject to qualitative testing in the year of acquisition.  In 2018, all reporting units were tested using the quantitative valuation approaches listed below.  As the Company’s business model evolves, management will continue to evaluate its reporting units and review the aggregation criteria.

[0000038725-19-000046:mdna:148]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the market value and income approaches. The market value approach compares the reporting units’ current and projected financial results to entities of similar size and industry to determine the market value of the reporting unit. The income approach utilizes assumptions regarding estimated future cash flows and other factors to determine the fair value of the respective assets. These cash flows consider factors regarding expected future operating income and historical trends, as well as the effects of demand and competition. The Company may be required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units is below their associated carrying values. Goodwill included on the balance sheet as of the fiscal year ended 2018 was $248.7 million.

[0000038725-19-000046:mdna:149]
During the fourth quarter of 2018, the Company completed its annual impairment test of goodwill and tradenames and determined the fair value of all intangibles were substantially in excess of the respective carrying values.  Significant judgment is required to determine if an indication of impairment has taken place.  Factors to be considered include the following: adverse changes in operating results, decline in strategic business plans, significantly lower future cash flows, and sustainable declines in market data such as market capitalization.  A 10 percent decrease in the fair value estimates used in the impairment test would not have changed this determination.  The sensitivity analysis required the use of numerous subjective assumptions, which, if actual experience varies, could result in material differences in the requirements for impairment charges.  Further, an extended downturn in the economy may impact certain components of the operating segments more significantly and could result in changes to the aggregation assumptions and impairment determination.

[0000038725-19-000046:mdna:150]
Income Taxes

[0000038725-19-000046:mdna:151]
Under the requirements of FASB ASC Topic 740, Income Taxes, the Company records deferred tax assets and liabilities for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company analyzes the deferred tax assets and liabilities for their future realization based on the estimated existence of sufficient taxable income.  This analysis considers the following sources of taxable income: prior year taxable income, future reversals of existing taxable temporary differences, future taxable income exclusive of reversing temporary differences and tax planning strategies that would generate taxable income in the relevant period.  If sufficient taxable income is not projected then the Company will record a valuation allowance against the relevant deferred tax assets.

[0000038725-19-000046:mdna:152]
The Company’s operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions.  These jurisdictions have different tax rates, and the Company determines the allocation of income to each of these jurisdictions based upon various estimates and assumptions. In the normal course of business, the Company will undergo tax audits by various tax jurisdictions. Such audits often require an extended period of time to complete and may result in income tax adjustments if changes to the allocation are required between jurisdictions with different tax rates.  The final taxes paid are dependent upon many factors, including negotiations with taxing authorities in the various jurisdictions and resolution of disputes arising from federal, state, and international tax audits.  Although the Company has recorded all income tax uncertainties in accordance with FASB ASC Topic 740, these accruals represent estimates that are subject to the inherent uncertainties associated with the tax audit process, and therefore include uncertainties.  Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, which, if actual experience varies, could result in material adjustments to tax expense and/or deferred tax assets and liabilities.

[0000038725-19-000046:mdna:153]
Pension and Employee Benefit Obligations

[0000038725-19-000046:mdna:154]
The Company consults with its actuaries to assist with the calculation of discount rates used in its pension and post retirement plans.  Beginning in 2016, the discount rates used to determine domestic pension and post-retirement plan liabilities are calculated using a full yield curve approach.  The change compared to the previous method resulted in different service and interest components of net periodic benefit cost in the 2016 fiscal year.  Historically, the Company estimated these service and interest cost components utilizing a single weighted-average discount rate derived from the yield curve used to measure the benefit obligation at the beginning of the period.  The Company made this change to provide a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot yield curve rates. Market conditions have caused the weighted-average discount rate to move from 3.61 percent last year to 4.28 percent this year for the domestic pension plans and from 3.51 percent last year to 4.18 percent this year for the postretirement health and life insurance plan. A change in the discount rate selected by the Company of 25 basis points would result in a change of about $0.1 million to employee benefit expense and a change of about $4.0 million of liability.

[0000038725-19-000046:mdna:155]
The Company consults with actuaries and investment advisors in making its determination of the expected long-term rate of return on plan assets. Using input from these consultations such as long-term investment sector expected returns, the correlations and standard deviations thereof, and the plan asset allocation, the Company has assumed an expected long-term rate of return on plan assets of 5.75 percent as of the fiscal year ended 2018.  A change in the long-term rate of return selected by the Company of 25 basis points would result in a change of about $0.4 million of employee benefit expense.

[0000038725-19-000046:mdna:156]
According to FASB ASC 715, Compensation - Retirement Benefits, settlement accounting is triggered when lump sum payouts from a defined benefit plan exceed the sum of service cost and interest cost for the year. During 2016, one of the Company’s domestic pension plans required settlement accounting as a payout to a participant exceeded these criteria.

[0000038725-19-000046:mdna:157]
FACTORS THAT MAY AFFECT FUTURE RESULTS
