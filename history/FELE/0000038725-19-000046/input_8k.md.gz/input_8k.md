# FELE 8-K — 0000038725-19-000008 filed 2019-02-19

## item codes, every 8-K on or before 2019-02-28

- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2019-02-28

- none on or before 2019-02-28

## item 2.02 — earnings release, exhibit 99.1

[0000038725-19-000008:8k_2_02:1]
EX-99.1
2
a201902198-kexhibit991.htm
EXHIBIT 99.1

[0000038725-19-000008:8k_2_02:2]
Exhibit

[0000038725-19-000008:8k_2_02:3]
Exhibit 99.1

[0000038725-19-000008:8k_2_02:4]
For Immediate Release

[0000038725-19-000008:8k_2_02:5]
For Further Information

[0000038725-19-000008:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-19-000008:8k_2_02:7]
260-824-2900

[0000038725-19-000008:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS RECORD FOURTH

[0000038725-19-000008:8k_2_02:9]
QUARTER AND FULL YEAR 2018 SALES AND EARNINGS

[0000038725-19-000008:8k_2_02:10]
Fort Wayne, IN - February 19, 2019 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported fourth quarter 2018 GAAP fully diluted earnings per share (EPS) of $0.51, versus a GAAP fully diluted EPS in the fourth quarter 2017 of $0.17.  Fourth quarter 2018 sales were $316.7 million, compared to 2017 fourth quarter sales of $288.2 million.  Fourth quarter 2018 organic sales increased about 9 percent when excluding the impact of foreign currency translation. Fourth quarter EPS before the impact of restructuring expenses was $0.52 compared to 2017 fourth quarter EPS before restructuring of $0.21 (see table below for a reconciliation of GAAP EPS to EPS before restructuring). The Company incurred a tax expense of $0.21 per share in the fourth quarter of 2017 related to the U.S. Tax Cuts and Jobs Act of 2017. Before restructuring and the tax expense, the Company’s fourth quarter EPS was $0.42.

[0000038725-19-000008:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-19-000008:8k_2_02:12]
“Our record fourth quarter results were driven by continued strong performance in the U.S. Water Systems and our global Fueling Systems businesses. Before restructuring charges, our operating income and earnings per share grew by 17 and 24 percent, respectively, compared to the fourth quarter of 2017. Water margin improved; but Fueling margin declined from last year’s record margin, due to mix and cost pressures. Cash generation in the quarter was strong and reductions in working capital drove 2018 free cash flow to equal net income for the year.

[0000038725-19-000008:8k_2_02:13]
For the full year 2018, we set new records in all our key financial metrics with all-time highs in net sales, gross profit, operating income, earnings per share and cash flow from operations.  Despite continued headwinds from global economic and political uncertainties, we remain confident we can sustain this momentum into 2019.”

[0000038725-19-000008:8k_2_02:14]
Key Performance Indicators:

[0000038725-19-000008:8k_2_02:15]
| Earnings Before and After Restructuring |  | For the Fourth Quarter |  | For the Full Year |
| (in millions) |  | 2018 | 2017 | Change |  | 2018 | 2017 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 24.2 |  | $ | 8.1 |  | 199 | % |  | $ | 105.9 |  | $ | 78.2 |  | 35 | % |
| Allocated Earnings |  | $ | (0.2 | ) | $ | (0.1 | ) |  |  | $ | (0.8 | ) | $ | (0.6 | ) |  |
| Earnings for EPS Calculations |  | $ | 24.0 |  | $ | 8.0 |  | 200 | % |  | $ | 105.1 |  | $ | 77.6 |  | 35 | % |
| Restructuring (before tax): |  | $ | 0.7 |  | $ | 2.7 |  |  |  | $ | 1.7 |  | $ | 4.3 |  |  |
| Restructuring, net of tax: |  | $ | 0.6 |  | $ | 1.6 |  |  |  | $ | 1.4 |  | $ | 2.6 |  |  |
| 2017 Impact of U.S. Tax Cuts and Jobs Act |  | $ | — |  | $ | 10.2 |  |  |  | $ | — |  | $ | 10.2 |  |  |
| Earnings Before Restructuring |  | $ | 24.6 |  | $ | 19.8 |  | 24 | % |  | $ | 106.5 |  | $ | 90.4 |  | 18 | % |
| Earnings Per Share |  | For the Fourth Quarter |  | For the Full Year |
| Before and After Restructuring |  | 2018 | 2017 | Change |  | 2018 | 2017 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.8 |  | 47.1 |  | (1 | )% |  | 47.0 |  | 47.0 |  | — | % |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.51 |  | $ | 0.17 |  | 200 | % |  | $ | 2.23 |  | $ | 1.65 |  | 35 | % |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | 0.04 |  |  |  | $ | 0.03 |  | $ | 0.06 |  |  |
| 2017 Impact of the U.S. Tax Cuts and Jobs Act |  | $ | — |  | $ | 0.21 |  |  |  | $ | — |  | $ | 0.21 |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.52 |  | $ | 0.42 |  | 24 | % |  | $ | 2.26 |  | $ | 1.92 |  | 18 | % |

[0000038725-19-000008:8k_2_02:16]
|  | Net Sales For the Fourth Quarter |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q4 2017 | $ | 80.1 |  | $ | 33.4 |  | $ | 44.3 |  | $ | 23.7 |  | $ | 181.5 |  | $ | 67.9 |  | $ | 49.5 |  | $ | (10.7 | ) | $ | 288.2 |  |
| Q4 2018 | $ | 98.1 |  | $ | 31.6 |  | $ | 42.5 |  | $ | 23.8 |  | $ | 196.0 |  | $ | 75.9 |  | $ | 56.0 |  | $ | (11.2 | ) | $ | 316.7 |  |
| Change | $ | 18.0 |  | $ | (1.8 | ) | $ | (1.8 | ) | $ | 0.1 |  | $ | 14.5 |  | $ | 8.0 |  | $ | 6.5 |  | $ | (0.5 | ) | $ | 28.5 |  |
| % Change | 22 | % | (5 | )% | (4 | )% | — | % | 8 | % | 12 | % | 13 | % |  | 10 | % |
| Foreign currency translation | $ | (0.6 | ) | $ | (2.9 | ) | $ | (5.0 | ) | $ | (1.0 | ) | $ | (9.5 | ) | $ | (1.3 | ) | $ | — |  |  |  |
| % Change | (1 | )% | (8 | )% | (11 | )% | (5 | )% | (5 | )% | (1 | )% | — | % |  |  |
| Acquisitions |  | $ | 4.4 |  |  |  | $ | 4.4 |  | $ | 2.2 |  | $ | 6.4 |  |  |  |
| Volume/Price | $ | 18.6 |  | $ | (3.3 | ) | $ | 3.2 |  | $ | 1.1 |  | $ | 19.6 |  | $ | 7.1 |  | $ | 0.1 |  |  |  |
| % Change | 23 | % | (10 | )% | 7 | % | 5 | % | 11 | % | 10 | % | — | % |  |  |

[0000038725-19-000008:8k_2_02:17]
|  | Net Sales For the Full Year |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| FY 2017 | $ | 349.3 |  | $ | 130.0 |  | $ | 177.7 |  | $ | 86.3 |  | $ | 743.3 |  | $ | 245.7 |  | $ | 176.7 |  | $ | (40.8 | ) | $ | 1,124.9 |  |
| FY 2018 | $ | 410.3 |  | $ | 120.9 |  | $ | 184.3 |  | $ | 81.0 |  | $ | 796.5 |  | $ | 288.2 |  | $ | 269.6 |  | $ | (56.2 | ) | $ | 1,298.1 |  |
| Change | $ | 61.0 |  | $ | (9.1 | ) | $ | 6.6 |  | $ | (5.3 | ) | $ | 53.2 |  | $ | 42.5 |  | $ | 92.9 |  | $ | (15.4 | ) | $ | 173.2 |  |
| % Change | 17 | % | (7 | )% | 4 | % | (6 | )% | 7 | % | 17 | % | 53 | % |  | 15 | % |
| Foreign currency translation | $ | 0.5 |  | $ | (9.3 | ) | $ | (5.2 | ) | $ | (1.4 | ) | $ | (15.4 | ) | $ | 2.3 |  | $ | — |  |  |  |
| % Change | — | % | (7 | )% | (3 | )% | (1 | )% | (2 | )% | 1 | % | — | % |  |  |
| Acquisitions | — |  | $ | 8.3 |  | — |  | — |  | $ | 8.3 |  | $ | 3.5 |  | $ | 87.4 |  |  |  |
| Volume/Price | $ | 60.5 |  | $ | (8.1 | ) | $ | 11.8 |  | $ | (3.9 | ) | $ | 60.3 |  | $ | 36.7 |  | $ | 5.6 |  |  |  |
| % Change | 17 | % | (6 | )% | 7 | % | (5 | )% | 8 | % | 15 | % | 3 | % |  |  |

[0000038725-19-000008:8k_2_02:18]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2018 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 27.0 |  | $ | 17.0 |  | $ | (2.9 | ) | $ | (12.4 | ) | $ | 28.7 |  |
| % Operating Income To Net Sales | 13.8 | % | 22.4 | % | (5.2 | )% |  | 9.1 | % |
| Restructuring | $ | 0.1 |  | $ | 0.1 |  | $ | 0.5 |  | $ | — |  | $ | 0.7 |  |
| Operating Income/(Loss) Before Restructuring | $ | 27.1 |  | $ | 17.1 |  | $ | (2.4 | ) | $ | (12.4 | ) | $ | 29.4 |  |
| % Operating Income to Net Sales Before Restructuring | 13.8 | % | 22.5 | % | (4.3 | )% |  | 9.3 | % |
|  | For the Fourth Quarter 2017 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 19.5 |  | $ | 17.0 |  | $ | (2.0 | ) | $ | (12.1 | ) | $ | 22.4 |  |
| % Operating Income To Net Sales | 10.7 | % | 25.0 | % | (4.0 | )% |  | 7.8 | % |
| Restructuring | $ | 1.1 |  | $ | 1.6 |  | $ | — |  | $ | — |  | $ | 2.7 |  |
| Operating Income/(Loss) Before Restructuring | $ | 20.6 |  | $ | 18.6 |  | $ | (2.0 | ) | $ | (12.1 | ) | $ | 25.1 |  |
| % Operating Income to Net Sales Before Restructuring | 11.3 | % | 27.4 | % | (4.0 | )% |  | 8.7 | % |

[0000038725-19-000008:8k_2_02:19]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year of 2018 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 112.9 |  | $ | 70.4 |  | $ | 3.4 |  | $ | (54.7 | ) | $ | 132.0 |  |
| % Operating Income To Net Sales | 14.2 | % | 24.4 | % | 1.3 | % |  | 10.2 | % |
| Restructuring | $ | 0.6 |  | $ | 0.3 |  | $ | 0.8 |  | $ | — |  | $ | 1.7 |  |
| Operating Income/(Loss) Before Restructuring | $ | 113.5 |  | $ | 70.7 |  | $ | 4.2 |  | $ | (54.7 | ) | $ | 133.7 |  |
| % Operating Income to Net Sales Before Restructuring | 14.2 | % | 24.5 | % | 1.6 | % |  | 10.3 | % |
|  | For the Full Year of 2017 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 102.0 |  | $ | 60.0 |  | $ | 3.7 |  | $ | (58.5 | ) | $ | 107.2 |  |
| % Operating Income To Net Sales | 13.7 | % | 24.4 | % | 2.1 | % |  | 9.5 | % |
| Restructuring | $ | 2.7 |  | $ | 1.6 |  | $ | — |  | $ | — |  | $ | 4.3 |  |
| Operating Income/(Loss) Before Restructuring | $ | 104.7 |  | $ | 61.6 |  | $ | 3.7 |  | $ | (58.5 | ) | $ | 111.5 |  |
| % Operating Income to Net Sales Before Restructuring | 14.1 | % | 25.1 | % | 2.1 | % |  | 9.9 | % |

[0000038725-19-000008:8k_2_02:20]
Water Systems

[0000038725-19-000008:8k_2_02:21]
Water Systems sales were $196.0 million in the fourth quarter 2018, versus the fourth quarter 2017 sales of $181.5 million.  In the fourth quarter of 2018, sales from businesses acquired since the fourth quarter of 2017 were $4.4 million. Water Systems sales decreased about 5 percent in the quarter due to foreign currency translation. Water Systems organic sales increased about 11 percent compared to the fourth quarter of 2017.

[0000038725-19-000008:8k_2_02:22]
Water Systems sales in the U.S. and Canada increased by about 22 percent compared to the fourth quarter 2017. Foreign currency translation decreased sales by about 1 percent.  Sales of Pioneer branded dewatering equipment doubled in the fourth quarter when compared to the prior year due to continued strength in North American oil and gas markets and diversification of product sales channels and geographies. Sales of other surface pumping equipment increased by about 9 percent on stronger HVAC and wastewater products, versus the fourth quarter 2017. Sales of groundwater pumping equipment were flat, versus the fourth quarter 2017.

[0000038725-19-000008:8k_2_02:23]
Outside the U.S. and Canada, Water Systems realized mid to upper single digit organic growth in Europe, the Middle East, Africa, and Asia Pacific. This increase was mostly offset by a 10 percent organic sales decline in Latin America, primarily Brazil. Due to the strengthening U.S. dollar, foreign exchange translation lowered sales outside the U.S. and Canada by about  percent in the fourth quarter.

[0000038725-19-000008:8k_2_02:24]
Water Systems operating income was $27.0 million in the fourth quarter 2018, compared to $19.5 million in the fourth quarter 2017.  Strong operating income growth in the U.S. and Canada was partially offset by declines in international regions, in part due to weakening foreign currencies versus the U.S. dollar.

[0000038725-19-000008:8k_2_02:25]
Fueling Systems

[0000038725-19-000008:8k_2_02:26]
Fueling Systems sales were a record $75.9 million in the fourth quarter 2018 compared to fourth quarter 2017 sales of $67.9 million.  In the fourth quarter of 2018, sales from businesses acquired since the fourth quarter of 2017 were $2.2 million.  Fueling Systems organic sales were up about 10 percent compared to the fourth quarter of 2017.

[0000038725-19-000008:8k_2_02:27]
Fueling Systems sales in the U.S. and Canada increased by about 13 percent compared to the fourth quarter 2017.  The increase was principally in the fuel management and service station hardware product lines.  Outside the U.S. and Canada, Fueling Systems revenues grew by about 8 percent, led by stronger sales of pipe and containment systems in China.

[0000038725-19-000008:8k_2_02:28]
Fueling Systems operating income was $17.0 million in the fourth quarter of 2018 and 2017, respectively.  Fueling Systems operating income was flat in the fourth quarter as growth from higher sales was offset primarily by negative geographic and product sales mix and higher fixed costs.

[0000038725-19-000008:8k_2_02:29]
Distribution

[0000038725-19-000008:8k_2_02:30]
Distribution sales were $56.0 million in the fourth quarter 2018, versus fourth quarter 2017 sales of $49.5 million.  In the fourth quarter of 2018, sales from businesses acquired since the fourth quarter of 2017 were $6.4 million.  The Distribution segment organic sales were flat compared to the fourth quarter of 2017.

[0000038725-19-000008:8k_2_02:31]
The Distribution segment recorded an operating loss of $2.9 million in the fourth quarter of 2018, compared to $2.0 million loss in the fourth quarter of 2017.  Higher product costs not completely offset by price and higher employee benefit costs contributed to the Distribution segment earnings decline.

[0000038725-19-000008:8k_2_02:32]
Overall

[0000038725-19-000008:8k_2_02:33]
The Company’s consolidated gross profit was $104.3 million for the fourth quarter of 2018, an increase from the fourth quarter of 2017 gross profit of $94.6 million.  The gross profit increase was primarily due to higher sales.  The gross profit as a percent of net sales was 33.0 percent in the fourth quarter of 2018 compared 32.8 percent in the fourth quarter of 2017.

[0000038725-19-000008:8k_2_02:34]
Selling, general, and administrative (SG&A) expenses were $75.0 million in the fourth quarter of 2018 compared to $69.4 million in the fourth quarter of the prior year.  The increase in SG&A expenses from acquired businesses was $3.3 million.  Excluding the acquired entities, the Company’s SG&A expenses in the fourth quarter of 2018 were $71.7 million, an increase of about 3 percent from the fourth quarter 2017, due primarily to higher variable compensation expenses in the fourth quarter of 2018 versus the prior year.

[0000038725-19-000008:8k_2_02:35]
The Company ended 2018 with a cash balance of $59.2 million, which was $8.0 million lower than at the end of 2017.  Significantly higher net cash flows from operating activities were offset by higher repayments of debt and repurchases of the Company’s common stock in 2018.

[0000038725-19-000008:8k_2_02:36]
Commenting on the outlook for 2019, Mr. Sengstack said:

[0000038725-19-000008:8k_2_02:37]
“As we look towards 2019, our U.S. Water and global Fueling Systems businesses have great potential for continued growth and have good momentum coming out of 2018, however, many of the headwinds that have challenged our International Water businesses remain, most notably in Brazil and Asia Pacific.  Our distribution business is positioned for better growth and profitability in 2019.

[0000038725-19-000008:8k_2_02:38]
We are currently thinking that our organic growth will slow from the 9 percent we experienced in 2018 to around 4 to 6 percent in 2019.  Further, we calculate that there is about $27 million or 2 percent of foreign exchange headwind in our revenue in 2019 due to a strengthened U.S. dollar.  We also note that because of discrete tax benefits realized in 2018 that will not repeat in 2019, we expect our overall effective tax rate to increase to between 18 and 20 percent in 2019, or about 20 cents of headwind to earnings per share.

[0000038725-19-000008:8k_2_02:39]
As a result of this growth, offset by the impact of the strong dollar and a higher tax rate, we currently estimate our 2019 earnings per share before restructuring charges to be between $2.37 and $2.47.”

[0000038725-19-000008:8k_2_02:40]
A conference call to review earnings and other developments in the business will commence at 9:00 am EST.  The fourth quarter and fiscal year 2018 earnings call will be available via a live webcast.  The webcast will be available in a listen only mode by going to:

[0000038725-19-000008:8k_2_02:41]
https://edge.media-server.com/m6/p/2ufggzr4

[0000038725-19-000008:8k_2_02:42]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 3798049.

[0000038725-19-000008:8k_2_02:43]
A replay of the conference call will be available Tuesday, February 19, 2019 at 12:00 noon EST through noon EST on Tuesday, February 26, 2019, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 3798049.

[0000038725-19-000008:8k_2_02:44]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-19-000008:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Fourth Quarter Ended |  | Fiscal Year Ended |
|  | December 31, 2018 |  | December 31, 2017 |  | December 31, 2018 |  | December 31, 2017 |
| Net sales | $ | 316,663 |  |  | $ | 288,195 |  |  | $ | 1,298,129 |  |  | $ | 1,124,909 |  |
| Cost of sales | 212,321 |  |  | 193,624 |  |  | 865,763 |  |  | 747,927 |  |
| Gross profit | 104,342 |  |  | 94,571 |  |  | 432,366 |  |  | 376,982 |  |
| Selling, general, and administrative expenses | 74,983 |  |  | 69,370 |  |  | 298,706 |  |  | 265,447 |  |
| Restructuring expense | 676 |  |  | 2,732 |  |  | 1,666 |  |  | 4,307 |  |
| Operating income/(expense),net | 28,683 |  |  | 22,469 |  |  | 131,994 |  |  | 107,228 |  |
| Interest expense | (2,362 | ) |  | (2,267 | ) |  | (9,839 | ) |  | (10,322 | ) |
| Other income/(expense), net | (461 | ) |  | 40 |  |  | (1,042 | ) |  | 6,656 |  |
| Foreign exchange income/(expense) | 2,445 |  |  | 729 |  |  | (706 | ) |  | 1,025 |  |
| Income before income taxes | 28,305 |  |  | 20,971 |  |  | 120,407 |  |  | 104,587 |  |
| Income tax expense | 3,974 |  |  | 13,104 |  |  | 14,890 |  |  | 25,994 |  |
| Net income | $ | 24,331 |  |  | $ | 7,867 |  |  | $ | 105,517 |  |  | $ | 78,593 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (131 | ) |  | 204 |  |  | 360 |  |  | (413 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 24,200 |  |  | $ | 8,071 |  |  | $ | 105,877 |  |  | $ | 78,180 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.52 |  |  | $ | 0.17 |  |  | $ | 2.25 |  |  | $ | 1.67 |  |
| Diluted | $ | 0.51 |  |  | $ | 0.17 |  |  | $ | 2.23 |  |  | $ | 1.65 |  |

[0000038725-19-000008:8k_2_02:46]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | December 31, 2018 |  | December 31, 2017 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 59,173 |  |  | $ | 67,233 |  |
| Receivables | 172,899 |  |  | 171,007 |  |
| Inventories | 314,049 |  |  | 312,325 |  |
| Other current assets | 33,758 |  |  | 38,566 |  |
| Total current assets | 579,879 |  |  | 589,131 |  |
| Property, plant, and equipment, net | 207,064 |  |  | 215,694 |  |
| Goodwill and other assets | 395,422 |  |  | 380,528 |  |
| Total assets | $ | 1,182,365 |  |  | $ | 1,185,353 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 76,652 |  |  | $ | 79,348 |  |
| Accrued expenses and other current liabilities | 67,230 |  |  | 66,100 |  |
| Current maturities of long-term debt and short-term borrowings | 111,975 |  |  | 100,453 |  |
| Total current liabilities | 255,857 |  |  | 245,901 |  |
| Long-term debt | 94,379 |  |  | 125,596 |  |
| Income taxes payable non-current | 10,881 |  |  | 17,391 |  |
| Deferred income taxes | 28,949 |  |  | 30,913 |  |
| Employee benefit plans | 38,020 |  |  | 42,178 |  |
| Other long-term liabilities | 17,934 |  |  | 19,251 |  |
| Redeemable noncontrolling interest | 518 |  |  | 1,502 |  |
| Total equity | 735,827 |  |  | 702,621 |  |
| Total liabilities and equity | $ | 1,182,365 |  |  | $ | 1,185,353 |  |

[0000038725-19-000008:8k_2_02:47]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
| (In thousands) | 2018 |  | 2017 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 105,517 |  |  | $ | 78,593 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 38,604 |  |  | 38,506 |  |
| Share-based compensation | 8,450 |  |  | 7,109 |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | — |  |  | 10,198 |  |
| Gain on equity investment | — |  |  | (5,165 | ) |
| Other | (4,147 | ) |  | (5,764 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (8,194 | ) |  | 9,948 |  |
| Inventory | (4,775 | ) |  | (46,372 | ) |
| Accounts payable and accrued expenses | 1,677 |  |  | (11,071 | ) |
| Income taxes-U.S. Tax Cuts and Jobs Act | (6,510 | ) |  | — |  |
| Other | (2,187 | ) |  | (9,228 | ) |
| Net cash flows from operating activities | 128,435 |  |  | 66,754 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (22,432 | ) |  | 33,484 |  |
| Proceeds from sale of property, plant, and equipment | 724 |  |  | 211 |  |
| Acquisitions and investments | (44,971 | ) |  | (51,783 | ) |
| Other investing activities | 387 |  |  | 355 |  |
| Net cash flows from investing activities | (66,292 | ) |  | (84,701 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (18,985 | ) |  | 1,882 |  |
| Proceeds from issuance of common stock | 8,999 |  |  | 4,497 |  |
| Purchases of common stock | (34,188 | ) |  | (3,621 | ) |
| Dividends paid | (22,612 | ) |  | (20,289 | ) |
| Purchase of redeemable non-controlling shares | — |  |  | (5,047 | ) |
| Net cash flows from financing activities | (66,786 | ) |  | (22,578 | ) |
| Effect of exchange rate changes on cash | (3,417 | ) |  | 3,427 |  |
| Net change in cash and equivalents | (8,060 | ) |  | (37,098 | ) |
| Cash and equivalents at beginning of period | 67,233 |  |  | 104,331 |  |
| Cash and equivalents at end of period | $ | 59,173 |  |  | $ | 67,233 |  |
