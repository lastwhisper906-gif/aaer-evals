# FELE note change history — 0000038725-23-000151 → 0000038725-23-000182


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-10-27):
[0000038725-23-000182:note_history:1]
At September 30, 2023, the Company had $9.6 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2023-07-28, similarity 0.9625):
[0000038725-23-000151:note_history:1]
At June 30, 2023, the Company had $11.1 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2023-10-27):
[0000038725-23-000182:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2023, are as follows:
  (was, 2023-07-28, similarity 0.9582):
[0000038725-23-000151:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2023, are as follows:

- changed (2023-10-27):
[0000038725-23-000182:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2022 |  | $ | 11.2 |  |
| Accruals related to product warranties |  | 9.4 |  |
| Reductions for payments made |  | (10.3) |  |
| Balance as of September 30, 2023 |  | $ | 10.3 |  |
  (was, 2023-07-28, similarity 0.9724):
[0000038725-23-000151:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2022 |  | $ | 11.2 |  |
| Accruals related to product warranties |  | 6.4 |  |
| Reductions for payments made |  | (6.9) |  |
| Balance as of June 30, 2023 |  | $ | 10.7 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-10-27):
[0000038725-23-000182:note_history:4]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2022, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2023, and for the third quarters and nine months ended September 30, 2023 and September 30, 2022 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2023. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022.
  (was, 2023-07-28, similarity 0.9345):
[0000038725-23-000151:note_history:4]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2022, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2023, and for the second quarters and six months ended June 30, 2023 and June 30, 2022 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2023. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-27):
[0000038725-23-000182:note_history:5]
| (In millions) |  | September 30, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 39.0 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.1 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 0.4 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 128.4 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (40.4) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.0 |  |  | $ | 89.3 |  |
  (was, 2023-07-28, similarity 0.9178):
[0000038725-23-000151:note_history:5]
| (In millions) |  | June 30, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 158.3 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.7 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 0.6 |  |  | 3.1 |  |
| Other |  | — |  |  | — |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 248.5 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (159.8) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.7 |  |  | 89.3 |

- added (2023-10-27):
[0000038725-23-000182:note_history:6]
As of September 30, 2023, the Company had $39.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $307.4 million of available capacity under its credit agreement. As of December 31, 2022, the Company had $122.8 million outstanding borrowings with a weighted-average interest rate of 5.0 percent, $4.0 million in letters of credit outstanding, and $223.2 million of available capacity under its credit agreement.

- added (2023-10-27):
[0000038725-23-000182:note_history:7]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $18.1 million. As of September 30, 2023, there were no outstanding borrowings and $18.1 million of available capacity under these lines of credit. As of December 31, 2022, there were $22.0 million overdraft lines of credit with $2.7 million of outstanding borrowings and $19.3 million of available capacity under these lines of credit.

- removed (2023-10-27):
[0000038725-23-000151:note_history:8]
As of June 30, 2023, the Company had $158.3 million outstanding borrowings with a weighted-average interest rate of 5.9 percent, $3.6 million in letters of credit outstanding, and $188.1 million of available capacity under its credit agreement. As of December 31, 2022, the Company had $122.8 million outstanding borrowings with a weighted-average interest rate of 5.0 percent, $4.0 million in letters of credit outstanding, and $223.2 million of available capacity under its credit agreement.

- removed (2023-10-27):
[0000038725-23-000151:note_history:9]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $20.3 million. As of June 30, 2023, there were $0.1 million outstanding borrowings and $20.2 million of available capacity under these lines of credit. As of December 31, 2022, there were $22.0 million overdraft lines of credit with $2.7 million of outstanding borrowings and $19.3 million of available capacity under these lines of credit.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-27):
[0000038725-23-000182:note_history:10]
| (In millions) |  | September 30, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 39.0 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.1 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 0.4 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 128.4 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (40.4) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.0 |  |  | $ | 89.3 |  |
  (was, 2023-07-28, similarity 0.9178):
[0000038725-23-000151:note_history:10]
| (In millions) |  | June 30, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 158.3 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.7 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 0.6 |  |  | 3.1 |  |
| Other |  | — |  |  | — |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 248.5 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (159.8) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.7 |  |  | 89.3 |
