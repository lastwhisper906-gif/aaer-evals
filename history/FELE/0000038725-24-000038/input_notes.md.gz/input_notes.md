# FELE notes — 0000038725-24-000038


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000038725-24-000038:notes:1]
A portion of the Proxy Statement for the Annual Meeting of Shareholders to be held on May 3, 2024 (Part III).


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000038725-24-000038:notes:2]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Company--“Franklin Electric” or the “Company” shall refer to Franklin Electric Co., Inc. and its consolidated subsidiaries.

[0000038725-24-000038:notes:3]
Fiscal Year--The financial statements and accompanying notes are as of and for the years ended December 31, 2023, December 31, 2022, and December 31, 2021, and referred to as 2023, 2022, and 2021, respectively.

[0000038725-24-000038:notes:4]
Principles of Consolidation--The consolidated financial statements include the accounts of Franklin Electric Co., Inc. and its consolidated subsidiaries. All intercompany transactions have been eliminated.

[0000038725-24-000038:notes:5]
Business Combinations--The Company allocates the purchase price of its acquisitions to the assets acquired, liabilities assumed, and noncontrolling interests based upon their respective fair values at the acquisition date. The Company utilizes management estimates and may use inputs from an independent third-party valuation firm to assist in determining these fair values. The excess of the acquisition price over estimated fair values of the net assets acquired is recorded as goodwill. Goodwill is adjusted for any changes to acquisition date fair value amounts made within the measurement period, which may be up to one year from the acquisition date. If the preliminary, estimated fair values of the net assets acquired are in excess of the acquisition price, that represents a bargain purchase gain, and the Company records this amount in "Accrued expenses and other current liabilities" on the consolidated balance sheet until it completes its determination of fair values for the net assets acquired. Once that fair value determination is completed, the bargain purchase gain is recognized on the consolidated statements of income in "Other income/(expense), net". Acquisition-related transaction costs are recognized separately from the business combination and expensed as incurred.

[0000038725-24-000038:notes:6]
Revenue Recognition--Revenue is recognized when promised goods or services are transferred to customers in an amount that reflects the consideration to which the entity expects to be entitled to in exchange for those goods or services. The promise in a contract to transfer goods or services to a customer represents a performance obligation. The Company typically sells its products to customers by purchase order and does not have any additional performance obligations included in contracts to customers. Shipping and handling activities are considered to be fulfillment activities and are not considered to be a separate performance obligation. Therefore, the Company allocates the transaction price based on a single performance obligation. The Company typically ships products Free on Board (FOB) shipping point at which point control of the products passes to the customers. The Company considers the performance obligation satisfied and recognizes revenue at a point in time, the time of shipment. The Company applies a practical expedient to expense as incurred costs to obtain a contract with a customer when the amortization period would have been one year or less as well as applies the financing component practical expedient when the duration of the financing is one year or less.

[0000038725-24-000038:notes:7]
The Company’s products may include routine assurance-type warranties which do not qualify as separate performance obligations. In the event that significant post-shipment obligations were to exist for the Company’s products, revenue recognition would be deferred until the performance obligations were satisfied.

[0000038725-24-000038:notes:8]
The Company records net sales after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience.

[0000038725-24-000038:notes:9]
Shipping and Handling Costs--Shipping and handling costs are considered activities required to fulfill the Company’s promise to transfer goods, and do not qualify as a separate performance obligation. Shipping and handling costs are recorded as a component of cost of sales.

[0000038725-24-000038:notes:10]
Research and Development Expense--The Company’s research and development activities are charged to expense in the period incurred. The Company incurred expenses of approximately $17.7 million in 2023, $16.7 million in 2022, and $17.3 million in 2021 related to research and development.

[0000038725-24-000038:notes:11]
Cash and Cash Equivalents--The Company considers cash on hand, demand deposits, and highly liquid investments with an original maturity date of three months or less to be cash and cash equivalents.

[0000038725-24-000038:notes:12]
Fair Value of Financial Instruments--Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value. The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-24-000038:notes:13]
Level 1 – Quoted prices for identical assets and liabilities in active markets;

[0000038725-24-000038:notes:14]
Level 2 – Quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets; and

[0000038725-24-000038:notes:15]
Level 3 – Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable.

[0000038725-24-000038:notes:16]
Accounts Receivable, Earned Discounts, and Allowance for Uncollectible Accounts--Accounts receivable are stated at estimated net realizable value. Accounts receivable are comprised of balances due from customers, net of earned discounts and estimated allowances for uncollectible accounts. Earned discounts are based on specific customer agreement terms. In determining allowances for uncollectible accounts, historical collection experience, current trends and reasonable, supportable future forecasts, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are reviewed.

[0000038725-24-000038:notes:17]
Inventories--Inventories are stated at the lower of cost or net realizable value. The majority of the cost of inventories is determined using the first in, first out (FIFO) method with a portion of inventory costs determined using the average cost method. The Company reviews its inventories for excess or obsolete products or components based on an analysis of historical usage and management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts.

[0000038725-24-000038:notes:18]
Property, Plant, and Equipment--Property, plant, and equipment are stated at historical cost. The Company capitalizes certain computer software and software development costs incurred in connection with developing or obtaining computer software for internal use, which are included in property, plant, and equipment. Depreciation of property, plant and equipment is calculated on a straight line basis over the following estimated useful lives:

[0000038725-24-000038:notes:19]
| Land improvement and buildings | 10 - 40 years |
| Machinery and equipment | 5 - 10 years |
| Software | 3 - 7 years |
| Furniture and fixtures | 3 - 7 years |

[0000038725-24-000038:notes:20]
Maintenance, repairs, and renewals of a minor nature are expensed as incurred. Betterments and major renewals which extend the useful lives or add to the productive capacity of buildings, improvements, and equipment are capitalized. The Company reviews its property, plant, and equipment for impairment at the asset group level whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. If an indicator is present, the Company compares carrying values to undiscounted future cash flows; if the undiscounted future cash flows are less than the carrying value, an impairment would be recognized for the difference between the fair value and the carrying value.

[0000038725-24-000038:notes:21]
The Company’s depreciation expense was $35.1 million, $33.1 million, and $30.2 million in 2023, 2022, and 2021, respectively.

[0000038725-24-000038:notes:22]
Leases--The Company determines if an arrangement is a lease, or contains a lease, at the inception of the arrangement and determines whether it is an operating or financing lease. Operating and financing leases result in the Company recording a right-of-use ("ROU") asset, current lease liability, and long term lease liability on its balance sheet. The Company has elected to not present leases with an initial term of 12 months or less on the balance sheet. The ROU assets and liabilities are initially recognized based on the present value of lease payments over the lease term. Initial direct costs and lease incentives are generally not material when measuring the ROU asset present value. Lease expense for operating lease payments is recognized on a straight-line basis over the lease term.

[0000038725-24-000038:notes:23]
In determining the present value, the Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the Company’s borrowing information available at inception. A portion of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised. In addition, the Company has elected not to separate non-lease components from lease components.

[0000038725-24-000038:notes:24]
Goodwill and Other Intangible Assets--Goodwill is tested at the reporting unit level. In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the income and market valuation approaches. The income approach estimates fair value based upon future revenue, expenses, and cash flows discounted to present value. The market valuation approach estimates fair value using market multipliers of various financial measures compared to a set of comparable public companies. The fair value calculated for each reporting unit is considered a Level 3 measurement within the fair value hierarchy. An impairment exists if the carrying value of the reporting unit is higher than its fair value. The Company will test goodwill for impairment more frequently if warranted by triggering events that indicate potential impairment. The Company completed its annual goodwill impairment test during the fourth quarter, using balances as of October 1.

[0000038725-24-000038:notes:25]
The Company also tests indefinite-lived intangible assets, primarily trade names, for impairment on an annual basis during the fourth quarter of each year, using balances as of October 1, or more frequently as warranted by triggering events that indicate potential impairment. In assessing the recoverability of the trade names, the Company determines the fair value using an income approach. The income approach estimates fair value based upon future revenue and estimated royalty rates, discounted to present value. The fair value calculated for indefinite-lived intangible assets is considered a Level 3 measurement within the fair value hierarchy. An impairment exists if the carrying value of the trade names is higher than the fair value, and the Company would record an impairment charge for the difference.

[0000038725-24-000038:notes:26]
Amortization is recorded and calculated for definite-lived intangible assets on a basis that reflects cash flows over the estimated useful lives. The estimated useful lives over which each intangible class is amortized is as follows:

[0000038725-24-000038:notes:27]
| Customer relationships | 13 - 20 years |
| Patents | 17 years |
| Technology | 15 years |
| Trade names | 5 - 20 years |
| Other | 5 - 8 years |

[0000038725-24-000038:notes:28]
Definite-lived intangible assets are evaluated for impairment whenever a triggering event, including a significant change in the use of the asset or unexpected change in financial condition, occurs that indicates the carrying value may be impaired. The Company tests for impairment at the asset group level by comparing the carrying value of an asset group that includes the applicable definite lived intangible asset(s) to that asset group's undiscounted future cash flows. An impairment exists if the carrying value of the definite-lived intangible assets is higher than the fair value, and the Company would record an impairment charge for the difference.

[0000038725-24-000038:notes:29]
Warranty Obligations--The Company provides warranties on most of its products. The warranty terms vary but are generally 2 years to 5 years from the date of manufacture or 1 year to 5 years from the date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.

[0000038725-24-000038:notes:30]
Income Taxes--Deferred tax assets and liabilities are determined based on the difference between the financial statement and tax basis of assets and liabilities and net operating loss and credit carry forwards using enacted tax rates in effect for the year in which the differences are expected to reverse. Valuation allowances are established when necessary to reduce deferred tax assets to the amounts expected to be realized. The Company records a liability for uncertain tax positions by establishing a more likely than not recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return.

[0000038725-24-000038:notes:31]
Defined Benefit Plans--The Company makes its determination for pension, post retirement, and post employment benefit plans liabilities based on management estimates and consultation with actuaries. The Company incorporates estimates and assumptions of future plan service costs, future interest costs on projected benefit obligations, rates of compensation increases, employee turnover rates, anticipated mortality rates, expected investment returns on plan assets, asset allocation assumptions of plan assets, and other factors.

[0000038725-24-000038:notes:32]
Earnings Per Common Share--The Company utilizes the two-class method to compute earnings available to common shareholders. Under the two-class method, the Company allocates net earnings to each class of common stock and participating security as if all of the net earnings for the period had been distributed. The Company’s participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders. Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period. Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards and non-employee deferred shares.

[0000038725-24-000038:notes:33]
Translation of Foreign Currency Financial Statements--All assets and liabilities of foreign subsidiaries in a functional currency other than the U.S. dollar are translated at year-end exchange rates. All revenue and expense accounts are translated at average rates in effect during the respective period. Transaction gains and losses and highly inflationary accounting adjustments are included in “Foreign exchange expense” within the Company’s consolidated statements of income, as incurred.

[0000038725-24-000038:notes:34]
In the second quarter of 2022, the Company concluded that Turkey represents a highly inflationary economy as its three-year cumulative inflation rate exceeded 100 percent. As a result, the Company started remeasuring the financial statements for the Company’s Turkish operations in accordance with the highly inflationary accounting rules in FASB ASC 830, Foreign Currency Matters, as of April 1, 2022. As a result, all gains and losses resulting from the remeasurement of the financial results of operations and other transactional foreign exchange gains and losses are reflected in earnings rather than as a component of the Company’s comprehensive income within shareholders’ equity. Additionally, the Company’s operations in Argentina have also been accounted for using the highly inflationary accounting rules since the date they were acquired in 2018.

[0000038725-24-000038:notes:35]
Significant Estimates--The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make significant estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of expenses during the reporting periods. Although the Company regularly assesses these estimates, actual results could materially differ. The Company bases its estimates on historical experience and various other assumptions that it believes to be reasonable under the circumstances.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-24-000038:notes:36]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-24-000038:notes:37]
In October 2021, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires entities to recognize and measure contracts on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. This will improve comparability after the business combination by providing consistent recognition and measurement guidance for revenue contracts with customers acquired in a business combination and revenue contracts with customers not acquired in a business combination. ASU 2021-08 is effective for interim and annual periods beginning after December 15, 2022 with early adoption permitted. ASU 2021-08 should be applied on a prospective basis to business combinations that occur after the effective date. The Company adopted this ASU on January 1, 2023, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-24-000038:notes:38]
In September 2022, the FASB issued ASU 2022-04, Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations. ASU 2022-04 creates the obligation for a company that uses a supplier finance program to purchase goods or services to disclose qualitative and quantitative information about its supplier finance program(s). This will allow financial statement users to better consider the effect of the program(s) on the entity's working capital, liquidity and cash flow over time. ASU 2022-04 is effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years, except for the amendment on rollforward information, which is effective for fiscal years beginning after December 15, 2023 with early adoption permitted. ASU 2022-04 should be applied retrospectively to each period in which a balance sheet is presented except for the amendment on rollforward information, which should be applied prospectively. The Company adopted this ASU on January 1, 2023, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows, as the Company has no amounts outstanding under its current supplier finance program.

[0000038725-24-000038:notes:39]
Accounting Standards Issued But Not Yet Adopted

[0000038725-24-000038:notes:40]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 is intended to improve reportable segment disclosure requirements, primarily through additional and more detailed information about a reportable segment's expenses. ASU 2023-07 is effective for fiscal years beginning after

[0000038725-24-000038:notes:41]
December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The guidance is to be applied retrospectively to all prior periods presented in the financial statements. The Company is still determining the date of adoption for this ASU, but does not anticipate the adoption to have a material impact on the Company's financial disclosures.

[0000038725-24-000038:notes:42]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. This amendment modifies the rules on income tax disclosures to require entities to disclose (1) specific categories in the rate reconciliation and additional information for reconciling items that meet a quantitative threshold, (2) the amount of income taxes paid (net of refunds received) (disaggregated by federal, state, and foreign taxes) as well as individual jurisdictions in which income taxes paid is equal to or greater than 5 percent of total income taxes paid net of refunds, (3) the income or loss from continuing operations before income tax expense or benefit (disaggregated between domestic and foreign) and (4) income tax expense or benefit from continuing operations (disaggregated by federal, state and foreign). ASU 2023-09 is effective for annual periods beginning after December 15, 2024, with early adoption permitted. ASU 2023-09 should be applied on a prospective basis, while retrospective application is permitted. The Company is still determining the date of adoption for this ASU, but does not anticipate the adoption to have a material impact on the Company's financial disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-24-000038:notes:43]
ACQUISITIONS
2023

[0000038725-24-000038:notes:44]
During the fourth quarter ended December 31, 2023, the Company acquired substantially all of the assets of Aqua Systems of Fort Myers, a water treatment systems distributor.  In another separate transaction, the Company acquired substantially all of the assets of Action Manufacturing and Supply, Inc., a water treatment equipment provider located in southwest Florida. The Company also acquired, in a separate transaction, substantially all of the assets of LCA Pump, LLC, which operates Water Works Pump, a Missouri based professional groundwater distributor. The combined, all-cash purchase price for the acquisitions in the fourth quarter of 2023, was $34.9 million, including contingent consideration with an estimated fair value of $3.0 million, after purchase price adjustments based on the level of working capital acquired. The fair value of the assets acquired and liabilities assumed for all acquisitions is preliminary as of December 31, 2023.

[0000038725-24-000038:notes:45]
During the first quarter ended March 31, 2023, the Company acquired substantially all of the assets of Phil-Good Products, Inc. ("Phil-Good"). Phil-Good is an injection molded plastics component manufacturer. In another separate transaction in the first quarter of 2023, the Company acquired 100 percent of the ownership interests of Hydropompe S.r.l. ("Hydropompe"). Hydropompe is a pump manufacturer with a focus in dewatering and sewage products. The combined, all-cash purchase price for both acquisitions in the first quarter of 2023 was $8.7 million after purchase price adjustments based on the level of working capital acquired. The fair value of the assets acquired and liabilities assumed for both acquisitions is preliminary as of December 31, 2023.

[0000038725-24-000038:notes:46]
The Company has not presented separate results of operations of the acquired companies since the closing of the acquisitions or combined pro forma financial information of the Company and the acquired interests since the beginning of 2022, as the results of operations for all acquisitions in 2023 are immaterial.

[0000038725-24-000038:notes:47]
2022

[0000038725-24-000038:notes:48]
During the fourth quarter ended December 31, 2022, the Company acquired 100 percent of the ownership interests of Casper Well Products ("Casper") for a purchase price of $2.0 million after working capital adjustments. Casper conducts the sale and distribution of pumps, drilling equipment, tanks, pipe, accessories and other equipment used in drilling water wells and distribution of water-related products. The fair value of the assets acquired and liabilities assumed is final as of December 31, 2023. In addition, the Company has not presented separate results of operations of the acquired company since the closing of the acquisition or combined pro forma financial information of the Company and the acquired interest since the beginning of 2021, as the results of operations for this acquisition are immaterial.

[0000038725-24-000038:notes:49]
2021

[0000038725-24-000038:notes:50]
During the fourth quarter ended December 31, 2021, the Company acquired 100 percent of the ownership interests of B&R Industries, Inc. ("B&R"), a water treatment equipment provider located in Mesa, Arizona, for a cash purchase price of $16.3 million after purchase price adjustments based on the level of working capital acquired. B&R will be included as part of the Water Systems segment of the Company. The Company also acquired, in a separate transaction, 100 percent of the ownership interests of Blake Group Holdings, Inc. ("Blake"), a professional groundwater distributor operating in the northeast United States for a cash purchase price of $28.5 million after purchase price adjustments based on the level of working capital acquired. Blake is included as part of the Distribution segment of the Company.  The fair value of the assets acquired and liabilities assumed for both acquisitions were considered final as of December 31, 2022.

[0000038725-24-000038:notes:51]
During the third quarter ended September 30, 2021, the Company acquired 100 percent of the ownership interests of Minetuff Dewatering Pumps Australia Pty Ltd ("Minetuff") for a cash purchase price of $13.7 million after purchase price adjustments based on the level of working capital acquired. Minetuff manufactures and sells submersible pumps, spare parts, and accessories to the mining industry and expands the Company’s existing product offerings and channel access in the Water Systems segment. The fair value of the assets acquired and liabilities assumed for the acquisition were considered final as of September 30, 2022.

[0000038725-24-000038:notes:52]
During the second quarter ended June 30, 2021, the Company acquired, in separate transactions, 100 percent of the ownership interests of Puronics, Inc. and its wholly owned subsidiaries ("Puronics"), headquartered in Livermore, California, and 100 percent of the ownership interests of New Aqua, LLC ("New Aqua") and its wholly owned subsidiaries, headquartered in Indianapolis, Indiana. Both Puronics and New Aqua are water treatment equipment providers and are included as a part of the Water Systems segment of the Company. In a separate transaction during the second quarter ended June 30, 2021, the Company acquired all of the assets of Power Integrity Services, LLC, a North Carolina-based company, which is included in the Fueling Systems segment of the Company.

[0000038725-24-000038:notes:53]
In another separate transaction during the quarter ended June 30, 2021, the Company acquired all of the assets of Atlantic Turbine Pump, LLC, a Georgia-based company, which is included in the Distribution segment of the Company. The Company recorded fair values that exceeded the acquisition price by $0.4 million, representing a bargain purchase gain due to favorable market conditions that was recorded within the "Other income/(expense), net" line in the consolidated statements of income for the year ended December 31, 2021.

[0000038725-24-000038:notes:54]
The combined, all-cash purchase price for all acquisitions in the second quarter of 2021 was $185.5 million after purchase price adjustments based on the level of working capital acquired. The fair value of the assets acquired and liabilities assumed for all acquisitions were considered final as of June 30, 2022.

[0000038725-24-000038:notes:55]
The identifiable intangible assets recognized in the separate transactions in 2021 were $132.1 million and consist primarily of customer relationships and trade names from New Aqua of $93.2 million. The intangible assets are being amortized using the straight-line method over 12 - 20 years.

[0000038725-24-000038:notes:56]
The goodwill of $66.0 million resulting from the acquisitions in 2021 consists primarily of expanded geographical presence and product channel expansion.  Goodwill deductible for tax purposes is $62.7 million from the acquisitions in 2021. Goodwill was recorded in the Water Systems, Fueling Systems, and Distribution segments (see Note 6 - Goodwill and Other Intangible Assets).

[0000038725-24-000038:notes:57]
The final purchase price assigned to the major identifiable assets acquired and liabilities assumed for all acquisitions in 2021 on an aggregated basis is as follows:

[0000038725-24-000038:notes:58]
| (In millions) |  |  |
| Assets: |  |  |
| Inventory |  | $ | 34.3 |  |
| Intangible assets |  | 132.1 |
| Goodwill |  | 66.0 |
| Other assets |  | 39.0 |
| Total assets |  | 271.4 |
| Liabilities |  | 27.0 |
| Less: Bargain purchase gain |  | 0.4 |
| Total consideration paid |  | $ | 244.0 |  |

[0000038725-24-000038:notes:59]
For all acquisitions in 2021, aggregated annual revenue for the full year 2020 was $191.3 million, which would be incremental to the Company's revenue had the acquisitions occurred on the first day of 2020. Since acquisition in 2021, aggregate revenue was $72.5 million for the year ended December 31, 2021. The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for all acquisitions is immaterial to the Company's consolidated financials.

[0000038725-24-000038:notes:60]
2020

[0000038725-24-000038:notes:61]
During the fourth quarter ended December 31, 2020, the Company acquired 100 percent of the ownership interests of Gicon Pumps & Equipment, Inc., a professional groundwater distributor operating seven locations in the state of Texas for a purchase price of $28.1 million after working capital adjustments. The fair value of the assets acquired and liabilities assumed exceeded the purchase price by $6.1 million, representing a bargain purchase gain. This gain was attributable to favorable market conditions and is recorded within the "Other income/(expense), net" line in the consolidated statements of income for the year ended December 31, 2021.

[0000038725-24-000038:notes:62]
Transaction costs for all acquisition-related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations. Transaction costs are included in the "Selling, general, and administrative expenses" line of the Company’s consolidated statements of income and were $0.3 million, $0.2 million, and $0.9 million for the years ended December 31, 2023, 2022, and 2021, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-24-000038:notes:63]
FAIR VALUE MEASUREMENTS
As of December 31, 2023 and December 31, 2022, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-24-000038:notes:64]
| (In millions) |  | December 31, 2023 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 10.9 |  |  | $ | 10.9 |  |  | $ | — |  |  | $ | — |  |
| Share swap transaction |  | $ | 1.1 |  |  | $ | 1.1 |  |  | $ | — |  |  | $ | — |  |
| Total assets |  | $ | 12.0 |  |  | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Contingent payments related to acquisition |  | $ | 3.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 3.0 |  |
| Total liabilities |  | $ | 3.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 3.0 |  |
|  |  | December 31, 2022 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 7.9 |  |  | $ | 7.9 |  |  | $ | — |  |  | $ | — |  |
| Total assets |  | $ | 7.9 |  |  | $ | 7.9 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Share swap transaction |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |
| Total liabilities |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |

[0000038725-24-000038:notes:65]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The share swap transaction is recorded within the "Accounts Payable" and "Receivables" lines of the consolidated balance sheets and is further described in Note 5 - Financial Instruments.

[0000038725-24-000038:notes:66]
The Company has no assets measured on a recurring basis classified as Level 2 excluding the recurring fair value measurements in the Company's pension and other retirement plans as discussed in Note 7 - Employee Benefit Plans.

[0000038725-24-000038:notes:67]
The Company's Level 3 category includes contingent consideration related to acquisitions, which valuation inputs are unobservable and significant to the fair value measurement.  Projections and estimated probabilities are used to estimate future contingent earn-out payments, which are discounted back to present value to compute contingent earn-out liabilities. The following table provides a roll-forward of the contingent consideration liability, which is included in other long-term liabilities in the consolidated balance sheets:

[0000038725-24-000038:notes:68]
| (In millions) | 2023 |
| Fair value at beginning of period | $ | — |  |
| Additions | $ | 3.0 |  |
| Change in fair value recognized in earnings | $ | — |  |
| Payments | $ | — |  |
| Fair value at end of period | $ | 3.0 |  |

[0000038725-24-000038:notes:69]
Total debt, including current maturities, have carrying amounts of $100.5 million as of December 31, 2023 and $216.1 million at December 31, 2022. The estimated fair value of all debt was $98.6 million and $213.2 million as of December 31, 2023 and December 31, 2022, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-24-000038:notes:70]
FINANCIAL INSTRUMENTS
The Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (“the swap”) to mitigate the Company’s exposure to these fluctuations in the Company’s stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party. As of December 31, 2023 and December 31, 2022, the swap had a notional value based on 240,000 shares and 225,000 shares, respectively. For the years ended December 31, 2023, December 31, 2022, and December 31, 2021, the swap resulted in a gain of $2.5 million, a loss of $3.4 million, and a gain of $6.2 million, respectively. Gains and losses resulting from the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the deferred compensation stock liability and the swap are recorded in the Company’s consolidated statements of income within the “Selling, general, and administrative expenses” line.
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of December 31, 2023, the Company had no foreign currency contracts outstanding. As of December 31, 2022, the Company had a notional amount of $10.3 million in forward currency contracts outstanding and the related fair value of those contracts was not material. For the years ended December 31, 2023 and December 31, 2022, the forward currency contracts resulted in gains of $1.6 million and $1.2 million, respectively. This is recorded in the Company's consolidated statements of income within the "Foreign exchange expense" line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-24-000038:notes:71]
GOODWILL AND OTHER INTANGIBLE ASSETS
The carrying amounts of the Company’s intangible assets are as follows:

[0000038725-24-000038:notes:72]
| (In millions) |  | 2023 |  | 2022 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 263.7 |  |  | $ | (115.5) |  |  | $ | 251.6 |  |  | $ | (101.5) |  |
| Patents |  | 7.3 |  |  | (7.3) |  |  | 7.3 |  |  | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.5) |  |  | 7.5 |  |  | (7.4) |  |
| Trade names |  | 44.1 |  |  | (5.8) |  |  | 41.8 |  |  | (3.7) |  |
| Other |  | 3.4 |  |  | (2.8) |  |  | 3.4 |  |  | (2.7) |  |
| Total |  | $ | 326.0 |  |  | $ | (138.9) |  |  | $ | 311.6 |  |  | $ | (122.6) |  |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.9 |  |  | — |  |  | 42.3 |  |  | — |  |
| Total intangibles |  | $ | 368.9 |  |  | $ | (138.9) |  |  | $ | 353.9 |  |  | $ | (122.6) |  |

[0000038725-24-000038:notes:73]
Amortization expense related to intangible assets for the years ended December 31, 2023, 2022, and 2021, was $17.1 million, $17.2 million, and $14.4 million, respectively.

[0000038725-24-000038:notes:74]
Amortization expense for each of the five succeeding years is projected as follows:

[0000038725-24-000038:notes:75]
| (In millions) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |
|  |  | $ | 18.5 |  |  | $ | 17.7 |  |  | $ | 16.7 |  |  | $ | 15.3 |  |  | $ | 14.7 |  |

[0000038725-24-000038:notes:76]
The change in the carrying amount of goodwill by reportable segment for 2023 and 2022, is as follows:

[0000038725-24-000038:notes:77]
| (In millions) |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2021 |  | $ | 213.9 |  |  | $ | 70.7 |  |  | $ | 45.0 |  |  | $ | 329.6 |  |
| Acquisitions |  | — |  |  | — |  |  | 1.2 |  |  | 1.2 |  |
| Adjustments to prior year acquisitions |  | 0.5 |  |  | — |  |  | (0.4) |  |  | 0.1 |  |
| Foreign currency translation |  | (2.5) |  |  | (0.4) |  |  | — |  |  | (2.9) |  |
| Balance as of December 31, 2022 |  | $ | 211.9 |  |  | $ | 70.3 |  |  | $ | 45.8 |  |  | $ | 328.0 |  |
| Acquisitions |  | 8.0 |  |  | — |  |  | 4.8 |  |  | 12.8 |  |
| Adjustments to prior year acquisitions |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Foreign currency translation |  | 1.4 |  |  | 0.1 |  |  | — |  |  | 1.5 |  |
| Balance as of December 31, 2023 |  | $ | 221.4 |  |  | $ | 70.4 |  |  | 50.6 |  |  | $ | 342.4 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-24-000038:notes:78]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of December 31, 2023, the Company maintained two domestic pension plans and three German pension plans. The Company used a December 31, 2023 measurement date for these plans. One of the Company’s domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees. Both domestic plans were frozen as of December 31, 2011. The two domestic and three German plans collectively comprise the ‘Pension Benefits’ disclosure caption.

[0000038725-24-000038:notes:79]
Other Benefits - The Company’s other post-retirement benefit plan provides health and life insurance to domestic employees hired prior to 1992. The Company effectively capped its cost for those benefits through plan amendments made in 1992, freezing Company contributions for insurance benefits at 1991 levels for current and future beneficiaries with actuarially reduced benefits for employees who retire before age 65. The disclosures surrounding this plan are reflected in the “Other Benefits” caption.

[0000038725-24-000038:notes:80]
The following table sets forth aggregated information related to the Company’s pension benefits and other postretirement benefits, including changes in the benefit obligations, changes in plan assets, funded status, amounts recognized in the balance sheet, amounts recognized in accumulated other comprehensive income, and actuarial assumptions that the Company considered in its determination of benefit obligations and plan costs.

[0000038725-24-000038:notes:81]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Accumulated benefit obligation, end of year |  | $ | 136.4 |  |  | $ | 133.2 |  |  | $ | 5.6 |  |  | $ | 6.0 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |  |
| Benefit obligation, beginning of year |  | $ | 135.2 |  |  | $ | 175.2 |  |  | $ | 6.0 |  |  | $ | 7.7 |  |
| Service cost |  | 0.6 |  |  | 0.7 |  |  | — |  |  | — |  |
| Interest cost |  | 6.4 |  |  | 3.3 |  |  | 0.3 |  |  | 0.1 |  |
| Actuarial (gain)/loss |  | 4.2 |  |  | (32.5) |  |  | — |  |  | (1.1) |  |
| Settlements paid |  | (0.5) |  |  | (0.3) |  |  | — |  |  | — |  |
| Benefits paid |  | (8.9) |  |  | (9.7) |  |  | (0.7) |  |  | (0.7) |  |
| Foreign currency exchange |  | 0.5 |  |  | (1.5) |  |  | — |  |  | — |  |
| Benefit obligation, end of year |  | $ | 137.5 |  |  | $ | 135.2 |  |  | $ | 5.6 |  |  | $ | 6.0 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of assets, beginning of year |  | $ | 113.4 |  |  | $ | 143.9 |  |  | $ | — |  |  | $ | — |  |
| Actual return on plan assets |  | 6.9 |  |  | (20.9) |  |  | — |  |  | — |  |
| Company contributions |  | 0.6 |  |  | 0.5 |  |  | 0.7 |  |  | 0.7 |  |
| Settlements paid |  | (0.4) |  |  | (0.3) |  |  | — |  |  | — |  |
| Benefits paid |  | (8.9) |  |  | (9.7) |  |  | (0.7) |  |  | (0.7) |  |
| Foreign currency exchange |  | 0.1 |  |  | (0.1) |  |  | — |  |  | — |  |
| Plan assets, end of year |  | $ | 111.7 |  |  | $ | 113.4 |  |  | $ | — |  |  | $ | — |  |
| Funded status |  | $ | (25.8) |  |  | $ | (21.8) |  |  | $ | (5.6) |  |  | $ | (6.0) |  |
| Amounts recognized in balance sheet: |  |  |  |  |  |  |  |  |
| Non current assets |  | $ | 4.2 |  |  | $ | 3.6 |  |  | $ | — |  |  | $ | — |  |
| Current liabilities |  | (0.5) |  |  | (0.5) |  |  | (0.7) |  |  | (0.7) |  |
| Non current liabilities |  | (29.5) |  |  | (24.9) |  |  | (4.9) |  |  | (5.3) |  |
| Net liability, end of year |  | $ | (25.8) |  |  | $ | (21.8) |  |  | $ | (5.6) |  |  | $ | (6.0) |  |
| Amount recognized in accumulated other comprehensive income/(loss): |  |  |  |  |  |  |  |  |
| Prior service cost |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net actuarial loss |  | (42.1) |  |  | (40.4) |  |  | 0.3 |  |  | 0.3 |  |
| Settlement |  | — |  |  | — |  |  | — |  |  | — |  |
| Total recognized in accumulated other comprehensive income/(loss) |  | $ | (42.1) |  |  | $ | (40.4) |  |  | $ | 0.3 |  |  | $ | 0.3 |  |

[0000038725-24-000038:notes:82]
As of December 31, 2023, the pension benefits' aggregate accumulated benefit obligation and benefit obligation in excess of plan assets was $33.3 million and $34.4 million, respectively and as of December 31, 2022, was $27.9 million and $29.8 million, respectively.  As of December 31, 2023 and December 31, 2022, the aggregate fair value of plan assets related to the accumulated benefit obligation and benefit obligation was $4.4 million and $4.4 million, respectively.

[0000038725-24-000038:notes:83]
The following table sets forth other changes in plan assets and benefit obligation recognized in other comprehensive income for 2023 and 2022:

[0000038725-24-000038:notes:84]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net actuarial (gain)/loss |  | $ | 4.4 |  |  | $ | (5.5) |  |  | $ | — |  |  | $ | (1.1) |  |
| Amortization of: |  |  |  |  |  |  |  |  |
| Net actuarial loss |  | (2.1) |  |  | (5.6) |  |  | — |  |  | (0.1) |  |
| Prior service credit |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement recognition |  | — |  |  | — |  |  | — |  |  | — |  |
| Deferred tax asset |  | (0.6) |  |  | 3.3 |  |  | — |  |  | 0.3 |  |
| Foreign currency exchange |  | — |  |  | (0.1) |  |  | — |  |  | — |  |
| Total recognized in other comprehensive income |  | $ | 1.7 |  |  | $ | (7.9) |  |  | $ | — |  |  | $ | (0.9) |  |

[0000038725-24-000038:notes:85]
The decreased discount rate is the largest contributor to the net actuarial losses affecting the benefit obligation for the defined benefit pension plans.

[0000038725-24-000038:notes:86]
Weighted-average assumptions used to determine domestic benefit obligations:

[0000038725-24-000038:notes:87]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Discount rate |  | 4.90 | % |  | 5.15 | % |  | 4.88 | % |  | 5.08 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | 2.00 - 9.00%(Graded) |  | 2.00 - 9.00%(Graded) |

[0000038725-24-000038:notes:88]
*No rate of increases in future compensation were used in the assumptions for 2023 and 2022, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation. The weighted-average interest crediting rate of the cash balance component of the domestic Pension Plan was 4.5 percent for 2023, 2022, and 2021 and is based on the approximate 30-year Treasury rate as of November of the prior year with a minimum of 4.5 percent.

[0000038725-24-000038:notes:89]
Assumptions used to determine domestic periodic benefit cost:

[0000038725-24-000038:notes:90]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  | 2021 |
| Discount rate |  | 5.14 | % |  | 2.79 | % |  | 2.41 | % |  | 5.08 | % |  | 2.57 | % |  | 2.12 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | — | % | * | 2.00 - 9.00%(Graded) |  | 2.00 - 9.00%(Graded) |  | 2.00 - 9.00%(Graded) |
| Expected long-term rate of return on plan assets |  | 5.70 | % |  | 4.50 | % |  | 4.00 | % |  | — | % |  | — | % |  | — | % |

[0000038725-24-000038:notes:91]
*No rate of increases in future compensation were used in the assumptions for 2023, 2022, and 2021, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation.

[0000038725-24-000038:notes:92]
For the years ended December 31, 2023 and December 31, 2022, the Company used the PRI-2012 aggregate mortality table, and then projected forward from 2012 using Scale MP-2021 released by the Society of Actuaries during 2021 to estimate future mortality rates based upon current data.

[0000038725-24-000038:notes:93]
The following table sets forth the aggregated net periodic benefit cost for all defined benefit plans for 2023, 2022, and 2021:

[0000038725-24-000038:notes:94]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  | 2021 |
| Service cost | $ | 0.6 |  |  | $ | 0.7 |  |  | $ | 0.7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 6.4 |  |  | 3.3 |  |  | 2.7 |  |  | 0.3 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | (7.2) |  |  | (6.1) |  |  | (5.5) |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Transition obligation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 2.1 |  |  | 5.6 |  |  | 4.3 |  |  | — |  |  | 0.1 |  |  | 0.2 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 1.9 |  |  | $ | 3.5 |  |  | $ | 2.2 |  |  | $ | 0.3 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |

[0000038725-24-000038:notes:95]
The Company consults with a third party investment manager for the assets of the funded domestic defined benefit plan. The plan assets are currently invested primarily in pooled funds, where each fund in turn is composed of mutual funds that have at least daily net asset valuations. Thus, the Company’s funded domestic defined benefit plan assets are invested in a “fund of funds” approach.

[0000038725-24-000038:notes:96]
The Company’s Board has delegated oversight and guidance to an appointed Employee Benefits Committee. The Committee has the tasks of reviewing plan performance and asset allocation, ensuring plan compliance with applicable laws, establishing plan policies, procedures, and controls, monitoring expenses, and other related activities.

[0000038725-24-000038:notes:97]
The plan’s investment policies and strategies focus on the ability to fund benefit obligations as they come due. Considerations include the plan’s current funded level, plan design, benefit payment assumptions, funding regulations, impact of potentially volatile business results on the Company’s ability to make certain levels of contributions, and interest rate and asset return volatility among other considerations. The Company currently attempts to maintain plan funded status at approximately 80 percent or greater pursuant to the Pension Protection Act of 2007. Given the plan’s current funded status, the Company’s cash on hand, cash historically generated from business operations, and cash available under committed credit facilities, the Company sees ample liquidity to achieve this goal.

[0000038725-24-000038:notes:98]
Risk management and continuous monitoring requirements are met through monthly investment portfolio reports, quarterly Employee Benefits Committee meetings, annual valuations, asset/liability studies, and the annual assumption process focusing primarily on the return on asset assumption and the discount rate assumption. As of December 31, 2023 and December 31, 2022, funds were invested in equity, fixed income, and other investments as follows:

[0000038725-24-000038:notes:99]
|  |  | Target Percentage |  | Plan Asset Allocation at Year-End |
| Asset Category |  | at Year-End 2023 |  | 2023 |  | 2022 |
| Equity securities |  | 16 | % |  | 16 | % |  | 18 | % |
| Fixed income securities |  | 79 | % |  | 79 | % |  | 78 | % |
| Other |  | 5 | % |  | 5 | % |  | 4 | % |
| Total |  | 100 | % |  | 100 | % |  | 100 | % |

[0000038725-24-000038:notes:100]
The Company does not see any particular concentration of risk within the plans, nor any plan assets that pose difficulties for fair value assessment. The Company currently has no allocation to potentially illiquid or potentially difficult to value assets such as hedge funds, venture capital, private equity, and real estate.

[0000038725-24-000038:notes:101]
The Company works with actuaries and consultants in making its determination of the asset rate of return assumption and also the discount rate assumption.

[0000038725-24-000038:notes:102]
Asset class assumptions are set using a combination of empirical and forward-looking analysis for long-term rate of return on plan assets. A variety of models are applied for filtering historical data and isolating the fundamental characteristics of asset classes. These models provide empirical return estimates for each asset class, which are then reviewed and combined with a qualitative assessment of long-term relationships between asset classes before a return estimate is finalized. This provides an

[0000038725-24-000038:notes:103]
additional means for correcting for the effect of unrealistic or unsustainable short-term valuations or trends, opting instead for return levels and behavior that are more likely to prevail over long periods. With that, the Company has assumed an expected long-term rate of return on plan assets of 6.20 percent for the 2024 net periodic benefit cost, up from 5.70 percent in the prior year.

[0000038725-24-000038:notes:104]
The Company uses the Aon Hewitt AA Above Median curve to determine the discount rate. All cash flow obligations under the plan are matched to bonds in the Aon Hewitt universe of liquid, high-quality, non-callable / non-puttable corporate bonds with outliers removed. From that matching exercise, a discount rate is determined.

[0000038725-24-000038:notes:105]
The Company’s German pension plans are funded by insurance contract policies whereby the insurance company guarantees a fixed minimum return. Due to tax legislation, individual pension benefits can only be financed using direct insurance policies up to certain maximums. These maximum amounts in respect of each member are paid into such an arrangement on a yearly basis.

[0000038725-24-000038:notes:106]
The Company designated all equity and most domestic fixed income plan assets as Level 1, as they are mutual funds with prices that are readily available. The U.S. Treasury securities and German plan assets are designated as Level 2 inputs. The fair value of the German plan assets are measured by the reserve that is supervised by the German Federal Financial Supervisory Authority. The U.S. Treasury securities are administered by the United States government.

[0000038725-24-000038:notes:107]
The fair values of the Company’s pension plan assets for 2023 and 2022 by asset category are as follows:

[0000038725-24-000038:notes:108]
| (In millions) |  | 2023 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| International equity mutual funds |  | $ | 18.3 |  |  | $ | 18.3 |  |  | $ | — |  |  | $ | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 12.3 |  |  | — |  |  | 12.3 |  |  | — |  |
| Fixed income mutual funds |  | 76.0 |  |  | 76.0 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.4 |  |  | — |  |  | 4.4 |  |  | — |  |
| Cash and equivalents |  | 0.7 |  |  | 0.7 |  |  | — |  |  | — |  |
| Total |  | $ | 111.7 |  |  | $ | 95.0 |  |  | $ | 16.7 |  |  | $ | — |  |

[0000038725-24-000038:notes:109]
| (In millions) |  | 2022 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| International equity mutual funds |  | $ | 20.1 |  |  | $ | 20.1 |  |  | $ | — |  |  | $ | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 19.2 |  |  | — |  |  | 19.2 |  |  | — |  |
| Fixed income mutual funds |  | 69.0 |  |  | 69.0 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.4 |  |  | — |  |  | 4.4 |  |  | — |  |
| Cash and equivalents |  | 0.7 |  |  | 0.7 |  |  | — |  |  | — |  |
| Total |  | $ | 113.4 |  |  | $ | 89.8 |  |  | $ | 23.6 |  |  | $ | — |  |

[0000038725-24-000038:notes:110]
The Company estimates total contributions to the plans of about $0.8 million in 2024.

[0000038725-24-000038:notes:111]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid in accordance with the following schedule:

[0000038725-24-000038:notes:112]
| (In millions) |  | Pension Benefits |  | Other Benefits |
| 2024 |  | $ | 10.0 |  |  | $ | 0.6 |  |
| 2025 |  | $ | 9.9 |  |  | $ | 0.6 |  |
| 2026 |  | $ | 15.6 |  |  | $ | 0.6 |  |
| 2027 |  | $ | 15.3 |  |  | $ | 0.6 |  |
| 2028 |  | $ | 14.5 |  |  | $ | 0.5 |  |
| Years 2029 through 2033 |  | $ | 43.5 |  |  | $ | 2.2 |  |

[0000038725-24-000038:notes:113]
Defined Contribution Plans - The Company maintained two defined contribution plans during 2023, 2022, and 2021. The Company’s cash contributions are allocated to participant’s accounts based on investment elections.

[0000038725-24-000038:notes:114]
The following table sets forth Company contributions to the defined contribution plans:

[0000038725-24-000038:notes:115]
| (In millions) |  | 2023 |  | 2022 |  | 2021 |
| Company contributions to the plans |  | $ | 11.5 |  |  | $ | 11.4 |  |  | $ | 8.9 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000038725-24-000038:notes:116]
ACCRUED EXPENSES AND OTHER CURRENT LIABILITIES
Accrued expenses and other current liabilities consist of:

[0000038725-24-000038:notes:117]
| (In millions) |  | 2023 |  | 2022 |
| Salaries, wages, and commissions |  | $ | 45.9 |  |  | $ | 57.9 |  |
| Product warranty costs |  | 9.3 |  |  | 11.2 |  |
| Insurance |  | 2.5 |  |  | 1.7 |  |
| Employee benefits |  | 13.8 |  |  | 13.5 |  |
| Other |  | 28.7 |  |  | 36.3 |  |
|  |  | $ | 100.2 |  |  | $ | 120.6 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-24-000038:notes:118]
INCOME TAXES
Income before income taxes consisted of the following:

[0000038725-24-000038:notes:119]
| (In millions) |  | 2023 |  | 2022 |  | 2021 |
| Domestic |  | $ | 163.9 |  |  | $ | 157.6 |  |  | $ | 113.1 |  |
| Foreign |  | 78.3 |  |  | 77.6 |  |  | 76.6 |  |
|  |  | $ | 242.2 |  |  | $ | 235.2 |  |  | $ | 189.7 |  |

[0000038725-24-000038:notes:120]
The income tax provision/(benefit) consisted of the following:

[0000038725-24-000038:notes:121]
| (In millions) |  | 2023 |  | 2022 |  | 2021 |
| Current: |  |  |  |  |  |  |
| Federal |  | $ | 27.0 |  |  | $ | 25.3 |  |  | $ | 15.9 |  |
| Foreign |  | 14.9 |  |  | 15.3 |  |  | 15.7 |  |
| State |  | 7.2 |  |  | 7.0 |  |  | 3.0 |  |
| Total current |  | 49.1 |  |  | 47.6 |  |  | 34.6 |  |
| Deferred: |  |  |  |  |  |  |
| Federal |  | (1.1) |  |  | (0.1) |  |  | (0.7) |  |
| Foreign |  | (0.3) |  |  | (2.6) |  |  | (0.1) |  |
| State |  | (0.2) |  |  | 1.5 |  |  | 0.9 |  |
| Total deferred |  | $ | (1.6) |  |  | $ | (1.2) |  |  | $ | 0.1 |  |
|  |  | $ | 47.5 |  |  | $ | 46.4 |  |  | $ | 34.7 |  |

[0000038725-24-000038:notes:122]
A reconciliation of the tax provision at the U.S. statutory rate to the effective income tax expense rate as reported is as follows:

[0000038725-24-000038:notes:123]
|  |  | 2023 |  | 2022 |  | 2021 |
| U.S. Federal statutory rate |  | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income taxes, net of federal benefit |  | 2.3 |  |  | 2.9 |  |  | 1.7 |  |
| Foreign operations |  | (0.7) |  |  | (0.5) |  |  | 0.2 |  |
| R&D tax credits |  | (0.4) |  |  | (0.4) |  |  | (0.5) |  |
| Uncertain tax position adjustments |  | (0.1) |  |  | 0.1 |  |  | 0.2 |  |
| Valuation allowance on state and foreign deferred tax |  | (0.2) |  |  | (0.6) |  |  | (0.6) |  |
| Share-based compensation |  | (1.0) |  |  | (0.7) |  |  | (2.3) |  |
| Other items |  | (0.1) |  |  | (0.5) |  |  | (0.6) |  |
| Foreign Derived Intangible Income |  | (2.4) |  |  | (2.6) |  |  | (1.9) |  |
| Nondeductible officers compensation |  | 1.2 |  |  | 1.0 |  |  | 1.1 |  |
| Effective tax rate |  | 19.6 | % |  | 19.7 | % |  | 18.3 | % |

[0000038725-24-000038:notes:124]
The effective tax rate continues to be lower than the statutory rate of 21 percent primarily due to the recognition of the U.S. foreign-derived intangible income (FDII) provisions, foreign earnings taxed at rates below the U.S. statutory rate, certain incentives, and discrete events partially offset by state taxes.

[0000038725-24-000038:notes:125]
The Company recorded discrete excess tax benefits from share-based compensation of $3.2 million in the year ended December 31, 2023.

[0000038725-24-000038:notes:126]
Significant components of the Company’s deferred tax assets and liabilities were as follows:

[0000038725-24-000038:notes:127]
| (In millions) |  | 2023 |  | 2022 |
| Deferred tax assets: |  |  |  |  |
| Accrued expenses and reserves |  | $ | 15.1 |  |  | $ | 14.9 |  |
| Compensation and employee benefits |  | 17.4 |  |  | 15.6 |  |
| Net operating losses, tax credit carryforwards, and other |  | 13.2 |  |  | 14.0 |  |
| Lease liability |  | 14.7 |  |  | 12.6 |  |
| Research and development expenditures |  | 7.0 |  |  | 3.3 |  |
| Valuation allowance on state and foreign deferred tax |  | (4.1) |  |  | (4.9) |  |
| Other items |  | 0.1 |  |  | — |  |
| Total deferred tax assets |  | 63.4 |  |  | 55.5 |  |
| Deferred tax liabilities: |  |  |  |  |
| Accelerated depreciation on fixed assets |  | 17.7 |  |  | 14.5 |  |
| Amortization of intangibles |  | 51.3 |  |  | 51.1 |  |
| Lease right-of-use asset, net |  | 14.7 |  |  | 12.6 |  |
| Other items |  | 0.4 |  |  | 0.3 |  |
| Total deferred tax liabilities |  | 84.1 |  |  | 78.5 |  |
| Net deferred tax liabilities |  | $ | (20.7) |  |  | $ | (23.0) |  |

[0000038725-24-000038:notes:128]
The Company assesses the available positive and negative evidence to estimate whether sufficient future taxable income will be generated to permit use of the existing deferred tax assets. A significant piece of objective negative evidence evaluated was the cumulative loss for certain state and foreign income tax purposes incurred over the 3-year period ended December 31, 2023. Such objective evidence limits the ability to consider other subjective evidence, such as the Company's projections for future growth.

[0000038725-24-000038:notes:129]
On the basis of this evaluation, as of December 31, 2023, a valuation allowance of $4.1 million has been recorded to recognize only the portion of the deferred tax assets that are more likely than not to be realized. The Company has foreign income tax net operating loss (“NOL”) and credit carryforwards of $8.6 million and state income tax NOL and credit carryforwards of $4.6 million, which will expire on various dates as follows:

[0000038725-24-000038:notes:130]
| (In millions) |  |
| 2024 | $ | 0.5 |  |
| 2025-2029 | 3.7 |  |
| 2030-2034 | 0.3 |  |
| 2035-2039 | 0.7 |  |
| Unlimited | 8.0 |  |
|  | $ | 13.2 |  |

[0000038725-24-000038:notes:131]
The Company believes that it is more likely than not that the benefit from certain foreign NOL carryforwards as well as certain state credit carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance of $2.7 million on the deferred tax assets related to these foreign NOL carryforwards and a valuation allowance of $1.4 million on the deferred tax assets related to these state credit carryforwards.

[0000038725-24-000038:notes:132]
As of December 31, 2023, the Company has estimated accumulated undistributed earnings generated by the Company's foreign subsidiaries of approximately $315.8 million. Any taxes due with respect to such earnings or the excess of the amount for financial reporting over the tax basis of its foreign investments would generally be limited to foreign and state taxes. The Company intends, however, to indefinitely reinvest these earnings and expects future U.S. cash generation to be sufficient to meet future U.S. cash needs. The Company, therefore, has not recorded a deferred tax liability of approximately $6.1 million.

[0000038725-24-000038:notes:133]
As of the beginning of 2023, the Company had gross unrecognized tax benefits of $0.9 million, excluding accrued interest and penalties. The unrecognized tax benefits decreased due to statute expirations, which were offset by uncertain tax positions identified in the current year based on evaluations made during 2023. The Company had gross unrecognized tax benefits, excluding accrued interest and penalties, of $0.8 million as of December 31, 2023.

[0000038725-24-000038:notes:134]
A reconciliation of the beginning and ending amount of gross unrecognized tax benefits for 2023, 2022, and 2021 (excluding interest and penalties) is as follows:

[0000038725-24-000038:notes:135]
| (In millions) |  | 2023 |  | 2022 |  | 2021 |
| Beginning balance |  | $ | 0.9 |  |  | $ | 0.9 |  |  | $ | 0.6 |  |
| Additions for tax positions of the current year |  | 0.3 |  |  | 0.1 |  |  | 0.3 |  |
| Additions for tax positions of prior years |  | — |  |  | — |  |  | — |  |
| Reductions for tax positions of prior years |  | — |  |  | — |  |  | — |  |
| Statute expirations |  | (0.4) |  |  | (0.1) |  |  | — |  |
| Settlements |  | — |  |  | — |  |  | — |  |
| Ending balance |  | $ | 0.8 |  |  | $ | 0.9 |  |  | $ | 0.9 |  |

[0000038725-24-000038:notes:136]
If recognized, each annual effective tax rate would be affected by the net unrecognized tax benefits of $0.8 million, $0.9 million, and $0.9 million as of year-end 2023, 2022, and 2021, respectively.

[0000038725-24-000038:notes:137]
The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense. The Company has accrued interest and penalties as of December 31, 2023, December 31, 2022, and December 31, 2021 of approximately $0.1 million, $0.2 million, and $0.1 million, respectively.

[0000038725-24-000038:notes:138]
The Company is subject to taxation in the United States and various state and foreign jurisdictions. With few exceptions, as of December 31, 2023, the Company is no longer subject to U.S. federal income tax examinations by tax authorities for years before 2020 and is no longer subject to foreign or state income tax examinations by tax authorities for years before 2018.
It is reasonably possible that the amounts of unrecognized tax benefits could change in the next twelve months as a result of an audit or due to the expiration of a statute of limitation. Based on the current audits in process and pending statute expirations, the payment of taxes as a result could be up to $0.4 million.


## us-gaap:DebtDisclosureTextBlock

[0000038725-24-000038:notes:139]
DEBT
Debt consisted of the following:

[0000038725-24-000038:notes:140]
| (In millions) |  | 2023 |  | 2022 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 11.0 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.1 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 0.5 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | 100.5 |  |  | 216.1 |  |
| Less current maturities |  | (12.4) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.1 |  |  | $ | 89.3 |  |

[0000038725-24-000038:notes:141]
Debt outstanding at December 31, 2023, excluding unamortized debt issuance costs, matures as follows:

[0000038725-24-000038:notes:142]
| (In millions) |  | Total |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |
| Debt |  | $ | 100.6 |  |  | $ | 12.4 |  |  | $ | 76.5 |  |  | $ | 1.6 |  |  | $ | 1.4 |  |  | $ | 1.4 |  |  | $ | 7.3 |  |

[0000038725-24-000038:notes:143]
New York Life Agreement

[0000038725-24-000038:notes:144]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the “New York Life Agreement”) for $150.0 million maximum aggregate principal borrowing capacity. On October 28, 2016, the Company entered into the First Amendment to the Note Purchase and Private Shelf Agreement. The Amendment was intended to make the covenants within the New York Life Agreement consistent with the covenants that were modified in the Third Amended and Restated Credit Agreement (the “Credit Agreement”). On September 26, 2018, the Company entered into the Second Amendment to the Note Purchase and Private Shelf Agreement which increased the aggregate borrowing capacity to $200.0 million and authorized the issuance of $75.0 million of fixed rate senior noted due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable rate indebtedness with New York Life. On July 30, 2021, the New York Life agreement was renewed and expires on July 30, 2024. As of December 31, 2023, there was $125.0 million of remaining borrowing capacity under the New York Life Agreement.

[0000038725-24-000038:notes:145]
Project Bonds

[0000038725-24-000038:notes:146]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).” The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (“Tax increment financing debt”) bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033. The use of the proceeds from the Project Notes was limited to assist the financing of the new Global Corporate Headquarters and Engineering Center. On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement. This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-24-000038:notes:147]
Prudential Agreement

[0000038725-24-000038:notes:148]
On April 9, 2007, the Company entered into the Amended and Restated Note Purchase and Private Shelf Agreement (the “Prudential Agreement”) in the amount of $175.0 million. Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”). The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had, at issuance, an average life of 10 years with a final maturity in 2019. On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million. On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Agreement. On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to

[0000038725-24-000038:notes:149]
extend the effective date to December 31, 2015. On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement. This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees. On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million. On October 28, 2016, the Company entered into Amendment No. 1 to the Third Amended and Restated Note Purchase and Private Shelf Agreement. This amendment was intended to make the covenants within the Prudential Agreement consistent with the covenants that were modified in the Credit Agreement (below). On July 30, 2021, the Company entered into the Fourth Amended and Restated Note Purchase and Private Shelf Agreement, which reduced the borrowing capacity to $150.0 million and expires on July 30, 2024. As of December 31, 2023, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-24-000038:notes:150]
Credit Agreement

[0000038725-24-000038:notes:151]
On May 13, 2021, the Company entered into the Fourth Amended and Restated Credit Agreement (the “Credit Agreement”). The Credit Agreement extended the maturity date of the Company’s previous credit agreement to May 13, 2026, and decreased the commitment amount from $300.0 million to $250.0 million. On May 11, 2022, the Company entered into Amendment No. 1 that increased the commitment amount from $250.0 million to $350.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million (not to exceed a total commitment of $475.0 million) subject to the conditions contained therein. All of the Company’s present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers’ obligations under and in connection with the Credit Agreement. Additionally, the Company unconditionally guaranties all of the obligations of Franklin Electric B.V. under the Credit Agreement. Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100 percent to 0.275 percent (depending on the Company’s leverage ratio) of the aggregate commitment, payable quarterly in arrears. USD loans may be made either at (i) a Secured Overnight Financing Rate (SOFR) Term Benchmark, with a zero percent floor, plus an applicable margin of 0.950 percent to 1.975 percent (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement. EUR loans may be made in Euro Interbank Offer Rate (EURIBOR) Term Benchmark, with a zero percent floor, plus an applicable margin of 0.850 percent to 1.875 percent (depending on the Company’s leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-24-000038:notes:152]
As of December 31, 2023, the Company had $11.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $335.4 million of available capacity under the Credit Agreement. As of December 31, 2022, the Company had $122.8 million outstanding borrowings with a weighted average interest rate of 5.0 percent, $4.0 million in letters of credit outstanding, and $223.2 million of available capacity under the Credit Agreement.

[0000038725-24-000038:notes:153]
The Company also has lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $17.9 million. As of December 31, 2023, there were no outstanding borrowings and $17.9 million of available capacity under these lines of credit. As of December 31, 2022, there were $22.0 million overdraft lines of credit with $2.7 million outstanding borrowings and $19.3 million of available capacity under these lines of credit.

[0000038725-24-000038:notes:154]
Covenants
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Credit Agreement, the Prudential Agreement, the Project Bonds, and the New York Life Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of December 31, 2023.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-24-000038:notes:155]
SHAREHOLDERS’ EQUITY
Authorized Shares

[0000038725-24-000038:notes:156]
The Company has the authority to issue 65,000,000, $.10 par value common shares.

[0000038725-24-000038:notes:157]
The Company also has the authority to issue 100,000 preference shares with no par value and 5,000,000 preferred shares with no par value.  No preference or preferred shares have been issued.

[0000038725-24-000038:notes:158]
Share Repurchases

[0000038725-24-000038:notes:159]
During 2023, 2022, and 2021, pursuant to a stock repurchase program authorized by the Company’s Board of Directors, the Company repurchased and retired the following amounts and number of shares:

[0000038725-24-000038:notes:160]
| (In millions, except share amounts) |  | 2023 |  | 2022 |  | 2021 |
| Repurchases |  | $ | 32.5 |  |  | $ | 36.3 |  |  | $ | 15.3 |  |
| Shares |  | 371,452 |  |  | 453,207 |  |  | 192,509 |  |

[0000038725-24-000038:notes:161]
The Company retired shares in the amount of 101,690, 63,133, and 126,332 in 2023, 2022, and 2021, respectively, that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards. The Company also retired shares in the amount of 0, 16,839, and 2,511, in 2023, 2022, and 2021, respectively, that had been previously granted as stock awards to employees but were forfeited upon not meeting the required restriction criteria or termination.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-24-000038:notes:162]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss), net of tax, by component are summarized below:

[0000038725-24-000038:notes:163]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance, December 31, 2020 | $ | (152.2) |  |  | $ | (52.6) |  |  | $ | (204.8) |  |
| Other comprehensive income/(loss) before reclassifications | (27.4) |  |  | — |  |  | (27.4) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1)(2) | — |  |  | 3.6 |  |  | 3.6 |  |
| Net other comprehensive income/(loss) | (27.4) |  |  | 3.6 |  |  | (23.8) |  |
| Balance, December 31, 2021 | $ | (179.6) |  |  | $ | (49.0) |  |  | $ | (228.6) |  |
| Other comprehensive income/(loss) before reclassifications(1) | (11.7) |  |  | 4.9 |  |  | (6.8) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (2)(3) | — |  |  | 4.0 |  |  | 4.0 |  |
| Net other comprehensive income/(loss) | (11.7) |  |  | 8.9 |  |  | (2.8) |  |
| Balance, December 31, 2022 | $ | (191.3) |  |  | $ | (40.1) |  |  | $ | (231.4) |  |
| Other comprehensive income/(loss) before reclassifications(1) | 12.0 |  |  | (3.3) |  |  | 8.7 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (2)(3) | — |  |  | 1.6 |  |  | 1.6 |  |
| Net other comprehensive income/(loss) | 12.0 |  |  | (1.7) |  |  | 10.3 |  |
| Balance, December 31, 2023 | $ | (179.3) |  |  | $ | (41.8) |  |  | $ | (221.1) |  |

[0000038725-24-000038:notes:164]
(1) Net of tax (benefit)/expense of $(1.1) million and  $1.8 million for 2023 and 2022, respectively.

[0000038725-24-000038:notes:165]
(2) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 7 - Employee Benefit Plans for additional details) and is included in the “Other income/(expense), net” line of the Company’s consolidated statements of income.

[0000038725-24-000038:notes:166]
(3) Net of tax expense of $0.5 million, $1.8 million and $1.5 million for 2023, 2022, and 2021, respectively.
Amounts related to noncontrolling interests were not material.


## us-gaap:EarningsPerShareTextBlock

[0000038725-24-000038:notes:167]
EARNINGS PER SHARE
The Company calculates basic and diluted earnings per common share using the two-class method. Under the two-class method, net earnings are allocated to each class of common stock and participating security as if all of the net earnings for the period had been distributed. The Company’s participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.

[0000038725-24-000038:notes:168]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period. Diluted earnings per common share is calculated by

[0000038725-24-000038:notes:169]
dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-24-000038:notes:170]
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-24-000038:notes:171]
| (In millions, except per share amounts) |  | 2023 |  | 2022 |  | 2021 |
| Numerator: |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. |  | $ | 193.3 |  |  | $ | 187.3 |  |  | $ | 153.9 |  |
| Less: Earnings allocated to participating securities |  | 0.7 |  |  | 0.7 |  |  | 0.9 |  |
| Net income available to common shareholders |  | $ | 192.6 |  |  | $ | 186.6 |  |  | $ | 153.0 |  |
| Denominator: |  |  |  |  |  |  |
| Basic weighted average common shares outstanding |  | 46.2 |  |  | 46.3 |  |  | 46.4 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors |  | 0.7 |  |  | 0.7 |  |  | 0.6 |  |
| Diluted weighted average common shares outstanding |  | 46.9 |  |  | 47.0 |  |  | 47.0 |  |
| Basic earnings per share |  | $ | 4.17 |  |  | $ | 4.02 |  |  | $ | 3.29 |  |
| Diluted earnings per share |  | $ | 4.11 |  |  | $ | 3.97 |  |  | $ | 3.25 |  |

[0000038725-24-000038:notes:172]
There were 0.1 million stock options outstanding as of 2023, 2022, and 2021, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-24-000038:notes:173]
SHARE-BASED COMPENSATION
In 2023, the Company amended The Franklin Electric Co., Inc. 2017 Stock Plan, which is called The Franklin Electric Co., Inc. Amended and Restated 2017 Stock Plan ("the 2017 Amended and Restated Stock Plan") and increased the number of shares available under the Plan by 900,000 to 2,300,000. The 2017 Amended and Restated Stock Plan is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, stock unit awards, and stock appreciation rights (“SARs”) to key employees and non-employee directors. Stock options and SARs reduce the number of available shares by one share for each share subject to the option or SAR, and stock awards and stock unit awards settled in shares reduce the number of available shares by 1.5 shares for every one share delivered.

[0000038725-24-000038:notes:174]
The Company also maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the “2012 Stock Plan”), which is a share-based compensation plan that provides for discretionary grants of stock options, stock awards and stock unit awards to key employees and non-employee directors.

[0000038725-24-000038:notes:175]
The 2012 Stock Plan authorized 2,400,000 shares for issuance as follows:

[0000038725-24-000038:notes:176]
| 2012 Stock Plan |  | Authorized Shares |
| Stock Options |  | 1,680,000 |
| Stock/Stock Unit Awards |  | 720,000 |

[0000038725-24-000038:notes:177]
No additional options and awards are granted out of the 2012 Stock Plan. However, there are still unvested awards and unexercised options under this plan.

[0000038725-24-000038:notes:178]
The Company currently issues new shares from its common stock balance to satisfy option exercises and the settlement of stock awards and stock unit awards made under the outstanding stock plans.

[0000038725-24-000038:notes:179]
The Company recognizes share-based compensation expense only for the portion of shares that it expects to vest. As such, an estimated forfeiture rate is applied to calculate the share-based compensation expense, which is based on historical forfeiture data. The total share-based compensation expense recognized in 2023, 2022, and 2021 was $10.1 million, $11.0 million, and $11.7 million, respectively. The tax benefit recognized in 2023, 2022, and 2021 was $5.6 million, $4.7 million, and $7.8 million. Included in the benefit in 2023, 2022, and 2021 were excess tax benefits on share-based compensation of $3.2 million,  $2.1 million, and $5.0 million, respectively.

[0000038725-24-000038:notes:180]
Stock Options:

[0000038725-24-000038:notes:181]
Under the above plans, the exercise price of each option equals the market price of the Company’s common stock on the date of grant, and the options expire 10 years after the date of the grant. Options vest at 33 percent a year and become fully vested and fully exercisable after 3 years. Vesting is accelerated upon retirement, death or disability. Subject to the terms of the plans, in general, the aggregate option exercise price and any applicable tax withholding may be satisfied in cash or its equivalent, by the plan participant’s delivery of shares of the Company’s common stock having a fair market value at the time of exercise equal to the aggregate option exercise price and/or the applicable tax withholding or by having shares otherwise subject to the award withheld by the Company or via cashless exercise through a broker-dealer.

[0000038725-24-000038:notes:182]
The fair value of each option award is estimated on the date of grant using the Black-Scholes option valuation model with a single approach and amortized using a straight-line attribution method over the option’s vesting period. Options granted to retirement eligible employees are immediately expensed. The Company uses historical data to estimate the expected volatility of its stock, the weighted average expected life, the period of time options granted are expected to be outstanding, and its dividend yield. The risk-free rates for periods within the contractual life of the option are based on the U.S. Treasury yield curve in effect at the time of the grant.

[0000038725-24-000038:notes:183]
The table below provides the weighted average grant-date fair values and key assumptions used for the Black-Scholes model to determine the fair value of options granted during 2023, 2022, and 2021:

[0000038725-24-000038:notes:184]
|  |  | 2023 |  | 2022 |  | 2021 |
| Risk-free interest rate |  | 4.02 | % |  | 1.87 | % |  | 0.66 | % |
| Dividend yield |  | 0.95 | % |  | 0.93 | % |  | 0.96 | % |
| Volatility factor |  | 33.81 | % |  | 33.88 | % |  | 34.98 | % |
| Expected term |  | 6.0 years |  | 5.5 years |  | 5.5 years |
| Weighted average grant-date fair value of options |  | $ | 34.51 |  |  | $ | 26.05 |  |  | $ | 21.70 |  |

[0000038725-24-000038:notes:185]
A summary of the Company’s outstanding stock option activity and related information is as follows:

[0000038725-24-000038:notes:186]
| (Shares in thousands) |  | Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | AggregateIntrinsic Value (000’s) |
| Stock Options |  |  |  |  |
| Outstanding at beginning of 2023 |  | 1,040 |  |  | $ | 52.91 |  |  |  |  |  |
| Granted |  | 77 |  |  | 94.87 |  |  |  |  |  |
| Exercised |  | (216) |  |  | 42.54 |  |  |  |  |  |
| Forfeited |  | (1) |  |  | 84.78 |  |  |  |  |  |
| Expired |  | — |  |  | — |  |  |  |  |  |
| Outstanding at end of 2023 |  | 900 |  |  | $ | 58.96 |  |  | 4.97 years |  | $ | 33,933 |  |
| Expected to vest after applying forfeiture rate |  | 899 |  |  | $ | 58.91 |  |  | 4.97 years |  | $ | 33,924 |  |
| Vested and exercisable at end of period |  | 736 |  |  | $ | 52.86 |  |  | 4.22 years |  | $ | 32,238 |  |

[0000038725-24-000038:notes:187]
| (In millions) |  | 2023 |  | 2022 |  | 2021 |
| Intrinsic value of options exercised |  | $ | 11.6 |  |  | $ | 3.7 |  |  | $ | 20.7 |  |
| Cash received from the exercise of options |  | 9.2 |  |  | 3.9 |  |  | 15.5 |  |
| Fair value of shares vested |  | 3.1 |  |  | 3.1 |  |  | 3.9 |  |
| Tax benefit of options exercised |  | 2.9 |  |  | 0.9 |  |  | 5.1 |  |

[0000038725-24-000038:notes:188]
As of December 31, 2023, there was $0.9 million of total unrecognized compensation cost related to non-vested stock options granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.28 years.

[0000038725-24-000038:notes:189]
Stock/Stock Unit Awards:

[0000038725-24-000038:notes:190]
Under the 2017 Stock Plan, non-employee directors and employees may be granted stock awards and stock units. Stock awards to non-employee directors are generally fully vested when made. Stock/stock unit awards to employees cliff vest over 3 years (subject to accelerated vesting of a pro rata portion in the case of retirement, death or disability) and may be contingent on the attainment of certain performance goals. Dividends are paid to the recipient prior to vesting, except that dividends on

[0000038725-24-000038:notes:191]
performance-based stock awards under the 2012 Stock Plan and the 2017 Stock Plan will be paid only to the extent the performance goals are met.

[0000038725-24-000038:notes:192]
Stock/stock unit awards granted to retirement eligible employees are expensed over the vesting period. Compensation cost for the performance stock/stock unit awards is accrued based on the probable outcome of specified performance conditions.

[0000038725-24-000038:notes:193]
A summary of the Company’s restricted stock/stock unit award activity and related information is as follows:

[0000038725-24-000038:notes:194]
| (Shares in thousands) |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Restricted Stock/Stock Unit Awards |  |  |
| Non-vested at beginning of 2023 |  | 264 |  |  | $ | 72.90 |  |
| Awarded |  | 138 |  |  | 87.31 |  |
| Vested |  | (128) |  |  | 62.16 |  |
| Forfeited |  | (15) |  |  | 87.30 |  |
| Non-vested at end of 2023 |  | 259 |  |  | $ | 85.05 |  |

[0000038725-24-000038:notes:195]
The weighted-average grant date fair value of restricted stock/stock unit awards granted in 2023, 2022, and 2021, is $87.31, $81.16, and $74.23, respectively. The fair value of restricted stock/stock unit awards that vested in 2023, 2022, and 2021, was $8.0 million, $9.1 million, and $6.1 million, respectively.

[0000038725-24-000038:notes:196]
As of December 31, 2023, there was $8.7 million of total unrecognized compensation cost related to non-vested stock/stock unit awards granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.32 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-24-000038:notes:197]
SEGMENT AND GEOGRAPHIC INFORMATION
The Company’s business consists of the Water Systems, Distribution, and Fueling Systems reportable segments, based on the principal end market served. The Company includes unallocated corporate expenses and intercompany eliminations in an “Intersegment Eliminations/Other” segment that together with the Water Systems, Distribution, and Fueling Systems segments, represent the Company.

[0000038725-24-000038:notes:198]
The Water Systems segment designs, manufactures and sells motors, pumps, electronic controls, water treatment systems and related parts and equipment primarily for use in submersible water or other fluid system applications. The Fueling Systems segment designs, manufactures and sells pumps, electronic controls and related parts and equipment primarily for use in submersible fueling system applications. The Fueling Systems segment integrates and sells motors and electronic controls produced by the Water Systems segment. The Company reports these product transfers between Water and Fueling as inventory transfers since a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes. The Distribution segment sells to and provides presale support and specifications to the installing contractors. The Distribution segment sells products produced by the Water Systems segment. The Company reports intersegment transfers from Water Systems to Distribution as intersegment revenue at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water Systems and Distribution segments.

[0000038725-24-000038:notes:199]
Segment operating income is a key financial performance measure. Operating income by segment is based on net sales less identifiable operating expenses and allocations and includes profits recorded on sales to other segments of the Company.

[0000038725-24-000038:notes:200]
The accounting policies of the Company’s reportable segments are the same as those described in Note 1 - Summary of Significant Accounting Policies. Performance is evaluated based on the sales and operating income of the segments and a variety of ratios to measure performance. These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented.

[0000038725-24-000038:notes:201]
Financial information by reportable business segment is included in the following summary:

[0000038725-24-000038:notes:202]
| Net Sales |
| (In millions) | 2023 |  | 2022 |  | 2021 |
| Water Systems |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | $ | 636.0 |  |  | $ | 596.9 |  |  | $ | 460.8 |  |
| Latin America | 174.2 |  |  | 159.3 |  |  | 139.5 |  |
| Europe, Middle East & Africa | 198.3 |  |  | 192.8 |  |  | 189.8 |  |
| Asia Pacific | 86.8 |  |  | 92.5 |  |  | 85.1 |  |
| Intersegment sales |  |  |  |  |  |
| United States & Canada | 108.4 |  |  | 116.0 |  |  | 88.4 |  |
| Total sales | 1,203.7 |  |  | 1,157.5 |  |  | 963.6 |  |
| Distribution |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 673.3 |  |  | 668.1 |  |  | 497.6 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |
| Total sales | 673.3 |  |  | 668.1 |  |  | 497.6 |  |
| Fueling Systems |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 220.9 |  |  | 242.6 |  |  | 198.5 |  |
| All other | 75.6 |  |  | 91.5 |  |  | 90.6 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |
| Total Sales | 296.5 |  |  | 334.1 |  |  | 289.1 |  |
| Intersegment Eliminations/Other | (108.4) |  |  | (116.0) |  |  | (88.4) |  |
| Consolidated | $ | 2,065.1 |  |  | $ | 2,043.7 |  |  | $ | 1,661.9 |  |
| Operating income (loss) |
|  | 2023 |  | 2022 |  | 2021 |
| Water Systems | $ | 196.6 |  |  | $ | 172.3 |  |  | $ | 139.1 |  |
| Distribution | 34.3 |  |  | 54.5 |  |  | 35.9 |  |
| Fueling Systems | 92.7 |  |  | 96.8 |  |  | 79.5 |  |
| Intersegment Eliminations/Other | (61.2) |  |  | (66.4) |  |  | (65.3) |  |
| Consolidated | $ | 262.4 |  |  | $ | 257.2 |  |  | $ | 189.2 |  |

[0000038725-24-000038:notes:203]
|  | Total assets |  | Depreciation |
|  | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  | 2021 |
| Water Systems | $ | 1,044.4 |  |  | $ | 1,017.5 |  |  | $ | 894.4 |  |  | $ | 22.1 |  |  | $ | 20.4 |  |  | $ | 19.8 |  |
| Distribution | 365.6 |  |  | 360.4 |  |  | 363.0 |  |  | 6.8 |  |  | 6.1 |  |  | 4.4 |  |
| Fueling Systems | 256.4 |  |  | 269.1 |  |  | 273.6 |  |  | 2.6 |  |  | 2.5 |  |  | 2.2 |  |
| Other | 61.7 |  |  | 47.2 |  |  | 44.2 |  |  | 3.6 |  |  | 4.1 |  |  | 3.8 |  |
| Consolidated | $ | 1,728.1 |  |  | $ | 1,694.2 |  |  | $ | 1,575.2 |  |  | $ | 35.1 |  |  | $ | 33.1 |  |  | $ | 30.2 |  |
|  | Amortization |  | Capital expenditures |
|  | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  | 2021 |
| Water Systems | $ | 14.7 |  |  | $ | 14.7 |  |  | $ | 11.9 |  |  | $ | 28.6 |  |  | $ | 23.4 |  |  | $ | 19.4 |  |
| Distribution | 0.8 |  |  | 0.8 |  |  | 0.7 |  |  | 9.3 |  |  | 13.4 |  |  | 6.5 |  |
| Fueling Systems | 1.6 |  |  | 1.7 |  |  | 1.8 |  |  | 3.0 |  |  | 2.7 |  |  | 3.0 |  |
| Other | — |  |  | — |  |  | — |  |  | 2.3 |  |  | 1.6 |  |  | 1.2 |  |
| Consolidated | $ | 17.1 |  |  | $ | 17.2 |  |  | $ | 14.4 |  |  | $ | 43.2 |  |  | $ | 41.1 |  |  | $ | 30.1 |  |

[0000038725-24-000038:notes:204]
Cash and property, plant and equipment are the major asset groups in “Other” of total assets for the years ended December 31, 2023, December 31, 2022 and December 31, 2021.

[0000038725-24-000038:notes:205]
Financial information by geographic region is as follows:

[0000038725-24-000038:notes:206]
|  | Net sales |  | Long-lived assets |
| (In millions) | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  | 2021 |
| United States | $ | 1,441.6 |  |  | $ | 1,414.1 |  |  | $ | 1,075.7 |  |  | $ | 625.3 |  |  | $ | 601.7 |  |  | $ | 604.5 |  |
| Foreign | 623.5 |  |  | 629.6 |  |  | 586.2 |  |  | 240.3 |  |  | 227.6 |  |  | 238.4 |  |
| Consolidated | $ | 2,065.1 |  |  | $ | 2,043.7 |  |  | $ | 1,661.9 |  |  | $ | 865.6 |  |  | $ | 829.3 |  |  | $ | 842.9 |  |

[0000038725-24-000038:notes:207]
Net sales are attributed to geographic regions based upon the ship to location of the customer. Long-lived assets are attributed to geographic regions based upon the country of domicile.

[0000038725-24-000038:notes:208]
The Company offers a large array of products and systems to multiple markets and customers. Product sales information is tracked regionally and products are categorized differently between regions based on local needs and reporting requirements. However, net sales by segment are representative of the Company’s sales by major product category. The Company sells its products through various distribution channels including wholesale and retail distributors, specialty distributors, industrial and petroleum equipment distributors, as well as major oil and utility companies and original equipment manufacturers.

[0000038725-24-000038:notes:209]
No single customer accounted for more than 10 percent of the Company’s net sales in 2023, 2022, or 2021. No single customer accounted for more than 10 percent of the Company’s gross accounts receivable in 2023 or 2022.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-24-000038:notes:210]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor reasonably estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position,  results of operations, or cash flows.

[0000038725-24-000038:notes:211]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal

[0000038725-24-000038:notes:212]
actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-24-000038:notes:213]
At December 31, 2023, the Company had $11.1 million of commitments primarily for capital expenditures and the purchase of raw materials to be used in production.

[0000038725-24-000038:notes:214]
At December 31, 2023, the Company has a contingent consideration liability with an estimated fair value of $3.0 million that could result in a payment up to $5.0 million if a future profitability milestone is achieved.

[0000038725-24-000038:notes:215]
The changes in the carrying amount of the warranty accrual, as recorded in the “Accrued expenses and other current liabilities” line of the Company’s consolidated balance sheets for 2023 and 2022, are as follows:

[0000038725-24-000038:notes:216]
| (In millions) |  | 2023 |  | 2022 |
| Beginning balance |  | $ | 11.2 |  |  | $ | 10.5 |  |
| Accruals related to product warranties |  | 11.8 |  |  | 10.4 |  |
| Additions related to acquisitions |  | — |  |  | — |  |
| Reductions for payments made |  | (13.7) |  |  | (9.7) |  |
| Ending balance |  | $ | 9.3 |  |  | $ | 11.2 |  |

[0000038725-24-000038:notes:217]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. However, these financing leases are immaterial to the Company.

[0000038725-24-000038:notes:218]
The components of the Company's operating lease portfolio as of 2023, 2022, and 2021 are as follows:

[0000038725-24-000038:notes:219]
| Lease Cost (In millions): |  | 2023 |  | 2022 |  | 2021 |
| Operating lease cost |  | $ | 18.8 |  |  | $ | 17.4 |  |  | $ | 13.6 |  |
| Short-term lease cost |  | $ | 0.5 |  |  | $ | 0.2 |  |  | $ | 0.6 |  |
| Other Information: |  |  |  |  |  |  |
| Weighted-average remaining lease term |  | 4.0 years |  | 4.2 years |  |  |
| Weighted-average discount rate |  | 4.3 | % |  | 3.6 | % |  |  |

[0000038725-24-000038:notes:220]
The Company has entered into lease agreements with aggregate future minimum payments of approximately $2.2 million that have not yet commenced as of December 31, 2023.

[0000038725-24-000038:notes:221]
The future minimum rental payments for non-cancellable operating leases as of December 31, 2023, are as follows:

[0000038725-24-000038:notes:222]
| (In millions) | Total |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |
| Undiscounted future minimum rental payments | $ | 61.9 |  |  | $ | 19.5 |  |  | $ | 15.3 |  |  | $ | 11.3 |  |  | $ | 7.8 |  |  | $ | 4.5 |  |  | $ | 3.5 |  |
| Less: Imputed Interest | 6.0 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | $ | 55.9 |  |  |  |  |  |  |  |  |  |  |  |  |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000038725-24-000038:notes:223]
None of the Company’s directors or officers adopted, modified, or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement during the Company’s fiscal quarter ended December 31, 2023.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000038725-24-000038:notes:224]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000038725-24-000038:notes:225]
| (In millions) |  | Balance at Beginning of Period |  | Charged to Costs and Expenses |  | Deductions (a) |  | Other (b) |  | Balance at End of Period |
| 2023 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4.2 |  |  | $ | (0.3) |  |  | $ | 0.4 |  |  | $ | 0.1 |  |  | $ | 3.6 |  |
| Allowance for deferred taxes |  | 4.9 |  |  | — |  |  | 0.8 |  |  | — |  |  | 4.1 |  |
| 2022 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4.0 |  |  | $ | 0.1 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | 4.2 |  |
| Allowance for deferred taxes |  | 6.5 |  |  | 0.4 |  |  | 2.0 |  |  | — |  |  | 4.9 |  |
| 2021 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4.0 |  |  | $ | (0.3) |  |  | $ | 0.1 |  |  | $ | 0.4 |  |  | $ | 4.0 |  |
| Allowance for deferred taxes |  | 8.3 |  |  | 0.6 |  |  | 2.4 |  |  | — |  |  | 6.5 |  |

[0000038725-24-000038:notes:226]
(a) Charges for which allowances were created.

[0000038725-24-000038:notes:227]
(b) Primarily related to acquisitions
