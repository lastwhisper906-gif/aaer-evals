# FELE MD&A — 0000038725-24-000038


## mdna

[0000038725-24-000038:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-24-000038:mdna:2]
Discussion of the year-over-year comparison of changes in the Company's financial condition and results of operation as of and for the fiscal years ended December 31, 2022 and December 31, 2021 can be found in Part II, Item 7. "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our Annual Report on Form 10-K for the fiscal year ended December 31, 2022.

[0000038725-24-000038:mdna:3]
2023 vs. 2022

[0000038725-24-000038:mdna:4]
OVERVIEW

[0000038725-24-000038:mdna:5]
Net sales in 2023 increased 1 percent compared to the prior year.  The sales increase in 2023 was primarily due to price realization, partially offset by the negative impact of foreign currency translation and lower volumes. The Company's consolidated gross profit was $697.0 million for 2023, an increase of $5.6 million from the prior year. Diluted earnings per share was $4.11 for 2023, an increase of $0.14 or 4 percent from the prior year.

[0000038725-24-000038:mdna:6]
RESULTS OF OPERATIONS

[0000038725-24-000038:mdna:7]
Net Sales

[0000038725-24-000038:mdna:8]
|  | Net Sales |
| (In millions) | 2023 |  | 2022 |  | 2023 v 2022 |
| Water Systems | $ | 1,203.7 |  |  | $ | 1,157.5 |  |  | $ | 46.2 |  |
| Fueling Systems | 296.5 |  |  | 334.1 |  |  | (37.6) |  |
| Distribution | 673.3 |  |  | 668.1 |  |  | 5.2 |  |
| Eliminations/Other | (108.4) |  |  | (116.0) |  |  | 7.6 |  |
| Consolidated | $ | 2,065.1 |  |  | $ | 2,043.7 |  |  | $ | 21.4 |  |

[0000038725-24-000038:mdna:9]
Net sales increased 1 percent in 2023 compared to the prior year. Foreign currency unfavorably impacted net sales by 3 percentage points during 2023, principally due to the strengthening of the U.S. Dollar relative to the Turkish Lira and Argentine Peso.

[0000038725-24-000038:mdna:10]
Net Sales-Water Systems

[0000038725-24-000038:mdna:11]
Water Systems sales increased 4 percent in 2023, as compared to the prior year. This sales growth was primarily due to price realization. Partially offsetting the increase, sales decreased 5 percent in 2023 due to the negative impact from foreign exchange rates, as compared to prior year.

[0000038725-24-000038:mdna:12]
Water Systems sales in the U.S. and Canada increased 4 percent in 2023, as compared to the prior year. Sales decreased less than 1 percent in 2023 due to the negative impact from foreign exchange rates, as compared to prior year.  In 2023, sales of large dewatering equipment increased 63 percent, sales of groundwater pumping equipment decreased 10 percent and sales of all other surface pumping equipment decreased 1 percent compared to 2022.

[0000038725-24-000038:mdna:13]
Water Systems sales in markets outside the U.S. and Canada increased 3 percent in 2023, as compared to the prior year. Sales decreased 11 percent in 2023 due to the negative impact from foreign exchange rates, as compared to prior year.  In 2023 excluding the impact of foreign currency translation, sales increases in EMEA and Latin America more than offset sales declines in the Asia Pacific markets.

[0000038725-24-000038:mdna:14]
Net Sales-Fueling Systems

[0000038725-24-000038:mdna:15]
Fueling Systems sales decreased 11 percent in 2023, as compared to the prior year. This sales decline was primarily due to lower volumes driven by customer inventory destocking as well as higher interest rates, labor constraints, and permitting delays causing some new station build plans to move into 2024.

[0000038725-24-000038:mdna:16]
Fueling Systems sales in the U.S. and Canada decreased 9 percent in 2023, as compared to the prior year. The decrease was primarily in dispensing and piping equipment. Outside the U.S. and Canada, Fueling Systems sales decreased 19 percent in 2023, as compared to the prior year, due primarily to the divestiture of the above ground storage tank business in 2022 and lower sales in China.

[0000038725-24-000038:mdna:17]
Net Sales-Distribution

[0000038725-24-000038:mdna:18]
Distribution sales increased 1 percentage point in 2023, as compared to the prior year. The Distribution segment sales increase was primarily due to higher volumes, partially offset by lower commodity-driven pricing.

[0000038725-24-000038:mdna:19]
Gross Profit and Expense Ratios

[0000038725-24-000038:mdna:20]
|  | Fiscal Year |
| (In Millions) | 2023 |  | % of Net Sales |  | 2022 |  | % of Net Sales |
| Gross Profit | $ | 697.0 |  |  | 33.8 | % |  | $ | 691.4 |  |  | 33.8 | % |
| Selling, General and Administrative Expense | 433.5 |  |  | 21.0 | % |  | 432.1 |  |  | 21.1 | % |

[0000038725-24-000038:mdna:21]
Gross Profit

[0000038725-24-000038:mdna:22]
The gross profit margin ratio was 33.8 percent in 2023 and 2022. The gross profit margin was favorably impacted in 2023 by price realization, product mix and lower freight costs in Water Systems and Fueling, partially offset by margin compression from unfavorable pricing of commodity-based products sold through the Distribution business.

[0000038725-24-000038:mdna:23]
Selling, General and Administrative (“SG&A”)

[0000038725-24-000038:mdna:24]
SG&A expenses were $433.5 million in 2023 compared to $432.1 million in 2022. SG&A expenses increased by less than 1 percent in 2023 primarily due to higher compensation costs, partially offset by lower advertising and marketing expenses. The SG&A expenses ratio was 21.0 percent and 21.1 percent in 2023 and 2022, respectively.

[0000038725-24-000038:mdna:25]
Restructuring Expenses

[0000038725-24-000038:mdna:26]
Restructuring expenses were $1.1 million and $2.2 million in 2023 and 2022, respectively. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities, branch closings and consolidations.

[0000038725-24-000038:mdna:27]
Operating Income

[0000038725-24-000038:mdna:28]
Operating income increased 2 percent in 2023, as compared to the prior year.

[0000038725-24-000038:mdna:29]
|  |  | Operating income (loss) |
| (In millions) |  | 2023 |  | 2022 |  | 2023 v 2022 |
| Water Systems |  | $ | 196.6 |  |  | $ | 172.3 |  |  | $ | 24.3 |  |
| Fueling Systems |  | 92.7 |  |  | 96.8 |  |  | (4.1) |  |
| Distribution |  | 34.3 |  |  | 54.5 |  |  | (20.2) |  |
| Eliminations/Other |  | (61.2) |  |  | (66.4) |  |  | 5.2 |  |
| Consolidated |  | $ | 262.4 |  |  | $ | 257.2 |  |  | $ | 5.2 |  |

[0000038725-24-000038:mdna:30]
Operating Income-Water Systems

[0000038725-24-000038:mdna:31]
Water Systems operating income increased $24.3 million in 2023, as compared to the prior-year period, primarily due to price realization and cost management, including lower freight costs. The 2023 operating income margin was 16.3 percent compared to 2022 operating income margin of 14.9 percent of net sales. Operating income margin increased in Water Systems primarily due to price realization and operating leverage on higher sales.

[0000038725-24-000038:mdna:32]
Operating Income-Fueling Systems

[0000038725-24-000038:mdna:33]
Fueling Systems operating income decreased $4.1 million in 2023, as compared to the prior-year period.  Operating income decreased in Fueling Systems primarily due to lower sales volumes, partially offset by a favorable product and geographic mix of net sales and disciplined cost management. The 2023 operating income margin was 31.3 percent compared to 29.0 percent of net sales in 2022. Operating income margin increased in Fueling Systems primarily due to price realization, a favorable product and geographic sales mix shift and disciplined cost management.

[0000038725-24-000038:mdna:34]
Operating Income-Distribution

[0000038725-24-000038:mdna:35]
Distribution operating income decreased $20.2 million in 2023, as compared to the prior-year period.  The 2023 operating income margin was 5.1 percent compared to 8.2 percent of net sales in 2022. Operating income and operating income margin decreased primarily due to unfavorable pricing of commodity-based products sold through the business.

[0000038725-24-000038:mdna:36]
Operating Income-Eliminations/Other

[0000038725-24-000038:mdna:37]
Operating income-eliminations/other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in 2023 compared to 2022 was a favorable $6.2 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses increased $1.0 million, compared to the prior year.

[0000038725-24-000038:mdna:38]
Interest Expense

[0000038725-24-000038:mdna:39]
Interest expense was $11.8 million in 2023 and $11.5 million in 2022, respectively. The increase in 2023 was primarily driven by higher interest rates, partially offset by lower average borrowings in 2023.

[0000038725-24-000038:mdna:40]
Other Income or Expense

[0000038725-24-000038:mdna:41]
Other income (expense), net was a benefit of $3.7 million in 2023 and an expense of $3.2 million in 2022. The favorable benefit in 2023 was due to higher interest income as a result of favorable interest rates and lower benefit costs related to the Company’s employee benefit plans.

[0000038725-24-000038:mdna:42]
Foreign Exchange

[0000038725-24-000038:mdna:43]
Foreign currency-based transactions produced an expense of $12.1 million in 2023 and $7.2 million in 2022, respectively. The expense in 2023 was primarily due to transaction losses associated with the Turkish Lira, Argentine and Mexican Peso relative to the U.S. dollar. The expense in 2022 was primarily due to transaction losses associated with the Argentine Peso and Turkish Lira. The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-24-000038:mdna:44]
Income Taxes

[0000038725-24-000038:mdna:45]
The provision for income taxes in 2023 and 2022 were $47.5 million and $46.4 million, respectively. The effective tax rate for 2023 was about 20 percent and before the impact of discrete events was about 21 percent. The effective tax rate for 2022 both before and after the impact of discrete events was about 20 percent. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to the recognition of the U.S. foreign-derived intangible income (FDII) provisions, foreign earnings taxed at rates below the U.S. statutory rate, certain incentives, and discrete events partially offset by state taxes.

[0000038725-24-000038:mdna:46]
Net Income

[0000038725-24-000038:mdna:47]
Net income for 2023 was $194.7 million compared to 2022 net income of $188.8 million. Net income attributable to Franklin Electric Co., Inc. for 2023 was $193.3 million, or $4.11 per diluted share, compared to 2022 net income attributable to Franklin Electric Co., Inc. of $187.3 million, or $3.97 per diluted share.

[0000038725-24-000038:mdna:48]
CAPITAL RESOURCES AND LIQUIDITY

[0000038725-24-000038:mdna:49]
Sources of Liquidity

[0000038725-24-000038:mdna:50]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at December 31, 2023 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-24-000038:mdna:51]
As of December 31, 2023, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of December 31, 2023, the Company had $335.4 million borrowing capacity under the Credit Agreement as $3.6 million in letters of commercial and standby letters of credit were outstanding and undrawn and $11.0 million in revolver borrowings were drawn and outstanding, which were primarily used for funding working capital requirements.

[0000038725-24-000038:mdna:52]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of $125.0 million as of December 31, 2023. The New York Life Agreement matures on July 30, 2024. The Company also has other long-term debt borrowings outstanding as of December 31, 2023. See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-24-000038:mdna:53]
At December 31, 2023, the Company had $69.6 million of cash and cash equivalents held in foreign jurisdictions, which the Company intends to use to fund foreign operations. There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-24-000038:mdna:54]
Cash Flows

[0000038725-24-000038:mdna:55]
The following table summarizes significant sources and uses of cash and cash equivalents:

[0000038725-24-000038:mdna:56]
| (in millions) | 2023 |  | 2022 |
| Cash flows from operating activities | $ | 315.7 |  |  | $ | 101.7 |  |
| Cash flows from investing activities | $ | (74.3) |  |  | $ | (43.1) |  |
| Cash flows from financing activities | $ | (192.2) |  |  | $ | (48.5) |  |
| Impact of exchange rates on cash and cash equivalents | $ | (10.0) |  |  | $ | (4.9) |  |
| Change in cash and cash equivalents | $ | 39.2 |  |  | $ | 5.2 |  |

[0000038725-24-000038:mdna:57]
Cash Flows from Operating Activities

[0000038725-24-000038:mdna:58]
2023 vs 2022

[0000038725-24-000038:mdna:59]
Net cash provided by operating activities was $315.7 million for 2023 compared to $101.7 million for 2022. The increase in cash provided by operating activities was primarily due to actions the Company took to improve working capital including inventory reductions as its supply chain resiliency and lead times improved during the back half of the year.

[0000038725-24-000038:mdna:60]
Cash Flows from Investing Activities

[0000038725-24-000038:mdna:61]
2023 vs. 2022

[0000038725-24-000038:mdna:62]
Net cash used in investing activities was $74.3 million in 2023 compared to $43.1 million in 2022. The increase was primarily attributable to increased acquisition activity in 2023.

[0000038725-24-000038:mdna:63]
Cash Flows from Financing Activities

[0000038725-24-000038:mdna:64]
2023 vs. 2022

[0000038725-24-000038:mdna:65]
Net cash used by financing activities was $192.2 million in 2023 compared to $48.5 million in 2022. The change in financing cash flow was primarily attributable to net borrowings under the Company's revolving credit facility in 2022 compared to net repayments in 2023.

[0000038725-24-000038:mdna:66]
AGGREGATE CONTRACTUAL OBLIGATIONS

[0000038725-24-000038:mdna:67]
The majority of the Company’s contractual obligations to third parties relate to debt obligations. In addition, the Company has certain contractual obligations for future lease payments and purchase obligations. The payment schedule for these contractual obligations is as follows:

[0000038725-24-000038:mdna:68]
| (In millions) |  |  |  |  |  |  |  |  | More than |
|  | Total |  | 2024 |  | 2025-2026 |  | 2027-2028 |  | 5 years |
| Debt | $ | 100.6 |  |  | $ | 12.4 |  |  | $ | 78.1 |  |  | $ | 2.8 |  |  | $ | 7.3 |  |
| Debt interest | 13.8 |  |  | 7.6 |  |  | 4.8 |  |  | 0.7 |  |  | 0.7 |  |
| Operating leases | 61.9 |  |  | 19.5 |  |  | 26.6 |  |  | 12.3 |  |  | 3.5 |  |
| Purchase obligations | 11.1 |  |  | 11.0 |  |  | 0.1 |  |  | — |  |  | — |  |
| Income Taxes-U.S. Tax Cuts and Jobs Act transition tax | $ | 8.7 |  |  | $ | 3.9 |  |  | $ | 4.8 |  |  | $ | — |  |  | $ | — |  |
|  | $ | 196.1 |  |  | $ | 54.4 |  |  | $ | 114.4 |  |  | $ | 15.8 |  |  | $ | 11.5 |  |

[0000038725-24-000038:mdna:69]
Interest payments on debt obligations are calculated for future periods using interest rates in effect at the end of 2023. Certain of these projected interest payments may differ in the future based on interest rates or other factors or events. The projected interest payments only pertain to obligations and agreements outstanding at December 31, 2023.

[0000038725-24-000038:mdna:70]
The Company has pension and other post-retirement benefit obligations not included in the table above which will result in estimated future payments of approximately $0.8 million in 2024. In addition, due to the timing of funding in future periods being uncertain and dependent on future movements in interest rates, investment returns, changes in laws and regulations and other variables, the table above excludes the non-current liability of $29.5 million for cash outflows related to the Company's pension plans.

[0000038725-24-000038:mdna:71]
The Company also has unrecognized tax benefits, none of which are included in the table above. The unrecognized tax benefits of approximately $0.8 million have been recorded as liabilities and the Company is uncertain as to if or when such amounts may be settled. Related to the unrecognized tax benefits, the Company has also recorded a liability for potential penalties and interest of $0.1 million.

[0000038725-24-000038:mdna:72]
ACCOUNTING PRONOUNCEMENTS

[0000038725-24-000038:mdna:73]
For information regarding recent accounting pronouncements, refer to Note 2 - Accounting Pronouncements, in the Notes to Consolidated Financial Statements in the sections entitled ""Adoption of New Accounting Standards" and "Accounting Standards Issued But Not Yet Adopted", included in Part II, Item 8, "Financial Statements and Supplementary Data" of this Annual Report on Form 10-K.

[0000038725-24-000038:mdna:74]
CRITICAL ACCOUNTING ESTIMATES

[0000038725-24-000038:mdna:75]
Management’s discussion and analysis of its financial condition and results of operations are based upon the Company’s consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires management to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and the related disclosure of contingent assets and liabilities. Management evaluates estimates on an ongoing basis. Estimates are based on historical experience and on other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. There were no material changes to estimates or methodologies used to develop those estimates in 2023. The Company’s critical accounting estimates are identified below:

[0000038725-24-000038:mdna:76]
Inventory Valuation

[0000038725-24-000038:mdna:77]
The Company uses certain estimates and judgments to value inventory. Inventory is recorded at the lower of cost or net realizable value. The Company reviews its inventories for excess or obsolete products or components. Based on an analysis of historical usage, management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts, carrying values are adjusted. The carrying value is reduced regularly to reflect the age and current anticipated product demand. If actual demand differs from the estimates, additional reductions would be necessary in the period such determination is made. Excess and obsolete inventory is periodically disposed of through sale to third parties, scrapping, or other means.

[0000038725-24-000038:mdna:78]
Business Combinations and Valuation of Acquired Intangible Assets

[0000038725-24-000038:mdna:79]
The Company follows the guidance under FASB ASC Topic 805, Business Combinations. The acquisition purchase price is allocated to the assets acquired and liabilities assumed based upon their respective fair values. The Company utilizes management estimates and may use an independent third-party valuation firm to assist in determining the fair values of assets acquired, including intangible assets, and liabilities assumed. The identifiable intangible assets acquired typically include customer relationships and trade names. Identifiable intangible assets are initially valued using a methodology commensurate with the intended use of the asset. The fair value of customer relationships is measured using the multi-period excess earnings method ("MPEEM"). The fair value of trade names is measured using a relief-from-royalty ("RFR") approach, which assumes the value of the trade name is the discounted amount of cash flows that would be paid to third parties had the Company not owned the trade name and instead licensed the trade name from another company. Higher royalty rates are assigned to premium brands within the marketplace based on name recognition and profitability, while other brands receive lower royalty rates. The basis for future sales projections for both the RFR and MPEEM are based on internal revenue forecasts which the Company believes represents reasonable market participant assumptions. The future cash flows are discounted using an applicable discount rate as well as any potential risk premium to reflect the inherent risk of holding a standalone intangible asset.  The key uncertainties in the RFR and MPEEM calculations, as applicable, are the selection of an appropriate royalty rate, assumptions used in developing estimates of future cash flows, including revenue growth and expense forecasts, assumed customer attrition rates, as well as the perceived risk associated with those forecasts in determining the discount rate and risk premium.  There is inherent uncertainty in forecasted future cash flows and therefore, actual results may differ and could result in subsequent impairment charges of acquired intangibles and/or goodwill.

[0000038725-24-000038:mdna:80]
Indefinite-Lived Intangible Asset and Goodwill Impairment Evaluation

[0000038725-24-000038:mdna:81]
According to FASB ASC Topic 350, Intangibles - Goodwill and Other, intangible assets with indefinite lives must be tested for impairment at least annually or more frequently as warranted by triggering events that indicate potential impairment. The Company uses a variety of methodologies in conducting impairment assessments including income and market approaches. For indefinite-lived assets apart from goodwill, primarily trade names for the Company, if the fair value is less than the carrying amount, an impairment charge is recognized in an amount equal to that excess. The Company has not made any material changes to the method of evaluating impairments during the last three years.

[0000038725-24-000038:mdna:82]
In compliance with FASB ASC Topic 350, goodwill is not amortized. Goodwill is tested at the reporting unit level for impairment annually or more frequently as warranted by triggering events that indicate potential impairment. Reporting units are operating segments or one level below, known as components, which can be aggregated for testing purposes.

[0000038725-24-000038:mdna:83]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the market value and income approaches. The market value approach compares the reporting units’ current and projected financial results to entities of similar size and industry to determine the market value of the reporting unit. The income approach utilizes assumptions regarding estimated future cash flows and other factors to determine the fair value of the respective assets. These cash flows consider factors regarding expected future operating income and historical trends, as well as the effects of demand and competition. The Company is required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units is below their associated carrying values. Goodwill included on the balance sheet as of the year ended December 31, 2023 was $342.4 million.

[0000038725-24-000038:mdna:84]
During the fourth quarter of 2023, the Company completed its annual impairment test of goodwill and indefinite-lived trade names and determined the fair value of all intangibles were substantially in excess of the respective carrying values. Significant judgment is required to determine if an indication of impairment has taken place. Factors to be considered include the following: adverse changes in operating results, decline in strategic business plans, significantly lower future cash flows, and sustainable declines in market data such as market capitalization. A 10 percent decrease in the estimated fair value of any of these intangible assets would not have changed this determination. The sensitivity analysis required the use of numerous subjective assumptions, which, if actual experience varies, could result in material differences in the requirements for impairment charges. Further, an extended downturn in the economy may impact certain components of the operating segments more significantly and could result in an impairment determination.

[0000038725-24-000038:mdna:85]
Income Taxes

[0000038725-24-000038:mdna:86]
Under the requirements of FASB ASC Topic 740, Income Taxes, the Company records deferred tax assets and liabilities for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company analyzes the deferred tax assets and liabilities for their future realization based on the estimated existence of sufficient taxable income. This analysis considers the following sources of taxable income: prior year taxable income, future reversals of existing taxable temporary differences, future taxable income exclusive of reversing temporary differences and tax planning strategies that would generate taxable income in the relevant period. If sufficient taxable income is not projected then the Company will record a valuation allowance against the relevant deferred tax assets.

[0000038725-24-000038:mdna:87]
The Company’s operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions. These jurisdictions have different tax rates, and the Company determines the allocation of income to each of these jurisdictions based upon various estimates and assumptions. In the normal course of business, the Company will undergo tax audits by various tax jurisdictions. Such audits often require an extended period of time to complete and may result in income tax adjustments if changes to the allocation are required between jurisdictions with different tax rates. The final taxes paid are dependent upon many factors, including negotiations with taxing authorities in the various jurisdictions and resolution of disputes arising from federal, state, and international tax audits. Although the Company has recorded all income tax uncertainties in accordance with FASB ASC Topic 740, these accruals represent estimates that are subject to the inherent uncertainties associated with the tax audit process. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, which, if actual experience varies, could result in material adjustments to tax expense and/or deferred tax assets and liabilities.

[0000038725-24-000038:mdna:88]
Pension and Employee Benefit Obligations

[0000038725-24-000038:mdna:89]
The Company consults with its actuaries to assist with the calculation of discount rates used in its pension and post retirement plans. The discount rates used to determine domestic pension and post-retirement plan liabilities are calculated using a full yield curve approach. Market conditions have caused the weighted-average discount rate to move from 5.15 percent last year to 4.90 percent this year for the domestic pension plans and from 5.08 percent last year to 4.88 percent this year for the postretirement health and life insurance plan. A change in the discount rate selected by the Company of 25 basis points would result in a change of about $0.1 million to employee benefit expense and a change of about $2.4 million of liability.

[0000038725-24-000038:mdna:90]
The Company consults with actuaries and investment advisors in making its determination of the expected long-term rate of return on plan assets. Using input from these consultations such as long-term investment sector expected returns, the correlations and standard deviations thereof, and the plan asset allocation, the Company will use an expected long-term rate of return on plan assets of 6.20 percent in measuring net periodic cost for 2024. Market conditions have caused the expected long-term rate or return to increase from 5.70 percent as used in measuring net periodic cost for 2023. A change in the long-term rate of return selected by the Company of 25 basis points would result in a change of about $0.3 million of employee benefit expense.

[0000038725-24-000038:mdna:91]
FACTORS THAT MAY AFFECT FUTURE RESULTS
