# FELE 8-K — 0000038725-24-000010 filed 2024-02-13

## item codes, every 8-K on or before 2024-02-23

- 2024-02-13 0000038725-24-000012 — 7.01, 9.01
- 2024-02-13 0000038725-24-000010 — 2.02, 9.01
- 2023-11-06 0000038725-23-000184 — 7.01, 9.01
- 2023-10-24 0000038725-23-000177 — 2.02, 9.01
- 2023-08-04 0000038725-23-000160 — 5.02, 9.01
- 2023-08-03 0000038725-23-000158 — 7.01, 9.01
- 2023-07-25 0000038725-23-000149 — 2.02, 9.01
- 2023-07-05 0000038725-23-000144 — 5.02, 7.01, 9.01
- 2023-05-09 0000038725-23-000094 — 5.02, 9.01
- 2023-05-09 0000038725-23-000092 — 5.07
- 2023-05-08 0000038725-23-000087 — 7.01, 9.01
- 2023-05-02 0000038725-23-000065 — 2.02, 9.01
- 2023-03-08 0000038725-23-000046 — 7.01, 9.01
- 2023-02-21 0000038725-23-000016 — 8.01, 9.01
- 2023-02-14 0000038725-23-000002 — 2.02, 9.01
- 2022-10-28 0000038725-22-000180 — 7.01, 9.01
- 2022-10-25 0000038725-22-000177 — 2.02, 9.01
- 2022-08-04 0000038725-22-000150 — 7.01, 9.01
- 2022-07-26 0000038725-22-000142 — 2.02, 9.01
- 2022-05-11 0000038725-22-000106 — 2.03, 9.01
- 2022-05-06 0000038725-22-000082 — 5.07
- 2022-05-06 0000038725-22-000081 — 5.02, 9.01
- 2022-05-03 0000038725-22-000075 — 7.01, 9.01
- 2022-04-26 0000038725-22-000073 — 2.02, 9.01
- 2022-03-24 0000038725-22-000056 — 5.02, 9.01
- 2022-03-08 0000038725-22-000049 — 7.01, 9.01
- 2022-02-15 0000038725-22-000007 — 2.02, 9.01
- 2022-01-04 0000038725-22-000002 — 7.01, 9.01
- 2021-11-03 0000038725-21-000212 — 7.01, 9.01
- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2024-02-23

- none on or before 2024-02-23

## item 2.02 — earnings release, exhibit 99.1

[0000038725-24-000010:8k_2_02:1]
EX-99.1
2
a2024213ex991earningsrelea.htm
EX-99.1

[0000038725-24-000010:8k_2_02:2]
Document

[0000038725-24-000010:8k_2_02:3]
Exhibit 99.1

[0000038725-24-000010:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-24-000010:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS FOURTH QUARTER 2023 AND FULL YEAR 2023 RESULTS

[0000038725-24-000010:8k_2_02:6]
Fourth Quarter 2023 Highlights

[0000038725-24-000010:8k_2_02:7]
•Consolidated net sales of $473.0 million, a decrease of 3% to the prior year

[0000038725-24-000010:8k_2_02:8]
•Water Systems and Distribution net sales decreased by 1% each, while Fueling Systems net sales decreased 23%

[0000038725-24-000010:8k_2_02:9]
•Operating income was $50.8 million with operating margin of 10.7%

[0000038725-24-000010:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $0.82

[0000038725-24-000010:8k_2_02:11]
Full Year 2023 Highlights

[0000038725-24-000010:8k_2_02:12]
•Full Year record net sales of $2.1 billion, an increase of 1% over the prior year

[0000038725-24-000010:8k_2_02:13]
•Water Systems and Distribution both set new net sales records with increases of 4% and 1%, respectively, while Fueling Systems net sales decreased 11%

[0000038725-24-000010:8k_2_02:14]
•Operating income for 2023 was a record at $262.4 million with operating margin of 12.7%

[0000038725-24-000010:8k_2_02:15]
•GAAP fully diluted EPS was a record at $4.11, an increase of 4% over the prior year

[0000038725-24-000010:8k_2_02:16]
•Record cash flows from operating activities of $315.7 million increased $214.0 million over the prior year

[0000038725-24-000010:8k_2_02:17]
Fort Wayne, IN – February 13, 2024 – Franklin Electric Co., Inc. today announced its fourth quarter and full year financial results for fiscal year 2023.

[0000038725-24-000010:8k_2_02:18]
Fourth quarter 2023 net sales were $473.0 million, compared to fourth quarter 2022 net sales of $489.4 million. Fourth quarter 2023 operating income was $50.8 million, compared to fourth quarter 2022 operating income of $56.2 million.  Fourth quarter 2023 EPS was $0.82, versus EPS in the fourth quarter 2022 of $0.84.

[0000038725-24-000010:8k_2_02:19]
Full Year 2023 net sales were $2.1 billion, compared to full year 2022 net sales of $2.0 billion. Full year 2023 operating income was $262.4 million, compared to full year 2022 operating income of $257.2 million.  Full year 2023 EPS was $4.11, versus EPS in 2022 of $3.97.

[0000038725-24-000010:8k_2_02:20]
“The Franklin Electric team delivered another solid quarter to end a record year overall for the Company with new full year records for net sales, operating income, earnings per share, and operating cash flows. Strong execution drove healthy margins for both the quarter and year, led by record full-year operating income in our Water Systems segment while commodity price headwinds in our Distribution business and destocking activity in Fueling continued to weigh on our results,” commented Gregg Sengstack, Franklin Electric’s Chairperson and Chief Executive Officer.

[0000038725-24-000010:8k_2_02:21]
“The breadth and durability of our global portfolio has proven resilient and positions us well entering 2024 where we expect demand to gain momentum as we move further into the year. I’m confident our healthy financial position and commitment to remain focused on meeting our customers’ growing requirements for water and energy solutions provides a solid foundation to enhance shareholder value”, concluded Mr. Sengstack.

[0000038725-24-000010:8k_2_02:22]
Segment Summaries

[0000038725-24-000010:8k_2_02:23]
Water Systems net sales were $279.6 million in the fourth quarter, a decrease of $1.7 million or 1 percent compared to the fourth quarter 2022. Sales decreases were driven by lower sales of groundwater pumping and water treatment products, partially offset by strong end market demand for large pumps. Water Systems operating income in the fourth quarter 2023 was $44.1 million.  Fourth quarter 2022 Water Systems operating income was $44.6 million.

[0000038725-24-000010:8k_2_02:24]
Distribution net sales were $148.0 million in the fourth quarter 2023, a decrease of $0.9 million or 1 percent compared to the fourth quarter 2022. The Distribution segment operating income was $1.0 million in the fourth quarter 2023 compared to fourth quarter 2022 operating income of $2.9 million. Distribution segment sales and operating income were negatively impacted by adverse weather and margin compression from declining pricing of commodity-based products sold through the business.

[0000038725-24-000010:8k_2_02:25]
Fueling Systems net sales were $65.7 million in the fourth quarter 2023, a decrease of $19.8 million or 23 percent compared to the fourth quarter 2022.   Sales decreases were driven by customer inventory destocking driving lower volumes and higher interest rates, labor constraints, and permitting delays causing some new station build plans to move into 2024. Fueling Systems operating income in the fourth quarter 2023 was $19.4 million.  Fourth quarter 2022 Fueling Systems operating income was $24.3 million.

[0000038725-24-000010:8k_2_02:26]
Cash Flow

[0000038725-24-000010:8k_2_02:27]
Net cash flows from operating activities for 2023 were $315.7 million versus $101.7 million in the same period in 2022. The increase was primarily due to actions the Company took to improve working capital including inventory reductions as its supply chain resiliency and lead times improved during the back half of the year.

[0000038725-24-000010:8k_2_02:28]
2024 Guidance

[0000038725-24-000010:8k_2_02:29]
The Company expects its full year 2024 sales to be in the range of $2.10 billion to $2.17 billion and full year 2024 EPS to be in the range of $4.22 to $4.40.

[0000038725-24-000010:8k_2_02:30]
Earnings Conference Call

[0000038725-24-000010:8k_2_02:31]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The fourth quarter and fiscal year 2023 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-24-000010:8k_2_02:32]
https://edge.media-server.com/mmc/p/y88zfrpv

[0000038725-24-000010:8k_2_02:33]
For those interested in participating in the question-and-answer portion of the call, please register for the call at the link below.

[0000038725-24-000010:8k_2_02:34]
https://register.vevent.com/register/BI7028d9118f904de0860c8fee5c50244a

[0000038725-24-000010:8k_2_02:35]
All registrants will receive dial-in information and a PIN allowing them to access the live call. It is recommended that you join 10 minutes prior to the event start (although you may register and dial in at any time during the call).

[0000038725-24-000010:8k_2_02:36]
A replay of the conference call will be available from Tuesday, February 13, 2024, through 9:00 am ET on Tuesday, February 20, 2024, by visiting the listen-only webcast link above.

[0000038725-24-000010:8k_2_02:37]
Forward Looking Statements

[0000038725-24-000010:8k_2_02:38]
About Franklin Electric

[0000038725-24-000010:8k_2_02:39]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and energy. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications. Franklin Electric is proud to be named in Newsweek’s lists of America’s Most Responsible Companies and Most Trustworthy Companies for 2023 and America’s Climate Leaders 2023 by USA Today.

[0000038725-24-000010:8k_2_02:40]
Franklin Electric Contact:

[0000038725-24-000010:8k_2_02:41]
Sandy Statzer

[0000038725-24-000010:8k_2_02:42]
Franklin Electric Co., Inc.

[0000038725-24-000010:8k_2_02:43]
InvestorRelations@fele.com

[0000038725-24-000010:8k_2_02:44]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Fourth Quarter Ended |  | Fiscal Year End |
|  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  | December 31, 2022 |
| Net sales | $ | 472,970 |  |  | $ | 489,431 |  |  | $ | 2,065,133 |  |  | $ | 2,043,711 |  |
| Cost of sales | 312,961 |  |  | 323,213 |  |  | 1,368,125 |  |  | 1,352,276 |  |
| Gross profit | 160,009 |  |  | 166,218 |  |  | 697,008 |  |  | 691,435 |  |
| Selling, general, and administrative expenses | 108,825 |  |  | 109,724 |  |  | 433,476 |  |  | 432,076 |  |
| Restructuring expense | 356 |  |  | 272 |  |  | 1,091 |  |  | 2,170 |  |
| Operating income | 50,828 |  |  | 56,222 |  |  | 262,441 |  |  | 257,189 |  |
| Interest expense | (1,481) |  |  | (4,033) |  |  | (11,790) |  |  | (11,525) |  |
| Other income/(expense), net | 1,831 |  |  | (414) |  |  | 3,696 |  |  | (3,201) |  |
| Foreign exchange expense | (4,026) |  |  | (2,946) |  |  | (12,124) |  |  | (7,236) |  |
| Income before income taxes | 47,152 |  |  | 48,829 |  |  | 242,223 |  |  | 235,227 |  |
| Income tax expense | 8,322 |  |  | 8,872 |  |  | 47,489 |  |  | 46,416 |  |
| Net income | $ | 38,830 |  |  | $ | 39,957 |  |  | $ | 194,734 |  |  | $ | 188,811 |  |
| Less: Net income attributable to noncontrolling interests | (281) |  |  | (378) |  |  | (1,462) |  |  | (1,479) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 38,549 |  |  | $ | 39,579 |  |  | $ | 193,272 |  |  | $ | 187,332 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.83 |  |  | $ | 0.85 |  |  | $ | 4.17 |  |  | $ | 4.02 |  |
| Diluted | $ | 0.82 |  |  | $ | 0.84 |  |  | $ | 4.11 |  |  | $ | 3.97 |  |

[0000038725-24-000010:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | December 31, 2023 |  | December 31, 2022 |
| ASSETS |  |
| Cash and equivalents | $ | 84,963 |  |  | $ | 45,790 |  |
| Receivables (net) | 222,418 |  |  | 230,404 |  |
| Inventories | 508,696 |  |  | 544,980 |  |
| Other current assets | 37,718 |  |  | 36,916 |  |
| Total current assets | 853,795 |  |  | 858,090 |  |
| Property, plant, and equipment, net | 229,739 |  |  | 215,154 |  |
| Lease right-of-use assets, net | 57,014 |  |  | 48,948 |  |
| Goodwill and other assets | 587,574 |  |  | 572,009 |  |
| Total assets | $ | 1,728,122 |  |  | $ | 1,694,201 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 152,419 |  |  | $ | 139,266 |  |
| Accrued expenses and other current liabilities | 104,949 |  |  | 123,788 |  |
| Current lease liability | 17,316 |  |  | 15,959 |  |
| Current maturities of long-term debt and short-term borrowings | 12,355 |  |  | 126,756 |  |
| Total current liabilities | 287,039 |  |  | 405,769 |  |
| Long-term debt | 88,056 |  |  | 89,271 |  |
| Long-term lease liability | 38,549 |  |  | 32,858 |  |
| Income taxes payable non-current | 4,837 |  |  | 8,707 |  |
| Deferred income taxes | 29,461 |  |  | 29,744 |  |
| Employee benefit plans | 35,973 |  |  | 31,889 |  |
| Other long-term liabilities | 33,914 |  |  | 25,209 |  |
| Redeemable noncontrolling interest | 1,145 |  |  | 620 |  |
| Total equity | 1,209,148 |  |  | 1,070,134 |  |
| Total liabilities and equity | $ | 1,728,122 |  |  | $ | 1,694,201 |  |

[0000038725-24-000010:8k_2_02:46]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | December 31, 2023 |  | December 31, 2022 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 194,734 |  |  | $ | 188,811 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 52,260 |  |  | 50,374 |  |
| Non-cash lease expense | 18,852 |  |  | 17,406 |  |
| Share-based compensation | 10,133 |  |  | 10,973 |  |
| Other | 10,259 |  |  | 7,291 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | 19,150 |  |  | (44,800) |  |
| Inventory | 48,176 |  |  | (101,080) |  |
| Accounts payable and accrued expenses | (23,085) |  |  | (12,283) |  |
| Operating leases | (18,874) |  |  | (17,406) |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | (2,902) |  | (355) |
| Other | 7,007 |  |  | 2,743 |  |
| Net cash flows from operating activities | 315,710 |  |  | 101,674 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (41,415) |  |  | (41,903) |  |
| Proceeds from sale of property, plant, and equipment | 1,494 |  |  | 6 |  |
| Acquisitions and investments | (34,831) |  |  | (1,186) |  |
| Other investing activities | 463 |  |  | 9 |  |
| Net cash flows from investing activities | (74,289) |  |  | (43,074) |  |
| Cash flows from financing activities: |  |  |  |
| Net change in debt | (115,529) |  |  | 28,936 |  |
| Proceeds from issuance of common stock | 9,193 |  |  | 3,859 |  |
| Purchases of common stock | (43,332) |  |  | (40,490) |  |
| Dividends paid | (41,723) |  |  | (36,991) |  |
| Deferred payments for acquisitions | (802) |  |  | (3,786) |  |
| Net cash flows from financing activities | (192,193) |  |  | (48,472) |  |
| Effect of exchange rate changes on cash and cash equivalents | (10,055) |  |  | (4,874) |  |
| Net change in cash and cash equivalents | 39,173 |  |  | 5,254 |  |
| Cash and cash equivalents at beginning of period | 45,790 |  |  | 40,536 |  |
| Cash and cash equivalents at end of period | $ | 84,963 |  |  | $ | 45,790 |  |

[0000038725-24-000010:8k_2_02:47]
Key Performance Indicators: Net Sales Summary

[0000038725-24-000010:8k_2_02:48]
|  | Net Sales For the Fourth Quarter |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q4 2022 | $ | 171.0 |  | $ | 38.4 |  | $ | 46.0 |  | $ | 25.9 |  | $ | 281.3 |  | $ | 85.5 |  | $ | 148.9 |  | $ | (26.3) |  | $ | 489.4 |  |
| Q4 2023 | $ | 161.2 |  | $ | 46.6 |  | $ | 45.5 |  | $ | 26.3 |  | $ | 279.6 |  | $ | 65.7 |  | $ | 148.0 |  | $ | (20.3) |  | $ | 473.0 |  |
| Change | $ | (9.8) |  | $ | 8.2 |  | $ | (0.5) |  | $ | 0.4 |  | $ | (1.7) |  | $ | (19.8) |  | $ | (0.9) |  | $ | 6.0 |  | $ | (16.4) |  |
| % Change | (6) | % | 21 | % | (1) | % | 2 | % | (1) | % | (23) | % | (1) | % |  | (3) | % |
| Foreign currency translation | $ | (0.1) |  | $ | (6.9) |  | $ | (5.8) |  | $ | (0.1) |  | $ | (12.9) |  | $ | 0.1 |  | $ | — |  |  | $ | (12.8) |  |
| % Change | — | % | (18) | % | (13) | % | — | % | (5) | % | — | % | — | % |  | (3) | % |
| Volume/Price | $ | (9.7) |  | $ | 15.1 |  | $ | 5.3 |  | $ | 0.5 |  | $ | 11.2 |  | $ | (19.9) |  | $ | (0.9) |  | $ | 6.0 |  | $ | (3.6) |  |
| % Change | (6) | % | 39 | % | 12 | % | 2 | % | 4 | % | (23) | % | (1) | % | (23) | % | (1) | % |

[0000038725-24-000010:8k_2_02:49]
|  | Net Sales For the Full Year |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| FY 2022 | $ | 712.9 |  | $ | 159.3 |  | $ | 192.8 |  | $ | 92.5 |  | $ | 1,157.5 |  | $ | 334.1 |  | $ | 668.1 |  | $ | (116.0) |  | $ | 2,043.7 |  |
| FY 2023 | $ | 744.4 |  | $ | 174.2 |  | $ | 198.3 |  | $ | 86.8 |  | $ | 1,203.7 |  | $ | 296.5 |  | $ | 673.3 |  | $ | (108.4) |  | $ | 2,065.1 |  |
| Change | $ | 31.5 |  | $ | 14.9 |  | $ | 5.5 |  | $ | (5.7) |  | $ | 46.2 |  | $ | (37.6) |  | $ | 5.2 |  | $ | 7.6 |  | $ | 21.4 |  |
| % Change | 4 | % | 9 | % | 3 | % | (6) | % | 4 | % | (11) | % | 1 | % |  | 1 | % |
| Foreign currency translation | $ | (3.3) |  | $ | (22.1) |  | $ | (23.6) |  | $ | (3.3) |  | $ | (52.3) |  | $ | (0.8) |  | $ | — |  |  | $ | (53.1) |  |
| % Change | — | % | (14) | % | (12) | % | (4) | % | (5) | % | — | % | — | % |  | (3) | % |
| Volume/Price | $ | 34.8 |  | $ | 37.0 |  | $ | 29.1 |  | $ | (2.4) |  | $ | 98.5 |  | $ | (36.8) |  | $ | 5.2 |  | $ | 7.6 |  | $ | 74.5 |  |
| % Change | 5 | % | 23 | % | 15 | % | (3) | % | 9 | % | (11) | % | 1 | % | (7) | % | 4 | % |

[0000038725-24-000010:8k_2_02:50]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-24-000010:8k_2_02:51]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2023 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 44.1 |  | $ | 19.4 |  | $ | 1.0 |  | $ | (13.7) |  | $ | 50.8 |  |
| % Operating Income To Net Sales | 15.8 | % | 29.5 | % | 0.7 | % |  | 10.7 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2022 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 44.6 |  | $ | 24.3 |  | $ | 2.9 |  | $ | (15.6) |  | $ | 56.2 |  |
| % Operating Income To Net Sales | 15.9 | % | 28.4 | % | 1.9 | % |  | 11.5 | % |

[0000038725-24-000010:8k_2_02:52]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year 2023 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 196.6 |  | $ | 92.7 |  | $ | 34.3 |  | $ | (61.2) |  | $ | 262.4 |  |
| % Operating Income To Net Sales | 16.3 | % | 31.3 | % | 5.1 | % |  | 12.7 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year 2022 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 172.3 |  | $ | 96.8 |  | $ | 54.5 |  | $ | (66.4) |  | $ | 257.2 |  |
| % Operating Income To Net Sales | 14.9 | % | 29.0 | % | 8.2 | % |  | 12.6 | % |
