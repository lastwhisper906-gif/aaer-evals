# FELE 10-K controls and the auditor's report


## auditors_report

[0000038725-24-000038:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000038725-24-000038:auditors_report:2]
To the shareholders and the Board of Directors of Franklin Electric Co., Inc.

[0000038725-24-000038:auditors_report:3]
Opinion on the Financial Statements

[0000038725-24-000038:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Franklin Electric Co., Inc. and subsidiaries (the "Company") as of December 31, 2023 and 2022, the related consolidated statements of income, comprehensive income, equity, and cash flows, for each of the three years in the period ended December 31, 2023, and the related notes and the schedule listed in the Index at Item 15 (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of December 31, 2023 and 2022, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2023, in conformity with accounting principles generally accepted in the United States of America.

[0000038725-24-000038:auditors_report:5]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of December 31, 2023, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated February 23, 2024, expressed an unqualified opinion on the Company's internal control over financial reporting.

[0000038725-24-000038:auditors_report:6]
Basis for Opinion

[0000038725-24-000038:auditors_report:7]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000038725-24-000038:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0000038725-24-000038:auditors_report:9]
Critical Audit Matter

[0000038725-24-000038:auditors_report:10]
The critical audit matter communicated below is a matter arising from the current-period audit of the financial statements that was communicated or required to be communicated to the audit committee and that (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000038725-24-000038:auditors_report:11]
Income Taxes – Uncertain Tax Positions — Refer to Notes 1 and 9 to the financial statements

[0000038725-24-000038:auditors_report:12]
Critical Audit Matter Description

[0000038725-24-000038:auditors_report:13]
The Company’s operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions. The Company records a liability for uncertain tax positions by establishing a more likely than not recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return. Accruals for income tax uncertainties represent estimates that are subject to the inherent uncertainties associated with the tax audit process.

[0000038725-24-000038:auditors_report:14]
Because of the numerous taxing jurisdictions in which the Company files its tax returns and the complexity of tax laws and regulations, auditing uncertain tax positions and the determination of whether the more likely than not threshold was met requires a high degree of auditor judgment and increased extent of effort, including the involvement of our income tax specialists.

[0000038725-24-000038:auditors_report:15]
52

[0000038725-24-000038:auditors_report:16]
How the Critical Audit Matter Was Addressed in the Audit

[0000038725-24-000038:auditors_report:17]
Our audit procedures related to unrecognized tax benefits included the following, among others:

[0000038725-24-000038:auditors_report:18]
•We tested the effectiveness of controls over income taxes, including those over identifying uncertain tax positions.

[0000038725-24-000038:auditors_report:19]
•We evaluated, with the assistance of our tax specialists, a selection of the Company’s uncertain tax positions and the Company’s application of the more likely than not principle by performing the following:

[0000038725-24-000038:auditors_report:20]
•Obtaining management memoranda, including their third-party specialist memoranda, regarding the analysis of uncertain tax positions and identifying the key judgments and evaluating whether the analysis was consistent with our interpretation of the relevant laws and regulations.

[0000038725-24-000038:auditors_report:21]
•Evaluating the matters raised by tax authorities in former and ongoing tax examinations and considering the implications of these matters on open tax years.

[0000038725-24-000038:auditors_report:22]
•Assessing changes and interpretation of applicable tax law.

[0000038725-24-000038:auditors_report:23]
/s/DELOITTE & TOUCHE LLP

[0000038725-24-000038:auditors_report:24]
Chicago, Illinois

[0000038725-24-000038:auditors_report:25]
February 23, 2024

[0000038725-24-000038:auditors_report:26]
We have served as the Company’s auditor since 1988.

[0000038725-24-000038:auditors_report:27]
53


## item_9a

[0000038725-24-000038:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0000038725-24-000038:item_9a:2]
As of the end of the period covered by this report (the “Evaluation Date”), the Company carried out an evaluation, under the supervision and with the participation of the Company’s management, including the Company’s Chief Executive Officer and the Company’s Chief Financial Officer, of the effectiveness of the design and operation of the Company’s disclosure controls and procedures pursuant to Exchange Act Rules 13a-15. Based upon that evaluation, the Company’s Chief Executive Officer and the Company’s Chief Financial Officer concluded that, as of the Evaluation Date, the Company’s disclosure controls and procedures were effective.

[0000038725-24-000038:item_9a:3]
There have been no changes in the Company’s internal control over financial reporting identified in connection with the evaluation required by Rules 13a-15 under the Exchange Act during the last fiscal quarter that have materially affected, or are reasonably likely to materially affect the Company’s internal control over financial reporting.

[0000038725-24-000038:item_9a:4]
MANAGEMENT’S REPORT ON INTERNAL CONTROL OVER FINANCIAL REPORTING

[0000038725-24-000038:item_9a:5]
Management is responsible for establishing and maintaining an adequate system of internal control over financial reporting of the Company. This system is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with accounting principles generally accepted in the United States of America.

[0000038725-24-000038:item_9a:6]
The Company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the financial statements.

[0000038725-24-000038:item_9a:7]
Because of its inherent limitations, internal control over financial reporting can provide only reasonable assurance with respect to financial statement preparation and may not prevent or detect misstatements. Further, because of changes in conditions, effectiveness of internal controls over financial reporting may vary over time.

[0000038725-24-000038:item_9a:8]
Management conducted an evaluation of the effectiveness of the system of internal control over financial reporting based on the framework in the Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Management excluded Hydropompe S.r.l. as well as the asset acquisitions of Phil-Good Products, Inc., Aqua Systems of Fort Myers, Action Manufacturing and Supply, Inc, and LCA Pump, LLC (Note 3 - Acquisitions) from its assessment of internal controls over financial reporting as the acquisition occurred in 2023. This exclusion is in accordance with the general guidance from the Staff of the Securities and Exchange Commission that an assessment of a recently acquired business may be omitted from the scope of management’s assessment of internal control over financial reporting for one year following the acquisition. The net sales and total assets of the current year acquisitions represented less than 1 percent and 2.6 percent of the consolidated financial statement amounts as of and for the year ended December 31, 2023. Based on its evaluation, management concluded that the Company’s system of internal control over financial reporting was effective as of December 31, 2023.

[0000038725-24-000038:item_9a:9]
Our independent registered public accounting firm has issued an audit report on the effectiveness of the Company’s internal control over financial reporting as of December 31, 2023. This report appears on page 55.

[0000038725-24-000038:item_9a:10]
54

[0000038725-24-000038:item_9a:11]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000038725-24-000038:item_9a:12]
To the shareholders and the Board of Directors of Franklin Electric Co., Inc.

[0000038725-24-000038:item_9a:13]
Opinion on Internal Control over Financial Reporting

[0000038725-24-000038:item_9a:14]
We have audited the internal control over financial reporting of Franklin Electric Co., Inc. and subsidiaries (the “Company”) as of December 31, 2023, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2023, based on criteria established in Internal Control — Integrated Framework (2013) issued by COSO.

[0000038725-24-000038:item_9a:15]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended December 31, 2023, of the Company and our report dated February 23, 2024, expressed an unqualified opinion on those financial statements.

[0000038725-24-000038:item_9a:16]
As described in Management’s Report on Internal Control over Financial Reporting, management excluded from its assessment the internal control over financial reporting at Hydropompe S.r.l. as well as the asset acquisitions of Phil-Good Products, Inc., Aqua Systems of Fort Myers, Action Manufacturing and Supply, Inc, and LCA Pump, LLC, which were acquired in 2023. These acquired businesses constitute less than 1% and 2.6% of net sales and total assets, respectively, of the consolidated financial statements of the Company as of and for the year ended December 31, 2023. Accordingly, our audit did not include the internal control over financial reporting at these acquired businesses.

[0000038725-24-000038:item_9a:17]
Basis for Opinion

[0000038725-24-000038:item_9a:18]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000038725-24-000038:item_9a:19]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000038725-24-000038:item_9a:20]
Definition and Limitations of Internal Control over Financial Reporting

[0000038725-24-000038:item_9a:21]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000038725-24-000038:item_9a:22]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000038725-24-000038:item_9a:23]
/s/ DELOITTE & TOUCHE LLP

[0000038725-24-000038:item_9a:24]
Chicago, Illinois

[0000038725-24-000038:item_9a:25]
February 23, 2024

[0000038725-24-000038:item_9a:26]
55
