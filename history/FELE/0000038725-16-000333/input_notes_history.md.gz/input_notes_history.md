# FELE note change history — 0000038725-15-000195 → 0000038725-16-000333


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2016-05-10):
[0000038725-16-000333:note_history:1]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be successfully defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

- changed (2016-05-10):
[0000038725-16-000333:note_history:2]
At April 2, 2016, the Company had $18.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2015-11-03, similarity 0.9658):
[0000038725-15-000195:note_history:2]
At October 3, 2015, the Company had $12.4 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2016-05-10):
[0000038725-16-000333:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended April 2, 2016, are as follows:
  (was, 2015-11-03, similarity 0.8958):
[0000038725-15-000195:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended October 3, 2015, are as follows:

- changed (2016-05-10):
[0000038725-16-000333:note_history:4]
| (In millions) |  |  |
| Balance as of January 2, 2016 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 1.2 |  |
| Reductions for payments made |  | (1.7 | ) |
| Balance as of April 2, 2016 |  | $ | 8.8 |  |
  (was, 2015-11-03, similarity 0.9698):
[0000038725-15-000195:note_history:4]
| (In millions) |  |  |
| Balance as of January 3, 2015 |  | $ | 9.4 |  |
| Accruals related to product warranties |  | 5.5 |  |
| Reductions for payments made |  | (5.8 | ) |
| Balance as of October 3, 2015 |  | $ | 9.1 |  |

- removed (2016-05-10):
[0000038725-15-000195:note_history:5]
In August 2010, the California Air Resources Board (“CARB”) and South Coast Air Quality Management District (“SCAQMD”) filed civil complaints in the Los Angeles Superior Court against the Company and Franklin Fueling Systems, Inc.  The complaints related to a third-party-supplied component part of the Company's Healy 900 Series nozzle, which is part of the Company's Enhanced Vapor Recovery (“EVR”) Systems installed in California gasoline filling stations.  This part, a diaphragm, was the subject of a retrofit during the first half of 2008.  As the Company previously reported, in October 2008 CARB issued a Notice of Violation to the Company alleging that the circumstances leading to the retrofit program violated California statutes and regulations.

- removed (2016-05-10):
[0000038725-15-000195:note_history:6]
The claims in the complaints mirrored those that CARB presented to the Company in the Notice of Violation, and included claims that the Company negligently and intentionally sold nozzles with a modified diaphragm without required CARB certification. Those complaints were consolidated into one case in the Superior Court of California, County of Los Angeles (People of the State of California vs. Franklin Fueling Systems, Inc. et al.) which was tried in the later part of December 2012 and early part of January 2013 (“CARB Case”).

- removed (2016-05-10):
[0000038725-15-000195:note_history:7]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company filed its response brief on December 23, 2014 and CARB filed its Reply brief on February 2, 2015.  On September 29, 2015, both sides made oral arguments in front of the California Court of Appeals. The Appellate Court has ninety days to issue a ruling.

- removed (2016-05-10):
[0000038725-15-000195:note_history:8]
Neither of these suits has had any effect on CARB's certification of the Company's EVR System or any other products of the Company or its subsidiaries, and did not interfere with continuing sales.  CARB has never decertified the Company's EVR System and has never proposed to do so.

- removed (2016-05-10):
[0000038725-15-000195:note_history:9]
The Company is defending various other claims and legal actions, including environmental matters, which have arisen in the

- removed (2016-05-10):
[0000038725-15-000195:note_history:10]
ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with

- removed (2016-05-10):
[0000038725-15-000195:note_history:11]
counsel, these claims and legal actions can be successfully defended or resolved without a material effect on the

- removed (2016-05-10):
[0000038725-15-000195:note_history:12]
Company’s financial position, results of operations, and net cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-10):
[0000038725-16-000333:note_history:13]
The accompanying condensed consolidated balance sheet as of January 2, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of April 2, 2016, and for the first quarters ended April 2, 2016 and April 4, 2015 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended April 2, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2016.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended January 2, 2016.
  (was, 2015-11-03, similarity 0.8588):
[0000038725-15-000195:note_history:13]
The accompanying condensed consolidated balance sheet as of January 3, 2015, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of October 3, 2015, and for the third quarter and nine months ended October 3, 2015 and September 27, 2014, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the third quarter and nine months ended October 3, 2015, are not necessarily indicative of the results that may be expected for the fiscal year ending January 2, 2016.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K for the year ended January 3, 2015.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-10):
[0000038725-16-000333:note_history:14]
| (In millions) |  | April 2, 2016 |  | January 2, 2016 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 120.0 |  |
| Tax increment financing debt |  | 22.3 |  |  | 22.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 11.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.0 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 232.6 |  |  | $ | 220.7 |  |
| Less: current maturities |  | (45.3 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 187.3 |  |  | $ | 187.8 |  |
  (was, 2015-11-03, similarity 0.8815):
[0000038725-15-000195:note_history:14]
| (In millions) |  | October 3, 2015 |  | January 3, 2015 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 22.8 |  |  | 23.7 |  |
| New York Life |  | 75.0 |  |  | — |  |
| Revolver |  | 20.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 4.9 |  |  | 3.5 |  |
|  |  | $ | 243.3 |  |  | 177.8 |  |
| Less current maturities |  | (55.1 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 188.2 |  |  | $ | 143.7 |  |

- added (2016-05-10):
[0000038725-16-000333:note_history:15]
During the first quarter ended April 2, 2016, a portion of the revolver borrowing was used for seasonal working capital needs.

- added (2016-05-10):
[0000038725-16-000333:note_history:16]
Debt outstanding, excluding unamortized debt issuance costs, at April 2, 2016 matures as follows:

- changed (2016-05-10):
[0000038725-16-000333:note_history:17]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 232.8 |  |  | $ | 45.3 |  |  | $ | 31.1 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 92.6 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 232.9 |  |  | $ | 45.3 |  |  | $ | 31.2 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 92.6 |  |
  (was, 2015-11-03, similarity 0.6306):
[0000038725-15-000195:note_history:17]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 243.2 |  |  | $ | 55.0 |  |  | $ | 31.5 |  |  | $ | 31.0 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 93.2 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 243.3 |  |  | $ | 55.1 |  |  | $ | 31.5 |  |  | $ | 31.0 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 93.2 |  |

- removed (2016-05-10):
[0000038725-15-000195:note_history:18]
On May 5, 2015, the Company executed the following amendments: Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc.; Amendment No. 3 to the Credit Agreement; and Amendment No. 1 to the Bond Purchase and Loan Agreement.  Each of those amendments provides for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

- removed (2016-05-10):
[0000038725-15-000195:note_history:19]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025.  These series notes have a floating interest rate of one-month USD LIBOR plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  The New York Life Agreement contains customary affirmative and negative covenants and a cross default provision in the event the Company defaults on any obligation exceeding $10.0 million.  As of October 3, 2015, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

- removed (2016-05-10):
[0000038725-15-000195:note_history:20]
On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc. (the "Prudential Agreement") to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of October 3, 2015, $120.0 million was outstanding under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.  As of October 3, 2015, the Company had $100.0 million borrowing capacity under the Prudential Agreement.

- removed (2016-05-10):
[0000038725-15-000195:note_history:21]
The following debt payments are expected to be paid in accordance with the following schedule:


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-10):
[0000038725-16-000333:note_history:22]
| (In millions) |  | April 2, 2016 |  | January 2, 2016 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 120.0 |  |
| Tax increment financing debt |  | 22.3 |  |  | 22.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 11.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.0 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 232.6 |  |  | $ | 220.7 |  |
| Less: current maturities |  | (45.3 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 187.3 |  |  | $ | 187.8 |  |
  (was, 2015-11-03, similarity 0.8815):
[0000038725-15-000195:note_history:22]
| (In millions) |  | October 3, 2015 |  | January 3, 2015 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 22.8 |  |  | 23.7 |  |
| New York Life |  | 75.0 |  |  | — |  |
| Revolver |  | 20.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 4.9 |  |  | 3.5 |  |
|  |  | $ | 243.3 |  |  | 177.8 |  |
| Less current maturities |  | (55.1 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 188.2 |  |  | $ | 143.7 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-05-10):
[0000038725-16-000333:note_history:23]
Debt outstanding, excluding unamortized debt issuance costs, at April 2, 2016 matures as follows:

- changed (2016-05-10):
[0000038725-16-000333:note_history:24]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 232.8 |  |  | $ | 45.3 |  |  | $ | 31.1 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 92.6 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 232.9 |  |  | $ | 45.3 |  |  | $ | 31.2 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 92.6 |  |
  (was, 2015-11-03, similarity 0.6306):
[0000038725-15-000195:note_history:24]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 243.2 |  |  | $ | 55.0 |  |  | $ | 31.5 |  |  | $ | 31.0 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 93.2 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 243.3 |  |  | $ | 55.1 |  |  | $ | 31.5 |  |  | $ | 31.0 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 93.2 |  |

- removed (2016-05-10):
[0000038725-15-000195:note_history:25]
The following debt payments are expected to be paid in accordance with the following schedule:
