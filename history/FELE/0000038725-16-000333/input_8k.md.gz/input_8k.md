# FELE 8-K — 0000038725-16-000308 filed 2016-05-02

## item codes, every 8-K on or before 2016-05-10

- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2016-05-10

- none on or before 2016-05-10

## item 2.02 — earnings release, exhibit 99.1

[0000038725-16-000308:8k_2_02:1]
EX-99.1
2
a201605028-kexhibit991.htm
EXHIBIT 99.1

[0000038725-16-000308:8k_2_02:2]
Exhibit

[0000038725-16-000308:8k_2_02:3]
Exhibit 99.1

[0000038725-16-000308:8k_2_02:4]
For Immediate Release

[0000038725-16-000308:8k_2_02:5]
For Further Information

[0000038725-16-000308:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-16-000308:8k_2_02:7]
260-824-2900

[0000038725-16-000308:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS FIRST QUARTER

[0000038725-16-000308:8k_2_02:9]
2016 SALES AND EARNINGS

[0000038725-16-000308:8k_2_02:10]
Fort Wayne, Indiana - May 2, 2016 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported first quarter 2016 adjusted earnings per share (EPS) of $0.29 compared to 2015 first quarter adjusted EPS of $0.32, a 9 percent decrease (see table below for a reconciliation of GAAP EPS to the adjusted EPS).  In the first quarter of 2016, the Company’s GAAP fully diluted EPS was $0.28, down versus the GAAP fully diluted EPS of $0.41 from the first quarter of 2015.

[0000038725-16-000308:8k_2_02:11]
First quarter 2016 sales were $218.4 million, a decrease of 3 percent compared to 2015 first quarter sales of $225.7 million.  The Company’s organic sales growth was 3 percent excluding the impact of foreign currency translation.

[0000038725-16-000308:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-16-000308:8k_2_02:13]
“Our company delivered solid results in the first quarter led by the improved profitability of our U.S. Water business and record performance in our Fueling Systems business. Excluding the impact of foreign exchange, we achieved 3 percent organic growth in the first quarter of 2016, growing both our Water and Fueling Systems segments. Adjusted operating income increased 33 percent as we realized the continuing benefits of improved costs, sales mix and pricing. After non-GAAP adjustments, Water Systems operating income increased 25 percent on a reported 6 percent sales decline. Water system operating margins increased sequentially and increased 360 basis points compared to the first quarter 2015. Fueling Systems operating income increased 8 percent on a 7 percent sales increase.”

[0000038725-16-000308:8k_2_02:14]
Key Performance Indicators:

[0000038725-16-000308:8k_2_02:15]
| Earnings Before and After Non-GAAP Adjustments |  | For the First Quarter |
| (in millions) |  | 2016 | 2015 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 13.5 |  | $ | 19.8 |  | (32 | )% |
| Allocated Undistributed Earnings |  | $ | (0.6 | ) | $ | (0.3 | ) |  |
| Adjusted Earnings for EPS Calculations |  | $ | 12.9 |  | $ | 19.5 |  | (34 | )% |
| Non-GAAP adjustments (before tax): |  |  |  |  |
| Restructuring |  | $ | 0.8 |  | $ | 0.5 |  |  |
| Non-GAAP items |  | $ | 0.3 |  | $ | 0.3 |  |  |
| Pioneer tax benefits on equity gain |  | $ | — |  | $ | (4.8 | ) |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |
| Restructuring |  | $ | 0.5 |  | $ | 0.3 |  |  |
| Non-GAAP items |  | $ | 0.2 |  | $ | 0.2 |  |  |
| Pioneer tax benefits on equity gain |  | $ | — |  | $ | (4.8 | ) |  |
| Earnings after Non-GAAP Adjustments |  | $ | 13.6 |  | $ | 15.2 |  | (11 | )% |
| Earnings Per Share |  | For the First Quarter |
| Before and After Non-GAAP Adjustments |  | 2016 | 2015 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.4 |  | 48.1 |  | (4 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.28 |  | $ | 0.41 |  | (32 | )% |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | 0.01 |  |  |
| Non-GAAP items, net of tax |  | $ | — |  | $ | — |  |  |
| Pioneer tax benefits on equity gain |  | $ | — |  | $ | (0.10 | ) |  |
| Fully Diluted EPS after Non-GAAP Adjustments(Adjusted EPS) |  | $ | 0.29 |  | $ | 0.32 |  | (9 | )% |

[0000038725-16-000308:8k_2_02:16]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Consolidated |
| Q1 2015 | $ | 79.6 |  | $ | 36.3 |  | $ | 44.2 |  | $ | 19.1 |  | $ | 179.2 |  | $ | 46.5 |  | $ | 225.7 |  |
| Q1 2016 | $ | 78.1 |  | $ | 27.2 |  | $ | 42.2 |  | $ | 21.3 |  | $ | 168.8 |  | $ | 49.6 |  | $ | 218.4 |  |
| Change | $ | (1.5 | ) | $ | (9.1 | ) | $ | (2.0 | ) | $ | 2.2 |  | $ | (10.4 | ) | $ | 3.1 |  | $ | (7.3 | ) |
| % Change | (2 | )% | (25 | )% | (5 | )% | 12 | % | (6 | )% | 7 | % | (3 | )% |
| Foreign currency translation | $ | (1.1 | ) | $ | (7.1 | ) | $ | (4.6 | ) | $ | (0.5 | ) | $ | (13.3 | ) | $ | (0.5 | ) | $ | (13.8 | ) |
| % Change | (1 | )% | (20 | )% | (10 | )% | (3 | )% | (7 | )% | (1 | )% | (6 | )% |
| Volume/Price | $ | (0.4 | ) | $ | (2.0 | ) | $ | 2.6 |  | $ | 2.7 |  | $ | 2.9 |  | $ | 3.6 |  | $ | 6.5 |  |
| % Change | (1 | )% | (5 | )% | 5 | % | 15 | % | 1 | % | 8 | % | 3 | % |

[0000038725-16-000308:8k_2_02:17]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the First Quarter 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 24.2 |  | $ | 10.2 |  | $ | (13.3 | ) | $ | 21.1 |  |
| % Operating Income To Net Sales | 14.3 | % | 20.6 | % |  | 9.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.4 |  | $ | 0.4 |  | $ | — |  | $ | 0.8 |  |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.3 |  | $ | 0.3 |  |
| Operating Income after Non-GAAP Adjustments | $ | 24.6 |  | $ | 10.6 |  | $ | (13.0 | ) | $ | 22.2 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.6 | % | 21.4 | % |  | 10.2 | % |
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the First Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 19.4 |  | $ | 9.6 |  | $ | (13.1 | ) | $ | 15.9 |  |
| % Operating Income To Net Sales | 10.8 | % | 20.6 | % |  | 7.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.3 |  | $ | 0.2 |  | $ | — |  | $ | 0.5 |  |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.3 |  | $ | 0.3 |  |
| Operating Income after Non-GAAP Adjustments | $ | 19.7 |  | $ | 9.8 |  | $ | (12.8 | ) | $ | 16.7 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 11.0 | % | 21.1 | % |  | 7.4 | % |

[0000038725-16-000308:8k_2_02:18]
Water Systems

[0000038725-16-000308:8k_2_02:19]
Water Systems sales were $168.8 million in the first quarter 2016, a decrease of $10.4 million or about 6 percent versus the first quarter 2015 sales of $179.2 million.  Foreign currency translation reduced Water Systems sales by $13.3 million or about 7 percent in the quarter.  Excluding foreign currency translation, Water Systems sales grew about 1 percent compared to the first quarter 2015.

[0000038725-16-000308:8k_2_02:20]
Water Systems sales in the U.S. and Canada were down about 1 percent compared to the prior year first quarter, excluding the impact of foreign currency. In the first quarter 2016, sales of groundwater pumping equipment grew by about 1 percent.  The growth in groundwater equipment sales was more than offset by a decline in sales of surface water pumping equipment, which declined by about 5 percent versus the first quarter 2015, primarily due to lower wastewater product sales.  Water Systems sales in markets outside the U.S. and Canada experienced overall growth of about 3 percent, after excluding the impact of foreign currency translation.  International Water Systems sales growth was led by improved groundwater product sales in the Asia Pacific and European markets, but was offset by a decline in sales in Latin America and Africa.

[0000038725-16-000308:8k_2_02:21]
Water Systems operating income, after non-GAAP adjustments, was $24.6 million in the first quarter 2016, up $4.9 million or 25 percent versus the first quarter 2015. The first quarter operating income margin after non-GAAP adjustments was 14.6 percent, up 360 basis points from 11.0 percent in the first quarter of 2015.

[0000038725-16-000308:8k_2_02:22]
Fueling Systems

[0000038725-16-000308:8k_2_02:23]
Fueling Systems sales were $49.6 million in the first quarter 2016, an increase of $3.1 million or about 7 percent versus the first quarter 2015 sales of $46.5 million.  Fueling Systems sales decreased by $0.5 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems sales were up about 8 percent, after excluding foreign currency translation.  Fueling Systems Sales and Adjusted Operating Income in the first quarter 2016 were a record for any first quarter in the history of the segment.

[0000038725-16-000308:8k_2_02:24]
Fueling Systems sales in the U.S. and Canada grew by about 8 percent during the quarter with most of the sales growth coming from pump and fuel management systems.  Fueling Systems revenues outside the U.S. were up slightly with strong results in India offsetting continued weakness in tank sales for North Sea oil production.

[0000038725-16-000308:8k_2_02:25]
Fueling Systems operating income after non-GAAP adjustments was $10.6 million in the first quarter of 2016 compared to $9.8 million after non-GAAP adjustments in the first quarter of 2015, an increase of about 8 percent. The first quarter operating income margin after non-GAAP adjustments was 21.4 percent, an increase of 30 basis points from the 21.1 percent of net sales in the first quarter of 2015.

[0000038725-16-000308:8k_2_02:26]
Overall

[0000038725-16-000308:8k_2_02:27]
The Company’s consolidated gross profit was $74.2 million for the first quarter of 2016, an increase of $2.7 million, or about 4 percent, from the first quarter of 2015 gross profit of $71.5 million. The gross profit as a percent of net sales was 34.0 percent in the first quarter of 2016 and increased about 230 basis points versus 31.7 percent during the first quarter 2015.  The gross profit margin increase was primarily due to favorable pricing, lower direct material costs and lower fixed cost.

[0000038725-16-000308:8k_2_02:28]
Selling, general, and administrative (SG&A) expenses were $52.3 million in the first quarter of 2016 compared to $55.2 million in the first quarter of the prior year, a decrease of $2.9 million or about 5 percent.  The Company’s SG&A expenses decreased by $2.5 million in the quarter due to lower costs from foreign exchange.

[0000038725-16-000308:8k_2_02:29]
Adjusted earnings per share for the first quarter of 2016 are about 9 percent less than the first quarter of the prior year primarily due to the non-recurrence of benefits recorded below operating income from the Pioneer acquisition in the first quarter of 2015. The Company purchased the remaining outstanding shares of Pioneer Pump and realized a gain on the liability of about $2.7 million that was included in ‘Other income’.  This transaction also created tax benefits of about $3.5 million, which offset income tax expense and resulted in an overall net tax benefit in the first quarter 2015.  The impact of this transaction was an increase to adjusted earnings per share in the first quarter 2015 of about $0.10.

[0000038725-16-000308:8k_2_02:30]
The Company ended the first quarter of 2016 with a cash balance of $74.6 million, which was $7.0 million lower than at the end of 2015.  The cash balance decreased primarily due to higher capital expenditures in the first quarter and reduced borrowing on the Company’s revolving line of credit.

[0000038725-16-000308:8k_2_02:31]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-16-000308:8k_2_02:32]
“As we outlined last quarter, we continue to be challenged with an exchange rate headwind, however, global currencies have strengthened over the last quarter relative to the U.S. dollar. We are raising our full year 2016 earnings per share guidance to a range of $1.60 and $1.70 to reflect this change in exchange rates.”

[0000038725-16-000308:8k_2_02:33]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The first quarter 2016 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-16-000308:8k_2_02:34]
http://edge.media-server.com/m/p/wynrjho5

[0000038725-16-000308:8k_2_02:35]
If you intend to ask questions during the call, please dial in using (877) 643-7158 for domestic calls and (914) 495-8565 for international calls.  The conference ID is: 90665870.

[0000038725-16-000308:8k_2_02:36]
A replay of the conference call will be available Monday, May 2, 2016 at 12:00 noon EDT through midnight EDT on Monday, May 9, 2016, by dialing (855) 859-2056 for domestic calls and (404) 537-3406 for international calls. The replay passcode is: 90665870.

[0000038725-16-000308:8k_2_02:37]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-16-000308:8k_2_02:38]
The Company presents the non-GAAP financial measures of earnings after non-GAAP adjustments, fully diluted earnings per share after non-GAAP adjustments (or adjusted EPS), operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments (or operating income margin after non-GAAP adjustments) because the Company believes the information helps investors understand underlying trends in the Company's business more easily. The differences between these measures and the most comparable GAAP measures are reconciled in the tables above.

[0000038725-16-000308:8k_2_02:39]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |
|  | First Quarter Ended |
|  | April 2, 2016 |  | April 4, 2015 |
| Net sales | $ | 218,430 |  |  | $ | 225,728 |  |
| Cost of sales | 144,194 |  |  | 154,238 |  |
| Gross profit | 74,236 |  |  | 71,490 |  |
| Selling, general, and administrative expenses | 52,345 |  |  | 55,160 |  |
| Restructuring expense | 820 |  |  | 463 |  |
| Operating income | 21,071 |  |  | 15,867 |  |
| Interest expense | (2,427 | ) |  | (2,708 | ) |
| Other income/(expense), net | (32 | ) |  | 3,019 |  |
| Foreign exchange income/(expense) | (77 | ) |  | 416 |  |
| Income before income taxes | 18,535 |  |  | 16,594 |  |
| Income tax (benefit)/expense | 4,955 |  |  | (3,382 | ) |
| Net income | $ | 13,580 |  |  | $ | 19,976 |  |
| Less: Net income attributable to noncontrolling interests | (123 | ) |  | (181 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 13,457 |  |  | $ | 19,795 |  |
| Income per share: |  |  |  |
| Basic | $ | 0.28 |  |  | $ | 0.41 |  |
| Diluted | $ | 0.28 |  |  | $ | 0.41 |  |

[0000038725-16-000308:8k_2_02:40]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | April 2, 2016 |  | January 2, 2016 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 74,642 |  |  | $ | 81,561 |  |
| Receivables | 151,173 |  |  | 127,251 |  |
| Inventories | 207,741 |  |  | 194,594 |  |
| Other current assets | 30,617 |  |  | 34,715 |  |
| Total current assets | 464,173 |  |  | 438,121 |  |
| Property, plant, and equipment, net | 194,756 |  |  | 190,039 |  |
| Goodwill and other assets | 373,594 |  |  | 367,951 |  |
| Total assets | $ | 1,032,523 |  |  | $ | 996,111 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 62,568 |  |  | $ | 57,822 |  |
| Accrued expenses and other current liabilities | 49,222 |  |  | 53,903 |  |
| Current maturities of long-term debt and short-term borrowings | 45,337 |  |  | 32,946 |  |
| Total current liabilities | 157,127 |  |  | 144,671 |  |
| Long-term debt | 187,257 |  |  | 187,806 |  |
| Deferred income taxes | 36,025 |  |  | 33,404 |  |
| Employee benefit plans | 46,799 |  |  | 47,398 |  |
| Other long-term liabilities | 17,656 |  |  | 16,511 |  |
| Redeemable noncontrolling interest | 7,329 |  |  | 6,856 |  |
| Total equity | 580,330 |  |  | 559,465 |  |
| Total liabilities and equity | $ | 1,032,523 |  |  | $ | 996,111 |  |

[0000038725-16-000308:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | First Quarter Ended |
| (In thousands) | April 2, 2016 |  | April 4, 2015 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 13,580 |  |  | $ | 19,976 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 8,752 |  |  | 8,840 |  |
| Share-based compensation | 2,539 |  |  | 2,354 |  |
| Realized gain on share purchase liability | — |  |  | (2,723 | ) |
| Other | 1,709 |  |  | (7,425 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (20,609 | ) |  | (17,901 | ) |
| Inventory | (8,884 | ) |  | (7,360 | ) |
| Accounts payable and accrued expenses | (3,649 | ) |  | (18,081 | ) |
| Other | 6,125 |  |  | 504 |  |
| Net cash flows from operating activities | (437 | ) |  | (21,816 | ) |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (11,153 | ) |  | (4,205 | ) |
| Proceeds from sale of property, plant, and equipment | 185 |  |  | 8 |  |
| Acquisitions and investments | — |  |  | (3,616 | ) |
| Net cash flows from investing activities | (10,968 | ) |  | (7,813 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 11,789 |  |  | 68,813 |  |
| Proceeds from issuance of common stock | 411 |  |  | 883 |  |
| Excess tax from share-based payment arrangements | 53 |  |  | 515 |  |
| Purchases of common stock | (4,175 | ) |  | (2,288 | ) |
| Dividends paid | (4,506 | ) |  | (4,283 | ) |
| Share purchase liability payment | — |  |  | (20,200 | ) |
| Net cash flows from financing activities | 3,572 |  |  | 43,440 |  |
| Effect of exchange rate changes on cash | 914 |  |  | (3,359 | ) |
| Net change in cash and equivalents | (6,919 | ) |  | 10,452 |  |
| Cash and equivalents at beginning of period | 81,561 |  |  | 59,141 |  |
| Cash and equivalents at end of period | $ | 74,642 |  |  | $ | 69,593 |  |
