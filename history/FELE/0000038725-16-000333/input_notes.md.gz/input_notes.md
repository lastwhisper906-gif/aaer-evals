# FELE notes — 0000038725-16-000333


## fele:DisclosureOfShareBasedCompensationArrangementsAuthorizedSharesTableTextBlock

[0000038725-16-000333:notes:1]
[same as prior period, unchanged from 0000038725-15-000195:notes:1]

[0000038725-16-000333:notes:2]
[same as prior period, unchanged from 0000038725-15-000195:notes:2]

[0000038725-16-000333:notes:3]
[same as prior period, unchanged from 0000038725-15-000195:notes:3]

[0000038725-16-000333:notes:4]
[same as prior period, unchanged from 0000038725-15-000195:notes:4]


## fele:ScheduleOfFiniteAndIndefiniteLivedIntangibleAssetsTableTextBlock

[0000038725-16-000333:notes:5]
[same as prior period, unchanged from 0000038725-15-000195:notes:5]

[0000038725-16-000333:notes:6]
| (In millions) |  | April 2, 2016 |  | January 2, 2016 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.3 | ) |  | $ | 7.4 |  |  | $ | (6.2 | ) |
| Technology |  | 7.5 |  |  | (4.9 | ) |  | 7.5 |  |  | (4.8 | ) |
| Customer relationships |  | 134.5 |  |  | (44.7 | ) |  | 132.6 |  |  | (42.3 | ) |
| Software |  | 2.5 |  |  | (1.7 | ) |  | 2.5 |  |  | (1.7 | ) |
| Other |  | 0.3 |  |  | (0.3 | ) |  | 1.0 |  |  | (1.0 | ) |
| Total |  | $ | 152.3 |  |  | $ | (57.9 | ) |  | $ | 151.0 |  |  | $ | (56.0 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 47.1 |  |  | — |  |  | 46.4 |  |  | — |  |
| Total intangibles |  | $ | 199.4 |  |  | $ | (57.9 | ) |  | $ | 197.4 |  |  | $ | (56.0 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000038725-16-000333:notes:7]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be successfully defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-16-000333:notes:8]
At April 2, 2016, the Company had $18.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-16-000333:notes:9]
The Company provides warranties on most of its products.  The warranty terms vary but are generally 2 years from date of manufacture or 1 year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to 5 years from date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-16-000333:notes:10]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended April 2, 2016, are as follows:

[0000038725-16-000333:notes:11]
| (In millions) |  |  |
| Balance as of January 2, 2016 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 1.2 |  |
| Reductions for payments made |  | (1.7 | ) |
| Balance as of April 2, 2016 |  | $ | 8.8 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-16-000333:notes:12]
[same as prior period, unchanged from 0000038725-15-000195:notes:26]

[0000038725-16-000333:notes:13]
Changes in accumulated other comprehensive income/(loss) by component for the first quarters ended April 2, 2016 and April 4, 2015, are summarized below:

[0000038725-16-000333:notes:14]
| (In millions) |  |  |  |  |  |
| For the first quarter ended April 2, 2016: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance as of January 2, 2016 | $ | (110.1 | ) |  | $ | (51.5 | ) |  | $ | (161.6 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | 13.1 |  |  | — |  |  | 13.1 |  |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | 13.1 |  |  | — |  |  | 13.1 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income/(loss) | — |  |  | 0.7 |  | (1) | 0.7 |  |
| Income tax (expense)/benefit | — |  |  | (0.3 | ) |  | (0.3 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 0.4 |  |  | 0.4 |  |
| Net current period other comprehensive income/(loss), net of income taxes | 13.1 |  |  | 0.4 |  |  | 13.5 |  |
| Less: Other comprehensive income/(loss) attributable to noncontrolling interests | 0.1 |  |  | — |  |  | 0.1 |  |
| Balance as of April 2, 2016 | $ | (97.1 | ) |  | $ | (51.1 | ) |  | $ | (148.2 | ) |
| For the first quarter ended April 4, 2015: |  |  |  |  |  |
| Balance as of January 3, 2015 | $ | (51.8 | ) |  | $ | (56.1 | ) |  | $ | (107.9 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (27.8 | ) |  | — |  |  | (27.8 | ) |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (27.8 | ) |  | — |  |  | (27.8 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income/(loss) | — |  |  | 1.0 |  | (1) | 1.0 |  |
| Income tax (expense)/benefit | — |  |  | (0.4 | ) |  | (0.4 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 0.6 |  |  | 0.6 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (27.8 | ) |  | 0.6 |  |  | (27.2 | ) |
| Less: Other comprehensive income/(loss) attributable to noncontrolling interests | (0.3 | ) |  | — |  |  | (0.3 | ) |
| Balance as of April 4, 2015 | $ | (79.3 | ) |  | $ | (55.5 | ) |  | $ | (134.8 | ) |

[0000038725-16-000333:notes:15]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 7 for additional details) and is included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income.


## us-gaap:DebtDisclosureTextBlock

[0000038725-16-000333:notes:16]
DEBT

[0000038725-16-000333:notes:17]
Debt consisted of the following:

[0000038725-16-000333:notes:18]
| (In millions) |  | April 2, 2016 |  | January 2, 2016 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 120.0 |  |
| Tax increment financing debt |  | 22.3 |  |  | 22.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 11.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.0 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 232.6 |  |  | $ | 220.7 |  |
| Less: current maturities |  | (45.3 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 187.3 |  |  | $ | 187.8 |  |

[0000038725-16-000333:notes:19]
During the first quarter ended April 2, 2016, a portion of the revolver borrowing was used for seasonal working capital needs.

[0000038725-16-000333:notes:20]
Debt outstanding, excluding unamortized debt issuance costs, at April 2, 2016 matures as follows:

[0000038725-16-000333:notes:21]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 232.8 |  |  | $ | 45.3 |  |  | $ | 31.1 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 92.6 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 232.9 |  |  | $ | 45.3 |  |  | $ | 31.2 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 92.6 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-16-000333:notes:22]
[same as prior period, unchanged from 0000038725-15-000195:notes:38]

[0000038725-16-000333:notes:23]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  During February 2014, the Company entered into a share swap transaction agreement ("the swap") to mitigate the Company’s exposure to these fluctuations in the Company's stock price.  The swap was not designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  As of April 2, 2016, the swap has a notional value based on 175,000 shares.  For the first quarters ended April 2, 2016 and April 4, 2015, the swap resulted in a gain of $0.8 million and a loss of $0.1 million, respectively.  Gains and losses on the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-16-000333:notes:24]
[same as prior period, unchanged from 0000038725-15-000195:notes:40]

[0000038725-16-000333:notes:25]
[same as prior period, unchanged from 0000038725-15-000195:notes:41]

[0000038725-16-000333:notes:26]
[same as prior period, unchanged from 0000038725-15-000195:notes:42]

[0000038725-16-000333:notes:27]
[same as prior period, unchanged from 0000038725-15-000195:notes:43]

[0000038725-16-000333:notes:28]
[same as prior period, unchanged from 0000038725-15-000195:notes:44]

[0000038725-16-000333:notes:29]
[same as prior period, unchanged from 0000038725-15-000195:notes:45]

[0000038725-16-000333:notes:30]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the first quarters ended April 2, 2016 and April 4, 2015 are as follows:

[0000038725-16-000333:notes:31]
|  |  | April 2, 2016 |  | April 4, 2015 |
| Risk-free interest rate |  | 1.21 | % |  | 1.59 | % |
| Dividend yield |  | 1.32 | % |  | 0.95 | % |
| Volatility factor |  | 0.377 |  |  | 0.379 |  |
| Expected term |  | 5.5 years |  |  | 5.5 years |  |
| Forfeiture rate |  | 3.77 | % |  | 3.67 | % |

[0000038725-16-000333:notes:32]
There were 265,270 and 184,706 stock options granted during the first quarters ended April 2, 2016 and April 4, 2015, respectively.

[0000038725-16-000333:notes:33]
A summary of the Company’s outstanding stock option activity and related information for the first quarters ended April 2, 2016 and April 4, 2015 is as follows:

[0000038725-16-000333:notes:34]
| (Shares in thousands) |  | April 2, 2016 |  | April 4, 2015 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,472 |  |  | $ | 23.26 |  |  | 1,397 |  |  | $ | 21.17 |  |
| Granted |  | 265 |  |  | 29.08 |  |  | 185 |  |  | 36.67 |  |
| Exercised |  | (21 | ) |  | 18.98 |  |  | (46 | ) |  | 19.36 |  |
| Outstanding at end of period |  | 1,716 |  |  | $ | 24.22 |  |  | 1,536 |  |  | $ | 23.09 |  |
| Expected to vest after applying forfeiture rate |  | 1,680 |  |  | $ | 24.05 |  |  | 1,511 |  |  | $ | 22.86 |  |
| Vested and exercisable at end of period |  | 1,183 |  |  | $ | 20.54 |  |  | 1,124 |  |  | $ | 18.75 |  |

[0000038725-16-000333:notes:35]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of April 2, 2016 is as follows:

[0000038725-16-000333:notes:36]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.82 years |  | $ | 15,402 |  |
| Expected to vest after applying forfeiture rate |  | 5.74 years |  | $ | 15,338 |  |
| Vested and exercisable at end of period |  | 4.39 years |  | $ | 14,348 |  |

[0000038725-16-000333:notes:37]
The total intrinsic value of options exercised during the first quarters ended April 2, 2016 and April 4, 2015 was $0.2 million and $0.8 million, respectively.

[0000038725-16-000333:notes:38]
As of April 2, 2016, there was $2.5 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.72 years.

[0000038725-16-000333:notes:39]
[same as prior period, unchanged from 0000038725-15-000195:notes:55]

[0000038725-16-000333:notes:40]
A summary of the Company’s restricted stock/stock unit award activity and related information for the first quarters ended April 2, 2016 and April 4, 2015 is as follows:

[0000038725-16-000333:notes:41]
| (Shares in thousands) |  | April 2, 2016 |  | April 4, 2015 |
| Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 510 |  |  | $ | 34.43 |  |  | 554 |  |  | $ | 32.72 |  |
| Awarded |  | 162 |  |  | 29.08 |  |  | 120 |  |  | 36.67 |  |
| Vested |  | (31 | ) |  | 34.32 |  |  | (74 | ) |  | 25.01 |  |
| Forfeited |  | (11 | ) |  | 32.53 |  |  | — |  |  | — |  |
| Non-vested at end of period |  | 630 |  |  | $ | 33.10 |  |  | 600 |  |  | $ | 34.47 |  |

[0000038725-16-000333:notes:42]
As of April 2, 2016, there was $11.4 million of total unrecognized compensation cost related to non-vested stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.67 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-16-000333:notes:43]
[same as prior period, unchanged from 0000038725-15-000195:notes:59]

[0000038725-16-000333:notes:44]
[same as prior period, unchanged from 0000038725-15-000195:notes:60]

[0000038725-16-000333:notes:45]
[same as prior period, unchanged from 0000038725-15-000195:notes:61]

[0000038725-16-000333:notes:46]
[same as prior period, unchanged from 0000038725-15-000195:notes:62]

[0000038725-16-000333:notes:47]
|  | First Quarter Ended |
| (In millions, except per share amounts) | April 2, 2016 |  | April 4, 2015 |
| Numerator: |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 13.5 |  |  | $ | 19.8 |  |
| Less: Undistributed earnings allocated to participating securities | 0.1 |  |  | 0.2 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | 0.5 |  |  | 0.1 |  |
|  | $ | 12.9 |  |  | $ | 19.5 |  |
| Denominator: |  |  |  |  |  |
| Basic |  |  |  |  |  |
| Weighted average common shares | 46.1 |  |  | 47.6 |  |
| Diluted |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.3 |  |  | 0.5 |  |
| Adjusted weighted average common shares | 46.4 |  |  | 48.1 |  |
| Basic earnings per share | $ | 0.28 |  |  | $ | 0.41 |  |
| Diluted earnings per share | $ | 0.28 |  |  | $ | 0.41 |  |
| Anti-dilutive stock options | 0.6 |  |  | 0.2 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000038725-16-000333:notes:48]
The following table summarizes information regarding the Company's non-financial assets measured at fair value on a nonrecurring basis:

[0000038725-16-000333:notes:49]
| (In millions) | April 2, 2016 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) | Recognized Loss |
| Asset held for sale | $ | 2.0 |  | $ | — |  | $ | — |  | $ | 2.0 |  | $ | 0.4 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-16-000333:notes:50]
As of April 2, 2016 and January 2, 2016, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-16-000333:notes:51]
| (In millions) | April 2, 2016 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.8 |  | $ | 3.8 |  | $ | — |  | $ | — |  |
|  | January 2, 2016 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.9 |  | $ | 3.9 |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-16-000333:notes:52]
[same as prior period, unchanged from 0000038725-15-000195:notes:66]

[0000038725-16-000333:notes:53]
[same as prior period, unchanged from 0000038725-15-000195:notes:67]

[0000038725-16-000333:notes:54]
[same as prior period, unchanged from 0000038725-15-000195:notes:68]

[0000038725-16-000333:notes:55]
[same as prior period, unchanged from 0000038725-15-000195:notes:69]

[0000038725-16-000333:notes:56]
[same as prior period, unchanged from 0000038725-15-000195:notes:70]

[0000038725-16-000333:notes:57]
[same as prior period, unchanged from 0000038725-15-000195:notes:71]

[0000038725-16-000333:notes:58]
Total debt, including current maturities, have carrying amounts of $232.5 million and $220.6 million and estimated fair values of $237 million and $225 million as of April 2, 2016 and January 2, 2016, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.

[0000038725-16-000333:notes:59]
The Company's Level 3 asset consists of a held for sale facility.  During the first quarter of 2016, the Company agreed upon the terms of a letter of intent to sell its Saco, Maine facility.  As a result, the Company reduced the carrying amount of the held for sale asset to approximate the estimated sales price less costs to sell.

[0000038725-16-000333:notes:60]
As of April 2, 2016 and January 2, 2016, the Company also had $1.8 million and $1.6 million of assets held for sale, respectively, recorded at carrying value in the Water Systems segment relating to an idle facility in Brazil.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-16-000333:notes:61]
[same as prior period, unchanged from 0000038725-15-000195:notes:74]

[0000038725-16-000333:notes:62]
Amortization expense related to intangible assets for the first quarters ended April 2, 2016 and April 4, 2015 was $2.0 million and $2.2 million, respectively.

[0000038725-16-000333:notes:63]
[same as prior period, unchanged from 0000038725-15-000195:notes:77]

[0000038725-16-000333:notes:64]
| (In millions) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |
|  |  | $ | 8.6 |  |  | $ | 8.4 |  |  | $ | 8.4 |  |  | $ | 8.3 |  |  | $ | 8.2 |  |

[0000038725-16-000333:notes:65]
The change in the carrying amount of goodwill by reporting segment for the first quarter ended April 2, 2016, is as follows:

[0000038725-16-000333:notes:66]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of January 2, 2016 |  | $ | 136.8 |  |  | $ | 63.0 |  |  | $ | 199.8 |  |
| Foreign currency translation |  | 1.9 |  |  | (0.1 | ) |  | 1.8 |  |
| Balance as of April 2, 2016 |  | $ | 138.7 |  |  | $ | 62.9 |  |  | $ | 201.6 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-16-000333:notes:67]
[same as prior period, unchanged from 0000038725-15-000195:notes:81]

[0000038725-16-000333:notes:68]
The Company’s effective tax rate from continuing operations for the three month period ended April 2, 2016 was 26.7% as compared to negative 20.4% for the three month period ended April 4, 2015.

[0000038725-16-000333:notes:69]
The effective tax rate continues to be lower than the U.S. statutory rate primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate as well as recognition of U.S. tax incentives and credits.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations as well as cash on hand and available credit.

[0000038725-16-000333:notes:70]
In addition during the three month period ended April 4, 2015, the Company settled the liability for the noncontrolling interest of a subsidiary during the first quarter.  This transaction created additional accretive benefits for the Company from the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer. The Company also realized a gain on the mandatorily redeemable noncontrolling interest liability.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-16-000333:notes:71]
ACCOUNTING PRONOUNCEMENTS

[0000038725-16-000333:notes:72]
Adoption of New Accounting Standards

[0000038725-16-000333:notes:73]
In April 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs, which requires debt issuance costs to be presented in the balance sheet as a direct deduction from the associated debt liability instead of a deferred asset.  The standard does not change the amortization of debt issuance costs, which will continue to follow the existing accounting guidance.  The Company adopted ASU 2015-03 during the first quarter ended April 2, 2016.  The retrospective adoption of this ASU required a total of approximately $0.3 million of unamortized debt issuance costs as of year-end 2015 to be reclassified from "Other assets" and "Other current assets" to a direct deduction from "Long-term debt" in the Company's condensed consolidated balance sheet as of January 2, 2016.  In addition, there were no impacts to the Company's results of operations, retained earnings, or cash flows in the current or previous interim and annual reporting periods.

[0000038725-16-000333:notes:74]
Accounting Standards Issued But Not Yet Adopted

[0000038725-16-000333:notes:75]
In March 2016, the FASB issued ASU 2016-09, Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.  This standard simplifies several aspects of the accounting for employee share-based payment transactions including the recognition of excess tax benefits and deficiencies, the classification of those excess tax benefits on the statement of cash flows, an accounting policy election for forfeitures, the amount an employer can withhold to cover income taxes and still qualify for equity classification, and the classification of those taxes paid on the statement of cash flows.  This ASU is effective for annual and interim periods beginning after December 15, 2016 with early adoption permitted.  The transition method is either prospective, retrospective or modified retrospective, depending on the area covered in this update.  The Company is still in the process of analyzing the effects of this new standard to determine the impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.

[0000038725-16-000333:notes:76]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification ("ASC") Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.

[0000038725-16-000333:notes:77]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606).  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  In March 2016, the FASB issued ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net).  ASU 2016-08 clarifies the implementation guidance on principal versus agent considerations.  In April 2016, the FASB issued ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing.  ASU 2016-10 clarifies the implementation guidance on identifying performance obligations.  These ASU's are effective for interim and annual reporting periods beginning after December 15, 2017.  Early adoption is permitted, but not before interim and annual reporting periods beginning after December 15, 2016.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt these standards.  The Company is still in the process of analyzing the effect of these new standards, including the transition method, to determine the impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-16-000333:notes:78]
[same as prior period, unchanged from 0000038725-15-000195:notes:99]

[0000038725-16-000333:notes:79]
The accompanying condensed consolidated balance sheet as of January 2, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of April 2, 2016, and for the first quarters ended April 2, 2016 and April 4, 2015 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended April 2, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2016.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended January 2, 2016.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000038725-16-000333:notes:80]
[same as prior period, unchanged from 0000038725-15-000195:notes:101]

[0000038725-16-000333:notes:81]
The Company has equity interests in various companies for various strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s condensed consolidated balance sheets.  The carrying amount of the investments is adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income/(expense), net" line of the Company's condensed consolidated statements of income, were immaterial for the first quarters ended April 2, 2016 and April 4, 2015.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-16-000333:notes:82]
[same as prior period, unchanged from 0000038725-15-000195:notes:103]

[0000038725-16-000333:notes:83]
Defined Benefit Plans - As of April 2, 2016, the Company maintained two domestic pension plans and three German pension plans.  The Company used a January 2, 2016 measurement date for these plans.  One of the Company's domestic pension plans covers two management employees (one active employee and one former employee), while the other domestic plan covers all other eligible employees.  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-16-000333:notes:84]
[same as prior period, unchanged from 0000038725-15-000195:notes:105]

[0000038725-16-000333:notes:85]
The following table sets forth the aggregated net periodic benefit cost for all pension and postretirement plans for the first quarters ended April 2, 2016 and April 4, 2015, respectively:

[0000038725-16-000333:notes:86]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | First Quarter Ended |  | First Quarter Ended |
|  | April 2, 2016 |  | April 4, 2015 |  | April 2, 2016 |  | April 4, 2015 |
| Service cost | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 1.5 |  |  | 1.8 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | (2.3 | ) |  | (2.5 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Amortization of loss | 0.6 |  |  | 0.8 |  |  | — |  |  | 0.1 |  |
| Net periodic benefit cost | $ | — |  |  | $ | 0.4 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |
| Settlement cost | 0.3 |  |  | 0.3 |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 0.3 |  |  | $ | 0.7 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |

[0000038725-16-000333:notes:87]
In the first quarter ended April 2, 2016, the Company made contributions of $0.6 million to the funded plans.  The amount of contributions to be made to the plans during the calendar year 2016 will be finalized by September 15, 2016, based upon the plans' year-end valuation at January 2, 2016, and the funding level required for the plans' year ended January 2, 2016.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-16-000333:notes:88]
[same as prior period, unchanged from 0000038725-15-000195:notes:111]

[0000038725-16-000333:notes:89]
[same as prior period, unchanged from 0000038725-15-000195:notes:112]

[0000038725-16-000333:notes:90]
Costs incurred in the first quarter ended April 2, 2016, included in the “Restructuring expense” line of the Company's condensed consolidated statements of income, are as follows:

[0000038725-16-000333:notes:91]
|  |  | First Quarter Ended |
|  |  | April 2, 2016 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |
| Equipment relocation |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset write-off |  | — |  |  | 0.4 |  |  | — |  |  | 0.4 |  |
| Other |  | 0.3 |  |  | — |  |  | — |  |  | 0.3 |  |
| Total |  | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | — |  |  | $ | 0.8 |  |

[0000038725-16-000333:notes:92]
Restructuring expenses for the first quarter ended April 4, 2015 were approximately $0.5 million and primarily for the Water Systems realignment.

[0000038725-16-000333:notes:93]
As of April 2, 2016, there were $0.2 million of restructuring reserves.  As of April 4, 2015, there were $6.4 million of restructuring reserves.  The restructuring reserves were primarily for severance.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-16-000333:notes:94]
[same as prior period, unchanged from 0000038725-15-000195:notes:117]

[0000038725-16-000333:notes:95]
|  | First Quarter Ended |  |
| (In millions) | April 2, 2016 |  | April 4, 2015 |  |
|  | Net sales to external customers |  |
| Water Systems | $ | 168.8 |  |  | $ | 179.2 |  |  |
| Fueling Systems | 49.6 |  |  | 46.5 |  |  |
| Other | — |  |  | — |  |  |
| Consolidated | $ | 218.4 |  |  | $ | 225.7 |  |  |
|  | First Quarter Ended |  |
|  | April 2, 2016 |  | April 4, 2015 |  |
|  | Operating income/(loss) |  |
| Water Systems | $ | 24.2 |  |  | $ | 19.4 |  |  |
| Fueling Systems | 10.2 |  |  | 9.6 |  |  |
| Other | (13.3 | ) |  | (13.1 | ) |  |
| Consolidated | $ | 21.1 |  |  | $ | 15.9 |  |  |
|  | April 2, 2016 |  | January 2, 2016 |  |
|  | Total assets |  |
| Water Systems | $ | 712.0 |  |  | $ | 677.6 |  |  |
| Fueling Systems | 249.4 |  |  | 248.5 |  |  |
| Other | 71.1 |  |  | 70.0 |  |  |
| Consolidated | $ | 1,032.5 |  |  | $ | 996.1 |  |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-16-000333:notes:96]
The schedule below sets forth equity changes in the first quarter ended April 2, 2016:

[0000038725-16-000333:notes:97]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of January 2, 2016 | $ | 4,622 |  |  | $ | 216,472 |  |  | $ | 498,214 |  |  | $ | (51,558 | ) |  | $ | (110,050 | ) |  | $ | 1,765 |  |  | $ | 559,465 |  |  | $ | 6,856 |  |
| Net income |  |  |  |  | 13,457 |  |  |  |  |  |  | 162 |  |  | 13,619 |  |  | (39 | ) |
| Adjustment to Impo redemption value |  |  |  |  | (493 | ) |  |  |  |  |  |  |  | (493 | ) |  | 493 |  |
| Dividends on common stock |  |  |  |  | (4,506 | ) |  |  |  |  |  |  |  | (4,506 | ) |  |  |
| Common stock issued | 2 |  |  | 409 |  |  |  |  |  |  |  |  |  |  | 411 |  |  |  |
| Common stock repurchased | (15 | ) |  |  |  | (4,160 | ) |  |  |  |  |  |  |  | (4,175 | ) |  |  |
| Share-based compensation | 8 |  |  | 2,531 |  |  |  |  |  |  |  |  |  |  | 2,539 |  |  |  |
| Tax expense of stock options exercised |  |  | (12 | ) |  |  |  |  |  |  |  |  |  | (12 | ) |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 12,940 |  |  | 66 |  |  | 13,006 |  |  | 19 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 476 |  |  |  |  |  |  | 476 |  |  |  |
| Balance as of April 2, 2016 | $ | 4,617 |  |  | $ | 219,400 |  |  | $ | 502,512 |  |  | $ | (51,082 | ) |  | $ | (97,110 | ) |  | $ | 1,993 |  |  | $ | 580,330 |  |  | $ | 7,329 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-16-000333:notes:98]
[same as prior period, unchanged from 0000038725-15-000195:notes:121]

[0000038725-16-000333:notes:99]
Property, plant, and equipment is the major asset group in "Other" of total assets as of April 2, 2016 and January 2, 2016.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-16-000333:notes:100]
[same as prior period, unchanged from 0000038725-15-000195:notes:123]
