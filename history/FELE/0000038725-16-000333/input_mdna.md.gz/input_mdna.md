# FELE MD&A — 0000038725-16-000333


## mdna

[0000038725-16-000333:mdna:1]
[same as prior period, unchanged from 0000038725-15-000195:mdna:1]

[0000038725-16-000333:mdna:2]
First Quarter 2016 vs. First Quarter 2015

[0000038725-16-000333:mdna:3]
[same as prior period, unchanged from 0000038725-15-000195:mdna:3]

[0000038725-16-000333:mdna:4]
Sales in the first quarter of 2016 decreased from the first quarter last year.  The sales decrease was primarily due to the negative impact of foreign currency translation. The Company’s organic sales growth was 3 percent excluding the impact of foreign currency.  The Company's consolidated gross profit was $74.2 million for the first quarter of 2016, an increase of $2.7 million or about 4 percent from the prior year’s first quarter. The gross profit as a percent of net sales increased 230 basis points to 34.0 percent in 2016 from 31.7 percent in first quarter of 2015.

[0000038725-16-000333:mdna:5]
[same as prior period, unchanged from 0000038725-15-000195:mdna:5]

[0000038725-16-000333:mdna:6]
[same as prior period, unchanged from 0000038725-15-000195:mdna:6]

[0000038725-16-000333:mdna:7]
Net sales in the first quarter of 2016 were $218.4 million, a decrease of $7.3 million or about 3 percent compared to 2015 first quarter sales of $225.7 million.  Sales revenue decreased by $13.8 million or about 6 percent in the first quarter of 2016 due to foreign currency translation. The sales change in the first quarter of 2016, excluding foreign currency translation, was an increase of about 3 percent, primarily due to price.

[0000038725-16-000333:mdna:8]
|  | Net Sales |
| (In millions) | Q1 2016 |  | Q1 2015 |  | 2016 v 2015 |
| Water Systems | $ | 168.8 |  |  | $ | 179.2 |  |  | $ | (10.4 | ) |
| Fueling Systems | 49.6 |  |  | 46.5 |  |  | 3.1 |  |
| Consolidated | $ | 218.4 |  |  | $ | 225.7 |  |  | $ | (7.3 | ) |

[0000038725-16-000333:mdna:9]
[same as prior period, unchanged from 0000038725-15-000195:mdna:9]

[0000038725-16-000333:mdna:10]
Water Systems revenues were $168.8 million in the first quarter 2016, a decrease of $10.4 million or about 6 percent versus the first quarter 2015 sales of $179.2 million. Sales were reduced by $13.3 million or about 7 percent in the quarter due to foreign currency translation. Water Systems sales were up 1 percent, excluding foreign currency translation, in the first quarter of 2016 versus the first quarter of 2015.

[0000038725-16-000333:mdna:11]
Water Systems sales in the U.S. and Canada represented 36 percent of consolidated sales and declined by about 2 percent compared to the prior year. Water Systems sales were reduced by $1.1 million or about 1 percent in the quarter due to foreign currency translation.  Sales of groundwater pumping equipment increased by about 1 percent as U.S. groundwater business showed signs of recovery during the first quarter of 2016. The year-over-year revenue decline in agricultural and industrial pumping system sales was about 5 percent compared to the 20 plus percent decline experienced in the last half of 2015. Sales of surface water pumping equipment decreased by about 5 percent in the U.S. and Canada compared to the first quarter 2015. Surface pumping business was weak in two regions: Canadian business was impacted by the value of the Canadian dollar and the retail sump pump business was soft due to the mild winter in the upper Midwest.

[0000038725-16-000333:mdna:12]
Water Systems sales in Latin America were about 12 percent of consolidated sales for the first quarter and declined by about 25 percent compared to the first quarter of the prior year.  Water Systems sales were reduced by $7.1 million or about 20 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, Latin American sales decreased by about 5 percent compared to the first quarter 2015, as price was more than offset by volume declines.  The weakness in sales was primarily in Brazil and is attributable to the economy.

[0000038725-16-000333:mdna:13]
Water Systems sales in the Middle East and Africa were about 11 percent of consolidated sales and decreased by about 9 percent compared to the first quarter 2015.  Water Systems sales were reduced by about 15 percent in the quarter due to foreign currency translation.  Excluding the impact of foreign currency translation, sales increased by about 6 percent compared to the first quarter 2015. The growth was driven by strong sales of dewatering pumping equipment, partially offset by weakness in Southern Africa in the mining sector.

[0000038725-16-000333:mdna:14]
Water Systems sales in the Asia Pacific region were 10 percent of consolidated sales and were up about 12 percent compared to the first quarter prior year.  Asia Pacific sales were reduced by about 3 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, Asia Pacific sales increased by about 15 percent compared to

[0000038725-16-000333:mdna:15]
the first quarter 2015.  The Asia Pacific region experienced strong sales in several end markets, especially in southeast Asia due to dry favorable weather conditions.

[0000038725-16-000333:mdna:16]
Water Systems sales in Europe were about 8 percent of consolidated sales and increased by about 3 percent compared to the first quarter 2015.   The impact of foreign currency translation decreased sales by about 3 percent compared to the first quarter 2015.  Excluding the impact of foreign currency translation, European sales were up about 6 percent to the first quarter 2015 due to increased rental sales of Pioneer branded dewatering equipment.

[0000038725-16-000333:mdna:17]
[same as prior period, unchanged from 0000038725-15-000195:mdna:17]

[0000038725-16-000333:mdna:18]
Fueling Systems sales were about 23 percent of consolidated sales at $49.6 million in the first quarter of 2016, an increase of $3.1 million or about 7 percent versus the first quarter 2015 sales of $46.5 million. Fueling Systems sales were decreased by $0.5 million or 1 percent in the quarter due to foreign currency translation. Fueling Systems sales growth, excluding foreign currency translation, was about 8 percent.  Fueling Systems sales in the U.S. and Canada grew by about 8 percent during the quarter with most of the sales growth coming from pump and fuel management systems.  Fueling Systems revenues in Asia Pacific grew by about 30 percent due to higher pumping systems sales in India. These sales increases were partially offset by lower sales in Europe due to continued weakness in tank sales for North Sea oil production.

[0000038725-16-000333:mdna:19]
[same as prior period, unchanged from 0000038725-15-000195:mdna:20]

[0000038725-16-000333:mdna:20]
Cost of sales as a percentage of net sales for the first quarters of 2016 and 2015 was 66.0 percent and 68.3 percent, respectively. Correspondingly, the gross profit margin increased to 34.0 percent from 31.7 percent, a 230 basis point improvement. The Company’s consolidated gross profit was $74.2 million for the first quarter of 2016, an increase of $2.7 million, or about 4 percent, from the first quarter of 2015 gross profit of $71.5 million.  The gross profit margin increase was primarily due to reduced raw material costs, pricing and lower fixed costs.

[0000038725-16-000333:mdna:21]
[same as prior period, unchanged from 0000038725-15-000195:mdna:22]

[0000038725-16-000333:mdna:22]
Selling, general, and administrative (SG&A) expenses were $52.3 million in the first quarter of 2016 compared to $55.2 million in the first quarter of the prior year, a decrease of $2.9 million or about 5 percent.  The Company’s SG&A expenses decreased by $2.5 million in the quarter due to foreign currency translation.

[0000038725-16-000333:mdna:23]
[same as prior period, unchanged from 0000038725-15-000195:mdna:24]

[0000038725-16-000333:mdna:24]
Restructuring expenses for the first quarter of 2016 were $0.8 million resulting in a $0.01 impact on diluted earnings per share. Restructuring expenses were split $0.4 million across both segments, Water and Fueling, and included asset write-offs, severance expenses and other miscellaneous manufacturing realignment activities.  Restructuring expenses for the first quarter of 2015 were $0.5 million resulting in a $0.01 impact on diluted earnings per share. Restructuring expenses were primarily for the European manufacturing realignment and include severance expenses and other miscellaneous manufacturing realignment activities.

[0000038725-16-000333:mdna:25]
[same as prior period, unchanged from 0000038725-15-000195:mdna:28]

[0000038725-16-000333:mdna:26]
Operating income was $21.1 million in the first quarter of 2016, up $5.2 million or about 33 percent from $15.9 million in the first quarter of 2015.

[0000038725-16-000333:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2016 |  | Q1 2015 |  | 2016 v 2015 |
| Water Systems |  | $ | 24.2 |  |  | $ | 19.4 |  |  | $ | 4.8 |  |
| Fueling Systems |  | 10.2 |  |  | 9.6 |  |  | 0.6 |  |
| Other |  | (13.3 | ) |  | (13.1 | ) |  | (0.2 | ) |
| Consolidated |  | $ | 21.1 |  |  | $ | 15.9 |  |  | $ | 5.2 |  |

[0000038725-16-000333:mdna:28]
There were specific items in the first quarters of 2016 and 2015 that impacted operating income that were not operational in nature.  In the first quarter of 2016, there were two such items: $0.8 million of restructuring charges and $0.3 million for retired executive pension costs. In the first quarter of 2015, there were two such items: $0.5 million of restructuring charges and $0.3 million for retired executive pension costs.

[0000038725-16-000333:mdna:29]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments

[0000038725-16-000333:mdna:30]
(operating income margin after non-GAAP adjustments).  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000333:mdna:31]
| Operating Income (Loss) and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (In millions) | For the First Quarter 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income (Loss) | $ | 24.2 |  | $ | 10.2 |  | $ | (13.3 | ) | $ | 21.1 |  |
| % Operating Income To Net Sales | 14.3 | % | 20.6 | % |  | 9.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.4 |  | $ | 0.4 |  | $ | — |  | $ | 0.8 |  |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.3 |  | $ | 0.3 |  |
| Operating Income (Loss) after Non-GAAP Adjustments | $ | 24.6 |  | $ | 10.6 |  | $ | (13.0 | ) | $ | 22.2 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.6 | % | 21.4 | % |  | 10.2 | % |
|  | For the First Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income (Loss) | $ | 19.4 |  | $ | 9.6 |  | $ | (13.1 | ) | $ | 15.9 |  |
| % Operating Income To Net Sales | 10.8 | % | 20.6 | % |  | 7.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.3 |  | $ | 0.2 |  | $ | — |  | $ | 0.5 |  |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.3 |  | $ | 0.3 |  |
| Operating Income (Loss) after Non-GAAP Adjustments | $ | 19.7 |  | $ | 9.8 |  | $ | (12.8 | ) | $ | 16.7 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 11.0 | % | 21.1 | % |  | 7.4 | % |

[0000038725-16-000333:mdna:32]
[same as prior period, unchanged from 0000038725-15-000195:mdna:36]

[0000038725-16-000333:mdna:33]
Water Systems operating income, after non-GAAP adjustments, was $24.6 million in the first quarter 2016, up $4.9 million versus the first quarter 2015. The first quarter 2016 operating income margin after non-GAAP adjustments was 14.6 percent, up 360 basis points from 11.0 percent in the first quarter of 2015.  Operating income after non-GAAP adjustments increased in Water Systems primarily due to lower input costs, primarily reduced raw material costs, pricing and lower fixed costs.

[0000038725-16-000333:mdna:34]
[same as prior period, unchanged from 0000038725-15-000195:mdna:38]

[0000038725-16-000333:mdna:35]
Fueling Systems operating income after non-GAAP adjustments was $10.6 million in the first quarter of 2016 compared to $9.8 million after non-GAAP adjustments in the first quarter of 2015, an increase of about 8 percent. The first quarter 2016 Fueling Systems operating income margin after non-GAAP adjustments was 21.4 percent, an increase of 30 basis points from the 21.1 percent of net sales in the first quarter of 2015.  The increase was driven by leveraging fixed costs on higher sales.

[0000038725-16-000333:mdna:36]
Operating Loss-Other

[0000038725-16-000333:mdna:37]
Operating loss-other is composed primarily of unallocated general and administrative expenses.

[0000038725-16-000333:mdna:38]
[same as prior period, unchanged from 0000038725-15-000195:mdna:42]

[0000038725-16-000333:mdna:39]
Interest expense for the first quarters of 2016 and 2015 was $2.4 million and $2.7 million, respectively.

[0000038725-16-000333:mdna:40]
[same as prior period, unchanged from 0000038725-15-000195:mdna:44]

[0000038725-16-000333:mdna:41]
Other income or expense was less than $(0.1) million dollars in the first quarter of 2016 and income of $3.0 million in the first quarter of 2015. Included in other income in the first quarter of 2016 was interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities.  Included in other income in the first quarter of 2015 was interest

[0000038725-16-000333:mdna:42]
income of $0.2 million, primarily derived from the investment of cash balances in short-term securities. The Company also realized a gain on the redeemable non-controlling interest liability in the first quarter of 2015 of about $2.7 million.

[0000038725-16-000333:mdna:43]
[same as prior period, unchanged from 0000038725-15-000195:mdna:46]

[0000038725-16-000333:mdna:44]
Foreign currency-based transactions produced a loss of $0.1 million for the first quarter of 2016.  Foreign currency-based transactions produced a gain of $0.4 million for the first quarter of 2015, primarily due to the euro.

[0000038725-16-000333:mdna:45]
[same as prior period, unchanged from 0000038725-15-000195:mdna:48]

[0000038725-16-000333:mdna:46]
The provision for (benefit from) income taxes in the first quarters of 2016 and 2015 was $5.0 million and $(3.4) million, respectively. The effective tax rate for the first quarter of 2016 was about 27 percent and, before the impact of discrete events, was about 26 percent.  The effective tax rate for the first quarter of 2015 was about negative 20 percent and, before the impact of discrete events, was about 27 percent.   Discrete adjustments during the first quarter of 2015 were the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer.  This first quarter tax benefit of about $4.8 million was treated as a non-GAAP adjustment.  The gain was treated as a non-GAAP adjustment in 2012 and, as such, the Company is consistently treating the reversal of the tax liability related to that gain as a non-GAAP adjustment and reduced reported Earnings per Share in the first quarter of 2015 by $0.10 cents. The Company also realized a gain on the redeemable non-controlling interest liability in the first quarter of 2015 of about $2.7 million which is included in ‘Other income’.  This purchase transaction also resulted in other tax benefits of about $2.5 million, which were expensed through the Company’s earnings in prior years as well as a current period benefit of about $1.0 million related to the 2015 gain.  The tax rate as a percentage of pre-tax earnings for the full year of 2016 is projected to be about 26 percent, flat to the first quarter of 2016 tax rate, before discrete adjustments.  The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its domestic operations, current cash on hand, and available credit.

[0000038725-16-000333:mdna:47]
[same as prior period, unchanged from 0000038725-15-000195:mdna:50]

[0000038725-16-000333:mdna:48]
Net income for the first quarter of 2016 was $13.6 million compared to the prior year first quarter net income of $20.0 million.  Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2016 was $13.5 million, or $0.28 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $19.8 million or $0.41 per diluted share. Earnings after non-GAAP adjustments for the first quarter of 2016 were $13.6 million, or $0.29 per diluted share, compared to the prior year first quarter earnings after non-GAAP adjustments of $15.2 million or $0.32 per diluted share.

[0000038725-16-000333:mdna:49]
There were specific items in the first quarters of 2016 and 2015 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000333:mdna:50]
| Earnings Before and After Non-GAAP Adjustments | For the First Quarter Ended |
| (In millions) | 2016 | 2015 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 13.5 |  | $ | 19.8 |  | (32 | )% |
| Allocated Undistributed Earnings | $ | (0.6 | ) | $ | (0.3 | ) |  |
| Adjusted Earnings for EPS Calculations | $ | 12.9 |  | $ | 19.5 |  | (34 | )% |
| Non-GAAP adjustments, before tax: |  |  |  |
| Restructuring | $ | 0.8 |  | $ | 0.5 |  |  |
| Non-GAAP items | $ | 0.3 |  | $ | 0.3 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | (4.8 | ) |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 0.5 |  | $ | 0.3 |  |  |
| Non-GAAP items | $ | 0.2 |  | $ | 0.2 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | (4.8 | ) |  |
| Net Income attributable to Franklin Electric Co., Inc. after Non-GAAP Adjustments (Adjusted Net Income) | $ | 13.6 |  | $ | 15.2 |  | (11 | )% |

[0000038725-16-000333:mdna:51]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the First Quarter Ended |
| (In millions, except per share data) | 2016 | 2015 | Change |
| Average Fully Diluted Shares Outstanding | 46.4 |  | 48.1 |  | (4 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.28 |  | $ | 0.41 |  | (32 | )% |
| Restructuring per Share, net of tax | $ | 0.01 |  | $ | 0.01 |  |  |
| Non-GAAP items, net of tax | $ | — |  | $ | — |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | (0.10 | ) |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.29 |  | $ | 0.32 |  | (9 | )% |

[0000038725-16-000333:mdna:52]
[same as prior period, unchanged from 0000038725-15-000195:mdna:115]

[0000038725-16-000333:mdna:53]
Overview

[0000038725-16-000333:mdna:54]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreement, and long-term debt funds available.

[0000038725-16-000333:mdna:55]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of April 2, 2016, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-16-000333:mdna:56]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement.  Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)."  The aggregate principal amount of the Project Bonds that were issued and authenticated was limited to $25.0 million.  The Company then borrowed the proceeds under the Project

[0000038725-16-000333:mdna:57]
[same as prior period, unchanged from 0000038725-15-000195:mdna:35]

[0000038725-16-000333:mdna:58]
Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (tax increment financing debt) bear interest at 3.6 percent per annum.  Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.  On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-16-000333:mdna:59]
On April 9, 2007, the Company entered into the Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") in the amount of $175.0 million.  Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”).  The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had at issuance an average life of 10 years with a final maturity in 2019.  On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million.  On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Credit Agreement.  On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015.  On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement.   This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of April 2, 2016, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.

[0000038725-16-000333:mdna:60]
On December 14, 2006, the Company entered into an amended and restated unsecured, 60-month $120.0 million revolving credit agreement (the “Credit Agreement”).  The Credit Agreement provides for various borrowing rate options including interest rates based on the London Interbank Offered Rates (LIBOR) plus interest spreads keyed to the Company’s ratio of debt to earnings before interest, taxes, depreciation, and amortization (“EBITDA”).  On December 14, 2011, the Company executed the Second Amended and Restated Credit Agreement, which extended the maturity of the Credit Agreement to December 14, 2016, and increased the commitment amount to $150.0 million.  On May 5, 2015, the Company entered into Amendment No. 3 to the Credit Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  As of April 2, 2016, the Company had $133.3 million borrowing capacity under the Credit Agreement as $5.2 million in letters of commercial and standby letters of credit were outstanding and undrawn and $11.5 million of revolver borrowing was drawn and outstanding as of the end of the quarter.

[0000038725-16-000333:mdna:61]
The New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws, and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales, and transfers of assets. The covenants also include financial requirements, including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million.  As of April 2, 2016, the Company was in compliance with all financial covenants.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-16-000333:mdna:62]
At April 2, 2016, the Company had $74.6 million of cash on hand at various locations worldwide.  Approximately 19 percent of the cash on hand was in the U.S. and readily accessible.  Approximately 48 percent was in Europe, and the remaining 33 percent was in Mexico, Asia Pacific, and other locations combined.  On a regular basis the Company reviews international cash balances and, if appropriate based on forecasted expenditures and considerations for the post-tax economic efficiency, will reposition cash among its global entities.  Global cash balances are invested according to a written policy, and are generally in bank demand accounts and bank time deposits with the preservation of principal as the highest priority.

[0000038725-16-000333:mdna:63]
Operating Activities

[0000038725-16-000333:mdna:64]
Net cash used by operating activities was $0.4 million for the first quarter ended April 2, 2016 compared to $21.8 million for the first quarter ended April 4, 2015.  The decrease in cash used in operations in the first quarter of 2016 in comparison to the first quarter of 2015 was largely attributable to greater uses of cash during the first quarter of 2015 to pay down higher year-end

[0000038725-16-000333:mdna:65]
2014 accounts payable balances resulting from timing of inventory receipts and higher inventory levels as of the end of 2014.  In addition, during the first quarter of 2015, the mandatory share purchase liability of $22.9 million for PPH was settled, resulting in a non-cash gain and reversal of certain deferred tax liabilities, also non-cash, both of which were adjustments to net income.

[0000038725-16-000333:mdna:66]
Investing Activities

[0000038725-16-000333:mdna:67]
Net cash used in investing activities was $11.0 million for the first quarter ended April 2, 2016 compared to $7.8 million for the first quarter ended April 4, 2015.  This increase was primarily attributable to an increase in capital expenditures including the purchase of a building during the first quarter of 2016.

[0000038725-16-000333:mdna:68]
Financing Activities

[0000038725-16-000333:mdna:69]
Net cash provided by financing activities was $3.6 million for the first quarter ended April 2, 2016 compared to $43.4 million for the first quarter ended April 4, 2015.  During the first quarter of 2015 cash provided from financing activities was higher primarily due to increased borrowings to fund operating requirements and the $20.2 million payment for the purchase of the remaining outstanding shares of Pioneer Pump.

[0000038725-16-000333:mdna:70]
[same as prior period, unchanged from 0000038725-15-000195:mdna:128]
