# FELE 8-K — 0000038725-19-000100 filed 2019-04-23

## item codes, every 8-K on or before 2019-04-30

- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2019-04-30

- none on or before 2019-04-30

## item 2.02 — earnings release, exhibit 99.1

[0000038725-19-000100:8k_2_02:1]
EX-99.1
2
a201904238-kexhibit991.htm
EXHIBIT 99.1

[0000038725-19-000100:8k_2_02:2]
Exhibit

[0000038725-19-000100:8k_2_02:3]
Exhibit 99.1

[0000038725-19-000100:8k_2_02:4]
For Immediate Release

[0000038725-19-000100:8k_2_02:5]
For Further Information

[0000038725-19-000100:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-19-000100:8k_2_02:7]
260-824-2900

[0000038725-19-000100:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS FIRST

[0000038725-19-000100:8k_2_02:9]
QUARTER 2019 SALES AND EARNINGS

[0000038725-19-000100:8k_2_02:10]
Fort Wayne, IN - April 23, 2019 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported first quarter 2019 GAAP fully diluted earnings per share (EPS) of $0.19, versus a GAAP fully diluted EPS in the first quarter 2018 of $0.45.  First quarter 2019 sales were $290.7 million, compared to 2018 first quarter sales of $295.6 million. First quarter EPS before the impact of restructuring expenses was $0.21 compared to 2018 first quarter EPS before restructuring of $0.45 (see table below for a reconciliation of GAAP EPS to EPS before restructuring).  In the first quarter of 2018, the Company recognized discrete income tax benefits of about $5 million which lowered the first quarter 2018 effective tax rate and resulted in an eleven-cent increase in earnings per share.

[0000038725-19-000100:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-19-000100:8k_2_02:12]
“Our first quarter 2019 net sales results were meaningfully below our expectations and were the primary driver of our lower earnings in the quarter.  The key factors that contributed to the lower than expected net sales included adverse winter weather conditions in North America that hurt all our operating segments, and weak international end markets primarily in Europe, the Middle East and Central America.  Our operating income before restructuring expenses declined by about $9.5 million from the first quarter 2018 due in large part to the lower sales volume and adverse sales mix, resulting in lost leverage on our fixed cost base.  Through our company wide focus on working capital reduction our operating cash flow improved by $24 million as compared to the first quarter of last year.

[0000038725-19-000100:8k_2_02:13]
Despite the lower than expected demand in first quarter, we remain confident in the overall strength of the end markets in which we compete.  Our Water Systems segment is positioned well to recover the declines in North America that resulted from adverse weather and we are encouraged by higher than expected net sales results in both Brazil and Asia Pacific during the first quarter.  Although sales in our Pioneer branded dewatering equipment business and our Fueling Systems segment were also below expectations in the first quarter, we attribute this mostly to the timing of customer requested deliveries.  As a result, we are reaffirming our 2019 earnings per share guidance of $2.37 to $2.47 per share.”

[0000038725-19-000100:8k_2_02:14]
Key Performance Indicators:

[0000038725-19-000100:8k_2_02:15]
| Earnings Before and After Restructuring |  | For the First Quarter |  |
| (in millions) |  | 2019 | 2018 | Change |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 9.1 |  | $ | 21.2 |  | (57 | )% |  |
| Allocated Earnings |  | $ | (0.1 | ) | $ | (0.2 | ) |  |  |
| Earnings for EPS Calculations |  | $ | 9.0 |  | $ | 21.0 |  | (57 | )% |  |
| Restructuring (before tax): |  | $ | 1.1 |  | $ | — |  |  |  |
| Restructuring, net of tax: |  | $ | 0.9 |  | $ | — |  |  |  |
| Earnings Before Restructuring |  | $ | 9.9 |  | $ | 21.0 |  | (53 | )% |  |
| Earnings Per Share |  | For the First Quarter |  |
| Before and After Restructuring |  | 2018 | 2017 | Change |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.7 |  | 47.1 |  | (1 | )% |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.19 |  | $ | 0.45 |  | (58 | )% |  |
| Restructuring Per Share, net of tax |  | $ | 0.02 |  | $ | — |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.21 |  | $ | 0.45 |  | (53 | )% |  |

[0000038725-19-000100:8k_2_02:16]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q1 2018 | $ | 96.5 |  | $ | 29.1 |  | $ | 46.2 |  | $ | 20.8 |  | $ | 192.6 |  | $ | 58.6 |  | $ | 56.2 |  | $ | (11.8 | ) | $ | 295.6 |  |
| Q1 2019 | $ | 98.0 |  | $ | 30.5 |  | $ | 37.7 |  | $ | 22.2 |  | $ | 188.4 |  | $ | 60.2 |  | $ | 53.3 |  | $ | (11.2 | ) | $ | 290.7 |  |
| Change | $ | 1.5 |  | $ | 1.4 |  | $ | (8.5 | ) | $ | 1.4 |  | $ | (4.2 | ) | $ | 1.6 |  | $ | (2.9 | ) | $ | 0.6 |  | $ | (4.9 | ) |
| % Change | 2 | % | 5 | % | (18 | )% | 7 | % | (2 | )% | 3 | % | (5 | )% |  | (2 | )% |
| Foreign currency translation | $ | (0.9 | ) | $ | (3.0 | ) | $ | (6.7 | ) | $ | (0.9 | ) | $ | (11.5 | ) | $ | (1.4 | ) | $ | — |  |  |  |
| % Change | (1 | )% | (10 | )% | (15 | )% | (4 | )% | (6 | )% | (2 | )% | — | % |  |  |
| Acquisitions | $ | — |  | $ | 4.3 |  | $ | — |  | $ | — |  | $ | 4.3 |  | $ | 1.5 |  | $ | 2.8 |  |  |  |
| Volume/Price | $ | 2.4 |  | $ | 0.1 |  | $ | (1.8 | ) | $ | 2.3 |  | $ | 3.0 |  | $ | 1.5 |  | $ | (5.7 | ) |  |  |
| % Change | 2 | % | — | % | (4 | )% | 11 | % | 2 | % | 3 | % | (10 | )% |  |  |

[0000038725-19-000100:8k_2_02:17]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2019 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 19.2 |  | $ | 12.3 |  | $ | (4.3 | ) | $ | (15.1 | ) | $ | 12.1 |  |
| % Operating Income To Net Sales | 10.2 | % | 20.4 | % | (8.1 | )% |  | 4.2 | % |
| Restructuring | $ | 0.5 |  | $ | — |  | $ | 0.6 |  | $ | — |  | $ | 1.1 |  |
| Operating Income/(Loss) Before Restructuring | $ | 19.7 |  | $ | 12.3 |  | $ | (3.7 | ) | $ | (15.1 | ) | $ | 13.2 |  |
| % Operating Income to Net Sales Before Restructuring | 10.5 | % | 20.4 | % |  |  | 4.5 | % |
|  | For the First Quarter 2018 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 25.1 |  | $ | 13.7 |  | $ | (0.8 | ) | $ | (15.3 | ) | $ | 22.7 |  |
| % Operating Income To Net Sales | 13.0 | % | 23.4 | % | (1.4 | )% |  | 7.7 | % |
| Restructuring | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  |
| Operating Income/(Loss) Before Restructuring | $ | 25.1 |  | $ | 13.7 |  | $ | (0.8 | ) | $ | (15.3 | ) | $ | 22.7 |  |
| % Operating Income to Net Sales Before Restructuring | 13 | % | 23.4 | % |  |  | 7.7 | % |

[0000038725-19-000100:8k_2_02:18]
Water Systems

[0000038725-19-000100:8k_2_02:19]
Water Systems sales were $188.4 million in the first quarter 2019, versus the first quarter 2018 sales of $192.6 million.  In the first quarter of 2019, sales from businesses acquired since the first quarter of 2018 were $4.3 million.  Water Systems sales decreased about 6 percent in the quarter due to foreign currency translation. Water Systems organic sales increased about 2 percent compared to the first quarter of 2018.

[0000038725-19-000100:8k_2_02:20]
Water Systems sales in the U.S. and Canada increased by about 2 percent compared to the first quarter 2018. Foreign currency translation decreased sales by about 1 percent.  Sales of Pioneer branded dewatering equipment increased by about 10 percent in the first quarter when compared to the prior year due to diversification of product sales channels. Sales of other surface pumping equipment increased by about 2 percent on stronger sales of wastewater products. Sales of groundwater pumping equipment were down about 5 percent versus the first quarter 2018.  The decline in groundwater pumping systems was primarily due to adverse winter weather conditions in North America that reduced demand for the Company’s groundwater pumping systems including sales through the Headwater Distribution segment.

[0000038725-19-000100:8k_2_02:21]
Water Systems sales in markets outside the U.S. and Canada declined by about 6 percent overall.  Foreign currency translation decreased sales by about 11 percent.  Outside the U.S. and Canada, Water Systems realized organic sales growth of about 11 percent in Asia Pacific and about 15 percent in Brazil versus the first quarter 2018. These increases were offset by an organic sales decline in Europe, the Middle East and Central America.

[0000038725-19-000100:8k_2_02:22]
Water Systems operating income was $19.2 million in the first quarter 2019, compared to $25.1 million in the first quarter 2018.  Water Systems operating income was lower in the first quarter primarily due to lower sales volume, the resultant lost leverage on fixed costs, adverse product sales mix and higher freight costs.

[0000038725-19-000100:8k_2_02:23]
Fueling Systems

[0000038725-19-000100:8k_2_02:24]
Fueling Systems sales were $60.2 million in the first quarter 2019 compared to first quarter 2018 sales of $58.6 million and were a record for any first quarter.  In the first quarter of 2019, sales from businesses acquired since the first quarter of 2018 were $1.5 million.  Fueling Systems sales decreased about 2 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased about 3 percent compared to the first quarter of 2018.

[0000038725-19-000100:8k_2_02:25]
Fueling Systems sales in the U.S. and Canada increased by about 10 percent compared to the first quarter 2018.  The increase was principally in the fuel management and service station hardware product lines.  Outside the U.S. and Canada, Fueling Systems revenues declined by about 5 percent, due to lower sales of storage tanks, fuel pumping systems, and underground pipe and containment systems primarily in Europe and China.

[0000038725-19-000100:8k_2_02:26]
Fueling Systems operating income was $12.3 million in the first quarter of 2019 compared to $13.7 million in the first quarter of 2018.  Fueling Systems operating income was lower in the first quarter as growth from higher sales was offset primarily by higher fixed costs.

[0000038725-19-000100:8k_2_02:27]
Distribution

[0000038725-19-000100:8k_2_02:28]
Distribution sales were $53.3 million in the first quarter 2019, versus first quarter 2018 sales of $56.2 million.  In the first quarter of 2019, sales from businesses acquired since the first quarter of 2018 were $2.8 million.  The Distribution segment organic sales were down about 10 percent compared to the first quarter of 2018 primarily due to unfavorable weather conditions.

[0000038725-19-000100:8k_2_02:29]
The Distribution segment recorded an operating loss of $4.3 million in the first quarter of 2019, compared to $0.8 million loss in the first quarter of 2018.  The loss before the impact of restructuring expenses was $3.7 million. The Distribution loss was primarily due to lower sales volume, higher product costs partially offset by sales price increases, adverse geographic and product sales mix and lost leverage on fixed costs from lower sales.

[0000038725-19-000100:8k_2_02:30]
Overall

[0000038725-19-000100:8k_2_02:31]
The Company’s consolidated gross profit was $89.5 million for the first quarter of 2019, a decrease from the first quarter of 2018 gross profit of $99.0 million.  The gross profit decrease was primarily due to lower sales and other impacts previously mentioned.  The gross profit as a percent of net sales was 30.8 percent in the first quarter of 2019 compared to 33.5 percent in the first quarter of 2018.

[0000038725-19-000100:8k_2_02:32]
Selling, general, and administrative (SG&A) expenses were $76.3 million in the first quarter of 2019 and 2018. SG&A expenses from acquired businesses was $3.0 million and excluding the acquired entities, the Company’s SG&A expenses in the first quarter of 2019 were $73.3 million, a decrease of about 4 percent from the first quarter 2018, due primarily to the effect of foreign currency translations in the first quarter of 2019 versus the prior year.

[0000038725-19-000100:8k_2_02:33]
Commenting on the outlook for 2019, Mr. Sengstack said:

[0000038725-19-000100:8k_2_02:34]
“As we look forward to the balance of 2019, the key question will be the recovery of net sales in North America in both our Water Systems and Distribution segments that we believe were delayed due to the poor weather during the first quarter.  Our review with these businesses in the last several weeks confirms that the end market demand is still robust; however, the environment for equipment manufacturers will be even more competitive.  Except for Europe and the Middle East, we think there is still opportunity for growth in the other international Water Systems businesses.  Fueling Systems continues to capitalize on numerous market opportunities.

[0000038725-19-000100:8k_2_02:35]
As a result, we continue to believe our previous growth guidance of 4 to 6 percent in 2019 is doable.  We also continue to believe we can achieve our original earnings per share before restructuring charges guidance of $2.37 to $2.47 per share.  In addition to some sales volume recovery, we are taking cost reduction actions in virtually all of our business units to make up portions of the earnings shortfall we experienced in the first quarter.”

[0000038725-19-000100:8k_2_02:36]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET.  The first quarter 2019 earnings call will be available via a live webcast.

[0000038725-19-000100:8k_2_02:37]
https://edge.media-server.com/m6/p/ugbyz5i8

[0000038725-19-000100:8k_2_02:38]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 1382996.

[0000038725-19-000100:8k_2_02:39]
A replay of the conference call will be available Tuesday, April 23, 2019 at 12:00 noon ET through noon ET on Tuesday, April 30, 2019, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 1382996.

[0000038725-19-000100:8k_2_02:40]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-19-000100:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |
|  | First Quarter Ended |
|  | March 31, 2019 |  | March 31, 2018 |
| Net sales | $ | 290,715 |  |  | $ | 295,630 |  |
| Cost of sales | 201,209 |  |  | 196,648 |  |
| Gross profit | 89,506 |  |  | 98,982 |  |
| Selling, general, and administrative expenses | 76,299 |  |  | 76,275 |  |
| Restructuring expense | 1,086 |  |  | 7 |  |
| Operating income | 12,121 |  |  | 22,700 |  |
| Interest expense | (2,342 | ) |  | (2,428 | ) |
| Other income/(expense), net | 239 |  |  | (204 | ) |
| Foreign exchange income/(expense) | 589 |  |  | (551 | ) |
| Income before income taxes | 10,607 |  |  | 19,517 |  |
| Income tax (benefit)/expense | 1,480 |  |  | (1,698 | ) |
| Net income | $ | 9,127 |  |  | $ | 21,215 |  |
| Less: Net income attributable to noncontrolling interests | (71 | ) |  | (41 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 9,056 |  |  | $ | 21,174 |  |
| Income per share: |  |  |  |
| Basic | $ | 0.19 |  |  | $ | 0.45 |  |
| Diluted | $ | 0.19 |  |  | $ | 0.45 |  |

[0000038725-19-000100:8k_2_02:42]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | March 31, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 54,364 |  |  | $ | 59,173 |  |
| Receivables | 180,584 |  |  | 172,899 |  |
| Inventories | 336,639 |  |  | 314,049 |  |
| Other current assets | 34,115 |  |  | 33,758 |  |
| Total current assets | 605,702 |  |  | 579,879 |  |
| Property, plant, and equipment, net | 202,597 |  |  | 207,064 |  |
| Right-of-use asset, net | 25,411 |  |  | — |  |
| Goodwill and other assets | 395,049 |  |  | 395,422 |  |
| Total assets | $ | 1,228,759 |  |  | $ | 1,182,365 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 91,399 |  |  | $ | 76,652 |  |
| Accrued expenses and other current liabilities | 52,990 |  |  | 67,230 |  |
| Current lease liability | 7,738 |  |  | — |  |
| Current maturities of long-term debt and short-term borrowings | 131,957 |  |  | 111,975 |  |
| Total current liabilities | 284,084 |  |  | 255,857 |  |
| Long-term debt | 93,803 |  |  | 94,379 |  |
| Long-term lease liability | 17,675 |  |  | — |  |
| Income taxes payable non-current | 10,881 |  |  | 10,881 |  |
| Deferred income taxes | 28,927 |  |  | 28,949 |  |
| Employee benefit plans | 36,963 |  |  | 38,020 |  |
| Other long-term liabilities | 19,826 |  |  | 17,934 |  |
| Redeemable noncontrolling interest | 408 |  |  | 518 |  |
| Total equity | 736,192 |  |  | 735,827 |  |
| Total liabilities and equity | $ | 1,228,759 |  |  | $ | 1,182,365 |  |

[0000038725-19-000100:8k_2_02:43]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Three Months Ended |
| (In thousands) | March 31, 2019 |  | March 31, 2018 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 9,127 |  |  | $ | 21,215 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 12,073 |  |  | 9,896 |  |
| Share-based compensation | 3,230 |  |  | 3,326 |  |
| Other | (96 | ) |  | (5,262 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (6,517 | ) |  | (17,242 | ) |
| Inventory | (20,986 | ) |  | (23,932 | ) |
| Accounts payable and accrued expenses | 1,309 |  |  | (15,378 | ) |
| Operating Leases | (2,804 | ) |  | — |  |
| Other | 1,729 |  |  | 193 |  |
| Net cash flows from operating activities | (2,935 | ) |  | (27,184 | ) |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (5,220 | ) |  | (5,921 | ) |
| Proceeds from sale of property, plant, and equipment | 64 |  |  | 208 |  |
| Acquisitions and investments | (5,405 | ) |  | (8,428 | ) |
| Other investing activities | 3 |  |  | — |  |
| Net cash flows from investing activities | (10,558 | ) |  | (14,141 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 19,669 |  |  | 52,007 |  |
| Proceeds from issuance of common stock | 1,251 |  |  | 642 |  |
| Purchases of common stock | (4,329 | ) |  | (7,949 | ) |
| Dividends paid | (6,723 | ) |  | (5,037 | ) |
| Net cash flows from financing activities | 9,868 |  |  | 39,663 |  |
| Effect of exchange rate changes on cash | (1,184 | ) |  | 1,799 |  |
| Net change in cash and equivalents | (4,809 | ) |  | 137 |  |
| Cash and equivalents at beginning of period | 59,173 |  |  | 67,233 |  |
| Cash and equivalents at end of period | $ | 54,364 |  |  | $ | 67,370 |  |
