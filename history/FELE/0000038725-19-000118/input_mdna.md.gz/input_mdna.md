# FELE MD&A — 0000038725-19-000118


## mdna

[0000038725-19-000118:mdna:1]
[same as prior period, unchanged from 0000038725-18-000191:mdna:1]

[0000038725-19-000118:mdna:2]
First Quarter 2019 vs. First Quarter 2018

[0000038725-19-000118:mdna:3]
[same as prior period, unchanged from 0000038725-18-000191:mdna:3]

[0000038725-19-000118:mdna:4]
Sales in the first quarter of 2019 decreased from the first quarter of last year. The sales decrease was primarily from foreign currency translation. The Company's consolidated gross profit was $89.5 million for the first quarter of 2019, a decrease of $9.5 million from the prior year’s first quarter. The gross profit decrease was primarily due to lower sales. The gross profit as a percent of net sales was 30.8 percent in the first quarter of 2019 versus 33.5 percent during the first quarter 2018.

[0000038725-19-000118:mdna:5]
[same as prior period, unchanged from 0000038725-18-000191:mdna:5]

[0000038725-19-000118:mdna:6]
[same as prior period, unchanged from 0000038725-18-000191:mdna:6]

[0000038725-19-000118:mdna:7]
Net sales in the first quarter of 2019 were $290.7 million, a decrease of $4.9 million or about 2 percent compared to 2018 first quarter sales of $295.6 million.  The sales increase from acquisitions was $8.6 million.  Sales revenue decreased by $12.9 million or about 4 percent in the first quarter of 2019 due to foreign currency translation. Excluding the impact of foreign currency translation, the Company’s organic sales growth was flat.

[0000038725-19-000118:mdna:8]
|  | Net Sales |
| (In millions) | Q1 2019 |  | Q1 2018 |  | 2019 v 2018 |
| Water Systems | $ | 188.4 |  |  | $ | 192.6 |  |  | $ | (4.2 | ) |
| Fueling Systems | 60.2 |  |  | 58.6 |  |  | $ | 1.6 |  |
| Distribution | 53.3 |  |  | 56.2 |  |  | $ | (2.9 | ) |
| Eliminations/Other | (11.2 | ) |  | (11.8 | ) |  | $ | 0.6 |  |
| Consolidated | $ | 290.7 |  |  | $ | 295.6 |  |  | $ | (4.9 | ) |

[0000038725-19-000118:mdna:9]
[same as prior period, unchanged from 0000038725-18-000191:mdna:9]

[0000038725-19-000118:mdna:10]
Water Systems revenues were $188.4 million in the first quarter 2019, a decrease of $4.2 million or about 2 percent versus the first quarter 2018 sales of $192.6 million. In the first quarter of 2019, sales from businesses acquired since the first quarter of 2018 were $4.3 million.  Sales decreased by $11.5 million or 6 percent in the quarter due to foreign currency translation. Water Systems sales were up about 2 percent, excluding foreign currency translation, in the first quarter of 2019 versus the first quarter of 2018.

[0000038725-19-000118:mdna:11]
Water Systems sales in the U.S. and Canada increased by about 2 percent compared to the first quarter 2018. Foreign currency translation decreased sales by about 1 percent.  Sales of Pioneer branded dewatering equipment increased by about 10 percent in the first quarter when compared to the prior year due to diversification of product sales channels. Sales of other surface pumping equipment increased by about 2 percent on stronger sales of wastewater products. Sales of groundwater pumping equipment were down about 5 percent versus the first quarter 2018.  The decline in groundwater pumping systems was primarily due to adverse winter weather conditions in North America that reduced demand for the Company’s groundwater pumping systems including sales through the Headwater Distribution segment.

[0000038725-19-000118:mdna:12]
Water Systems sales in markets outside the U.S. and Canada declined by about 6 percent overall.  Foreign currency translation decreased sales by about 11 percent.  Outside the U.S. and Canada, Water Systems realized organic sales growth of about 11 percent in Asia Pacific and about 15 percent in Brazil versus the first quarter 2018. These increases were offset by an organic sales decline in Europe, the Middle East and Central America.

[0000038725-19-000118:mdna:13]
[same as prior period, unchanged from 0000038725-18-000191:mdna:14]

[0000038725-19-000118:mdna:14]
Fueling Systems sales were $60.2 million in the first quarter of 2019, an increase of $1.6 million or about 3 percent versus the first quarter 2018 sales of $58.6 million. In the first quarter of 2019, sales from businesses acquired since the first quarter of

[0000038725-19-000118:mdna:15]
2018 were $1.5 million.  Fueling Systems sales decreased by $1.4 million or 2 percent in the quarter due to foreign currency translation. Fueling Systems sales growth, excluding foreign currency translation, was about 3 percent.

[0000038725-19-000118:mdna:16]
Fueling Systems sales in the U.S. and Canada increased by about 10 percent compared to the first quarter 2018.  The increase was principally in the fuel management and service station hardware product lines.  Outside the U.S. and Canada, Fueling Systems revenues declined by about 5 percent, due to lower sales of storage tanks, fuel pumping systems, and underground pipe and containment systems primarily in Europe and China.

[0000038725-19-000118:mdna:17]
[same as prior period, unchanged from 0000038725-18-000191:mdna:17]

[0000038725-19-000118:mdna:18]
Distribution sales were $53.3 million in the first quarter 2019, versus first quarter 2018 sales of $56.2 million.  In the first quarter of 2019, sales from businesses acquired since the first quarter of 2018 were $2.8 million.  The Distribution segment organic sales were down about 10 percent compared to the first quarter of 2018 primarily due to unfavorable weather conditions.

[0000038725-19-000118:mdna:19]
[same as prior period, unchanged from 0000038725-18-000191:mdna:19]

[0000038725-19-000118:mdna:20]
Cost of sales as a percentage of net sales for the first quarters of 2019 and 2018 was 69.2 percent and 66.5 percent, respectively. Correspondingly, the gross profit margin decreased to 30.8 percent from 33.5 percent, a decline of 270 basis points. The Company’s consolidated gross profit was $89.5 million for the first quarter of 2019, a decrease from the first quarter of 2018 gross profit of $99.0 million. The gross profit decrease was primarily due to lower sales volume primarily due to unfavorable weather conditions in North America. The decline in gross profit margin percentage is primarily due to the lost leverage on fixed cost from the lower sales, unfavorable product and geographic sales mix shifts, mostly in the Water Systems segment, and higher freight costs.

[0000038725-19-000118:mdna:21]
[same as prior period, unchanged from 0000038725-18-000191:mdna:21]

[0000038725-19-000118:mdna:22]
Selling, general, and administrative (SG&A) expenses were $76.3 million in the first quarter of 2019 and 2018. SG&A expenses from acquired businesses was $3.0 million and excluding the acquired entities, the Company’s SG&A expenses in the first quarter of 2019 were $73.3 million, a decrease of about 4 percent from the first quarter 2018, due primarily to the effect of foreign currency translations in the first quarter of 2019 versus the prior year.

[0000038725-19-000118:mdna:23]
[same as prior period, unchanged from 0000038725-18-000191:mdna:23]

[0000038725-19-000118:mdna:24]
There were $1.1 million of restructuring expenses for the first quarter of 2019. Restructuring expenses for the first quarter of 2019 were $0.6 million in the Distribution segment and related to miscellaneous branch closings and consolidation. Restructuring expenses for the first quarter of 2019 were $0.5 million in the Water segment and related to continued miscellaneous manufacturing realignment activities.  There were no meaningful restructuring expenses for the first quarter of 2018.

[0000038725-19-000118:mdna:25]
[same as prior period, unchanged from 0000038725-18-000191:mdna:25]

[0000038725-19-000118:mdna:26]
Operating income was $12.1 million in the first quarter of 2019, down $10.6 million or about 47 percent from $22.7 million in the first quarter of 2018.

[0000038725-19-000118:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2019 |  | Q1 2018 |  | 2019 v 2018 |
| Water Systems |  | $ | 19.2 |  |  | $ | 25.1 |  |  | $ | (5.9 | ) |
| Fueling Systems |  | 12.3 |  |  | 13.7 |  |  | (1.4 | ) |
| Distribution |  | (4.3 | ) |  | (0.8 | ) |  | (3.5 | ) |
| Eliminations/Other |  | (15.1 | ) |  | (15.3 | ) |  | 0.2 |  |
| Consolidated |  | $ | 12.1 |  |  | $ | 22.7 |  |  | $ | (10.6 | ) |

[0000038725-19-000118:mdna:28]
[same as prior period, unchanged from 0000038725-18-000191:mdna:28]

[0000038725-19-000118:mdna:29]
Water Systems operating income was $19.2 million in the first quarter 2019, down $5.9 million versus the first quarter 2018. The first quarter operating income margin was 10.2 percent, down 280 basis points from 13.0 percent in the first quarter of 2018. Operating income decreased in Water Systems primarily due to lower sales volume, the resultant lost leverage on fixed costs, adverse product sales mix and higher freight costs.

[0000038725-19-000118:mdna:30]
[same as prior period, unchanged from 0000038725-18-000191:mdna:30]

[0000038725-19-000118:mdna:31]
Fueling Systems operating income was $12.3 million in the first quarter of 2019 compared to $13.7 million in the first quarter of 2018, a decrease of about 10 percent. The decrease in operating income was primarily related to higher fixed costs. The first quarter Fueling Systems operating income margin was 20.4 percent, a decrease of 300 basis points from the 23.4 percent of net sales in the first quarter of 2018. Operating income margin declined primarily due to lost leverage on fixed costs as growth from higher sales was offset by higher fixed costs.

[0000038725-19-000118:mdna:32]
[same as prior period, unchanged from 0000038725-18-000191:mdna:32]

[0000038725-19-000118:mdna:33]
The Distribution segment recorded an operating loss of $4.3 million in the first quarter of 2019 compared to a $0.8 million loss in the first quarter of 2018. The Distribution loss was primarily due to lower sales volume, higher product costs partially offset by sales price increases, adverse geographic and product sales mix and lost leverage on fixed costs from lower sales.

[0000038725-19-000118:mdna:34]
[same as prior period, unchanged from 0000038725-18-000191:mdna:34]

[0000038725-19-000118:mdna:35]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses.  The intersegment profit elimination impact in the first quarter of 2019 versus the first quarter of 2018 was expense of $0.6 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses were lower by $0.8 million or about 6 percent to last year, primarily due to lower variable incentive-based compensation expenses.

[0000038725-19-000118:mdna:36]
[same as prior period, unchanged from 0000038725-18-000191:mdna:36]

[0000038725-19-000118:mdna:37]
Interest expense for the first quarters of 2019 and 2018 was $2.3 million and $2.4 million, respectively.

[0000038725-19-000118:mdna:38]
[same as prior period, unchanged from 0000038725-18-000191:mdna:38]

[0000038725-19-000118:mdna:39]
Other income or expense was income in the first quarter of 2019 of $0.2 million and a loss of $0.2 million in the first quarter of 2018. Included in other income in the first quarter of 2019 was interest income of $0.2 million, primarily derived from the investment of cash balances in short-term securities. Included in other income in the first quarter of 2018 was interest income of $0.1 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-19-000118:mdna:40]
[same as prior period, unchanged from 0000038725-18-000191:mdna:40]

[0000038725-19-000118:mdna:41]
Foreign currency-based transactions produced a gain of $0.6 million for the first quarter of 2019. Foreign currency-based transactions produced a loss of $0.6 million for the first quarter of 2018.

[0000038725-19-000118:mdna:42]
[same as prior period, unchanged from 0000038725-18-000191:mdna:42]

[0000038725-19-000118:mdna:43]
The provision for income taxes in the first quarter of 2019 was an expense of $1.5 million and for the same period 2018 a benefit of $1.7 million. The effective tax rate for the first quarter of 2019 was about 14 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate for the first quarter of 2018 was a benefit of about 9 percent and, before the impact of discrete events, was about 19 percent. The increase in the effective tax rate was primarily the result of the release of a valuation allowance of $5.4 million related to state net operating losses and incentives during the first quarter of 2018. The tax rate as a percentage of pre-tax earnings for the full year of 2019 is projected to be about 20 percent, compared to the full year 2018 tax rate of about 19 percent, both before discrete adjustments.

[0000038725-19-000118:mdna:44]
[same as prior period, unchanged from 0000038725-18-000191:mdna:45]

[0000038725-19-000118:mdna:45]
Net income for the first quarter of 2019 was $9.1 million compared to the prior year first quarter net income of $21.2 million.  Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2019 was $9.1 million, or $0.19 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $21.2 million or $0.45 per diluted share.

[0000038725-19-000118:mdna:46]
[same as prior period, unchanged from 0000038725-18-000191:mdna:91]

[0000038725-19-000118:mdna:47]
[same as prior period, unchanged from 0000038725-18-000191:mdna:92]

[0000038725-19-000118:mdna:48]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at March 31, 2019 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and exiting credit agreements.

[0000038725-19-000118:mdna:49]
As of March 31, 2019 the Company had $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of March 31, 2019, the Company had $200.6 million borrowing capacity under the Credit Agreement as $3.7

[0000038725-19-000118:mdna:50]
million in letters of commercial and standby letters of credit were outstanding and undrawn and $95.7 million in revolver borrowings were drawn and outstanding which were primarily used for acquisition and working capital needs.

[0000038725-19-000118:mdna:51]
The Company also has other long-term debt borrowing outstanding as of March 31, 2019.  See Note 9 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-19-000118:mdna:52]
At March 31, 2019, the Company had $49.9 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-19-000118:mdna:53]
[same as prior period, unchanged from 0000038725-18-000191:mdna:97]

[0000038725-19-000118:mdna:54]
The following table summarizes significant sources and uses of cash and cash equivalents for the first three months of 2019 and 2018.

[0000038725-19-000118:mdna:55]
| (in millions) |  | 2019 |  | 2018 |
| Net cash used in operating activities |  | $ | (2.9 | ) |  | $ | (27.2 | ) |
| Net cash used in investing activities |  | (10.6 | ) |  | (14.2 | ) |
| Net cash provided by financing activities |  | 9.9 |  |  | 39.7 |  |
| Impact of exchange rates on cash and cash equivalents |  | (1.2 | ) |  | 1.8 |  |
| Change in cash and cash equivalents |  | $ | (4.8 | ) |  | $ | 0.1 |  |

[0000038725-19-000118:mdna:56]
Cash Flows Used in Operating Activities

[0000038725-19-000118:mdna:57]
2019 vs. 2018

[0000038725-19-000118:mdna:58]
Net cash used in operating activities was $2.9 million for the first quarter ended March 31, 2019 compared to $27.2 million used in operating activities for the first quarter ended March 31, 2018.  The decrease in cash used by operating activities was due to a decrease of $30.3 million in working capital requirements, primarily customer accounts receivable and accounts payable offset by a decrease in net earnings of about $6.6 million before the prior year non-cash gain of the release of a valuation allowance in deferred income taxes.

[0000038725-19-000118:mdna:59]
[same as prior period, unchanged from 0000038725-18-000191:mdna:103]

[0000038725-19-000118:mdna:60]
2019 vs. 2018

[0000038725-19-000118:mdna:61]
Net cash used in investing activities was $10.6 million for the first quarter ended March 31, 2019 compared to $14.2 million used in investing activities for the first quarter ended March 31, 2018.  The decrease in cash used in investing activities is primarily attributable to decreased acquisition activity and lower spending for property, plant and equipment during the current year.

[0000038725-19-000118:mdna:62]
Cash Flows Provided by Financing Activities

[0000038725-19-000118:mdna:63]
2019 vs. 2018

[0000038725-19-000118:mdna:64]
Net cash provided by financing activities was $9.9 million for the first quarter ended March 31, 2019 compared to $39.7 million provided by financing activities for the first quarter ended March 31, 2018.  The decrease in cash provided by financing activities was primarily attributable to lower net debt borrowings, down approximately $32.3 million in the current year consistent with reduced working capital requirements as well as an increase in dividends paid of $1.7 million in the current year compared to dividends paid in the prior year.  These were offset by a decrease in common stock repurchases of $3.6 million in the current year compared to common stock repurchases in the prior year.

[0000038725-19-000118:mdna:65]
[same as prior period, unchanged from 0000038725-18-000191:mdna:110]

[0000038725-19-000118:mdna:66]
channels, supply constraints, effect of price increases, raw material costs and availability, technology factors, integration of acquisitions, litigation, government and regulatory actions, the Company’s accounting policies, and other risks, all as described in the Company's Securities and Exchange Commission filings, included in Part I, Item 1A of the Company's Annual Report on Form 10-K for the fiscal year ended December 31, 2018, and in Exhibit 99.1 thereto. Any forward-looking statements included in this Form 10-Q are based upon information presently available. The Company does not assume any obligation to update any forward-looking information, except as required by law.

[0000038725-19-000118:mdna:67]
29
