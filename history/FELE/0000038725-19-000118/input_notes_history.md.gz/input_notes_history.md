# FELE note change history — 0000038725-18-000191 → 0000038725-19-000118


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0000038725-19-000118:note_history:1]
At March 31, 2019, the Company had $7.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2018-11-02, similarity 0.966):
[0000038725-18-000191:note_history:1]
At September 30, 2018, the Company had $4.1 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2019-04-30):
[0000038725-19-000118:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2019, are as follows:
  (was, 2018-11-02, similarity 0.8921):
[0000038725-18-000191:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2018, are as follows:

- changed (2019-04-30):
[0000038725-19-000118:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2018 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 2.5 |  |
| Additions related to acquisitions |  | 0.2 |  |
| Reductions for payments made |  | (2.9 | ) |
| Balance as of March 31, 2019 |  | $ | 8.8 |  |
  (was, 2018-11-02, similarity 0.9717):
[0000038725-18-000191:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2017 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 6.7 |  |
| Additions related to acquisitions |  | 0.1 |  |
| Reductions for payments made |  | (7.7 | ) |
| Balance as of September 30, 2018 |  | $ | 8.6 |  |

- added (2019-04-30):
[0000038725-19-000118:note_history:4]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. These financing leases are immaterial to the Company.

- added (2019-04-30):
[0000038725-19-000118:note_history:5]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilized its incremental borrowing rate based on the information available as of the adoption of ASU 2016-02 or at the inception of any new leases entered into thereafter when determining the present value of future lease payments.

- added (2019-04-30):
[0000038725-19-000118:note_history:6]
Some of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.

- added (2019-04-30):
[0000038725-19-000118:note_history:7]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2019 are as follows:

- added (2019-04-30):
[0000038725-19-000118:note_history:8]
| Lease Cost (in millions): |  |  |
| Operating lease cost |  | $ | 2.8 |  |
| Short-term lease cost |  | 0.1 |  |
| Other Information: |  |  |
| Weighted-average remaining lease term |  | 6 years |  |
| Weighted-average discount rate |  | 4.4 | % |

- added (2019-04-30):
[0000038725-19-000118:note_history:9]
As of March 31, 2019 the Company has approximately $1.4 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.

- added (2019-04-30):
[0000038725-19-000118:note_history:10]
The minimum rental payments for non-cancellable operating leases as of March 31, 2019, are as follows:

- added (2019-04-30):
[0000038725-19-000118:note_history:11]
| (In millions) | 2019 | 2020 | 2021 | 2022 | 2023 | Thereafter |
| Future Minimum Rental Payments | $ | 7.0 |  | $ | 7.2 |  | $ | 4.9 |  | $ | 3.4 |  | $ | 2.5 |  | $ | 6.7 |  |

- added (2019-04-30):
[0000038725-19-000118:note_history:12]
The minimum rental payments for non-cancellable operating leases as of December 31, 2018, were reported as follows:

- added (2019-04-30):
[0000038725-19-000118:note_history:13]
| (In millions) | 2019 | 2020 | 2021 | 2022 | 2023 | Thereafter |
| Future Minimum Rental Payments | $ | 8.9 |  | $ | 5.9 |  | $ | 3.5 |  | $ | 2.0 |  | $ | 1.1 |  | $ | 5.7 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0000038725-19-000118:note_history:14]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2018, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2019, and for the first quarters ended March 31, 2019 and March 31, 2018 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the first quarter ended March 31, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2019.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2018.
  (was, 2018-11-02, similarity 0.9366):
[0000038725-18-000191:note_history:14]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2017, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2018, and for the third quarters and nine months ended September 30, 2018 and September 30, 2017 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the third quarter and nine months ended September 30, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2018.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2017.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0000038725-19-000118:note_history:15]
| (In millions) |  | March 31, 2019 |  | December 31, 2018 |
| Prudential Agreement |  | $ | 30.0 |  |  | $ | 30.0 |  |
| Tax increment financing debt |  | 19.3 |  |  | 19.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 95.7 |  |  | 76.3 |  |
| Financing Leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 5.8 |  |  | 5.4 |  |
| Less: unamortized debt issuance costs |  | (0.1 | ) |  | (0.2 | ) |
|  |  | $ | 225.8 |  |  | $ | 206.4 |  |
| Less: current maturities |  | (132.0 | ) |  | (112.0 | ) |
| Long-term debt |  | $ | 93.8 |  |  | $ | 94.4 |  |
  (was, 2018-11-02, similarity 0.8606):
[0000038725-18-000191:note_history:15]
| (In millions) |  | September 30, 2018 |  | December 31, 2017 |
| Prudential Agreement |  | $ | 30.0 |  |  | $ | 60.0 |  |
| Tax increment financing debt |  | 19.7 |  |  | 20.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 89.1 |  |  | 67.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.4 |  |  | 3.5 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 217.0 |  |  | $ | 226.1 |  |
| Less: current maturities |  | (122.8 | ) |  | (100.5 | ) |
| Long-term debt |  | $ | 94.2 |  |  | $ | 125.6 |  |

- changed (2019-04-30):
[0000038725-19-000118:note_history:16]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2019 matures as follows:
  (was, 2018-11-02, similarity 0.9474):
[0000038725-18-000191:note_history:16]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2018 matures as follows:

- changed (2019-04-30):
[0000038725-19-000118:note_history:17]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 225.8 |  |  | $ | 132.0 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 88.7 |  |
| Financing Leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 225.9 |  |  | $ | 132.0 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 88.7 |  |
  (was, 2018-11-02, similarity 0.9806):
[0000038725-18-000191:note_history:17]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 217.2 |  |  | $ | 122.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 89.4 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 217.3 |  |  | $ | 122.8 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 89.4 |  |

- changed (2019-04-30):
[0000038725-19-000118:note_history:18]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of March 31, 2019, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.
  (was, 2018-11-02, similarity 0.9884):
[0000038725-18-000191:note_history:18]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of September 30, 2018, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

- changed (2019-04-30):
[0000038725-19-000118:note_history:19]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As
  (was, 2018-11-02, similarity 0.9194):
[0000038725-18-000191:note_history:19]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2018, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

- added (2019-04-30):
[0000038725-19-000118:note_history:20]
of March 31, 2019, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

- changed (2019-04-30):
[0000038725-19-000118:note_history:21]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.
  (was, 2018-11-02, similarity 0.8253):
[0000038725-18-000191:note_history:21]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable

- changed (2019-04-30):
[0000038725-19-000118:note_history:22]
As of March 31, 2019, the Company had $95.7 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $3.7 million in letters of credit outstanding, and $200.6 million of available capacity under the Credit Agreement.
  (was, 2018-11-02, similarity 0.9719):
[0000038725-18-000191:note_history:22]
As of September 30, 2018, the Company had $89.1 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $5.6 million in letters of credit outstanding, and $205.3 million of available capacity under the Credit Agreement.

- changed (2019-04-30):
[0000038725-19-000118:note_history:23]
Covenants
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2019.
  (was, 2018-11-02, similarity 0.9941):
[0000038725-18-000191:note_history:23]
Covenants
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of September 30, 2018.

- removed (2019-04-30):
[0000038725-18-000191:note_history:24]
quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0000038725-19-000118:note_history:25]
| (In millions) |  | March 31, 2019 |  | December 31, 2018 |
| Prudential Agreement |  | $ | 30.0 |  |  | $ | 30.0 |  |
| Tax increment financing debt |  | 19.3 |  |  | 19.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 95.7 |  |  | 76.3 |  |
| Financing Leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 5.8 |  |  | 5.4 |  |
| Less: unamortized debt issuance costs |  | (0.1 | ) |  | (0.2 | ) |
|  |  | $ | 225.8 |  |  | $ | 206.4 |  |
| Less: current maturities |  | (132.0 | ) |  | (112.0 | ) |
| Long-term debt |  | $ | 93.8 |  |  | $ | 94.4 |  |
  (was, 2018-11-02, similarity 0.8606):
[0000038725-18-000191:note_history:25]
| (In millions) |  | September 30, 2018 |  | December 31, 2017 |
| Prudential Agreement |  | $ | 30.0 |  |  | $ | 60.0 |  |
| Tax increment financing debt |  | 19.7 |  |  | 20.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 89.1 |  |  | 67.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.4 |  |  | 3.5 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 217.0 |  |  | $ | 226.1 |  |
| Less: current maturities |  | (122.8 | ) |  | (100.5 | ) |
| Long-term debt |  | $ | 94.2 |  |  | $ | 125.6 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-04-30):
[0000038725-19-000118:note_history:26]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2019 matures as follows:
  (was, 2018-11-02, similarity 0.9474):
[0000038725-18-000191:note_history:26]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2018 matures as follows:

- changed (2019-04-30):
[0000038725-19-000118:note_history:27]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 225.8 |  |  | $ | 132.0 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 88.7 |  |
| Financing Leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 225.9 |  |  | $ | 132.0 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 88.7 |  |
  (was, 2018-11-02, similarity 0.9806):
[0000038725-18-000191:note_history:27]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 217.2 |  |  | $ | 122.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 89.4 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 217.3 |  |  | $ | 122.8 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 89.4 |  |
