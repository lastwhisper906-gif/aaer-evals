# FELE notes — 0000038725-19-000118


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-19-000118:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2018, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2019, and for the first quarters ended March 31, 2019 and March 31, 2018 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the first quarter ended March 31, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2019.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2018.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-19-000118:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-19-000118:notes:3]
In February 2018, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 ("Tax Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The ASU is effective for interim and annual periods beginning after December 15, 2018, with early adoption permitted, and may be applied either at the beginning of the period of adoption or retrospectively to each period in which the effect of the change in the U.S. federal corporate income tax rate in the Tax Act is recognized. The Company adopted the standard effective January 1, 2019 and did not reclassify tax effects stranded in accumulated other comprehensive loss.  As such, there is no impact on the Company’s consolidated financial position, results of operations, and cash flows as a result of the adoption of the ASU.

[0000038725-19-000118:notes:4]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification (“ASC”) Topic 840.  This ASU requires lessees to present right-of-use (“ROU”) assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases and ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-10 clarifies certain aspects of Topic 842, including the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options, variable payments that depend on an index or rate and certain transition adjustments, among other things. ASU 2018-11 allows entities adopting ASU 2016-02 to choose an additional (and optional) transition method of adoption, under which an entity initially applies the new lease standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. Additionally, ASU 2018-11 allows lessors to not separate non-lease components from the associated lease component if certain conditions are met. The guidance is to be applied using either the transition method prescribed in ASU 2018-11 or a modified retrospective approach at the beginning of the earliest comparative period in the financial statements.

[0000038725-19-000118:notes:5]
The Company adopted the standard effective January 1, 2019 utilizing the optional transition method prescribed in ASU 2018-11. The Company utilized the transition practical expedients, per ASC 842-10-65-11, that are permitted with the new standard when elected as a package. The Company will also utilize other available practical expedients, including the election not to separate non-lease components and the election to use hindsight when determining the lease terms. Finally, the Company has made an accounting policy election to not present leases with an initial term of 12 months or less (short-term leases) on the balance sheet.

[0000038725-19-000118:notes:6]
The Company has recorded on the Balance Sheet ROU assets and lease liabilities. The initial ROU asset at the implementation of the standard was approximately $26.3 million with a corresponding lease liability of the same amount. The Company segregated the lease liabilities between short term and long term based on the related contractual maturities. The Company has recognized the cash paid for lease liabilities in the Statement of Cash Flows. The Company did not have an adjustment to retained earnings as a result of the adoption of this standard.  Additional disclosures regarding the Company’s leases can be found in Footnote 14 - Commitments and Contingencies.

[0000038725-19-000118:notes:7]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) as modified by subsequently issued ASUs 2015-14, 2016-08, 2016-10, 2016-12 and 2016-20 (collectively ASU 2014-09).  Topic 606 supersedes the revenue recognition requirements in Accounting Standards Codification (“ASC”) Topic 605, Revenue Recognition (“Topic 605”), and requires the recognition of revenue when promised goods or services are transferred to

[0000038725-19-000118:notes:8]
customers in an amount that reflects the considerations to which the entity expects to be entitled to in exchange for those goods or services.  The Company made the accounting policy election allowed by ASC 606-10-32-2A to continue to present sales tax on a net basis, consistent with current guidance in ASC 605-45-15-2(e).  The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method).  The Company adopted ASU 2014-09 during the first quarter ended March 31, 2018 utilizing the modified retrospective approach. The adoption of this ASU did not have a material impact to the Company’s condensed consolidated financial position, results of operations, or cash flow; however, the adoption of this ASU requires the Company to disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company completed its assessment of the additional disclosure requirements with the following results:

[0000038725-19-000118:notes:9]
Disaggregation of Revenue

[0000038725-19-000118:notes:10]
The adoption of this ASU requires the Company to disaggregate revenue into categories to depict how the nature, timing, and uncertainty of revenue and cash flows are affected by economic factors.  As evidenced in Footnote 13 Segment and Geographic Information, the Company’s business consists of the Water, Fueling, Distribution, and Other segments. The Other segment includes unallocated corporate expenses and intersegment eliminations. A reconciliation of disaggregated revenue to segment revenue as well as Water Segment revenue by geographical regions is provided in Footnote 13, consistent with how the Company evaluates financial performance.

[0000038725-19-000118:notes:11]
Performance Obligations

[0000038725-19-000118:notes:12]
A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in ASC Topic 606.  The Company typically sells its products to customers by purchase order, and does not have any additional performance obligations included in contracts to customers other than the shipment of products. The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience. The Company typically ships products FOB shipping at which point control of the products passes to the customers. Any shipping and handling fees prior to shipment are considered activities required to fulfill the Company’s promise to transfer goods, and do not qualify as a separate performance obligation. Shipping and handling costs are recorded as a component of cost of sales.  Additionally, the Company offers assurance-type warranties (vs. service warranties) which do not qualify as a separate performance obligation. Therefore, the Company allocates the transaction price based on a single performance obligation.  The Company offers normal and customary trade terms to its customers, no significant part of which is of an extended nature.  The Company considers the performance obligation satisfied and recognizes revenue at a point in time, the time of shipment.  The Company does not generally allow for refunds or returns to customers and does not have outstanding performance obligations for contracts with original durations of greater than one year at the end of the reporting period.

[0000038725-19-000118:notes:13]
Contract Costs

[0000038725-19-000118:notes:14]
The Company does not have outstanding contracts with an original term greater than one year; therefore, the Company expenses costs to obtain a contract as incurred.

[0000038725-19-000118:notes:15]
Accounting Standards Issued But Not Yet Adopted

[0000038725-19-000118:notes:16]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which modifies the disclosure requirements for employers that sponsor defined benefit pension or other postretirement plans. The amendments remove disclosures that no longer are considered cost beneficial, including the estimated amounts in accumulated other comprehensive income expected to be recognized as components of net periodic expense over the next fiscal year. The amendments clarify the specific requirements of disclosures, and add disclosure requirements identified as relevant, including the reasons for significant gains and losses related to change in the benefit obligation for the period.  The ASU should be applied retrospectively and is effective for interim and annual periods beginning after December 15, 2020. The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-19-000118:notes:17]
In August 2018, the FASB issued ASU 2018-15, Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. This ASU aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with

[0000038725-19-000118:notes:18]
the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include internal-use software license). The ASU should be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption and is effective for interim and annual periods beginning after December 15, 2019 with early adoption permitted. The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-19-000118:notes:19]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-19-000118:notes:20]
ACQUISITIONS
During the first quarter ended March 31, 2019, the Company acquired 100 percent of the ownership interests of Mt. Pleasant, Michigan-based Milan Supply Company ("Milan Supply"), for a purchase price of approximately $6.1 million after working capital adjustments. Milan Supply is a professional groundwater distributor operating six locations in the State of Michigan.  Milan Supply is part of the Company’s Distribution Segment, which is a collection of professional groundwater equipment distributors.  The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2019, as the results of operations for this acquisition is immaterial.

[0000038725-19-000118:notes:21]
During the third quarter ended September 30, 2018, the Company acquired, in separate transactions, substantially all of the assets of Stationary Power Division ("SPD") of Midtronics, Inc., and 100 percent of the ownership interest in Industrias Rotor Pump S.A. ("Industrias Rotor Pump") for a combined purchase price of approximately $37 million. The acquisitions were not material individually or in the aggregate.  The fair value of the assets acquired and the liabilities assumed are preliminary as of March 31, 2019.

[0000038725-19-000118:notes:22]
During the first quarter ended March 31, 2018, the Company acquired 100 percent of the ownership interests of Valley Farms Supply, Inc ("Valley Farms"). The fair value of the assets acquired and the liabilities assumed related to the Valley Farms acquisition are considered final as of March 31, 2019, and the final purchase price was $9.5 million after working capital adjustments.  The Company has not presented fair values of the assets acquired and the liabilities assumed as the values are not material.

[0000038725-19-000118:notes:23]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations.  There were $0.0 million and $0.1 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the first quarters ended March 31, 2019 and March 31, 2018, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-19-000118:notes:24]
[same as prior period, unchanged from 0000038725-18-000191:notes:36]

[0000038725-19-000118:notes:25]
[same as prior period, unchanged from 0000038725-18-000191:notes:37]

[0000038725-19-000118:notes:26]
[same as prior period, unchanged from 0000038725-18-000191:notes:38]

[0000038725-19-000118:notes:27]
[same as prior period, unchanged from 0000038725-18-000191:notes:39]

[0000038725-19-000118:notes:28]
As of March 31, 2019 and December 31, 2018, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-19-000118:notes:29]
| (In millions) | March 31, 2019 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.5 |  | $ | 3.5 |  | $ | — |  | $ | — |  |
|  | December 31, 2018 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 2.5 |  | $ | 2.5 |  | $ | — |  | $ | — |  |

[0000038725-19-000118:notes:30]
[same as prior period, unchanged from 0000038725-18-000191:notes:42]

[0000038725-19-000118:notes:31]
[same as prior period, unchanged from 0000038725-18-000191:notes:43]

[0000038725-19-000118:notes:32]
Total debt, including current maturities, have carrying amounts of $225.7 million and $206.3 million and estimated fair values of $228 million and $205 million as of March 31, 2019 and December 31, 2018, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-19-000118:notes:33]
FINANCIAL INSTRUMENTSThe Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of March 31, 2019, the swap had a notional value based on 235,000 shares.  For the first quarters ended March 31, 2019 and March 31, 2018, the swap resulted in a gain of $1.9 million and a loss of  $1.1 million, respectively. Gains and losses resulting from the the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-19-000118:notes:34]
[same as prior period, unchanged from 0000038725-18-000191:notes:46]

[0000038725-19-000118:notes:35]
| (In millions) |  | March 31, 2019 |  | December 31, 2018 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.9 | ) |  | $ | 7.5 |  |  | $ | (6.9 | ) |
| Technology |  | 7.5 |  |  | (6.5 | ) |  | 7.5 |  |  | (6.4 | ) |
| Customer relationships |  | 150.8 |  |  | (65.6 | ) |  | 151.0 |  |  | (63.8 | ) |
| Other |  | 2.8 |  |  | (2.6 | ) |  | 2.8 |  |  | (2.5 | ) |
| Total |  | $ | 168.6 |  |  | $ | (81.6 | ) |  | $ | 168.8 |  |  | $ | (79.6 | ) |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 45.8 |  |  | — |  |  | 45.9 |  |  | — |  |
| Total intangibles |  | $ | 214.4 |  |  | $ | (81.6 | ) |  | $ | 214.7 |  |  | $ | (79.6 | ) |

[0000038725-19-000118:notes:36]
Amortization expense related to intangible assets for the first quarters ended March 31, 2019 and March 31, 2018 was $2.3 million and $2.2 million, respectively.

[0000038725-19-000118:notes:37]
[same as prior period, unchanged from 0000038725-18-000191:notes:49]

[0000038725-19-000118:notes:38]
| (In millions) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |
|  |  | $ | 9.2 |  |  | $ | 9.0 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |  | $ | 8.4 |  |

[0000038725-19-000118:notes:39]
The change in the carrying amount of goodwill by reportable segment for the three months ended March 31, 2019, is as follows:

[0000038725-19-000118:notes:40]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2018 |  | $ | 145.5 |  |  | $ | 67.5 |  |  | $ | 35.7 |  |  | $ | 248.7 |  |
| Acquisitions |  | — |  |  | — |  |  | 1.7 |  |  | 1.7 |  |
| Foreign currency translation |  | (0.6 | ) |  | 0.1 |  |  | — |  |  | (0.5 | ) |
| Balance as of March 31, 2019 |  | $ | 144.9 |  |  | $ | 67.6 |  |  | $ | 37.4 |  |  | $ | 249.9 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-19-000118:notes:41]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of March 31, 2019, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2018 measurement date for these plans.  One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-19-000118:notes:42]
[same as prior period, unchanged from 0000038725-18-000191:notes:54]

[0000038725-19-000118:notes:43]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the first quarters ended March 31, 2019 and March 31, 2018:

[0000038725-19-000118:notes:44]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | First Quarter Ended |  | First Quarter Ended |
|  | March 31, 2019 |  | March 31, 2018 |  | March 31, 2019 |  | March 31, 2018 |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 1.5 |  |  | 1.3 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | (2.0 | ) |  | (2.1 | ) |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.6 |  |  | 0.7 |  |  | — |  |  | 0.1 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.3 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |

[0000038725-19-000118:notes:45]
In the first quarter ended March 31, 2019, the Company made contributions of $0.0 million to the funded plans.   The amount of contributions to be made to the plans during the calendar year 2019 will be finalized by September 15, 2019, based upon the funding level requirements identified and year-end valuation performed at December 31, 2018.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-19-000118:notes:46]
INCOME TAXES
The Company’s effective tax rate from continuing operations for the three month period ended March 31, 2019 was 13.9 percent as compared to negative 8.7 percent for the three month period ended March 31, 2018. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to foreign earnings taxed at rates below the U.S. statutory rate, t

[0000038725-19-000118:notes:47]
he recognition of the foreign-derived intangible income (FDII) provisions, and certain discrete events including excess tax benefits from share-based compensation.

[0000038725-19-000118:notes:48]
The increase in the effective tax rate for the three months ended March 31, 2019, compared with the same period in 2018, was primarily a result of the release of a valuation allowance of $5.4 million related to NOLs and incentives during the three month period ended March 31, 2018.


## us-gaap:DebtDisclosureTextBlock

[0000038725-19-000118:notes:49]
DEBT
Debt consisted of the following:

[0000038725-19-000118:notes:50]
| (In millions) |  | March 31, 2019 |  | December 31, 2018 |
| Prudential Agreement |  | $ | 30.0 |  |  | $ | 30.0 |  |
| Tax increment financing debt |  | 19.3 |  |  | 19.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 95.7 |  |  | 76.3 |  |
| Financing Leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 5.8 |  |  | 5.4 |  |
| Less: unamortized debt issuance costs |  | (0.1 | ) |  | (0.2 | ) |
|  |  | $ | 225.8 |  |  | $ | 206.4 |  |
| Less: current maturities |  | (132.0 | ) |  | (112.0 | ) |
| Long-term debt |  | $ | 93.8 |  |  | $ | 94.4 |  |

[0000038725-19-000118:notes:51]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2019 matures as follows:

[0000038725-19-000118:notes:52]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 225.8 |  |  | $ | 132.0 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 88.7 |  |
| Financing Leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 225.9 |  |  | $ | 132.0 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 88.7 |  |

[0000038725-19-000118:notes:53]
Prudential Agreement

[0000038725-19-000118:notes:54]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of March 31, 2019, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-19-000118:notes:55]
Project Bonds

[0000038725-19-000118:notes:56]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-19-000118:notes:57]
New York Life Agreement

[0000038725-19-000118:notes:58]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As

[0000038725-19-000118:notes:59]
of March 31, 2019, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-19-000118:notes:60]
Credit Agreement

[0000038725-19-000118:notes:61]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-19-000118:notes:62]
As of March 31, 2019, the Company had $95.7 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $3.7 million in letters of credit outstanding, and $200.6 million of available capacity under the Credit Agreement.

[0000038725-19-000118:notes:63]
Covenants
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2019.


## us-gaap:EarningsPerShareTextBlock

[0000038725-19-000118:notes:64]
[same as prior period, unchanged from 0000038725-18-000191:notes:80]

[0000038725-19-000118:notes:65]
[same as prior period, unchanged from 0000038725-18-000191:notes:81]

[0000038725-19-000118:notes:66]
[same as prior period, unchanged from 0000038725-18-000191:notes:82]

[0000038725-19-000118:notes:67]
|  | First Quarter Ended |
| (In millions, except per share amounts) | March 31, 2019 |  | March 31, 2018 |
| Numerator: |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 9.1 |  |  | $ | 21.2 |  |
| Less: Earnings allocated to participating securities | 0.1 |  |  | 0.2 |  |
| Net income available to common shareholders | $ | 9.0 |  |  | $ | 21.0 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.3 |  |  | 46.6 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.4 |  |  | 0.5 |  |
| Diluted weighted average common shares outstanding | 46.7 |  |  | 47.1 |  |
| Basic earnings per share | $ | 0.19 |  |  | $ | 0.45 |  |
| Diluted earnings per share | $ | 0.19 |  |  | $ | 0.45 |  |

[0000038725-19-000118:notes:68]
There were 0.1 million and 0.3 million stock options outstanding for the first quarters ended March 31, 2019 and March 31, 2018, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-19-000118:notes:69]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the first quarters ended March 31, 2019 and March 31, 2018:

[0000038725-19-000118:notes:70]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2018 | $ | 4,632 |  |  | $ | 257,535 |  |  | $ | 654,724 |  |  | $ | (48,585 | ) |  | $ | (134,434 | ) |  | $ | 1,955 |  |  | $ | 735,827 |  |  | $ | 518 |  |
| Net income |  |  |  |  | 9,056 |  |  |  |  |  |  | 174 |  |  | 9,230 |  |  | (103 | ) |
| Dividends on common stock ($0.145/share) |  |  |  |  | (6,723 | ) |  |  |  |  |  |  |  | (6,723 | ) |  |  |
| Common stock issued | 6 |  |  | 1,245 |  |  |  |  |  |  |  |  |  |  | 1,251 |  |  |  |
| Common stock repurchased | (9 | ) |  |  |  | (4,320 | ) |  |  |  |  |  |  |  | (4,329 | ) |  |  |
| Share-based compensation | 8 |  |  | 3,222 |  |  |  |  |  |  |  |  |  |  | 3,230 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (2,771 | ) |  | (32 | ) |  | (2,803 | ) |  | (7 | ) |
| Pension liability, net of tax |  |  |  |  |  |  | 509 |  |  |  |  |  |  | 509 |  |  |  |
| Balance as of March 31, 2019 | $ | 4,637 |  |  | $ | 262,002 |  |  | $ | 652,737 |  |  | $ | (48,076 | ) |  | $ | (137,205 | ) |  | $ | 2,097 |  |  | $ | 736,192 |  |  | $ | 408 |  |

[0000038725-19-000118:notes:71]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2017 | $ | 4,663 |  |  | $ | 240,136 |  |  | $ | 604,905 |  |  | $ | (49,364 | ) |  | $ | (99,683 | ) |  | $ | 1,964 |  |  | $ | 702,621 |  |  | $ | 1,502 |  |
| Net Income |  |  |  |  | 21,174 |  |  |  |  |  |  | 195 |  |  | 21,369 |  |  | (154 | ) |
| Dividends on common stock ($0.1075/share) |  |  |  |  | (5,037 | ) |  |  |  |  |  |  |  | (5,037 | ) |  |  |
| Common stock issued | 3 |  |  | 639 |  |  |  |  |  |  |  |  |  |  | 642 |  |  |  |
| Common stock repurchased | (20 | ) |  |  |  | (7,929 | ) |  |  |  |  |  |  |  | (7,949 | ) |  |  |
| Share-based compensation | 6 |  |  | 3,320 |  |  |  |  |  |  |  |  |  |  | 3,326 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 6,943 |  |  | 40 |  |  | 6,983 |  |  | 12 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 601 |  |  |  |  |  |  | 601 |  |  |  |
| Balance as of March 31, 2018 | $ | 4,652 |  |  | $ | 244,095 |  |  | $ | 613,113 |  |  | $ | (48,763 | ) |  | $ | (92,740 | ) |  | $ | 2,199 |  |  | $ | 722,556 |  |  | $ | 1,360 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-19-000118:notes:72]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS) 
Changes in accumulated other comprehensive income/(loss) by component for the first quarters ended March 31, 2019 and March 31, 2018, are summarized below:

[0000038725-19-000118:notes:73]
| (In millions) |  |  |  |  |  |
| For the first quarter ended March 31, 2019: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2018 | $ | (134.5 | ) |  | $ | (48.5 | ) |  | $ | (183.0 | ) |
| Other comprehensive income/(loss) before reclassifications | (2.8 | ) |  | — |  |  | (2.8 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.5 |  |  | 0.5 |  |
| Net other comprehensive income/(loss) | (2.8 | ) |  | 0.5 |  |  | (2.3 | ) |
| Balance as of March 31, 2019 | $ | (137.3 | ) |  | $ | (48.0 | ) |  | $ | (185.3 | ) |
| For the first quarter ended March 31, 2018 |  |  |  |  |  |
| Balance as of December 31, 2017 | $ | (99.7 | ) |  | $ | (49.3 | ) |  | $ | (149.0 | ) |
| Other comprehensive income/(loss) before reclassifications | 6.9 |  |  | — |  |  | 6.9 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.6 |  |  | 0.6 |  |
| Net other comprehensive income/(loss) | 6.9 |  |  | 0.6 |  |  | 7.5 |  |
| Balance as of March 31, 2018 | $ | (92.8 | ) |  | $ | (48.7 | ) |  | $ | (141.5 | ) |

[0000038725-19-000118:notes:74]
[same as prior period, unchanged from 0000038725-18-000191:notes:89]

[0000038725-19-000118:notes:75]
(2) Net of tax expense of $0.1 million and $0.2 million for the three months ended March 31, 2019 and March 31, 2018, respectively.

[0000038725-19-000118:notes:76]
[same as prior period, unchanged from 0000038725-18-000191:notes:91]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-19-000118:notes:77]
SEGMENT AND GEOGRAPHIC INFORMATION
The accounting policies of the operating segments are the same as those described in Note 1 of the Company's Form 10-K.  Revenue is recognized based on the invoice price at the point in time when the customer obtains control of the product, which is typically upon shipment to the customer.  The Water and Fueling segments include manufacturing operations and supply certain components and finished goods, both between segments and to the Distribution segment.  The Company reports these product transfers between Water and Fueling as inventory transfers as a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes.  The Company reports intersegment transfers from Water to Distribution as intersegment revenue at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water and Distribution segments.

[0000038725-19-000118:notes:78]
Segment operating income is a key financial performance measure. Operating income by segment is based on net sales less identifiable operating expenses and allocations and includes profits recorded on sales to other segments of the Company.  During the first quarter of 2019, the Company changed management reporting for transfers of certain products between the Water and Fueling segments. This reclassification resulted in $0.8 million of sales and $0.1 million of operating income for the quarter ended March 31, 2018, being reclassified from the Fueling Segment to the Water segment. There is no impact on the Company's previously reported consolidated financial position, results of operations, or cash flows.

[0000038725-19-000118:notes:79]
[same as prior period, unchanged from 0000038725-18-000191:notes:93]

[0000038725-19-000118:notes:80]
|  | First Quarter Ended |
| (In millions) | March 31, 2019 |  | March 31, 2018 |
|  | Net sales |
| Water Systems |  |  |  |
| External sales |  |  |  |
| United States & Canada | $ | 86.8 |  |  | $ | 84.7 |  |
| Latin America | 30.5 |  |  | 29.1 |  |
| Europe, Middle East & Africa | 37.7 |  |  | 46.2 |  |
| Asia Pacific | 22.2 |  |  | 20.8 |  |
| Intersegment sales |  |  |  |
| United States & Canada | 11.2 |  |  | 11.8 |  |
| Total sales | 188.4 |  |  | 192.6 |  |
| Distribution |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 53.3 |  |  | 56.2 |  |
| Intersegment sales | — |  |  | — |  |
| Total sales | 53.3 |  |  | 56.2 |  |
| Fueling Systems |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 35.1 |  |  | 32.0 |  |
| All other | 25.1 |  |  | 26.6 |  |
| Intersegment sales | — |  |  | — |  |
| Total sales | 60.2 |  |  | 58.6 |  |
| Intersegment Eliminations/Other | (11.2 | ) |  | (11.8 | ) |
| Consolidated | $ | 290.7 |  |  | $ | 295.6 |  |
|  | First Quarter Ended |
|  | March 31, 2019 |  | March 31, 2018 |
|  | Operating income/(loss) |
| Water Systems | $ | 19.2 |  |  | $ | 25.1 |  |
| Distribution | (4.3 | ) |  | (0.8 | ) |
| Fueling Systems | 12.3 |  |  | 13.7 |  |
| Intersegment Eliminations/Other | (15.1 | ) |  | (15.3 | ) |
| Consolidated | $ | 12.1 |  |  | $ | 22.7 |  |

[0000038725-19-000118:notes:81]
|  | March 31, 2019 |  | December 31, 2018 |
|  | Total assets |
| Water Systems | $ | 694.3 |  |  | $ | 679.7 |  |
| Distribution | 185.1 |  |  | 165.1 |  |
| Fueling Systems | 283.5 |  |  | 275.7 |  |
| Other | 65.9 |  |  | 61.9 |  |
| Consolidated | $ | 1,228.8 |  |  | $ | 1,182.4 |  |

[0000038725-19-000118:notes:82]
[same as prior period, unchanged from 0000038725-18-000191:notes:96]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-19-000118:notes:83]
COMMITMENTS AND CONTINGENCIES
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-19-000118:notes:84]
At March 31, 2019, the Company had $7.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-19-000118:notes:85]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-19-000118:notes:86]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2019, are as follows:

[0000038725-19-000118:notes:87]
| (In millions) |  |  |
| Balance as of December 31, 2018 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 2.5 |  |
| Additions related to acquisitions |  | 0.2 |  |
| Reductions for payments made |  | (2.9 | ) |
| Balance as of March 31, 2019 |  | $ | 8.8 |  |

[0000038725-19-000118:notes:88]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. These financing leases are immaterial to the Company.

[0000038725-19-000118:notes:89]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilized its incremental borrowing rate based on the information available as of the adoption of ASU 2016-02 or at the inception of any new leases entered into thereafter when determining the present value of future lease payments.

[0000038725-19-000118:notes:90]
Some of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.

[0000038725-19-000118:notes:91]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2019 are as follows:

[0000038725-19-000118:notes:92]
| Lease Cost (in millions): |  |  |
| Operating lease cost |  | $ | 2.8 |  |
| Short-term lease cost |  | 0.1 |  |
| Other Information: |  |  |
| Weighted-average remaining lease term |  | 6 years |  |
| Weighted-average discount rate |  | 4.4 | % |

[0000038725-19-000118:notes:93]
As of March 31, 2019 the Company has approximately $1.4 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.

[0000038725-19-000118:notes:94]
The minimum rental payments for non-cancellable operating leases as of March 31, 2019, are as follows:

[0000038725-19-000118:notes:95]
| (In millions) | 2019 | 2020 | 2021 | 2022 | 2023 | Thereafter |
| Future Minimum Rental Payments | $ | 7.0 |  | $ | 7.2 |  | $ | 4.9 |  | $ | 3.4 |  | $ | 2.5 |  | $ | 6.7 |  |

[0000038725-19-000118:notes:96]
The minimum rental payments for non-cancellable operating leases as of December 31, 2018, were reported as follows:

[0000038725-19-000118:notes:97]
| (In millions) | 2019 | 2020 | 2021 | 2022 | 2023 | Thereafter |
| Future Minimum Rental Payments | $ | 8.9 |  | $ | 5.9 |  | $ | 3.5 |  | $ | 2.0 |  | $ | 1.1 |  | $ | 5.7 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-19-000118:notes:98]
[same as prior period, unchanged from 0000038725-18-000191:notes:102]

[0000038725-19-000118:notes:99]
[same as prior period, unchanged from 0000038725-18-000191:notes:103]

[0000038725-19-000118:notes:100]
[same as prior period, unchanged from 0000038725-18-000191:notes:104]

[0000038725-19-000118:notes:101]
[same as prior period, unchanged from 0000038725-18-000191:notes:105]

[0000038725-19-000118:notes:102]
[same as prior period, unchanged from 0000038725-18-000191:notes:106]

[0000038725-19-000118:notes:103]
[same as prior period, unchanged from 0000038725-18-000191:notes:107]

[0000038725-19-000118:notes:104]
[same as prior period, unchanged from 0000038725-18-000191:notes:108]

[0000038725-19-000118:notes:105]
[same as prior period, unchanged from 0000038725-18-000191:notes:109]

[0000038725-19-000118:notes:106]
[same as prior period, unchanged from 0000038725-18-000191:notes:110]

[0000038725-19-000118:notes:107]
[same as prior period, unchanged from 0000038725-18-000191:notes:111]

[0000038725-19-000118:notes:108]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the first quarters ended March 31, 2019 and March 31, 2018 are as follows:

[0000038725-19-000118:notes:109]
|  |  | March 31, 2019 |  | March 31, 2018 |
| Risk-free interest rate |  | 2.53 | % |  | 2.69 | % |
| Dividend yield |  | 1.05 | % |  | 1.05 | % |
| Volatility factor |  | 29.38 | % |  | 28.71 | % |
| Expected term |  | 5.5 years |  |  | 5.6 years |  |

[0000038725-19-000118:notes:110]
A summary of the Company’s outstanding stock option activity and related information for the first quarter ended March 31, 2019 is as follows:

[0000038725-19-000118:notes:111]
| (Shares in thousands) |  | March 31, 2019 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,229 |  |  | $ | 33.25 |  |
| Granted |  | 190 |  |  | 55.16 |  |
| Exercised |  | (59 | ) |  | 21.14 |  |
| Forfeited |  | — |  |  | — |  |
| Outstanding at end of period |  | 1,360 |  |  | $ | 36.84 |  |
| Expected to vest after applying forfeiture rate |  | 1,351 |  |  | $ | 36.78 |  |
| Vested and exercisable at end of period |  | 839 |  |  | $ | 31.86 |  |

[0000038725-19-000118:notes:112]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of March 31, 2019 is as follows:

[0000038725-19-000118:notes:113]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 6.55 years |  | $ | 20,155 |  |
| Expected to vest after applying forfeiture rate |  | 6.53 years |  | $ | 20,088 |  |
| Vested and exercisable at end of period |  | 5.10 years |  | $ | 16,129 |  |

[0000038725-19-000118:notes:114]
The total intrinsic value of options exercised during the first quarters ended March 31, 2019 and March 31, 2018 was $2.0 million and $0.4 million, respectively.

[0000038725-19-000118:notes:115]
As of March 31, 2019, there was $2.4 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.17 years.

[0000038725-19-000118:notes:116]
[same as prior period, unchanged from 0000038725-18-000191:notes:120]

[0000038725-19-000118:notes:117]
A summary of the Company’s restricted stock/stock unit award activity and related information for the first quarter ended March 31, 2019 is as follows:

[0000038725-19-000118:notes:118]
| (Shares in thousands) |  | March 31, 2019 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 498 |  |  | $ | 37.27 |  |
| Awarded |  | 118 |  |  | 54.61 |  |
| Vested |  | (67 | ) |  | 36.60 |  |
| Forfeited |  | (5 | ) |  | 37.56 |  |
| Non-vested at end of period |  | 544 |  |  | $ | 41.12 |  |

[0000038725-19-000118:notes:119]
As of March 31, 2019, there was $12.6 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 1.98 years.
