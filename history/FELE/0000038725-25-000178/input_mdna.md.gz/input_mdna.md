# FELE MD&A — 0000038725-25-000178


## mdna

[0000038725-25-000178:mdna:1]
[same as prior period, unchanged from 0000038725-25-000162:mdna:1]

[0000038725-25-000178:mdna:2]
Refer to the Company's Annual Report on Form 10-K for the year ended December 31, 2024 for management’s discussion and analysis of its financial condition and results of operations. The following is management’s discussion and analysis of the Company's financial condition and results of operations for the third quarter and nine months ended September 30, 2025 and 2024.

[0000038725-25-000178:mdna:3]
In the first quarter of 2025, the Company acquired Barnes de Colombia S.A. (Barnes), a leading manufacturer and distributor of industrial and commercial pumps based in Colombia. Also in the first quarter of 2025, the Company acquired PumpEng Pty Ltd ("PumpEng"), an Australia-based company that specializes in the design, manufacture and service of submersible pumps for the mining sector. Acquisitions contributed $37.2 million of incremental net sales in the first nine months of 2025. Refer to Note 3 in Item 1 of this Quarterly Report on Form 10-Q for additional information on the Barnes and PumpEng acquisitions.

[0000038725-25-000178:mdna:4]
In the third quarter of 2025, the Company completed the process of settling the Franklin Electric Co,, Inc. Pension Plan resulting in a third quarter of 2025 pre-tax pension settlement charge of $55.3 million related to actuarial losses previously recorded in Accumulated Other Comprehensive Loss.  Refer to Note 10 in Item 1 of this Quarterly Report on Form 10-Q for additional information on the pension settlement loss.

[0000038725-25-000178:mdna:5]
[same as prior period, unchanged from 0000038725-25-000162:mdna:4]

[0000038725-25-000178:mdna:6]
Third Quarter 2025 vs. 2024

[0000038725-25-000178:mdna:7]
[same as prior period, unchanged from 0000038725-25-000162:mdna:6]

[0000038725-25-000178:mdna:8]
Net sales in the third quarter and first nine months of 2025 were $581.7 million and $1.6 billion, respectively, and increased 9 percent and 6 percent, respectively, as compared to the prior-year periods. The sales increases were due to higher volumes, price realization, and the incremental sales impact from recent acquisitions. The Company's consolidated gross profit was $208.7 million and $584.4 million, respectively, for the third quarter and first nine months of 2025, increases of 10 percent and 6 percent, respectively, from the prior-year periods. Diluted earnings per share was $0.37 and $1.17, respectively, for the third quarter and first nine months of 2025, decreases of $0.80 and $0.79, respectively, from the prior-year periods.  The third quarter and first nine months of 2025 were negatively impacted by the pension settlement loss of $41.7 million net of tax benefit ($55.3 million gross of tax benefit) million related to actuarial losses previously recorded in Accumulated Other Comprehensive Loss.  Refer to Note 10 in Item 1 of this Quarterly Report on Form 10-Q for additional information on the pension settlement loss.

[0000038725-25-000178:mdna:9]
[same as prior period, unchanged from 0000038725-25-000162:mdna:8]

[0000038725-25-000178:mdna:10]
[same as prior period, unchanged from 0000038725-25-000162:mdna:9]

[0000038725-25-000178:mdna:11]
Net sales in the third quarter and first nine months of 2025 were $581.7 million and $1.6 billion, respectively, and increased 9 percent and 6 percent, respectively, as compared to the prior-year periods. Sales in the third quarter and the first nine months of 2025 from recent acquisitions were approximately 3 percent and 2 percent, respectively.  Sales increased less than 1 percent in the third quarter and decreased 1 percent in the first nine months of 2025 due to the impact from foreign exchange rates, as compared to prior-year periods.

[0000038725-25-000178:mdna:12]
|  | Net Sales |
| (In millions) | Q3 2025 |  | Q3 2024 |  | 2025 v 2024 |
| Water Systems | $ | 336.6 |  |  | $ | 302.2 |  |  | $ | 34.4 |  |
| Energy Systems | 80.0 |  |  | 69.7 |  |  | 10.3 |  |
| Distribution | 197.3 |  |  | 190.8 |  |  | 6.5 |  |
| Eliminations/Other | (32.2) |  |  | (31.3) |  |  | (0.9) |  |
| Consolidated | $ | 581.7 |  |  | $ | 531.4 |  |  | $ | 50.3 |  |

[0000038725-25-000178:mdna:13]
|  | Net Sales |
| (In millions) | YTD September 30, 2025 |  | YTD September 30, 2024 |  | 2025 v 2024 |
| Water Systems | $ | 964.7 |  |  | $ | 904.4 |  |  | $ | 60.3 |  |
| Energy Systems | 224.3 |  |  | 204.9 |  |  | 19.4 |  |
| Distribution | 539.1 |  |  | 528.3 |  |  | 10.8 |  |
| Eliminations/Other | (103.7) |  |  | (102.0) |  |  | (1.7) |  |
| Consolidated | $ | 1,624.4 |  |  | $ | 1,535.6 |  |  | $ | 88.8 |  |

[0000038725-25-000178:mdna:14]
[same as prior period, unchanged from 0000038725-25-000162:mdna:13]

[0000038725-25-000178:mdna:15]
Water Systems net sales increased 11 percent in the third quarter and 7 percent in the first nine months of 2025, as compared to the prior-year periods. The sales growth in the third quarter and the first nine months of 2025 was due to incremental sales impact from recent acquisitions of approximately 5 percent and 4 percent, respectively, favorable volumes, and price realization.  Sales increased less than 1 percent in the third quarter and decreased 1 percent in the first nine months of 2025 due to the impact from foreign exchange rates, as compared to prior-year periods.

[0000038725-25-000178:mdna:16]
Water Systems net sales in the U.S. and Canada increased 9 percent in the third quarter and 5 percent in the first nine months of 2025, as compared to the prior-year periods. In the third quarter of 2025, sales of large dewatering equipment increased 38 percent, sales of water treatment products increased 9 percent, sales of all other surface pumping equipment increased 4 percent and sales of groundwater pumping equipment were flat compared to 2024. In the first nine months of 2025, sales of large dewatering equipment increased 18 percent, sales of water treatment products increased 8 percent, while sales of groundwater pumping equipment and sales of all other surface pumping equipment were flat compared to 2024.

[0000038725-25-000178:mdna:17]
Water Systems net sales in markets outside the U.S. and Canada increased 15 percent in the third quarter and 9 percent in the first nine months of 2025, as compared to the prior-year periods. Sales increased 1 percent in the third quarter and decreased 2 percent in the first nine months of 2025 due to the negative impact from foreign exchange rates, as compared to prior-year periods, while sales increased 13 percent and 10 percent, respectively, compared to prior-year periods due to the incremental sales impact from recent acquisitions. Excluding the impact of foreign currency translation and acquisitions, in both the third quarter and first nine months of 2025, sales grew 1 percent, led by higher sales in the European region partly offset by sales declines in the Latin America regions.

[0000038725-25-000178:mdna:18]
[same as prior period, unchanged from 0000038725-25-000162:mdna:17]

[0000038725-25-000178:mdna:19]
Energy Systems net sales increased 15 percent in the third quarter and 9 percent in the first nine months of 2025, as compared to the prior-year periods. This sales increase was primarily due to price realization and favorable volumes.

[0000038725-25-000178:mdna:20]
Energy Systems net sales in the U.S. and Canada increased 11 percent in the third quarter and 9 percent in the first nine months of 2025, as compared to the prior-year periods. The increase was broad based and across all product lines, led by fuel pumping systems. Outside the U.S. and Canada, Energy Systems sales increased 26 percent in the third quarter and 13 percent in the first nine months of 2025, as compared to the prior-year periods, due primarily to sales growth in the Asia Pacific region.

[0000038725-25-000178:mdna:21]
[same as prior period, unchanged from 0000038725-25-000162:mdna:20]

[0000038725-25-000178:mdna:22]
Distribution net sales increased 3 percent in the third quarter and 2 percent in the first nine months of 2025, as compared to the prior-year periods.  The Distribution segment sales increased due to higher volumes and price realization.

[0000038725-25-000178:mdna:23]
[same as prior period, unchanged from 0000038725-25-000162:mdna:22]

[0000038725-25-000178:mdna:24]
|  | Three Months Ended September 30, |
| (In millions) | 2025 |  | % of Net Sales |  | 2024 |  | % of Net Sales |
| Gross Profit | $ | 208.7 |  |  | 35.9 | % |  | $ | 189.7 |  |  | 35.7 | % |
| Selling, General and Administrative Expense | 123.5 |  |  | 21.2 | % |  | 116.0 |  |  | 21.8 | % |

[0000038725-25-000178:mdna:25]
|  | Nine Months Ended September 30, |
| (In millions) | 2025 |  | % of Net Sales |  | 2024 |  | % of Net Sales |
| Gross Profit | $ | 584.4 |  |  | 36.0 | % |  | $ | 553.0 |  |  | 36.0 | % |
| Selling, General and Administrative Expense | 366.6 |  |  | 22.6 | % |  | 352.3 |  |  | 22.9 | % |

[0000038725-25-000178:mdna:26]
[same as prior period, unchanged from 0000038725-25-000162:mdna:25]

[0000038725-25-000178:mdna:27]
The gross profit margin ratio was 35.9 percent and 36.0 percent in the third quarter and first nine months of 2025, respectively, and 35.7 percent and 36.0 percent in the third quarter and first nine months of 2024, respectively.  Gross profit has remained consistent with prior periods primarily due to pricing and volume increases offset by increased cost related to tariffs.

[0000038725-25-000178:mdna:28]
[same as prior period, unchanged from 0000038725-25-000162:mdna:27]

[0000038725-25-000178:mdna:29]
SG&A expenses were $123.5 million in the third quarter and $366.6 million in the first nine months of 2025 compared to $116.0 million in the third quarter and $352.3 million in the first nine months of 2024. SG&A expenses increased in the third quarter and first nine months of 2025 primarily due to the incremental expense impact from recent acquisitions and higher employee compensation costs. The SG&A expenses ratio was 21.2 percent and 22.6 percent in the third quarter and first nine months of 2025, respectively, and 21.8 percent and 22.9 percent in the third quarter and first nine months of 2024, respectively.

[0000038725-25-000178:mdna:30]
[same as prior period, unchanged from 0000038725-25-000162:mdna:29]

[0000038725-25-000178:mdna:31]
There were $0.1 million and $0.4 million in restructuring expenses in the third quarter and first nine months of 2025, compared to $0.1 million and $0.1 million restructuring expenses in the third quarter and first nine months of 2024. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities.

[0000038725-25-000178:mdna:32]
[same as prior period, unchanged from 0000038725-25-000162:mdna:31]

[0000038725-25-000178:mdna:33]
Operating income in the third quarter and first nine months of 2025 was $85.1 million and $217.4 million, respectively, increases of 16 percent and 8 percent, respectively, as compared to the prior-year periods.

[0000038725-25-000178:mdna:34]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2025 |  | Q3 2024 |  | 2025 v 2024 |
| Water Systems |  | $ | 60.2 |  |  | $ | 52.8 |  |  | $ | 7.4 |  |
| Energy Systems |  | 25.4 |  |  | 24.1 |  |  | 1.3 |  |
| Distribution |  | 16.3 |  |  | 12.2 |  |  | 4.1 |  |
| Eliminations/Other |  | (16.8) |  |  | (15.6) |  |  | (1.2) |  |
| Consolidated |  | $ | 85.1 |  |  | $ | 73.5 |  |  | $ | 11.6 |  |

[0000038725-25-000178:mdna:35]
|  |  | Operating income (loss) |
| (In millions) |  | YTD September 30, 2025 |  | YTD September 30, 2024 |  | 2025 v 2024 |
| Water Systems |  | $ | 165.5 |  |  | $ | 162.3 |  |  | $ | 3.2 |  |
| Energy Systems |  | 76.4 |  |  | 68.9 |  |  | 7.5 |  |
| Distribution |  | 34.6 |  |  | 23.8 |  |  | 10.8 |  |
| Eliminations/Other |  | (59.1) |  |  | (54.4) |  |  | (4.7) |  |
| Consolidated |  | $ | 217.4 |  |  | $ | 200.6 |  |  | $ | 16.8 |  |

[0000038725-25-000178:mdna:36]
[same as prior period, unchanged from 0000038725-25-000162:mdna:35]

[0000038725-25-000178:mdna:37]
Water Systems operating income in the third quarter and first nine months of 2025 was $60.2 million and $165.5 million, respectively, increases of $7.4 million and $3.2 million, respectively, as compared to the prior-year periods. The third quarter

[0000038725-25-000178:mdna:38]
operating income margin was 17.9 percent, an increase of 40 basis points from 17.5 percent in the third quarter of 2024. The increase in operating income for the third quarter was primarily due to higher sales. The first nine months of 2025 operating income margin was 17.2 percent, a decrease of 70 basis points from 17.9 percent in the first nine months of 2024.  The decrease in operating income margin in the first nine months was primarily due to incremental expenses associated with recent acquisitions and an unfavorable product and geographic sales mix shift.

[0000038725-25-000178:mdna:39]
[same as prior period, unchanged from 0000038725-25-000162:mdna:37]

[0000038725-25-000178:mdna:40]
Energy Systems operating income in the third quarter and first nine months of 2025 was $25.4 million and $76.4 million, respectively, increases of $1.3 million and $7.5 million, respectively, as compared to the prior-year periods. The increases were primarily due to higher sales. The third quarter operating income margin was 31.8 percent, a decrease of 280 basis points from 34.6 percent in the third quarter of 2024. Operating income margin decreased primarily due to an unfavorable product sales mix shift. The first nine months of 2025 operating income margin was 34.1 percent, an increase of 50 basis points from 33.6 percent in the first nine months of 2024. Operating income margin increased primarily due to price realization and cost management.

[0000038725-25-000178:mdna:41]
[same as prior period, unchanged from 0000038725-25-000162:mdna:39]

[0000038725-25-000178:mdna:42]
Distribution operating income in the third quarter and first nine months of 2025 was $16.3 million and $34.6 million, respectively, increases of $4.1 million and $10.8 million, respectively, as compared to the prior-year periods. The third quarter operating income margin was 8.3 percent, an increase of 190 basis points from 6.4 percent in the third quarter of 2024. The first nine months of 2025 operating income margin was 6.4 percent, an increase of 190 basis points from 4.5 percent in the first nine months of 2024. Operating income and operating income margins increased primarily due to higher sales and reduced SG&A expenses as a result of cost actions implemented in 2024 to improve the performance of the segment.

[0000038725-25-000178:mdna:43]
[same as prior period, unchanged from 0000038725-25-000162:mdna:41]

[0000038725-25-000178:mdna:44]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the third quarter and first nine months of 2025 compared to the prior-year periods of 2024 was an unfavorable $1.0 million and $0.4 million, respectively. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses increased $0.2 million and $4.3 million, respectively, compared to the prior-year periods, primarily due to higher employee compensation costs, including incremental expenses associated with the Company’s executive leadership transitions.

[0000038725-25-000178:mdna:45]
[same as prior period, unchanged from 0000038725-25-000162:mdna:43]

[0000038725-25-000178:mdna:46]
Interest expense was $3.5 million and $8.1 million in the third quarter and first nine months of 2025, respectively, and $1.6 million and $5.0 million in the third quarter and first nine months of 2024, respectively. The increases in the third quarter and first nine months of 2025 were primarily driven by higher average amount of outstanding debt.

[0000038725-25-000178:mdna:47]
Other income (expense), net

[0000038725-25-000178:mdna:48]
Other income (expense), net was a net loss of $(0.2) million and a net gain of $0.5 million in the third quarter and first nine months of 2025, respectively, and net loss of $(0.2) million and a net gain of $0.7 million in the third quarter and first nine months of 2024, respectively.

[0000038725-25-000178:mdna:49]
Pension settlement loss

[0000038725-25-000178:mdna:50]
In the third quarter of 2025, the Company completed the process of settling the Franklin Electric Co,, Inc. Pension Plan resulting in a third quarter of 2025 pre-tax pension settlement charge of $55.3 million related to actuarial losses previously recorded in Accumulated Other Comprehensive Loss.  Refer to Note 10 in Item 1 of this Quarterly Report on Form 10-Q for additional information on the pension settlement loss.

[0000038725-25-000178:mdna:51]
[same as prior period, unchanged from 0000038725-25-000162:mdna:47]

[0000038725-25-000178:mdna:52]
Foreign currency-based transactions produced an expense of $2.7 million and $8.5 million in the third quarter and first nine months of 2025, respectively, and a gain of $0.1 million and an expense of $5.2 million in the third quarter and first nine months of 2024, respectively. The results in the third quarters and first nine months of 2025 and 2024 are primarily due to transaction losses associated with the Argentine Peso and Turkish Lira relative to the U.S. dollar  The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-25-000178:mdna:53]
[same as prior period, unchanged from 0000038725-25-000162:mdna:49]

[0000038725-25-000178:mdna:54]
The provision for income taxes in the third quarter and first nine months of 2025 was $6.3 million and $36.9 million, respectively, and $17.0 million and $43.8 million in the third quarter and first nine months of 2024, respectively. The effective

[0000038725-25-000178:mdna:55]
tax rate for the third quarter and first nine months of 2025 was 26.9 percent and 25.3 percent, respectively, and 23.6 percent and 22.9 percent in the third quarter and the first nine months of 2024, respectively. The increase in the effective tax rate was due to mix of foreign earnings taxed at rates different than the U.S. statutory rate, a decreased benefit in the U.S. foreign-derived intangible income (FDII) provision related to a prior year prepayment of inventory from foreign subsidiaries, and less favorable discrete events in 2025, primarily related to excess tax benefits from share-based compensation.

[0000038725-25-000178:mdna:56]
[same as prior period, unchanged from 0000038725-25-000162:mdna:51]

[0000038725-25-000178:mdna:57]
Net income in the third quarter and first nine months of 2025 was $17.2 million and $109.1 million, respectively, and $54.9 million and $147.3 million in the third quarter and first nine months of 2024, respectively. Net income attributable to Franklin Electric Co., Inc. in the third quarter and first nine months of 2025 was $16.7 million and $107.8 million, respectively, or $0.37 and $2.35 per diluted share. Net income attributable to Franklin Electric Co., Inc. in the third quarter and first nine months of 2024 was $54.6 million and $146.7 million, respectively, or $1.17 and $3.14 per diluted share.

[0000038725-25-000178:mdna:58]
[same as prior period, unchanged from 0000038725-25-000162:mdna:53]

[0000038725-25-000178:mdna:59]
[same as prior period, unchanged from 0000038725-25-000162:mdna:54]

[0000038725-25-000178:mdna:60]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at September 30, 2025 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-25-000178:mdna:61]
As of September 30, 2025, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 14, 2030. As of September 30, 2025, the Company had $277.3 million borrowing capacity under its credit agreement as $6.4 million in letters of commercial and standby letters of credit were outstanding and undrawn and $66.3 million revolver borrowings were drawn or outstanding.

[0000038725-25-000178:mdna:62]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates, with a remaining borrowing capacity of $200.0 million as of September 30, 2025. The maturity date of the agreement is May 15, 2027.

[0000038725-25-000178:mdna:63]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity on the New York Life Agreement of $175.0 million as of September 30, 2025. The maturity date of the agreement is May 15, 2027.

[0000038725-25-000178:mdna:64]
The Company also has other long-term debt borrowings outstanding as of September 30, 2025. See Note 6 - Debt included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024, for additional information regarding these obligations and future maturities as well as Note 6 - Debt of this current quarterly report for changes to these agreements since December 31, 2024.

[0000038725-25-000178:mdna:65]
At September 30, 2025, the Company had $62.7 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate the majority of these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-25-000178:mdna:66]
[same as prior period, unchanged from 0000038725-25-000162:mdna:60]

[0000038725-25-000178:mdna:67]
The following table summarizes significant sources and uses of cash and cash equivalents for the first nine months of 2025 and 2024.

[0000038725-25-000178:mdna:68]
| (In millions) |  | 2025 |  | 2024 |
| Net cash flows from operating activities |  | $ | 134.7 |  |  | $ | 151.1 |  |
| Net cash flows from investing activities |  | (137.1) |  |  | (29.3) |  |
| Net cash flows from financing activities |  | (112.2) |  |  | (100.0) |  |
| Impact of exchange rates on cash and cash equivalents |  | (3.0) |  |  | (0.5) |  |
| Change in cash and cash equivalents |  | $ | (117.6) |  |  | $ | 21.3 |  |

[0000038725-25-000178:mdna:69]
[same as prior period, unchanged from 0000038725-25-000162:mdna:63]

[0000038725-25-000178:mdna:70]
[same as prior period, unchanged from 0000038725-25-000162:mdna:64]

[0000038725-25-000178:mdna:71]
Net cash provided by operating activities was $134.7 million for the nine months ended September 30, 2025 compared to $151.1 million used by operating activities for the nine months ended September 30, 2024. The change in operating cash flow was primarily attributable to changes in working capital.

[0000038725-25-000178:mdna:72]
[same as prior period, unchanged from 0000038725-25-000162:mdna:66]

[0000038725-25-000178:mdna:73]
[same as prior period, unchanged from 0000038725-25-000162:mdna:67]

[0000038725-25-000178:mdna:74]
Net cash used in investing activities was $137.1 million for the nine months ended September 30, 2025 compared to $29.3 million used in investing activities for the nine months ended September 30, 2024. The change in investing cash flow was primarily attributable to the Barnes and PumpEng acquisitions in the first nine months of 2025.

[0000038725-25-000178:mdna:75]
[same as prior period, unchanged from 0000038725-25-000162:mdna:69]

[0000038725-25-000178:mdna:76]
[same as prior period, unchanged from 0000038725-25-000162:mdna:70]

[0000038725-25-000178:mdna:77]
Net cash used in financing activities was $112.2 million for the nine months ended September 30, 2025 compared to $100.0 million used in financing activities for the nine months ended September 30, 2024. The change in financing cash flow was primarily due to increased repurchases of Company stock, offset by higher net borrowings under the Company's credit facility in 2025 compared to 2024.

[0000038725-25-000178:mdna:78]
[same as prior period, unchanged from 0000038725-25-000162:mdna:72]
