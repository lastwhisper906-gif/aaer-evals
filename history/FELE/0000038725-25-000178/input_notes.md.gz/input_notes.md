# FELE notes — 0000038725-25-000178


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-25-000178:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2024, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2025, and for the third quarters and nine months ended September 30, 2025 and September 30, 2024 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2025. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-25-000178:notes:2]
ACCOUNTING PRONOUNCEMENTS
Accounting Standards Issued But Not Yet Adopted

[0000038725-25-000178:notes:3]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments — Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets. ASU 2025-05 provides an optional practical expedient to simplify the measurement of credit losses for certain receivables and contract assets. ASU 2025-05 is effective for interim and annual periods beginning after December 15, 2025, with early adoption permitted. The guidance is to be applied prospectively. The Company will adopt this ASU in 2026 and does not anticipate the adoption to have material impact on the Company's financial statements.

[0000038725-25-000178:notes:4]
In September 2025, the FASB issued ASU 2025-06, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. ASU 2025-06 removes all references to software development project stages and requires entities to start capitalizing software costs when both of the following occur: (i) management has authorized and committed to funding the software project and (ii) it is probable that the project will be completed and the software will be used to perform the function intended. ASU 2025-06 is effective for interim and annual periods beginning after December 15, 2027, with early adoption permitted. The guidance can be applied prospectively, retrospectively, or utilizing a modified transition method. The Company is currently evaluating the impact of this ASU on the Company's financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-25-000178:notes:5]
[same as prior period, unchanged from 0000038725-25-000162:notes:2]

[0000038725-25-000178:notes:6]
[same as prior period, unchanged from 0000038725-25-000162:notes:3]

[0000038725-25-000178:notes:7]
In March 2025, the Company acquired 100 percent of Barnes de Colombia S.A. ("Barnes"), a leading manufacturer and distributor of industrial and commercial pumps based in Cota, Cundinamarca, Colombia, for total upfront cash consideration of $96.8 million, net of cash acquired.

[0000038725-25-000178:notes:8]
The valuation of assets acquired and liabilities assumed has not yet been finalized as of September 30, 2025. As a result, the Company recorded preliminary estimates for the fair value of assets acquired and liabilities assumed as of the acquisition date. Finalization of the valuation during the measurement period could result in a change in the amounts recorded for the acquisition date fair value of intangible assets, goodwill and income taxes among other items. The completion of the valuation will occur no later than one year from the acquisition date. The following table summarizes the preliminary fair values of the assets acquired and liabilities assumed as of the acquisition date:

[0000038725-25-000178:notes:9]
| (in millions) |  |
| Assets acquired and liabilities assumed |  |
| Cash and cash equivalents | $ | 3.4 |  |
| Receivables | 9.6 |  |
| Inventories | 23.6 |  |
| Other current assets | 2.1 |  |
| Property, plant and equipment | 13.5 |  |
| Goodwill | 47.4 |  |
| Other intangible assets | 45.5 |  |
| Other non-current assets | 3.6 |  |
| Debt | (13.8) |  |
| Accounts payable | (9.8) |  |
| Accrued expenses and other current liabilities | (2.4) |  |
| Deferred tax liabilities | (19.7) |  |
| Other non-current liabilities | (2.8) |  |
| Total assets acquired and liabilities assumed | $ | 100.2 |  |

[0000038725-25-000178:notes:10]
The Company allocated $33.4 million of the total consideration to customer relationships with a useful life of 8 years, $9.3 million to trade names with a useful life of 11 years, and $2.8 million to developed technology with a useful life of 7 years. The fair values of the intangible assets were determined using the income approach. The discount rates used to measure the intangible assets were 19 percent for customer relationships, 18 percent for trade names, and 18 percent for developed technology. The Company considers the fair value of the intangible assets to be Level 3 measurements due to the significant estimates and assumptions used by management in establishing the estimated fair values. In the third quarter of 2025, the Company recorded various immaterial measurement period adjustments, resulting in an increase to the purchase price of $0.2 million and an increase to goodwill of $0.6 million. The measurement period adjustments did not have a significant impact on the Company’s results of operations.

[0000038725-25-000178:notes:11]
[same as prior period, unchanged from 0000038725-25-000162:notes:8]

[0000038725-25-000178:notes:12]
The results of operations of the acquired business have been included in the Company’s consolidated statement of income since the date the business was acquired. The Barnes acquisition contributed $27.2 million of net sales for the nine months ended September 30, 2025 while the impact on net income was not significant. The Company has not presented pro forma financial information for the Barnes acquisition because its results are not material to the Company’s condensed consolidated financial statements.

[0000038725-25-000178:notes:13]
[same as prior period, unchanged from 0000038725-25-000162:notes:10]

[0000038725-25-000178:notes:14]
[same as prior period, unchanged from 0000038725-25-000162:notes:11]

[0000038725-25-000178:notes:15]
The valuation of assets acquired and liabilities assumed has not yet been finalized as of September 30, 2025. As a result, the Company recorded preliminary estimates for the fair value of assets acquired and liabilities assumed as of the acquisition date. Finalization of the valuation during the measurement period could result in a change in the amounts recorded for the acquisition date fair value of intangible assets, goodwill and income taxes among other items. The completion of the valuation will occur no later than one year from the acquisition date. The purchase price was primarily allocated to goodwill and other intangible assets as well as accounts receivable, inventory and fixed assets. The goodwill, which is not deductible for tax purposes, includes the value of an assembled workforce, potential future technologies as well as the overall strategic benefits provided to the Company’s product portfolio and is included in the Water Systems segment.

[0000038725-25-000178:notes:16]
[same as prior period, unchanged from 0000038725-25-000162:notes:13]

[0000038725-25-000178:notes:17]
For the third quarter and nine months ended September 30, 2025, acquisition costs associated with the 2025 acquisitions were $0.0 million and $2.0 million, respectively. Acquisition costs for all periods in 2024 were insignificant.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-25-000178:notes:18]
[same as prior period, unchanged from 0000038725-25-000162:notes:15]

[0000038725-25-000178:notes:19]
| (In millions) |  | September 30, 2025 |  | December 31, 2024 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 305.6 |  |  | $ | (144.7) |  |  | $ | 263.4 |  |  | $ | (128.8) |  |
| Patents |  | 7.4 |  |  | (7.4) |  |  | 7.2 |  |  | (7.2) |  |
| Technology |  | 10.4 |  |  | (7.7) |  |  | 7.5 |  |  | (7.5) |  |
| Trade names |  | 58.1 |  |  | (10.7) |  |  | 44.5 |  |  | (8.1) |  |
| Other |  | 2.9 |  |  | (2.5) |  |  | 2.8 |  |  | (2.4) |  |
| Total |  | $ | 384.4 |  |  | $ | (173.0) |  |  | $ | 325.4 |  |  | $ | (154.0) |  |
| Non-amortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 41.8 |  |  | — |  |  | 41.6 |  |  | — |  |
| Total intangibles |  | $ | 426.2 |  |  | $ | (173.0) |  |  | $ | 367.0 |  |  | $ | (154.0) |  |

[0000038725-25-000178:notes:20]
Amortization expense related to intangible assets for the third quarters ended September 30, 2025 and September 30, 2024 was $6.1 million and $4.7 million, respectively, and for nine months ended September 30, 2025 and September 30, 2024 was $17.2 million and $14.2 million, respectively.

[0000038725-25-000178:notes:21]
The change in the carrying amount of goodwill by reportable segment for the nine months ended September 30, 2025 is as follows:

[0000038725-25-000178:notes:22]
| (In millions) |  |  |
|  |  | Water Systems |  | Energy Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2024 |  | $ | 217.6 |  |  | $ | 70.3 |  |  | $ | 50.6 |  |  | $ | 338.5 |  |
| Acquisitions |  | 55.4 |  |  | — |  |  | — |  |  | 55.4 |  |
| Adjustments to prior year acquisitions |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Foreign currency translation |  | 4.2 |  |  | 0.2 |  |  | — |  |  | 4.4 |  |
| Balance as of September 30, 2025 |  | $ | 277.3 |  |  | $ | 70.5 |  |  | $ | 50.6 |  |  | $ | 398.4 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-25-000178:notes:23]
[same as prior period, unchanged from 0000038725-25-000162:notes:20]

[0000038725-25-000178:notes:24]
| (In millions) |  | September 30, 2025 |  | December 31, 2024 |
| Salaries, wages, and commissions |  | $ | 51.4 |  |  | $ | 49.0 |  |
| Product warranty costs |  | 9.0 |  |  | 9.0 |  |
| Insurance |  | 3.1 |  |  | 2.4 |  |
| Employee benefits |  | 18.9 |  |  | 19.9 |  |
| Other |  | 28.9 |  |  | 39.5 |  |
| Total |  | $ | 111.3 |  |  | $ | 119.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0000038725-25-000178:notes:25]
DEBT
Debt consisted of the following:

[0000038725-25-000178:notes:26]
| (In millions) |  | September 30, 2025 |  | December 31, 2024 |
| Prudential Agreement |  | $ | 50.0 |  |  | $ | — |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 66.3 |  |  | 41.4 |  |
| Tax increment financing debt |  | 11.5 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 1.5 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 204.3 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (69.1) |  |  | (117.8) |  |
| Long-term debt |  | $ | 135.2 |  |  | $ | 11.6 |  |

[0000038725-25-000178:notes:27]
Prudential Agreement

[0000038725-25-000178:notes:28]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates. On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $50.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2025, there was $200.0 million remaining borrowing capacity under the Prudential Agreement.

[0000038725-25-000178:notes:29]
New York Life Agreement

[0000038725-25-000178:notes:30]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 to the renewal that increased the total available facility amount from lenders to $250.0 million from $200.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2025, there was $175.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-25-000178:notes:31]
Credit Agreement

[0000038725-25-000178:notes:32]
On May 14, 2025, the Company entered into the Fifth Amended and Restated Credit Agreement (the “Credit Agreement”).  The Fifth Amended and Restated Credit Agreement extended the maturity date of the Company’s Fourth Amended and Restated Credit Agreement, as amended (which is referred to in this current report as the “Previous Credit Agreement”) to May 14, 2030 while keeping the revolving commitment amount unchanged at $350.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $175.0 million (not to exceed a total commitment of $525.0 million) subject to the conditions contained therein. The Previous Credit Agreement provided the Borrowers could request an increase in the aggregate revolving commitments by up to $125.0 million (not to exceed a total commitment of $475.0 million). All of the Company's present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers' obligations under and in connection with the Credit Agreement. Additionally, the Company unconditionally guarantees all of the obligations of Franklin Electric B.V. under the Credit Agreement.  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a commitment fee of 0.10% to 0.25% (depending on the Company's leverage ratio) of the aggregate commitment, payable quarterly in arrears. The Credit Agreement contains customary affirmative and negative covenants.  Loans may be made either at (i) a Term Benchmark rate based on SOFR, for borrowings denominated in Dollars, or EURIBOR, for borrowings denominated in Euros,  plus an applicable margin of  1.00% to 1.75% (depending on the Company's leverage ratio), or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-25-000178:notes:33]
As of September 30, 2025, the Company had $66.3 million outstanding borrowings with a weighted-average interest rate of 3.6 percent, $6.4 million in letters of credit outstanding, and $277.3 million of available capacity under the Credit Agreement. As of December 31, 2024, the Company had $41.4 million outstanding borrowings with a weighted-average interest rate of 3.7 percent, $4.5 million in letters of credit outstanding, and $304.1 million of available capacity under the Previous Credit Agreement.

[0000038725-25-000178:notes:34]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $19.8 million. As of September 30, 2025, there were $1.3 million outstanding borrowings and $18.5 million of available capacity under these lines of credit. As of December 31, 2024, there were $16.8 million overdraft lines of credit with no outstanding borrowings and $16.8 million of available capacity under these lines of credit.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-25-000178:notes:35]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.

[0000038725-25-000178:notes:36]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-25-000178:notes:37]
At September 30, 2025, the Company had $9.0 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

[0000038725-25-000178:notes:38]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2025, are as follows:

[0000038725-25-000178:notes:39]
| (In millions) |  |  |
| Balance as of December 31, 2024 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 8.5 |  |
| Reductions for payments made |  | (8.5) |  |
| Balance as of September 30, 2025 |  | $ | 9.0 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-25-000178:notes:40]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the third quarters and nine months ended September 30, 2025 and September 30, 2024:

[0000038725-25-000178:notes:41]
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of July 1, 2025 | $ | 4,448 |  |  | $ | 383,428 |  |  | $ | 1,088,407 |  |  |  |  |  |  | $ | (214,407) |  |  | $ | 3,186 |  |  | $ | 1,265,062 |  |  | $ | 1,511 |  |
| Net income | — |  |  | — |  |  | 16,738 |  |  |  |  |  |  | — |  |  | 292 |  |  | 17,030 |  |  | 174 |  |
| Dividends on common stock ($0.265/share) | — |  |  | — |  |  | (11,835) |  |  |  |  |  |  | — |  |  | — |  |  | (11,835) |  |  | — |  |
| Common stock issued | 2 |  |  | 1,036 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 1,038 |  |  | — |  |
| Common stock repurchased | (1) |  |  | — |  |  | (94) |  |  |  |  |  |  | — |  |  | — |  |  | (95) |  |  | — |  |
| Share-based compensation | 2 |  |  | 2,370 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 2,372 |  |  | — |  |
| Dividend to noncontrolling interest | — |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | — |  |  | (28) |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 4,578 |  |  | (10) |  |  | 4,568 |  |  | (13) |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 43,262 |  |  | — |  |  | 43,262 |  |  | — |  |
| Balance as of September 30, 2025 | $ | 4,451 |  |  | $ | 386,834 |  |  | $ | 1,093,216 |  |  |  |  |  |  | $ | (166,567) |  |  | $ | 3,468 |  |  | $ | 1,321,402 |  |  | $ | 1,644 |  |
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of July 1, 2024 | $ | 4,575 |  |  | $ | 356,016 |  |  | $ | 1,099,285 |  |  |  |  |  |  | $ | (237,705) |  |  | $ | 2,725 |  |  | $ | 1,224,896 |  |  | $ | 1,134 |  |
| Net income | — |  |  | — |  |  | 54,596 |  |  |  |  |  |  | — |  |  | 252 |  |  | 54,848 |  |  | 46 |  |
| Dividends on common stock ($0.250/share) | — |  |  | — |  |  | (11,462) |  |  |  |  |  |  | — |  |  | — |  |  | (11,462) |  |  | — |  |
| Common stock issued | 2 |  |  | 965 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 967 |  |  | — |  |
| Common stock repurchased | (9) |  |  | — |  |  | (8,769) |  |  |  |  |  |  | — |  |  | — |  |  | (8,778) |  |  | — |  |
| Share-based compensation | 1 |  |  | 3,111 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 3,112 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 8,621 |  |  | 86 |  |  | 8,707 |  |  | (1) |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 416 |  |  | — |  |  | 416 |  |  | — |  |
| Balance as of September 30, 2024 | $ | 4,569 |  |  | $ | 360,092 |  |  | $ | 1,133,650 |  |  |  |  |  |  | $ | (228,668) |  |  | $ | 3,063 |  |  | $ | 1,272,706 |  |  | $ | 1,179 |  |

[0000038725-25-000178:notes:42]
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2024 | $ | 4,571 |  |  | $ | 363,956 |  |  | $ | 1,151,575 |  |  |  |  |  |  | $ | (254,003) |  |  | $ | 2,511 |  |  | $ | 1,268,610 |  |  | $ | 1,224 |  |
| Net Income | — |  |  | — |  |  | 107,840 |  |  |  |  |  |  | — |  |  | 892 |  |  | 108,732 |  |  | 409 |  |
| Dividends on common stock ($0.795/share) | — |  |  | — |  |  | (36,194) |  |  |  |  |  |  | — |  |  | — |  |  | (36,194) |  |  | — |  |
| Common stock issued | 16 |  |  | 12,549 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 12,565 |  |  | — |  |
| Common stock repurchased | (148) |  |  | — |  |  | (130,005) |  |  |  |  |  |  | — |  |  | — |  |  | (130,153) |  |  | — |  |
| Share-based compensation | 12 |  |  | 10,329 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 10,341 |  |  | — |  |
| Dividend to noncontrolling interest | — |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | — |  |  | (28) |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 43,553 |  |  | 65 |  |  | 43,618 |  |  | 39 |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 43,883 |  |  | — |  |  | 43,883 |  |  | — |  |
| Balance as of September 30, 2025 | $ | 4,451 |  |  | $ | 386,834 |  |  | $ | 1,093,216 |  |  |  |  |  |  | $ | (166,567) |  |  | $ | 3,468 |  |  | $ | 1,321,402 |  |  | $ | 1,644 |  |
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2023 | $ | 4,607 |  |  | $ | 344,717 |  |  | $ | 1,078,512 |  |  |  |  |  |  | $ | (221,114) |  |  | $ | 2,426 |  |  | $ | 1,209,148 |  |  | $ | 1,145 |  |
| Net Income | — |  |  | — |  |  | 146,654 |  |  |  |  |  |  | — |  |  | 607 |  |  | 147,261 |  |  | 56 |  |
| Dividends on common stock ($0.750/share) | — |  |  | — |  |  | (34,586) |  |  |  |  |  |  | — |  |  | — |  |  | (34,586) |  |  | — |  |
| Common stock issued | 9 |  |  | 5,260 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 5,269 |  |  | — |  |
| Common stock repurchased | (59) |  |  | — |  |  | (56,930) |  |  |  |  |  |  | — |  |  | — |  |  | (56,989) |  |  | — |  |
| Share-based compensation | 12 |  |  | 10,115 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 10,127 |  |  | — |  |
| Dividend to noncontrolling interest | — |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | — |  |  | (21) |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (8,837) |  |  | 30 |  |  | (8,807) |  |  | (1) |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 1,283 |  |  | — |  |  | 1,283 |  |  | — |  |
| Balance as of September 30, 2024 | $ | 4,569 |  |  | $ | 360,092 |  |  | $ | 1,133,650 |  |  |  |  |  |  | $ | (228,668) |  |  | $ | 3,063 |  |  | $ | 1,272,706 |  |  | $ | 1,179 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-25-000178:notes:43]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the nine months ended September 30, 2025 and September 30, 2024, are summarized below:

[0000038725-25-000178:notes:44]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| For the nine months ended September 30, 2025: |  |  |
| Balance as of December 31, 2024 | $ | (215.0) |  |  | $ | (39.0) |  |  | $ | (254.0) |  |
| Other comprehensive income/(loss) before reclassifications | 43.6 |  |  | — |  |  | 43.6 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 2.2 |  |  | 2.2 |  |
| Pension settlement, net of tax | — |  |  | 41.7 |  |  | 41.7 |  |
| Net other comprehensive income/(loss) | 43.6 |  |  | 43.9 |  |  | 87.5 |  |
| Balance as of September 30, 2025 | $ | (171.4) |  |  | $ | 4.9 |  |  | $ | (166.5) |  |
| For the nine months ended September 30, 2024: |  |  |  |  |  |
| Balance as of December 31, 2023 | $ | (179.3) |  |  | $ | (41.8) |  |  | $ | (221.1) |  |
| Other comprehensive income/(loss) before reclassifications | (8.8) |  |  | — |  |  | (8.8) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.3 |  |  | 1.3 |  |
| Net other comprehensive income/(loss) | (8.8) |  |  | 1.3 |  |  | (7.5) |  |
| Balance as of September 30, 2024 | $ | (188.1) |  |  | $ | (40.5) |  |  | $ | (228.6) |  |

[0000038725-25-000178:notes:45]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 10 for additional details) and is included in the "Other (expense) income, net" line of the Company's condensed consolidated statements of income.

[0000038725-25-000178:notes:46]
(2) Net of tax expense of $14.3 million and $0.4 million for the nine months ended September 30, 2025 and September 30, 2024, respectively.

[0000038725-25-000178:notes:47]
[same as prior period, unchanged from 0000038725-25-000162:notes:41]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-25-000178:notes:48]
EMPLOYEE BENEFIT PLANS
On February 13, 2025, our Board of Directors approved the termination of the domestic Franklin Electric Co, Inc. Pension Plan (the “Plan”). On July 9, 2025, lump sum distributions of $59.9 million were made to eligible participants who elected that payment option to settle the obligation. On July 29, 2025, the Company settled its benefit obligation under the Plan for the remaining participants with the purchase of a nonparticipating, single premium annuity contract from a third-party insurance company, for $28.9 million. In connection with the termination and settlement of the Plan, the Company recognized a non-cash pension settlement gross loss of $55.3 million during Q3 related to the actuarial losses previously accumulated in Accumulated Other Comprehensive Loss, which was included in the “Pension settlement loss” line of the Company’s condensed consolidated statements of income.

[0000038725-25-000178:notes:49]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the third quarters and nine months ended September 30, 2025 and September 30, 2024:

[0000038725-25-000178:notes:50]
| (In millions) | Pension Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2025 |  | September 30, 2024 |  | September 30, 2025 |  | September 30, 2024 |
| Service cost | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.5 |  |
| Interest cost | 0.9 |  |  | 1.6 |  |  | 3.8 |  |  | 4.7 |  |
| Expected return on assets | (0.6) |  |  | (1.9) |  |  | (3.8) |  |  | (5.7) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.1 |  |  | 0.5 |  |  | 0.9 |  |  | 1.7 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Remeasurement of defined benefit pension | 2.0 |  |  | — |  |  | 2.0 |  |  | — |  |
| Pension settlement loss | 55.3 |  |  | — |  |  | 55.3 |  |  | — |  |
| Net periodic benefit cost | $ | 57.8 |  |  | $ | 0.4 |  |  | $ | 58.4 |  |  | $ | 1.2 |  |

[0000038725-25-000178:notes:51]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the third quarters and nine months ended September 30, 2025 and September 30, 2024:

[0000038725-25-000178:notes:52]
| (In millions) | Other Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2025 |  | September 30, 2024 |  | September 30, 2025 |  | September 30, 2024 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.2 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-25-000178:notes:53]
INCOME TAXES
The Company’s effective tax rate for the nine-month period ended September 30, 2025 was 25.3 percent as compared to 22.9 percent for the nine-month period ended September 30, 2024. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to U.S state taxes and foreign earnings taxed at rates higher than the U.S. statutory rate partially offset by the recognition of the U.S. foreign-derived intangible income (FDII) provisions. For the third quarter of 2025, the effective tax rate was 26.9 percent compared to 23.6 percent for the third quarter of 2024.

[0000038725-25-000178:notes:54]
The increase in the effective tax rate for the third quarter and first nine months of 2025 compared to the comparable periods in the prior year was primarily due to mix of foreign earnings taxed at rates different than the U.S. statutory rate, a decreased benefit in the U.S. foreign-derived intangible income (FDII) provision related to a prior year prepayment of inventory from foreign subsidiaries, and less favorable discrete events in 2025, primarily related to excess tax benefits from share-based compensation.

[0000038725-25-000178:notes:55]
On July 4, 2025, the reconciliation bill, commonly referred to as the One Big Beautiful Bill Act ("OBBB") was signed into law, which includes a broad range of tax reform provisions. The OBBB allows an elective deduction for domestic Research and Development (R&D), a reinstatement of elective 100% first-year bonus depreciation, and a more favorable tax rate on Foreign-derived Deduction Eligible Income and income from non-U.S. subsidiaries, among other provisions. The impact of those tax provisions in the OBBB will depend on the Company's facts in each year and anticipated guidance from the U.S. Department of the Treasury. The Company has recorded impact from OBBB in the third quarter that is not material, nor does the Company expect material impact in the future.


## us-gaap:EarningsPerShareTextBlock

[0000038725-25-000178:notes:56]
[same as prior period, unchanged from 0000038725-25-000162:notes:49]

[0000038725-25-000178:notes:57]
[same as prior period, unchanged from 0000038725-25-000162:notes:50]

[0000038725-25-000178:notes:58]
[same as prior period, unchanged from 0000038725-25-000162:notes:51]

[0000038725-25-000178:notes:59]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions, except per share amounts) | September 30, 2025 |  | September 30, 2024 |  | September 30, 2025 |  | September 30, 2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 16.7 |  |  | $ | 54.6 |  |  | $ | 107.8 |  |  | $ | 146.7 |  |
| Less: Earnings allocated to participating securities | 0.1 |  |  | 0.2 |  |  | 0.3 |  |  | 0.5 |  |
| Net income available to common shareholders | $ | 16.6 |  |  | $ | 54.4 |  |  | $ | 107.5 |  |  | $ | 146.2 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 44.5 |  |  | 45.7 |  |  | 45.2 |  |  | 45.9 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors | 0.5 |  |  | 0.6 |  |  | 0.5 |  |  | 0.6 |  |
| Diluted weighted average common shares outstanding | 45.0 |  |  | 46.3 |  |  | 45.7 |  |  | 46.5 |  |
| Basic earnings per share | $ | 0.37 |  |  | $ | 1.19 |  |  | $ | 2.38 |  |  | $ | 3.18 |  |
| Diluted earnings per share | $ | 0.37 |  |  | $ | 1.17 |  |  | $ | 2.35 |  |  | $ | 3.14 |  |

[0000038725-25-000178:notes:60]
There were 0.2 million and 0.1 million stock options outstanding for the third quarters and nine months ended September 30, 2025 and September 30, 2024, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-25-000178:notes:61]
FINANCIAL INSTRUMENTS
The Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of September 30, 2025 and December 31, 2024, the swap had a notional value based on 150,000 shares and 250,000 shares, respectively. For the third quarter and nine months ended September 30, 2025, changes in the fair value of the swap resulted in a gain of $0.7 million and a loss of $2.2 million, respectively. For the third quarter and nine months ended September 30, 2024, changes in the fair value of the swap resulted in gains of $1.7 million and $0.9 million, respectively. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.

[0000038725-25-000178:notes:62]
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company. To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of September 30,

[0000038725-25-000178:notes:63]
2025, the Company had a notional amount of $112.2 million in forward currency contracts outstanding and the related fair value of those contracts was a net liability of $0.8 million. The forward currency contracts asset and liability are recorded within the "Receivables" and "Accounts Payable" lines of the condensed consolidated balance sheets. As of December 31, 2024, the Company had no foreign currency contracts outstanding. For the third quarter and nine months ended September 30, 2025, changes in the fair value of the forward currency contracts resulted in a loss of $0.1 million and a gain of $11.1 million, respectively. For the third quarter and nine months ended September 30, 2024, changes in the fair value of the forward currency contracts resulted in losses of $0.6 million and $0.9 million, respectively. These gains and losses are recorded in the Company's condensed consolidated statements of income within the "Foreign exchange income (expense), net" line.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-25-000178:notes:64]
FAIR VALUE MEASUREMENTS
FASB Accounting Standards Codification Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value. The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-25-000178:notes:65]
[same as prior period, unchanged from 0000038725-25-000162:notes:58]

[0000038725-25-000178:notes:66]
[same as prior period, unchanged from 0000038725-25-000162:notes:59]

[0000038725-25-000178:notes:67]
[same as prior period, unchanged from 0000038725-25-000162:notes:60]

[0000038725-25-000178:notes:68]
As of September 30, 2025 and December 31, 2024, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-25-000178:notes:69]
| (In millions) | September 30, 2025 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 7.8 |  | $ | 7.8 |  | $ | — |  | $ | — |  |
| Forward currency contracts | 0.1 |  | — |  | 0.1 |  | — |  |
| Marketable securities | 10.0 |  | 10.0 |  | — |  | — |  |
| Total assets | $ | 17.9 |  | $ | 17.8 |  | $ | 0.1 |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Share swap transaction | $ | 0.4 |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Forward currency contracts | 0.9 |  | — |  | 0.9 |  | — |  |
| Total liabilities | $ | 1.3 |  | $ | 0.4 |  | $ | 0.9 |  | $ | — |  |
| (In millions) | December 31, 2024 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 5.0 |  | $ | 5.0 |  | $ | — |  | $ | — |  |
| Total assets | $ | 5.0 |  | $ | 5.0 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Share swap transaction | $ | 2.5 |  | $ | 2.5 |  | $ | — |  | $ | — |  |
| Contingent payments related to acquisition | 5.0 |  | — |  | — |  | 5.0 |  |
| Total liabilities | $ | 7.5 |  | $ | 2.5 |  | $ | — |  | $ | 5.0 |  |

[0000038725-25-000178:notes:70]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The Company’s Level 1 marketable securities assets are comprised of short term investment funds. The marketable securities asset is recorded within the "Other current assets" line of the condensed consolidated balance sheets. These marketable securities were excess plan assets from the pension settlement disclosed in Note 10 – Employee Benefit Plans.  The excess plan assets were  reclassified to “Other current assets” during the quarter as a result of the pension settlement. The forward currency contracts asset and the share swap transaction asset are recorded within the "Receivables" line of the condensed consolidated balance sheets. The forward currency contracts liability and the share swap transaction liability are recorded within the "Accounts payable" line of the condensed consolidated balance sheets. The forward currency contracts and share swap transaction are further described in Note 13 - Financial Instruments.

[0000038725-25-000178:notes:71]
The Company's Level 3 category includes contingent consideration related to acquisitions, which valuation inputs are unobservable and significant to the fair value measurement.  Projections and estimated probabilities are used to estimate future contingent earn-out payments, which are discounted back to present value to compute contingent earn-out liabilities. The following table provides a roll-forward of the contingent consideration liability, which is included in "Accrued expenses and other current liabilities" as of September 30, 2025:

[0000038725-25-000178:notes:72]
|  | Third Quarter Ended | Nine Months Ended |
| (In millions) | September 30, 2025 | September 30, 2025 |
| Fair value at beginning of period | $ | — |  | $ | 5.0 |  |
| Adjustments to prior year acquisition | — |  | — |  |
| Change in fair value recognized in earnings | — |  | — |  |
| Payments | — |  | (5.0) |  |
| Fair value at end of period | $ | — |  | $ | — |  |

[0000038725-25-000178:notes:73]
Total debt, including current maturities, have carrying amounts of $204.3 million and $129.4 million and estimated fair values of $197.5 million and $128.0 million as of September 30, 2025 and December 31, 2024, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-25-000178:notes:74]
[same as prior period, unchanged from 0000038725-25-000162:notes:67]

[0000038725-25-000178:notes:75]
[same as prior period, unchanged from 0000038725-25-000162:notes:68]

[0000038725-25-000178:notes:76]
[same as prior period, unchanged from 0000038725-25-000162:notes:69]

[0000038725-25-000178:notes:77]
[same as prior period, unchanged from 0000038725-25-000162:notes:70]

[0000038725-25-000178:notes:78]
| Third Quarter Ended September 30, 2025 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 304.4 |  |  | $ | 197.3 |  |  | $ | 80.0 |  |  | $ | 581.7 |  |
| Intersegment sales | 32.2 |  |  | — |  |  | — |  |  | 32.2 |  |
|  | $ | 336.6 |  |  | $ | 197.3 |  |  | $ | 80.0 |  |  | $ | 613.9 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (32.2) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 581.7 |  |
| Cost of sales | $ | 220.1 |  |  | $ | 142.6 |  |  | $ | 43.5 |  |  |  |
| Selling, general and administrative expenses | 56.2 |  |  | 38.4 |  |  | 11.1 |  |  |  |
| Restructuring expense | 0.1 |  |  | — |  |  | — |  |  |  |
| Segment operating income | $ | 60.2 |  |  | $ | 16.3 |  |  | $ | 25.4 |  |  | $ | 101.9 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | 1.1 |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (17.8) |  |
| Interest expense |  |  |  |  |  |  | (3.5) |  |
| Other income (expense), net |  |  |  |  |  |  | (0.2) |  |
| Foreign exchange expense, net |  |  |  |  |  |  | (2.7) |  |
| Pension settlement loss |  |  |  |  |  |  | (55.3) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 23.5 |  |

[0000038725-25-000178:notes:79]
| Third Quarter Ended September 30, 2024 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 270.9 |  |  | $ | 190.8 |  |  | $ | 69.7 |  |  | $ | 531.4 |  |
| Intersegment sales | 31.3 |  |  | — |  |  | — |  |  | 31.3 |  |
|  | $ | 302.2 |  |  | $ | 190.8 |  |  | $ | 69.7 |  |  | $ | 562.7 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (31.3) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 531.4 |  |
| Cost of sales | $ | 200.1 |  |  | $ | 139.9 |  |  | $ | 35.1 |  |  |  |
| Selling, general and administrative expenses | 49.2 |  |  | 38.7 |  |  | 10.5 |  |  |  |
| Restructuring expense | 0.1 |  |  | — |  |  | — |  |  |  |
| Segment operating income | $ | 52.8 |  |  | $ | 12.2 |  |  | $ | 24.1 |  |  | $ | 89.1 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | 2.1 |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (17.6) |  |
| Interest expense |  |  |  |  |  |  | (1.6) |  |
| Other income (expense), net |  |  |  |  |  |  | (0.2) |  |
| Foreign exchange income, net |  |  |  |  |  |  | 0.1 |  |
| Pension settlement loss |  |  |  |  |  |  | — |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 71.9 |  |

[0000038725-25-000178:notes:80]
| Nine Months Ended September 30, 2025 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 861.0 |  |  | $ | 539.1 |  |  | $ | 224.3 |  |  | $ | 1,624.4 |  |
| Intersegment sales | 103.7 |  |  | — |  |  | — |  |  | 103.7 |  |
|  | $ | 964.7 |  |  | $ | 539.1 |  |  | $ | 224.3 |  |  | $ | 1,728.1 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (103.7) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 1,624.4 |  |
| Cost of sales | $ | 634.2 |  |  | $ | 391.4 |  |  | $ | 116.1 |  |  |  |
| Selling, general and administrative expenses | 164.8 |  |  | 112.9 |  |  | 31.8 |  |  |  |
| Restructuring expense | 0.2 |  |  | 0.2 |  |  | — |  |  |  |
| Segment operating income | $ | 165.5 |  |  | $ | 34.6 |  |  | $ | 76.4 |  |  | $ | 276.5 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment loss |  |  |  |  |  |  | (2.0) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (57.1) |  |
| Interest expense |  |  |  |  |  |  | (8.1) |  |
| Other income (expense), net |  |  |  |  |  |  | 0.5 |  |
| Foreign exchange expense, net |  |  |  |  |  |  | (8.5) |  |
| Pension settlement loss |  |  |  |  |  |  | (55.3) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 146.0 |  |

[0000038725-25-000178:notes:81]
| Nine Months Ended September 30, 2024 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 802.4 |  |  | $ | 528.3 |  |  | $ | 204.9 |  |  | $ | 1,535.6 |  |
| Intersegment sales | 102.0 |  |  | — |  |  | — |  |  | 102.0 |  |
|  | $ | 904.4 |  |  | $ | 528.3 |  |  | $ | 204.9 |  |  | $ | 1,637.6 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (102.0) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 1,535.6 |  |
| Cost of sales | $ | 591.7 |  |  | $ | 387.2 |  |  | $ | 104.0 |  |  |  |
| Selling, general and administrative expenses | 150.3 |  |  | 117.1 |  |  | 32.0 |  |  |  |
| Restructuring expense | 0.1 |  |  | 0.1 |  |  | — |  |  |  |
| Segment operating income | $ | 162.3 |  |  | $ | 23.9 |  |  | $ | 68.9 |  |  | $ | 255.1 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment loss |  |  |  |  |  |  | (1.7) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (52.8) |  |
| Interest expense |  |  |  |  |  |  | (5.0) |  |
| Other income (expense), net |  |  |  |  |  |  | 0.7 |  |
| Foreign exchange expense, net |  |  |  |  |  |  | (5.2) |  |
| Pension settlement loss |  |  |  |  |  |  | — |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 191.1 |  |

[0000038725-25-000178:notes:82]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions) | September 30, 2025 |  | September 30, 2024 |  | September 30, 2025 |  | September 30, 2024 |
| Depreciation and amortization |  |  |  |  |  |  |  |
| Water Systems | $ | 11.9 |  |  | $ | 9.9 |  |  | $ | 33.7 |  |  | $ | 29.2 |  |
| Distribution | 2.3 |  |  | 2.3 |  |  | 7.0 |  |  | 7.1 |  |
| Energy Systems | 1.1 |  |  | 1.1 |  |  | 3.2 |  |  | 3.1 |  |
| Total segment depreciation and amortization | $ | 15.3 |  |  | $ | 13.3 |  |  | $ | 43.9 |  |  | $ | 39.4 |  |
| Corporate | 0.8 |  |  | 0.8 |  |  | 2.4 |  |  | 2.4 |  |
| Total depreciation and amortization | $ | 16.1 |  |  | $ | 14.1 |  |  | $ | 46.3 |  |  | $ | 41.8 |  |
| Capital Expenditures |  |  |  |  |  |  |  |
| Water Systems | $ | 12.4 |  |  | $ | 7.0 |  |  | $ | 22.3 |  |  | $ | 17.5 |  |
| Distribution | 1.5 |  |  | 1.8 |  |  | 4.6 |  |  | 7.9 |  |
| Energy Systems | 0.5 |  |  | 0.2 |  |  | 1.6 |  |  | 1.2 |  |
| Total segment capital expenditure | $ | 14.4 |  |  | $ | 9.0 |  |  | $ | 28.5 |  |  | $ | 26.6 |  |
| Corporate | 0.4 |  |  | 0.5 |  |  | 1.3 |  |  | 2.3 |  |
| Total capital expenditures | $ | 14.8 |  |  | $ | 9.5 |  |  | $ | 29.8 |  |  | $ | 28.9 |  |
| Assets |  |  |  |  |  |
| Water Systems | $ | 1,244.3 |  |  | $ | 1,052.1 |  |  |  |  |  |
| Distribution | 385.1 |  |  | 398.0 |  |  |  |  |  |
| Energy Systems | 273.1 |  |  | 255.6 |  |  |  |  |  |
| Total segment assets | $ | 1,902.5 |  |  | $ | 1,705.7 |  |  |  |  |  |
| Corporate | 94.9 |  |  | 101.5 |  |  |  |  |  |
| Total assets | $ | 1,997.4 |  |  | $ | 1,807.2 |  |  |  |  |  |

[0000038725-25-000178:notes:83]
Cash and property, plant and equipment are the major asset groups in “Corporate” of total assets for the quarters ended September 30, 2025 and September 30, 2024.

[0000038725-25-000178:notes:84]
[same as prior period, unchanged from 0000038725-25-000162:notes:77]

[0000038725-25-000178:notes:85]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions) | September 30, 2025 |  | September 30, 2024 |  | September 30, 2025 |  | September 30, 2024 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 168.4 |  |  | $ | 152.3 |  |  | $ | 476.4 |  |  | $ | 448.0 |  |
| Latin America | 55.4 |  |  | 43.5 |  |  | 147.7 |  |  | 126.6 |  |
| Europe, Middle East & Africa | 57.5 |  |  | 53.4 |  |  | 164.7 |  |  | 161.7 |  |
| Asia Pacific | 23.1 |  |  | 21.7 |  |  | 72.2 |  |  | 66.1 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 32.2 |  |  | 31.3 |  |  | 103.7 |  |  | 102.0 |  |
| Total sales | 336.6 |  |  | 302.2 |  |  | 964.7 |  |  | 904.4 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 197.3 |  |  | 190.8 |  |  | 539.1 |  |  | 528.3 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 197.3 |  |  | 190.8 |  |  | 539.1 |  |  | 528.3 |  |
| Energy Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 61.4 |  |  | 55.1 |  |  | 173.7 |  |  | 160.2 |  |
| All other | 18.6 |  |  | 14.6 |  |  | 50.6 |  |  | 44.7 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 80.0 |  |  | 69.7 |  |  | 224.3 |  |  | 204.9 |  |
| Intersegment Eliminations/Other | (32.2) |  |  | (31.3) |  |  | (103.7) |  |  | (102.0) |  |
| Consolidated | $ | 581.7 |  |  | $ | 531.4 |  |  | $ | 1,624.4 |  |  | $ | 1,535.6 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000038725-25-000178:notes:86]
None of the Company’s directors or officers adopted, modified, or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement during the Company’s fiscal quarter ended September 30, 2025.
