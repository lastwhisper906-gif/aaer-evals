# FELE 8-K — 0000038725-25-000174 filed 2025-10-28

## item codes, every 8-K on or before 2025-10-30

- 2025-10-28 0000038725-25-000176 — 7.01, 9.01
- 2025-10-28 0000038725-25-000174 — 2.02, 9.01
- 2025-10-02 0000038725-25-000172 — 1.01, 2.03, 9.01
- 2025-07-29 0000038725-25-000160 — 7.01, 9.01
- 2025-07-29 0000038725-25-000158 — 2.02, 9.01
- 2025-07-28 0000038725-25-000156 — 1.01, 8.01, 9.01
- 2025-07-11 0000038725-25-000153 — 5.02, 7.01, 9.01
- 2025-06-13 0000038725-25-000144 — 1.01, 8.01, 9.01
- 2025-05-20 0000038725-25-000117 — 2.03, 9.01
- 2025-05-08 0000038725-25-000108 — 5.02, 9.01
- 2025-05-06 0000038725-25-000104 — 7.01, 9.01
- 2025-05-05 0000038725-25-000088 — 5.02, 5.07
- 2025-04-29 0000038725-25-000080 — 7.01, 9.01
- 2025-04-29 0000038725-25-000078 — 2.02, 9.01
- 2025-04-03 0000038725-25-000066 — 5.02, 9.01
- 2025-02-28 0000038725-25-000054 — 7.01, 9.01
- 2025-02-24 0000038725-25-000040 — 5.02
- 2025-02-18 0000038725-25-000013 — 7.01, 9.01
- 2025-02-18 0000038725-25-000011 — 2.02, 9.01
- 2025-02-14 0000038725-25-000009 — 7.01, 9.01
- 2024-11-12 0000038725-24-000175 — 7.01, 9.01
- 2024-11-06 0000038725-24-000169 — 7.01, 9.01
- 2024-10-29 0000038725-24-000164 — 7.01, 9.01
- 2024-10-29 0000038725-24-000162 — 2.02, 9.01
- 2024-07-24 0000038725-24-000140 — 7.01, 9.01
- 2024-07-23 0000038725-24-000138 — 2.02, 9.01
- 2024-07-01 0000038725-24-000132 — 5.02
- 2024-05-22 0000038725-24-000119 — 5.02, 9.01 — amendment of 0000038725-24-000101
- 2024-05-16 0000038725-24-000105 — 1.01, 2.03, 9.01
- 2024-05-14 0000038725-24-000101 — 5.02, 7.01, 9.01
- 2024-05-03 0000038725-24-000097 — 7.01, 9.01
- 2024-05-03 0000038725-24-000096 — 5.07
- 2024-04-30 0000038725-24-000074 — 2.02, 9.01
- 2024-02-13 0000038725-24-000012 — 7.01, 9.01
- 2024-02-13 0000038725-24-000010 — 2.02, 9.01
- 2023-11-06 0000038725-23-000184 — 7.01, 9.01
- 2023-10-24 0000038725-23-000177 — 2.02, 9.01
- 2023-08-04 0000038725-23-000160 — 5.02, 9.01
- 2023-08-03 0000038725-23-000158 — 7.01, 9.01
- 2023-07-25 0000038725-23-000149 — 2.02, 9.01
- 2023-07-05 0000038725-23-000144 — 5.02, 7.01, 9.01
- 2023-05-09 0000038725-23-000094 — 5.02, 9.01
- 2023-05-09 0000038725-23-000092 — 5.07
- 2023-05-08 0000038725-23-000087 — 7.01, 9.01
- 2023-05-02 0000038725-23-000065 — 2.02, 9.01
- 2023-03-08 0000038725-23-000046 — 7.01, 9.01
- 2023-02-21 0000038725-23-000016 — 8.01, 9.01
- 2023-02-14 0000038725-23-000002 — 2.02, 9.01
- 2022-10-28 0000038725-22-000180 — 7.01, 9.01
- 2022-10-25 0000038725-22-000177 — 2.02, 9.01
- 2022-08-04 0000038725-22-000150 — 7.01, 9.01
- 2022-07-26 0000038725-22-000142 — 2.02, 9.01
- 2022-05-11 0000038725-22-000106 — 2.03, 9.01
- 2022-05-06 0000038725-22-000082 — 5.07
- 2022-05-06 0000038725-22-000081 — 5.02, 9.01
- 2022-05-03 0000038725-22-000075 — 7.01, 9.01
- 2022-04-26 0000038725-22-000073 — 2.02, 9.01
- 2022-03-24 0000038725-22-000056 — 5.02, 9.01
- 2022-03-08 0000038725-22-000049 — 7.01, 9.01
- 2022-02-15 0000038725-22-000007 — 2.02, 9.01
- 2022-01-04 0000038725-22-000002 — 7.01, 9.01
- 2021-11-03 0000038725-21-000212 — 7.01, 9.01
- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2025-10-30

- none on or before 2025-10-30

## item 2.02 — earnings release, exhibit 99.1

[0000038725-25-000174:8k_2_02:1]
EX-99.1
2
a20251028ex991earningsrele.htm
EX-99.1

[0000038725-25-000174:8k_2_02:2]
Document

[0000038725-25-000174:8k_2_02:3]
Exhibit 99.1

[0000038725-25-000174:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-25-000174:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS THIRD QUARTER 2025 RESULTS

[0000038725-25-000174:8k_2_02:6]
Third Quarter 2025 Highlights

[0000038725-25-000174:8k_2_02:7]
•Consolidated net sales of $581.7 million, an increase of 9% to the prior year

[0000038725-25-000174:8k_2_02:8]
•Net sales increased across all three segments; 11% in Water Systems, 15% in Energy Systems, and 3% in Distribution

[0000038725-25-000174:8k_2_02:9]
•Operating income was $85.1 million, an increase of 16% to the prior year, with operating margin of 14.6%

[0000038725-25-000174:8k_2_02:10]
•The company terminated its US Pension Plan for a pre-tax settlement charge of $55.3 million ($41.7 million net of tax) and an EPS impact of approximately $0.93 per share net of tax

[0000038725-25-000174:8k_2_02:11]
•GAAP fully diluted earnings per share (EPS) was $0.37

[0000038725-25-000174:8k_2_02:12]
Fort Wayne, IN – October 28, 2025 – Franklin Electric Co., Inc. today announced its third quarter financial results for fiscal year 2025.

[0000038725-25-000174:8k_2_02:13]
Third quarter 2025 net sales were $581.7 million compared to third quarter 2024 net sales of $531.4 million. Third quarter 2025 operating income was $85.1 million, compared to third quarter 2024 operating income of $73.5 million. Third quarter 2025 diluted EPS was $0.37, compared to third quarter 2024 EPS of $1.17. Third quarter 2025 adjusted diluted EPS was $1.30, up $0.13 or 11 percent, compared to third quarter 2024.

[0000038725-25-000174:8k_2_02:14]
“Our team’s consistent execution drove third quarter results in line with our expectations, reflecting solid growth across the business. Operating performance was supported by both higher volumes and effective pricing initiatives. In addition, we continue to make progress on our strategic initiatives, including the expansion of our global manufacturing footprint in several key markets, which positions us well to more efficiently serve our customers and capture new growth opportunities,” commented Joe Ruzynski, Franklin Electric’s CEO.

[0000038725-25-000174:8k_2_02:15]
“While we continue to watch the macroeconomic environment closely, order activity remains healthy, giving us confidence in our outlook. As we close out the year, we remain focused on executing pricing discipline and cost control, while maintaining a balanced capital allocation approach to drive value for our shareholders,” concluded Mr. Ruzynski.

[0000038725-25-000174:8k_2_02:16]
Segment Summaries

[0000038725-25-000174:8k_2_02:17]
Water Systems net sales were $336.6 million in the third quarter, an increase of $34.4 million or 11 percent compared to the third quarter of 2024. Results were driven by the incremental sales impact of recent acquisitions, as well as organic volume and price realization. Water Systems operating income in the third quarter of 2025 was $60.2 million. Third quarter 2024 Water Systems operating income was $52.8 million.

[0000038725-25-000174:8k_2_02:18]
Distribution net sales were $197.3 million, an increase of $6.5 million or 3 percent compared to the third quarter of 2024. Sales increases were driven by higher volumes and price realization. The Distribution segment operating income in the third quarter 2025 was $16.3 million. Third quarter 2024 Distribution operating income was $12.2 million.

[0000038725-25-000174:8k_2_02:19]
Energy Systems net sales were $80.0 million in the third quarter 2025, an increase of $10.3 million or 15 percent compared to the third quarter 2024. Sales increases were driven by higher volumes and price realization. Energy Systems operating income in the third quarter of 2025 was $25.4 million. Third quarter 2024 Energy Systems operating income was $24.1 million.

[0000038725-25-000174:8k_2_02:20]
Cash Flow

[0000038725-25-000174:8k_2_02:21]
Net cash flows from operating activities through the nine months of 2025 were $134.7 million versus $151.1 million in the same period in 2024.

[0000038725-25-000174:8k_2_02:22]
2025 Guidance

[0000038725-25-000174:8k_2_02:23]
The Company is maintaining the midpoint of its guidance for full year 2025 sales to be in the range of $2.09 billion to $2.15 billion and full year 2025 EPS to be in the range of $4.00 to $4.20 without the impact of the pension termination.

[0000038725-25-000174:8k_2_02:24]
Earnings Conference Call

[0000038725-25-000174:8k_2_02:25]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The third quarter 2025 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-25-000174:8k_2_02:26]
https://edge.media-server.com/mmc/p/apav9spr

[0000038725-25-000174:8k_2_02:27]
For those interested in participating in the question-and-answer portion of the call, please register for the call at the link below.

[0000038725-25-000174:8k_2_02:28]
https://register-conf.media-server.com/register/BIf59e8648a1fd4ca6975c13e36b5bb68a

[0000038725-25-000174:8k_2_02:29]
All registrants will receive dial-in information and a PIN allowing them to access the live call. It is recommended that you join 10 minutes prior to the event start (although you may register and dial in at any time during the call).

[0000038725-25-000174:8k_2_02:30]
A replay of the conference call will be available from Tuesday, October 28, 2025, through 9:00 am ET on Tuesday, November 4, 2025, by visiting the listen-only webcast link above.

[0000038725-25-000174:8k_2_02:31]
Forward Looking Statements

[0000038725-25-000174:8k_2_02:32]
on information currently available, and the Company assumes no obligation to update any forward-looking statements.

[0000038725-25-000174:8k_2_02:33]
Note Regarding Non-GAAP Financial Measures

[0000038725-25-000174:8k_2_02:34]
The company reports its financial results in accordance with U.S. generally accepted accounting principles (GAAP). Management believes that the non-GAAP financial measure Adjusted Diluted EPS provides additional meaningful information regarding the company’s performance and financial strength. Non-GAAP financial measures should be viewed in addition to and not as an alternative for the company’s reported results prepared in accordance with GAAP. In addition, not all companies use identical calculations for Adjusted Diluted EPS; therefore, Adjusted Diluted EPS included in this release may not be comparable to similarly titled measures of other companies.

[0000038725-25-000174:8k_2_02:35]
About Franklin Electric

[0000038725-25-000174:8k_2_02:36]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and energy. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications. Franklin Electric is proud to be named in Newsweek’s lists of America’s Most Responsible Companies and Most Trustworthy Companies for 2024 and America’s Climate Leaders 2024 by USA Today.

[0000038725-25-000174:8k_2_02:37]
Franklin Electric Contact:

[0000038725-25-000174:8k_2_02:38]
Jennifer Wolfenbarger

[0000038725-25-000174:8k_2_02:39]
Franklin Electric Co., Inc.

[0000038725-25-000174:8k_2_02:40]
InvestorRelations@fele.com

[0000038725-25-000174:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |  |  |  |  |
|  | Third Quarter Ended |  | Nine Months Ended |  |  |
|  | September 30, 2025 |  | September 30, 2024 |  | September 30, 2025 |  | September 30, 2024 |  |  |  |  |
| Net sales | $ | 581,714 |  |  | $ | 531,438 |  |  | $ | 1,624,395 |  |  | $ | 1,535,596 |  |  |  |  |  |
| Cost of sales | 373,010 |  |  | 341,775 |  |  | 1,039,962 |  |  | 982,556 |  |  |  |  |  |
| Gross profit | 208,704 |  |  | 189,663 |  |  | 584,433 |  |  | 553,040 |  |  |  |  |  |
| Selling, general, and administrative expenses | 123,474 |  |  | 115,998 |  |  | 366,638 |  |  | 352,290 |  |  |  |  |  |
| Restructuring expense | 112 |  |  | 139 |  |  | 435 |  |  | 139 |  |  |  |  |  |
| Operating income | 85,118 |  |  | 73,526 |  |  | 217,360 |  |  | 200,611 |  |  |  |  |  |
| Interest expense | (3,496) |  |  | (1,556) |  |  | (8,100) |  |  | (4,980) |  |  |  |  |  |
| Other income (expense), net | (165) |  |  | (181) |  |  | 514 |  |  | 709 |  |  |  |  |  |
| Foreign exchange income (expense), net | (2,673) |  |  | 88 |  |  | (8,514) |  |  | (5,228) |  |  |  |  |  |
| Pension settlement loss | (55,251) |  |  | — |  |  | (55,251) |  |  | — |  |  |  |  |  |
| Income before income taxes | 23,533 |  |  | 71,877 |  |  | 146,009 |  |  | 191,112 |  |  |  |  |  |
| Income tax expense | 6,329 |  |  | 16,983 |  |  | 36,868 |  |  | 43,795 |  |  |  |  |  |
| Net income | $ | 17,204 |  |  | $ | 54,894 |  |  | $ | 109,141 |  |  | $ | 147,317 |  |  |  |  |  |
| Less: Net income attributable to noncontrolling interests | (466) |  |  | (298) |  |  | (1,301) |  |  | (663) |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 16,738 |  |  | $ | 54,596 |  |  | $ | 107,840 |  |  | $ | 146,654 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.37 |  |  | $ | 1.19 |  |  | $ | 2.38 |  |  | $ | 3.18 |  |  |  |  |  |
| Diluted | $ | 0.37 |  |  | $ | 1.17 |  |  | $ | 2.35 |  |  | $ | 3.14 |  |  |  |  |  |

[0000038725-25-000174:8k_2_02:42]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | September 30, 2025 |  | December 31, 2024 |
| ASSETS |  |
| Cash and cash equivalents | $ | 102,927 |  |  | $ | 220,540 |  |
| Receivables (net) | 291,178 |  |  | 226,826 |  |
| Inventories | 569,180 |  |  | 483,875 |  |
| Other current assets | 53,470 |  |  | 32,950 |  |
| Total current assets | 1,016,755 |  |  | 964,191 |  |
| Property, plant, and equipment, net | 245,315 |  |  | 223,566 |  |
| Lease right-of-use assets, net | 66,891 |  |  | 62,637 |  |
| Goodwill and other assets | 668,415 |  |  | 570,212 |  |
| Total assets | $ | 1,997,376 |  |  | $ | 1,820,606 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 185,775 |  |  | $ | 157,046 |  |
| Accrued expenses and other current liabilities | 126,164 |  |  | 139,989 |  |
| Current lease liability | 19,781 |  |  | 18,878 |  |
| Current maturities of long-term debt and short-term borrowings | 69,074 |  |  | 117,814 |  |
| Total current liabilities | 400,794 |  |  | 433,727 |  |
| Long-term debt | 135,230 |  |  | 11,622 |  |
| Long-term lease liability | 46,632 |  |  | 43,304 |  |
| Deferred income taxes | 32,425 |  |  | 10,193 |  |
| Employee benefit plans | 31,672 |  |  | 29,808 |  |
| Other long-term liabilities | 27,577 |  |  | 22,118 |  |
| Redeemable noncontrolling interest | 1,644 |  |  | 1,224 |  |
| Total equity | 1,321,402 |  |  | 1,268,610 |  |
| Total liabilities and equity | $ | 1,997,376 |  |  | $ | 1,820,606 |  |

[0000038725-25-000174:8k_2_02:43]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Nine Months Ended |
| (In thousands) |  |  |  |
|  | September 30, 2025 |  | September 30, 2024 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 109,141 |  |  | $ | 147,317 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 46,258 |  |  | 41,825 |  |
| Pension settlement loss, net of tax | 41,693 |  |  | — |  |
| Non-cash lease expense | 16,279 |  |  | 15,223 |  |
| Share-based compensation | 10,341 |  |  | 10,127 |  |
| Other | 4,188 |  |  | 5,178 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (34,660) |  |  | (51,440) |  |
| Inventory | (45,036) |  |  | (18,760) |  |
| Accounts payable and accrued expenses | 873 |  |  | 17,218 |  |
| Operating leases | (16,300) |  |  | (15,700) |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | (4,837) |  | (3,870) |
| Other | 6,747 |  |  | 3,968 |  |
| Net cash flows from operating activities | 134,687 |  |  | 151,086 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (29,820) |  |  | (28,897) |  |
| Proceeds from sale of property, plant, and equipment | 2,578 |  |  | 704 |  |
| Acquisitions and investments | (109,948) |  |  | (1,151) |  |
| Other investing activities | 73 |  |  | 37 |  |
| Net cash flows from investing activities | (137,117) |  |  | (29,307) |  |
| Cash flows from financing activities: |  |  |  |
| Net change in debt | 55,721 |  |  | (12,477) |  |
| Payment of debt issuance costs | (974) |  |  | — |  |
| Proceeds from issuance of common stock | 3,991 |  |  | 5,269 |  |
| Purchases of common stock | (129,415) |  |  | (56,989) |  |
| Dividends paid | (37,184) |  |  | (35,442) |  |
| Deferred payments for acquisitions | (4,300) |  |  | (348) |  |
| Net cash flows from financing activities | (112,161) |  |  | (99,987) |  |
| Effect of exchange rate changes on cash and cash equivalents | (3,022) |  |  | (482) |  |
| Net change in cash and cash equivalents | (117,613) |  |  | 21,310 |  |
| Cash and cash equivalents at beginning of period | 220,540 |  |  | 84,963 |  |
| Cash and cash equivalents at end of period | $ | 102,927 |  |  | $ | 106,273 |  |

[0000038725-25-000174:8k_2_02:44]
Key Performance Indicators: Net Sales Summary

[0000038725-25-000174:8k_2_02:45]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Energy | Distribution | Other/Elims | Consolidated |
| Q3 2024 | $ | 183.6 |  | $ | 43.5 |  | $ | 53.4 |  | $ | 21.7 |  | $ | 302.2 |  | $ | 69.7 |  | $ | 190.8 |  | $ | (31.3) |  | $ | 531.4 |  |
| Q3 2025 | $ | 200.6 |  | $ | 55.4 |  | $ | 57.5 |  | $ | 23.1 |  | $ | 336.6 |  | $ | 80.0 |  | $ | 197.3 |  | $ | (32.2) |  | $ | 581.7 |  |
| Change | $ | 17.0 |  | $ | 11.9 |  | $ | 4.1 |  | $ | 1.4 |  | $ | 34.4 |  | $ | 10.3 |  | $ | 6.5 |  | $ | (0.9) |  | $ | 50.3 |  |
| % Change | 9 | % | 27 | % | 8 | % | 6 | % | 11 | % | 15 | % | 3 | % |  | 9 | % |
| Foreign currency translation, net* | $ | (0.1) |  | $ | 0.7 |  | $ | 0.7 |  | $ | (0.4) |  | $ | 0.9 |  | $ | 0.1 |  | $ | — |  |  | $ | 1.0 |  |
| % Change | — | % | 2 | % | 1 | % | (2) | % | — | % | — | % | — | % |  | — | % |
| Acquisitions | $ | 0.9 |  | $ | 12.3 |  | $ | — |  | $ | 3.0 |  | $ | 16.2 |  | $ | — |  | $ | — |  |  | $ | 16.2 |  |
| % Change | — | % | 28 | % | — | % | 14 | % | 5 | % | — | % | — | % |  | 3 | % |
| Volume/Price | $ | 16.2 |  | $ | (1.1) |  | $ | 3.4 |  | $ | (1.2) |  | $ | 17.3 |  | $ | 10.2 |  | $ | 6.5 |  | $ | (0.9) |  | $ | 33.1 |  |
| % Change | 9 | % | (3) | % | 6 | % | (6) | % | 6 | % | 15 | % | 3 | % | 3 | % | 6 | % |

[0000038725-25-000174:8k_2_02:46]
*The Company has presented local currency price increases used to offset currency devaluation in the Argentina and Turkey hyperinflationary economies within the foreign currency translation, net row above.

[0000038725-25-000174:8k_2_02:47]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-25-000174:8k_2_02:48]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2025 |
|  | Water | Energy | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 60.2 |  | $ | 25.4 |  | $ | 16.3 |  | $ | (16.8) |  | $ | 85.1 |  |
| % Operating Income To Net Sales | 17.9 | % | 31.8 | % | 8.3 | % |  | 14.6 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2024 |
|  | Water | Energy | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 52.8 |  | $ | 24.1 |  | $ | 12.2 |  | $ | (15.6) |  | $ | 73.5 |  |
| % Operating Income To Net Sales | 17.5 | % | 34.6 | % | 6.4 | % |  | 13.8 | % |

[0000038725-25-000174:8k_2_02:49]
|  | For the Third Quarter |  | For the first nine months |
|  | 2025 | 2024 | Change |  | 2025 | 2024 | Change |
| Diluted Earnings per Share "EPS" (as reported - US GAAP) | $ | 0.37 |  | $ | 1.17 |  | (68) | % |  | $ | 2.35 |  | $ | 3.14 |  | (25) | % |
| Pension Settlement Loss | $ | 0.93 |  | $ | — |  |  |  | $ | 0.93 |  | $ | — |  |  |
| Adjusted Diluted EPS (non-GAAP) | $ | 1.30 |  | $ | 1.17 |  | 11 | % |  | $ | 3.28 |  | $ | 3.14 |  | 4 | % |
