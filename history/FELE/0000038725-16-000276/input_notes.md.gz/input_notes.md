# FELE notes — 0000038725-16-000276


## fele:DisclosureOfShareBasedCompensationArrangementsAuthorizedSharesTableTextBlock

[0000038725-16-000276:notes:1]
The 2012 Stock Plan authorizes 2,400,000 shares for issuance as follows:

[0000038725-16-000276:notes:2]
| 2012 Stock Plan |  | Authorized Shares |
| Stock Options |  | 1,680,000 |
| Stock/Stock Unit Awards |  | 720,000 |

[0000038725-16-000276:notes:3]
The Company also maintains the Amended and Restated Franklin Electric Co., Inc. Stock Plan (the "2009 Stock Plan") which, as amended in 2009, provided for discretionary grants of stock options and stock awards.  The 2009 Stock Plan authorized 4,400,000 shares for issuance as follows:

[0000038725-16-000276:notes:4]
| 2009 Stock Plan | Authorized Shares |
| Stock Options | 3,200,000 |
| Stock Awards | 1,200,000 |


## fele:ExtendedAndStandardProductWarrantyPolicyPolicyTextBlock

[0000038725-16-000276:notes:5]
Warranty terms are generally 2 years from date of manufacture or 1 year from date of installation.  The general warranty liability is recorded when revenue is recognized and is based on actual historical return rates from the most recent warranty periods.  In 2007, the Company began offering an extended warranty program to certain Water Systems segment customers, which provides warranty coverage up to 5 years from the date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims and expected customer returns.  The Company actively studies trends of warranty claims and takes action to improve product quality and minimize warranty claims.


## fele:ScheduleOfFiniteAndIndefiniteLivedIntangibleAssetsTableTextBlock

[0000038725-16-000276:notes:6]
The carrying amounts of the Company’s intangible assets are as follows:

[0000038725-16-000276:notes:7]
| (In millions) |  | 2015 |  | 2014 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.4 |  |  | $ | (6.2 | ) |  | $ | 7.6 |  |  | $ | (6.1 | ) |
| Supply agreements |  | — |  |  | — |  |  | 4.4 |  |  | (4.4 | ) |
| Technology |  | 7.5 |  |  | (4.8 | ) |  | 7.5 |  |  | (4.3 | ) |
| Customer relationships |  | 132.6 |  |  | (42.3 | ) |  | 140.2 |  |  | (36.5 | ) |
| Software |  | 2.5 |  |  | (1.7 | ) |  | 2.9 |  |  | (1.7 | ) |
| Other |  | 1.0 |  |  | (1.0 | ) |  | 1.2 |  |  | (1.2 | ) |
| Total |  | $ | 151.0 |  |  | $ | (56.0 | ) |  | $ | 163.8 |  |  | $ | (54.2 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 46.4 |  |  | — |  |  | 50.7 |  |  | — |  |
| Total intangibles |  | $ | 197.4 |  |  | $ | (56.0 | ) |  | $ | 214.5 |  |  | $ | (54.2 | ) |


## fele:ScheduleOfSharesRepurchasedAndRetiredDuringYearTableTextBlock

[0000038725-16-000276:notes:8]
During 2015, 2014, and 2013, pursuant to a stock repurchase program authorized by the Company’s Board of Directors, the Company repurchased and retired the following amounts and number of shares:

[0000038725-16-000276:notes:9]
| (In millions, except share amounts) |  | 2015 |  | 2014 |  | 2013 |
| Repurchases |  | $ | 46.3 |  |  | $ | 9.0 |  |  | $ | 2.8 |  |
| Shares |  | 1,568,731 |  |  | 243,020 |  |  | 88,200 |  |


## fele:ScheduleOfWeightedAverageNumberOfYearsOverWhichEachIntangibleClassIsAmortizedTableTextBlock

[0000038725-16-000276:notes:10]
The weighted average number of years over which each intangible class is amortized is as follows:

[0000038725-16-000276:notes:11]
| Class |  | Years |
| Patents |  | 17 |
| Supply agreements |  | 6 |
| Technology |  | 15 |
| Customer relationships |  | 13 - 20 |
| Software |  | 5 |
| Other |  | 8 |


## fele:ScheduleRelatedChangesInBenefitObligationsChangesInPlanAssetsFundedStatusAmountsRecognizedInBalanceSheetAmountsRecognizedInOtherAccumulatedComprehensiveIncomeTableTextBlock

[0000038725-16-000276:notes:12]
The following table sets forth aggregated information related to the Company’s pension benefits and other postretirement benefits, including changes in the benefit obligations, changes in plan assets, funded status, amounts recognized in the balance sheet, amounts recognized in accumulated other comprehensive income, and actuarial assumptions that the Company considered in its determination of benefit obligations and plan costs.  Benefit obligation balances presented below reflect the projected benefit obligation (PBO) for the Company's pension plans, and accumulated postretirement benefit obligations (APBO) for the Company's other benefit plans.

[0000038725-16-000276:notes:13]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Accumulated benefit obligation, end of year |  | $ | 182.8 |  |  | $ | 203.4 |  |  | $ | 11.3 |  |  | $ | 13.0 |  |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation, beginning of year |  | $ | 209.5 |  |  | $ | 184.7 |  |  | $ | 13.0 |  |  | $ | 12.6 |  |
| Service cost |  | 1.4 |  |  | 1.2 |  |  | 0.1 |  |  | 0.1 |  |
| Interest cost |  | 7.5 |  |  | 8.2 |  |  | 0.5 |  |  | 0.5 |  |
| Actuarial (gain)/loss |  | (12.3 | ) |  | 33.0 |  |  | (1.0 | ) |  | 1.2 |  |
| Settlements paid |  | (0.4 | ) |  | (0.2 | ) |  | — |  |  | — |  |
| Benefits paid |  | (14.4 | ) |  | (15.0 | ) |  | (1.3 | ) |  | (1.4 | ) |
| Curtailment |  | (1.9 | ) |  | — |  |  | — |  |  | — |  |
| Foreign currency exchange |  | (2.5 | ) |  | (2.4 | ) |  | — |  |  | — |  |
| Benefit obligation, end of year |  | $ | 186.9 |  |  | $ | 209.5 |  |  | $ | 11.3 |  |  | $ | 13.0 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of assets, beginning of year |  | $ | 160.0 |  |  | $ | 151.1 |  |  | $ | — |  |  | $ | — |  |
| Actual return on plan assets |  | (4.0 | ) |  | 14.4 |  |  | — |  |  | — |  |
| Company contributions |  | 6.9 |  |  | 10.1 |  |  | 1.3 |  |  | 1.4 |  |
| Settlements paid |  | (0.4 | ) |  | (0.1 | ) |  | — |  |  | — |  |
| Benefits paid |  | (14.4 | ) |  | (15.0 | ) |  | (1.3 | ) |  | (1.4 | ) |
| Foreign currency exchange |  | (0.7 | ) |  | (0.5 | ) |  | — |  |  | — |  |
| Plan assets, end of year |  | $ | 147.4 |  |  | $ | 160.0 |  |  | $ | — |  |  | $ | — |  |
| Funded status |  | $ | (39.5 | ) |  | $ | (49.5 | ) |  | $ | (11.3 | ) |  | $ | (13.0 | ) |
| Amounts recognized in balance sheet: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred tax asset |  | 29.6 |  |  | 30.4 |  |  | 0.9 |  |  | 1.5 |  |
| Current liabilities |  | (3.4 | ) |  | (3.5 | ) |  | (1.2 | ) |  | (1.3 | ) |
| Noncurrent liabilities |  | (36.0 | ) |  | (46.0 | ) |  | (10.1 | ) |  | (11.7 | ) |
| Net liability, end of year |  | $ | (9.8 | ) |  | $ | (19.1 | ) |  | $ | (10.4 | ) |  | $ | (11.5 | ) |
| Amount recognized in accumulated other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior service cost |  | — |  |  | — |  |  | 0.5 |  |  | 0.7 |  |
| Net actuarial loss |  | 48.0 |  |  | 52.3 |  |  | 0.9 |  |  | 1.7 |  |
| Settlement |  | 2.1 |  |  | 1.4 |  |  | — |  |  | — |  |
| Total recognized in accumulated other comprehensive income |  | $ | 50.1 |  |  | $ | 53.7 |  |  | $ | 1.4 |  |  | $ | 2.4 |  |


## fele:ScheduleofCompanyContributionstoDefinedContributionPlansTableTextBlock

[0000038725-16-000276:notes:14]
The following table sets forth Company contributions to the defined contribution plans:

[0000038725-16-000276:notes:15]
| (In millions) |  | 2015 |  | 2014 |  | 2013 |
| Company contributions to the plans |  | $ | 5.9 |  |  | $ | 5.6 |  |  | $ | 5.3 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000038725-16-000276:notes:16]
ACCRUED EXPENSES AND OTHER CURRENT LIABILITIES

[0000038725-16-000276:notes:17]
Accrued expenses and other current liabilities consist of:

[0000038725-16-000276:notes:18]
| (In millions) |  | 2015 |  | 2014 |
| Salaries, wages, and commissions |  | $ | 20.5 |  |  | $ | 38.8 |  |
| Product warranty costs |  | 9.3 |  |  | 9.4 |  |
| Insurance |  | 2.7 |  |  | 2.8 |  |
| Employee benefits |  | 11.0 |  |  | 11.1 |  |
| Pioneer additional purchase price |  | — |  |  | 22.9 |  |
| Other |  | 8.6 |  |  | 9.8 |  |
|  |  | $ | 52.1 |  |  | $ | 94.8 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-16-000276:notes:19]
ACQUISITIONS

[0000038725-16-000276:notes:20]
In 2012, the Company acquired a controlling interest in Pioneer Pump Holdings, Inc. ("PPH").  Pursuant to the terms of the 2012 stock purchase agreement, the remaining 29.5 percent noncontrolling interest was recorded at $22.9 million and accounted for as a share purchase liability.  During the first quarter of 2015, the Company purchased the remaining 29.5 percent of outstanding shares of PPH for $20.2 million, increasing the Company's ownership in PPH to 100 percent.  The purchase was considered the settlement of a financing obligation, and the resulting $2.7 million gain was recorded in the Company's consolidated statements of income in the "Other income, net" line during the first quarter of 2015.

[0000038725-16-000276:notes:21]
During the third quarter of 2014, the Company acquired controlling interests in two entities in India in separate unrelated transactions.  Neither of the acquisitions was individually material, and the combined purchase price paid was approximately $6.6 million.  The results of the two businesses from their respective dates of acquisition through January 3, 2015 were not material.

[0000038725-16-000276:notes:22]
In an agreement dated June 6, 2014, between the Company and Bombas Leao S.A. ("Bombas Leao"), the Company acquired rights to 100 percent of the outstanding shares of Bombas Leao for a cash purchase price of approximately BRL 69.6 million million, $31.0 million at the then current exchange rate, subject to certain terms and conditions. The Company also acquired debt and certain liabilities of Bombas Leao. The Company funded the acquisition with cash on hand and short-term borrowings from the Company's revolving credit agreement.

[0000038725-16-000276:notes:23]
Bombas Leao, based in Monte Azul Paulista, State of Sao Paulo, Brazil, designs, manufactures, and distributes submersible groundwater pumping equipment through manufacturing and distribution facilities.

[0000038725-16-000276:notes:24]
The Bombas Leao intangible assets of $23.5 million consist primarily of customer relationships, which will be amortized utilizing the straight line method over 20 years, and trade names, which are classified as indefinite lived assets and will not be amortized.

[0000038725-16-000276:notes:25]
The goodwill amount of $3.4 million resulting from the Bombas Leao acquisition consists primarily of broadened product offerings and expanded customer base. All of the goodwill was recorded as part of the Water Systems segment and is not expected to be deductible for tax purposes.

[0000038725-16-000276:notes:26]
Preliminary goodwill increased by $0.3 million and current assets decreased by $0.3 million during 2015 due to working capital adjustments.  In addition, the Company paid an additional $0.3 million to the sellers of Bombas Leao during 2015 to satisfy amounts previously accrued per the original purchase agreement.

[0000038725-16-000276:notes:27]
The final purchase price assigned to the major identifiable assets and liabilities for the Bombas Leao acquisition is as follows:

[0000038725-16-000276:notes:28]
| (In millions) |  |
| Assets: |  |
| Cash acquired | $ | 1.1 |  |
| Current assets | 13.4 |  |
| Property, plant, and equipment | 6.5 |  |
| Intangible assets | 23.5 |  |
| Goodwill | 3.4 |  |
| Other assets | 3.1 |  |
| Total assets | 51.0 |  |
| Liabilities | (20.0 | ) |
| Total consideration paid | $ | 31.0 |  |

[0000038725-16-000276:notes:29]
The fair values of the identifiable assets, property, plant, and equipment, and liabilities were final as of the second quarter of 2015.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation.

[0000038725-16-000276:notes:30]
The results of operations of Bombas Leao were included in the Company's consolidated statements of income from the acquisition date through the year ended January 3, 2015.  The difference between actual sales for the Company and proforma sales including Bombas Leao as if it was acquired at the beginning of each year was not material as a component of the Company's consolidated sales for the years ended January 3, 2015 and December 28, 2013, respectively.  Due to the immaterial nature of the acquisition, the Company has not included full year proforma statements of income for the acquisition year or previous year.

[0000038725-16-000276:notes:31]
Transaction costs for all acquisition related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations.  Transaction costs included in selling, general, and administrative expense in the Company’s consolidated statements of income were $0.2 million, $2.4 million, and $1.1 million for the fiscal years ended 2015, 2014, and 2013, respectively.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000038725-16-000276:notes:32]
The Company considers cash on hand, demand deposits, and highly liquid investments with an original maturity date of three months or less to be cash and cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000038725-16-000276:notes:33]
COMMITMENTS AND CONTINGENCIES

[0000038725-16-000276:notes:34]
In August 2010, the California Air Resources Board (“CARB”) and South Coast Air Quality Management District (“SCAQMD”) filed civil complaints in the Los Angeles Superior Court against the Company and Franklin Fueling Systems, Inc.  The complaints related to a third-party-supplied component part of the Company's Healy 900 Series nozzle, which is part of the Company's Enhanced Vapor Recovery (“EVR”) Systems installed in California gasoline filling stations.  The complaints were consolidated into one case (People of the State of California vs. Franklin Fueling Systems, Inc. et al.) which was tried in the later part of December 2012 and early part of January 2013 (“CARB Case”).

[0000038725-16-000276:notes:35]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed. On September 29, 2015 the Court of Appeals heard oral arguments on the case. On December 8, 2015, the Court of Appeals affirmed the lower court’s decision. Although CARB had the opportunity to petition for cert to the California Supreme Court, the time for filing such petition has passed and thus this case has concluded.

[0000038725-16-000276:notes:36]
Neither of these suits has had any effect on CARB's certification of the Company's EVR System or any other products of the Company or its subsidiaries, and did not interfere with continuing sales.  CARB has never decertified the Company's EVR System and has never proposed to do so.

[0000038725-16-000276:notes:37]
The Company is defending various other claims and legal actions, including environmental matters, which have arisen in the

[0000038725-16-000276:notes:38]
ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with

[0000038725-16-000276:notes:39]
counsel, these claims and legal actions can be successfully defended or resolved without a material adverse effect on the

[0000038725-16-000276:notes:40]
Company’s financial position, results of operations, and net cash flows.

[0000038725-16-000276:notes:41]
Total rent expense charged to operations for operating leases including contingent rentals was $11.9 million, $12.6 million, and $11.0 million in 2015, 2014, and 2013, respectively.

[0000038725-16-000276:notes:42]
The future minimum rental payments for non-cancelable operating leases as of January 2, 2016, are as follows:

[0000038725-16-000276:notes:43]
| (In millions) | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |
| Future minimum rental payments | $ | 7.7 |  |  | $ | 5.0 |  |  | $ | 3.6 |  |  | $ | 2.5 |  |  | $ | 1.9 |  |

[0000038725-16-000276:notes:44]
Rental commitments subsequent to 2020 are not significant by year, but aggregated are $1.9 million in total.

[0000038725-16-000276:notes:45]
At January 2, 2016, the Company had $8.3 million of commitments primarily for capital expenditures and the purchase of raw materials to be used in production.

[0000038725-16-000276:notes:46]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's consolidated balance sheets for 2015 and 2014, are as follows:

[0000038725-16-000276:notes:47]
| (In millions) |  | 2015 |  | 2014 |
| Beginning balance |  | $ | 9.4 |  |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 7.6 |  |  | 8.9 |  |
| Reductions for payments made |  | (7.7 | ) |  | (9.0 | ) |
| Ending balance |  | $ | 9.3 |  |  | $ | 9.4 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-16-000276:notes:48]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0000038725-16-000276:notes:49]
Changes in accumulated other comprehensive income (loss) by component are summarized below:

[0000038725-16-000276:notes:50]
| (In millions) |  |  |  |  |  |
| For the Year Ended January 2, 2016: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance, January 3, 2015 | $ | (51.8 | ) |  | $ | (56.1 | ) |  | $ | (107.9 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (58.9 | ) |  | — |  |  | (58.9 | ) |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (58.9 | ) |  | — |  |  | (58.9 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income/(loss) | — |  |  | 7.1 |  | (1) | 7.1 |  |
| Income tax (expense)/benefit | — |  |  | (2.5 | ) |  | (2.5 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 4.6 |  |  | 4.6 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (58.9 | ) |  | 4.6 |  |  | (54.3 | ) |
| Less: Other comprehensive income/(loss) attributable to noncontrolling interest | (0.6 | ) |  | — |  |  | (0.6 | ) |
| Balance, January 2, 2016 | $ | (110.1 | ) |  | $ | (51.5 | ) |  | $ | (161.6 | ) |
| For the Year Ended January 3, 2015: |  |  |  |  |  |
| Balance, December 28, 2013 | $ | (16.0 | ) |  | $ | (38.7 | ) |  | $ | (54.7 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (36.3 | ) |  | — |  |  | (36.3 | ) |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (36.3 | ) |  | — |  |  | (36.3 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income/(loss) | — |  |  | (26.0 | ) | (1) | (26.0 | ) |
| Income tax (expense)/benefit | — |  |  | 8.6 |  |  | 8.6 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | (17.4 | ) |  | (17.4 | ) |
| Net current period other comprehensive income/(loss), net of income taxes | (36.3 | ) |  | (17.4 | ) |  | (53.7 | ) |
| Less: Other comprehensive income/(loss) attributable to noncontrolling interest | (0.5 | ) |  | — |  |  | (0.5 | ) |

[0000038725-16-000276:notes:51]
| Balance, January 3, 2015 | $ | (51.8 | ) |  | $ | (56.1 | ) |  | $ | (107.9 | ) |
| For the Year Ended December 28, 2013: |  |  |  |  |  |
| Balance, December 29, 2012 | $ | (0.3 | ) |  | $ | (56.8 | ) |  | $ | (57.1 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (16.0 | ) |  | — |  |  | (16.0 | ) |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (16.0 | ) |  | $ | — |  |  | (16.0 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income/(loss) | — |  |  | 30.2 |  | (1 | ) | 30.2 |  |
| Income tax (expense)/benefit | — |  |  | (12.1 | ) |  | (12.1 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 18.1 |  |  | 18.1 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (16.0 | ) |  | 18.1 |  |  | 2.1 |  |
| Less: Other comprehensive income/(loss) attributable to noncontrolling interest | (0.3 | ) |  | — |  |  | (0.3 | ) |
| Balance, December 28, 2013 | $ | (16.0 | ) |  | $ | (38.7 | ) |  | $ | (54.7 | ) |

[0000038725-16-000276:notes:52]
(1) This accumulated other comprehensive income (loss) component is included in the computation of net periodic pension cost (refer to Note 8 for additional details) and is included in the "Selling, general, and administrative expenses" line of the Company's consolidated statements of income.


## us-gaap:ConsolidationPolicyTextBlock

[0000038725-16-000276:notes:53]
The consolidated financial statements include the accounts of Franklin Electric Co., Inc. and its consolidated subsidiaries.  All intercompany transactions have been eliminated.


## us-gaap:DebtDisclosureTextBlock

[0000038725-16-000276:notes:54]
DEBT

[0000038725-16-000276:notes:55]
New York Life

[0000038725-16-000276:notes:56]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025.  These senior notes have a floating interest rate of one-month USD LIBOR plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of January 2, 2016, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-16-000276:notes:57]
Project Bonds

[0000038725-16-000276:notes:58]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement.  Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)."  The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million.  The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (tax increment financing debt) bear interest at 3.6 percent per annum.  Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.  The use of the proceeds from the Project Notes was limited to assist the financing of the new Global Corporate Headquarters and Engineering Center.  On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-16-000276:notes:59]
Prudential Agreement

[0000038725-16-000276:notes:60]
On April 9, 2007, the Company entered into the Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") in the amount of $175.0 million.  Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”).  The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had at issuance an average life of 10 years with a final maturity in 2019.  On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million.  On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Agreement.  On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015.  On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement.   This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of January 2, 2016, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.

[0000038725-16-000276:notes:61]
Credit Agreement

[0000038725-16-000276:notes:62]
On December 14, 2006, the Company entered into an amended and restated unsecured, 60-month $120.0 million revolving credit agreement (the “Credit Agreement”).  The Credit Agreement provides for various borrowing rate options including interest rates based on the London Interbank Offered Rates (LIBOR) plus interest spreads keyed to the Company’s ratio of debt to earnings before interest, taxes, depreciation, and amortization (“EBITDA”).  On December 14, 2011, the Company executed the Second Amended and Restated Credit Agreement, which extended the maturity of the Agreement to December 14, 2016, and increased the commitment amount to $150.0 million.  On May 5, 2015, the Company entered into Amendment No. 3 to the Credit Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  The Company had zero borrowings under the Credit Agreement at January 2, 2016 and January 3, 2015.

[0000038725-16-000276:notes:63]
Covenants

[0000038725-16-000276:notes:64]
The New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Credit Agreement, the Prudential Agreement, the Project Bonds, and the New York Life Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million.  The Company was in compliance with all financial covenants as of January 2, 2016.

[0000038725-16-000276:notes:65]
The Company also has certain overdraft facilities at its foreign subsidiaries, of which none were outstanding at January 2, 2016 and January 3, 2015.

[0000038725-16-000276:notes:66]
Debt consisted of the following:

[0000038725-16-000276:notes:67]
| (In millions) |  | 2015 |  | 2014 |
| New York Life |  | $ | 75.0 |  |  | $ | — |  |
| Prudential Agreement - 5.79 percent |  | 120.0 |  |  | 150.0 |  |
| Tax increment financing debt |  | 22.8 |  |  | 23.7 |  |
| Capital leases |  | 0.1 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 3.1 |  |  | 3.5 |  |
|  |  | 221.0 |  |  | 177.8 |  |
| Less current maturities |  | (32.9 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 188.1 |  |  | $ | 143.7 |  |

[0000038725-16-000276:notes:68]
The following debt payments are expected to be paid in accordance with the following schedule:

[0000038725-16-000276:notes:69]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More than 5 years |
| Debt |  | $ | 220.9 |  |  | $ | 32.8 |  |  | $ | 31.1 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 93.2 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 221.0 |  |  | $ | 32.9 |  |  | $ | 31.1 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 93.2 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-16-000276:notes:70]
FINANCIAL INSTRUMENTS

[0000038725-16-000276:notes:71]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  During February 2014, the Company entered into a share swap transaction agreement ("the swap") to mitigate the Company’s exposure to these fluctuations in the Company's stock price.  The swap was not designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  As of January 2, 2016, the swap has a notional value based on 175,000 shares.  For the years ended January 2, 2016 and January 3, 2015, the swap resulted in losses of $2.0 million and $0.8 million, respectively.  Losses resulting from the swap were primarily offset by gains on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-16-000276:notes:72]
SHARE-BASED COMPENSATION

[0000038725-16-000276:notes:73]
The Company maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the "2012 Stock Plan"), which is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards and stock unit awards, to key employees and non-employee directors.

[0000038725-16-000276:notes:74]
All options in the 2009 Stock Plan have been awarded.

[0000038725-16-000276:notes:75]
The Company currently issues new shares from its common stock balance to satisfy option exercises and the settlement of stock awards and stock unit awards made under the 2009 Stock Plan and/or the 2012 Stock Plan.

[0000038725-16-000276:notes:76]
The total share-based compensation expense recognized in 2015, 2014, and 2013 was $5.6 million, $7.5 million, and $4.9 million, respectively.

[0000038725-16-000276:notes:77]
Stock Options:

[0000038725-16-000276:notes:78]
Under the above plans, the exercise price of each option equals the market price of the Company’s common stock on the date of grant, and the options expire 10 years after the date of the grant.  Options granted to employees vest at 25 percent a year and become fully vested and fully exercisable after 4 years (vesting is accelerated upon retirement, death, or disability).  Subject to the terms of the plans, in general, the aggregate option exercise price and any applicable tax withholdings may be satisfied in cash or its equivalent, by the plan participant’s delivery of shares of the Company’s common stock having a fair market value at the time of exercise equal to the aggregate option exercise price and/or the applicable tax withholdings or by having shares otherwise subject to the award withheld by the Company or via cashless exercise through a broker-dealer.

[0000038725-16-000276:notes:79]
The fair value of each option award is estimated on the date of grant using the Black-Scholes option valuation model with a single approach and amortized using a straight-line attribution method over the option’s vesting period.  Options granted to retirement eligible employees are immediately expensed.  The Company uses historical data to estimate the expected volatility of its stock, the weighted average expected life, the period of time options granted are expected to be outstanding, and its dividend yield.  The risk-free rates for periods within the contractual life of the option are based on the U.S. Treasury yield curve in effect at the time of the grant.

[0000038725-16-000276:notes:80]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during 2015, 2014, and 2013, are as follows:

[0000038725-16-000276:notes:81]
|  |  | 2015 |  | 2014 |  | 2013 |
| Risk-free interest rate |  | 1.59 | % |  | 1.68 | % |  | 1.03 | % |
| Dividend yield |  | 0.95 | % |  | 0.70 | % |  | 0.89 | % |
| Volatility factor |  | 0.379 |  |  | 0.387 |  |  | 0.394 |  |
| Expected term |  | 5.5 years |  |  | 5.6 years |  |  | 6.0 years |  |
| Forfeiture rate |  | 3.67 | % |  | 3.81 | % |  | 4.52 | % |

[0000038725-16-000276:notes:82]
A summary of the Company’s outstanding stock option activity and related information is as follows:

[0000038725-16-000276:notes:83]
| (Shares in thousands) |  |  |  |  |  |  |  |  |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | AggregateIntrinsic Value (000’s) |
| Outstanding at beginning of 2013 |  | 2,184 |  |  | $ | 16.69 |  |  |  |  |  |
| Granted |  | 176 |  |  | 32.53 |  |  |  |  |  |
| Exercised |  | (880 | ) |  | 15.98 |  |  |  |  |  |
| Forfeited |  | (4 | ) |  | 14.37 |  |  |  |  |  |
| Expired |  | — |  |  | — |  |  |  |  |  |
| Outstanding at beginning of 2014 |  | 1,476 |  |  | $ | 19.01 |  |  |  |  |  |
| Granted |  | 115 |  |  | 42.24 |  |  |  |  |  |
| Exercised |  | (171 | ) |  | 17.03 |  |  |  |  |  |
| Forfeited |  | (6 | ) |  | 26.28 |  |  |  |  |  |
| Expired |  | (17 | ) |  | 16.34 |  |  |  |  |  |
| Outstanding at beginning of 2015 |  | 1,397 |  |  | $ | 21.17 |  |  |  |  |  |
| Granted |  | 185 |  |  | 36.67 |  |  |  |  |  |
| Exercised |  | (108 | ) |  | 18.99 |  |  |  |  |  |
| Forfeited |  | (2 | ) |  | 34.93 |  |  |  |  |  |
| Expired |  | — |  |  | — |  |  |  |  |  |
| Outstanding at end of period |  | 1,472 |  |  | $ | 23.26 |  |  | 4.79 years |  | $ | 9,981 |  |
| Expected to vest after applying forfeiture rate |  | 1,456 |  |  | $ | 23.11 |  |  | 4.74 years |  | $ | 9,980 |  |
| Vested and exercisable at end of period |  | 1,106 |  |  | $ | 19.04 |  |  | 3.61 years |  | $ | 9,871 |  |

[0000038725-16-000276:notes:84]
|  |  | 2015 |  | 2014 |  | 2013 |
| Weighted average grant-date fair value of options |  | $ | 12.34 |  |  | $ | 15.09 |  |  | $ | 11.47 |  |

[0000038725-16-000276:notes:85]
| (In millions) |  | 2015 |  | 2014 |  | 2013 |
| Intrinsic value of options exercised |  | $ | 1.7 |  |  | $ | 3.8 |  |  | $ | 16.6 |  |
| Cash received from the exercise of options |  | 2.0 |  |  | 2.9 |  |  | 14.1 |  |
| Fair value of shares vested |  | 1.4 |  |  | 2.8 |  |  | 2.1 |  |
| Tax benefit of options exercised |  | 0.7 |  |  | 1.5 |  |  | 6.5 |  |

[0000038725-16-000276:notes:86]
There were no share-based liabilities paid during the 2015 and 2014 fiscal years.

[0000038725-16-000276:notes:87]
A summary of the Company’s non-vested stock option activity and related information is as follows:

[0000038725-16-000276:notes:88]
| (Shares in thousands) |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of 2014 |  | 534 |  |  | $ | 25.30 |  |
| Granted |  | 115 |  |  | 42.24 |  |
| Vested |  | (330 | ) |  | 23.98 |  |
| Forfeited |  | (6 | ) |  | 26.28 |  |
| Non-vested at beginning of 2015 |  | 313 |  |  | $ | 32.91 |  |
| Granted |  | 185 |  |  | 36.67 |  |
| Vested |  | (130 | ) |  | 29.49 |  |
| Forfeited |  | (2 | ) |  | 34.93 |  |
| Non-vested at end of period |  | 366 |  |  | $ | 36.02 |  |

[0000038725-16-000276:notes:89]
As of January 2, 2016, there was $1.6 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.44 years.

[0000038725-16-000276:notes:90]
Stock/Stock Unit Awards:

[0000038725-16-000276:notes:91]
Under the 2009 Stock Plan, non-employee directors and employees may be granted stock awards.  Under the 2012 Stock Plan, non-employee directors and employees may be granted stock awards and stock units.

[0000038725-16-000276:notes:92]
Stock awards to non-employee directors are generally fully vested when made.  Stock/stock unit awards to employees cliff vest over 3 or 4 years (subject to accelerated vesting of a pro rata portion in the case of retirement, death or disability) and may be contingent on the attainment of certain performance goals.  Dividends are paid to the recipient prior to vesting, except that dividends on performance-based stock awards under the 2012 Stock Plan will be paid only to the extent the performance goals are met.  Stock/stock unit awards granted to retirement eligible employees are expensed over the vesting period.

[0000038725-16-000276:notes:93]
A summary of the Company’s restricted stock/stock unit award activity and related information is as follows:

[0000038725-16-000276:notes:94]
| (Shares in thousands) |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of 2014 |  | 551 |  |  | $ | 24.75 |  |
| Awarded |  | 208 |  |  | 42.39 |  |
| Vested |  | (132 | ) |  | 17.08 |  |
| Forfeited |  | (73 | ) |  | 28.49 |  |
| Non-vested at beginning of 2015 |  | 554 |  |  | $ | 32.72 |  |
| Awarded |  | 134 |  |  | 36.27 |  |
| Vested |  | (169 | ) |  | 30.39 |  |
| Forfeited |  | (9 | ) |  | 32.31 |  |
| Non-vested at end of period |  | 510 |  |  | $ | 34.43 |  |

[0000038725-16-000276:notes:95]
As of January 2, 2016, there was $7.7 million of total unrecognized compensation cost related to non-vested stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.25 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000038725-16-000276:notes:96]
Basic and diluted earnings per share are computed and disclosed in accordance with FASB ASC Topic 260, Earnings Per Share.  The Company utilizes the two-class method to compute earnings available to common shareholders.  Under the two-class method, earnings are adjusted by accretion amounts to redeemable noncontrolling interests recorded at redemption value.  The adjustments represent dividend distributions, in substance, to the noncontrolling interest holder as the holders have contractual rights to receive an amount upon redemption other than the fair value of applicable shares.  As a result, earnings are adjusted to reflect this in substance distribution that is different from other common shareholders.  In addition, the Company allocates net earnings to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company's participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.  Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.


## us-gaap:EarningsPerShareTextBlock

[0000038725-16-000276:notes:97]
EARNINGS PER SHARE

[0000038725-16-000276:notes:98]
The Company calculates basic and diluted earnings per common share using the two-class method.  Under the two-class method, net earnings are allocated to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company's participating securities consist of share-based payment awards that contain a nonforfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.

[0000038725-16-000276:notes:99]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-16-000276:notes:100]
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-16-000276:notes:101]
| (In millions, except per share amounts) |  | 2015 |  | 2014 |  | 2013 |
| Numerator: |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. |  | $ | 72.9 |  |  | $ | 69.8 |  |  | $ | 82.0 |  |
| Less: Undistributed earnings allocated to participating securities |  | 0.7 |  |  | 0.7 |  |  | 1.0 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest |  | 0.8 |  |  | 0.9 |  |  | 0.2 |  |
|  |  | $ | 71.4 |  |  | $ | 68.2 |  |  | $ | 80.8 |  |
| Denominator: |  |  |  |  |  |  |
| Basic |  |  |  |  |  |  |
| Weighted average common shares |  | 47.1 |  |  | 47.7 |  |  | 47.5 |  |
| Diluted |  |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |
| Non-participating employee incentive stock options and performance awards |  | 0.5 |  |  | 0.5 |  |  | 0.6 |  |
| Adjusted weighted average common shares |  | 47.6 |  |  | 48.2 |  |  | 48.1 |  |
| Basic earnings per share |  | $ | 1.52 |  |  | $ | 1.43 |  |  | $ | 1.70 |  |
| Diluted earnings per share |  | $ | 1.50 |  |  | $ | 1.41 |  |  | $ | 1.68 |  |
| Anti-dilutive stock options |  | 0.3 |  |  | 0.1 |  |  | 0.1 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-16-000276:notes:102]
As of January 2, 2016 and January 3, 2015, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-16-000276:notes:103]
| (In millions) |  | January 2, 2016 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 3.9 |  |  | $ | 3.9 |  |  | $ | — |  |  | $ | — |  |  |
|  |  | January 3, 2015 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 5.4 |  |  | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-16-000276:notes:104]
FAIR VALUE MEASUREMENTS

[0000038725-16-000276:notes:105]
FASB ASC Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy.  Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date.  The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value.  The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-16-000276:notes:106]
Level 1 – Quoted prices for identical assets and liabilities in active markets;

[0000038725-16-000276:notes:107]
Level 2 – Quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets; and

[0000038725-16-000276:notes:108]
Level 3 – Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable.

[0000038725-16-000276:notes:109]
The Company's Level 1 assets consist of cash equivalents which are generally comprised of foreign bank guaranteed certificates of deposit.

[0000038725-16-000276:notes:110]
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3.

[0000038725-16-000276:notes:111]
As of January 2, 2016 and January 3, 2015, the Company had $1.6 million and $2.4 million of assets held for sale, respectively, recorded at carrying value in the Water Systems segment relating to an idle facility in Brazil.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000038725-16-000276:notes:112]
All assets and liabilities of foreign subsidiaries in functional currency other than the U.S. dollar are translated at year end exchange rates.  All revenue and expense accounts are translated at average rates in effect during the respective period.  Adjustments for translating longer term foreign currency assets and liabilities in U.S. dollars are included as a component of other comprehensive income.  Transaction gains and losses that arise from shorter term exchange rate fluctuations are included in the “Foreign exchange expense" line within the Company's consolidated statements of income, as incurred.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-16-000276:notes:113]
GOODWILL AND OTHER INTANGIBLE ASSETS

[0000038725-16-000276:notes:114]
Amortization expense related to intangible assets for fiscal years 2015, 2014, and 2013, was $8.6 million, $9.1 million, and $8.0 million, respectively.

[0000038725-16-000276:notes:115]
Amortization expense for each of the five succeeding years is projected as follows:

[0000038725-16-000276:notes:116]
| (In millions) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |
|  |  | $ | 8.4 |  |  | $ | 8.3 |  |  | $ | 8.3 |  |  | $ | 8.2 |  |  | $ | 8.1 |  |

[0000038725-16-000276:notes:117]
The Company uses the acquisition method of accounting for business combinations.  Annual goodwill impairment testing and trade name impairment testing is performed during the fourth quarter of each year based on balances as of the last Saturday of the Company's eighth fiscal period, unless events or circumstances indicate earlier impairment testing is required.  No impairment loss was recognized for 2015, 2014, or 2013.

[0000038725-16-000276:notes:118]
The change in the carrying amount of goodwill by reporting segment for 2015 and 2014, is as follows:

[0000038725-16-000276:notes:119]
| (In millions) |  | 2015 |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of January 3, 2015 |  | $ | 145.3 |  |  | $ | 63.5 |  |  | $ | 208.8 |  |
| Acquisitions |  | — |  |  | — |  |  | — |  |
| Adjustments to prior year acquisitions |  | (0.9 | ) |  | (0.2 | ) |  | (1.1 | ) |
| Foreign currency translation |  | (7.6 | ) |  | (0.3 | ) |  | (7.9 | ) |
| Balance as of January 2, 2016 |  | $ | 136.8 |  |  | $ | 63.0 |  |  | $ | 199.8 |  |

[0000038725-16-000276:notes:120]
| (In millions) |  | 2014 |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of December 28, 2013 |  | $ | 144.1 |  |  | $ | 63.1 |  |  | $ | 207.2 |  |
| Acquisitions |  | 6.7 |  |  | 0.6 |  |  | 7.3 |  |
| Adjustments to prior year acquisitions |  | — |  |  | — |  |  | — |  |
| Foreign currency translation |  | (5.5 | ) |  | (0.2 | ) |  | (5.7 | ) |
| Balance as of January 3, 2015 |  | $ | 145.3 |  |  | $ | 63.5 |  |  | $ | 208.8 |  |

[0000038725-16-000276:notes:121]
The 2014 acquired goodwill in the Water Systems segment primarily related to the Company's acquisition of Bombas Leao.  The remaining acquired goodwill in both the Water Systems and Fueling Systems segments related to two immaterial controlling interest acquisitions made in India.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000038725-16-000276:notes:122]
The Company tests goodwill for impairment on an annual basis during the fourth quarter or more frequently as warranted by triggering events that indicate potential impairment.  Goodwill is tested at the reporting unit level, which the company has determined to be the North America Water Systems, International Water, and Fueling Systems units.  In compliance with FASB ASC Topic 350, Intangibles - Goodwill and Other, the Company has evaluated the aggregation criteria and determined that the components within the North America Water Systems and International Water reporting units can be aggregated in 2015.

[0000038725-16-000276:notes:123]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the income and market valuation approaches.  The income approach estimates fair value based upon future revenue, expenses, and cash flows discounted to present value.  The market valuation approach estimates fair value using market multipliers of various financial measures compared to a set of comparable public companies.  The fair value calculated for each reporting unit is considered a Level 3 measurement within the fair value hierarchy.

[0000038725-16-000276:notes:124]
An indication of impairment exists if the carrying value of the reporting unit is higher than its fair value, as determined by the above approach.  The second step of testing as outlined in FASB ASC Topic 350 must be performed to measure the amount of impairment loss.  The amount of impairment is determined by comparing the implied fair value of the reporting unit's goodwill to its carrying value in the same manner as if the reporting units were being acquired in a business combination.  The Company would allocate the fair value to all of the reporting unit's assets and liabilities, including any unrecognized intangible assets, in a hypothetical analysis that would calculate the implied fair value of goodwill.  The Company would record an impairment charge for the difference between the implied fair value of goodwill and the recorded goodwill.

[0000038725-16-000276:notes:125]
The Company also tests indefinite lived intangible assets, primarily trade names, for impairment on an annual basis during the fourth quarter of each year, or more frequently as warranted by triggering events that indicate potential impairment.  In assessing the recoverability of the trade names, the Company determines the fair value using an income approach.  The income approach estimates fair value based upon future revenue and estimated royalty rates.  The fair value calculated for indefinite lived intangible assets is considered a Level 3 measurement within the fair value hierarchy.  An indication of impairment exists if the carrying value of the trade names is higher than the fair value.  The Company would record an impairment charge for the difference.

[0000038725-16-000276:notes:126]
Amortization is recorded and calculated for other definite lived intangible assets on a basis that reflects cash flows over the estimated useful lives.  The weighted average number of years over which each intangible class is amortized is 17 years for patents, 6 years for supply agreements, 15 years for technology, 13 to 20 years for customer relationships, 5 years for software, and 8 years for all others.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-16-000276:notes:127]
INCOME TAXES

[0000038725-16-000276:notes:128]
Income before income taxes consisted of the following:

[0000038725-16-000276:notes:129]
| (In millions) |  | 2015 |  | 2014 |  | 2013 |
| Domestic |  | $ | 23.6 |  |  | $ | 42.2 |  |  | $ | 53.5 |  |
| Foreign |  | 62.7 |  |  | 47.5 |  |  | 58.0 |  |
|  |  | $ | 86.3 |  |  | $ | 89.7 |  |  | $ | 111.5 |  |

[0000038725-16-000276:notes:130]
The income tax provision/(benefit) from continuing operations consisted of the following:

[0000038725-16-000276:notes:131]
| (In millions) |  | 2015 |  | 2014 |  | 2013 |
| Current: |  |  |  |  |  |  |
| Federal |  | $ | 1.2 |  |  | $ | 7.4 |  |  | $ | 10.8 |  |
| Foreign |  | 17.4 |  |  | 12.2 |  |  | 14.3 |  |
| State |  | 0.8 |  |  | 1.7 |  |  | 2.1 |  |
| Total current |  | 19.4 |  |  | 21.3 |  |  | 27.2 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Federal |  | (1.8 | ) |  | 3.3 |  |  | 4.3 |  |
| Foreign |  | (4.0 | ) |  | (3.8 | ) |  | (1.3 | ) |
| State |  | (1.0 | ) |  | (1.9 | ) |  | (1.3 | ) |
| Total deferred |  | $ | (6.8 | ) |  | $ | (2.4 | ) |  | $ | 1.7 |  |
|  |  | $ | 12.6 |  |  | $ | 18.9 |  |  | $ | 28.9 |  |

[0000038725-16-000276:notes:132]
A reconciliation of the tax provision for continuing operations at the U.S. statutory rate to the effective income tax expense rate as reported is as follows:

[0000038725-16-000276:notes:133]
|  |  | 2015 |  | 2014 |  | 2013 |
| U.S. Federal statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State income taxes, net of federal benefit |  | (0.3 | ) |  | 1.0 |  |  | 1.2 |  |
| Foreign operations |  | (13.1 | ) |  | (9.2 | ) |  | (6.2 | ) |
| R&D tax credits |  | (1.0 | ) |  | (0.6 | ) |  | (1.1 | ) |
| Uncertain tax position adjustments |  | (1.5 | ) |  | (1.6 | ) |  | (1.9 | ) |
| Deferred tax adjustments - restructuring and rate adjustments |  | 1.1 |  |  | (3.9 | ) |  | — |  |
| Valuation allowance on state and foreign deferred tax |  | 4.1 |  |  | (0.3 | ) |  | (0.8 | ) |
| Purchase of noncontrolling interest |  | (9.4 | ) |  | — |  |  | — |  |
| Other items |  | (0.3 | ) |  | 0.6 |  |  | (0.3 | ) |
| Effective tax rate |  | 14.6 | % |  | 21.0 | % |  | 25.9 | % |

[0000038725-16-000276:notes:134]
Significant components of the Company's deferred tax assets and liabilities were as follows:

[0000038725-16-000276:notes:135]
| (In millions) |  | 2015 |  | 2014 |
| Deferred tax assets: |  |  |  |  |
| Accrued expenses and reserves |  | $ | 12.8 |  |  | $ | 12.2 |  |
| Compensation and employee benefits |  | 25.7 |  |  | 32.6 |  |
| Other items |  | 9.6 |  |  | 7.3 |  |
| Valuation allowance on state and foreign deferred tax |  | (7.2 | ) |  | (3.9 | ) |
| Total deferred tax assets |  | 40.9 |  |  | 48.2 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Accelerated depreciation on fixed assets |  | 14.0 |  |  | 14.0 |  |
| Amortization of intangibles |  | 56.6 |  |  | 62.1 |  |
| Other items |  | 0.2 |  |  | 6.0 |  |
| Total deferred tax liabilities |  | 70.8 |  |  | 82.1 |  |
| Net deferred tax liabilities |  | $ | (29.9 | ) |  | $ | (33.9 | ) |

[0000038725-16-000276:notes:136]
The effective tax rate continues to be lower than the statutory rate primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate as well as recognition of foreign tax credits.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations as well as cash on hand and available credit.

[0000038725-16-000276:notes:137]
The Company settled the liability for the noncontrolling interest of a subsidiary during the first quarter.  This transaction created additional accretive benefits for the Company from the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer. The Company also realized a gain on the mandatorily redeemable noncontrolling interest liability.

[0000038725-16-000276:notes:138]
In November 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2015-17, Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes. This ASU requires an entity to classify deferred tax assets and liabilities as noncurrent within a classified balance sheet. The ASU is effective for interim and annual periods beginning after December 15, 2016, and early adoption is permitted. Entities can elect either prospective or retrospective adoption of the standard. The Company adopted the new standard on a prospective basis as of the fiscal year-ended January 2, 2016. Accordingly, classification of prior period deferred tax amounts were not retrospectively adjusted.

[0000038725-16-000276:notes:139]
The Company assesses the available positive and negative evidence to estimate whether sufficient future taxable income will be generated to permit use of the existing deferred tax assets. A significant piece of objective negative evidence evaluated was the cumulative loss for certain state and foreign income tax purposes incurred over the three-year period ended January 2, 2016. Such objective evidence limits the ability to consider other subjective evidence, such as our projections for future growth.  On the basis of this evaluation, as of January 2, 2016, a valuation allowance of $7.2 million has been recorded to recognize only the portion of the deferred tax asset that is more likely than not to be realized.

[0000038725-16-000276:notes:140]
The Company has foreign income tax net operating loss ("NOL") carryforwards of $5.2 million and state income tax NOL and credit carryforwards of $5.1 million, which will expire on various dates as follows:

[0000038725-16-000276:notes:141]
| (In millions) |  |
| 2016-2019 | $ | 0.9 |  |
| 2020-2024 | 2.2 |  |
| 2025-2029 | 0.2 |  |
| 2030-2034 | 2.0 |  |
| 2035-2039 | 0.5 |  |
| Unlimited | 4.5 |  |
|  | $ | 10.3 |  |

[0000038725-16-000276:notes:142]
The Company believes that it is more likely than not that the benefit from certain foreign NOL carryforwards as well as certain state NOL and state credit carryforwards will not be realized.  In recognition of this risk, we have provided a valuation allowance of $2.4 million on the deferred tax assets related to these foreign NOL carryforwards and a valuation allowance of $4.8 million on the deferred tax assets related to these state NOL and credit carryforwards.

[0000038725-16-000276:notes:143]
The Company considers undistributed earnings from its foreign subsidiaries to be indefinitely reinvested with respect to the U.S. It is the Company’s policy to reinvest earnings as needed for operations, capital and acquisition spending. The Company does not provide for deferred taxes on the excess of the financial reporting over the tax basis in our investments in foreign subsidiaries that are essentially permanent in duration. That excess totaled approximately $374.8 million as of January 2, 2016.  The determination of the additional deferred taxes that have not been provided is not practicable.

[0000038725-16-000276:notes:144]
As of the beginning of fiscal year 2015, the Company had gross unrecognized tax benefits of $4.4 million, excluding accrued interest and penalties.  The unrecognized tax benefits decreased $2.0 million for federal tax liabilities and remained the same for state income tax liabilities based on evaluations made during 2015 primarily due to statute expirations and offset by uncertain tax positions identified in the current year.  The Company had gross unrecognized tax benefits, excluding accrued interest and penalties, of $2.4 million as of January 2, 2016.

[0000038725-16-000276:notes:145]
A reconciliation of the beginning and ending amount of gross unrecognized tax benefits for 2015, 2014, and 2013 (excluding interest and penalties) is as follows:

[0000038725-16-000276:notes:146]
| (In millions) |  | 2015 |  | 2014 |  | 2013 |
| Beginning balance |  | $ | 4.4 |  |  | $ | 5.1 |  |  | $ | 6.9 |  |
| Additions for tax positions of the current year |  | 0.2 |  |  | 0.1 |  |  | — |  |
| Additions for tax positions of prior years |  | 0.2 |  |  | 1.7 |  |  | 1.7 |  |
| Reductions for tax positions of prior years |  | (0.8 | ) |  | (1.1 | ) |  | (3.5 | ) |
| Statute expirations |  | (1.6 | ) |  | (1.4 | ) |  | — |  |
| Settlements |  | — |  |  | — |  |  | — |  |
| Ending balance |  | $ | 2.4 |  |  | $ | 4.4 |  |  | $ | 5.1 |  |

[0000038725-16-000276:notes:147]
If recognized, each annual effective tax rate would be affected by the net unrecognized tax benefits of $2.3 million, $4.3 million, and $5.0 million as of January 2, 2016, January 3, 2015, and December 28, 2013, respectively.

[0000038725-16-000276:notes:148]
The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.  In 2015, interest and penalties decreased $0.2 million, for prior year tax positions.  The Company has accrued interest and penalties as of January 2, 2016, January 3, 2015, and December 28, 2013 of approximately $2.3 million, $2.5 million, and $0.2 million, respectively.

[0000038725-16-000276:notes:149]
Of the unrecognized tax benefits at January 2, 2016, $2.1 million is related to acquisitions for which indemnification was provided for in the respective purchase agreement.  The stock purchase agreements related to these acquisitions provide the Company rights to recover tax liabilities related to pre-acquisition tax years from the sellers.

[0000038725-16-000276:notes:150]
The Company is subject to taxation in the United States and various state and foreign jurisdictions.  With few exceptions, as of January 2, 2016, the Company is no longer subject to U.S. federal income tax examinations by authorities for years before 2012 and is no longer subject to foreign or state income tax examinations by tax authorities for years before 2010.

[0000038725-16-000276:notes:151]
It is reasonably possible that the amounts of unrecognized tax benefits could change in the next twelve months as a result of an audit or due to the expiration of a statute of limitation.  Based on the current audits in process and pending statute expirations, the payment of taxes as a result could be up to $0.7 million.


## us-gaap:IncomeTaxPolicyTextBlock

[0000038725-16-000276:notes:152]
Income taxes are accounted for in accordance with FASB ASC Topic 740, Income Taxes.  Under this guidance, deferred tax assets and liabilities are determined based on the difference between the financial statement and tax basis of assets and liabilities and net operating loss and credit carry forwards using enacted tax rates in effect for the year in which the differences are expected to reverse.  Valuation allowances are established when necessary to reduce deferred tax assets to the amounts expected to be realized.  The Company records a liability for uncertain tax positions by establishing a recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return.


## us-gaap:InventoryPolicyTextBlock

[0000038725-16-000276:notes:153]
Inventories are stated at the lower of cost or market.  The majority of the cost of domestic and foreign inventories is determined using the FIFO method with a portion of inventory costs determined using the average cost method.  The Company reviews its inventories for excess or obsolete products or components based on an analysis of historical usage and management's evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-16-000276:notes:154]
ACCOUNTING PRONOUNCEMENTS

[0000038725-16-000276:notes:155]
Adoption of New Accounting Standards

[0000038725-16-000276:notes:156]
In November 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2015-17, Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes.  This ASU requires an entity to classify deferred tax assets and liabilities as noncurrent within a classified balance sheet.  The ASU is effective for interim and annual periods beginning after December 15, 2016, and early adoption is permitted.  Entities can elect either prospective or retrospective adoption of the standard.  The Company early adopted the new standard on a prospective basis as of the fiscal year-ended January 2, 2016.  Accordingly, classification of prior period deferred tax amounts were not retrospectively adjusted.

[0000038725-16-000276:notes:157]
In February 2015, the FASB issued Accounting Standards Update ASU 2015-02, Consolidation (Topic 810), Amendments to the Consolidation Analysis. The amendments affect both the variable interest entity and voting interest entity consolidation models. The need to assess an entity under a different consolidation model may change previous consolidation conclusions. The standard is effective for both interim and annual reporting periods beginning after December 15, 2015 and early adoption is permitted. The Company has adopted this standard with no impact on the Company's consolidated financial position, results of operations, cash flows, or related disclosures.

[0000038725-16-000276:notes:158]
Accounting Standards Issued But Not Yet Adopted

[0000038725-16-000276:notes:159]
In September 2015, the FASB issued ASU 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments. The ASU will require an acquirer to recognize provisional amounts that are identified during the measurement period in the reporting period in which the adjustment amounts are determined rather than restating prior periods. The ASU will be effective on a prospective basis for interim and annual period beginning after December 15, 2015. The Company will adopt this new standard beginning with the 2016 fiscal year, and does not expect the adoption of this standard to have a material impact on the Company's consolidated financial position, results of operations, cash flows, or related disclosures.

[0000038725-16-000276:notes:160]
In July 2015, the FASB issued ASU 2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory. The ASU will change the measurement principle for inventory from the lower of cost or market to the lower of cost and net realizable value. Net realizable value is defined as the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. ASU 2015-11 eliminates the guidance that entities consider replacement cost or net realizable value less an approximately normal profit margin in the subsequent measurement of inventory when cost is determined on a first-in, first-out or average cost basis. The ASU will be effective on a prospective basis for interim and annual periods beginning after December 15, 2016, and early adoption is permitted. The Company plans to early adopt this standard beginning with the 2016 fiscal year, but does not expect the adoption of this standard to have a material impact on the Company's consolidated financial position, results of operations, or related disclosures.

[0000038725-16-000276:notes:161]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other Internal-Use Software (Subtopic 350-40): Customer's Accounting for Fees Paid in a Cloud Computing Agreement. The ASU will require an entity's management to assess, for each annual and interim period, whether a cloud computing arrangement includes a software license. All software licenses within the scope of Subtopic 350-40 will be accounted for consistent with other licenses of intangible assets. If the arrangement does not include a software license, the arrangement should be accounted for as a service contract. The ASU will be effective for interim and annual periods beginning after December 15, 2015 and early adoption is permitted. Entities will have the choice of prospective or retrospective adoption of the standard. The Company does not expect the adoption of this standard beginning in the 2016 fiscal year to have a material impact on the Company's consolidated financial position, results of operations, cash flows, or related disclosures.

[0000038725-16-000276:notes:162]
In April 2015, the FASB issued ASU 2015-04, Compensation - Retirement Benefits (Topic 715): Practical Expedient for the Measurement Date of an Employer's Defined Benefit Obligation and Plan Assets, which allows an entity a practical expedient to measure defined benefit plan assets and obligations using the month end date that is closest to the entity's fiscal year end and apply that practical expedient consistently from year to year. The practical expedient should be applied consistently to all plans if the entity has more than one plan. The ASU will be effective on a prospective basis for interim and annual periods beginning after December 15, 2015 and early adoption is permitted. The Company does not currently plan on electing the practical expedient for the 2016 fiscal year.

[0000038725-16-000276:notes:163]
In April 2015, the FASB issued ASU 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs, which requires debt issuance costs to be presented in the balance sheet as a direct deduction from the associated debt liability. The standard will not change the amortization of debt issuance costs, which will continue to follow the existing accounting guidance. In August 2015, the FASB issued ASU 2015-15, Interest-Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements, which indicates the SEC staff would not object to an entity deferring and presenting debt issuance costs related to line-of-credit arrangements as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. These ASU's will be effective on a retrospective basis for interim and annual periods beginning after December 15, 2015 and early adoption is permitted.  These new standards will be adopted by the Company beginning with the 2016 fiscal year with the required change in accounting principle disclosures. The Company does not expect the adoption of these standards to have a material impact on the Company's consolidated financial position, results of operations, cash flows, or related disclosures.

[0000038725-16-000276:notes:164]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance. In August 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date. The amendment in this update defers the effective date of ASU 2014-09 for all entities by one year to annual periods beginning after December 15, 2017. Early adoption is permitted as of the original effective date, interim and annual reporting periods after December 15, 2016. Entities have the option of using either a full retrospective or a modified retrospective approach to adopt ASU 2014-09. The Company is still in the process of analyzing the effect of this new standard, including the transition method, to determine the impact on the Company's consolidated financial position, results of operations, cash flows, or related disclosures.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000038725-16-000276:notes:165]
OTHER ASSETS

[0000038725-16-000276:notes:166]
The Company has equity interests in various companies for strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s consolidated balance sheet.  The carrying amount of the investments is adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income, net" line of the Company's consolidated statements of income, were immaterial for the years ended January 2, 2016, January 3, 2015, and December 28, 2013.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-16-000276:notes:167]
EMPLOYEE BENEFIT PLANS

[0000038725-16-000276:notes:168]
Defined Benefit Plans - As of January 2, 2016, the Company maintained two domestic pension plans and three German pension plans.  The Company used a January 2, 2016 measurement date for these plans.  One of the Company’s domestic pension plans covers two management employees (one active employee and one former employee), while the other domestic plan covers all other eligible employees.  The two domestic and three German plans collectively comprise the ‘Pension Benefits’ disclosure caption.

[0000038725-16-000276:notes:169]
Other Benefits - The Company also maintains a postretirement benefit plan to provide health and life insurance benefits to employees hired prior to 1992.  The Company effectively capped its cost for those benefits through plan amendments made in 1992, freezing Company contributions for insurance benefits at 1991 levels for current and future beneficiaries with actuarially reduced benefits for employees who retire before age 65.  The disclosures surrounding this plan are reflected in the "Other Benefits" caption.

[0000038725-16-000276:notes:170]
The following table sets forth other changes in plan assets and benefit obligation recognized in other comprehensive income for 2015 and 2014:

[0000038725-16-000276:notes:171]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net actuarial (gain)/loss |  | $ | (0.3 | ) |  | $ | 29.1 |  |  | $ | (1.0 | ) |  | $ | 1.3 |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net actuarial gain |  | (2.8 | ) |  | (2.2 | ) |  | (0.2 | ) |  | (0.1 | ) |
| Prior service credit |  | — |  |  | — |  |  | (0.4 | ) |  | (0.4 | ) |
| Settlement recognition |  | (2.1 | ) |  | (1.4 | ) |  | — |  |  | — |  |
| Deferred tax asset/(liability) |  | 1.9 |  |  | (8.3 | ) |  | 0.6 |  |  | (0.3 | ) |
| Foreign currency exchange |  | (0.3 | ) |  | (0.3 | ) |  | — |  |  | — |  |
| Total recognized in other comprehensive income |  | $ | (3.6 | ) |  | $ | 16.9 |  |  | $ | (1.0 | ) |  | $ | 0.5 |  |

[0000038725-16-000276:notes:172]
Weighted-average assumptions used to determine domestic benefit obligations:

[0000038725-16-000276:notes:173]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Discount rate |  | 4.37 | % |  | 3.95 | % |  | 4.09 | % |  | 3.75 | % |
| Rate of increase in future compensation* |  | — | % |  | — | % |  | 3.00 - 8.00%(Graded) |  |  | 3.00 - 8.00%(Graded) |  |

[0000038725-16-000276:notes:174]
*No rate of increases in future compensation used within assumptions for 2015 and 2014, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation.

[0000038725-16-000276:notes:175]
Assumptions used to determine domestic periodic benefit cost:

[0000038725-16-000276:notes:176]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Discount rate |  | 4.00 | % |  | 4.75 | % |  | 4.00 | % |  | 3.75 | % |  | 4.50 | % |  | 3.50 | % |
| Rate of increase in future compensation* |  | — | % |  | — | % |  | — | % |  | 3.00 - 8.00%(Graded) |  |  | 3.00 - 12.00%(Graded) |  |  | 3.00 - 12.00%(Graded) |  |
| Expected long-term rate of return on plan assets |  | 7.00 | % |  | 7.70 | % |  | 8.00 | % |  | — | % |  | — | % |  | — | % |

[0000038725-16-000276:notes:177]
For the fiscal year ended January 2, 2016, the Company used the RP-2014 aggregate table adjusted to back out estimated mortality improvements from 2006 to the measurement date using Scale MP-2014, and then projected forward using Scale MP-2015 released by the Society of Actuaries during 2015 to estimate future mortality rates based upon current data.   For the fiscal year ended January 3, 2015, the Company adopted the RP-2014 aggregate table projected using Scale MP-2014 released by the Society of Actuaries during 2014.

[0000038725-16-000276:notes:178]
The accumulated benefit obligation for the Company’s tax qualified plan and German benefit pension plans was $175.2 million and $192.8 million for the years ended 2015 and 2014.

[0000038725-16-000276:notes:179]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for 2015, 2014, and 2013:

[0000038725-16-000276:notes:180]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Service cost | $ | 1.4 |  |  | $ | 1.2 |  |  | $ | 1.8 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |
| Interest cost | 7.5 |  |  | 8.2 |  |  | 7.6 |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Expected return on assets | (9.9 | ) |  | (10.6 | ) |  | (10.0 | ) |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Transition obligation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.4 |  |
| Settlement cost | — |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | 0.4 |  |  | 0.4 |  |  | 0.4 |  |
| Actuarial loss | 3.4 |  |  | 2.5 |  |  | 3.6 |  |  | 0.2 |  |  | 0.1 |  |  | — |  |
| Net periodic benefit cost | $ | 2.4 |  |  | $ | 1.3 |  |  | $ | 3.1 |  |  | $ | 1.2 |  |  | $ | 1.1 |  |  | $ | 1.4 |  |
| Settlement cost | 1.2 |  |  | 1.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 3.6 |  |  | $ | 2.3 |  |  | $ | 3.1 |  |  | $ | 1.2 |  |  | $ | 1.1 |  |  | $ | 1.4 |  |

[0000038725-16-000276:notes:181]
The estimated net actuarial (gain)/loss and prior service cost/(credit) that will be amortized from accumulated other comprehensive income into net periodic benefit cost during the 2016 fiscal year are $2.6 million and $0.0 million, respectively, for the pension plans and $0.1 million and $0.3 million, respectively, for all other benefits.

[0000038725-16-000276:notes:182]
The Company consults with a third party investment manager for the assets of the funded domestic defined benefit plan.  The plan assets are currently invested primarily in pooled funds, where each fund in turn is composed of mutual funds that have at least daily net asset valuations.  Thus, the Company’s funded domestic defined benefit plan assets are invested in a “fund of funds” approach.

[0000038725-16-000276:notes:183]
The Company’s Board has delegated oversight and guidance to an appointed Employee Benefits Committee.  The Committee has the tasks of reviewing plan performance and asset allocation, ensuring plan compliance with applicable laws, establishing plan policies, procedures, and controls, monitoring expenses, and other related activities.

[0000038725-16-000276:notes:184]
The plans’ investment policies and strategies focus on the ability to fund benefit obligations as they come due.  Considerations include the plan's current funded level, plan design, benefit payment assumptions, funding regulations, impact of potentially volatile business results on the Company’s ability to make certain levels of contributions, and interest rate and asset return volatility among other considerations.  The Company currently attempts to maintain plan funded status at approximately 80 percent or greater pursuant to the Pension Protection Act of 2007.  Given the plan’s current funded status, the Company’s cash on hand, cash historically generated from business operations, and cash available under committed credit facilities, the Company sees ample liquidity to achieve this goal.

[0000038725-16-000276:notes:185]
Risk management and continuous monitoring requirements are met through monthly investment portfolio reports, quarterly Employee Benefits Committee meetings, annual valuations, asset/liability studies, and the annual assumption process focusing primarily on the return on asset assumption and the discount rate assumption.  As of January 2, 2016, funds were invested in equity, fixed income, and other investments as follows:

[0000038725-16-000276:notes:186]
| Equity |  | Percentage |
| U.S. Large Cap |  | 15 | % |
| World Equity ex-U.S. |  | 13 | % |
| U.S. Small / Mid Cap |  | 6 | % |
| Subtotal |  | 34 | % |
| Fixed Income |  |  |
| U.S. Treasury and Government Agency Securities |  | 11 | % |
| Intermediate Duration Bond |  | 24 | % |
| Long Duration Bond |  | 19 | % |
| High Yield Fixed Income |  | 4 | % |
| Emerging Markets Debt |  | 4 | % |
| Subtotal |  | 62 | % |
| Other |  |  |
| Insurance Contracts |  | 3 | % |
| Cash Equivalents |  | 1 | % |
| Subtotal |  | 4 | % |
| Total |  | 100 | % |

[0000038725-16-000276:notes:187]
The Company does not see any particular concentration of risk within the plans, nor any plan assets that pose difficulties for fair value assessment.  The Company currently has no allocation to potentially illiquid or potentially difficult to value assets such as hedge funds, venture capital, private equity, and real estate.

[0000038725-16-000276:notes:188]
The Company works with actuaries and consultants in making its determination of the asset rate of return assumption and also the discount rate assumption.

[0000038725-16-000276:notes:189]
Asset class assumptions are set using a combination of empirical and forward-looking analysis for long-term rate of return on plan assets.  A variety of models are applied for filtering historical data and isolating the fundamental characteristics of asset classes.  These models provide empirical return estimates for each asset class, which are then reviewed and combined with a qualitative assessment of long-term relationships between asset classes before a return estimate is finalized.  This provides an additional means for correcting for the effect of unrealistic or unsustainable short-term valuations or trends, opting instead for return levels and behavior that are more likely to prevail over long periods.  With that, the Company has assumed an expected long-term rate of return on plan assets of 6.50 percent for the 2016 net periodic benefit cost, down from 7.00 percent in the prior year.  This decrease in the assumed long-term rate of return is due to a higher percentage of assets in fixed income securities.

[0000038725-16-000276:notes:190]
The Company uses the Aon Hewitt AA Above Median curve to determine the discount rate.  All cash flow obligations under the plan are matched to bonds in the Aon Hewitt universe of liquid, high-quality, non-callable / non-putable corporate bonds with outliers removed.  From that matching exercise, a discount rate is determined.

[0000038725-16-000276:notes:191]
At January 2, 2016, the Company changed the method used to calculate the service and interest components of net periodic benefit cost for pension and other postretirement benefits for plans that utilize a yield curve approach.  This change compared to the previous method will result in different service and interest components of net period benefit cost in future periods.  Historically, the Company estimated these service and interest cost components utilizing a single weighted-average discount rate derived from the yield curve used to measure the benefit obligation at the beginning of the period.  The Company elected to utilize a full yield curve approach in the estimation of these components by applying the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows.  The Company made this change to provide a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot yield curve rates.  This change does not affect the measurement of the Company's domestic pension and postretirement benefit obligations and is accounted for as a change in accounting estimate applied prospectively.  The change in the service and interest costs going forward is not expected to be material.

[0000038725-16-000276:notes:192]
The Company’s German pension plans are funded by insurance contract policies whereby the insurance company guarantees a fixed minimum return.  Due to tax legislation, individual pension benefits can only be financed using direct insurance policies up to certain maximums.  These maximum amounts in respect of each member are paid into such an arrangement on a yearly basis.

[0000038725-16-000276:notes:193]
The Company designated all equity and most domestic fixed income plan assets as Level 1, as they are mutual funds with prices that are readily available.  The U.S. Treasury securities and German plan assets are designated as Level 2 inputs.  The fair value of the German plan assets are measured by the reserve that is supervised by the German Federal Financial Supervisory Authority.  The U.S. Treasury securities are administered by the United States government.

[0000038725-16-000276:notes:194]
The fair values of the Company’s pension plan assets for 2015 and 2014 by asset category are as follows:

[0000038725-16-000276:notes:195]
| (In millions) |  | 2015 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| U.S. Large Cap |  | $ | 22.9 |  |  | $ | 22.9 |  |  | $ | — |  |  | $ | — |  |
| U.S. Small / Mid Cap |  | 8.1 |  |  | 8.1 |  |  | — |  |  | — |  |
| World Equity ex-U.S. |  | 19.6 |  |  | 19.6 |  |  | — |  |  | — |  |
| Fixed Income |  |  |  |  |  |  |  |  |
| U.S. Treasury and Government Agency Securities |  | 15.8 |  |  | — |  |  | 15.8 |  |  | — |  |
| Intermediate Duration Bond |  | 35.4 |  |  | 35.4 |  | — |  | — |  |  | — |  |
| Long Duration Bond |  | 28.0 |  |  | 28.0 |  |  | — |  |  | — |  |
| High Yield Fixed Income |  | 6.5 |  |  | 6.5 |  |  | — |  |  | — |  |
| Emerging Markets Debt |  | 5.4 |  |  | 5.4 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance Contracts |  | 4.9 |  |  | — |  |  | 4.9 |  |  | — |  |
| Cash and Equivalents |  | 0.8 |  |  | 0.8 |  |  | — |  |  | — |  |
| Total |  | $ | 147.4 |  |  | $ | 126.7 |  |  | $ | 20.7 |  |  | $ | — |  |

[0000038725-16-000276:notes:196]
| (In millions) |  | 2014 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| U.S. Large Cap |  | $ | 23.0 |  |  | $ | 23.0 |  |  | $ | — |  |  | $ | — |  |
| U.S. Small / Mid Cap |  | 8.9 |  |  | 8.9 |  |  | — |  |  | — |  |
| World Equity ex-U.S. |  | 19.9 |  |  | 19.9 |  |  | — |  |  | — |  |
| Fixed Income |  |  |  |  |  |  |  |  |
| U.S. Treasury and Government Agency Securities |  | 27.9 |  |  | — |  |  | 27.9 |  | — |  | — |  |
| Intermediate Duration Bond |  | — |  |  | — |  |  | — |  |  | — |  |
| Long Duration Bond |  | 62.7 |  |  | 62.7 |  |  | — |  |  | — |  |
| High Yield Fixed Income |  | 7.0 |  |  | 7.0 |  |  | — |  |  | — |  |
| Emerging Markets Debt |  | 5.4 |  |  | 5.4 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance Contracts |  | 5.2 |  |  | — |  |  | 5.2 |  |  | — |  |
| Cash and Equivalents |  | — |  |  | — |  |  | — |  |  | — |  |
| Total |  | $ | 160.0 |  |  | $ | 126.9 |  |  | $ | 33.1 |  |  | $ | — |  |

[0000038725-16-000276:notes:197]
One of the Company’s domestic pension plans covers only two management employees.  The Company does not fund this plan.  The plan’s projected benefit obligation and accumulated benefit obligation were $9.8 million and $7.7 million, respectively, for 2015, and $12.4 million and $10.5 million, respectively, for 2014.

[0000038725-16-000276:notes:198]
The Company estimates total contributions to the plans of $7 million in 2016.

[0000038725-16-000276:notes:199]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid in accordance with the following schedule:

[0000038725-16-000276:notes:200]
| (In millions) |  | Pension Benefits |  | Other Benefits |
| 2016 |  | $ | 14.9 |  |  | $ | 1.2 |  |
| 2017 |  | 11.3 |  |  | 1.1 |  |
| 2018 |  | 11.5 |  |  | 1.0 |  |
| 2019 |  | 11.2 |  |  | 1.0 |  |
| 2020 |  | 11.2 |  |  | 0.9 |  |
| Years 2021 through 2025 |  | 61.6 |  |  | 3.8 |  |

[0000038725-16-000276:notes:201]
Defined Contribution Plans - The Company maintained two defined contribution plans during 2015 and 2014.  The Company's cash contributions are allocated to participant's accounts based on investment elections.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000038725-16-000276:notes:202]
Property, plant, and equipment are stated at cost.  Depreciation of plant and equipment is calculated on a straight line basis over the estimated useful lives of 10 to 40 years for land improvements and buildings, 5 to 10 years for machinery and equipment, and 3 to 7 years for furniture, fixtures, computers, and software.  Maintenance, repairs, and renewals of a minor nature are expensed as incurred.  Betterments and major renewals which extend the useful lives or add to the productive capacity of buildings, improvements, and equipment are capitalized.  The Company reviews its property, plant, and equipment for impairment at the asset group level whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable.  The Company’s depreciation expense was $26.8 million, $28.1 million, and $23.4 million in 2015, 2014, and 2013, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000038725-16-000276:notes:203]
SELECTED QUARTERLY FINANCIAL DATA (UNAUDITED)

[0000038725-16-000276:notes:204]
Unaudited quarterly financial information for 2015 and 2014, from continuing operations, is as follows:

[0000038725-16-000276:notes:205]
| (In millions, except per share amounts) |  |  |  |  |  |  |  |  |  |  |
|  | Net Sales |  | Gross Profit |  | Net Income |  | Net Income Attributable to Franklin Electric Co., Inc. |  | Basic Earnings Per Share |  | Diluted Earnings Per Share |
| 2015 |  |  |  |  |  |  |  |  |  |  |  |
| 1st quarter | $ | 225.7 |  |  | $ | 71.5 |  |  | $ | 20.0 |  |  | $ | 19.8 |  |  | $ | 0.41 |  |  | $ | 0.41 |  |
| 2nd quarter | 247.4 |  |  | 80.2 |  |  | 16.4 |  |  | 16.1 |  |  | 0.33 |  |  | 0.33 |  |
| 3rd quarter | 232.5 |  |  | 76.8 |  |  | 21.0 |  |  | 20.8 |  |  | 0.44 |  |  | 0.43 |  |
| 4th quarter | 219.3 |  |  | 69.1 |  |  | 16.3 |  |  | 16.2 |  |  | 0.34 |  |  | 0.33 |  |
|  | $ | 924.9 |  |  | $ | 297.6 |  |  | $ | 73.7 |  |  | $ | 72.9 |  |  | $ | 1.52 |  |  | $ | 1.50 |  |
| 2014 |  |  |  |  |  |  |  |  |  |  |  |  |
| 1st quarter | $ | 231.4 |  |  | $ | 78.1 |  |  | $ | 17.4 |  |  | $ | 17.0 |  |  | $ | 0.35 |  |  | $ | 0.35 |  |
| 2nd quarter | 284.5 |  |  | 99.4 |  |  | 27.5 |  |  | 27.1 |  |  | 0.56 |  |  | 0.55 |  |
| 3rd quarter | 278.1 |  |  | 89.2 |  |  | 22.8 |  |  | 22.7 |  |  | 0.46 |  |  | 0.46 |  |
| 4th quarter | 253.8 |  |  | 77.7 |  |  | 3.2 |  |  | 3.0 |  |  | 0.06 |  |  | 0.06 |  |
|  | $ | 1,047.8 |  |  | $ | 344.4 |  |  | $ | 70.9 |  |  | $ | 69.8 |  |  | $ | 1.43 |  |  | $ | 1.41 |  |

[0000038725-16-000276:notes:206]
Basic and diluted earnings per share amounts are computed independently for each of the quarters presented.  As a result, the sum of the quarterly earnings per share amounts may not equal the annual earnings per share amount.


## us-gaap:ReceivablesPolicyTextBlock

[0000038725-16-000276:notes:207]
Accounts receivable are stated at estimated net realizable value.  Accounts receivable are comprised of balances due from customers, net of earned discounts and estimated allowances for uncollectible accounts.  Earned discounts are based on specific customer agreement terms.  In determining allowances for uncollectible accounts, historical collection experience, current trends, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are reviewed.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-16-000276:notes:208]
RESTRUCTURING

[0000038725-16-000276:notes:209]
On July 1, 2014, the Company announced a plan to close its Wittlich, Germany manufacturing facility.  As part of this action, the Company will transfer the existing Wittlich manufacturing activity to its Brno, Czech Republic facility.  The Company will maintain its European Water Systems headquarters and distribution center in Wittlich, only the manufacturing operations will be relocating.  The realignment began in the third quarter of 2014 and is estimated to conclude by the end of 2016.  Charges for the realignment are expected to be approximately $19.4 million and will include severance expenses, professional service fees, asset write-offs, and temporarily leased facilities costs.

[0000038725-16-000276:notes:210]
Costs incurred in the twelve months ended January 2, 2016, included in the “Restructuring expense” line of the Company's consolidated statements of income, are as follows:

[0000038725-16-000276:notes:211]
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | 0.6 |  |
| Equipment relocation |  | 0.6 |  |  | — |  |  | — |  |  | 0.6 |  |
| Asset write-off |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Pension |  | 0.6 |  |  | — |  |  | — |  |  | 0.6 |  |
| Other |  | 1.1 |  |  | — |  |  | — |  |  | 1.1 |  |
| Total |  | $ | 2.7 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | 3.0 |  |

[0000038725-16-000276:notes:212]
Restructuring expenses of $16.6 million and $3.7 million were incurred in 2014 and 2013, respectively, primarily for the Water Systems realignment.

[0000038725-16-000276:notes:213]
As of January 2, 2016 there were no restructuring reserves.  As of January 3, 2015, there were $13.1 million restructuring reserves.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000038725-16-000276:notes:214]
Products are shipped utilizing common carriers direct to customers or, for consignment products, to customer specified warehouse locations.  Sales are recognized when the Company’s products are shipped direct or, in the case of consignment products, transferred from the customer specified warehouse location to the customer, at which time transfer of ownership and risk of loss pass to the customer.  The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience.


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000038725-16-000276:notes:215]
Financial information by geographic region is as follows:

[0000038725-16-000276:notes:216]
|  | Net sales |  | Long-lived assets |
| (In millions) | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |
| United States | $ | 418.5 |  |  | $ | 485.5 |  |  | $ | 460.5 |  |  | $ | 404.1 |  |  | $ | 418.0 |  |
| Foreign | 506.4 |  |  | 562.3 |  |  | 505.0 |  |  | 150.7 |  |  | 184.4 |  |
| Consolidated | $ | 924.9 |  |  | $ | 1,047.8 |  |  | $ | 965.5 |  |  | $ | 554.8 |  |  | $ | 602.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-16-000276:notes:217]
Financial information by reportable business segment is included in the following summary:

[0000038725-16-000276:notes:218]
|  | Net sales to external customers |  | Operating income (loss) |
| (In millions) | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Water Systems | $ | 707.6 |  |  | $ | 824.6 |  |  | $ | 766.4 |  |  | $ | 86.7 |  |  | $ | 103.9 |  |  | $ | 131.3 |  |
| Fueling Systems | 217.3 |  |  | 223.2 |  |  | 199.1 |  |  | 51.5 |  |  | 49.7 |  |  | 42.6 |  |
| Other | — |  |  | — |  |  | — |  |  | (47.8 | ) |  | (53.5 | ) |  | (50.1 | ) |
| Consolidated | $ | 924.9 |  |  | $ | 1,047.8 |  |  | $ | 965.5 |  |  | $ | 90.4 |  |  | $ | 100.1 |  |  | $ | 123.8 |  |
|  | Total assets |  |  |  | Depreciation |
|  | 2015 |  | 2014 |  |  |  | 2015 |  | 2014 |  | 2013 |
| Water Systems | $ | 677.6 |  |  | $ | 757.5 |  |  |  |  |  | $ | 19.5 |  |  | $ | 19.9 |  |  | $ | 18.1 |  |
| Fueling Systems | 248.5 |  |  | 252.7 |  |  |  |  |  | 2.5 |  |  | 2.4 |  |  | 1.9 |  |
| Other | 70.3 |  |  | 65.7 |  |  |  |  |  | 4.8 |  |  | 5.8 |  |  | 3.4 |  |
| Consolidated | $ | 996.4 |  |  | $ | 1,075.9 |  |  |  |  |  | $ | 26.8 |  |  | $ | 28.1 |  |  | $ | 23.4 |  |
|  | Amortization |  | Capital expenditures |
|  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Water Systems | $ | 6.6 |  |  | $ | 7.1 |  |  | $ | 6.0 |  |  | $ | 19.5 |  |  | $ | 33.8 |  |  | $ | 31.0 |  |
| Fueling Systems | 1.9 |  |  | 1.8 |  |  | 1.9 |  |  | 1.4 |  |  | 3.9 |  |  | 4.0 |  |
| Other | 0.1 |  |  | 0.2 |  |  | 0.1 |  |  | 5.0 |  |  | 4.7 |  |  | 32.2 |  |
| Consolidated | $ | 8.6 |  |  | $ | 9.1 |  |  | $ | 8.0 |  |  | $ | 25.9 |  |  | $ | 42.4 |  |  | $ | 67.2 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000038725-16-000276:notes:219]
FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES

[0000038725-16-000276:notes:220]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000038725-16-000276:notes:221]
| (In millions) |  | Balance at Beginning of Period |  | Additions Charged to Costs and Expenses |  | Deductions (a) |  | Other |  | Balance at End of Period |
| 2015 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.2 |  |  | $ | 1.1 |  |  | $ | 0.5 |  |  | $ | — |  |  | $ | 3.8 |  |
| Allowance for deferred taxes |  | 3.9 |  |  | 3.5 |  |  | 0.2 |  |  | — |  |  | 7.2 |  |
| 2014 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.0 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 3.2 |  |
| Allowance for deferred taxes |  | 3.5 |  |  | 1.3 |  |  | 0.9 |  |  | — |  |  | 3.9 |  |
| 2013 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.2 |  |  | $ | (0.1 | ) |  | $ | 0.1 |  |  | $ | — |  |  | $ | 3.0 |  |
| Allowance for deferred taxes |  | 4.4 |  |  | (0.9 | ) |  | — |  |  | — |  |  | 3.5 |  |

[0000038725-16-000276:notes:222]
(a) Charges for which allowances were created.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-16-000276:notes:223]
SEGMENT AND GEOGRAPHIC INFORMATION

[0000038725-16-000276:notes:224]
The Company’s business consists of the Water Systems and Fueling Systems reportable segments, based on the principal end market served.  The Company includes unallocated corporate expenses and inter-company eliminations in an “Other” segment that together with the Water Systems and Fueling Systems segments, represent the Company.

[0000038725-16-000276:notes:225]
The Water Systems segment designs, manufactures and sells motors, pumps, electronic controls and related parts and equipment primarily for use in submersible water and other fluid system applications.  The Fueling Systems segment designs, manufactures and sells pumps, electronic controls and related parts and equipment primarily for use in submersible fueling system applications.  The Fueling Systems segment integrates and sells motors and electronic controls produced by the Water Systems segment.

[0000038725-16-000276:notes:226]
The accounting policies of the Company's reportable segments are the same as those described in Note 1 (Summary of Significant Accounting Policies).  Performance is evaluated based on the sales and operating income of the segments and a variety of ratios to measure performance.  These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented.

[0000038725-16-000276:notes:227]
Property, plant and equipment is the major asset group in "Other" of total assets at January 2, 2016.  Property, plant and equipment is the major asset group in "Other" of total assets at January 3, 2015.

[0000038725-16-000276:notes:228]
Net sales are attributed to geographic regions based upon the ship to location of the customer.  Long-lived assets are attributed to geographic regions based upon the country of domicile.

[0000038725-16-000276:notes:229]
No single customer accounted for more than 10 percent of the Company’s consolidated sales in 2015, 2014, or 2013.  No single customer accounted for more than 10 percent of the Company's gross accounts receivable in 2015 or 2014.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000038725-16-000276:notes:230]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0000038725-16-000276:notes:231]
Company--“Franklin Electric” or the “Company” shall refer to Franklin Electric Co., Inc. and its consolidated subsidiaries.

[0000038725-16-000276:notes:232]
Fiscal Year--The Company's fiscal year ends on the Saturday nearest December 31.  The financial statements and accompanying notes are as of and for the years ended January 2, 2016 (52 weeks), January 3, 2015 (53 weeks), and December 28, 2013 (52 weeks), and referred to as 2015, 2014, and 2013, respectively.

[0000038725-16-000276:notes:233]
Principles of Consolidation--The consolidated financial statements include the accounts of Franklin Electric Co., Inc. and its consolidated subsidiaries.  All intercompany transactions have been eliminated.

[0000038725-16-000276:notes:234]
Business Combinations--The Company allocates the purchase price of its acquisitions to the assets acquired, liabilities assumed, and noncontrolling interests acquired based upon their respective fair values at the acquisition date.  The Company utilizes management estimates and inputs from an independent third-party valuation firm to assist in determining these fair values.  The excess of the acquisition price over these estimated fair values is recorded as goodwill.  Goodwill is adjusted for any changes to acquisition date fair value amounts made within the measurement period.  Acquisition-related transaction costs are recognized separately from the business combination and expensed as incurred.

[0000038725-16-000276:notes:235]
Revenue Recognition--Products are shipped utilizing common carriers direct to customers or, for consignment products, to customer specified warehouse locations.  Sales are recognized when the Company’s products are shipped direct or, in the case of consignment products, transferred from the customer specified warehouse location to the customer, at which time transfer of ownership and risk of loss pass to the customer.  The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience.

[0000038725-16-000276:notes:236]
Research and Development Expense--The Company’s research and development activities are charged to expense in the period incurred.  The Company incurred expenses of approximately $18.4 million in 2015, $19.3 million in 2014, and $16.8 million in 2013 related to research and development.

[0000038725-16-000276:notes:237]
Cash and Cash Equivalents--The Company considers cash on hand, demand deposits, and highly liquid investments with an original maturity date of three months or less to be cash and cash equivalents.

[0000038725-16-000276:notes:238]
Fair Value of Financial Instruments--Total debt, including current maturities, have carrying amounts of $220.9 million at January 2, 2016 and $177.2 million at January 3, 2015.  The estimated fair value of all debt was $225 million and $191 million at January 2, 2016 and January 3, 2015, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.  The Company’s off-balance sheet instruments consist of operating leases and certain derivative instruments with cancellation terms of thirty days or less.

[0000038725-16-000276:notes:239]
Accounts Receivable, Earned Discounts, and Allowance for Uncollectible Accounts--Accounts receivable are stated at estimated net realizable value.  Accounts receivable are comprised of balances due from customers, net of earned discounts and estimated allowances for uncollectible accounts.  Earned discounts are based on specific customer agreement terms.  In determining allowances for uncollectible accounts, historical collection experience, current trends, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are reviewed.

[0000038725-16-000276:notes:240]
Inventories--  Inventories are stated at the lower of cost or market.  The majority of the cost of domestic and foreign inventories is determined using the FIFO method with a portion of inventory costs determined using the average cost method.  The Company reviews its inventories for excess or obsolete products or components based on an analysis of historical usage and management's evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts.

[0000038725-16-000276:notes:241]
Property, Plant, and Equipment--Property, plant, and equipment are stated at cost.  Depreciation of plant and equipment is calculated on a straight line basis over the estimated useful lives of 10 to 40 years for land improvements and buildings, 5 to 10 years for machinery and equipment, and 3 to 7 years for furniture, fixtures, computers, and software.  Maintenance, repairs, and renewals of a minor nature are expensed as incurred.  Betterments and major renewals which extend the useful lives or add to the productive capacity of buildings, improvements, and equipment are capitalized.  The Company reviews its property, plant, and equipment for impairment at the asset group level whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable.  The Company’s depreciation expense was $26.8 million, $28.1 million, and $23.4 million in 2015, 2014, and 2013, respectively.

[0000038725-16-000276:notes:242]
Goodwill and Other Intangible Assets--The Company tests goodwill for impairment on an annual basis during the fourth quarter or more frequently as warranted by triggering events that indicate potential impairment.  Goodwill is tested at the reporting unit level, which the company has determined to be the North America Water Systems, International Water, and Fueling Systems units.  In compliance with FASB ASC Topic 350, Intangibles - Goodwill and Other, the Company has evaluated the aggregation criteria and determined that the components within the North America Water Systems and International Water reporting units can be aggregated in 2015.

[0000038725-16-000276:notes:243]
Warranty Obligations--Warranty terms are generally 2 years from date of manufacture or 1 year from date of installation.  The general warranty liability is recorded when revenue is recognized and is based on actual historical return rates from the most recent warranty periods.  In 2007, the Company began offering an extended warranty program to certain Water Systems segment customers, which provides warranty coverage up to 5 years from the date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims and expected customer returns.  The Company actively studies trends of warranty claims and takes action to improve product quality and minimize warranty claims.

[0000038725-16-000276:notes:244]
Income Taxes--Income taxes are accounted for in accordance with FASB ASC Topic 740, Income Taxes.  Under this guidance, deferred tax assets and liabilities are determined based on the difference between the financial statement and tax basis of assets and liabilities and net operating loss and credit carry forwards using enacted tax rates in effect for the year in which the differences are expected to reverse.  Valuation allowances are established when necessary to reduce deferred tax assets to the amounts expected to be realized.  The Company records a liability for uncertain tax positions by establishing a recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return.

[0000038725-16-000276:notes:245]
Share-Based Compensation-- Share-based awards are issued to key employees and non-employee directors and include discretionary grants of stock options, stock awards, and stock unit awards.  Compensation costs resulting from share-based payment transactions are recognized within selling, general, and administrative expenses at the grant date fair value over the requisite service period on a straight-line basis.

[0000038725-16-000276:notes:246]
Pensions--The Company makes its determination for pension, post retirement, and post employment benefit plans liabilities based on management estimates and consultation with actuaries, incorporating estimates and assumptions of future plan service costs, future interest costs on projected benefit obligations, rates of compensation increases, employee turnover rates, anticipated mortality rates, expected investment returns on plan assets, asset allocation assumptions of plan assets, and other factors.

[0000038725-16-000276:notes:247]
Earnings Per Common Share--Basic and diluted earnings per share are computed and disclosed in accordance with FASB ASC Topic 260, Earnings Per Share.  The Company utilizes the two-class method to compute earnings available to common shareholders.  Under the two-class method, earnings are adjusted by accretion amounts to redeemable noncontrolling interests recorded at redemption value.  The adjustments represent dividend distributions, in substance, to the noncontrolling interest holder as the holders have contractual rights to receive an amount upon redemption other than the fair value of applicable shares.  As a result, earnings are adjusted to reflect this in substance distribution that is different from other common shareholders.  In addition, the Company allocates net earnings to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company's participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.  Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-16-000276:notes:248]
Translation of Foreign Currency Financial Statements--All assets and liabilities of foreign subsidiaries in functional currency other than the U.S. dollar are translated at year end exchange rates.  All revenue and expense accounts are translated at average rates in effect during the respective period.  Adjustments for translating longer term foreign currency assets and liabilities in U.S. dollars are included as a component of other comprehensive income.  Transaction gains and losses that arise from shorter term exchange rate fluctuations are included in the “Foreign exchange expense" line within the Company's consolidated statements of income, as incurred.

[0000038725-16-000276:notes:249]
Significant Estimates--The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make significant estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of expenses during the reporting periods.  Significant estimates and assumptions by management affect the allowance for uncollectible accounts, inventory valuation, warranty, business combinations, redeemable noncontrolling interest, trade names and goodwill, income taxes, pension and employee benefit obligations, and share-based compensation.

[0000038725-16-000276:notes:250]
Although the Company regularly assesses these estimates, actual results could materially differ.  The Company bases its estimates on historical experience and various other assumptions that it believes to be reasonable under the circumstances.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-16-000276:notes:251]
SHAREOWNERS' EQUITY

[0000038725-16-000276:notes:252]
The Company has the authority to issue 65,000,000, $.10 par value shares.

[0000038725-16-000276:notes:253]
In 2015, the Company retired 65,209 shares that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards.  The Company also retired 958 shares that had been previously granted as stock awards to employees, but were forfeited upon not meeting the required restriction criteria or termination.  In 2014, the Company retired 40,679 shares that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards.  The Company also retired 68,675 shares that had been previously granted as a stock award to employees, but were forfeited upon termination.  In 2013, the Company retired 273,799 shares that were received from employees as payment for the exercise price of their stock options and taxes owned upon the exercise of their stock options and release of their restricted awards.  The Company also retired 6,190 shares that had been previously granted as stock awards to employees, but were forfeited upon termination.

[0000038725-16-000276:notes:254]
In 2015, 2014, and 2013, the Company recorded $1.4 million, $2.3 million, and $5.1 million, respectively, as a reduction in tax liability and an increase to shareowners’ equity as a result of stock option exercises.
