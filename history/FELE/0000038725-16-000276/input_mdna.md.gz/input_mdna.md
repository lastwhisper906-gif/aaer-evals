# FELE MD&A — 0000038725-16-000276


## mdna

[0000038725-16-000276:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS

[0000038725-16-000276:mdna:2]
2015 vs. 2014

[0000038725-16-000276:mdna:3]
OVERVIEW

[0000038725-16-000276:mdna:4]
Sales in 2015 decreased from the prior year.  Net sales in 2015 were $924.9 million, a decrease of about 12 percent compared to 2014 sales of $1,047.8 million. The sales decrease was primarily the impact of foreign currency translation as the US dollar strengthened against certain foreign currencies and lower sales volume, partially offset by price increases, as well as the Company's acquisitions. The Company's consolidated gross profit was $297.6 million for 2015, a decrease of $46.8 million or about 14 percent from 2014. The gross profit as a percent of net sales decreased 70 basis points to 32.2 percent in 2015 from 32.9 percent in 2014. The gross profit margin change was due primarily to lost leverage on fixed cost due to lower sales. For 2015, diluted earnings per share were $1.50, an increase of 6 percent compared to 2014 diluted earnings per share of $1.41. Adjusted earnings per share were $1.47, a decrease of 16 percent versus the $1.76 adjusted earnings per share in 2014 (see the table below for a reconciliation of the GAAP EPS to the adjusted EPS).

[0000038725-16-000276:mdna:5]
RESULTS OF OPERATIONS

[0000038725-16-000276:mdna:6]
Net Sales

[0000038725-16-000276:mdna:7]
Net sales in 2015 were $924.9 million, a decrease of $122.9 million or about 12 percent compared to 2014 sales of $1,047.8 million.  The incremental impact of sales from acquired businesses was $21.3 million or about 2 percent.  Sales revenue decreased by $89.3 million or about 9 percent in 2015 due to foreign currency translation. The sales change in 2015, excluding acquisitions and foreign currency translation, was a decrease of $54.9 million or about 5 percent.

[0000038725-16-000276:mdna:8]
|  | Net Sales |
| (In millions) | 2015 |  | 2014 |  | 2015 v 2014 |
| Water Systems | $ | 707.6 |  |  | $ | 824.6 |  |  | $ | (117.0 | ) |
| Fueling Systems | 217.3 |  |  | 223.2 |  |  | (5.9 | ) |
| Consolidated | $ | 924.9 |  |  | $ | 1,047.8 |  |  | $ | (122.9 | ) |

[0000038725-16-000276:mdna:9]
Net Sales-Water Systems

[0000038725-16-000276:mdna:10]
Water Systems sales were $707.6 million in 2015, a decrease of $117.0 million or 14 percent versus 2014. The incremental impact of sales from acquired businesses was $20.8 million or about 2 percent.  Foreign currency translation rate changes decreased sales $78.3 million, or about 9 percent, compared to sales in 2014. The sales change in 2015, excluding acquisitions and foreign currency translation, was a decrease of $59.5 million or about 7 percent.

[0000038725-16-000276:mdna:11]
Water Systems sales in the U.S. and Canada were 36 percent of consolidated sales and declined by about 20 percent in 2015 compared to the prior year. Sales revenue decreased by $5.9 million or about 1 percent in 2015 due to foreign currency translation. In 2015, U.S. and Canada sales of Pioneer branded mobile dewatering equipment declined by about 55 percent. The decline in mobile dewatering equipment is primarily attributed to reduced demand in the oil and gas end markets. Sales of groundwater pumping equipment declined by about 14 percent, and sales of surface water pumping equipment declined by about 6 percent versus 2014. The decline in groundwater equipment sales is attributable primarily to weaker demand in the agriculture sector as a result of less favorable weather and to a lesser extent, distributor changes the Company made in its primary groundwater distribution channel.  Sales of surface water pumping equipment also declined due to lower condensate pump sales as cooler temperatures delayed the start to the HVAC season.

[0000038725-16-000276:mdna:12]
Water Systems sales in Latin America were about 14 percent of consolidated sales for 2015 and declined by about 9 percent compared to the prior year. Acquisition related sales during 2015 were $10.4 million or about 7 percent. Foreign currency translation rate changes decreased sales $34.7 million, or about 24 percent, compared to sales in 2014. Excluding acquisition and foreign currency translation, sales in Latin America grew by about 8 percent during 2015. The growth in sales was led by increased sales in Mexico and Brazil, in local currency. This sales growth is a result of increasing demand for Franklin submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions.

[0000038725-16-000276:mdna:13]
Water Systems sales in the Middle East and Africa were about 11 percent of consolidated sales and decreased by about 10 percent compared to 2014. Water Systems sales in the Middle East and Africa were reduced by $16.5 million or about 14 percent in the year due to foreign currency translation. Excluding the impact of foreign currency translation, sales were up

[0000038725-16-000276:mdna:14]
about 4 percent compared to 2014. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-16-000276:mdna:15]
Water Systems sales in the Asia Pacific region were 8 percent of consolidated sales and grew by about 7 percent compared to the prior year. Acquisition related sales during 2015 increased sales by about 9 percent in Asia Pacific. Foreign currency translation rate changes decreased sales in 2015 in the Asia Pacific region by about 5 percent. Excluding acquisitions and foreign currency translation sales grew by about 3 percent during 2015. The Asia Pacific region experienced strong year over year growth in Southeast Asia and Korea. These sales increases were partially offset by smaller declines in sales in Australia, Japan and China.

[0000038725-16-000276:mdna:16]
Water Systems sales in Europe were about 7 percent of consolidated sales and decreased by about 20 percent compared to the prior year. Foreign currency translation rate changes decreased sales by about 21 percent compared to sales in 2014. Excluding foreign currency translation, European sales grew by about 1 percent during 2015.

[0000038725-16-000276:mdna:17]
Net Sales-Fueling Systems

[0000038725-16-000276:mdna:18]
Fueling Systems sales which represented 23 percent of consolidated sales were $217.3 million in 2015, a decrease of $5.9 million or about 3 percent versus 2014. The incremental impact of sales from acquired businesses was $0.5 million.  Foreign currency translation rate changes decreased sales $11.0 million or about 5 percent compared to sales in 2014. The sales change in 2015, excluding acquisitions and foreign currency translation, was an increase of $4.6 million or about 2 percent.

[0000038725-16-000276:mdna:19]
Fueling Systems sales in the U.S. and Canada grew by about 6 percent in 2015 compared to the prior year with sales growth coming from most product lines, especially in piping. Fueling Systems revenues declined in India and China due to the timing of tender awards made in India and the ongoing reduction in State owned oil company procurements in China. Sales also declined in Europe principally due to a 42 percent decline in the sale of storage tanks that support North Sea oil production.

[0000038725-16-000276:mdna:20]
Cost of Sales

[0000038725-16-000276:mdna:21]
Cost of sales as a percent of net sales for 2015 and 2014 was 67.8 percent and 67.1 percent, respectively. Correspondingly, the gross profit margin decreased to 32.2 percent from 32.9 percent, a 70 basis point decline. The gross profit margin decrease was primarily due to fixed costs deleverage on lower sales and higher raw material costs.  Direct materials as a percentage of sales was 46.9 percent up 50 basis points compared to 46.4 percent last year.  This increase in direct materials was partially offset by lower labor and burden costs.  The Company's consolidated gross profit was $297.6 million for 2015, down $46.8 million or 14 percent from 2014.

[0000038725-16-000276:mdna:22]
Selling, General and Administrative (“SG&A”)

[0000038725-16-000276:mdna:23]
Selling, general, and administrative (SG&A) expenses were $204.3 million in 2015 and decreased by $23.4 million or about 10 percent in 2015 compared to last year. In 2015, increases in SG&A attributable to acquisitions were about $6 million or about 3 percent. Additional year over year changes in SG&A costs were decreases in the year primarily due to lower marketing and selling related expenses, as well as lower costs for incentive compensation. Approximately half of the lower SG&A expenses was related to foreign exchange.

[0000038725-16-000276:mdna:24]
Restructuring Expenses

[0000038725-16-000276:mdna:25]
Restructuring expenses for 2015 were $3.0 million and reduced diluted earnings per share by approximately $0.04. Restructuring expenses in 2015 included severance and pension costs, equipment relocation expenses, asset write-downs and primarily related to the closure of the Wittlich, Germany facility and other manufacturing realignment activities in Europe and Brazil. There were $16.6 million of restructuring expenses in 2014 and reduced diluted earnings per share by approximately $0.24. Restructuring expenses in 2014 included severance costs, equipment relocation expenses, and asset write-downs primarily related to the closure of the Wittlich, Germany facility and other European manufacturing realignment activities.

[0000038725-16-000276:mdna:26]
Operating Income

[0000038725-16-000276:mdna:27]
Operating income was $90.4 million in 2015, down $9.7 million from $100.1 million in 2014.

[0000038725-16-000276:mdna:28]
|  |  | Operating income (loss) |
| (In millions) |  | 2015 |  | 2014 |  | 2015 v 2014 |
| Water Systems |  | $ | 86.7 |  |  | $ | 103.9 |  |  | $ | (17.2 | ) |
| Fueling Systems |  | 51.5 |  |  | 49.7 |  |  | 1.8 |  |
| Other |  | (47.8 | ) |  | (53.5 | ) |  | 5.7 |  |
| Consolidated |  | $ | 90.4 |  |  | $ | 100.1 |  |  | $ | (9.7 | ) |

[0000038725-16-000276:mdna:29]
There were specific items in 2015 and 2014 that impacted operating income that were not operational in nature.

[0000038725-16-000276:mdna:30]
In 2015 they were as follows:

[0000038725-16-000276:mdna:31]
| • | There were $3.0 million of restructuring charges. Restructuring expenses in 2015 were $0.6 million in severance cost, $0.6 million in pension cost, $0.6 million expenses related to equipment transfers and freight costs, $0.1 million in asset write-offs and $1.1 million in other relocation costs primarily related to the closure of the Wittlich, Germany facility and other manufacturing realignment activities in Europe and Brazil. |

[0000038725-16-000276:mdna:32]
| • | $1.2 million related to executive transition. |

[0000038725-16-000276:mdna:33]
| • | $0.7 million related to business realignment cost, primarily severance, in targeted fixed cost reduction actions. |

[0000038725-16-000276:mdna:34]
| • | $0.2 million in other miscellaneous costs related to closed acquisitions. |

[0000038725-16-000276:mdna:35]
In 2014 they were as follows:

[0000038725-16-000276:mdna:36]
| • | There were $16.6 million of restructuring charges. Restructuring expenses in 2014 were $14.7 million in severance cost, $1.7 million expenses related to equipment transfers, freight and other relocation costs and $0.2 million in asset write-offs primarily related to the transfer of production activities from Germany to the Czech Republic and other continued manufacturing realignments. |

[0000038725-16-000276:mdna:37]
| • | $3.2 million in other miscellaneous costs related to closed and pending acquisitions and $0.2 million in legal fees incurred by Franklin Fueling Systems. |

[0000038725-16-000276:mdna:38]
| • | $2.5 million related to executive transition. |

[0000038725-16-000276:mdna:39]
| • | $1.8 million of software write-offs. |

[0000038725-16-000276:mdna:40]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments to net sales (operating income margin after non-GAAP adjustments).  The Company believes this information helps investors and management understand underlying trends in the Company's business more easily and by presenting these matters in this way, gives our investors and management a more accurate picture of the actual operational performance of the Company. The non-GAAP adjustments are for restructuring expenses, reported separately on the income statement, as well as certain legal matters and acquisition related items which are included in SG&A on the income statement.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000276:mdna:41]
18

[0000038725-16-000276:mdna:42]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Full Year of 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 86.7 |  | $ | 51.5 |  | $ | (47.8 | ) | $ | 90.4 |  |
| % Operating Income To Net Sales | 12.3 | % | 23.7 | % |  | 9.8 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 2.7 |  | $ | 0.3 |  | $ | — |  | $ | 3.0 |  |
| Non-GAAP Expenses | $ | 0.7 |  | $ | 0.2 |  | $ | 1.2 |  | $ | 2.1 |  |
| Operating Income after Non-GAAP Adjustments | $ | 90.1 |  | $ | 52.0 |  | $ | (46.6 | ) | $ | 95.5 |  |
| % Operating Income to Net Sales after Non-GAAP adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.7 | % | 23.9 | % |  | 10.3 | % |
|  | For the Full Year of 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 103.9 |  | $ | 49.7 |  | $ | (53.5 | ) | $ | 100.1 |  |
| % Operating Income To Net Sales | 12.6 | % | 22.3 | % |  | 9.6 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 16.1 |  | $ | 0.5 |  | $ | — |  | $ | 16.6 |  |
| Non-GAAP Expenses | $ | 3.7 |  | $ | 1.5 |  | $ | 2.5 |  | $ | 7.7 |  |
| Operating Income after Non-GAAP Adjustments | $ | 123.7 |  | $ | 51.7 |  | $ | (51.0 | ) | $ | 124.4 |  |
| % Operating Income to Net Sales after Non-GAAP adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.0 | % | 23.2 | % |  | 11.9 | % |

[0000038725-16-000276:mdna:43]
Operating Income-Water Systems

[0000038725-16-000276:mdna:44]
Water Systems operating income, after non-GAAP adjustments, was $90.1 million in 2015, a decrease of 27 percent versus 2014. The 2015 operating income margin after non-GAAP adjustments was 12.7 percent and decreased by 230 basis points compared to the 15.0 percent of net sales in 2014. Operating income margin after non-GAAP adjustments decreased in Water Systems primarily due to loss of operating leverage.

[0000038725-16-000276:mdna:45]
Operating Income-Fueling Systems

[0000038725-16-000276:mdna:46]
Fueling Systems operating income after non-GAAP adjustments was $52.0 million in 2015 compared to $51.7 million after non-GAAP adjustments in 2014. The 2015 operating income margin after non-GAAP adjustments was 23.9 percent and increased by 70 basis points compared to the 23.2 percent of net sales in 2014. This increased profitability was primarily due to lower fixed costs.

[0000038725-16-000276:mdna:47]
Operating Income-Other

[0000038725-16-000276:mdna:48]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses after non-GAAP adjustments were down about 9 percent compared to last year primarily due to lower incentive compensation due to lower overall operating results.

[0000038725-16-000276:mdna:49]
Interest Expense

[0000038725-16-000276:mdna:50]
Interest expense for 2015 and 2014 was $10.0 million and $10.7 million, respectively.

[0000038725-16-000276:mdna:51]
Other Income or Expense

[0000038725-16-000276:mdna:52]
Other income or expense was a gain of $6.9 million in 2015. Included in other income or expense in 2015 was minority income of $2.8 million and interest income of $1.3 million, primarily derived from the investment of cash balances in short-term securities. The Company also realized a gain on the settlement of the redeemable non-controlling interest liability in the first quarter of this year of about $2.7 million. Other income or expense was a gain of $1.3 million in 2014 and included in other income or expense in 2014 was interest income of $2.0 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-16-000276:mdna:53]
Foreign Exchange

[0000038725-16-000276:mdna:54]
Foreign currency-based transactions produced a loss for 2015 of $0.9 million, primarily due to the South African rand, Colombian Peso and Australian dollar relative to the U.S. dollar, none of which individually were significant.  Foreign currency-based transactions produced a loss for 2014 of $1.0 million, primarily due to the Canadian dollar, Australian dollar, Turkish lira, and South African rand relative to the U.S. dollar, none of which individually were significant.

[0000038725-16-000276:mdna:55]
Income Taxes

[0000038725-16-000276:mdna:56]
The provision for income taxes in 2015 and 2014 was $12.6 million and $18.9 million, respectively. The tax rate for 2015 was 14.6 percent and 2014 was 21.0 percent. Discrete adjustments during 2015 were the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer. This tax benefit of about $4.8 million was treated as a non-GAAP adjustment. Because in 2012, the gain was treated as a non-GAAP adjustment, the Company is now consistently treating the reversal of the tax liability related to that gain as a non-GAAP adjustment and reducing reported Earnings per Share in 2015 by $0.10 cents. The Company also realized a gain on the redeemable non-controlling interest liability in the year of about $2.7 million which is included in ‘Other income’. This purchase transaction also resulted in other tax benefits of about $2.5 million, which were expensed through the Company’s earnings in prior years as well as a current year benefit of about $1.0 million related to the 2015 gain. The effective tax rate for 2015 was about 27 percent and 2014 was about 26 percent before discrete adjustments. The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-16-000276:mdna:57]
Net Income

[0000038725-16-000276:mdna:58]
Net income for 2015 was $73.7 million compared to 2014 net income of $70.9 million.  Net income attributable to Franklin Electric Co., Inc. for 2015 was $72.9 million, or $1.50 per diluted share, compared to 2014 net income attributable to Franklin Electric Co., Inc. of $69.8 million or $1.41 per diluted share. Net income attributable to Franklin Electric Co., Inc. after Non-GAAP adjustments for 2015 was $69.7 million, or $1.47 per diluted share, compared to 2014 net income attributable to Franklin Electric Co., Inc. after Non-GAAP adjustments of $84.3 million or $1.76 per diluted share.

[0000038725-16-000276:mdna:59]
There were specific items in 2015 and 2014 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature. The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of net income attributable to Franklin Electric Co., Inc. and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000276:mdna:60]
| Earnings Before and After Non-GAAP Adjustments | For the Full Year |
| (in millions) | 2015 | 2014 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 72.9 |  | $ | 69.8 |  | 4 | % |
| Allocated Undistributed Earnings | $ | (1.5 | ) | $ | (1.6 | ) |  |
| Adjusted Earnings for EPS Calculations | $ | 71.4 |  | $ | 68.2 |  | 5 | % |
| Non-GAAP adjustments (before tax): |  |  |  |
| Restructuring | $ | 3.0 |  | $ | 16.6 |  |  |
| Non-GAAP items | $ | 2.1 |  | $ | 7.7 |  |  |
| Pioneer tax benefits on equity gain | $ | (4.8 | ) | $ | — |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 1.8 |  | $ | 11.4 |  |  |
| Non-GAAP items | $ | 1.3 |  | $ | 4.7 |  |  |
| Pioneer tax benefits on equity gain | $ | (4.8 | ) | $ | — |  |  |
| Net Income attributable to Franklin Electric Co., Inc. after Non-GAAP Adjustments (Adjusted Net Income) | $ | 69.7 |  | $ | 84.3 |  | (17 | )% |

[0000038725-16-000276:mdna:61]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the Full Year |
| (in millions except per-share data) | 2015 |  | 2014 |  | Change |
| Average Fully Diluted Shares Outstanding | $ | 47.6 |  |  | $ | 48.2 |  |  | (1 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 1.50 |  |  | $ | 1.41 |  |  | 6 | % |
| Restructuring Per Share, net of tax | $ | 0.04 |  |  | $ | 0.24 |  |  |  |
| Non-GAAP items, net of tax | $ | 0.03 |  |  | $ | 0.11 |  |  |  |
| Pioneer tax benefits on equity gain | $ | (0.10 | ) |  | $ | — |  |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 1.47 |  |  | $ | 1.76 |  |  | (16 | )% |

[0000038725-16-000276:mdna:62]
2014 vs. 2013

[0000038725-16-000276:mdna:63]
OVERVIEW

[0000038725-16-000276:mdna:64]
Sales in 2014 increased from the prior year.  Net sales in 2014 were $1,047.8 million, an increase of about 9 percent compared to 2013 sales of $965.5 million. The sales increase was primarily from sales volume and price increases, as well as the Company's acquisitions. Sales increases were partially offset by the impact of foreign currency translation as the US dollar strengthened against certain foreign currencies. The Company's consolidated gross profit was $344.4 million for 2014, an increase of $12.9 million or about 4 percent from 2013. The gross profit as a percent of net sales decreased 140 basis points to 32.9 percent in 2014 from 34.3 percent in 2013. The gross profit margin change was due primarily to a sales revenue mix shift in the Water Systems. For 2014, diluted earnings per share were $1.41, a decrease of 16 percent compared to 2013 diluted earnings per share of $1.68. Adjusted earnings per share were $1.76, an increase of 2 percent versus the $1.72 adjusted earnings per share in 2013 (see the table below for a reconciliation of the GAAP EPS to the adjusted EPS).

[0000038725-16-000276:mdna:65]
RESULTS OF OPERATIONS

[0000038725-16-000276:mdna:66]
Net Sales

[0000038725-16-000276:mdna:67]
Net sales in 2014 were $1,047.8 million, an increase of $82.3 million or about 9 percent compared to 2013 sales of $965.5 million.  The incremental impact of sales from acquired businesses was $23.5 million or about 2 percent.  Sales revenue decreased by $24.1 million or about 2 percent in 2014 due to foreign currency translation. The sales change in 2014, excluding acquisitions and foreign currency translation, was an increase of $82.9 million or about 9 percent.

[0000038725-16-000276:mdna:68]
|  |  | Net Sales |
| (In millions) |  | 2014 |  | 2013 |  | 2014 v 2013 |
| Water Systems |  | $ | 824.6 |  |  | $ | 766.4 |  |  | $ | 58.2 |  |
| Fueling Systems |  | 223.2 |  |  | 199.1 |  |  | 24.1 |  |
| Consolidated |  | $ | 1,047.8 |  |  | $ | 965.5 |  |  | $ | 82.3 |  |

[0000038725-16-000276:mdna:69]
Net Sales-Water Systems

[0000038725-16-000276:mdna:70]
Water Systems sales were $824.6 million in 2014, an increase of $58.2 million or 8 percent versus 2013. The incremental impact of sales from acquired businesses was $23.4 million or about 3 percent.  Foreign currency translation rate changes decreased sales $24.8 million, or about 3 percent, compared to sales in 2013. The sales change in 2014, excluding acquisitions and foreign currency translation, was an increase of $59.6 million or about 8 percent.

[0000038725-16-000276:mdna:71]
Water Systems sales in the U.S. and Canada were 39 percent of consolidated sales and grew by about 5 percent compared to 2013. Foreign currency translation rate changes decreased sales by about 1 percent compared to sales in 2013. The sales change in 2014, excluding acquisitions and foreign currency translation, was an increase of $23 million or about 6 percent. Leading the Company's growth in the U.S. and Canada were sales of Pioneer branded mobile pumping equipment which increased by about 70 percent in 2014 compared to the prior year. Sales of surface water pumping equipment grew by 8 percent in the year. These

[0000038725-16-000276:mdna:72]
sales increases in the U.S and Canada were partially offset by lower sales of groundwater pumping equipment which declined about 10 percent in 2014 due, in part, to weaker demand in the agriculture sector as a result of less favorable weather and to a lesser extent, distributor changes the Company made in its primary groundwater distribution channel.

[0000038725-16-000276:mdna:73]
Water Systems sales in Latin America were about 14 percent of consolidated sales for 2014 and grew by about 18 percent compared to the prior year. Acquisition related sales during 2014 were about $17 million or about 14 percent. Foreign currency translation rate changes decreased sales $8 million, or about 7 percent, compared to sales in 2013. Excluding acquisition and foreign currency translation, sales in Latin America grew by about 10 percent during 2014. The 2014 year-on-year sales increase in Brazil, in local currency, was 15 percent. The sales growth in Brazil is a result of increasing demand for Franklin submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions. New distribution outlets in Chile and Colombia contributed to significantly increased sales in these markets compared to 2013. These sales increases were partially offset with lower sales in Argentina.

[0000038725-16-000276:mdna:74]
Water Systems sales in the Middle East and Africa were about 11 percent of consolidated sales and increased by about 2 percent compared to 2013. Water Systems sales in the Middle East and Africa were reduced by $11.3 million or about 10 percent in the year due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, sales were up about 11 percent compared to 2013. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-16-000276:mdna:75]
Water Systems sales in Europe were about 8 percent of consolidated sales and grew by about 11 percent compared to the prior year. Acquisition related sales during 2014 were about 2 percent in Europe. Foreign currency translation rate changes decreased sales by about 1 percent compared to sales in 2013. Excluding acquisitions and foreign currency translation, European sales grew by about 10 percent during 2014. Sales improvements in Europe included growth in both groundwater pumping equipment and Pioneer products.

[0000038725-16-000276:mdna:76]
Water Systems sales in the Asia Pacific region were 7 percent of consolidated sales and grew by about 11 percent compared to the prior year. Acquisition related sales during 2014 increased sales by about 7 percent in Asia Pacific. Foreign currency translation rate changes decreased sales in 2014 in the Asia Pacific region by about 2 percent. Excluding acquisitions and foreign currency translation sales grew by about 7 percent during 2014. Sales in Australia grew by about 28 percent led by improved Pioneer product sales in the region and aided in part by the launch of the new solar powered water well pumping system. Sales in Taiwan and Southeast Asia grew by about 5 percent compared to the prior year, as the Company continues to benefit from the improved customer service levels attributable to a new distribution center in Singapore. These sales increases were partially offset by smaller declines in sales in Japan and China.

[0000038725-16-000276:mdna:77]
Net Sales-Fueling Systems

[0000038725-16-000276:mdna:78]
Fueling Systems sales which represented 21 percent of consolidated sales were $223.2 million in 2014, an increase of $24.1 million or about 12 percent versus 2013. The incremental impact of sales from acquired businesses was $0.1 million.  Foreign currency translation rate changes increased sales $0.7 million compared to sales in 2013. The sales change in 2014, excluding acquisitions and foreign currency translation, was an increase of $23.3 million or about 12 percent.

[0000038725-16-000276:mdna:79]
This growth was led by sales increases in developing markets, which grew by 15 percent compared to the prior year, as customers outside North America continue to invest in the Company’s pressure pumping systems for transferring gasoline from underground tanks. As well, adoption of the Company’s electronic fuel management products is increasing among international customers. Fueling Systems sales in more developed markets; like the U.S., Canada and Europe grew by about 11 percent compared to prior year.

[0000038725-16-000276:mdna:80]
Cost of Sales

[0000038725-16-000276:mdna:81]
Cost of sales as a percent of net sales for 2014 and 2013 was 67.1 percent and 65.7 percent, respectively. Correspondingly, the gross profit margin decreased to 32.9 percent from 34.3 percent, a 140 basis point decline. The gross profit margin change was due primarily to a sales revenue mix shift in the Water Systems segment, as groundwater pumping system sales have declined and surface pumping equipment system sales have increased, contributing significantly to lower gross profit margins in 2014. Direct materials as a percentage of sales was 46.4 percent up 200 basis points compared to 44.4 percent last year.   This increase in direct materials was partially offset by lower labor and burden costs.  The Company's consolidated gross profit was $344.4 million for 2014, up $12.9 million or 4 percent from 2013.

[0000038725-16-000276:mdna:82]
Selling, General and Administrative (“SG&A”)

[0000038725-16-000276:mdna:83]
Selling, general, and administrative (SG&A) expenses were $227.7 million in 2014 and increased by $23.7 million or about 12 percent in 2014 compared to last year. In 2014, increases in SG&A attributable to acquisitions were about $6 million or about 3 percent. Additional year over year changes in SG&A costs were increases in marketing and selling-related expenses attributable

[0000038725-16-000276:mdna:84]
to sales volume and higher research, development, and engineering expenses.

[0000038725-16-000276:mdna:85]
Restructuring Expenses

[0000038725-16-000276:mdna:86]
Restructuring expenses for 2014 were $16.6 million and reduced diluted earnings per share by approximately $0.24. Restructuring expenses in 2014 included severance costs, equipment relocation expenses, asset write-downs and primarily related to the closure of the Wittlich, Germany facility and other European manufacturing realignment activities. There were $3.7 million of restructuring expenses in 2013.

[0000038725-16-000276:mdna:87]
Operating Income

[0000038725-16-000276:mdna:88]
Operating income was $100.1 million in 2014, down $23.7 million from $123.8 million in 2013.

[0000038725-16-000276:mdna:89]
|  |  | Operating income (loss) |
| (In millions) |  | 2014 |  | 2013 |  | 2014 v 2013 |
| Water Systems |  | $ | 103.9 |  |  | $ | 131.3 |  |  | $ | (27.4 | ) |
| Fueling Systems |  | 49.7 |  |  | 42.6 |  |  | 7.1 |  |
| Other |  | (53.5 | ) |  | (50.1 | ) |  | (3.4 | ) |
| Consolidated |  | $ | 100.1 |  |  | $ | 123.8 |  |  | $ | (23.7 | ) |

[0000038725-16-000276:mdna:90]
There were specific items in 2014 and 2013 that impacted operating income that were not operational in nature.

[0000038725-16-000276:mdna:91]
In 2014 they were as follows:

[0000038725-16-000276:mdna:92]
| • | There were $16.6 million of restructuring charges. Restructuring expenses in 2014 were $14.7 million in severance cost, $1.7 million expenses related to equipment transfers, freight and other relocation costs and $0.2 million in asset write-offs primarily related to the transfer of production activities from Germany to the Czech Republic and other continued manufacturing realignments. |

[0000038725-16-000276:mdna:93]
| • | $3.2 million in other miscellaneous costs related to closed and pending acquisitions and $0.2 million in legal fees incurred by Franklin Fueling Systems. |

[0000038725-16-000276:mdna:94]
| • |  |

[0000038725-16-000276:mdna:95]
| • | $2.5 million related to executive transitions. |

[0000038725-16-000276:mdna:96]
| • | $1.8 million of software write-offs. |

[0000038725-16-000276:mdna:97]
In 2013 they were as follows:

[0000038725-16-000276:mdna:98]
| • | There were $3.7 million of restructuring charges. Restructuring expenses were $1.5 million in other miscellaneous manufacturing realignment activities, severance expenses of $1.1 million, and $1.1 million related to relocation to the new corporate headquarters and engineering center in Fort Wayne, Indiana. |

[0000038725-16-000276:mdna:99]
| • | A net $1.0 million of benefit from the $1.6 million reversal of a reverse for legal claims established in prior years that was favorably resolved in the third quarter of 2013, offset by $0.6 million of legal fees incurred by Franklin Fueling Systems. |

[0000038725-16-000276:mdna:100]
| • | $0.9 million in other miscellaneous costs related to pending acquisitions. |

[0000038725-16-000276:mdna:101]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments to net sales (operating income margin after non-GAAP adjustments).  The Company believes this information helps investors and management understand underlying trends in the Company's business more easily. The Company believes presenting these matters in this way gives our investors and management a more accurate picture of the actual operational performance of the Company. The non-GAAP adjustments are for restructuring expenses, reported separately on the income statement, as well as certain legal matters and acquisition related items which are included in SGA on the income statement.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000276:mdna:102]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Full Year of 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 103.9 |  | $ | 49.7 |  | $ | (53.5 | ) | $ | 100.1 |  |
| % Operating Income To Net Sales | 12.6 | % | 22.3 | % |  | 9.6 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 16.1 |  | $ | 0.5 |  | $ | — |  | $ | 16.6 |  |
| Non-GAAP Expenses | $ | 3.7 |  | $ | 1.5 |  | $ | 2.5 |  | $ | 7.7 |  |
| Operating Income after Non-GAAP Adjustments | $ | 123.7 |  | $ | 51.7 |  | $ | (51.0 | ) | $ | 124.4 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.0 | % | 23.2 | % |  | 11.9 | % |
|  | For the Full Year of 2013 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 131.3 |  | $ | 42.6 |  | $ | (50.1 | ) | $ | 123.8 |  |
| % Operating Income To Net Sales | 17.1 | % | 21.4 | % |  | 12.8 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 3.2 |  | $ | 0.5 |  | $ | — |  | $ | 3.7 |  |
| Non-GAAP Expenses | $ | 0.7 |  | $ | (0.8 | ) | $ | — |  | $ | (0.1 | ) |
| Operating Income after Non-GAAP Adjustments | $ | 135.2 |  | $ | 42.3 |  | $ | (50.1 | ) | $ | 127.4 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 17.6 | % | 21.2 | % |  | 13.2 | % |

[0000038725-16-000276:mdna:103]
Operating Income-Water Systems

[0000038725-16-000276:mdna:104]
Water Systems operating income, after non-GAAP adjustments, was $123.7 million in 2014, a decrease of 9 percent versus 2013. The 2014 operating income margin after non-GAAP adjustments was 15.0 percent and decreased by 260 basis points compared to the 17.6 percent of net sales in 2013. The change in profitability was primarily the result of higher global raw material costs, higher marketing and selling costs in the U.S. and Canada commercial business, and the continued sales mix shift to surface pumping equipment away from groundwater pumping equipment. Contributing to both the sales mix shift to surface pumping equipment and the higher material costs, Pioneer branded mobile pumping equipment sales have had a surge in demand during the year and the Company has temporarily outsourced certain operations to meet the increased demand.

[0000038725-16-000276:mdna:105]
Operating Income-Fueling Systems

[0000038725-16-000276:mdna:106]
Fueling Systems operating income after non-GAAP adjustments was $51.7 million in 2014 compared to $42.3 million after non-GAAP adjustments in 2013, an increase of 22 percent. The 2014 operating income margin after non-GAAP adjustments was 23.2 percent and increased by 200 basis points compared to the 21.2 percent of net sales in 2013. This increased profitability was primarily due to fixed costs leverage on higher sales.

[0000038725-16-000276:mdna:107]
Operating Income-Other

[0000038725-16-000276:mdna:108]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses were higher due to $2.5 million of cost included in non-GAAP adjustments related to executive transition.

[0000038725-16-000276:mdna:109]
Interest Expense

[0000038725-16-000276:mdna:110]
Interest expense for 2014 and 2013 was $10.7 million and $10.6 million, respectively.

[0000038725-16-000276:mdna:111]
Other Income or Expense

[0000038725-16-000276:mdna:112]
Other income or expense was a gain of $1.3 million in 2014. Included in other income or expense in 2014 was interest income of $2.0 million, primarily derived from the investment of cash balances in short-term securities. Other income or expense was a gain of $1.7 million in 2013. Included in other income or expense in 2013 was interest income of $1.8 million, primarily

[0000038725-16-000276:mdna:113]
derived from the investment of cash balances in short-term securities.

[0000038725-16-000276:mdna:114]
Foreign Exchange

[0000038725-16-000276:mdna:115]
Foreign currency-based transactions produced a loss for 2014 of $1.0 million, primarily due to the Canadian dollar, Australian dollar, Turkish lira, and South African rand relative to the U.S. dollar, none of which individually were significant.  Foreign currency-based transactions produced a loss for 2013 of $3.3 million, primarily due to the Turkish lira, the euro, South African rand, Brazilian real and Canadian dollar relative to the U.S. dollar, none of which individually were significant.

[0000038725-16-000276:mdna:116]
Income Taxes

[0000038725-16-000276:mdna:117]
The provision for income taxes in 2014 and 2013 was $18.9 million and $28.9 million, respectively. The tax rate for 2014 was 21.0 percent and 2013 was 25.9 percent. The tax rate declined in 2014 from the tax rate for 2013 primarily due to a reversal of deferred tax liabilities associated with earnings of certain foreign subsidiaries which have been realigned within the Company’s organization. The realignment of certain foreign entities results in their unremitted earnings being indefinitely reinvested. The effective tax rate differs from the statutory rate primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate as well as recognition of foreign tax credits. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations as well as cash on hand and available credit.

[0000038725-16-000276:mdna:118]
Net Income

[0000038725-16-000276:mdna:119]
Net income for 2014 was $70.9 million compared to 2013 net income of $82.7 million.  Net income attributable to Franklin Electric Co., Inc. for 2014 was $69.8 million, or $1.41 per diluted share, compared to 2013 net income attributable to Franklin Electric Co., Inc. of $82.0 million or $1.68 per diluted share. Net income attributable to Franklin Electric Co., Inc. after Non-GAAP adjustments for 2014 was $84.3 million, or $1.76 per diluted share, compared to 2013 net income attributable to Franklin Electric Co., Inc. after Non-GAAP adjustments of $82.9 million or $1.72 per diluted share.

[0000038725-16-000276:mdna:120]
There were specific items in 2014 and 2013 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature. The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of net income attributable to Franklin Electric Co., Inc. and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000276:mdna:121]
| Earnings Before and After Non-GAAP Adjustments | For the Full Year |
| (in millions) | 2014 |  | 2013 |  | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 69.8 |  |  | $ | 82.0 |  |  | (15 | )% |
| Allocated Undistributed Earnings | $ | (1.6 | ) |  | $ | (1.2 | ) |  |  |
| Adjusted Earnings for EPS Calculations | $ | 68.2 |  |  | $ | 80.8 |  |  | (16 | )% |
| Non-GAAP adjustments (before tax): |  |  |  |  |  |
| Restructuring | $ | 16.6 |  |  | $ | 3.7 |  |  |  |
| Non-GAAP items | $ | 7.7 |  |  | $ | (0.1 | ) |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |  |
| Restructuring | $ | 11.4 |  |  | $ | 2.2 |  |  |  |
| Non-GAAP items | $ | 4.7 |  |  | $ | (0.1 | ) |  |  |
| Net Income attributable to Franklin Electric Co., Inc. after Non-GAAP Adjustments (Adjusted Net Income) | $ | 84.3 |  |  | $ | 82.9 |  |  | 2 | % |

[0000038725-16-000276:mdna:122]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the Full Year |
| (in millions except per-share data) | 2014 |  | 2013 |  | Change |
| Average Fully Diluted Shares Outstanding | $ | 48.2 |  |  | $ | 48.1 |  |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 1.41 |  |  | $ | 1.68 |  |  | (16 | )% |
| Restructuring Per Share, net of tax | $ | 0.24 |  |  | $ | 0.05 |  |  |  |
| Non-GAAP items, net of tax | $ | 0.11 |  |  | $ | (0.01 | ) |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 1.76 |  |  | $ | 1.72 |  |  | 2 | % |

[0000038725-16-000276:mdna:123]
CAPITAL RESOURCES AND LIQUIDITY

[0000038725-16-000276:mdna:124]
Overview

[0000038725-16-000276:mdna:125]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreement, and long-term debt funds available.

[0000038725-16-000276:mdna:126]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of January 2, 2016, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-16-000276:mdna:127]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement.  Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)."  The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million.  The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (tax increment financing debt) bear interest at 3.6 percent per annum.  Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.  On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-16-000276:mdna:128]
On April 9, 2007, the Company entered into the Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") in the amount of $175.0 million.  Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”).  The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had at issuance an average life of 10 years with a final maturity in 2019.  On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million.  On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Agreement.  On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015.  On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement.   This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of January 2, 2016, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.

[0000038725-16-000276:mdna:129]
26

[0000038725-16-000276:mdna:130]
On December 14, 2006, the Company entered into an amended and restated unsecured, 60-month $120.0 million revolving credit agreement (the “Credit Agreement”).  The Credit Agreement provides for various borrowing rate options including interest rates based on the London Interbank Offered Rates (LIBOR) plus interest spreads keyed to the Company’s ratio of debt to earnings before interest, taxes, depreciation, and amortization (“EBITDA”).  On December 14, 2011, the Company executed the Second Amended and Restated Credit Agreement, which extended the maturity of the Agreement to December 14, 2016, and increased the commitment amount to $150.0 million.  On May 5, 2015, the Company entered into Amendment No. 3 to the Credit Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  As of January 2, 2016, the Company had $144.8 million borrowing capacity under the Credit Agreement as $5.2 million in letters of commercial and standby letters of credit were outstanding and undrawn.  There were no other outstanding borrowings as of January 2, 2016 on the Credit Agreement.

[0000038725-16-000276:mdna:131]
The New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws, and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales, and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million.  As of January 2, 2016, the Company was in compliance with all financial covenants.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-16-000276:mdna:132]
At January 2, 2016, the Company had $81.6 million of cash on hand at various locations worldwide.  Approximately 21 percent of the cash on hand was in the U.S. and readily accessible.  Approximately 38 percent was in Europe, and the remaining 41 percent was in Mexico, Asia Pacific, and other locations combined.  On a regular basis the Company reviews international cash balances and, if appropriate based on forecasted expenditures and considerations for the post-tax economic efficiency, will reposition cash among its global entities.  Global cash balances are invested according to a written policy, and are generally in bank demand accounts and bank time deposits with the preservation of principal as the highest priority.

[0000038725-16-000276:mdna:133]
Operating Activities

[0000038725-16-000276:mdna:134]
Net cash provided by operating activities was $99.6 million for 2015 compared to $47.3 million for 2014 and $98.3 million in 2013.  The increase in cash provided from operations in 2015 compared to 2014 was primarily due to lower uses of cash for trade receivables and inventory in conjunction with reduced sales in 2015.  This increase in cash provided from operations was partially offset by a reduction in outstanding accounts payable balances at year-end 2015 compared to 2014.  This reduction was also primarily due to lower year-end inventory levels.  The reduction in cash provided from operations in 2014 compared to 2013 was primarily due to an increased use of cash for inventory and receivables compared to 2013.  Outstanding inventory balances were elevated at 2014 year-end, primarily due to anticipated demand increases for products, various new product launches, and higher than normal seasonal inventory build.  Receivable balances were elevated at 2014 year-end due to higher sales, especially in some emerging markets, along with extended credit terms in certain markets.  Operationally, the Company generally experiences a higher working capital investment in the second and third quarters of each year as a result of stronger seasonal activity in the building, agricultural, and other industries in the Northern Hemisphere.  To the extent the Company potentially grows further in the Southern Hemisphere, this historical pattern may moderate.

[0000038725-16-000276:mdna:135]
Investing Activities

[0000038725-16-000276:mdna:136]
Net cash used in investing activities was $29.6 million in 2015 compared to $77.7 million in 2014 and $76.5 million in 2013. During 2015, the Company used less cash for acquisitions and equity investment purchases compared to 2014.  In addition, cash used for capital expenditures during 2015 was less than previous years as 2014 saw the completion of a new manufacturing facility in Brazil and 2013 saw the completion of the new Global Corporate Headquarters and Engineering Center.  During 2014, the Company completed the acquisitions of Bombas Leao S.A. (“Bombas Leao”), with cash on hand and short-term borrowings repaid within the year, and two entities in India, with cash on hand.  Capital spending in 2014 was down approximately $32.0 million from 2013.  Additions to property, plant, and equipment in 2013 were primarily attributed to the new 110,000 square foot Global Corporate Headquarters and Engineering Center and the new manufacturing facility in Brazil.  The Company's rationale and strategy for potential future acquisitions that impact cash flows from investing activities includes an emphasis on increasing global distribution and complementary product lines that can be effectively marketed through existing global distribution.

[0000038725-16-000276:mdna:137]
Financing Activities

[0000038725-16-000276:mdna:138]
Net cash flows from financing activities were uses of cash of $41.1 million in 2015 compared to $44.3 million in 2014 and cash provided of $11.1 million in 2013.  During 2015, the Company made a payment of $20.2 million for the PPH mandatory share

[0000038725-16-000276:mdna:139]
purchase liability.  In addition, the Company used cash of $46.3 million to complete the repurchase of about 1.6 million shares of the Company’s common stock pursuant to the Company’s stock repurchase program.  Dividends in the amount of $18.9 million were paid to shareholders.  The Company also had increased debt borrowings and repayments during 2015 primarily due to the issuance of $75.0 million of debt under the New York Life Agreement, first scheduled Prudential Agreement payment of $30.0 million, and increased Revolver borrowing and repayments.  During 2014, the Company had increased debt repayments compared to 2013, primarily related to the Project Bonds and Revolver borrowings.  In addition, stock option exercises were down in 2014, which resulted in the receipt of $2.9 million of cash for the payment of exercise price compared to $14.1 million in 2013.  During 2014, the Company completed the repurchase of about 0.2 million shares of the Company’s common stock for $9.0 million pursuant to the Company’s stock repurchase program.   Dividends in the amount of $17.4 million were paid to shareholders.  At least annually the dividend policy is reviewed, and the Company attempts to purchase shares annually to offset dilution of equity awards, but market conditions may prompt a perceived more efficient alternate use of cash.  The Company in recent history has not looked to the public capital markets for financing, and under current circumstances the Company does not foresee a need to do so in the near future.

[0000038725-16-000276:mdna:140]
AGGREGATE CONTRACTUAL OBLIGATIONS

[0000038725-16-000276:mdna:141]
The majority of the Company’s contractual obligations to third parties relate to debt obligations.  In addition, the Company has certain contractual obligations for future lease payments, and purchase obligations.  The payment schedule for these contractual obligations is as follows:

[0000038725-16-000276:mdna:142]
| (In millions) |  |  |  |  |  |  |  |  | More than |
|  | Total |  | 2016 |  | 2017-2018 |  | 2019-2020 |  | 5 years |
| Debt | $ | 220.9 |  |  | $ | 32.8 |  |  | $ | 62.3 |  |  | $ | 32.6 |  |  | $ | 93.2 |  |
| Debt interest | 35.1 |  |  | 8.5 |  |  | 11.2 |  |  | 5.0 |  |  | 10.4 |  |
| Capital leases | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |
| Operating leases | 22.6 |  |  | 7.7 |  |  | 8.6 |  |  | 4.4 |  |  | 1.9 |  |
| Purchase obligations | 8.3 |  |  | 6.8 |  |  | 1.5 |  |  | — |  |  | — |  |
|  | $ | 287.0 |  |  | $ | 55.9 |  |  | $ | 83.6 |  |  | $ | 42.0 |  |  | $ | 105.5 |  |

[0000038725-16-000276:mdna:143]
The calculated interest was based on the fixed rate of 5.79 percent for the Company’s $120.0 million Prudential Agreement debt, a fixed rate of 3.60 percent for the Company's $22.8 million Project Bonds, a floating interest rate of one-month USD LIBOR as of January 2, 2016 plus a spread of 1.35 percent for the Company's $75.0 million New York Life Agreement, and other various loans of $3.1 million with interest rates ranging from 0.5% to 12.5% with maturity dates ranging from 2016 to 2027.

[0000038725-16-000276:mdna:144]
Purchase obligations include commitments primarily for capital expenditures and the purchase of raw materials to be used in production.

[0000038725-16-000276:mdna:145]
The Company has pension and other post-retirement benefit obligations not included in the table above which will result in estimated future payments of approximately $7 million in 2016.  The Company also has unrecognized tax benefits, none of which are included in the table above.  The unrecognized tax benefits of approximately $2.4 million have been recorded as liabilities and the Company is uncertain as to if or when such amounts may be settled.  Related to the unrecognized tax benefits, the Company has also recorded a liability for potential penalties and interest of $2.3 million.

[0000038725-16-000276:mdna:146]
ACCOUNTING PRONOUNCEMENTS

[0000038725-16-000276:mdna:147]
Adoption of New Accounting Standards

[0000038725-16-000276:mdna:148]
In November 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2015-17, Balance Sheet Classification of Deferred Taxes.  This ASU requires an entity to classify deferred tax assets and liabilities as noncurrent within a classified balance sheet.  The ASU is effective for interim and annual periods beginning after December 15, 2016, and early adoption is permitted.  Entities can elect either prospective or retrospective adoption of the standard.  The Company early adopted the new standard on a prospective basis as of the fiscal year-ended January 2, 2016.  Accordingly, classification of prior period deferred tax amounts were not retrospectively adjusted.

[0000038725-16-000276:mdna:149]
In February 2015, the FASB issued Accounting Standards Update ASU 2015-02, Consolidation (Topic 810), Amendments to the Consolidation Analysis. The amendments affect both the variable interest entity and voting interest entity consolidation models. The need to assess an entity under a different consolidation model may change previous consolidation conclusions. The standard is effective for both interim and annual reporting periods beginning after December 15, 2015 and early adoption is

[0000038725-16-000276:mdna:150]
permitted. The Company has adopted this standard with no impact on the Company's consolidated financial position, results of operations, cash flows, or related disclosures.

[0000038725-16-000276:mdna:151]
Accounting Standards Issued But Not Yet Adopted

[0000038725-16-000276:mdna:152]
In September 2015, the FASB issued ASU 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments. The ASU will require an acquirer to recognize provisional amounts that are identified during the measurement period in the reporting period in which the adjustment amounts are determined rather than restating prior periods. The ASU will be effective on a prospective basis for interim and annual period beginning after December 15, 2015. The Company will adopt this new standard beginning with the 2016 fiscal year, and does not expect the adoption of this standard to have a material impact on the Company's consolidated financial position, results of operations, cash flows, or related disclosures.

[0000038725-16-000276:mdna:153]
In July 2015, the FASB issued ASU 2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory. The ASU will change the measurement principle for inventory from the lower of cost or market to the lower of cost and net realizable value. Net realizable value is defined as the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. ASU 2015-11 eliminates the guidance that entities consider replacement cost or net realizable value less an approximately normal profit margin in the subsequent measurement of inventory when cost is determined on a first-in, first-out or average cost basis. The ASU will be effective on a prospective basis for interim and annual periods beginning after December 15, 2016, and early adoption is permitted. The Company plans to early adopt this standard beginning with the 2016 fiscal year, but does not expect the adoption of this standard to have a material impact on the Company's consolidated financial position, results of operations, or related disclosures.

[0000038725-16-000276:mdna:154]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other Internal-Use Software (Subtopic 350-40): Customer's Accounting for Fees Paid in a Cloud Computing Agreement. The ASU will require an entity's management to assess, for each annual and interim period, whether a cloud computing arrangement includes a software license. All software licenses within the scope of Subtopic 350-40 will be accounted for consistent with other licenses of intangible assets. If the arrangement does not include a software license, the arrangement should be accounted for as a service contract. The ASU will be effective for interim and annual periods beginning after December 15, 2015 and early adoption is permitted. Entities will have the choice of prospective or retrospective adoption of the standard. The Company does not expect the adoption of this standard beginning in the 2016 fiscal year to have a material impact on the Company's consolidated financial position, results of operations, cash flows, or related disclosures.

[0000038725-16-000276:mdna:155]
In April 2015, the FASB issued ASU 2015-04, Compensation - Retirement Benefits (Topic 715): Practical Expedient for the Measurement Date of an Employer's Defined Benefit Obligation and Plan Assets, which allows an entity a practical expedient to measure defined benefit plan assets and obligations using the month end date that is closest to the entity's fiscal year end and apply that practical expedient consistently from year to year. The practical expedient should be applied consistently to all plans if the entity has more than one plan. The ASU will be effective on a prospective basis for interim and annual periods beginning after December 15, 2015 and early adoption is permitted. The Company does not currently plan on electing the practical expedient for the 2016 fiscal year.

[0000038725-16-000276:mdna:156]
In April 2015, the FASB issued ASU 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs, which requires debt issuance costs to be presented in the balance sheet as a direct deduction from the associated debt liability. The standard will not change the amortization of debt issuance costs, which will continue to follow the existing accounting guidance. In August 2015, the FASB issued ASU 2015-15, Interest-Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements, which indicates the SEC staff would not object to an entity deferring and presenting debt issuance costs related to line-of-credit arrangements as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. These ASU's will be effective on a retrospective basis for interim and annual periods beginning after December 15, 2015 and early adoption is permitted. These new standards will be adopted by the Company beginning with the 2016 fiscal year with the required change in accounting principle disclosures. The Company does not expect the adoption of these standards to have a material impact on the Company's consolidated financial position, results of operations, cash flows, or related disclosures.

[0000038725-16-000276:mdna:157]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance. In August 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date. The amendment in this update defers the effective date of ASU 2014-09 for all entities by one year to annual periods beginning after December 15, 2017. Early adoption is permitted as of the original effective date, interim and annual reporting periods after December 15, 2016. Entities have the option of using either a full

[0000038725-16-000276:mdna:158]
retrospective or a modified retrospective approach to adopt ASU 2014-09. The Company is still in the process of analyzing the effect of this new standard, including the transition method, to determine the impact on the Company's consolidated financial position, results of operations, cash flows, or related disclosures.

[0000038725-16-000276:mdna:159]
CRITICAL ACCOUNTING ESTIMATES

[0000038725-16-000276:mdna:160]
Management’s discussion and analysis of its financial condition and results of operations are based upon the Company’s consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America.  The preparation of these financial statements requires management to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and the related disclosure of contingent assets and liabilities.  Management evaluates its estimates on an ongoing basis.  Estimates are based on historical experience and on other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources.  Actual results may differ from these estimates under different assumptions or conditions.  There were no material changes to estimates or methodologies used to develop those estimates in 2015.

[0000038725-16-000276:mdna:161]
The Company’s critical accounting estimates are identified below:

[0000038725-16-000276:mdna:162]
Allowance for Uncollectible Accounts

[0000038725-16-000276:mdna:163]
Accounts receivable is comprised of balances due from customers net of estimated allowances for uncollectible accounts.  In determining allowances, historical collection experience, current trends, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are analyzed to arrive at appropriate allowances.  Allowance levels change as customer-specific circumstances and the other analysis areas previously noted change.  Based on current knowledge, the Company does not believe there is a reasonable likelihood that there will be a material change in the estimates or assumptions used to determine the allowance.

[0000038725-16-000276:mdna:164]
Inventory Valuation

[0000038725-16-000276:mdna:165]
The Company uses certain estimates and judgments to value inventory.  Inventory is recorded at the lower of cost or market. The Company reviews its inventories for excess or obsolete products or components.  Based on an analysis of historical usage, management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts, carrying values are adjusted.  The carrying value is reduced regularly to reflect the age and current anticipated product demand.  If actual demand differs from the estimates, additional reductions would be necessary in the period such determination is made.  Excess and obsolete inventory is periodically disposed of through sale to third parties, scrapping, or other means.

[0000038725-16-000276:mdna:166]
Business Combinations

[0000038725-16-000276:mdna:167]
The Company follows the guidance under FASB ASC Topic 805, Business Combinations.  The acquisition purchase price is allocated to the assets acquired and liabilities assumed based upon their respective fair values.  The Company shall report in its financial statements provisional amounts for the items for which accounting is incomplete.  Goodwill is adjusted for any changes to provisional amounts made within the measurement period.  The Company utilizes management estimates and an independent third-party valuation firm to assist in determining the fair values of assets acquired and liabilities assumed.  Such estimates and valuations require the Company to make significant assumptions, including projections of future events and operating performance.

[0000038725-16-000276:mdna:168]
Redeemable Noncontrolling Interest

[0000038725-16-000276:mdna:169]
The Company held three redeemable noncontrolling interests during 2015.  The noncontrolling interests were recorded at fair value as of the acquisition date.  The noncontrolling interest holders have the option to require the Company to redeem their ownership interests in the future with cash.  The redemption value will be derived using a specified formula based on an earnings multiple adjusted by the net debt position, subject to a redemption floor value at the time of redemption.  An assessment to compare redemption value to carrying value is performed on a quarterly basis.  In 2015, the redemption value for one of the redeemable noncontrolling interests exceeded the carrying value; therefore, $0.8 million of redemption value adjustments were made.  In 2014 and 2013, $0.9 million and $0.2 million of redemption value adjustments were made, respectively.  As a result, an adjustment to the earnings per share computation was necessary in 2015, 2014, and 2013.

[0000038725-16-000276:mdna:170]
Trade Names and Goodwill

[0000038725-16-000276:mdna:171]
According to FASB ASC Topic 350, Intangibles – Goodwill and Other, intangible assets with indefinite lives must be tested for impairment at least annually or more frequently as warranted by triggering events that indicate potential impairment.  The Company uses a variety of methodologies in conducting impairment assessments including income and market approaches that utilize discounted cash flow models, which the Company believes are consistent with hypothetical market data.  For indefinite-lived assets apart from goodwill, primarily trade names for the Company, if the fair value is less than the carrying amount, an

[0000038725-16-000276:mdna:172]
impairment charge is recognized in an amount equal to that excess.  The Company has not made any material changes to the method of evaluating impairments during the last three years.

[0000038725-16-000276:mdna:173]
In compliance with FASB ASC Topic 350, goodwill is not amortized.  Goodwill is tested at the reporting unit level for impairment annually or more frequently as warranted by triggering events that indicate potential impairment.  Reporting units are operating segments or one level below, known as components, which can be aggregated for testing purposes.  The Company’s goodwill is allocated to the North America Water Systems, International Water, and Fueling Systems units, as components within the North America Water Systems and International Water reporting units can be aggregated.  As the Company’s business model evolves, management will continue to evaluate its reporting units and review the aggregation criteria.

[0000038725-16-000276:mdna:174]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the market value and income approaches.  The market value approach compares the reporting units' current and projected financial results to entities of similar size and industry to determine the market value of the reporting unit.  The income approach utilizes assumptions regarding estimated future cash flows and other factors to determine the fair value of the respective assets.  These cash flows consider factors regarding expected future operating income and historical trends, as well as the effects of demand and competition.  The Company may be required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units is below their associated carrying values.  Goodwill included on the balance sheet as of the fiscal year ended 2015 was $199.8 million.

[0000038725-16-000276:mdna:175]
During the fourth quarter of 2015, the Company completed its annual impairment test of intangibles and determined the fair value of all intangibles were substantially in excess of the respective carrying values.  Significant judgment is required to determine if an indication of impairment has taken place.  Factors to be considered include the following: adverse changes in operating results, decline in strategic business plans, significantly lower future cash flows, and sustainable declines in market data such as market capitalization.  A 10 percent decrease in the fair value estimates used in the impairment test would not have changed this determination.  The sensitivity analysis required the use of numerous subjective assumptions, which, if actual experience varies, could result in material differences in the requirements for impairment charges.  Further, an extended downturn in the economy may impact certain components of the operating segments more significantly and could result in changes to the aggregation assumptions and impairment determination.

[0000038725-16-000276:mdna:176]
Income Taxes

[0000038725-16-000276:mdna:177]
Under the requirements of FASB ASC Topic 740, Income Taxes, the Company records deferred tax assets and liabilities for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases.  Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled.  The Company analyzes the deferred tax assets and liabilities for their future realization based on the estimated existence of sufficient taxable income.  This analysis considers the following sources of taxable income: prior year taxable income, future reversals of existing taxable temporary differences, future taxable income exclusive of reversing temporary differences and tax planning strategies that would generate taxable income in the relevant period.  If sufficient taxable income is not projected then the Company will record a valuation allowance against the relevant deferred tax assets.  The Company operates in multiple tax jurisdictions with different tax rates, and determines the allocation of income to each of these jurisdictions based upon various estimates and assumptions.  In the normal course of business, the Company will undergo tax audits by various tax jurisdictions.  Such audits often require an extended period of time to complete and may result in income tax adjustments if changes to the allocation are required between jurisdictions with different tax rates.  Although the Company has recorded all probable income tax uncertainties in accordance with FASB ASC Topic 740, these accruals represent estimates that are subject to the inherent uncertainties associated with the tax audit process, and therefore include uncertainties.  Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, which, if actual experience varies, could result in material adjustments to deferred tax assets and liabilities.  The Company’s operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions.  The final taxes paid are dependent upon many factors, including negotiations with taxing authorities in various jurisdictions and resolution of disputes arising from federal, state, and international tax audits.

[0000038725-16-000276:mdna:178]
Pension and Employee Benefit Obligations

[0000038725-16-000276:mdna:179]
With the assistance of the Company’s actuaries, the discount rates used to determine pension and post-retirement plan liabilities are calculated using a yield-curve approach.  The yield-curve approach discounts each expected cash flow of the liability stream at an interest rate based on high quality corporate bonds.  The present value of the discounted cash flows is summed and an equivalent weighted-average discount rate is calculated.  Market conditions have caused the weighted-average discount rate to move from 3.95 percent last year to 4.37 percent this year for the domestic pension plans and from 3.75 percent last year to 4.09 percent this year for the postretirement health and life insurance plan.  A change in the discount rate selected by the

[0000038725-16-000276:mdna:180]
Company of 25 basis points would result in no change to employee benefit expense and a change of about $4.5 million of liability.  The Company consults with actuaries and investment advisors in making its determination of the expected long-term rate of return on plan assets.  Using input from these consultations such as long-term investment sector expected returns, the correlations and standard deviations thereof, and the plan asset allocation, the Company has assumed an expected long-term rate of return on plan assets of 6.50 percent as of the fiscal year ended 2015.   A change in the long-term rate of return selected by the Company of 25 basis points would result in a change of about $0.3 million of employee benefit expense.  According to FASB ASC 715, Compensation - Retirement Benefits, settlement accounting is triggered when lump sum payouts from a defined benefit plan exceed the sum of service cost and interest cost for the year.  During 2015, one of the Company’s domestic pension plans required settlement accounting as a payout to a participant exceeded these criteria. For the fiscal year ended January 2, 2016, the Company used the RP-2014 aggregate table projected using Scale MP-2015 released by the Society of Actuaries during 2015 to estimate future mortality rates based upon current data.

[0000038725-16-000276:mdna:181]
Share-Based Compensation

[0000038725-16-000276:mdna:182]
The fair value of each option award is estimated on the date of grant using the Black-Scholes option valuation model with a single approach and amortized using a straight-line attribution method over the option’s vesting period.  Options granted to retirement eligible employees are immediately expensed.  Restricted awards and units granted to retirement eligible employees are expensed over the vesting period as the employee will receive a pro-rata number of shares upon their retirement.  The Company uses historical data to estimate the expected volatility of its stock, the weighted average expected life, the period of time options granted are expected to be outstanding, and its dividend yield.  The risk-free rates for periods within the contractual life of the option are based on the U.S. Treasury yield curve in effect at the time of the grant.

[0000038725-16-000276:mdna:183]
FACTORS THAT MAY AFFECT FUTURE RESULTS
