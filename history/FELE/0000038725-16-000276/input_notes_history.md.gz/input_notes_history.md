# FELE note change history — 0000038725-15-000161 → 0000038725-15-000195


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-03):
[0000038725-15-000195:note_history:1]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company filed its response brief on December 23, 2014 and CARB filed its Reply brief on February 2, 2015.  On September 29, 2015, both sides made oral arguments in front of the California Court of Appeals. The Appellate Court has ninety days to issue a ruling.
  (was, 2015-08-04, similarity 0.7755):
[0000038725-15-000161:note_history:1]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company filed its response brief on December 23, 2014 and CARB filed its reply brief on February 2, 2015.  On July 29, 2015, the Court of Appeals issued a Calendar Notice for oral argument scheduled for August 25, 2015.  Both the Company and CARB have ten days to either confirm or waive the oral argument.

- changed (2015-11-03):
[0000038725-15-000195:note_history:2]
counsel, these claims and legal actions can be successfully defended or resolved without a material effect on the
  (was, 2015-08-04, similarity 0.9658):
[0000038725-15-000161:note_history:2]
counsel, these claims and legal actions can be successfully defended or resolved without a material adverse effect on the

- changed (2015-11-03):
[0000038725-15-000195:note_history:3]
At October 3, 2015, the Company had $12.4 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2015-08-04, similarity 0.9622):
[0000038725-15-000161:note_history:3]
At July 4, 2015, the Company had $11.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2015-11-03):
[0000038725-15-000195:note_history:4]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended October 3, 2015, are as follows:
  (was, 2015-08-04, similarity 0.9622):
[0000038725-15-000161:note_history:4]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended July 4, 2015, are as follows:

- changed (2015-11-03):
[0000038725-15-000195:note_history:5]
| (In millions) |  |  |
| Balance as of January 3, 2015 |  | $ | 9.4 |  |
| Accruals related to product warranties |  | 5.5 |  |
| Reductions for payments made |  | (5.8 | ) |
| Balance as of October 3, 2015 |  | $ | 9.1 |  |
  (was, 2015-08-04, similarity 0.9723):
[0000038725-15-000161:note_history:5]
| (In millions) |  |  |
| Balance as of January 3, 2015 |  | $ | 9.4 |  |
| Accruals related to product warranties |  | 3.7 |  |
| Reductions for payments made |  | (3.8 | ) |
| Balance as of July 4, 2015 |  | $ | 9.3 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-03):
[0000038725-15-000195:note_history:6]
The accompanying condensed consolidated balance sheet as of January 3, 2015, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of October 3, 2015, and for the third quarter and nine months ended October 3, 2015 and September 27, 2014, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the third quarter and nine months ended October 3, 2015, are not necessarily indicative of the results that may be expected for the fiscal year ending January 2, 2016.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K for the year ended January 3, 2015.
  (was, 2015-08-04, similarity 0.9294):
[0000038725-15-000161:note_history:6]
The accompanying condensed consolidated balance sheet as of January 3, 2015, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of July 4, 2015, and for the second quarters and six months ended July 4, 2015 and June 28, 2014, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the second quarter and six months ended July 4, 2015, are not necessarily indicative of the results that may be expected for the fiscal year ending January 2, 2016.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K for the year ended January 3, 2015.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-03):
[0000038725-15-000195:note_history:7]
| (In millions) |  | October 3, 2015 |  | January 3, 2015 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 22.8 |  |  | 23.7 |  |
| New York Life |  | 75.0 |  |  | — |  |
| Revolver |  | 20.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 4.9 |  |  | 3.5 |  |
|  |  | $ | 243.3 |  |  | 177.8 |  |
| Less current maturities |  | (55.1 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 188.2 |  |  | $ | 143.7 |  |
  (was, 2015-08-04, similarity 0.9868):
[0000038725-15-000161:note_history:7]
| (In millions) |  | July 4, 2015 |  | January 3, 2015 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.2 |  |  | 23.7 |  |
| New York Life |  | 75.0 |  |  | — |  |
| Revolver |  | 4.0 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 3.0 |  |  | 3.5 |  |
|  |  | $ | 225.3 |  |  | 177.8 |  |
| Less current maturities |  | (37.5 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 187.8 |  |  | $ | 143.7 |  |

- added (2015-11-03):
[0000038725-15-000195:note_history:8]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025.  These series notes have a floating interest rate of one-month USD LIBOR plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  The New York Life Agreement contains customary affirmative and negative covenants and a cross default provision in the event the Company defaults on any obligation exceeding $10.0 million.  As of October 3, 2015, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

- added (2015-11-03):
[0000038725-15-000195:note_history:9]
On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc. (the "Prudential Agreement") to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of October 3, 2015, $120.0 million was outstanding under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.  As of October 3, 2015, the Company had $100.0 million borrowing capacity under the Prudential Agreement.

- removed (2015-11-03):
[0000038725-15-000161:note_history:10]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025.  These series notes have a floating interest rate with interest-only payments due on a monthly basis.  The New York Life Agreement contains customary affirmative and negative covenants and a cross default provision in the event the Company defaults on any obligation exceeding $10.0 million.  As of July 4, 2015, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

- removed (2015-11-03):
[0000038725-15-000161:note_history:11]
On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc. (the "Prudential Agreement") to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of July 4, 2015, $120.0 million was outstanding under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.  As of July 4, 2015, the Company had $100.0 million borrowing capacity under the Prudential Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-03):
[0000038725-15-000195:note_history:12]
| (In millions) |  | October 3, 2015 |  | January 3, 2015 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 22.8 |  |  | 23.7 |  |
| New York Life |  | 75.0 |  |  | — |  |
| Revolver |  | 20.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 4.9 |  |  | 3.5 |  |
|  |  | $ | 243.3 |  |  | 177.8 |  |
| Less current maturities |  | (55.1 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 188.2 |  |  | $ | 143.7 |  |
  (was, 2015-08-04, similarity 0.9868):
[0000038725-15-000161:note_history:12]
| (In millions) |  | July 4, 2015 |  | January 3, 2015 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.2 |  |  | 23.7 |  |
| New York Life |  | 75.0 |  |  | — |  |
| Revolver |  | 4.0 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 3.0 |  |  | 3.5 |  |
|  |  | $ | 225.3 |  |  | 177.8 |  |
| Less current maturities |  | (37.5 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 187.8 |  |  | $ | 143.7 |  |
