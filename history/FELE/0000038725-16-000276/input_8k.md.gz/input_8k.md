# FELE 8-K — 0000038725-16-000253 filed 2016-02-23

## item codes, every 8-K on or before 2016-03-02

- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2016-03-02

- none on or before 2016-03-02

## item 2.02 — earnings release, exhibit 99.1

[0000038725-16-000253:8k_2_02:1]
EX-99.1
2
a201602238-kexhibit991.htm
EXHIBIT 99.1

[0000038725-16-000253:8k_2_02:2]
Exhibit

[0000038725-16-000253:8k_2_02:3]
Exhibit 99.1

[0000038725-16-000253:8k_2_02:4]
For Immediate Release

[0000038725-16-000253:8k_2_02:5]
For Further Information

[0000038725-16-000253:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-16-000253:8k_2_02:7]
260-824-2900

[0000038725-16-000253:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS RECORD FOURTH QUARTER

[0000038725-16-000253:8k_2_02:9]
2015 EARNINGS

[0000038725-16-000253:8k_2_02:10]
Fort Wayne, Indiana - February 23, 2016 - Franklin Electric Co., Inc. (NASDAQ:FELE) reported fourth quarter 2015 adjusted earnings per share (EPS) of $0.35, a record for any fourth quarter, compared to 2014 fourth quarter adjusted EPS of $0.31, a 13 percent increase (see table below for a reconciliation of GAAP EPS to the adjusted EPS).  In the fourth quarter of 2015, the Company’s GAAP fully diluted EPS was $0.33, also a record for any fourth quarter, up 450 percent to the GAAP fully diluted EPS of $0.06 from the fourth quarter of 2014.  The GAAP fully diluted EPS in the fourth quarter of 2014 included a restructuring charge of $0.22 per share related to rationalizing our European manufacturing footprint.

[0000038725-16-000253:8k_2_02:11]
Fourth quarter 2015 sales were $219.3 million, a decrease of 14 percent compared to 2014 fourth quarter sales of $253.8 million.  The Company’s organic sales decline was 5 percent excluding acquisitions and the impact of foreign currency translation.

[0000038725-16-000253:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-16-000253:8k_2_02:13]
“We are pleased to report that our earnings for the fourth quarter were a record for any fourth quarter in the Company’s history. The top line impact of the strong dollar and the weak price of oil and other commodities was offset by margin expansion due to reductions in fixed costs, variable compensation expense, input costs and pricing. After non-GAAP adjustments, Water Systems operating income declined 2 percent on a 17 percent sales decline, and Fueling Systems operating income increased 8 percent on a 2 percent sales decline. Excluding the impact of foreign exchange and the decline in the price of oil, sales were flat compared to the fourth quarter 2014. Demand in our U.S. water business remains weak; however, we saw a slight sequential improvement in the year-over-year quarterly decline.  Organic sales in developing regions were positive.”

[0000038725-16-000253:8k_2_02:14]
Key Performance Indicators:

[0000038725-16-000253:8k_2_02:15]
| Earnings Before and After Non-GAAP Adjustments |  | For the Fourth Quarter |  | For the Full Year |
| (in millions) |  | 2015 | 2014 | Change |  | 2015 | 2014 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 16.2 |  | $ | 3.1 |  | 423 | % |  | $ | 72.9 |  | $ | 69.8 |  | 4 | % |
| Allocated Undistributed Earnings |  | $ | (0.5 | ) | $ | (0.3 | ) |  |  | $ | (1.5 | ) | $ | (1.6 | ) |  |
| Adjusted Earnings for EPS Calculations |  | $ | 15.7 |  | $ | 2.8 |  | 461 | % |  | $ | 71.4 |  | $ | 68.2 |  | 5 | % |
| Non-GAAP adjustments (before tax): |  |  |  |  |  |  |  |  |
| Restructuring |  | $ | 0.5 |  | $ | 15.1 |  |  |  | $ | 3.0 |  | $ | 16.6 |  |  |
| Non-GAAP items |  | $ | 0.4 |  | $ | 2.5 |  |  |  | $ | 2.1 |  | $ | 7.7 |  |  |
| Pioneer tax benefits on equity gain |  | $ | — |  | $ | — |  |  |  | $ | (4.8 | ) | - |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |  |  |  |  |
| Restructuring |  | $ | 0.3 |  | $ | 10.5 |  |  |  | $ | 1.8 |  | $ | 11.4 |  |  |
| Non-GAAP items |  | $ | 0.2 |  | $ | 1.5 |  |  |  | $ | 1.3 |  | $ | 4.7 |  |  |
| Pioneer tax benefits on equity gain |  | $ | — |  | $ | — |  |  |  | $ | (4.8 | ) | $ | — |  |  |
| Earnings after Non-GAAP Adjustments |  | $ | 16.2 |  | $ | 14.8 |  | 9 | % |  | $ | 69.7 |  | $ | 84.3 |  | (17 | )% |
| Earnings Per Share |  | For the Fourth Quarter |  | For the Full Year |
| Before and After Non-GAAP Adjustments |  | 2015 | 2014 | Change |  | 2015 | 2014 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.7 |  | 48.1 |  | (3 | )% |  | 47.6 |  | 48.2 |  | (1 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.33 |  | $ | 0.06 |  | 450 | % |  | $ | 1.50 |  | $ | 1.41 |  | 6 | % |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | 0.22 |  |  |  | $ | 0.04 |  | $ | 0.24 |  |  |
| Non-GAAP items, net of tax |  | $ | 0.01 |  | $ | 0.03 |  |  |  | $ | 0.03 |  | $ | 0.11 |  |  |
| Pioneer tax benefits on equity gain |  | $ | — |  | $ | — |  |  |  | $ | (0.10 | ) | $ | — |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments(Adjusted EPS) |  | $ | 0.35 |  | $ | 0.31 |  | 13 | % |  | $ | 1.47 |  | $ | 1.76 |  | (16 | )% |

[0000038725-16-000253:8k_2_02:16]
| Net Sales | For the Fourth Quarter |  | For the Full Year |
| (in millions) | Water | Fueling | Consolidated |  | Water | Fueling | Consolidated |
| Sales for 2014 | $ | 196.7 |  | $ | 57.1 |  | $ | 253.8 |  |  | $ | 824.6 |  | $ | 223.2 |  | $ | 1,047.8 |  |
| Acquisitions | $ | 1.3 |  | $ | — |  | $ | 1.3 |  |  | $ | 20.8 |  | $ | 0.5 |  | $ | 21.3 |  |
| Foreign currency translation | $ | (20.9 | ) | $ | (2.0 | ) | $ | (22.9 | ) |  | $ | (78.3 | ) | $ | (11.0 | ) | $ | (89.3 | ) |
| Volume/Price Change | $ | (13.9 | ) | $ | 1.0 |  | $ | (12.9 | ) |  | $ | (59.5 | ) | $ | 4.6 |  | $ | (54.9 | ) |
| Sales for 2015 | $ | 163.2 |  | $ | 56.1 |  | $ | 219.3 |  |  | $ | 707.6 |  | $ | 217.3 |  | $ | 924.9 |  |

[0000038725-16-000253:8k_2_02:17]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Fourth Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 20.0 |  | $ | 14.1 |  | $ | (10.5 | ) | $ | 23.6 |  |
| % Operating Income To Net Sales | 12.3 | % | 25.1 | % |  | 10.8 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.5 |  | $ | — |  | $ | — |  | $ | 0.5 |  |
| Non-GAAP | $ | 0.1 |  | $ | — |  | $ | 0.3 |  | $ | 0.4 |  |
| Operating Income after Non-GAAP Adjustments | $ | 20.6 |  | $ | 14.1 |  | $ | (10.2 | ) | $ | 24.5 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.6 | % | 25.1 | % |  | 11.2 | % |
|  | For the Fourth Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 4.7 |  | $ | 11.7 |  | $ | (13.8 | ) | $ | 2.6 |  |
| % Operating Income To Net Sales | 2.4 | % | 20.5 | % |  | 1.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 14.7 |  | $ | 0.4 |  | $ | — |  | $ | 15.1 |  |
| Non-GAAP | $ | 1.6 |  | $ | 0.9 |  | $ | — |  | $ | 2.5 |  |
| Operating Income after Non-GAAP Adjustments | $ | 21.0 |  | $ | 13.0 |  | $ | (13.8 | ) | $ | 20.2 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 10.7 | % | 22.8 | % |  | 8.0 | % |

[0000038725-16-000253:8k_2_02:18]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Full Year of 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 86.7 |  | $ | 51.5 |  | $ | (47.8 | ) | $ | 90.4 |  |
| % Operating Income To Net Sales | 12.3 | % | 23.7 | % |  | 9.8 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 2.7 |  | $ | 0.3 |  | $ | — |  | $ | 3.0 |  |
| Non-GAAP | $ | 0.7 |  | $ | 0.2 |  | $ | 1.2 |  | $ | 2.1 |  |
| Operating Income after Non-GAAP Adjustments | $ | 90.1 |  | $ | 52.0 |  | $ | (46.6 | ) | $ | 95.5 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.7 | % | 23.9 | % |  | 10.3 | % |
|  | For the Full Year of 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 103.9 |  | $ | 49.7 |  | $ | (53.5 | ) | $ | 100.1 |  |
| % Operating Income To Net Sales | 12.6 | % | 22.3 | % |  | 9.6 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 16.1 |  | $ | 0.5 |  | $ | — |  | $ | 16.6 |  |
| Non-GAAP | $ | 3.7 |  | $ | 1.5 |  | $ | 2.5 |  | $ | 7.7 |  |
| Operating Income after Non-GAAP Adjustments | $ | 123.7 |  | $ | 51.7 |  | $ | (51.0 | ) | $ | 124.4 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.0 | % | 23.2 | % |  | 11.9 | % |

[0000038725-16-000253:8k_2_02:19]
Water Systems

[0000038725-16-000253:8k_2_02:20]
Water Systems sales were $163.2 million in the fourth quarter 2015, a decrease of $33.5 million or about 17 percent versus the fourth quarter 2014 sales of $196.7 million.  Water Systems sales were reduced by $20.9 million or about 11 percent in the quarter due to foreign currency translation.  Excluding foreign currency translation, Water Systems sales declined about 6 percent compared to the fourth quarter 2014.

[0000038725-16-000253:8k_2_02:21]
Water Systems sales in the U.S. and Canada represented 33 percent of consolidated sales and declined by about 19 percent compared to the prior year. Water Systems sales in the U.S and Canada were reduced by about 2 percent in the quarter due to foreign currency translation.  In the fourth quarter 2015, U.S. and Canada sales of mobile dewatering equipment declined by about 50 percent. The decline in mobile dewatering equipment is primarily attributed to reduced demand in the oil and gas end markets.  Sales of groundwater pumping equipment declined by about 15 percent.  The decline in groundwater equipment sales is attributable primarily to continued weakness in agricultural related products.  Finally, sales of surface water pumping equipment declined by about 8 percent versus the fourth quarter 2014, primarily due to lower wastewater product sales.

[0000038725-16-000253:8k_2_02:22]
Water Systems sales in Latin America were about 14 percent of consolidated sales for the fourth quarter and declined by about 24 percent compared to the fourth quarter of the prior year.  Water Systems sales were reduced by $10.8 million or about 26 percent in the quarter due to foreign currency translation.

[0000038725-16-000253:8k_2_02:23]
Excluding the impact of foreign currency translation, Latin American sales increased by about 2 percent compared to the fourth quarter 2014.  This growth in sales was led by increased sales in Central America and Argentina.  Sales of Water Systems products in Brazil increased about 1 percent in local currency during the fourth quarter.

[0000038725-16-000253:8k_2_02:24]
Water Systems sales in the Middle East and Africa were about 12 percent of consolidated sales and decreased by about 9 percent compared to the fourth quarter 2014.  Water Systems sales were reduced by about 17 percent in the quarter due to foreign currency translation.  Excluding the impact of foreign currency translation, sales increased by about 8 percent compared to the fourth quarter 2014. The growth was across all major product lines and was driven by strong sales in the Gulf and Near East countries, mainly Turkey.

[0000038725-16-000253:8k_2_02:25]
Water Systems sales in the Asia Pacific region were 9 percent of consolidated sales and were down about 4 percent compared to the fourth quarter prior year.  The impact of foreign currency translation decreased sales by about 5 percent compared to the fourth quarter 2014.  Excluding the impact of foreign currency translation, Asia Pacific sales increased by about 1 percent compared to the fourth quarter 2014.  The Asia Pacific region experienced growth in groundwater product sales of about 4 percent, but this improvement was offset by a decline in mobile dewatering equipment.

[0000038725-16-000253:8k_2_02:26]
Water Systems sales in Europe were about 6 percent of consolidated sales and decreased by about 20 percent compared to the fourth quarter 2014.  The impact of foreign currency translation decreased sales by about 15 percent compared to the fourth quarter 2014.  Excluding currency translation, European sales were down about 5 percent versus the fourth quarter of 2014. The decline was due to lower mobile dewatering equipment sales.

[0000038725-16-000253:8k_2_02:27]
Water Systems operating income, after non-GAAP adjustments, was $20.6 million in the fourth quarter 2015, down $0.4 million or 2 percent versus the fourth quarter 2014. The fourth quarter operating income margin after non-GAAP adjustments was 12.6 percent, up 190 basis points from 10.7 percent in the fourth quarter of 2014.

[0000038725-16-000253:8k_2_02:28]
Fueling Systems

[0000038725-16-000253:8k_2_02:29]
Fueling Systems sales represented 26 percent of consolidated sales and were $56.1 million in the fourth quarter 2015, a decrease of $1.0 million or about 2 percent versus the fourth quarter 2014 sales of $57.1 million.  Fueling Systems sales decreased by $2.0 million or about 4 percent in the quarter due to foreign currency translation. Fueling Systems sales were up about 2 percent, after excluding foreign currency translation.

[0000038725-16-000253:8k_2_02:30]
Fueling Systems sales in the U.S. and Canada grew by about 6 percent during the quarter with most of the sales growth coming from fuel dispensing products and piping.  Fueling Systems revenues in Asia Pacific grew by about 5 percent due to increased sales in India, partially offset with lower sales in China due to the ongoing reduction in State owned oil company procurements.  Sales also declined in Europe principally due to a 65 percent decline in the sale of storage tanks that support North Sea oil production.

[0000038725-16-000253:8k_2_02:31]
Fueling Systems operating income after non-GAAP adjustments was $14.1 million in the fourth quarter of 2015 compared to $13.0 million after non-GAAP adjustments in the fourth quarter of 2014, an increase of about 8 percent. The fourth quarter operating income margin after non-GAAP adjustments was 25.1 percent, an increase of 230 basis points from the 22.8 percent of net sales in the fourth quarter of 2014.

[0000038725-16-000253:8k_2_02:32]
Overall

[0000038725-16-000253:8k_2_02:33]
The Company’s consolidated gross profit was $69.1 million for the fourth quarter of 2015, a decrease of $8.7 million, or about 11 percent, from the fourth quarter of 2014 gross profit of $77.8 million. The gross profit as a percent of net sales was 31.5 percent in the fourth quarter of 2015 and increased about 90 basis points versus 30.6 percent during the fourth quarter 2014.  The gross profit margin increase was primarily due to lower direct material costs and an improved sales mix of Water Systems products.

[0000038725-16-000253:8k_2_02:34]
Selling, general, and administrative (SG&A) expenses were $45.1 million in the fourth quarter of 2015 compared to $60.1 million in the fourth quarter of the prior year, a decrease of $15.0 million or about 25 percent.  The Company’s SG&A expenses decreased in the quarter primarily due to lower marketing and selling-related expenses, as well as lower costs for incentive compensation.  About 20 percent of the SG&A expense decline was related to foreign exchange.

[0000038725-16-000253:8k_2_02:35]
The Company ended the fourth quarter of 2015 with a cash balance of $81.6 million, which was $22.5 million higher than at the end of 2014.  The cash balance increase is primarily attributable to cash generated from operations for the full year 2015 of about $98.3 million, or 133 percent of reported net income.

[0000038725-16-000253:8k_2_02:36]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-16-000253:8k_2_02:37]
“Looking forward to 2016, we will have an exchange rate headwind which at current rates would reduce sales by $40 million and earnings per share by $0.08, when compared to 2015 results. We believe that we will overcome this headwind. Our plan is for two to four percent revenue growth and 2016 adjusted earnings per share to be between $1.57 and $1.67.  Similar to other companies that have already provided results and guidance, we anticipate the year to start slow and gain momentum as the Northern Hemisphere moves into late spring.”

[0000038725-16-000253:8k_2_02:38]
A conference call to review earnings and other developments in the business will commence at 9:00 am EST.  The fourth quarter 2015 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-16-000253:8k_2_02:39]
http://edge.media-server.com/m/p/ytnrkiqm

[0000038725-16-000253:8k_2_02:40]
If you intend to ask questions during the call, please dial in using (877) 643-7158 for domestic calls and (914) 495-8565 for international calls.  The Conference ID is: 48713989.

[0000038725-16-000253:8k_2_02:41]
A replay of the conference call will be available Tuesday, February 23, 2016 at 12:00 noon EST through midnight EST on Tuesday, March 1, 2016, by dialing (855) 859-2056 for domestic calls and (404) 537-3406 for international calls. The replay passcode is: 48713989.

[0000038725-16-000253:8k_2_02:42]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-16-000253:8k_2_02:43]
The Company presents the non-GAAP financial measures of earnings after non-GAAP adjustments, fully diluted earnings per share after non-GAAP adjustments (or adjusted EPS), operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments (or operating income margin after non-GAAP adjustments) because the Company believes the information helps investors understand underlying trends in the Company's business more easily. The differences between these measures and the most comparable GAAP measures are reconciled in the tables above.

[0000038725-16-000253:8k_2_02:44]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Fourth Quarter Ended |  | Fiscal Year End |
|  | January 2, 2016 |  | January 3, 2015 |  | January 2, 2016 |  | January 3, 2015 |
| Net sales | $ | 219,283 |  |  | $ | 253,837 |  |  | $ | 924,923 |  |  | $ | 1,047,777 |  |
| Cost of sales | 150,165 |  |  | 176,083 |  |  | 627,315 |  |  | 703,367 |  |
| Gross profit | 69,118 |  |  | 77,754 |  |  | 297,608 |  |  | 344,410 |  |
| Selling, general, and administrative expenses | 45,090 |  |  | 60,090 |  |  | 204,250 |  |  | 227,711 |  |
| Restructuring expense | 472 |  |  | 15,094 |  |  | 2,997 |  |  | 16,611 |  |
| Operating income | 23,556 |  |  | 2,570 |  |  | 90,361 |  |  | 100,088 |  |
| Interest expense | (2,322 | ) |  | (2,697 | ) |  | (10,039 | ) |  | (10,735 | ) |
| Other income (expense), net | 838 |  |  | (202 | ) |  | 6,863 |  |  | 1,349 |  |
| Foreign exchange expense | (830 | ) |  | (397 | ) |  | (869 | ) |  | (999 | ) |
| Income (Loss) before income taxes | 21,242 |  |  | (726 | ) |  | 86,316 |  |  | 89,703 |  |
| Income tax expense (income) | 4,991 |  |  | (3,894 | ) |  | 12,625 |  |  | 18,851 |  |
| Net income | $ | 16,251 |  |  | $ | 3,168 |  |  | $ | 73,691 |  |  | $ | 70,852 |  |
| Less: Net income attributable to noncontrolling interests | (90 | ) |  | (66 | ) |  | (746 | ) |  | (1,046 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 16,161 |  |  | $ | 3,102 |  |  | $ | 72,945 |  |  | $ | 69,806 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.34 |  |  | $ | 0.06 |  |  | $ | 1.52 |  |  | $ | 1.43 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.06 |  |  | $ | 1.50 |  |  | $ | 1.41 |  |

[0000038725-16-000253:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | January 2, 2016 |  | January 3, 2015 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 81,561 |  |  | $ | 59,141 |  |
| Receivables | 127,251 |  |  | 143,787 |  |
| Inventories | 194,594 |  |  | 220,528 |  |
| Other current assets | 34,728 |  |  | 46,083 |  |
| Total current assets | 438,134 |  |  | 469,539 |  |
| Property, plant, and equipment, net | 190,039 |  |  | 209,786 |  |
| Goodwill and other assets | 368,235 |  |  | 396,562 |  |
| Total assets | $ | 996,408 |  |  | $ | 1,075,887 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 57,822 |  |  | $ | 70,806 |  |
| Accrued expenses and other current liabilities | 53,903 |  |  | 96,207 |  |
| Current maturities of long-term debt and short-term borrowings | 32,946 |  |  | 34,092 |  |
| Total current liabilities | 144,671 |  |  | 201,105 |  |
| Long-term debt | 188,103 |  |  | 143,695 |  |
| Deferred income taxes | 33,404 |  |  | 45,568 |  |
| Employee benefit plans | 47,398 |  |  | 58,709 |  |
| Other long-term liabilities | 16,511 |  |  | 21,407 |  |
| Redeemable noncontrolling interest | 6,856 |  |  | 6,420 |  |
| Total equity | 559,465 |  |  | 598,983 |  |
| Total liabilities and equity | $ | 996,408 |  |  | $ | 1,075,887 |  |

[0000038725-16-000253:8k_2_02:46]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
| (In thousands) | 2015 |  | 2014 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 73,691 |  |  | $ | 70,852 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 35,476 |  |  | 37,210 |  |
| Share-based compensation | 5,626 |  |  | 7,471 |  |
| Realized gain on share purchase liability | (2,723 | ) |  | — |  |
| Other | (6,663 | ) |  | (2,528 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | 3,444 |  |  | (29,064 | ) |
| Inventory | 9,350 |  |  | (32,782 | ) |
| Accounts payable and accrued expenses | (19,744 | ) |  | 22,852 |  |
| Other | (194 | ) |  | (26,662 | ) |
| Net cash flows from operating activities | 98,263 |  |  | 47,349 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (26,171 | ) |  | (35,525 | ) |
| Proceeds from sale of property, plant, and equipment | 1,542 |  |  | 1,608 |  |
| Acquisitions and investments | (3,888 | ) |  | (42,315 | ) |
| Other investing activities | 274 |  |  | (1,490 | ) |
| Net cash flows from investing activities | (28,243 | ) |  | (77,722 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 43,576 |  |  | (18,823 | ) |
| Proceeds from issuance of common stock | 2,050 |  |  | 2,929 |  |
| Excess tax from share-based payment arrangements | 932 |  |  | 2,463 |  |
| Purchases of common stock | (48,579 | ) |  | (10,610 | ) |
| Dividends paid | (18,926 | ) |  | (17,421 | ) |
| Purchase of redeemable non-controlling shares | — |  |  | (2,875 | ) |
| Share purchase liability payment | (20,200 | ) |  | — |  |
| Net cash flows from financing activities | (41,147 | ) |  | (44,337 | ) |
| Effect of exchange rate changes on cash | (6,453 | ) |  | (702 | ) |
| Net change in cash and equivalents | 22,420 |  |  | (75,412 | ) |
| Cash and equivalents at beginning of period | 59,141 |  |  | 134,553 |  |
| Cash and equivalents at end of period | $ | 81,561 |  |  | $ | 59,141 |  |
