# FELE 8-K — 0000038725-22-000177 filed 2022-10-25

## item codes, every 8-K on or before 2022-11-01

- 2022-10-28 0000038725-22-000180 — 7.01, 9.01
- 2022-10-25 0000038725-22-000177 — 2.02, 9.01
- 2022-08-04 0000038725-22-000150 — 7.01, 9.01
- 2022-07-26 0000038725-22-000142 — 2.02, 9.01
- 2022-05-11 0000038725-22-000106 — 2.03, 9.01
- 2022-05-06 0000038725-22-000082 — 5.07
- 2022-05-06 0000038725-22-000081 — 5.02, 9.01
- 2022-05-03 0000038725-22-000075 — 7.01, 9.01
- 2022-04-26 0000038725-22-000073 — 2.02, 9.01
- 2022-03-24 0000038725-22-000056 — 5.02, 9.01
- 2022-03-08 0000038725-22-000049 — 7.01, 9.01
- 2022-02-15 0000038725-22-000007 — 2.02, 9.01
- 2022-01-04 0000038725-22-000002 — 7.01, 9.01
- 2021-11-03 0000038725-21-000212 — 7.01, 9.01
- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2022-11-01

- none on or before 2022-11-01

## item 2.02 — earnings release, exhibit 99.1

[0000038725-22-000177:8k_2_02:1]
EX-99.1
2
a20221025ex991earningsrele.htm
EX-99.1

[0000038725-22-000177:8k_2_02:2]
Document

[0000038725-22-000177:8k_2_02:3]
Exhibit 99.1

[0000038725-22-000177:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-22-000177:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS RECORD THIRD QUARTER 2022 RESULTS

[0000038725-22-000177:8k_2_02:6]
Third Quarter 2022 Highlights

[0000038725-22-000177:8k_2_02:7]
•Record sales of $551.7 million, compared to third quarter 2021 sales of $459.0 million, an increase of 20%

[0000038725-22-000177:8k_2_02:8]
•Strong organic sales growth in all three Segments; Distribution 22%, Water Systems 19%, and Fueling Systems 13%

[0000038725-22-000177:8k_2_02:9]
•Operating income was a third quarter record at $80.0 million, compared to third quarter operating income in 2021 of $56.6 million, an increase of 41%

[0000038725-22-000177:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $1.24, a new third quarter record

[0000038725-22-000177:8k_2_02:11]
•2022 FY net sales guidance is updated to $2.0 billion to $2.1 billion and 2022 FY earnings per share excluding restructuring guidance to $4.08 to $4.18

[0000038725-22-000177:8k_2_02:12]
Fort Wayne, IN – October 25, 2022 – Franklin Electric Co. Inc. today announced third quarter financial results for fiscal year 2022.

[0000038725-22-000177:8k_2_02:13]
Third quarter 2022 sales were $551.7 million, compared to third quarter 2021 sales of $459.0 million.  Third quarter 2022 operating income was $80.0 million, compared to third quarter operating income in 2021 of $56.6 million.  Third quarter 2022 GAAP fully diluted earnings per share was $1.24, versus GAAP fully diluted EPS in the third quarter 2021 of $0.98.

[0000038725-22-000177:8k_2_02:14]
“We are pleased with the strong performance of our global business during the quarter and particularly the resilience demonstrated as we delivered our ninth straight quarter of record results. We continue to see strong demand in our core markets as evidenced by our double-digit top line growth on a consolidated basis and all three operating segments,” commented Gregg Sengstack, Franklin Electric’s Chairperson and Chief Executive Officer. “Furthermore, our open order backlog remains at an elevated level of $250 million indicating on-going strong demand for the remainder of this year and into 2023.”

[0000038725-22-000177:8k_2_02:15]
“Similar to the second quarter, the operating environment remained choppy. Supply issues improved, but at a slower pace than we anticipated. In this strong inflationary environment, our global team performed exceptionally well with focused cost management, particularly in SG&A expense, where we continue to realize increased operating leverage. This strong performance more than offset the higher than anticipated headwind to earnings from foreign translation and exchange losses in the quarter. As a result, we are revising our guidance for full-year 2022 net sales to between $2.0 billion and $2.1 billion with our 2022 full-year earnings per share excluding restructuring to the range of $4.08 and $4.18, reflecting an increase in our earnings per share guidance midpoint to $4.13.” concluded Mr. Sengstack.

[0000038725-22-000177:8k_2_02:16]
Segment Summaries

[0000038725-22-000177:8k_2_02:17]
Water Systems sales, a new third quarter record, were $293.1 million in the third quarter 2022, an increase of $32.4 million or 12 percent versus the third quarter 2021. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 19 percent compared to the third quarter 2021.  Sales increases were led by pricing actions and strong end market demand across all major product lines in groundwater pumping, surface pumping and dewatering equipment.  Water Systems operating income in the third quarter was $45.5 million, a new third quarter record, driven by higher sales.  Third quarter 2021 Water Systems operating income was $36.8 million.

[0000038725-22-000177:8k_2_02:18]
Distribution sales, a new record for any quarter, were $193.2 million in the third quarter 2022.  The Distribution segment organic sales increased 22 percent compared to the third quarter of 2021.  Revenue growth was driven by solid demand primarily in the U.S. groundwater market due to strong price realization in addition to the growth from acquisition. The Distribution segment operating income, a new third quarter record, was $19.0 million in the third quarter of 2022 compared to third quarter 2021 operating income of $12.3 million.

[0000038725-22-000177:8k_2_02:19]
Fueling Systems sales, a new record for any quarter, were $90.2 million in the third quarter 2022, an increase of $9.2 million versus the third quarter 2021. Fueling Systems sales, excluding the impact of foreign currency translation, were up about 13 percent compared to the third quarter 2021. Fueling Systems sales increases in the U.S. and Canada were led by stronger demand for Fuel Management Systems compared to the third quarter 2021.  Outside the U.S. and Canada, Fueling Systems revenues were up, with sales growth in India and EMEA, offsetting lower sales in China.  Fueling Systems operating income, a new record for any quarter, was $28.6 million in the third quarter of 2022, compared to $23.9 million in the third quarter of 2021.

[0000038725-22-000177:8k_2_02:20]
Earnings Conference Call

[0000038725-22-000177:8k_2_02:21]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The third quarter 2022 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-22-000177:8k_2_02:22]
https://edge.media-server.com/mmc/p/88bghpev

[0000038725-22-000177:8k_2_02:23]
For those interested in participating in the question-and-answer portion of the call, please register for the call at the link below.

[0000038725-22-000177:8k_2_02:24]
https://register.vevent.com/register/BI377bd3eac6cb4e0a942916866ed7386d

[0000038725-22-000177:8k_2_02:25]
All registrants will receive dial-in information and a PIN allowing them to access the live call. It is recommended that you join 10 minutes prior to the event start (although you may register and dial in at any time during the call).

[0000038725-22-000177:8k_2_02:26]
A replay of the conference call will be available from Tuesday, October 25, 2022 through Tuesday, November 1, 2022, by visiting the listen-only webcast link above.

[0000038725-22-000177:8k_2_02:27]
Forward Looking Statements

[0000038725-22-000177:8k_2_02:28]
About Franklin Electric

[0000038725-22-000177:8k_2_02:29]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-22-000177:8k_2_02:30]
Franklin Electric Contact:

[0000038725-22-000177:8k_2_02:31]
Jeffery L. Taylor

[0000038725-22-000177:8k_2_02:32]
Franklin Electric Co., Inc.

[0000038725-22-000177:8k_2_02:33]
260-824-2900

[0000038725-22-000177:8k_2_02:34]
Email: jeffery.taylor@fele.com

[0000038725-22-000177:8k_2_02:35]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2022 |  | September 30, 2021 |  | September 30, 2022 |  | September 30, 2021 |
| Net sales | $ | 551,672 |  |  | $ | 459,019 |  |  | $ | 1,554,280 |  |  | $ | 1,229,345 |  |
| Cost of sales | 361,077 |  |  | 295,903 |  |  | 1,029,063 |  |  | 798,444 |  |
| Gross profit | 190,595 |  |  | 163,116 |  |  | 525,217 |  |  | 430,901 |  |
| Selling, general, and administrative expenses | 109,366 |  |  | 106,446 |  |  | 322,352 |  |  | 288,534 |  |
| Restructuring expense | 1,185 |  |  | 76 |  |  | 1,898 |  |  | 381 |  |
| Operating income | 80,044 |  |  | 56,594 |  |  | 200,967 |  |  | 141,986 |  |
| Interest expense | (3,066) |  |  | (1,384) |  |  | (7,492) |  |  | (3,840) |  |
| Other income/(expense), net | (1,250) |  |  | 2,061 |  |  | (2,787) |  |  | 1,531 |  |
| Foreign exchange income/(expense) | (3,376) |  |  | (408) |  |  | (4,290) |  |  | (1,654) |  |
| Income before income taxes | 72,352 |  |  | 56,863 |  |  | 186,398 |  |  | 138,023 |  |
| Income tax expense | 13,380 |  |  | 10,409 |  |  | 37,544 |  |  | 24,043 |  |
| Net income | $ | 58,972 |  |  | $ | 46,454 |  |  | $ | 148,854 |  |  | $ | 113,980 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (348) |  |  | (282) |  |  | (1,101) |  |  | (787) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 58,624 |  |  | $ | 46,172 |  |  | $ | 147,753 |  |  | $ | 113,193 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.26 |  |  | $ | 0.99 |  |  | $ | 3.17 |  |  | $ | 2.43 |  |
| Diluted | $ | 1.24 |  |  | $ | 0.98 |  |  | $ | 3.13 |  |  | $ | 2.40 |  |

[0000038725-22-000177:8k_2_02:36]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | September 30, 2022 |  | December 31, 2021 |
| ASSETS |  |
| Cash and equivalents | $ | 39,523 |  |  | $ | 40,536 |  |
| Receivables (net) | 251,543 |  |  | 196,173 |  |
| Inventories | 557,604 |  |  | 449,975 |  |
| Other current assets | 39,049 |  |  | 37,963 |  |
| Total current assets | 887,719 |  |  | 724,647 |  |
| Property, plant, and equipment, net | 207,714 |  |  | 210,654 |  |
| Right-of-use asset, net | 47,808 |  |  | 48,379 |  |
| Goodwill and other assets | 571,766 |  |  | 591,485 |  |
| Total assets | $ | 1,715,007 |  |  | $ | 1,575,165 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 153,540 |  |  | $ | 164,758 |  |
| Accrued expenses and other current liabilities | 113,215 |  |  | 117,955 |  |
| Current lease liability | 15,434 |  |  | 15,320 |  |
| Current maturities of long-term debt and short-term borrowings | 179,619 |  |  | 97,981 |  |
| Total current liabilities | 461,808 |  |  | 396,014 |  |
| Long-term debt | 89,225 |  |  | 90,535 |  |
| Long-term lease liability | 32,245 |  |  | 32,937 |  |
| Income taxes payable non-current | 8,707 |  |  | 11,610 |  |
| Deferred income taxes | 31,971 |  |  | 28,162 |  |
| Employee benefit plans | 37,333 |  |  | 40,696 |  |
| Other long-term liabilities | 25,547 |  |  | 26,568 |  |
| Redeemable noncontrolling interest | 455 |  |  | (19) |  |
| Total equity | 1,027,716 |  |  | 948,662 |  |
| Total liabilities and equity | $ | 1,715,007 |  |  | $ | 1,575,165 |  |

[0000038725-22-000177:8k_2_02:37]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Nine Months Ended |
| (In thousands) |  |  |  |
|  | September 30, 2022 |  | September 30, 2021 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 148,854 |  |  | $ | 113,980 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 37,067 |  |  | 32,767 |  |
| Non-cash lease expense | 12,939 |  |  | 9,394 |  |
| Share-based compensation | 8,940 |  |  | 8,921 |  |
| Other | 9,160 |  |  | 1,978 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (73,995) |  |  | (57,434) |  |
| Inventory | (122,150) |  |  | (85,873) |  |
| Accounts payable and accrued expenses | 1,881 |  |  | 92,214 |  |
| Operating leases | (12,939) |  |  | (9,394) |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | (355) |  | (355) |
| Other | (2,242) |  |  | (12,296) |  |
| Net cash flows from operating activities | 7,160 |  |  | 93,902 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (29,327) |  |  | (20,274) |  |
| Proceeds from sale of property, plant, and equipment | 6 |  |  | 839 |  |
| Acquisitions and investments | (1,576) |  |  | (193,987) |  |
| Other investing activities | 9 |  |  | 38 |  |
| Net cash flows from investing activities | (30,888) |  |  | (213,384) |  |
| Cash flows from financing activities: |  |  |  |
| Net change in debt | 83,679 |  |  | 102,395 |  |
| Proceeds from issuance of common stock | 3,584 |  |  | 11,390 |  |
| Purchases of common stock | (30,731) |  |  | (21,138) |  |
| Dividends paid | (27,293) |  |  | (24,499) |  |
| Net cash flows from financing activities | 29,239 |  |  | 68,148 |  |
| Effect of exchange rate changes on cash | (6,524) |  |  | (3,501) |  |
| Net change in cash and equivalents | (1,013) |  |  | (54,835) |  |
| Cash and equivalents at beginning of period | 40,536 |  |  | 130,787 |  |
| Cash and equivalents at end of period | $ | 39,523 |  |  | $ | 75,952 |  |

[0000038725-22-000177:8k_2_02:38]
Key Performance Indicators: Earnings Per Share Calculations

[0000038725-22-000177:8k_2_02:39]
| Earnings Before and After Restructuring |  | For the Third Quarter |  |  |
| (in millions) |  | 2022 | 2021 | Change |  |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 58.6 |  | $ | 46.2 |  | 27 | % |  |  |  |  |
| Allocated Earnings |  | $ | (0.2) |  | $ | (0.3) |  |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 58.4 |  | $ | 45.9 |  | 27 | % |  |  |  |  |
| Restructuring (before tax): |  | $ | 1.2 |  | $ | 0.1 |  |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 1.0 |  | $ | 0.1 |  |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 59.4 |  | $ | 46.0 |  | 29 | % |  |  |  |  |
| Earnings Per Share |  | For the Third Quarter |  |  |
| Before and After Restructuring |  | 2022 | 2021 | Change |  |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.0 |  | 47.0 |  | — | % |  |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 1.24 |  | $ | 0.98 |  | 27 | % |  |  |  |  |
| Restructuring Per Share, net of tax |  | $ | 0.02 |  | $ | — |  |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 1.26 |  | $ | 0.98 |  | 29 | % |  |  |  |  |

[0000038725-22-000177:8k_2_02:40]
Key Performance Indicators: Net Sales Summary

[0000038725-22-000177:8k_2_02:41]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q3 2021 | $ | 157.7 |  | $ | 36.5 |  | $ | 46.9 |  | $ | 19.6 |  | $ | 260.7 |  | $ | 81.0 |  | $ | 140.2 |  | $ | (22.9) |  | $ | 459.0 |  |
| Q3 2022 | $ | 183.7 |  | $ | 41.3 |  | $ | 46.0 |  | $ | 22.1 |  | $ | 293.1 |  | $ | 90.2 |  | $ | 193.2 |  | $ | (24.8) |  | $ | 551.7 |  |
| Change | $ | 26.0 |  | $ | 4.8 |  | $ | (0.9) |  | $ | 2.5 |  | $ | 32.4 |  | $ | 9.2 |  | $ | 53.0 |  | $ | (1.9) |  | $ | 92.7 |  |
| % Change | 16 | % | 13 | % | (2) | % | 13 | % | 12 | % | 11 | % | 38 | % |  | 20 | % |
| Foreign currency translation | $ | (0.7) |  | $ | (2.8) |  | $ | (18.3) |  | $ | (1.3) |  | $ | (23.1) |  | $ | (1.7) |  | $ | — |  |  |  |
| % Change | — | % | (8) | % | (39) | % | (7) | % | (9) | % | (2) | % | — | % |  |  |
| Acquisitions | $ | 5.6 |  | $ | — |  | $ | — |  | $ | 1.0 |  | $ | 6.6 |  | $ | — |  | $ | 21.7 |  |  |  |
| Volume/Price | $ | 21.1 |  | $ | 7.6 |  | $ | 17.4 |  | $ | 2.8 |  | $ | 48.9 |  | $ | 10.9 |  | $ | 31.3 |  |  |  |
| % Change | 13 | % | 21 | % | 37 | % | 14 | % | 19 | % | 13 | % | 22 | % |  |  |

[0000038725-22-000177:8k_2_02:42]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-22-000177:8k_2_02:43]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2022 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 45.5 |  | $ | 28.6 |  | $ | 19.0 |  | $ | (13.1) |  | $ | 80.0 |  |
| % Operating Income To Net Sales | 15.5 | % | 31.7 | % | 9.8 | % |  | 14.5 | % |
| Restructuring | $ | 0.5 |  | $ | 0.6 |  | $ | 0.1 |  | $ | — |  | $ | 1.2 |  |
| Operating Income/(Loss) Before Restructuring | $ | 46.0 |  | $ | 29.2 |  | $ | 19.1 |  | $ | (13.1) |  | $ | 81.2 |  |
| % Operating Income to Net Sales Before Restructuring | 15.7 | % | 32.4 | % | 9.9 | % |  | 14.7 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2021 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 36.8 |  | $ | 23.9 |  | $ | 12.3 |  | $ | (16.4) |  | $ | 56.6 |  |
| % Operating Income To Net Sales | 14.1 | % | 29.5 | % | 8.8 | % |  | 12.3 | % |
| Restructuring | $ | 0.1 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.1 |  |
| Operating Income/(Loss) Before Restructuring | $ | 36.9 |  | $ | 23.9 |  | $ | 12.3 |  | $ | (16.4) |  | $ | 56.7 |  |
| % Operating Income to Net Sales Before Restructuring | 14.2 | % | 29.5 | % | 8.8 | % |  | 12.4 | % |
