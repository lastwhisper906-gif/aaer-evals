# FELE MD&A — 0000038725-22-000182


## mdna

[0000038725-22-000182:mdna:1]
[same as prior period, unchanged from 0000038725-22-000148:mdna:1]

[0000038725-22-000182:mdna:2]
Third Quarter 2022 vs. Third Quarter 2021

[0000038725-22-000182:mdna:3]
[same as prior period, unchanged from 0000038725-22-000148:mdna:3]

[0000038725-22-000182:mdna:4]
Sales in the third quarter of 2022 increased from the third quarter last year. The sales increase was led by increases from price, acquisitions, and volume. The Company's consolidated gross profit was $190.6 million for the third quarter of 2022, an increase of $27.5 million or about 17 percent from the prior year’s third quarter. Earnings per share in the third quarter of 2022 were up compared to the same period last year by about 27 percent.

[0000038725-22-000182:mdna:5]
[same as prior period, unchanged from 0000038725-22-000148:mdna:5]

[0000038725-22-000182:mdna:6]
[same as prior period, unchanged from 0000038725-22-000148:mdna:6]

[0000038725-22-000182:mdna:7]
Net sales in the third quarter of 2022 were $551.7 million, an increase of $92.7 million or about 20 percent compared to 2021 third quarter sales of $459.0 million. Acquisition related sales were $28.3 million. Sales revenue decreased by $24.9 million or about 5 percent in the third quarter of 2022 due to foreign currency translation.

[0000038725-22-000182:mdna:8]
|  | Net Sales |
| (In millions) | Q3 2022 |  | Q3 2021 |  | 2022 v 2021 |
| Water Systems | $ | 293.1 |  |  | $ | 260.7 |  |  | $ | 32.4 |  |
| Fueling Systems | 90.2 |  |  | 81.0 |  |  | 9.2 |  |
| Distribution | 193.2 |  |  | 140.2 |  |  | 53.0 |  |
| Eliminations/Other | (24.8) |  |  | (22.9) |  |  | (1.9) |  |
| Consolidated | $ | 551.7 |  |  | $ | 459.0 |  |  | $ | 92.7 |  |

[0000038725-22-000182:mdna:9]
[same as prior period, unchanged from 0000038725-22-000148:mdna:9]

[0000038725-22-000182:mdna:10]
Water Systems sales were $293.1 million in the third quarter 2022, an increase of $32.4 million versus the third quarter 2021 sales of $260.7 million. In the third quarter of 2022, sales from businesses acquired since the third quarter of 2021 were $6.6 million. Water Systems sales decreased by $23.2 million or about 9 percent in the quarter due to foreign currency translation. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 19 percent compared to the third quarter 2021.

[0000038725-22-000182:mdna:11]
Water Systems sales in the U.S. and Canada were up overall by 16 percent compared to the third quarter 2021. In the third quarter of 2022, sales from businesses acquired since the third quarter of 2021 were $5.6 million. In the U.S. and Canada, Water Systems organic sales increased by 13 percent. Sales of groundwater pumping equipment increased by about 12 percent, and sales of dewatering equipment were up about 70 percent, both due to strong end market demand. Sales of surface pumping equipment increased by about 4 percent versus the third quarter 2021, as supply constraints with certain utility pumps and lower overall sales of sump pumps limited their growth rate.

[0000038725-22-000182:mdna:12]
Water Systems sales in markets outside the U.S. and Canada increased by 6 percent overall. Foreign currency translation decreased sales by $22.4 million or about 22 percent in the quarter. In the third quarter of 2022, sales from businesses acquired since the third quarter of 2021 were $1.0 million. Outside the U.S. and Canada, Water Systems organic sales increased by 27 percent, driven by higher sales in all three major geographic regions of the world; Europe, the Middle East and Africa, Latin America and in the Asia Pacific markets.

[0000038725-22-000182:mdna:13]
[same as prior period, unchanged from 0000038725-22-000148:mdna:13]

[0000038725-22-000182:mdna:14]
Fueling Systems sales were $90.2 million in the third quarter 2022, an increase of $9.2 million versus the third quarter 2021 sales of $81.0 million. In the third quarter of 2022, sales decreased by $1.7 million or about 2 percent due to foreign currency translation. Fueling Systems organic sales increased about 13 percent compared to the third quarter of 2021.

[0000038725-22-000182:mdna:15]
Fueling Systems sales in the U.S. and Canada increased by about 11 percent compared to the third quarter 2021. The increase was due to higher demand across most product groups. Outside the U.S. and Canada, Fueling Systems revenues were up, with sales growth in India and EMEA more than offsetting weak sales in Asia and Latin America. China sales were about $2 million in the third quarter of 2022 compared to about $4 million in the third quarter of 2021.

[0000038725-22-000182:mdna:16]
[same as prior period, unchanged from 0000038725-22-000148:mdna:17]

[0000038725-22-000182:mdna:17]
Distribution sales were $193.2 million in the third quarter 2022, versus third quarter 2021 sales of $140.2 million. In the third

[0000038725-22-000182:mdna:18]
quarter of 2022, sales from businesses acquired since the third quarter of 2021 were $21.7 million. The Distribution segment organic sales increased about 22 percent compared to the third quarter of 2021. Revenue growth was driven by pricing and strong demand in all regions and product categories.

[0000038725-22-000182:mdna:19]
[same as prior period, unchanged from 0000038725-22-000148:mdna:19]

[0000038725-22-000182:mdna:20]
Cost of sales as a percent of net sales for the third quarter of 2022 and 2021 was 65.5 percent and 64.5 percent, respectively. Correspondingly, the gross profit margin as a percent of net sales was 34.5 percent in the third quarter of 2022 compared to 35.5 percent in the third quarter of 2021. The gross profit margin was down 100 basis points, as realized pricing actions are more than offsetting inflationary cost increases. However, supply disruptions are causing unfavorable absorption variances and higher inbound freight.  The Company's consolidated gross profit was $190.6 million for the third quarter of 2022, an increase of $27.5 million from the gross profit of $163.1 million in the third quarter of 2021. The gross profit increase was primarily due to higher sales.

[0000038725-22-000182:mdna:21]
[same as prior period, unchanged from 0000038725-22-000148:mdna:21]

[0000038725-22-000182:mdna:22]
Selling, general, and administrative (SG&A) expenses were $109.4 million in the third quarter of 2022 compared to $106.4 million in the third quarter of the prior year. SG&A expenses from acquired businesses were about $6 million. Excluding acquisitions, SG&A expenses were lower by $3 million or less than 3 percent. SG&A costs as a percent of Net Sales were below 2021.

[0000038725-22-000182:mdna:23]
[same as prior period, unchanged from 0000038725-22-000148:mdna:23]

[0000038725-22-000182:mdna:24]
Restructuring expenses for the third quarter of 2022 were $1.2 million, across all three segments: Fueling $0.6 million, Water $0.5 million and Distribution $0.1 million and all related to miscellaneous manufacturing and branch realignment activities. Restructuring expenses for the third quarter of 2021 were $0.1 million, primarily in the Water segment and related to miscellaneous manufacturing realignment activities.

[0000038725-22-000182:mdna:25]
[same as prior period, unchanged from 0000038725-22-000148:mdna:25]

[0000038725-22-000182:mdna:26]
Operating income was $80.0 million in the third quarter of 2022, up $23.4 million or 41 percent from $56.6 million in the third quarter of 2021.

[0000038725-22-000182:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2022 |  | Q3 2021 |  | 2022 v 2021 |
| Water Systems |  | $ | 45.5 |  |  | $ | 36.8 |  |  | $ | 8.7 |  |
| Fueling Systems |  | 28.6 |  |  | 23.9 |  |  | 4.7 |  |
| Distribution |  | 19.0 |  |  | 12.3 |  |  | 6.7 |  |
| Eliminations/Other |  | (13.1) |  |  | (16.4) |  |  | 3.3 |  |
| Consolidated |  | $ | 80.0 |  |  | $ | 56.6 |  |  | $ | 23.4 |  |

[0000038725-22-000182:mdna:28]
[same as prior period, unchanged from 0000038725-22-000148:mdna:28]

[0000038725-22-000182:mdna:29]
Water Systems operating income was $45.5 million in the third quarter 2022, up $8.7 million compared to $36.8 million in the third quarter 2021. The increase in operating income was primarily due to higher sales revenues. The third quarter of 2022 operating income margin was 15.5 percent versus 14.1 percent of net sales in the third quarter of 2021. The increase in operating margin was primarily due leverage on higher sales volumes and cost controls in SG&A spending.

[0000038725-22-000182:mdna:30]
[same as prior period, unchanged from 0000038725-22-000148:mdna:30]

[0000038725-22-000182:mdna:31]
Fueling Systems operating income was $28.6 million in the third quarter of 2022, up $4.7 million compared to $23.9 million in the third quarter of 2021. The increase in operating income was primarily due to higher sales revenues. The third quarter of 2022 operating income margin was 31.7 percent versus 29.5 percent of net sales in the third quarter of 2021. Operating income margin in the third quarter increased in Fueling Systems primarily due to leverage on higher sales volumes, favorable product, geographic sales mix shifts and cost controls in SG&A.

[0000038725-22-000182:mdna:32]
[same as prior period, unchanged from 0000038725-22-000148:mdna:32]

[0000038725-22-000182:mdna:33]
Distribution operating income was $19.0 million in the third quarter of 2022 and the third quarter operating income margin was 9.8 percent. Distribution operating income was $12.3 million in the third quarter of 2021 and the third quarter operating income margin was 8.8 percent. Distribution’s operating income was higher in the third quarter due to higher sales volumes. The increase in operating income margin was primarily due to revenue growth and operating leverage.

[0000038725-22-000182:mdna:34]
[same as prior period, unchanged from 0000038725-22-000148:mdna:34]

[0000038725-22-000182:mdna:35]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses. The inter-segment profit elimination impact in the third quarter of 2022 compared to the third quarter of 2021 was a positive impact of $2.3 million on operating income. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its customer. Unallocated general and administrative expenses were lower by $1.0 million or about 6 percent, primarily due to cost controls in SG&A and lower variable compensation expense.

[0000038725-22-000182:mdna:36]
[same as prior period, unchanged from 0000038725-22-000148:mdna:36]

[0000038725-22-000182:mdna:37]
Interest expense for the third quarter of 2022 and 2021 was $3.1 million and $1.4 million, respectively, primarily as a result of higher debt levels and increased interest rates.

[0000038725-22-000182:mdna:38]
[same as prior period, unchanged from 0000038725-22-000148:mdna:38]

[0000038725-22-000182:mdna:39]
Other income or expense was a loss of $1.3 million and a gain of $2.1 million in the third quarter of 2022 and 2021, respectively. Included in other income or expense in the third quarter of 2022 was a loss of $1.1 million related to a settlement of an indirect tax dispute. Included in other income or expense in the third quarter of 2021 was a gain of $2.5 million related to a settlement of an indirect tax dispute.

[0000038725-22-000182:mdna:40]
[same as prior period, unchanged from 0000038725-22-000148:mdna:40]

[0000038725-22-000182:mdna:41]
Foreign currency-based transactions produced a loss for the third quarter of 2022 of $3.4 million, primarily due to the Turkish lira and Argentinian peso. Foreign currency-based transactions produced a loss for the third quarter of 2021 of $0.4 million.

[0000038725-22-000182:mdna:42]
[same as prior period, unchanged from 0000038725-22-000148:mdna:42]

[0000038725-22-000182:mdna:43]
The provision for income taxes in the third quarter of 2022 and 2021 was $13.4 million and $10.4 million, respectively. The effective tax rate for the third quarter of 2022 was about 19 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate for the third quarter of 2021 was about 18 percent and, before the impact of discrete events, was about 20 percent. The increase in the effective tax rate was primarily a result of smaller net favorable discrete events recorded in the third quarter of 2022 compared to the third quarter of 2021. The tax rate as a percentage of pre-tax earnings for the full year 2022 is projected to be about 21 percent, compared to the full year 2021 tax rate of about 21 percent, both before discrete adjustments.

[0000038725-22-000182:mdna:44]
[same as prior period, unchanged from 0000038725-22-000148:mdna:44]

[0000038725-22-000182:mdna:45]
Net income for the third quarter of 2022 was $59.0 million compared to the prior year third quarter net income of $46.5 million. Net income attributable to Franklin Electric Co., Inc. for the third quarter of 2022 was $58.6 million, or $1.24 per diluted share, compared to the prior year third quarter net income attributable to Franklin Electric Co., Inc. of $46.2 million or $0.98 per diluted share.

[0000038725-22-000182:mdna:46]
First Nine Months of 2022 vs. First Nine Months of 2021

[0000038725-22-000182:mdna:47]
[same as prior period, unchanged from 0000038725-22-000148:mdna:47]

[0000038725-22-000182:mdna:48]
Sales in the first nine months of 2022 were up from the same period last year. The sales increase was primarily from price, acquisitions, and higher volumes. The impact of foreign currency translation decreased sales by about 5 percent. The Company's consolidated gross profit was $525.2 million for the first nine months of 2022, an increase of $94.3 million or about 22 percent from the first nine months of 2021. Earnings in the first nine months of 2022 were up from the same period last year.

[0000038725-22-000182:mdna:49]
[same as prior period, unchanged from 0000038725-22-000148:mdna:49]

[0000038725-22-000182:mdna:50]
[same as prior period, unchanged from 0000038725-22-000148:mdna:50]

[0000038725-22-000182:mdna:51]
Net sales in the first nine months of 2022 were $1,554.3 million, an increase of $325.0 million or about 26 percent compared to 2021 first nine months sales of $1,229.3 million. The incremental impact of sales from acquired businesses was $110.9 million. Sales revenue decreased by $57.4 million or about 5 percent in the first nine months of 2022 due to foreign currency translation.

[0000038725-22-000182:mdna:52]
|  | Net Sales |
| (In millions) | YTD September 30, 2022 |  | YTD September 30, 2021 |  | 2022 v 2021 |
| Water Systems | $ | 876.2 |  |  | $ | 705.5 |  |  | $ | 170.7 |  |
| Fueling Systems | 248.7 |  |  | 210.0 |  |  | 38.7 |  |
| Distribution | 519.2 |  |  | 380.7 |  |  | 138.5 |  |
| Eliminations/Other | (89.8) |  |  | (66.9) |  |  | (22.9) |  |
| Consolidated | $ | 1,554.3 |  |  | $ | 1,229.3 |  |  | $ | 325.0 |  |

[0000038725-22-000182:mdna:53]
[same as prior period, unchanged from 0000038725-22-000148:mdna:53]

[0000038725-22-000182:mdna:54]
Water Systems sales were $876.2 million in the first nine months 2022, an increase of $170.7 million or about 24 percent versus the first nine months of 2021. The incremental impact of sales from acquired businesses was $55.3 million. Foreign currency translation changes decreased sales $53.5 million, or about 8 percent, compared to sales in the first nine months of 2021. The Water Systems sales change in the first nine months of 2022, excluding acquisitions and foreign currency translation, was an increase of $168.9 million or about 24 percent.

[0000038725-22-000182:mdna:55]
Water Systems sales in the U.S. and Canada increased by about 35 percent compared to the first nine months of 2021. The incremental impact of sales from acquired businesses was $50.6 million. Sales revenue decreased by $1.5 million in the first nine months of 2022 due to foreign currency translation. In the first nine months of 2022, Sales of groundwater pumping equipment increased by about 30 percent and sales of all surface pumping equipment increased by about 22 percent versus the first nine months of 2021, due to strong end market demand and pricing.

[0000038725-22-000182:mdna:56]
Water Systems sales in markets outside the U.S. and Canada increased by about 9 percent compared to the first nine months of 2021. The incremental impact of sales from acquired businesses was $4.7 million. Sales revenue decreased by $51.9 million or 17 percent in the first nine months of 2022 due to foreign currency translation. The change in the first nine months of 2022, excluding acquisitions and foreign currency translation, was an increase of about 25 percent. Sales grew organically in all major markets; Latin America, EMENA, and Asia Pacific.

[0000038725-22-000182:mdna:57]
[same as prior period, unchanged from 0000038725-22-000148:mdna:57]

[0000038725-22-000182:mdna:58]
Fueling Systems sales were $248.7 million in the first nine months of 2022, an increase of $38.7 million or about 18 percent from the first nine months of 2021. Foreign currency translation changes decreased sales $3.9 million or about 2 percent compared to sales in the first nine months of 2021. The Fueling Systems sales change in the first nine months of 2022, excluding foreign currency translation, was an increase of $42.6 million or about 20 percent.

[0000038725-22-000182:mdna:59]
Fueling Systems sales in the U.S. and Canada increased by about 25 percent during the first nine months of 2022, the increase was due to higher demand across all product lines. Outside the U.S. and Canada, Fueling Systems revenues were up, with sales growth in India more than offsetting weak sales in China.  China sales were about $5 million in the first nine months of 2022 compared to the first nine months of 2021 Fueling Systems China sales of about $9 million.

[0000038725-22-000182:mdna:60]
[same as prior period, unchanged from 0000038725-22-000148:mdna:60]

[0000038725-22-000182:mdna:61]
Distribution sales were $519.2 million in the first nine months of 2022, versus the first nine months of 2021 sales of $380.7 million. The incremental impact of sales from acquired businesses was $55.6 million. Distribution segment organic sales increased about 22 percent compared to the first nine months of 2021. Revenue growth was driven by pricing and broad-based demand in all regions and product categories.

[0000038725-22-000182:mdna:62]
[same as prior period, unchanged from 0000038725-22-000148:mdna:62]

[0000038725-22-000182:mdna:63]
Cost of sales as a percent of net sales for the first nine months of 2022 and 2021 was 66.2 percent and 64.9 percent, respectively. Correspondingly, the gross profit margin was 33.8 percent and 35.1 percent, respectively. The gross profit margin decline was primarily a result of realized pricing actions more than offsetting inflationary cost increases, however, supply disruptions are causing unfavorable absorption variances and higher inbound freight.  The Company's consolidated gross profit was $525.2 million for the first nine months of 2022, up $94.3 million from the gross profit of $430.9 million in the first nine months of 2021. The gross profit increase was primarily due to higher sales.

[0000038725-22-000182:mdna:64]
[same as prior period, unchanged from 0000038725-22-000148:mdna:64]

[0000038725-22-000182:mdna:65]
Selling, general, and administrative expenses were $322.4 million in the first nine months of 2022 and increased by $33.9 million compared to $288.5 million in the first nine months of last year. SG&A expenses from acquired businesses were $26 million. Excluding acquisitions, SG&A expenses were higher by $7.9 million or 3 percent versus the prior year. SG&A costs as a percent of Net Sales were below 2021.

[0000038725-22-000182:mdna:66]
[same as prior period, unchanged from 0000038725-22-000148:mdna:67]

[0000038725-22-000182:mdna:67]
Restructuring expenses for the first nine months of 2022 were $1.9 million. Restructuring expenses were $1.1 million in the Water segment, $0.6 in the Fueling segment and $0.2 million in Distribution segments. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution segment. Restructuring expenses for the first nine months of 2021 were $0.4 million. Restructuring expenses were $0.3 million in the Water segment and $0.1 million in Distribution segments. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution segment.

[0000038725-22-000182:mdna:68]
[same as prior period, unchanged from 0000038725-22-000148:mdna:69]

[0000038725-22-000182:mdna:69]
Operating income was $201.0 million in the first nine months of 2022, up $59.0 million or 42 percent from $142.0 million in

[0000038725-22-000182:mdna:70]
the first nine months of 2021.

[0000038725-22-000182:mdna:71]
|  |  | Operating income (loss) |
| (In millions) |  | YTD September 30, 2022 |  | YTD September 30, 2021 |  | 2022 v 2021 |
| Water Systems |  | $ | 127.7 |  |  | $ | 102.7 |  |  | $ | 25.0 |  |
| Fueling Systems |  | 72.4 |  |  | 57.3 |  |  | 15.1 |  |
| Distribution |  | 51.7 |  |  | 30.3 |  |  | 21.4 |  |
| Eliminations/Other |  | (50.8) |  |  | (48.3) |  |  | (2.5) |  |
| Consolidated |  | $ | 201.0 |  |  | $ | 142.0 |  |  | $ | 59.0 |  |

[0000038725-22-000182:mdna:72]
[same as prior period, unchanged from 0000038725-22-000148:mdna:72]

[0000038725-22-000182:mdna:73]
Water Systems operating income was $127.7 million in the first nine months of 2022 compared to $102.7 million in the first nine months of 2021, an increase of 24 percent. Operating income increased in Water Systems primarily due to higher sales volumes and SG&A cost controls. The first nine months operating income margin was 14.6 percent compared to the first nine months of 2021 operating income margin of 14.6 percent.

[0000038725-22-000182:mdna:74]
[same as prior period, unchanged from 0000038725-22-000148:mdna:74]

[0000038725-22-000182:mdna:75]
Fueling Systems operating income was $72.4 million in the first nine months of 2022 compared to $57.3 million in the first nine months of 2021. Operating income increased in Fueling Systems primarily due to higher sales volumes. The first nine months operating income margin was 29.1 percent compared to 27.3 percent of net sales in the first nine months of 2021. Operating income margin increased in Fueling Systems primarily due to operating leverage on higher sales, favorable product and geographic sales mix shifts.

[0000038725-22-000182:mdna:76]
[same as prior period, unchanged from 0000038725-22-000148:mdna:76]

[0000038725-22-000182:mdna:77]
Distribution operating income was $51.7 million in the first nine months of 2022 and operating income margin was 10.0 percent. Distribution operating income was $30.3 million in the first nine months of 2021 and operating income margin was 8.0 percent. Distribution’s operating income in the first nine months was higher in due to higher sales volumes. The increase in operating income margin was primarily due to revenue growth and operating leverage.

[0000038725-22-000182:mdna:78]
[same as prior period, unchanged from 0000038725-22-000148:mdna:78]

[0000038725-22-000182:mdna:79]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses. The inter-segment profit elimination impact in the first nine months of 2022 decreased operating income about $2.6 million versus the impact in the first nine months of 2021. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its third-party customer. Unallocated general and administrative expenses were lower by $0.1 million to last year in the first nine months.

[0000038725-22-000182:mdna:80]
[same as prior period, unchanged from 0000038725-22-000148:mdna:80]

[0000038725-22-000182:mdna:81]
Interest expense for the first nine months of 2022 and 2021 was $7.5 million and $3.8 million, respectively, primarily as a result of higher debt levels and increase interest rates.

[0000038725-22-000182:mdna:82]
[same as prior period, unchanged from 0000038725-22-000148:mdna:82]

[0000038725-22-000182:mdna:83]
Other income or expense was a loss of $2.8 million and a gain of 1.5 million, respectively in the first nine months of 2022 and 2021. Included in other income or expense in 2022 was a loss of $2.1 million related to a settlement of an indirect tax dispute.  Included in other income or expense in 2021 was a gain of $2.5 million related to a settlement of an indirect tax dispute.

[0000038725-22-000182:mdna:84]
[same as prior period, unchanged from 0000038725-22-000148:mdna:84]

[0000038725-22-000182:mdna:85]
Foreign currency–based transactions produced a loss for the first nine months of 2022 of $4.3 million, primarily from the Turkish lira and Argentinian peso. Foreign currency–based transactions produced a loss for the first nine months of 2021 of $1.7 million, primarily from the Argentinian peso.

[0000038725-22-000182:mdna:86]
[same as prior period, unchanged from 0000038725-22-000148:mdna:86]

[0000038725-22-000182:mdna:87]
The provision for income taxes in the first nine months of 2022 and 2021 was $37.5 million and $24.0 million, respectively. The effective tax rate for the first nine months of 2022 was 20 percent and, before the impact of discrete events, was about 21 percent. The effective tax rate in the first nine months of 2021 was about 17 percent and, before the impact of discrete events, was about 20 percent. The increase in the effective tax rate was primarily a result of a smaller net favorable discrete events

[0000038725-22-000182:mdna:88]
recorded in the first nine months of 2022 compared to the first nine months of 2021, primarily related to excess tax benefits from share-based compensation. The tax rate as a percentage of pre-tax earnings for the full year 2022 is projected to be about 21 percent, compared to the full year 2021 tax rate of about 21 percent, both before discrete adjustments.

[0000038725-22-000182:mdna:89]
[same as prior period, unchanged from 0000038725-22-000148:mdna:88]

[0000038725-22-000182:mdna:90]
Net income for the first nine months of 2022 was $148.9 million compared to 2021 first nine months net income of $114.0 million. Net income attributable to Franklin Electric Co., Inc. for the first nine months of 2022 was $147.8 million, or $3.13 per diluted share, compared to 2021 first nine months net income attributable to Franklin Electric Co., Inc. of $113.2 million or $2.40 per diluted share.

[0000038725-22-000182:mdna:91]
[same as prior period, unchanged from 0000038725-22-000148:mdna:90]

[0000038725-22-000182:mdna:92]
[same as prior period, unchanged from 0000038725-22-000148:mdna:91]

[0000038725-22-000182:mdna:93]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at September 30, 2022 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-22-000182:mdna:94]
As of September 30, 2022 the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of September 30, 2022, the Company had $171.8 million borrowing capacity under the Credit Agreement as $4.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and $174.2 million in revolver borrowings were drawn and outstanding, which were primarily used for funding working capital requirements.

[0000038725-22-000182:mdna:95]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of  $125.0 million as of September 30, 2022. The Company also has other long-term debt borrowings outstanding as of September 30, 2022. See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-22-000182:mdna:96]
At September 30, 2022, the Company had $36.1 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-22-000182:mdna:97]
[same as prior period, unchanged from 0000038725-22-000148:mdna:96]

[0000038725-22-000182:mdna:98]
The following table summarizes significant sources and uses of cash and cash equivalents for the first nine months of 2022 and 2021.

[0000038725-22-000182:mdna:99]
| (in millions) |  | 2022 |  | 2021 |
| Net cash flows from operating activities |  | $ | 7.2 |  |  | $ | 93.9 |  |
| Net cash flows from investing activities |  | (30.9) |  |  | (213.4) |  |
| Net cash flows from financing activities |  | 29.2 |  |  | 68.2 |  |
| Impact of exchange rates on cash and cash equivalents |  | (6.5) |  |  | (3.5) |  |
| Change in cash and cash equivalents |  | $ | (1.0) |  |  | $ | (54.8) |  |

[0000038725-22-000182:mdna:100]
[same as prior period, unchanged from 0000038725-22-000148:mdna:99]

[0000038725-22-000182:mdna:101]
[same as prior period, unchanged from 0000038725-22-000148:mdna:100]

[0000038725-22-000182:mdna:102]
Net cash provided by operating activities was $7.2 million for the nine months ended September 30, 2022 compared to $93.9 million provided by operating activities for the nine months ended September 30, 2021. The decrease in cash provided by operating activities was primarily due to increased working capital requirements in support of supply chain resiliency and meeting the strong demand from our customers.

[0000038725-22-000182:mdna:103]
[same as prior period, unchanged from 0000038725-22-000148:mdna:102]

[0000038725-22-000182:mdna:104]
[same as prior period, unchanged from 0000038725-22-000148:mdna:103]

[0000038725-22-000182:mdna:105]
Net cash used in investing activities was $30.9 million for the nine months ended September 30, 2022 compared to $213.4 million used in investing activities for the nine months ended September 30, 2021. The decrease in cash used in investing activities was attributable to decreased acquisition activity in 2022.

[0000038725-22-000182:mdna:106]
[same as prior period, unchanged from 0000038725-22-000148:mdna:105]

[0000038725-22-000182:mdna:107]
[same as prior period, unchanged from 0000038725-22-000148:mdna:106]

[0000038725-22-000182:mdna:108]
Net cash provided by financing activities was $29.2 million for the nine months ended September 30, 2022 compared to $68.2 million provided by financing activities for the nine months ended September 30, 2021. The decrease in cash provided by financing activities was attributable to increased common stock repurchases slightly offset by decreased net proceeds from debt and common stock issuances.

[0000038725-22-000182:mdna:109]
[same as prior period, unchanged from 0000038725-22-000148:mdna:108]

[0000038725-22-000182:mdna:110]
33
