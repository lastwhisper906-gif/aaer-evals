# FELE note change history — 0000038725-23-000070 → 0000038725-23-000151


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-07-28):
[0000038725-23-000151:note_history:1]
At June 30, 2023, the Company had $11.1 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2023-05-05, similarity 0.9689):
[0000038725-23-000070:note_history:1]
At March 31, 2023, the Company had $13.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2023-07-28):
[0000038725-23-000151:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2023, are as follows:
  (was, 2023-05-05, similarity 0.9053):
[0000038725-23-000070:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2023, are as follows:

- changed (2023-07-28):
[0000038725-23-000151:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2022 |  | $ | 11.2 |  |
| Accruals related to product warranties |  | 6.4 |  |
| Reductions for payments made |  | (6.9) |  |
| Balance as of June 30, 2023 |  | $ | 10.7 |  |
  (was, 2023-05-05, similarity 0.8753):
[0000038725-23-000070:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2022 |  | $ | 11.2 |  |
| Accruals related to product warranties |  | 3.4 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (3.3) |  |
| Balance as of March 31, 2023 |  | $ | 11.3 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-07-28):
[0000038725-23-000151:note_history:4]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2022, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2023, and for the second quarters and six months ended June 30, 2023 and June 30, 2022 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2023. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022.
  (was, 2023-05-05, similarity 0.9431):
[0000038725-23-000070:note_history:4]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2022, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2023, and for the first quarters ended March 31, 2023 and March 31, 2022 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2023. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-07-28):
[0000038725-23-000151:note_history:5]
| (In millions) |  | June 30, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 158.3 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.7 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 0.6 |  |  | 3.1 |  |
| Other |  | — |  |  | — |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 248.5 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (159.8) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.7 |  |  | 89.3 |
  (was, 2023-05-05, similarity 0.9894):
[0000038725-23-000070:note_history:5]
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 182.5 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.7 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 2.0 |  |  | 3.1 |  |
| Other |  | — |  |  | — |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 274.1 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (185.3) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.8 |  |  | 89.3 |

- changed (2023-07-28):
[0000038725-23-000151:note_history:6]
As of June 30, 2023, the Company had $158.3 million outstanding borrowings with a weighted-average interest rate of 5.9 percent, $3.6 million in letters of credit outstanding, and $188.1 million of available capacity under its credit agreement. As of December 31, 2022, the Company had $122.8 million outstanding borrowings with a weighted-average interest rate of 5.0 percent, $4.0 million in letters of credit outstanding, and $223.2 million of available capacity under its credit agreement.
  (was, 2023-05-05, similarity 0.988):
[0000038725-23-000070:note_history:6]
As of March 31, 2023, the Company had $182.5 million outstanding borrowings with a weighted-average interest rate of 5.6 percent, $3.6 million in letters of credit outstanding, and $163.9 million of available capacity under its credit agreement. As of December 31,2022, the company had $122.8 million outstanding borrowings with a weighted-average interest rate of 5.0 percent, $4.0 million in letters of credit outstanding, and $223.2 million of available capacity under its credit agreement.

- changed (2023-07-28):
[0000038725-23-000151:note_history:7]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $20.3 million. As of June 30, 2023, there were $0.1 million outstanding borrowings and $20.2 million of available capacity under these lines of credit. As of December 31, 2022, there were $22.0 million overdraft lines of credit with $2.7 million of outstanding borrowings and $19.3 million of available capacity under these lines of credit.
  (was, 2023-05-05, similarity 0.9806):
[0000038725-23-000070:note_history:7]
The Company also has lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $21.9 million. As of March 31, 2023, there were $1.5 million outstanding borrowings and $20.4 million of available capacity under these lines of credit. As of December 31, 2022, there were $22.0 million overdraft lines of credit with $2.7 million of outstanding borrowings and $19.3 million of available capacity under these lines of credit.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-07-28):
[0000038725-23-000151:note_history:8]
| (In millions) |  | June 30, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 158.3 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.7 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 0.6 |  |  | 3.1 |  |
| Other |  | — |  |  | — |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 248.5 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (159.8) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.7 |  |  | 89.3 |
  (was, 2023-05-05, similarity 0.9894):
[0000038725-23-000070:note_history:8]
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 182.5 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.7 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 2.0 |  |  | 3.1 |  |
| Other |  | — |  |  | — |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 274.1 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (185.3) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.8 |  |  | 89.3 |
