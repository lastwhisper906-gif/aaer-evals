# FELE 8-K — 0000038725-23-000149 filed 2023-07-25

## item codes, every 8-K on or before 2023-07-28

- 2023-07-25 0000038725-23-000149 — 2.02, 9.01
- 2023-07-05 0000038725-23-000144 — 5.02, 7.01, 9.01
- 2023-05-09 0000038725-23-000094 — 5.02, 9.01
- 2023-05-09 0000038725-23-000092 — 5.07
- 2023-05-08 0000038725-23-000087 — 7.01, 9.01
- 2023-05-02 0000038725-23-000065 — 2.02, 9.01
- 2023-03-08 0000038725-23-000046 — 7.01, 9.01
- 2023-02-21 0000038725-23-000016 — 8.01, 9.01
- 2023-02-14 0000038725-23-000002 — 2.02, 9.01
- 2022-10-28 0000038725-22-000180 — 7.01, 9.01
- 2022-10-25 0000038725-22-000177 — 2.02, 9.01
- 2022-08-04 0000038725-22-000150 — 7.01, 9.01
- 2022-07-26 0000038725-22-000142 — 2.02, 9.01
- 2022-05-11 0000038725-22-000106 — 2.03, 9.01
- 2022-05-06 0000038725-22-000082 — 5.07
- 2022-05-06 0000038725-22-000081 — 5.02, 9.01
- 2022-05-03 0000038725-22-000075 — 7.01, 9.01
- 2022-04-26 0000038725-22-000073 — 2.02, 9.01
- 2022-03-24 0000038725-22-000056 — 5.02, 9.01
- 2022-03-08 0000038725-22-000049 — 7.01, 9.01
- 2022-02-15 0000038725-22-000007 — 2.02, 9.01
- 2022-01-04 0000038725-22-000002 — 7.01, 9.01
- 2021-11-03 0000038725-21-000212 — 7.01, 9.01
- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2023-07-28

- none on or before 2023-07-28

## item 2.02 — earnings release, exhibit 99.1

[0000038725-23-000149:8k_2_02:1]
EX-99.1
2
a20230725ex991earningsrele.htm
EX-99.1

[0000038725-23-000149:8k_2_02:2]
Document

[0000038725-23-000149:8k_2_02:3]
Exhibit 99.1

[0000038725-23-000149:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-23-000149:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS RECORD SECOND QUARTER 2023 RESULTS

[0000038725-23-000149:8k_2_02:6]
Second Quarter 2023 Highlights

[0000038725-23-000149:8k_2_02:7]
•Consolidated net sales of $569.1 million, a new all-time quarterly record, was an increase of 3% over the prior year

[0000038725-23-000149:8k_2_02:8]
•Water Systems and Distribution sales increased by 4% and 1%, respectively, while Fueling Systems sales decreased 7%

[0000038725-23-000149:8k_2_02:9]
•Operating income was $80.9 million with healthy operating margin of 14.2%

[0000038725-23-000149:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $1.27, a new record for any quarter

[0000038725-23-000149:8k_2_02:11]
Fort Wayne, IN – July 25, 2023 – Franklin Electric Co., Inc. today announced its second quarter financial results for fiscal year 2023.

[0000038725-23-000149:8k_2_02:12]
Second quarter 2023 net sales were $569.1 million, compared to second quarter 2022 net sales of $551.1 million.  Second quarter 2023 operating income was $80.9 million, compared to second quarter 2022 operating income of $81.0 million.  Second quarter 2023 EPS was $1.27, versus EPS in the second quarter 2022 of $1.26.

[0000038725-23-000149:8k_2_02:13]
“We delivered another quarter of record sales and EPS performance for Franklin Electric. Results were driven by a solid demand environment that continued into the busy season for our core markets. Strong execution by our global teams enabled backlog and inventory levels to continue trending towards normalized levels, significantly improving our cash flow generation,” commented Gregg Sengstack, Franklin Electric’s Chairperson and Chief Executive Officer.

[0000038725-23-000149:8k_2_02:14]
“Even though our second quarter sales were adversely impacted by weather and distributors right-sizing inventory levels, our end-market demand remains healthy. As we enter the third quarter, we have an elevated backlog which gives us momentum and confidence in our outlook for the remainder of 2023,” concluded Mr. Sengstack.

[0000038725-23-000149:8k_2_02:15]
Segment Summaries

[0000038725-23-000149:8k_2_02:16]
Water Systems net sales, a new all-time quarterly record, were $321.7 million in the second quarter 2023, an increase of $11.2 million compared to the second quarter 2022. Sales increases were led by pricing actions and continued strong end market demand for large pumps. Water Systems operating income in the second quarter 2023 was $50.8 million, a new quarterly record, driven by higher sales.  Second quarter 2022 Water Systems operating income was $49.0 million.

[0000038725-23-000149:8k_2_02:17]
Distribution net sales, a new second quarter record, were $193.1 million in the second quarter 2023, an increase of $2.0 million compared to the second quarter 2022.  Sales increases were led by end market demand. The Distribution segment operating income was $17.8 million in the second quarter 2023 compared to second quarter 2022 operating income of $23.3 million. Distribution segment sales and operating income were negatively impacted by wet weather across much of the US, margin compression from declining pricing of commodity-based products sold through the business, and some channel inventory destocking as supply chains normalize.

[0000038725-23-000149:8k_2_02:18]
Fueling Systems net sales were $80.4 million in the second quarter 2023, a decrease of $5.6 million compared to the second quarter 2022. Sales decreased in the U.S. and Canada by 6 percent and outside the U.S. and Canada by 8 percent. Fueling Systems operating income in the second quarter 2023 was

[0000038725-23-000149:8k_2_02:19]
$26.7 million, a new second quarter record, driven by a favorable product and geographic mix of sales. Second quarter 2022 Fueling Systems operating income was $26.1 million.

[0000038725-23-000149:8k_2_02:20]
2023 Guidance

[0000038725-23-000149:8k_2_02:21]
The Company is maintaining its guidance for full year 2023 sales to be in the range of $2.15 billion to $2.25 billion and full year 2023 EPS to be in the range of $4.25 to $4.45.

[0000038725-23-000149:8k_2_02:22]
Earnings Conference Call

[0000038725-23-000149:8k_2_02:23]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The second quarter 2023 earnings call will be available via a live webcast. The webcast will be available in a listen-only mode by going to:

[0000038725-23-000149:8k_2_02:24]
https://edge.media-server.com/mmc/p/ykifmgrn

[0000038725-23-000149:8k_2_02:25]
For those interested in participating in the question-and-answer portion of the call, please register for the call at the link below.

[0000038725-23-000149:8k_2_02:26]
https://register.vevent.com/register/BId7ec20b8d1f5442687a9b4f54a3e54a8

[0000038725-23-000149:8k_2_02:27]
All registrants will receive dial-in information and a PIN allowing them to access the live call. It is recommended that you join 10 minutes prior to the event start (although you may register and dial in at any time during the call).

[0000038725-23-000149:8k_2_02:28]
A replay of the conference call will be available from Tuesday, July 25, 2023, through 9 am ET on Tuesday, August 1, 2023, by visiting the listen-only webcast link above.

[0000038725-23-000149:8k_2_02:29]
Forward Looking Statements

[0000038725-23-000149:8k_2_02:30]
About Franklin Electric

[0000038725-23-000149:8k_2_02:31]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-23-000149:8k_2_02:32]
Franklin Electric Contact:

[0000038725-23-000149:8k_2_02:33]
Jeffery L. Taylor

[0000038725-23-000149:8k_2_02:34]
Franklin Electric Co., Inc.

[0000038725-23-000149:8k_2_02:35]
260-824-2900

[0000038725-23-000149:8k_2_02:36]
Email: jeffery.taylor@fele.com

[0000038725-23-000149:8k_2_02:37]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2023 |  | June 30, 2022 |  | June 30, 2023 |  | June 30, 2022 |
| Net sales | $ | 569,181 |  |  | $ | 551,138 |  |  | $ | 1,053,732 |  |  | $ | 1,002,608 |  |
| Cost of sales | 380,700 |  |  | 361,850 |  |  | 702,986 |  |  | 667,986 |  |
| Gross profit | 188,481 |  |  | 189,288 |  |  | 350,746 |  |  | 334,622 |  |
| Selling, general, and administrative expenses | 107,429 |  |  | 108,313 |  |  | 216,964 |  |  | 212,986 |  |
| Restructuring (income)/expense | 149 |  |  | (7) |  |  | 273 |  |  | 713 |  |
| Operating income | 80,903 |  |  | 80,982 |  |  | 133,509 |  |  | 120,923 |  |
| Interest expense | (4,178) |  |  | (2,932) |  |  | (7,325) |  |  | (4,426) |  |
| Other income/(expense), net | 1,179 |  |  | (1,159) |  |  | 1,588 |  |  | (1,537) |  |
| Foreign exchange expense | (3,571) |  |  | (329) |  |  | (5,615) |  |  | (914) |  |
| Income before income taxes | 74,333 |  |  | 76,562 |  |  | 122,157 |  |  | 114,046 |  |
| Income tax expense | 14,173 |  |  | 16,799 |  |  | 24,421 |  |  | 24,164 |  |
| Net income | $ | 60,160 |  |  | $ | 59,763 |  |  | $ | 97,736 |  |  | $ | 89,882 |  |
| Less: Net income attributable to noncontrolling interests | (560) |  |  | (399) |  |  | (811) |  |  | (753) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 59,600 |  |  | $ | 59,364 |  |  | $ | 96,925 |  |  | $ | 89,129 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.29 |  |  | $ | 1.27 |  |  | $ | 2.09 |  |  | $ | 1.91 |  |
| Diluted | $ | 1.27 |  |  | $ | 1.26 |  |  | $ | 2.06 |  |  | $ | 1.89 |  |

[0000038725-23-000149:8k_2_02:38]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | June 30, 2023 |  | December 31, 2022 |
| ASSETS |  |
| Cash and equivalents | $ | 53,227 |  |  | $ | 45,790 |  |
| Receivables (net) | 299,485 |  |  | 230,404 |  |
| Inventories | 574,642 |  |  | 544,980 |  |
| Other current assets | 39,036 |  |  | 36,916 |  |
| Total current assets | 966,390 |  |  | 858,090 |  |
| Property, plant, and equipment, net | 224,464 |  |  | 215,154 |  |
| Lease right-of-use assets, net | 44,160 |  |  | 48,948 |  |
| Goodwill and other assets | 568,067 |  |  | 572,009 |  |
| Total assets | $ | 1,803,081 |  |  | $ | 1,694,201 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 161,266 |  |  | $ | 139,266 |  |
| Accrued expenses and other current liabilities | 97,946 |  |  | 123,788 |  |
| Current lease liability | 13,624 |  |  | 15,959 |  |
| Current maturities of long-term debt and short-term borrowings | 159,841 |  |  | 126,756 |  |
| Total current liabilities | 432,677 |  |  | 405,769 |  |
| Long-term debt | 88,680 |  |  | 89,271 |  |
| Long-term lease liability | 29,513 |  |  | 32,858 |  |
| Income taxes payable non-current | 4,837 |  |  | 8,707 |  |
| Deferred income taxes | 32,434 |  |  | 29,744 |  |
| Employee benefit plans | 32,628 |  |  | 31,889 |  |
| Other long-term liabilities | 31,910 |  |  | 25,209 |  |
| Redeemable noncontrolling interest | 901 |  |  | 620 |  |
| Total equity | 1,149,501 |  |  | 1,070,134 |  |
| Total liabilities and equity | $ | 1,803,081 |  |  | $ | 1,694,201 |  |

[0000038725-23-000149:8k_2_02:39]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Six Months Ended |
| (In thousands) |  |  |  |
|  | June 30, 2023 |  | June 30, 2022 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 97,736 |  |  | $ | 89,882 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 26,259 |  |  | 24,521 |  |
| Non-cash lease expense | 8,523 |  |  | 8,526 |  |
| Share-based compensation | 6,410 |  |  | 6,322 |  |
| Other | 7,896 |  |  | 3,639 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (70,725) |  |  | (93,063) |  |
| Inventory | (24,125) |  |  | (123,817) |  |
| Accounts payable and accrued expenses | (3,880) |  |  | 29,969 |  |
| Operating leases | (8,706) |  |  | (8,526) |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | (2,902) |  | (355) |
| Other | 6,540 |  |  | 361 |  |
| Net cash flows from operating activities | 43,026 |  |  | (62,541) |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (20,241) |  |  | (20,084) |  |
| Proceeds from sale of property, plant, and equipment | — |  |  | 6 |  |
| Acquisitions and investments | (6,641) |  |  | (1,365) |  |
| Other investing activities | 2 |  |  | (8) |  |
| Net cash flows from investing activities | (26,880) |  |  | (21,451) |  |
| Cash flows from financing activities: |  |  |  |
| Net change in debt | 32,171 |  |  | 126,272 |  |
| Proceeds from issuance of common stock | 9,010 |  |  | 1,916 |  |
| Purchases of common stock | (25,541) |  |  | (30,644) |  |
| Dividends paid | (20,872) |  |  | (18,205) |  |
| Deferred payments for acquisitions | (186) |  |  | — |  |
| Net cash flows from financing activities | (5,418) |  |  | 79,339 |  |
| Effect of exchange rate changes on cash and cash equivalents | (3,291) |  |  | (2,658) |  |
| Net change in cash and cash equivalents | 7,437 |  |  | (7,311) |  |
| Cash and cash equivalents at beginning of period | 45,790 |  |  | 40,536 |  |
| Cash and cash equivalents at end of period | $ | 53,227 |  |  | $ | 33,225 |  |

[0000038725-23-000149:8k_2_02:40]
Key Performance Indicators: Net Sales Summary

[0000038725-23-000149:8k_2_02:41]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q2 2022 | $ | 194.9 |  | $ | 41.7 |  | $ | 49.7 |  | $ | 24.2 |  | $ | 310.5 |  | $ | 86.0 |  | $ | 191.1 |  | $ | (36.5) |  | $ | 551.1 |  |
| Q2 2023 | $ | 202.9 |  | $ | 42.0 |  | $ | 54.6 |  | $ | 22.2 |  | $ | 321.7 |  | $ | 80.4 |  | $ | 193.1 |  | $ | (26.1) |  | $ | 569.1 |  |
| Change | $ | 8.0 |  | $ | 0.3 |  | $ | 4.9 |  | $ | (2.0) |  | $ | 11.2 |  | $ | (5.6) |  | $ | 2.0 |  | $ | 10.4 |  | $ | 18.0 |  |
| % Change | 4 | % | 1 | % | 10 | % | (8) | % | 4 | % | (7) | % | 1 | % |  | 3 | % |
| Foreign currency translation | $ | (1.2) |  | $ | (4.9) |  | $ | (5.3) |  | $ | (1.2) |  | $ | (12.6) |  | $ | (0.1) |  | $ | — |  |  | $ | (12.7) |  |
| % Change | (1) | % | (12) | % | (11) | % | (5) | % | (4) | % | — | % | — | % |  | (2) | % |
| Volume/Price | $ | 9.2 |  | $ | 5.2 |  | $ | 10.2 |  | $ | (0.8) |  | $ | 23.8 |  | $ | (5.5) |  | $ | 2.0 |  | $ | 10.4 |  | 30.7 |
| % Change | 5 | % | 12 | % | 21 | % | (3) | % | 8 | % | (6) | % | 1 | % | (28) | % | 6 | % |

[0000038725-23-000149:8k_2_02:42]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-23-000149:8k_2_02:43]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Second Quarter 2023 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 50.8 |  | $ | 26.7 |  | $ | 17.8 |  | $ | (14.4) |  | $ | 80.9 |  |
| % Operating Income To Net Sales | 15.8 | % | 33.2 | % | 9.2 | % |  | 14.2 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Second Quarter 2022 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 49.0 |  | $ | 26.1 |  | $ | 23.3 |  | $ | (17.4) |  | $ | 81.0 |  |
| % Operating Income To Net Sales | 15.8 | % | 30.3 | % | 12.2 | % |  | 14.7 | % |
