# FELE notes — 0000038725-23-000151


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-23-000151:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2022, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2023, and for the second quarters and six months ended June 30, 2023 and June 30, 2022 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2023. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-23-000151:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-23-000151:notes:3]
In October 2021, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires entities to recognize and measure contracts on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. This will improve comparability after the business combination by providing consistent recognition and measurement guidance for revenue contracts with customers acquired in a business combination and revenue contracts with customers not acquired in a business combination. ASU 2021-08 is effective for interim and annual periods beginning after December 15, 2022 with early adoption permitted. ASU 2021-08 should be applied on a prospective basis to business combinations that occur after the effective date. The Company adopted this ASU on January 1, 2023, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-23-000151:notes:4]
In September 2022, the FASB issued ASU 2022-04, Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations. ASU 2022-04 creates the obligation for a company that uses a supplier finance program to purchase goods or services to disclose qualitative and quantitative information about its supplier finance program(s). This will allow financial statement users to better consider the effect of the program(s) on the entity's working capital, liquidity and cash flow over time. ASU 2022-04 is effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years, except for the amendment on rollforward information, which is effective for fiscal years beginning after December 15, 2023 with early adoption permitted. ASU 2022-04 should be applied retrospectively to each period in which a balance sheet is presented except for the amendment on rollforward information, which should be applied prospectively. The Company adopted this ASU on January 1, 2023, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows as the Company has no current supplier finance programs.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-23-000151:notes:5]
[same as prior period, unchanged from 0000038725-23-000070:notes:5]

[0000038725-23-000151:notes:6]
During the first quarter ended March 31, 2023, the Company acquired all of the assets of Phil-Good Products, Inc. ("Phil-Good"). Phil-Good is an injection molded plastics component manufacturer. In another separate transaction in the first quarter of 2023, the Company acquired 100 percent of the ownership interests of Hydropompe S.r.l. ("Hydropompe"). Hydropompe is a pump manufacturer with a focus in dewatering and sewage products. The combined, all-cash purchase price for both acquisitions in the first quarter of 2023 was $8.7 million after purchase price adjustments based on the level of working capital acquired. The fair value of the assets acquired and liabilities assumed for both acquisitions is preliminary as of June 30, 2023. In addition, the Company has not presented separate results of operations of the acquired companies since the closing of the acquisitions or combined pro forma financial information of the Company and the acquired interests since the beginning of 2022, as the results of operations for both acquisitions are immaterial.

[0000038725-23-000151:notes:7]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations and were insignificant for all periods presented.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-23-000151:notes:8]
FAIR VALUE MEASUREMENTSFASB ASC Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy. Fair value is defined as the exchange price that would be received for 
an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value. The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-23-000151:notes:9]
[same as prior period, unchanged from 0000038725-23-000070:notes:12]

[0000038725-23-000151:notes:10]
[same as prior period, unchanged from 0000038725-23-000070:notes:13]

[0000038725-23-000151:notes:11]
[same as prior period, unchanged from 0000038725-23-000070:notes:14]

[0000038725-23-000151:notes:12]
As of June 30, 2023 and December 31, 2022, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-23-000151:notes:13]
| (In millions) | June 30, 2023 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 11.7 |  | $ | 11.7 |  | $ | — |  | $ | — |  |
| Share swap transaction | 0.9 |  | 0.9 |  | — |  | — |  |
| Total assets | $ | 12.6 |  | $ | 12.6 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Forward currency contracts | $ | 0.1 |  | $ | — |  | $ | 0.1 |  | $ | — |  |
| Total liabilities | $ | 0.1 |  | $ | — |  | $ | 0.1 |  | $ | — |  |
|  | December 31, 2022 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 7.9 |  | $ | 7.9 |  | $ | — |  | $ | — |  |
| Total assets | $ | 7.9 |  | $ | 7.9 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Share swap transaction | $ | 0.1 |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Total liabilities | $ | 0.1 |  | $ | 0.1 |  | $ | — |  | $ | — |  |

[0000038725-23-000151:notes:14]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The share swap transaction and forward currency contracts assets and liabilities are recorded within the "Receivables" and "Accounts Payable" lines of the condensed consolidated balance sheets and are further described in Note 5 - Financial Instruments. 
Total debt, including current maturities, have carrying amounts of $248.5 million and $216.1 million and estimated fair values of $244.9 million and $213.2 million as of June 30, 2023 and December 31, 2022, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-23-000151:notes:15]
FINANCIAL INSTRUMENTSThe Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written 
notice by either party. As of June 30, 2023 and December 31, 2022, respectively, the swap had a notional value based on 240,000 shares and 225,000 shares. For the second quarter and six months ended June 30, 2023, changes in the fair value of the swap resulted in a gain of $1.7 million and a gain of $4.7 million, respectively. For the second quarter and six months ended June 30, 2022, changes in the fair value of the swap resulted in a loss of $2.1 million and a loss of $4.6 million, respectively. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.

[0000038725-23-000151:notes:16]
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of June 30, 2023 and December 31, 2022, respectively, the Company had a notional amount of $27.9 million and $10.3 million in forward currency contracts outstanding and the related fair value of those contracts was not material.  For the second quarter and six months ended June 30, 2023, changes in the fair value of the forward currency contracts resulted in gains of $0.6 million and $1.6 million, respectively. For the second quarter and six months ended June 30, 2022, changes in the fair value of the forward currency contracts resulted in gains of $0.5 million and $0.3 million, respectively. These gains are recorded in the Company's condensed consolidated statements of income within the "Foreign exchange expense" line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-23-000151:notes:17]
GOODWILL AND OTHER INTANGIBLE ASSETS
The carrying amounts of the Company’s intangible assets, excluding goodwill, are as follows:

[0000038725-23-000151:notes:18]
| (In millions) |  | June 30, 2023 |  | December 31, 2022 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Definite-lived intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | 252.2 |  |  | (108.8) |  |  | 251.6 |  |  | (101.5) |  |
| Patents |  | $ | 7.3 |  |  | $ | (7.3) |  |  | $ | 7.3 |  |  | $ | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.4) |  |  | 7.5 |  |  | (7.4) |  |
| Trade names |  | 41.7 |  |  | (4.8) |  |  | $ | 41.8 |  |  | (3.7) |  |
| Other |  | 3.4 |  |  | (2.8) |  |  | 3.4 |  |  | (2.7) |  |
| Total |  | $ | 312.1 |  |  | $ | (131.1) |  |  | $ | 311.6 |  |  | $ | (122.6) |  |
| Indefinite-lived intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 43.0 |  |  | — |  |  | 42.3 |  |  | — |  |
| Total intangibles |  | $ | 355.1 |  |  | $ | (131.1) |  |  | $ | 353.9 |  |  | $ | (122.6) |  |

[0000038725-23-000151:notes:19]
Amortization expense related to intangible assets for the second quarters ended June 30, 2023 and June 30, 2022 was $4.3 million and $4.4 million, respectively, and for the six months ended June 30, 2023 and June 30, 2022 was $8.5 million and $8.7 million, respectively.

[0000038725-23-000151:notes:20]
The change in the carrying amount of goodwill by reportable segment for the six months ended June 30, 2023 is as follows:

[0000038725-23-000151:notes:21]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2022 |  | $ | 211.9 |  |  | $ | 70.3 |  |  | $ | 45.8 |  |  | $ | 328.0 |  |
| Acquisitions |  | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| Foreign currency translation |  | 1.1 |  |  | 0.2 |  |  | — |  |  | 1.3 |  |
| Balance as of June 30, 2023 |  | $ | 214.0 |  |  | $ | 70.5 |  |  | $ | 45.8 |  |  | $ | 330.3 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-23-000151:notes:22]
EMPLOYEE BENEFIT PLANS
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the second quarters and six months ended June 30, 2023 and June 30, 2022:

[0000038725-23-000151:notes:23]
| (In millions) | Pension Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2023 |  | June 30, 2022 |  | June 30, 2023 |  | June 30, 2022 |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |
| Interest cost | 1.8 |  |  | 0.8 |  |  | 3.3 |  |  | 1.6 |  |
| Expected return on assets | (1.8) |  |  | (1.5) |  |  | (3.6) |  |  | (3.0) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.5 |  |  | 1.2 |  |  | 1.1 |  |  | 2.4 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.7 |  |  | $ | 0.7 |  |  | $ | 1.1 |  |  | $ | 1.4 |  |

[0000038725-23-000151:notes:24]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the second quarters and six months ended June 30, 2023 and June 30, 2022:

[0000038725-23-000151:notes:25]
| (In millions) | Other Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2023 |  | June 30, 2022 |  | June 30, 2023 |  | June 30, 2022 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | 0.1 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-23-000151:notes:26]
[same as prior period, unchanged from 0000038725-23-000070:notes:29]

[0000038725-23-000151:notes:27]
| (In millions) |  | June 30, 2023 |  | December 31, 2022 |
| Salaries, wages, and commissions |  | 40.3 |  |  | 57.9 |  |
| Product warranty costs |  | 10.7 |  |  | 11.2 |  |
| Insurance |  | 3.0 |  |  | 1.7 |  |
| Employee benefits |  | 8.9 |  |  | 13.5 |  |
| Other |  | 32.2 |  |  | 36.3 |  |
| Total |  | 95.1 |  |  | 120.6 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-23-000151:notes:28]
INCOME TAXES
The Company’s effective tax rate for the six-month period ended June 30, 2023, was 20.0 percent as compared to 21.2 percent for the six-month period ended June 30, 2022. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to the recognition of the U.S. foreign-derived intangible income (FDII) provisions, partially offset by state taxes, and certain discrete events including excess tax benefits from share-based compensation. For the second quarter of 2023, the effective tax rate was 19.1 percent compared to 21.9 percent for the second quarter of 2022.

[0000038725-23-000151:notes:29]
The decrease in the effective tax rates for the second quarter and first six months of 2023 compared to the comparable periods in the prior year was a result of more favorable discrete events in 2023, primarily related to excess tax benefits from share-based compensation.


## us-gaap:DebtDisclosureTextBlock

[0000038725-23-000151:notes:30]
DEBT
Debt consisted of the following:

[0000038725-23-000151:notes:31]
| (In millions) |  | June 30, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 158.3 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.7 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 0.6 |  |  | 3.1 |  |
| Other |  | — |  |  | — |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 248.5 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (159.8) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.7 |  |  | 89.3 |

[0000038725-23-000151:notes:32]
Credit Agreement

[0000038725-23-000151:notes:33]
As of June 30, 2023, the Company had $158.3 million outstanding borrowings with a weighted-average interest rate of 5.9 percent, $3.6 million in letters of credit outstanding, and $188.1 million of available capacity under its credit agreement. As of December 31, 2022, the Company had $122.8 million outstanding borrowings with a weighted-average interest rate of 5.0 percent, $4.0 million in letters of credit outstanding, and $223.2 million of available capacity under its credit agreement.

[0000038725-23-000151:notes:34]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $20.3 million. As of June 30, 2023, there were $0.1 million outstanding borrowings and $20.2 million of available capacity under these lines of credit. As of December 31, 2022, there were $22.0 million overdraft lines of credit with $2.7 million of outstanding borrowings and $19.3 million of available capacity under these lines of credit.


## us-gaap:EarningsPerShareTextBlock

[0000038725-23-000151:notes:35]
[same as prior period, unchanged from 0000038725-23-000070:notes:38]

[0000038725-23-000151:notes:36]
[same as prior period, unchanged from 0000038725-23-000070:notes:39]

[0000038725-23-000151:notes:37]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions, except per share amounts) | June 30, 2023 |  | June 30, 2022 |  | June 30, 2023 |  | June 30, 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 59.6 |  |  | $ | 59.4 |  |  | $ | 96.9 |  |  | $ | 89.1 |  |
| Less: Earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.3 |  |  | 0.4 |  |
| Net income available to common shareholders | $ | 59.4 |  |  | $ | 59.2 |  |  | $ | 96.6 |  |  | $ | 88.7 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.2 |  |  | 46.3 |  |  | 46.2 |  |  | 46.4 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors | 0.7 |  |  | 0.6 |  |  | 0.7 |  |  | 0.7 |  |
| Diluted weighted average common shares outstanding | 46.9 |  |  | 46.9 |  |  | 46.9 |  |  | 47.1 |  |
| Basic earnings per share | $ | 1.29 |  |  | $ | 1.27 |  |  | $ | 2.09 |  |  | $ | 1.91 |  |
| Diluted earnings per share | $ | 1.27 |  |  | $ | 1.26 |  |  | $ | 2.06 |  |  | $ | 1.89 |  |

[0000038725-23-000151:notes:38]
There were 0.1 million and 0.1 million stock options outstanding for the second quarters ended June 30, 2023 and June 30, 2022, and 0.1 million and 0.1 million stock options outstanding for the six months ended June 30, 2023 and June 30, 2022, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-23-000151:notes:39]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the second quarters and six months ended June 30, 2023 and June 30, 2022:

[0000038725-23-000151:notes:40]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2023 | $ | 4,614 |  |  | $ | 332,263 |  |  | $ | 980,114 |  |  |  |  |  |  | $ | (224,560) |  |  | $ | 2,537 |  |  | $ | 1,094,968 |  |  | $ | 633 |  |
| Net income | — |  |  | — |  |  | 59,600 |  |  |  |  |  |  | — |  |  | 292 |  |  | 59,892 |  |  | 268 |  |
| Dividends on common stock ($0.225/share) | — |  |  | — |  |  | (10,432) |  |  |  |  |  |  | — |  |  | — |  |  | (10,432) |  |  | — |  |
| Common stock issued | 15 |  |  | 6,057 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 6,072 |  |  | — |  |
| Common stock repurchased | (9) |  |  | — |  |  | (8,399) |  |  |  |  |  |  | — |  |  | — |  |  | (8,408) |  |  | — |  |
| Share-based compensation | 6 |  |  | 2,492 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 2,498 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 4,482 |  |  | 13 |  |  | 4,495 |  |  | — |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 416 |  |  | — |  |  | 416 |  |  | — |  |
| Balance as of June 30, 2023 | $ | 4,626 |  |  | $ | 340,812 |  |  | $ | 1,020,883 |  |  |  |  |  |  | $ | (219,662) |  |  | $ | 2,842 |  |  | $ | 1,149,501 |  |  | $ | 901 |  |
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2022 | $ | 4,635 |  |  | $ | 314,935 |  |  | $ | 861,156 |  |  |  |  |  |  | $ | (219,019) |  |  | $ | 2,352 |  |  | $ | 964,059 |  |  | $ | 106 |  |
| Net income | — |  |  | — |  |  | 59,364 |  |  |  |  |  |  | — |  |  | 229 |  |  | 59,593 |  |  | 170 |  |
| Dividends on common stock ($0.195/share) | — |  |  | — |  |  | (9,076) |  |  |  |  |  |  | — |  |  | — |  |  | (9,076) |  |  | — |  |
| Common stock issued | 3 |  |  | 1,570 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 1,573 |  |  | — |  |
| Common stock repurchased | (15) |  |  | — |  |  | (11,309) |  |  |  |  |  |  | — |  |  | — |  |  | (11,324) |  |  | — |  |
| Share-based compensation | 5 |  |  | 2,332 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 2,337 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (19,418) |  |  | (95) |  |  | (19,513) |  |  | 8 |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 924 |  |  | — |  |  | 924 |  |  | — |  |
| Balance as of June 30, 2022 | $ | 4,628 |  |  | $ | 318,837 |  |  | $ | 900,135 |  |  |  |  |  |  | $ | (237,513) |  |  | $ | 2,486 |  |  | $ | 988,573 |  |  | $ | 284 |  |

[0000038725-23-000151:notes:41]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2022 | $ | 4,619 |  |  | $ | 325,426 |  |  | $ | 969,261 |  |  |  |  |  |  | $ | (231,448) |  |  | $ | 2,276 |  |  | $ | 1,070,134 |  |  | $ | 620 |  |
| Net Income | — |  |  | — |  |  | 96,925 |  |  |  |  |  |  | — |  |  | 530 |  |  | 97,455 |  |  | 281 |  |
| Dividends on common stock ($0.450/share) | — |  |  | — |  |  | (20,872) |  |  |  |  |  |  | — |  |  | — |  |  | (20,872) |  |  | — |  |
| Common stock issued | 22 |  |  | 8,988 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 9,010 |  |  | — |  |
| Common stock repurchased | (27) |  |  | — |  |  | (24,431) |  |  |  |  |  |  | — |  |  | — |  |  | (24,458) |  |  | — |  |
| Share-based compensation | 12 |  |  | 6,398 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 6,410 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 10,953 |  |  | 36 |  |  | 10,989 |  |  | — |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 833 |  |  | — |  |  | 833 |  |  | — |  |
| Balance as of June 30, 2023 | $ | 4,626 |  |  | $ | 340,812 |  |  | $ | 1,020,883 |  |  |  |  |  |  | $ | (219,662) |  |  | $ | 2,842 |  |  | $ | 1,149,501 |  |  | $ | 901 |  |
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2021 | $ | 4,648 |  |  | $ | 310,617 |  |  | $ | 859,817 |  |  |  |  |  |  | $ | (228,581) |  |  | $ | 2,161 |  |  | $ | 948,662 |  |  | $ | (19) |  |
| Net Income | — |  |  | — |  |  | 89,129 |  |  |  |  |  |  | — |  |  | 464 |  |  | 89,593 |  |  | 289 |  |
| Dividends on common stock ($0.390/share) | — |  |  | — |  |  | (18,205) |  |  |  |  |  |  | — |  |  | — |  |  | (18,205) |  |  | — |  |
| Common stock issued | 4 |  |  | 1,912 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 1,916 |  |  | — |  |
| Common stock repurchased | (38) |  |  | — |  |  | (30,606) |  |  |  |  |  |  | — |  |  | — |  |  | (30,644) |  |  | — |  |
| Share-based compensation | 14 |  |  | 6,308 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 6,322 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (10,788) |  |  | (139) |  |  | (10,927) |  |  | 14 |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 1,856 |  |  | — |  |  | 1,856 |  |  | — |  |
| Balance as of June 30, 2022 | $ | 4,628 |  |  | $ | 318,837 |  |  | $ | 900,135 |  |  |  |  |  |  | $ | (237,513) |  |  | $ | 2,486 |  |  | $ | 988,573 |  |  | $ | 284 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-23-000151:notes:42]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the six months ended June 30, 2023 and June 30, 2022, are summarized below:

[0000038725-23-000151:notes:43]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| For the six months ended June 30, 2023: |  |  |
| Balance as of December 31, 2022 | $ | (191.3) |  |  | $ | (40.1) |  |  | $ | (231.4) |  |
| Other comprehensive income/(loss) before reclassifications | 10.9 |  |  | — |  |  | 10.9 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.8 |  |  | 0.8 |  |
| Net other comprehensive income/(loss) | 10.9 |  |  | 0.8 |  |  | 11.7 |  |
| Balance as of June 30, 2023 | $ | (180.4) |  |  | $ | (39.3) |  |  | $ | (219.7) |  |
| For the six months ended June 30, 2022: |  |  |  |  |  |
| Balance as of December 31, 2021 | $ | (179.6) |  |  | $ | (49.0) |  |  | $ | (228.6) |  |
| Other comprehensive income/(loss) before reclassifications | (10.7) |  |  | — |  |  | (10.7) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.8 |  |  | 1.8 |  |
| Net other comprehensive income/(loss) | (10.7) |  |  | 1.8 |  |  | (8.9) |  |
| Balance as of June 30, 2022 | $ | (190.3) |  |  | $ | (47.2) |  |  | $ | (237.5) |  |

[0000038725-23-000151:notes:44]
[same as prior period, unchanged from 0000038725-23-000070:notes:46]

[0000038725-23-000151:notes:45]
(2) Net of tax expense of $0.3 million and $0.5 million for the six months ended June 30, 2023 and June 30, 2022, respectively.

[0000038725-23-000151:notes:46]
[same as prior period, unchanged from 0000038725-23-000070:notes:48]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-23-000151:notes:47]
[same as prior period, unchanged from 0000038725-23-000070:notes:49]

[0000038725-23-000151:notes:48]
[same as prior period, unchanged from 0000038725-23-000070:notes:50]

[0000038725-23-000151:notes:49]
[same as prior period, unchanged from 0000038725-23-000070:notes:51]

[0000038725-23-000151:notes:50]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions) | June 30, 2023 |  | June 30, 2022 |  | June 30, 2023 |  | June 30, 2022 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 176.8 |  |  | $ | 158.4 |  |  | $ | 336.2 |  |  | $ | 293.1 |  |
| Latin America | 42.0 |  |  | 41.7 |  |  | 82.3 |  |  | 79.6 |  |
| Europe, Middle East & Africa | 54.6 |  |  | 49.7 |  |  | 105.0 |  |  | 100.7 |  |
| Asia Pacific | 22.2 |  |  | 24.2 |  |  | 41.0 |  |  | 44.7 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 26.1 |  |  | 36.5 |  |  | 63.8 |  |  | 65.0 |  |
| Total sales | 321.7 |  |  | 310.5 |  |  | 628.3 |  |  | 583.1 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 193.1 |  |  | 191.1 |  |  | 336.1 |  |  | 326.0 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 193.1 |  |  | 191.1 |  |  | 336.1 |  |  | 326.0 |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 60.4 |  |  | 64.2 |  |  | 114.4 |  |  | 116.0 |  |
| All other | 20.0 |  |  | 21.8 |  |  | 38.7 |  |  | 42.5 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 80.4 |  |  | 86.0 |  |  | 153.1 |  |  | 158.5 |  |
| Intersegment Eliminations/Other | (26.1) |  |  | (36.5) |  |  | (63.8) |  |  | (65.0) |  |
| Consolidated | $ | 569.1 |  |  | $ | 551.1 |  |  | $ | 1,053.7 |  |  | $ | 1,002.6 |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2023 |  | June 30, 2022 |  | June 30, 2023 |  | June 30, 2022 |
|  | Operating income/(loss) |
| Water Systems | $ | 50.8 |  |  | $ | 49.0 |  |  | $ | 99.8 |  |  | $ | 82.2 |  |
| Distribution | 17.8 |  |  | 23.3 |  |  | 22.5 |  |  | 32.7 |  |
| Fueling Systems | 26.7 |  |  | 26.1 |  |  | 47.5 |  |  | 43.8 |  |
| Intersegment Eliminations/Other | (14.4) |  |  | (17.4) |  |  | (36.3) |  |  | (37.8) |  |
| Consolidated | $ | 80.9 |  |  | $ | 81.0 |  |  | $ | 133.5 |  |  | $ | 120.9 |  |

[0000038725-23-000151:notes:51]
|  | June 30, 2023 |  | December 31, 2022 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 1,058.6 |  |  | $ | 1,017.5 |  |  |  |  |  |
| Distribution | 412.4 |  |  | 360.4 |  |  |  |  |  |
| Fueling Systems | 276.6 |  |  | 269.1 |  |  |  |  |  |
| Other | 55.5 |  |  | 47.2 |  |  |  |  |  |
| Consolidated | $ | 1,803.1 |  |  | $ | 1,694.2 |  |  |  |  |  |

[0000038725-23-000151:notes:52]
[same as prior period, unchanged from 0000038725-23-000070:notes:54]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-23-000151:notes:53]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position,  results of operations, or cash flows.

[0000038725-23-000151:notes:54]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-23-000151:notes:55]
At June 30, 2023, the Company had $11.1 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-23-000151:notes:56]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2023, are as follows:

[0000038725-23-000151:notes:57]
| (In millions) |  |  |
| Balance as of December 31, 2022 |  | $ | 11.2 |  |
| Accruals related to product warranties |  | 6.4 |  |
| Reductions for payments made |  | (6.9) |  |
| Balance as of June 30, 2023 |  | $ | 10.7 |  |
