# FELE MD&A — 0000038725-23-000151


## mdna

[0000038725-23-000151:mdna:1]
[same as prior period, unchanged from 0000038725-23-000070:mdna:1]

[0000038725-23-000151:mdna:2]
Second Quarter 2023 vs. Second Quarter 2022

[0000038725-23-000151:mdna:3]
[same as prior period, unchanged from 0000038725-23-000070:mdna:3]

[0000038725-23-000151:mdna:4]
Net sales in the second quarter and first six months of 2023 increased 3 percent and 5 percent, respectively, from the prior-year periods. The sales increase was primarily due to price realization and volume, partially offset by the negative impact of foreign currency translation. The Company's consolidated gross profit was $188.5 million and $350.7 million, respectively, for the second quarter and first six months of 2023, a decrease of $0.8 million and an increase of $16.1 million, respectively, from the prior-year periods. Diluted earnings per share was $1.27 and $2.06, respectively, for the second quarter and first six months of 2023, increases of $0.01 and $0.17, respectively, from the prior-year periods.

[0000038725-23-000151:mdna:5]
[same as prior period, unchanged from 0000038725-23-000070:mdna:5]

[0000038725-23-000151:mdna:6]
[same as prior period, unchanged from 0000038725-23-000070:mdna:6]

[0000038725-23-000151:mdna:7]
|  | Net Sales |
| (In millions) | Q2 2023 |  | Q2 2022 |  | 2023 v 2022 |
| Water Systems | $ | 321.7 |  |  | $ | 310.5 |  |  | $ | 11.2 |  |
| Fueling Systems | 80.4 |  |  | 86.0 |  |  | (5.6) |  |
| Distribution | 193.1 |  |  | 191.1 |  |  | 2.0 |  |
| Eliminations/Other | (26.1) |  |  | (36.5) |  |  | 10.4 |  |
| Consolidated | $ | 569.1 |  |  | $ | 551.1 |  |  | $ | 18.0 |  |

[0000038725-23-000151:mdna:8]
|  | Net Sales |
| (In millions) | YTD June 30, 2023 |  | YTD June 30, 2022 |  | 2023 v 2022 |
| Water Systems | 628.3 |  |  | $ | 583.1 |  |  | $ | 45.2 |  |
| Fueling Systems | 153.1 |  |  | 158.5 |  |  | (5.4) |  |
| Distribution | 336.1 |  |  | 326.0 |  |  | 10.1 |  |
| Eliminations/Other | (63.8) |  |  | (65.0) |  |  | 1.2 |  |
| Consolidated | $ | 1,053.7 |  |  | $ | 1,002.6 |  |  | $ | 51.1 |  |

[0000038725-23-000151:mdna:9]
Net sales increased 3 percent in the second quarter and 5 percent in the first six months of 2023, as compared to the prior-year periods. Foreign currency unfavorably impacted net sales by 2 and 3 percentage points during the second quarter and first six months of 2023, respectively, compared to the prior-year periods, principally due to the strengthening of the U.S. Dollar relative to the Turkish Lira and Argentine Peso.

[0000038725-23-000151:mdna:10]
[same as prior period, unchanged from 0000038725-23-000070:mdna:9]

[0000038725-23-000151:mdna:11]
Water Systems net sales increased 4 percent in the second quarter and 8 percent in the first six months of 2023, as compared to the prior-year periods. This sales growth was primarily due to price and volume, which increased due to strong end market demand. Partially offsetting the increase, sales decreased 4 percent in the second quarter and 5 percent in the first six months of 2023 due to the negative impact from foreign exchange rates, as compared to prior-year periods. While net sales increased in 2023, Water Systems sales were negatively impacted by unfavorable weather conditions and customer inventories trending to more normalized levels.

[0000038725-23-000151:mdna:12]
Water Systems net sales in the U.S. and Canada increased 4 percent in the second quarter and 12 percent in the first six months of 2023, as compared to the prior-year periods. Sales decreased 1 percent in both the second quarter and first six months of 2023 due to the negative impact from foreign exchange rates, as compared to prior-year periods. In the second quarter of 2023, sales of large dewatering equipment increased 102 percent, sales of groundwater pumping equipment decreased 16 percent and sales of all other surface pumping equipment were flat compared to 2022. In the first half of 2023, sales of large dewatering equipment increased 120 percent, sales of groundwater pumping equipment decreased 5 percent and sales of all other surface pumping equipment increased 6 percent compared to 2022.

[0000038725-23-000151:mdna:13]
Water Systems net sales in markets outside the U.S. and Canada increased 3 percent in the second quarter and 1 percent in the first six months of 2023, as compared to the prior-year periods. Sales decreased 10 percent in the second quarter and 11 percent in the first six months of 2023 due to the negative impact from foreign exchange rates, as compared to prior-year periods.  In both the second quarter and first half of 2023, outside the U.S. and Canada, excluding the impact of foreign currency translation, sales increases in EMEA and Latin America more than offset sales declines in the Asia Pacific markets.

[0000038725-23-000151:mdna:14]
[same as prior period, unchanged from 0000038725-23-000070:mdna:13]

[0000038725-23-000151:mdna:15]
Fueling Systems net sales decreased 7 percent in the second quarter and 3 percent in the first six months of 2023, as compared to the prior-year periods. This sales decline was primarily due to lower volumes. Sales decreased less than 1 percent in both the second quarter and first six months of 2023 due to the negative impact from foreign exchange rates, as compared to prior-year periods.

[0000038725-23-000151:mdna:16]
Fueling Systems net sales in the U.S. and Canada decreased 6 percent in the second quarter and 1 percent in the first six months of 2023, as compared to the prior-year periods. The decrease was primarily in dispensing and piping. Outside the U.S. and Canada, Fueling Systems sales decreased 8 percent in the second quarter and 9 percent in the first six months of 2023, as compared to the prior-year periods, due primarily to the divestiture of the above ground storage tank business in 2022 and lower sales in China.

[0000038725-23-000151:mdna:17]
[same as prior period, unchanged from 0000038725-23-000070:mdna:16]

[0000038725-23-000151:mdna:18]
Distribution net sales increased 1 percent in the second quarter and 3 percent in the first six months of 2023, as compared to the prior-year periods. The Distribution segment sales growth was primarily due to price and volume. While net sales increased in 2023, Distribution sales were negatively impacted by unfavorable weather conditions, commodity pricing continuing to decline and customer inventories trending to more normalized levels.

[0000038725-23-000151:mdna:19]
Gross Profit and Expenses Ratios

[0000038725-23-000151:mdna:20]
|  | Three months ended June 30, |
| (In Millions) | 2023 |  | % of Net Sales |  | 2022 |  | % of Net Sales |
| Gross Profit | $ | 188.5 |  |  | 33.1 | % |  | $189.3 |  | 34.3 | % |
| Selling, General and Administrative Expense | 107.4 |  |  | 18.9 | % |  | 108.3 |  |  | 19.7 | % |

[0000038725-23-000151:mdna:21]
|  | Six months ended June 30, |
| (In Millions) | 2023 |  | % of Net Sales |  | 2022 |  | % of Net Sales |
| Gross Profit | $ | 350.7 |  |  | 33.3 | % |  | $ | 334.6 |  |  | 33.4 | % |
| Selling, General and Administrative Expense | 217.0 |  |  | 20.6 | % |  | 213.0 |  |  | 21.2 | % |

[0000038725-23-000151:mdna:22]
Gross Profit

[0000038725-23-000151:mdna:23]
The gross profit margin ratio was 33.1 percent and 33.3 percent in the second quarter and first six months of 2023, respectively, and 34.3 percent and 33.4 percent in the second quarter and first six months of 2022, respectively. The gross profit margin was negatively impacted in the second quarter and first six months of 2023 by wet weather across much of the United States and margin compression from unfavorable pricing of commodity-based products sold through the Distribution business.

[0000038725-23-000151:mdna:24]
[same as prior period, unchanged from 0000038725-23-000070:mdna:20]

[0000038725-23-000151:mdna:25]
SG&A expenses were $107.4 million in the second quarter and $217.0 million in the first half of 2023 compared to $108.3 million in the second quarter and $213.0 million in the first half of 2022. SG&A expenses decreased in the second quarter of 2023 primarily due to lower advertising and marketing expenses. SG&A expenses increased in the first half of 2023 primarily due to higher compensation costs, partially offset by lower advertising and marketing expenses. The SG&A expenses ratio was 18.9 percent and 20.6 percent in the second quarter and first six months of 2023, respectively, and 19.7 percent and 21.2 percent in the second quarter and first six months of 2022, respectively.

[0000038725-23-000151:mdna:26]
[same as prior period, unchanged from 0000038725-23-000070:mdna:22]

[0000038725-23-000151:mdna:27]
Restructuring expenses were $0.1 million and $0.3 million in the second quarter and first six months of 2023, respectively, and nil and $0.7 million in the second quarter and first six months of 2022, respectively. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities, branch closings and consolidations.

[0000038725-23-000151:mdna:28]
[same as prior period, unchanged from 0000038725-23-000070:mdna:24]

[0000038725-23-000151:mdna:29]
Operating income decreased less than 1 percent and increased 10 percent in the second quarter and first six months of 2023, as compared to the prior-year periods.

[0000038725-23-000151:mdna:30]
|  |  | Operating income (loss) |
| (In millions) |  | Q2 2023 |  | Q2 2022 |  | 2023 v 2022 |
| Water Systems |  | $ | 50.8 |  |  | $ | 49.0 |  |  | $ | 1.8 |  |
| Fueling Systems |  | 26.7 |  |  | 26.1 |  |  | 0.6 |  |
| Distribution |  | 17.8 |  |  | 23.3 |  |  | (5.5) |  |
| Eliminations/Other |  | (14.4) |  |  | (17.4) |  |  | 3.0 |  |
| Consolidated |  | $ | 80.9 |  |  | $ | 81.0 |  |  | $ | (0.1) |  |

[0000038725-23-000151:mdna:31]
|  |  | Operating income (loss) |
| (In millions) |  | YTD June 30, 2023 |  | YTD June 30, 2022 |  | 2023 v 2022 |
| Water Systems |  | $ | 99.8 |  |  | $ | 82.2 |  |  | $ | 17.6 |  |
| Fueling Systems |  | 47.5 |  |  | 43.8 |  |  | 3.7 |  |
| Distribution |  | 22.5 |  |  | 32.7 |  |  | (10.2) |  |
| Eliminations/Other |  | (36.3) |  |  | (37.8) |  |  | 1.5 |  |
| Consolidated |  | $ | 133.5 |  |  | $ | 120.9 |  |  | $ | 12.6 |  |

[0000038725-23-000151:mdna:32]
[same as prior period, unchanged from 0000038725-23-000070:mdna:27]

[0000038725-23-000151:mdna:33]
Water Systems operating income increased $1.8 million in the second quarter and $17.6 million in the first six months of 2023, as compared to the prior-year periods, primarily due to higher sales. The second quarter operating income margin was 15.8 percent, unchanged from the second quarter of 2022. The first six months of 2023 operating income margin was 15.9 percent, an increase of 180 basis points from 14.1 percent in the first six months of 2022. Operating income margin increased in the first half primarily due to price realization, cost management and operating leverage on higher sales.

[0000038725-23-000151:mdna:34]
[same as prior period, unchanged from 0000038725-23-000070:mdna:29]

[0000038725-23-000151:mdna:35]
Fueling Systems operating income increased $0.6 million in the second quarter and $3.7 million in the first six months of 2023, as compared to the prior-year periods, primarily due to a favorable product and geographic mix of net sales. The second quarter operating income margin was 33.2 percent, an increase of 290 basis points from 30.3 percent in the second quarter of 2022. The first six months of 2023 operating income margin was 31.0 percent, an increase of 340 basis points from 27.6 percent in the first six months of 2022. Operating income margin increased primarily due to price realization and a favorable product and geographic sales mix shift.

[0000038725-23-000151:mdna:36]
[same as prior period, unchanged from 0000038725-23-000070:mdna:31]

[0000038725-23-000151:mdna:37]
Distribution operating income decreased $5.5 million in the second quarter and $10.2 million in the first six months of 2023, as compared to the prior-year periods. The second quarter operating income margin was 9.2 percent, a decrease of 300 basis points from 12.2 percent in the second quarter of 2022. The first six months of 2023 operating income margin was 6.7 percent, a decrease of 330 basis points from 10.0 percent in the first six months of 2022. Operating income and operating income margin decreased primarily due to wet weather across much of the United States, unfavorable pricing of commodity-based products sold through the business and inventory destocking.

[0000038725-23-000151:mdna:38]
[same as prior period, unchanged from 0000038725-23-000070:mdna:33]

[0000038725-23-000151:mdna:39]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the second quarter and first six months of 2023 compared to the prior-year periods of 2022 was a favorable $4.0 million and $3.2 million, respectively. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses increased $1.0 million and $1.7 million, respectively, compared to the prior- year periods, in part due to higher compensation, software, professional fees and travel expenses.

[0000038725-23-000151:mdna:40]
[same as prior period, unchanged from 0000038725-23-000070:mdna:35]

[0000038725-23-000151:mdna:41]
Interest expense was $4.2 million and $7.3 million in the second quarter and first six months of 2023, respectively, and $2.9 million and $4.4 million in the second quarter and first six months of 2022, respectively. The increases in the second quarter and first six months of 2023 were primarily driven by higher interest rates.

[0000038725-23-000151:mdna:42]
[same as prior period, unchanged from 0000038725-23-000070:mdna:37]

[0000038725-23-000151:mdna:43]
Other (income) expense, net was a gain of $1.2 million and $1.6 million in the second quarter and first six months of 2023, respectively, and an expense of $1.2 million and $1.5 million in the second quarter and first six months of 2022, respectively.

[0000038725-23-000151:mdna:44]
[same as prior period, unchanged from 0000038725-23-000070:mdna:39]

[0000038725-23-000151:mdna:45]
Foreign currency-based transactions produced an expense of $3.6 million and $5.6 million in the second quarter and first six months of 2023, respectively, and an expense of $0.3 million and $0.9 million in the second quarter and first six months of 2022, respectively. The expense in 2023 was primarily due to transaction losses associated with the Turkish Lira, Argentine and Mexican Peso relative to the U.S. dollar. The expense in 2022 was primarily due to transaction losses associated with the Argentine Peso and Turkish Lira. The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-23-000151:mdna:46]
[same as prior period, unchanged from 0000038725-23-000070:mdna:41]

[0000038725-23-000151:mdna:47]
The provision for income taxes in the second quarter and first six months of 2023 was $14.2 million and $24.4 million, respectively, and $16.8 million and $24.2 million in the second quarter and first six months of 2022, respectively. The effective tax rate for the second quarter and first six months of 2023 was 19.1 percent and 20.0 percent, respectively, and 21.9 percent and 21.2 percent in the second quarter and first six months of 2022, respectively. The decrease in the effective tax rates for the second quarter and first six months of 2023 compared to the comparable periods in the prior year was a result of more favorable discrete events in 2023, primarily related to excess tax benefits from share-based compensation.

[0000038725-23-000151:mdna:48]
[same as prior period, unchanged from 0000038725-23-000070:mdna:43]

[0000038725-23-000151:mdna:49]
Net income in the second quarter and first six months of 2023 was $60.2 million and $97.7 million, respectively, and $59.8 million and $89.9 million in the second quarter and first six months of 2022, respectively.  Net income attributable to Franklin Electric Co., Inc. in the second quarter and first six months of 2023 was $59.6 million and $96.9 million, respectively, or $1.27 and $2.06 per diluted share.  Net income attributable to Franklin Electric Co., Inc. in the second quarter and first six months of 2022 was $59.4 million and $89.1 million, respectively, or $1.26 and $1.89 per diluted share.

[0000038725-23-000151:mdna:50]
[same as prior period, unchanged from 0000038725-23-000070:mdna:45]

[0000038725-23-000151:mdna:51]
[same as prior period, unchanged from 0000038725-23-000070:mdna:46]

[0000038725-23-000151:mdna:52]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at June 30, 2023 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-23-000151:mdna:53]
As of June 30, 2023, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of June 30, 2023, the Company had $188.1 million borrowing capacity under its credit agreement as $3.6 million in letters of commercial and standby letters of credit were outstanding and undrawn and $158.3 million in revolver borrowings were drawn and outstanding, which were primarily used for funding working capital requirements.

[0000038725-23-000151:mdna:54]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of  $125.0 million as of June 30, 2023. The Company also has other long-term debt borrowings outstanding as of June 30, 2023. See Note 10 - Debt included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022, for additional information regarding these obligations and future maturities as well as Note 10 - Debt of this current quarterly report for changes to these agreements since December 31, 2022.

[0000038725-23-000151:mdna:55]
At June 30, 2023, the Company had $45.9 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate the majority of these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-23-000151:mdna:56]
[same as prior period, unchanged from 0000038725-23-000070:mdna:51]

[0000038725-23-000151:mdna:57]
The following table summarizes significant sources and uses of cash and cash equivalents for the first six months of 2023 and 2022.

[0000038725-23-000151:mdna:58]
| (in millions) |  | 2023 |  | 2022 |
| Net cash flows from operating activities |  | $ | 43.0 |  |  | $ | (62.5) |  |
| Net cash flows from investing activities |  | (26.9) |  |  | (21.5) |  |
| Net cash flows from financing activities |  | (5.4) |  |  | 79.3 |  |
| Impact of exchange rates on cash and cash equivalents |  | (3.3) |  |  | (2.6) |  |
| Change in cash and cash equivalents |  | $ | 7.4 |  |  | $ | (7.3) |  |

[0000038725-23-000151:mdna:59]
26

[0000038725-23-000151:mdna:60]
[same as prior period, unchanged from 0000038725-23-000070:mdna:54]

[0000038725-23-000151:mdna:61]
[same as prior period, unchanged from 0000038725-23-000070:mdna:55]

[0000038725-23-000151:mdna:62]
Net cash provided by operating activities was $43.0 million for the six months ended June 30, 2023 compared to $62.5 million used by operating activities for the six months ended June 30, 2022. The change in operating cash flow was primarily due to decreased working capital requirements.

[0000038725-23-000151:mdna:63]
[same as prior period, unchanged from 0000038725-23-000070:mdna:57]

[0000038725-23-000151:mdna:64]
[same as prior period, unchanged from 0000038725-23-000070:mdna:58]

[0000038725-23-000151:mdna:65]
Net cash used in investing activities was $26.9 million for the six months ended June 30, 2023 compared to $21.5 million used in investing activities for the six months ended June 30, 2022. The increase in cash used in investing activities was attributable to increased acquisition activity in the first six months of 2023.

[0000038725-23-000151:mdna:66]
[same as prior period, unchanged from 0000038725-23-000070:mdna:60]

[0000038725-23-000151:mdna:67]
[same as prior period, unchanged from 0000038725-23-000070:mdna:61]

[0000038725-23-000151:mdna:68]
Net cash used by financing activities was $5.4 million for the six months ended June 30, 2023 compared to $79.3 million provided by financing activities for the six months ended June 30, 2022. The change in financing cash flow was primarily attributable to decreased borrowings under the Company's revolving credit facility.

[0000038725-23-000151:mdna:69]
[same as prior period, unchanged from 0000038725-23-000070:mdna:63]
