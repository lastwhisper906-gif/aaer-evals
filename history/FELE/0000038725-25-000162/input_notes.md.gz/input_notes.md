# FELE notes — 0000038725-25-000162


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-25-000162:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2024, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2025, and for the second quarters and six months ended June 30, 2025 and June 30, 2024 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2025. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-25-000162:notes:2]
[same as prior period, unchanged from 0000038725-25-000084:notes:2]

[0000038725-25-000162:notes:3]
[same as prior period, unchanged from 0000038725-25-000084:notes:3]

[0000038725-25-000162:notes:4]
In March 2025, the Company acquired 100 percent of Barnes de Colombia S.A. ("Barnes"), a leading manufacturer and distributor of industrial and commercial pumps based in Cota, Cundinamarca, Colombia, for total upfront cash consideration of $96.6 million, net of cash acquired.

[0000038725-25-000162:notes:5]
The valuation of assets acquired and liabilities assumed has not yet been finalized as of June 30, 2025. As a result, the Company recorded preliminary estimates for the fair value of assets acquired and liabilities assumed as of the acquisition date. Finalization of the valuation during the measurement period could result in a change in the amounts recorded for the acquisition date fair value of intangible assets, goodwill and income taxes among other items. The completion of the valuation will occur no later than one year from the acquisition date. The following table summarizes the preliminary fair values of the assets acquired and liabilities assumed as of the acquisition date:

[0000038725-25-000162:notes:6]
| (in millions) |  |
| Assets acquired and liabilities assumed |  |
| Cash and cash equivalents | $ | 3.4 |  |
| Receivables | 9.6 |  |
| Inventories | 24.2 |  |
| Other current assets | 4.2 |  |
| Property, plant and equipment | 11.8 |  |
| Goodwill | 46.8 |  |
| Other intangible assets | 45.5 |  |
| Other non-current assets | 3.6 |  |
| Debt | (12.6) |  |
| Accounts payable | (9.7) |  |
| Accrued expenses and other current liabilities | (3.6) |  |
| Deferred tax liabilities | (20.4) |  |
| Other non-current liabilities | $ | (2.8) |  |
| Total assets acquired and liabilities assumed | $ | 100.0 |  |

[0000038725-25-000162:notes:7]
[same as prior period, unchanged from 0000038725-25-000084:notes:7]

[0000038725-25-000162:notes:8]
[same as prior period, unchanged from 0000038725-25-000084:notes:8]

[0000038725-25-000162:notes:9]
The results of operations of the acquired business have been included in the Company’s consolidated statement of income since the date the business was acquired. The Barnes acquisition contributed $15.0 million of net sales for the six months ended June 30, 2025 while the impact on net income was not significant. The Company has not presented pro forma financial information for the Barnes acquisition because its results are not material to the Company’s condensed consolidated financial statements.

[0000038725-25-000162:notes:10]
[same as prior period, unchanged from 0000038725-25-000084:notes:10]

[0000038725-25-000162:notes:11]
[same as prior period, unchanged from 0000038725-25-000084:notes:11]

[0000038725-25-000162:notes:12]
The valuation of assets acquired and liabilities assumed has not yet been finalized as of June 30, 2025. As a result, the Company recorded preliminary estimates for the fair value of assets acquired and liabilities assumed as of the acquisition date. Finalization of the valuation during the measurement period could result in a change in the amounts recorded for the acquisition date fair value of intangible assets, goodwill and income taxes among other items. The completion of the valuation will occur no later than one year from the acquisition date. The purchase price was primarily allocated to goodwill and other intangible assets as well as accounts receivable, inventory and fixed assets. The goodwill, which is not deductible for tax purposes, includes the value of an assembled workforce, potential future technologies as well as the overall strategic benefits provided to the Company’s product portfolio and is included in the Water Systems segment.

[0000038725-25-000162:notes:13]
[same as prior period, unchanged from 0000038725-25-000084:notes:13]

[0000038725-25-000162:notes:14]
For the second quarter and six months ended June 30, 2025, acquisition costs associated with the 2025 acquisitions were $0.6 million and $2.1 million, respectively. Acquisition costs for all periods in 2024 were insignificant.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-25-000162:notes:15]
[same as prior period, unchanged from 0000038725-25-000084:notes:15]

[0000038725-25-000162:notes:16]
| (In millions) |  | June 30, 2025 |  | December 31, 2024 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 304.5 |  |  | $ | (139.9) |  |  | $ | 263.4 |  |  | $ | (128.8) |  |
| Patents |  | 7.4 |  |  | (7.4) |  |  | 7.2 |  |  | (7.2) |  |
| Technology |  | 10.3 |  |  | (7.6) |  |  | 7.5 |  |  | (7.5) |  |
| Trade names |  | 56.9 |  |  | (9.8) |  |  | 44.5 |  |  | (8.1) |  |
| Other |  | 3.0 |  |  | (2.6) |  |  | 2.8 |  |  | (2.4) |  |
| Total |  | $ | 382.1 |  |  | $ | (167.3) |  |  | $ | 325.4 |  |  | $ | (154.0) |  |
| Non-amortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.6 |  |  | — |  |  | 41.6 |  |  | — |  |
| Total intangibles |  | $ | 424.7 |  |  | $ | (167.3) |  |  | $ | 367.0 |  |  | $ | (154.0) |  |

[0000038725-25-000162:notes:17]
Amortization expense related to intangible assets for the second quarters ended June 30, 2025 and June 30, 2024 was $6.0 million and $4.7 million, respectively, and for six months ended June 30, 2025 and June 30, 2024 was $11.1 million and $9.5 million, respectively.

[0000038725-25-000162:notes:18]
The change in the carrying amount of goodwill by reportable segment for the six months ended June 30, 2025 is as follows:

[0000038725-25-000162:notes:19]
| (In millions) |  |  |
|  |  | Water Systems |  | Energy Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2024 |  | $ | 217.6 |  |  | $ | 70.3 |  |  | $ | 50.6 |  |  | $ | 338.5 |  |
| Acquisitions |  | 52.7 |  |  | — |  |  | — |  |  | 52.7 |  |
| Adjustments to prior year acquisitions |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Foreign currency translation |  | 4.4 |  |  | 0.3 |  |  | — |  |  | 4.7 |  |
| Balance as of June 30, 2025 |  | $ | 274.8 |  |  | $ | 70.6 |  |  | $ | 50.6 |  |  | $ | 396.0 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-25-000162:notes:20]
[same as prior period, unchanged from 0000038725-25-000084:notes:20]

[0000038725-25-000162:notes:21]
| (In millions) |  | June 30, 2025 |  | December 31, 2024 |
| Salaries, wages, and commissions |  | $ | 43.3 |  |  | $ | 49.0 |  |
| Product warranty costs |  | 8.9 |  |  | 9.0 |  |
| Insurance |  | 2.8 |  |  | 2.4 |  |
| Employee benefits |  | 15.6 |  |  | 19.9 |  |
| Other |  | 30.1 |  |  | 39.5 |  |
| Total |  | $ | 100.7 |  |  | $ | 119.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0000038725-25-000162:notes:22]
DEBT
Debt consisted of the following:

[0000038725-25-000162:notes:23]
| (In millions) |  | June 30, 2025 |  | December 31, 2024 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 186.0 |  |  | 41.4 |  |
| Tax increment financing debt |  | 12.2 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 11.5 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 284.7 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (270.2) |  |  | (117.8) |  |
| Long-term debt |  | $ | 14.5 |  |  | $ | 11.6 |  |

[0000038725-25-000162:notes:24]
Credit Agreement

[0000038725-25-000162:notes:25]
On May 14, 2025, the Company entered into the Fifth Amended and Restated Credit Agreement (the “Credit Agreement”).  The Fifth Amended and Restated Credit Agreement extended the maturity date of the Company’s Fourth Amended and Restated Credit Agreement, as amended (which is referred to in this current report as the “Previous Credit Agreement”) to May 14, 2030 while keeping the revolving commitment amount unchanged at $350.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $175.0 million (not to exceed a total commitment of $525.0 million) subject to the conditions contained therein. The Previous Credit Agreement provided the Borrowers could request an increase in the aggregate revolving commitments by up to $125.0 million (not to exceed a total commitment of $475.0 million). All of the Company's present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers' obligations under and in connection with the Credit Agreement. Additionally, the Company unconditionally guarantees all of the obligations of Franklin Electric B.V. under the Credit Agreement.  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a commitment fee of 0.10% to 0.25% (depending on the Company's leverage ratio) of the aggregate commitment, payable quarterly in arrears. The Credit Agreement contains customary affirmative and negative covenants.  Loans may be made either at (i) a Term Benchmark rate based on SOFR, for borrowings denominated in Dollars, or EURIBOR, for borrowings denominated in Euros,  plus an applicable margin of  1.00% to 1.75% (depending on the Company's leverage ratio), or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-25-000162:notes:26]
As of June 30, 2025, the Company had $186.0 million outstanding borrowings with a weighted-average interest rate of 4.3 percent, $4.6 million in letters of credit outstanding, and $159.4 million of available capacity under the Credit Agreement. As of December 31, 2024, the Company had $41.4 million outstanding borrowings with a weighted-average interest rate of 3.7

[0000038725-25-000162:notes:27]
percent, $4.5 million in letters of credit outstanding, and $304.1 million of available capacity under the Previous Credit Agreement.

[0000038725-25-000162:notes:28]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $20.1 million. As of June 30, 2025, there were no outstanding borrowings and $20.1 million of available capacity under these lines of credit. As of December 31, 2024, there were $16.8 million overdraft lines of credit with no outstanding borrowings and $16.8 million of available capacity under these lines of credit.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-25-000162:notes:29]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.

[0000038725-25-000162:notes:30]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-25-000162:notes:31]
At June 30, 2025, the Company had $8.0 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

[0000038725-25-000162:notes:32]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2025, are as follows:

[0000038725-25-000162:notes:33]
| (In millions) |  |  |
| Balance as of December 31, 2024 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 5.4 |  |
| Reductions for payments made |  | (5.5) |  |
| Balance as of June 30, 2025 |  | $ | 8.9 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-25-000162:notes:34]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the second quarters and six months ended June 30, 2025 and June 30, 2024:

[0000038725-25-000162:notes:35]
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2025 | $ | 4,572 |  |  | $ | 370,347 |  |  | $ | 1,162,873 |  |  |  |  |  |  | $ | (240,545) |  |  | $ | 2,675 |  |  | $ | 1,299,922 |  |  | $ | 1,373 |  |
| Net income | — |  |  | — |  |  | 60,140 |  |  |  |  |  |  | — |  |  | 284 |  |  | 60,424 |  |  | 139 |  |
| Dividends on common stock ($0.265/share) | — |  |  | — |  |  | (12,161) |  |  |  |  |  |  | — |  |  | — |  |  | (12,161) |  |  | — |  |
| Common stock issued | 12 |  |  | 10,077 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 10,089 |  |  | — |  |
| Common stock repurchased | (139) |  |  | — |  |  | (122,445) |  |  |  |  |  |  | — |  |  | — |  |  | (122,584) |  |  | — |  |
| Share-based compensation | 3 |  |  | 3,004 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 3,007 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 25,827 |  |  | 227 |  |  | 26,054 |  |  | (1) |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 311 |  |  | — |  |  | 311 |  |  | — |  |
| Balance as of June 30, 2025 | $ | 4,448 |  |  | $ | 383,428 |  |  | $ | 1,088,407 |  |  |  |  |  |  | $ | (214,407) |  |  | $ | 3,186 |  |  | $ | 1,265,062 |  |  | $ | 1,511 |  |
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2024 | $ | 4,609 |  |  | $ | 352,797 |  |  | $ | 1,090,874 |  |  |  |  |  |  | $ | (227,855) |  |  | $ | 2,554 |  |  | $ | 1,222,979 |  |  | $ | 1,109 |  |
| Net income | — |  |  | — |  |  | 59,099 |  |  |  |  |  |  | — |  |  | 186 |  |  | 59,285 |  |  | 46 |  |
| Dividends on common stock ($0.250/share) | — |  |  | — |  |  | (11,564) |  |  |  |  |  |  | — |  |  | — |  |  | (11,564) |  |  | — |  |
| Common stock issued | — |  |  | 252 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 252 |  |  | — |  |
| Common stock repurchased | (40) |  |  | — |  |  | (39,124) |  |  |  |  |  |  | — |  |  | — |  |  | (39,164) |  |  | — |  |
| Share-based compensation | 6 |  |  | 2,967 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 2,973 |  |  | — |  |
| Dividend to noncontrolling interest | — |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | — |  |  | (21) |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (10,284) |  |  | (15) |  |  | (10,299) |  |  | — |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 434 |  |  | — |  |  | 434 |  |  | — |  |
| Balance as of June 30, 2024 | $ | 4,575 |  |  | $ | 356,016 |  |  | $ | 1,099,285 |  |  |  |  |  |  | $ | (237,705) |  |  | $ | 2,725 |  |  | $ | 1,224,896 |  |  | $ | 1,134 |  |

[0000038725-25-000162:notes:36]
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2024 | $ | 4,571 |  |  | $ | 363,956 |  |  | $ | 1,151,575 |  |  |  |  |  |  | $ | (254,003) |  |  | $ | 2,511 |  |  | $ | 1,268,610 |  |  | $ | 1,224 |  |
| Net Income | — |  |  | — |  |  | 91,102 |  |  |  |  |  |  | — |  |  | 600 |  |  | 91,702 |  |  | 235 |  |
| Dividends on common stock ($0.530/share) | — |  |  | — |  |  | (24,359) |  |  |  |  |  |  | — |  |  | — |  |  | (24,359) |  |  | — |  |
| Common stock issued | 14 |  |  | 11,513 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 11,527 |  |  | — |  |
| Common stock repurchased | (147) |  |  | — |  |  | (129,911) |  |  |  |  |  |  | — |  |  | — |  |  | (130,058) |  |  | — |  |
| Share-based compensation | 10 |  |  | 7,959 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 7,969 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 38,975 |  |  | 75 |  |  | 39,050 |  |  | 52 |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 621 |  |  | — |  |  | 621 |  |  | — |  |
| Balance as of June 30, 2025 | $ | 4,448 |  |  | $ | 383,428 |  |  | $ | 1,088,407 |  |  |  |  |  |  | $ | (214,407) |  |  | $ | 3,186 |  |  | $ | 1,265,062 |  |  | $ | 1,511 |  |
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2023 | $ | 4,607 |  |  | $ | 344,717 |  |  | $ | 1,078,512 |  |  |  |  |  |  | $ | (221,114) |  |  | $ | 2,426 |  |  | $ | 1,209,148 |  |  | $ | 1,145 |  |
| Net Income | — |  |  | — |  |  | 92,058 |  |  |  |  |  |  | — |  |  | 355 |  |  | 92,413 |  |  | 10 |  |
| Dividends on common stock ($0.500/share) | — |  |  | — |  |  | (23,124) |  |  |  |  |  |  | — |  |  | — |  |  | (23,124) |  |  | — |  |
| Common stock issued | 7 |  |  | 4,295 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 4,302 |  |  | — |  |
| Common stock repurchased | (50) |  |  | — |  |  | (48,161) |  |  |  |  |  |  | — |  |  | — |  |  | (48,211) |  |  | — |  |
| Share-based compensation | 11 |  |  | 7,004 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 7,015 |  |  | — |  |
| Dividend to noncontrolling interest | — |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | — |  |  | (21) |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (17,458) |  |  | (56) |  |  | (17,514) |  |  | — |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 867 |  |  | — |  |  | 867 |  |  | — |  |
| Balance as of June 30, 2024 | $ | 4,575 |  |  | $ | 356,016 |  |  | $ | 1,099,285 |  |  |  |  |  |  | $ | (237,705) |  |  | $ | 2,725 |  |  | $ | 1,224,896 |  |  | $ | 1,134 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-25-000162:notes:37]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the six months ended June 30, 2025 and June 30, 2024, are summarized below:

[0000038725-25-000162:notes:38]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| For the six months ended June 30, 2025: |  |  |
| Balance as of December 31, 2024 | $ | (215.0) |  |  | $ | (39.0) |  |  | $ | (254.0) |  |
| Other comprehensive income/(loss) before reclassifications | 39.0 |  |  | — |  |  | 39.0 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.6 |  |  | 0.6 |  |
| Net other comprehensive income/(loss) | 39.0 |  |  | 0.6 |  |  | 39.6 |  |
| Balance as of June 30, 2025 | $ | (176.0) |  |  | $ | (38.4) |  |  | $ | (214.4) |  |
| For the six months ended June 30, 2024: |  |  |  |  |  |
| Balance as of December 31, 2023 | $ | (179.3) |  |  | $ | (41.8) |  |  | $ | (221.1) |  |
| Other comprehensive income/(loss) before reclassifications | (17.5) |  |  | — |  |  | (17.5) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.9 |  |  | 0.9 |  |
| Net other comprehensive income/(loss) | (17.5) |  |  | 0.9 |  |  | (16.6) |  |
| Balance as of June 30, 2024 | $ | (196.8) |  |  | $ | (40.9) |  |  | $ | (237.7) |  |

[0000038725-25-000162:notes:39]
[same as prior period, unchanged from 0000038725-25-000084:notes:37]

[0000038725-25-000162:notes:40]
(2) Net of tax expense of $0.2 million and $0.3 million for the six months ended June 30, 2025 and June 30, 2024, respectively.

[0000038725-25-000162:notes:41]
[same as prior period, unchanged from 0000038725-25-000084:notes:39]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-25-000162:notes:42]
EMPLOYEE BENEFIT PLANS
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the second quarters and six months ended June 30, 2025 and June 30, 2024:

[0000038725-25-000162:notes:43]
| (In millions) | Pension Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2025 |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| Service cost | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.1 |  |  | $ | 0.3 |  |
| Interest cost | 1.5 |  |  | 1.6 |  |  | 2.9 |  |  | 3.1 |  |
| Expected return on assets | (1.6) |  |  | (1.9) |  |  | (3.2) |  |  | (3.8) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.4 |  |  | 0.6 |  |  | 0.8 |  |  | 1.2 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | 0.6 |  |  | $ | 0.8 |  |

[0000038725-25-000162:notes:44]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the second quarters and six months ended June 30, 2025 and June 30, 2024:

[0000038725-25-000162:notes:45]
| (In millions) | Other Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2025 |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | 0.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-25-000162:notes:46]
INCOME TAXES
The Company’s effective tax rate for the six-month period ended June 30, 2025 was 24.9 percent as compared to 22.5 percent for the six-month period ended June 30, 2024. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to U.S state taxes and foreign earnings taxed at rates higher than the U.S. statutory rate partially offset by the recognition of the U.S. foreign-derived intangible income (FDII) provisions. For the second quarter of 2025, the effective tax rate was 24.9 percent compared to 22.9 percent for the second quarter of 2024.

[0000038725-25-000162:notes:47]
The increase in the effective tax rate for the second quarter and first six months of 2025 compared to the comparable periods in the prior year was primarily due to mix of foreign earnings taxed at rates different than the U.S. statutory rate, a decreased benefit in the U.S. foreign-derived intangible income (FDII) provision related to a prior year prepayment of inventory from foreign subsidiaries, and less favorable discrete events in 2025, primarily related to excess tax benefits from share-based compensation.

[0000038725-25-000162:notes:48]
On July 4, 2025, the reconciliation bill, commonly referred to as the One Big Beautiful Bill Act ("OBBB") was signed into law, which includes a broad range of tax reform provisions that may affect the Company's financial results. The OBBB allows an elective deduction for domestic Research and Development (R&D), a reinstatement of elective 100% first-year bonus depreciation, and a more favorable tax rate on Foreign-derived Deduction Eligible Income and income from non-U.S. subsidiaries, among other provisions. The Company is currently evaluating the impact of these provisions which could affect the Company's effective tax rate and deferred tax assets in 2025 and future periods. A quantitative estimate of the specific financial effects cannot be reasonably determined at this time due to the complexity of the changes in the tax reform. The impact of those tax provisions in the OBBB will depend on our facts in each year and anticipated guidance from the U.S. Department of the Treasury.


## us-gaap:EarningsPerShareTextBlock

[0000038725-25-000162:notes:49]
[same as prior period, unchanged from 0000038725-25-000084:notes:47]

[0000038725-25-000162:notes:50]
[same as prior period, unchanged from 0000038725-25-000084:notes:48]

[0000038725-25-000162:notes:51]
[same as prior period, unchanged from 0000038725-25-000084:notes:49]

[0000038725-25-000162:notes:52]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions, except per share amounts) | June 30, 2025 |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 60.1 |  |  | $ | 59.1 |  |  | $ | 91.1 |  |  | $ | 92.1 |  |
| Less: Earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Net income available to common shareholders | $ | 59.9 |  |  | $ | 58.9 |  |  | $ | 90.8 |  |  | $ | 91.8 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 45.4 |  |  | 46.0 |  |  | 45.6 |  |  | 46.0 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors | 0.5 |  |  | 0.6 |  |  | 0.5 |  |  | 0.6 |  |
| Diluted weighted average common shares outstanding | 45.9 |  |  | 46.6 |  |  | 46.1 |  |  | 46.6 |  |
| Basic earnings per share | $ | 1.32 |  |  | $ | 1.28 |  |  | $ | 1.99 |  |  | $ | 1.99 |  |
| Diluted earnings per share | $ | 1.31 |  |  | $ | 1.26 |  |  | $ | 1.97 |  |  | $ | 1.97 |  |

[0000038725-25-000162:notes:53]
There were 0.2 million and 0.1 million stock options outstanding for the second quarters and six months ended June 30, 2025 and June 30, 2024, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-25-000162:notes:54]
FINANCIAL INSTRUMENTS
The Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of June 30, 2025 and December 31, 2024, the swap had a notional value based on 150,000 shares and 250,000 shares, respectively. For the second quarter and six months ended June 30, 2025, changes in the fair value of the swap resulted in losses of $1.6 million and $2.8 million, respectively. For the second quarter and six months ended June 30, 2024, changes in the fair value of the swap resulted in a losses of $2.9 million and $0.8 million, respectively. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.

[0000038725-25-000162:notes:55]
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of June 30, 2025, the Company had a notional amount of $116.4 million in forward currency contracts outstanding and the related fair value of those contracts was a net liability of $0.2 million. The forward currency contracts asset and liability are recorded within the "Receivables" and "Accounts Payable" lines of the condensed consolidated balance sheets. As of December 31, 2024, the Company had no foreign currency contracts outstanding. For the second quarter and six months ended June 30, 2025, changes in the fair value of the forward currency contracts resulted in gains of $6.8 million and $11.2 million, respectively. For the second quarter and six months ended June 30, 2024, changes in the fair value of the forward currency contracts resulted in losses of $0.9 million and $0.3 million, respectively. These gains and losses are recorded in the Company's condensed consolidated statements of income within the "Foreign exchange expense, net" line.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-25-000162:notes:56]
FAIR VALUE MEASUREMENTS
FASB Accounting Standards Codification Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most

[0000038725-25-000162:notes:57]
advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value. The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-25-000162:notes:58]
[same as prior period, unchanged from 0000038725-25-000084:notes:55]

[0000038725-25-000162:notes:59]
[same as prior period, unchanged from 0000038725-25-000084:notes:56]

[0000038725-25-000162:notes:60]
[same as prior period, unchanged from 0000038725-25-000084:notes:57]

[0000038725-25-000162:notes:61]
As of June 30, 2025 and December 31, 2024, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-25-000162:notes:62]
| (In millions) | June 30, 2025 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 9.6 |  | $ | 9.6 |  | $ | — |  | $ | — |  |
| Share swap transaction | 0.4 |  | 0.4 |  | — |  | — |  |
| Forward currency contracts | 0.2 |  | — |  | 0.2 |  | — |  |
| Total assets | $ | 10.2 |  | $ | 10.0 |  | $ | 0.2 |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Forward currency contracts | $ | 0.4 |  | $ | — |  | $ | 0.4 |  | $ | — |  |
| Total liabilities | $ | 0.4 |  | $ | — |  | $ | 0.4 |  | $ | — |  |
| (In millions) | December 31, 2024 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 5.0 |  | $ | 5.0 |  | $ | — |  | $ | — |  |
| Total assets | $ | 5.0 |  | $ | 5.0 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Share swap transaction | $ | 2.5 |  | $ | 2.5 |  | $ | — |  | $ | — |  |
| Contingent payments related to acquisition | 5.0 |  | — |  | — |  | 5.0 |  |
| Total liabilities | $ | 7.5 |  | $ | 2.5 |  | $ | — |  | $ | 5.0 |  |

[0000038725-25-000162:notes:63]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The forward currency contracts asset and the share swap transaction asset are recorded within the "Receivables" line of the condensed consolidated balance sheets. The forward currency contracts liability and the share swap transaction liability are recorded within the "Accounts payable" line of the condensed consolidated balance sheets. The forward currency contracts and share swap transaction are further described in Note 12 - Financial Instruments.

[0000038725-25-000162:notes:64]
The Company's Level 3 category includes contingent consideration related to acquisitions, which valuation inputs are unobservable and significant to the fair value measurement.  Projections and estimated probabilities are used to estimate future contingent earn-out payments, which are discounted back to present value to compute contingent earn-out liabilities. The following table provides a roll-forward of the contingent consideration liability, which is included in "Accrued expenses and other current liabilities" as of June 30, 2025 and June 30, 2024:

[0000038725-25-000162:notes:65]
|  | Second Quarter Ended | Six Months Ended |
| (In millions) | June 30, 2025 | June 30, 2025 |
| Fair value at beginning of period | $ | — |  | $ | 5.0 |  |
| Adjustments to prior year acquisition | — |  | — |  |
| Change in fair value recognized in earnings | — |  | — |  |
| Payments | — |  | (5.0) |  |
| Fair value at end of period | $ | — |  | $ | — |  |

[0000038725-25-000162:notes:66]
Total debt, including current maturities, have carrying amounts of $284.7 million and $129.4 million and estimated fair values of $283.7 million and $128.0 million as of June 30, 2025 and December 31, 2024, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-25-000162:notes:67]
[same as prior period, unchanged from 0000038725-25-000084:notes:64]

[0000038725-25-000162:notes:68]
[same as prior period, unchanged from 0000038725-25-000084:notes:65]

[0000038725-25-000162:notes:69]
The Company's chief operating decision maker is its Chief Executive Officer. Performance is evaluated based on the sales and operating income of the segments. Operating income and margin are used to evaluate income generated from segment assets in deciding whether to reinvest profits into each segment or other parts of the entity. Operating income is also used to monitor budget versus actual results for purposes of determining portions of management compensation and for benchmarking against similar measures used by peers and competitors. These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented as corporate expenses are not allocated to segments. Interest expense, other income (expense), net, foreign exchange expense, net, and income tax expense are also not allocated to each segment.

[0000038725-25-000162:notes:70]
The following tables summarize reportable business segment information with a reconciliation to our condensed consolidated results for the periods presented:

[0000038725-25-000162:notes:71]
| Second Quarter Ended June 30, 2025 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 309.9 |  |  | $ | 200.0 |  |  | $ | 77.5 |  |  | $ | 587.4 |  |
| Intersegment sales | 30.9 |  |  | — |  |  | — |  |  | 30.9 |  |
|  | $ | 340.8 |  |  | $ | 200.0 |  |  | $ | 77.5 |  |  | $ | 618.3 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (30.9) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 587.4 |  |
| Cost of sales | $ | 222.9 |  |  | $ | 146.6 |  |  | $ | 38.2 |  |  |  |
| Selling, general and administrative expenses | 56.0 |  |  | 37.3 |  |  | 10.2 |  |  |  |
| Restructuring expense | 0.1 |  |  | — |  |  | — |  |  |  |
| Segment operating income | $ | 61.8 |  |  | $ | 16.1 |  |  | $ | 29.1 |  |  | $ | 107.0 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | 1.1 |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (20.0) |  |
| Interest expense |  |  |  |  |  |  | (2.8) |  |
| Other income (expense), net |  |  |  |  |  |  | (0.2) |  |
| Foreign exchange expense, net |  |  |  |  |  |  | (4.5) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 80.6 |  |

[0000038725-25-000162:notes:72]
| Second Quarter Ended June 30, 2024 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 279.7 |  |  | $ | 190.5 |  |  | $ | 73.1 |  |  | $ | 543.3 |  |
| Intersegment sales | 35.9 |  |  | — |  |  | — |  |  | 35.9 |  |
|  | $ | 315.6 |  |  | $ | 190.5 |  |  | $ | 73.1 |  |  | $ | 579.2 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (35.9) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 543.3 |  |
| Cost of sales | $ | 202.3 |  |  | $ | 140.0 |  |  | $ | 36.2 |  |  |  |
| Selling, general and administrative expenses | 51.0 |  |  | 40.7 |  |  | 10.9 |  |  |  |
| Restructuring expense | — |  |  | — |  |  | — |  |  |  |
| Segment operating income | $ | 62.3 |  |  | $ | 9.8 |  |  | $ | 26.0 |  |  | $ | 98.1 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | (0.9) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (18.1) |  |
| Interest expense |  |  |  |  |  |  | (2.0) |  |
| Other income (expense), net |  |  |  |  |  |  | 0.2 |  |
| Foreign exchange expense, net |  |  |  |  |  |  | (0.4) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 76.9 |  |

[0000038725-25-000162:notes:73]
| Six Months Ended June 30, 2025 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 556.5 |  |  | $ | 341.9 |  |  | $ | 144.3 |  |  | $ | 1,042.7 |  |
| Intersegment sales | 71.6 |  |  | — |  |  | — |  |  | 71.6 |  |
|  | $ | 628.1 |  |  | $ | 341.9 |  |  | $ | 144.3 |  |  | $ | 1,114.3 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (71.6) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 1,042.7 |  |
| Cost of sales | $ | 414.1 |  |  | $ | 249.0 |  |  | $ | 72.6 |  |  |  |
| Selling, general and administrative expenses | 108.6 |  |  | 74.5 |  |  | 20.7 |  |  |  |
| Restructuring expense | 0.1 |  |  | 0.2 |  |  | — |  |  |  |
| Segment operating income | $ | 105.3 |  |  | $ | 18.2 |  |  | $ | 51.0 |  |  | $ | 174.5 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | (3.0) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (39.3) |  |
| Interest expense |  |  |  |  |  |  | (4.6) |  |
| Other income (expense), net |  |  |  |  |  |  | 0.7 |  |
| Foreign exchange expense, net |  |  |  |  |  |  | (5.8) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 122.5 |  |

[0000038725-25-000162:notes:74]
| Six Months Ended June 30, 2024 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 531.5 |  |  | $ | 337.5 |  |  | $ | 135.2 |  |  | $ | 1,004.2 |  |
| Intersegment sales | 70.7 |  |  | — |  |  | — |  |  | 70.7 |  |
|  | $ | 602.2 |  |  | $ | 337.5 |  |  | $ | 135.2 |  |  | $ | 1,074.9 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (70.7) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 1,004.2 |  |
| Cost of sales | $ | 391.6 |  |  | $ | 247.4 |  |  | $ | 68.9 |  |  |  |
| Selling, general and administrative expenses | 101.1 |  |  | 78.4 |  |  | 21.6 |  |  |  |
| Restructuring expense | — |  |  | — |  |  | — |  |  |  |
| Segment operating income | $ | 109.5 |  |  | $ | 11.7 |  |  | $ | 44.7 |  |  | $ | 165.9 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | (3.7) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (35.2) |  |
| Interest expense |  |  |  |  |  |  | (3.4) |  |
| Other income (expense), net |  |  |  |  |  |  | 0.9 |  |
| Foreign exchange expense, net |  |  |  |  |  |  | (5.3) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 119.2 |  |

[0000038725-25-000162:notes:75]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions) | June 30, 2025 |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| Depreciation and amortization |  |  |  |  |  |  |  |
| Water Systems | $ | 11.6 |  |  | $ | 9.7 |  |  | $ | 21.8 |  |  | $ | 19.3 |  |
| Distribution | 2.3 |  |  | 2.4 |  |  | 4.7 |  |  | 4.8 |  |
| Energy Systems | 1.1 |  |  | 1.0 |  |  | 2.1 |  |  | 2.1 |  |
| Total segment depreciation and amortization | $ | 15.0 |  |  | $ | 13.1 |  |  | $ | 28.6 |  |  | $ | 26.2 |  |
| Corporate | 0.8 |  |  | 0.8 |  |  | 1.6 |  |  | 1.5 |  |
| Total depreciation and amortization | $ | 15.8 |  |  | $ | 13.9 |  |  | $ | 30.2 |  |  | $ | 27.7 |  |
| Capital Expenditures |  |  |  |  |  |  |  |
| Water Systems | 10.2 |  |  | 6.7 |  |  | 13.4 |  |  | 10.5 |  |
| Distribution | 1.4 |  |  | 3.5 |  |  | 3.1 |  |  | 6.1 |  |
| Energy Systems | 0.2 |  |  | 0.5 |  |  | 1.0 |  |  | 1.0 |  |
| Total segment capital expenditure | $ | 11.8 |  |  | $ | 10.7 |  |  | $ | 17.5 |  |  | $ | 17.6 |  |
| Corporate | 0.5 |  |  | 1.0 |  |  | 0.9 |  |  | 1.8 |  |
| Total capital expenditures | $ | 12.3 |  |  | $ | 11.7 |  |  | $ | 18.4 |  |  | $ | 19.4 |  |
| Assets |  |  |  |  |  |
| Water Systems | $ | 1,282.1 |  |  | $ | 1,056.5 |  |  |  |  |  |
| Distribution | 399.0 |  |  | 415.5 |  |  |  |  |  |
| Energy Systems | 269.2 |  |  | 259.5 |  |  |  |  |  |
| Total segment assets | 1,950.3 |  |  | 1,731.5 |  |  |  |  |  |
| Corporate | 67.6 |  |  | 52.8 |  |  |  |  |  |
| Total assets | $ | 2,017.9 |  |  | $ | 1,784.3 |  |  |  |  |  |

[0000038725-25-000162:notes:76]
Cash and property, plant and equipment are the major asset groups in “Corporate” of total assets for the quarters ended June 30, 2025 and June 30, 2024.

[0000038725-25-000162:notes:77]
[same as prior period, unchanged from 0000038725-25-000084:notes:72]

[0000038725-25-000162:notes:78]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions) | June 30, 2025 |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 172.9 |  |  | $ | 157.7 |  |  | $ | 307.9 |  |  | $ | 295.7 |  |
| Latin America | 52.8 |  |  | 41.8 |  |  | 92.3 |  |  | 83.1 |  |
| Europe, Middle East & Africa | 55.7 |  |  | 56.0 |  |  | 107.2 |  |  | 108.3 |  |
| Asia Pacific | 28.5 |  |  | 24.2 |  |  | 49.1 |  |  | 44.4 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 30.9 |  |  | 35.9 |  |  | 71.6 |  |  | 70.7 |  |
| Total sales | 340.8 |  |  | 315.6 |  |  | 628.1 |  |  | 602.2 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 200.0 |  |  | 190.5 |  |  | 341.9 |  |  | 337.5 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 200.0 |  |  | 190.5 |  |  | 341.9 |  |  | 337.5 |  |
| Energy Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 60.5 |  |  | 58.4 |  |  | 112.3 |  |  | 105.1 |  |
| All other | 17.0 |  |  | 14.7 |  |  | 32.0 |  |  | 30.1 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 77.5 |  |  | 73.1 |  |  | 144.3 |  |  | 135.2 |  |
| Intersegment Eliminations/Other | (30.9) |  |  | (35.9) |  |  | (71.6) |  |  | (70.7) |  |
| Consolidated | $ | 587.4 |  |  | $ | 543.3 |  |  | $ | 1,042.7 |  |  | $ | 1,004.2 |  |


## us-gaap:SubsequentEventsTextBlock

[0000038725-25-000162:notes:79]
SUBSEQUENT EVENT
In July 2025, the Company began the process of terminating the Franklin Electric Co,, Inc. Pension Plan by making lump sum payments of $59.9 million directly to eligible participants who elected that payment option. Additionally, the Company purchased a single premium group annuity contract from an independent insurance company, in which $30 million in future pension obligations were transferred to the insurance company to pay the outstanding accrued benefits to participants and beneficiaries of the plan.The annuity contract and lump sum payments do not exceed the assets of the plan, there will be no cash or asset contributions made by the Company. Management estimates that the Company will recognize a one-time non-cash pre-tax pension settlement charge of approximately $60 million in the fiscal third quarter of 2025 related to actuarial losses previously recorded in Accumulated Other Comprehensive Loss. The actual charge will depend on finalization of the actuarial and other assumptions. As a result of the plan’s over-funded status, remaining surplus plan assets are expected to be utilized to fund certain employer contributions associated with one of the Company's qualified 401(k) plans.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000038725-25-000162:notes:80]
None of the Company’s directors or officers adopted, modified, or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement during the Company’s fiscal quarter ended June 30, 2025.
