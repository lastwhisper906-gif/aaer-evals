# FELE MD&A — 0000038725-25-000162


## mdna

[0000038725-25-000162:mdna:1]
[same as prior period, unchanged from 0000038725-25-000084:mdna:1]

[0000038725-25-000162:mdna:2]
Refer to the Company's Annual Report on Form 10-K for the year ended December 31, 2024 for management’s discussion and analysis of its financial condition and results of operations. The following is management’s discussion and analysis of the Company's financial condition and results of operations for the second quarter and six months ended June 30, 2025 and 2024.

[0000038725-25-000162:mdna:3]
In the first quarter of 2025, the Company acquired Barnes de Colombia S.A. (Barnes), a leading manufacturer and distributor of industrial and commercial pumps based in Colombia. Also in the first quarter of 2025, the Company acquired PumpEng Pty Ltd ("PumpEng"), an Australia-based company that specializes in the design, manufacture and service of submersible pumps for the mining sector. Acquisitions contributed approximately $21.0 million of incremental net sales in the first six months of 2025. Refer to Note 2 in Item 1 of this Quarterly Report on Form 10-Q for additional information on the Barnes and PumpEng acquisitions.

[0000038725-25-000162:mdna:4]
[same as prior period, unchanged from 0000038725-25-000084:mdna:4]

[0000038725-25-000162:mdna:5]
Second Quarter 2025 vs. 2024

[0000038725-25-000162:mdna:6]
[same as prior period, unchanged from 0000038725-25-000084:mdna:6]

[0000038725-25-000162:mdna:7]
Net sales in the second quarter and first six months of 2025 increased 8 percent and 4 percent, respectively, as compared to the prior-year periods. The sales increases were due to higher volumes, price realization, and the incremental sales impact from recent acquisitions, partially offset by the negative impact of foreign currency translation. The Company's consolidated gross profit was $211.8 million and $375.7 million, respectively, for the second quarter and first six months of 2025, increases of 6 percent and 3 percent, respectively, from the prior-year periods. Diluted earnings per share was $1.31 and $1.97, respectively, for the second quarter and first six months of 2025, increases of $0.05 and unchanged, respectively, from the prior-year periods.

[0000038725-25-000162:mdna:8]
[same as prior period, unchanged from 0000038725-25-000084:mdna:8]

[0000038725-25-000162:mdna:9]
[same as prior period, unchanged from 0000038725-25-000084:mdna:9]

[0000038725-25-000162:mdna:10]
Net sales in the second quarter and first six months of 2025 were $587.4 million and $1.0 billion, respectively, and increased 8 percent and 4 percent, respectively, as compared to the prior-year periods. Sales were negatively impacted by changes in foreign exchange rates, partly due to the strengthening of the U.S. Dollar relative to the Argentine Peso and Turkish Lira. However, the Company increases prices in the local currency to offset the impact of currency devaluation in the Argentina and Turkey hyperinflationary economies. As a result, the net negative impact of foreign currency exchange rates on net sales was less than 1 percent in the second quarter and 1 percent in the first six months of 2025 compared to the same period in the prior year.

[0000038725-25-000162:mdna:11]
|  | Net Sales |
| (In millions) | Q2 2025 |  | Q2 2024 |  | 2025 v 2024 |
| Water Systems | $ | 340.8 |  |  | $ | 315.6 |  |  | $ | 25.2 |  |
| Energy Systems | 77.5 |  |  | 73.1 |  |  | 4.4 |  |
| Distribution | 200.0 |  |  | 190.5 |  |  | 9.5 |  |
| Eliminations/Other | (30.9) |  |  | (35.9) |  |  | 5.0 |  |
| Consolidated | $ | 587.4 |  |  | $ | 543.3 |  |  | $ | 44.1 |  |

[0000038725-25-000162:mdna:12]
|  | Net Sales |
| (In millions) | YTD June 30, 2025 |  | YTD June 30, 2024 |  | 2025 v 2024 |
| Water Systems | 628.1 |  |  | 602.2 |  |  | $ | 25.9 |  |
| Energy Systems | 144.3 |  |  | 135.2 |  |  | 9.1 |  |
| Distribution | 341.9 |  |  | 337.5 |  |  | 4.4 |  |
| Eliminations/Other | (71.6) |  |  | (70.7) |  |  | (0.9) |  |
| Consolidated | $ | 1,042.7 |  |  | $ | 1,004.2 |  |  | $ | 38.5 |  |

[0000038725-25-000162:mdna:13]
[same as prior period, unchanged from 0000038725-25-000084:mdna:12]

[0000038725-25-000162:mdna:14]
Water Systems net sales increased 8 percent in the second quarter and 4 percent in the first six months of 2025, as compared to the prior-year periods. The sales growth in the second quarter and the first six months of 2025 was due to incremental sales impact from recent acquisitions of approximately 5 percent and 3 percent, respectively, favorable volumes, and price realization.  These increases were partially offset by the negative impact from foreign exchange rates. Sales decreased less than 1 percent in the second quarter and approximately 1 percent in the first six months of 2025 due to the negative impact from foreign exchange rates, as compared to prior-year periods.

[0000038725-25-000162:mdna:15]
Water Systems net sales in the U.S. and Canada increased 5 percent in the second quarter and 4 percent in the first six months of 2025, as compared to the prior-year periods. In the second quarter of 2025, sales of large dewatering equipment increased 20 percent, sales of water treatment products increased 7 percent, sales of all other surface pumping equipment increased 2 percent and sales of groundwater pumping equipment decreased 4 percent compared to 2024. In the first six months of 2025, sales of large dewatering equipment increased 7 percent, sales of water treatment products increased 7 percent, sales of groundwater pumping equipment increased 1 percent and sales of all other surface pumping equipment decreased 2 percent compared to 2024.

[0000038725-25-000162:mdna:16]
Water Systems net sales in markets outside the U.S. and Canada increased 12 percent in the second quarter and 5 percent in the first six months of 2025, as compared to the prior-year periods. The sales growth in the second quarter and the first six months of 2025 was to due incremental sales impact from recent acquisitions of 11 percent and 8 percent, respectively. Sales decreased 1 percent in the second quarter and 3 percent in the first six months of 2025 due to the negative impact from foreign exchange rates, as compared to prior-year periods, while sales increased 11 percent and 8 percent, respectively, compared to prior-year periods due to the incremental sales impact from recent acquisitions. Excluding the impact of foreign currency translation and acquisitions, in both the second quarter and first six months of 2025, sales growth in the Latin America and Asia Pacific regions was partly offset by sales declines in the European region.

[0000038725-25-000162:mdna:17]
[same as prior period, unchanged from 0000038725-25-000084:mdna:16]

[0000038725-25-000162:mdna:18]
Energy Systems net sales increased 6 percent in the second quarter and 7 percent in the first six months of 2025, as compared to the prior-year periods. This sales increase was primarily due to price realization and favorable volumes.

[0000038725-25-000162:mdna:19]
Energy Systems net sales in the U.S. and Canada increased 6 percent in the second quarter and 8 percent in the first six months of 2025, as compared to the prior-year periods. The increase was primarily in fuel management systems and pumping systems. Outside the U.S. and Canada, Energy Systems sales increased 14 percent in the second quarter and 3 percent in the first six months of 2025, as compared to the prior-year periods, due primarily to sales growth in the Asia Pacific region.

[0000038725-25-000162:mdna:20]
[same as prior period, unchanged from 0000038725-25-000084:mdna:19]

[0000038725-25-000162:mdna:21]
Distribution net sales increased 5 percent in the second quarter and 1 percent in the first six months of 2025, as compared to the prior-year periods.  The Distribution segment sales increased due to favorable volumes partly offset by the negative impact of commodity pricing declines.

[0000038725-25-000162:mdna:22]
[same as prior period, unchanged from 0000038725-25-000084:mdna:21]

[0000038725-25-000162:mdna:23]
|  | Three Months Ended June 30, |
| (In millions) | 2025 |  | % of Net Sales |  | 2024 |  | % of Net Sales |
| Gross Profit | $ | 211.8 |  |  | 36.1 | % |  | $ | 199.8 |  |  | 36.8 | % |
| Selling, General and Administrative Expense | 123.5 |  |  | 21.0 | % |  | 120.6 |  |  | 22.2 | % |

[0000038725-25-000162:mdna:24]
|  | Six Months Ended June 30, |
| (In millions) | 2025 |  | % of Net Sales |  | 2024 |  | % of Net Sales |
| Gross Profit | $ | 375.7 |  |  | 36.0 | % |  | $ | 363.4 |  |  | 36.2 | % |
| Selling, General and Administrative Expense | 243.2 |  |  | 23.3 | % |  | 236.3 |  |  | 23.5 | % |

[0000038725-25-000162:mdna:25]
[same as prior period, unchanged from 0000038725-25-000084:mdna:23]

[0000038725-25-000162:mdna:26]
The gross profit margin ratio was 36.1 percent and 36.0 percent in the second quarter and first six months of 2025, respectively, and 36.8 percent and 36.2 percent in the second quarter and first six months of 2024, respectively.  The gross profit margin was unfavorably impacted in the second quarter and first six months of 2025 by Water Systems which was impacted by an unfavorable product and geographic sales mix shift.

[0000038725-25-000162:mdna:27]
[same as prior period, unchanged from 0000038725-25-000084:mdna:25]

[0000038725-25-000162:mdna:28]
SG&A expenses were $123.5 million in the second quarter and $243.2 million in the first six months of 2025 compared to $120.6 million in the second quarter and $236.3 million in the first six months of 2024. SG&A expenses increased in the second quarter and first six months of 2025 primarily due higher employee compensation costs, including incremental expenses associated with the Company’s executive leadership transitions, and the incremental expense impact of recent acquisitions. The SG&A expenses ratio was 21.0 percent and 23.3 percent in the second quarter and first six months of 2025, respectively, and 22.2 percent and 23.5 percent in the second quarter and first six months of 2024, respectively.

[0000038725-25-000162:mdna:29]
Restructuring Expenses

[0000038725-25-000162:mdna:30]
There were $0.2 million and $0.3 million in restructuring expenses in the second quarter and first six months of 2025, compared to no restructuring expenses in the second quarter and first six months of 2024. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities.

[0000038725-25-000162:mdna:31]
[same as prior period, unchanged from 0000038725-25-000084:mdna:27]

[0000038725-25-000162:mdna:32]
Operating income in the second quarter and first six months of 2025 was $88.1 million and $132.2 million, respectively, increases of 11 percent and 4 percent, respectively, as compared to the prior-year periods.

[0000038725-25-000162:mdna:33]
|  |  | Operating income (loss) |
| (In millions) |  | Q2 2025 |  | Q2 2024 |  | 2025 v 2024 |
| Water Systems |  | $ | 61.8 |  |  | $ | 62.3 |  |  | $ | (0.5) |  |
| Energy Systems |  | 29.1 |  |  | 26.0 |  |  | 3.1 |  |
| Distribution |  | 16.1 |  |  | 9.8 |  |  | 6.3 |  |
| Eliminations/Other |  | (18.9) |  |  | (19.0) |  |  | 0.1 |  |
| Consolidated |  | $ | 88.1 |  |  | $ | 79.1 |  |  | $ | 9.0 |  |

[0000038725-25-000162:mdna:34]
|  |  | Operating income (loss) |
| (In millions) |  | YTD June 30, 2025 |  | YTD June 30, 2024 |  | 2025 v 2024 |
| Water Systems |  | 105.3 |  |  | 109.5 |  |  | $ | (4.2) |  |
| Energy Systems |  | 51.0 |  |  | 44.8 |  |  | 6.2 |  |
| Distribution |  | 18.2 |  |  | 11.7 |  |  | 6.5 |  |
| Eliminations/Other |  | (42.3) |  |  | (38.9) |  |  | (3.4) |  |
| Consolidated |  | $ | 132.2 |  |  | $ | 127.1 |  |  | $ | 5.1 |  |

[0000038725-25-000162:mdna:35]
[same as prior period, unchanged from 0000038725-25-000084:mdna:30]

[0000038725-25-000162:mdna:36]
Water Systems operating income in the second quarter and first six months of 2025 was $61.8 million and $105.3 million, respectively, decreases of $0.5 million and $4.2 million, respectively, as compared to the prior-year periods. The second quarter operating income margin was 18.1 percent, a decrease of 160 basis points from 19.7 percent in the second quarter of 2024. The first six months of 2025 operating income margin was 16.8 percent, a decrease of 140 basis points from 18.2 percent in the first six months of 2024.  The decrease in operating income and margin was primarily due to incremental expenses associated with recent acquisitions and an unfavorable product and geographic sales mix shift.

[0000038725-25-000162:mdna:37]
[same as prior period, unchanged from 0000038725-25-000084:mdna:32]

[0000038725-25-000162:mdna:38]
Energy Systems operating income in the second quarter and first six months of 2025 was $29.1 million and $51.0 million, respectively, increases of $3.1 million and $6.2 million, respectively, as compared to the prior-year periods. The increases were primarily due to higher sales. The second quarter operating income margin was 37.5 percent, an increase of 190 basis points from 35.6 percent in the second quarter of 2024. The first six months of 2025 operating income margin was 35.3 percent, an increase of 220 basis points from 33.1 percent in the first six months of 2024. Operating income margin increased primarily due to price realization, cost management, and a favorable product sales mix shift.

[0000038725-25-000162:mdna:39]
[same as prior period, unchanged from 0000038725-25-000084:mdna:34]

[0000038725-25-000162:mdna:40]
Distribution operating income in the second quarter and first six months of 2025 was $16.1 million and $18.2 million, respectively, increases of $6.3 million and $6.5 million, respectively, as compared to the prior-year periods. The second quarter operating income margin was 8.1 percent, an increase of 300 basis points from 5.1 percent in the second quarter of 2024. The first six months of 2025 operating income margin was 5.3 percent, an increase of 180 basis points from 3.5 percent in the first six months of 2024. Operating income and operating income margins increased primarily due to higher sales and reduced SG&A expenses as a result of cost actions implemented in 2024 to improve the performance of the segment.

[0000038725-25-000162:mdna:41]
[same as prior period, unchanged from 0000038725-25-000084:mdna:36]

[0000038725-25-000162:mdna:42]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the second quarter and first six months of 2025 compared to the prior-year periods of 2024 was a favorable $2.0 million and $0.7 million, respectively. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses increased $1.9 million and $4.1 million, respectively, compared to the prior-year periods, primarily due to higher employee compensation costs, including incremental expenses associated with the Company’s executive leadership transitions.

[0000038725-25-000162:mdna:43]
[same as prior period, unchanged from 0000038725-25-000084:mdna:38]

[0000038725-25-000162:mdna:44]
Interest expense was $2.8 million and $4.6 million in the second quarter and first six months of 2025, respectively, and $2.0 million and $3.4 million in the second quarter and first six months of 2024, respectively. The increases in the second quarter and first six months of 2025 were primarily driven by higher average amount of outstanding debt.

[0000038725-25-000162:mdna:45]
[same as prior period, unchanged from 0000038725-25-000084:mdna:40]

[0000038725-25-000162:mdna:46]
Other income / Expense, net was a net loss of $(0.2) million and a net gain of $0.7 million in the second quarter and first six months of 2025, respectively, and net gains of $0.2 million and $0.9 million in the second quarter and first six months of 2024, respectively.

[0000038725-25-000162:mdna:47]
[same as prior period, unchanged from 0000038725-25-000084:mdna:42]

[0000038725-25-000162:mdna:48]
Foreign currency-based transactions produced an expense of $4.5 million and $5.8 million in the second quarter and first six months of 2025, respectively, and an expense of $0.4 million and $5.3 million in the second quarter and first six months of 2024, respectively. The results in the second quarters and first six months of 2025 and 2024 are primarily due to transaction losses associated with the Argentine Peso and Turkish Lira relative to the U.S. dollar  The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-25-000162:mdna:49]
[same as prior period, unchanged from 0000038725-25-000084:mdna:44]

[0000038725-25-000162:mdna:50]
The provision for income taxes in the second quarter and first six months of 2025 was $20.1 million and $30.5 million, respectively, and $17.6 million and $26.8 million in the second quarter and first six months of 2024, respectively. The effective tax rate for both the second quarter and first six months of 2025 was 24.9 percent, and 22.9 percent and 22.5 percent in the second quarter and the first six months of 2024, respectively. The increase in the effective tax rate was due to mix of foreign earnings taxed at rates different than the U.S. statutory rate, a decreased benefit in the U.S. foreign-derived intangible income (FDII) provision related to a prior year prepayment of inventory from foreign subsidiaries, and less favorable discrete events in 2025, primarily related to excess tax benefits from share-based compensation.

[0000038725-25-000162:mdna:51]
[same as prior period, unchanged from 0000038725-25-000084:mdna:46]

[0000038725-25-000162:mdna:52]
Net income in the second quarter and first six months of 2025 was $60.6 million and $91.9 million, respectively, and $59.3 million and $92.4 million in the second quarter and first six months of 2024, respectively. Net income attributable to Franklin Electric Co., Inc. in the second quarter and first six months of 2025 was $60.1 million and $91.1 million, respectively, or $1.31 and $1.97 per diluted share. Net income attributable to Franklin Electric Co., Inc. in the second quarter and first six months of 2024 was $59.1 million and $92.1 million, respectively, or $1.26 and $1.97 per diluted share.

[0000038725-25-000162:mdna:53]
[same as prior period, unchanged from 0000038725-25-000084:mdna:48]

[0000038725-25-000162:mdna:54]
[same as prior period, unchanged from 0000038725-25-000084:mdna:49]

[0000038725-25-000162:mdna:55]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at June 30, 2025 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-25-000162:mdna:56]
As of June 30, 2025, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 14, 2030. As of June 30, 2025, the Company had $159.4 million borrowing capacity under its credit agreement as $4.6 million in letters of commercial and standby letters of credit were outstanding and undrawn and $186.0 million revolver borrowings were drawn or outstanding.

[0000038725-25-000162:mdna:57]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity on the New York Life Agreement was $175.0 million as of June 30, 2025. The maturity date of the agreement is May 15, 2027.

[0000038725-25-000162:mdna:58]
The Company also has other long-term debt borrowings outstanding as of June 30, 2025. See Note 6 - Debt included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024, for additional information regarding these obligations and future maturities as well as Note 5 - Debt of this current quarterly report for changes to these agreements since December 31, 2024.

[0000038725-25-000162:mdna:59]
At June 30, 2025, the Company had $97.6 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate the majority of these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-25-000162:mdna:60]
[same as prior period, unchanged from 0000038725-25-000084:mdna:56]

[0000038725-25-000162:mdna:61]
The following table summarizes significant sources and uses of cash and cash equivalents for the first six months of 2025 and 2024.

[0000038725-25-000162:mdna:62]
| (In millions) |  | 2025 |  | 2024 |
| Net cash flows from operating activities |  | $ | 32.0 |  |  | $ | 35.0 |  |
| Net cash flows from investing activities |  | (127.3) |  |  | (20.2) |  |
| Net cash flows from financing activities |  | (22.1) |  |  | (38.7) |  |
| Impact of exchange rates on cash and cash equivalents |  | 1.5 |  |  | (3.0) |  |
| Change in cash and cash equivalents |  | $ | (115.9) |  |  | $ | (26.9) |  |

[0000038725-25-000162:mdna:63]
[same as prior period, unchanged from 0000038725-25-000084:mdna:59]

[0000038725-25-000162:mdna:64]
[same as prior period, unchanged from 0000038725-25-000084:mdna:60]

[0000038725-25-000162:mdna:65]
Net cash provided by operating activities was $32.0 million for the six months ended June 30, 2025 compared to $35.0 million used by operating activities for the six months ended June 30, 2024. The change in operating cash flow was primarily attributable to changes in working capital.

[0000038725-25-000162:mdna:66]
[same as prior period, unchanged from 0000038725-25-000084:mdna:62]

[0000038725-25-000162:mdna:67]
[same as prior period, unchanged from 0000038725-25-000084:mdna:63]

[0000038725-25-000162:mdna:68]
Net cash used in investing activities was $127.3 million for the six months ended June 30, 2025 compared to $20.2 million used in investing activities for the six months ended June 30, 2024. The change in investing cash flow was primarily attributable to the Barnes and PumpEng acquisitions in the first six months of 2025.

[0000038725-25-000162:mdna:69]
[same as prior period, unchanged from 0000038725-25-000084:mdna:65]

[0000038725-25-000162:mdna:70]
[same as prior period, unchanged from 0000038725-25-000084:mdna:66]

[0000038725-25-000162:mdna:71]
Net cash used in financing activities was $22.1 million for the six months ended June 30, 2025 compared to $38.7 million used in financing activities for the six months ended June 30, 2024. The change in financing cash flow was primarily due to higher net borrowings under the Company's credit facility in 2025 compared to 2024, partially offset by increased repurchases of Company stock.

[0000038725-25-000162:mdna:72]
[same as prior period, unchanged from 0000038725-25-000084:mdna:68]

[0000038725-25-000162:mdna:73]
33
