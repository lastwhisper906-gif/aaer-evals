# FELE note change history — 0000038725-25-000084 → 0000038725-25-000162


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-07-31):
[0000038725-25-000162:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.
  (was, 2025-05-01, similarity 0.8875):
[0000038725-25-000084:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February

- changed (2025-07-31):
[0000038725-25-000162:note_history:2]
At June 30, 2025, the Company had $8.0 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.
  (was, 2025-05-01, similarity 0.9725):
[0000038725-25-000084:note_history:2]
At March 31, 2025, the Company had $10.9 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

- changed (2025-07-31):
[0000038725-25-000162:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2025, are as follows:
  (was, 2025-05-01, similarity 0.9053):
[0000038725-25-000084:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2025, are as follows:

- changed (2025-07-31):
[0000038725-25-000162:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2024 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 5.4 |  |
| Reductions for payments made |  | (5.5) |  |
| Balance as of June 30, 2025 |  | $ | 8.9 |  |
  (was, 2025-05-01, similarity 0.9772):
[0000038725-25-000084:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2024 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 2.8 |  |
| Reductions for payments made |  | (2.7) |  |
| Balance as of March 31, 2025 |  | $ | 9.1 |  |

- removed (2025-07-31):
[0000038725-25-000084:note_history:5]
2023. The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-07-31):
[0000038725-25-000162:note_history:6]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2024, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2025, and for the second quarters and six months ended June 30, 2025 and June 30, 2024 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2025. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024.
  (was, 2025-05-01, similarity 0.9432):
[0000038725-25-000084:note_history:6]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2024, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2025, and for the first quarters ended March 31, 2025 and March 31, 2024 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2025. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-07-31):
[0000038725-25-000162:note_history:7]
| (In millions) |  | June 30, 2025 |  | December 31, 2024 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 186.0 |  |  | 41.4 |  |
| Tax increment financing debt |  | 12.2 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 11.5 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 284.7 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (270.2) |  |  | (117.8) |  |
| Long-term debt |  | $ | 14.5 |  |  | $ | 11.6 |  |
  (was, 2025-05-01, similarity 0.989):
[0000038725-25-000084:note_history:7]
| (In millions) |  | March 31, 2025 |  | December 31, 2024 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 63.8 |  |  | 41.4 |  |
| Tax increment financing debt |  | 12.2 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 13.6 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 164.6 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (149.7) |  |  | (117.8) |  |
| Long-term debt |  | $ | 14.9 |  |  | $ | 11.6 |  |

- added (2025-07-31):
[0000038725-25-000162:note_history:8]
On May 14, 2025, the Company entered into the Fifth Amended and Restated Credit Agreement (the “Credit Agreement”).  The Fifth Amended and Restated Credit Agreement extended the maturity date of the Company’s Fourth Amended and Restated Credit Agreement, as amended (which is referred to in this current report as the “Previous Credit Agreement”) to May 14, 2030 while keeping the revolving commitment amount unchanged at $350.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $175.0 million (not to exceed a total commitment of $525.0 million) subject to the conditions contained therein. The Previous Credit Agreement provided the Borrowers could request an increase in the aggregate revolving commitments by up to $125.0 million (not to exceed a total commitment of $475.0 million). All of the Company's present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers' obligations under and in connection with the Credit Agreement. Additionally, the Company unconditionally guarantees all of the obligations of Franklin Electric B.V. under the Credit Agreement.  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a commitment fee of 0.10% to 0.25% (depending on the Company's leverage ratio) of the aggregate commitment, payable quarterly in arrears. The Credit Agreement contains customary affirmative and negative covenants.  Loans may be made either at (i) a Term Benchmark rate based on SOFR, for borrowings denominated in Dollars, or EURIBOR, for borrowings denominated in Euros,  plus an applicable margin of  1.00% to 1.75% (depending on the Company's leverage ratio), or (ii) an alternative base rate as defined in the Credit Agreement.

- changed (2025-07-31):
[0000038725-25-000162:note_history:9]
As of June 30, 2025, the Company had $186.0 million outstanding borrowings with a weighted-average interest rate of 4.3 percent, $4.6 million in letters of credit outstanding, and $159.4 million of available capacity under the Credit Agreement. As of December 31, 2024, the Company had $41.4 million outstanding borrowings with a weighted-average interest rate of 3.7
  (was, 2025-05-01, similarity 0.8317):
[0000038725-25-000084:note_history:9]
As of March 31, 2025, the Company had $63.8 million outstanding borrowings with a weighted-average interest rate of 3.3 percent, $4.6 million in letters of credit outstanding, and $281.6 million of available capacity under its credit agreement. As of December 31, 2024, the Company had $41.4 million outstanding borrowings with a weighted-average interest rate of 3.7 percent, $4.5 million in letters of credit outstanding, and $304.1 million of available capacity under its credit agreement.

- added (2025-07-31):
[0000038725-25-000162:note_history:10]
percent, $4.5 million in letters of credit outstanding, and $304.1 million of available capacity under the Previous Credit Agreement.

- changed (2025-07-31):
[0000038725-25-000162:note_history:11]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $20.1 million. As of June 30, 2025, there were no outstanding borrowings and $20.1 million of available capacity under these lines of credit. As of December 31, 2024, there were $16.8 million overdraft lines of credit with no outstanding borrowings and $16.8 million of available capacity under these lines of credit.
  (was, 2025-05-01, similarity 0.8887):
[0000038725-25-000084:note_history:11]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $17.0 million. As of March 31, 2025, there were $1.1 million outstanding borrowings and $15.9 million of available capacity under these lines of credit. As of December 31, 2024, there were $16.8 million overdraft lines of credit with no outstanding borrowings and $16.8 million of available capacity under these lines of credit.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-07-31):
[0000038725-25-000162:note_history:12]
| (In millions) |  | June 30, 2025 |  | December 31, 2024 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 186.0 |  |  | 41.4 |  |
| Tax increment financing debt |  | 12.2 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 11.5 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 284.7 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (270.2) |  |  | (117.8) |  |
| Long-term debt |  | $ | 14.5 |  |  | $ | 11.6 |  |
  (was, 2025-05-01, similarity 0.989):
[0000038725-25-000084:note_history:12]
| (In millions) |  | March 31, 2025 |  | December 31, 2024 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 63.8 |  |  | 41.4 |  |
| Tax increment financing debt |  | 12.2 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 13.6 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 164.6 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (149.7) |  |  | (117.8) |  |
| Long-term debt |  | $ | 14.9 |  |  | $ | 11.6 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-07-31):
[0000038725-25-000162:note_history:13]
SUBSEQUENT EVENT
In July 2025, the Company began the process of terminating the Franklin Electric Co,, Inc. Pension Plan by making lump sum payments of $59.9 million directly to eligible participants who elected that payment option. Additionally, the Company purchased a single premium group annuity contract from an independent insurance company, in which $30 million in future pension obligations were transferred to the insurance company to pay the outstanding accrued benefits to participants and beneficiaries of the plan.The annuity contract and lump sum payments do not exceed the assets of the plan, there will be no cash or asset contributions made by the Company. Management estimates that the Company will recognize a one-time non-cash pre-tax pension settlement charge of approximately $60 million in the fiscal third quarter of 2025 related to actuarial losses previously recorded in Accumulated Other Comprehensive Loss. The actual charge will depend on finalization of the actuarial and other assumptions. As a result of the plan’s over-funded status, remaining surplus plan assets are expected to be utilized to fund certain employer contributions associated with one of the Company's qualified 401(k) plans.
