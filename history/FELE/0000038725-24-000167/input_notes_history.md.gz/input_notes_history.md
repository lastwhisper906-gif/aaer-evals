# FELE note change history — 0000038725-24-000143 → 0000038725-24-000167


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000038725-24-000167:note_history:1]
At September 30, 2024, the Company had $12.1 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.
  (was, 2024-07-26, similarity 0.9668):
[0000038725-24-000143:note_history:1]
At June 30, 2024, the Company had $7.5 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

- added (2024-10-31):
[0000038725-24-000167:note_history:2]
At September 30, 2024, the Company has a contingent consideration liability with an estimated fair value of $4.8 million that could result in a payment of up to $5.0 million if a future profitability milestone is achieved.

- changed (2024-10-31):
[0000038725-24-000167:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2024, are as follows:
  (was, 2024-07-26, similarity 0.9582):
[0000038725-24-000143:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2024, are as follows:

- changed (2024-10-31):
[0000038725-24-000167:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2023 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 10.0 |  |
| Reductions for payments made |  | (10.0) |  |
| Balance as of September 30, 2024 |  | $ | 9.3 |  |
  (was, 2024-07-26, similarity 0.9724):
[0000038725-24-000143:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2023 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 6.4 |  |
| Reductions for payments made |  | (6.3) |  |
| Balance as of June 30, 2024 |  | $ | 9.4 |  |

- removed (2024-10-31):
[0000038725-24-000143:note_history:5]
At June 30, 2024, the Company has a contingent consideration liability with an estimated fair value of $4.6 million that could result in a payment of up to $5.0 million if a future profitability milestone is achieved.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000038725-24-000167:note_history:6]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2023, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2024, and for the third quarters and nine months ended September 30, 2024 and September 30, 2023 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2024. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2023.
  (was, 2024-07-26, similarity 0.9346):
[0000038725-24-000143:note_history:6]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2023, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2024, and for the second quarters and six months ended June 30, 2024 and June 30, 2023 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2024. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000038725-24-000167:note_history:7]
| (In millions) |  | September 30, 2024 |  | December 31, 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | — |  |  | 11.0 |  |
| Tax increment financing debt |  | 12.8 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.3 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 88.0 |  |  | $ | 100.5 |  |
| Less: current maturities |  | (76.4) |  |  | (12.4) |  |
| Long-term debt |  | $ | 11.6 |  |  | $ | 88.1 |  |
  (was, 2024-07-26, similarity 0.9819):
[0000038725-24-000143:note_history:7]
| (In millions) |  | June 30, 2024 |  | December 31, 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 41.0 |  |  | 11.0 |  |
| Tax increment financing debt |  | 13.4 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.3 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 129.6 |  |  | $ | 100.5 |  |
| Less: current maturities |  | (42.4) |  |  | (12.4) |  |
| Long-term debt |  | $ | 87.2 |  |  | $ | 88.1 |  |

- added (2024-10-31):
[0000038725-24-000167:note_history:8]
As of September 30, 2024, the Company had no outstanding borrowings, $4.6 million in letters of credit outstanding, and $345.4 million of available capacity under its credit agreement. As of December 31, 2023, the Company had $11.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $335.4 million of available capacity under its credit agreement.

- added (2024-10-31):
[0000038725-24-000167:note_history:9]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $17.6 million. As of September 30, 2024, there were no outstanding borrowings and $17.6 million of available capacity under these lines of credit. As of December 31, 2023, there were $17.9 million overdraft lines of credit with no outstanding borrowings and $17.9 million of available capacity under these lines of credit.

- removed (2024-10-31):
[0000038725-24-000143:note_history:10]
As of June 30, 2024, the Company had $41.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.5 million in letters of credit outstanding, and $305.5 million of available capacity under its credit agreement. As of December 31, 2023, the Company had $11.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $335.4 million of available capacity under its credit agreement.

- removed (2024-10-31):
[0000038725-24-000143:note_history:11]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $17.4 million. As of June 30, 2024, there were no outstanding borrowings and $17.4 million of available capacity under these lines of credit. As of December 31, 2023, there were $17.9 million overdraft lines of credit with no outstanding borrowings and $17.9 million of available capacity under these lines of credit.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-31):
[0000038725-24-000167:note_history:12]
| (In millions) |  | September 30, 2024 |  | December 31, 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | — |  |  | 11.0 |  |
| Tax increment financing debt |  | 12.8 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.3 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 88.0 |  |  | $ | 100.5 |  |
| Less: current maturities |  | (76.4) |  |  | (12.4) |  |
| Long-term debt |  | $ | 11.6 |  |  | $ | 88.1 |  |
  (was, 2024-07-26, similarity 0.9819):
[0000038725-24-000143:note_history:12]
| (In millions) |  | June 30, 2024 |  | December 31, 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 41.0 |  |  | 11.0 |  |
| Tax increment financing debt |  | 13.4 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.3 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 129.6 |  |  | $ | 100.5 |  |
| Less: current maturities |  | (42.4) |  |  | (12.4) |  |
| Long-term debt |  | $ | 87.2 |  |  | $ | 88.1 |  |
