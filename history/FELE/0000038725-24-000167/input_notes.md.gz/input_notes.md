# FELE notes — 0000038725-24-000167


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-24-000167:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2023, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2024, and for the third quarters and nine months ended September 30, 2024 and September 30, 2023 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2024. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2023.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-24-000167:notes:2]
ACCOUNTING PRONOUNCEMENTS
Accounting Standards Issued But Not Yet Adopted

[0000038725-24-000167:notes:3]
In November 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 is intended to improve reportable segment disclosure requirements, primarily through additional and more detailed information about a reportable segment's expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The guidance is to be applied retrospectively to all prior periods presented in the financial statements. The Company plans to adopt this ASU for its fiscal year end December 31, 2024 disclosures, but does not anticipate the adoption to have a material impact on the Company's financial disclosures.

[0000038725-24-000167:notes:4]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. This amendment modifies the rules on income tax disclosures to require entities to disclose (1) specific categories in the rate reconciliation and additional information for reconciling items that meet a quantitative threshold, (2) the amount of income taxes paid (net of refunds received) (disaggregated by federal, state, and foreign taxes) as well as individual jurisdictions in which income taxes paid is equal to or greater than 5 percent of total income taxes paid net of refunds, (3) the income or loss from continuing operations before income tax expense or benefit (disaggregated between domestic and foreign) and (4) income tax expense or benefit from continuing operations (disaggregated by federal, state and foreign). ASU 2023-09 is effective for annual periods beginning after December 15, 2024, with early adoption permitted. ASU 2023-09 should be applied on a prospective basis, while retrospective application is permitted. The Company will adopt this ASU in 2025 and does not anticipate the adoption to have material impact on the Company's financial disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-24-000167:notes:5]
[same as prior period, unchanged from 0000038725-24-000143:notes:5]

[0000038725-24-000167:notes:6]
During the fourth quarter ended December 31, 2023, the Company acquired substantially all of the assets of Aqua Systems of Fort Myers, a water treatment systems distributor.  In another separate transaction, the Company acquired substantially all of the assets of Action Manufacturing and Supply, Inc., a water treatment equipment provider located in southwest Florida. The Company also acquired, in a separate transaction, substantially all of the assets of LCA Pump, LLC, which operates Water Works Pump, a Missouri based professional groundwater distributor. The combined purchase price for the acquisitions in the fourth quarter of 2023, was $36.0 million, including contingent consideration with an estimated fair value of $4.3 million, after purchase price adjustments based on the level of working capital acquired. In the first quarter of 2024, the Company recorded a measurement period adjustment of $1.3 million to increase the acquisition-date fair value of the contingent consideration transferred. The measurement period adjustment resulted in an increase to acquired identifiable intangible assets of $2.3 million and a reduction to acquired goodwill of $1.0 million. The measurement period adjustments did not have a significant impact on the Company’s results of operations. The fair value of the assets acquired and liabilities assumed for the above acquisitions is preliminary as of September 30, 2024.

[0000038725-24-000167:notes:7]
[same as prior period, unchanged from 0000038725-24-000143:notes:7]

[0000038725-24-000167:notes:8]
[same as prior period, unchanged from 0000038725-24-000143:notes:8]

[0000038725-24-000167:notes:9]
[same as prior period, unchanged from 0000038725-24-000143:notes:9]

[0000038725-24-000167:notes:10]
[same as prior period, unchanged from 0000038725-24-000143:notes:10]


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-24-000167:notes:11]
[same as prior period, unchanged from 0000038725-24-000143:notes:11]

[0000038725-24-000167:notes:12]
[same as prior period, unchanged from 0000038725-24-000143:notes:12]

[0000038725-24-000167:notes:13]
[same as prior period, unchanged from 0000038725-24-000143:notes:13]

[0000038725-24-000167:notes:14]
[same as prior period, unchanged from 0000038725-24-000143:notes:14]

[0000038725-24-000167:notes:15]
As of September 30, 2024 and December 31, 2023, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-24-000167:notes:16]
| (In millions) | September 30, 2024 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 5.9 |  | $ | 5.9 |  | $ | — |  | $ | — |  |
| Share swap transaction | 2.2 |  | 2.2 |  | — |  | — |  |
| Total assets | $ | 8.1 |  | $ | 8.1 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Contingent payments related to acquisition | 4.8 |  | — |  | — |  | 4.8 |  |
| Total liabilities | $ | 4.8 |  | $ | — |  | $ | — |  | $ | 4.8 |  |
| (In millions) | December 31, 2023 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 10.9 |  | $ | 10.9 |  | $ | — |  | $ | — |  |
| Share swap transaction | 1.1 |  | 1.1 |  | — |  | — |  |
| Total assets | $ | 12.0 |  | $ | 12.0 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Contingent payments related to acquisition | $ | 3.0 |  | $ | — |  | $ | — |  | $ | 3.0 |  |
| Total liabilities | $ | 3.0 |  | $ | — |  | $ | — |  | $ | 3.0 |  |

[0000038725-24-000167:notes:17]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The share swap transaction asset is recorded within the "Receivables" line of the condensed consolidated balance sheets and is further described in Note 5 - Financial Instruments.

[0000038725-24-000167:notes:18]
The Company's Level 3 category includes contingent consideration related to acquisitions, which valuation inputs are unobservable and significant to the fair value measurement.  Projections and estimated probabilities are used to estimate future contingent earn-out payments, which are discounted back to present value to compute contingent earn-out liabilities. The following table provides a roll-forward of the contingent consideration liability, which is included in "Other long-term liabilities" as of December 31, 2023 and "Accrued expenses and other current liabilities" as of September 30, 2024 in the condensed consolidated balance sheets:

[0000038725-24-000167:notes:19]
|  | Third Quarter Ended | Nine Months Ended |
| (In millions) | September 30, 2024 | September 30, 2024 |
| Fair value at beginning of period | $ | 4.6 |  | $ | 3.0 |  |
| Adjustments to prior year acquisition | — |  | 1.3 |  |
| Change in fair value recognized in earnings | 0.2 |  | 0.5 |  |
| Payments | — |  | — |  |
| Fair value at end of period | $ | 4.8 |  | $ | 4.8 |  |

[0000038725-24-000167:notes:20]
Total debt, including current maturities, have carrying amounts of $88.0 million and $100.5 million and estimated fair values of $86.9 million and $98.6 million as of September 30, 2024 and December 31, 2023, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-24-000167:notes:21]
FINANCIAL INSTRUMENTS
The Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of September 30, 2024 and December 31, 2023, the swap had a notional value based on 240,000 shares. For the third quarter and nine months ended September 30, 2024, changes in the fair value of the swap resulted in gains of $1.7 million, and $0.9 million, respectively. For the third quarter and nine months ended September 30, 2023, changes in the fair value of the swap resulted in a loss of $3.6 million and a gain of $1.1 million, respectively. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.

[0000038725-24-000167:notes:22]
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of September 30, 2024, the Company had a notional amount of $31.4 million in forward currency contracts outstanding and the related fair value of those contracts was not material.  As of December 31, 2023, the Company had no foreign currency contracts outstanding.  For the third quarter and nine months ended September 30, 2024, changes in the fair value of the forward currency contracts resulted in losses of $0.6 million and $0.9 million, respectively. For the third quarter and nine months ended September 30, 2023, changes in the fair value of the forward currency contracts resulted in gains of $0.0 million and $1.6 million, respectively. These gains and losses are recorded in the Company's condensed consolidated statements of income within the "Foreign exchange income (expense), net" line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-24-000167:notes:23]
[same as prior period, unchanged from 0000038725-24-000143:notes:23]

[0000038725-24-000167:notes:24]
| (In millions) |  | September 30, 2024 |  | December 31, 2023 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 264.3 |  |  | $ | (126.6) |  |  | $ | 263.7 |  |  | $ | (115.5) |  |
| Patents |  | 7.3 |  |  | (7.3) |  |  | 7.3 |  |  | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.5) |  |  | 7.5 |  |  | (7.5) |  |
| Trade names |  | 44.2 |  |  | (7.7) |  |  | 44.1 |  |  | (5.8) |  |
| Other |  | 3.2 |  |  | (2.6) |  |  | 3.4 |  |  | (2.8) |  |
| Total |  | $ | 326.5 |  |  | $ | (151.7) |  |  | $ | 326.0 |  |  | $ | (138.9) |  |
| Non-amortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.5 |  |  | — |  |  | 42.9 |  |  | — |  |
| Total intangibles |  | $ | 369.0 |  |  | $ | (151.7) |  |  | $ | 368.9 |  |  | $ | (138.9) |  |

[0000038725-24-000167:notes:25]
Amortization expense related to intangible assets for the third quarters ended September 30, 2024 and September 30, 2023 was $4.7 million and $4.2 million, respectively, and for the nine months ended September 30, 2024 and September 30, 2023 was $14.2 million and $12.7 million, respectively.

[0000038725-24-000167:notes:26]
The change in the carrying amount of goodwill by reportable segment for the nine months ended September 30, 2024 is as follows:

[0000038725-24-000167:notes:27]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2023 |  | $ | 221.4 |  |  | $ | 70.4 |  |  | $ | 50.6 |  |  | $ | 342.4 |  |
| Adjustments to prior year acquisitions |  | (0.9) |  |  | — |  |  | (0.1) |  |  | (1.0) |  |
| Foreign currency translation |  | (0.4) |  |  | 0.1 |  |  | — |  |  | (0.3) |  |
| Balance as of September 30, 2024 |  | $ | 220.1 |  |  | $ | 70.5 |  |  | $ | 50.5 |  |  | $ | 341.1 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-24-000167:notes:28]
EMPLOYEE BENEFIT PLANS
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the third quarters and nine months ended September 30, 2024 and September 30, 2023:

[0000038725-24-000167:notes:29]
| (In millions) | Pension Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2024 |  | September 30, 2023 |  | September 30, 2024 |  | September 30, 2023 |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.5 |  |  | $ | 0.5 |  |
| Interest cost | 1.6 |  |  | 1.7 |  |  | 4.7 |  |  | 5.0 |  |
| Expected return on assets | (1.9) |  |  | (1.8) |  |  | (5.7) |  |  | (5.4) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.5 |  |  | 0.5 |  |  | 1.7 |  |  | 1.6 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.4 |  |  | $ | 0.6 |  |  | $ | 1.2 |  |  | $ | 1.7 |  |

[0000038725-24-000167:notes:30]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the third quarters and nine months ended September 30, 2024 and September 30, 2023:

[0000038725-24-000167:notes:31]
| (In millions) | Other Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2024 |  | September 30, 2023 |  | September 30, 2024 |  | September 30, 2023 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.2 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-24-000167:notes:32]
[same as prior period, unchanged from 0000038725-24-000143:notes:32]

[0000038725-24-000167:notes:33]
| (In millions) |  | September 30, 2024 |  | December 31, 2023 |
| Salaries, wages, and commissions |  | $ | 47.0 |  |  | $ | 45.9 |  |
| Product warranty costs |  | 9.3 |  |  | 9.3 |  |
| Insurance |  | 2.4 |  |  | 2.5 |  |
| Employee benefits |  | 18.3 |  |  | 13.8 |  |
| Other |  | 38.8 |  |  | 28.7 |  |
| Total |  | $ | 115.8 |  |  | $ | 100.2 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-24-000167:notes:34]
INCOME TAXES
The Company’s effective tax rate for the nine-month period ended September 30, 2024 was 22.9 percent as compared to 20.1 percent for the nine-month period ended September 30, 2023. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to state taxes and foreign earnings taxed at rates higher than the U.S. statutory rate partially offset by the recognition of the U.S. foreign-derived intangible income (FDII) provisions and certain discrete events including excess tax benefits from share-based compensation. For the third quarter of 2024, the effective tax rate was 23.6 percent compared to 20.2 percent for the third quarter of 2023.

[0000038725-24-000167:notes:35]
The increase in the effective tax rate for the third quarter and first nine months of 2024 compared to the comparable periods in the prior year was a result of less favorable discrete events in 2024, primarily related to excess tax benefits from share-based compensation, in addition to an increase in the rate on foreign earnings with the implementation of the European Union’s Pillar Two Directive.


## us-gaap:DebtDisclosureTextBlock

[0000038725-24-000167:notes:36]
DEBT
Debt consisted of the following:

[0000038725-24-000167:notes:37]
| (In millions) |  | September 30, 2024 |  | December 31, 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | — |  |  | 11.0 |  |
| Tax increment financing debt |  | 12.8 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.3 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 88.0 |  |  | $ | 100.5 |  |
| Less: current maturities |  | (76.4) |  |  | (12.4) |  |
| Long-term debt |  | $ | 11.6 |  |  | $ | 88.1 |  |

[0000038725-24-000167:notes:38]
Prudential Agreement

[0000038725-24-000167:notes:39]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates. On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million and changed the expiration date from July 30, 2024 to May 15, 2027.

[0000038725-24-000167:notes:40]
New York Life Agreement

[0000038725-24-000167:notes:41]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC and its affiliates (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $200.0 million and changed the expiration date from July 30, 2024 to May 15, 2027.

[0000038725-24-000167:notes:42]
Credit Agreement

[0000038725-24-000167:notes:43]
As of September 30, 2024, the Company had no outstanding borrowings, $4.6 million in letters of credit outstanding, and $345.4 million of available capacity under its credit agreement. As of December 31, 2023, the Company had $11.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $335.4 million of available capacity under its credit agreement.

[0000038725-24-000167:notes:44]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $17.6 million. As of September 30, 2024, there were no outstanding borrowings and $17.6 million of available capacity under these lines of credit. As of December 31, 2023, there were $17.9 million overdraft lines of credit with no outstanding borrowings and $17.9 million of available capacity under these lines of credit.


## us-gaap:EarningsPerShareTextBlock

[0000038725-24-000167:notes:45]
[same as prior period, unchanged from 0000038725-24-000143:notes:45]

[0000038725-24-000167:notes:46]
[same as prior period, unchanged from 0000038725-24-000143:notes:46]

[0000038725-24-000167:notes:47]
[same as prior period, unchanged from 0000038725-24-000143:notes:47]

[0000038725-24-000167:notes:48]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions, except per share amounts) | September 30, 2024 |  | September 30, 2023 |  | September 30, 2024 |  | September 30, 2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 54.6 |  |  | $ | 57.8 |  |  | $ | 146.7 |  |  | $ | 154.7 |  |
| Less: Earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.5 |  |  | 0.5 |  |
| Net income available to common shareholders | $ | 54.4 |  |  | $ | 57.6 |  |  | $ | 146.2 |  |  | $ | 154.2 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 45.7 |  |  | 46.2 |  |  | 45.9 |  |  | 46.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors | 0.6 |  |  | 0.7 |  |  | 0.6 |  |  | 0.7 |  |
| Diluted weighted average common shares outstanding | 46.3 |  |  | 46.9 |  |  | 46.5 |  |  | 46.9 |  |
| Basic earnings per share | $ | 1.19 |  |  | $ | 1.25 |  |  | $ | 3.18 |  |  | $ | 3.34 |  |
| Diluted earnings per share | $ | 1.17 |  |  | $ | 1.23 |  |  | $ | 3.14 |  |  | $ | 3.29 |  |

[0000038725-24-000167:notes:49]
There were 0.1 million stock options outstanding for the third quarters and nine months ended September 30, 2024 and September 30, 2023, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-24-000167:notes:50]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the third quarters and nine months ended September 30, 2024 and September 30, 2023:

[0000038725-24-000167:notes:51]
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of July 1, 2024 | $ | 4,575 |  |  | $ | 356,016 |  |  | $ | 1,099,285 |  |  |  |  |  |  | $ | (237,705) |  |  | $ | 2,725 |  |  | $ | 1,224,896 |  |  | $ | 1,134 |  |
| Net income | — |  |  | — |  |  | 54,596 |  |  |  |  |  |  | — |  |  | 252 |  |  | 54,848 |  |  | 46 |  |
| Dividends on common stock ($0.250/share) | — |  |  | — |  |  | (11,462) |  |  |  |  |  |  | — |  |  | — |  |  | (11,462) |  |  | — |  |
| Common stock issued | 2 |  |  | 965 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 967 |  |  | — |  |
| Common stock repurchased | (9) |  |  | — |  |  | (8,769) |  |  |  |  |  |  | — |  |  | — |  |  | (8,778) |  |  | — |  |
| Share-based compensation | 1 |  |  | 3,111 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 3,112 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 8,621 |  |  | 86 |  |  | 8,707 |  |  | (1) |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 416 |  |  | — |  |  | 416 |  |  | — |  |
| Balance as of September 30, 2024 | $ | 4,569 |  |  | $ | 360,092 |  |  | $ | 1,133,650 |  |  |  |  |  |  | $ | (228,668) |  |  | $ | 3,063 |  |  | $ | 1,272,706 |  |  | $ | 1,179 |  |
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of July 1, 2023 | $ | 4,626 |  |  | $ | 340,812 |  |  | $ | 1,020,883 |  |  |  |  |  |  | $ | (219,662) |  |  | $ | 2,842 |  |  | $ | 1,149,501 |  |  | $ | 901 |  |
| Net income | — |  |  | — |  |  | 57,798 |  |  |  |  |  |  | — |  |  | 234 |  |  | 58,032 |  |  | 136 |  |
| Dividends on common stock ($0.225/share) | — |  |  | — |  |  | (10,443) |  |  |  |  |  |  | — |  |  | — |  |  | (10,443) |  |  | — |  |
| Common stock repurchased | (6) |  |  | — |  |  | (5,231) |  |  |  |  |  |  | — |  |  | — |  |  | (5,237) |  |  | — |  |
| Share-based compensation | 1 |  |  | 2,038 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 2,039 |  |  | — |  |
| Dividend to noncontrolling interest |  |  |  |  |  |  |  |  |  |  |  |  | (821) |  |  | (821) |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (10,775) |  |  | (74) |  |  | (10,849) |  |  | (2) |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 385 |  |  | — |  |  | 385 |  |  | — |  |
| Balance as of September 30, 2023 | $ | 4,621 |  |  | $ | 342,850 |  |  | $ | 1,063,007 |  |  |  |  |  |  | $ | (230,052) |  |  | $ | 2,181 |  |  | $ | 1,182,607 |  |  | $ | 1,035 |  |

[0000038725-24-000167:notes:52]
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2023 | $ | 4,607 |  |  | $ | 344,717 |  |  | $ | 1,078,512 |  |  |  |  |  |  | $ | (221,114) |  |  | $ | 2,426 |  |  | $ | 1,209,148 |  |  | $ | 1,145 |  |
| Net Income | — |  |  | — |  |  | 146,654 |  |  |  |  |  |  | — |  |  | 607 |  |  | 147,261 |  |  | 56 |  |
| Dividends on common stock ($0.750/share) | — |  |  | — |  |  | (34,586) |  |  |  |  |  |  | — |  |  | — |  |  | (34,586) |  |  | — |  |
| Common stock issued | 9 |  |  | 5,260 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 5,269 |  |  | — |  |
| Common stock repurchased | (59) |  |  | — |  |  | (56,930) |  |  |  |  |  |  | — |  |  | — |  |  | (56,989) |  |  | — |  |
| Share-based compensation | 12 |  |  | 10,115 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 10,127 |  |  | — |  |
| Dividend to noncontrolling interest | — |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | — |  |  | (21) |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (8,837) |  |  | 30 |  |  | (8,807) |  |  | (1) |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 1,283 |  |  | — |  |  | 1,283 |  |  | — |  |
| Balance as of September 30, 2024 | $ | 4,569 |  |  | $ | 360,092 |  |  | $ | 1,133,650 |  |  |  |  |  |  | $ | (228,668) |  |  | $ | 3,063 |  |  | $ | 1,272,706 |  |  | $ | 1,179 |  |
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2022 | $ | 4,619 |  |  | $ | 325,426 |  |  | $ | 969,261 |  |  |  |  |  |  | $ | (231,448) |  |  | $ | 2,276 |  |  | $ | 1,070,134 |  |  | $ | 620 |  |
| Net Income | — |  |  | — |  |  | 154,723 |  |  |  |  |  |  | — |  |  | 764 |  |  | 155,487 |  |  | 417 |  |
| Dividends on common stock ($0.675/share) | — |  |  | — |  |  | (31,315) |  |  |  |  |  |  | — |  |  | — |  |  | (31,315) |  |  | — |  |
| Common stock issued | 22 |  |  | 8,988 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 9,010 |  |  | — |  |
| Common stock repurchased | (33) |  |  | — |  |  | (29,662) |  |  |  |  |  |  | — |  |  | — |  |  | (29,695) |  |  | — |  |
| Share-based compensation | 13 |  |  | 8,436 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 8,449 |  |  | — |  |
| Dividend to noncontrolling interest |  |  |  |  |  |  |  |  |  |  |  |  | (821) |  |  | (821) |  |  |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 178 |  |  | (38) |  |  | 140 |  |  | (2) |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 1,218 |  |  | — |  |  | 1,218 |  |  | — |  |
| Balance as of September 30, 2023 | $ | 4,621 |  |  | $ | 342,850 |  |  | $ | 1,063,007 |  |  |  |  |  |  | $ | (230,052) |  |  | $ | 2,181 |  |  | $ | 1,182,607 |  |  | $ | 1,035 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-24-000167:notes:53]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the nine months ended September 30, 2024 and September 30, 2023, are summarized below:

[0000038725-24-000167:notes:54]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| For the nine months ended September 30, 2024: |  |  |
| Balance as of December 31, 2023 | $ | (179.3) |  |  | $ | (41.8) |  |  | $ | (221.1) |  |
| Other comprehensive income/(loss) before reclassifications | (8.8) |  |  | — |  |  | (8.8) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.3 |  |  | 1.3 |  |
| Net other comprehensive income/(loss) | (8.8) |  |  | 1.3 |  |  | (7.5) |  |
| Balance as of September 30, 2024 | $ | (188.1) |  |  | $ | (40.5) |  |  | $ | (228.6) |  |
| For the nine months ended September 30, 2023: |  |  |  |  |  |
| Balance as of December 31, 2022 | $ | (191.3) |  |  | $ | (40.1) |  |  | $ | (231.4) |  |
| Other comprehensive income/(loss) before reclassifications | 0.2 |  |  | — |  |  | 0.2 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.2 |  |  | 1.2 |  |
| Net other comprehensive income/(loss) | 0.2 |  |  | 1.2 |  |  | 1.4 |  |
| Balance as of September 30, 2023 | $ | (191.1) |  |  | $ | (38.9) |  |  | $ | (230.0) |  |

[0000038725-24-000167:notes:55]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 7 for additional details) and is included in the "Other (expense) income, net" line of the Company's condensed consolidated statements of income.

[0000038725-24-000167:notes:56]
(2) Net of tax expense of $0.4 million for the nine months ended September 30, 2024 and September 30, 2023, respectively.

[0000038725-24-000167:notes:57]
[same as prior period, unchanged from 0000038725-24-000143:notes:57]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-24-000167:notes:58]
[same as prior period, unchanged from 0000038725-24-000143:notes:58]

[0000038725-24-000167:notes:59]
[same as prior period, unchanged from 0000038725-24-000143:notes:59]

[0000038725-24-000167:notes:60]
[same as prior period, unchanged from 0000038725-24-000143:notes:60]

[0000038725-24-000167:notes:61]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions) | September 30, 2024 |  | September 30, 2023 |  | September 30, 2024 |  | September 30, 2023 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 152.3 |  |  | $ | 157.7 |  |  | $ | 448.0 |  |  | $ | 494.0 |  |
| Latin America | 43.5 |  |  | 45.5 |  |  | 126.6 |  |  | 127.8 |  |
| Europe, Middle East & Africa | 53.4 |  |  | 48.7 |  |  | 161.7 |  |  | 153.7 |  |
| Asia Pacific | 21.7 |  |  | 19.6 |  |  | 66.1 |  |  | 60.6 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 31.3 |  |  | 24.3 |  |  | 102.0 |  |  | 88.0 |  |
| Total sales | 302.2 |  |  | 295.8 |  |  | 904.4 |  |  | 924.1 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 190.8 |  |  | 189.2 |  |  | 528.3 |  |  | 525.3 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 190.8 |  |  | 189.2 |  |  | 528.3 |  |  | 525.3 |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 55.1 |  |  | 58.5 |  |  | 160.2 |  |  | 172.8 |  |
| All other | 14.6 |  |  | 19.2 |  |  | 44.7 |  |  | 58.0 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 69.7 |  |  | 77.7 |  |  | 204.9 |  |  | 230.8 |  |
| Intersegment Eliminations/Other | (31.3) |  |  | (24.3) |  |  | (102.0) |  |  | (88.0) |  |
| Consolidated | $ | 531.4 |  |  | $ | 538.4 |  |  | $ | 1,535.6 |  |  | $ | 1,592.2 |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2024 |  | September 30, 2023 |  | September 30, 2024 |  | September 30, 2023 |
|  | Operating income/(loss) |
| Water Systems | $ | 52.8 |  |  | $ | 52.7 |  |  | $ | 162.3 |  |  | $ | 152.5 |  |
| Distribution | 12.2 |  |  | 10.7 |  |  | 23.8 |  |  | 33.2 |  |
| Fueling Systems | 24.1 |  |  | 25.8 |  |  | 68.9 |  |  | 73.3 |  |
| Intersegment Eliminations/Other | (15.6) |  |  | (11.1) |  |  | (54.4) |  |  | (47.4) |  |
| Consolidated | $ | 73.5 |  |  | $ | 78.1 |  |  | $ | 200.6 |  |  | $ | 211.6 |  |

[0000038725-24-000167:notes:62]
|  | September 30, 2024 |  | December 31, 2023 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 1,052.1 |  |  | $ | 1,044.4 |  |  |  |  |  |
| Distribution | 398.0 |  |  | 365.6 |  |  |  |  |  |
| Fueling Systems | 255.6 |  |  | 256.4 |  |  |  |  |  |
| Other | 101.5 |  |  | 61.7 |  |  |  |  |  |
| Consolidated | $ | 1,807.2 |  |  | $ | 1,728.1 |  |  |  |  |  |

[0000038725-24-000167:notes:63]
[same as prior period, unchanged from 0000038725-24-000143:notes:63]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-24-000167:notes:64]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.

[0000038725-24-000167:notes:65]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-24-000167:notes:66]
At September 30, 2024, the Company had $12.1 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

[0000038725-24-000167:notes:67]
At September 30, 2024, the Company has a contingent consideration liability with an estimated fair value of $4.8 million that could result in a payment of up to $5.0 million if a future profitability milestone is achieved.

[0000038725-24-000167:notes:68]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2024, are as follows:

[0000038725-24-000167:notes:69]
| (In millions) |  |  |
| Balance as of December 31, 2023 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 10.0 |  |
| Reductions for payments made |  | (10.0) |  |
| Balance as of September 30, 2024 |  | $ | 9.3 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000038725-24-000167:notes:70]
None of the Company’s directors or officers adopted, modified, or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement during the Company’s fiscal quarter ended September 30, 2024.
