# FELE 8-K — 0000038725-24-000162 filed 2024-10-29

## item codes, every 8-K on or before 2024-10-31

- 2024-10-29 0000038725-24-000164 — 7.01, 9.01
- 2024-10-29 0000038725-24-000162 — 2.02, 9.01
- 2024-07-24 0000038725-24-000140 — 7.01, 9.01
- 2024-07-23 0000038725-24-000138 — 2.02, 9.01
- 2024-07-01 0000038725-24-000132 — 5.02
- 2024-05-22 0000038725-24-000119 — 5.02, 9.01 — amendment of 0000038725-24-000101
- 2024-05-16 0000038725-24-000105 — 1.01, 2.03, 9.01
- 2024-05-14 0000038725-24-000101 — 5.02, 7.01, 9.01
- 2024-05-03 0000038725-24-000097 — 7.01, 9.01
- 2024-05-03 0000038725-24-000096 — 5.07
- 2024-04-30 0000038725-24-000074 — 2.02, 9.01
- 2024-02-13 0000038725-24-000012 — 7.01, 9.01
- 2024-02-13 0000038725-24-000010 — 2.02, 9.01
- 2023-11-06 0000038725-23-000184 — 7.01, 9.01
- 2023-10-24 0000038725-23-000177 — 2.02, 9.01
- 2023-08-04 0000038725-23-000160 — 5.02, 9.01
- 2023-08-03 0000038725-23-000158 — 7.01, 9.01
- 2023-07-25 0000038725-23-000149 — 2.02, 9.01
- 2023-07-05 0000038725-23-000144 — 5.02, 7.01, 9.01
- 2023-05-09 0000038725-23-000094 — 5.02, 9.01
- 2023-05-09 0000038725-23-000092 — 5.07
- 2023-05-08 0000038725-23-000087 — 7.01, 9.01
- 2023-05-02 0000038725-23-000065 — 2.02, 9.01
- 2023-03-08 0000038725-23-000046 — 7.01, 9.01
- 2023-02-21 0000038725-23-000016 — 8.01, 9.01
- 2023-02-14 0000038725-23-000002 — 2.02, 9.01
- 2022-10-28 0000038725-22-000180 — 7.01, 9.01
- 2022-10-25 0000038725-22-000177 — 2.02, 9.01
- 2022-08-04 0000038725-22-000150 — 7.01, 9.01
- 2022-07-26 0000038725-22-000142 — 2.02, 9.01
- 2022-05-11 0000038725-22-000106 — 2.03, 9.01
- 2022-05-06 0000038725-22-000082 — 5.07
- 2022-05-06 0000038725-22-000081 — 5.02, 9.01
- 2022-05-03 0000038725-22-000075 — 7.01, 9.01
- 2022-04-26 0000038725-22-000073 — 2.02, 9.01
- 2022-03-24 0000038725-22-000056 — 5.02, 9.01
- 2022-03-08 0000038725-22-000049 — 7.01, 9.01
- 2022-02-15 0000038725-22-000007 — 2.02, 9.01
- 2022-01-04 0000038725-22-000002 — 7.01, 9.01
- 2021-11-03 0000038725-21-000212 — 7.01, 9.01
- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2024-10-31

- none on or before 2024-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000038725-24-000162:8k_2_02:1]
EX-99.1
2
a20241029ex991earningsrele.htm
EX-99.1

[0000038725-24-000162:8k_2_02:2]
Document

[0000038725-24-000162:8k_2_02:3]
Exhibit 99.1

[0000038725-24-000162:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-24-000162:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS THIRD QUARTER 2024 RESULTS

[0000038725-24-000162:8k_2_02:6]
Third Quarter 2024 Highlights

[0000038725-24-000162:8k_2_02:7]
•Consolidated net sales of $531.4 million, a decrease of 1% to the prior year

[0000038725-24-000162:8k_2_02:8]
•Water Systems and Distribution net sales increased 2% and 1%, respectively, while Fueling Systems net sales decreased 10%

[0000038725-24-000162:8k_2_02:9]
•Operating income was $73.5 million with operating margin of 13.8%

[0000038725-24-000162:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $1.17

[0000038725-24-000162:8k_2_02:11]
Fort Wayne, IN – October 29, 2024 – Franklin Electric Co., Inc. today announced its third quarter financial results for fiscal year 2024.

[0000038725-24-000162:8k_2_02:12]
Third quarter 2024 net sales were $531.4 million, compared to third quarter 2023 net sales of $538.4 million. Third quarter 2024 operating income was $73.5 million, compared to third quarter 2023 operating income of $78.1 million. Third quarter 2024 EPS was $1.17, versus EPS in the third quarter 2023 of $1.23.

[0000038725-24-000162:8k_2_02:13]
“Our third quarter results were softer than expected due to continued macro pressure from lower home sales and starts, along with weather being wetter than normal. However, the demand environment remains healthy across our key end markets, which has normalized following record levels of sales in recent years. Margins remained stable due to our disciplined cost management, and we are actively pursuing opportunities to further reduce expenses across the enterprise,” commented Joe Ruzynski, Franklin Electric’s CEO.

[0000038725-24-000162:8k_2_02:14]
“As we close out the year, we expect tempered order activity in-line with seasonal patterns. That said, having spent time with our incredible global team members over the past few months, I am energized by the potential of Franklin Electric. With our wide range of capabilities, strategic footprint, and flexible balance sheet, we have the ability to drive differentiated growth and accelerate productivity for years to come,” concluded Mr. Ruzynski.

[0000038725-24-000162:8k_2_02:15]
Segment Summaries

[0000038725-24-000162:8k_2_02:16]
Water Systems net sales were $302.2 million, a new third quarter record, an increase of $6.4 million or 2 percent compared to the third quarter 2023. The sales increase was driven by higher sales of groundwater products, all other surface products and water treatment products. The sales increase was partially offset by lower sales of large dewatering pumps, which had a record quarter last year. Water Systems operating income in the third quarter 2024 was $52.8 million, a new third quarter record. Third quarter 2023 Water Systems operating income was $52.7 million.

[0000038725-24-000162:8k_2_02:17]
Distribution net sales were $190.8 million, an increase of $1.6 million or 1 percent compared to the third quarter 2023. Sales increases were driven by sales from a recent acquisition. The Distribution segment operating income in the third quarter 2024 was $12.2 million. Third quarter 2023 Distribution operating income was $10.7 million.

[0000038725-24-000162:8k_2_02:18]
Fueling Systems net sales were $69.7 million in the third quarter 2024, a decrease of $8.0 million or 10 percent compared to the third quarter 2023. Sales decreases were driven by lower volumes. Fueling Systems operating income in the third quarter 2024 was $24.1 million. Third quarter 2023 Fueling Systems operating income was $25.8 million.

[0000038725-24-000162:8k_2_02:19]
2024 Guidance

[0000038725-24-000162:8k_2_02:20]
The Company is lowering its sales guidance for full year 2024 to be approximately $2.00 billion and reducing its EPS guidance for full year 2024 to be in the range of $3.75 to $3.85 which incorporates the Company’s first nine months performance and its outlook for the fourth quarter.

[0000038725-24-000162:8k_2_02:21]
Earnings Conference Call

[0000038725-24-000162:8k_2_02:22]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The third quarter 2024 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-24-000162:8k_2_02:23]
https://edge.media-server.com/mmc/p/cp5pmtx9

[0000038725-24-000162:8k_2_02:24]
For those interested in participating in the question-and-answer portion of the call, please register for the call at the link below.

[0000038725-24-000162:8k_2_02:25]
https://register.vevent.com/register/BIa5e3e952cc2d47c28144fef8683c97e0

[0000038725-24-000162:8k_2_02:26]
All registrants will receive dial-in information and a PIN allowing them to access the live call. It is recommended that you join 10 minutes prior to the event start (although you may register and dial in at any time during the call).

[0000038725-24-000162:8k_2_02:27]
A replay of the conference call will be available from Tuesday, October 29, 2024, through 9:00 am ET on Tuesday, November 5, 2024, by visiting the listen-only webcast link above.

[0000038725-24-000162:8k_2_02:28]
Forward Looking Statements

[0000038725-24-000162:8k_2_02:29]
About Franklin Electric

[0000038725-24-000162:8k_2_02:30]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and energy. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications. Franklin Electric is proud to be named in Newsweek’s lists of America’s Most Responsible Companies and Most Trustworthy Companies for 2023 and America’s Climate Leaders 2023 by USA Today.

[0000038725-24-000162:8k_2_02:31]
Franklin Electric Contact:

[0000038725-24-000162:8k_2_02:32]
Jeffery L. Taylor

[0000038725-24-000162:8k_2_02:33]
Franklin Electric Co., Inc.

[0000038725-24-000162:8k_2_02:34]
InvestorRelations@fele.com

[0000038725-24-000162:8k_2_02:35]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2024 |  | September 30, 2023 |  | September 30, 2024 |  | September 30, 2023 |
| Net sales | $ | 531,438 |  |  | $ | 538,431 |  |  | $ | 1,535,596 |  |  | $ | 1,592,163 |  |
| Cost of sales | 341,775 |  |  | 352,178 |  |  | 982,556 |  |  | 1,055,164 |  |
| Gross profit | 189,663 |  |  | 186,253 |  |  | 553,040 |  |  | 536,999 |  |
| Selling, general, and administrative expenses | 115,998 |  |  | 107,687 |  |  | 352,290 |  |  | 324,651 |  |
| Restructuring expense | 139 |  |  | 462 |  |  | 139 |  |  | 735 |  |
| Operating income | 73,526 |  |  | 78,104 |  |  | 200,611 |  |  | 211,613 |  |
| Interest expense | (1,556) |  |  | (2,984) |  |  | (4,980) |  |  | (10,309) |  |
| Other (expense) income, net | (181) |  |  | 277 |  |  | 709 |  |  | 1,865 |  |
| Foreign exchange income (expense), net | 88 |  |  | (2,483) |  |  | (5,228) |  |  | (8,098) |  |
| Income before income taxes | 71,877 |  |  | 72,914 |  |  | 191,112 |  |  | 195,071 |  |
| Income tax expense | 16,983 |  |  | 14,746 |  |  | 43,795 |  |  | 39,167 |  |
| Net income | $ | 54,894 |  |  | $ | 58,168 |  |  | $ | 147,317 |  |  | $ | 155,904 |  |
| Less: Net income attributable to noncontrolling interests | (298) |  |  | (370) |  |  | (663) |  |  | (1,181) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 54,596 |  |  | $ | 57,798 |  |  | $ | 146,654 |  |  | $ | 154,723 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.19 |  |  | $ | 1.25 |  |  | $ | 3.18 |  |  | $ | 3.34 |  |
| Diluted | $ | 1.17 |  |  | $ | 1.23 |  |  | $ | 3.14 |  |  | $ | 3.29 |  |

[0000038725-24-000162:8k_2_02:36]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | September 30, 2024 |  | December 31, 2023 |
| ASSETS |  |
| Cash and cash equivalents | $ | 106,273 |  |  | $ | 84,963 |  |
| Receivables (net) | 272,003 |  |  | 222,418 |  |
| Inventories | 524,647 |  |  | 508,696 |  |
| Other current assets | 39,560 |  |  | 37,718 |  |
| Total current assets | 942,483 |  |  | 853,795 |  |
| Property, plant, and equipment, net | 226,072 |  |  | 229,739 |  |
| Lease right-of-use assets, net | 62,694 |  |  | 57,014 |  |
| Goodwill and other assets | 575,994 |  |  | 587,574 |  |
| Total assets | $ | 1,807,243 |  |  | $ | 1,728,122 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 173,935 |  |  | $ | 152,419 |  |
| Accrued expenses and other current liabilities | 124,865 |  |  | 104,949 |  |
| Current lease liability | 17,963 |  |  | 17,316 |  |
| Current maturities of long-term debt and short-term borrowings | 76,402 |  |  | 12,355 |  |
| Total current liabilities | 393,165 |  |  | 287,039 |  |
| Long-term debt | 11,581 |  |  | 88,056 |  |
| Long-term lease liability | 43,484 |  |  | 38,549 |  |
| Income taxes payable non-current | — |  |  | 4,837 |  |
| Deferred income taxes | 31,128 |  |  | 29,461 |  |
| Employee benefit plans | 30,781 |  |  | 35,973 |  |
| Other long-term liabilities | 23,219 |  |  | 33,914 |  |
| Redeemable noncontrolling interest | 1,179 |  |  | 1,145 |  |
| Total equity | 1,272,706 |  |  | 1,209,148 |  |
| Total liabilities and equity | $ | 1,807,243 |  |  | $ | 1,728,122 |  |

[0000038725-24-000162:8k_2_02:37]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Nine Months Ended |
| (In thousands) |  |  |  |
|  | September 30, 2024 |  | September 30, 2023 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 147,317 |  |  | $ | 155,904 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 41,825 |  |  | 39,582 |  |
| Non-cash lease expense | 15,223 |  |  | 12,664 |  |
| Share-based compensation | 10,127 |  |  | 8,449 |  |
| Other | 5,178 |  |  | 10,894 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (51,440) |  |  | (20,427) |  |
| Inventory | (18,760) |  |  | 2,537 |  |
| Accounts payable and accrued expenses | 17,218 |  |  | 4,376 |  |
| Operating leases | (15,700) |  |  | (12,847) |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | (3,870) |  | (2,902) |
| Other | 3,968 |  |  | 399 |  |
| Net cash flows from operating activities | 151,086 |  |  | 198,629 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (28,897) |  |  | (30,155) |  |
| Proceeds from sale of property, plant, and equipment | 704 |  |  | — |  |
| Acquisitions and investments | (1,151) |  |  | (6,641) |  |
| Other investing activities | 37 |  |  | 26 |  |
| Net cash flows from investing activities | (29,307) |  |  | (36,770) |  |
| Cash flows from financing activities: |  |  |  |
| Net change in debt | (12,477) |  |  | (87,653) |  |
| Proceeds from issuance of common stock | 5,269 |  |  | 9,010 |  |
| Purchases of common stock | (56,989) |  |  | (29,888) |  |
| Dividends paid | (35,442) |  |  | (31,315) |  |
| Deferred payments for acquisitions | (348) |  |  | (448) |  |
| Net cash flows from financing activities | (99,987) |  |  | (140,294) |  |
| Effect of exchange rate changes on cash and cash equivalents | (482) |  |  | (4,848) |  |
| Net change in cash and cash equivalents | 21,310 |  |  | 16,717 |  |
| Cash and cash equivalents at beginning of period | 84,963 |  |  | 45,790 |  |
| Cash and cash equivalents at end of period | $ | 106,273 |  |  | $ | 62,507 |  |

[0000038725-24-000162:8k_2_02:38]
Key Performance Indicators: Net Sales Summary

[0000038725-24-000162:8k_2_02:39]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q3 2023 | $ | 182.0 |  | $ | 45.5 |  | $ | 48.7 |  | $ | 19.6 |  | $ | 295.8 |  | $ | 77.7 |  | $ | 189.2 |  | $ | (24.3) |  | $ | 538.4 |  |
| Q3 2024 | $ | 183.6 |  | $ | 43.5 |  | $ | 53.4 |  | $ | 21.7 |  | $ | 302.2 |  | $ | 69.7 |  | $ | 190.8 |  | $ | (31.3) |  | $ | 531.4 |  |
| Change | $ | 1.6 |  | $ | (2.0) |  | $ | 4.7 |  | $ | 2.1 |  | $ | 6.4 |  | $ | (8.0) |  | $ | 1.6 |  | $ | (7.0) |  | $ | (7.0) |  |
| % Change | 1 | % | (4) | % | 10 | % | 11 | % | 2 | % | (10) | % | 1 | % |  | (1) | % |
| Foreign currency translation, net* | $ | (0.3) |  | $ | (4.4) |  | $ | (0.3) |  | $ | — |  | $ | (5.0) |  | $ | 0.1 |  | $ | — |  |  | $ | (4.9) |  |
| % Change | — | % | (10) | % | (1) | % | — | % | (2) | % | — | % | — | % |  | (1) | % |
| Acquisitions | $ | 4.5 |  | $ | — |  | $ | — |  | $ | — |  | $ | 4.5 |  | $ | — |  | $ | 4.7 |  |  | $ | 9.2 |  |
| % Change | 2 | % | — | % | — | % | — | % | 2 | % | — | % | 2 | % |  | 2 | % |
| Volume/Price | $ | (2.6) |  | $ | 2.4 |  | $ | 5.0 |  | $ | 2.1 |  | $ | 6.9 |  | $ | (8.1) |  | $ | (3.1) |  | $ | (7.0) |  | $ | (11.3) |  |
| % Change | (1) | % | 5 | % | 10 | % | 11 | % | 2 | % | (10) | % | (2) | % | 29 | % | (2) | % |

[0000038725-24-000162:8k_2_02:40]
*The Company has presented local currency price increases used to offset currency devaluation in the Argentina and Turkey hyperinflationary economies within the foreign currency translation, net row above.

[0000038725-24-000162:8k_2_02:41]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-24-000162:8k_2_02:42]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2024 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 52.8 |  | $ | 24.1 |  | $ | 12.2 |  | $ | (15.6) |  | $ | 73.5 |  |
| % Operating Income To Net Sales | 17.5 | % | 34.6 | % | 6.4 | % |  | 13.8 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2023 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 52.7 |  | $ | 25.8 |  | $ | 10.7 |  | $ | (11.1) |  | $ | 78.1 |  |
| % Operating Income To Net Sales | 17.8 | % | 33.2 | % | 5.7 | % |  | 14.5 | % |
