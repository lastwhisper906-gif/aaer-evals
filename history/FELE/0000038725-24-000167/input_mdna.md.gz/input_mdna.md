# FELE MD&A — 0000038725-24-000167


## mdna

[0000038725-24-000167:mdna:1]
[same as prior period, unchanged from 0000038725-24-000143:mdna:1]

[0000038725-24-000167:mdna:2]
Third Quarter 2024 vs. 2023

[0000038725-24-000167:mdna:3]
[same as prior period, unchanged from 0000038725-24-000143:mdna:3]

[0000038725-24-000167:mdna:4]
Net sales in the third quarter and first nine months of 2024 decreased 1 percent and 4 percent, respectively, from the prior-year periods. The sales decreases in the third quarter and first nine months of 2024 were primarily due to lower volumes and the negative impact of foreign currency translation, partially offset by price realization and the incremental sales impact from recent acquisitions. The Company's consolidated gross profit was $189.7 million and $553.0 million, respectively, for the third quarter and first nine months of 2024, increases of $3.4 million and $16.0 million, respectively, from the prior-year periods. Diluted earnings per share was $1.17 and $3.14, respectively, for the third quarter and first nine months of 2024, decreases of $0.06 and $0.15, respectively, from the prior-year periods.

[0000038725-24-000167:mdna:5]
[same as prior period, unchanged from 0000038725-24-000143:mdna:5]

[0000038725-24-000167:mdna:6]
[same as prior period, unchanged from 0000038725-24-000143:mdna:6]

[0000038725-24-000167:mdna:7]
Net sales in the third quarter and first nine months of 2024 were $531.4 million and $1.5 billion, respectively, and decreased 1 percent and 4 percent as compared to the prior-year periods. Sales were negatively impacted by changes in foreign exchange rates, principally due to the strengthening of the U.S. Dollar relative to the Argentine Peso and Turkish Lira. However, the Company increases prices in the local currency to offset the impact of currency devaluation in the Argentina and Turkey hyperinflationary economies. As a result, the net negative impact of foreign currency exchange rates on net sales was 1 percent in the third quarter and first nine months of 2024 compared to the same periods in the prior year.

[0000038725-24-000167:mdna:8]
|  | Net Sales |
| (In millions) | Q3 2024 |  | Q3 2023 |  | 2024 v 2023 |
| Water Systems | $ | 302.2 |  |  | $ | 295.8 |  |  | $ | 6.4 |  |
| Fueling Systems | 69.7 |  |  | 77.7 |  |  | (8.0) |  |
| Distribution | 190.8 |  |  | 189.2 |  |  | 1.6 |  |
| Eliminations/Other | (31.3) |  |  | (24.3) |  |  | (7.0) |  |
| Consolidated | $ | 531.4 |  |  | $ | 538.4 |  |  | $ | (7.0) |  |

[0000038725-24-000167:mdna:9]
|  | Net Sales |
| (In millions) | YTD September 30, 2024 |  | YTD September 30, 2023 |  | 2024 v 2023 |
| Water Systems | $ | 904.4 |  |  | $ | 924.1 |  |  | $ | (19.7) |  |
| Fueling Systems | 204.9 |  |  | 230.8 |  |  | (25.9) |  |
| Distribution | 528.3 |  |  | 525.3 |  |  | 3.0 |  |
| Eliminations/Other | (102.0) |  |  | (88.0) |  |  | (14.0) |  |
| Consolidated | $ | 1,535.6 |  |  | $ | 1,592.2 |  |  | $ | (56.6) |  |

[0000038725-24-000167:mdna:10]
[same as prior period, unchanged from 0000038725-24-000143:mdna:10]

[0000038725-24-000167:mdna:11]
Water Systems net sales increased 2 percent in the third quarter but decreased 2 percent in the first nine months of 2024, as compared to the prior-year periods. The sales growth in the third quarter was primarily due to higher volumes and price realization. The sales decline in the first nine months of 2024 was primarily due to lower volumes, which decreased due to weaker end market demand for large dewatering equipment. Sales decreased 2 percent in the third quarter and 1 percent in the first nine months of 2024 due to the negative impact from foreign exchange rates, as compared to prior-year periods. The incremental sales impact from a recent acquisition favorably impacted sales 2 percent in the third quarter and first nine months of 2024.

[0000038725-24-000167:mdna:12]
Water Systems net sales in the U.S. and Canada increased 1 percent in the third quarter but decreased 5 percent in the first nine months of 2024, as compared to the prior-year periods. In the third quarter of 2024, sales of groundwater pumping equipment increased 13 percent, sales of water treatment products increased 9 percent, and the sales of all other surface pumping

[0000038725-24-000167:mdna:13]
equipment increased 5 percent compared to 2023. Partially offsetting the increase, sales of large dewatering equipment decreased 31 percent compared to 2023.  In the first nine months of 2024, sales of large dewatering equipment decreased 43 percent, sales of water treatment products increased 12 percent, sales of all other surface pumping equipment increased 5 percent and sales of groundwater pumping equipment increased 3 percent compared to 2023.

[0000038725-24-000167:mdna:14]
Water Systems net sales in markets outside the U.S. and Canada increased 4 percent in both the third quarter and the first nine months of 2024, as compared to the prior-year periods. Sales decreased 4 percent in the third quarter and 3 percent in the first nine months of 2024 due to the negative impact from foreign exchange rates, as compared to prior-year periods. In both the third quarter and first nine months of 2024, excluding the impact of foreign currency translation, sales increased in all three major regions: EMEA, Latin America and Asia Pacific.

[0000038725-24-000167:mdna:15]
[same as prior period, unchanged from 0000038725-24-000143:mdna:14]

[0000038725-24-000167:mdna:16]
Fueling Systems net sales decreased 10 percent in the third quarter and 11 percent in the first nine months of 2024, as compared to the prior-year periods. These sales declines were primarily due to lower volumes.

[0000038725-24-000167:mdna:17]
Fueling Systems net sales in the U.S. and Canada decreased 4 percent in the third quarter and 6 percent in the first nine months of 2024, as compared to the prior-year periods. Outside the U.S. and Canada, Fueling Systems net sales decreased 22 percent in both the third quarter and first nine months of 2024, as compared to the prior-year periods.  The decreases were across all product lines.

[0000038725-24-000167:mdna:18]
[same as prior period, unchanged from 0000038725-24-000143:mdna:17]

[0000038725-24-000167:mdna:19]
Distribution net sales increased 1 percent in both the third quarter and first nine months of 2024, as compared to the prior-year periods. The Distribution segment sales increased due to the incremental sales impact from a recent acquisition which favorably impacted net sales by 2 percent in the third quarter and first nine months of 2024, partially offset by the negative impact of commodity pricing declines and unfavorable weather.

[0000038725-24-000167:mdna:20]
[same as prior period, unchanged from 0000038725-24-000143:mdna:19]

[0000038725-24-000167:mdna:21]
|  | Three Months Ended September 30, |
| (In Millions) | 2024 |  | % of Net Sales |  | 2023 |  | % of Net Sales |
| Gross Profit | $ | 189.7 |  |  | 35.7 | % |  | $ | 186.3 |  |  | 34.6 | % |
| Selling, General and Administrative Expense | 116.0 |  |  | 21.8 | % |  | 107.7 |  |  | 20.0 | % |

[0000038725-24-000167:mdna:22]
|  | Nine Months Ended September 30, |
| (In Millions) | 2024 |  | % of Net Sales |  | 2023 |  | % of Net Sales |
| Gross Profit | $ | 553.0 |  |  | 36.0 | % |  | $ | 537.0 |  |  | 33.7 | % |
| Selling, General and Administrative Expense | 352.3 |  |  | 22.9 | % |  | 324.7 |  |  | 20.4 | % |

[0000038725-24-000167:mdna:23]
[same as prior period, unchanged from 0000038725-24-000143:mdna:22]

[0000038725-24-000167:mdna:24]
The gross profit margin ratio was 35.7 percent and 36.0 percent in the third quarter and first nine months of 2024, respectively, and 34.6 percent and 33.7 percent in the third quarter and first nine months of 2023, respectively. The gross profit margin was favorably impacted in the third quarter and first nine months of 2024 by cost management, including lower freight costs in Water Systems and Fueling Systems, and a favorable product and geographic sales mix shift.

[0000038725-24-000167:mdna:25]
[same as prior period, unchanged from 0000038725-24-000143:mdna:24]

[0000038725-24-000167:mdna:26]
SG&A expenses were $116.0 million in the third quarter and $352.3 million in the first nine months of 2024 compared to $107.7 million in the third quarter and $324.7 million in the first nine months of 2023. SG&A expenses increased in the third quarter and first nine months of 2024 primarily due to higher employee compensation costs, including incremental expenses associated with the Company’s CEO transition, and the incremental expense impact of recent acquisitions. The SG&A expenses ratio was 21.8 percent and 22.9 percent in the third quarter and first nine months of 2024, respectively, and 20.0 percent and 20.4 percent in the third quarter and first nine months of 2023, respectively.

[0000038725-24-000167:mdna:27]
[same as prior period, unchanged from 0000038725-24-000143:mdna:26]

[0000038725-24-000167:mdna:28]
Restructuring expenses were $0.1 million in the third quarter and first nine months of 2024, respectively, and $0.5 million and $0.7 million in the third quarter and first nine months of 2023, respectively. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities, branch closings and consolidations.

[0000038725-24-000167:mdna:29]
[same as prior period, unchanged from 0000038725-24-000143:mdna:28]

[0000038725-24-000167:mdna:30]
Operating income decreased 6 percent and 5 percent in the third quarter and first nine months of 2024, as compared to the prior-year periods.

[0000038725-24-000167:mdna:31]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2024 |  | Q3 2023 |  | 2024 v 2023 |
| Water Systems |  | $ | 52.8 |  |  | $ | 52.7 |  |  | $ | 0.1 |  |
| Fueling Systems |  | 24.1 |  |  | 25.8 |  |  | (1.7) |  |
| Distribution |  | 12.2 |  |  | 10.7 |  |  | 1.5 |  |
| Eliminations/Other |  | (15.6) |  |  | (11.1) |  |  | (4.5) |  |
| Consolidated |  | $ | 73.5 |  |  | $ | 78.1 |  |  | $ | (4.6) |  |

[0000038725-24-000167:mdna:32]
|  |  | Operating income (loss) |
| (In millions) |  | YTD September 30, 2024 |  | YTD September 30, 2023 |  | 2024 v 2023 |
| Water Systems |  | $ | 162.3 |  |  | $ | 152.5 |  |  | $ | 9.8 |  |
| Fueling Systems |  | 68.9 |  |  | 73.3 |  |  | (4.4) |  |
| Distribution |  | 23.8 |  |  | 33.2 |  |  | (9.4) |  |
| Eliminations/Other |  | (54.4) |  |  | (47.4) |  |  | (7.0) |  |
| Consolidated |  | $ | 200.6 |  |  | $ | 211.6 |  |  | $ | (11.0) |  |

[0000038725-24-000167:mdna:33]
[same as prior period, unchanged from 0000038725-24-000143:mdna:32]

[0000038725-24-000167:mdna:34]
Water Systems operating income in the third quarter and first nine months of 2024 was $52.8 million and $162.3 million, respectively, increases of $0.1 million and $9.8 million, respectively, as compared to the prior-year periods. The increases were primarily due to price realization, cost management and a favorable product and geographic sales mix shift. The third quarter operating income margin was 17.5 percent, a decrease of 30 basis points from 17.8 percent in the third quarter of 2023. The first nine months of 2024 operating income margin was 17.9 percent, an increase of 140 basis points from 16.5 percent in the first nine months of 2023. Operating income margin increased in the first nine months of 2024 primarily due to cost management and a favorable product and geographic sales mix shift.

[0000038725-24-000167:mdna:35]
[same as prior period, unchanged from 0000038725-24-000143:mdna:34]

[0000038725-24-000167:mdna:36]
Fueling Systems operating income in the third quarter and first nine months of 2024 was $24.1 million and $68.9 million, respectively, decreases of $1.7 million and $4.4 million, respectively, as compared to the prior-year periods. The decreases were primarily due to lower sales. The third quarter operating income margin was 34.6 percent, an increase of 140 basis points from 33.2 percent in the third quarter of 2023. The first nine months of 2024 operating income margin was 33.6 percent, an increase of 180 basis points from 31.8 percent in the first nine months of 2023. Operating income margin increased primarily due to price realization and cost management.

[0000038725-24-000167:mdna:37]
[same as prior period, unchanged from 0000038725-24-000143:mdna:36]

[0000038725-24-000167:mdna:38]
Distribution operating income in the third quarter and first nine months of 2024 was $12.2 million and $23.8 million, respectively, an increase of $1.5 million and a decrease of $9.4 million, respectively, as compared to the prior-year periods. The third quarter operating income margin was 6.4 percent, an increase of 70 basis points from 5.7 percent in the third quarter of 2023. The first nine months of 2024 operating income margin was 4.5 percent, a decrease of 180 basis points from 6.3 percent in the first nine months of 2023. Operating income and operating income margin increased in the third quarter of 2024 primarily due to the incremental impact from a recent acquisition. Operating income and operating income margin decreased in the first nine months of 2024 primarily due to the negative impact on sales from wet weather across much of the United States, decreases in pricing of commodity-based products sold through the business and increased SG&A costs.

[0000038725-24-000167:mdna:39]
[same as prior period, unchanged from 0000038725-24-000143:mdna:38]

[0000038725-24-000167:mdna:40]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the third quarter and first nine months of 2024 compared to the prior-year periods of 2023 was an unfavorable $0.7 million and $2.2 million, respectively. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses increased $3.8 million and $4.8 million, respectively,

[0000038725-24-000167:mdna:41]
compared to the prior-year periods.  The increase was primarily driven by to higher employee compensation costs, including incremental expenses associated with the Company’s CEO transition.

[0000038725-24-000167:mdna:42]
[same as prior period, unchanged from 0000038725-24-000143:mdna:40]

[0000038725-24-000167:mdna:43]
Interest expense was $1.6 million and $5.0 million in the third quarter and first nine months of 2024, respectively, and $3.0 million and $10.3 million in the third quarter and first nine months of 2023, respectively. The decreases in the third quarter and first nine months of 2024 was primarily driven by lower debt.

[0000038725-24-000167:mdna:44]
Other (Expense) Income, Net

[0000038725-24-000167:mdna:45]
Other (expense) income, net was an expense of $0.2 million and income of $0.7 million in the third quarter and first nine months of 2024, respectively, and was income of $0.3 million and $1.9 million in the third quarter and first nine months of 2023, respectively.

[0000038725-24-000167:mdna:46]
[same as prior period, unchanged from 0000038725-24-000143:mdna:44]

[0000038725-24-000167:mdna:47]
Foreign currency-based transactions produced a gain of $0.1 million and an expense $5.2 million in the third quarter and first nine months of 2024, respectively, and an expense of $2.5 million and $8.1 million in the third quarter and first nine months of 2023, respectively. The results in the first nine months of 2024 and the third quarter and first nine months of 2023 are primarily due to transaction losses associated with the Turkish Lira and Argentine Peso relative to the U.S. dollar. The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-24-000167:mdna:48]
[same as prior period, unchanged from 0000038725-24-000143:mdna:46]

[0000038725-24-000167:mdna:49]
The provision for income taxes in the third quarter and first nine months of 2024 was $17.0 million and $43.8 million, respectively, and $14.7 million and $39.2 million in the third quarter and first nine months of 2023, respectively. The effective tax rate for the third quarter and first nine months of 2024 was 23.6 percent and 22.9 percent, respectively, and 20.2 percent and 20.1 percent in the third quarter and first nine months of 2023, respectively. The increase in the effective tax rates for the third quarter and first nine months of 2024 compared to the comparable periods in the prior year was a result of less favorable discrete events in 2024, primarily related to excess tax benefits from share-based compensation, in addition to an increase in the rate on foreign earnings with the implementation of the European Union’s Pillar Two Directive in 2024.

[0000038725-24-000167:mdna:50]
[same as prior period, unchanged from 0000038725-24-000143:mdna:48]

[0000038725-24-000167:mdna:51]
Net income in the third quarter and first nine months of 2024 was $54.9 million and $147.3 million, respectively, and $58.2 million and $155.9 million in the third quarter and first nine months of 2023, respectively. Net income attributable to Franklin Electric Co., Inc. in the third quarter and first nine months of 2024 was $54.6 million and $146.7 million, respectively, or $1.17 and $3.14 per diluted share. Net income attributable to Franklin Electric Co., Inc. in the third quarter and first nine months of 2023 was $57.8 million and $154.7 million, respectively, or $1.23 and $3.29 per diluted share.

[0000038725-24-000167:mdna:52]
[same as prior period, unchanged from 0000038725-24-000143:mdna:50]

[0000038725-24-000167:mdna:53]
[same as prior period, unchanged from 0000038725-24-000143:mdna:51]

[0000038725-24-000167:mdna:54]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at September 30, 2024 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-24-000167:mdna:55]
As of September 30, 2024, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of September 30, 2024, the Company had $345.4 million borrowing capacity under its credit agreement as $4.6 million in letters of commercial and standby letters of credit were outstanding and undrawn and no revolver borrowings were drawn or outstanding.

[0000038725-24-000167:mdna:56]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $200.0 million.  As of September 30, 2024, the remaining borrowing capacity on the New York Life Agreement was $175.0 million. The Company also maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates. On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million. The maturity dates of both agreements were extended from July 30, 2024 to May 15, 2027.

[0000038725-24-000167:mdna:57]
The Company also has other long-term debt borrowings outstanding as of September 30, 2024. See Note 10 - Debt included in the Company's Annual Report on Form 10-K for the year ended December 31, 2023, for additional information regarding these obligations and future maturities as well as Note 10 - Debt of this current quarterly report for changes to these agreements since December 31, 2023.

[0000038725-24-000167:mdna:58]
At September 30, 2024, the Company had $68.6 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate the majority of these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-24-000167:mdna:59]
[same as prior period, unchanged from 0000038725-24-000143:mdna:57]

[0000038725-24-000167:mdna:60]
The following table summarizes significant sources and uses of cash and cash equivalents for the first nine months of 2024 and 2023.

[0000038725-24-000167:mdna:61]
| (in millions) |  | 2024 |  | 2023 |
| Net cash flows from operating activities |  | $ | 151.1 |  |  | $ | 198.6 |  |
| Net cash flows from investing activities |  | (29.3) |  |  | (36.8) |  |
| Net cash flows from financing activities |  | (100.0) |  |  | (140.3) |  |
| Impact of exchange rates on cash and cash equivalents |  | (0.5) |  |  | (4.8) |  |
| Change in cash and cash equivalents |  | $ | 21.3 |  |  | $ | 16.7 |  |

[0000038725-24-000167:mdna:62]
[same as prior period, unchanged from 0000038725-24-000143:mdna:60]

[0000038725-24-000167:mdna:63]
[same as prior period, unchanged from 0000038725-24-000143:mdna:61]

[0000038725-24-000167:mdna:64]
Net cash provided by operating activities was $151.1 million for the nine months ended September 30, 2024 compared to $198.6 million provided by operating activities for the nine months ended September 30, 2023. The change in operating cash flow was primarily attributable to changes in working capital and lower earnings.

[0000038725-24-000167:mdna:65]
[same as prior period, unchanged from 0000038725-24-000143:mdna:63]

[0000038725-24-000167:mdna:66]
[same as prior period, unchanged from 0000038725-24-000143:mdna:64]

[0000038725-24-000167:mdna:67]
Net cash used in investing activities was $29.3 million for the nine months ended September 30, 2024 compared to $36.8 million used in investing activities for the nine months ended September 30, 2023. The change in investing cash flow was primarily attributable to decreased acquisition activity in the first nine months of 2024.

[0000038725-24-000167:mdna:68]
[same as prior period, unchanged from 0000038725-24-000143:mdna:66]

[0000038725-24-000167:mdna:69]
[same as prior period, unchanged from 0000038725-24-000143:mdna:67]

[0000038725-24-000167:mdna:70]
Net cash used in financing activities was $100.0 million for the nine months ended September 30, 2024 compared to $140.3 million used in financing activities for the nine months ended September 30, 2023. The change in financing cash flow was primarily due to lower net repayments under the Company's credit facility in 2024 compared to 2023, partially offset by lower proceeds from option exercises, increased share repurchase activity and higher dividends.

[0000038725-24-000167:mdna:71]
[same as prior period, unchanged from 0000038725-24-000143:mdna:69]

[0000038725-24-000167:mdna:72]
forward-looking statements included in this Form 10-Q are based upon information presently available. The Company does not assume any obligation to update any forward-looking information, except as required by law.

[0000038725-24-000167:mdna:73]
28
