# FELE MD&A — 0000038725-15-000161


## mdna

[0000038725-15-000161:mdna:1]
[same as prior period, unchanged from 0000038725-15-000090:mdna:1]

[0000038725-15-000161:mdna:2]
Second Quarter 2015 vs. Second Quarter 2014

[0000038725-15-000161:mdna:3]
[same as prior period, unchanged from 0000038725-15-000090:mdna:3]

[0000038725-15-000161:mdna:4]
Sales and adjusted earnings in the second quarter of 2015 decreased from the second quarter last year.  The sales decrease was primarily due to volume decreases and the negative impact of foreign currency translation. The Company's consolidated gross profit was $80.2 million for the second quarter of 2015, a decrease of $19.2 million or about 19 percent from the prior year’s second quarter.

[0000038725-15-000161:mdna:5]
[same as prior period, unchanged from 0000038725-15-000090:mdna:5]

[0000038725-15-000161:mdna:6]
[same as prior period, unchanged from 0000038725-15-000090:mdna:6]

[0000038725-15-000161:mdna:7]
Net sales in the second quarter of 2015 were $247.4 million, a decrease of $37.1 million or about 13 percent compared to 2014 second quarter sales of $284.5 million.  The incremental impact of sales from acquired businesses was $8.5 million or about 3 percent.  Sales revenue decreased by $22.5 million or about 8 percent in the second quarter of 2015 due to foreign currency translation. The sales change in the second quarter of 2015, excluding acquisitions and foreign currency translation, was a decrease of $23.1 million or about 8 percent.

[0000038725-15-000161:mdna:8]
|  | Net Sales |
| (In millions) | Q2 2015 |  | Q2 2014 |  | 2015 v 2014 |
| Water Systems | $ | 191.6 |  |  | $ | 226.7 |  |  | $ | (35.1 | ) |
| Fueling Systems | 55.8 |  |  | 57.8 |  |  | (2.0 | ) |
| Consolidated | $ | 247.4 |  |  | $ | 284.5 |  |  | $ | (37.1 | ) |

[0000038725-15-000161:mdna:9]
[same as prior period, unchanged from 0000038725-15-000090:mdna:9]

[0000038725-15-000161:mdna:10]
Water Systems sales were $191.6 million in the second quarter 2015, a decrease of $35.1 million or about 15 percent versus the second quarter 2014 sales of $226.7 million.  Sales from businesses acquired since the second quarter of 2014 were $8.3 million or about 4 percent.  Water Systems sales were reduced by $19.5 million or about 9 percent in the quarter due to foreign currency translation.  Excluding acquisitions and foreign currency translation, Water Systems sales were down about 11 percent compared to the second quarter 2014.

[0000038725-15-000161:mdna:11]
Water Systems sales in the U.S. and Canada represented 37 percent of consolidated sales and declined by about 25 percent compared to the prior year. Water Systems sales in the U.S and Canada were reduced by $1.4 million or about 1 percent in the quarter due to foreign currency translation.  In the second quarter 2015, U.S. and Canada sales of Pioneer branded mobile dewatering equipment declined by over 60 percent, sales of groundwater pumping equipment declined by about 24 percent, and sales of surface water pumping equipment declined by about 12 percent versus the second quarter 2014.  The decline in mobile dewatering equipment is primarily attributed to reduced demand in the oil and gas end markets.  The decline in groundwater equipment sales is attributable primarily to the near record precipitation experienced in many key markets and across the U.S. in general during the second quarter 2015.

[0000038725-15-000161:mdna:12]
Additionally, demand for groundwater and surface pumping equipment declined due to excessive customer inventories that were being worked down in the second quarter.  Sales of surface water pumping equipment also declined in the quarter due to lower condensate pump sales as cooler temperatures delayed the start to the HVAC season.

[0000038725-15-000161:mdna:13]
Water Systems sales in Latin America were about 13 percent of consolidated sales for the second quarter and declined by about 1 percent compared to the second quarter of the prior year.  Sales from businesses acquired since the second quarter of 2014 were $4.1 million or about 13 percent. Water Systems sales were reduced by $6.7 million or about 21 percent in the quarter due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, Latin American sales increased by about 7 percent compared to the second quarter 2014.  The growth in sales was led by increased sales in Mexico due to general improved conditions.

[0000038725-15-000161:mdna:14]
Water Systems sales in the Middle East and Africa were about 12 percent of consolidated sales and decreased by about 7

[0000038725-15-000161:mdna:15]
percent compared to the second quarter 2014.  Water Systems sales were reduced by about 14 percent in the quarter due to foreign currency translation.  Excluding the impact of foreign currency translation, sales increased by about 7 percent compared to the second quarter 2014. The growth was driven by strong sales in the Gulf and Near East countries, mainly Turkey.

[0000038725-15-000161:mdna:16]
Water Systems sales in the Asia Pacific region were 8 percent of consolidated sales and were up about 37 percent compared to the second quarter prior year.  Sales from businesses acquired since the second quarter of 2014 were $2.8 million or about 19 percent.  Asia Pacific sales were reduced by about 5 percent in the quarter due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, Asia Pacific sales increased by about 24 percent compared to the second quarter 2014.  The Asia Pacific region experienced strong year over year growth in Southeast Asia and Korea due to a combination of strong favorable weather and shipment timing.

[0000038725-15-000161:mdna:17]
Water Systems sales in Europe were about 7 percent of consolidated sales and decreased by about 27 percent compared to the second quarter 2014.   The impact of foreign currency translation decreased sales by about 24 percent compared to the second quarter 2014.  Excluding the impact of foreign currency translation, European sales were down about 3 percent versus the second quarter of 2014 due to lower Pioneer branded dewatering equipment sales.

[0000038725-15-000161:mdna:18]
[same as prior period, unchanged from 0000038725-15-000090:mdna:16]

[0000038725-15-000161:mdna:19]
Fueling Systems sales represented 23 percent of consolidated sales and were $55.8 million in the second quarter 2015, a decrease of $2.0 million or about 3 percent versus the second quarter 2014 sales of $57.8 million. Sales from businesses acquired since the second quarter of 2014 were $0.2 million or less than 1 percent. Fueling Systems sales decreased by $3.0 million or about 5 percent in the quarter due to foreign currency translation. Fueling Systems sales increased by $0.8 million or about 1 percent after excluding foreign currency translation.

[0000038725-15-000161:mdna:20]
Fueling Systems sales in the U.S. grew by about 8 percent during the quarter with most of the sales growth coming from fuel dispensing products and piping.  Fueling Systems revenues declined in India and China due to the timing of tender awards made in India and the ongoing reduction in State owned oil company procurements in China.  Sales also declined in Europe principally due to a reduction in the sale of storage tanks that support North Sea oil production.

[0000038725-15-000161:mdna:21]
[same as prior period, unchanged from 0000038725-15-000090:mdna:18]

[0000038725-15-000161:mdna:22]
Cost of sales as a percent of net sales for the second quarter of 2015 and 2014 was 67.6 percent and 65.1 percent, respectively. Correspondingly, the gross profit margin decreased to 32.4 percent from 34.9 percent, a 250 basis point decline.  The gross profit margin decrease was due in large part from deleveraging of fixed costs on lower sales.  The Company’s consolidated gross profit was $80.2 million for the second quarter of 2015, a decrease of $19.2 million, or about 19 percent, from the second quarter of 2014 gross profit of $99.4 million.

[0000038725-15-000161:mdna:23]
[same as prior period, unchanged from 0000038725-15-000090:mdna:20]

[0000038725-15-000161:mdna:24]
Selling, general, and administrative (SG&A) expenses were $56.3 million in the second quarter of 2015 compared to $60.0 million in the second quarter of prior year, a decrease of $3.7 million or about 6 percent.  The increase in SG&A expenses from acquired businesses was $2.0 million.  Excluding acquisitions, the Company’s overall SG&A expenses in the second quarter of 2015 decreased by $5.7 million or about 10 percent to prior year second quarter a portion of which was related to foreign exchange.

[0000038725-15-000161:mdna:25]
[same as prior period, unchanged from 0000038725-15-000090:mdna:22]

[0000038725-15-000161:mdna:26]
Restructuring expenses for the second quarter of 2015 were $0.8 million and had a $0.01 impact on diluted earnings per share and were primarily severance expenses and other miscellaneous manufacturing realignment activities. Restructuring expenses for the second quarter of 2014 were $0.3 million and had no impact on diluted earnings per share and were primarily related to severance expenses and other miscellaneous manufacturing realignment activities.

[0000038725-15-000161:mdna:27]
[same as prior period, unchanged from 0000038725-15-000090:mdna:24]

[0000038725-15-000161:mdna:28]
Operating income was $23.2 million in the second quarter of 2015, down $15.9 million or about 41 percent from $39.1 million in the second quarter of 2014.

[0000038725-15-000161:mdna:29]
|  |  | Operating income (loss) |
| (In millions) |  | Q2 2015 |  | Q2 2014 |  | 2015 v 2014 |
| Water Systems |  | $ | 24.3 |  |  | $ | 41.7 |  |  | $ | (17.4 | ) |
| Fueling Systems |  | 12.4 |  |  | 13.5 |  |  | (1.1 | ) |
| Other |  | (13.5 | ) |  | (16.1 | ) |  | 2.6 |  |
| Consolidated |  | $ | 23.2 |  |  | $ | 39.1 |  |  | $ | (15.9 | ) |

[0000038725-15-000161:mdna:30]
There were specific items in the second quarter of 2015 and 2014 that impacted operating income that were not operational in nature.  In the second quarter of 2015 there were four such items: $0.8 million of restructuring charges, $0.5 million related to business realignment cost, primarily severance, in targeted fixed cost reduction actions, $0.3 million related to executive transition and $0.1 million for pending and completed acquisition related activities. In the second quarter of 2014 there were three such items: $0.3 million of restructuring charges, $2.5 million related to executive transition and $0.8 million for pending and completed acquisition-related activities.

[0000038725-15-000161:mdna:31]
[same as prior period, unchanged from 0000038725-15-000090:mdna:29]

[0000038725-15-000161:mdna:32]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (In millions) | For the Second Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 24.3 |  | $ | 12.4 |  | $ | (13.5 | ) | $ | 23.2 |  |
| % Operating Income To Net Sales | 12.7 | % | 22.2 | % |  | 9.4 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.6 |  | $ | 0.2 |  | $ | — |  | $ | 0.8 |  |
| Non-GAAP | $ | 0.5 |  | $ | 0.1 |  | $ | 0.3 |  | $ | 0.9 |  |
| Operating Income after Non-GAAP Adjustments | $ | 25.4 |  | $ | 12.7 |  | $ | (13.2 | ) | $ | 24.9 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 13.3 | % | 22.8 | % |  | 10.1 | % |
|  | For the Second Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 41.7 |  | $ | 13.5 |  | $ | (16.1 | ) | $ | 39.1 |  |
| % Operating Income To Net Sales | 18.4 | % | 23.4 | % |  | 13.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.3 |  | $ | — |  | $ | — |  | $ | 0.3 |  |
| Non-GAAP | $ | 0.4 |  | $ | 0.4 |  | $ | 2.5 |  | $ | 3.3 |  |
| Operating Income after Non-GAAP Adjustments | $ | 42.4 |  | $ | 13.9 |  | $ | (13.6 | ) | $ | 42.7 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 18.7 | % | 24.0 | % |  | 15.0 | % |

[0000038725-15-000161:mdna:33]
[same as prior period, unchanged from 0000038725-15-000090:mdna:31]

[0000038725-15-000161:mdna:34]
Water Systems operating income, after non-GAAP adjustments, was $25.4 million in the second quarter 2015, down $17.0 million versus the second quarter 2014. The second quarter operating income margin after non-GAAP adjustments was 13.3 percent, down 540 basis points from 18.7 percent in the second quarter of 2014.  Operating income margin after non-GAAP

[0000038725-15-000161:mdna:35]
24

[0000038725-15-000161:mdna:36]
adjustments decreased in Water Systems primarily due to fixed costs deleveraging from lower sales.

[0000038725-15-000161:mdna:37]
[same as prior period, unchanged from 0000038725-15-000090:mdna:33]

[0000038725-15-000161:mdna:38]
Fueling Systems operating income after non-GAAP adjustments was $12.7 million in the second quarter of 2015 compared to $13.9 million after non-GAAP adjustments in the second quarter of 2014, a decrease of about 9 percent. The second quarter operating income margin after non-GAAP adjustments was 22.8 percent, a decrease of 120 basis points from the 24.0 percent of net sales in the second quarter of 2014.  The decrease in basis points was primarily due to deleveraging fixed costs.

[0000038725-15-000161:mdna:39]
[same as prior period, unchanged from 0000038725-15-000090:mdna:35]

[0000038725-15-000161:mdna:40]
Operating income-other is composed primarily of unallocated general and administrative expenses.  Adjusted general and administrative expenses were lower by about 3 percent primarily related to lower compensation expenses.

[0000038725-15-000161:mdna:41]
[same as prior period, unchanged from 0000038725-15-000090:mdna:37]

[0000038725-15-000161:mdna:42]
Interest expense for the second quarter of 2015 and 2014 was $2.4 million and $2.5 million, respectively.

[0000038725-15-000161:mdna:43]
[same as prior period, unchanged from 0000038725-15-000090:mdna:39]

[0000038725-15-000161:mdna:44]
Other income or expense was income of $1.4 million in the second quarter of 2015 and income of $0.9 million in the second quarter of 2014.  Included in other income in the second quarter of 2015 was minority income of $1.4 million and interest income of $0.1 million, primarily derived from the investment of cash balances in short-term securities. Included in other income in the second quarter of 2014 was interest income of $0.6 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-15-000161:mdna:45]
[same as prior period, unchanged from 0000038725-15-000090:mdna:41]

[0000038725-15-000161:mdna:46]
Foreign currency-based transactions produced a loss for the second quarter of 2015 of $0.4 million, primarily due to the euro relative to the U.S. dollar.  Foreign currency-based transactions produced a gain for the second quarter of 2014 of $0.3 million primarily due to the Canadian dollar which strengthened relative to the U.S. dollar.

[0000038725-15-000161:mdna:47]
[same as prior period, unchanged from 0000038725-15-000090:mdna:43]

[0000038725-15-000161:mdna:48]
The provision for income taxes in the second quarter of 2015 and 2014 was $5.4 million and $10.4 million, respectively. The effective tax rate before discrete adjustments for the second quarter of 2015 was about 27 percent, flat to the second quarter of 2014 tax rate before discrete adjustments. The tax rate as a percentage of pre-tax earnings for the second quarter of 2015 was about 25 percent primarily due the completion of income tax audits and the favorable resolution of matters previously under review. The average effective tax rate after discrete events for the back half of 2015 is projected to be 25 percent. The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-15-000161:mdna:49]
[same as prior period, unchanged from 0000038725-15-000090:mdna:45]

[0000038725-15-000161:mdna:50]
Net income for the second quarter of 2015 was $16.4 million compared to the prior year second quarter net income of $27.5 million.  Net income attributable to Franklin Electric Co., Inc. for the second quarter of 2015 was $16.2 million, or $0.33 per diluted share, compared to the prior year second quarter net income attributable to Franklin Electric Co., Inc. of $27.1 million or $0.55 per diluted share. Earnings after non-GAAP adjustments for the second quarter of 2015 were $17.0 million, or $0.35 per diluted share, compared to the prior year second quarter earnings after non-GAAP adjustments of $28.8 million or $0.60 per diluted share.

[0000038725-15-000161:mdna:51]
There were specific items in the second quarter of 2015 and 2014 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-15-000161:mdna:52]
| Earnings Before and After Non-GAAP Adjustments | For the Second Quarter Ended |
| (In millions) | 2015 | 2014 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 16.2 |  | $ | 27.1 |  | (40 | )% |
| Allocated Undistributed Earnings | $ | (0.2 | ) | $ | (0.5 | ) |  |
| Adjusted Earnings for EPS Calculations | $ | 16.0 |  | $ | 26.6 |  | (40 | )% |
| Non-GAAP adjustments, before tax: |  |  |  |
| Restructuring | $ | 0.8 |  | $ | 0.3 |  |  |
| Non-GAAP items | $ | 0.9 |  | $ | 3.3 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | — |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 0.5 |  | $ | 0.2 |  |  |
| Non-GAAP items | $ | 0.5 |  | $ | 2.0 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | — |  |  |
| Net Income attributable to Franklin Electric Co., Inc. after Non-GAAP Adjustments (Adjusted Net Income) | $ | 17.0 |  | $ | 28.8 |  | (41 | )% |

[0000038725-15-000161:mdna:53]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the Second Quarter Ended |
| (In millions, except per share data) | 2015 | 2014 | Change |
| Average Fully Diluted Shares Outstanding | 48.1 |  | $ | 48.2 |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.33 |  | $ | 0.55 |  | (40 | )% |
| Restructuring per Share, net of tax | $ | 0.01 |  | $ | — |  |  |
| Non-GAAP items | $ | 0.01 |  | $ | 0.05 |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.35 |  | $ | 0.60 |  | (42 | )% |

[0000038725-15-000161:mdna:54]
First Half of 2015 vs. First Half of 2014

[0000038725-15-000161:mdna:55]
OVERVIEW

[0000038725-15-000161:mdna:56]
Sales and earnings in the first half of 2015 were down from the same period last year.  The sales decrease was related to the negative impact of foreign currency translation on sales and volume decreases partially offset by acquisitions and price increases. The Company's consolidated gross profit was $151.7 million for the first half of 2015, a decrease of $25.8 million or about 15 percent from the first half of 2014.

[0000038725-15-000161:mdna:57]
RESULTS OF OPERATIONS

[0000038725-15-000161:mdna:58]
Net Sales

[0000038725-15-000161:mdna:59]
Net sales in the first half of 2015 were $473.2 million, a decrease of $42.7 million or about 8 percent compared to 2014 first half sales of $515.9 million.  The incremental impact of sales from acquired businesses was $17.4 million or about 3 percent.  Sales revenue decreased by $39.1 million or about 7 percent in the first half of 2015 due to foreign currency translation. The sales change in the first half of 2015, excluding acquisitions and foreign currency translation, was a decrease of $21.0 million or about 4 percent.

[0000038725-15-000161:mdna:60]
26

[0000038725-15-000161:mdna:61]
| (In millions) | YTD July 4, 2015 |  | YTD June 28, 2014 |  | 2015 v 2014 |
|  | Net Sales |
| Water Systems | $ | 370.9 |  |  | $ | 411.3 |  |  | $ | (40.4 | ) |
| Fueling Systems | 102.3 |  |  | 104.6 |  |  | (2.3 | ) |
| Consolidated | $ | 473.2 |  |  | $ | 515.9 |  |  | $ | (42.7 | ) |

[0000038725-15-000161:mdna:62]
Net Sales-Water Systems

[0000038725-15-000161:mdna:63]
Water Systems sales were $370.9 million in the first half 2015, a decrease of $40.4 million or about 10 percent versus the first half 2014. The incremental impact of sales from acquired businesses was $17.1 million or 4 percent. Foreign currency translation rate changes decreased sales $33.4 million, or about 8 percent, compared to sales in the first half of 2014. The Water Systems sales change in the first half of 2015, excluding acquisitions and foreign currency translation, was a decrease of $24.1 million or about 6 percent.

[0000038725-15-000161:mdna:64]
Water Systems sales in the U.S. and Canada were 36 percent of consolidated sales and declined by about 19 percent compared to the first half of 2014. Sales revenue decreased by $2.5 million or about 1 percent in the first half of 2015 due to foreign currency translation. The sales change in the first half of 2015, excluding acquisitions and foreign currency translation, was a decrease of about 19 percent.

[0000038725-15-000161:mdna:65]
In the first half of 2015, U.S. and Canada sales of Pioneer branded mobile dewatering equipment declined by about 55 percent. The decline in mobile dewatering equipment is primarily attributed to reduced demand in the oil and gas end markets. Sales of groundwater pumping equipment declined by about 18 percent, and sales of surface water pumping equipment declined by about 5 percent versus the first half of 2014.  The decline in groundwater equipment sales is attributable primarily to the near record precipitation experienced in many key markets and across the U.S. in general.  Additionally, demand for groundwater and surface pumping equipment declined due to excessive customer inventories that were being worked down.  Sales of surface water pumping equipment also declined due to lower condensate pump sales as cooler temperatures delayed the start to the HVAC season.

[0000038725-15-000161:mdna:66]
Water Systems sales in Latin America were about 14 percent of consolidated sales for the first half and grew by 10 percent compared to the prior year first half.  The incremental impact of sales from acquired businesses was $10.4 million or about 17 percent. Sales revenue decreased by $11.5 million or about 19 percent in the first half of 2015 due to foreign currency translation. The sales change in the first half of 2015, excluding acquisitions and foreign currency translation, was an increase of $7.2 million or about 12 percent.  The growth in sales was led by increased sales in Mexico and Brazil, in local currency.  This sales growth is a result of increasing demand for Franklin submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions.

[0000038725-15-000161:mdna:67]
Water Systems sales in the Middle East and Africa were about 12 percent of consolidated sales and declined by about 5 percent compared to the first half of 2014. Water Systems in the Middle East and Africa were reduced by $6.8 million or about 11 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, sales were up $3.6 million or about 6 percent compared to the first half of 2014. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-15-000161:mdna:68]
Water Systems sales in the Asia Pacific region were 8 percent of consolidated sales and increased by about 19 percent compared to the first half of the prior year. The incremental impact of sales from acquired businesses was $5.3 million or about 16 percent.  Sales revenue decreased by about 5 percent in the first half of 2015 due to foreign currency translation. The sales change in the first half of 2015, excluding acquisitions and foreign currency translation, was an increase about 8 percent. The Asia Pacific region experienced strong year over year growth in Southeast Asia and Korea.

[0000038725-15-000161:mdna:69]
Water Systems sales in Europe were about 7 percent of consolidated sales and declined by about 20 percent compared to the first half of 2014.  Sales in Europe in the first half of 2015 decreased by $10.9 million or about 25 percent due to foreign currency translation. Excluding the impact of foreign currency translation, European sales increased $2.1 million or about 5 percent compared to the first half of 2014.

[0000038725-15-000161:mdna:70]
Net Sales-Fueling Systems

[0000038725-15-000161:mdna:71]
Fueling Systems sales were $102.3 million or about 23 percent of consolidated sales in the first half of 2015 and decreased $2.3 million or about 2 percent from the first half of 2014. The incremental impact of sales from acquired businesses was $0.3

[0000038725-15-000161:mdna:72]
million or less than 1 percent. Foreign currency translation rate changes decreased sales $5.7 million or about 5 percent compared to sales in the first half of 2014. The Fueling Systems sales change in the first half of 2015, excluding foreign currency translation, was an increase of $3.1 million or about 3 percent.

[0000038725-15-000161:mdna:73]
Fueling Systems sales in the U.S. grew by about 7 percent during the first half with most of the sales growth coming from all product lines, especially in piping.  Fueling Systems revenues declined in India and China due to the timing of tender awards made in India and the ongoing reduction in State owned oil company procurements in China.  Sales also declined in Europe principally due to a reduction in the sale of storage tanks that support North Sea oil production.

[0000038725-15-000161:mdna:74]
Cost of Sales

[0000038725-15-000161:mdna:75]
Cost of sales as a percent of net sales for the first half of 2015 and 2014 was 67.9 percent and 65.6 percent, respectively. Correspondingly, the gross profit margin was 32.1 percent and 34.4 percent for both first halves. The Company's consolidated gross profit was $151.7 million for the first half of 2015, down $25.8 million from the gross profit of $177.5 million in the first half of 2014. The gross profit margin decrease was primarily due to higher raw material costs and fixed costs deleverage on lower sales.

[0000038725-15-000161:mdna:76]
Selling, General, and Administrative (“SG&A”)

[0000038725-15-000161:mdna:77]
Selling, general, and administrative expenses were $111.4 million in the first half of 2015 and decreased by $0.6 million or less than 1 percent in the first half of 2015 compared to $112.0 million the first half of last year. There were $1.2 million of costs included in non-GAAP adjustments (see discussion of non-GAAP adjustments below) related to executive transition, business realignment cost and pending or completed acquisitions in the first half of 2015. There were $3.3 million of costs included in non-GAAP adjustments related to executive transition and pending or completed acquisitions in the first half of 2014. After non-GAAP adjustments, SG&A expenses were $110.2 million in the first half of 2015 and increased by $1.5 million or about 1 percent in the first half of 2015 compared to $108.7 million the first half of last year. In the first half of 2015, increases in SG&A attributable to acquisitions were $4.0 million. Excluding non-GAAP adjustments and acquisitions, the Company’s overall SG&A expenses in the first half of 2015 decreased by $2.5 million or about 2 percent to prior year a portion of which was related to foreign exchange.

[0000038725-15-000161:mdna:78]
Restructuring Expenses

[0000038725-15-000161:mdna:79]
Restructuring expenses for the first half of 2015 were $1.2 million and reduced diluted earnings per share by approximately $0.02. Restructuring expenses were primarily related to the continuing European manufacturing realignment started last year. Restructuring expenses were primarily severance expenses and other miscellaneous manufacturing realignment activities. Restructuring expenses for the first half of 2014 were $0.4 million and had no impact on diluted earnings per share.

[0000038725-15-000161:mdna:80]
Operating Income

[0000038725-15-000161:mdna:81]
Operating income was $39.0 million in the first half of 2015, down $26.1 million from $65.1 million in the first half of 2014.

[0000038725-15-000161:mdna:82]
| (In millions) |  | YTDJuly 4, 2015 |  | YTDJune 28, 2014 |  | 2015 v 2014 |
|  |  | Operating income (loss) |
| Water Systems |  | $ | 43.7 |  |  | $ | 71.0 |  |  | $ | (27.3 | ) |
| Fueling Systems |  | 22.0 |  |  | 22.5 |  |  | (0.5 | ) |
| Other |  | (26.7 | ) |  | (28.4 | ) |  | 1.7 |  |
| Consolidated |  | $ | 39.0 |  |  | $ | 65.1 |  |  | $ | (26.1 | ) |

[0000038725-15-000161:mdna:83]
There were specific items in the first half of 2015 and 2014 that impacted operating income that were not operational in nature.

[0000038725-15-000161:mdna:84]
In the first half of 2015 they were as follows:

[0000038725-15-000161:mdna:85]
| • | Restructuring charges of $1.2 million including severance expenses and other miscellaneous manufacturing realignment activities, primarily related to the continued European realignment activities started last year. |

[0000038725-15-000161:mdna:86]
| • | Executive transition costs of $0.6 million. |

[0000038725-15-000161:mdna:87]
| • | Business realignment expenses of $0.4 million, primarily related to severance, in targeted fixed cost reduction actions. |

[0000038725-15-000161:mdna:88]
| • | Other miscellaneous costs of $0.2 million related to pending and completed acquisitions. |

[0000038725-15-000161:mdna:89]
In the first half of 2014 they were as follows:

[0000038725-15-000161:mdna:90]
| • | Restructuring charges of $0.4 million including severance expenses and other miscellaneous manufacturing |

[0000038725-15-000161:mdna:91]
realignment activities.

[0000038725-15-000161:mdna:92]
| • | Executive transition costs of $2.5 million. |

[0000038725-15-000161:mdna:93]
| • | Other miscellaneous costs of $0.9 million related to pending and completed acquisitions. |

[0000038725-15-000161:mdna:94]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income after non-GAAP adjustments to net sales.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-15-000161:mdna:95]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the First Half of 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 43.7 |  | $ | 22.0 |  | $ | (26.7 | ) | $ | 39.0 |  |
| % Operating Income To Net Sales | 11.8 | % | 21.5 | % |  | 8.2 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.9 |  | $ | 0.3 |  | $ | — |  | $ | 1.2 |  |
| Non-GAAP | $ | 0.5 |  | $ | 0.1 |  | $ | 0.6 |  | $ | 1.2 |  |
| Operating Income after Non-GAAP Adjustments | $ | 45.1 |  | $ | 22.4 |  | $ | (26.1 | ) | $ | 41.4 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.2 | % | 21.9 | % |  | 8.7 | % |
|  | For the First Half of 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 71.0 |  | $ | 22.5 |  | $ | (28.4 | ) | $ | 65.1 |  |
| % Operating Income To Net Sales | 17.3 | % | 21.5 | % |  | 12.6 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.4 |  | $ | — |  | $ | — |  | $ | 0.4 |  |
| Non-GAAP | $ | 0.5 |  | $ | 0.4 |  | $ | 2.5 |  | $ | 3.4 |  |
| Operating Income after Non-GAAP Adjustments | $ | 71.9 |  | $ | 22.9 |  | $ | (25.9 | ) | $ | 68.9 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 17.5 | % | 21.9 | % |  | 13.4 | % |

[0000038725-15-000161:mdna:96]
Operating Income-Water Systems

[0000038725-15-000161:mdna:97]
Water Systems operating income, after non-GAAP adjustments, was $45.1 million in the first half of 2015 compared to $71.9 million after non-GAAP adjustments in the first half of 2014, a decrease of 37 percent. The first half operating income margin after non-GAAP adjustments was 12.2 percent and decreased by 530 basis points compared to the first half of 2014. Operating income margin after non-GAAP adjustments decreased in Water Systems primarily due to loss of operating leverage.

[0000038725-15-000161:mdna:98]
Operating Income-Fueling Systems

[0000038725-15-000161:mdna:99]
Fueling Systems operating income after non-GAAP adjustments was $22.4 million in the first half of 2015 compared to $22.9 million after non-GAAP adjustments in the first half of 2014, a decrease of 2 percent. The first half operating income margin after non-GAAP adjustments was 21.9 percent flat compared to the percent of net sales in the first half of 2014.

[0000038725-15-000161:mdna:100]
Operating Income-Other

[0000038725-15-000161:mdna:101]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses were flat in the first half of 2015 compared to the same period last year.

[0000038725-15-000161:mdna:102]
Interest Expense

[0000038725-15-000161:mdna:103]
Interest expense for the first half of 2015 and 2014 was $5.1 million and $5.3 million, respectively.

[0000038725-15-000161:mdna:104]
Other Income or Expense

[0000038725-15-000161:mdna:105]
Other income or expense was a gain of $4.4 million in the first half of 2015. Included in other income in the first half of 2015 was minority income $1.7 million and interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities. The Company also realized a gain on the share purchase liability in the first quarter of this year of about $2.7 million. The first half of 2014 was a gain of $1.2 million. Included in other income in the first half of 2014 was interest income of $0.9 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-15-000161:mdna:106]
Foreign Exchange

[0000038725-15-000161:mdna:107]
Foreign currency-based transactions produced a gain for the first half of 2015 of $0.1 million, primarily due to the euro weakening relative to the U.S. dollar.  Foreign currency-based transactions produced a loss for the first half of 2014 of $0.1 million.

[0000038725-15-000161:mdna:108]
Income Taxes

[0000038725-15-000161:mdna:109]
The provision for income taxes in the first half of 2015 and 2014 was $2.0 million and $16.0 million, respectively.

[0000038725-15-000161:mdna:110]
The effective tax rate for the first half of 2015 was about 5 percent and, before the impact of discrete events, was about 27 percent.   Discrete adjustments during the first half of 2015 included the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer.  This first half tax benefit of about $4.8 million was treated as a non-GAAP adjustment.  Because in 2012, the gain was treated as a non-GAAP adjustment, the Company is now consistently treating the reversal of the tax liability related to that gain as a non-GAAP adjustment, reducing reported Earnings per Share in the first half of 2015 by $0.10 cents. The Company also realized a gain on the redeemable non-controlling interest liability in the first half of this year of about $2.7 million which is included in ‘Other income’.  This purchase transaction also resulted in other tax benefits of about $2.5 million, which were expensed through the Company’s earnings in prior years as well as a current period benefit of about $1.0 million related to the 2015 gain.  The effective tax rate for the first half of 2015 was about 27 percent and 28 percent for the first half of 2014 before discrete adjustments. The tax rate as a percentage of pre-tax earnings for the first half of 2014 was about 26 percent primarily due the completion of income tax audits and the favorable resolution of matters previously under review. The average effective tax rate after discrete events for the back half of 2015 is projected to be 25 percent. The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-15-000161:mdna:111]
Net Income

[0000038725-15-000161:mdna:112]
Net income for the first half of 2015 was $36.4 million compared to 2014 first half net income of $44.9 million.  Net income attributable to Franklin Electric Co., Inc. for the first half of 2015 was $36.0 million, or $0.74 per diluted share, compared to 2014 first half net income attributable to Franklin Electric Co., Inc. of $44.0 million or $0.90 per diluted share. Earnings after non-GAAP adjustments for the first half of 2015 were $32.1 million, or $0.67 per diluted share, compared to the prior year first half earnings after non-GAAP adjustments of $45.6 million or $0.95 per diluted share.

[0000038725-15-000161:mdna:113]
There were specific items in the first half  of 2015 and 2014 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-15-000161:mdna:114]
| Earnings Before and After Non-GAAP Adjustments | For the First Half |
| (in millions) | 2015 | 2014 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 36.0 |  | $ | 44.0 |  | (18 | )% |
| Allocated Undistributed Earnings | $ | (0.5 | ) | $ | (0.7 | ) |  |
| Adjusted Earnings for EPS Calculation | $ | 35.5 |  | $ | 43.3 |  | (18 | )% |
| Non-GAAP adjustments (before tax): |  |  |  |
| Restructuring | $ | 1.2 |  | $ | 0.4 |  |  |
| Non-GAAP items | $ | 1.2 |  | $ | 3.4 |  |  |
| Pioneer tax benefits on equity gain | $ | (4.8 | ) | $ | — |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 0.7 |  | $ | 0.2 |  |  |
| Non-GAAP items | $ | 0.7 |  | $ | 2.1 |  |  |
| Pioneer tax benefits on equity gain | $ | (4.8 | ) | $ | — |  |  |
| Earnings after Non-GAAP Adjustments | $ | 32.1 |  | $ | 45.6 |  | (30 | )% |

[0000038725-15-000161:mdna:115]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the First Half |
| (in millions except Earnings Per Share) | 2015 | 2014 | Change |
| Average Fully Diluted Shares Outstanding | 48.1 |  | 48.3 |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.74 |  | $ | 0.90 |  | (18 | )% |
| Restructuring Per Share, net of tax | $ | 0.02 |  | $ | — |  |  |
| Non-GAAP items | $ | 0.01 |  | $ | 0.05 |  |  |
| Pioneer tax benefits on equity gain | $ | (0.10 | ) | $ | — |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.67 |  | $ | 0.95 |  | (29 | )% |

[0000038725-15-000161:mdna:116]
[same as prior period, unchanged from 0000038725-15-000090:mdna:50]

[0000038725-15-000161:mdna:117]
[same as prior period, unchanged from 0000038725-15-000090:mdna:51]

[0000038725-15-000161:mdna:118]
[same as prior period, unchanged from 0000038725-15-000090:mdna:52]

[0000038725-15-000161:mdna:119]
On May 5, 2015, the Company executed the following amendments:  Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc.; Amendment No. 3 to the Credit Agreement; and Amendment No. 1 to the Bond Purchase and Loan Agreement. Each of those amendments provides for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-15-000161:mdna:120]
31

[0000038725-15-000161:mdna:121]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025.  These series notes have a floating interest rate with interest-only payments due on a monthly basis.  The New York Life Agreement contains customary affirmative and negative covenants and a cross default provision in the event the Company defaults on any obligation exceeding $10.0 million.  As of July 4, 2015, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-15-000161:mdna:122]
On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc. (the "Prudential Agreement") to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of July 4, 2015, $120.0 million was outstanding under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.  As of July 4, 2015, the Company had $100.0 million borrowing capacity under the Prudential Agreement.

[0000038725-15-000161:mdna:123]
In addition, the Company has a committed, unsecured, revolving credit agreement maturing on December 14, 2016 (the “Credit Agreement”) in the amount of $150.0 million. As of July 4, 2015, the Company had $142.2 million borrowing capacity under the Credit Agreement as $3.8 million in letters of commercial and standby letters of credit were outstanding and undrawn and $4.0 million of revolver borrowing was drawn and outstanding at the end of the quarter. There were no other outstanding borrowings as of July 4, 2015 on the Credit Agreement.

[0000038725-15-000161:mdna:124]
The Credit Agreement, the Prudential Agreement, the Project Bonds, and the New York Life Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Credit Agreement, the Prudential Agreement, the Project Bonds, and the NYL Shelf Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million.

[0000038725-15-000161:mdna:125]
At July 4, 2015, the Company had $63.0 million of cash on hand at various locations worldwide. Approximately 28 percent of the cash and equivalents was in the U.S. and readily accessible. Approximately 38 percent was in Europe, and the remaining 34 percent was in South America, Asia Pacific, and other locations combined. On a regular basis the Company reviews international cash balances and, if appropriate based on forecasted expenditures and considerations for the post-tax economic efficiency, will reposition cash among its global entities. Cash investments worldwide are invested according to a written policy, and are generally in bank demand accounts and bank time deposits with the preservation of principal as the highest priority.

[0000038725-15-000161:mdna:126]
Net cash provided by operating activities was $7.0 million for the six months ended July 4, 2015 compared to a use of cash of $26.2 million for the six months ended June 28, 2014.  During the first quarter of 2015, the mandatory share purchase liability of $22.9 million for PPH was settled, resulting in a non-cash gain and reversal of certain deferred tax liabilities, also non-cash, both of which were adjustments to net income. In addition, the first half of 2014 experienced higher builds of inventory and an increase in outstanding trade receivable balances compared to the first half of 2015 primarily due to higher levels of shipments and projected sales in 2014.

[0000038725-15-000161:mdna:127]
Net cash used in investing activities was $13.2 million for the six months ended July 4, 2015, compared to $55.1 million for the six months ended June 28, 2014. The primary decrease in cash used in investing activities is due to less spending for acquisitions and equity investments during the first half of 2015 compared to the first half of 2014 (the Bombas Leao acquisition was completed during the first half of 2014).  In addition, capital expenditures during the first half of 2015 were down from the first half of 2014 primarily due to the completion of a new manufacturing facility in Brazil in 2014.

[0000038725-15-000161:mdna:128]
Net cash provided by financing activities was $13.6 million for the six months ended July 4, 2015, compared to $34.6 million for the six months ended June 28, 2014. The decrease in cash provided by financing activities in the first half of 2015 was primarily due to the payment made during the first quarter for the PPH mandatory share purchase liability.

[0000038725-15-000161:mdna:129]
[same as prior period, unchanged from 0000038725-15-000090:mdna:61]

[0000038725-15-000161:mdna:130]
This quarterly report on Form 10-Q contains certain forward-looking information, such as statements about the Company’s financial goals, acquisition strategies, financial expectations including anticipated revenue or expense levels, business
