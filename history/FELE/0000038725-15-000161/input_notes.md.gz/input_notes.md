# FELE notes — 0000038725-15-000161


## fele:DisclosureOfShareBasedCompensationArrangementsAuthorizedSharesTableTextBlock

[0000038725-15-000161:notes:1]
The 2012 Stock Plan authorized 2,400,000 shares for issuance as follows:

[0000038725-15-000161:notes:2]
[same as prior period, unchanged from 0000038725-15-000090:notes:2]

[0000038725-15-000161:notes:3]
[same as prior period, unchanged from 0000038725-15-000090:notes:3]

[0000038725-15-000161:notes:4]
[same as prior period, unchanged from 0000038725-15-000090:notes:4]


## fele:ScheduleOfFiniteAndIndefiniteLivedIntangibleAssetsTableTextBlock

[0000038725-15-000161:notes:5]
[same as prior period, unchanged from 0000038725-15-000090:notes:5]

[0000038725-15-000161:notes:6]
| (In millions) |  | July 4, 2015 |  | January 3, 2015 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.1 | ) |  | $ | 7.6 |  |  | $ | (6.1 | ) |
| Supply agreements |  | 4.4 |  |  | (4.4 | ) |  | 4.4 |  |  | (4.4 | ) |
| Technology |  | 7.5 |  |  | (4.6 | ) |  | 7.5 |  |  | (4.3 | ) |
| Customer relationships |  | 137.5 |  |  | (39.5 | ) |  | 140.2 |  |  | (36.5 | ) |
| Software |  | 2.6 |  |  | (1.7 | ) |  | 2.9 |  |  | (1.7 | ) |
| Other |  | 1.0 |  |  | (1.0 | ) |  | 1.2 |  |  | (1.2 | ) |
| Total |  | $ | 160.5 |  |  | $ | (57.3 | ) |  | $ | 163.8 |  |  | $ | (54.2 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 48.8 |  |  | — |  |  | 50.7 |  |  | — |  |
| Total intangibles |  | $ | 209.3 |  |  | $ | (57.3 | ) |  | $ | 214.5 |  |  | $ | (54.2 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-15-000161:notes:7]
[same as prior period, unchanged from 0000038725-15-000090:notes:7]

[0000038725-15-000161:notes:8]
In 2012, the Company acquired a controlling interest in Pioneer Pump Holdings, Inc. ("PPH").  Pursuant to the terms of the 2012 stock purchase agreement, the remaining 29.5 percent noncontrolling interest was recorded at $22.9 million and accounted for as a share purchase liability.  During the first quarter of 2015, the Company purchased the remaining 29.5 percent of outstanding shares of PPH for $20.2 million, increasing the Company's ownership in PPH to 100 percent.  The purchase was considered the settlement of a financing obligation, and the resulting $2.7 million gain was recorded in the Company's condensed consolidated statements of income in the "Other income, net" line during the first quarter of 2015.

[0000038725-15-000161:notes:9]
In an agreement dated June 6, 2014, the Company acquired all of the outstanding shares of Bombas Leao S.A. ("Bombas Leao").

[0000038725-15-000161:notes:10]
Goodwill increased by $0.3 million and current assets decreased by $0.3 million in the second quarter ended July 4, 2015, due to working capital adjustments.  In addition, the Company paid an additional $0.3 million to the sellers of Bombas Leao during the second quarter ended July 4, 2015 to satisfy amounts previously accrued per the original purchase agreement.  The final purchase price assigned to the major identifiable assets and liabilities for the Bombas Leao acquisition is as follows:

[0000038725-15-000161:notes:11]
| (In millions) |  |  |
| Assets: |  |  |
| Cash acquired |  | $ | 1.1 |  |
| Current assets |  | 13.4 |  |
| Property, plant, and equipment |  | 6.5 |  |
| Intangible assets |  | 23.5 |  |
| Goodwill |  | 3.4 |  |
| Other assets |  | 3.1 |  |
| Total assets |  | 51.0 |  |
| Liabilities |  | (20.0 | ) |
| Total consideration paid |  | $ | 31.0 |  |

[0000038725-15-000161:notes:12]
The fair values of the identifiable assets, property, plant, and equipment, and liabilities are final as of the second quarter ended July 4, 2015.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation.

[0000038725-15-000161:notes:13]
Transaction costs for all acquisition related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations.  Transaction costs included in selling, general, and administrative expenses in the Company’s condensed consolidated statements of income were $0.2 million and $0.9 million for the six months ended July 4, 2015 and June 28, 2014, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000038725-15-000161:notes:14]
In August 2010, the California Air Resources Board (“CARB”) and South Coast Air Quality Management District (“SCAQMD”) filed civil complaints in the Los Angeles Superior Court against the Company and Franklin Fueling Systems, Inc.  The complaints related to a third-party-supplied component part of the Company's Healy 900 Series nozzle, which is part of the Company's Enhanced Vapor Recovery (“EVR”) Systems installed in California gasoline filling stations.  This part, a diaphragm, was the subject of a retrofit during the first half of 2008.  As the Company previously reported, in October 2008 CARB issued a Notice of Violation to the Company alleging that the circumstances leading to the retrofit program violated California statutes and regulations.

[0000038725-15-000161:notes:15]
The claims in the complaints mirrored those that CARB presented to the Company in the Notice of Violation, and included claims that the Company negligently and intentionally sold nozzles with a modified diaphragm without required CARB certification. Those complaints were consolidated into one case in the Superior Court of California, County of Los Angeles (People of the State of California vs. Franklin Fueling Systems, Inc. et al.) which was tried in the later part of December 2012 and early part of January 2013 (“CARB Case”).

[0000038725-15-000161:notes:16]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company filed its response brief on December 23, 2014 and CARB filed its reply brief on February 2, 2015.  On July 29, 2015, the Court of Appeals issued a Calendar Notice for oral argument scheduled for August 25, 2015.  Both the Company and CARB have ten days to either confirm or waive the oral argument.

[0000038725-15-000161:notes:17]
Neither of these suits has had any effect on CARB's certification of the Company's EVR System or any other products of the Company or its subsidiaries, and did not interfere with continuing sales.  CARB has never decertified the Company's EVR System and has never proposed to do so.

[0000038725-15-000161:notes:18]
The Company is defending various other claims and legal actions, including environmental matters, which have arisen in the

[0000038725-15-000161:notes:19]
ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with

[0000038725-15-000161:notes:20]
counsel, these claims and legal actions can be successfully defended or resolved without a material adverse effect on the

[0000038725-15-000161:notes:21]
Company’s financial position, results of operations, and net cash flows.

[0000038725-15-000161:notes:22]
At July 4, 2015, the Company had $11.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-15-000161:notes:23]
The Company provides warranties on most of its products.  The warranty terms vary but are generally 2 years from date of manufacture or 1 year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to 5 years from date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-15-000161:notes:24]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended July 4, 2015, are as follows:

[0000038725-15-000161:notes:25]
| (In millions) |  |  |
| Balance as of January 3, 2015 |  | $ | 9.4 |  |
| Accruals related to product warranties |  | 3.7 |  |
| Reductions for payments made |  | (3.8 | ) |
| Balance as of July 4, 2015 |  | $ | 9.3 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-15-000161:notes:26]
[same as prior period, unchanged from 0000038725-15-000090:notes:22]

[0000038725-15-000161:notes:27]
Changes in accumulated other comprehensive income/(loss) by component for the six months ended July 4, 2015 and June 28, 2014, are summarized below:

[0000038725-15-000161:notes:28]
| (In millions) |  |  |  |  |  |
| For the six months ended July 4, 2015: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance as of January 3, 2015 | $ | (51.8 | ) |  | $ | (56.1 | ) |  | $ | (107.9 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (28.2 | ) |  | — |  |  | (28.2 | ) |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (28.2 | ) |  | — |  |  | (28.2 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 2.0 |  | (1) | 2.0 |  |
| Income tax expense | — |  |  | (0.7 | ) |  | (0.7 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 1.3 |  |  | 1.3 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (28.2 | ) |  | 1.3 |  |  | (26.9 | ) |
| Other comprehensive income/(loss) attributable to noncontrolling interest | (0.4 | ) |  | — |  |  | (0.4 | ) |
| Balance as of July 4, 2015 | $ | (79.6 | ) |  | $ | (54.8 | ) |  | $ | (134.4 | ) |
| For the six months ended June 28, 2014: |  |  |  |  |  |
| Balance as of December 28, 2013 | $ | (16.0 | ) |  | $ | (38.7 | ) |  | $ | (54.7 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | 4.7 |  |  | — |  |  | 4.7 |  |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | 4.7 |  |  | — |  |  | 4.7 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 1.5 |  | (1) | 1.5 |  |
| Income tax expense | — |  |  | (0.5 | ) |  | (0.5 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 1.0 |  |  | 1.0 |  |
| Net current period other comprehensive income/(loss), net of income taxes | 4.7 |  |  | 1.0 |  |  | 5.7 |  |
| Other comprehensive income/(loss) attributable to noncontrolling interest | 0.1 |  |  | — |  |  | 0.1 |  |
| Balance as of June 28, 2014 | $ | (11.4 | ) |  | $ | (37.7 | ) |  | $ | (49.1 | ) |

[0000038725-15-000161:notes:29]
[same as prior period, unchanged from 0000038725-15-000090:notes:25]


## us-gaap:DebtDisclosureTextBlock

[0000038725-15-000161:notes:30]
DEBT

[0000038725-15-000161:notes:31]
Debt consisted of the following:

[0000038725-15-000161:notes:32]
| (In millions) |  | July 4, 2015 |  | January 3, 2015 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.2 |  |  | 23.7 |  |
| New York Life |  | 75.0 |  |  | — |  |
| Revolver |  | 4.0 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 3.0 |  |  | 3.5 |  |
|  |  | $ | 225.3 |  |  | 177.8 |  |
| Less current maturities |  | (37.5 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 187.8 |  |  | $ | 143.7 |  |

[0000038725-15-000161:notes:33]
On May 5, 2015, the Company executed the following amendments: Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc.; Amendment No. 3 to the Credit Agreement; and Amendment No. 1 to the Bond Purchase and Loan Agreement.  Each of those amendments provides for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-15-000161:notes:34]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025.  These series notes have a floating interest rate with interest-only payments due on a monthly basis.  The New York Life Agreement contains customary affirmative and negative covenants and a cross default provision in the event the Company defaults on any obligation exceeding $10.0 million.  As of July 4, 2015, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-15-000161:notes:35]
On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc. (the "Prudential Agreement") to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of July 4, 2015, $120.0 million was outstanding under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.  As of July 4, 2015, the Company had $100.0 million borrowing capacity under the Prudential Agreement.

[0000038725-15-000161:notes:36]
The following debt payments are expected to be paid in accordance with the following schedule:

[0000038725-15-000161:notes:37]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 225.2 |  |  | $ | 37.4 |  |  | $ | 31.5 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 1.1 |  |  | $ | 93.2 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 225.3 |  |  | $ | 37.5 |  |  | $ | 31.5 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 1.1 |  |  | $ | 93.2 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-15-000161:notes:38]
[same as prior period, unchanged from 0000038725-15-000090:notes:33]

[0000038725-15-000161:notes:39]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  During February 2014, the Company entered into a share swap transaction agreement ("the swap") to mitigate the Company’s exposure to these fluctuations in the Company's stock price.  The Company renewed the swap agreement in February 2015. The swap was not designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  As of July 4, 2015, the swap has a notional value based on 175,000 shares.  For the second quarter and six months ended July 4, 2015, the swap resulted in losses of $0.9 million and $1.0 million, respectively.  For the second quarter and six months ended June 28, 2014, the swap resulted in losses of $0.1 million and $0.3 million, respectively.  Losses resulting from the swap were primarily offset by gains on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-15-000161:notes:40]
[same as prior period, unchanged from 0000038725-15-000090:notes:35]

[0000038725-15-000161:notes:41]
[same as prior period, unchanged from 0000038725-15-000090:notes:36]

[0000038725-15-000161:notes:42]
[same as prior period, unchanged from 0000038725-15-000090:notes:37]

[0000038725-15-000161:notes:43]
[same as prior period, unchanged from 0000038725-15-000090:notes:38]

[0000038725-15-000161:notes:44]
[same as prior period, unchanged from 0000038725-15-000090:notes:39]

[0000038725-15-000161:notes:45]
[same as prior period, unchanged from 0000038725-15-000090:notes:40]

[0000038725-15-000161:notes:46]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the six months ended July 4, 2015 and June 28, 2014, are as follows:

[0000038725-15-000161:notes:47]
|  |  | July 4, 2015 |  | June 28, 2014 |
| Risk-free interest rate |  | 1.59 | % |  | 1.68 | % |
| Dividend yield |  | 0.95 | % |  | 0.70 | % |
| Volatility factor |  | 0.379 |  |  | 0.387 |  |
| Expected term |  | 5.5 years |  |  | 5.6 years |  |
| Forfeiture rate |  | 3.67 | % |  | 3.81 | % |

[0000038725-15-000161:notes:48]
There were no stock options granted during the second quarter ended July 4, 2015.  There were 22,050 stock options granted during the second quarter ended June 28, 2014.

[0000038725-15-000161:notes:49]
A summary of the Company’s outstanding stock option activity and related information for the six months ended July 4, 2015 and June 28, 2014 is as follows:

[0000038725-15-000161:notes:50]
| (Shares in thousands) |  | July 4, 2015 |  | June 28, 2014 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,397 |  |  | $ | 21.17 |  |  | 1,476 |  |  | $ | 19.01 |  |
| Granted |  | 185 |  |  | 36.67 |  |  | 115 |  |  | 42.24 |  |
| Exercised |  | (70 | ) |  | 17.63 |  |  | (63 | ) |  | 18.89 |  |
| Forfeited |  | (2 | ) |  | 34.93 |  |  | (3 | ) |  | 26.95 |  |
| Expired |  | — |  |  | — |  |  | (16 | ) |  | 16.34 |  |
| Outstanding at end of period |  | 1,510 |  |  | $ | 23.22 |  |  | 1,509 |  |  | $ | 20.80 |  |
| Expected to vest after applying forfeiture rate |  | 1,488 |  |  | $ | 23.02 |  |  | 1,491 |  |  | $ | 20.63 |  |
| Vested and exercisable at end of period |  | 1,144 |  |  | $ | 19.13 |  |  | 1,194 |  |  | $ | 17.62 |  |

[0000038725-15-000161:notes:51]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of July 4, 2015 is as follows:

[0000038725-15-000161:notes:52]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.19 years |  | $ | 15,597 |  |
| Expected to vest after applying forfeiture rate |  | 5.13 years |  | $ | 15,588 |  |
| Vested and exercisable at end of period |  | 4.03 years |  | $ | 15,291 |  |

[0000038725-15-000161:notes:53]
The total intrinsic value of options exercised during the six months ended July 4, 2015 and June 28, 2014, was $1.3 million and $1.4 million, respectively.

[0000038725-15-000161:notes:54]
As of July 4, 2015, there was $2.2 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements related to stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.87 years.

[0000038725-15-000161:notes:55]
[same as prior period, unchanged from 0000038725-15-000090:notes:50]

[0000038725-15-000161:notes:56]
A summary of the Company’s restricted stock/stock unit award activity and related information for the six months ended July 4, 2015 and June 28, 2014 is as follows:

[0000038725-15-000161:notes:57]
| (Shares in thousands) |  | July 4, 2015 |  | June 28, 2014 |
| Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 554 |  |  | $ | 32.72 |  |  | 551 |  |  | $ | 24.75 |  |
| Awarded |  | 132 |  |  | 36.37 |  |  | 193 |  |  | 42.81 |  |
| Vested |  | (167 | ) |  | 30.52 |  |  | (124 | ) |  | 16.75 |  |
| Forfeited |  | (9 | ) |  | 32.31 |  |  | (59 | ) |  | 28.04 |  |
| Non-vested at end of period |  | 510 |  |  | $ | 34.40 |  |  | $ | 561 |  |  | $ | 32.38 |  |

[0000038725-15-000161:notes:58]
As of July 4, 2015, there was $10.1 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements related to stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.57 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-15-000161:notes:59]
[same as prior period, unchanged from 0000038725-15-000090:notes:54]

[0000038725-15-000161:notes:60]
[same as prior period, unchanged from 0000038725-15-000090:notes:55]

[0000038725-15-000161:notes:61]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-15-000161:notes:62]
[same as prior period, unchanged from 0000038725-15-000090:notes:57]

[0000038725-15-000161:notes:63]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions, except per share amounts) | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 16.2 |  |  | $ | 27.1 |  |  | $ | 36.0 |  |  | $ | 44.0 |  |
| Less: Undistributed earnings allocated to participating securities | 0.1 |  |  | 0.3 |  |  | 0.3 |  |  | 0.5 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | 0.1 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
|  | $ | 16.0 |  |  | $ | 26.6 |  |  | $ | 35.5 |  |  | $ | 43.3 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  |  |  |  |  |
| Weighted average common shares | 47.6 |  |  | 47.6 |  |  | 47.6 |  |  | 47.7 |  |
| Diluted |  |  |  |  |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee incentive stock options and performance awards | 0.5 |  |  | 0.6 |  |  | 0.5 |  |  | 0.6 |  |
| Adjusted weighted average common shares | 48.1 |  |  | 48.2 |  |  | 48.1 |  |  | 48.3 |  |
| Basic earnings per share | $ | 0.33 |  |  | $ | 0.56 |  |  | $ | 0.74 |  |  | $ | 0.91 |  |
| Diluted earnings per share | $ | 0.33 |  |  | $ | 0.55 |  |  | $ | 0.74 |  |  | $ | 0.90 |  |
| Anti-dilutive stock options | 0.3 |  |  | 0.1 |  |  | 0.3 |  |  | 0.1 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-15-000161:notes:64]
As of July 4, 2015 and January 3, 2015, the assets measured at fair value on a recurring basis were as set forth in the table below.

[0000038725-15-000161:notes:65]
| (In millions) | July 4, 2015 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 1.6 |  | $ | 1.6 |  | $ | — |  | $ | — |  |
|  | January 3, 2015 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 5.4 |  | $ | 5.4 |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-15-000161:notes:66]
[same as prior period, unchanged from 0000038725-15-000090:notes:61]

[0000038725-15-000161:notes:67]
[same as prior period, unchanged from 0000038725-15-000090:notes:62]

[0000038725-15-000161:notes:68]
[same as prior period, unchanged from 0000038725-15-000090:notes:63]

[0000038725-15-000161:notes:69]
[same as prior period, unchanged from 0000038725-15-000090:notes:64]

[0000038725-15-000161:notes:70]
[same as prior period, unchanged from 0000038725-15-000090:notes:65]

[0000038725-15-000161:notes:71]
[same as prior period, unchanged from 0000038725-15-000090:notes:66]

[0000038725-15-000161:notes:72]
Total debt, including current maturities, have carrying amounts of $225.2 million and $177.2 million and estimated fair values of $232.2 million and $191.1 million as of July 4, 2015 and January 3, 2015, respectively.  The fair value assumed short-term floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.

[0000038725-15-000161:notes:73]
As of July 4, 2015, the Company had $2.1 million of assets held for sale recorded at carrying value in the Water Systems segment relating to a facility in Brazil.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-15-000161:notes:74]
[same as prior period, unchanged from 0000038725-15-000090:notes:69]

[0000038725-15-000161:notes:75]
Changes in carrying values for intangible assets are primarily attributed to the impact of foreign exchange for the six months ended July 4, 2015.

[0000038725-15-000161:notes:76]
Amortization expense related to intangible assets for the second quarters ended July 4, 2015 and June 28, 2014 was $2.2 million and $2.1 million, respectively, and $4.4 million and $4.1 million for the six months ended July 4, 2015 and June 28, 2014, respectively.

[0000038725-15-000161:notes:77]
[same as prior period, unchanged from 0000038725-15-000090:notes:72]

[0000038725-15-000161:notes:78]
| (In millions) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |
|  |  | $ | 8.7 |  |  | $ | 8.7 |  |  | $ | 8.6 |  |  | $ | 8.6 |  |  | $ | 8.5 |  |

[0000038725-15-000161:notes:79]
The change in the carrying amount of goodwill by reporting segment for the six months ended July 4, 2015, is as follows:

[0000038725-15-000161:notes:80]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of January 3, 2015 |  | $ | 145.3 |  |  | $ | 63.5 |  |  | $ | 208.8 |  |
| Adjustments to prior year acquisitions |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Foreign currency translation |  | (4.2 | ) |  | (0.1 | ) |  | (4.3 | ) |
| Balance as of July 4, 2015 |  | $ | 141.4 |  |  | $ | 63.4 |  |  | $ | 204.8 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-15-000161:notes:81]
[same as prior period, unchanged from 0000038725-15-000090:notes:76]

[0000038725-15-000161:notes:82]
The effective tax rate continues to be lower than the U.S. statutory rate of 35.0 percent primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate as well as recognition of foreign tax credits.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations as well as cash on hand and available credit.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000038725-15-000161:notes:83]
[same as prior period, unchanged from 0000038725-15-000090:notes:78]

[0000038725-15-000161:notes:84]
[same as prior period, unchanged from 0000038725-15-000090:notes:79]

[0000038725-15-000161:notes:85]
The Company uses the interest method to accrete changes in the anticipated redemption value of the Impo redeemable noncontrolling interest over an amortization period to the earliest projected redemption date.  Accretion adjustments were $0.1 million and $0.2 million for the second quarter and six months ended July 4, 2015, respectively, and $0.2 million for the second quarter and six months ended June 28, 2014.  These adjustments were reflected in the computation of earnings per share using the two-class method.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-15-000161:notes:86]
ACCOUNTING PRONOUNCEMENTS

[0000038725-15-000161:notes:87]
Adoption of New Accounting Standards

[0000038725-15-000161:notes:88]
In February 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2015-02, Consolidation (Topic 810), Amendments to the Consolidation Analysis.  The amendments affect both the variable interest entity and voting interest entity consolidation models.  The need to assess an entity under a different consolidation model may change previous consolidation conclusions.  The standard is effective for both interim and annual reporting periods beginning after December 15, 2015 and early adoption is permitted.  The Company has adopted this standard with no impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-15-000161:notes:89]
Accounting Standards Issued But Not Yet Adopted

[0000038725-15-000161:notes:90]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (Topic 330).  The ASU will change the measurement principle for inventory from the "lower of cost or market" to the "lower of cost and net realizable value."  Net realizable value is defined as the “estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation.” ASU 2015-11 eliminates the guidance that entities consider replacement cost or net realizable value less an approximately normal profit margin in the subsequent measurement of inventory when cost is determined on a first-in, first-out or average cost basis.  The ASU will be effective for interim and annual periods beginning after December 15, 2016 and early adoption is permitted.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, and related disclosures.

[0000038725-15-000161:notes:91]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other Internal-Use Software (Subtopic 350-40): Customer's Accounting for Fees Paid in a Cloud Computing Agreement.  The ASU will require an entity's management to assess, for each annual and interim period, whether a cloud computing arrangement includes a software license.  All software licenses within the scope of Subtopic 350-40 will be accounted for consistent with other licenses of intangible assets.  If the arrangement does not include a software license, the arrangement should be accounted for as a service contract.  The ASU will be effective for interim and annual periods beginning after December 15, 2015 and early adoption is permitted.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, and related disclosures.

[0000038725-15-000161:notes:92]
In April 2015, the FASB issued ASU 2015-04, Retirement Benefits (Topic 715): Practical Expedient for the Measurement Date of an Employer's Defined Benefit Obligation and Plan Assets, which allows an entity a practical expedient to measure defined benefit plan assets and obligations using the month end date that is closest to the entity's fiscal year end and apply that practical expedient consistently from year to year.  The practical expedient should be applied consistently to all plans if the entity has more than one plan.  The ASU will be effective on a prospective basis for interim and annual periods beginning after December 15, 2015 and early adoption is permitted.  The Company does not expect the adoption of this standard to have a material impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.

[0000038725-15-000161:notes:93]
In April 2015, the FASB issued ASU 2015-03, Simplifying the Presentation of Debt Issuance Costs, which requires debt issuance costs to be presented in the balance sheet as a direct deduction from the associated debt liability.  The standard will not change the amortization of debt issuance costs, which will continue to follow the existing accounting guidance.  The ASU will be effective for interim and annual periods beginning after December 15, 2015 and early adoption is permitted.  The Company does not expect the adoption of this standard to have a material impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.

[0000038725-15-000161:notes:94]
In May 2014, the FASB issued ASU 2014-09 Revenue from Contracts with Customers.  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  The ASU was originally effective for annual reporting periods beginning after December 15, 2016 and early adoption was not permitted.  In July 2015, the FASB approved a one-year deferral on the effective date of this ASU, which will now be effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt the new ASU.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-15-000161:notes:95]
[same as prior period, unchanged from 0000038725-15-000090:notes:87]

[0000038725-15-000161:notes:96]
The accompanying condensed consolidated balance sheet as of January 3, 2015, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of July 4, 2015, and for the second quarters and six months ended July 4, 2015 and June 28, 2014, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the second quarter and six months ended July 4, 2015, are not necessarily indicative of the results that may be expected for the fiscal year ending January 2, 2016.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K for the year ended January 3, 2015.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000038725-15-000161:notes:97]
[same as prior period, unchanged from 0000038725-15-000090:notes:89]

[0000038725-15-000161:notes:98]
The Company has equity interests in various companies for various strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s condensed consolidated balance sheet.  The carrying amount of the investments is adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income, net" line of the Company's condensed consolidated statements of income, were immaterial for the second quarter and six months ended July 4, 2015.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-15-000161:notes:99]
[same as prior period, unchanged from 0000038725-15-000090:notes:91]

[0000038725-15-000161:notes:100]
Defined Benefit Plans - As of July 4, 2015, the Company maintained two domestic pension plans and three German pension plans.  The Company used a January 3, 2015 measurement date for these plans.  One of the Company's domestic pension plans covers two management employees, while the other domestic plan covers all other eligible employees.  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-15-000161:notes:101]
[same as prior period, unchanged from 0000038725-15-000090:notes:93]

[0000038725-15-000161:notes:102]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the second quarters and six months ended July 4, 2015 and June 28, 2014, respectively:

[0000038725-15-000161:notes:103]
| (In millions) | Pension Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Service cost | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.6 |  |  | $ | 0.7 |  |
| Interest cost | 1.8 |  |  | 2.1 |  |  | 3.6 |  |  | 4.1 |  |
| Expected return on assets | (2.5 | ) |  | (2.6 | ) |  | (5.0 | ) |  | (5.2 | ) |
| Amortization of prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of loss | 0.8 |  |  | 0.6 |  |  | 1.6 |  |  | 1.2 |  |
| Net periodic benefit cost | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | 0.8 |  |  | $ | 0.8 |  |
| Settlement cost | 0.3 |  |  | 0.2 |  |  | 0.6 |  |  | 0.4 |  |
| Total net periodic benefit cost | $ | 0.7 |  |  | $ | 0.7 |  |  | $ | 1.4 |  |  | $ | 1.2 |  |

[0000038725-15-000161:notes:104]
In the six months ended July 4, 2015, the Company made contributions of $1.3 million to the funded plans.  The amount of contributions to be made to the plans during the calendar year 2015 will be finalized by September 15, 2015, based upon the plan's year-end valuation at January 3, 2015, and the funding level required for the plan year ended January 3, 2015.

[0000038725-15-000161:notes:105]
The following table sets forth the aggregated net periodic benefit cost for the postretirement benefit plan for the second quarters and six months ended July 4, 2015 and June 28, 2014, respectively:

[0000038725-15-000161:notes:106]
|  | Other Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
| Service cost | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.1 |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Amortization of loss | 0.1 |  |  | — |  |  | 0.2 |  |  | — |  |
| Net periodic benefit cost | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.6 |  |  | $ | 0.5 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.6 |  |  | $ | 0.5 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-15-000161:notes:107]
[same as prior period, unchanged from 0000038725-15-000090:notes:97]

[0000038725-15-000161:notes:108]
[same as prior period, unchanged from 0000038725-15-000090:notes:98]

[0000038725-15-000161:notes:109]
Costs incurred in the second quarter and six months ended July 4, 2015, included in the “Restructuring expense” line of the Company's condensed consolidated statements of income, are as follows:

[0000038725-15-000161:notes:110]
|  |  | Second Quarter Ended |
|  |  | July 4, 2015 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 0.3 |  |
| Equipment relocation |  | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |
| Other |  | 0.3 |  |  | — |  |  | — |  |  | 0.3 |  |
| Total |  | $ | 0.6 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 0.8 |  |
|  |  | Six Months Ended |
|  |  | July 4, 2015 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.1 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | 0.4 |  |
| Equipment relocation |  | 0.3 |  |  | — |  |  | — |  |  | 0.3 |  |
| Other |  | 0.5 |  |  | — |  |  | — |  |  | 0.5 |  |
| Total |  | $ | 0.9 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | 1.2 |  |

[0000038725-15-000161:notes:111]
Restructuring expenses for the second quarter and six months ended June 28, 2014 were approximately $0.3 million and $0.4 million, respectively, primarily relating to severance.

[0000038725-15-000161:notes:112]
As of July 4, 2015, there were $4.3 million of restructuring reserves.  As of June 28, 2014, there were no restructuring reserves.  The restructuring reserves were primarily for severance.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-15-000161:notes:113]
[same as prior period, unchanged from 0000038725-15-000090:notes:103]

[0000038725-15-000161:notes:114]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions) | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
|  | Net sales to external customers |
| Water Systems | $ | 191.6 |  |  | $ | 226.7 |  |  | $ | 370.9 |  |  | $ | 411.3 |  |
| Fueling Systems | 55.8 |  |  | 57.8 |  |  | 102.3 |  |  | 104.6 |  |
| Other | — |  |  | — |  |  | $ | — |  |  | $ | — |  |
| Consolidated | $ | 247.4 |  |  | $ | 284.5 |  |  | $ | 473.2 |  |  | $ | 515.9 |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | July 4, 2015 |  | June 28, 2014 |  | July 4, 2015 |  | June 28, 2014 |
|  | Operating income (loss) |
| Water Systems | $ | 24.3 |  |  | $ | 41.7 |  |  | $ | 43.7 |  |  | $ | 71.0 |  |
| Fueling Systems | 12.4 |  |  | 13.5 |  |  | 22.0 |  |  | 22.5 |  |
| Other | (13.5 | ) |  | (16.1 | ) |  | (26.7 | ) |  | (28.4 | ) |
| Consolidated | $ | 23.2 |  |  | $ | 39.1 |  |  | $ | 39.0 |  |  | $ | 65.1 |  |
|  | July 4, 2015 |  | January 3, 2015 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 754.0 |  |  | $ | 757.5 |  |  |  |  |  |
| Fueling Systems | 250.2 |  |  | 252.7 |  |  |  |  |  |
| Other | 65.7 |  |  | 65.7 |  |  |  |  |  |
| Consolidated | $ | 1,069.9 |  |  | $ | 1,075.9 |  |  |  |  |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-15-000161:notes:115]
The schedule below sets forth equity changes in the six months ended July 4, 2015:

[0000038725-15-000161:notes:116]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of January 3, 2015 | $ | 4,759 |  |  | $ | 207,446 |  |  | $ | 492,548 |  |  | $ | (56,124 | ) |  | $ | (51,789 | ) |  | $ | 2,143 |  |  | $ | 598,983 |  |  | $ | 6,420 |  |
| Net income |  |  |  |  | 35,959 |  |  |  |  |  |  | 348 |  |  | 36,307 |  |  | 107 |  |
| Adjustment to Impo redemption value |  |  |  |  | (157 | ) |  |  |  |  |  |  |  | (157 | ) |  | 157 |  |
| Dividends on common stock |  |  |  |  | (8,960 | ) |  |  |  |  |  |  |  | (8,960 | ) |  |  |
| Common stock issued | 7 |  |  | 1,233 |  |  |  |  |  |  |  |  |  |  | 1,240 |  |  |  |
| Common stock repurchased | (18 | ) |  |  |  | (6,200 | ) |  |  |  |  |  |  |  | (6,218 | ) |  |  |
| Share-based compensation | 15 |  |  | 3,442 |  |  |  |  |  |  |  |  |  |  | 3,457 |  |  |  |
| Tax benefit of stock options exercised |  |  | 686 |  |  |  |  |  |  |  |  |  |  | 686 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (823 | ) |  | (823 | ) |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (27,794 | ) |  | (118 | ) |  | (27,912 | ) |  | (283 | ) |
| Pension liability, net of tax |  |  |  |  |  |  | 1,308 |  |  |  |  |  |  | 1,308 |  |  |  |
| Balance as of July 4, 2015 | $ | 4,763 |  |  | $ | 212,807 |  |  | $ | 513,190 |  |  | $ | (54,816 | ) |  | $ | (79,583 | ) |  | $ | 1,550 |  |  | $ | 597,911 |  |  | $ | 6,401 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-15-000161:notes:117]
[same as prior period, unchanged from 0000038725-15-000090:notes:107]

[0000038725-15-000161:notes:118]
Property, plant, and equipment is the major asset group in "Other" of total assets as of July 4, 2015 and January 3, 2015.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-15-000161:notes:119]
[same as prior period, unchanged from 0000038725-15-000090:notes:109]
