# FELE MD&A — 0000038725-19-000185


## mdna

[0000038725-19-000185:mdna:1]
[same as prior period, unchanged from 0000038725-19-000118:mdna:1]

[0000038725-19-000185:mdna:2]
Second Quarter 2019 vs. Second Quarter 2018

[0000038725-19-000185:mdna:3]
[same as prior period, unchanged from 0000038725-19-000118:mdna:3]

[0000038725-19-000185:mdna:4]
Sales in the second quarter of 2019 increased about 3 percent from the second quarter last year.  The sales increase was led by acquisition related sales, as well as sales increases from price partially offset by lower volume. The impact of foreign currency translation on sales was unfavorable by about 3 percent. The Company's consolidated gross profit was $119.7 million for the second quarter of 2019, an increase of $3.6 million or about 3 percent from the prior year’s second quarter. Diluted earnings per share in the second quarter of 2019 were higher by 9 percent to the same period last year.

[0000038725-19-000185:mdna:5]
[same as prior period, unchanged from 0000038725-19-000118:mdna:5]

[0000038725-19-000185:mdna:6]
[same as prior period, unchanged from 0000038725-19-000118:mdna:6]

[0000038725-19-000185:mdna:7]
Net sales in the second quarter of 2019 were $355.3 million, an increase of $11.3 million or about 3 percent compared to 2018 second quarter sales of $344.0 million.  Acquisition related sales were $12.0 million. Sales revenue decreased by $10.3 million or about 3 percent in the second quarter of 2019 due to foreign currency translation. Organic sales increased about 3 percent compared to the second quarter of 2018.

[0000038725-19-000185:mdna:8]
|  | Net Sales |
| (In millions) | Q2 2019 |  | Q2 2018 |  | 2019 v 2018 |
| Water Systems | $ | 205.0 |  |  | $ | 211.4 |  |  | $ | (6.4 | ) |
| Fueling Systems | 78.0 |  |  | 73.1 |  |  | $ | 4.9 |  |
| Distribution | 87.1 |  |  | 79.5 |  |  | $ | 7.6 |  |
| Eliminations/Other | (14.8 | ) |  | (20.0 | ) |  | $ | 5.2 |  |
| Consolidated | $ | 355.3 |  |  | $ | 344.0 |  |  | $ | 11.3 |  |

[0000038725-19-000185:mdna:9]
[same as prior period, unchanged from 0000038725-19-000118:mdna:9]

[0000038725-19-000185:mdna:10]
Water Systems sales were $205.0 million in the second quarter 2019, a decrease of $6.4 million or about 3 percent versus the second quarter 2018 sales of $211.4 million. Acquisition related sales were $3.3 million. Water Systems sales were reduced by $8.7 million or about 4 percent in the quarter due to foreign currency translation. Excluding acquisitions and foreign currency translation, Water Systems sales were down $1.0 million or less than 1 percent compared to the second quarter 2018.

[0000038725-19-000185:mdna:11]
Water Systems sales in the U.S. and Canada were flat compared to the second quarter 2018. The impact of foreign currency translation decreased sales by about 1 percent. Sales of surface pumping equipment increased by 9 percent on the strength of higher sales of both wastewater and dewatering equipment. Sales of groundwater pumping equipment declined 12 percent versus the second quarter 2018.  The decline in groundwater pumping systems was primarily due to adverse weather conditions in North America and reduced sales to the Company’s Headwater Distribution segment.

[0000038725-19-000185:mdna:12]
Water Systems sales in markets outside the U.S. and Canada declined by 6 percent overall. The impact of foreign currency translation decreased sales by about 8 percent. Excluding the impact of foreign currency translation, Water Systems sales in markets outside the U.S. and Canada declined organically by about 2 percent. International Water Systems sales declined primarily from lower sales in Latin America markets outside of Brazil.  In EMEA, sales declined primarily due to foreign currency translation.

[0000038725-19-000185:mdna:13]
[same as prior period, unchanged from 0000038725-19-000118:mdna:13]

[0000038725-19-000185:mdna:14]
Fueling Systems sales were $78.0 million in the second quarter 2019, an increase of $4.9 million or about 7 percent versus the second quarter 2018 sales of $73.1 million. Acquisition related sales were $1.7 million.  Fueling Systems sales decreased by $1.6 million or about 2 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased about 7 percent compared to the second quarter of 2018.

[0000038725-19-000185:mdna:15]
Fueling Systems sales in the U.S. and Canada increased by 15 percent compared to the second quarter 2018.  The increase was principally in the fuel pumping systems, underground piping and containment systems and service station hardware product lines.  Outside the U.S. and Canada, Fueling Systems revenues declined by 2 percent, due to lower sales in Europe and Africa partially offset by higher sales in China and other regions.

[0000038725-19-000185:mdna:16]
[same as prior period, unchanged from 0000038725-19-000118:mdna:17]

[0000038725-19-000185:mdna:17]
Distribution sales were $87.1 million in the second quarter 2019, versus second quarter 2018 sales of $79.5 million. In the second quarter of 2019, sales from businesses acquired since the second quarter of 2018 were $7.0 million. The Distribution segment organic sales increased about 1 percent compared to the second quarter of 2018.

[0000038725-19-000185:mdna:18]
[same as prior period, unchanged from 0000038725-19-000118:mdna:19]

[0000038725-19-000185:mdna:19]
Cost of sales as a percent of net sales for both the second quarter of 2019 and 2018 was 66.3 percent. Correspondingly, the gross profit margin was unchanged for both second quarters at 33.7 percent. The Company's consolidated gross profit was $119.7 million for the second quarter of 2019, up $3.6 million from the gross profit of $116.1 million in the second quarter of 2018. The gross profit increase was primarily due to higher sales. In the second quarter, realized selling price increases offset inflation.

[0000038725-19-000185:mdna:20]
[same as prior period, unchanged from 0000038725-19-000118:mdna:21]

[0000038725-19-000185:mdna:21]
Selling, general, and administrative (SG&A) expenses were $75.8 million in the second quarter of 2019 compared to $75.0 million in the second quarter of 2018. SG&A expenses from acquired businesses was $2.8 million and excluding the acquired entities, the Company’s SG&A expenses in the second quarter of 2019 were $73.0 million, a decrease of 3 percent from the second quarter 2018, partially due to the effect of foreign currency translation in the second quarter of 2019 versus the prior year.

[0000038725-19-000185:mdna:22]
[same as prior period, unchanged from 0000038725-19-000118:mdna:23]

[0000038725-19-000185:mdna:23]
Restructuring expenses for the second quarter of 2019 were $0.2 million and related to branch consolidations and other asset rationalizations in the Headwater distribution segment.  Restructuring expenses for the second quarter of 2018 were $0.6 million, with $0.4 million in the Water segment and $0.2 in Fueling from continued miscellaneous manufacturing realignment activities in North America and India.

[0000038725-19-000185:mdna:24]
[same as prior period, unchanged from 0000038725-19-000118:mdna:25]

[0000038725-19-000185:mdna:25]
Operating income was $43.7 million in the second quarter of 2019, up $3.2 million or about 8 percent from $40.5 million in the second quarter of 2018.

[0000038725-19-000185:mdna:26]
|  |  | Operating income (loss) |
| (In millions) |  | Q2 2019 |  | Q2 2018 |  | 2019 v 2018 |
| Water Systems |  | $ | 30.9 |  |  | $ | 32.2 |  |  | $ | (1.3 | ) |
| Fueling Systems |  | 21.7 |  |  | 19.0 |  |  | 2.7 |  |
| Distribution |  | 4.5 |  |  | 4.0 |  |  | 0.5 |  |
| Eliminations/Other |  | (13.4 | ) |  | (14.7 | ) |  | 1.3 |  |
| Consolidated |  | $ | 43.7 |  |  | $ | 40.5 |  |  | $ | 3.2 |  |

[0000038725-19-000185:mdna:27]
[same as prior period, unchanged from 0000038725-19-000118:mdna:28]

[0000038725-19-000185:mdna:28]
Water Systems operating income was $30.9 million in the second quarter 2019, down $1.3 million or 4 percent versus the second quarter 2018 and operating income margin was 15.1 percent compared to the 15.2 percent in the second quarter 2018 primarily due to product and geographic sales mix shifts.

[0000038725-19-000185:mdna:29]
[same as prior period, unchanged from 0000038725-19-000118:mdna:30]

[0000038725-19-000185:mdna:30]
Fueling Systems operating income was $21.7 million in the second quarter of 2019, up $2.7 million or about 14 percent compared to $19.0 million in the second quarter of 2018 and the second quarter operating income margin was 27.8 percent, an increase of 180 basis points from the 26.0 percent of net sales in the second quarter of 2018. The increase in operating income margin was primarily due to favorable sales mix shifts and leverage on fixed cost from higher sales.

[0000038725-19-000185:mdna:31]
[same as prior period, unchanged from 0000038725-19-000118:mdna:32]

[0000038725-19-000185:mdna:32]
Distribution operating income was $4.5 million in the second quarter of 2019 and the second quarter operating income margin was 5.2 percent. Distribution operating income was $4.0 million in the second quarter of 2018 and the second quarter operating income margin was 5.0 percent. The increase in operating income is primarily related to acquisitions.

[0000038725-19-000185:mdna:33]
[same as prior period, unchanged from 0000038725-19-000118:mdna:34]

[0000038725-19-000185:mdna:34]
Operating income-Eliminations/Other is composed primarily of unallocated general and administrative expenses and inter-segment sales and profit eliminations.  The inter-segment profit elimination impact in the second quarter of 2019 was $1.4 million.  General and administrative expenses were higher by $0.1 million or less than 1 percent.

[0000038725-19-000185:mdna:35]
[same as prior period, unchanged from 0000038725-19-000118:mdna:36]

[0000038725-19-000185:mdna:36]
Interest expense for the second quarter of 2019 and 2018 was $2.3 million and $2.6 million, respectively.

[0000038725-19-000185:mdna:37]
[same as prior period, unchanged from 0000038725-19-000118:mdna:38]

[0000038725-19-000185:mdna:38]
Other income or expense was a loss of $0.3 million and $0.0 in the second quarter of 2019 and 2018, respectively. Included in other income in the second quarter of 2019 and 2018 was interest income of $0.2 million, primarily derived from the investment of cash balances.

[0000038725-19-000185:mdna:39]
[same as prior period, unchanged from 0000038725-19-000118:mdna:40]

[0000038725-19-000185:mdna:40]
Foreign currency-based transactions produced a loss for the second quarter of 2019 of $0.5 million, primarily due to the Turkish Lira relative to the U.S. dollar. Foreign currency-based transactions produced a loss for the second quarter of 2018 of $1.0 million, primarily due to the Mexican Peso relative to the U.S. dollar.

[0000038725-19-000185:mdna:41]
[same as prior period, unchanged from 0000038725-19-000118:mdna:42]

[0000038725-19-000185:mdna:42]
The provision for income taxes in the second quarter of 2019 and 2018 was $7.8 million and $6.9 million, respectively. The effective tax rate for the second quarter of 2019 and 2018 was about 19 percent for both and, before the impact of discrete events, was about 21 percent for both. The tax rate as a percentage of pre-tax earnings for the full year of 2019 is projected to be about 21 percent, compared to the full year 2018 tax rate of about 19 percent, both before discrete adjustments.

[0000038725-19-000185:mdna:43]
[same as prior period, unchanged from 0000038725-19-000118:mdna:44]

[0000038725-19-000185:mdna:44]
Net income for the second quarter of 2019 was $32.8 million compared to the prior year second quarter net income of $30.0 million.  Net income attributable to Franklin Electric Co., Inc. for the second quarter of 2019 was $32.7 million, or $0.70 per diluted share, compared to the prior year second quarter net income attributable to Franklin Electric Co., Inc. of $30.5 million or $0.64 per diluted share.

[0000038725-19-000185:mdna:45]
First Half of 2019 vs. First Half of 2018

[0000038725-19-000185:mdna:46]
OVERVIEW

[0000038725-19-000185:mdna:47]
Sales in the first half of 2019 were up from the same period last year.  The sales increase was led by acquisition related sales, as well as price increases partially offset by lower volume. The impact of foreign currency translation decreased sales by about 4 percent. The Company's consolidated gross profit was $209.2 million for the first half of 2019, a decrease of $5.9 million or about 3 percent from the first half of 2018. Diluted earnings per share in the first half of 2019 were down from the same period last year.

[0000038725-19-000185:mdna:48]
RESULTS OF OPERATIONS

[0000038725-19-000185:mdna:49]
Net Sales

[0000038725-19-000185:mdna:50]
Net sales in the first half of 2019 were $646.1 million, an increase of $6.5 million or about 1 percent compared to 2018 first half sales of $639.6 million.  The incremental impact of sales from acquired businesses was $20.6 million.  Sales revenue decreased by $23.2 million or about 4 percent in the first half of 2019 due to foreign currency translation.

[0000038725-19-000185:mdna:51]
|  | Net Sales |
| (In millions) | YTD June 30, 2019 |  | YTD June 30, 2018 |  | 2019 v 2018 |
| Water Systems | $ | 393.4 |  |  | $ | 404.0 |  |  | $ | (10.6 | ) |
| Fueling Systems | 138.3 |  |  | 131.7 |  |  | $ | 6.6 |  |
| Distribution | 140.4 |  |  | 135.7 |  |  | $ | 4.7 |  |
| Eliminations/Other | (26.0 | ) |  | (31.8 | ) |  | $ | 5.8 |  |
| Consolidated | $ | 646.1 |  |  | $ | 639.6 |  |  | $ | 6.5 |  |

[0000038725-19-000185:mdna:52]
Net Sales-Water Systems

[0000038725-19-000185:mdna:53]
Water Systems sales were $393.4 million in the first half 2019, a decrease of $10.6 million or about 3 percent versus the first half 2018. The incremental impact of sales from acquired businesses was $7.6 million.  Foreign currency translation changes decreased sales $20.2 million, or about 5 percent, compared to sales in the first half of 2018. The Water Systems sales change in the first half of 2019, excluding acquisitions and foreign currency translation, was an increase of $2.0 million or less than 1 percent.

[0000038725-19-000185:mdna:54]
Water Systems sales in the U.S. and Canada increased by about 1 percent compared to the first half of 2018. Sales revenue decreased by $2.1 million or about 1 percent in the first half of 2019 due to foreign currency translation. In the first half of 2019, sales of Pioneer branded dewatering equipment increased by about 10 percent compared to the prior year due to strength in North American oil and gas markets and continued diversification of product sales channels and geographies. Sales of groundwater pumping equipment decreased by about 9 percent on lower residential and agricultural system sales primarily to the Headwater companies, versus the first half of 2018. Sales of other surface pumping equipment increased by 5 percent in part due to wet weather conditions in the upper Midwest and Canada.

[0000038725-19-000185:mdna:55]
Water Systems sales in markets outside the U.S. and Canada decreased by about 6 percent compared to the first half of 2018. The incremental impact of sales from acquired businesses was $7.6 million or about 4 percent.   Sales revenue decreased by $18.1 million or about 10 percent in the first half of 2019 due to foreign currency translation. International Water Systems sales change in the first half of 2019, excluding acquisitions and foreign currency translation, was a decrease of less than 1 percent.  International Water Systems sales growth in the Asia Pacific markets were offset by declines primarily from by lower sales in EMENA and in Latin America markets outside of Brazil.

[0000038725-19-000185:mdna:56]
Net Sales-Fueling Systems

[0000038725-19-000185:mdna:57]
Fueling Systems sales were $138.3 million in the first half 2019, an increase of $6.6 million or about 5 percent from the first half of 2018. The incremental impact of sales from acquired businesses was $3.2 million.  Foreign currency translation changes decreased sales $3.0 million or about 2 percent compared to sales in the first half of 2018. The Fueling Systems sales change in the first half of 2019, excluding acquisitions and foreign currency translation, was an increase of about 5 percent.

[0000038725-19-000185:mdna:58]
Fueling Systems sales in the U.S. and Canada grew by about 13 percent during the first half with most of the sales growth coming from piping. Internationally, Fueling Systems revenues declined by about 4 percent due to lower sales in Europe and Africa partially offset by higher sales in India, China and other regions.

[0000038725-19-000185:mdna:59]
Net Sales-Distribution

[0000038725-19-000185:mdna:60]
Distribution sales were $140.4 million in the first half of 2019, versus the first half of 2018 sales of $135.7 million. The incremental impact of sales from acquired businesses was $9.8 million. Distribution segment organic sales decreased about 4 percent compared to the first half of 2018 primarily due to unfavorable weather conditions.

[0000038725-19-000185:mdna:61]
Cost of Sales

[0000038725-19-000185:mdna:62]
Cost of sales as a percent of net sales for the first half of 2019 and 2018 was 67.6 percent and 66.4 percent, respectively. Correspondingly, the gross profit margin was 32.4 percent and 33.6 percent, respectively. The Company's consolidated gross profit was $209.2 million for the first half of 2019, down $5.9 million from the gross profit of $215.1 million in the first half of 2018. The gross profit decrease was primarily due to lower sales. The decline in gross profit margin percentage is partially attributable to product and geographic sales mix shifts.

[0000038725-19-000185:mdna:63]
Selling, General, and Administrative (“SG&A”)

[0000038725-19-000185:mdna:64]
Selling, general, and administrative expenses were $152.1 million in the first half of 2019 and increased by $0.9 million in the first half of 2019 compared to $151.2 million the first half of last year. The increase in SG&A expenses from acquired businesses were $5.8 million. Excluding the acquired entities, the Company’s SG&A expenses in the first half of 2019 decreased by $4.9 million or about 3 percent, partially due to the effect of foreign currency translation in the first half of 2019 versus the prior year.

[0000038725-19-000185:mdna:65]
Restructuring Expenses

[0000038725-19-000185:mdna:66]
Restructuring expenses for the first half of 2019 were $1.3 million. Restructuring expenses were $0.5 million in the Water segment from continued miscellaneous manufacturing realignment activities and $0.8 in distribution related to branch consolidations and other asset rationalizations in the Headwater distribution segment.  Restructuring expenses for the first half of 2018 were $0.6 million. Restructuring expenses were $0.4 million in the Water segment and $0.2 in Fueling from continued miscellaneous manufacturing realignment activities.

[0000038725-19-000185:mdna:67]
Operating Income

[0000038725-19-000185:mdna:68]
Operating income was $55.8 million in the first half of 2019, down $7.4 million from $63.2 million in the first half

[0000038725-19-000185:mdna:69]
of 2018.

[0000038725-19-000185:mdna:70]
|  |  | Operating income (loss) |
| (In millions) |  | YTD June 30, 2019 |  | YTD June 30, 2018 |  | 2019 v 2018 |
| Water Systems |  | $ | 50.1 |  |  | $ | 57.3 |  |  | $ | (7.2 | ) |
| Fueling Systems |  | 34.0 |  |  | 32.7 |  |  | 1.3 |  |
| Distribution |  | 0.2 |  |  | 3.2 |  |  | (3.0 | ) |
| Eliminations/Other |  | (28.5 | ) |  | (30.0 | ) |  | 1.5 |  |
| Consolidated |  | $ | 55.8 |  |  | $ | 63.2 |  |  | $ | (7.4 | ) |

[0000038725-19-000185:mdna:71]
Operating Income-Water Systems

[0000038725-19-000185:mdna:72]
Water Systems operating income was $50.1 million in the first half of 2019 compared to $57.3 million in the first half of 2018, a decrease of about 13 percent. The first half operating income margin was 12.7 percent and decreased by 150 basis points compared to the first half of 2018. Operating income margin decreased in Water Systems primarily due to lost leverage on fixed costs due to lower sales volumes, as well as product and geographic sales mix shifts.

[0000038725-19-000185:mdna:73]
Operating Income-Fueling Systems

[0000038725-19-000185:mdna:74]
Fueling Systems operating income was $34.0 million in the first half of 2019 compared to $32.7 million in the first half of 2018. The first half operating income margin was 24.6 percent compared to 24.8 percent of net sales in the first half of 2018, a decrease of 20 basis points.

[0000038725-19-000185:mdna:75]
Operating Income-Distribution

[0000038725-19-000185:mdna:76]
Distribution operating income was $0.2 million in the first half of 2019 and operating income margin was 0.1 percent. Distribution operating income was $3.2 million in the first half of 2018 and operating income margin was 2.4 percent. Operating income decreased in distribution due to lower sales volumes, partially offset by acquisitions.

[0000038725-19-000185:mdna:77]
Operating Income-Eliminations/Other

[0000038725-19-000185:mdna:78]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the first half of 2019 was $0.8 million.  General and administrative expenses were lower by $0.7 million or about 2 percent to last year in the first half.

[0000038725-19-000185:mdna:79]
Interest Expense

[0000038725-19-000185:mdna:80]
Interest expense for the first half of 2019 and 2018 was $4.6 million and $5.0 million, respectively.

[0000038725-19-000185:mdna:81]
Other Income or Expense

[0000038725-19-000185:mdna:82]
Other income or expense was a loss of $0.1 million in the first half of 2019. Included in other income in the first half of 2019 was interest income of $0.4 million, primarily derived from the investment of cash balances in short-term securities. Other income or expense was a loss of $0.2 million in the first half of 2018. Included in other income in the first half of 2018 was interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-19-000185:mdna:83]
Foreign Exchange

[0000038725-19-000185:mdna:84]
Foreign currency-based transactions for the first half of 2019 was a gain $0.1 million due to movements in several currencies relative to the U.S. dollar, none of which individually were significant. Foreign currency-based transactions for the first half of 2018 was a loss of $1.6 million due to movements in several currencies relative to the U.S. dollar, with the Mexican Peso and South African Rand being the most significant.

[0000038725-19-000185:mdna:85]
Income Taxes

[0000038725-19-000185:mdna:86]
The provision for income taxes in the first half of 2019 and 2018 was $9.3 million and $5.2 million, respectively. The effective tax rate for the first half of 2019 was about 18 percent and, before the impact of discrete events, was about 21 percent. The effective tax rate in the first half of 2018 was about 9 percent and, before the impact of discrete events, was about 20 percent. The Company estimates its effective tax rate for 2019 after discrete events will be about 20 percent, or about 8 points higher than the effective tax rate of 12 percent in 2018. The increase in the effective tax rate was primarily the result of the release of a valuation allowance of $5.4 million related to state net operating losses and incentives during the first quarter of 2018.

[0000038725-19-000185:mdna:87]
Net Income

[0000038725-19-000185:mdna:88]
Net income for the first half of 2019 was $41.9 million compared to 2018 first half net income of $51.3 million.  Net income attributable to Franklin Electric Co., Inc. for the first half of 2019 was $41.8 million, or $0.89 per diluted share, compared to 2018 first half net income attributable to Franklin Electric Co., Inc. of $51.7 million or $1.09 per diluted share.

[0000038725-19-000185:mdna:89]
[same as prior period, unchanged from 0000038725-19-000118:mdna:46]

[0000038725-19-000185:mdna:90]
[same as prior period, unchanged from 0000038725-19-000118:mdna:47]

[0000038725-19-000185:mdna:91]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at June 30, 2019 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-19-000185:mdna:92]
As of June 30, 2019 the Company had a $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of June 30, 2019, the Company had $171.7 million borrowing capacity under the Credit Agreement as $5.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and $123.3 million in revolver borrowings were drawn and outstanding which were primarily used for working capital needs, the payment of existing indebtedness, and acquisitions.

[0000038725-19-000185:mdna:93]
The Company also has other long-term debt borrowing outstanding as of June 30, 2019.  See Note 9 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-19-000185:mdna:94]
At June 30, 2019, the Company had $38.5 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-19-000185:mdna:95]
[same as prior period, unchanged from 0000038725-19-000118:mdna:53]

[0000038725-19-000185:mdna:96]
The following table summarizes significant sources and uses of cash and cash equivalents for the first six months of 2019 and 2018.

[0000038725-19-000185:mdna:97]
| (in millions) |  | 2019 |  | 2018 |
| Net cash flows from operating activities |  | $ | 4.1 |  |  | $ | 5.2 |  |
| Net cash flows from investing activities |  | (16.3 | ) |  | (19.4 | ) |
| Net cash flows from financing activities |  | (5.2 | ) |  | 17.5 |  |
| Impact of exchange rates on cash and cash equivalents |  | (0.8 | ) |  | (0.5 | ) |
| Change in cash and cash equivalents |  | $ | (18.2 | ) |  | $ | 2.8 |  |

[0000038725-19-000185:mdna:98]
Cash Flows from Operating Activities

[0000038725-19-000185:mdna:99]
[same as prior period, unchanged from 0000038725-19-000118:mdna:57]

[0000038725-19-000185:mdna:100]
Net cash provided by operating activities was $4.1 million for the six months ended June 30, 2019 compared to $5.2 million provided by operating activities for the six months ended June 30, 2018.  The decrease in cash provided by operating activities was due to decreased earnings of approximately $9.3 million, offset by lower tax payments in the current year. Total working capital requirements for the first six months remained flat when compared to the prior year.  The Company saw increases in

[0000038725-19-000185:mdna:101]
cash provided by accounts payables and accrued expenses due to better payment terms with vendors, which was offset by increased inventory mainly due to lower than expected sales.

[0000038725-19-000185:mdna:102]
Cash Flows from Investing Activities

[0000038725-19-000185:mdna:103]
[same as prior period, unchanged from 0000038725-19-000118:mdna:60]

[0000038725-19-000185:mdna:104]
Net cash used in investing activities was $16.3 million for the six months ended June 30, 2019 compared to $19.4 million used in investing activities for the sixth months ended June 30, 2018.  The decrease in cash used in investing activities is primarily attributable to decreased acquisition activity and lower spending for property, plant and equipment during the current year.

[0000038725-19-000185:mdna:105]
Cash Flows from Financing Activities

[0000038725-19-000185:mdna:106]
[same as prior period, unchanged from 0000038725-19-000118:mdna:63]

[0000038725-19-000185:mdna:107]
Net cash used in financing activities was $5.2 million for the sixth months ended June 30, 2019 compared to $17.5 million provided by financing activities for the six months ended June 30, 2018.  The change in net cash from financing activities was primarily attributable to lower net debt borrowings, down approximately $20.5 million in the current year consistent with reduced acquisition activity as well as an increase in dividends paid of $2.8 million in the current year compared to dividends paid in the prior year.  These were offset by a decrease in common stock repurchases of $1.5 million in the current year compared to common stock repurchases in the prior year.

[0000038725-19-000185:mdna:108]
[same as prior period, unchanged from 0000038725-19-000118:mdna:65]
