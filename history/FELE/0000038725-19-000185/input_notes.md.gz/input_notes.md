# FELE notes — 0000038725-19-000185


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-19-000185:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2018, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2019, and for the second quarters and six months ended June 30, 2019 and June 30, 2018 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the second quarter and six months ended June 30, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2019.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2018.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-19-000185:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-19-000185:notes:3]
In February 2018, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 ("Tax Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The ASU is effective for interim and annual periods beginning after December 15, 2018, with early adoption permitted, and may be applied either at the beginning of the period of adoption or retrospectively to each period in which the effect of the change in the U.S. federal corporate income tax rate in the Tax Act is recognized. The Company adopted the standard effective January 1, 2019 and did not reclassify tax effects stranded in accumulated other comprehensive loss.  As such, there is no impact on the Company’s consolidated financial position, results of operations, and cash flows as a result of the adoption of the ASU.

[0000038725-19-000185:notes:4]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification (“ASC”) Topic 840.  This ASU requires lessees to present right-of-use (“ROU”) assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases and ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-10 clarifies certain aspects of Topic 842, including the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options, variable payments that depend on an index or rate and certain transition adjustments, among other things. ASU 2018-11 allows entities adopting ASU 2016-02 to choose an additional (and optional) transition method of adoption, under which an entity initially applies the new lease standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. Additionally, ASU 2018-11 allows lessors to not separate non-lease components from the associated lease component if certain conditions are met. The guidance is to be applied using either the transition method prescribed in ASU 2018-11 or a modified retrospective approach at the beginning of the earliest comparative period in the financial statements.

[0000038725-19-000185:notes:5]
The Company adopted the standard effective January 1, 2019 utilizing the optional transition method prescribed in ASU 2018-11. The Company utilized the transition practical expedients, per ASC 842-10-65-11, that are permitted with the new standard when elected as a package. The Company will also utilize other available practical expedients, including the election not to separate non-lease components and the election to use hindsight when determining the lease terms. Finally, the Company has made an accounting policy election to not present leases with an initial term of 12 months or less (short-term leases) on the balance sheet.

[0000038725-19-000185:notes:6]
The Company has recorded on the Balance Sheet ROU assets and lease liabilities. The initial ROU asset at the implementation of the standard was approximately $26.3 million with a corresponding lease liability of the same amount. The Company segregated the lease liabilities between short term and long term based on the related contractual maturities. The Company has recognized the cash paid for lease liabilities in the Statement of Cash Flows. The Company did not have an adjustment to retained earnings as a result of the adoption of this standard.  Additional disclosures regarding the Company’s leases can be found in Footnote 14 - Commitments and Contingencies.

[0000038725-19-000185:notes:7]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) as modified by subsequently issued ASUs 2015-14, 2016-08, 2016-10, 2016-12 and 2016-20 (collectively ASU 2014-09).  Topic 606 supersedes the revenue recognition requirements in Accounting Standards Codification (“ASC”) Topic 605, Revenue Recognition (“Topic 605”), and requires the recognition of revenue when promised goods or services are transferred to

[0000038725-19-000185:notes:8]
customers in an amount that reflects the considerations to which the entity expects to be entitled to in exchange for those goods or services.  The Company made the accounting policy election allowed by ASC 606-10-32-2A to continue to present sales tax on a net basis, consistent with current guidance in ASC 605-45-15-2(e).  The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method).  The Company adopted ASU 2014-09 during the first quarter ended March 31, 2018 utilizing the modified retrospective approach. The adoption of this ASU did not have a material impact to the Company’s condensed consolidated financial position, results of operations, or cash flow; however, the adoption of this ASU requires the Company to disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company completed its assessment of the additional disclosure requirements with the following results:

[0000038725-19-000185:notes:9]
Disaggregation of Revenue

[0000038725-19-000185:notes:10]
The adoption of this ASU requires the Company to disaggregate revenue into categories to depict how the nature, timing, and uncertainty of revenue and cash flows are affected by economic factors.  As evidenced in Footnote 13 Segment and Geographic Information, the Company’s business consists of the Water, Fueling, Distribution, and Other segments. The Other segment includes unallocated corporate expenses and intersegment eliminations. A reconciliation of disaggregated revenue to segment revenue as well as Water Segment revenue by geographical regions is provided in Footnote 13, consistent with how the Company evaluates financial performance.

[0000038725-19-000185:notes:11]
Performance Obligations

[0000038725-19-000185:notes:12]
A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in ASC Topic 606.  The Company typically sells its products to customers by purchase order, and does not have any additional performance obligations included in contracts to customers other than the shipment of products. The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience. The Company typically ships products FOB shipping at which point control of the products passes to the customers. Any shipping and handling fees prior to shipment are considered activities required to fulfill the Company’s promise to transfer goods, and do not qualify as a separate performance obligation. Shipping and handling costs are recorded as a component of cost of sales.  Additionally, the Company offers assurance-type warranties (vs. service warranties) which do not qualify as a separate performance obligation. Therefore, the Company allocates the transaction price based on a single performance obligation.  The Company offers normal and customary trade terms to its customers, no significant part of which is of an extended nature.  The Company considers the performance obligation satisfied and recognizes revenue at a point in time, the time of shipment.  The Company does not generally allow for refunds or returns to customers and does not have outstanding performance obligations for contracts with original durations of greater than one year at the end of the reporting period.

[0000038725-19-000185:notes:13]
Contract Costs

[0000038725-19-000185:notes:14]
The Company does not have outstanding contracts with an original term greater than one year; therefore, the Company expenses costs to obtain a contract as incurred.

[0000038725-19-000185:notes:15]
Accounting Standards Issued But Not Yet Adopted

[0000038725-19-000185:notes:16]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which modifies the disclosure requirements for employers that sponsor defined benefit pension or other postretirement plans. The amendments remove disclosures that no longer are considered cost beneficial, including the estimated amounts in accumulated other comprehensive income expected to be recognized as components of net periodic expense over the next fiscal year. The amendments clarify the specific requirements of disclosures, and add disclosure requirements identified as relevant, including the reasons for significant gains and losses related to change in the benefit obligation for the period.  The ASU should be applied retrospectively and is effective for interim and annual periods beginning after December 15, 2020. The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-19-000185:notes:17]
In August 2018, the FASB issued ASU 2018-15, Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. This ASU aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with

[0000038725-19-000185:notes:18]
the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include internal-use software license). The ASU should be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption and is effective for interim and annual periods beginning after December 15, 2019 with early adoption permitted. The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-19-000185:notes:19]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-19-000185:notes:20]
ACQUISITIONS
During the second quarter ended June 30, 2019, the Company acquired the remaining interest in Pluga Pumps and Motors Private Limited, India, increasing the Company's ownership to 100 percent.  The redemption of this interest was immaterial.

[0000038725-19-000185:notes:21]
During the first quarter ended March 31, 2019, the Company acquired 100 percent of the ownership interests of Mt. Pleasant, Michigan-based Milan Supply Company ("Milan Supply"), for a purchase price of approximately $6.1 million after working capital adjustments.  Milan Supply is a professional groundwater distributor operating six locations in the State of Michigan.  Milan Supply is part of the Company’s Distribution Segment, which is a collection of professional groundwater equipment distributors.  The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2019, as the results of operations for this acquisition is immaterial.  The fair value of the assets acquired and the liabilities assumed are preliminary as of June 30, 2019.

[0000038725-19-000185:notes:22]
During the third quarter ended September 30, 2018, the Company acquired, in separate transactions, substantially all of the assets of Stationary Power Division ("SPD") of Midtronics, Inc., and 100 percent of the ownership interest in Industrias Rotor Pump S.A. ("Industrias Rotor Pump") for a combined purchase price of approximately $37 million. The acquisitions were not material individually or in the aggregate.  The fair value of the assets acquired and the liabilities assumed are preliminary as of June 30, 2019.

[0000038725-19-000185:notes:23]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations.  There were $0.1 million and $0.1 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the second quarter and six months ended June 30, 2019 respectively.  There were $0.1 million and $0.2 million of transaction costs incurred in the second quarter and six months ended June 30, 2018, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-19-000185:notes:24]
[same as prior period, unchanged from 0000038725-19-000118:notes:24]

[0000038725-19-000185:notes:25]
[same as prior period, unchanged from 0000038725-19-000118:notes:25]

[0000038725-19-000185:notes:26]
[same as prior period, unchanged from 0000038725-19-000118:notes:26]

[0000038725-19-000185:notes:27]
[same as prior period, unchanged from 0000038725-19-000118:notes:27]

[0000038725-19-000185:notes:28]
As of June 30, 2019 and December 31, 2018, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-19-000185:notes:29]
| (In millions) | June 30, 2019 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 1.9 |  | $ | 1.9 |  | $ | — |  | $ | — |  |
|  | December 31, 2018 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 2.5 |  | $ | 2.5 |  | $ | — |  | $ | — |  |

[0000038725-19-000185:notes:30]
[same as prior period, unchanged from 0000038725-19-000118:notes:30]

[0000038725-19-000185:notes:31]
[same as prior period, unchanged from 0000038725-19-000118:notes:31]

[0000038725-19-000185:notes:32]
Total debt, including current maturities, have carrying amounts of $222.9 million and $206.3 million and estimated fair values of $228 million and $205 million as of June 30, 2019 and December 31, 2018, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-19-000185:notes:33]
FINANCIAL INSTRUMENTSThe Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of June 30, 2019, the swap had a notional value based on 255,000 shares.  For the second quarter and six months ended June 30, 2019, the swap resulted in a loss of $0.9 million and a gain of  $1.0 million, respectively. For the second quarter and six months ended June 30, 2018, the swap resulted in a gain of 0.8 million and a loss of 0.3 million, respectively.  Gains and losses resulting from the the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-19-000185:notes:34]
[same as prior period, unchanged from 0000038725-19-000118:notes:34]

[0000038725-19-000185:notes:35]
| (In millions) |  | June 30, 2019 |  | December 31, 2018 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (7.0 | ) |  | $ | 7.5 |  |  | $ | (6.9 | ) |
| Technology |  | 7.5 |  |  | (6.6 | ) |  | 7.5 |  |  | (6.4 | ) |
| Customer relationships |  | 151.0 |  |  | (67.6 | ) |  | 151.0 |  |  | (63.8 | ) |
| Other |  | 2.8 |  |  | (2.7 | ) |  | 2.8 |  |  | (2.5 | ) |
| Total |  | $ | 168.8 |  |  | $ | (83.9 | ) |  | $ | 168.8 |  |  | $ | (79.6 | ) |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 45.8 |  |  | — |  |  | 45.9 |  |  | — |  |
| Total intangibles |  | $ | 214.6 |  |  | $ | (83.9 | ) |  | $ | 214.7 |  |  | $ | (79.6 | ) |

[0000038725-19-000185:notes:36]
Amortization expense related to intangible assets for the second quarters ended June 30, 2019 and June 30, 2018 was $2.3 million and $2.2 million, and for the six months ended June 30, 2019 and June 30, 2018, $4.6 million and $4.3 million respectively.

[0000038725-19-000185:notes:37]
[same as prior period, unchanged from 0000038725-19-000118:notes:37]

[0000038725-19-000185:notes:38]
| (In millions) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |
|  |  | $ | 9.2 |  |  | $ | 9.1 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |  | $ | 8.4 |  |

[0000038725-19-000185:notes:39]
The change in the carrying amount of goodwill by reportable segment for the six months ended June 30, 2019, is as follows:

[0000038725-19-000185:notes:40]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2018 |  | $ | 145.5 |  |  | $ | 67.5 |  |  | $ | 35.7 |  |  | $ | 248.7 |  |
| Acquisitions |  | — |  |  | — |  |  | 1.7 |  |  | 1.7 |  |
| Foreign currency translation |  | (0.3 | ) |  | 0.1 |  |  | — |  |  | (0.2 | ) |
| Balance as of June 30, 2019 |  | $ | 145.2 |  |  | $ | 67.6 |  |  | $ | 37.4 |  |  | $ | 250.2 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-19-000185:notes:41]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of June 30, 2019, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2018 measurement date for these plans.  One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-19-000185:notes:42]
[same as prior period, unchanged from 0000038725-19-000118:notes:42]

[0000038725-19-000185:notes:43]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the second quarters and six months ended June 30, 2019 and June 30, 2018:

[0000038725-19-000185:notes:44]
| (In millions) | Pension Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |
| Interest cost | 1.5 |  |  | 1.4 |  |  | 3.0 |  |  | 2.7 |  |
| Expected return on assets | (2.0 | ) |  | (2.2 | ) |  | (4.0 | ) |  | (4.3 | ) |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.7 |  |  | 0.8 |  |  | 1.3 |  |  | 1.5 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.4 |  |  | $ | 0.2 |  |  | $ | 0.7 |  |  | $ | 0.3 |  |

[0000038725-19-000185:notes:45]
In the six months ended June 30, 2019, the Company made contributions of $0.0 million to the funded plans.   The amount of contributions to be made to the plans during the calendar year 2019 will be finalized by September 15, 2019, based upon the funding level requirements identified and year-end valuation performed at December 31, 2018.

[0000038725-19-000185:notes:46]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the second quarters and six months ended June 30, 2019 and June 30, 2018:

[0000038725-19-000185:notes:47]
| (In millions) | Other Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-19-000185:notes:48]
INCOME TAXES
The Company’s effective tax rate from continuing operations for the six month period ended June 30, 2019 was 18.1 percent as compared to 9.2 percent for the six month period ended June 30, 2018. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to foreign earnings taxed at rates below the U.S. statutory rate, the recognition of the foreign-derived intangible income (FDII) provisions, and certain discrete events including excess tax benefits from share-based compensation. For the second quarter of 2019 the effective tax rate was 19.2 percent as compared to 18.6 percent for the second quarter of 2018.

[0000038725-19-000185:notes:49]
The increase in the effective tax rate for the six months ended June 30, 2019, compared with the same period in 2018, was primarily a result of the release of a valuation allowance of $5.4 million related to state net operating losses and incentives during the six month period ended June 30, 2018.


## us-gaap:DebtDisclosureTextBlock

[0000038725-19-000185:notes:50]
DEBT
Debt consisted of the following:

[0000038725-19-000185:notes:51]
| (In millions) |  | June 30, 2019 |  | December 31, 2018 |
| Prudential Agreement |  | $ | — |  |  | $ | 30.0 |  |
| Tax increment financing debt |  | 19.3 |  |  | 19.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 123.3 |  |  | 76.3 |  |
| Financing Leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 5.5 |  |  | 5.4 |  |
| Less: unamortized debt issuance costs |  | (0.2 | ) |  | (0.2 | ) |
|  |  | $ | 223.0 |  |  | $ | 206.4 |  |
| Less: current maturities |  | (129.3 | ) |  | (112.0 | ) |
| Long-term debt |  | $ | 93.7 |  |  | $ | 94.4 |  |

[0000038725-19-000185:notes:52]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2019 matures as follows:

[0000038725-19-000185:notes:53]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 223.1 |  |  | $ | 129.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 88.7 |  |
| Financing Leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 223.2 |  |  | $ | 129.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 88.7 |  |

[0000038725-19-000185:notes:54]
Prudential Agreement

[0000038725-19-000185:notes:55]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Company paid the remaining principal balance of the previously issued notes during the second quarter of 2019.  As of June 30, 2019, the Company has $150.0 million borrowing capacity available under the Prudential Agreement. There is no additional borrowing capacity resulting from principal payments made by the Company.

[0000038725-19-000185:notes:56]
Project Bonds

[0000038725-19-000185:notes:57]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-19-000185:notes:58]
New York Life Agreement

[0000038725-19-000185:notes:59]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of June 30, 2019, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-19-000185:notes:60]
Credit Agreement

[0000038725-19-000185:notes:61]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-19-000185:notes:62]
As of June 30, 2019, the Company had $123.3 million in outstanding borrowings which were primarily used for working capital needs and the payment of existing indebtedness, $5.0 million in letters of credit outstanding, and $171.7 million of available capacity under the Credit Agreement.

[0000038725-19-000185:notes:63]
Covenants

[0000038725-19-000185:notes:64]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2019.


## us-gaap:EarningsPerShareTextBlock

[0000038725-19-000185:notes:65]
[same as prior period, unchanged from 0000038725-19-000118:notes:64]

[0000038725-19-000185:notes:66]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated

[0000038725-19-000185:notes:67]
by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-19-000185:notes:68]
[same as prior period, unchanged from 0000038725-19-000118:notes:66]

[0000038725-19-000185:notes:69]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions, except per share amounts) | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 32.7 |  |  | $ | 30.5 |  |  | $ | 41.8 |  |  | $ | 51.7 |  |
| Less: Earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.3 |  |  | 0.4 |  |
| Net income available to common shareholders | $ | 32.5 |  |  | $ | 30.3 |  |  | $ | 41.5 |  |  | $ | 51.3 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.3 |  |  | 46.5 |  |  | 46.3 |  |  | 46.5 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.4 |  |  | 0.5 |  |  | 0.4 |  |  | 0.5 |  |
| Diluted weighted average common shares outstanding | 46.7 |  |  | 47.0 |  |  | 46.7 |  |  | 47.0 |  |
| Basic earnings per share | $ | 0.70 |  |  | $ | 0.65 |  |  | $ | 0.89 |  |  | $ | 1.10 |  |
| Diluted earnings per share | $ | 0.70 |  |  | $ | 0.64 |  |  | $ | 0.89 |  |  | $ | 1.09 |  |

[0000038725-19-000185:notes:70]
There were 0.3 million and 0.2 million stock options outstanding for the second quarters ended June 30, 2019 and June 30, 2018, and 0.2 million and 0.2 million stock options outstanding for the six months ended June 30, 2019 and June 30, 2018 respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-19-000185:notes:71]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the second quarters ended June 30, 2019 and June 30, 2018:

[0000038725-19-000185:notes:72]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2019 | $ | 4,637 |  |  | $ | 262,002 |  |  | $ | 652,737 |  |  | $ | (48,076 | ) |  | $ | (137,205 | ) |  | $ | 2,097 |  |  | $ | 736,192 |  |  | $ | 408 |  |
| Net income |  |  |  |  | 32,745 |  |  |  |  |  |  | 247 |  |  | 32,992 |  |  | (180 | ) |
| Dividends on common stock ($0.1450/share) |  |  |  |  | (6,787 | ) |  |  |  |  |  |  |  | (6,787 | ) |  |  |
| Common stock issued | 1 |  |  | 243 |  |  |  |  |  |  |  |  |  |  | 244 |  |  |  |
| Common stock repurchased | (12 | ) |  |  |  | (5,202 | ) |  |  |  |  |  |  |  | (5,214 | ) |  |  |
| Share-based compensation | 6 |  |  | 2,288 |  |  |  |  |  |  |  |  |  |  | 2,294 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (642 | ) |  | (642 | ) |  |  |
| Purchase of redeemable noncontrolling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | (485 | ) |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 1,303 |  |  | 12 |  |  | 1,315 |  |  | 47 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 508 |  |  |  |  |  |  | 508 |  |  |  |
| Balance as of June 30, 2019 | $ | 4,632 |  |  | $ | 264,533 |  |  | $ | 673,493 |  |  | $ | (47,568 | ) |  | $ | (135,902 | ) |  | $ | 1,714 |  |  | $ | 760,902 |  |  | $ | (210 | ) |

[0000038725-19-000185:notes:73]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2018 | $ | 4,652 |  |  | $ | 244,095 |  |  | $ | 613,113 |  |  | $ | (48,763 | ) |  | $ | (92,740 | ) |  | $ | 2,199 |  |  | $ | 722,556 |  |  | $ | 1,360 |  |
| Net income |  |  |  |  | 30,497 |  |  |  |  |  |  | 190 |  |  | 30,687 |  |  | (648 | ) |
| Dividends on common stock ($0.1200/share) |  |  |  |  | (5,621 | ) |  |  |  |  |  |  |  | (5,621 | ) |  |  |
| Common stock issued | 6 |  |  | 1,147 |  |  |  |  |  |  |  |  |  |  | 1,153 |  |  |  |
| Common stock repurchased | (7 | ) |  |  |  | (2,997 | ) |  |  |  |  |  |  |  | (3,004 | ) |  |  |
| Share-based compensation | 3 |  |  | 1,440 |  |  |  |  |  |  |  |  |  |  | 1,443 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |  |  |
| Purchase of redeemable noncontrolling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (32,725 | ) |  | (63 | ) |  | (32,788 | ) |  | 52 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 598 |  |  |  |  |  |  | 598 |  |  |  |
| Balance as of June 30, 2018 | $ | 4,654 |  |  | $ | 246,682 |  |  | $ | 634,992 |  |  | $ | (48,165 | ) |  | $ | (125,465 | ) |  | $ | 2,326 |  |  | $ | 715,024 |  |  | $ | 764 |  |

[0000038725-19-000185:notes:74]
The schedules below set forth equity changes in the six months ended June 30, 2019 and June 30, 2018:

[0000038725-19-000185:notes:75]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2018 | $ | 4,632 |  |  | $ | 257,535 |  |  | $ | 654,724 |  |  | $ | (48,585 | ) |  | $ | (134,434 | ) |  | $ | 1,955 |  |  | $ | 735,827 |  |  | $ | 518 |  |
| Net income |  |  |  |  | 41,801 |  |  |  |  |  |  | 421 |  |  | 42,222 |  |  | (283 | ) |
| Dividends on common stock ($0.2900/share) |  |  |  |  | (13,510 | ) |  |  |  |  |  |  |  | (13,510 | ) |  |  |
| Common stock issued | 7 |  |  | 1,488 |  |  |  |  |  |  |  |  |  |  | 1,495 |  |  |  |
| Common stock repurchased | (21 | ) |  |  |  | (9,522 | ) |  |  |  |  |  |  |  | (9,543 | ) |  |  |
| Share-based compensation | 14 |  |  | 5,510 |  |  |  |  |  |  |  |  |  |  | 5,524 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (642 | ) |  | (642 | ) |  |  |
| Purchase of redeemable noncontrolling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | (485 | ) |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (1,468 | ) |  | (20 | ) |  | (1,488 | ) |  | 40 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 1,017 |  |  |  |  |  |  | 1,017 |  |  |  |
| Balance as of June 30, 2019 | $ | 4,632 |  |  | $ | 264,533 |  |  | $ | 673,493 |  |  | $ | (47,568 | ) |  | $ | (135,902 | ) |  | $ | 1,714 |  |  | $ | 760,902 |  |  | $ | (210 | ) |

[0000038725-19-000185:notes:76]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2017 | $ | 4,663 |  |  | $ | 240,136 |  |  | $ | 604,905 |  |  | $ | (49,364 | ) |  | $ | (99,683 | ) |  | $ | 1,964 |  |  | $ | 702,621 |  |  | $ | 1,502 |  |
| Net income |  |  |  |  | 51,671 |  |  |  |  |  |  | 385 |  |  | 52,056 |  |  | (802 | ) |
| Dividends on common stock ($0.2275/share) |  |  |  |  | (10,658 | ) |  |  |  |  |  |  |  | (10,658 | ) |  |  |
| Common stock issued | 9 |  |  | 1,786 |  |  |  |  |  |  |  |  |  |  | 1,795 |  |  |  |
| Common stock repurchased | (27 | ) |  |  |  | (10,926 | ) |  |  |  |  |  |  |  | (10,953 | ) |  |  |
| Share-based compensation | 9 |  |  | 4,760 |  |  |  |  |  |  |  |  |  |  | 4,769 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |  |  |
| Purchase of redeemable noncontrolling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (25,782 | ) |  | (23 | ) |  | (25,805 | ) |  | 64 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 1,199 |  |  |  |  |  |  | 1,199 |  |  |  |
| Balance as of June 30, 2018 | $ | 4,654 |  |  | $ | 246,682 |  |  | $ | 634,992 |  |  | $ | (48,165 | ) |  | $ | (125,465 | ) |  | $ | 2,326 |  |  | $ | 715,024 |  |  | $ | 764 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-19-000185:notes:77]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the six months ended June 30, 2019 and June 30, 2018, are summarized below:

[0000038725-19-000185:notes:78]
| (In millions) |  |  |  |  |  |
| For the six months ended June 30, 2019: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2018 | $ | (134.5 | ) |  | $ | (48.5 | ) |  | $ | (183.0 | ) |
| Other comprehensive income/(loss) before reclassifications | (1.4 | ) |  | — |  |  | (1.4 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.9 |  |  | 0.9 |  |
| Net other comprehensive income/(loss) | (1.4 | ) |  | 0.9 |  |  | (0.5 | ) |
| Balance as of June 30, 2019 | $ | (135.9 | ) |  | $ | (47.6 | ) |  | $ | (183.5 | ) |
| For the six months ended June 30, 2018 |  |  |  |  |  |
| Balance as of December 31, 2017 | $ | (99.7 | ) |  | $ | (49.3 | ) |  | $ | (149.0 | ) |
| Other comprehensive income/(loss) before reclassifications | (25.8 | ) |  | — |  |  | (25.8 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.2 |  |  | 1.2 |  |
| Net other comprehensive income/(loss) | (25.8 | ) |  | 1.2 |  |  | (24.6 | ) |
| Balance as of June 30, 2018 | $ | (125.5 | ) |  | $ | (48.1 | ) |  | $ | (173.6 | ) |

[0000038725-19-000185:notes:79]
[same as prior period, unchanged from 0000038725-19-000118:notes:74]

[0000038725-19-000185:notes:80]
(2) Net of tax expense of $0.3 million and $0.4 million for the six months ended June 30, 2019 and June 30, 2018, respectively.

[0000038725-19-000185:notes:81]
[same as prior period, unchanged from 0000038725-19-000118:notes:76]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-19-000185:notes:82]
[same as prior period, unchanged from 0000038725-19-000118:notes:77]

[0000038725-19-000185:notes:83]
Segment operating income is a key financial performance measure. Operating income by segment is based on net sales less identifiable operating expenses and allocations and includes profits recorded on sales to other segments of the Company.  During the first quarter of 2019, the Company changed management reporting for transfers of certain products between the Water and Fueling segments. This reclassification resulted in $1.0 million of sales and $0.1 million of operating income for the second quarter ended June 30, 2018 and $1.8 million of sales and $0.2 million of operating income for the six months ended June 30, 2018, being reclassified between the Fueling segment and the Water segment. Additionally, the changes to management reporting had an impact on how the Company reviews and summarizes sales of geographical components within a segment. The Company has updated the sales of geographical components of the Water Systems segment from prior year to

[0000038725-19-000185:notes:84]
align with current management reporting.  The changes resulted in sales reclassifications from Latin America, Asia Pacific, and Europe, Middle East, and Africa ("EMEA") to the U.S. and Canada for both the second quarter and six months ended June 30, 2018. This resulted in $3.5 million and $6.6 million of sales to be reclassified to the U.S. and Canada for the second quarter and six months ended June 30, 2018, respectively.  There is no impact on the Company's previously reported consolidated financial position, results of operations, or cash flows.

[0000038725-19-000185:notes:85]
[same as prior period, unchanged from 0000038725-19-000118:notes:79]

[0000038725-19-000185:notes:86]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions) | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 103.1 |  |  | $ | 98.3 |  |  | $ | 189.9 |  |  | $ | 183.0 |  |
| Latin America | 29.4 |  |  | 28.9 |  |  | 59.9 |  |  | 58.0 |  |
| Europe, Middle East & Africa | 39.0 |  |  | 45.2 |  |  | 76.7 |  |  | 91.4 |  |
| Asia Pacific | 18.7 |  |  | 19.0 |  |  | 40.9 |  |  | 39.8 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 14.8 |  |  | 20.0 |  |  | 26.0 |  |  | 31.8 |  |
| Total sales | 205.0 |  |  | 211.4 |  |  | 393.4 |  |  | 404.0 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |  |  |  |  |
| United States & Canada | 87.1 |  |  | 79.5 |  |  | 140.4 |  |  | 135.7 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 87.1 |  |  | 79.5 |  |  | 140.4 |  |  | 135.7 |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 45.9 |  |  | 37.5 |  |  | 81.1 |  |  | 69.5 |  |
| All other | 32.1 |  |  | 35.6 |  |  | 57.2 |  |  | 62.2 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 78.0 |  |  | 73.1 |  |  | 138.3 |  |  | 131.7 |  |
| Intersegment Eliminations/Other | (14.8 | ) |  | (20.0 | ) |  | (26.0 | ) |  | (31.8 | ) |
| Consolidated | $ | 355.3 |  |  | $ | 344.0 |  |  | $ | 646.1 |  |  | $ | 639.6 |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
|  | Operating income/(loss) |
| Water Systems | $ | 30.9 |  |  | $ | 32.2 |  |  | $ | 50.1 |  |  | $ | 57.3 |  |
| Distribution | 4.5 |  |  | 4.0 |  |  | 0.2 |  |  | 3.2 |  |
| Fueling Systems | 21.7 |  |  | 19.0 |  |  | 34.0 |  |  | 32.7 |  |
| Intersegment Eliminations/Other | (13.4 | ) |  | (14.7 | ) |  | (28.5 | ) |  | (30.0 | ) |
| Consolidated | $ | 43.7 |  |  | $ | 40.5 |  |  | $ | 55.8 |  |  | $ | 63.2 |  |

[0000038725-19-000185:notes:87]
|  | June 30, 2019 |  | December 31, 2018 |
|  | Total assets |
| Water Systems | $ | 707.5 |  |  | $ | 679.7 |  |
| Distribution | 204.9 |  |  | 165.1 |  |
| Fueling Systems | 299.6 |  |  | 275.7 |  |
| Other | 57.7 |  |  | 61.9 |  |
| Consolidated | $ | 1,269.7 |  |  | $ | 1,182.4 |  |

[0000038725-19-000185:notes:88]
[same as prior period, unchanged from 0000038725-19-000118:notes:82]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-19-000185:notes:89]
COMMITMENTS AND CONTINGENCIES
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-19-000185:notes:90]
At June 30, 2019, the Company had $9.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-19-000185:notes:91]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-19-000185:notes:92]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2019, are as follows:

[0000038725-19-000185:notes:93]
| (In millions) |  |  |
| Balance as of December 31, 2018 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 5.1 |  |
| Additions related to acquisitions |  | 0.2 |  |
| Reductions for payments made |  | (5.4 | ) |
| Balance as of June 30, 2019 |  | $ | 8.9 |  |

[0000038725-19-000185:notes:94]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. These financing leases are immaterial to the Company.

[0000038725-19-000185:notes:95]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilized its incremental borrowing rate based on the information available as of the adoption of ASU 2016-02 or at the inception of any new leases entered into thereafter when determining the present value of future lease payments.

[0000038725-19-000185:notes:96]
Some of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.

[0000038725-19-000185:notes:97]
The components of the Company’s operating lease portfolio for both the second quarter and the six months ended June 30, 2019 are as follows:

[0000038725-19-000185:notes:98]
| Lease Cost (in millions): | Second Quarter Ended |  | Sixth Months Ended |
| Operating lease cost | $ | 2.4 |  |  | $ | 5.2 |  |
| Short-term lease cost | — |  |  | 0.1 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 6 years |  |
| Weighted-average discount rate |  |  | 3.9 | % |

[0000038725-19-000185:notes:99]
The minimum rental payments for non-cancellable operating leases as of June 30, 2019, are as follows:

[0000038725-19-000185:notes:100]
| (In millions) | 2019 | 2020 | 2021 | 2022 | 2023 | Thereafter |
| Future Minimum Rental Payments | $ | 4.8 |  | $ | 7.9 |  | $ | 5.4 |  | $ | 3.4 |  | $ | 2.3 |  | $ | 5.8 |  |

[0000038725-19-000185:notes:101]
The minimum rental payments for non-cancellable operating leases as of December 31, 2018, were reported as follows:

[0000038725-19-000185:notes:102]
| (In millions) | 2019 | 2020 | 2021 | 2022 | 2023 | Thereafter |
| Future Minimum Rental Payments | $ | 8.9 |  | $ | 5.9 |  | $ | 3.5 |  | $ | 2.0 |  | $ | 1.1 |  | $ | 5.7 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-19-000185:notes:103]
[same as prior period, unchanged from 0000038725-19-000118:notes:98]

[0000038725-19-000185:notes:104]
[same as prior period, unchanged from 0000038725-19-000118:notes:99]

[0000038725-19-000185:notes:105]
[same as prior period, unchanged from 0000038725-19-000118:notes:100]

[0000038725-19-000185:notes:106]
[same as prior period, unchanged from 0000038725-19-000118:notes:101]

[0000038725-19-000185:notes:107]
[same as prior period, unchanged from 0000038725-19-000118:notes:102]

[0000038725-19-000185:notes:108]
[same as prior period, unchanged from 0000038725-19-000118:notes:103]

[0000038725-19-000185:notes:109]
[same as prior period, unchanged from 0000038725-19-000118:notes:104]

[0000038725-19-000185:notes:110]
[same as prior period, unchanged from 0000038725-19-000118:notes:105]

[0000038725-19-000185:notes:111]
[same as prior period, unchanged from 0000038725-19-000118:notes:106]

[0000038725-19-000185:notes:112]
[same as prior period, unchanged from 0000038725-19-000118:notes:107]

[0000038725-19-000185:notes:113]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the six months ended June 30, 2019 and June 30, 2018 are as follows:

[0000038725-19-000185:notes:114]
|  |  | June 30, 2019 |  | June 30, 2018 |
| Risk-free interest rate |  | 2.53 | % |  | 2.69 | % |
| Dividend yield |  | 1.05 | % |  | 1.05 | % |
| Volatility factor |  | 29.38 | % |  | 28.71 | % |
| Expected term |  | 5.5 years |  |  | 5.6 years |  |

[0000038725-19-000185:notes:115]
A summary of the Company’s outstanding stock option activity and related information for the six months ended June 30, 2019 is as follows:

[0000038725-19-000185:notes:116]
| (Shares in thousands) |  | June 30, 2019 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,229 |  |  | $ | 33.25 |  |
| Granted |  | 190 |  |  | 55.16 |  |
| Exercised |  | (68 | ) |  | 21.99 |  |
| Forfeited |  | (2 | ) |  | 42.77 |  |
| Outstanding at end of period |  | 1,349 |  |  | $ | 36.89 |  |
| Expected to vest after applying forfeiture rate |  | 1,342 |  |  | $ | 36.84 |  |
| Vested and exercisable at end of period |  | 830 |  |  | $ | 31.90 |  |

[0000038725-19-000185:notes:117]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of June 30, 2019 is as follows:

[0000038725-19-000185:notes:118]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 6.31 years |  | $ | 15,768 |  |
| Expected to vest after applying forfeiture rate |  | 6.30 years |  | $ | 15,731 |  |
| Vested and exercisable at end of period |  | 4.86 years |  | $ | 12,945 |  |

[0000038725-19-000185:notes:119]
The total intrinsic value of options exercised during the six months ended June 30, 2019 and June 30, 2018 was $2.1 million and $2.0 million, respectively.

[0000038725-19-000185:notes:120]
As of June 30, 2019, there was $2.0 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 1.93 years.

[0000038725-19-000185:notes:121]
[same as prior period, unchanged from 0000038725-19-000118:notes:116]

[0000038725-19-000185:notes:122]
A summary of the Company’s restricted stock/stock unit award activity and related information for the six months ended June 30, 2019 is as follows:

[0000038725-19-000185:notes:123]
| (Shares in thousands) |  | June 30, 2019 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 498 |  |  | $ | 37.27 |  |
| Awarded |  | 136 |  |  | 51.59 |  |
| Vested |  | (133 | ) |  | 33.64 |  |
| Forfeited |  | (9 | ) |  | 38.80 |  |
| Non-vested at end of period |  | 492 |  |  | $ | 42.19 |  |

[0000038725-19-000185:notes:124]
As of June 30, 2019, there was $11.3 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 1.73 years.
