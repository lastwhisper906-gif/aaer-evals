# FELE note change history — 0000038725-19-000118 → 0000038725-19-000185


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-07-30):
[0000038725-19-000185:note_history:1]
At June 30, 2019, the Company had $9.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2019-04-30, similarity 0.9689):
[0000038725-19-000118:note_history:1]
At March 31, 2019, the Company had $7.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2019-07-30):
[0000038725-19-000185:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2019, are as follows:
  (was, 2019-04-30, similarity 0.9118):
[0000038725-19-000118:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2019, are as follows:

- changed (2019-07-30):
[0000038725-19-000185:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2018 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 5.1 |  |
| Additions related to acquisitions |  | 0.2 |  |
| Reductions for payments made |  | (5.4 | ) |
| Balance as of June 30, 2019 |  | $ | 8.9 |  |
  (was, 2019-04-30, similarity 0.9816):
[0000038725-19-000118:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2018 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 2.5 |  |
| Additions related to acquisitions |  | 0.2 |  |
| Reductions for payments made |  | (2.9 | ) |
| Balance as of March 31, 2019 |  | $ | 8.8 |  |

- changed (2019-07-30):
[0000038725-19-000185:note_history:4]
The components of the Company’s operating lease portfolio for both the second quarter and the six months ended June 30, 2019 are as follows:
  (was, 2019-04-30, similarity 0.8065):
[0000038725-19-000118:note_history:4]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2019 are as follows:

- changed (2019-07-30):
[0000038725-19-000185:note_history:5]
| Lease Cost (in millions): | Second Quarter Ended |  | Sixth Months Ended |
| Operating lease cost | $ | 2.4 |  |  | $ | 5.2 |  |
| Short-term lease cost | — |  |  | 0.1 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 6 years |  |
| Weighted-average discount rate |  |  | 3.9 | % |
  (was, 2019-04-30, similarity 0.8674):
[0000038725-19-000118:note_history:5]
| Lease Cost (in millions): |  |  |
| Operating lease cost |  | $ | 2.8 |  |
| Short-term lease cost |  | 0.1 |  |
| Other Information: |  |  |
| Weighted-average remaining lease term |  | 6 years |  |
| Weighted-average discount rate |  | 4.4 | % |

- changed (2019-07-30):
[0000038725-19-000185:note_history:6]
The minimum rental payments for non-cancellable operating leases as of June 30, 2019, are as follows:
  (was, 2019-04-30, similarity 0.9529):
[0000038725-19-000118:note_history:6]
The minimum rental payments for non-cancellable operating leases as of March 31, 2019, are as follows:

- removed (2019-07-30):
[0000038725-19-000118:note_history:7]
As of March 31, 2019 the Company has approximately $1.4 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-07-30):
[0000038725-19-000185:note_history:8]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2018, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2019, and for the second quarters and six months ended June 30, 2019 and June 30, 2018 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the second quarter and six months ended June 30, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2019.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2018.
  (was, 2019-04-30, similarity 0.9428):
[0000038725-19-000118:note_history:8]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2018, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2019, and for the first quarters ended March 31, 2019 and March 31, 2018 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the first quarter ended March 31, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2019.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2018.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-07-30):
[0000038725-19-000185:note_history:9]
| (In millions) |  | June 30, 2019 |  | December 31, 2018 |
| Prudential Agreement |  | $ | — |  |  | $ | 30.0 |  |
| Tax increment financing debt |  | 19.3 |  |  | 19.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 123.3 |  |  | 76.3 |  |
| Financing Leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 5.5 |  |  | 5.4 |  |
| Less: unamortized debt issuance costs |  | (0.2 | ) |  | (0.2 | ) |
|  |  | $ | 223.0 |  |  | $ | 206.4 |  |
| Less: current maturities |  | (129.3 | ) |  | (112.0 | ) |
| Long-term debt |  | $ | 93.7 |  |  | $ | 94.4 |  |
  (was, 2019-04-30, similarity 0.9889):
[0000038725-19-000118:note_history:9]
| (In millions) |  | March 31, 2019 |  | December 31, 2018 |
| Prudential Agreement |  | $ | 30.0 |  |  | $ | 30.0 |  |
| Tax increment financing debt |  | 19.3 |  |  | 19.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 95.7 |  |  | 76.3 |  |
| Financing Leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 5.8 |  |  | 5.4 |  |
| Less: unamortized debt issuance costs |  | (0.1 | ) |  | (0.2 | ) |
|  |  | $ | 225.8 |  |  | $ | 206.4 |  |
| Less: current maturities |  | (132.0 | ) |  | (112.0 | ) |
| Long-term debt |  | $ | 93.8 |  |  | $ | 94.4 |  |

- changed (2019-07-30):
[0000038725-19-000185:note_history:10]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2019 matures as follows:
  (was, 2019-04-30, similarity 0.9514):
[0000038725-19-000118:note_history:10]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2019 matures as follows:

- added (2019-07-30):
[0000038725-19-000185:note_history:11]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Company paid the remaining principal balance of the previously issued notes during the second quarter of 2019.  As of June 30, 2019, the Company has $150.0 million borrowing capacity available under the Prudential Agreement. There is no additional borrowing capacity resulting from principal payments made by the Company.

- changed (2019-07-30):
[0000038725-19-000185:note_history:12]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of June 30, 2019, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.
  (was, 2019-04-30, similarity 0.9231):
[0000038725-19-000118:note_history:12]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As

- added (2019-07-30):
[0000038725-19-000185:note_history:13]
As of June 30, 2019, the Company had $123.3 million in outstanding borrowings which were primarily used for working capital needs and the payment of existing indebtedness, $5.0 million in letters of credit outstanding, and $171.7 million of available capacity under the Credit Agreement.

- added (2019-07-30):
[0000038725-19-000185:note_history:14]
Covenants

- changed (2019-07-30):
[0000038725-19-000185:note_history:15]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2019.
  (was, 2019-04-30, similarity 0.992):
[0000038725-19-000118:note_history:15]
Covenants
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2019.

- removed (2019-07-30):
[0000038725-19-000118:note_history:16]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of March 31, 2019, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

- removed (2019-07-30):
[0000038725-19-000118:note_history:17]
of March 31, 2019, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

- removed (2019-07-30):
[0000038725-19-000118:note_history:18]
As of March 31, 2019, the Company had $95.7 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $3.7 million in letters of credit outstanding, and $200.6 million of available capacity under the Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-07-30):
[0000038725-19-000185:note_history:19]
| (In millions) |  | June 30, 2019 |  | December 31, 2018 |
| Prudential Agreement |  | $ | — |  |  | $ | 30.0 |  |
| Tax increment financing debt |  | 19.3 |  |  | 19.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 123.3 |  |  | 76.3 |  |
| Financing Leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 5.5 |  |  | 5.4 |  |
| Less: unamortized debt issuance costs |  | (0.2 | ) |  | (0.2 | ) |
|  |  | $ | 223.0 |  |  | $ | 206.4 |  |
| Less: current maturities |  | (129.3 | ) |  | (112.0 | ) |
| Long-term debt |  | $ | 93.7 |  |  | $ | 94.4 |  |
  (was, 2019-04-30, similarity 0.9889):
[0000038725-19-000118:note_history:19]
| (In millions) |  | March 31, 2019 |  | December 31, 2018 |
| Prudential Agreement |  | $ | 30.0 |  |  | $ | 30.0 |  |
| Tax increment financing debt |  | 19.3 |  |  | 19.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 95.7 |  |  | 76.3 |  |
| Financing Leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 5.8 |  |  | 5.4 |  |
| Less: unamortized debt issuance costs |  | (0.1 | ) |  | (0.2 | ) |
|  |  | $ | 225.8 |  |  | $ | 206.4 |  |
| Less: current maturities |  | (132.0 | ) |  | (112.0 | ) |
| Long-term debt |  | $ | 93.8 |  |  | $ | 94.4 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-07-30):
[0000038725-19-000185:note_history:20]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2019 matures as follows:
  (was, 2019-04-30, similarity 0.9514):
[0000038725-19-000118:note_history:20]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2019 matures as follows:
