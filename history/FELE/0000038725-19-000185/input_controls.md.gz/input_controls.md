# FELE 10-Q controls and the auditor's report


## item_4_controls

[0000038725-19-000185:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000038725-19-000185:item_4_controls:2]
As of the end of the period covered by this report (the "Evaluation Date"), the Company carried out an evaluation, under the supervision and with the participation of the Company's management, including the Company's Chief Executive Officer and the Company's Chief Financial Officer, of the effectiveness of the design and operation of the Company's disclosure controls and procedures pursuant to Exchange Act Rules 13a-15.  Based upon that evaluation, the Company's Chief Executive Officer and the Company's Chief Financial Officer concluded that, as of the Evaluation Date, the Company's disclosure controls and procedures were effective.

[0000038725-19-000185:item_4_controls:3]
In the third quarter of 2016, the Company began the process of a multi-year implementation of a global enterprise resource planning (“ERP”) system.  The new ERP system was designed to better support the Company's business needs in response to the changing operating environment and for many business units within the Company is an update to a legacy system product.  The implementation of a worldwide ERP system affects the processes that constitute the Company's internal control over financial reporting and requires testing for effectiveness as the implementation progresses. The Company expects that the new ERP system will enhance the overall system of internal controls over financial reporting through further automation and integration of business processes, although it is not being implemented in response to any identified deficiency in the Company’s internal controls over financial reporting.  The Conversion will happen in two stages. The first stage involved converting the primary legacy ERP system. As of the quarter ended, all business units previously on the primary legacy system have converted to the new ERP system. The second stage will convert those companies that remained on their local ERP system after the date of acquisition. The second stage is ongoing as of June 30, 2019.

[0000038725-19-000185:item_4_controls:4]
Other than the ERP implementation, there have been no changes in the Company's internal control over financial reporting identified in connection with the evaluation required by Rules 13a-15 under the Exchange Act during the last fiscal quarter that have materially affected, or are reasonably likely to materially affect the Company's internal control over financial reporting.

[0000038725-19-000185:item_4_controls:5]
33
