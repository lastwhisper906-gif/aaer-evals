# FELE 8-K — 0000038725-19-000178 filed 2019-07-23

## item codes, every 8-K on or before 2019-07-30

- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2019-07-30

- none on or before 2019-07-30

## item 2.02 — earnings release, exhibit 99.1

[0000038725-19-000178:8k_2_02:1]
EX-99.1
2
a201907238-kexhibit991.htm
EXHIBIT 99.1

[0000038725-19-000178:8k_2_02:2]
Exhibit

[0000038725-19-000178:8k_2_02:3]
Exhibit 99.1

[0000038725-19-000178:8k_2_02:4]
For Immediate Release

[0000038725-19-000178:8k_2_02:5]
For Further Information

[0000038725-19-000178:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-19-000178:8k_2_02:7]
260-824-2900

[0000038725-19-000178:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS RECORD SECOND

[0000038725-19-000178:8k_2_02:9]
QUARTER 2019 SALES AND EARNINGS

[0000038725-19-000178:8k_2_02:10]
Fort Wayne, IN - July 23, 2019 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported record second quarter 2019 GAAP fully diluted earnings per share (EPS) of $0.70, versus a GAAP fully diluted EPS in the second quarter 2018 of $0.64.  Second quarter 2019 sales were a record $355.3 million, compared to 2018 second quarter sales of $344.0 million. Second quarter EPS before the impact of restructuring expenses was also $0.70 compared to 2018 second quarter EPS before restructuring of $0.65 (see table below for a reconciliation of GAAP EPS to EPS before restructuring).

[0000038725-19-000178:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-19-000178:8k_2_02:12]
“Overall, our second quarter results were a record for any quarter in the Company’s history.  Sales of Pioneer branded dewatering equipment increased by about 9 percent in the second quarter when compared to the prior year and our Fueling Systems organic revenue growth was about 7 percent. However, in the U.S. and Canada, sales of groundwater products, by both our Water Systems and Distribution segments, continue to be adversely impacted by the record precipitation during the first half of the year.  Our operating income before restructuring expenses grew by 7 percent and our earnings per share before restructuring expenses grew by 8 percent.”

[0000038725-19-000178:8k_2_02:13]
Key Performance Indicators:

[0000038725-19-000178:8k_2_02:14]
| Earnings Before and After Restructuring |  | For the Second Quarter |  |
| (in millions) |  | 2019 | 2018 | Change |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 32.7 |  | $ | 30.5 |  | 7 | % |  |
| Allocated Earnings |  | $ | (0.2 | ) | $ | (0.2 | ) |  |  |
| Earnings for EPS Calculations |  | $ | 32.5 |  | $ | 30.3 |  | 7 | % |  |
| Restructuring (before tax): |  | $ | 0.2 |  | $ | 0.6 |  |  |  |
| Restructuring, net of tax: |  | $ | 0.2 |  | $ | 0.5 |  |  |  |
| Earnings Before Restructuring |  | $ | 32.7 |  | $ | 30.8 |  | 6 | % |  |
| Earnings Per Share |  | For the Second Quarter |  |
| Before and After Restructuring |  | 2019 | 2018 | Change |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.7 |  | 47.0 |  | (1 | )% |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.70 |  | $ | 0.64 |  | 9 | % |  |
| Restructuring Per Share, net of tax |  | $ | — |  | $ | 0.01 |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.70 |  | $ | 0.65 |  | 8 | % |  |

[0000038725-19-000178:8k_2_02:15]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q2 2018 | $ | 118.3 |  | $ | 28.9 |  | $ | 45.2 |  | $ | 19.0 |  | $ | 211.4 |  | $ | 73.1 |  | $ | 79.5 |  | $ | (20.0 | ) | $ | 344.0 |  |
| Q2 2019 | $ | 117.9 |  | $ | 29.4 |  | $ | 39.0 |  | $ | 18.7 |  | $ | 205.0 |  | $ | 78.0 |  | $ | 87.1 |  | $ | (14.8 | ) | $ | 355.3 |  |
| Change | $ | (0.4 | ) | $ | 0.5 |  | $ | (6.2 | ) | $ | (0.3 | ) | $ | (6.4 | ) | $ | 4.9 |  | $ | 7.6 |  | $ | 5.2 |  | $ | 11.3 |  |
| % Change | — | % | 2 | % | (14 | )% | (2 | )% | (3 | )% | 7 | % | 10 | % |  | 3 | % |
| Foreign currency translation | $ | (1.2 | ) | $ | (1.3 | ) | $ | (5.9 | ) | $ | (0.3 | ) | $ | (8.7 | ) | $ | (1.6 | ) | $ | — |  |  |  |
| % Change | (1 | )% | (4 | )% | (13 | )% | (2 | )% | (4 | )% | (2 | )% | — | % |  |  |
| Acquisitions | $ | — |  | $ | 3.3 |  | $ | — |  | $ | — |  | $ | 3.3 |  | $ | 1.7 |  | $ | 7.0 |  |  |  |
| Volume/Price | $ | 0.8 |  | $ | (1.5 | ) | $ | (0.3 | ) | $ | — |  | $ | (1.0 | ) | $ | 4.8 |  | $ | 0.6 |  |  |  |
| % Change | 1 | % | (5 | )% | (1 | )% | — | % | — | % | 7 | % | 1 | % |  |  |

[0000038725-19-000178:8k_2_02:16]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Second Quarter 2019 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 30.9 |  | $ | 21.7 |  | $ | 4.5 |  | $ | (13.4 | ) | $ | 43.7 |  |
| % Operating Income To Net Sales | 15.1 | % | 27.8 | % | 5.2 | % |  | 12.3 | % |
| Restructuring | $ | — |  | $ | — |  | $ | 0.2 |  |  | $ | 0.2 |  |
| Operating Income/(Loss) Before Restructuring | $ | 30.9 |  | $ | 21.7 |  | $ | 4.7 |  | $ | (13.4 | ) | $ | 43.9 |  |
| % Operating Income to Net Sales Before Restructuring | 15.1 | % | 27.8 | % | 5.4 | % |  | 12.4 | % |
|  | For the Second Quarter 2018 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 32.2 |  | $ | 19.0 |  | $ | 4.0 |  | $ | (14.7 | ) | $ | 40.5 |  |
| % Operating Income To Net Sales | 15.2 | % | 26.0 | % | 5.0 | % |  | 11.8 | % |
| Restructuring | $ | 0.4 |  | $ | 0.2 |  | $ | — |  |  | $ | 0.6 |  |
| Operating Income/(Loss) Before Restructuring | $ | 32.6 |  | $ | 19.2 |  | $ | 4.0 |  | $ | (14.7 | ) | $ | 41.1 |  |
| % Operating Income to Net Sales Before Restructuring | 15.4 | % | 26.3 | % | 5.0 | % |  | 11.9 | % |

[0000038725-19-000178:8k_2_02:17]
Water Systems

[0000038725-19-000178:8k_2_02:18]
Water Systems sales were $205.0 million in the second quarter 2019, versus the second quarter 2018 sales of $211.4 million.  In the second quarter of 2019, sales from businesses acquired since the second quarter of 2018 were $3.3 million.  Water Systems sales decreased about 4 percent in the quarter due to foreign currency translation. Water Systems organic sales were flat compared to the second quarter of 2018.

[0000038725-19-000178:8k_2_02:19]
Water Systems sales in the U.S. and Canada were flat overall compared to the second quarter 2018.  Sales of surface pumping equipment increased by 9 percent on the strength of higher sales of both wastewater and dewatering equipment. Sales of groundwater pumping equipment declined 12 percent versus the second quarter 2018.  The decline in groundwater pumping systems was primarily due to adverse weather conditions in North America and reduced sales to the Company’s Headwater Distribution segment.

[0000038725-19-000178:8k_2_02:20]
Water Systems sales in markets outside the U.S. and Canada declined by 6 percent overall.  Foreign currency translation decreased sales by 8 percent.  Outside the U.S. and Canada, Water Systems organic sales declined by 2 percent, primarily driven by lower sales in Latin America markets outside of Brazil.  In EMEA, sales declined primarily due to foreign currency translation.

[0000038725-19-000178:8k_2_02:21]
Water Systems operating income was $30.9 million in the second quarter 2019, compared to $32.2 million in the second quarter 2018.  Water Systems operating income was lower in the second quarter primarily due to lower sales volume, resulting in lost leverage on fixed costs, and adverse product sales mix.

[0000038725-19-000178:8k_2_02:22]
Fueling Systems

[0000038725-19-000178:8k_2_02:23]
Fueling Systems sales were $78.0 million in the second quarter 2019 compared to second quarter 2018 sales of $73.1 million and were a record for any second quarter.  In the second quarter of 2019, sales from businesses acquired since the second quarter of 2018 were $1.7 million.  Fueling Systems sales decreased 2 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased 7 percent compared to the second quarter of 2018.

[0000038725-19-000178:8k_2_02:24]
Fueling Systems sales in the U.S. and Canada increased by 15 percent compared to the second quarter 2018.  The increase was principally in the fuel pumping systems, underground piping and containment systems and service station hardware product lines.  Outside the U.S. and Canada, Fueling Systems revenues declined by 2 percent, due to lower sales in Europe and Africa partially offset by higher sales in China and other regions.

[0000038725-19-000178:8k_2_02:25]
Fueling Systems operating income was a record for any quarter at $21.7 million in the second quarter of 2019 compared to $19.0 million in the second quarter of 2018.  Fueling Systems operating income was higher in the second quarter due to favorable mix and operating leverage.

[0000038725-19-000178:8k_2_02:26]
Distribution

[0000038725-19-000178:8k_2_02:27]
Distribution sales were $87.1 million in the second quarter 2019, versus second quarter 2018 sales of $79.5 million.  In the second quarter of 2019, sales from businesses acquired since the second quarter of 2018 were $7.0 million.  The Distribution segment organic sales increased 1 percent compared to the second quarter of 2018.

[0000038725-19-000178:8k_2_02:28]
The Distribution segment operating income was $4.5 million in the second quarter of 2019, compared to $4.0 million in the second quarter of 2018.  Operating income before the impact of restructuring expenses

[0000038725-19-000178:8k_2_02:29]
was $4.7 million. Distribution’s operating income was higher in the second quarter due primarily to acquisitions.

[0000038725-19-000178:8k_2_02:30]
Overall

[0000038725-19-000178:8k_2_02:31]
The Company’s consolidated gross profit was $119.7 million for the second quarter of 2019, an increase from the second quarter of 2018 gross profit of $116.1 million.  The gross profit increase was primarily due to higher Fueling Systems sales.  The gross profit as a percent of net sales was 33.7 percent in the second quarter of 2019 and 2018.

[0000038725-19-000178:8k_2_02:32]
Selling, general, and administrative (SG&A) expenses were $75.8 million in the second quarter of 2019 compared to $75.0 million in the second quarter of 2018. SG&A expenses from acquired businesses was $2.8 million and excluding the acquired entities, the Company’s SG&A expenses in the second quarter of 2019 were $73.0 million, a decrease of 3 percent from the second quarter 2018, partially due to the effect of foreign currency translation in the second quarter of 2019 versus the prior year.

[0000038725-19-000178:8k_2_02:33]
Commenting on the outlook for the balance of 2019, Mr. Sengstack said:

[0000038725-19-000178:8k_2_02:34]
“As we look forward to the second half of 2019, we are encouraged by what appears to be a return to more normal weather in the United States, which should positively impact our Water Systems and Distribution segments.  We also see improved demand in several International Water Systems markets.  Additionally, our Fueling Systems business has strong momentum globally.  Despite these positives looking forward, our first half results did not meet our expectations and we do not believe we will be able to achieve our original earnings per share guidance.

[0000038725-19-000178:8k_2_02:35]
We now believe our full year 2019 earnings per share before restructuring charges will be between $2.15 and $2.25, which at its midpoint, would result in a second half 2019 earnings per share before restructuring charges of $1.29, an eleven percent increase over the second half of 2018.”

[0000038725-19-000178:8k_2_02:36]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET.  The first quarter 2019 earnings call will be available via a live webcast.

[0000038725-19-000178:8k_2_02:37]
https://edge.media-server.com/mmc/p/dgjyznjr

[0000038725-19-000178:8k_2_02:38]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 9585257.

[0000038725-19-000178:8k_2_02:39]
A replay of the conference call will be available Tuesday, July 23, 2019 at 12:00 noon Eastern Time through noon Eastern Time on Tuesday, July 30, 2019, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 9585257.

[0000038725-19-000178:8k_2_02:40]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-19-000178:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2019 |  | June 30, 2018 |  | June 30, 2019 |  | June 30, 2018 |
| Net sales | $ | 355,340 |  |  | $ | 343,970 |  |  | $ | 646,055 |  |  | $ | 639,600 |  |
| Cost of sales | 235,622 |  |  | 227,894 |  |  | 436,831 |  |  | 424,542 |  |
| Gross profit | 119,718 |  |  | 116,076 |  |  | 209,224 |  |  | 215,058 |  |
| Selling, general, and administrative expenses | 75,782 |  |  | 74,965 |  |  | 152,081 |  |  | 151,240 |  |
| Restructuring expense | 245 |  |  | 637 |  |  | 1,331 |  |  | 644 |  |
| Operating income | 43,691 |  |  | 40,474 |  |  | 55,812 |  |  | 63,174 |  |
| Interest expense | (2,295 | ) |  | (2,606 | ) |  | (4,637 | ) |  | (5,034 | ) |
| Other income/(expense), net | (292 | ) |  | 45 |  |  | (53 | ) |  | (159 | ) |
| Foreign exchange income/(expense) | (505 | ) |  | (999 | ) |  | 84 |  |  | (1,550 | ) |
| Income before income taxes | 40,599 |  |  | 36,914 |  |  | 51,206 |  |  | 56,431 |  |
| Income tax (benefit)/expense | 7,787 |  |  | 6,875 |  |  | 9,267 |  |  | 5,177 |  |
| Net income | $ | 32,812 |  |  | $ | 30,039 |  |  | $ | 41,939 |  |  | $ | 51,254 |  |
| Less: Net income attributable to noncontrolling interests | (67 | ) |  | 458 |  |  | (138 | ) |  | 417 |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 32,745 |  |  | $ | 30,497 |  |  | $ | 41,801 |  |  | $ | 51,671 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.70 |  |  | $ | 0.65 |  |  | $ | 0.89 |  |  | $ | 1.10 |  |
| Diluted | $ | 0.70 |  |  | $ | 0.64 |  |  | $ | 0.89 |  |  | $ | 1.09 |  |

[0000038725-19-000178:8k_2_02:42]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | June 30, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 40,991 |  |  | $ | 59,173 |  |
| Receivables | 220,815 |  |  | 172,899 |  |
| Inventories | 352,383 |  |  | 314,049 |  |
| Other current assets | 34,937 |  |  | 33,758 |  |
| Total current assets | 649,126 |  |  | 579,879 |  |
| Property, plant, and equipment, net | 202,100 |  |  | 207,064 |  |
| Right-of-use asset, net | 25,708 |  |  | — |  |
| Goodwill and other assets | 392,729 |  |  | 395,422 |  |
| Total assets | $ | 1,269,663 |  |  | $ | 1,182,365 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 99,654 |  |  | $ | 76,652 |  |
| Accrued expenses and other current liabilities | 63,760 |  |  | 67,230 |  |
| Current lease liability | 8,605 |  |  | — |  |
| Current maturities of long-term debt and short-term borrowings | 129,337 |  |  | 111,975 |  |
| Total current liabilities | 301,356 |  |  | 255,857 |  |
| Long-term debt | 93,707 |  |  | 94,379 |  |
| Long-term lease liability | 17,105 |  |  | — |  |
| Income taxes payable non-current | 10,881 |  |  | 10,881 |  |
| Deferred income taxes | 29,815 |  |  | 28,949 |  |
| Employee benefit plans | 36,523 |  |  | 38,020 |  |
| Other long-term liabilities | 19,584 |  |  | 17,934 |  |
| Redeemable noncontrolling interest | (210 | ) |  | 518 |  |
| Total equity | 760,902 |  |  | 735,827 |  |
| Total liabilities and equity | $ | 1,269,663 |  |  | $ | 1,182,365 |  |

[0000038725-19-000178:8k_2_02:43]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Six Months Ended |
| (In thousands) | June 30, 2019 |  | June 30, 2018 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 41,939 |  |  | $ | 51,254 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 18,350 |  |  | 19,595 |  |
| Non-Cash Lease Expense | 5,199 |  |  |  |
| Share-based compensation | 5,524 |  |  | 4,769 |  |
| Other | 1,011 |  |  | (3,083 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (46,371 | ) |  | (40,812 | ) |
| Inventory | (35,318 | ) |  | (20,614 | ) |
| Accounts payable and accrued expenses | 18,637 |  |  | (1,072 | ) |
| Operating Leases | (5,195 | ) |  | — |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | 369 |  |  | (4,600 | ) |
| Other | — |  |  | (268 | ) |
| Net cash flows from operating activities | 4,145 |  |  | 5,169 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (10,444 | ) |  | (11,446 | ) |
| Proceeds from sale of property, plant, and equipment | 866 |  |  | 306 |  |
| Acquisitions and investments | (6,728 | ) |  | (8,428 | ) |
| Other investing activities | 8 |  |  | 199 |  |
| Net cash flows from investing activities | (16,298 | ) |  | (19,369 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 16,814 |  |  | 37,333 |  |
| Proceeds from issuance of common stock | 1,495 |  |  | 1,795 |  |
| Purchases of common stock | (9,543 | ) |  | (10,953 | ) |
| Dividends paid | (13,510 | ) |  | (10,658 | ) |
| Purchase of redeemable non-controlling shares | (485 | ) |  | — |  |
| Net cash flows from financing activities | (5,229 | ) |  | 17,517 |  |
| Effect of exchange rate changes on cash | (800 | ) |  | (506 | ) |
| Net change in cash and equivalents | (18,182 | ) |  | 2,811 |  |
| Cash and equivalents at beginning of period | 59,173 |  |  | 67,233 |  |
| Cash and equivalents at end of period | $ | 40,991 |  |  | $ | 70,044 |  |

[0000038725-19-000178:8k_2_02:44]
ending December 31, 2018, Exhibit 99.1 attached thereto and in Item 1A of Part II of the Company’s Quarterly Reports on Form 10-Q. These risks and uncertainties may cause actual results to differ materially from those indicated by the forward-looking statements. All forward-looking statements made herein are based on information currently available, and the Company assumes no obligation to update any forward-looking statements.
