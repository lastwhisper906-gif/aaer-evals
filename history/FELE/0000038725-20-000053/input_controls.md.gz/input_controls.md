# FELE 10-K controls and the auditor's report


## auditors_report

[0000038725-20-000053:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000038725-20-000053:auditors_report:2]
To the Shareholders and the Board of Directors of Franklin Electric Co., Inc.

[0000038725-20-000053:auditors_report:3]
Fort Wayne, Indiana

[0000038725-20-000053:auditors_report:4]
Opinion on the Financial Statements

[0000038725-20-000053:auditors_report:5]
We have audited the accompanying consolidated balance sheets of Franklin Electric Co., Inc. and subsidiaries (the "Company") as of December 31, 2019 and 2018, the related consolidated statements of income, comprehensive income, equity, and cash flows, for each of the three years in the period ended December 31, 2019, and the related notes and the schedule listed in the Index at Item 15 (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of December 31, 2019 and 2018, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2019, in conformity with accounting principles generally accepted in the United States of America.

[0000038725-20-000053:auditors_report:6]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of December 31, 2019, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated February 25, 2020, expressed an unqualified opinion on the Company's internal control over financial reporting.

[0000038725-20-000053:auditors_report:7]
Basis for Opinion

[0000038725-20-000053:auditors_report:8]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000038725-20-000053:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0000038725-20-000053:auditors_report:10]
Critical Audit Matter

[0000038725-20-000053:auditors_report:11]
The critical audit matter communicated below is a matter arising from the current-period audit of the financial statements that was communicated or required to be communicated to the audit committee and that (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000038725-20-000053:auditors_report:12]
Goodwill — Distribution Reporting Unit — Refer to Notes 1 and 6 to the financial statements

[0000038725-20-000053:auditors_report:13]
Critical Audit Matter Description

[0000038725-20-000053:auditors_report:14]
The Company’s evaluation of goodwill for impairment involves the comparison of the fair value of each reporting unit to its carrying value. The Company determines the fair value of its reporting units by utilizing a combination of both the income and market valuation approaches. The income approach estimates fair value based upon future revenue, expenses, and cash flows discounted to present value. The market valuation approach estimates fair value using market multipliers of various financial measures compared to a set of comparable public companies. The determination of the fair value by the income approach using the discounted cash flow analysis requires management to make significant assumptions and estimates related to forecasts of future revenues and operating margins and discount rates. The Company may be required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units is below their associated carrying values. The Company’s goodwill balance was $256.1 million at December 31, 2019, including $37.5 million of goodwill associated with the Distribution Reporting Unit (“Distribution”). The fair value of the Distribution reporting unit exceeded its carrying value as of the measurement date and, therefore, no impairment was recognized.

[0000038725-20-000053:auditors_report:15]
We identified goodwill of the Distribution reporting unit is a critical audit matter because of the significant judgments made by management when developing the fair value measurement of the Distribution reporting unit. This led to a high degree of auditor judgment and an increased extent of effort when performing audit procedures and evaluating audit evidence obtained relating to management’s forecasts of future revenue and operating margin and determination of the discount rate used in the income approach for determining fair value of the Distribution reporting unit.

[0000038725-20-000053:auditors_report:16]
How the Critical Audit Matter Was Addressed in the Audit

[0000038725-20-000053:auditors_report:17]
Our audit procedures related to the Company’s forecasts of future revenues and operating margins and the Company’s determination of the discount rate for the Distribution reporting unit included the following, among others:

[0000038725-20-000053:auditors_report:18]
61

[0000038725-20-000053:auditors_report:19]
•We tested the effectiveness of internal controls over goodwill, including those over management’s forecasts of future revenues and operating margins, and the determination of the discount rate.

[0000038725-20-000053:auditors_report:20]
•We evaluated management’s ability to accurately forecast future revenues and operating margins by comparing actual results to management’s historical forecasts.

[0000038725-20-000053:auditors_report:21]
•We evaluated the reasonableness of management’s revenue and operating margin forecasts by comparing the forecasts to:

[0000038725-20-000053:auditors_report:22]
◦Historical revenues and operating margins.

[0000038725-20-000053:auditors_report:23]
◦Internal communications to management and the Board of Directors.

[0000038725-20-000053:auditors_report:24]
◦Forecasted information included in Company’s press releases as well as in analyst and industry reports for the Company and certain of its peer companies.

[0000038725-20-000053:auditors_report:25]
◦Publicly available information about companies considered to be comparable.

[0000038725-20-000053:auditors_report:26]
•We evaluated the impact of changes in management’s forecasts from the October 1, 2019, annual measurement date to December 31, 2019.

[0000038725-20-000053:auditors_report:27]
•With the assistance of our fair value specialists, we evaluated the reasonableness of the discount rate by:

[0000038725-20-000053:auditors_report:28]
◦Testing the source information underlying the determination of the discount rate and the mathematical accuracy of the calculation.

[0000038725-20-000053:auditors_report:29]
◦Developing a range of independent estimates and comparing those to the discount rate determined by management.

[0000038725-20-000053:auditors_report:30]
/s/DELOITTE & TOUCHE LLP

[0000038725-20-000053:auditors_report:31]
Chicago, Illinois

[0000038725-20-000053:auditors_report:32]
February 25, 2020

[0000038725-20-000053:auditors_report:33]
We have served as the Company’s auditor since 1988.

[0000038725-20-000053:auditors_report:34]
62


## item_9a

[0000038725-20-000053:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0000038725-20-000053:item_9a:2]
As of the end of the period covered by this report (the “Evaluation Date”), the Company carried out an evaluation, under the supervision and with the participation of the Company’s management, including the Company’s Chief Executive Officer and the Company’s Chief Financial Officer, of the effectiveness of the design and operation of the Company’s disclosure controls and procedures pursuant to Exchange Act Rules 13a-15.  Based upon that evaluation, the Company’s Chief Executive Officer and the Company’s Chief Financial Officer concluded that, as of the Evaluation Date, the Company’s disclosure controls and procedures were effective.

[0000038725-20-000053:item_9a:3]
In the third quarter of 2016, the Company began the process of a multi-year implementation of a global enterprise resource planning (“ERP”) system. The new ERP system was designed to better support the Company's business needs in response to the changing operating environment and for many business units within the Company is an update to a legacy system product.  The implementation of a worldwide ERP system affects the processes that constitute the Company's internal control over financial reporting and requires testing for effectiveness as the implementation progresses. The Company expects that the new ERP system will enhance the overall system of internal controls over financial reporting through further automation and integration of business processes, although it is not being implemented in response to any identified deficiency in the Company’s internal controls over financial reporting. The Conversion will happen in two stages. The first stage involved converting the primary legacy ERP system. As of the first quarter of 2018, all business units previously on the primary legacy system have converted to the new ERP system. The second stage will convert those companies that remained on their local ERP system after the date of acquisition. The second stage is ongoing as of December 31, 2019.

[0000038725-20-000053:item_9a:4]
Other than the ERP implementation, there have been no changes in the Company’s internal control over financial reporting identified in connection with the evaluation required by Rules 13a-15 under the Exchange Act during the last fiscal quarter that have materially affected, or are reasonably likely to materially affect the Company’s internal control over financial reporting.

[0000038725-20-000053:item_9a:5]
MANAGEMENT’S REPORT ON INTERNAL CONTROL OVER FINANCIAL REPORTING

[0000038725-20-000053:item_9a:6]
Management is responsible for establishing and maintaining an adequate system of internal control over financial reporting of the Company.  This system is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with accounting principles generally accepted in the United States of America.

[0000038725-20-000053:item_9a:7]
The Company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the financial statements.

[0000038725-20-000053:item_9a:8]
Because of its inherent limitations, internal control over financial reporting can provide only reasonable assurance with respect to financial statement preparation and may not prevent or detect misstatements.  Further, because of changes in conditions, effectiveness of internal controls over financial reporting may vary over time.

[0000038725-20-000053:item_9a:9]
Management conducted an evaluation of the effectiveness of the system of internal control over financial reporting based on the framework in the Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.  Management excluded Milan Supply and First Sales, LLC (Note 3 - Acquisitions) from its assessment of internal controls over financial reporting as these acquisitions occurred in 2019. This exclusion is in accordance with the general guidance from the Staff of the Securities and Exchange Commission that an assessment of a recently acquired business may be omitted from the scope of management’s assessment of internal control over financial reporting for one year following the acquisition.  The net sales and total assets of current year acquisitions represented was approximately 2.1 percent and 2.1 percent, respectively, of the consolidated financial statement amounts as of and for the year ended December 31, 2019.  Based on its evaluation, management concluded that the Company’s system of internal control over financial reporting was effective as of December 31, 2019.

[0000038725-20-000053:item_9a:10]
63

[0000038725-20-000053:item_9a:11]
Our independent registered public accounting firm has issued an audit report on the effectiveness of the Company’s internal control over financial reporting as of December 31, 2019.  This report appears on page 65.

[0000038725-20-000053:item_9a:12]
64

[0000038725-20-000053:item_9a:13]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000038725-20-000053:item_9a:14]
To the Shareholders and the Board of Directors of Franklin Electric Co., Inc.

[0000038725-20-000053:item_9a:15]
Fort Wayne, Indiana

[0000038725-20-000053:item_9a:16]
Opinion on Internal Control over Financial Reporting

[0000038725-20-000053:item_9a:17]
We have audited the internal control over financial reporting of Franklin Electric Co., Inc. and subsidiaries (the “Company”) as of December 31, 2019, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2019, based on criteria established in Internal Control — Integrated Framework (2013) issued by COSO.

[0000038725-20-000053:item_9a:18]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended December 31, 2019, of the Company and our report dated February 25, 2020, expressed, an unqualified opinion on those financial statements.

[0000038725-20-000053:item_9a:19]
As described in Management’s Report on Internal Control over Financial Reporting, management excluded Milan Supply Co. (“Milan Supply”) and First Sales LLC (“First Sales”) from its assessment of internal control over financial reporting as these acquisitions occurred in 2019. The combined net sales and total assets of these acquisitions represented approximately 2.1 percent and 2.1 percent, respectively, of the consolidated financial statement amounts as of and for the year ended December 31, 2019. Accordingly, our audit did not include the internal control over financial reporting at these acquired companies.

[0000038725-20-000053:item_9a:20]
Basis for Opinion

[0000038725-20-000053:item_9a:21]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management's Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000038725-20-000053:item_9a:22]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000038725-20-000053:item_9a:23]
Definition and Limitations of Internal Control over Financial Reporting

[0000038725-20-000053:item_9a:24]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000038725-20-000053:item_9a:25]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000038725-20-000053:item_9a:26]
/s/  DELOITTE & TOUCHE LLP

[0000038725-20-000053:item_9a:27]
Chicago, Illinois

[0000038725-20-000053:item_9a:28]
February 25, 2020

[0000038725-20-000053:item_9a:29]
65
