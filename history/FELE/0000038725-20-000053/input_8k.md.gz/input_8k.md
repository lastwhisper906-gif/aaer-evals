# FELE 8-K — 0000038725-20-000018 filed 2020-02-18

## item codes, every 8-K on or before 2020-02-25

- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2020-02-25

- none on or before 2020-02-25

## item 2.02 — earnings release, exhibit 99.1

[0000038725-20-000018:8k_2_02:1]
EX-99.1
2
a202002188-kexhibit991.htm
EX-99.1

[0000038725-20-000018:8k_2_02:2]
Document

[0000038725-20-000018:8k_2_02:3]
Exhibit 99.1

[0000038725-20-000018:8k_2_02:4]
For Immediate Release

[0000038725-20-000018:8k_2_02:5]
For Further Information

[0000038725-20-000018:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-20-000018:8k_2_02:7]
260-824-2900

[0000038725-20-000018:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS FOURTH QUARTER 2019 SALES AND EARNINGS

[0000038725-20-000018:8k_2_02:9]
Fort Wayne, IN – February 18, 2020 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported fourth quarter 2019 GAAP fully diluted earnings per share (EPS) of $0.42, versus a GAAP fully diluted EPS in the fourth quarter 2018 of $0.51. Fourth quarter 2019 sales were $320.1 million, compared to 2018 fourth quarter sales of $316.7 million. Fourth quarter EPS before the impact of restructuring expenses was $0.43 compared to 2018 fourth quarter EPS before restructuring of $0.52 (see table below for a reconciliation of GAAP EPS to EPS before restructuring).

[0000038725-20-000018:8k_2_02:10]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-20-000018:8k_2_02:11]
“Our fourth quarter operating results were generally in line with our expectations which were to be about the same as the fourth quarter last year.  Our revenue was up 1 percent from last year as we benefited from stronger sales in our Distribution business, our water treatment acquisition and continued strength in Fueling Systems all of which was offset by the expected decline in our dewatering pump systems sales in the quarter. These sales impacts were offset with lower selling, general and administrative expenses and resulted in operating income being flat in the quarter. Our Earnings Per Share decline versus last year’s fourth quarter is entirely due to higher foreign exchange transactional losses that are non-operational in nature and below the operating income line.

[0000038725-20-000018:8k_2_02:12]
In 2019, our team executed well in a tough end market environment. While earnings were below our expectations, our free cash flow conversion of net income increased from 101 percent in 2018 to 163 percent in 2019.”

[0000038725-20-000018:8k_2_02:13]
Key Performance Indicators:

[0000038725-20-000018:8k_2_02:14]
| Earnings Before and After Restructuring |  | For the Fourth Quarter |  |  |  | For the Full Year |  |  |  |  |  |
| (in millions) |  | 2019 | 2018 | Change |  | 2019 | 2018 | Change |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 19.8 |  | $ | 24.2 |  | (18) | % |  | $ | 95.5 |  | $ | 105.9 |  | (10) | % |  |  |  |
| Allocated Earnings |  | $ | (0.2) |  | $ | (0.2) |  |  |  | $ | (0.7) |  | $ | (0.8) |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 19.6 |  | $ | 24.0 |  | (18) | % |  | $ | 94.8 |  | $ | 105.1 |  | (10) | % |  |  |  |
| Restructuring (before tax): |  | $ | 0.8 |  | $ | 0.7 |  |  |  | $ | 2.5 |  | $ | 1.7 |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 0.6 |  | $ | 0.6 |  |  |  | $ | 2.0 |  | $ | 1.4 |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 20.2 |  | $ | 24.6 |  | (18) | % |  | $ | 96.8 |  | $ | 106.5 |  | (9) | % |  |  |  |
| Earnings Per Share |  | For the Fourth Quarter |  |  |  | For the Full Year |  |  |  |  |  |
| Before and After Restructuring |  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.8 |  | 46.8 |  | — | % |  | 46.8 |  | 47.0 |  | — | % |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.42 |  | $ | 0.51 |  | (18) | % |  | $ | 2.03 |  | $ | 2.23 |  | (9) | % |  |  |  |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | 0.01 |  |  |  | $ | 0.04 |  | $ | 0.03 |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.43 |  | $ | 0.52 |  | (17) | % |  | $ | 2.07 |  | $ | 2.26 |  | (8) | % |  |  |  |

[0000038725-20-000018:8k_2_02:15]
|  | Net Sales For the Fourth Quarter |  |  |  |  |  |  |  |  |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q4 2018 | $ | 103.3 |  | $ | 31.2 |  | $ | 38.7 |  | $ | 23.7 |  | $ | 196.9 |  | $ | 75.0 |  | $ | 56.0 |  | $ | (11.2) |  | $ | 316.7 |  |
| Q4 2019 | $ | 92.5 |  | $ | 33.7 |  | $ | 38.1 |  | $ | 23.9 |  | $ | 188.2 |  | $ | 77.3 |  | $ | 64.4 |  | $ | (9.8) |  | $ | 320.1 |  |
| Change | $ | (10.8) |  | $ | 2.5 |  | $ | (0.6) |  | $ | 0.2 |  | $ | (8.7) |  | $ | 2.3 |  | $ | 8.4 |  | $ | 1.4 |  | $ | 3.4 |  |
| % Change | (10) | % | 8 | % | (2) | % | 1 | % | (4) | % | 3 | % | 15 | % |  | 1 | % |
| Foreign currency translation | $ | — |  | $ | (3.7) |  | $ | (1.3) |  | $ | (0.4) |  | $ | (5.4) |  | $ | (0.4) |  | $ | — |  |  |  |
| % Change | — | % | (12) | % | (3) | % | (2) | % | (3) | % | (1) | % | — | % |  |  |
| Acquisitions | $ | 3.1 |  | $ | — |  | $ | — |  | $ | — |  | $ | 3.1 |  | $ | — |  | $ | 4.8 |  |  |  |
| Volume/Price | $ | (13.9) |  | $ | 6.2 |  | $ | 0.7 |  | $ | 0.6 |  | $ | (6.4) |  | $ | 2.7 |  | $ | 3.6 |  |  |  |
| % Change | (13) | % | 20 | % | 2 | % | 3 | % | (3) | % | 4 | % | 6 | % |  |  |

[0000038725-20-000018:8k_2_02:16]
|  | Net Sales For the Full Year |  |  |  |  |  |  |  |  |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| FY 2018 | $ | 428.2 |  | $ | 120.2 |  | $ | 170.9 |  | $ | 80.8 |  | $ | 800.1 |  | $ | 284.6 |  | $ | 269.6 |  | $ | (56.2) |  | $ | 1,298.1 |  |
| FY 2019 | $ | 419.9 |  | $ | 124.2 |  | $ | 155.6 |  | $ | 81.8 |  | $ | 781.5 |  | $ | 293.6 |  | $ | 291.8 |  | $ | (52.3) |  | $ | 1,314.6 |  |
| Change | $ | (8.3) |  | $ | 4.0 |  | $ | (15.3) |  | $ | 1.0 |  | $ | (18.6) |  | $ | 9.0 |  | $ | 22.2 |  | $ | 3.9 |  | $ | 16.5 |  |
| % Change | (2) | % | 3 | % | (9) | % | 1 | % | (2) | % | 3 | % | 8 | % |  | 1 | % |
| Foreign currency translation | $ | (2.5) |  | $ | (10.3) |  | $ | (15.9) |  | $ | (1.8) |  | $ | (30.5) |  | $ | (4.3) |  | $ | — |  |  |  |
| % Change | (1) | % | (9) | % | (9) | % | (2) | % | (4) | % | (2) | % | — | % |  |  |
| Acquisitions | $ | 5.4 |  | $ | 7.6 |  | $ | — |  | $ | — |  | $ | 13.0 |  | $ | 3.2 |  | $ | 21.9 |  |  |  |
| Volume/Price | $ | (11.2) |  | $ | 6.7 |  | $ | 0.6 |  | $ | 2.8 |  | $ | (1.1) |  | $ | 10.1 |  | $ | 0.3 |  |  |  |
| % Change | (3) | % | 6 | % | — | % | 3 | % | — | % | 4 | % | — | % |  |  |

[0000038725-20-000018:8k_2_02:17]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2019 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 24.5 |  | $ | 20.2 |  | $ | (2.5) |  | $ | (13.6) |  | $ | 28.6 |  |
| % Operating Income To Net Sales | 13.0 | % | 26.1 | % | (3.9) | % |  | 8.9 | % |
| Restructuring | $ | 0.8 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.8 |  |
| Operating Income/(Loss) Before Restructuring | $ | 25.3 |  | $ | 20.2 |  | $ | (2.5) |  | $ | (13.6) |  | $ | 29.4 |  |
| % Operating Income to Net Sales Before Restructuring | 13.4 | % | 26.1 | % | (3.9) | % |  | 9.2 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2018 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 27.0 |  | $ | 17.0 |  | $ | (2.9) |  | $ | (12.4) |  | $ | 28.7 |  |
| % Operating Income To Net Sales | 13.7 | % | 22.7 | % | (5.2) | % |  | 9.1 | % |
| Restructuring | $ | 0.1 |  | $ | 0.1 |  | $ | 0.5 |  | $ | — |  | $ | 0.7 |  |
| Operating Income/(Loss) Before Restructuring | $ | 27.1 |  | $ | 17.1 |  | $ | (2.4) |  | $ | (12.4) |  | $ | 29.4 |  |
| % Operating Income to Net Sales Before Restructuring | 13.8 | % | 22.8 | % | (4.3) | % |  | 9.3 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year of 2019 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 103.0 |  | $ | 75.8 |  | $ | 3.6 |  | $ | (55.3) |  | $ | 127.1 |  |
| % Operating Income To Net Sales | 13.2 | % | 25.8 | % | 1.2 | % |  | 9.7 | % |
| Restructuring | $ | 1.7 |  | $ | — |  | $ | 0.8 |  | $ | — |  | $ | 2.5 |  |
| Operating Income/(Loss) Before Restructuring | $ | 104.7 |  | $ | 75.8 |  | $ | 4.4 |  | $ | (55.3) |  | $ | 129.6 |  |
| % Operating Income to Net Sales Before Restructuring | 13.4 | % | 25.8 | % | 1.5 | % |  | 9.9 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year of 2018 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 112.7 |  | $ | 70.6 |  | $ | 3.4 |  | $ | (54.7) |  | $ | 132.0 |  |
| % Operating Income To Net Sales | 14.1 | % | 24.8 | % | 1.3 | % |  | 10.2 | % |
| Restructuring | $ | 0.6 |  | $ | 0.3 |  | $ | 0.8 |  | $ | — |  | $ | 1.7 |  |
| Operating Income/(Loss) Before Restructuring | $ | 113.3 |  | $ | 70.9 |  | $ | 4.2 |  | $ | (54.7) |  | $ | 133.7 |  |
| % Operating Income to Net Sales Before Restructuring | 14.2 | % | 24.9 | % | 1.6 | % |  | 10.3 | % |

[0000038725-20-000018:8k_2_02:18]
Water Systems

[0000038725-20-000018:8k_2_02:19]
Water Systems sales were $188.2 million in the fourth quarter 2019, versus the fourth quarter 2018 sales of $196.9 million.  In the fourth quarter of 2019, sales from businesses acquired since the fourth quarter of 2018 were $3.1 million.  Water Systems sales decreased 3 percent in the quarter due to foreign currency translation. Water Systems organic sales were lower by 3 percent compared to the fourth quarter of 2018.

[0000038725-20-000018:8k_2_02:20]
Water Systems sales in the U.S. and Canada decreased by 10 percent overall compared to the fourth quarter 2018, primarily due to lower sales volumes of dewatering equipment.  Sales of dewatering equipment decreased by nearly 50 percent due to lower sales in rental channels and a surge of sales in the fourth quarter 2018 driven by regulatory demand.  Sales of groundwater pumping equipment increased by 4 percent versus the fourth quarter 2018.  The increase in groundwater pumping systems was primarily due to increased sales of residential water systems. Sales of surface pumping equipment decreased by 5 percent on lower sales of both wastewater and water transfer systems.

[0000038725-20-000018:8k_2_02:21]
Water Systems sales in markets outside the U.S. and Canada increased by 2 percent overall.  Foreign currency translation decreased sales by 6 percent.  Outside the U.S. and Canada, Water Systems organic sales increased by 8 percent, primarily driven by higher sales in Latin America, as well as increased sales in both the Europe, Middle East, and Africa markets, and the Asia Pacific markets.

[0000038725-20-000018:8k_2_02:22]
Water Systems operating income was $24.5 million in the fourth quarter 2019, compared to $27.0 million in the fourth quarter 2018 primarily driven by lower revenues.

[0000038725-20-000018:8k_2_02:23]
Fueling Systems

[0000038725-20-000018:8k_2_02:24]
Fueling Systems sales were $77.3 million in the fourth quarter 2019 compared to fourth quarter 2018 sales of $75.0 million and were a record for any fourth quarter.  Fueling Systems sales decreased 1 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased 4 percent compared to the fourth quarter of 2018.

[0000038725-20-000018:8k_2_02:25]
Fueling Systems sales in the U.S. and Canada increased by 7 percent compared to the fourth quarter 2018.  The increase was principally in the pumping and fuel management systems product lines.  Outside the U.S. and Canada, Fueling Systems revenues were flat, as increased sales in Europe, India and Latin America were offset by lower sales in China.

[0000038725-20-000018:8k_2_02:26]
Fueling Systems operating income was a record for any fourth quarter at $20.2 million compared to $17.0 million in the fourth quarter of 2018.  Fueling Systems operating income was higher in the quarter primarily due to favorable product sales mix.

[0000038725-20-000018:8k_2_02:27]
Distribution

[0000038725-20-000018:8k_2_02:28]
Distribution sales were $64.4 million in the fourth quarter 2019, versus fourth quarter 2018 sales of $56.0 million.  In the fourth quarter of 2019, sales from businesses acquired since the fourth quarter of 2018 were $4.8 million.  The Distribution segment organic sales increased 6 percent compared to the fourth quarter of 2018.

[0000038725-20-000018:8k_2_02:29]
The Distribution segment recorded an operating loss of $2.5 million in the fourth quarter of 2019, compared to a loss of $2.9 million in the fourth quarter of 2018.  Higher product costs not completely offset by price and higher operating expenses contributed to the Distribution segment earnings loss.

[0000038725-20-000018:8k_2_02:30]
Overall

[0000038725-20-000018:8k_2_02:31]
The Company’s consolidated gross profit was $101.3 million for the fourth quarter of 2019, a decrease from the fourth quarter of 2018 gross profit of $104.3 million.  The gross profit decrease was primarily due to lower Water Systems sales volume which more than offset gross profit increases on higher Fueling Systems and Distribution sales volume.  The gross profit as a percent of net sales was 31.6 percent in the fourth quarter of 2019 versus 33.0 percent in the fourth quarter of 2018.

[0000038725-20-000018:8k_2_02:32]
Selling, general, and administrative (SG&A) expenses were $71.9 million in the fourth quarter of 2019 compared to $75.0 million in the fourth quarter of 2018. SG&A expenses from acquired businesses was $1.8 million and excluding the acquired entities, the Company’s SG&A expenses in the fourth quarter of 2019 were $70.1 million, a decrease of 7 percent from the fourth quarter 2018, partially due to lower variable performance based compensation expenses and due to the impact of foreign currency translation reducing expenses versus the prior year.

[0000038725-20-000018:8k_2_02:33]
Transactional foreign exchange losses were $3.8 million in the fourth quarter 2019 versus foreign exchange gains of $2.4 million in the fourth quarter of 2018.  These foreign exchange gains and losses are below operating income, are non-operational in nature, are non-cash, and are not representative of ongoing results of the Company.  The change in foreign exchange gains and losses from the fourth quarter of 2018 represents about $0.11 cents of earnings per share and is primarily the result of the strengthening U.S. dollar compared to currencies in emerging markets, most notably the Argentina Peso.

[0000038725-20-000018:8k_2_02:34]
Commenting on the outlook for 2020, Mr. Sengstack said:

[0000038725-20-000018:8k_2_02:35]
“As we look towards 2020, we feel confident in our ability to grow earnings and sustain operating cash generation in excess of net income while achieving organic growth in our Water Systems and Distribution segments.  Although Fueling Systems global demand remains robust, we expect revenues in this segment to be flat in 2020 due to a significant decline in China.

[0000038725-20-000018:8k_2_02:36]
Here are some of the key assumptions for our 2020 outlook:

[0000038725-20-000018:8k_2_02:37]
•More normal North America precipitation rates than the record levels seen in 2019

[0000038725-20-000018:8k_2_02:38]
•Organic Growth, net of foreign exchange, of about 5 to 7 percent in Water Systems and Distribution, but flat in Fueling Systems

[0000038725-20-000018:8k_2_02:39]
•Free Cash Flow conversion of net income between 120 percent and 140 percent

[0000038725-20-000018:8k_2_02:40]
•An effective tax rate between 18 and 20 percent

[0000038725-20-000018:8k_2_02:41]
•Capital spending of around $30 million and Depreciation and Amortization of around $38 million

[0000038725-20-000018:8k_2_02:42]
As a result, we currently estimate our 2020 earnings per share before restructuring charges to be between $2.25 and $2.35.”

[0000038725-20-000018:8k_2_02:43]
A conference call to review earnings and other developments in the business will commence at 9:00 am Eastern Time.  The fourth quarter 2019 earnings call will be available via a live webcast.  The webcast will be available in a listen only mode by going to:

[0000038725-20-000018:8k_2_02:44]
https://edge.media-server.com/mmc/p/bdcyyuow

[0000038725-20-000018:8k_2_02:45]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 5464278.

[0000038725-20-000018:8k_2_02:46]
A replay of the conference call will be available Tuesday, February 18, 2020 at 12:00 noon ET through noon ET on Tuesday, February 25, 2020, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 5464278.

[0000038725-20-000018:8k_2_02:47]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-20-000018:8k_2_02:48]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |  |  |  |  |  |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |  |  |  |  |  |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |  |  |  |  |
|  | Fourth Quarter Ended |  |  |  | Fiscal Year End |  |  |  |  |  |  |
|  | December 31, 2019 |  | December 31, 2018 |  | December 31, 2019 |  | December 31, 2018 |  |  |  |  |
| Net sales | $ | 320,107 |  |  | $ | 316,663 |  |  | $ | 1,314,578 |  |  | $ | 1,298,129 |  |  |  |  |  |
| Cost of sales | 218,851 |  |  | 212,321 |  |  | 886,475 |  |  | 865,763 |  |  |  |  |  |
| Gross profit | 101,256 |  |  | 104,342 |  |  | 428,103 |  |  | 432,366 |  |  |  |  |  |
| Selling, general, and administrative expenses | 71,870 |  |  | 74,983 |  |  | 298,451 |  |  | 298,706 |  |  |  |  |  |
| Restructuring expense | 784 |  |  | 676 |  |  | 2,519 |  |  | 1,666 |  |  |  |  |  |
| Operating income | 28,602 |  |  | 28,683 |  |  | 127,133 |  |  | 131,994 |  |  |  |  |  |
| Interest expense | (1,571) |  |  | (2,362) |  |  | (8,245) |  |  | (9,839) |  |  |  |  |  |
| Other income/(expense), net | (109) |  |  | (461) |  |  | (412) |  |  | (1,042) |  |  |  |  |  |
| Foreign exchange income/(expense) | (3,807) |  |  | 2,445 |  |  | (1,641) |  |  | (706) |  |  |  |  |  |
| Income before income taxes | 23,115 |  |  | 28,305 |  |  | 116,835 |  |  | 120,407 |  |  |  |  |  |
| Income tax expense | 3,130 |  |  | 3,974 |  |  | 20,836 |  |  | 14,890 |  |  |  |  |  |
| Net income | $ | 19,985 |  |  | $ | 24,331 |  |  | $ | 95,999 |  |  | $ | 105,517 |  |  |  |  |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (210) |  |  | (131) |  |  | (516) |  |  | 360 |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 19,775 |  |  | $ | 24,200 |  |  | $ | 95,483 |  |  | $ | 105,877 |  |  |  |  |  |
| Income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.42 |  |  | $ | 0.52 |  |  | $ | 2.04 |  |  | $ | 2.25 |  |  |  |  |  |
| Diluted | $ | 0.42 |  |  | $ | 0.51 |  |  | $ | 2.03 |  |  | $ | 2.23 |  |  |  |  |  |

[0000038725-20-000018:8k_2_02:49]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |  |  |
| (Unaudited) |  |  |  |
| (In thousands) |  |  |  |
|  | December 31, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 64,405 |  |  | $ | 59,173 |  |
| Receivables | 173,327 |  |  | 172,899 |  |
| Inventories | 300,246 |  |  | 314,049 |  |
| Other current assets | 29,466 |  |  | 33,758 |  |
| Total current assets | 567,444 |  |  | 579,879 |  |
| Property, plant, and equipment, net | 201,328 |  |  | 207,064 |  |
| Right-of-use asset, net | 27,621 |  |  | — |  |
| Goodwill and other assets | 398,350 |  |  | 395,422 |  |
| Total assets | $ | 1,194,743 |  |  | $ | 1,182,365 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 82,593 |  |  | $ | 76,652 |  |
| Accrued expenses and other current liabilities | 71,454 |  |  | 67,230 |  |
| Current lease liability | 9,838 |  |  | — |  |
| Current maturities of long-term debt and short-term borrowings | 21,879 |  |  | 111,975 |  |
| Total current liabilities | 185,764 |  |  | 255,857 |  |
| Long-term debt | 93,141 |  |  | 94,379 |  |
| Long-term lease liability | 17,785 |  |  | — |  |
| Income taxes payable non-current | 11,965 |  |  | 10,881 |  |
| Deferred income taxes | 27,598 |  |  | 28,949 |  |
| Employee benefit plans | 38,288 |  |  | 38,020 |  |
| Other long-term liabilities | 21,769 |  |  | 17,934 |  |
| Redeemable noncontrolling interest | (236) |  |  | 518 |  |
| Total equity | 798,669 |  |  | 735,827 |  |
| Total liabilities and equity | $ | 1,194,743 |  |  | $ | 1,182,365 |  |

[0000038725-20-000018:8k_2_02:50]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |  |  |
| (Unaudited) |  |  |  |
| (In thousands) |  |  |  |
|  | 2019 |  | 2018 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 95,999 |  |  | $ | 105,517 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 36,977 |  |  | 38,604 |  |
| Non-Cash Lease Expense | 11,699 |  |  | — |  |
| Share-based compensation | 8,957 |  |  | 8,450 |  |
| Other | (34) |  |  | (4,147) |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | 1,076 |  |  | (8,194) |  |
| Inventory | 17,228 |  |  | (4,775) |  |
| Accounts payable and accrued expenses | 6,770 |  |  | 1,677 |  |
| Operating Leases | (11,698) |  |  | — |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | — |  |  | (6,510) |  |
| Other | 10,702 |  |  | (2,187) |  |
| Net cash flows from operating activities | 177,676 |  |  | 128,435 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (21,855) |  |  | (22,432) |  |
| Proceeds from sale of property, plant, and equipment | 866 |  |  | 724 |  |
| Acquisitions and investments | (20,827) |  |  | (44,971) |  |
| Other investing activities | 10 |  |  | 387 |  |
| Net cash flows from investing activities | (41,806) |  |  | (66,292) |  |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (90,943) |  |  | (18,985) |  |
| Proceeds from issuance of common stock | 3,194 |  |  | 8,999 |  |
| Purchases of common stock | (10,741) |  |  | (34,188) |  |
| Dividends paid | (27,671) |  |  | (22,612) |  |
| Purchase of redeemable non-controlling shares | (487) |  |  | — |  |
| Net cash flows from financing activities | (126,648) |  |  | (66,786) |  |
| Effect of exchange rate changes on cash | (3,990) |  |  | (3,417) |  |
| Net change in cash and equivalents | 5,232 |  |  | (8,060) |  |
| Cash and equivalents at beginning of period | 59,173 |  |  | 67,233 |  |
| Cash and equivalents at end of period | $ | 64,405 |  |  | $ | 59,173 |  |
