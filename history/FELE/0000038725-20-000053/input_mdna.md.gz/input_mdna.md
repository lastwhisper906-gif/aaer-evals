# FELE MD&A — 0000038725-20-000053


## mdna

[0000038725-20-000053:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-20-000053:mdna:2]
2019 vs. 2018

[0000038725-20-000053:mdna:3]
OVERVIEW

[0000038725-20-000053:mdna:4]
Sales in 2019 increased by 1 percent from the prior year.  The sales increase was led by acquisition related sales, as well as volume and price increases of about 1 percent. The impact of foreign currency translation decreased sales by about 3 percent. The Company's consolidated gross profit was $428.1 million for 2019, a decrease of $4.3 million or about 1 percent from 2018. The gross profit as a percent of net sales decreased 70 basis points to 32.6 percent in 2019 from 33.3 percent in 2018.  For 2019, diluted earnings per share were $2.03, down from 2018 diluted earnings per share of $2.23.

[0000038725-20-000053:mdna:5]
RESULTS OF OPERATIONS

[0000038725-20-000053:mdna:6]
Net Sales

[0000038725-20-000053:mdna:7]
Net sales in 2019 were $1,314.6 million, an increase of $16.5 million or about 1 percent compared to 2018 sales of $1,298.1 million.  The incremental impact of sales from acquired businesses was $38.1 million.  Sales revenue decreased by $34.8 million or about 3 percent in 2019 due to foreign currency translation. The sales change in 2019, excluding acquisitions and foreign currency translation, was an increase of $13.2 million or about 1 percent.

[0000038725-20-000053:mdna:8]
|  | Net Sales |  |  |  |  |
| (In millions) | 2019 |  | 2018 |  | 2019 v 2018 |
| Water Systems | $ | 781.5 |  |  | $ | 800.1 |  |  | $ | (18.6) |  |
| Fueling Systems | 293.6 |  |  | 284.6 |  |  | 9.0 |  |
| Distribution | 291.8 |  |  | 269.6 |  |  | 22.2 |  |
| Eliminations/Other | (52.3) |  |  | (56.2) |  |  | 3.9 |  |
| Consolidated | $ | 1,314.6 |  |  | $ | 1,298.1 |  |  | $ | 16.5 |  |

[0000038725-20-000053:mdna:9]
Net Sales-Water Systems

[0000038725-20-000053:mdna:10]
Water Systems sales were $781.5 million in 2019, a decrease of $18.6 million or about 2 percent versus 2018. The incremental impact of sales from acquired businesses was $13 million. Foreign currency translation changes decreased sales $30.5 million, or about 4 percent, compared to sales in 2018. The Water Systems organic sales change in 2019 was a decrease of $1.1 million.

[0000038725-20-000053:mdna:11]
Water Systems sales in the U.S. and Canada decreased by about 2 percent compared to 2018. The incremental impact of sales from acquired businesses was $5.4 million. Sales revenue decreased by $2.5 million or about 1 percent in 2019 due to foreign currency translation. In 2019, sales of dewatering equipment decreased by about 9 percent when compared to the prior year due to lower sales in rental channels and higher sales in 2018 driven by regulatory demand. Sales of groundwater pumping equipment decreased by about 4 percent on lower residential and agricultural system sales primarily to the Headwater companies, versus 2018. Sales of other surface pumping equipment were flat to prior year.

[0000038725-20-000053:mdna:12]
Water Systems sales in markets outside the U.S. and Canada decreased by about 3 percent compared to 2018. Sales revenue decreased by $28.0 million or about 8 percent in 2019 due to foreign currency translation. The incremental impact of sales from acquired businesses was $7.6 million. International Water Systems sales change in 2019, excluding acquisitions and foreign currency translation, was an increase of about 3 percent. International Water Systems sales grew in all three major international markets, Latin American, Asia Pacific and the European, Middle East and African markets.

[0000038725-20-000053:mdna:13]
Net Sales-Fueling Systems

[0000038725-20-000053:mdna:14]
Fueling Systems sales were $293.6 million in 2019, an increase of $9.0 million or about 3 percent from 2018. The incremental impact of sales from acquired businesses was $3.2 million. Foreign currency translation changes decreased sales $4.3 million or about 2 percent compared to sales in 2018. The Fueling Systems organic sales change in 2019 was an increase of $10.1 million or about 4 percent.

[0000038725-20-000053:mdna:15]
Fueling Systems sales in the U.S. and Canada grew by about 11 percent during 2019 with most of the sales growth coming from fuel management and pumping systems, piping and service station hardware product lines.  Internationally, Fueling Systems revenues declined by about 5 percent due to lower sales in China and Africa partially offset by higher sales in India and other regions. China sales were about $45 million in 2019 compared to 2018 sales of about $52 million.

[0000038725-20-000053:mdna:16]
Net Sales-Distribution

[0000038725-20-000053:mdna:17]
Distribution sales were $291.8 million in 2019, versus 2018 sales of $269.6 million. The incremental impact of sales from acquired businesses was $21.9 million. Distribution segment organic sales change was an increase of $0.3 million compared to 2018.

[0000038725-20-000053:mdna:18]
Cost of Sales

[0000038725-20-000053:mdna:19]
Cost of sales as a percent of net sales for 2019 and 2018 was 67.4 percent and 66.7 percent, respectively. Correspondingly, the gross profit margin was 32.6 percent and 33.3 percent for both years. The Company’s consolidated gross profit was $428.1 million for 2019, down $4.3 million from the gross profit of $432.4 million in 2018. The gross profit decline was primarily due to lower sales volumes and subsequent lower gross profit from the Water Systems segment which more than offset higher Fueling Systems and Distribution sales.

[0000038725-20-000053:mdna:20]
Selling, General and Administrative (“SG&A”)

[0000038725-20-000053:mdna:21]
Selling, general, and administrative expenses were $298.5 million in 2019 and decreased by $0.2 million compared to $298.7 million last year. The increase in SG&A expenses from acquired businesses were $9.1 million. Excluding the acquired entities, the Company’s SG&A expenses in 2019 were $289.4 million and decreased by $9.3 million or about 3 percent in 2019 compared to last year, partially due to the effect of foreign currency translation (primarily a stronger U.S. dollar relative to foreign currencies) in 2019 reducing SG&A expenses versus the prior year.

[0000038725-20-000053:mdna:22]
Restructuring Expenses

[0000038725-20-000053:mdna:23]
Restructuring expenses for 2019 were $2.5 million. Restructuring expenses were $1.7 million in the Water Systems segment and $0.8 million in the Distribution segment. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and distribution branch closings and consolidations.  Restructuring expenses for 2018 were $1.7 million. Restructuring expenses for 2018 were $0.6 million in the Water Systems segment, $0.3 million in the Fueling Systems segment and $0.8 million in the Distribution segment. Restructuring expenses for 2018 were primarily from continued miscellaneous manufacturing realignment activities and distribution branch closings and consolidations.

[0000038725-20-000053:mdna:24]
Operating Income

[0000038725-20-000053:mdna:25]
Operating income was $127.1 million in 2019, down $4.9 million or 4 percent from $132.0 million in 2018.

[0000038725-20-000053:mdna:26]
|  |  | Operating income (loss) |  |  |  |  |
| (In millions) |  | 2019 |  | 2018 |  | 2019 v 2018 |
| Water Systems |  | $ | 103.0 |  |  | $ | 112.7 |  |  | $ | (9.7) |  |
| Fueling Systems |  | 75.8 |  |  | 70.6 |  |  | 5.2 |  |
| Distribution |  | 3.6 |  |  | 3.4 |  |  | 0.2 |  |
| Eliminations/Other |  | (55.3) |  |  | (54.7) |  |  | (0.6) |  |
| Consolidated |  | $ | 127.1 |  |  | $ | 132.0 |  |  | $ | (4.9) |  |

[0000038725-20-000053:mdna:27]
Operating Income-Water Systems

[0000038725-20-000053:mdna:28]
Water Systems operating income was $103.0 million in 2019 compared to $112.7 million in 2018, a decrease of 9 percent. Operating income margin for 2019 was 13.2 percent compared to 2018 operating income margin of 14.1 percent. Operating income decreased in Water Systems primarily from lower sales.

[0000038725-20-000053:mdna:29]
Operating Income-Fueling Systems

[0000038725-20-000053:mdna:30]
Fueling Systems operating income was $75.8 million in 2019 compared to $70.6 million in 2018. The operating income margin was 25.8 percent compared to 2018 operating income margin of 24.8 percent. The increase in operating income was primarily due to higher sales.

[0000038725-20-000053:mdna:31]
Operating Income-Distribution

[0000038725-20-000053:mdna:32]
Distribution operating income was $3.6 million in 2019 and operating income margin was 1.2 percent. Distribution operating income was $3.4 million in 2018 and operating income margin was 1.3 percent.

[0000038725-20-000053:mdna:33]
Operating Income-Eliminations/Other

[0000038725-20-000053:mdna:34]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in 2019 compared to 2018 reduced operating income about $1.3 million. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its customer. Unallocated general and administrative expenses were lower by $0.7 million or about 1 percent.

[0000038725-20-000053:mdna:35]
Interest Expense

[0000038725-20-000053:mdna:36]
Interest expense for 2019 and 2018 was $8.2 million and $9.8 million, respectively.

[0000038725-20-000053:mdna:37]
Other Income or Expense

[0000038725-20-000053:mdna:38]
Other income or expense was a loss of $0.4 million and $1.0 million, respectively in 2019 and 2018.

[0000038725-20-000053:mdna:39]
Foreign Exchange

[0000038725-20-000053:mdna:40]
Foreign currency-based transactions for 2019 was a loss of $1.6 million due primarily to the Argentinian Peso weakening relative to the U.S. dollar. Foreign currency-based transactions for 2018 was a loss of $0.7 million due to movements in several currencies relative to the U.S. dollar, with the Turkish Lira, South African Rand, Argentinian Peso and Mexican Peso being the most significant.

[0000038725-20-000053:mdna:41]
Income Taxes

[0000038725-20-000053:mdna:42]
The provision for income taxes in 2019 and 2018 was $20.8 million and $14.9 million, respectively. The effective tax rate for 2019 was about 18 percent and before the impact of discrete events was about 20 percent. The effective tax rate for 2018 was about 12 percent and before the impact of discrete events was about 19 percent. The tax rate was lower than the statutory rate of 21 percent primarily due to foreign earnings taxed at lower statutory rates, as well as recognition of the U.S. deduction for Foreign Derived Intangible Income, and certain incentives and discrete events. Discrete events in 2018 include a net benefit related to the release of valuation allowances on deferred taxes in multiple jurisdictions. In 2020, the Company estimates its effective tax rate will be about 18 to 20 percent.

[0000038725-20-000053:mdna:43]
Net Income

[0000038725-20-000053:mdna:44]
Net income for 2019 was $96.0 million compared to 2018 net income of $105.5 million.  Net income attributable to Franklin Electric Co., Inc. for 2019 was $95.5 million, or $2.03 per diluted share, compared to 2018 net income attributable to Franklin Electric Co., Inc. of $105.9 million or $2.23 per diluted share.

[0000038725-20-000053:mdna:45]
2018 vs. 2017

[0000038725-20-000053:mdna:46]
Discussion of fiscal year 2017 items and the year-over-year comparison of changes in the Company's financial condition and results of operation as of and for the fiscal years ended December 31, 2018 and December 31, 2017 can be found in Part II, Item 7. "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our Annual Report on Form 10-K for the fiscal year ended December 31, 2018.

[0000038725-20-000053:mdna:47]
CAPITAL RESOURCES AND LIQUIDITY

[0000038725-20-000053:mdna:48]
Sources of Liquidity

[0000038725-20-000053:mdna:49]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available for at least the next twelve months. The Company believes its capital resources and liquidity position at December 31, 2019 is adequate to meet projected needs. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-20-000053:mdna:50]
As of December 31, 2019, the Company had a $300.0 million revolving credit facility. The facility is scheduled to mature on October 28, 2021. As of December 31, 2019, the Company had $276.5 million borrowing capacity under the Credit Agreement as $4.5 million in letters of commercial and standby letters of credit were outstanding and undrawn and $19.0 million revolver borrowing was drawn and outstanding as of the end of the year.

[0000038725-20-000053:mdna:51]
The Company also has other long-term debt borrowings outstanding as of December 31, 2019. See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-20-000053:mdna:52]
At December 31, 2019, the Company had $40 million of cash and cash equivalents held in foreign jurisdictions, which the company intends to use to fund foreign operations. There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-20-000053:mdna:53]
Cash Flows

[0000038725-20-000053:mdna:54]
The following table summarizes significant sources and uses of cash and cash equivalents:

[0000038725-20-000053:mdna:55]
| (in thousands) | 2019 |  | 2018 |  | 2017 |
| Net cash provided by operating activities | $ | 177.7 |  |  | $ | 128.4 |  |  | $ | 66.8 |  |
| Net cash used in investing activities | (41.8) |  |  | (66.3) |  |  | (84.7) |  |
| Net cash used in financing activities | (126.7) |  |  | (66.8) |  |  | (22.6) |  |
| Impact of exchange rates on cash and cash equivalents | (4.0) |  |  | (3.4) |  |  | 3.4 |  |
| Change in cash and cash equivalents | $ | 5.2 |  |  | $ | (8.1) |  |  | $ | (37.1) |  |

[0000038725-20-000053:mdna:56]
Cash Flows Provided by Operating Activities

[0000038725-20-000053:mdna:57]
2019 vs. 2018

[0000038725-20-000053:mdna:58]
Net cash provided by operating activities was $177.7 million for 2019 compared to $128.4 million for 2018. The increase in cash provided by operating activities was primarily due to a decrease of $36.4 million in working capital requirements related to a reduction in inventory and more favorable payment terms with vendors. The company also experienced lower income tax payments in the current year. Increases in cash provided by operating activities were partially offset by the decrease in net income from the prior year.

[0000038725-20-000053:mdna:59]
2018 vs. 2017

[0000038725-20-000053:mdna:60]
Discussion of fiscal year 2017 items and the year-over-year comparison of changes in our financial condition and results of operation as of and for the fiscal years ended December 31, 2018 and December 31, 2017 can be found in Part II, Item 7. "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our Annual Report on Form 10-K for the fiscal year ended December 31, 2018.

[0000038725-20-000053:mdna:61]
Cash Flows Used in Investing Activities

[0000038725-20-000053:mdna:62]
2019 vs. 2018

[0000038725-20-000053:mdna:63]
Net cash used in investing activities was $41.8 million in 2019 compared to $66.3 million in 2018. The decrease is primarily attributable to decreased acquisition activity.

[0000038725-20-000053:mdna:64]
2018 vs. 2017

[0000038725-20-000053:mdna:65]
Discussion of fiscal year 2017 items and the year-over-year comparison of changes in our financial condition and results of operation as of and for the fiscal years ended December 31, 2018 and December 31, 2017 can be found in Part II, Item 7. "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our Annual Report on Form 10-K for the fiscal year ended December 31, 2018.

[0000038725-20-000053:mdna:66]
Cash Flows Used in Financing Activities

[0000038725-20-000053:mdna:67]
2019 vs. 2018

[0000038725-20-000053:mdna:68]
Net cash used in financing activities was $126.7 million in 2019 compared to $66.8 million in 2018. The increase in cash used in financing activities was primarily attributable to an increase in debt repayments, up approximately $72 million in the current year consistent with reduced acquisition activity.  Other uses of cash in financing activities include dividend payments, which increased by $5.1 million in the current year compared to dividends paid in the prior year, and proceeds from common stock issuance, which decreased $5.8 million compared to prior year.  These were offset by a decrease in common stock repurchases of $23.4 million.

[0000038725-20-000053:mdna:69]
2018 vs. 2017

[0000038725-20-000053:mdna:70]
Discussion of fiscal year 2017 items and the year-over-year comparison of changes in our financial condition and results of operation as of and for the fiscal years ended December 31, 2018 and December 31, 2017 can be found in Part II, Item 7. "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our Annual Report on Form 10-K for the fiscal year ended December 31, 2018.

[0000038725-20-000053:mdna:71]
AGGREGATE CONTRACTUAL OBLIGATIONS

[0000038725-20-000053:mdna:72]
The majority of the Company’s contractual obligations to third parties relate to debt obligations.  In addition, the Company has certain contractual obligations for future lease payments and purchase obligations.  The payment schedule for these contractual obligations is as follows:

[0000038725-20-000053:mdna:73]
| (In millions) |  |  |  |  |  |  |  |  | More than |
|  | Total |  | 2020 |  | 2021-2022 |  | 2023-2024 |  | 5 years |
| Debt | $ | 115.0 |  |  | $ | 21.8 |  |  | $ | 2.5 |  |  | $ | 2.7 |  |  | $ | 88.0 |  |
| Debt interest | 24.1 |  |  | 4.5 |  |  | 7.3 |  |  | 7.1 |  |  | 5.2 |  |
| Financing leases | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |
| Operating leases | 30.2 |  |  | 10.8 |  |  | 12.2 |  |  | 4.5 |  |  | 2.7 |  |
| Purchase obligations | 6.1 |  |  | 6.1 |  |  | — |  |  | — |  |  | — |  |
| Income Taxes-U.S. Tax Cuts and Jobs Act transition tax | $ | 16.3 |  |  | $ | 1.6 |  |  | $ | 3.1 |  |  | $ | 6.8 |  |  | $ | 4.8 |  |
|  | $ | 191.8 |  |  | $ | 44.9 |  |  | $ | 25.1 |  |  | $ | 21.1 |  |  | $ | 100.7 |  |

[0000038725-20-000053:mdna:74]
The Company has pension and other post-retirement benefit obligations not included in the table above which will result in estimated future payments of approximately $1 million in 2020. The Company also has unrecognized tax benefits, none of which are included in the table above. The unrecognized tax benefits of approximately $0.4 million have been recorded as liabilities and the Company is uncertain as to if or when such amounts may be settled. Related to the unrecognized tax benefits, the Company has also recorded a liability for potential penalties and interest of $0.1 million.

[0000038725-20-000053:mdna:75]
ACCOUNTING PRONOUNCEMENTS

[0000038725-20-000053:mdna:76]
For information regarding recent accounting pronouncements, refer to Note 2 - Accounting Pronouncements, in the Notes to Consolidated Financial Statements in the sections entitled ""Adoption of New Accounting Standards" and "Accounting Standards Issued But Not Yet Adopted", included in Part II, Item 8, "Financial Statements and Supplementary Data" of this Annual Report on Form 10-K.

[0000038725-20-000053:mdna:77]
CRITICAL ACCOUNTING ESTIMATES

[0000038725-20-000053:mdna:78]
Management’s discussion and analysis of its financial condition and results of operations are based upon the Company’s consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires management to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and the related disclosure of contingent assets and liabilities.  Management evaluates estimates on an ongoing basis.  Estimates are based on historical experience and on other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions.  There were no material changes to estimates or methodologies used to develop those estimates in 2019.

[0000038725-20-000053:mdna:79]
The Company’s critical accounting estimates are identified below:

[0000038725-20-000053:mdna:80]
Inventory Valuation

[0000038725-20-000053:mdna:81]
The Company uses certain estimates and judgments to value inventory. Inventory is recorded at the lower of cost or market. The Company reviews its inventories for excess or obsolete products or components. Based on an analysis of historical usage, management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts, carrying values are adjusted.  The carrying value is reduced regularly to reflect the age and current anticipated product demand. If actual demand differs from the estimates, additional reductions would be necessary in the period such determination is made.  Excess and obsolete inventory is periodically disposed of through sale to third parties, scrapping, or other means.

[0000038725-20-000053:mdna:82]
Business Combinations

[0000038725-20-000053:mdna:83]
The Company follows the guidance under FASB Accounting Standards Codification (“ASC”) Topic 805, Business Combinations.  The acquisition purchase price is allocated to the assets acquired and liabilities assumed based upon their respective fair values.  The Company shall report in its financial statements provisional amounts for the items for which accounting is incomplete.  Goodwill is adjusted for any changes to provisional amounts made within the measurement period.  The Company utilizes management estimates and an independent third-party valuation firm to assist in determining the fair values of assets acquired and liabilities assumed.  Such estimates and valuations require the Company to make significant assumptions, including projections of future events and operating performance.  The Company has not made any material changes to the method of valuing fair values of assets acquired and liabilities assumed during the last three years.

[0000038725-20-000053:mdna:84]
Trade Names and Goodwill

[0000038725-20-000053:mdna:85]
According to FASB ASC Topic 350, Intangibles - Goodwill and Other, intangible assets with indefinite lives must be tested for impairment at least annually or more frequently as warranted by triggering events that indicate potential impairment.  The Company uses a variety of methodologies in conducting impairment assessments including income and market approaches.  For indefinite-lived assets apart from goodwill, primarily trade names for the Company, if the fair value is less than the carrying amount, an impairment charge is recognized in an amount equal to that excess.  The Company has not made any material changes to the method of evaluating impairments during the last three years.

[0000038725-20-000053:mdna:86]
In compliance with FASB ASC Topic 350, goodwill is not amortized. Goodwill is tested at the reporting unit level for impairment annually or more frequently as warranted by triggering events that indicate potential impairment.  Reporting units are operating segments or one level below, known as components, which can be aggregated for testing purposes.  The Company’s goodwill is allocated to the North America Water Systems, International Water, and Fueling Systems units, as components within the North America Water Systems and International Water reporting units can be aggregated.  In 2017, as a result of the Headwater acquisition, the Company added a Distribution reporting unit. The Distribution reporting unit was subject to qualitative testing in the year of acquisition.  In 2018 and 2019, all reporting units were tested using the quantitative valuation approaches listed below.  As the Company’s business model evolves, management will continue to evaluate its reporting units and review the aggregation criteria.

[0000038725-20-000053:mdna:87]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the market value and income approaches. The market value approach compares the reporting units’ current and projected financial results to entities of similar size and industry to determine the market value of the reporting unit. The income approach utilizes assumptions regarding estimated future cash flows and other factors to determine the fair value of the respective assets. These cash flows consider factors regarding expected future operating income and historical trends, as well as the effects of demand and competition. The Company may be required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units is below their associated carrying values. Goodwill included on the balance sheet as of the fiscal year ended 2019 was $256.1 million.

[0000038725-20-000053:mdna:88]
During the fourth quarter of 2019, the Company completed its annual impairment test of goodwill and trade names and determined the fair value of all intangibles were substantially in excess of the respective carrying values.  Significant judgment is required to determine if an indication of impairment has taken place.  Factors to be considered include the following: adverse changes in operating results, decline in strategic business plans, significantly lower future cash flows, and sustainable declines in market data such as market capitalization.  A 10 percent decrease in the fair value estimates used in the impairment test would not have changed this determination.  The sensitivity analysis required the use of numerous subjective assumptions, which, if actual experience varies, could result in material differences in the requirements for impairment charges.  Further, an extended downturn in the economy may impact certain components of the operating segments more significantly and could result in changes to the aggregation assumptions and impairment determination.

[0000038725-20-000053:mdna:89]
Income Taxes

[0000038725-20-000053:mdna:90]
Under the requirements of FASB ASC Topic 740, Income Taxes, the Company records deferred tax assets and liabilities for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company analyzes the deferred tax assets and liabilities for their future realization based on the estimated existence of sufficient taxable income.  This analysis considers the following sources of taxable income: prior year taxable income, future reversals of existing taxable temporary differences, future taxable income exclusive of reversing temporary differences and tax planning strategies that would generate taxable income in the relevant period.  If sufficient taxable income is not projected then the Company will record a valuation allowance against the relevant deferred tax assets.

[0000038725-20-000053:mdna:91]
The Company’s operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions.  These jurisdictions have different tax rates, and the Company determines the allocation of income to each of these jurisdictions based upon various estimates and assumptions. In the normal course of business, the Company will undergo tax audits by various tax jurisdictions. Such audits often require an extended period of time to complete and may result in income tax adjustments if changes to the allocation are required between jurisdictions with different tax rates.  The final taxes paid are dependent upon many factors, including negotiations with taxing authorities in the various jurisdictions and resolution of disputes arising from federal, state, and international tax audits.  Although the Company has recorded all income tax uncertainties in accordance with FASB ASC Topic 740, these accruals represent estimates that are subject to the inherent uncertainties associated with the tax audit process, and therefore include uncertainties.  Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, which, if actual experience varies, could result in material adjustments to tax expense and/or deferred tax assets and liabilities.

[0000038725-20-000053:mdna:92]
Pension and Employee Benefit Obligations

[0000038725-20-000053:mdna:93]
The Company consults with its actuaries to assist with the calculation of discount rates used in its pension and post retirement plans.  The discount rates used to determine domestic pension and post-retirement plan liabilities are calculated using a full yield curve approach.  Market conditions have caused the weighted-average discount rate to move from 4.28 percent last year to 3.12 percent this year for the domestic pension plans and from 4.18 percent last year to 2.98 percent this year for the postretirement health and life insurance plan. A change in the discount rate selected by the Company of 25 basis points would result in a change of about $0.1 million to employee benefit expense and a change of about $3.7 million of liability.

[0000038725-20-000053:mdna:94]
The Company consults with actuaries and investment advisors in making its determination of the expected long-term rate of return on plan assets. Using input from these consultations such as long-term investment sector expected returns, the correlations and standard deviations thereof, and the plan asset allocation, the Company has assumed an expected long-term rate of return on plan assets of 4.90 percent as of the fiscal year ended 2019.  A change in the long-term rate of return selected by the Company of 25 basis points would result in a change of about $0.4 million of employee benefit expense.

[0000038725-20-000053:mdna:95]
FACTORS THAT MAY AFFECT FUTURE RESULTS
