# FELE notes — 0000038725-20-000053


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000038725-20-000053:notes:1]
A portion of the Proxy Statement for the Annual Meeting of Shareholders to be held on May 8, 2020 (Part III).


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000038725-20-000053:notes:2]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Company--“Franklin Electric” or the “Company” shall refer to Franklin Electric Co., Inc. and its consolidated subsidiaries.

[0000038725-20-000053:notes:3]
Fiscal Year--The financial statements and accompanying notes are as of and for the years ended December 31, 2019, December 31, 2018, and December 31, 2017, and referred to as 2019, 2018, and 2017, respectively.

[0000038725-20-000053:notes:4]
Principles of Consolidation--The consolidated financial statements include the accounts of Franklin Electric Co., Inc. and its consolidated subsidiaries.  All intercompany transactions have been eliminated.

[0000038725-20-000053:notes:5]
Business Combinations--The Company allocates the purchase price of its acquisitions to the assets acquired, liabilities assumed, and noncontrolling interests based upon their respective fair values at the acquisition date.  The Company utilizes management estimates and inputs from an independent third-party valuation firm to assist in determining these fair values.  The excess of the acquisition price over estimated fair values is recorded as goodwill.  Goodwill is adjusted for any changes to acquisition date fair value amounts made within the measurement period.  Acquisition-related transaction costs are recognized separately from the business combination and expensed as incurred.

[0000038725-20-000053:notes:6]
Revenue Recognition--Revenue is recognized when promised goods or services are transferred to customers in an amount that reflects the consideration to which the entity expects to be entitled to in exchange for those goods or services.   The promise in a contract to transfer goods or services to a customer represents a performance obligation.  The Company typically sells its products to customers by purchase order and does not have any additional performance obligations included in contracts to customers other than the shipment of the products.  Therefore, the Company allocates the transaction price based on a single performance obligation. The Company typically ships products FOB shipping at which point control of the products passes to the customers. The Company considers the performance obligation satisfied and recognizes revenue at a point in time, the time of shipment.

[0000038725-20-000053:notes:7]
The Company’s products may include routine assurance-type warranties which do not qualify as separate performance obligations.  In the event that significant post-shipment obligations were to exist for the Company’s products, revenue recognition would be deferred until the performance obligations were satisfied.

[0000038725-20-000053:notes:8]
The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience.

[0000038725-20-000053:notes:9]
Shipping and Handling Costs--Shipping and handling costs are considered activities required to fulfill the Company’s promise to transfer goods, and do not qualify as a separate performance obligation. Shipping and handling costs are recorded as a component of cost of sales.

[0000038725-20-000053:notes:10]
Research and Development Expense--The Company’s research and development activities are charged to expense in the period incurred.  The Company incurred expenses of approximately $20.8 million in 2019, $22.1 million in 2018, and $20.8 million in 2017 related to research and development.

[0000038725-20-000053:notes:11]
Cash and Cash Equivalents--The Company considers cash on hand, demand deposits, and highly liquid investments with an original maturity date of three months or less to be cash and cash equivalents.

[0000038725-20-000053:notes:12]
Fair Value of Financial Instruments--Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy.  Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date.  The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value.  The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-20-000053:notes:13]
Level 1 – Quoted prices for identical assets and liabilities in active markets;

[0000038725-20-000053:notes:14]
Level 2 – Quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets; and

[0000038725-20-000053:notes:15]
Level 3 – Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable.

[0000038725-20-000053:notes:16]
Accounts Receivable, Earned Discounts, and Allowance for Uncollectible Accounts--Accounts receivable are stated at estimated net realizable value.  Accounts receivable are comprised of balances due from customers, net of earned discounts and estimated allowances for uncollectible accounts.  Earned discounts are based on specific customer agreement terms.  In determining allowances for uncollectible accounts, historical collection experience, current trends, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are reviewed.

[0000038725-20-000053:notes:17]
Inventories--Inventories are stated at the lower of cost or market.  The majority of the cost of domestic and foreign inventories is determined using the FIFO method with a portion of inventory costs determined using the average cost method.  The Company reviews its inventories for excess or obsolete products or components based on an analysis of historical usage and management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts.

[0000038725-20-000053:notes:18]
Property, Plant, and Equipment--Property, plant, and equipment are stated at historical cost.  The Company capitalizes certain computer software and software development costs incurred in connection with developing or obtaining computer software for internal use, which are included in property, plant, and equipment.  Depreciation of plant and equipment is calculated on a straight line basis over the following estimated useful lives:

[0000038725-20-000053:notes:19]
| Land improvement and buildings | 10 - 40 years |
| Machinery and equipment | 5 - 10 years |
| Software | 3 - 7 years |
| Furniture and fixtures | 3 - 7 years |

[0000038725-20-000053:notes:20]
Maintenance, repairs, and renewals of a minor nature are expensed as incurred.  Betterments and major renewals which extend the useful lives or add to the productive capacity of buildings, improvements, and equipment are capitalized.  The Company reviews its property, plant, and equipment for impairment at the asset group level whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable.  If an indicator is present, the Company compares carrying values to undiscounted future cash flows; if the undiscounted future cash flows are less than the carrying value, an impairment would be recognized for the difference between the fair value and the carrying value.

[0000038725-20-000053:notes:21]
The Company’s depreciation expense was $27.6 million, $29.7 million, and $29.9 million in 2019, 2018, and 2017, respectively.

[0000038725-20-000053:notes:22]
Leases--The Company determines if an arrangement is a lease, or contains a lease, at the inception of the arrangement and determines whether it is an operating or financing lease.  Operating and financing leases result in the Company recording a right-of-use (ROU) asset, current lease liability, and long term lease liability on its balance sheet. The Company has elected to not present leases with an initial term of 12 months or less on the balance sheet.  The ROU assets and liabilities are initially recognized based on the present value of lease payments over the lease term.  Initial direct costs and lease incentives are not material when measuring the ROU asset present value.  Lease expense for operating lease payments is recognized on a straight-line basis over the lease term.

[0000038725-20-000053:notes:23]
In determining the present value, the Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the Company’s borrowing information available at inception.  A portion of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.  In addition, the Company has elected not to separate non-lease components from lease components.

[0000038725-20-000053:notes:24]
Goodwill and Other Intangible Assets--Goodwill is tested at the reporting unit level, which the Company has determined to be the North America Water Systems, International Water, Fueling Systems, and Distribution units.  In compliance with FASB ASC Topic 350, Intangibles - Goodwill and Other, the Company has evaluated the aggregation criteria and determined that the individual components within the North America Water Systems and International Water reporting units, respectively, can be aggregated in 2019.

[0000038725-20-000053:notes:25]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the income and market valuation approaches.  The income approach estimates fair value based upon future revenue, expenses, and cash flows discounted to present value.  The market valuation approach estimates fair value using

[0000038725-20-000053:notes:26]
market multipliers of various financial measures compared to a set of comparable public companies.  The fair value calculated for each reporting unit is considered a Level 3 measurement within the fair value hierarchy.

[0000038725-20-000053:notes:27]
An indication of impairment exists if the carrying value of the reporting unit is higher than its fair value, as determined by the above approach.  The second step of testing as outlined in FASB ASC Topic 350 must be performed to measure the amount of impairment loss.  The amount of impairment is determined by comparing the implied fair value of the reporting unit’s goodwill to its carrying value in the same manner as if the reporting units were being acquired in a business combination.  The Company would allocate the fair value to all of the reporting unit’s assets and liabilities, including any unrecognized intangible assets, in a hypothetical analysis that would calculate the implied fair value of goodwill.  The Company would record an impairment charge for the difference between the implied fair value of goodwill and the recorded goodwill.

[0000038725-20-000053:notes:28]
Beginning in 2017, the Company completed its annual goodwill impairment test during the fourth quarter, using balances as of October 1. Additionally, in 2017 as a result of the Headwater acquisitions, the Company added the Distribution reporting unit. The Distribution reporting unit was subject to qualitative testing in the year of acquisition.  The Company did not recognize a goodwill impairment as a result of the qualitative assessment.  In 2019, all reporting units were tested using the quantitative valuation approaches described above. The Company will test goodwill for impairment more frequently if warranted by triggering events that indicate potential impairment.

[0000038725-20-000053:notes:29]
The Company also tests indefinite lived intangible assets, primarily trade names, for impairment on an annual basis during the fourth quarter of each year, using balances as of October 1, or more frequently as warranted by triggering events that indicate potential impairment.  In assessing the recoverability of the trade names, the Company determines the fair value using an income approach.  The income approach estimates fair value based upon future revenue and estimated royalty rates.  The fair value calculated for indefinite lived intangible assets is considered a Level 3 measurement within the fair value hierarchy.  An indication of impairment exists if the carrying value of the trade names is higher than the fair value.  The Company would record an impairment charge for the difference.

[0000038725-20-000053:notes:30]
Amortization is recorded and calculated for other definite lived intangible assets on a basis that reflects cash flows over the estimated useful lives.  The weighted average number of years over which each intangible class is amortized is as follows:

[0000038725-20-000053:notes:31]
| Patents | 17 years |
| Technology | 15 years |
| Customer relationships | 13 - 20 years |
| Other | 5 - 8 years |

[0000038725-20-000053:notes:32]
Warranty Obligations--The Company provides warranties on most of its products. The warranty terms vary but are generally 2 years to 5 years from date of manufacture or 1 year to 5 years from date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims. The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-20-000053:notes:33]
Income Taxes--Income taxes are accounted for in accordance with FASB ASC Topic 740, Income Taxes.  Under this guidance, deferred tax assets and liabilities are determined based on the difference between the financial statement and tax basis of assets and liabilities and net operating loss and credit carry forwards using enacted tax rates in effect for the year in which the differences are expected to reverse.  Valuation allowances are established when necessary to reduce deferred tax assets to the amounts expected to be realized.  The Company records a liability for uncertain tax positions by establishing a recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return.

[0000038725-20-000053:notes:34]
Defined Benefit Plans--The Company makes its determination for pension, post retirement, and post employment benefit plans liabilities based on management estimates and consultation with actuaries. The Company incorporates estimates and assumptions of future plan service costs, future interest costs on projected benefit obligations, rates of compensation increases, employee turnover rates, anticipated mortality rates, expected investment returns on plan assets, asset allocation assumptions of plan assets, and other factors.

[0000038725-20-000053:notes:35]
Earnings Per Common Share--Basic and diluted earnings per share are computed and disclosed in accordance with FASB ASC Topic 260, Earnings Per Share.  The Company utilizes the two-class method to compute earnings available to common

[0000038725-20-000053:notes:36]
shareholders.  Under the two-class method, earnings are adjusted by accretion amounts to redeemable noncontrolling interests recorded at redemption value.  The adjustments represent dividend distributions, in substance, to the noncontrolling interest holder as the holders have contractual rights to receive an amount upon redemption other than the fair value of the applicable shares.  As a result, earnings are adjusted to reflect this in substance distribution that is different from other common shareholders.  In addition, the Company allocates net earnings to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company’s participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.  Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-20-000053:notes:37]
Translation of Foreign Currency Financial Statements--All assets and liabilities of foreign subsidiaries in functional currency other than the U.S. dollar are translated at year end exchange rates with the exception of the non-monetary assets and liabilities in countries with highly inflationary economies, which are translated at historical exchange rates.  All revenue and expense accounts are translated at average rates in effect during the respective period with the exception of expenses related to the non-monetary assets and liabilities, which are translated at historical exchange rates.  Adjustments for translating longer term foreign currency assets and liabilities in U.S. dollars are included as a component of other comprehensive income except for hyperinflation accounting adjustments.  Transaction gains and losses that arise from shorter term exchange rate fluctuations and hyperinflation accounting adjustments are included in the “Foreign exchange income/(expense)” line within the Company’s consolidated statements of income, as incurred.

[0000038725-20-000053:notes:38]
Significant Estimates--The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make significant estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of expenses during the reporting periods.  Significant estimates and assumptions by management affect inventory valuation, warranty, trade names and goodwill, income taxes, and pension and employee benefit obligations.

[0000038725-20-000053:notes:39]
Although the Company regularly assesses these estimates, actual results could materially differ.  The Company bases its estimates on historical experience and various other assumptions that it believes to be reasonable under the circumstances.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-20-000053:notes:40]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-20-000053:notes:41]
In August 2018, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. This ASU aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include internal-use software license). The ASU should be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption and is effective for interim and annual periods beginning after December 15, 2019 with early adoption permitted. The Company prospectively adopted the standard in the third quarter of 2019, and it did not have a material impact on the consolidated financial position, results of operations, and cash flows.

[0000038725-20-000053:notes:42]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 ("Tax Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The ASU is effective for interim and annual periods beginning after December 15, 2018, with early adoption permitted, and may be applied either at the beginning of the period of adoption or retrospectively to each period in which the effect of the change in the U.S. federal corporate income tax rate in the Tax Act is recognized. The Company adopted the standard effective January 1, 2019 and did not reclassify tax effects stranded in accumulated other comprehensive loss. As such, there is no impact on the Company’s consolidated financial position, results of operations, and cash flows as a result of the adoption of the ASU.

[0000038725-20-000053:notes:43]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification (“ASC”) Topic 840. This ASU requires lessees to present right-of-use (“ROU”) assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases and ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-10 clarifies certain aspects of Topic 842, including the rate implicit in the lease, impairment of the

[0000038725-20-000053:notes:44]
net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options, variable payments that depend on an index or rate and certain transition adjustments, among other things. ASU 2018-11 allows entities adopting ASU 2016-02 to choose an additional (and optional) transition method of adoption, under which an entity initially applies the new lease standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. Additionally, ASU 2018-11 allows lessors to not separate non-lease components from the associated lease component if certain conditions are met. The guidance is to be applied using either the transition method prescribed in ASU 2018-11 or a modified retrospective approach at the beginning of the earliest comparative period in the financial statements.

[0000038725-20-000053:notes:45]
The Company adopted the standard effective January 1, 2019 utilizing the optional transition method prescribed in ASU 2018-11. The Company utilized the transition practical expedients, per ASC 842-10-65-11, that are permitted with the new standard when elected as a package. The Company will also utilize other available practical expedients, including the election not to separate non-lease components and the election to use hindsight when determining the lease terms. Finally, the Company has made an accounting policy election to not present leases with an initial term of 12 months or less (short-term leases) on the balance sheet.

[0000038725-20-000053:notes:46]
The Company has recorded on the balance sheet ROU assets and lease liabilities. The initial ROU asset at the implementation of the standard was approximately $32.9million with a corresponding lease liability of the same amount. The Company segregated the lease liabilities between short term and long term based on the related contractual maturities. The Company did not have an adjustment to retained earnings as a result of the adoption of this standard. Additional disclosures regarding the Company’s leases can be found in Note 1 - Summary of Significant Accounting Policies and Note 16 - Commitments and Contingencies.

[0000038725-20-000053:notes:47]
Accounting Standards Issued But Not Yet Adopted

[0000038725-20-000053:notes:48]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which modifies the disclosure requirements for employers that sponsor defined benefit pension or other postretirement plans. The amendments remove disclosures that no longer are considered cost beneficial, including the estimated amounts in accumulated other comprehensive income expected to be recognized as components of net periodic expense over the next fiscal year. The amendments clarify the specific requirements of disclosures, and add disclosure requirements identified as relevant, including the reasons for significant gains and losses related to change in the benefit obligation for the period.  The ASU should be applied retrospectively and is effective for interim and annual periods beginning after December 15, 2020. The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000053:notes:49]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company will adopt this standard effective January 1, 2020, but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000053:notes:50]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which modifies the measurement of expected credit losses on certain financial instruments, including trade receivables. ASU 2016-13 is effective for interim and annual periods beginning after December 15, 2019 with early adoption permitted. Amendments should be applied using a modified retrospective approach except for debt securities, which require a prospective transitions approach. The Company will adopt this standard effective January 1, 2020. Adoption is not expected to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is expected to reduce cost and complexity related to accounting for income taxes. ASU 2019-12 eliminates the need for the Company to analyze whether certain exceptions apply and improves financial statement preparers' application of income tax-related guidance. ASU 2019-12 is effective for interim and annual periods beginning after December 15, 2020 with early adoption permitted. Amendments related to franchise taxes that are partially based on income should be applied on either a retrospective or modified retrospective basis. All other amendments should be applied on a prospective basis. The Company is still determining the date of adoption of this ASU. Adoption is not expected to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-20-000053:notes:51]
ACQUISITIONS
During the third quarter ended September 30, 2019, the Company acquired 100 percent of the ownership interests of First Sales, LLC, an Indiana manufacturer of water treatment and filtration equipment for the residential and commercial markets, which are sold through some of the same channels as other Company products in the Water Systems segment, for a purchase price of approximately $15.5 million after working capital adjustments. Goodwill resulting from the acquisition consists primarily of complementary product offerings.  The operating results from the date of acquisition through December 31, 2019 were not material to the Company as a whole. Annual net sales are estimated to be less than two percent of consolidated net sales and the fair value of the acquired assets are estimated to be less than one percent of consolidated total assets. The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2019, as the results of operations for this acquisition is immaterial. The fair value of the assets acquired and liabilities assumed are preliminary as of December 31, 2019.

[0000038725-20-000053:notes:52]
During the second quarter ended June 30, 2019, the Company acquired the remaining interest in Pluga Pumps and Motors Private Limited, India, increasing the Company's ownership to 100 percent.  The redemption of this interest was immaterial.

[0000038725-20-000053:notes:53]
During the first quarter ended March 31, 2019, the Company acquired 100 percent of the ownership interests of Mt. Pleasant, Michigan-based Milan Supply Company ("Milan Supply"), for a purchase price of approximately $6.1 million after working capital adjustments. Milan Supply is a professional groundwater distributor operating six locations in the State of Michigan.  Milan Supply is part of the Company’s Distribution Segment, which is a collection of professional groundwater equipment distributors. The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2019, as the results of operations for this acquisition is immaterial. The fair value of the assets acquired and liabilities assumed are preliminary as of December 31, 2019.

[0000038725-20-000053:notes:54]
During the third quarter ended September 30, 2018, the Company acquired, in separate transactions, substantially all of the assets of the Stationary Power Division (“SPD”) of Midtronics, Inc., and 100 percent of the ownership interest in Industrias Rotor Pump S.A. (“Industrias Rotor Pump”), located in the United States and Argentina, respectively. Neither of the acquisitions were material individually or in the aggregate, and the final combined purchase price was $37 million. The operating results of the two businesses from their respective dates of acquisition through December 31, 2018 were not material to the Company as a whole. SPD offers a variety of products to users in the electrical substation monitoring, data center and mobile telecommunications markets. Annual net sales for SPD are approximately one percent of consolidated net sales and the fair value of the acquired assets are less than one percent of consolidated total assets. Industrias Rotor Pump is the leading provider of water pumping equipment in Argentina. Annual net sales for Industrias Rotor Pump are less than one percent of consolidated net sales and the fair value of the acquired assets are estimated to be less than three percent of consolidated total assets.

[0000038725-20-000053:notes:55]
The identifiable intangible assets recognized in the separate transactions were $17 million, and consist primarily of customer relationships, which will be amortized utilizing the straight-line method over 15 - 20 years.

[0000038725-20-000053:notes:56]
The goodwill of $14.2 million resulting from the separate acquisitions consists primarily of the benefits of complementary product offerings and expanded geographical presence. Goodwill was recorded in the Fueling and Water segments (see Note 6 - Goodwill and Other Intangible Assets), and only a portion ($4.1 million) is expected to be deductible for tax purposes. The fair value of assets acquired and liabilities assumed for both acquisitions were considered final as of the third quarter of 2019.

[0000038725-20-000053:notes:57]
The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interests since the beginning of 2018, as the results of operations for these acquisitions are immaterial.

[0000038725-20-000053:notes:58]
Prior to the acquisition of the Argentina entity the economy in Argentina was classified as highly inflationary.  Beginning from the date of acquisition, the Company will apply the requisite accounting for highly inflationary economies, and the functional currency of the entity will be the U.S. dollar.  Monetary assets and liabilities will be remeasured into U.S. dollars using exchange rates as of the latest balance sheet date while non-monetary assets and liabilities will be remeasured using historical exchange rates.  Remeasurement adjustments will be included in foreign exchange gain / (loss) on the consolidated statements of income.

[0000038725-20-000053:notes:59]
During the first quarter ended March 31, 2018, the Company acquired 100 percent of the ownership interests of Lansing, Michigan-based Valley Farms Supply, Inc. ("Valley Farms"). The fair value of assets acquired and liabilities assumed were considered final in the first quarter of 2019, and the final purchase price was  $9.5 million after working capital adjustments.  Valley Farms is a professional groundwater distributor operating four locations in the State of Michigan and one in the State of Indiana.  Valley Farms was acquired to serve customers in this region of the United States as part of the Company’s

[0000038725-20-000053:notes:60]
Distribution Segment, which is a collection of professional groundwater equipment distributors.  The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2018, as the results of operations for this acquisition is immaterial.

[0000038725-20-000053:notes:61]
During the second quarter of 2017, the Company redeemed 10 percent of the noncontrolling interest of Impo, a Turkish subsidiary, increasing the Company’s ownership to 100 percent for approximately Turkish Lira (TRY) 17.0 million, $5.0 million at the then current exchange rate.  The 10 percent redemption value was calculated using a specified formula and resulted in a reduction of the carrying value of TRY 0.6 million ($0.2 million).  Due to the immaterial nature of the redemption, the Company has not included full year proforma statements of income for the acquisition year or previous year.

[0000038725-20-000053:notes:62]
During the second quarter of 2017, the Company acquired controlling interests in three distributors (2M Company, Inc. (“2M”), Drillers Service, Inc. (“DSI”), and Western Hydro, LLC (“Western Hydro”), collectively referred to below as the “Headwater acquisitions”) in the U.S. professional groundwater market for a combined purchase price of approximately $57.4 million, subject to certain terms and conditions.  The Company had previously prepaid a $3.0 million portion of the purchase price at the time of original investment.  The Company funded the Headwater acquisitions with cash on hand and short-term borrowings from the Company’s Revolver (see Note 10 - Debt).  The Headwater acquisitions are reported within a new “Distribution” segment (see Note 15 - Segment Information).  The Headwater acquisitions provide the Company with a robust groundwater distribution channel throughout the United States.

[0000038725-20-000053:notes:63]
The Company previously held equity interests in these entities, each of which was less than 50 percent, and accounted for by the equity method of accounting.  The Company’s total interest in each of the entities is now 100 percent and the entities are included in the Company’s consolidated results effective from the date of acquisition.  The original equity interests in the acquired entities were remeasured to their fair values as of the acquisition date (which aggregated was $20.6 million) based on the income approach, which utilized management estimates and consultation with an independent third-party valuation firm.  Inputs included an analysis of the enterprise value based on financial projections and ownership percentages.

[0000038725-20-000053:notes:64]
Intangible assets recognized due to the Headwater acquisitions were $5.7 million, and consist of customer relationships, which will be amortized utilizing the straight-line method over 15 years.  The fair value of the identifiable intangible assets has been estimated using an income approach, a valuation method that values an intangible asset by discounting the future incremental earnings that may be achieved by the subject intangible asset.

[0000038725-20-000053:notes:65]
The goodwill of $33.9 million resulting from the Headwater acquisitions consists primarily of the benefits of forward channel integration opportunities and broadened product offerings. All of the goodwill was recorded as part of the Distribution segment, and only a portion ($7.8 million) is expected to be deductible for tax purposes.

[0000038725-20-000053:notes:66]
The final purchase price assigned to the major identifiable assets and liabilities for the Headwater acquisitions on an aggregated basis is as follows:

[0000038725-20-000053:notes:67]
| (In millions) |  |  |
| Cash |  | $ | 2.7 |  |
| Receivables |  | 29.9 |  |
| Inventory |  | 56.0 |  |
| Other current assets |  | 5.1 |  |
| Total current assets |  | 93.7 |  |
| Property, plant, and equipment |  | 9.8 |  |
| Intangible assets |  | 5.7 |  |
| Goodwill |  | 33.9 |  |
| Other assets |  | 0.2 |  |
| Total assets |  | 143.3 |  |
| Accounts payable |  | (19.6) |  |
| Accrued liabilities and other current liabilities |  | (11.4) |  |
| Current maturities of long-term debt |  | (31.6) |  |
| Total current liabilities |  | (62.6) |  |
| Long-term debt |  | (2.0) |  |
| Other long-term liabilities |  | (0.7) |  |
| Total liabilities |  | (65.3) |  |
| Total |  | 78.0 |  |
| Less: Fair value of original equity interest |  | (20.6) |  |
| Total purchase price |  | $ | 57.4 |  |

[0000038725-20-000053:notes:68]
The fair values of the assets acquired and liabilities assumed related to the Headwater acquisitions were final as of June 30, 2018.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation process.

[0000038725-20-000053:notes:69]
The following unaudited proforma financial information for the year ended December 31, 2019, December 31, 2018 and December 31, 2017 gives effect to the Headwater acquisitions as if the acquisitions had occurred as of January 1, 2017. These unaudited proforma condensed consolidated financial statements are prepared for informational purposes only and are not necessarily indicative of actual results or financial position that would have been achieved had the acquisitions been consummated on the dates indicated and are not necessarily indicative of future operating results or financial position of the consolidated companies.  The unaudited proforma condensed consolidated financial statements do not give effect to any cost savings or incremental costs that may result from the integration of the Headwater acquisitions.

[0000038725-20-000053:notes:70]
| FRANKLIN ELECTRIC CO., INC. |  |  |  |  |  |  |
| PROFORMA CONDENSED CONSOLIDATED STATEMENTS OF INCOME |  |  |  |  |  |  |
| (in millions, except per share amounts) |  | 2019 |  | 2018 |  | 2017 |
| Revenue: |  |  |  |  |  |  |
| As reported |  | $ | 1,314.6 |  |  | $ | 1,298.1 |  |  | $ | 1,124.9 |  |
| Proforma |  | 1,314.6 |  |  | 1,298.1 |  |  | 1,184.8 |  |
| Net income attributable to Franklin Electric Co., Inc.: |  |  |  |  |  |  |
| As reported |  | $ | 95.5 |  |  | $ | 105.9 |  |  | $ | 78.2 |  |
| Proforma |  | 95.5 |  |  | 105.9 |  |  | 79.4 |  |
| Basic earnings per share: |  |  |  |  |  |  |
| As reported |  | $ | 2.04 |  |  | $ | 2.25 |  |  | $ | 1.67 |  |
| Proforma |  | 2.04 |  |  | 2.25 |  |  | 1.70 |  |
| Diluted earnings per share: |  |  |  |  |  |  |
| As reported |  | $ | 2.03 |  |  | $ | 2.23 |  |  | $ | 1.65 |  |
| Proforma |  | 2.03 |  |  | 2.23 |  |  | 1.68 |  |

[0000038725-20-000053:notes:71]
Transaction costs for all acquisition related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations.  Transaction costs included in selling, general, and administrative expense in the Company’s consolidated statements of income were $0.2 million, $0.4 million, and $0.6 million for the years ended 2019, 2018, and 2017, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-20-000053:notes:72]
FAIR VALUE MEASUREMENTS
As of December 31, 2019 and December 31, 2018, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-20-000053:notes:73]
| (In millions) |  | December 31, 2019 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |  |
|  |  | December 31, 2018 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  |
| Cash equivalents |  | $ | 2.5 |  |  | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |  |

[0000038725-20-000053:notes:74]
The Company’s Level 1 assets consist of cash equivalents which are generally comprised of foreign bank guaranteed certificates of deposit.

[0000038725-20-000053:notes:75]
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3 excluding the recurring fair value measurements in the Company's pension and other retirement plans as discussed in Note 7 - Employee Benefit Plans.
Total debt, including current maturities, have carrying amounts of $115.0 million at December 31, 2019 and $206.3 million at December 31, 2018.  The estimated fair value of all debt was $121 million and $205 million at December 31, 2019 and December 31, 2018, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-20-000053:notes:76]
FINANCIAL INSTRUMENTSThe Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements (“the swap”) to mitigate the Company’s exposure to these fluctuations in the Company’s stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  As of December 31, 2019, the swap has a notional value based on 255,000 shares.  For the years ended December 31, 2019, December 31, 2018, and December 31, 2017, the swap resulted in a gain of $3.4 million, a loss of $1.0 million, and a gain of $1.4 million, respectively.  Gains and losses resulting from the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company’s consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-20-000053:notes:77]
GOODWILL AND OTHER INTANGIBLE ASSETS
The carrying amounts of the Company’s intangible assets are as follows:

[0000038725-20-000053:notes:78]
| (In millions) |  | 2019 |  |  |  | 2018 |  |  |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.4 |  |  | $ | (7.0) |  |  | $ | 7.5 |  |  | $ | (6.9) |  |
| Technology |  | 7.5 |  |  | (6.8) |  |  | 7.5 |  |  | (6.4) |  |
| Customer relationships |  | 155.4 |  |  | (71.4) |  |  | 151.0 |  |  | (63.8) |  |
| Other |  | 3.8 |  |  | (2.8) |  |  | 2.8 |  |  | (2.5) |  |
| Total |  | $ | 174.1 |  |  | $ | (88.0) |  |  | $ | 168.8 |  |  | $ | (79.6) |  |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 45.0 |  |  | — |  |  | 45.9 |  |  | — |  |
| Total intangibles |  | $ | 219.1 |  |  | $ | (88.0) |  |  | $ | 214.7 |  |  | $ | (79.6) |  |

[0000038725-20-000053:notes:79]
Amortization expense related to intangible assets for fiscal years 2019, 2018, and 2017, was $9.4 million, $8.9 million, and $8.6 million, respectively.

[0000038725-20-000053:notes:80]
Amortization expense for each of the five succeeding years is projected as follows:

[0000038725-20-000053:notes:81]
| (In millions) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |
|  |  | $ | 9.4 |  |  | $ | 9.0 |  |  | $ | 8.8 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |

[0000038725-20-000053:notes:82]
The change in the carrying amount of goodwill by reportable segment for 2019 and 2018, is as follows:

[0000038725-20-000053:notes:83]
| (In millions) |  |  |  |  |  |  |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2017 |  | $ | 139.3 |  |  | $ | 63.6 |  |  | $ | 33.9 |  |  | $ | 236.8 |  |
| Acquisitions |  | 10.1 |  |  | 4.1 |  |  | 1.8 |  |  | 16.0 |  |
| Foreign currency translation |  | (3.9) |  |  | (0.2) |  |  | — |  |  | (4.1) |  |
| Balance as of December 31, 2018 |  | $ | 145.5 |  |  | $ | 67.5 |  |  | $ | 35.7 |  |  | $ | 248.7 |  |
| Acquisitions |  | 6.4 |  |  | — |  |  | 1.8 |  |  | 8.2 |  |
| Foreign currency translation |  | (0.9) |  |  | 0.1 |  |  | — |  |  | (0.8) |  |
| Balance as of December 31, 2019 |  | $ | 151.0 |  |  | $ | 67.6 |  |  | 37.5 |  |  | $ | 256.1 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-20-000053:notes:84]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of December 31, 2019, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2019 measurement date for these plans.  One of the Company’s domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the ‘Pension Benefits’ disclosure caption.

[0000038725-20-000053:notes:85]
Other Benefits - The Company’s other post-retirement benefit plan provides health and life insurance to domestic employees hired prior to 1992.  The Company effectively capped its cost for those benefits through plan amendments made in 1992, freezing Company contributions for insurance benefits at 1991 levels for current and future beneficiaries with actuarially reduced benefits for employees who retire before age 65.  The disclosures surrounding this plan are reflected in the “Other Benefits” caption.

[0000038725-20-000053:notes:86]
The following table sets forth aggregated information related to the Company’s pension benefits and other postretirement benefits, including changes in the benefit obligations, changes in plan assets, funded status, amounts recognized in the balance sheet, amounts recognized in accumulated other comprehensive income, and actuarial assumptions that the Company considered in its determination of benefit obligations and plan costs.  Benefit obligation balances presented below reflect the projected benefit obligation (PBO) for the Company’s pension plans, and accumulated postretirement benefit obligations (APBO) for the Company’s other benefit plans.

[0000038725-20-000053:notes:87]
| (In millions) |  | Pension Benefits |  |  |  | Other Benefits |  |  |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Accumulated benefit obligation, end of year |  | $ | 176.5 |  |  | $ | 164.9 |  |  | $ | 8.3 |  |  | $ | 9.1 |  |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |
| Benefit obligation, beginning of year |  | $ | 168.9 |  |  | $ | 185.1 |  |  | $ | 9.1 |  |  | $ | 10.3 |  |
| Service cost |  | 0.7 |  |  | 0.6 |  |  | — |  |  | — |  |
| Interest cost |  | 5.8 |  |  | 5.4 |  |  | 0.3 |  |  | 0.3 |  |
| Actuarial (gain)/loss |  | 17.0 |  |  | (9.5) |  |  | (0.2) |  |  | (0.5) |  |
| Settlements paid |  | (0.7) |  |  | (0.3) |  |  | — |  |  | — |  |
| Benefits paid |  | (10.3) |  |  | (11.4) |  |  | (0.9) |  |  | (1.0) |  |
| Foreign currency exchange |  | (0.5) |  |  | (1.0) |  |  | — |  |  | — |  |
| Benefit obligation, end of year |  | $ | 180.9 |  |  | $ | 168.9 |  |  | $ | 8.3 |  |  | $ | 9.1 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of assets, beginning of year |  | $ | 140.1 |  |  | $ | 153.3 |  |  | $ | — |  |  | $ | — |  |
| Actual return on plan assets |  | 20.0 |  |  | (3.8) |  |  | — |  |  | — |  |
| Company contributions |  | 2.0 |  |  | 2.5 |  |  | 0.9 |  |  | 1.0 |  |
| Settlements paid |  | (0.5) |  |  | (0.3) |  |  | — |  |  | — |  |
| Benefits paid |  | (10.3) |  |  | (11.4) |  |  | (0.9) |  |  | (1.0) |  |
| Foreign currency exchange |  | (0.1) |  |  | (0.2) |  |  | — |  |  | — |  |
| Plan assets, end of year |  | $ | 151.2 |  |  | $ | 140.1 |  |  | $ | — |  |  | $ | — |  |
| Funded status |  | $ | (29.7) |  |  | $ | (28.8) |  |  | $ | (8.3) |  |  | $ | (9.1) |  |
| Amounts recognized in balance sheet: |  |  |  |  |  |  |  |  |
| Current liabilities |  | $ | (0.5) |  |  | $ | (0.4) |  |  | $ | (0.8) |  |  | $ | (1.0) |  |
| Noncurrent liabilities |  | (29.2) |  |  | (28.4) |  |  | (7.5) |  |  | (8.1) |  |
| Net liability, end of year |  | $ | (29.7) |  |  | $ | (28.8) |  |  | $ | (8.3) |  |  | $ | (9.1) |  |
| Amount recognized in accumulated other comprehensive income/(loss): |  |  |  |  |  |  |  |  |
| Prior service cost |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net actuarial loss |  | 49.0 |  |  | 47.5 |  |  | 0.4 |  |  | 0.6 |  |
| Settlement |  | 0.6 |  |  | 0.4 |  |  | — |  |  | — |  |
| Total recognized in accumulated other comprehensive income/(loss) |  | $ | 49.6 |  |  | $ | 47.9 |  |  | $ | 0.4 |  |  | $ | 0.6 |  |

[0000038725-20-000053:notes:88]
The following table sets forth other changes in plan assets and benefit obligation recognized in other comprehensive income for 2019 and 2018:

[0000038725-20-000053:notes:89]
| (In millions) |  | Pension Benefits |  |  |  | Other Benefits |  |  |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net actuarial (gain)/loss |  | $ | 5.2 |  |  | $ | 2.8 |  |  | $ | (0.2) |  |  | $ | (0.5) |  |
| Amortization of: |  |  |  |  |  |  |  |  |
| Net actuarial gain |  | (2.2) |  |  | (2.5) |  |  | (0.1) |  |  | (0.2) |  |
| Prior service credit |  | — |  |  | — |  |  | — |  |  | (0.1) |  |
| Settlement recognition |  | (0.6) |  |  | (0.5) |  |  | — |  |  | — |  |
| Deferred tax asset |  | (0.6) |  |  | 0.1 |  |  | 0.1 |  |  | 0.2 |  |
| Foreign currency exchange |  | (0.1) |  |  | (0.1) |  |  | — |  |  | — |  |
| Total recognized in other comprehensive income |  | $ | 1.7 |  |  | $ | (0.2) |  |  | $ | (0.2) |  |  | $ | (0.6) |  |

[0000038725-20-000053:notes:90]
Weighted-average assumptions used to determine domestic benefit obligations:

[0000038725-20-000053:notes:91]
|  |  | Pension Benefits |  |  |  | Other Benefits |  |  |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Discount rate |  | 3.12 | % |  | 4.28 | % |  | 2.98 | % |  | 4.18 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | 3.00 - 8.00%(Graded) |  | 3.00 - 8.00%(Graded) |

[0000038725-20-000053:notes:92]
*No rate of increases in future compensation were used in the assumptions for 2019 and 2018, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation.

[0000038725-20-000053:notes:93]
Assumptions used to determine domestic periodic benefit cost:

[0000038725-20-000053:notes:94]
|  |  | Pension Benefits |  |  |  |  |  | Other Benefits |  |  |  |  |
|  |  | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| Discount rate |  | 4.31 | % |  | 3.64 | % |  | 4.13 | % |  | 4.18 | % |  | 3.51 | % |  | 3.91 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | — | % | * | 3.00 - 8.00%(Graded) |  | 3.00 - 8.00%(Graded) |  | 3.00 - 8.00%(Graded) |
| Expected long-term rate of return on plan assets |  | 5.75 | % |  | 5.90 | % |  | 6.25 | % |  | — | % |  | — | % |  | — | % |

[0000038725-20-000053:notes:95]
*No rate of increases in future compensation were used in the assumptions for 2019, 2018, and 2017, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation.

[0000038725-20-000053:notes:96]
For the fiscal year ended December 31, 2019, the Company used the RP-2014 aggregate table adjusted to back out estimated mortality improvements from 2006 to the measurement date using Scale MP-2014, and then projected forward using Scale MP-2018 released by the Society of Actuaries during 2018 to estimate future mortality rates based upon current data. For the fiscal year ended December 31, 2018, the Company used the RP-2014 aggregate table adjusted to back out estimated mortality improvements from 2006 to the measurement date using Scale MP-2014, and then projected forward using Scale MP-2017 released by the Society of Actuaries during 2017 to estimate future mortality rates.

[0000038725-20-000053:notes:97]
The following table sets forth the aggregated net periodic benefit cost for all defined benefit plans for 2019, 2018, and 2017:

[0000038725-20-000053:notes:98]
| (In millions) | Pension Benefits |  |  |  |  |  | Other Benefits |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| Service cost | $ | 0.7 |  |  | $ | 0.6 |  |  | $ | 0.7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 5.8 |  |  | 5.4 |  |  | 5.6 |  |  | 0.3 |  |  | 0.3 |  |  | 0.3 |  |
| Expected return on assets | (8.1) |  |  | (8.5) |  |  | (9.0) |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Transition obligation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |  | 0.3 |  |
| Actuarial loss | 2.6 |  |  | 2.9 |  |  | 2.8 |  |  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 1.0 |  |  | $ | 0.4 |  |  | $ | 0.1 |  |  | $ | 0.4 |  |  | $ | 0.6 |  |  | $ | 0.7 |  |

[0000038725-20-000053:notes:99]
The estimated net actuarial (gain)/loss and prior service cost/(credit) that will be amortized from accumulated other comprehensive income into net periodic benefit cost during 2020 are $3.5 million and $0.0 million, respectively, for the pension plans and $0.0 million and $0.0 million, respectively, for all other benefits.

[0000038725-20-000053:notes:100]
The Company consults with a third party investment manager for the assets of the funded domestic defined benefit plan.  The plan assets are currently invested primarily in pooled funds, where each fund in turn is composed of mutual funds that have at least daily net asset valuations.  Thus, the Company’s funded domestic defined benefit plan assets are invested in a “fund of funds” approach.

[0000038725-20-000053:notes:101]
The Company’s Board has delegated oversight and guidance to an appointed Employee Benefits Committee.  The Committee has the tasks of reviewing plan performance and asset allocation, ensuring plan compliance with applicable laws, establishing plan policies, procedures, and controls, monitoring expenses, and other related activities.

[0000038725-20-000053:notes:102]
The plan’s investment policies and strategies focus on the ability to fund benefit obligations as they come due.  Considerations include the plan’s current funded level, plan design, benefit payment assumptions, funding regulations, impact of potentially volatile business results on the Company’s ability to make certain levels of contributions, and interest rate and asset return volatility among other considerations.  The Company currently attempts to maintain plan funded status at approximately 80 percent or greater pursuant to the Pension Protection Act of 2007.  Given the plan’s current funded status, the Company’s cash on hand, cash historically generated from business operations, and cash available under committed credit facilities, the Company sees ample liquidity to achieve this goal.

[0000038725-20-000053:notes:103]
Risk management and continuous monitoring requirements are met through monthly investment portfolio reports, quarterly Employee Benefits Committee meetings, annual valuations, asset/liability studies, and the annual assumption process focusing primarily on the return on asset assumption and the discount rate assumption.  As of December 31, 2019 and December 31, 2018, funds were invested in equity, fixed income, and other investments as follows:

[0000038725-20-000053:notes:104]
|  |  | Target Percentage |  | Plan Asset Allocation at Year-End |  |  |
| Asset Category |  | at Year-End 2019 |  | 2019 |  | 2018 |
| Equity securities |  | 19 | % |  | 19 | % |  | 21 | % |
| Fixed income securities |  | 77 | % |  | 77 | % |  | 75 | % |
| Other |  | 4 | % |  | 4 | % |  | 4 | % |
| Total |  | 100 | % |  | 100 | % |  | 100 | % |

[0000038725-20-000053:notes:105]
The Company does not see any particular concentration of risk within the plans, nor any plan assets that pose difficulties for fair value assessment.  The Company currently has no allocation to potentially illiquid or potentially difficult to value assets such as hedge funds, venture capital, private equity, and real estate.

[0000038725-20-000053:notes:106]
The Company works with actuaries and consultants in making its determination of the asset rate of return assumption and also the discount rate assumption.

[0000038725-20-000053:notes:107]
Asset class assumptions are set using a combination of empirical and forward-looking analysis for long-term rate of return on plan assets.  A variety of models are applied for filtering historical data and isolating the fundamental characteristics of asset classes.  These models provide empirical return estimates for each asset class, which are then reviewed and combined with a qualitative assessment of long-term relationships between asset classes before a return estimate is finalized.  This provides an additional means for correcting for the effect of unrealistic or unsustainable short-term valuations or trends, opting instead for return levels and behavior that are more likely to prevail over long periods.  With that, the Company has assumed an expected long-term rate of return on plan assets of 4.90 percent for the 2020 net periodic benefit cost, down from 5.75 percent in the prior year.  This decrease in the assumed long-term rate of return is primarily due to a higher percentage of assets in fixed income securities.

[0000038725-20-000053:notes:108]
The Company uses the Aon Hewitt AA Above Median curve to determine the discount rate.  All cash flow obligations under the plan are matched to bonds in the Aon Hewitt universe of liquid, high-quality, non-callable / non-putable corporate bonds with outliers removed.  From that matching exercise, a discount rate is determined.

[0000038725-20-000053:notes:109]
The Company’s German pension plans are funded by insurance contract policies whereby the insurance company guarantees a fixed minimum return.  Due to tax legislation, individual pension benefits can only be financed using direct insurance policies up to certain maximums.  These maximum amounts in respect of each member are paid into such an arrangement on a yearly basis.

[0000038725-20-000053:notes:110]
The Company designated all equity and most domestic fixed income plan assets as Level 1, as they are mutual funds with prices that are readily available.  The U.S. Treasury securities and German plan assets are designated as Level 2 inputs.  The fair value of the German plan assets are measured by the reserve that is supervised by the German Federal Financial Supervisory Authority.  The U.S. Treasury securities are administered by the United States government.

[0000038725-20-000053:notes:111]
The fair values of the Company’s pension plan assets for 2019 and 2018 by asset category are as follows:

[0000038725-20-000053:notes:112]
| (In millions) |  | 2019 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| International equity mutual funds |  | $ | 29.1 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 17.5 |  |  | — |  |  | 17.5 |  |  | — |  |
| Fixed income mutual funds |  | 99.3 |  |  | 99.3 |  | — |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.5 |  |  | — |  |  | 4.5 |  |  | — |  |
| Cash and equivalents |  | 0.8 |  |  | 0.8 |  |  | — |  |  | — |  |
| Total |  | $ | 151.2 |  |  | $ | 129.2 |  |  | $ | 22.0 |  |  | $ | — |  |

[0000038725-20-000053:notes:113]
| (In millions) |  | 2018 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| International equity mutual funds |  | $ | 28.9 |  |  | $ | 28.9 |  |  | $ | — |  |  | $ | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 20.4 |  |  | — |  |  | 20.4 |  | — |  | — |  |
| Fixed income mutual funds |  | 85.1 |  |  | 85.1 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.9 |  |  | — |  |  | 4.9 |  |  | — |  |
| Cash and equivalents |  | 0.8 |  |  | 0.8 |  |  | — |  |  | — |  |
| Total |  | $ | 140.1 |  |  | $ | 114.8 |  |  | $ | 25.3 |  |  | $ | — |  |

[0000038725-20-000053:notes:114]
The Company estimates total contributions to the plans of about $1 million in 2020.

[0000038725-20-000053:notes:115]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid in accordance with the following schedule:

[0000038725-20-000053:notes:116]
| (In millions) |  | Pension Benefits |  | Other Benefits |
| 2020 |  | $ | 11.3 |  |  | $ | 0.8 |  |
| 2021 |  | 11.0 |  |  | 0.8 |  |
| 2022 |  | 10.8 |  |  | 0.7 |  |
| 2023 |  | 10.6 |  |  | 0.7 |  |
| 2024 |  | 15.7 |  |  | 0.7 |  |
| Years 2025 through 2029 |  | 51.8 |  |  | 2.7 |  |

[0000038725-20-000053:notes:117]
Defined Contribution Plans - The Company maintained two defined contribution plans during 2019, 2018, and 2017.  The Company’s cash contributions are allocated to participant’s accounts based on investment elections.

[0000038725-20-000053:notes:118]
The following table sets forth Company contributions to the defined contribution plans:

[0000038725-20-000053:notes:119]
| (In millions) |  | 2019 |  | 2018 |  | 2017 |
| Company contributions to the plans |  | $ | 7.4 |  |  | $ | 6.8 |  |  | $ | 6.7 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000038725-20-000053:notes:120]
ACCRUED EXPENSES AND OTHER CURRENT LIABILITIES
Accrued expenses and other current liabilities consist of:

[0000038725-20-000053:notes:121]
| (In millions) |  | 2019 |  | 2018 |
| Salaries, wages, and commissions |  | $ | 28.6 |  |  | $ | 30.7 |  |
| Product warranty costs |  | 9.1 |  |  | 9.0 |  |
| Insurance |  | 2.6 |  |  | 2.5 |  |
| Employee benefits |  | 9.9 |  |  | 9.5 |  |
| Other |  | 18.2 |  |  | 13.1 |  |
|  |  | $ | 68.4 |  |  | $ | 64.8 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-20-000053:notes:122]
INCOME TAXES
Income before income taxes consisted of the following:

[0000038725-20-000053:notes:123]
| (In millions) |  | 2019 |  | 2018 |  | 2017 |
| Domestic |  | $ | 55.5 |  |  | $ | 54.7 |  |  | $ | 47.1 |  |
| Foreign |  | 61.3 |  |  | 65.7 |  |  | 57.5 |  |
|  |  | $ | 116.8 |  |  | $ | 120.4 |  |  | $ | 104.6 |  |

[0000038725-20-000053:notes:124]
The income tax provision/(benefit) from continuing operations consisted of the following:

[0000038725-20-000053:notes:125]
| (In millions) |  | 2019 |  | 2018 |  | 2017 |
| Current: |  |  |  |  |  |  |
| Federal |  | $ | 6.9 |  |  | $ | 4.6 |  |  | $ | 29.7 |  |
| Foreign |  | 15.1 |  |  | 14.3 |  |  | 10.2 |  |
| State |  | 1.4 |  |  | 1.2 |  |  | 1.1 |  |
| Total current |  | 23.4 |  |  | 20.1 |  |  | 41.0 |  |
| Deferred: |  |  |  |  |  |  |
| Federal |  | (0.6) |  |  | 3.6 |  |  | (10.7) |  |
| Foreign |  | (2.5) |  |  | (2.6) |  |  | (4.5) |  |
| State |  | 0.5 |  |  | (6.2) |  |  | 0.2 |  |
| Total deferred |  | $ | (2.6) |  |  | $ | (5.2) |  |  | $ | (15.0) |  |
|  |  | $ | 20.8 |  |  | $ | 14.9 |  |  | $ | 26.0 |  |

[0000038725-20-000053:notes:126]
A reconciliation of the tax provision for continuing operations at the U.S. statutory rate to the effective income tax expense rate as reported is as follows:

[0000038725-20-000053:notes:127]
|  |  | 2019 |  | 2018 |  | 2017 |
| U.S. Federal statutory rate |  | 21.0 | % |  | 21.0 | % |  | 35.0 | % |
| State income taxes, net of federal benefit |  | 1.1 |  |  | 1.1 |  |  | 1.0 |  |
| Foreign operations |  | (1.0) |  |  | (3.5) |  |  | (10.2) |  |
| R&D tax credits |  | (0.8) |  |  | (0.7) |  |  | (0.9) |  |
| Uncertain tax position adjustments |  | (0.6) |  |  | (0.5) |  |  | (0.5) |  |
| Deferred tax adjustments - restructuring and rate adjustments |  | — |  |  | — |  |  | (1.2) |  |
| Valuation allowance on state and foreign deferred tax |  | 0.4 |  |  | (2.4) |  |  | (1.2) |  |
| Purchase of noncontrolling interest |  | — |  |  | — |  |  | (2.3) |  |
| Share-based compensation |  | (0.8) |  |  | (1.3) |  |  | (1.9) |  |
| Realized foreign currency loss |  | (0.4) |  |  | (0.1) |  |  | (1.5) |  |
| Other items |  | 0.9 |  |  | 0.9 |  |  | (1.3) |  |
| Impact of the Tax Act |  |  |  |  |  |  |
| Transition tax |  | — |  |  | 0.5 |  |  | 18.1 |  |
| Deferred tax effects |  | — |  |  | (0.3) |  |  | (8.3) |  |
| Foreign Derived Intangible Income |  | (2.0) |  |  | (2.3) |  |  | — |  |
| Effective tax rate |  | 17.8 | % |  | 12.4 | % |  | 24.8 | % |

[0000038725-20-000053:notes:128]
The effective tax rate continues to be lower than the statutory rate of 21 percent primarily due to foreign earnings taxed at rates below the U.S. statutory rate, as well as recognition of the U.S. deduction for Foreign Derived Intangible Income, and certain incentives and discrete events.

[0000038725-20-000053:notes:129]
The Company recorded discrete excess tax benefits from share-based compensation of $1.3 million in the twelve-month period ended December 31, 2019 pursuant to ASU 2016-09. ASU 2016-09 can add variability to the Company’s provision for income taxes, mainly due to the timing of stock option exercises, vesting of restricted stock, and the stock price.

[0000038725-20-000053:notes:130]
During the twelve-month period ended December 31, 2018, the Company recorded a net discrete benefit related to the release of valuation allowances on deferred taxes of $4.2 million in domestic and foreign jurisdictions.

[0000038725-20-000053:notes:131]
The U.S. Tax Cuts and Jobs Act (Tax Act) was enacted on December 22, 2017 and introduced significant changes to U.S. income tax law. Effective in 2018, the Tax Act reduced the U.S. statutory tax rate from 35 percent to 21 percent, modified existing provisions, and created new provisions including a U.S. based foreign export incentive referred to as Foreign Derived Intangible Income.

[0000038725-20-000053:notes:132]
Significant components of the Company’s deferred tax assets and liabilities were as follows:

[0000038725-20-000053:notes:133]
| (In millions) |  | 2019 |  | 2018 |
| Deferred tax assets: |  |  |  |  |
| Accrued expenses and reserves |  | $ | 10.1 |  |  | $ | 9.4 |  |
| Compensation and employee benefits |  | 17.7 |  |  | 16.2 |  |
| Net operating losses, tax credit carryforwards, and other |  | 18.8 |  |  | 18.1 |  |
| Lease liability |  | 7.0 |  |  | — |  |
| Valuation allowance on state and foreign deferred tax |  | (6.4) |  |  | (6.8) |  |
| Total deferred tax assets |  | 47.2 |  |  | 36.9 |  |
| Deferred tax liabilities: |  |  |  |  |
| Accelerated depreciation on fixed assets |  | 11.9 |  |  | 12.2 |  |
| Amortization of intangibles |  | 46.5 |  |  | 45.0 |  |
| Right-of-Use asset, net |  | 7.0 |  |  | — |  |
| Other items |  | 0.2 |  |  | — |  |
| Total deferred tax liabilities |  | 65.6 |  |  | 57.2 |  |
| Net deferred tax liabilities |  | $ | (18.4) |  |  | $ | (20.3) |  |

[0000038725-20-000053:notes:134]
The Company assesses the available positive and negative evidence to estimate whether sufficient future taxable income will be generated to permit use of the existing deferred tax assets. A significant piece of objective negative evidence evaluated was the cumulative loss for certain state and foreign income tax purposes incurred over the 3-year period ended December 31, 2019. Such objective evidence limits the ability to consider other subjective evidence, such as our projections for future growth.

[0000038725-20-000053:notes:135]
On the basis of this evaluation, as of December 31, 2019, a valuation allowance of $6.4 million has been recorded to recognize only the portion of the deferred tax assets that are more likely than not to be realized.  The Company has foreign income tax net operating loss (“NOL”) and credit carryforwards of $12.0 million and state income tax NOL and credit carryforwards of $6.8 million, which will expire on various dates as follows:

[0000038725-20-000053:notes:136]
| (In millions) |  |
| 2020-2024 | $ | 2.6 |  |
| 2025-2029 | 4.2 |  |
| 2030-2034 | 1.9 |  |
| 2035-2039 | 0.6 |  |
| Unlimited | 9.5 |  |
|  | $ | 18.8 |  |

[0000038725-20-000053:notes:137]
The Company believes that it is more likely than not that the benefit from certain foreign NOL carryforwards as well as certain state credit carryforwards will not be realized.  In recognition of this risk, the Company has provided a valuation allowance of $4.6 million on the deferred tax assets related to these foreign NOL carryforwards and a valuation allowance of $1.8 million on the deferred tax assets related to these state credit carryforwards.

[0000038725-20-000053:notes:138]
As of December 31, 2019, the Company has accumulated undistributed earnings generated by our foreign subsidiaries of approximately $438.1 million. Any taxes due with respect to such earnings or the excess of the amount for financial reporting over the tax basis of our foreign investments would generally be limited to foreign and state taxes. The Company intends, however, to indefinitely reinvest these earnings and expects future U.S. cash generation to be sufficient to meet future U.S. cash needs.  The Company, therefore, has not recorded a deferred tax liability of $4.8 million.

[0000038725-20-000053:notes:139]
As of the beginning of fiscal year 2019, the Company had gross unrecognized tax benefits of $1.1 million, excluding accrued interest and penalties. The unrecognized tax benefits increased due to uncertain tax positions identified in the current year based on evaluations made during 2019. The Company had gross unrecognized tax benefits, excluding accrued interest and penalties, of $0.4 million as of December 31, 2019.

[0000038725-20-000053:notes:140]
A reconciliation of the beginning and ending amount of gross unrecognized tax benefits for 2019, 2018, and 2017 (excluding interest and penalties) is as follows:

[0000038725-20-000053:notes:141]
| (In millions) |  | 2019 |  | 2018 |  | 2017 |
| Beginning balance |  | $ | 1.1 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |
| Additions for tax positions of the current year |  | — |  |  | — |  |  | 0.4 |  |
| Additions for tax positions of prior years |  | — |  |  | 0.3 |  |  | 0.2 |  |
| Reductions for tax positions of prior years |  | (0.4) |  |  | — |  |  | — |  |
| Statute expirations |  | (0.3) |  |  | (0.5) |  |  | (0.6) |  |
| Settlements |  | — |  |  | — |  |  | — |  |
| Ending balance |  | $ | 0.4 |  |  | $ | 1.1 |  |  | $ | 1.3 |  |

[0000038725-20-000053:notes:142]
If recognized, each annual effective tax rate would be affected by the net unrecognized tax benefits of $0.4 million, $1.0 million, and $1.3 million as of year-end 2019, 2018, and 2017, respectively.

[0000038725-20-000053:notes:143]
The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.  In 2019, interest and penalties decreased $0.2 million, for prior year tax positions.  The Company has accrued interest and penalties as of December 31, 2019, December 31, 2018, and December 31, 2017 of approximately $0.1 million, $0.3 million, and $0.6 million, respectively.

[0000038725-20-000053:notes:144]
The Company is subject to taxation in the United States and various state and foreign jurisdictions.  With few exceptions, as of December 31, 2019, the Company is no longer subject to U.S. federal income tax examinations by tax authorities for years before 2016 and is no longer subject to foreign or state income tax examinations by tax authorities for years before 2014.

[0000038725-20-000053:notes:145]
It is reasonably possible that the amounts of unrecognized tax benefits could change in the next twelve months as a result of an audit or due to the expiration of a statute of limitation.  Based on the current audits in process and pending statute expirations, the payment of taxes as a result could be up to $0.5 million.


## us-gaap:DebtDisclosureTextBlock

[0000038725-20-000053:notes:146]
DEBT
Debt consisted of the following:

[0000038725-20-000053:notes:147]
| (In millions) |  | 2019 |  | 2018 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 19.0 |  |  | 76.3 |  |
| Prudential Agreement |  | — |  |  | 30.0 |  |
| Tax increment financing debt |  | 18.7 |  |  | 19.8 |  |
| Financing leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 2.3 |  |  | 5.4 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.2) |  |
|  |  | 115.0 |  |  | 206.4 |  |
| Less current maturities |  | (21.9) |  |  | (112.0) |  |
| Long-term debt |  | $ | 93.1 |  |  | $ | 94.4 |  |

[0000038725-20-000053:notes:148]
Debt outstanding at December 31, 2019, excluding unamortized debt issuance costs, matures as follows:

[0000038725-20-000053:notes:149]
| (In millions) |  | Total |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
| Debt |  | $ | 115.0 |  |  | $ | 21.8 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 88.0 |  |
| Financing leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 115.1 |  |  | $ | 21.9 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 88.0 |  |

[0000038725-20-000053:notes:150]
New York Life Agreement

[0000038725-20-000053:notes:151]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the “New York Life Agreement”) for $150.0 million maximum aggregate principal borrowing capacity.  On October 28, 2016, the Company entered into the First Amendment to the Note Purchase and Private Shelf Agreement.  The Amendment was intended to make the covenants within the New York Life Agreement consistent with the covenants that were modified in the Third Amended and Restated Credit Agreement (the “Credit Agreement”).   On September 26, 2018 the Company entered into the Second Amendment to the Note Purchase and Private Shelf Agreement which  increased the aggregate borrowing capacity to $200.0 million and authorized the issuance of $75.0 million of fixed rate senior noted due September 26, 2025.  These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable rate indebtedness with New York Life.  As of December 31, 2019, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-20-000053:notes:152]
Project Bonds

[0000038725-20-000053:notes:153]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement.  Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).”  The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million.  The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (“Tax increment financing debt”) bear interest at 3.6 percent per annum.  Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.  The use of the proceeds from the Project Notes was limited to assist the financing of the new Global Corporate Headquarters and Engineering Center.  On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-20-000053:notes:154]
Prudential Agreement

[0000038725-20-000053:notes:155]
On April 9, 2007, the Company entered into the Amended and Restated Note Purchase and Private Shelf Agreement (the “Prudential Agreement”) in the amount of $175.0 million.  Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”).  The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had at issuance an average life of 10 years with a final maturity in 2019.  On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million.  On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Agreement.  On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015.  On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement.   This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million.  On October 28, 2016, the Company entered into Amendment No. 1 to the Third Amended and Restated Note Purchase and Private Shelf Agreement.  This amendment was intended to make the covenants within the Prudential Agreement consistent with the covenants that were modified in the Credit Agreement (below).  As of December 31, 2019, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-20-000053:notes:156]
Credit Agreement

[0000038725-20-000053:notes:157]
On October 28, 2016, the Company entered into the Third Amended and Restated Credit Agreement (the “Credit Agreement”). The Credit Agreement extended the maturity date of the Company’s previous credit agreement to October 28, 2021 and increased the commitment amount from $150.0 million to $300.0 million.  The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million) subject to the conditions contained therein. All of the Company’s present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers’ obligations under and in connection with the Credit Agreement. Additionally, the Company unconditionally guaranties all of the obligations of Franklin Electric B.V. under the Credit Agreement.  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company’s leverage ratio) of the aggregate commitment, payable quarterly in arrears. Borrowings may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company’s leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-20-000053:notes:158]
As of December 31, 2019, the Company had $19.0 million outstanding borrowings, $4.5 million in letters of credit outstanding, and $276.5 million of available capacity under the Credit Agreement.  As of December 31, 2018, the Company had $76.3 million outstanding borrowings, $5.5 million in letters of credit outstanding, and $218.2 million of available capacity under the Credit Agreement.

[0000038725-20-000053:notes:159]
Covenants
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Credit Agreement, the Prudential Agreement, the Project Bonds, and the New York Life Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million.  The Company was in compliance with all financial covenants as of December 31, 2019.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-20-000053:notes:160]
SHAREHOLDERS’ EQUITY
Authorized Shares

[0000038725-20-000053:notes:161]
The Company has the authority to issue 65,000,000, $.10 par value shares.

[0000038725-20-000053:notes:162]
Share Repurchases

[0000038725-20-000053:notes:163]
During 2019, 2018, and 2017, pursuant to a stock repurchase program authorized by the Company’s Board of Directors, the Company repurchased and retired the following amounts and number of shares:

[0000038725-20-000053:notes:164]
| (In millions, except share amounts) |  | 2019 |  | 2018 |  | 2017 |
| Repurchases |  | $ | 6.6 |  |  | $ | 31.4 |  |  | $ | — |  |
| Shares |  | 150,778 |  |  | 749,614 |  |  | — |  |

[0000038725-20-000053:notes:165]
The Company retired shares in the amount of 82,601, 62,908, and 87,679 in 2019, 2018, and 2017, respectively, that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards. The company also retired shares in the amount of 5,345, 8,775, and 14,033, in 2019, 2018, and 2017, respectively that had been previously granted as stock awards to employees but were forfeited upon not meeting the required restriction criteria or termination.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-20-000053:notes:166]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS) 
Changes in accumulated other comprehensive income/(loss), net of tax, by component are summarized below:

[0000038725-20-000053:notes:167]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance, December 31, 2016 | $ | (118.4) |  |  | $ | (51.5) |  |  | $ | (169.9) |  |
| Other comprehensive income/(loss) before reclassifications | 18.7 |  |  | — |  |  | 18.7 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 2.2 |  |  | 2.2 |  |
| Net other comprehensive income/(loss) | 18.7 |  |  | 2.2 |  |  | 20.9 |  |
| Balance, December 31, 2017 | $ | (99.7) |  |  | $ | (49.3) |  |  | $ | (149.0) |  |
| Other comprehensive income/(loss) before reclassifications | (34.8) |  |  | — |  |  | (34.8) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.8 |  |  | 0.8 |  |
| Net other comprehensive income/(loss) | (34.8) |  |  | 0.8 |  |  | (34.0) |  |
| Balance, December 31, 2018 | $ | (134.5) |  |  | $ | (48.5) |  |  | $ | (183.0) |  |
| Other comprehensive income/(loss) before reclassifications | (5.7) |  |  | — |  |  | (5.7) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | (1.5) |  |  | (1.5) |  |
| Net other comprehensive income/(loss) | (5.7) |  |  | (1.5) |  |  | (7.2) |  |
| Balance, December 31, 2019 | $ | (140.2) |  |  | $ | (50.0) |  |  | $ | (190.2) |  |

[0000038725-20-000053:notes:168]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 7 - Employee Benefit Plans for additional details) and is included in the “Selling, general, and administrative expenses” line of the Company’s consolidated statements of income.

[0000038725-20-000053:notes:169]
(2) Net of tax (benefit)/expense of $(0.6) million, $0.3 million and $0.5 million for 2019, 2018, and 2017, respectively.
Amounts related to noncontrolling interests were not material.


## us-gaap:EarningsPerShareTextBlock

[0000038725-20-000053:notes:170]
EARNINGS PER SHARE
The Company calculates basic and diluted earnings per common share using the two-class method.  Under the two-class method, net earnings are allocated to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company’s participating securities consist of share-based payment awards that contain a nonforfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.

[0000038725-20-000053:notes:171]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-20-000053:notes:172]
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-20-000053:notes:173]
| (In millions, except per share amounts) |  | 2019 |  | 2018 |  | 2017 |
| Numerator: |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. |  | $ | 95.5 |  |  | $ | 105.9 |  |  | $ | 78.2 |  |
| Less: Earnings allocated to participating securities |  | 0.7 |  |  | 0.8 |  |  | 0.6 |  |
| Net income available to common shareholders |  | $ | 94.8 |  |  | $ | 105.1 |  |  | $ | 77.6 |  |
| Denominator: |  |  |  |  |  |  |
| Basic weighted average common shares outstanding |  | 46.4 |  |  | 46.6 |  |  | 46.5 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards |  | 0.4 |  |  | 0.4 |  |  | 0.5 |  |
| Diluted weighted average common shares outstanding |  | 46.8 |  |  | 47.0 |  |  | 47.0 |  |
| Basic earnings per share |  | $ | 2.04 |  |  | $ | 2.25 |  |  | $ | 1.67 |  |
| Diluted earnings per share |  | $ | 2.03 |  |  | $ | 2.23 |  |  | $ | 1.65 |  |

[0000038725-20-000053:notes:174]
There were 0.2 million, 0.1 million, and 0.3 million stock options outstanding as of 2019, 2018, and 2017, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-20-000053:notes:175]
SHARE-BASED COMPENSATION
The Franklin Electric Co., Inc. 2017 Stock Plan (the “2017 Stock Plan”) is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, stock unit awards, and stock appreciation rights (“SARs”) to key employees and non-employee directors.  The number of shares that may be issued under the Plan is 1,400,000.  Stock options and SARs reduce the number of available shares by one share for each share subject to the option or SAR, and stock awards and stock unit awards settled in shares reduce the number of available shares by 1.5 shares for every one share delivered.

[0000038725-20-000053:notes:176]
The Company also maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the “2012 Stock Plan”), which is a share-based compensation plan that provides for discretionary grants of stock options, stock awards and stock unit awards to key employees and non-employee directors.

[0000038725-20-000053:notes:177]
The 2012 Stock Plan authorized 2,400,000 shares for issuance as follows:

[0000038725-20-000053:notes:178]
| 2012 Stock Plan |  | Authorized Shares |
| Stock Options |  | 1,680,000 |  |
| Stock/Stock Unit Awards |  | 720,000 |  |

[0000038725-20-000053:notes:179]
The Company also maintains the Amended and Restated Franklin Electric Co., Inc. Stock Plan (the “2009 Stock Plan”) which, as amended in 2009, provided for discretionary grants of stock options and stock awards.  The 2009 Stock Plan authorized 4,400,000 shares for issuance as follows:

[0000038725-20-000053:notes:180]
| 2009 Stock Plan | Authorized Shares |
| Stock Options | 3,200,000 |  |
| Stock Awards | 1,200,000 |  |

[0000038725-20-000053:notes:181]
All options in the 2009 Stock Plan have been awarded.

[0000038725-20-000053:notes:182]
The Company currently issues new shares from its common stock balance to satisfy option exercises and the settlement of stock awards and stock unit awards made under the outstanding stock plans.

[0000038725-20-000053:notes:183]
The total share-based compensation expense recognized in 2019, 2018, and 2017 was $8.9 million, $8.4 million, and $7.1 million, respectively.

[0000038725-20-000053:notes:184]
Stock Options:

[0000038725-20-000053:notes:185]
Under the above plans, the exercise price of each option equals the market price of the Company’s common stock on the date of grant, and the options expire 10 years after the date of the grant.  Options granted to employees in 2019 vest at 33 percent a year and become fully vested and fully exercisable after 3 years.  Options granted prior to 2019 vest at 25 percent a year and become fully vested and fully exercisable after 4 years.  Vesting is accelerated upon death or disability. Subject to the terms of the plans, in general, the aggregate option exercise price and any applicable tax withholding may be satisfied in cash or its equivalent, by the plan participant’s delivery of shares of the Company’s common stock having a fair market value at the time of exercise equal to the aggregate option exercise price and/or the applicable tax withholding or by having shares otherwise subject to the award withheld by the Company or via cashless exercise through a broker-dealer.

[0000038725-20-000053:notes:186]
The fair value of each option award is estimated on the date of grant using the Black-Scholes option valuation model with a single approach and amortized using a straight-line attribution method over the option’s vesting period.  Options granted to retirement eligible employees are immediately expensed.  The Company uses historical data to estimate the expected volatility of its stock, the weighted average expected life, the period of time options granted are expected to be outstanding, and its dividend yield.  The risk-free rates for periods within the contractual life of the option are based on the U.S. Treasury yield curve in effect at the time of the grant.

[0000038725-20-000053:notes:187]
The table below provides the weighted average grant-date fair values and key assumptions used for the Black-Scholes model to determine the fair value of options granted during 2019, 2018, and 2017:

[0000038725-20-000053:notes:188]
|  |  | 2019 |  | 2018 |  | 2017 |
| Risk-free interest rate |  | 2.53 | % |  | 2.69 | % |  | 1.89 | % |
| Dividend yield |  | 1.05 | % |  | 1.05 | % |  | 0.94 | % |
| Volatility factor |  | 29.38 | % |  | 28.71 | % |  | 31.19 | % |
| Expected term |  | 5.5 years |  | 5.6 years |  | 5.5 years |
| Weighted average grant-date fair value of options |  | $ | 15.61 |  |  | $ | 11.40 |  |  | $ | 12.30 |  |

[0000038725-20-000053:notes:189]
A summary of the Company’s outstanding stock option activity and related information is as follows:

[0000038725-20-000053:notes:190]
| (Shares in thousands) |  |  |  |  |  |  |  |  |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | AggregateIntrinsic Value (000’s) |
| Outstanding at beginning of 2019 |  | 1,229 |  |  | $ | 33.25 |  |  |  |  |  |
| Granted |  | 190 |  |  | 55.16 |  |  |  |  |  |
| Exercised |  | (152) |  |  | 20.96 |  |  |  |  |  |
| Forfeited |  | (5) |  |  | 45.04 |  |  |  |  |  |
| Outstanding at end of 2019 |  | 1,262 |  |  | $ | 37.99 |  |  | 5.88 years |  | $ | 24,397 |  |
| Expected to vest after applying forfeiture rate |  | 1,258 |  |  | $ | 37.96 |  |  | 5.88 years |  | $ | 24,356 |  |
| Vested and exercisable at end of period |  | 772 |  |  | $ | 33.41 |  |  | 4.44 years |  | $ | 18,464 |  |

[0000038725-20-000053:notes:191]
| (In millions) |  | 2019 |  | 2018 |  | 2017 |
| Intrinsic value of options exercised |  | $ | 4.6 |  |  | $ | 10.2 |  |  | $ | 6.2 |  |
| Cash received from the exercise of options |  | 3.2 |  |  | 9.0 |  |  | 4.5 |  |
| Fair value of shares vested |  | 2.6 |  |  | 2.2 |  |  | 2.1 |  |
| Tax benefit of options exercised |  | 1.1 |  |  | 2.6 |  |  | 2.1 |  |

[0000038725-20-000053:notes:192]
As of December 31, 2019, there was $1.2 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 1.44 years.

[0000038725-20-000053:notes:193]
Stock/Stock Unit Awards:

[0000038725-20-000053:notes:194]
Under the 2009 Stock Plan, non-employee directors and employees may be granted stock awards.  Under the 2012 Stock Plan and the 2017 Stock Plan, non-employee directors and employees may be granted stock awards and stock units.

[0000038725-20-000053:notes:195]
Stock awards to non-employee directors are generally fully vested when made.  Stock/stock unit awards to employees cliff vest over 3 or 4 years (subject to accelerated vesting of a pro rata portion in the case of retirement, death or disability) and may be contingent on the attainment of certain performance goals. Dividends are paid to the recipient prior to vesting, except that dividends on performance-based stock awards under the 2012 Stock Plan and the 2017 Stock Plan will be paid only to the extent the performance goals are met.

[0000038725-20-000053:notes:196]
Stock/stock unit awards granted to retirement eligible employees are expensed over the vesting period.  Compensation cost for the performance stock/stock unit awards is accrued based on the probable outcome of specified performance conditions.

[0000038725-20-000053:notes:197]
A summary of the Company’s restricted stock/stock unit award activity and related information is as follows:

[0000038725-20-000053:notes:198]
| (Shares in thousands) |  |  |  |  |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of 2019 |  | 498 |  |  | $ | 37.27 |  |
| Awarded |  | 139 |  |  | 51.47 |  |
| Vested |  | (153) |  |  | 34.33 |  |
| Forfeited |  | (21) |  |  | 40.32 |  |
| Non-vested at end of 2019 |  | 463 |  |  | $ | 42.36 |  |

[0000038725-20-000053:notes:199]
The weighted-average grant date fair value of restricted stock/stock unit awards granted in 2019, 2018, and 2017, is $51.47, $40.48, and $42.23, respectively.

[0000038725-20-000053:notes:200]
As of December 31, 2019, there was $7.6 million of total unrecognized compensation cost related to non-vested stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan. That cost is expected to be recognized over a weighted-average period of 1.40 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-20-000053:notes:201]
SEGMENT AND GEOGRAPHIC INFORMATION
The Company’s business consists of the Water Systems, Distribution, and Fueling Systems reportable segments, based on the principal end market served. Within the Water Systems segment, North America Water Systems and International Water Systems have been identified as operating segments.  For reportable segment purposes, the Company aggregates North America Water Systems and International Water Systems into the Water Systems segment, as they meet the aggregation criteria in FASB ASC 280. The Company includes unallocated corporate expenses and inter-company eliminations in an “Intersegment Eliminations/Other” segment that together with the Water Systems, Distribution, and Fueling Systems segments, represent the Company.

[0000038725-20-000053:notes:202]
The Water Systems segment designs, manufactures and sells motors, pumps, electronic controls and related parts and equipment primarily for use in submersible water and other fluid system applications.  The Fueling Systems segment designs, manufactures and sells pumps, electronic controls and related parts and equipment primarily for use in submersible fueling system applications. The Fueling Systems segment integrates and sells motors and electronic controls produced by the Water Systems segment.  The Company reports these product transfers between Water and Fueling as inventory transfers since a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes.  The Distribution segment sells to and provides presale support and specifications to the installing contractors. The Distribution segment sells products produced by the Water Systems segment.  The Company reports intersegment transfers from Water Systems to Distribution as intersegment revenue at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water System and Distribution segments.

[0000038725-20-000053:notes:203]
Segment operating income is a key financial performance measure. Operating income by segment is based on net sales less identifiable operating expenses and allocations and includes profits recorded on sales to other segments of the Company. During the first quarter of 2019, the Company changed management reporting for transfers of certain products between the Water and Fueling segments. This reclassification resulted in $3.6 million and $0.9 million of sales for the years ended December 31, 2018 and December 31, 2017, respectively, being reclassified between the Fueling Systems segment and Water

[0000038725-20-000053:notes:204]
Systems segment. Additionally, $0.2 million of operating income for the year ended December 31, 2018 was reclassified between the Fueling Systems segment and Water Systems segment. There was no change to operating income for the year ended December 31, 2017.  The changes to management reporting had an impact on how the Company reviews and summarizes sales of geographical components within a segment. The Company has updated the sales of geographic components of the Water Systems segment from the prior year to align with current management reporting. The changes resulted in sales reclassifications from Latin America, Asia Pacific, and Europe, Middle East, and Africa (“EMEA”) to the U.S. and Canada for the years ended December 31, 2018 and December 31, 2017. This resulted in $14.3 million and $12.5 million of sales to be reclassified to the U.S. and Canada for the years ended December 31, 2018 and December 31, 2017, respectively. There is no impact on the Company’s previously reported consolidated financial position, results of operations, or cash flows.

[0000038725-20-000053:notes:205]
The accounting policies of the Company’s reportable segments are the same as those described in Note 1 - Summary of Significant Accounting Policies. Performance is evaluated based on the sales and operating income of the segments and a variety of ratios to measure performance. These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented.

[0000038725-20-000053:notes:206]
Financial information by reportable business segment is included in the following summary:

[0000038725-20-000053:notes:207]
| Net Sales |  |  |  |  |  |
| (In millions) | 2019 |  | 2018 |  | 2017 |
| Water Systems |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | $ | 367.6 |  |  | $ | 372.0 |  |  | $ | 321.9 |  |
| Latin America | 124.2 |  |  | 120.2 |  |  | 129.4 |  |
| Europe, Middle East & Africa | 155.6 |  |  | 170.9 |  |  | 165.8 |  |
| Asia Pacific | 81.8 |  |  | 80.8 |  |  | 86.3 |  |
| Intersegment sales |  |  |  |  |  |
| United States & Canada | 52.3 |  |  | 56.2 |  |  | 40.8 |  |
| Total sales | 781.5 |  |  | 800.1 |  |  | 744.2 |  |
| Distribution |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 291.8 |  |  | 269.6 |  |  | 176.7 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |
| Total sales | 291.8 |  |  | 269.6 |  |  | 176.7 |  |
| Fueling Systems |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 173.5 |  |  | 156.9 |  |  | 144.5 |  |
| All other | 120.1 |  |  | 127.7 |  |  | 100.3 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |
| Total Sales | 293.6 |  |  | 284.6 |  |  | 244.8 |  |
| Intersegment Eliminations/Other | (52.3) |  |  | (56.2) |  |  | (40.8) |  |
| Consolidated | $ | 1,314.6 |  |  | $ | 1,298.1 |  |  | $ | 1,124.9 |  |
| Operating income (loss) |  |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |
| Water Systems | $ | 103.0 |  |  | $ | 112.7 |  |  | $ | 102.0 |  |
| Distribution | 3.6 |  |  | 3.4 |  |  | 3.7 |  |
| Fueling Systems | 75.8 |  |  | 70.6 |  |  | 60.0 |  |
| Intersegment Eliminations/Other | (55.3) |  |  | (54.7) |  |  | (58.5) |  |
| Consolidated | $ | 127.1 |  |  | $ | 132.0 |  |  | $ | 107.2 |  |

[0000038725-20-000053:notes:208]
|  | Total assets |  |  |  |  |  | Depreciation |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| Water Systems | $ | 658.3 |  |  | $ | 679.7 |  |  | $ | 695.4 |  |  | $ | 19.0 |  |  | $ | 20.4 |  |  | $ | 20.9 |  |
| Distribution | 180.2 |  |  | 165.1 |  |  | 153.1 |  |  | 2.8 |  |  | 2.2 |  |  | 1.3 |  |
| Fueling Systems | 283.8 |  |  | 275.7 |  |  | 265.7 |  |  | 2.1 |  |  | 2.2 |  |  | 2.2 |  |
| Other | 72.4 |  |  | 61.9 |  |  | 71.2 |  |  | 3.7 |  |  | 4.9 |  |  | 5.5 |  |
| Consolidated | $ | 1,194.7 |  |  | $ | 1,182.4 |  |  | $ | 1,185.4 |  |  | $ | 27.6 |  |  | $ | 29.7 |  |  | $ | 29.9 |  |
|  | Amortization |  |  |  |  |  | Capital expenditures |  |  |  |  |
|  | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| Water Systems | $ | 6.9 |  |  | $ | 6.5 |  |  | $ | 6.2 |  |  | $ | 15.1 |  |  | $ | 18.2 |  |  | $ | 19.1 |  |
| Distribution | 0.5 |  |  | 0.5 |  |  | 0.4 |  |  | 3.9 |  |  | 2.0 |  |  | 1.1 |  |
| Fueling Systems | 1.9 |  |  | 1.8 |  |  | 1.9 |  |  | 1.9 |  |  | 2.2 |  |  | 11.0 |  |
| Other | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 1.2 |  |  | 1.0 |  |  | 2.2 |  |
| Consolidated | $ | 9.4 |  |  | $ | 8.9 |  |  | $ | 8.6 |  |  | $ | 22.1 |  |  | $ | 23.4 |  |  | $ | 33.4 |  |

[0000038725-20-000053:notes:209]
Cash and property, plant and equipment are the major asset groups in “Other” of total assets for the fiscal year ended December 31, 2019.  Property, plant and equipment is the major asset group in "Other" of total assets for the fiscal years ended December 31, 2018, and December 31, 2017.

[0000038725-20-000053:notes:210]
Financial information by geographic region is as follows:

[0000038725-20-000053:notes:211]
|  | Net sales |  |  |  |  |  | Long-lived assets |  |  |  |  |
| (In millions) | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| United States | $ | 776.6 |  |  | $ | 752.5 |  |  | $ | 609.1 |  |  | $ | 394.7 |  |  | $ | 372.6 |  |  | $ | 326.1 |  |
| Foreign | 538.0 |  |  | 545.6 |  |  | 515.8 |  |  | 223.4 |  |  | 221.2 |  |  | 261.2 |  |
| Consolidated | $ | 1,314.6 |  |  | $ | 1,298.1 |  |  | $ | 1,124.9 |  |  | $ | 618.1 |  |  | $ | 593.8 |  |  | $ | 587.3 |  |

[0000038725-20-000053:notes:212]
Net sales are attributed to geographic regions based upon the ship to location of the customer.  Long-lived assets are attributed to geographic regions based upon the country of domicile.

[0000038725-20-000053:notes:213]
The Company offers a large array of products and systems to multiple markets and customers.  Product sales information is tracked regionally and products are categorized differently between regions based on local needs and reporting requirements. However, net sales by segment are representative of the Company’s sales by major product category. The Company sells its products through various distribution channels including wholesale and retail distributors, specialty distributors, industrial and petroleum equipment distributors, as well as major oil and utility companies and original equipment manufacturers.

[0000038725-20-000053:notes:214]
No single customer accounted for more than 10 percent of the Company’s consolidated sales in 2019, 2018, or 2017.  No single customer accounted for more than 10 percent of the Company’s gross accounts receivable in 2019 or 2018.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-20-000053:notes:215]
COMMITMENTS AND CONTINGENCIES
The Company is defending various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-20-000053:notes:216]
At December 31, 2019, the Company had $6.1 million of commitments primarily for capital expenditures and the purchase of raw materials to be used in production.

[0000038725-20-000053:notes:217]
The changes in the carrying amount of the warranty accrual, as recorded in the “Accrued expenses and other current liabilities” line of the Company’s consolidated balance sheets for 2019 and 2018, are as follows:

[0000038725-20-000053:notes:218]
| (In millions) |  | 2019 |  | 2018 |
| Beginning balance |  | $ | 9.0 |  |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 10.7 |  |  | 10.1 |  |
| Additions related to acquisitions |  | 0.1 |  |  | 0.1 |  |
| Reductions for payments made |  | (10.7) |  |  | (10.7) |  |
| Ending balance |  | $ | 9.1 |  |  | $ | 9.0 |  |

[0000038725-20-000053:notes:219]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases.  The Company also has lease agreements that are classified as financing. However, these financing leases are immaterial to the Company.

[0000038725-20-000053:notes:220]
The components of the Company's operating lease portfolio as of December 31, 2019 are as follows:

[0000038725-20-000053:notes:221]
| Lease Cost (In millions) |  |  |
| Operating lease cost |  | $ | 11.7 |  |
| Short-term lease cost |  | 0.5 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  | 4 years |
| Weighted-average discount rate |  | 3.7 | % |

[0000038725-20-000053:notes:222]
Total rent expense charged to operations for operating leases including contingent rentals was $17.4 million, and $15.1 million in 2018, and 2017, respectively, under Topic 840.

[0000038725-20-000053:notes:223]
The future minimum rental payments for non-cancellable operating leases as of December 31, 2019, are as follows:

[0000038725-20-000053:notes:224]
| (In millions) | Total |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |
| Undiscounted future minimum rental payments | $ | 30.2 |  |  | $ | 10.8 |  |  | $ | 8.1 |  |  | $ | 4.1 |  |  | $ | 2.9 |  |  | $ | 1.6 |  |  | $ | 2.7 |  |
| Less: Imputed Interest | $ | 2.6 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | $ | 27.6 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000038725-20-000053:notes:225]
The future minimum rental payments for non-cancellable operating leases as of December 31, 2018, under Topic 840 were reported as follows:

[0000038725-20-000053:notes:226]
| (In millions) | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
| Undiscounted future minimum rental payments | $ | 8.9 |  |  | $ | 5.9 |  |  | $ | 3.5 |  |  |  | $ | 2.0 |  |  | $ | 1.1 |  |  | $ | 5.7 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000038725-20-000053:notes:227]
SELECTED QUARTERLY FINANCIAL DATA (UNAUDITED)Unaudited quarterly financial information for 2019 and 2018, is as follows:

[0000038725-20-000053:notes:228]
| (In millions, except per share amounts) |  |  |  |  |  |  |  |  |  |  |  |
|  | Net Sales |  | Gross Profit |  | Net Income |  | Net Income Attributable to Franklin Electric Co., Inc. |  | Basic Earnings Per Share |  | Diluted Earnings Per Share |
| 2019 |  |  |  |  |  |  |  |  |  |  |  |
| 1st quarter | $ | 290.7 |  |  | $ | 89.5 |  |  | $ | 9.1 |  |  | $ | 9.1 |  |  | $ | 0.19 |  |  | $ | 0.19 |  |
| 2nd quarter | 355.4 |  |  | 119.7 |  |  | 32.8 |  |  | 32.7 |  |  | 0.70 |  |  | 0.70 |  |
| 3rd quarter | 348.4 |  |  | 117.6 |  |  | 34.1 |  |  | 33.9 |  |  | 0.73 |  |  | 0.72 |  |
| 4th quarter | 320.1 |  |  | 101.3 |  |  | 20.0 |  |  | 19.8 |  |  | 0.42 |  |  | 0.42 |  |
|  | $ | 1,314.6 |  |  | $ | 428.1 |  |  | $ | 96.0 |  |  | $ | 95.5 |  |  | $ | 2.04 |  |  | $ | 2.03 |  |
| 2018 |  |  |  |  |  |  |  |  |  |  |  |
| 1st quarter | $ | 295.6 |  |  | $ | 99.0 |  |  | $ | 21.2 |  |  | $ | 21.2 |  |  | $ | 0.45 |  |  | $ | 0.45 |  |
| 2nd quarter | 344.0 |  |  | 116.1 |  |  | 30.0 |  |  | 30.5 |  |  | 0.65 |  |  | 0.64 |  |
| 3rd quarter | 341.9 |  |  | 113.0 |  |  | 30.0 |  |  | 30.0 |  |  | 0.64 |  |  | 0.63 |  |
| 4th quarter | 316.6 |  |  | 104.3 |  |  | 24.3 |  |  | 24.2 |  |  | 0.51 |  |  | 0.51 |  |
|  | $ | 1,298.1 |  |  | $ | 432.4 |  |  | $ | 105.5 |  |  | $ | 105.9 |  |  | $ | 2.25 |  |  | $ | 2.23 |  |

[0000038725-20-000053:notes:229]
Basic and diluted earnings per share amounts are computed independently for each of the quarters presented.  As a result, the sum of the quarterly earnings per share amounts may not equal the annual earnings per share amount.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000038725-20-000053:notes:230]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000038725-20-000053:notes:231]
| (In millions) |  | Balance at Beginning of Period |  | Additions Charged to Costs and Expenses |  | Deductions (a) |  | Other (b) |  | Balance at End of Period |
| 2019 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4.4 |  |  | $ | 0.1 |  |  | $ | 0.9 |  |  | $ | 0.1 |  |  | $ | 3.7 |  |
| Allowance for deferred taxes |  | 6.8 |  |  | — |  |  | 0.4 |  |  | — |  |  | 6.4 |  |
| 2018 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4.4 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | 4.4 |  |
| Allowance for deferred taxes |  | 9.8 |  |  | 2.3 |  |  | 5.3 |  |  | — |  |  | 6.8 |  |
| 2017 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.6 |  |  | $ | (0.1) |  |  | $ | 0.2 |  |  | $ | 1.1 |  |  | $ | 4.4 |  |
| Allowance for deferred taxes |  | 9.8 |  |  | 2.4 |  |  | 2.4 |  |  | — |  |  | 9.8 |  |

[0000038725-20-000053:notes:232]
(a) Charges for which allowances were created.

[0000038725-20-000053:notes:233]
(b) Primarily related to acquisitions
