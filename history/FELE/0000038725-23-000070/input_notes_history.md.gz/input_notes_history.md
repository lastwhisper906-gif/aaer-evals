# FELE note change history — 0000038725-22-000182 → 0000038725-23-000070


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000038725-23-000070:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position,  results of operations, or cash flows.
  (was, 2022-11-01, similarity 0.6743):
[0000038725-22-000182:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022 the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s continuing position that its products were not the cause of any alleged damage. The Company's response to the expert's final report is due in January 2023, at which time the French court will determine whether the merits of the claim warrant additional proceedings. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.

- changed (2023-05-05):
[0000038725-23-000070:note_history:2]
At March 31, 2023, the Company had $13.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2022-11-01, similarity 0.966):
[0000038725-22-000182:note_history:2]
At September 30, 2022, the Company had $13.9 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2023-05-05):
[0000038725-23-000070:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2023, are as follows:
  (was, 2022-11-01, similarity 0.894):
[0000038725-22-000182:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2022, are as follows:

- changed (2023-05-05):
[0000038725-23-000070:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2022 |  | $ | 11.2 |  |
| Accruals related to product warranties |  | 3.4 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (3.3) |  |
| Balance as of March 31, 2023 |  | $ | 11.3 |  |
  (was, 2022-11-01, similarity 0.9715):
[0000038725-22-000182:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2021 |  | $ | 10.5 |  |
| Accruals related to product warranties |  | 8.3 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (6.9) |  |
| Balance as of September 30, 2022 |  | $ | 11.9 |  |

- removed (2023-05-05):
[0000038725-22-000182:note_history:5]
The Company provides warranties on most of its products. The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims. The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

- removed (2023-05-05):
[0000038725-22-000182:note_history:6]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. These financing leases are immaterial to the Company.

- removed (2023-05-05):
[0000038725-22-000182:note_history:7]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate in effect at the inception of a lease when determining the present value of future lease payments.

- removed (2023-05-05):
[0000038725-22-000182:note_history:8]
Some of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.

- removed (2023-05-05):
[0000038725-22-000182:note_history:9]
The components of the Company’s operating lease portfolio as of the third quarter and nine months ended September 30, 2022 are as follows:

- removed (2023-05-05):
[0000038725-22-000182:note_history:10]
|  |  | Third Quarter Ended |  | Nine Months Ended |
| Lease Cost (in millions): |  | September 30, 2022 |  | September 30, 2021 |  | September 30, 2022 |  | September 30, 2021 |
| Operating lease cost |  | $ | 4.3 |  |  | $ | 3.5 |  |  | $ | 12.9 |  |  | $ | 9.2 |  |
| Short-term lease cost |  | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.5 |  |
| Other Information: |  |  |  |  |  |  |  |  |
| Weighted-average remaining lease term |  |  |  |  |  | 4.3 years |  | 4.1 years |
| Weighted-average discount rate |  |  |  |  |  | 3.7 | % |  | 4.1 | % |

- removed (2023-05-05):
[0000038725-22-000182:note_history:11]
As of September 30, 2022, the Company has approximately $2.3 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.

- removed (2023-05-05):
[0000038725-22-000182:note_history:12]
The minimum rental payments for non-cancellable operating leases as of September 30, 2022, are as follows:

- removed (2023-05-05):
[0000038725-22-000182:note_history:13]
| (In millions) | 2022 | 2023 | 2024 | 2025 | 2026 | Thereafter |
| Future Minimum Rental Payments | $ | 4.5 |  | $ | 15.5 |  | $ | 10.6 |  | $ | 7.3 |  | $ | 5.7 |  | $ | 8.4 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000038725-23-000070:note_history:14]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2022, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2023, and for the first quarters ended March 31, 2023 and March 31, 2022 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2023. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022.
  (was, 2022-11-01, similarity 0.9363):
[0000038725-22-000182:note_history:14]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2021, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2022, and for the third quarters and nine months ended September 30, 2022 and September 30, 2021 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2022. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2021.

- removed (2023-05-05):
[0000038725-22-000182:note_history:15]
In the second quarter of 2022, the Company concluded that Turkey represents a highly inflationary economy as its projected three-year cumulative inflation rate exceeds 100%. As a result, the Company started remeasuring the financial statements for the Company’s Turkish operations in accordance with the highly inflationary accounting rules in ASC 830, Foreign Currency Matters, as of April 1, 2022. As a result, all gains and losses resulting from the remeasurement of the financial results of operations and other transactional foreign exchange gains and losses would be reflected in earnings rather than as a component of the Company’s comprehensive income within stockholders’ equity. As of September 30, 2022, this impact was not significant to the Company’s results.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-05-05):
[0000038725-23-000070:note_history:16]
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 182.5 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.7 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 2.0 |  |  | 3.1 |  |
| Other |  | — |  |  | — |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 274.1 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (185.3) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.8 |  |  | 89.3 |

- added (2023-05-05):
[0000038725-23-000070:note_history:17]
As of March 31, 2023, the Company had $182.5 million outstanding borrowings with a weighted-average interest rate of 5.6 percent, $3.6 million in letters of credit outstanding, and $163.9 million of available capacity under its credit agreement. As of December 31,2022, the company had $122.8 million outstanding borrowings with a weighted-average interest rate of 5.0 percent, $4.0 million in letters of credit outstanding, and $223.2 million of available capacity under its credit agreement.

- changed (2023-05-05):
[0000038725-23-000070:note_history:18]
The Company also has lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $21.9 million. As of March 31, 2023, there were $1.5 million outstanding borrowings and $20.4 million of available capacity under these lines of credit. As of December 31, 2022, there were $22.0 million overdraft lines of credit with $2.7 million of outstanding borrowings and $19.3 million of available capacity under these lines of credit.
  (was, 2022-11-01, similarity 0.764):
[0000038725-22-000182:note_history:18]
The Company also has lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $18.7 million. As of September 30, 2022, there were $4.2 million outstanding borrowings and $14.5 million of available capacity under these lines of credit.

- removed (2023-05-05):
[0000038725-22-000182:note_history:19]
| (In millions) |  | September 30, 2022 |  | December 31, 2021 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 174.2 |  |  | 96.6 |  |
| Tax increment financing debt |  | 15.3 |  |  | 16.5 |  |
| Foreign subsidiary debt |  | 4.5 |  |  | 0.5 |  |
| Other |  | — |  |  | 0.1 |  |
| Less: unamortized debt issuance costs |  | (0.2) |  |  | (0.2) |  |
|  |  | $ | 268.8 |  |  | $ | 188.5 |  |
| Less: current maturities |  | (179.6) |  |  | (98.0) |  |
| Long-term debt |  | $ | 89.2 |  |  | 90.5 |

- removed (2023-05-05):
[0000038725-22-000182:note_history:20]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2022 matures as follows:

- removed (2023-05-05):
[0000038725-22-000182:note_history:21]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 269.0 |  |  | $ | 179.6 |  |  | $ | 1.4 |  |  | $ | 76.4 |  |  | $ | 1.5 |  |  | $ | 1.4 |  |  | $ | 8.7 |  |

- removed (2023-05-05):
[0000038725-22-000182:note_history:22]
Prudential Agreement

- removed (2023-05-05):
[0000038725-22-000182:note_history:23]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates, which was renewed on July 30, 2021 and expires on July 30, 2024.  The Prudential Agreement has an initial borrowing capacity of $150.0 million. As of September 30, 2022, the Company had no notes issued and  $150.0 million borrowing capacity available under the Prudential Agreement.

- removed (2023-05-05):
[0000038725-22-000182:note_history:24]
Project Bonds

- removed (2023-05-05):
[0000038725-22-000182:note_history:25]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Bonds ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Bonds are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

- removed (2023-05-05):
[0000038725-22-000182:note_history:26]
New York Life Agreement

- removed (2023-05-05):
[0000038725-22-000182:note_history:27]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC and its affiliates (the "New York Life Agreement"), which was renewed on July 30, 2021 and expires on July 30, 2024. The New York Life Agreement has a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2022, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

- removed (2023-05-05):
[0000038725-22-000182:note_history:28]
The Company maintains the Fourth Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement was renewed on May 13, 2021, has a maturity date of May 13, 2026. On May 11, 2022, the Company entered into Amendment No. 1 that increased the commitment amount from $250.0 million to $350.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million subject to agreement of the lenders

- removed (2023-05-05):
[0000038725-22-000182:note_history:29]
(not to exceed a total commitment of $475.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100 percent to 0.275 percent (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. USD loans may be made either at (i) a Secured Overnight Financing Rate (SOFR) Term Benchmark, with a zero percent floor, plus an applicable margin of 0.950 percent to 1.975 percent (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement. EUR loans may be made in Euro Interbank Offer Rate (EURIBOR) Term Benchmark, with a zero percent floor, plus an applicable margin of 0.850 percent to 1.875 percent (depending on the Company’s leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

- removed (2023-05-05):
[0000038725-22-000182:note_history:30]
As of September 30, 2022, the Company had $174.2 million outstanding borrowings, $4.0 million in letters of credit outstanding, and $171.8 million of available capacity under the Credit Agreement.

- removed (2023-05-05):
[0000038725-22-000182:note_history:31]
Covenants

- removed (2023-05-05):
[0000038725-22-000182:note_history:32]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of September 30, 2022.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-05-05):
[0000038725-23-000070:note_history:33]
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 182.5 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.7 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 2.0 |  |  | 3.1 |  |
| Other |  | — |  |  | — |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 274.1 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (185.3) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.8 |  |  | 89.3 |

- removed (2023-05-05):
[0000038725-22-000182:note_history:34]
| (In millions) |  | September 30, 2022 |  | December 31, 2021 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 174.2 |  |  | 96.6 |  |
| Tax increment financing debt |  | 15.3 |  |  | 16.5 |  |
| Foreign subsidiary debt |  | 4.5 |  |  | 0.5 |  |
| Other |  | — |  |  | 0.1 |  |
| Less: unamortized debt issuance costs |  | (0.2) |  |  | (0.2) |  |
|  |  | $ | 268.8 |  |  | $ | 188.5 |  |
| Less: current maturities |  | (179.6) |  |  | (98.0) |  |
| Long-term debt |  | $ | 89.2 |  |  | 90.5 |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-05-05):
[0000038725-22-000182:note_history:35]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2022 matures as follows:

- removed (2023-05-05):
[0000038725-22-000182:note_history:36]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 269.0 |  |  | $ | 179.6 |  |  | $ | 1.4 |  |  | $ | 76.4 |  |  | $ | 1.5 |  |  | $ | 1.4 |  |  | $ | 8.7 |  |
