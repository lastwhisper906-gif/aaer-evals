# FELE MD&A — 0000038725-23-000070


## mdna

[0000038725-23-000070:mdna:1]
[same as prior period, unchanged from 0000038725-22-000182:mdna:1]

[0000038725-23-000070:mdna:2]
First Quarter 2023 vs. First Quarter 2022

[0000038725-23-000070:mdna:3]
[same as prior period, unchanged from 0000038725-22-000182:mdna:3]

[0000038725-23-000070:mdna:4]
Net sales in the first quarter of 2023 increased 7 percent from the first quarter of last year. The sales increase was primarily due to higher sales across all three segments, achieved by price realization and volume, partially offset by the negative impact of foreign currency translation. The Company's consolidated gross profit was $162.3 million for the first quarter of 2023, an increase of $17.0 million from the prior year’s first quarter. The gross profit as a percent of net sales was 33.5 percent in the first quarter of 2023 compared to 32.2 percent during the first quarter of 2022.  For the first quarter of 2023, diluted earnings per share were $0.79, an increase of $0.16 from the first quarter of 2022 diluted earnings per share of $0.63.

[0000038725-23-000070:mdna:5]
[same as prior period, unchanged from 0000038725-22-000182:mdna:5]

[0000038725-23-000070:mdna:6]
[same as prior period, unchanged from 0000038725-22-000182:mdna:6]

[0000038725-23-000070:mdna:7]
Net sales in the first quarter of 2023 were $484.6 million, an increase of $33.1 million or 7 percent compared to 2022 first quarter sales of $451.5 million. Sales decreased $15.0 million or 3 percent in the first quarter of 2023 due to foreign currency translation.

[0000038725-23-000070:mdna:8]
|  | Net Sales |
| (In millions) | Q1 2023 |  | Q1 2022 |  | 2023 v 2022 |
| Water Systems | $ | 306.6 |  |  | $ | 272.6 |  |  | $ | 34.0 |  |
| Fueling Systems | 72.7 |  |  | 72.5 |  |  | 0.2 |  |
| Distribution | 143.0 |  |  | 134.9 |  |  | 8.1 |  |
| Eliminations/Other | (37.7) |  |  | (28.5) |  |  | (9.2) |  |
| Consolidated | $ | 484.6 |  |  | $ | 451.5 |  |  | $ | 33.1 |  |

[0000038725-23-000070:mdna:9]
[same as prior period, unchanged from 0000038725-22-000182:mdna:9]

[0000038725-23-000070:mdna:10]
Water Systems sales were $306.6 million in the first quarter of 2023, an increase of $34.0 million or 12 percent compared to the first quarter of 2022 sales of $272.6 million. This sales growth was primarily due to price and volume, which increased due to strong end market demand. Partially offsetting the increase, sales decreased $14.2 million or 5 percent due to foreign currency translation.

[0000038725-23-000070:mdna:11]
Water Systems sales in the U.S. and Canada increased 21 percent compared to the first quarter of 2022.  Foreign currency translation decreased sales by 1 percent. Sales of large dewatering equipment increased 144 percent, sales of groundwater pumping equipment increased 6 percent and sales of all other surface pumping equipment increased 7 percent compared to the first quarter of 2022, due to strong end market demand.

[0000038725-23-000070:mdna:12]
Water Systems sales in markets outside the U.S. and Canada were flat overall. Foreign currency translation decreased sales 12 percent. Outside the U.S. and Canada, excluding the impact of foreign currency translation, sales increases in EMEA and Latin America more than offset sales declines in the Asia Pacific markets.

[0000038725-23-000070:mdna:13]
[same as prior period, unchanged from 0000038725-22-000182:mdna:13]

[0000038725-23-000070:mdna:14]
Fueling Systems sales were $72.7 million in the first quarter of 2023, an increase of $0.2 million or less than 1 percent compared to the first quarter of 2022 sales of $72.5 million. This sales growth was primarily due to price and volume, which increased due to strong end market demand. Partially offsetting the increase, Fueling Systems sales decreased $0.8 million or 1 percent in the quarter due to foreign currency translation.

[0000038725-23-000070:mdna:15]
Fueling Systems sales in the U.S. and Canada increased 4 percent compared to the first quarter of 2022. The increase was primarily in Fuel Management and Pumping Systems. Outside the U.S. and Canada, Fueling Systems sales decreased 10 percent, due primarily to the divestiture of the above ground storage tank business in 2022 and lower sales in China.

[0000038725-23-000070:mdna:16]
[same as prior period, unchanged from 0000038725-22-000182:mdna:16]

[0000038725-23-000070:mdna:17]
Distribution sales were $143.0 million in the first quarter of 2023, an increase of $8.1 million or 6 percent compared to the first quarter of 2022 sales of $134.9 million. The Distribution segment sales growth was primarily due to price and volume.

[0000038725-23-000070:mdna:18]
[same as prior period, unchanged from 0000038725-22-000182:mdna:19]

[0000038725-23-000070:mdna:19]
Cost of sales as a percentage of net sales for the first quarters of 2023 and 2022 was 66.5 percent and 67.8 percent, respectively. Correspondingly, gross profit margin increased to 33.5 percent from 32.2 percent. The Company’s consolidated gross profit was $162.3 million for the first quarter of 2023, an increase of $17.0 million from the first quarter of 2022 gross profit of $145.3 million. The gross profit margin increase was primarily due to price realization, cost management and operating leverage on higher sales.

[0000038725-23-000070:mdna:20]
[same as prior period, unchanged from 0000038725-22-000182:mdna:21]

[0000038725-23-000070:mdna:21]
SG&A expenses were $109.5 million in the first quarter of 2023 compared to $104.7 million in the first quarter of 2022. The increase was primarily due to higher spending in marketing, selling and engineering to support sales growth. SG&A costs as a percent of net sales decreased to 22.6 percent in the first quarter of 2023 from 23.2 percent in the first quarter of 2022.

[0000038725-23-000070:mdna:22]
[same as prior period, unchanged from 0000038725-22-000182:mdna:23]

[0000038725-23-000070:mdna:23]
Restructuring expenses were $0.1 million and $0.7 million in first quarters of 2023 and 2022, respectively. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities, branch closings and consolidations.

[0000038725-23-000070:mdna:24]
[same as prior period, unchanged from 0000038725-22-000182:mdna:25]

[0000038725-23-000070:mdna:25]
Operating income was $52.6 million in the first quarter of 2023, an increase of $12.7 million or 32 percent from $39.9 million in the first quarter of 2022.

[0000038725-23-000070:mdna:26]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2023 |  | Q1 2022 |  | 2023 v 2022 |
| Water Systems |  | $ | 49.0 |  |  | $ | 33.2 |  |  | $ | 15.8 |  |
| Fueling Systems |  | 20.8 |  |  | 17.7 |  |  | 3.1 |  |
| Distribution |  | 4.7 |  |  | 9.4 |  |  | (4.7) |  |
| Eliminations/Other |  | (21.9) |  |  | (20.4) |  |  | (1.5) |  |
| Consolidated |  | $ | 52.6 |  |  | $ | 39.9 |  |  | $ | 12.7 |  |

[0000038725-23-000070:mdna:27]
[same as prior period, unchanged from 0000038725-22-000182:mdna:28]

[0000038725-23-000070:mdna:28]
Water Systems operating income was $49.0 million in the first quarter of 2023, an increase of $15.8 million compared to the first quarter of 2022. Operating income increased in Water Systems primarily due to higher sales. The first quarter operating income margin was 16.0 percent, an increase of 380 basis points from 12.2 percent in the first quarter 2022. Operating income margin increased primarily due to price realization, cost management and operating leverage on higher sales.

[0000038725-23-000070:mdna:29]
[same as prior period, unchanged from 0000038725-22-000182:mdna:30]

[0000038725-23-000070:mdna:30]
Fueling Systems operating income was $20.8 million in the first quarter of 2023, an increase of $3.1 million compared to the first quarter of 2022. Operating income increased in Fueling Systems primarily due to a favorable product and geographic mix of net sales. The first quarter operating income margin was 28.6 percent, an increase of 420 basis points from 24.4 percent in the first quarter of 2022. Operating income margin increased primarily due to price realization and a favorable product and geographic sales mix shift.

[0000038725-23-000070:mdna:31]
[same as prior period, unchanged from 0000038725-22-000182:mdna:32]

[0000038725-23-000070:mdna:32]
Distribution operating income was $4.7 million in the first quarter of 2023, a decrease of $4.7 million compared to the first quarter of 2022. The first quarter operating income margin was 3.3 percent, a decrease of 370 basis points from 7.0 percent in the first quarter of 2022. Operating income and operating income margin decreased primarily due to unfavorable pricing of commodity-based products sold through the business and higher operating expenses as the business invested in future growth with 6 recently added new branch locations.

[0000038725-23-000070:mdna:33]
[same as prior period, unchanged from 0000038725-22-000182:mdna:34]

[0000038725-23-000070:mdna:34]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the first quarter of 2023 compared to the first quarter of 2022 was an unfavorable $0.7 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses increased $0.8 million compared to the prior year, in part due to higher software, professional fees and travel expenses.

[0000038725-23-000070:mdna:35]
[same as prior period, unchanged from 0000038725-22-000182:mdna:36]

[0000038725-23-000070:mdna:36]
Interest expense increased in the first quarter of 2023 to $3.1 million from $1.5 million in the first quarter of 2022 primarily due to higher outstanding debt levels and higher interest rates.

[0000038725-23-000070:mdna:37]
[same as prior period, unchanged from 0000038725-22-000182:mdna:38]

[0000038725-23-000070:mdna:38]
Other income or expense was income in the first quarter of 2023 of $0.4 million and an expense of $0.4 million in the first quarter of 2022.

[0000038725-23-000070:mdna:39]
[same as prior period, unchanged from 0000038725-22-000182:mdna:40]

[0000038725-23-000070:mdna:40]
Foreign currency-based transactions produced an expense for the first quarter of 2023 of $2.0 million, primarily due to the Argentinian and Mexican Peso relative to the U.S. dollar. The expense in 2022 was primarily due to transaction losses associated with the Argentine Peso and Turkish Lira. The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-23-000070:mdna:41]
[same as prior period, unchanged from 0000038725-22-000182:mdna:42]

[0000038725-23-000070:mdna:42]
The provision for income taxes in the first quarters of 2023 and 2022 was $10.2 million and $7.4 million, respectively. The effective tax rate for the first quarters of 2023 and 2022 was 21 percent and 20 percent, respectively. The impact of discrete events had a positive impact on the effective tax rate of 1 percent in both 2023 and 2022. The increase in the effective tax rate was primarily a result of smaller net favorable discrete events recorded in the first quarter of 2023 compared to the first quarter of 2022.

[0000038725-23-000070:mdna:43]
[same as prior period, unchanged from 0000038725-22-000182:mdna:44]

[0000038725-23-000070:mdna:44]
Net income for the first quarter of 2023 was $37.6 million compared to the prior year first quarter net income of $30.1 million. Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2023 was $37.3 million, or $0.79 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $29.8 million, or $0.63 per diluted share.

[0000038725-23-000070:mdna:45]
[same as prior period, unchanged from 0000038725-22-000182:mdna:91]

[0000038725-23-000070:mdna:46]
[same as prior period, unchanged from 0000038725-22-000182:mdna:92]

[0000038725-23-000070:mdna:47]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at March 31, 2023 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-23-000070:mdna:48]
As of March 31, 2023 the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of March 31, 2023, the Company had $163.9 million borrowing capacity under its credit agreement as $3.6 million in letters of commercial and standby letters of credit were outstanding and undrawn and $182.5 million in revolver borrowings were drawn and outstanding, which were primarily used for funding working capital requirements.

[0000038725-23-000070:mdna:49]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of  $125.0 million as of March 31, 2023. The Company also has other long-term debt borrowings outstanding as of March 31, 2023. See Note 10 - Debt included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022, for additional information regarding these obligations and future maturities as well as Note 10 - Debt of this current quarterly report for changes to these agreements since December 31, 2022.

[0000038725-23-000070:mdna:50]
At March 31, 2023, the Company had $50.1 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate the majority of these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-23-000070:mdna:51]
[same as prior period, unchanged from 0000038725-22-000182:mdna:97]

[0000038725-23-000070:mdna:52]
The following table summarizes significant sources and uses of cash and cash equivalents for the first three months of 2023 and 2022.

[0000038725-23-000070:mdna:53]
| (in millions) |  | 2023 |  | 2022 |
| Net cash flows from operating activities |  | $ | (12.0) |  |  | $ | (61.3) |  |
| Net cash flows from investing activities |  | (14.6) |  |  | (8.9) |  |
| Net cash flows from financing activities |  | 33.1 |  |  | 68.7 |  |
| Impact of exchange rates on cash and cash equivalents |  | (0.4) |  |  | (0.5) |  |
| Change in cash and cash equivalents |  | $ | 6.1 |  |  | $ | (2.0) |  |

[0000038725-23-000070:mdna:54]
[same as prior period, unchanged from 0000038725-22-000182:mdna:100]

[0000038725-23-000070:mdna:55]
2023 vs. 2022

[0000038725-23-000070:mdna:56]
Net cash used by operating activities was $12.0 million for the three months ended March 31, 2023 compared to $61.3 million used by operating activities for the three months ended March 31, 2022. The decrease in cash used by operating activities was primarily due to decreased working capital requirements.

[0000038725-23-000070:mdna:57]
[same as prior period, unchanged from 0000038725-22-000182:mdna:103]

[0000038725-23-000070:mdna:58]
2023 vs. 2022

[0000038725-23-000070:mdna:59]
Net cash used in investing activities was $14.6 million for the three months ended March 31, 2023 compared to $8.9 million used in investing activities for the three months ended March 31, 2022. The increase in cash used in investing activities was attributable to increased acquisition activity in the first quarter of 2023.

[0000038725-23-000070:mdna:60]
[same as prior period, unchanged from 0000038725-22-000182:mdna:106]

[0000038725-23-000070:mdna:61]
2023 vs. 2022

[0000038725-23-000070:mdna:62]
Net cash provided by financing activities was $33.1 million for the three months ended March 31, 2023 compared to $68.7 million provided by financing activities for the three months ended March 31, 2022. The decrease in cash provided by financing activities was attributable to decreased net proceeds from debt.

[0000038725-23-000070:mdna:63]
[same as prior period, unchanged from 0000038725-22-000182:mdna:109]
