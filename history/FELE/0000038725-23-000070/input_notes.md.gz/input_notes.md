# FELE notes — 0000038725-23-000070


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-23-000070:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2022, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2023, and for the first quarters ended March 31, 2023 and March 31, 2022 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2023. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-23-000070:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-23-000070:notes:3]
In October 2021, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires entities to recognize and measure contracts on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. This will improve comparability after the business combination by providing consistent recognition and measurement guidance for revenue contracts with customers acquired in a business combination and revenue contracts with customers not acquired in a business combination. ASU 2021-08 is effective for interim and annual periods beginning after December 15, 2022 with early adoption permitted. ASU 2021-08 should be applied on a prospective basis to business combinations that occur after the effective date. The Company adopted this ASU on January 1, 2023, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-23-000070:notes:4]
In September 2022, the FASB issued ASU 2022-04, Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations. ASU 2022-04 creates the obligation for a company that uses a supplier finance program to purchase goods or services to disclose qualitative and quantitative information about its supplier finance program(s). This will allow financial statement users to better consider the effect of the program(s) on the entity's working capital, liquidity and cash flow over time. ASU 2022-04 is effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years, except for the amendment on rollforward information, which is effective for fiscal years beginning after December 15, 2023 with early adoption permitted. ASU 2022-04 should be applied retrospectively to each period in which a balance sheet is presented except for the amendment on rollforward information, which should be applied prospectively. The Company adopted this ASU on January 1, 2023, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows as the Company has no current supplier finance programs.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-23-000070:notes:5]
ACQUISITIONS
2023

[0000038725-23-000070:notes:6]
During the first quarter ended March 31, 2023, the Company acquired all of the assets of Phil-Good Products, Inc. ("Phil-Good"). Phil-Good is an injection molded plastics component manufacturer. In another, separate transaction in the first quarter of 2023, the Company acquired 100 percent of the ownership interests of Hydropompe S.r.l. ("Hydropompe"). Hydropompe is a pump manufacturer with a focus in the dewatering and sewage products. The combined, all-cash purchase price for both acquisitions in the first quarter of 2023 was $6.9 million after purchase price adjustments based on the level of working capital acquired. The fair value of the assets acquired and liabilities assumed for both acquisitions is preliminary as of March 31, 2023. In addition, the Company has not presented separate results of operations of the acquired companies since the closing of the acquisitions or combined pro forma financial information of the Company and the acquired interests since the beginning of 2022, as the results of operations for both acquisitions are immaterial.

[0000038725-23-000070:notes:7]
2022

[0000038725-23-000070:notes:8]
During the fourth quarter ended December 31, 2022, the Company acquired 100 percent of the ownership interests of Casper Well Products ("Casper") for a purchase price of $2.0 million after purchase price adjustments based on the level of working capital acquired. Casper conducts the sale and distribution of pumps, drilling equipment, tanks, pipe, accessories and other equipment used in drilling water wells and distribution of water-related products. The fair value of the assets acquired and liabilities assumed is preliminary as of March 31, 2023. In addition, the Company has not presented separate results of

[0000038725-23-000070:notes:9]
operations of the acquired company since the closing of the acquisition or combined pro forma financial information of the Company and the acquired interest since the beginning of 2022, as the results of operations for this acquisition are immaterial.

[0000038725-23-000070:notes:10]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations. There were $0.0 million and $0.2 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the first quarters ended March 31, 2023 and March 31, 2022, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-23-000070:notes:11]
[same as prior period, unchanged from 0000038725-22-000182:notes:19]

[0000038725-23-000070:notes:12]
[same as prior period, unchanged from 0000038725-22-000182:notes:20]

[0000038725-23-000070:notes:13]
[same as prior period, unchanged from 0000038725-22-000182:notes:21]

[0000038725-23-000070:notes:14]
[same as prior period, unchanged from 0000038725-22-000182:notes:22]

[0000038725-23-000070:notes:15]
As of March 31, 2023 and December 31, 2022, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-23-000070:notes:16]
| (In millions) | March 31, 2023 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 11.2 |  | $ | 11.2 |  | $ | — |  | $ | — |  |
| Share swap transaction | 0.8 |  | 0.8 |  | — |  | — |  |
| Forward currency contracts | 0.5 |  | — |  | 0.5 |  | — |  |
| Total assets | $ | 12.5 |  | $ | 12.0 |  | $ | 0.5 |  | $ | — |  |
|  | December 31, 2022 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 7.9 |  | $ | 7.9 |  | $ | — |  | $ | — |  |
| Total assets | $ | 7.9 |  | $ | 7.9 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Share swap transaction | $ | 0.1 |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Total liabilities | $ | 0.1 |  | $ | 0.1 |  | $ | — |  | $ | — |  |

[0000038725-23-000070:notes:17]
[same as prior period, unchanged from 0000038725-22-000182:notes:25]

[0000038725-23-000070:notes:18]
Total debt, including current maturities, have carrying amounts of $274.1 million and $216.1 million and estimated fair values of $271.9 million and $213.2 million as of March 31, 2023 and December 31, 2022, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, 
the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-23-000070:notes:19]
FINANCIAL INSTRUMENTS
The Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of March 31, 2023 and December 31, 2022, the swap had a notional value based on 225,000 shares. For the first quarters ended March 31, 2023 and March 31, 2022, changes in the fair value of the swap resulted in a gain of $2.9 million and a loss of $2.4 million, respectively. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.

[0000038725-23-000070:notes:20]
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of March 31, 2023 and December 31, 2022, respectively, the Company had a notional amount of $22.4 million and $10.3 million in forward currency contracts outstanding and the related fair value of those contracts was not material.  For the first quarters ended March 31, 2023 and March 31, 2022, changes is the fair value of the forward currency contracts resulted in a gain of $1.0 million and a loss of $0.2 million, respectively. This is recorded in the Company's condensed consolidated statements of income within the "Foreign exchange income/(expense)" line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-23-000070:notes:21]
[same as prior period, unchanged from 0000038725-22-000182:notes:29]

[0000038725-23-000070:notes:22]
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Definite-lived intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | 251.9 |  |  | (105.2) |  |  | 251.6 |  |  | (101.5) |  |
| Patents |  | $ | 7.3 |  |  | $ | (7.3) |  |  | $ | 7.3 |  |  | $ | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.4) |  |  | 7.5 |  |  | (7.4) |  |
| Trade names |  | 41.7 |  |  | (4.2) |  |  | $ | 41.8 |  |  | (3.7) |  |
| Other |  | 3.4 |  |  | (2.8) |  |  | 3.4 |  |  | (2.7) |  |
| Total |  | $ | 311.8 |  |  | $ | (126.9) |  |  | $ | 311.6 |  |  | $ | (122.6) |  |
| Indefinite-lived intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.6 |  |  | — |  |  | 42.3 |  |  | — |  |
| Total intangibles |  | $ | 354.4 |  |  | $ | (126.9) |  |  | $ | 353.9 |  |  | $ | (122.6) |  |

[0000038725-23-000070:notes:23]
Amortization expense related to intangible assets for the first quarters ended March 31, 2023 and March 31, 2022 was $4.2 million and $4.3 million, respectively.
The change in the carrying amount of goodwill by reportable segment for the three months ended March 31, 2023, is as follows:

[0000038725-23-000070:notes:24]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidation |
| Balance as of December 31, 2022 |  | $ | 211.9 |  |  | $ | 70.3 |  |  | $ | 45.8 |  |  | $ | 328.0 |  |
| Acquisitions |  | 0.7 |  |  | — |  |  | — |  |  | 0.7 |  |
| Foreign currency translation |  | 0.5 |  |  | 0.1 |  |  | — |  |  | 0.6 |  |
| Balance as of March 31, 2023 |  | $ | 213.1 |  |  | $ | 70.4 |  |  | $ | 45.8 |  |  | $ | 329.3 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-23-000070:notes:25]
EMPLOYEE BENEFIT PLANS
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the first quarters ended March 31, 2023 and March 31, 2022:

[0000038725-23-000070:notes:26]
| (In millions) | Pension Benefits |
|  | First Quarter Ended |  |  |
|  | March 31, 2023 |  | March 31, 2022 |  |  |  |  |
| Service cost | $ | 0.1 |  |  | $ | 0.2 |  |  |  |  |  |
| Interest cost | 1.5 |  |  | 0.8 |  |  |  |  |  |
| Expected return on assets | (1.8) |  |  | (1.5) |  |  |  |  |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  |  |  |  |
| Actuarial loss | 0.6 |  |  | 1.2 |  |  |  |  |  |
| Settlement cost | — |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 0.4 |  |  | $ | 0.7 |  |  |  |  |  |

[0000038725-23-000070:notes:27]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the first quarters ended March 31, 2023 and March 31, 2022:

[0000038725-23-000070:notes:28]
| (In millions) | Other Benefits |
|  | First Quarter Ended |  |  |
|  | March 31, 2023 |  | March 31, 2022 |  |  |  |  |
| Service cost | $ | — |  |  | $ | — |  |  |  |  |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  |  |  |  |
| Expected return on assets | — |  |  | — |  |  |  |  |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  |  |  |  |
| Actuarial loss | — |  |  | — |  |  |  |  |  |
| Settlement cost | — |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.1 |  |  |  |  |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-23-000070:notes:29]
[same as prior period, unchanged from 0000038725-22-000182:notes:43]

[0000038725-23-000070:notes:30]
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| Salaries, wages, and commissions |  | 35.2 |  |  | 57.9 |  |
| Product warranty costs |  | 11.3 |  |  | 11.2 |  |
| Insurance |  | 1.6 |  |  | 1.7 |  |
| Employee benefits |  | 6.0 |  |  | 13.5 |  |
| Other |  | 34.6 |  |  | 36.3 |  |
| Total |  | 88.7 |  |  | 120.6 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-23-000070:notes:31]
INCOME TAXES
The Company’s effective tax rate for the three-month period ended March 31, 2023, was 21.4 percent as compared to 19.7 percent for the three-month period ended March 31, 2022. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to state taxes partially offset by the recognition of the U.S. foreign-derived intangible income (FDII) provisions and certain discrete events including excess tax benefits from share-based compensation.

[0000038725-23-000070:notes:32]
The increase in the effective tax rate was primarily a result of less favorable discrete events recorded in the three month period ended March 31, 2023, as compared to the three month period ended March 31, 2022.


## us-gaap:DebtDisclosureTextBlock

[0000038725-23-000070:notes:33]
DEBT
Debt consisted of the following:

[0000038725-23-000070:notes:34]
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 182.5 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.7 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 2.0 |  |  | 3.1 |  |
| Other |  | — |  |  | — |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 274.1 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (185.3) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.8 |  |  | 89.3 |

[0000038725-23-000070:notes:35]
Credit Agreement

[0000038725-23-000070:notes:36]
As of March 31, 2023, the Company had $182.5 million outstanding borrowings with a weighted-average interest rate of 5.6 percent, $3.6 million in letters of credit outstanding, and $163.9 million of available capacity under its credit agreement. As of December 31,2022, the company had $122.8 million outstanding borrowings with a weighted-average interest rate of 5.0 percent, $4.0 million in letters of credit outstanding, and $223.2 million of available capacity under its credit agreement.

[0000038725-23-000070:notes:37]
The Company also has lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $21.9 million. As of March 31, 2023, there were $1.5 million outstanding borrowings and $20.4 million of available capacity under these lines of credit. As of December 31, 2022, there were $22.0 million overdraft lines of credit with $2.7 million of outstanding borrowings and $19.3 million of available capacity under these lines of credit.


## us-gaap:EarningsPerShareTextBlock

[0000038725-23-000070:notes:38]
[same as prior period, unchanged from 0000038725-22-000182:notes:64]

[0000038725-23-000070:notes:39]
[same as prior period, unchanged from 0000038725-22-000182:notes:65]

[0000038725-23-000070:notes:40]
|  | First Quarter Ended |  |  |
| (In millions, except per share amounts) | March 31, 2023 |  | March 31, 2022 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 37.3 |  |  | $ | 29.8 |  |  |  |  |  |
| Less: Earnings allocated to participating securities | 0.1 |  |  | 0.1 |  |  |  |  |  |
| Net income available to common shareholders | $ | 37.2 |  |  | $ | 29.7 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.2 |  |  | 46.4 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors | 0.7 |  |  | 0.7 |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 46.9 |  |  | 47.1 |  |  |  |  |  |
| Basic earnings per share | $ | 0.81 |  |  | $ | 0.64 |  |  |  |  |  |
| Diluted earnings per share | $ | 0.79 |  |  | $ | 0.63 |  |  |  |  |  |

[0000038725-23-000070:notes:41]
There were 0.1 million and 0.1 million stock options outstanding for the first quarters ended March 31, 2023 and March 31, 2022, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-23-000070:notes:42]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the first quarters ended March 31, 2023 and March 31, 2022:

[0000038725-23-000070:notes:43]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Pension and Other Post Retirement Plans |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2022 | $ | 4,619 |  |  | $ | 325,426 |  |  | $ | 969,261 |  |  | $ | (40,236) |  |  | $ | (191,212) |  |  | $ | 2,276 |  |  | $ | 1,070,134 |  |  | $ | 620 |  |
| Net income |  |  |  |  | 37,325 |  |  |  |  |  |  | 238 |  |  | 37,563 |  |  | 13 |  |
| Dividends on common stock ($0.225/share) |  |  |  |  | (10,440) |  |  |  |  |  |  |  |  | (10,440) |  |  |  |
| Common stock issued | 7 |  |  | 2,931 |  |  |  |  |  |  |  |  |  |  | 2,938 |  |  |  |
| Common stock repurchased | (18) |  |  |  |  | (16,032) |  |  |  |  |  |  |  |  | (16,050) |  |  |  |
| Share-based compensation | 6 |  |  | 3,906 |  |  |  |  |  |  |  |  |  |  | 3,912 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 6,471 |  |  | 23 |  |  | 6,494 |  |  | — |  |
| Pension and other post retirement plans, net of taxes |  |  |  |  |  |  | 417 |  |  |  |  |  |  | 417 |  |  |  |
| Balance as of March 31, 2023 | $ | 4,614 |  |  | $ | 332,263 |  |  | $ | 980,114 |  |  | $ | (39,819) |  |  | $ | (184,741) |  |  | $ | 2,537 |  |  | $ | 1,094,968 |  |  | $ | 633 |  |
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Pension and Other Post Retirement Plans |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2021 | $ | 4,648 |  |  | $ | 310,617 |  |  | $ | 859,817 |  |  | $ | (49,076) |  |  | $ | (179,505) |  |  | $ | 2,161 |  |  | $ | 948,662 |  |  | $ | (19) |  |
| Net income |  |  |  |  | 29,765 |  |  |  |  |  |  | 235 |  |  | 30,000 |  |  | 119 |  |
| Dividends on common stock ($0.195/share) |  |  |  |  | (9,129) |  |  |  |  |  |  |  |  | (9,129) |  |  |  |
| Common stock issued | 1 |  |  | 342 |  |  |  |  |  |  |  |  |  |  | 343 |  |  |  |
| Common stock repurchased | (23) |  |  |  |  | (19,297) |  |  |  |  |  |  |  |  | (19,320) |  |  |  |
| Share-based compensation | 9 |  |  | 3,976 |  |  |  |  |  |  |  |  |  |  | 3,985 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 8,630 |  |  | (44) |  |  | 8,586 |  |  | 6 |  |
| Pension and other post retirement plans, net of taxes |  |  |  |  |  |  | 932 |  |  |  |  |  |  | 932 |  |  |  |
| Balance as of March 31, 2022 | $ | 4,635 |  |  | $ | 314,935 |  |  | $ | 861,156 |  |  | $ | (48,144) |  |  | $ | (170,875) |  |  | $ | 2,352 |  |  | $ | 964,059 |  |  | $ | 106 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-23-000070:notes:44]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the three months ended March 31, 2023 and March 31, 2022, are summarized below:

[0000038725-23-000070:notes:45]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| For the three months ended March 31, 2023: |  |  |
| Balance as of December 31, 2022 | $ | (191.3) |  |  | $ | (40.1) |  |  | $ | (231.4) |  |
| Other comprehensive income/(loss) before reclassifications | 6.5 |  |  | — |  |  | 6.5 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.3 |  |  | 0.3 |  |
| Net other comprehensive income/(loss) | 6.5 |  |  | 0.3 |  |  | 6.8 |  |
| Balance as of March 31, 2023 | $ | (184.8) |  |  | $ | (39.8) |  |  | $ | (224.6) |  |
| For the three months ended March 31, 2022: |  |  |  |  |  |
| Balance as of December 31, 2021 | $ | (179.6) |  |  | $ | (49.0) |  |  | $ | (228.6) |  |
| Other comprehensive income/(loss) before reclassifications | 8.7 |  |  | — |  |  | 8.7 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.9 |  |  | 0.9 |  |
| Net other comprehensive income/(loss) | 8.7 |  |  | 0.9 |  |  | 9.6 |  |
| Balance as of March 31, 2022 | $ | (170.9) |  |  | $ | (48.1) |  |  | $ | (219.0) |  |

[0000038725-23-000070:notes:46]
[same as prior period, unchanged from 0000038725-22-000182:notes:75]

[0000038725-23-000070:notes:47]
(2) Net of tax expense of $0.1 million and $0.3 million for the three months ended March 31, 2023 and March 31, 2022, respectively.

[0000038725-23-000070:notes:48]
[same as prior period, unchanged from 0000038725-22-000182:notes:77]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-23-000070:notes:49]
SEGMENT AND GEOGRAPHIC INFORMATION
The accounting policies of the operating segments are the same as those described in Note 1 of the Company's Annual Report on Form 10-K for the year ended December 31, 2022. Revenue is recognized based on the invoice price at the point in time when the customer obtains control of the product, which is typically upon shipment to the customer. The Water and Fueling segments include manufacturing operations and supply certain components and finished goods, both between segments and to the Distribution segment. The Company reports these product transfers between Water and Fueling as inventory transfers as a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes. The Company reports intersegment transfers from Water to Distribution as intersegment revenue at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water and Distribution segments.

[0000038725-23-000070:notes:50]
[same as prior period, unchanged from 0000038725-22-000182:notes:79]

[0000038725-23-000070:notes:51]
[same as prior period, unchanged from 0000038725-22-000182:notes:80]

[0000038725-23-000070:notes:52]
|  | First Quarter Ended |  |  |
| (In millions) | March 31, 2023 |  | March 31, 2022 |  |  |  |  |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 159.4 |  |  | $ | 134.7 |  |  |  |  |  |
| Latin America | 40.3 |  |  | 37.9 |  |  |  |  |  |
| Europe, Middle East & Africa | 50.4 |  |  | 51.0 |  |  |  |  |  |
| Asia Pacific | 18.8 |  |  | 20.5 |  |  |  |  |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 37.7 |  |  | 28.5 |  |  |  |  |  |
| Total sales | 306.6 |  |  | 272.6 |  |  |  |  |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 143.0 |  |  | 134.9 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 143.0 |  |  | 134.9 |  |  |  |  |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 54.0 |  |  | 51.9 |  |  |  |  |  |
| All other | 18.7 |  |  | 20.6 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 72.7 |  |  | 72.5 |  |  |  |  |  |
| Intersegment Eliminations/Other | (37.7) |  |  | (28.5) |  |  |  |  |  |
| Consolidated | $ | 484.6 |  |  | $ | 451.5 |  |  |  |  |  |
|  | First Quarter Ended |  |  |
|  | March 31, 2023 |  | March 31, 2022 |  |  |  |  |
|  | Operating income/(loss) |
| Water Systems | $ | 49.0 |  |  | $ | 33.2 |  |  |  |  |  |
| Distribution | 4.7 |  |  | 9.4 |  |  |  |  |  |
| Fueling Systems | 20.8 |  |  | 17.7 |  |  |  |  |  |
| Intersegment Eliminations/Other | (21.9) |  |  | (20.4) |  |  |  |  |  |
| Consolidated | $ | 52.6 |  |  | $ | 39.9 |  |  |  |  |  |

[0000038725-23-000070:notes:53]
|  | March 31, 2023 |  | December 31, 2022 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 1,055.9 |  |  | $ | 1,017.5 |  |  |  |  |  |
| Distribution | 423.0 |  |  | 360.4 |  |  |  |  |  |
| Fueling Systems | 273.1 |  |  | 269.1 |  |  |  |  |  |
| Other | 51.4 |  |  | 47.2 |  |  |  |  |  |
| Consolidated | $ | 1,803.4 |  |  | $ | 1,694.2 |  |  |  |  |  |

[0000038725-23-000070:notes:54]
[same as prior period, unchanged from 0000038725-22-000182:notes:83]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-23-000070:notes:55]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position,  results of operations, or cash flows.

[0000038725-23-000070:notes:56]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-23-000070:notes:57]
At March 31, 2023, the Company had $13.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-23-000070:notes:58]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2023, are as follows:

[0000038725-23-000070:notes:59]
| (In millions) |  |  |
| Balance as of December 31, 2022 |  | $ | 11.2 |  |
| Accruals related to product warranties |  | 3.4 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (3.3) |  |
| Balance as of March 31, 2023 |  | $ | 11.3 |  |
