# FELE MD&A — 0000038725-17-000168


## mdna

[0000038725-17-000168:mdna:1]
[same as prior period, unchanged from 0000038725-17-000145:mdna:1]

[0000038725-17-000168:mdna:2]
Third Quarter 2017 vs. Third Quarter 2016

[0000038725-17-000168:mdna:3]
[same as prior period, unchanged from 0000038725-17-000145:mdna:3]

[0000038725-17-000168:mdna:4]
Sales and earnings in the third quarter of 2017 increased from the third quarter last year.  The sales increase was due to acquisitions, volume and price. The Company's consolidated gross profit was $103.8 million for the third quarter of 2017, an increase of $18.3 million or about 21 percent from the prior year’s third quarter.

[0000038725-17-000168:mdna:5]
[same as prior period, unchanged from 0000038725-17-000145:mdna:5]

[0000038725-17-000168:mdna:6]
[same as prior period, unchanged from 0000038725-17-000145:mdna:6]

[0000038725-17-000168:mdna:7]
Net sales in the third quarter of 2017 were $311.1 million, an increase of $71.3 million or about 30 percent compared to 2016 third quarter sales of $239.8 million.  The sales increase was primarily from acquisition related sales.  Sales revenue increased by $0.9 million or less than 1 percent in the third quarter of 2017 due to foreign currency translation. The sales change in the third quarter of 2017, excluding acquisition related sales and foreign currency translation, was an increase of $19.3 million or about 8 percent.

[0000038725-17-000168:mdna:8]
|  | Net Sales |
| (In millions) | Q3 2017 |  | Q3 2016 |  | 2017 v 2016 |
| Water Systems | $ | 196.5 |  |  | $ | 182.0 |  |  | $ | 14.5 |  |
| Fueling Systems | 63.5 |  |  | 57.8 |  |  | 5.7 |  |
| Distribution | 68.1 |  |  | — |  |  | 68.1 |  |
| Eliminations/Other | (17.0 | ) |  | — |  |  | (17.0 | ) |
| Consolidated | $ | 311.1 |  |  | $ | 239.8 |  |  | $ | 71.3 |  |

[0000038725-17-000168:mdna:9]
[same as prior period, unchanged from 0000038725-17-000145:mdna:9]

[0000038725-17-000168:mdna:10]
Water Systems sales were $196.5 million in the third quarter 2017, an increase of $14.5 million or about 8 percent versus the third quarter 2016 sales of $182.0 million.  Water Systems sales increased by $0.3 million or less than 1 percent in the quarter due to foreign currency translation. Water Systems organic sales were up about 8 percent compared to the third quarter 2016.

[0000038725-17-000168:mdna:11]
Water Systems sales in the U.S. and Canada were up about 11 percent compared to the prior year third quarter.   Sales of Pioneer branded dewatering equipment increased by about 90 percent in the third quarter when compared to the prior year resulting from the continued diversification of customers and strengthening in U.S. oil and gas end markets.  Sales of groundwater pumping equipment increased about 10 percent on broad based strength in both residential and agricultural systems.  Sales of other surface pumping equipment increased by 4 percent primarily in irrigation and agricultural related products.

[0000038725-17-000168:mdna:12]
Water Systems sales in markets outside the U.S. and Canada overall increased by about 5 percent. The impact of foreign currency translation was not significant.  International Water Systems sales were led by improved sales in Europe, including higher sales of Pioneer branded equipment, and the Middle East and Africa, but were offset by lower sales in the Latin American and Asia Pacific markets in the quarter compared to last year.

[0000038725-17-000168:mdna:13]
[same as prior period, unchanged from 0000038725-17-000145:mdna:13]

[0000038725-17-000168:mdna:14]
Fueling Systems sales were $63.5 million in the third quarter 2017, an increase of $5.7 million or about 10 percent versus the third quarter 2016 sales of $57.8 million.  The impact of foreign currency translation in the quarter was not significant.  The growth was across all regions and product lines, with strength in piping and containment systems.  Internationally, Fueling Systems revenues grew by about 18 percent, led by stronger sales in Europe and Asia.

[0000038725-17-000168:mdna:15]
[same as prior period, unchanged from 0000038725-17-000145:mdna:16]

[0000038725-17-000168:mdna:16]
Distribution sales were $68.1 million in the third quarter 2017 and were all acquisition related.  Management estimates third quarter Distribution sales declined by about 6 percent from the third quarter of 2016 primarily driven by supply chain disruptions and weak end market conditions in the Southeast region of the United States.

[0000038725-17-000168:mdna:17]
[same as prior period, unchanged from 0000038725-17-000145:mdna:18]

[0000038725-17-000168:mdna:18]
Cost of sales as a percent of net sales for the third quarter of 2017 and 2016 was 66.6 percent and 64.4 percent, respectively. Correspondingly, the gross profit margin decreased to 33.4 percent from 35.6 percent, a 220 basis point decline. The Company’s consolidated gross profit was $103.8 million for the third quarter of 2017, an increase of $18.3 million, or about 21 percent, from the third quarter of 2016 gross profit of $85.5 million. The gross profit increase was primarily due to higher sales.  The decline in gross profit margin percentage is partially attributable to the inclusion of the Distribution segment which impacted the margin by 70 basis points and the balance is due to product and geographic sales mix shifts and higher raw material costs.

[0000038725-17-000168:mdna:19]
[same as prior period, unchanged from 0000038725-17-000145:mdna:20]

[0000038725-17-000168:mdna:20]
Selling, general, and administrative (SG&A) expenses were $71.0 million in the third quarter of 2017 compared to $55.4 million in the third quarter of prior year, an increase of $15.6 million or about 28 percent.  The increase in SG&A expenses from acquired businesses were $15.8 million.  Excluding the acquired entities, the Company’s SG&A expenses in the third quarter of 2017 were flat to last year.

[0000038725-17-000168:mdna:21]
[same as prior period, unchanged from 0000038725-17-000145:mdna:22]

[0000038725-17-000168:mdna:22]
Restructuring expenses for the third quarter of 2017 were $1.0 million.  Restructuring expenses, primarily incurred in Brazil, include severance expenses, asset write-downs, and manufacturing equipment relocation costs.

[0000038725-17-000168:mdna:23]
Restructuring charges for the third quarter of 2016 resulted in a net gain of $1.7 million, primarily due to proceeds of $2.0 million from the sale of land and building in Brazil, and net of $0.3 million in expenses for other restructuring costs from continued manufacturing realignments.

[0000038725-17-000168:mdna:24]
[same as prior period, unchanged from 0000038725-17-000145:mdna:24]

[0000038725-17-000168:mdna:25]
Operating income was $31.8 million in both the third quarter of 2017 and 2016.

[0000038725-17-000168:mdna:26]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2017 |  | Q3 2016 |  | 2017 v 2016 |
| Water Systems |  | $ | 28.3 |  |  | $ | 30.0 |  |  | $ | (1.7 | ) |
| Fueling Systems |  | 17.1 |  |  | 15.2 |  |  | 1.9 |  |
| Distribution |  | 2.0 |  |  | — |  |  | 2.0 |  |
| Eliminations/Other |  | (15.6 | ) |  | (13.4 | ) |  | (2.2 | ) |
| Consolidated |  | $ | 31.8 |  |  | $ | 31.8 |  |  | $ | — |  |

[0000038725-17-000168:mdna:27]
[same as prior period, unchanged from 0000038725-17-000145:mdna:27]

[0000038725-17-000168:mdna:28]
Water Systems operating income was $28.3 million in the third quarter 2017, down $1.7 million or 6 percent versus the third quarter 2016 and operating income margin was 14.4 percent compared to the 16.5 percent in the third quarter 2016.  As mentioned above Water Systems operating income was negatively impacted by $1.0 million in restructuring expenses in the third quarter of 2017 and favorably impacted by $1.8 million in the third quarter of the prior year.  Water Systems operating income before restructuring was $29.3 million in the third quarter 2017, up $1.1 million or about 4 percent versus the third quarter 2016 and operating income margin before restructuring was 14.9 percent compared to the 15.5 percent in the third quarter 2016.  The decline in operating income margin is primarily related to product sales mix shifts and higher raw material costs.

[0000038725-17-000168:mdna:29]
[same as prior period, unchanged from 0000038725-17-000145:mdna:29]

[0000038725-17-000168:mdna:30]
Fueling Systems operating income was $17.1 million in the third quarter of 2017, up $1.9 million or about 13 percent compared to $15.2 million in the third quarter of 2016.  The increase is primarily attributable to sales volume.  The third quarter operating income margin was 26.9 percent, an increase of 60 basis points from the 26.3 percent of net sales in the third quarter of 2016.

[0000038725-17-000168:mdna:31]
[same as prior period, unchanged from 0000038725-17-000145:mdna:31]

[0000038725-17-000168:mdna:32]
Distribution operating income was $2.0 million in the third quarter of 2017 and the third quarter operating income margin was 2.9 percent.

[0000038725-17-000168:mdna:33]
[same as prior period, unchanged from 0000038725-17-000145:mdna:33]

[0000038725-17-000168:mdna:34]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the third quarter of 2017 was $2.5 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer.  General and administrative expenses were lower by $0.3 million or about 2 percent.

[0000038725-17-000168:mdna:35]
[same as prior period, unchanged from 0000038725-17-000145:mdna:36]

[0000038725-17-000168:mdna:36]
Interest expense for the third quarter of 2017 and 2016 was $2.3 million and $2.0 million, respectively.

[0000038725-17-000168:mdna:37]
[same as prior period, unchanged from 0000038725-17-000145:mdna:38]

[0000038725-17-000168:mdna:38]
Other income or expense was income of $0.6 million in the third quarter of 2017 and income of $1.4 million in the third quarter of 2016.  Included in other income in the third quarter of 2017 was an additional gain of $0.4 million on the previously held equity investments in three Distribution entities and interest income of $0.2 million, primarily derived from the investment of cash balances in short-term securities. Included in other income in the third quarter of 2016 was minority income of $1.2 million and interest income of $0.2 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-17-000168:mdna:39]
[same as prior period, unchanged from 0000038725-17-000145:mdna:40]

[0000038725-17-000168:mdna:40]
Foreign currency-based transactions produced a gain for the third quarter of 2017 and 2016 of $0.2 million and $0.4 million, respectively.

[0000038725-17-000168:mdna:41]
[same as prior period, unchanged from 0000038725-17-000145:mdna:42]

[0000038725-17-000168:mdna:42]
The provision for income taxes in the third quarter of 2017 and 2016 was $5.8 million and $7.9 million, respectively. The effective tax rate for the third quarter of 2017 was about 19 percent and, before the impact of discrete events, was about 23 percent.  Discrete events in the third quarter included excess tax benefits on stock-based compensation and the statute expiration of domestic uncertain tax positions.  The effective tax rate for the third quarter of 2016 was about 25 percent and, before the impact of discrete events, was about 27 percent. The tax rate as a percentage of pre-tax earnings for the full year of 2017 is projected to be 25 percent to 28 percent, compared to the full year 2016 tax rate of about 26 percent, before discrete adjustments. The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings taxed at lower rates and the recognition of U.S. incentives. The Company has the ability to indefinitely reinvest foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-17-000168:mdna:43]
[same as prior period, unchanged from 0000038725-17-000145:mdna:44]

[0000038725-17-000168:mdna:44]
Net income for the third quarter of 2017 was $24.5 million compared to the prior year third quarter net income of $23.7 million.  Net income attributable to Franklin Electric Co., Inc. for the third quarter of 2017 was $24.5 million, or $0.52 per diluted share, compared to the prior year third quarter net income attributable to Franklin Electric Co., Inc. of $23.7 million or $0.50 per diluted share.

[0000038725-17-000168:mdna:45]
First Nine Months of 2017 vs. First Nine Months of 2016

[0000038725-17-000168:mdna:46]
[same as prior period, unchanged from 0000038725-17-000145:mdna:47]

[0000038725-17-000168:mdna:47]
Sales and earnings in the first nine months of 2017 were up from the same period last year.  The sales increase was related to acquisitions, volume and price increases partially offset by the negative impact of foreign currency translation on sales. The Company's consolidated gross profit was $282.4 million for the first nine months of 2017, an increase of $32.0 million or about 13 percent from the first nine months of 2016.

[0000038725-17-000168:mdna:48]
[same as prior period, unchanged from 0000038725-17-000145:mdna:49]

[0000038725-17-000168:mdna:49]
[same as prior period, unchanged from 0000038725-17-000145:mdna:50]

[0000038725-17-000168:mdna:50]
Net sales in the first nine months of 2017 were $836.7 million, an increase of $126.4 million or about 18 percent compared to sales in the first nine months of 2016 of $710.3 million.  The sales increase was primarily from acquisition related sales.  Sales revenue decreased by $1.4 million or less than 1 percent in the first nine months of 2017 due to foreign currency translation. The sales change in the first nine months of 2017, excluding acquisitions and foreign currency translation, was an increase of

[0000038725-17-000168:mdna:51]
$36.3 million or about 5 percent.

[0000038725-17-000168:mdna:52]
|  | Net Sales |
| (In millions) | YTD September 30, 2017 |  | YTD October 1, 2016 |  | 2017 v 2016 |
| Water Systems | $ | 567.1 |  |  | $ | 545.4 |  |  | $ | 21.7 |  |
| Fueling Systems | 178.1 |  |  | 164.9 |  |  | 13.2 |  |
| Distribution | 127.2 |  |  | — |  |  | 127.2 |  |
| Eliminations/Other | (35.7 | ) |  | — |  |  | (35.7 | ) |
| Consolidated | $ | 836.7 |  |  | $ | 710.3 |  |  | $ | 126.4 |  |

[0000038725-17-000168:mdna:53]
[same as prior period, unchanged from 0000038725-17-000145:mdna:53]

[0000038725-17-000168:mdna:54]
Water Systems sales were $567.1 million in the first nine months 2017 and increased by $21.7 million or about 4 percent versus the first nine months 2016. Foreign currency translation rate changes decreased sales $0.5 million compared to sales in the first nine months of 2016. The Water Systems sales change in the first nine months of 2017, excluding foreign currency translation, was an increase of $22.2 million or about 4 percent.

[0000038725-17-000168:mdna:55]
Water Systems sales in the U.S. and Canada were up about 5 percent compared to the first nine months of 2016.   Sales of Pioneer branded dewatering equipment increased by about 30 percent in the first nine months of 2017 when compared to the prior year resulting from the continued diversification of customers and strengthening in U.S. oil and gas end markets.  Sales of other surface pumping equipment increased by 3 percent primarily in irrigation and agricultural related products. Sales of groundwater pumping equipment were flat overall with increases in residential offset with declines in agricultural systems.

[0000038725-17-000168:mdna:56]
Water Systems sales in markets outside the U.S. and Canada overall increased by about 3 percent. The impact of foreign currency translation was not significant.  International Water Systems sales were led by improved sales in Europe, including higher sales of Pioneer branded equipment, and the Middle East and Africa, but were offset by lower sales in the Latin American and Asia Pacific markets in the quarter compared to last year.

[0000038725-17-000168:mdna:57]
[same as prior period, unchanged from 0000038725-17-000145:mdna:57]

[0000038725-17-000168:mdna:58]
Fueling Systems sales were $178.1 million in the first nine months of 2017 and increased $13.2 million or about 8 percent from the first nine months of 2016.  Foreign currency translation rate changes decreased sales $0.9 million or less than 1 percent compared to sales in the first nine months of 2016. The Fueling Systems sales change in the first nine months of 2017, excluding foreign currency translation, was an increase of $14.1 million or about 9 percent.

[0000038725-17-000168:mdna:59]
Fueling Systems sales in the U.S. and Canada grew by about 6 percent during the first nine months with sales growth coming from all product lines.  Outside the U.S. and Canada, Fueling Systems revenues were up by about 10 percent overall with increased sales in China and Europe partially offset by lower sales in India.

[0000038725-17-000168:mdna:60]
[same as prior period, unchanged from 0000038725-17-000145:mdna:60]

[0000038725-17-000168:mdna:61]
Distribution sales were $127.2 million in the first nine months of 2017 and were all acquisition related.  Management estimates Distribution sales declined by about 6 percent from the first nine months of 2016 primarily driven by supply chain disruptions and weak end market conditions in the Southeast region of the United States.

[0000038725-17-000168:mdna:62]
[same as prior period, unchanged from 0000038725-17-000145:mdna:62]

[0000038725-17-000168:mdna:63]
Cost of sales as a percent of net sales for the first nine months of 2017 and 2016 was 66.2 percent and 64.7 percent, respectively. Correspondingly, the gross profit margin was 33.8 percent and 35.3 percent for the first nine months of both years. The Company's consolidated gross profit was $282.4 million for the first nine months of 2017, up $32.0 million from the gross profit of $250.4 million in the first nine months of 2016. The gross profit increase was primarily due to higher sales. The decline in gross profit margin percentage is partially attributable to the inclusion of the Distribution segment which impacted the margin by about 60 basis points and the balance is due to product and geographic sales mix shifts and higher raw material costs.

[0000038725-17-000168:mdna:64]
[same as prior period, unchanged from 0000038725-17-000145:mdna:64]

[0000038725-17-000168:mdna:65]
Selling, general, and administrative expenses were $196.3 million in the first nine months of 2017 and increased by $30.6 million or 18 percent in the first nine months of 2017 compared to $165.7 million the first nine months of last year. The increase in SG&A expenses from acquired businesses were $28.8 million.  Excluding the acquired entities, the Company’s

[0000038725-17-000168:mdna:66]
SG&A expenses in the first nine months of 2017 were $167.5 and increased by $1.8 million or 1 percent.

[0000038725-17-000168:mdna:67]
[same as prior period, unchanged from 0000038725-17-000145:mdna:66]

[0000038725-17-000168:mdna:68]
Restructuring expenses for the first nine months of 2017 were $1.6 million. Restructuring expenses were primarily related to the continuing Brazilian manufacturing realignments. Restructuring expenses were primarily severance expenses, equipment relocations and other miscellaneous manufacturing realignment activities.  Restructuring charges for the first nine months of 2016 resulted in a net gain of $0.9 million. Restructuring expenses for the first nine months of 2016 included a gain of $2.0 million from the sale of land and building in Brazil and $1.1 million in expenses related to severance, equipment transfers, freight and relocation cost related to the transfer of production activities and other restructuring costs from continued manufacturing realignments.

[0000038725-17-000168:mdna:69]
[same as prior period, unchanged from 0000038725-17-000145:mdna:69]

[0000038725-17-000168:mdna:70]
Operating income was $84.6 million in the first nine months of 2017, down $1.0 million or about 1 percent from $85.6 million in the first nine months of 2016.

[0000038725-17-000168:mdna:71]
|  |  | Operating income (loss) |
| (In millions) |  | YTD September 30, 2017 |  | YTD October 1, 2016 |  | 2017 v 2016 |
| Water Systems |  | $ | 82.6 |  |  | $ | 85.6 |  |  | $ | (3 | ) |
| Fueling Systems |  | 43 |  |  | 40.9 |  |  | 2.1 |  |
| Distribution |  | 5.6 |  |  | — |  |  | 5.6 |  |
| Eliminations/Other |  | (46.6 | ) |  | (40.9 | ) |  | (5.7 | ) |
| Consolidated |  | $ | 84.6 |  |  | $ | 85.6 |  |  | $ | (1 | ) |

[0000038725-17-000168:mdna:72]
[same as prior period, unchanged from 0000038725-17-000145:mdna:73]

[0000038725-17-000168:mdna:73]
Water Systems operating income was $82.6 million in the first nine months of 2017, down $3.0 million or about 3 percent versus the first nine months of 2016 of $85.6 million and operating income margin was 14.6 percent in the first nine months of 2017 compared to the 15.7 percent in the first nine months of 2016. As mentioned above Water Systems operating income was negatively impacted by $1.6 million in restructuring expenses in the first nine months of 2017 and favorably impacted by $1.4 million in the first nine months of the prior year.  Water Systems operating income before restructuring was $84.2 million in both first nine months of 2017 and 2016 and operating income margin before restructuring was 14.8 percent compared to the 15.4 percent in the first nine months of 2016.  The decline in operating income margin is primarily related to product and geographic sales mix shifts and higher raw material costs.

[0000038725-17-000168:mdna:74]
[same as prior period, unchanged from 0000038725-17-000145:mdna:75]

[0000038725-17-000168:mdna:75]
Fueling Systems operating income was $43.0 million in the first nine months of 2017, up $2.1 million or about 5 percent compared to $40.9 million in the first nine months of 2016.  The first nine months of 2017 operating income margin was 24.1 percent, a decrease of 70 basis points from the 24.8 percent of net sales in the first nine months of 2016. Operating income margin decreased in Fueling Systems due to higher direct material costs.

[0000038725-17-000168:mdna:76]
[same as prior period, unchanged from 0000038725-17-000145:mdna:77]

[0000038725-17-000168:mdna:77]
Distribution operating income was $5.6 million in the first nine months of 2017 and in the first nine months of 2017 operating income margin was 4.4 percent

[0000038725-17-000168:mdna:78]
[same as prior period, unchanged from 0000038725-17-000145:mdna:79]

[0000038725-17-000168:mdna:79]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the first nine months of 2017 was $5.8 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer.  General and administrative expenses were flat to last year.

[0000038725-17-000168:mdna:80]
[same as prior period, unchanged from 0000038725-17-000145:mdna:81]

[0000038725-17-000168:mdna:81]
Interest expense for the first nine months of 2017 and 2016 was $8.1 million and $6.6 million, respectively. The increase in interest expense in the first nine months of 2017 is primarily interest charges on prior years VAT taxes as a result of an audit in an international jurisdiction.

[0000038725-17-000168:mdna:82]
[same as prior period, unchanged from 0000038725-17-000145:mdna:83]

[0000038725-17-000168:mdna:83]
Other income or expense was a gain of $6.8 million in the first nine months of 2017. Included in other income in the first nine months of 2017 was a gain of $5.2 million on the previously held equity investments in three Distribution entities as indicated in the announcement made on April 10, 2017 regarding the acquisition of the controlling interests of these entities. Also, included in other income in the first nine months of 2017 was minority income of $0.6 million and interest income of $0.7 million, primarily derived from the investment of cash balances in short-term securities.  The first nine months of 2016 was a gain of $2.8 million.  Included in other income in the first nine months of 2016 was minority income $1.7 million and interest income of $0.8 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-17-000168:mdna:84]
[same as prior period, unchanged from 0000038725-17-000145:mdna:85]

[0000038725-17-000168:mdna:85]
Foreign currency-based transactions produced a gain for the first nine months of 2017 and 2016 of $0.3 million and $0.6 million, respectively.

[0000038725-17-000168:mdna:86]
[same as prior period, unchanged from 0000038725-17-000145:mdna:87]

[0000038725-17-000168:mdna:87]
The provision for income taxes in the first nine months of 2017 and 2016 was $12.9 million and $20.8 million, respectively. The effective tax rate for the first nine months of 2017 was about 15 percent and, before the impact of discrete events, was about 26 percent. Discrete events in the first nine months include a foreign currency translation loss on the repayment of an intercompany loan that was a long-term-investment in nature, a tax restructuring in a foreign tax jurisdiction that released a valuation allowance on a deferred tax asset and a tax benefit on the non-taxable gain recorded on the previously held equity investments and the statute expiration on foreign uncertain tax positions. The effective tax rate for the first nine months of 2016 was about 25 percent and, before the impact of discrete events, was about 27 percent. The tax rate as a percentage of pre-tax earnings for the full year of 2017 is projected to be 25 percent to 28 percent, compared to the full year 2016 tax rate of about 26 percent, before discrete adjustments. The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings taxed at lower rates and the recognition of U.S. incentives. The Company believes that it has the ability to indefinitely reinvest foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-17-000168:mdna:88]
[same as prior period, unchanged from 0000038725-17-000145:mdna:89]

[0000038725-17-000168:mdna:89]
Net income for the first nine months of 2017 was $70.7 million compared to 2016 first nine months net income of $61.5 million.  Net income attributable to Franklin Electric Co., Inc. for the first nine months of 2017 was $70.1 million, or $1.48 per diluted share, compared to 2016 first nine months net income attributable to Franklin Electric Co., Inc. of $61.1 million or $1.28 per diluted share.

[0000038725-17-000168:mdna:90]
[same as prior period, unchanged from 0000038725-17-000145:mdna:91]

[0000038725-17-000168:mdna:91]
[same as prior period, unchanged from 0000038725-17-000145:mdna:92]

[0000038725-17-000168:mdna:92]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at September 30, 2017 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-17-000168:mdna:93]
As of September 30, 2017, the Company had a $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of September 30, 2017, the Company had $225.0 million borrowing capacity under the Credit Agreement as $5.5 million in letters of commercial and standby letters of credit were outstanding and undrawn and $69.5 million in revolver borrowings were drawn and outstanding as of the end of the quarter which were primarily used for acquisition and working capital needs.

[0000038725-17-000168:mdna:94]
The Company also has other long-term debt borrowings outstanding as of September 30, 2017.  See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-17-000168:mdna:95]
At September 30, 2017, the Company had $54.6 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-17-000168:mdna:96]
[same as prior period, unchanged from 0000038725-17-000145:mdna:97]

[0000038725-17-000168:mdna:97]
The following table summarizes significant sources and uses of cash and cash equivalents for the first nine months of 2017 and 2016.

[0000038725-17-000168:mdna:98]
| (in millions) |  | 2017 |  | 2016 |
| Net cash provided by operating activities |  | $ | 40.4 |  |  | $ | 70.9 |  |
| Net cash used in investing activities |  | (73.9 | ) |  | (25.1 | ) |
| Net cash used in financing activities |  | (14.2 | ) |  | (48.1 | ) |
| Impact of exchange rates on cash and cash equivalents |  | 3.5 |  |  | (0.3 | ) |
| Change in cash and cash equivalents |  | $ | (44.2 | ) |  | $ | (2.6 | ) |

[0000038725-17-000168:mdna:99]
[same as prior period, unchanged from 0000038725-17-000145:mdna:100]

[0000038725-17-000168:mdna:100]
[same as prior period, unchanged from 0000038725-17-000145:mdna:101]

[0000038725-17-000168:mdna:101]
Net cash provided by operating activities was $40.4 million for the nine months ended September 30, 2017 compared to the $70.9 million provided by operating activities for the nine months ended October 1, 2016.  The decrease in cash used in operations was largely attributable to an increase in inventory due to sales projections for the current year which are anticipated to be higher than the same period for the prior year.  Excluding the impact of the Distribution acquisitions in the second quarter of 2017, the Company also had higher uses of cash related to paying down accounts payable, primarily due to timing of inventory receipts and payments of incentive compensation in the first nine months of 2017 based on prior year earnings and relative to payments in the first nine months of the prior year.

[0000038725-17-000168:mdna:102]
[same as prior period, unchanged from 0000038725-17-000145:mdna:104]

[0000038725-17-000168:mdna:103]
[same as prior period, unchanged from 0000038725-17-000145:mdna:105]

[0000038725-17-000168:mdna:104]
Net cash used in investing activities was $73.9 million for the nine months ended September 30, 2017 compared to $25.1 million in the nine months ended October 1, 2016 in the prior year.  The increase was almost entirely attributable to cash paid related to the Distribution acquisitions during the second quarter of 2017.

[0000038725-17-000168:mdna:105]
[same as prior period, unchanged from 0000038725-17-000145:mdna:107]

[0000038725-17-000168:mdna:106]
[same as prior period, unchanged from 0000038725-17-000145:mdna:108]

[0000038725-17-000168:mdna:107]
Net cash used in financing activities was $14.2 million for the nine months ended September 30, 2017 compared to $48.1 million in the nine months ended October 1, 2016 in the prior year.  The decrease of cash used in financing activities was primarily attributable to decreased repayment relative to overall borrowings for the nine months ended October 1, 2016.

[0000038725-17-000168:mdna:108]
[same as prior period, unchanged from 0000038725-17-000145:mdna:110]
