# FELE notes — 0000038725-17-000168


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000038725-17-000168:notes:1]
| FRANKLIN ELECTRIC CO., INC. |
| PROFORMA CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
|  |  | Third Quarter Ended |  | Nine Months Ended |
| (in millions, except per share amounts) |  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Revenue: |  |  |  |  |  |  |  |  |
| As reported |  | $ | 311.1 |  |  | $ | 239.8 |  |  | $ | 836.7 |  |  | $ | 710.3 |  |
| Proforma |  | 311.1 |  |  | 294.8 |  |  | 896.6 |  |  | 865.8 |  |
| Net income: |  |  |  |  |  |  |  |  |
| As reported |  | $ | 24.5 |  |  | $ | 23.7 |  |  | $ | 70.1 |  |  | $ | 61.1 |  |
| Proforma |  | 24.5 |  |  | 26.4 |  |  | 71.3 |  |  | 67.0 |  |
| Basic earnings per share: |  |  |  |  |  |  |  |  |
| As reported |  | $ | 0.52 |  |  | $ | 0.51 |  |  | $ | 1.50 |  |  | $ | 1.29 |  |
| Proforma |  | 0.52 |  |  | 0.56 |  |  | 1.52 |  |  | 1.42 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |
| As reported |  | $ | 0.52 |  |  | $ | 0.50 |  |  | $ | 1.48 |  |  | $ | 1.28 |  |
| Proforma |  | 0.52 |  |  | 0.56 |  |  | 1.51 |  |  | 1.40 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-17-000168:notes:2]
[same as prior period, unchanged from 0000038725-17-000145:notes:2]

[0000038725-17-000168:notes:3]
[same as prior period, unchanged from 0000038725-17-000145:notes:3]

[0000038725-17-000168:notes:4]
During the second quarter of 2017, the Company acquired controlling interests in three distributors (2M Company, Inc. (“2M”), Drillers Service, Inc. (“DSI”), and Western Hydro, LLC (“Western Hydro”), collectively referred to below as the “Headwater acquisitions”) in the U.S. professional groundwater market for a combined purchase price of approximately $57.4 million, subject to certain terms and conditions.  The Company had previously prepaid a $3.0 million portion of the purchase price at the time of original investment.  The Company funded the Headwater acquisitions with cash on hand and short-term borrowings from the Company’s Revolver (see Note 10 - Debt).  The Headwater acquisitions will be reported within a new “Distribution” segment (see Note 14 - Segment Information).  The Headwater acquisitions provide the Company with a robust groundwater distribution channel throughout the United States.

[0000038725-17-000168:notes:5]
The Company previously held equity interests in these entities, each of which was less than 50 percent, and accounted for by the equity method of accounting.  The Company’s total interest in each of the entities is now 100 percent and the entities are included in the Company’s consolidated results effective from the date of acquisition.  The original equity interests in the acquired entities were remeasured to their fair values as of the acquisition date (which aggregated was $20.6 million) based on the income approach, which utilized management estimates and consultation with an independent third-party valuation firm.  Inputs included an analysis of the enterprise value based on financial projections and ownership percentages.  As a result, the Company has recognized an aggregate gain on the acquisitions of $5.2 million. These gains are included in the “Other income, net” line of the Company’s condensed consolidated statements of income.

[0000038725-17-000168:notes:6]
[same as prior period, unchanged from 0000038725-17-000145:notes:6]

[0000038725-17-000168:notes:7]
The preliminary goodwill of $34.0 million resulting from the Headwater acquisitions consists primarily of the benefits of forward channel integration opportunities and broadened product offerings. All of the goodwill was recorded as part of the Distribution segment, and only a portion ($12.0 million) is expected to be deductible for tax purposes.

[0000038725-17-000168:notes:8]
[same as prior period, unchanged from 0000038725-17-000145:notes:8]

[0000038725-17-000168:notes:9]
| (In millions) |  |  |
| Cash |  | $ | 2.7 |  |
| Receivables |  | 32.6 |  |
| Inventory |  | 56.0 |  |
| Other current assets |  | 4.9 |  |
| Total current assets |  | 96.2 |  |
| Property, plant, and equipment |  | 9.8 |  |
| Intangible assets |  | 5.7 |  |
| Goodwill |  | 34.0 |  |
| Other assets |  | 0.2 |  |
| Total assets |  | 145.9 |  |
| Accounts payable |  | (22.8 | ) |
| Accrued liabilities and other current liabilities |  | (10.8 | ) |
| Current maturities of long-term debt |  | (31.6 | ) |
| Total current liabilities |  | (65.2 | ) |
| Long-term debt |  | (2.0 | ) |
| Other long-term liabilities |  | (0.7 | ) |
| Total liabilities |  | (67.9 | ) |
| Total |  | 78.0 |  |
| Less: Fair value of original equity interest |  | (20.6 | ) |
| Total purchase price |  | $ | 57.4 |  |

[0000038725-17-000168:notes:10]
The fair values of the assets acquired and liabilities assumed related to the Headwater acquisitions are provisional amounts as of September 30, 2017, pending final valuations and purchase accounting adjustments.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation process.

[0000038725-17-000168:notes:11]
The following unaudited proforma financial information for the third quarter and nine months ended September 30, 2017 and October 1, 2016 gives effect to the Headwater acquisitions by the Company as if the acquisitions had occurred as of January 3, 2016.  These unaudited proforma condensed consolidated financial statements are prepared for informational purposes only and are not necessarily indicative of actual results or financial position that would have been achieved had the acquisitions been consummated on the dates indicated and are not necessarily indicative of future operating results or financial position of the consolidated companies.  The unaudited proforma condensed consolidated financial statements do not give effect to any cost savings or incremental costs that may result from the integration of the Headwater acquisitions with the Company.

[0000038725-17-000168:notes:12]
The Headwater entities contributed a total of $127.2 million of revenue and $2.8 million of net income to the Company's condensed consolidated statements of income from their acquisition dates through September 30, 2017.

[0000038725-17-000168:notes:13]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations.  There were zero and $0.3 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the third quarter and nine months ended September 30, 2017, respectively.  There were no transaction costs incurred in the third quarter or nine months ended October 1, 2016.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-17-000168:notes:14]
COMMITMENTS AND CONTINGENCIES

[0000038725-17-000168:notes:15]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-17-000168:notes:16]
At September 30, 2017, the Company had $8.7 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-17-000168:notes:17]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two to five years from date of manufacture or one to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-17-000168:notes:18]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2017, are as follows:

[0000038725-17-000168:notes:19]
| (In millions) |  |  |
| Balance as of December 31, 2016 |  | $ | 8.2 |  |
| Accruals related to product warranties |  | 7.3 |  |
| Additions related to acquisitions |  | 1.3 |  |
| Reductions for payments made |  | (6.8 | ) |
| Balance as of September 30, 2017 |  | $ | 10.0 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-17-000168:notes:20]
[same as prior period, unchanged from 0000038725-17-000145:notes:20]

[0000038725-17-000168:notes:21]
Changes in accumulated other comprehensive income/(loss) by component for the nine months ended September 30, 2017 and October 1, 2016, are summarized below:

[0000038725-17-000168:notes:22]
| (In millions) |  |  |  |  |  |
| For the nine months ended September 30, 2017: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2016 | $ | (118.4 | ) |  | $ | (51.5 | ) |  | $ | (169.9 | ) |
| Other comprehensive income/(loss) before reclassifications | 21.6 |  | — |  |  | 21.6 |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.5 |  |  | 1.5 |  |
| Net other comprehensive income/(loss) | 21.6 |  |  | 1.5 |  |  | 23.1 |  |
| Balance as of September 30, 2017 | $ | (96.8 | ) |  | $ | (50.0 | ) |  | $ | (146.8 | ) |
| For the nine months ended October 1, 2016: |  |  |  |  |  |
| Balance as of January 2, 2016 | $ | (110.1 | ) |  | $ | (51.5 | ) |  | $ | (161.6 | ) |
| Other comprehensive income/(loss) before reclassifications | 12.1 |  |  | — |  |  | 12.1 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.4 |  |  | 1.4 |  |
| Net other comprehensive income/(loss) | 12.1 |  |  | 1.4 |  |  | 13.5 |  |
| Balance as of October 1, 2016 | $ | (98.0 | ) |  | $ | (50.1 | ) |  | $ | (148.1 | ) |

[0000038725-17-000168:notes:23]
[same as prior period, unchanged from 0000038725-17-000145:notes:23]

[0000038725-17-000168:notes:24]
(2) Net of tax (benefit)/expense of $0.8 million for both the nine months ended September 30, 2017 and October 1, 2016.

[0000038725-17-000168:notes:25]
[same as prior period, unchanged from 0000038725-17-000145:notes:25]


## us-gaap:DebtDisclosureTextBlock

[0000038725-17-000168:notes:26]
DEBT

[0000038725-17-000168:notes:27]
Debt consisted of the following:

[0000038725-17-000168:notes:28]
| (In millions) |  | September 30, 2017 |  | December 31, 2016 |
| Prudential Agreement |  | $ | 60.0 |  |  | $ | 90.0 |  |
| Tax increment financing debt |  | 20.8 |  |  | 21.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 69.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.6 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 229.7 |  |  | $ | 190.2 |  |
| Less: current maturities |  | (104.1 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 125.6 |  |  | $ | 156.5 |  |

[0000038725-17-000168:notes:29]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2017 matures as follows:

[0000038725-17-000168:notes:30]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 229.9 |  |  | $ | 104.0 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 90.8 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 230.0 |  |  | $ | 104.1 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 90.8 |  |

[0000038725-17-000168:notes:31]
Prudential Agreement

[0000038725-17-000168:notes:32]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of September 30, 2017, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-17-000168:notes:33]
Project Bonds

[0000038725-17-000168:notes:34]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-17-000168:notes:35]
New York Life

[0000038725-17-000168:notes:36]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (1.24 percent as of September 30, 2017) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of September 30, 2017, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-17-000168:notes:37]
Credit Agreement

[0000038725-17-000168:notes:38]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-17-000168:notes:39]
As of September 30, 2017, the Company had $69.5 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $5.5 million in letters of credit outstanding, and $225.0 million of available capacity under the Credit Agreement.

[0000038725-17-000168:notes:40]
Covenants

[0000038725-17-000168:notes:41]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with these significant financial covenants as of September 30, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-17-000168:notes:42]
[same as prior period, unchanged from 0000038725-17-000145:notes:42]

[0000038725-17-000168:notes:43]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements ("the swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of September 30, 2017, the swap had a notional value based on 215,000 shares.  For the third quarter and nine months ended September 30, 2017, the swap resulted in gains of $0.7 million and $1.1 million, respectively.  For the third quarter and nine months ended October 1, 2016, the swap resulted in gains of $1.5 million and $2.6 million, respectively.  Gains and losses resulting from the the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-17-000168:notes:44]
[same as prior period, unchanged from 0000038725-17-000145:notes:44]

[0000038725-17-000168:notes:45]
[same as prior period, unchanged from 0000038725-17-000145:notes:45]

[0000038725-17-000168:notes:46]
[same as prior period, unchanged from 0000038725-17-000145:notes:46]

[0000038725-17-000168:notes:47]
[same as prior period, unchanged from 0000038725-17-000145:notes:47]

[0000038725-17-000168:notes:48]
[same as prior period, unchanged from 0000038725-17-000145:notes:48]

[0000038725-17-000168:notes:49]
[same as prior period, unchanged from 0000038725-17-000145:notes:49]

[0000038725-17-000168:notes:50]
[same as prior period, unchanged from 0000038725-17-000145:notes:50]

[0000038725-17-000168:notes:51]
[same as prior period, unchanged from 0000038725-17-000145:notes:51]

[0000038725-17-000168:notes:52]
[same as prior period, unchanged from 0000038725-17-000145:notes:52]

[0000038725-17-000168:notes:53]
[same as prior period, unchanged from 0000038725-17-000145:notes:53]

[0000038725-17-000168:notes:54]
[same as prior period, unchanged from 0000038725-17-000145:notes:54]

[0000038725-17-000168:notes:55]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the nine months ended September 30, 2017 and October 1, 2016 are as follows:

[0000038725-17-000168:notes:56]
|  |  | September 30, 2017 |  | October 1, 2016 |
| Risk-free interest rate |  | 1.89 | % |  | 1.21 | % |
| Dividend yield |  | 0.94 | % |  | 1.32 | % |
| Volatility factor |  | 31.19 | % |  | 37.70 | % |
| Expected term |  | 5.5 years |  |  | 5.5 years |  |

[0000038725-17-000168:notes:57]
A summary of the Company’s outstanding stock option activity and related information for the nine months ended September 30, 2017 is as follows:

[0000038725-17-000168:notes:58]
| (Shares in thousands) |  | September 30, 2017 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,455 |  |  | $ | 25.02 |  |
| Granted |  | 192 |  |  | 42.49 |  |
| Exercised |  | (208 | ) |  | 18.11 |  |
| Forfeited |  | (2 | ) |  | 35.99 |  |
| Outstanding at end of period |  | 1,437 |  |  | $ | 28.34 |  |
| Expected to vest after applying forfeiture rate |  | 1,415 |  |  | $ | 28.21 |  |
| Vested and exercisable at end of period |  | 951 |  |  | $ | 24.24 |  |

[0000038725-17-000168:notes:59]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of September 30, 2017 is as follows:

[0000038725-17-000168:notes:60]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.68 years |  | $ | 23,722 |  |
| Expected to vest after applying forfeiture rate |  | 5.64 years |  | $ | 23,549 |  |
| Vested and exercisable at end of period |  | 4.23 years |  | $ | 19,594 |  |

[0000038725-17-000168:notes:61]
The total intrinsic value of options exercised during the nine months ended September 30, 2017 and October 1, 2016 was $4.8 million and $3.0 million, respectively.

[0000038725-17-000168:notes:62]
As of September 30, 2017, there was $1.9 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 1.98 years.

[0000038725-17-000168:notes:63]
[same as prior period, unchanged from 0000038725-17-000145:notes:63]

[0000038725-17-000168:notes:64]
A summary of the Company’s restricted stock/stock unit award activity and related information for the nine months ended September 30, 2017 is as follows:

[0000038725-17-000168:notes:65]
| (Shares in thousands) |  | September 30, 2017 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 473 |  |  | $ | 34.89 |  |
| Awarded |  | 136 |  |  | 42.23 |  |
| Vested |  | (109 | ) |  | 35.81 |  |
| Forfeited |  | (37 | ) |  | 36.51 |  |
| Non-vested at end of period |  | 463 |  |  | $ | 36.71 |  |

[0000038725-17-000168:notes:66]
As of September 30, 2017, there was $10.2 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.30 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-17-000168:notes:67]
[same as prior period, unchanged from 0000038725-17-000145:notes:67]

[0000038725-17-000168:notes:68]
[same as prior period, unchanged from 0000038725-17-000145:notes:68]

[0000038725-17-000168:notes:69]
[same as prior period, unchanged from 0000038725-17-000145:notes:69]

[0000038725-17-000168:notes:70]
[same as prior period, unchanged from 0000038725-17-000145:notes:70]

[0000038725-17-000168:notes:71]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions, except per share amounts) | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 24.5 |  |  | $ | 23.7 |  |  | $ | 70.1 |  |  | $ | 61.1 |  |
| Less: Undistributed earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.5 |  |  | 0.6 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | — |  |  | 0.1 |  |  | — |  |  | 0.8 |  |
| Net income available to common shareholders | $ | 24.3 |  |  | $ | 23.4 |  |  | $ | 69.6 |  |  | $ | 59.7 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.5 |  |  | 46.3 |  |  | 46.5 |  |  | 46.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.5 |  |  | 0.6 |  |  | 0.5 |  |  | 0.5 |  |
| Diluted weighted average common shares outstanding | 47.0 |  |  | 46.9 |  |  | 47.0 |  |  | 46.7 |  |
| Basic earnings per share | $ | 0.52 |  |  | $ | 0.51 |  |  | $ | 1.50 |  |  | $ | 1.29 |  |
| Diluted earnings per share | $ | 0.52 |  |  | $ | 0.50 |  |  | $ | 1.48 |  |  | $ | 1.28 |  |

[0000038725-17-000168:notes:72]
There were 0.4 million and 0.2 million stock options outstanding for the third quarters ended September 30, 2017 and October 1, 2016, and 0.3 million and 0.6 million stock options outstanding for the nine months ended September 30, 2017 and October 1, 2016, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000038725-17-000168:notes:73]
[same as prior period, unchanged from 0000038725-17-000145:notes:73]

[0000038725-17-000168:notes:74]
Through the second quarter of 2017, the Company held equity interests in the acquired companies identified in Note 3 - Acquisitions for various strategic purposes.  The investments were accounted for under the equity method and were included in “Other assets” on the Company’s condensed consolidated balance sheets.  The carrying amount of the investments were adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments were not considered material to the Company’s financial position, either individually or in the aggregate.  During the second quarter of 2017, the remaining interests of these equity method investments were purchased (see Note 3 - Acquisitions), bringing total ownership of these entities to 100 percent.  As of September 30, 2017, there were no equity method investments recorded on the Company's condensed consolidated balance sheets.  Prior to the purchase of the remaining interests, the Company’s proportionate share of earnings from its equity interests, were included in the "Other income, net" line of the Company's condensed consolidated statements of income.  This amount was immaterial for the third quarter ended October 1, 2016.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-17-000168:notes:75]
As of September 30, 2017 and December 31, 2016, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-17-000168:notes:76]
| (In millions) | September 30, 2017 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.5 |  | $ | 3.5 |  | $ | — |  | $ | — |  |
|  | December 31, 2016 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.6 |  | $ | 3.6 |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-17-000168:notes:77]
[same as prior period, unchanged from 0000038725-17-000145:notes:78]

[0000038725-17-000168:notes:78]
[same as prior period, unchanged from 0000038725-17-000145:notes:79]

[0000038725-17-000168:notes:79]
[same as prior period, unchanged from 0000038725-17-000145:notes:80]

[0000038725-17-000168:notes:80]
[same as prior period, unchanged from 0000038725-17-000145:notes:81]

[0000038725-17-000168:notes:81]
[same as prior period, unchanged from 0000038725-17-000145:notes:82]

[0000038725-17-000168:notes:82]
[same as prior period, unchanged from 0000038725-17-000145:notes:83]

[0000038725-17-000168:notes:83]
[same as prior period, unchanged from 0000038725-17-000145:notes:84]

[0000038725-17-000168:notes:84]
Total debt, including current maturities, have carrying amounts of $229.7 million and $190.2 million and estimated fair values of $234 million and $195 million as of September 30, 2017 and December 31, 2016, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-17-000168:notes:85]
[same as prior period, unchanged from 0000038725-17-000145:notes:86]

[0000038725-17-000168:notes:86]
[same as prior period, unchanged from 0000038725-17-000145:notes:87]

[0000038725-17-000168:notes:87]
| (In millions) |  | September 30, 2017 |  | December 31, 2016 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.7 | ) |  | $ | 7.4 |  |  | $ | (6.4 | ) |
| Technology |  | 7.5 |  |  | (5.7 | ) |  | 7.5 |  |  | (5.3 | ) |
| Customer relationships |  | 140.9 |  |  | (55.9 | ) |  | 133.4 |  |  | (49.6 | ) |
| Other |  | 2.9 |  |  | (2.4 | ) |  | 2.7 |  |  | (2.1 | ) |
| Total |  | $ | 158.8 |  |  | $ | (70.7 | ) |  | $ | 151.0 |  |  | $ | (63.4 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 47.7 |  |  | — |  |  | 47.1 |  |  | — |  |
| Total intangibles |  | $ | 206.5 |  |  | $ | (70.7 | ) |  | $ | 198.1 |  |  | $ | (63.4 | ) |

[0000038725-17-000168:notes:88]
Amortization expense related to intangible assets for the third quarters ended September 30, 2017 and October 1, 2016 was $2.1 million and $2.2 million, respectively and $6.4 million and $6.3 million for the nine months ended September 30, 2017 and October 1, 2016, respectively.

[0000038725-17-000168:notes:89]
[same as prior period, unchanged from 0000038725-17-000145:notes:90]

[0000038725-17-000168:notes:90]
| (In millions) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 |
|  |  | $ | 8.8 |  |  | $ | 8.8 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |  | $ | 8.2 |  |

[0000038725-17-000168:notes:91]
The change in the carrying amount of goodwill by reporting segment for the nine months ended September 30, 2017, is as follows:

[0000038725-17-000168:notes:92]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2016 |  | $ | 136.3 |  |  | $ | 63.3 |  |  | $ | — |  |  | $ | 199.6 |  |
| Acquisitions |  | — |  |  | — |  |  | 34.0 |  |  | 34.0 |  |
| Foreign currency translation |  | 3.1 |  |  | 0.3 |  |  | — |  |  | 3.4 |  |
| Balance as of September 30, 2017 |  | $ | 139.4 |  |  | $ | 63.6 |  |  | $ | 34.0 |  |  | $ | 237.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-17-000168:notes:93]
[same as prior period, unchanged from 0000038725-17-000145:notes:94]

[0000038725-17-000168:notes:94]
The Company’s effective tax rate from continuing operations for the nine month period ended September 30, 2017 was 15.4 percent as compared to 25.3 percent for the nine month period ended October 1, 2016.  For the third quarters of 2017 and 2016 the effective tax rate was 19.0 percent and 25.0 percent, respectively.

[0000038725-17-000168:notes:95]
[same as prior period, unchanged from 0000038725-17-000145:notes:96]

[0000038725-17-000168:notes:96]
The Company recorded discrete excess tax benefits from stock-based compensation of $1.5 million in the nine month period ended September 30, 2017 and $0.9 million during the third quarter related to the adoption of ASU 2016-09. The adoption of ASU 2016-09 for stock-based compensation can add variability to the Company's provision for income taxes, mainly due to the timing of stock option exercises, vesting of restricted stock units, and the stock price.

[0000038725-17-000168:notes:97]
During the second quarter ended June 30, 2017, the Company acquired controlling interests in three U.S. distributors (see Note 3 - Acquisitions).  These transactions created a discrete non-taxable gain recognized on the original minority equity investments resulting in a tax benefit of $1.9 million.

[0000038725-17-000168:notes:98]
[same as prior period, unchanged from 0000038725-17-000145:notes:98]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-17-000168:notes:99]
ACCOUNTING PRONOUNCEMENTS

[0000038725-17-000168:notes:100]
Accounting Standards Issued But Not Yet Adopted

[0000038725-17-000168:notes:101]
In March 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2017-07, Compensation - Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  This ASU requires entities to present only the service cost component of net periodic benefit cost as an operating expense (consistent with the presentation of other employee compensation costs).  The other components of net periodic benefit cost are to be presented as a non-operating expense.  The ASU is effective on a retrospective basis for interim and annual periods beginning after December 15, 2017.  Early adoption is permitted as of the beginning of any annual period for which an entity's financial statements have not been issued or made available for issuance.  The Company plans to adopt the ASU in the first quarter ended March 31, 2018 and does not expect the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-17-000168:notes:102]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-17-000168:notes:103]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification ("ASC") Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company has begun the evaluation process for the adoption of the ASU, and anticipates that the majority of the Company’s outstanding operating leases would be recognized as right-of-use assets and lease liabilities upon adoption, resulting in a significant impact to the Company’s consolidated balance sheets. The impact of this ASU is non-cash in nature and will not affect the Company’s cash position.  The impact to the Company’s results of operations is still being evaluated.

[0000038725-17-000168:notes:104]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606).  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  In March 2016, the FASB issued ASU 2016-08, Principal versus Agent Considerations, which clarifies implementation guidance on principal versus agent considerations. In April 2016, the FASB issued ASU 2016-10, Identifying Performance Obligations and Licensing, and in May 2016, the FASB issued ASU 2016-12, Narrow-Scope Improvements and Practical Expedients, both of which amend certain aspects of the new revenue recognition pursuant to ASU 2014-09. The amendments ASU 2016-08, ASU 2016-10, and ASU 2016-12 are effective in conjunction with ASU 2014-09 for interim and annual reporting periods beginning after December 15, 2017.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt this standard.  The Company will adopt ASU 2014-09, and the related amendments, beginning in the first quarter of 2018 using the modified retrospective approach.  The Company does not expect the adoption of this ASU to have a material impact on the Company’s consolidated financial position, results of operations, or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-17-000168:notes:105]
[same as prior period, unchanged from 0000038725-17-000145:notes:105]

[0000038725-17-000168:notes:106]
The accompanying condensed consolidated balance sheet as of December 31, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2017, and for the third quarters and nine months ended September 30, 2017 and October 1, 2016 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the third quarter and nine months ended September 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2017.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2016.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-17-000168:notes:107]
[same as prior period, unchanged from 0000038725-17-000145:notes:107]

[0000038725-17-000168:notes:108]
Defined Benefit Plans - As of September 30, 2017, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2016 measurement date for these plans.  One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-17-000168:notes:109]
[same as prior period, unchanged from 0000038725-17-000145:notes:109]

[0000038725-17-000168:notes:110]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the third quarters and nine months ended September 30, 2017 and October 1, 2016:

[0000038725-17-000168:notes:111]
| (In millions) | Pension Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Service cost | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.5 |  |  | $ | 0.8 |  |
| Interest cost | 1.4 |  |  | 1.6 |  |  | 4.3 |  |  | 4.7 |  |
| Expected return on assets | (2.2 | ) |  | (2.3 | ) |  | (6.7 | ) |  | (7.0 | ) |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.7 |  |  | 0.6 |  |  | 2.0 |  |  | 1.9 |  |
| Settlement cost | — |  |  | 0.3 |  |  | — |  |  | 0.9 |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.5 |  |  | $ | 0.1 |  |  | $ | 1.3 |  |

[0000038725-17-000168:notes:112]
In the nine months ended September 30, 2017, the Company made contributions of $2.2 million to the funded plans.   The amount of contributions to be made to the plans during the calendar year 2017 were finalized by September 15, 2017, based upon the funding level requirements identified and year-end valuation performed at December 31, 2016.

[0000038725-17-000168:notes:113]
The following table sets forth the aggregated net periodic benefit cost for the post-retirement benefit plan for the third quarters and nine months ended September 30, 2017 and October 1, 2016:

[0000038725-17-000168:notes:114]
| (In millions) | Other Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | — |  |  | 0.1 |  |  | 0.2 |  |  | 0.3 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.5 |  |  | $ | 0.6 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-17-000168:notes:115]
[same as prior period, unchanged from 0000038725-17-000145:notes:115]

[0000038725-17-000168:notes:116]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions) | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales | $ | 179.5 |  |  | $ | 182.0 |  |  | $ | 532.5 |  |  | $ | 545.4 |  |
| Intersegment sales | 17.0 |  |  | — |  |  | 34.7 |  |  | — |  |
| Total sales | 196.5 |  |  | 182.0 |  |  | 567.1 |  |  | 545.4 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales | 68.1 |  |  | — |  |  | 127.2 |  |  | — |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 68.1 |  |  | — |  |  | 127.2 |  |  | — |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales | 63.5 |  |  | 57.8 |  |  | 177.1 |  |  | 164.9 |  |
| Intersegment sales | — |  |  | — |  |  | 1.0 |  |  | — |  |
| Total sales | 63.5 |  |  | 57.8 |  |  | 178.1 |  |  | 164.9 |  |
| Intersegment Eliminations/Other | (17.0 | ) |  | — |  |  | (35.7 | ) |  | — |  |
| Consolidated | $ | 311.1 |  |  | $ | 239.8 |  |  | $ | 836.7 |  |  | $ | 710.3 |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
|  | Operating income/(loss) |
| Water Systems | $ | 28.3 |  |  | $ | 30.0 |  |  | $ | 82.6 |  |  | $ | 85.6 |  |
| Distribution | 2.0 |  |  | — |  |  | 5.6 |  |  | — |  |
| Fueling Systems | 17.1 |  |  | 15.2 |  |  | 43.0 |  |  | 40.9 |  |
| Intersegment Eliminations/Other | (15.6 | ) |  | (13.4 | ) |  | (46.6 | ) |  | (40.9 | ) |
| Consolidated | $ | 31.8 |  |  | $ | 31.8 |  |  | $ | 84.6 |  |  | $ | 85.6 |  |

[0000038725-17-000168:notes:117]
|  | September 30, 2017 |  | December 31, 2016 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 699.0 |  |  | $ | 671.5 |  |  |  |  |  |
| Distribution | 158.8 |  |  | — |  |  |  |  |  |
| Fueling Systems | 260.9 |  |  | 251.1 |  |  |  |  |  |
| Other | 60.8 |  |  | 117.3 |  |  |  |  |  |
| Consolidated | $ | 1,179.5 |  |  | $ | 1,039.9 |  |  |  |  |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-17-000168:notes:118]
The schedule below sets forth equity changes in the nine months ended September 30, 2017:

[0000038725-17-000168:notes:119]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2016 | $ | 4,638 |  |  | $ | 228,564 |  |  | $ | 550,095 |  |  | $ | (51,568 | ) |  | $ | (118,284 | ) |  | $ | 1,643 |  |  | $ | 615,088 |  |  | $ | 7,652 |  |
| Net income |  |  |  |  | 70,109 |  |  |  |  |  |  | 509 |  |  | 70,618 |  |  | 108 |  |
| Adjustment to Impo redemption value |  |  |  |  | 27 |  |  |  |  |  |  |  |  | 27 |  |  | (27 | ) |
| Dividends on common stock |  |  |  |  | (14,741 | ) |  |  |  |  |  |  |  | (14,741 | ) |  |  |
| Common stock issued | 21 |  |  | 3,749 |  |  |  |  |  |  |  |  |  |  | 3,770 |  |  |  |
| Common stock repurchased | (8 | ) |  |  |  | (3,255 | ) |  |  |  |  |  |  |  | (3,263 | ) |  |  |
| Share-based compensation | 8 |  |  | 6,035 |  |  |  |  |  |  |  |  |  |  | 6,043 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (504 | ) |  | (504 | ) |  |  |
| Purchase of redeemable noncontrolling shares |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (5,047 | ) |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 21,550 |  |  | 141 |  |  | 21,691 |  |  | (815 | ) |
| Pension liability, net of tax |  |  |  |  |  |  | 1,534 |  |  |  |  |  |  | 1,534 |  |  |  |
| Balance as of September 30, 2017 | $ | 4,659 |  |  | $ | 238,348 |  |  | $ | 602,235 |  |  | $ | (50,034 | ) |  | $ | (96,734 | ) |  | $ | 1,789 |  |  | $ | 700,263 |  |  | $ | 1,871 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-17-000168:notes:120]
[same as prior period, unchanged from 0000038725-17-000145:notes:120]

[0000038725-17-000168:notes:121]
[same as prior period, unchanged from 0000038725-17-000145:notes:121]

[0000038725-17-000168:notes:122]
Other Assets are generally Corporate assets that are not allocated to the segments and are comprised primarily of cash and property, plant and equipment.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-17-000168:notes:123]
[same as prior period, unchanged from 0000038725-17-000145:notes:123]
