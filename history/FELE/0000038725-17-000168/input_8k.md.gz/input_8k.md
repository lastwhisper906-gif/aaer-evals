# FELE 8-K — 0000038725-17-000163 filed 2017-10-24

## item codes, every 8-K on or before 2017-10-31

- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2017-10-31

- none on or before 2017-10-31

## item 2.02 — earnings release, exhibit 99.1

[0000038725-17-000163:8k_2_02:1]
EX-99.1
2
a201710248-kexhibit991.htm
EXHIBIT 99.1

[0000038725-17-000163:8k_2_02:2]
Exhibit

[0000038725-17-000163:8k_2_02:3]
Exhibit 99.1

[0000038725-17-000163:8k_2_02:4]
For Immediate Release

[0000038725-17-000163:8k_2_02:5]
For Further Information

[0000038725-17-000163:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-17-000163:8k_2_02:7]
260-824-2900

[0000038725-17-000163:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS THIRD QUARTER

[0000038725-17-000163:8k_2_02:9]
2017 SALES AND EARNINGS

[0000038725-17-000163:8k_2_02:10]
Fort Wayne, IN - October 24, 2017 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported third quarter 2017 GAAP fully diluted earnings per share (EPS) of $0.52, versus a GAAP fully diluted EPS in the third quarter 2016 of $0.50, an increase of 4 percent.  In the third quarter of 2017, the Company’s EPS was $0.53 before restructuring compared to 2016 third quarter EPS of $0.48 before restructuring, a 10 percent increase (see table below for a reconciliation of GAAP EPS to the EPS before restructuring).

[0000038725-17-000163:8k_2_02:11]
Third quarter 2017 sales were $311.1 million, an increase of $71.3 million or 30 percent compared to 2016 third quarter sales of $239.8 million.  The sales increase was primarily from acquisition related sales, as well as sales volume and price increases. The Company’s organic sales growth was 8 percent. Foreign currency translation increased sales less than 1 percent.

[0000038725-17-000163:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-17-000163:8k_2_02:13]
“We are pleased with our third quarter results which include record net sales and earnings per share for any third quarter in our Company’s history.  Our Fueling Systems and Water Systems business in the U.S. and Canada grew organically by 10 and 11 percent, respectively.  Our consolidated operating income before restructuring grew by 9 percent and our earnings per share before restructuring grew by 10 percent versus the same quarter prior year.  We also experienced strong growth in our Water Systems businesses in Europe, the Middle East and Africa primarily as a result of market share gains of pump products in Europe and continued strength in Turkey.  Our distribution segment turned in solid sales results despite supply chain disruptions.”

[0000038725-17-000163:8k_2_02:14]
Key Performance Indicators:

[0000038725-17-000163:8k_2_02:15]
| Earnings Before and After Restructuring |  | For the Third Quarter |
| (in millions) |  | 2017 | 2016 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 24.5 |  | $ | 23.7 |  | 3 | % |
| Allocated Undistributed Earnings |  | $ | (0.2 | ) | $ | (0.3 | ) |  |
| Earnings for EPS Calculations |  | $ | 24.3 |  | $ | 23.4 |  | 4 | % |
| Restructuring (before tax): |  | $ | 1.0 |  | $ | (1.7 | ) |  |
| Restructuring, net of tax: |  | $ | 0.6 |  | $ | (1.0 | ) |  |
| Earnings after Restructuring |  | $ | 24.9 |  | $ | 22.4 |  | 11 | % |
| Earnings Per Share |  | For the Third Quarter |
| Before and After Restructuring |  | 2017 | 2016 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.0 |  | 46.9 |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.52 |  | $ | 0.50 |  | 4 | % |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | (0.02 | ) |  |
| Fully Diluted EPS before Restructuring |  | $ | 0.53 |  | $ | 0.48 |  | 10 | % |

[0000038725-17-000163:8k_2_02:16]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q3 2016 | $ | 87.5 |  | $ | 35.0 |  | $ | 39.5 |  | $ | 20.0 |  | $ | 182.0 |  | $ | 57.8 |  | $ | — |  | $ | — |  | $ | 239.8 |  |
| Q3 2017 | $ | 97.5 |  | $ | 32.7 |  | $ | 47.0 |  | $ | 19.3 |  | $ | 196.5 |  | $ | 63.5 |  | $ | 68.1 |  | $ | (17.0 | ) | $ | 311.1 |  |
| Change | $ | 10.0 |  | $ | (2.3 | ) | $ | 7.5 |  | $ | (0.7 | ) | $ | 14.5 |  | $ | 5.7 |  | $ | 68.1 |  | $ | (17.0 | ) | $ | 71.3 |  |
| % Change | 11 | % | (7 | )% | 19 | % | (4 | )% | 8 | % | 10 | % |  |  |  |  | 30 | % |
| Foreign currency translation | $ | 0.3 |  | $ | 0.3 |  | $ | (0.4 | ) | $ | 0.1 |  | $ | 0.3 |  | $ | 0.6 |  |  |  |  |
| % Change | — | % | — | % | (1 | )% | — | % | — | % | 1 | % |  |  |  |
| Volume/Price | $ | 9.7 |  | $ | (2.6 | ) | $ | 7.9 |  | $ | (0.8 | ) | $ | 14.2 |  | $ | 5.1 |  |  |  |  |
| % Change | 11 | % | (7 | )% | 20 | % | (4 | )% | 8 | % | 9 | % |  |  |  |

[0000038725-17-000163:8k_2_02:17]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2017 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Reported Operating Income/(Loss) | $ | 28.3 |  | $ | 17.1 |  | $ | 2.0 |  | $ | (15.6 | ) | $ | 31.8 |  |
| % Operating Income To Net Sales | 14.4 | % | 26.9 | % | 2.9 | % |  | 10.2 | % |
| Restructuring | $ | 1.0 |  | $ | — |  | $ | — |  | $ | — |  | $ | 1.0 |  |
| Operating Income/(Loss) before Restructuring | $ | 29.3 |  | $ | 17.1 |  | $ | 2.0 |  | $ | (15.6 | ) | $ | 32.8 |  |
| % Operating Income to Net Sales Before Restructuring | 14.9 | % | 26.9 | % | 2.9 | % |  | 10.5 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2016 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Reported Operating Income/(Loss) | $ | 30.0 |  | $ | 15.2 |  | $ | — |  | $ | (13.4 | ) | $ | 31.8 |  |
| % Operating Income To Net Sales | 16.5 | % | 26.3 | % |  |  | 13.3 | % |
| Restructuring | $ | (1.8 | ) | $ | 0.1 |  | $ | — |  | $ | — |  | $ | (1.7 | ) |
| Operating Income/(Loss) before Restructuring | $ | 28.2 |  | $ | 15.3 |  | $ | — |  | $ | (13.4 | ) | $ | 30.1 |  |
| % Operating Income to Net Sales Before Restructuring | 15.5 | % | 26.5 | % |  |  | 12.6 | % |

[0000038725-17-000163:8k_2_02:18]
Water Systems

[0000038725-17-000163:8k_2_02:19]
Water Systems sales were $196.5 million in the third quarter 2017, an increase of $14.5 million or about 8 percent versus the third quarter 2016 sales of $182.0 million.  Water Systems sales increased by $0.3 million or less than 1 percent in the quarter due to foreign currency translation. Water Systems organic sales were up about 8 percent compared to the third quarter 2016.

[0000038725-17-000163:8k_2_02:20]
Water Systems sales in the U.S. and Canada were up about 11 percent compared to the prior year third quarter.   Sales of Pioneer branded dewatering equipment increased by about 90 percent in the third quarter when compared to the prior year resulting from the continued diversification of customers and strengthening in U.S. oil and gas end markets.  Sales of groundwater pumping equipment increased about 10 percent on broad based strength in both residential and agricultural systems.  Sales of other surface pumping equipment increased by 4 percent primarily in irrigation and agricultural related products.

[0000038725-17-000163:8k_2_02:21]
Water Systems sales in markets outside the U.S. and Canada overall increased by about 5 percent. The impact of foreign currency translation was not significant.  International Water Systems sales were led by improved sales in Europe, including higher sales of Pioneer branded equipment, and the Middle East and Africa, but were offset by lower sales in the Latin American and Asia Pacific markets in the quarter compared to last year.

[0000038725-17-000163:8k_2_02:22]
Water Systems operating income was $28.3 million in the third quarter 2017, down $1.7 million or 6 percent versus the third quarter 2016 and operating income margin was 14.4 percent compared to the 16.5 percent in the third quarter 2016.  Water Systems operating income before restructuring was $29.3 million in the third quarter 2017, up $1.1 million or about 4 percent versus the third quarter 2016 and operating income margin before restructuring was 14.9 percent compared to the 15.5 percent in the third quarter 2016.  The decline in operating income margin is primarily related to product sales mix shifts and higher raw material costs.

[0000038725-17-000163:8k_2_02:23]
Fueling Systems

[0000038725-17-000163:8k_2_02:24]
Fueling Systems sales were a record $63.5 million in the third quarter 2017, an increase of $5.7 million or about 10 percent versus the third quarter 2016 sales of $57.8 million.  The impact of foreign currency translation in the quarter was not significant.

[0000038725-17-000163:8k_2_02:25]
Fueling Systems sales in the U.S. and Canada grew by about 10 percent during the quarter.  The increase was across all product lines, with particular strength in piping and containment systems.  Outside of the U.S. and Canada, Fueling Systems revenues grew by about 18 percent, led by stronger sales in Europe and Asia.

[0000038725-17-000163:8k_2_02:26]
Fueling Systems operating income was $17.1 million in the third quarter of 2017, up $1.9 million or about 13 percent compared to $15.2 million in the third quarter of 2016 and third quarter operating income margin was 26.9 percent, an increase of 60 basis points from the 26.3 percent of net sales in the third quarter of 2016

[0000038725-17-000163:8k_2_02:27]
Distribution

[0000038725-17-000163:8k_2_02:28]
Distribution sales were $68.1 million in the third quarter 2017.  Management estimates third quarter Distribution sales declined by about 6 percent from the third quarter of 2016 primarily driven by supply chain disruptions and weak end market conditions in the Southeast region of the United States.

[0000038725-17-000163:8k_2_02:29]
Distribution operating income was $2.0 million in the third quarter of 2017 and the third quarter operating income margin was 2.9 percent.

[0000038725-17-000163:8k_2_02:30]
Overall

[0000038725-17-000163:8k_2_02:31]
The Company’s consolidated gross profit was $103.8 million for the third quarter of 2017, an increase of $18.3 million, or about 21 percent, from the third quarter of 2016 gross profit of $85.5 million. The gross profit as a percent of net sales was 33.4 percent in the third quarter of 2017 and decreased about 220 basis points versus 35.6 percent during the third quarter 2016.  The gross profit increase was primarily due to higher sales.  The decline in gross profit margin percentage is partially attributable to

[0000038725-17-000163:8k_2_02:32]
the inclusion of the Distribution segment which impacted the margin by 70 basis points and the balance is due to product and geographic sales mix shifts and higher raw material costs.

[0000038725-17-000163:8k_2_02:33]
Selling, general, and administrative (SG&A) expenses were $71.0 million in the third quarter of 2017 compared to $55.4 million in the third quarter of the prior year, an increase of $15.6 million or about 28 percent.  The increase in SG&A expenses from acquired businesses were $15.8 million.  Excluding the acquired entities, the Company’s SG&A expenses in the third quarter of 2017 were flat to last year.

[0000038725-17-000163:8k_2_02:34]
Restructuring expenses for the third quarter of 2017 were $1.0 million, reduced diluted earnings per share by approximately $0.01 and were related to ongoing efforts in Brazil.  Restructuring for the third quarter of 2016 resulted in income of $1.7 million and increased diluted earnings per share by $0.02 principally due to a gain on the sale of property in Brazil.

[0000038725-17-000163:8k_2_02:35]
The Company ended the third quarter of 2017 with a cash balance of about $60 million versus about $104 million at the end of 2016, down primarily due to acquisitions and increased working capital.  Inventory levels at the end of the third quarter 2017 were $301 million versus year end 2016 of $203 million. About $65 million of the inventory increase is due to the Distribution segment acquisitions.

[0000038725-17-000163:8k_2_02:36]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-17-000163:8k_2_02:37]
“We expect our Fueling Systems momentum from the third quarter to continue and are confident in the strength of the U.S. and Canada water end markets as we enter the fourth quarter of 2017.    However, we remain cautious about certain international water end markets including Asia Pacific and Latin America.  As a result, we are narrowing our full year 2017 adjusted earnings per share guidance to $1.88 to $1.92.”

[0000038725-17-000163:8k_2_02:38]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The third quarter 2017 earnings call will be available via a live webcast.  The webcast will be available in a listen only mode by going to:

[0000038725-17-000163:8k_2_02:39]
https://edge.media-server.com/m6/p/tmfc9j2d

[0000038725-17-000163:8k_2_02:40]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 96637193.

[0000038725-17-000163:8k_2_02:41]
A replay of the conference call will be available Tuesday, October 24, 2017 at 12:00 noon EDT through noon EDT on Tuesday, October 31, 2017, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 96637193.

[0000038725-17-000163:8k_2_02:42]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-17-000163:8k_2_02:43]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| Net sales | $ | 311,113 |  |  | $ | 239,755 |  |  | $ | 836,714 |  |  | $ | 710,266 |  |
| Cost of sales | 207,271 |  |  | 154,286 |  |  | 554,303 |  |  | 459,883 |  |
| Gross profit | 103,842 |  |  | 85,469 |  |  | 282,411 |  |  | 250,383 |  |
| Selling, general, and administrative expenses | 70,986 |  |  | 55,373 |  |  | 196,275 |  |  | 165,672 |  |
| Restructuring (income)/expense | 1,009 |  |  | (1,715 | ) |  | 1,575 |  |  | (850 | ) |
| Operating income | 31,847 |  |  | 31,811 |  |  | 84,561 |  |  | 85,561 |  |
| Interest expense | (2,297 | ) |  | (1,983 | ) |  | (8,055 | ) |  | (6,631 | ) |
| Other income, net | 574 |  |  | 1,446 |  |  | 6,814 |  |  | 2,787 |  |
| Foreign exchange income | 193 |  |  | 399 |  |  | 296 |  |  | 637 |  |
| Income before income taxes | 30,317 |  |  | 31,673 |  |  | 83,616 |  |  | 82,354 |  |
| Income tax expense | 5,769 |  |  | 7,926 |  |  | 12,890 |  |  | 20,840 |  |
| Net income | $ | 24,548 |  |  | $ | 23,747 |  |  | $ | 70,726 |  |  | $ | 61,514 |  |
| Less: Net income attributable to noncontrolling interests | (78 | ) |  | (83 | ) |  | (617 | ) |  | (411 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 24,470 |  |  | $ | 23,664 |  |  | $ | 70,109 |  |  | $ | 61,103 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.52 |  |  | $ | 0.51 |  |  | $ | 1.50 |  |  | $ | 1.29 |  |
| Diluted | $ | 0.52 |  |  | $ | 0.50 |  |  | $ | 1.48 |  |  | $ | 1.28 |  |

[0000038725-17-000163:8k_2_02:44]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | September 30, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 60,129 |  |  | $ | 104,331 |  |
| Receivables | 176,286 |  |  | 145,999 |  |
| Inventories | 301,374 |  |  | 203,471 |  |
| Other current assets | 44,462 |  |  | 30,018 |  |
| Total current assets | 582,251 |  |  | 483,819 |  |
| Property, plant, and equipment, net | 213,206 |  |  | 196,137 |  |
| Goodwill and other assets | 384,036 |  |  | 359,949 |  |
| Total assets | $ | 1,179,493 |  |  | $ | 1,039,905 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 76,163 |  |  | $ | 63,927 |  |
| Accrued expenses and other current liabilities | 67,898 |  |  | 60,119 |  |
| Current maturities of long-term debt and short-term borrowings | 104,081 |  |  | 33,715 |  |
| Total current liabilities | 248,142 |  |  | 157,761 |  |
| Long-term debt | 125,608 |  |  | 156,544 |  |
| Deferred income taxes | 42,776 |  |  | 40,460 |  |
| Employee benefit plans | 42,180 |  |  | 45,307 |  |
| Other long-term liabilities | 18,653 |  |  | 17,093 |  |
| Redeemable noncontrolling interest | 1,871 |  |  | 7,652 |  |
| Total equity | 700,263 |  |  | 615,088 |  |
| Total liabilities and equity | $ | 1,179,493 |  |  | $ | 1,039,905 |  |

[0000038725-17-000163:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Nine Months Ended |
| (In thousands) | September 30, 2017 |  | October 1, 2016 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 70,726 |  |  | $ | 61,514 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 28,418 |  |  | 26,752 |  |
| Share-based compensation | 6,043 |  |  | 5,912 |  |
| Gain on equity investment | (5,165 | ) |  | — |  |
| Other | (2,444 | ) |  | 2,148 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | 8,449 |  |  | (22,088 | ) |
| Inventory | (35,758 | ) |  | (14,910 | ) |
| Accounts payable and accrued expenses | (17,942 | ) |  | 9,333 |  |
| Other | (11,963 | ) |  | 2,204 |  |
| Net cash flows from operating activities | 40,364 |  |  | 70,865 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (22,517 | ) |  | (30,109 | ) |
| Proceeds from sale of property, plant, and equipment | 207 |  |  | 5,839 |  |
| Acquisitions and investments | (51,783 | ) |  | (1,007 | ) |
| Other investing activities | 149 |  |  | 174 |  |
| Net cash flows from investing activities | (73,944 | ) |  | (25,103 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 5,594 |  |  | (30,626 | ) |
| Proceeds from issuance of common stock | 3,770 |  |  | 3,192 |  |
| Purchases of common stock | (3,263 | ) |  | (6,193 | ) |
| Dividends paid | (15,245 | ) |  | (14,483 | ) |
| Purchase of redeemable non-controlling shares | (5,047 | ) |  | — |  |
| Net cash flows from financing activities | (14,191 | ) |  | (48,110 | ) |
| Effect of exchange rate changes on cash | 3,569 |  |  | (232 | ) |
| Net change in cash and equivalents | (44,202 | ) |  | (2,580 | ) |
| Cash and equivalents at beginning of period | 104,331 |  |  | 81,561 |  |
| Cash and equivalents at end of period | $ | 60,129 |  |  | $ | 78,981 |  |
