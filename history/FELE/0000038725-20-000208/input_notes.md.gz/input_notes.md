# FELE notes — 0000038725-20-000208


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-20-000208:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2019, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2020, and for the third quarters and nine months ended September 30, 2020 and September 30, 2019 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the third quarter and nine months ended September 30, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2020.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2019.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-20-000208:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-20-000208:notes:3]
In January 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted. The Company adopted the standard effective January 1, 2020. The standard did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000208:notes:4]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which modifies the measurement of expected credit losses on certain financial instruments, including trade receivables.  ASU 2016-13 is effective for interim and annual periods beginning after December 15, 2019 with early adoption permitted.  Amendments should be applied using a modified retrospective approach except for debt securities, which require a prospective transitions approach.  The Company adopted the standard effective January 1, 2020. The standard did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000208:notes:5]
Accounting Standards Issued But Not Yet Adopted

[0000038725-20-000208:notes:6]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which modifies the disclosure requirements for employers that sponsor defined benefit pension or other postretirement plans. The amendments remove disclosures that no longer are considered cost beneficial, including the estimated amounts in accumulated other comprehensive income expected to be recognized as components of net periodic expense over the next fiscal year. The amendments clarify the specific requirements of disclosures, and add disclosure requirements identified as relevant, including the reasons for significant gains and losses related to change in the benefit obligation for the period.  The ASU should be applied retrospectively and is effective for interim and annual periods beginning after December 15, 2020. The Company is still determining the date of adoption, but does not expect the ASU to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000208:notes:7]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is expected to reduce cost and complexity related to accounting for income taxes. ASU 2019-12 eliminates the need for the Company to analyze whether certain exceptions apply and improves financial statement preparers' application of income tax-related guidance. ASU 2019-12 is effective for interim and annual periods beginning after December 15, 2020 with early adoption permitted. Amendments related to franchise taxes that are partially based on income should be applied on either a retrospective or modified retrospective basis. All other amendments should be applied on a prospective basis. The Company is still determining the date of adoption, but does not expect the ASU to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000208:notes:8]
In August 2020, the FASB issued ASU 2020-06, Debt – Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging – Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity. ASU 2020-06 reduces the number of accounting models for various convertible instruments and reduces form-over-substance-based accounting conclusions for the derivatives scope exception for contracts in an entity’s own equity. The FASB also updated Earnings Per Share (“EPS”) guidance under Topic 260 by requiring an entity to 
consider the potential effect of share settlement in the diluted EPS calculation for instruments that may be settled in cash or shares as well as other amendments. ASU 2020-06 is effective for interim and annual periods beginning after December 15, 2021 with early adoption permitted but no earlier than fiscal years beginning after December 15, 2020. The guidance should be adopted at the beginning of a fiscal year. ASU 2020-06 should be applied on either a retrospective or modified retrospective basis. The Company is still determining the date of adoption, but does not expect the ASU to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-20-000208:notes:9]
ACQUISITIONS
During the first quarter ended March 31, 2020, the Company acquired all of the assets of a company that manufactures line shaft turbines and other adjacent product lines for a purchase price of $5.9 million after working capital adjustments.  The fair value of the assets acquired and liabilities assumed are preliminary as of September 30, 2020.  In addition, the Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for this acquisition is immaterial.

[0000038725-20-000208:notes:10]
During the third quarter ended September 30, 2019, the Company acquired 100 percent of the ownership interests of First Sales, LLC for a purchase price of approximately $15.5 million after working capital adjustments.  The acquisition was not material, and the fair value of the assets acquired and liabilities assumed are considered final as of September 30, 2020.

[0000038725-20-000208:notes:11]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations and were not material for the third quarter and nine months ended September 30, 2020. There were $0.0 million and $0.1 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the third quarter and nine months ended September 30, 2019 respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-20-000208:notes:12]
[same as prior period, unchanged from 0000038725-20-000179:notes:12]

[0000038725-20-000208:notes:13]
[same as prior period, unchanged from 0000038725-20-000179:notes:13]

[0000038725-20-000208:notes:14]
[same as prior period, unchanged from 0000038725-20-000179:notes:14]

[0000038725-20-000208:notes:15]
[same as prior period, unchanged from 0000038725-20-000179:notes:15]

[0000038725-20-000208:notes:16]
As of September 30, 2020 and December 31, 2019, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-20-000208:notes:17]
| (In millions) | September 30, 2020 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 15.7 |  | $ | 15.7 |  | $ | — |  | $ | — |  |
|  | December 31, 2019 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 4.0 |  | $ | 4.0 |  | $ | — |  | $ | — |  |

[0000038725-20-000208:notes:18]
The Company's Level 1 assets consist of cash equivalents which are generally comprised of foreign bank guaranteed certificates of deposit. 
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3.Total debt, including current maturities, have carrying amounts of $94.3 million and $115.0 million and estimated fair values of $106.4 million and $121.0 million as of September 30, 2020 and December 31, 2019, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-20-000208:notes:19]
FINANCIAL INSTRUMENTSThe Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of September 30, 2020, the swap had a notional value based on 280,000 shares. For the third quarter and nine months ended September 30, 2020, the swap resulted in gains of $1.8 million and $0.3 million, respectively. For the third quarter and nine months ended September 30, 2019, the swap resulted in gains of $0.0 million and $1.0 million, respectively. Gains and losses resulting from the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-20-000208:notes:20]
[same as prior period, unchanged from 0000038725-20-000179:notes:21]

[0000038725-20-000208:notes:21]
| (In millions) |  | September 30, 2020 |  | December 31, 2019 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.4 |  |  | $ | (7.2) |  |  | $ | 7.4 |  |  | $ | (7.0) |  |
| Technology |  | 7.5 |  |  | (7.1) |  |  | 7.5 |  |  | (6.8) |  |
| Customer relationships |  | 152.1 |  |  | (75.6) |  |  | 155.4 |  |  | (71.4) |  |
| Other |  | 3.7 |  |  | (2.9) |  |  | 3.8 |  |  | (2.8) |  |
| Total |  | $ | 170.7 |  |  | $ | (92.8) |  |  | $ | 174.1 |  |  | $ | (88.0) |  |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.7 |  |  | — |  |  | 45.0 |  |  | — |  |
| Total intangibles |  | $ | 213.4 |  |  | $ | (92.8) |  |  | $ | 219.1 |  |  | $ | (88.0) |  |

[0000038725-20-000208:notes:22]
Amortization expense related to intangible assets for the third quarters ended September 30, 2020 and September 30, 2019 was $2.4 million and $2.4 million, and for the nine months ended September 30, 2020 and September 30, 2019, $7.0 million and $7.0 million respectively.

[0000038725-20-000208:notes:23]
[same as prior period, unchanged from 0000038725-20-000179:notes:24]

[0000038725-20-000208:notes:24]
| (In millions) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |
|  |  | $ | 9.3 |  |  | $ | 8.9 |  |  | $ | 8.7 |  |  | $ | 8.6 |  |  | $ | 8.4 |  |

[0000038725-20-000208:notes:25]
The change in the carrying amount of goodwill by reportable segment for the nine months ended September 30, 2020, is as follows:

[0000038725-20-000208:notes:26]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2019 |  | $ | 151.0 |  |  | $ | 67.6 |  |  | $ | 37.5 |  |  | $ | 256.1 |  |
| Acquisitions |  | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |
| Foreign currency translation |  | (1.8) |  |  | (0.1) |  |  | — |  |  | (1.9) |  |
| Balance as of September 30, 2020 |  | $ | 150.6 |  |  | $ | 67.5 |  |  | $ | 37.5 |  |  | $ | 255.6 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-20-000208:notes:27]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of September 30, 2020, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2019 measurement date for these plans.  One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-20-000208:notes:28]
Other Benefits - The Company's other post-retirement benefit plan provides health and life insurance to domestic employees hired prior to 1992.

[0000038725-20-000208:notes:29]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the third quarters and nine months ended September 30, 2020 and September 30, 2019:

[0000038725-20-000208:notes:30]
| (In millions) | Pension Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2020 |  | September 30, 2019 |  | September 30, 2020 |  | September 30, 2019 |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.5 |  |  | $ | 0.6 |  |
| Interest cost | 1.1 |  |  | 1.5 |  |  | 3.3 |  |  | 4.5 |  |
| Expected return on assets | (1.7) |  |  | (2.0) |  |  | (5.1) |  |  | (6.0) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 1.0 |  |  | 0.6 |  |  | 2.8 |  |  | 1.9 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.6 |  |  | $ | 0.3 |  |  | $ | 1.5 |  |  | $ | 1.0 |  |

[0000038725-20-000208:notes:31]
In the nine months ended September 30, 2020, the Company made contributions of $0.1 million to the funded plans.  The amount of contributions to be made to the plans during the calendar year 2020 was finalized by September 15, 2020, based upon the funding level requirements identified and year-end valuation performed at December 31, 2019.

[0000038725-20-000208:notes:32]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the third quarters and nine months ended September 30, 2020 and September 30, 2019:

[0000038725-20-000208:notes:33]
| (In millions) | Other Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2020 |  | September 30, 2019 |  | September 30, 2020 |  | September 30, 2019 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.3 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-20-000208:notes:34]
INCOME TAXESThe Company’s effective tax rate from continuing operations for both of the nine month periods ended September 30, 2020 and September 30, 2019 was 18.9 percent. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to foreign earnings taxed at rates below the U.S. statutory rate, the recognition of the U.S. foreign-derived intangible income 
(FDII) provisions, and certain discrete events including excess tax benefits from share-based compensation.  For the third quarter of 2020, the effective tax rate was 17.3 percent as compared to 19.8 percent for the third quarter of 2019.

[0000038725-20-000208:notes:35]
The decrease in the effective tax rate for the third quarter of 2020, compared with the same period in 2019, was primarily a result of additional FDII benefit mostly resulting from the reconciliation of the domestic federal return to the provision.


## us-gaap:DebtDisclosureTextBlock

[0000038725-20-000208:notes:36]
DEBT
Debt consisted of the following:

[0000038725-20-000208:notes:37]
| (In millions) |  | September 30, 2020 |  | December 31, 2019 |
| Tax increment financing debt |  | 17.6 |  |  | 18.7 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | — |  |  | 19.0 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.8 |  |  | 2.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 94.3 |  |  | $ | 115.0 |  |
| Less: current maturities |  | (2.4) |  |  | (21.9) |  |
| Long-term debt |  | $ | 91.9 |  |  | $ | 93.1 |  |

[0000038725-20-000208:notes:38]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2020 matures as follows:

[0000038725-20-000208:notes:39]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 94.4 |  |  | $ | 2.4 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 1.4 |  |  | $ | 86.6 |  |

[0000038725-20-000208:notes:40]
Prudential Agreement

[0000038725-20-000208:notes:41]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million.  As of September 30, 2020, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-20-000208:notes:42]
Project Bonds

[0000038725-20-000208:notes:43]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-20-000208:notes:44]
New York Life Agreement

[0000038725-20-000208:notes:45]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2020, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-20-000208:notes:46]
Credit Agreement

[0000038725-20-000208:notes:47]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-20-000208:notes:48]
As of September 30, 2020, the Company had no outstanding borrowings, $4.3 million in letters of credit outstanding, and $295.7 million of available capacity under the Credit Agreement.

[0000038725-20-000208:notes:49]
Covenants

[0000038725-20-000208:notes:50]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of September 30, 2020.


## us-gaap:EarningsPerShareTextBlock

[0000038725-20-000208:notes:51]
[same as prior period, unchanged from 0000038725-20-000179:notes:54]

[0000038725-20-000208:notes:52]
[same as prior period, unchanged from 0000038725-20-000179:notes:55]

[0000038725-20-000208:notes:53]
[same as prior period, unchanged from 0000038725-20-000179:notes:56]

[0000038725-20-000208:notes:54]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions, except per share amounts) | September 30, 2020 |  | September 30, 2019 |  | September 30, 2020 |  | September 30, 2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 38.4 |  |  | $ | 33.9 |  |  | $ | 73.7 |  |  | $ | 75.7 |  |
| Less: Earnings allocated to participating securities | 0.3 |  |  | 0.2 |  |  | 0.5 |  |  | 0.5 |  |
| Net income available to common shareholders | $ | 38.1 |  |  | $ | 33.7 |  |  | $ | 73.2 |  |  | $ | 75.2 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.2 |  |  | 46.4 |  |  | 46.2 |  |  | 46.3 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.4 |  |  | 0.3 |  |  | 0.4 |  |  | 0.4 |  |
| Diluted weighted average common shares outstanding | 46.6 |  |  | 46.7 |  |  | 46.6 |  |  | 46.7 |  |
| Basic earnings per share | $ | 0.82 |  |  | $ | 0.73 |  |  | $ | 1.58 |  |  | $ | 1.62 |  |
| Diluted earnings per share | $ | 0.82 |  |  | $ | 0.72 |  |  | $ | 1.57 |  |  | $ | 1.61 |  |

[0000038725-20-000208:notes:55]
There were 0.3 million and 0.3 million stock options outstanding for the third quarters ended September 30, 2020 and September 30, 2019, and 0.4 million and 0.3 million stock options outstanding for the nine months ended September 30, 2020 and September 30, 2019 respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-20-000208:notes:56]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the third quarters ended September 30, 2020 and September 30, 2019:

[0000038725-20-000208:notes:57]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of June 30, 2020 | $ | 4,618 |  |  | $ | 278,175 |  |  | $ | 715,621 |  |  | $ | (48,657) |  |  | $ | (175,893) |  |  | $ | 1,647 |  |  | $ | 775,511 |  |  | $ | (262) |  |
| Net income |  |  |  |  | 38,372 |  |  |  |  |  |  | 178 |  |  | 38,550 |  |  | 25 |  |
| Dividends on common stock ($0.155/share) |  |  |  |  | (7,195) |  |  |  |  |  |  |  |  | (7,195) |  |  |  |
| Common stock issued | 6 |  |  | 1,488 |  |  |  |  |  |  |  |  |  |  | 1,494 |  |  |  |
| Common stock repurchased | (3) |  |  |  |  | (1,364) |  |  |  |  |  |  |  |  | (1,367) |  |  |  |
| Share-based compensation | (1) |  |  | 1,298 |  |  |  |  |  |  |  |  |  |  | 1,297 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |  |  |
| Purchase of redeemable noncontrolling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 3,330 |  |  | 48 |  |  | 3,378 |  |  | (14) |  |
| Pension liability, net of tax |  |  |  |  |  |  | 774 |  |  |  |  |  |  | 774 |  |  |  |
| Balance as of September 30, 2020 | $ | 4,620 |  |  | $ | 280,961 |  |  | $ | 745,434 |  |  | $ | (47,883) |  |  | $ | (172,563) |  |  | $ | 1,873 |  |  | $ | 812,442 |  |  | $ | (251) |  |

[0000038725-20-000208:notes:58]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of June 30, 2019 | $ | 4,632 |  |  | $ | 264,533 |  |  | $ | 673,493 |  |  | $ | (47,568) |  |  | $ | (135,902) |  |  | $ | 1,714 |  |  | $ | 760,902 |  |  | $ | (210) |  |
| Net income |  |  |  |  | 33,907 |  |  |  |  |  |  | 199 |  |  | 34,106 |  |  | (31) |  |
| Dividends on common stock ($0.145/share) |  |  |  |  | (6,767) |  |  |  |  |  |  |  |  | (6,767) |  |  |  |
| Common stock issued | 5 |  |  | 831 |  |  |  |  |  |  |  |  |  |  | 836 |  |  |  |
| Common stock repurchased | (1) |  |  |  |  | (757) |  |  |  |  |  |  |  |  | (758) |  |  |  |
| Share-based compensation | — |  |  | 1,935 |  |  |  |  |  |  |  |  |  |  | 1,935 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |  |  |
| Purchase of redeemable noncontrolling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | (2) |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (13,622) |  |  | (51) |  |  | (13,673) |  |  | 14 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 475 |  |  |  |  |  |  | 475 |  |  |  |
| Balance as of September 30, 2019 | $ | 4,636 |  |  | $ | 267,299 |  |  | $ | 699,876 |  |  | $ | (47,093) |  |  | $ | (149,524) |  |  | $ | 1,862 |  |  | $ | 777,056 |  |  | $ | (229) |  |

[0000038725-20-000208:notes:59]
The schedules below set forth equity changes in the nine months ended September 30, 2020 and September 30, 2019:

[0000038725-20-000208:notes:60]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2019 | $ | 4,639 |  |  | $ | 269,656 |  |  | $ | 712,460 |  |  | $ | (50,089) |  |  | $ | (140,121) |  |  | $ | 2,124 |  |  | $ | 798,669 |  |  | $ | (236) |  |
| Net Income |  |  |  |  | 73,666 |  |  |  |  |  |  | 534 |  |  | 74,200 |  |  | (31) |  |
| Dividends on common stock ($0.465/share) |  |  |  |  | (21,641) |  |  |  |  |  |  |  |  | (21,641) |  |  |  |
| Common stock issued | 10 |  |  | 3,004 |  |  |  |  |  |  |  |  |  |  | 3,014 |  |  |  |
| Common stock repurchased | (40) |  |  |  |  | (19,051) |  |  |  |  |  |  |  |  | (19,091) |  |  |  |
| Share-based compensation | 11 |  |  | 8,301 |  |  |  |  |  |  |  |  |  |  | 8,312 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (830) |  |  | (830) |  |  |  |
| Purchase of redeemable non-controlling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (32,442) |  |  | 45 |  |  | (32,397) |  |  | 16 |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 2,206 |  |  |  |  |  |  | 2,206 |  |  |  |
| Balance as of September 30, 2020 | $ | 4,620 |  |  | $ | 280,961 |  |  | $ | 745,434 |  |  | $ | (47,883) |  |  | $ | (172,563) |  |  | $ | 1,873 |  |  | $ | 812,442 |  |  | $ | (251) |  |

[0000038725-20-000208:notes:61]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2018 | $ | 4,632 |  |  | $ | 257,535 |  |  | $ | 654,724 |  |  | $ | (48,585) |  |  | $ | (134,434) |  |  | $ | 1,955 |  |  | $ | 735,827 |  |  | $ | 518 |  |
| Net Income |  |  |  |  | 75,708 |  |  |  |  |  |  | 620 |  |  | 76,328 |  |  | (314) |  |
| Dividends on common stock ($0.435/share) |  |  |  |  | (20,277) |  |  |  |  |  |  |  |  | (20,277) |  |  |  |
| Common stock issued | 12 |  |  | 2,319 |  |  |  |  |  |  |  |  |  |  | 2,331 |  |  |  |
| Common stock repurchased | (22) |  |  |  |  | (10,279) |  |  |  |  |  |  |  |  | (10,301) |  |  |  |
| Share-based compensation | 14 |  |  | 7,445 |  |  |  |  |  |  |  |  |  |  | 7,459 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (642) |  |  | (642) |  |  |  |
| Purchase of redeemable non-controlling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | (487) |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (15,090) |  |  | (71) |  |  | (15,161) |  |  | 54 |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 1,492 |  |  |  |  |  |  | 1,492 |  |  |  |
| Balance as of September 30, 2019 | $ | 4,636 |  |  | $ | 267,299 |  |  | $ | 699,876 |  |  | $ | (47,093) |  |  | $ | (149,524) |  |  | $ | 1,862 |  |  | $ | 777,056 |  |  | $ | (229) |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-20-000208:notes:62]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the nine months ended September 30, 2020 and September 30, 2019, are summarized below:

[0000038725-20-000208:notes:63]
| (In millions) |  |  |  |  |  |
| For the nine months ended September 30, 2020: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2019 | $ | (140.2) |  |  | $ | (50.0) |  |  | $ | (190.2) |  |
| Other comprehensive income/(loss) before reclassifications | (32.4) |  |  | — |  |  | (32.4) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 2.2 |  |  | 2.2 |  |
| Net other comprehensive income/(loss) | (32.4) |  |  | 2.2 |  |  | (30.2) |  |
| Balance as of September 30, 2020 | $ | (172.6) |  |  | $ | (47.8) |  |  | $ | (220.4) |  |
| For the nine months ended September 30, 2019: |  |  |  |  |  |
| Balance as of December 31, 2018 | $ | (134.5) |  |  | $ | (48.5) |  |  | $ | (183.0) |  |
| Other comprehensive income/(loss) before reclassifications | (15.1) |  |  | — |  |  | (15.1) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.5 |  |  | 1.5 |  |
| Net other comprehensive income/(loss) | (15.1) |  |  | 1.5 |  |  | (13.6) |  |
| Balance as of September 30, 2019 | $ | (149.6) |  |  | $ | (47.0) |  |  | $ | (196.6) |  |

[0000038725-20-000208:notes:64]
[same as prior period, unchanged from 0000038725-20-000179:notes:67]

[0000038725-20-000208:notes:65]
(2) Net of tax expense of $0.6 million and $0.4 million for the nine months ended September 30, 2020 and September 30, 2019, respectively.

[0000038725-20-000208:notes:66]
[same as prior period, unchanged from 0000038725-20-000179:notes:69]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-20-000208:notes:67]
[same as prior period, unchanged from 0000038725-20-000179:notes:70]

[0000038725-20-000208:notes:68]
[same as prior period, unchanged from 0000038725-20-000179:notes:71]

[0000038725-20-000208:notes:69]
[same as prior period, unchanged from 0000038725-20-000179:notes:72]

[0000038725-20-000208:notes:70]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions) | September 30, 2020 |  | September 30, 2019 |  | September 30, 2020 |  | September 30, 2019 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 93.4 |  |  | $ | 94.9 |  |  | $ | 245.1 |  |  | $ | 284.8 |  |
| Latin America | 30.1 |  |  | 30.6 |  |  | 82.5 |  |  | 90.5 |  |
| Europe, Middle East & Africa | 41.8 |  |  | 40.8 |  |  | 115.5 |  |  | 117.5 |  |
| Asia Pacific | 19.5 |  |  | 17.0 |  |  | 53.0 |  |  | 57.9 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 18.1 |  |  | 16.5 |  |  | 49.3 |  |  | 42.5 |  |
| Total sales | 202.9 |  |  | 199.8 |  |  | 545.4 |  |  | 593.2 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 98.0 |  |  | 87.0 |  |  | 250.5 |  |  | 227.4 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 98.0 |  |  | 87.0 |  |  | 250.5 |  |  | 227.4 |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 46.4 |  |  | 48.3 |  |  | 119.0 |  |  | 129.3 |  |
| All other | 22.0 |  |  | 29.8 |  |  | 60.6 |  |  | 87.1 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 68.4 |  |  | 78.1 |  |  | 179.6 |  |  | 216.4 |  |
| Intersegment Eliminations/Other | (18.1) |  |  | (16.5) |  |  | (49.3) |  |  | (42.5) |  |
| Consolidated | $ | 351.2 |  |  | $ | 348.4 |  |  | $ | 926.2 |  |  | $ | 994.5 |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2020 |  | September 30, 2019 |  | September 30, 2020 |  | September 30, 2019 |
|  | Operating income/(loss) |
| Water Systems | $ | 36.6 |  |  | $ | 28.4 |  |  | $ | 84.1 |  |  | $ | 78.5 |  |
| Distribution | 6.4 |  |  | 5.9 |  |  | 10.9 |  |  | 6.1 |  |
| Fueling Systems | 18.9 |  |  | 21.6 |  |  | 44.5 |  |  | 55.6 |  |
| Intersegment Eliminations/Other | (13.5) |  |  | (13.2) |  |  | (43.4) |  |  | (41.7) |  |
| Consolidated | $ | 48.4 |  |  | $ | 42.7 |  |  | $ | 96.1 |  |  | $ | 98.5 |  |

[0000038725-20-000208:notes:71]
|  | September 30, 2020 |  | December 31, 2019 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 628.6 |  |  | $ | 658.3 |  |  |  |  |  |
| Distribution | 195.8 |  |  | 180.2 |  |  |  |  |  |
| Fueling Systems | 268.1 |  |  | 283.8 |  |  |  |  |  |
| Other | 108.9 |  |  | 72.4 |  |  |  |  |  |
| Consolidated | $ | 1,201.4 |  |  | $ | 1,194.7 |  |  |  |  |  |

[0000038725-20-000208:notes:72]
[same as prior period, unchanged from 0000038725-20-000179:notes:75]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-20-000208:notes:73]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. The subject-matter expert has issued their preliminary report, which indicates that total damages incurred by Esso amounted to approximately 12 million euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company has retained experts to demonstrate that its products did not cause the damage, and it has until January 2021 to issue its response to the expert’s preliminary report for each station. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s results of operations.

[0000038725-20-000208:notes:74]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-20-000208:notes:75]
At September 30, 2020, the Company had $8.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-20-000208:notes:76]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-20-000208:notes:77]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2020, are as follows:

[0000038725-20-000208:notes:78]
| (In millions) |  |  |
| Balance as of December 31, 2019 |  | $ | 9.1 |  |
| Accruals related to product warranties |  | 6.9 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (6.7) |  |
| Balance as of September 30, 2020 |  | $ | 9.3 |  |

[0000038725-20-000208:notes:79]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. These financing leases are immaterial to the Company.

[0000038725-20-000208:notes:80]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the information available as of the adoption of ASU 2016-02 or at the inception of any new leases entered into thereafter when determining the present value of future lease payments.

[0000038725-20-000208:notes:81]
Some of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.

[0000038725-20-000208:notes:82]
The components of the Company’s operating lease portfolio as of the third quarter and nine months ended September 30, 2020 are as follows:

[0000038725-20-000208:notes:83]
| Lease Cost (in millions): | Third Quarter Ended |  | Nine Months Ended |
| Operating lease cost | $ | 3.1 |  |  | $ | 8.3 |  |
| Short-term lease cost | 0.3 |  |  | 0.5 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 3.4 years |
| Weighted-average discount rate |  |  | 3.6 | % |

[0000038725-20-000208:notes:84]
As of September 30, 2020, the Company has approximately $2.3 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.

[0000038725-20-000208:notes:85]
The minimum rental payments for non-cancellable operating leases as of September 30, 2020, are as follows:

[0000038725-20-000208:notes:86]
| (In millions) | 2020 | 2021 | 2022 | 2023 | 2024 | Thereafter |
| Future Minimum Rental Payments | $ | 2.9 |  | $ | 9.1 |  | $ | 5.9 |  | $ | 3.9 |  | $ | 1.8 |  | $ | 2.6 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-20-000208:notes:87]
[same as prior period, unchanged from 0000038725-20-000179:notes:88]

[0000038725-20-000208:notes:88]
[same as prior period, unchanged from 0000038725-20-000179:notes:89]

[0000038725-20-000208:notes:89]
[same as prior period, unchanged from 0000038725-20-000179:notes:90]

[0000038725-20-000208:notes:90]
[same as prior period, unchanged from 0000038725-20-000179:notes:91]

[0000038725-20-000208:notes:91]
[same as prior period, unchanged from 0000038725-20-000179:notes:92]

[0000038725-20-000208:notes:92]
[same as prior period, unchanged from 0000038725-20-000179:notes:93]

[0000038725-20-000208:notes:93]
[same as prior period, unchanged from 0000038725-20-000179:notes:94]

[0000038725-20-000208:notes:94]
[same as prior period, unchanged from 0000038725-20-000179:notes:95]

[0000038725-20-000208:notes:95]
[same as prior period, unchanged from 0000038725-20-000179:notes:96]

[0000038725-20-000208:notes:96]
[same as prior period, unchanged from 0000038725-20-000179:notes:97]

[0000038725-20-000208:notes:97]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the nine months ended September 30, 2020 and September 30, 2019 are as follows:

[0000038725-20-000208:notes:98]
|  |  | September 30, 2020 |  | September 30, 2019 |
| Risk-free interest rate |  | 1.39 | % |  | 2.53 | % |
| Dividend yield |  | 1.04 | % |  | 1.05 | % |
| Volatility factor |  | 29.45 | % |  | 29.38 | % |
| Expected term |  | 5.5 years |  | 5.5 years |

[0000038725-20-000208:notes:99]
A summary of the Company’s outstanding stock option activity and related information for the nine months ended September 30, 2020 is as follows:

[0000038725-20-000208:notes:100]
| (Shares in thousands) |  | September 30, 2020 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,262 |  |  | $ | 37.99 |  |
| Granted |  | 214 |  |  | 59.71 |  |
| Exercised |  | (96) |  |  | 31.24 |  |
| Forfeited |  | (24) |  |  | 52.58 |  |
| Outstanding at end of period |  | 1,356 |  |  | $ | 41.65 |  |
| Expected to vest after applying forfeiture rate |  | 1,355 |  |  | $ | 41.63 |  |
| Vested and exercisable at end of period |  | 905 |  |  | $ | 36.13 |  |

[0000038725-20-000208:notes:101]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of September 30, 2020 is as follows:

[0000038725-20-000208:notes:102]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.69 years |  | $ | 23,485 |  |
| Expected to vest after applying forfeiture rate |  | 5.69 years |  | $ | 23,478 |  |
| Vested and exercisable at end of period |  | 4.33 years |  | $ | 20,558 |  |

[0000038725-20-000208:notes:103]
The total intrinsic value of options exercised during the nine months ended September 30, 2020 and September 30, 2019 was $2.4 million and $3.8 million, respectively.

[0000038725-20-000208:notes:104]
As of September 30, 2020, there was $1.1 million of total unrecognized compensation cost related to non-vested stock options granted under the stock plans.  That cost is expected to be recognized over a weighted-average period of 1.78 years.

[0000038725-20-000208:notes:105]
[same as prior period, unchanged from 0000038725-20-000179:notes:106]

[0000038725-20-000208:notes:106]
A summary of the Company’s restricted stock/stock unit award activity and related information for the nine months ended September 30, 2020 is as follows:

[0000038725-20-000208:notes:107]
| (Shares in thousands) |  | September 30, 2020 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 463 |  |  | $ | 42.36 |  |
| Awarded |  | 118 |  |  | 59.27 |  |
| Vested |  | (136) |  |  | 34.30 |  |
| Forfeited |  | (35) |  |  | 49.43 |  |
| Non-vested at end of period |  | 410 |  |  | $ | 49.31 |  |

[0000038725-20-000208:notes:108]
As of September 30, 2020, there was $9.0 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the stock plans.  That cost is expected to be recognized over a weighted-average period of 1.33 years.
