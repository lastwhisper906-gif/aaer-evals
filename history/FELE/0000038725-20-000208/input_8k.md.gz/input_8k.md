# FELE 8-K — 0000038725-20-000206 filed 2020-10-27

## item codes, every 8-K on or before 2020-10-30

- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2020-10-30

- none on or before 2020-10-30

## item 2.02 — earnings release, exhibit 99.1

[0000038725-20-000206:8k_2_02:1]
EX-99.1
2
a202010278-kexhibit991.htm
EX-99.1

[0000038725-20-000206:8k_2_02:2]
Document

[0000038725-20-000206:8k_2_02:3]
Exhibit 99.1

[0000038725-20-000206:8k_2_02:4]
For Immediate Release

[0000038725-20-000206:8k_2_02:5]
For Further Information

[0000038725-20-000206:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-20-000206:8k_2_02:7]
260-824-2900

[0000038725-20-000206:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS THIRD

[0000038725-20-000206:8k_2_02:9]
QUARTER 2020 SALES AND EARNINGS

[0000038725-20-000206:8k_2_02:10]
Fort Wayne, IN – October 27, 2020 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported third quarter 2020 GAAP fully diluted earnings per share (EPS) of $0.82, versus a GAAP fully diluted EPS in the third quarter 2019 of $0.72.  Third quarter 2020 sales were $351.2 million, compared to 2019 third quarter sales of $348.4 million.  Third quarter EPS before the impact of restructuring expenses was $0.83 compared to 2019 third quarter EPS before restructuring of $0.73 (see table below for a reconciliation of GAAP EPS to EPS before restructuring).

[0000038725-20-000206:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-20-000206:8k_2_02:12]
“The third quarter earnings were a record for any quarter in our Company’s history.  Our earnings per share before restructuring expense were $0.83 and grew by 14 percent from the third quarter last year.  Our 2020 cash flow performance is also a record through three quarters as we achieved free cash flow as a percent of net income of 160 percent compared to approximately 100 percent for the same time last year.  Our Water businesses outside the U.S and Canada grew organically by about 15 percent in the quarter, and our U.S and Canada water business grew organically by about 12 percent when you exclude large dewatering pumps that are often purchased for rental fleets.  Our distribution business grew by 13 percent organically helped by more favorable weather conditions in much of the United States.  Fueling Systems sales declined 12 percent in the third quarter versus third quarter 2019 but improved sequentially from being down 28 percent in the second quarter. The ongoing uncertainty of the global pandemic has slowed the construction of new filling stations.  Overall, I’m pleased with how our Company and my 5,500 colleagues are dealing with the current business environment in light of the pandemic and we are optimistic as we wind up 2020 and look forward to 2021.”

[0000038725-20-000206:8k_2_02:13]
Key Performance Indicators:

[0000038725-20-000206:8k_2_02:14]
| Earnings Before and After Restructuring |  | For the Third Quarter |  |  |  |  |  |  |
| (in millions) |  | 2020 | 2019 | Change |  |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 38.4 |  | $ | 33.9 |  | 13 | % |  |  |  |  |
| Allocated Earnings |  | $ | (0.3) |  | $ | (0.2) |  |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 38.1 |  | $ | 33.7 |  | 13 | % |  |  |  |  |
| Restructuring (before tax): |  | $ | 0.4 |  | $ | 0.4 |  |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 0.3 |  | $ | 0.3 |  |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 38.4 |  | $ | 34.0 |  | 13 | % |  |  |  |  |
| Earnings Per Share |  | For the Third Quarter |  |  |  |  |  |  |
| Before and After Restructuring |  | 2020 | 2019 | Change |  |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.6 |  | 46.7 |  | — | % |  |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.82 |  | $ | 0.72 |  | 14 | % |  |  |  |  |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | 0.01 |  |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.83 |  | $ | 0.73 |  | 14 | % |  |  |  |  |

[0000038725-20-000206:8k_2_02:15]
|  | Net Sales |  |  |  |  |  |  |  |  |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q3 2019 | $ | 111.4 |  | $ | 30.6 |  | $ | 40.8 |  | $ | 17.0 |  | $ | 199.8 |  | $ | 78.1 |  | $ | 87.0 |  | $ | (16.5) |  | $ | 348.4 |  |
| Q3 2020 | $ | 111.5 |  | $ | 30.1 |  | $ | 41.8 |  | $ | 19.5 |  | $ | 202.9 |  | $ | 68.4 |  | $ | 98.0 |  | $ | (18.1) |  | $ | 351.2 |  |
| Change | $ | 0.1 |  | $ | (0.5) |  | $ | 1.0 |  | $ | 2.5 |  | $ | 3.1 |  | $ | (9.7) |  | $ | 11.0 |  | $ | (1.6) |  | $ | 2.8 |  |
| % Change | — | % | (2) | % | 2 | % | 15 | % | 2 | % | (12) | % | 13 | % |  | 1 | % |
| Foreign currency translation | $ | (0.1) |  | $ | (8.3) |  | $ | (2.6) |  | $ | 0.1 |  | $ | (10.9) |  | $ | 0.5 |  | $ | — |  |  |  |
| % Change | — | % | (27) | % | (6) | % | 1 | % | (5) | % | 1 | % | — | % |  |  |
| Acquisitions | $ | 1.5 |  | $ | — |  | $ | — |  | $ | — |  | $ | 1.5 |  | $ | — |  | $ | — |  |  |  |
| Volume/Price | $ | (1.3) |  | $ | 7.8 |  | $ | 3.6 |  | $ | 2.4 |  | $ | 12.5 |  | $ | (10.2) |  | $ | 11.0 |  |  |  |
| % Change | (1) | % | 25 | % | 9 | % | 14 | % | 6 | % | (13) | % | 13 | % |  |  |

[0000038725-20-000206:8k_2_02:16]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2020 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 36.6 |  | $ | 18.9 |  | $ | 6.4 |  | $ | (13.5) |  | $ | 48.4 |  |
| % Operating Income To Net Sales | 18.0 | % | 27.6 | % | 6.5 | % |  | 13.8 | % |
| Restructuring | $ | 0.4 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.4 |  |
| Operating Income/(Loss) Before Restructuring | $ | 37.0 |  | $ | 18.9 |  | $ | 6.4 |  | $ | (13.5) |  | $ | 48.8 |  |
| % Operating Income to Net Sales Before Restructuring | 18.2 | % | 27.6 | % | 6.5 | % |  | 13.9 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2019 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 28.4 |  | $ | 21.6 |  | $ | 5.9 |  | $ | (13.2) |  | $ | 42.7 |  |
| % Operating Income To Net Sales | 14.2 | % | 27.7 | % | 6.8 | % |  | 12.3 | % |
| Restructuring | $ | 0.4 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.4 |  |
| Operating Income/(Loss) Before Restructuring | $ | 28.8 |  | $ | 21.6 |  | $ | 5.9 |  | $ | (13.2) |  | $ | 43.1 |  |
| % Operating Income to Net Sales Before Restructuring | 14.4 | % | 27.7 | % | 6.8 | % |  | 12.4 | % |

[0000038725-20-000206:8k_2_02:17]
Water Systems

[0000038725-20-000206:8k_2_02:18]
Water Systems sales in the U.S. and Canada were flat compared to the third quarter 2019.  Sales of groundwater pumping equipment increased by about 17 percent and sales of surface pumping equipment increased by about 8 percent versus the third quarter 2019, due to strong end market demand.  These increases were offset by lower sales of dewatering equipment, which were down by about 54 percent, due to lower sales in the rental channel.

[0000038725-20-000206:8k_2_02:19]
Water Systems sales in markets outside the U.S. and Canada increased by 3 percent overall.  Foreign currency translation decreased sales by 12 percent.  Outside the U.S. and Canada, Water Systems organic sales increased by about 15 percent, primarily driven by higher sales in all three major geographic regions: Latin America, Europe, the Middle East and Africa, and the Asia Pacific markets.

[0000038725-20-000206:8k_2_02:20]
Water Systems operating income was $36.6 million in the third quarter 2020, compared to $28.4 million in the third quarter 2019 driven by price realization, product sales mix and cost management.

[0000038725-20-000206:8k_2_02:21]
Fueling Systems

[0000038725-20-000206:8k_2_02:22]
Fueling Systems sales in the U.S. and Canada decreased by about 5 percent compared to the third quarter 2019.  The decrease was in all product lines and due to declining demand for new filling stations.  Outside the U.S. and Canada, Fueling Systems revenues declined by about 27 percent, driven by lower sales in Asia Pacific, primarily China.

[0000038725-20-000206:8k_2_02:23]
In the third quarter, outside of China, global Fueling Systems sales were down about 7 percent, an improvement from being down about 20 percent in the second quarter. In China, Fueling Systems sales improved sequentially but continue to be less than half of last year’s sales.

[0000038725-20-000206:8k_2_02:24]
Fueling Systems operating income was $18.9 million in the third quarter of 2020, compared to $21.6 million in the third quarter of 2019 driven almost entirely by lower revenues.

[0000038725-20-000206:8k_2_02:25]
Distribution

[0000038725-20-000206:8k_2_02:26]
Distribution sales were a record at $98.0 million in the third quarter 2020, versus third quarter 2019 sales of $87.0 million.  The Distribution segment organic sales increased 13 percent compared to the third quarter of 2019.  Favorable weather conditions versus the third quarter last year contributed to the revenue growth.

[0000038725-20-000206:8k_2_02:27]
The Distribution segment operating income was $6.4 million in the third quarter of 2020, compared to $5.9 million in the third quarter of 2019.

[0000038725-20-000206:8k_2_02:28]
Overall

[0000038725-20-000206:8k_2_02:29]
The Company’s consolidated gross profit was $124.3 million for the third quarter of 2020, an increase from the third quarter of 2019 gross profit of $117.6 million.  The gross profit as a percentage of net sales was 35.4 percent in the third quarter of 2020 versus 33.8 percent in the third quarter of 2019 and improved primarily due to better price realization and product sales mix.

[0000038725-20-000206:8k_2_02:30]
Selling, general, and administrative (SG&A) expenses were $75.5 million in the third quarter of 2020 compared to $74.5 million in the third quarter of 2019. SG&A expenses were higher primarily due to variable compensation expense partially offset by foreign currency translation.

[0000038725-20-000206:8k_2_02:31]
Liquidity

[0000038725-20-000206:8k_2_02:32]
The Company ended the third quarter of 2020 with a cash balance of $114.5 million and generated $118.5 million of free cash flow from operations during the first nine months of 2020, versus free cash flow in the first nine months of 2019 of $75.5 million and had total incremental borrowing capacity of $532 million at September 30, 2020.  Free Cash Flow is Net Cash Flows from Operating Activities, less net additions to property, plant, and equipment.

[0000038725-20-000206:8k_2_02:33]
Effects of the Global Pandemic

[0000038725-20-000206:8k_2_02:34]
The top priority of the Company is the health and welfare of its employees and partners around the world.  In response to the health risks posed by the Global Pandemic, the Company implemented and has been following the recommended hygiene and social distancing practices promulgated by the United States Centers for Disease Control and the World Health Organization.

[0000038725-20-000206:8k_2_02:35]
The Company’s products and services are generally viewed as essential in most jurisdictions in which the Company operates.  All the Company’s global manufacturing and distribution operations are operating with limited disruption.

[0000038725-20-000206:8k_2_02:36]
The primary impacts of the Global Pandemic on the Company’s end markets remain consistent with prior disclosures.  Large dewatering equipment sales in the Water Systems segment continue to be depressed and the deferral or cancellation of the construction of new filling stations in the Fueling Systems segment continues.  Additionally, the strengthening of the U.S. dollar versus most international currencies has resulted in lower translations of both Net Sales and earnings from many of the Company’s businesses outside the U.S., despite some recent dollar weakening.  The Company’s financial results are also impacted negatively by continuing government mandated closures and related customer behaviors.

[0000038725-20-000206:8k_2_02:37]
Commenting on the outlook for 2020 and the Franklin Electric Sustainability Report, Mr. Sengstack said:

[0000038725-20-000206:8k_2_02:38]
“As a result of our record third quarter financial performance, we are raising our full year guidance for both earnings per share and free cash flow.  We now believe our full year 2020 earnings per share before restructuring expenses will be between $2.10 and $2.15.  Except for large dewatering products, we expect the Water Systems and Distribution segments to continue to have solid top line performance.  In Fueling Systems, we expect continued weakness in filling station builds and upgrades globally.  We expect our free cash flow as a percent of net income to be over 170 percent for the full year 2020.

[0000038725-20-000206:8k_2_02:39]
Finally, I would like to call your attention to the 2020 Franklin Electric Sustainability Report that will be issued today and available for download on our website.  While this report is our first public disclosure of some important environmental and social measurements, principles of sustainability are the foundational tenets of Franklin Electric’s culture and have long contributed to our success: a commitment to safety, ethical compliance with established policies, care for the well-being of our employees, and a history of innovation, environmental protection, continuous improvement and lean manufacturing practices.”

[0000038725-20-000206:8k_2_02:40]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The third quarter 2020 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-20-000206:8k_2_02:41]
https://edge.media-server.com/mmc/p/x8hg92en

[0000038725-20-000206:8k_2_02:42]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls. The conference ID is: 3087669.

[0000038725-20-000206:8k_2_02:43]
A replay of the conference call will be available Tuesday, October 27, 2020 at 12:00 noon ET through noon ET on Tuesday, November 3, 2020, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls. The replay passcode is: 3087669.

[0000038725-20-000206:8k_2_02:44]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-20-000206:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |  |  |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |  |  |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |  |
|  | Third Quarter Ended |  |  |  |  | Nine Months Ended |  |  |
|  | September 30, 2020 |  | September 30, 2019 |  |  | September 30, 2020 |  | September 30, 2019 |
| Net sales | $ | 351,190 |  |  | $ | 348,416 |  |  |  | $ | 926,225 |  |  | $ | 994,471 |  |
| Cost of sales | 226,893 |  |  | 230,793 |  |  |  | 604,489 |  |  | 667,624 |  |
| Gross profit | 124,297 |  |  | 117,623 |  |  |  | 321,736 |  |  | 326,847 |  |
| Selling, general, and administrative expenses | 75,472 |  |  | 74,500 |  |  |  | 223,409 |  |  | 226,581 |  |
| Restructuring expense | 441 |  |  | 404 |  |  |  | 2,189 |  |  | 1,735 |  |
| Operating income | 48,384 |  |  | 42,719 |  |  |  | 96,138 |  |  | 98,531 |  |
| Interest expense | (1,130) |  |  | (2,037) |  |  |  | (3,496) |  |  | (6,674) |  |
| Other income/(expense), net | (463) |  |  | (250) |  |  |  | (1,062) |  |  | (303) |  |
| Foreign exchange income/(expense) | (140) |  |  | 2,082 |  |  |  | (84) |  |  | 2,166 |  |
| Income before income taxes | 46,651 |  |  | 42,514 |  |  |  | 91,496 |  |  | 93,720 |  |
| Income tax expense | 8,076 |  |  | 8,439 |  |  |  | 17,327 |  |  | 17,706 |  |
| Net income | $ | 38,575 |  |  | $ | 34,075 |  |  |  | $ | 74,169 |  |  | $ | 76,014 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (203) |  |  | (168) |  |  |  | (503) |  |  | (306) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 38,372 |  |  | $ | 33,907 |  |  |  | $ | 73,666 |  |  | $ | 75,708 |  |
| Income per share: |  |  |  |  |  |  |  |  |
| Basic | $ | 0.82 |  |  | $ | 0.73 |  |  |  | $ | 1.58 |  |  | $ | 1.62 |  |
| Diluted | $ | 0.82 |  |  | $ | 0.72 |  |  |  | $ | 1.57 |  |  | $ | 1.61 |  |

[0000038725-20-000206:8k_2_02:46]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |  |  |
| (Unaudited) |  |  |  |
| (In thousands) |  |  |  |
|  | September 30, 2020 |  | December 31, 2019 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 114,480 |  |  | $ | 64,405 |  |
| Receivables, net | 171,843 |  |  | 173,327 |  |
| Inventories | 289,292 |  |  | 300,246 |  |
| Other current assets | 26,924 |  |  | 29,466 |  |
| Total current assets | 602,539 |  |  | 567,444 |  |
| Property, plant, and equipment, net | 186,767 |  |  | 201,328 |  |
| Right-of-use asset, net | 24,716 |  |  | 27,621 |  |
| Goodwill and other assets | 387,420 |  |  | 398,350 |  |
| Total assets | $ | 1,201,442 |  |  | $ | 1,194,743 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 97,638 |  |  | $ | 82,593 |  |
| Accrued expenses and other current liabilities | 78,300 |  |  | 71,454 |  |
| Current lease liability | 9,540 |  |  | 9,838 |  |
| Current maturities of long-term debt and short-term borrowings | 2,388 |  |  | 21,879 |  |
| Total current liabilities | 187,866 |  |  | 185,764 |  |
| Long-term debt | 91,938 |  |  | 93,141 |  |
| Long-term lease liability | 15,178 |  |  | 17,785 |  |
| Income taxes payable non-current | 11,965 |  |  | 11,965 |  |
| Deferred income taxes | 25,165 |  |  | 27,598 |  |
| Employee benefit plans | 36,354 |  |  | 38,288 |  |
| Other long-term liabilities | 20,785 |  |  | 21,769 |  |
| Redeemable noncontrolling interest | (251) |  |  | (236) |  |
| Total equity | 812,442 |  |  | 798,669 |  |
| Total liabilities and equity | $ | 1,201,442 |  |  | $ | 1,194,743 |  |

[0000038725-20-000206:8k_2_02:47]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |  |  |
| (Unaudited) |  |  |  |
|  | Nine Months Ended |  |  |
| (In thousands) |  |  |  |
|  | September 30, 2020 |  | September 30, 2019 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 74,169 |  |  | $ | 76,014 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 26,917 |  |  | 27,705 |  |
| Non-cash lease expense | 8,478 |  |  | 7,640 |  |
| Share-based compensation | 8,312 |  |  | 7,459 |  |
| Other | (622) |  |  | (1,747) |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (5,147) |  |  | (27,170) |  |
| Inventory | 4,322 |  |  | (19,841) |  |
| Accounts payable and accrued expenses | 26,069 |  |  | 27,391 |  |
| Operating leases | (8,478) |  |  | (7,637) |  |
| Other | (312) |  |  | 411 |  |
| Net cash flows from operating activities | 133,708 |  |  | 90,225 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (15,239) |  |  | (15,591) |  |
| Proceeds from sale of property, plant, and equipment | 28 |  |  | 866 |  |
| Acquisitions and investments | (6,089) |  |  | (20,871) |  |
| Other investing activities | (74) |  |  | 8 |  |
| Net cash flows from investing activities | (21,374) |  |  | (35,588) |  |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (20,748) |  |  | (31,659) |  |
| Proceeds from issuance of common stock | 3,014 |  |  | 2,331 |  |
| Purchases of common stock | (19,091) |  |  | (10,301) |  |
| Dividends paid | (21,641) |  |  | (20,919) |  |
| Purchase of redeemable non-controlling shares |  |  | (487) |  |
| Net cash flows from financing activities | (58,466) |  |  | (61,035) |  |
| Effect of exchange rate changes on cash | (3,793) |  |  | (4,970) |  |
| Net change in cash and equivalents | 50,075 |  |  | (11,368) |  |
| Cash and equivalents at beginning of period | 64,405 |  |  | 59,173 |  |
| Cash and equivalents at end of period | $ | 114,480 |  |  | $ | 47,805 |  |
