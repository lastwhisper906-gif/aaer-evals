# FELE MD&A — 0000038725-20-000208


## mdna

[0000038725-20-000208:mdna:1]
[same as prior period, unchanged from 0000038725-20-000179:mdna:1]

[0000038725-20-000208:mdna:2]
Third Quarter 2020 vs. Third Quarter 2019

[0000038725-20-000208:mdna:3]
[same as prior period, unchanged from 0000038725-20-000179:mdna:3]

[0000038725-20-000208:mdna:4]
Sales in the third quarter of 2020 increased from the third quarter last year.  The sales increase was led by increases from volume and price, nearly offset by foreign currency translation. The impact on sales due to foreign currency translation was a reduction of about 3 percent. The Company's consolidated gross profit was $124.3 million for the third quarter of 2020, an increase of $6.7 million or about 6 percent from the prior year’s third quarter. Earnings per share in the third quarter of 2020 were up to the same period last year by about 14 percent.

[0000038725-20-000208:mdna:5]
[same as prior period, unchanged from 0000038725-20-000179:mdna:5]

[0000038725-20-000208:mdna:6]
The top priority of the Company is the health and welfare of its employees and partners around the world. In response to the health risks posed by the Global Pandemic, the Company implemented and has been following the recommended hygiene and social distancing practices promulgated by the United States Centers for Disease Control and the World Health Organization.

[0000038725-20-000208:mdna:7]
The Company’s products and services are generally viewed as essential in most jurisdictions in which the Company operates. All the Company’s global manufacturing and distribution operations are operating with limited disruption.

[0000038725-20-000208:mdna:8]
The primary impacts of the Global Pandemic on the Company’s end markets remain consistent with prior disclosures.  Large dewatering equipment sales in the Water Systems segment continue to be depressed and the deferral or cancellation of the construction of new filling stations in the Fueling Systems segment continues.  Additionally, the strengthening of the U.S. dollar versus most international currencies has resulted in lower translations of both Net Sales and earnings from many of the Company’s businesses outside the U.S., despite some recent dollar weakening.  The Company’s financial results are also impacted negatively by continuing government mandated closures and related customer behaviors.

[0000038725-20-000208:mdna:9]
[same as prior period, unchanged from 0000038725-20-000179:mdna:9]

[0000038725-20-000208:mdna:10]
[same as prior period, unchanged from 0000038725-20-000179:mdna:10]

[0000038725-20-000208:mdna:11]
Net sales in the third quarter of 2020 were $351.2 million, an increase of $2.8 million or about 1 percent compared to 2019 third quarter sales of $348.4 million.  Acquisition related sales were $1.5 million. Sales revenue decreased by $10.4 million or about 3 percent in the third quarter of 2020 due to foreign currency translation.

[0000038725-20-000208:mdna:12]
|  | Net Sales |
| (In millions) | Q3 2020 |  | Q3 2019 |  | 2020 v 2019 |
| Water Systems | $ | 202.9 |  |  | $ | 199.8 |  |  | $ | 3.1 |  |
| Fueling Systems | 68.4 |  |  | 78.1 |  |  | $ | (9.7) |  |
| Distribution | 98.0 |  |  | 87.0 |  |  | $ | 11.0 |  |
| Eliminations/Other | (18.1) |  |  | (16.5) |  |  | $ | (1.6) |  |
| Consolidated | $ | 351.2 |  |  | $ | 348.4 |  |  | $ | 2.8 |  |

[0000038725-20-000208:mdna:13]
[same as prior period, unchanged from 0000038725-20-000179:mdna:13]

[0000038725-20-000208:mdna:14]
Water Systems sales were $202.9 million in the third quarter 2020, an increase of $3.1 million versus the third quarter 2019 sales of $199.8 million. In the third quarter of 2020, sales from businesses acquired since the third quarter of 2019 were $1.5 million. Water Systems sales were reduced by $10.9 million or about 5 percent in the quarter due to foreign currency translation. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 6 percent compared to the third quarter 2019.

[0000038725-20-000208:mdna:15]
Water Systems sales in the U.S. and Canada were flat compared to the third quarter 2019.  Sales of groundwater pumping equipment increased by about 17 percent and sales of surface pumping equipment increased by about 8 percent versus the third quarter 2019, due to strong end market demand.  These increases were offset by lower sales of dewatering equipment, which were down by about 54 percent, due to lower sales in the rental channel.

[0000038725-20-000208:mdna:16]
Water Systems sales in markets outside the U.S. and Canada increased by 3 percent overall.  Foreign currency translation decreased sales by 12 percent.  Outside the U.S. and Canada, Water Systems organic sales increased by 15 percent, primarily

[0000038725-20-000208:mdna:17]
driven by higher sales in all three major geographic regions; Latin America, Europe, the Middle East and Africa, and the Asia Pacific markets.

[0000038725-20-000208:mdna:18]
[same as prior period, unchanged from 0000038725-20-000179:mdna:17]

[0000038725-20-000208:mdna:19]
Fueling Systems sales were $68.4 million in the third quarter 2020, a decrease of $9.7 million versus the third quarter 2019 sales of $78.1 million. In the third quarter of 2020, sales increased by $0.5 million or about 1 percent due to foreign currency translation. Fueling Systems organic sales decreased about 13 percent compared to the third quarter of 2019.

[0000038725-20-000208:mdna:20]
Fueling Systems sales in the U.S. and Canada decreased by about 5 percent compared to the third quarter 2019.  The decrease was in all product lines and due to declining demand for new filling stations.  Outside the U.S. and Canada, Fueling Systems revenues declined by about 27 percent, driven by lower sales in Asia Pacific, primarily China. China sales were about $6 million in the third quarter of 2020 compared to the third quarter of 2019 Fueling Systems China sales of about $12 million.

[0000038725-20-000208:mdna:21]
[same as prior period, unchanged from 0000038725-20-000179:mdna:20]

[0000038725-20-000208:mdna:22]
Distribution sales were $98.0 million in the third quarter 2020, versus third quarter 2019 sales of $87.0 million. The Distribution segment organic sales increased about 13 percent compared to the third quarter of 2019. Favorable weather conditions versus the third quarter last year contributed to the revenue growth.

[0000038725-20-000208:mdna:23]
[same as prior period, unchanged from 0000038725-20-000179:mdna:22]

[0000038725-20-000208:mdna:24]
Cost of sales as a percent of net sales for the third quarter of 2020 and 2019 was 64.6 percent and 66.2 percent, respectively. Correspondingly, the gross profit margin as a percent of net sales was 35.4 percent in the third quarter of 2020 compared to 33.8 percent in the third quarter of 2019. The Company's consolidated gross profit was $124.3 million for the third quarter of 2020, an increase of $6.7 million from the gross profit of $117.6 million in the third quarter of 2019. The gross profit increase was primarily due to better sales price realization and product sales mix.

[0000038725-20-000208:mdna:25]
[same as prior period, unchanged from 0000038725-20-000179:mdna:24]

[0000038725-20-000208:mdna:26]
Selling, general, and administrative (SG&A) expenses were $75.5 million in the third quarter of 2020 compared to $74.5 million in the third quarter of the prior year. SG&A expenses were higher primarily due to variable compensation expense partially offset by foreign currency translation.

[0000038725-20-000208:mdna:27]
[same as prior period, unchanged from 0000038725-20-000179:mdna:26]

[0000038725-20-000208:mdna:28]
Restructuring expenses for the third quarter of 2020 were $0.4 million, primarily in the Water segment and related to miscellaneous manufacturing realignment activities. Restructuring expenses for the third quarter of 2019 were also $0.4 million, primarily in the Water segment and related to miscellaneous manufacturing realignment activities.

[0000038725-20-000208:mdna:29]
[same as prior period, unchanged from 0000038725-20-000179:mdna:28]

[0000038725-20-000208:mdna:30]
Operating income was $48.4 million in the third quarter of 2020, up $5.7 million or 13 percent from $42.7 million in the third quarter of 2019.

[0000038725-20-000208:mdna:31]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2020 |  | Q3 2019 |  | 2020 v 2019 |
| Water Systems |  | $ | 36.6 |  |  | $ | 28.4 |  |  | $ | 8.2 |  |
| Fueling Systems |  | 18.9 |  |  | 21.6 |  |  | (2.7) |  |
| Distribution |  | 6.4 |  |  | 5.9 |  |  | 0.5 |  |
| Eliminations/Other |  | (13.5) |  |  | (13.2) |  |  | (0.3) |  |
| Consolidated |  | $ | 48.4 |  |  | $ | 42.7 |  |  | $ | 5.7 |  |

[0000038725-20-000208:mdna:32]
[same as prior period, unchanged from 0000038725-20-000179:mdna:31]

[0000038725-20-000208:mdna:33]
Water Systems operating income was $36.6 million in the third quarter 2020, up $8.2 million or about 29 percent compared to $28.4 million in the third quarter 2019. The third quarter of 2020 operating income margin was 18.0 percent versus 14.2 percent of net sales in the third quarter of 2019.  The increase in operating income and operating income margin was primarily driven by price realization, product sales mix and cost management.

[0000038725-20-000208:mdna:34]
[same as prior period, unchanged from 0000038725-20-000179:mdna:33]

[0000038725-20-000208:mdna:35]
Fueling Systems operating income was $18.9 million in the third quarter of 2020, down $2.7 million or about 13 percent compared to $21.6 million in the third quarter of 2019. The decrease in operating income was primarily due to lower sales revenues. The third quarter of 2020 operating income margin was 27.6 percent versus 27.7 percent of net sales in the third

[0000038725-20-000208:mdna:36]
quarter of 2019.

[0000038725-20-000208:mdna:37]
[same as prior period, unchanged from 0000038725-20-000179:mdna:35]

[0000038725-20-000208:mdna:38]
Distribution operating income was $6.4 million in the third quarter of 2020 and the third quarter operating income margin was 6.5 percent. Distribution operating income was $5.9 million in the third quarter of 2019 and the third quarter operating income margin was 6.8 percent. Distribution’s operating income was higher in the third quarter due to higher sales volumes. The decline in operating income margin was primarily due to unfavorable product sales mix and higher personnel costs.

[0000038725-20-000208:mdna:39]
[same as prior period, unchanged from 0000038725-20-000179:mdna:37]

[0000038725-20-000208:mdna:40]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the third quarter of 2020 compared to the third quarter of 2019 had no impact on operating income. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its customer. Unallocated general and administrative expenses were higher by $0.3 million or about 2 percent.

[0000038725-20-000208:mdna:41]
[same as prior period, unchanged from 0000038725-20-000179:mdna:39]

[0000038725-20-000208:mdna:42]
Interest expense for the third quarter of 2020 and 2019 was $1.1 million and $2.0 million, respectively.

[0000038725-20-000208:mdna:43]
[same as prior period, unchanged from 0000038725-20-000179:mdna:41]

[0000038725-20-000208:mdna:44]
Other income or expense was a loss of $0.5 million and $0.3 million in the third quarter of 2020 and 2019, respectively.

[0000038725-20-000208:mdna:45]
[same as prior period, unchanged from 0000038725-20-000179:mdna:43]

[0000038725-20-000208:mdna:46]
Foreign currency-based transactions produced a loss for the third quarter of 2020 of $0.1 million. Foreign currency-based transactions produced a gain for the third quarter of 2019 of $2.1 million, primarily due to a $2.1 million gain from the Argentinian Peso relative to the U.S. dollar.

[0000038725-20-000208:mdna:47]
[same as prior period, unchanged from 0000038725-20-000179:mdna:45]

[0000038725-20-000208:mdna:48]
The provision for income taxes in the third quarter of 2020 and 2019 was $8.1 million and $8.4 million, respectively. The effective tax rate for the third quarter of 2020 was about 17 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate for the third quarter of 2019 was about 20 percent and, before the impact of discrete events, was about 21 percent. The decrease in the effective tax rate was primarily a result of larger net favorable discrete events recorded in the third quarter of 2020 compared to the third quarter of 2019. The tax rate as a percentage of pre-tax earnings for the full year of 2020 is projected to be about 20 percent, compared to the full year 2019 tax rate of about 20 percent, both before discrete adjustments.

[0000038725-20-000208:mdna:49]
[same as prior period, unchanged from 0000038725-20-000179:mdna:47]

[0000038725-20-000208:mdna:50]
Net income for the third quarter of 2020 was $38.6 million compared to the prior year third quarter net income of $34.1 million.  Net income attributable to Franklin Electric Co., Inc. for the third quarter of 2020 was $38.4 million, or $0.82 per diluted share, compared to the prior year third quarter net income attributable to Franklin Electric Co., Inc. of $33.9 million or $0.72 per diluted share.

[0000038725-20-000208:mdna:51]
First Nine Months of 2020 vs. First Nine Months of 2019

[0000038725-20-000208:mdna:52]
[same as prior period, unchanged from 0000038725-20-000179:mdna:50]

[0000038725-20-000208:mdna:53]
Sales in the first nine months of 2020 were down from the same period last year.  The sales decrease was primarily from lower volumes, in part created by uncertainty and general disruptions around the Global Pandemic in the second quarter.  The impact of foreign currency translation decreased sales by about 3 percent. The Company's consolidated gross profit was $321.7 million for the first nine months of 2020, a decrease of $5.1 million or about 2 percent from the first nine months of 2019. Earnings in the first nine months of 2020 were down from the same period last year.

[0000038725-20-000208:mdna:54]
[same as prior period, unchanged from 0000038725-20-000179:mdna:52]

[0000038725-20-000208:mdna:55]
[same as prior period, unchanged from 0000038725-20-000179:mdna:53]

[0000038725-20-000208:mdna:56]
Net sales in the first nine months of 2020 were $926.2 million, a decrease of $68.3 million or about 7 percent compared to 2019 first nine months sales of $994.5 million.  The incremental impact of sales from acquired businesses was $8.7 million.  Sales revenue decreased by $30.7 million or 3 percent in the first nine months of 2020 due to foreign currency translation.

[0000038725-20-000208:mdna:57]
|  | Net Sales |
| (In millions) | YTD September 30, 2020 |  | YTD September 30, 2019 |  | 2020 v 2019 |
| Water Systems | $ | 545.4 |  |  | $ | 593.2 |  |  | $ | (47.8) |  |
| Fueling Systems | 179.6 |  |  | 216.4 |  |  | $ | (36.8) |  |
| Distribution | 250.5 |  |  | 227.4 |  |  | $ | 23.1 |  |
| Eliminations/Other | (49.3) |  |  | (42.5) |  |  | $ | (6.8) |  |
| Consolidated | $ | 926.2 |  |  | $ | 994.5 |  |  | $ | (68.3) |  |

[0000038725-20-000208:mdna:58]
[same as prior period, unchanged from 0000038725-20-000179:mdna:56]

[0000038725-20-000208:mdna:59]
Water Systems sales were $545.4 million in the first nine months 2020, a decrease of $47.8 million or about 8 percent versus the first nine months of 2019. The incremental impact of sales from acquired businesses was $8.7 million. Foreign currency translation changes decreased sales $30.2 million, or about 5 percent, compared to sales in the first nine months of 2019. The Water Systems sales change in the first nine months of 2020, excluding acquisitions and foreign currency translation, was a decrease of $26.3 million or about 4 percent.

[0000038725-20-000208:mdna:60]
Water Systems sales in the U.S. and Canada decreased by about 10 percent compared to the first nine months of 2019. The incremental impact of sales from acquired businesses was $8.7 million. Sales revenue decreased by $0.8 million in the first nine months of 2020 due to foreign currency translation. In the first nine months of 2020, sales of dewatering equipment decreased by about 60 percent due to lower sales in rental channels and substantial uncertainty in oil production end markets. Sales of groundwater pumping equipment increased by 9 percent versus the first nine months of 2019. Sales of other surface pumping equipment decreased by about 8 percent.

[0000038725-20-000208:mdna:61]
Water Systems sales in markets outside the U.S. and Canada decreased by about 6 percent compared to the first nine months of 2019. Sales revenue decreased by $29.4 million or about 11 percent in the first nine months of 2020 due to foreign currency translation. International Water Systems sales change in the first nine months of 2020, excluding foreign currency translation, was an increase of about 5 percent. International Water Systems sales growth in Latin America and EMENA were partially offset by lower sales in the Asia Pacific markets.

[0000038725-20-000208:mdna:62]
[same as prior period, unchanged from 0000038725-20-000179:mdna:60]

[0000038725-20-000208:mdna:63]
Fueling Systems sales were $179.6 million in the first nine months of 2020, a decrease of $36.8 million or about 17 percent from the first nine months of 2019. Foreign currency translation changes decreased sales $0.5 million or less than 1 percent compared to sales in the first nine months of 2019. The Fueling Systems sales change in the first nine months of 2020, excluding foreign currency translation, was a decrease of $36.3 million or about 17 percent.

[0000038725-20-000208:mdna:64]
Fueling Systems sales in the U.S. and Canada declined by about 8 percent during the first nine months of 2020. The decrease was in all product lines and due to declining demand for new filling stations. Internationally, Fueling Systems revenues declined by about 30 percent, driven by lower sales in Asia Pacific, primarily China and India.  China sales were about $14 million in the first nine months of 2020 compared to the first nine months of 2019 Fueling Systems China sales of about $34 million.

[0000038725-20-000208:mdna:65]
[same as prior period, unchanged from 0000038725-20-000179:mdna:63]

[0000038725-20-000208:mdna:66]
Distribution sales were $250.5 million in the first nine months of 2020, versus the first nine months of 2019 sales of $227.4 million. Distribution segment organic sales increased about 10 percent compared to the first nine months of 2019.  Favorable weather conditions versus the prior year contributed to the revenue growth.

[0000038725-20-000208:mdna:67]
[same as prior period, unchanged from 0000038725-20-000179:mdna:65]

[0000038725-20-000208:mdna:68]
Cost of sales as a percent of net sales for the first nine months of 2020 and 2019 was 65.3 percent and 67.1 percent, respectively. Correspondingly, the gross profit margin was 34.7 percent and 32.9 percent, respectively. The increase in gross profit margin was primarily driven by price realization, product sales mix and cost management. The Company's consolidated gross profit was $321.7 million for the first nine months of 2020, down $5.1 million from the gross profit of $326.8 million in the first nine months of 2019. The gross profit decrease was primarily due to lower sales in the Water and Fueling segments.

[0000038725-20-000208:mdna:69]
[same as prior period, unchanged from 0000038725-20-000179:mdna:67]

[0000038725-20-000208:mdna:70]
Selling, general, and administrative expenses were $223.4 million in the first nine months of 2020 and decreased by $3.2

[0000038725-20-000208:mdna:71]
million compared to $226.6 million in the first nine months of last year. SG&A expenses were lower versus the prior year due to companywide efforts to lower spending in response to the impacts of the Global Pandemic and in part because of foreign currency translation.

[0000038725-20-000208:mdna:72]
[same as prior period, unchanged from 0000038725-20-000179:mdna:69]

[0000038725-20-000208:mdna:73]
Restructuring expenses for the first nine months of 2020 were $2.2 million. Restructuring expenses were $2.0 million in the Water segment and $0.1 million in both the Fueling and Distribution segments. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution segment.  Restructuring expenses for the first nine months of 2019 were $1.8 million. Restructuring expenses were $1.0 million in the Water segment and $0.8 million in the Distribution segment. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution segment.

[0000038725-20-000208:mdna:74]
[same as prior period, unchanged from 0000038725-20-000179:mdna:71]

[0000038725-20-000208:mdna:75]
Operating income was $96.1 million in the first nine months of 2020, down $2.4 million or 2 percent from $98.5 million in the first nine months of 2019.

[0000038725-20-000208:mdna:76]
|  |  | Operating income (loss) |
| (In millions) |  | YTD September 30, 2020 |  | YTD September 30, 2019 |  | 2020 v 2019 |
| Water Systems |  | $ | 84.1 |  |  | $ | 78.5 |  |  | $ | 5.6 |  |
| Fueling Systems |  | 44.5 |  |  | 55.6 |  |  | (11.1) |  |
| Distribution |  | 10.9 |  |  | 6.1 |  |  | 4.8 |  |
| Eliminations/Other |  | (43.4) |  |  | (41.7) |  |  | (1.7) |  |
| Consolidated |  | $ | 96.1 |  |  | $ | 98.5 |  |  | $ | (2.4) |  |

[0000038725-20-000208:mdna:77]
[same as prior period, unchanged from 0000038725-20-000179:mdna:74]

[0000038725-20-000208:mdna:78]
Water Systems operating income was $84.1 million in the first nine months of 2020 compared to $78.5 million in the first nine months of 2019, an increase of 7 percent. The first nine months operating income margin was 15.4 percent compared to the first nine months of 2019 operating income margin of 13.2 percent. Operating income margin increased in Water Systems primarily due to higher sales volumes and favorable product sales mix shifts.

[0000038725-20-000208:mdna:79]
[same as prior period, unchanged from 0000038725-20-000179:mdna:76]

[0000038725-20-000208:mdna:80]
Fueling Systems operating income was $44.5 million in the first nine months of 2020 compared to $55.6 million in the first nine months of 2019. The first nine months operating income margin was 24.8 percent compared to 25.7 percent of net sales in the first nine months of 2019. Operating income margin decreased in Fueling Systems primarily due to lower sales volumes.

[0000038725-20-000208:mdna:81]
[same as prior period, unchanged from 0000038725-20-000179:mdna:78]

[0000038725-20-000208:mdna:82]
Distribution operating income was $10.9 million in the first nine months of 2020 and operating income margin was 4.4 percent. Distribution operating income was $6.1 million in the first nine months of 2019 and operating income margin was 2.7 percent. Operating income margin increased in Distribution due to higher sales volumes.

[0000038725-20-000208:mdna:83]
[same as prior period, unchanged from 0000038725-20-000179:mdna:80]

[0000038725-20-000208:mdna:84]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the first nine months of 2020 decreased operating loss about $0.3 million. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its third-party customer. Unallocated general and administrative expenses were lower by $1.4 million or about 3 percent to last year in the first nine months.

[0000038725-20-000208:mdna:85]
[same as prior period, unchanged from 0000038725-20-000179:mdna:82]

[0000038725-20-000208:mdna:86]
Interest expense for the first nine months of 2020 and 2019 was $3.5 million and $6.7 million, respectively, primarily as a result of lower debt levels.

[0000038725-20-000208:mdna:87]
[same as prior period, unchanged from 0000038725-20-000179:mdna:84]

[0000038725-20-000208:mdna:88]
Other income or expense was a loss of $1.1 million and $0.3 million, respectively in the first nine months of 2020 and 2019.

[0000038725-20-000208:mdna:89]
[same as prior period, unchanged from 0000038725-20-000179:mdna:86]

[0000038725-20-000208:mdna:90]
Foreign currency–based transactions produced a loss for the first nine months of 2020 of $0.1 million. Foreign currency–based transactions produced a gain for the first nine months of 2019 of $2.2 million, primarily due to a $2.3 million gain from the Argentinian Peso relative to the U.S. dollar.

[0000038725-20-000208:mdna:91]
[same as prior period, unchanged from 0000038725-20-000179:mdna:88]

[0000038725-20-000208:mdna:92]
The provision for income taxes in the first nine months of 2020 and 2019 was $17.3 million and $17.7 million, respectively. The effective tax rate for the first nine months of 2020 was about 19 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate in the first nine months of 2019 was about 19 percent and, before the impact of discrete events, was about 21 percent. The tax rate as a percentage of pre-tax earnings for the full year 2020 is projected to be about 20 percent, compared to the full year 2019 tax rate of about 20 percent, both before discrete adjustments.

[0000038725-20-000208:mdna:93]
[same as prior period, unchanged from 0000038725-20-000179:mdna:90]

[0000038725-20-000208:mdna:94]
Net income for the first nine months of 2020 was $74.2 million compared to 2019 first nine months net income of $76.0 million.  Net income attributable to Franklin Electric Co., Inc. for the first nine months of 2020 was $73.7 million, or $1.57 per diluted share, compared to 2019 first nine months net income attributable to Franklin Electric Co., Inc. of $75.7 million or $1.61 per diluted share.

[0000038725-20-000208:mdna:95]
[same as prior period, unchanged from 0000038725-20-000179:mdna:92]

[0000038725-20-000208:mdna:96]
[same as prior period, unchanged from 0000038725-20-000179:mdna:93]

[0000038725-20-000208:mdna:97]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at September 30, 2020 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-20-000208:mdna:98]
As of September 30, 2020 the Company had a $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of September 30, 2020, the Company had $295.7 million borrowing capacity under the Credit Agreement as $4.3 million in letters of commercial and standby letters of credit were outstanding and undrawn and no revolver borrowings were drawn and outstanding.

[0000038725-20-000208:mdna:99]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of  $125.0 million as of September 30, 2020. The Company also has other long-term debt borrowings outstanding as of September 30, 2020.  See Note 9 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-20-000208:mdna:100]
At September 30, 2020, the Company had $56.3 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need or intent to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-20-000208:mdna:101]
[same as prior period, unchanged from 0000038725-20-000179:mdna:98]

[0000038725-20-000208:mdna:102]
The following table summarizes significant sources and uses of cash and cash equivalents for the first nine months of 2020 and 2019.

[0000038725-20-000208:mdna:103]
| (in millions) |  | 2020 |  | 2019 |
| Net cash flows from operating activities |  | $ | 133.7 |  |  | $ | 90.2 |  |
| Net cash flows from investing activities |  | (21.4) |  |  | (35.6) |  |
| Net cash flows from financing activities |  | (58.5) |  |  | (61.0) |  |
| Impact of exchange rates on cash and cash equivalents |  | (3.8) |  |  | (5.0) |  |
| Change in cash and cash equivalents |  | $ | 50.0 |  |  | $ | (11.4) |  |

[0000038725-20-000208:mdna:104]
[same as prior period, unchanged from 0000038725-20-000179:mdna:101]

[0000038725-20-000208:mdna:105]
[same as prior period, unchanged from 0000038725-20-000179:mdna:102]

[0000038725-20-000208:mdna:106]
Net cash provided by operating activities was $133.7 million for the nine months ended September 30, 2020 compared to $90.2 million provided by operating activities for the nine months ended September 30, 2019.  The increase in cash provided by operating activities was due to a decrease of $44.9 million in working capital requirements, primarily driven by improved receivables collections and inventory management.

[0000038725-20-000208:mdna:107]
[same as prior period, unchanged from 0000038725-20-000179:mdna:104]

[0000038725-20-000208:mdna:108]
[same as prior period, unchanged from 0000038725-20-000179:mdna:105]

[0000038725-20-000208:mdna:109]
Net cash used in investing activities was $21.4 million for the nine months ended September 30, 2020 compared to $35.6 million used in investing activities for the  nine months ended September 30, 2019.  The decrease in cash used in investing activities was primarily attributable to decreased acquisition activity.

[0000038725-20-000208:mdna:110]
[same as prior period, unchanged from 0000038725-20-000179:mdna:107]

[0000038725-20-000208:mdna:111]
[same as prior period, unchanged from 0000038725-20-000179:mdna:108]

[0000038725-20-000208:mdna:112]
Net cash used in financing activities was $58.5 million for the nine months ended September 30, 2020 compared to $61.0 million used in financing activities for the nine months ended September 30, 2019. The decrease in cash used in financing activities was primarily attributable to a decrease in net debt payments of approximately $10.9 million offset by an increase of $8.8 million in common stock repurchases.

[0000038725-20-000208:mdna:113]
[same as prior period, unchanged from 0000038725-20-000179:mdna:110]
