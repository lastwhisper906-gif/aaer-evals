# FELE notes — 0000038725-24-000143


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-24-000143:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2023, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2024, and for the second quarters and six months ended June 30, 2024 and June 30, 2023 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2024. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2023.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-24-000143:notes:2]
ACCOUNTING PRONOUNCEMENTS
Accounting Standards Issued But Not Yet Adopted

[0000038725-24-000143:notes:3]
In November 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 is intended to improve reportable segment disclosure requirements, primarily through additional and more detailed information about a reportable segment's expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The guidance is to be applied retrospectively to all prior periods presented in the financial statements. The Company plans to adopt this ASU for its fiscal year end December 31, 2024 disclosures, but does not anticipate the adoption to have a material impact on the Company's financial disclosures.

[0000038725-24-000143:notes:4]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. This amendment modifies the rules on income tax disclosures to require entities to disclose (1) specific categories in the rate reconciliation and additional information for reconciling items that meet a quantitative threshold, (2) the amount of income taxes paid (net of refunds received) (disaggregated by federal, state, and foreign taxes) as well as individual jurisdictions in which income taxes paid is equal to or greater than 5 percent of total income taxes paid net of refunds, (3) the income or loss from continuing operations before income tax expense or benefit (disaggregated between domestic and foreign) and (4) income tax expense or benefit from continuing operations (disaggregated by federal, state and foreign). ASU 2023-09 is effective for annual periods beginning after December 15, 2024, with early adoption permitted. ASU 2023-09 should be applied on a prospective basis, while retrospective application is permitted. The Company is still determining the date of adoption for this ASU, but does not anticipate the adoption to have a material impact on the Company's financial disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-24-000143:notes:5]
[same as prior period, unchanged from 0000038725-24-000078:notes:5]

[0000038725-24-000143:notes:6]
During the fourth quarter ended December 31, 2023, the Company acquired substantially all of the assets of Aqua Systems of Fort Myers, a water treatment systems distributor.  In another separate transaction, the Company acquired substantially all of the assets of Action Manufacturing and Supply, Inc., a water treatment equipment provider located in southwest Florida. The Company also acquired, in a separate transaction, substantially all of the assets of LCA Pump, LLC, which operates Water Works Pump, a Missouri based professional groundwater distributor. The combined purchase price for the acquisitions in the fourth quarter of 2023, was $36.0 million, including contingent consideration with an estimated fair value of $4.3 million, after purchase price adjustments based on the level of working capital acquired. In the first quarter of 2024, the Company recorded a measurement period adjustment of $1.3 million to increase the acquisition-date fair value of the contingent consideration transferred. The measurement period adjustment resulted in an increase to acquired identifiable intangible assets of $2.3 million and a reduction to acquired goodwill of $1.0 million. The measurement period adjustments did not have a significant impact on the Company’s results of operations. The fair value of the assets acquired and liabilities assumed for the above acquisitions is preliminary as of June 30, 2024.

[0000038725-24-000143:notes:7]
During the first quarter ended March 31, 2023, the Company acquired all of the assets of Phil-Good Products, Inc. ("Phil-Good"). Phil-Good is an injection molded plastics component manufacturer. In another separate transaction in the first quarter of 2023, the Company acquired 100 percent of the ownership interests of Hydropompe S.r.l. ("Hydropompe"). Hydropompe is a pump manufacturer with a focus in dewatering and sewage products. The combined, all-cash purchase price for both

[0000038725-24-000143:notes:8]
acquisitions in the first quarter of 2023 was $8.7 million after purchase price adjustments based on the level of working capital acquired. The fair value of the assets acquired and liabilities assumed for both acquisitions was final as of March 31, 2024.

[0000038725-24-000143:notes:9]
[same as prior period, unchanged from 0000038725-24-000078:notes:8]

[0000038725-24-000143:notes:10]
[same as prior period, unchanged from 0000038725-24-000078:notes:9]


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-24-000143:notes:11]
FAIR VALUE MEASUREMENTS
FASB Accounting Standards Codification Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value. The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-24-000143:notes:12]
[same as prior period, unchanged from 0000038725-24-000078:notes:11]

[0000038725-24-000143:notes:13]
[same as prior period, unchanged from 0000038725-24-000078:notes:12]

[0000038725-24-000143:notes:14]
[same as prior period, unchanged from 0000038725-24-000078:notes:13]

[0000038725-24-000143:notes:15]
As of June 30, 2024 and December 31, 2023, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-24-000143:notes:16]
| (In millions) | June 30, 2024 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 7.4 |  | $ | 7.4 |  | $ | — |  | $ | — |  |
| Total assets | $ | 7.4 |  | $ | 7.4 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Share swap transaction | $ | 0.3 |  | $ | 0.3 |  | $ | — |  | $ | — |  |
| Forward currency contracts | 0.1 |  | — |  | 0.1 |  | — |  |
| Contingent payments related to acquisition | 4.6 |  | — |  | — |  | 4.6 |  |
| Total liabilities | $ | 5.0 |  | $ | 0.3 |  | $ | 0.1 |  | $ | 4.6 |  |
| (In millions) | December 31, 2023 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 10.9 |  | $ | 10.9 |  | $ | — |  | $ | — |  |
| Share swap transaction | 1.1 |  | 1.1 |  | — |  | — |  |
| Total assets | $ | 12.0 |  | $ | 12.0 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Contingent payments related to acquisition | $ | 3.0 |  | $ | — |  | $ | — |  | $ | 3.0 |  |
| Total liabilities | $ | 3.0 |  | $ | — |  | $ | — |  | $ | 3.0 |  |

[0000038725-24-000143:notes:17]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The share swap transaction asset is recorded within the "Receivables" line of the condensed consolidated balance sheets, and the share swap transaction and forward currency contracts liabilities are recorded within the "Accounts payable" lines of the condensed consolidated balance sheets and are further described in Note 5 - Financial Instruments.

[0000038725-24-000143:notes:18]
The Company's Level 3 category includes contingent consideration related to acquisitions, which valuation inputs are unobservable and significant to the fair value measurement.  Projections and estimated probabilities are used to estimate future contingent earn-out payments, which are discounted back to present value to compute contingent earn-out liabilities. The following table provides a roll-forward of the contingent consideration liability, which is included in "Other long-term liabilities" as of December 31, 2023 and "Accrued expenses and other current liabilities" as of June 30, 2024 in the condensed consolidated balance sheets:

[0000038725-24-000143:notes:19]
|  | Second Quarter Ended | Six Months Ended |
| (In millions) | June 30, 2024 | June 30, 2024 |
| Fair value at beginning of period | $ | 4.5 |  | $ | 3.0 |  |
| Adjustments to prior year acquisition | — |  | 1.3 |  |
| Change in fair value recognized in earnings | 0.1 |  | 0.3 |  |
| Payments | — |  | — |  |
| Fair value at end of period | $ | 4.6 |  | $ | 4.6 |  |

[0000038725-24-000143:notes:20]
Total debt, including current maturities, have carrying amounts of $129.6 million and $100.5 million and estimated fair values of $127.0 million and $98.6 million as of June 30, 2024 and December 31, 2023, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-24-000143:notes:21]
FINANCIAL INSTRUMENTS
The Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of June 30, 2024 and December 31, 2023, the swap had a notional value based on 240,000 shares. For the second quarter and six months ended June 30, 2024, changes in the fair value of the swap resulted in losses of $2.9 million, and $0.8 million, respectively. For the second quarter and six months ended June 30, 2023, changes in the fair value of the swap resulted in gains of $1.7 million and $4.7 million, respectively. Gaines and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.

[0000038725-24-000143:notes:22]
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of June 30, 2024, the Company had a notional amount of $28.2 million in forward currency contracts outstanding and the related fair value of those contracts was not material.  As of December 31, 2023, the Company had no foreign currency contracts outstanding.  For the second quarter and six months ended June 30, 2024, changes in the fair value of the forward currency contracts resulted in losses of $0.9 million and $0.3 million, respectively. For the second quarter and six months ended June 30, 2023, changes in the fair value of the forward currency contracts resulted in gains of $0.6 million and $1.6 million, respectively. These gains and losses are recorded in the Company's condensed consolidated statements of income within the "Foreign exchange expense" line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-24-000143:notes:23]
[same as prior period, unchanged from 0000038725-24-000078:notes:22]

[0000038725-24-000143:notes:24]
| (In millions) |  | June 30, 2024 |  | December 31, 2023 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 263.5 |  |  | $ | (122.1) |  |  | $ | 263.7 |  |  | $ | (115.5) |  |
| Patents |  | 7.3 |  |  | (7.3) |  |  | 7.3 |  |  | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.5) |  |  | 7.5 |  |  | (7.5) |  |
| Trade names |  | 44.1 |  |  | (7.0) |  |  | 44.1 |  |  | (5.8) |  |
| Other |  | 3.2 |  |  | (2.7) |  |  | 3.4 |  |  | (2.8) |  |
| Total |  | $ | 325.6 |  |  | $ | (146.6) |  |  | $ | 326.0 |  |  | $ | (138.9) |  |
| Non-amortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.1 |  |  | — |  |  | 42.9 |  |  | — |  |
| Total intangibles |  | $ | 367.7 |  |  | $ | (146.6) |  |  | $ | 368.9 |  |  | $ | (138.9) |  |

[0000038725-24-000143:notes:25]
Amortization expense related to intangible assets for the second quarters ended June 30, 2024 and June 30, 2023 was $4.7 million and $4.3 million, respectively, and for six months ended June 30, 2024 and June 30, 2023 was $9.5 million and $8.5 million, respectively.

[0000038725-24-000143:notes:26]
The change in the carrying amount of goodwill by reportable segment for the six months ended June 30, 2024 is as follows:

[0000038725-24-000143:notes:27]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2023 |  | $ | 221.4 |  |  | $ | 70.4 |  |  | $ | 50.6 |  |  | $ | 342.4 |  |
| Adjustments to prior year acquisitions |  | (0.7) |  |  | — |  |  | (0.1) |  |  | (0.8) |  |
| Foreign currency translation |  | (1.8) |  |  | — |  |  | — |  |  | (1.8) |  |
| Balance as of June 30, 2024 |  | $ | 218.9 |  |  | $ | 70.4 |  |  | $ | 50.5 |  |  | $ | 339.8 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-24-000143:notes:28]
EMPLOYEE BENEFIT PLANS
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the second quarters and six months ended June 30, 2024 and June 30, 2023:

[0000038725-24-000143:notes:29]
| (In millions) | Pension Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2024 |  | June 30, 2023 |  | June 30, 2024 |  | June 30, 2023 |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.3 |  |
| Interest cost | 1.6 |  |  | 1.8 |  |  | 3.1 |  |  | 3.3 |  |
| Expected return on assets | (1.9) |  |  | (1.8) |  |  | (3.8) |  |  | (3.6) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | 0.6 |  |  | — |  |  | 1.2 |  |  | — |  |
| Actuarial loss | — |  |  | 0.5 |  |  | — |  |  | 1.1 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.5 |  |  | $ | 0.7 |  |  | $ | 0.8 |  |  | $ | 1.1 |  |

[0000038725-24-000143:notes:30]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the second quarters and six months ended June 30, 2024 and June 30, 2023:

[0000038725-24-000143:notes:31]
| (In millions) | Other Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2024 |  | June 30, 2023 |  | June 30, 2024 |  | June 30, 2023 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | 0.1 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-24-000143:notes:32]
[same as prior period, unchanged from 0000038725-24-000078:notes:31]

[0000038725-24-000143:notes:33]
| (In millions) |  | June 30, 2024 |  | December 31, 2023 |
| Salaries, wages, and commissions |  | $ | 41.6 |  |  | $ | 45.9 |  |
| Product warranty costs |  | 9.4 |  |  | 9.3 |  |
| Insurance |  | 2.1 |  |  | 2.5 |  |
| Employee benefits |  | 15.0 |  |  | 13.8 |  |
| Other |  | 36.4 |  |  | 28.7 |  |
| Total |  | $ | 104.5 |  |  | $ | 100.2 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-24-000143:notes:34]
INCOME TAXES
The Company’s effective tax rate for the six-month period ended June 30, 2024 was 22.5 percent as compared to 20.0 percent for the six-month period ended June 30, 2023. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to state taxes and foreign earnings taxed at rates higher than the U.S. statutory rate partially offset by the recognition of the U.S. foreign-derived intangible income (FDII) provisions and certain discrete events including excess tax benefits from share-based compensation. For the second quarter of 2024, the effective tax rate was 22.9 percent compared to 19.1 percent for the second quarter of 2023.

[0000038725-24-000143:notes:35]
The increase in the effective tax rate for the second quarter and first six months of 2024 compared to the comparable period in the prior year was a result of less favorable discrete events in 2024, primarily related to excess tax benefits from share-based compensation, in addition to an increase in the rate on foreign earnings with the implementation of the European Union’s Pillar Two Directive.


## us-gaap:DebtDisclosureTextBlock

[0000038725-24-000143:notes:36]
DEBT
Debt consisted of the following:

[0000038725-24-000143:notes:37]
| (In millions) |  | June 30, 2024 |  | December 31, 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 41.0 |  |  | 11.0 |  |
| Tax increment financing debt |  | 13.4 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.3 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 129.6 |  |  | $ | 100.5 |  |
| Less: current maturities |  | (42.4) |  |  | (12.4) |  |
| Long-term debt |  | $ | 87.2 |  |  | $ | 88.1 |  |

[0000038725-24-000143:notes:38]
Prudential Agreement

[0000038725-24-000143:notes:39]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates. On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million and changed the expiration date from July 30, 2024 to May 15, 2027.

[0000038725-24-000143:notes:40]
New York Life Agreement

[0000038725-24-000143:notes:41]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC and its affiliates (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $200.0 million and changed the expiration date from July 30, 2024 to May 15, 2027.

[0000038725-24-000143:notes:42]
Credit Agreement

[0000038725-24-000143:notes:43]
As of June 30, 2024, the Company had $41.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.5 million in letters of credit outstanding, and $305.5 million of available capacity under its credit agreement. As of December 31, 2023, the Company had $11.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $335.4 million of available capacity under its credit agreement.

[0000038725-24-000143:notes:44]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $17.4 million. As of June 30, 2024, there were no outstanding borrowings and $17.4 million of available capacity under these lines of credit. As of December 31, 2023, there were $17.9 million overdraft lines of credit with no outstanding borrowings and $17.9 million of available capacity under these lines of credit.


## us-gaap:EarningsPerShareTextBlock

[0000038725-24-000143:notes:45]
[same as prior period, unchanged from 0000038725-24-000078:notes:40]

[0000038725-24-000143:notes:46]
[same as prior period, unchanged from 0000038725-24-000078:notes:41]

[0000038725-24-000143:notes:47]
[same as prior period, unchanged from 0000038725-24-000078:notes:42]

[0000038725-24-000143:notes:48]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions, except per share amounts) | June 30, 2024 |  | June 30, 2023 |  | June 30, 2024 |  | June 30, 2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 59.1 |  |  | $ | 59.6 |  |  | $ | 92.1 |  |  | $ | 96.9 |  |
| Less: Earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Net income available to common shareholders | $ | 58.9 |  |  | $ | 59.4 |  |  | $ | 91.8 |  |  | $ | 96.6 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.0 |  |  | 46.2 |  |  | 46.0 |  |  | 46.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors | 0.6 |  |  | 0.7 |  |  | 0.6 |  |  | 0.7 |  |
| Diluted weighted average common shares outstanding | 46.6 |  |  | 46.9 |  |  | 46.6 |  |  | 46.9 |  |
| Basic earnings per share | $ | 1.28 |  |  | $ | 1.29 |  |  | $ | 1.99 |  |  | $ | 2.09 |  |
| Diluted earnings per share | $ | 1.26 |  |  | $ | 1.27 |  |  | $ | 1.97 |  |  | $ | 2.06 |  |

[0000038725-24-000143:notes:49]
There were 0.1 million stock options outstanding for the second quarters and six months ended June 30, 2024 and June 30, 2023, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-24-000143:notes:50]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the second quarters and six months ended June 30, 2024 and June 30, 2023:

[0000038725-24-000143:notes:51]
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2024 | $ | 4,609 |  |  | $ | 352,797 |  |  | $ | 1,090,874 |  |  |  |  |  |  | $ | (227,855) |  |  | $ | 2,554 |  |  | $ | 1,222,979 |  |  | $ | 1,109 |  |
| Net income | — |  |  | — |  |  | 59,099 |  |  |  |  |  |  | — |  |  | 186 |  |  | 59,285 |  |  | 46 |  |
| Dividends on common stock ($0.250/share) | — |  |  | — |  |  | (11,564) |  |  |  |  |  |  | — |  |  | — |  |  | (11,564) |  |  | — |  |
| Common stock issued | — |  |  | 252 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 252 |  |  | — |  |
| Common stock repurchased | (40) |  |  | — |  |  | (39,124) |  |  |  |  |  |  | — |  |  | — |  |  | (39,164) |  |  | — |  |
| Share-based compensation | 6 |  |  | 2,967 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 2,973 |  |  | — |  |
| Dividend to noncontrolling interest | — |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | — |  |  | (21) |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (10,284) |  |  | (15) |  |  | (10,299) |  |  | — |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 434 |  |  | — |  |  | 434 |  |  | — |  |
| Balance as of June 30, 2024 | $ | 4,575 |  |  | $ | 356,016 |  |  | $ | 1,099,285 |  |  |  |  |  |  | $ | (237,705) |  |  | $ | 2,725 |  |  | $ | 1,224,896 |  |  | $ | 1,134 |  |
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2023 | $ | 4,614 |  |  | $ | 332,263 |  |  | $ | 980,114 |  |  |  |  |  |  | $ | (224,560) |  |  | $ | 2,537 |  |  | $ | 1,094,968 |  |  | $ | 633 |  |
| Net income | — |  |  | — |  |  | 59,600 |  |  |  |  |  |  | — |  |  | 292 |  |  | 59,892 |  |  | 268 |  |
| Dividends on common stock ($0.225/share) | — |  |  | — |  |  | (10,432) |  |  |  |  |  |  | — |  |  | — |  |  | (10,432) |  |  | — |  |
| Common stock issued | 15 |  |  | 6,057 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 6,072 |  |  | — |  |
| Common stock repurchased | (9) |  |  | — |  |  | (8,399) |  |  |  |  |  |  | — |  |  | — |  |  | (8,408) |  |  | — |  |
| Share-based compensation | 6 |  |  | 2,492 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 2,498 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 4,482 |  |  | 13 |  |  | 4,495 |  |  | — |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 416 |  |  | — |  |  | 416 |  |  | — |  |
| Balance as of June 30, 2023 | $ | 4,626 |  |  | $ | 340,812 |  |  | $ | 1,020,883 |  |  |  |  |  |  | $ | (219,662) |  |  | $ | 2,842 |  |  | $ | 1,149,501 |  |  | $ | 901 |  |

[0000038725-24-000143:notes:52]
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2023 | $ | 4,607 |  |  | $ | 344,717 |  |  | $ | 1,078,512 |  |  |  |  |  |  | $ | (221,114) |  |  | $ | 2,426 |  |  | $ | 1,209,148 |  |  | $ | 1,145 |  |
| Net Income | — |  |  | — |  |  | 92,058 |  |  |  |  |  |  | — |  |  | 355 |  |  | 92,413 |  |  | 10 |  |
| Dividends on common stock ($0.500/share) | — |  |  | — |  |  | (23,124) |  |  |  |  |  |  | — |  |  | — |  |  | (23,124) |  |  | — |  |
| Common stock issued | 7 |  |  | 4,295 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 4,302 |  |  | — |  |
| Common stock repurchased | (50) |  |  | — |  |  | (48,161) |  |  |  |  |  |  | — |  |  | — |  |  | (48,211) |  |  | — |  |
| Share-based compensation | 11 |  |  | 7,004 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 7,015 |  |  | — |  |
| Dividend to noncontrolling interest | — |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | — |  |  | (21) |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (17,458) |  |  | (56) |  |  | (17,514) |  |  | — |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 867 |  |  | — |  |  | 867 |  |  | — |  |
| Balance as of June 30, 2024 | $ | 4,575 |  |  | $ | 356,016 |  |  | $ | 1,099,285 |  |  |  |  |  |  | $ | (237,705) |  |  | $ | 2,725 |  |  | $ | 1,224,896 |  |  | $ | 1,134 |  |
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2022 | $ | 4,619 |  |  | $ | 325,426 |  |  | $ | 969,261 |  |  |  |  |  |  | $ | (231,448) |  |  | $ | 2,276 |  |  | $ | 1,070,134 |  |  | $ | 620 |  |
| Net Income | — |  |  | — |  |  | 96,925 |  |  |  |  |  |  | — |  |  | 530 |  |  | 97,455 |  |  | 281 |  |
| Dividends on common stock ($0.450/share) | — |  |  | — |  |  | (20,872) |  |  |  |  |  |  | — |  |  | — |  |  | (20,872) |  |  | — |  |
| Common stock issued | 22 |  |  | 8,988 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 9,010 |  |  | — |  |
| Common stock repurchased | (27) |  |  | — |  |  | (24,431) |  |  |  |  |  |  | — |  |  | — |  |  | (24,458) |  |  | — |  |
| Share-based compensation | 12 |  |  | 6,398 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 6,410 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 10,953 |  |  | 36 |  |  | 10,989 |  |  | — |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 833 |  |  | — |  |  | 833 |  |  | — |  |
| Balance as of June 30, 2023 | $ | 4,626 |  |  | $ | 340,812 |  |  | $ | 1,020,883 |  |  |  |  |  |  | $ | (219,662) |  |  | $ | 2,842 |  |  | $ | 1,149,501 |  |  | $ | 901 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-24-000143:notes:53]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the six months ended June 30, 2024 and June 30, 2023, are summarized below:

[0000038725-24-000143:notes:54]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| For the six months ended June 30, 2024: |  |  |
| Balance as of December 31, 2023 | $ | (179.3) |  |  | $ | (41.8) |  |  | $ | (221.1) |  |
| Other comprehensive income/(loss) before reclassifications | (17.5) |  |  | — |  |  | (17.5) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.9 |  |  | 0.9 |  |
| Net other comprehensive income/(loss) | (17.5) |  |  | 0.9 |  |  | (16.6) |  |
| Balance as of June 30, 2024 | $ | (196.8) |  |  | $ | (40.9) |  |  | $ | (237.7) |  |
| For the six months ended June 30, 2023: |  |  |  |  |  |
| Balance as of December 31, 2022 | $ | (191.3) |  |  | $ | (40.1) |  |  | $ | (231.4) |  |
| Other comprehensive income/(loss) before reclassifications | 10.9 |  |  | — |  |  | 10.9 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.8 |  |  | 0.8 |  |
| Net other comprehensive income/(loss) | 10.9 |  |  | 0.8 |  |  | 11.7 |  |
| Balance as of June 30, 2023 | $ | (180.4) |  |  | $ | (39.3) |  |  | $ | (219.7) |  |

[0000038725-24-000143:notes:55]
[same as prior period, unchanged from 0000038725-24-000078:notes:49]

[0000038725-24-000143:notes:56]
(2) Net of tax expense of $0.3 million for the six months ended June 30, 2024 and June 30, 2023, respectively.

[0000038725-24-000143:notes:57]
[same as prior period, unchanged from 0000038725-24-000078:notes:51]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-24-000143:notes:58]
[same as prior period, unchanged from 0000038725-24-000078:notes:52]

[0000038725-24-000143:notes:59]
[same as prior period, unchanged from 0000038725-24-000078:notes:53]

[0000038725-24-000143:notes:60]
[same as prior period, unchanged from 0000038725-24-000078:notes:54]

[0000038725-24-000143:notes:61]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions) | June 30, 2024 |  | June 30, 2023 |  | June 30, 2024 |  | June 30, 2023 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 157.7 |  |  | $ | 176.8 |  |  | $ | 295.7 |  |  | $ | 336.2 |  |
| Latin America | 41.8 |  |  | 42.0 |  |  | 83.1 |  |  | 82.3 |  |
| Europe, Middle East & Africa | 56.0 |  |  | 54.6 |  |  | 108.3 |  |  | 105.0 |  |
| Asia Pacific | 24.2 |  |  | 22.2 |  |  | 44.4 |  |  | 41.0 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 35.9 |  |  | 26.1 |  |  | 70.7 |  |  | 63.8 |  |
| Total sales | 315.6 |  |  | 321.7 |  |  | 602.2 |  |  | 628.3 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 190.5 |  |  | 193.1 |  |  | 337.5 |  |  | 336.1 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 190.5 |  |  | 193.1 |  |  | 337.5 |  |  | 336.1 |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 58.4 |  |  | 60.4 |  |  | 105.1 |  |  | 114.4 |  |
| All other | 14.7 |  |  | 20.0 |  |  | 30.1 |  |  | 38.7 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 73.1 |  |  | 80.4 |  |  | 135.2 |  |  | 153.1 |  |
| Intersegment Eliminations/Other | (35.9) |  |  | (26.1) |  |  | (70.7) |  |  | (63.8) |  |
| Consolidated | $ | 543.3 |  |  | $ | 569.1 |  |  | $ | 1,004.2 |  |  | $ | 1,053.7 |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2024 |  | June 30, 2023 |  | June 30, 2024 |  | June 30, 2023 |
|  | Operating income/(loss) |
| Water Systems | $ | 62.3 |  |  | $ | 50.8 |  |  | $ | 109.5 |  |  | $ | 99.8 |  |
| Distribution | 9.8 |  |  | 17.8 |  |  | 11.7 |  |  | 22.5 |  |
| Fueling Systems | 26.0 |  |  | 26.7 |  |  | 44.8 |  |  | 47.5 |  |
| Intersegment Eliminations/Other | (19.0) |  |  | (14.4) |  |  | (38.9) |  |  | (36.3) |  |
| Consolidated | $ | 79.1 |  |  | $ | 80.9 |  |  | $ | 127.1 |  |  | $ | 133.5 |  |

[0000038725-24-000143:notes:62]
|  | June 30, 2024 |  | December 31, 2023 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 1,056.5 |  |  | $ | 1,044.4 |  |  |  |  |  |
| Distribution | 415.5 |  |  | 365.6 |  |  |  |  |  |
| Fueling Systems | 259.5 |  |  | 256.4 |  |  |  |  |  |
| Other | 52.8 |  |  | 61.7 |  |  |  |  |  |
| Consolidated | $ | 1,784.3 |  |  | $ | 1,728.1 |  |  |  |  |  |

[0000038725-24-000143:notes:63]
[same as prior period, unchanged from 0000038725-24-000078:notes:57]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-24-000143:notes:64]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.

[0000038725-24-000143:notes:65]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-24-000143:notes:66]
At June 30, 2024, the Company had $7.5 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

[0000038725-24-000143:notes:67]
At June 30, 2024, the Company has a contingent consideration liability with an estimated fair value of $4.6 million that could result in a payment of up to $5.0 million if a future profitability milestone is achieved.

[0000038725-24-000143:notes:68]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2024, are as follows:

[0000038725-24-000143:notes:69]
| (In millions) |  |  |
| Balance as of December 31, 2023 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 6.4 |  |
| Reductions for payments made |  | (6.3) |  |
| Balance as of June 30, 2024 |  | $ | 9.4 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000038725-24-000143:notes:70]
None of the Company’s directors or officers adopted, modified, or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement during the Company’s fiscal quarter ended June 30, 2024.
