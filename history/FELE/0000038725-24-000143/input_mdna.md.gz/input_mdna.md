# FELE MD&A — 0000038725-24-000143


## mdna

[0000038725-24-000143:mdna:1]
[same as prior period, unchanged from 0000038725-24-000078:mdna:1]

[0000038725-24-000143:mdna:2]
Second Quarter 2024 vs. 2023

[0000038725-24-000143:mdna:3]
[same as prior period, unchanged from 0000038725-24-000078:mdna:3]

[0000038725-24-000143:mdna:4]
Net sales in the second quarter and first six months of 2024 were $543.3 million and $1.0 billion, respectively, and decreased 5 percent from the prior-year periods. The sales decreases were primarily due to lower volumes and the negative impact of foreign currency translation, partially offset by the incremental sales impact from recent acquisitions. The Company's consolidated gross profit was $199.8 million and $363.4 million, respectively, for the second quarter and first six months of 2024, increases of 6 percent and 4 percent, respectively, from the prior-year periods. Diluted earnings per share was $1.26 and $1.97, respectively, for the second quarter and first six months of 2024, decreases of $0.01 and $0.09, respectively, from the prior-year periods.

[0000038725-24-000143:mdna:5]
[same as prior period, unchanged from 0000038725-24-000078:mdna:5]

[0000038725-24-000143:mdna:6]
[same as prior period, unchanged from 0000038725-24-000078:mdna:6]

[0000038725-24-000143:mdna:7]
Net sales in the second quarter and first six months of 2024 were $543.3 million and $1.0 billion, respectively, and decreased 5 percent as compared to the prior-year periods. Sales were negatively impacted by changes in foreign exchange rates, principally due to the strengthening of the U.S. Dollar relative to the Argentine Peso and Turkish Lira. However, the Company increases prices in the local currency to offset the impact of currency devaluation in the Argentina and Turkey hyperinflationary economies. As a result, the net negative impact of foreign currency exchange rates on net sales was 1 percent in the second quarter and first six months of 2024 compared to the same periods in the prior year.

[0000038725-24-000143:mdna:8]
|  | Net Sales |
| (In millions) | Q2 2024 |  | Q2 2023 |  | 2024 v 2023 |
| Water Systems | $ | 315.6 |  |  | $ | 321.7 |  |  | $ | (6.1) |  |
| Fueling Systems | 73.1 |  |  | 80.4 |  |  | (7.3) |  |
| Distribution | 190.5 |  |  | 193.1 |  |  | (2.6) |  |
| Eliminations/Other | (35.9) |  |  | (26.1) |  |  | (9.8) |  |
| Consolidated | $ | 543.3 |  |  | $ | 569.1 |  |  | $ | (25.8) |  |

[0000038725-24-000143:mdna:9]
|  | Net Sales |
| (In millions) | YTD June 30, 2024 |  | YTD June 30, 2023 |  | 2024 v 2023 |
| Water Systems | $ | 602.2 |  |  | $ | 628.3 |  |  | $ | (26.1) |  |
| Fueling Systems | 135.2 |  |  | 153.1 |  |  | (17.9) |  |
| Distribution | 337.5 |  |  | 336.1 |  |  | 1.4 |  |
| Eliminations/Other | (70.7) |  |  | (63.8) |  |  | (6.9) |  |
| Consolidated | $ | 1,004.2 |  |  | $ | 1,053.7 |  |  | $ | (49.5) |  |

[0000038725-24-000143:mdna:10]
[same as prior period, unchanged from 0000038725-24-000078:mdna:9]

[0000038725-24-000143:mdna:11]
Water Systems net sales decreased 2 percent in the second quarter and 4 percent in the first six months of 2024, as compared to the prior-year periods. This sales decline was primarily due to lower volumes, which decreased due to weaker end market demand for large dewatering equipment. Sales decreased 2 percent in the second quarter and 1 percent in the first six months of 2024 due to the negative impact from foreign exchange rates, as compared to prior-year periods. The incremental sales impact from recent acquisitions favorably impacted sales 2 percent in the second quarter and first six months of 2024.

[0000038725-24-000143:mdna:12]
Water Systems net sales in the U.S. and Canada decreased 5 percent in the second quarter and 8 percent in the first six months of 2024, as compared to the prior-year periods. In the second quarter of 2024, sales of large dewatering equipment decreased 44 percent, sales of water treatment products increased 13 percent, sales of all other surface pumping equipment increased 11 percent and sales of groundwater pumping equipment increased 6 percent compared to 2023. In the first half of 2024, sales of large dewatering equipment decreased 47 percent, sales of groundwater pumping equipment decreased 1 percent, sales of water treatment products increased 13 percent and sales of all other surface pumping equipment increased 6 percent compared to 2023.

[0000038725-24-000143:mdna:13]
Water Systems net sales in markets outside the U.S. and Canada increased 3 percent in the second quarter and first six months of 2024, as compared to the prior-year periods. Sales decreased 4 percent in the second quarter and 3 percent in the first six months of 2024 due to the negative impact from foreign exchange rates, as compared to prior-year periods. In both the second quarter and first half of 2024, outside the U.S. and Canada, excluding the impact of foreign currency translation, sales increased in all three major regions: EMEA, Latin America and Asia Pacific.

[0000038725-24-000143:mdna:14]
[same as prior period, unchanged from 0000038725-24-000078:mdna:13]

[0000038725-24-000143:mdna:15]
Fueling Systems net sales decreased 9 percent in the second quarter and 12 percent in the first six months of 2024, as compared to the prior-year periods. This sales decline was primarily due to lower volumes.

[0000038725-24-000143:mdna:16]
Fueling Systems net sales in the U.S. and Canada decreased 4 percent in the second quarter and 6 percent in the first six months of 2024, as compared to the prior-year periods. The decrease was primarily in fuel management systems and pumping systems. Outside the U.S. and Canada, Fueling Systems sales decreased 7 percent in the second quarter and 6 percent in the first six months of 2024, as compared to the prior-year periods, due primarily to lower sales in European and Asia Pacific markets.

[0000038725-24-000143:mdna:17]
[same as prior period, unchanged from 0000038725-24-000078:mdna:16]

[0000038725-24-000143:mdna:18]
Distribution net sales decreased 1 percent in the second quarter and were flat in the first six months of 2024, as compared to the prior-year periods. The Distribution segment sales were negatively impacted by unfavorable weather conditions and commodity pricing declines, partially offset by the incremental sales impact from a recent acquisition which favorably impacted net sales by 2 percent in the second quarter and first six months of 2024.

[0000038725-24-000143:mdna:19]
[same as prior period, unchanged from 0000038725-24-000078:mdna:18]

[0000038725-24-000143:mdna:20]
|  | Three Months Ended June 30, |
| (In Millions) | 2024 |  | % of Net Sales |  | 2023 |  | % of Net Sales |
| Gross Profit | $ | 199.8 |  |  | 36.8 | % |  | $ | 188.5 |  |  | 33.1 | % |
| Selling, General and Administrative Expense | 120.6 |  |  | 22.2 | % |  | 107.4 |  |  | 18.9 | % |

[0000038725-24-000143:mdna:21]
|  | Six Months Ended June 30, |
| (In Millions) | 2024 |  | % of Net Sales |  | 2023 |  | % of Net Sales |
| Gross Profit | $ | 363.4 |  |  | 36.2 | % |  | $ | 350.7 |  |  | 33.3 | % |
| Selling, General and Administrative Expense | 236.3 |  |  | 23.5 | % |  | 217.0 |  |  | 20.6 | % |

[0000038725-24-000143:mdna:22]
[same as prior period, unchanged from 0000038725-24-000078:mdna:20]

[0000038725-24-000143:mdna:23]
The gross profit margin ratio was 36.8 percent and 36.2 percent in the second quarter and first six months of 2024, respectively, and 33.1 percent and 33.3 percent in the second quarter and first six months of 2023, respectively. The gross profit margin was impacted in the second quarter and first six months of 2024 by cost management, including lower freight costs in Water Systems and Fueling Systems, and a favorable product and geographic sales mix shift.

[0000038725-24-000143:mdna:24]
[same as prior period, unchanged from 0000038725-24-000078:mdna:22]

[0000038725-24-000143:mdna:25]
SG&A expenses were $120.6 million in the second quarter and $236.3 million in the first half of 2024 compared to $107.4 million in the second quarter and $217.0 million in the first half of 2023. SG&A expenses increased in the second quarter and first half of 2024 primarily due to higher compensation costs and advertising and marketing expenses. The SG&A expenses ratio was 22.2 percent and 23.5 percent in the second quarter and first six months of 2024, respectively, and 18.9 percent and 20.6 percent in the second quarter and first six months of 2023, respectively.

[0000038725-24-000143:mdna:26]
[same as prior period, unchanged from 0000038725-24-000078:mdna:24]

[0000038725-24-000143:mdna:27]
There were no restructuring expenses in the second quarter and first six months of 2024, and $0.1 million and $0.3 million in the second quarter and first six months of 2023, respectively. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities, branch closings and consolidations.

[0000038725-24-000143:mdna:28]
[same as prior period, unchanged from 0000038725-24-000078:mdna:26]

[0000038725-24-000143:mdna:29]
Operating income in the second quarter and first half of 2024 was $79.1 million and $127.1 million, respectively, decreases of 2 percent and 5 percent, respectively, as compared to the prior-year periods.

[0000038725-24-000143:mdna:30]
|  |  | Operating income (loss) |
| (In millions) |  | Q2 2024 |  | Q2 2023 |  | 2024 v 2023 |
| Water Systems |  | $ | 62.3 |  |  | $ | 50.8 |  |  | $ | 11.5 |  |
| Fueling Systems |  | 26.0 |  |  | 26.7 |  |  | (0.7) |  |
| Distribution |  | 9.8 |  |  | 17.8 |  |  | (8.0) |  |
| Eliminations/Other |  | (19.0) |  |  | (14.4) |  |  | (4.6) |  |
| Consolidated |  | $ | 79.1 |  |  | $ | 80.9 |  |  | $ | (1.8) |  |

[0000038725-24-000143:mdna:31]
|  |  | Operating income (loss) |
| (In millions) |  | YTD June 30, 2024 |  | YTD June 30, 2023 |  | 2024 v 2023 |
| Water Systems |  | $ | 109.5 |  |  | $ | 99.8 |  |  | $ | 9.7 |  |
| Fueling Systems |  | 44.8 |  |  | 47.5 |  |  | (2.7) |  |
| Distribution |  | 11.7 |  |  | 22.5 |  |  | (10.8) |  |
| Eliminations/Other |  | (38.9) |  |  | (36.3) |  |  | (2.6) |  |
| Consolidated |  | $ | 127.1 |  |  | $ | 133.5 |  |  | $ | (6.4) |  |

[0000038725-24-000143:mdna:32]
[same as prior period, unchanged from 0000038725-24-000078:mdna:29]

[0000038725-24-000143:mdna:33]
Water Systems operating income in the second quarter and first six months of 2024 was $62.3 million and $109.5 million, respectively, increases of $11.5 million and $9.7 million, respectively, as compared to the prior-year periods. The increases were primarily due to cost management and a favorable product and geographic sales mix shift.  The second quarter operating income margin was 19.7 percent, an increase of 390 basis points from 15.8 percent in the second quarter of 2023. The first six months of 2024 operating income margin was 18.2 percent, an increase of 230 basis points from 15.9 percent in the first six months of 2023. Operating income margin increased primarily due to cost management and a favorable product and geographic sales mix shift.

[0000038725-24-000143:mdna:34]
[same as prior period, unchanged from 0000038725-24-000078:mdna:31]

[0000038725-24-000143:mdna:35]
Fueling Systems operating income in the second quarter and first six months of 2024 was $26.0 million and $44.8 million, respectively, decreases of $0.7 million and $2.7 million, respectively, as compared to the prior-year periods. The decreases were primarily due to lower sales. The second quarter operating income margin was 35.6 percent, an increase of 240 basis points from 33.2 percent in the second quarter of 2023. The first six months of 2024 operating income margin was 33.1 percent, an increase of 210 basis points from 31.0 percent in the first six months of 2023. Operating income margin increased primarily due to price realization and cost management.

[0000038725-24-000143:mdna:36]
[same as prior period, unchanged from 0000038725-24-000078:mdna:33]

[0000038725-24-000143:mdna:37]
Distribution operating income in the second quarter and first six months of 2024 was $9.8 million and $11.7 million, respectively, decreases of $8.0 million and $10.8 million, respectively, as compared to the prior-year periods. The second quarter operating income margin was 5.1 percent, a decrease of 410 basis points from 9.2 percent in the second quarter of 2023. The first six months of 2024 operating income margin was 3.5 percent, a decrease of 320 basis points from 6.7 percent in the first six months of 2023. Operating income and operating income margin decreased primarily due to the negative impact on sales from wet weather across much of the United States, decreases in pricing of commodity-based products sold through the business and increased SG&A costs.

[0000038725-24-000143:mdna:38]
[same as prior period, unchanged from 0000038725-24-000078:mdna:35]

[0000038725-24-000143:mdna:39]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the second quarter and first six months of 2024 compared to the prior-year periods of 2023 was an unfavorable $2.9 million and $1.4 million, respectively. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses increased $1.7 million and $1.2 million, respectively, compared to the prior-year periods, primarily due to higher compensation and professional fees.

[0000038725-24-000143:mdna:40]
[same as prior period, unchanged from 0000038725-24-000078:mdna:38]

[0000038725-24-000143:mdna:41]
Interest expense was $2.0 million and $3.4 million in the second quarter and first six months of 2024, respectively, and $4.2 million and $7.3 million in the second quarter and first six months of 2023, respectively. The decreases in the second quarter and first six months of 2024 were primarily driven by lower debt.

[0000038725-24-000143:mdna:42]
[same as prior period, unchanged from 0000038725-24-000078:mdna:40]

[0000038725-24-000143:mdna:43]
Other income, net was $0.2 million and $0.9 million in the second quarter and first six months of 2024, respectively, and $1.2 million and $1.6 million in the second quarter and first six months of 2023, respectively. The decreases were primarily due to lower interest income.

[0000038725-24-000143:mdna:44]
[same as prior period, unchanged from 0000038725-24-000078:mdna:42]

[0000038725-24-000143:mdna:45]
Foreign currency-based transactions produced an expense of $0.4 million and $5.3 million in the second quarter and first six months of 2024, respectively, and an expense of $3.6 million and $5.6 million in the second quarter and first six months of 2023, respectively. The expense in 2024 was primarily due to transaction losses associated with the Argentine Peso and Turkish Lira relative to the U.S. dollar. The expense in 2023 was primarily due to transaction losses associated with the Turkish Lira, Argentine and Mexican Peso relative to the U.S. dollar. The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-24-000143:mdna:46]
[same as prior period, unchanged from 0000038725-24-000078:mdna:44]

[0000038725-24-000143:mdna:47]
The provision for income taxes in the second quarter and first six months of 2024 was $17.6 million and $26.8 million, respectively, and $14.2 million and $24.4 million in the second quarter and first six months of 2023, respectively. The effective tax rate for the second quarter and first six months of 2024 was 22.9 percent and 22.5 percent, respectively, and 19.1 percent and 20.0 percent in the second quarter and the first six months of 2023, respectively. The increase in the effective tax rates for the second quarter and first six months of 2024 compared to the comparable periods in the prior year was a result of less favorable discrete events in 2024, primarily related to excess tax benefits from share-based compensation, in addition to an increase in the rate on foreign earnings with the implementation of European Union’s Pillar Two Directive.

[0000038725-24-000143:mdna:48]
[same as prior period, unchanged from 0000038725-24-000078:mdna:46]

[0000038725-24-000143:mdna:49]
Net income in the second quarter and first six months of 2024 was $59.3 million and $92.4 million, respectively, and $60.2 million and $97.7 million in the second quarter and first six months of 2023, respectively. Net income attributable to Franklin Electric Co., Inc. in the second quarter and first six months of 2024 was $59.1 million and $92.1 million, respectively, or $1.26 and $1.97 per diluted share. Net income attributable to Franklin Electric Co., Inc. in the second quarter and first six months of 2023 was $59.6 million and $96.9 million, respectively, or $1.27 and $2.06 per diluted share.

[0000038725-24-000143:mdna:50]
[same as prior period, unchanged from 0000038725-24-000078:mdna:48]

[0000038725-24-000143:mdna:51]
[same as prior period, unchanged from 0000038725-24-000078:mdna:49]

[0000038725-24-000143:mdna:52]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at June 30, 2024 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-24-000143:mdna:53]
As of June 30, 2024, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of June 30, 2024, the Company had $305.5 million borrowing capacity under its credit agreement as $3.5 million in letters of commercial and standby letters of credit were outstanding and undrawn and $41.0 million in revolver borrowings were drawn and outstanding, which were primarily used for funding working capital requirements.

[0000038725-24-000143:mdna:54]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $200.0 million.  As of June 30, 2024, the remaining borrowing capacity on the New York Life Agreement was $175.0 million. The Company also maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates. On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million. The maturity dates of both agreements were extended from July 30, 2024 to May 15, 2027.

[0000038725-24-000143:mdna:55]
The Company also has other long-term debt borrowings outstanding as of June 30, 2024. See Note 10 - Debt included in the Company's Annual Report on Form 10-K for the year ended December 31, 2023, for additional information regarding these obligations and future maturities as well as Note 10 - Debt of this current quarterly report for changes to these agreements since December 31, 2023.

[0000038725-24-000143:mdna:56]
At June 30, 2024, the Company had $53.0 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate the majority of these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-24-000143:mdna:57]
[same as prior period, unchanged from 0000038725-24-000078:mdna:54]

[0000038725-24-000143:mdna:58]
The following table summarizes significant sources and uses of cash and cash equivalents for the first six months of 2024 and 2023.

[0000038725-24-000143:mdna:59]
| (in millions) |  | 2024 |  | 2023 |
| Net cash flows from operating activities |  | $ | 35.0 |  |  | $ | 43.0 |  |
| Net cash flows from investing activities |  | (20.2) |  |  | (26.9) |  |
| Net cash flows from financing activities |  | (38.7) |  |  | (5.4) |  |
| Impact of exchange rates on cash and cash equivalents |  | (3.0) |  |  | (3.3) |  |
| Change in cash and cash equivalents |  | $ | (26.9) |  |  | $ | 7.4 |  |

[0000038725-24-000143:mdna:60]
[same as prior period, unchanged from 0000038725-24-000078:mdna:57]

[0000038725-24-000143:mdna:61]
[same as prior period, unchanged from 0000038725-24-000078:mdna:58]

[0000038725-24-000143:mdna:62]
Net cash provided by operating activities was $35.0 million for the six months ended June 30, 2024 compared to $43.0 million provided by operating activities for the six months ended June 30, 2023. The change in operating cash flow was primarily due to lower earnings, partially offset by continued actions to improve working capital.

[0000038725-24-000143:mdna:63]
[same as prior period, unchanged from 0000038725-24-000078:mdna:60]

[0000038725-24-000143:mdna:64]
[same as prior period, unchanged from 0000038725-24-000078:mdna:61]

[0000038725-24-000143:mdna:65]
Net cash used in investing activities was $20.2 million for the six months ended June 30, 2024 compared to $26.9 million used in investing activities for the six months ended June 30, 2023. The change in investing cash flow was primarily attributable to decreased acquisition activity in the first six months of 2024.

[0000038725-24-000143:mdna:66]
[same as prior period, unchanged from 0000038725-24-000078:mdna:63]

[0000038725-24-000143:mdna:67]
[same as prior period, unchanged from 0000038725-24-000078:mdna:64]

[0000038725-24-000143:mdna:68]
Net cash used in financing activities was $38.7 million for the six months ended June 30, 2024 compared to $5.4 million used in financing activities for the six months ended June 30, 2023. The change in financing cash flow was primarily due to increased share repurchase activity and higher dividends in 2024 compared to 2023, partially offset by lower proceeds from option exercises and lower net borrowings under the Company's credit facility.

[0000038725-24-000143:mdna:69]
[same as prior period, unchanged from 0000038725-24-000078:mdna:66]
