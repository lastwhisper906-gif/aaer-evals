# FELE MD&A — 0000038725-22-000033


## mdna

[0000038725-22-000033:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-22-000033:mdna:2]
Discussion of the year-over-year comparison of changes in the Company's financial condition and results of operation as of and for the fiscal years ended December 31, 2020 and December 31, 2019 can be found in Part II, Item 7. "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our Annual Report on Form 10-K for the fiscal year ended December 31, 2020.

[0000038725-22-000033:mdna:3]
2021 vs. 2020

[0000038725-22-000033:mdna:4]
OVERVIEW

[0000038725-22-000033:mdna:5]
Sales in 2021 were up from the prior year. The sales increase was led by increases from volume, price, and acquisitions.  The impact of foreign currency translation decreased sales by less than 1 percent. The Company's consolidated gross profit was $576.1 million for 2021, an increase of $143.0 million or about 33 percent from 2020. The gross profit as a percent of net sales was changed at 34.7 percent in 2021 and 2020. For 2021, diluted earnings per share were $3.25, up from 2020 diluted earnings per share of $2.14.

[0000038725-22-000033:mdna:6]
RESULTS OF OPERATIONS

[0000038725-22-000033:mdna:7]
Net Sales

[0000038725-22-000033:mdna:8]
Net sales in 2021 were $1,661.9 million, an increase of $414.6 million or about 33 percent compared to 2020 sales of $1,247.3 million. The incremental impact of sales from acquired businesses was $149.8 million. Sales revenue decreased by $2.3 million or less than 1 percent in 2021 due to foreign currency translation. The sales change in 2021, excluding acquisitions and foreign currency translation, was an increase of about 21 percent. Revenue growth was from volume and price across all three segments.

[0000038725-22-000033:mdna:9]
|  | Net Sales |
| (In millions) | 2021 |  | 2020 |  | 2021 v 2020 |
| Water Systems | $ | 963.6 |  |  | $ | 734.7 |  |  | $ | 228.9 |  |
| Fueling Systems | 289.1 |  |  | 245.1 |  |  | 44.0 |  |
| Distribution | 497.6 |  |  | 328.4 |  |  | 169.2 |  |
| Eliminations/Other | (88.4) |  |  | (60.9) |  |  | (27.5) |  |
| Consolidated | $ | 1,661.9 |  |  | $ | 1,247.3 |  |  | $ | 414.6 |  |

[0000038725-22-000033:mdna:10]
Net Sales-Water Systems

[0000038725-22-000033:mdna:11]
Water Systems sales were $963.6 million in 2021, an increase of $228.9 million or about 31 percent versus 2020. The incremental impact of sales from acquired businesses was $96.7 million. Foreign currency translation changes decreased sales $4.5 million, or about 1 percent, compared to sales in 2020. The Water Systems sales change in 2021, excluding acquisitions and foreign currency translation, was an increase of $136.7 million or about 19 percent. Revenue growth was from volume and price driven by broad-based demand in all regions and product categories.

[0000038725-22-000033:mdna:12]
Water Systems sales in the U.S. and Canada increased by about 41 percent compared to 2020. The incremental impact of sales from acquired businesses was $94.3 million. Sales revenue increased by $4.0 million or about 1 percent in 2021 due to foreign currency translation. In 2021, sales of dewatering equipment increased by about 47 percent due to higher sales in rental channels and in oil production end markets. Sales of groundwater pumping equipment increased by 21 percent versus 2020. Sales of other surface pumping equipment increased by about 9 percent.

[0000038725-22-000033:mdna:13]
Water Systems sales in markets outside the U.S. and Canada increased by about 20 percent compared to 2020. The incremental impact of sales from acquired businesses was $2.4 million. Sales revenue decreased by $8.5 million or about 2 percent in 2021 due to foreign currency translation. Sales change in 2021, excluding acquisitions and foreign currency translation, was an increase of about 21 percent. Sales growth was in all geographic markets; Latin America, EMENA and Asia Pacific markets.

[0000038725-22-000033:mdna:14]
Net Sales-Fueling Systems

[0000038725-22-000033:mdna:15]
Fueling Systems sales were $289.1 million in 2021, an increase of $44.0 million or about 18 percent from 2020. Foreign currency translation changes increased sales $2.2 million or about 1 percent compared to sales in 2020. The Fueling Systems sales change in 2021, excluding foreign currency translation, was an increase of $41.8 million or about 17 percent. Revenue growth was from volume and price driven primarily by the U.S. and Canada regions.

[0000038725-22-000033:mdna:16]
Fueling Systems sales in the U.S. and Canada increased by about 25 percent during 2021. The growth was broad base across most product lines and due to higher demand from filling stations. Fueling Systems revenues outside the U.S and Canada increased by about 2 percent, driven by higher sales in India, Latin America and most regions in Asia Pacific, partially offset by lower sales in China.  China sales were about $12 million in 2021 compared to 2020 Fueling Systems China sales of about $18 million.

[0000038725-22-000033:mdna:17]
Net Sales-Distribution

[0000038725-22-000033:mdna:18]
Distribution sales were $497.6 million in 2021, versus 2020 sales of $328.4 million or about 52 percent from 2020. The incremental impact of sales from acquired businesses was $53.1 million.  Distribution segment organic sales increased $116.1 million or about 35 percent compared to 2020.   Revenue growth was from volume and price driven by broad-based demand in all regions and product categories.

[0000038725-22-000033:mdna:19]
Cost of Sales

[0000038725-22-000033:mdna:20]
Cost of sales as a percent of net sales for 2021 and 2020 was 65.3 percent for both years. Correspondingly, the gross profit margin was 34.7 percent, respectively. The Company's consolidated gross profit was $576.1 million for 2021, up $143.0 million from the gross profit of $433.1 million in 2020. The increase in gross profit and gross profit margin was primarily driven by price realization, favorable product and geographic sales mix shifts and cost management which were enough to offset inflation.

[0000038725-22-000033:mdna:21]
Selling, General and Administrative (“SG&A”)

[0000038725-22-000033:mdna:22]
Selling, general, and administrative expenses were $386.3 million in 2021 and increased by $86.2 million or 29 percent overall compared to $300.1 million last year. SG&A expenses from acquired businesses were $37.0 million, and excluding the acquired entities, the Company’s SG&A expenses in 2021 were $349.3 million, an increase of 16 percent from the prior year. SG&A expenses were higher versus the prior year due to higher variable performance-based compensation expenses and increased spending to support sales growth.

[0000038725-22-000033:mdna:23]
Restructuring Expenses

[0000038725-22-000033:mdna:24]
Restructuring expenses for 2021 were $0.6 million. Restructuring expenses were $0.5 million in the Water segment and $0.1 million in Distribution segments. Restructuring expenses in Water segment were primarily from Water Treatment realignment activities, and branch closings and consolidations in the Distribution segment. Restructuring expenses for 2020 were $2.5 million. Restructuring expenses were $2.3 million in the Water segment and $0.1 million in each of the Fueling and Distribution segments. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution segment.

[0000038725-22-000033:mdna:25]
Operating Income

[0000038725-22-000033:mdna:26]
Operating income was $189.2 million in 2021, up $58.7 million or 45 percent from $130.5 million in 2020.

[0000038725-22-000033:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | 2021 |  | 2020 |  | 2021 v 2020 |
| Water Systems |  | $ | 139.1 |  |  | $ | 114.4 |  |  | $ | 24.7 |  |
| Fueling Systems |  | 79.5 |  |  | 63.4 |  |  | 16.1 |  |
| Distribution |  | 35.9 |  |  | 11.5 |  |  | 24.4 |  |
| Eliminations/Other |  | (65.3) |  |  | (58.8) |  |  | (6.5) |  |
| Consolidated |  | $ | 189.2 |  |  | $ | 130.5 |  |  | $ | 58.7 |  |

[0000038725-22-000033:mdna:28]
Operating Income-Water Systems

[0000038725-22-000033:mdna:29]
Water Systems operating income was $139.1 million in 2021 compared to $114.4 million in 2020, an increase of 22 percent. The operating income margin was 14.4 percent compared to the 2020 operating income margin of 15.6 percent. Operating income increased in Water Systems primarily due to higher sales volumes.  Operating income margin decreased in Water Systems due to the dilution from Water Treatment at lower margins, higher inflation, and selling, general, and administrative costs not entirely offset by price realization.

[0000038725-22-000033:mdna:30]
Operating Income-Fueling Systems

[0000038725-22-000033:mdna:31]
Fueling Systems operating income was $79.5 million in 2021 compared to $63.4 million in 2020. The operating income margin was 27.5 percent compared to 25.9 percent of net sales in 2020. Operating income increased in Fueling Systems primarily due to higher sales volumes. The increase in margin was primarily due to leverage on higher sales volumes, favorable product, and geographic sales mix shifts.

[0000038725-22-000033:mdna:32]
Operating Income-Distribution

[0000038725-22-000033:mdna:33]
Distribution operating income was $35.9 million in 2021 and operating income margin was 7.2 percent. Distribution operating income was $11.5 million in 2020 and operating income margin was 3.5 percent. Operating income increased in Distribution due to higher sales volumes.  The increase in operating income margin was primarily due to revenue growth and operating leverage.

[0000038725-22-000033:mdna:34]
Operating Income-Eliminations/Other

[0000038725-22-000033:mdna:35]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses. The inter-segment profit elimination impact in 2021 on operating income was $0 million. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its third-party customer. Unallocated general and administrative expenses were higher by $6.5 million or about 11 percent to last year, primarily due to higher variable performance-based compensation expenses.

[0000038725-22-000033:mdna:36]
Interest Expense

[0000038725-22-000033:mdna:37]
Interest expense for 2021 and 2020 was $5.2 million and $4.6 million, respectively, and increased primarily as a result of higher debt levels.

[0000038725-22-000033:mdna:38]
Other Income or Expense

[0000038725-22-000033:mdna:39]
Other income or expense was a gain of $8.0 million and a loss of $0.8 million in 2021 and 2020, respectively.  Other income or expense in 2021 included a bargain purchase gain of $6.5 million and a gain of $2.5 million related to a settlement of an indirect tax dispute.

[0000038725-22-000033:mdna:40]
Foreign Exchange

[0000038725-22-000033:mdna:41]
Foreign currency–based transactions produced a loss for 2021 of $2.3 million, primarily due to changes in the value of the Argentinian Peso relative to the U.S. dollar. Foreign currency–based transactions produced a loss for 2020 of $1.4 million, primarily due to changes in the value of the Argentinian Peso relative to the U.S. dollar.

[0000038725-22-000033:mdna:42]
Income Taxes

[0000038725-22-000033:mdna:43]
The provision for income taxes in 2021 and 2020 was $34.8 million and $22.5 million, respectively. The effective tax rate for both 2021 and 2020 was about 18 percent and before the impact of discrete events was about 21 percent. The tax rate was lower than the statutory rate of 21 percent primarily due to the recognition of the U.S. deduction for Foreign Derived Intangible Income, and certain incentives and discrete events. Discrete events in 2021 include increased excess tax benefits from share-based compensation compared to 2020. Discrete events in 2020 include a benefit related to a realized foreign currency translation loss on the settlement of an intercompany loan.

[0000038725-22-000033:mdna:44]
Beginning in 2022, the Tax Cuts and Jobs Act of 2017 ("TCJA") eliminates the option to deduct research and development expenditures currently and requires taxpayers to amortize them over five years pursuant to IRC Section 174. Although Congress is considering legislation that would defer the amortization requirement to later years, we have no assurance that the provision will be repealed or otherwise modified. If the requirement is not modified, it will reduce our cash flows beginning in 2022 by an amount that is not significant.

[0000038725-22-000033:mdna:45]
Net Income

[0000038725-22-000033:mdna:46]
Net income for 2021 was $155.0 million compared to 2020 net income of $101.2 million. Net income attributable to Franklin Electric Co., Inc. for 2021 was $153.9 million, or $3.25 per diluted share, compared to 2020 net income attributable to Franklin Electric Co., Inc. of $100.5 million or $2.14 per diluted share.

[0000038725-22-000033:mdna:47]
CAPITAL RESOURCES AND LIQUIDITY

[0000038725-22-000033:mdna:48]
Sources of Liquidity

[0000038725-22-000033:mdna:49]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at December 31, 2021 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-22-000033:mdna:50]
As of December 31, 2021, the Company had a $250.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of December 31, 2021, the Company had $149.3 million borrowing capacity under the Credit Agreement as $4.1 million in letters of commercial and standby letters of credit were outstanding and undrawn and $96.6 million in revolver borrowings were drawn and outstanding, which were primarily used for funding recent acquisitions.

[0000038725-22-000033:mdna:51]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of $125.0 million as of December 31, 2021. The New York Life Agreement matures on July 30, 2024. The Company also has other long-term debt borrowings outstanding as of December 31, 2021. See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-22-000033:mdna:52]
At December 31, 2021, the Company had $37.4 million of cash and cash equivalents held in foreign jurisdictions, which the Company intends to use to fund foreign operations. There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-22-000033:mdna:53]
Cash Flows

[0000038725-22-000033:mdna:54]
The following table summarizes significant sources and uses of cash and cash equivalents:

[0000038725-22-000033:mdna:55]
| (in thousands) | 2021 |  | 2020 |  | 2019 |
| Cash flows from operating activities | $ | 129.8 |  |  | $ | 211.9 |  |  | $ | 177.7 |  |
| Cash flows from investing activities | $ | (264.8) |  |  | $ | (78.8) |  |  | $ | (41.8) |  |
| Cash flows from financing activities | $ | 50.9 |  |  | $ | (66.6) |  |  | $ | (126.7) |  |
| Impact of exchange rates on cash and cash equivalents | $ | (6.1) |  |  | $ | (0.1) |  |  | $ | (4.0) |  |
| Change in cash and cash equivalents | $ | (90.2) |  |  | $ | 66.4 |  |  | $ | 5.2 |  |

[0000038725-22-000033:mdna:56]
Cash Flows from Operating Activities

[0000038725-22-000033:mdna:57]
2021 vs 2020

[0000038725-22-000033:mdna:58]
Net cash provided by operating activities was $129.8 million for 2021 compared to $211.9 million for 2020. The decrease in cash provided by operating activities was primarily due to increased working capital requirements in support of higher revenues.

[0000038725-22-000033:mdna:59]
Cash Flows from Investing Activities

[0000038725-22-000033:mdna:60]
2021 vs. 2020

[0000038725-22-000033:mdna:61]
Net cash used in investing activities was $264.8 million in 2021 compared to $78.8 million in 2020. The increase was primarily attributable to increased acquisition activity in 2021.

[0000038725-22-000033:mdna:62]
Cash Flows from Financing Activities

[0000038725-22-000033:mdna:63]
2021 vs. 2020

[0000038725-22-000033:mdna:64]
Net cash provided by financing activities was $50.9 million in 2021 compared to $66.6 million used in financing activities in 2020. The increase in cash provided by financing activities was attributable to increased debt proceeds and issuance of common stock, primarily through stock option exercises, offset by increased dividend payments and common stock repurchases.

[0000038725-22-000033:mdna:65]
AGGREGATE CONTRACTUAL OBLIGATIONS

[0000038725-22-000033:mdna:66]
The majority of the Company’s contractual obligations to third parties relate to debt obligations. In addition, the Company has certain contractual obligations for future lease payments and purchase obligations. The payment schedule for these contractual obligations is as follows:

[0000038725-22-000033:mdna:67]
| (In millions) |  |  |  |  |  |  |  |  | More than |
|  | Total |  | 2022 |  | 2023-2024 |  | 2025-2026 |  | 5 years |
| Debt | $ | 188.7 |  |  | $ | 98.0 |  |  | $ | 2.7 |  |  | $ | 77.9 |  |  | $ | 10.1 |  |
| Debt interest | 18.5 |  |  | 5.0 |  |  | 7.8 |  |  | 4.4 |  |  | 1.3 |  |
| Operating leases | 52.4 |  |  | 16.4 |  |  | 20.6 |  |  | 9.2 |  |  | 6.2 |  |
| Purchase obligations | 13.2 |  |  | 13.2 |  |  | — |  |  | — |  |  | — |  |
| Income Taxes-U.S. Tax Cuts and Jobs Act transition tax | $ | 13.1 |  |  | $ | 1.5 |  |  | $ | 6.8 |  |  | $ | 4.8 |  |  | $ | — |  |
|  | $ | 285.9 |  |  | $ | 134.1 |  |  | $ | 37.9 |  |  | $ | 96.3 |  |  | $ | 17.6 |  |

[0000038725-22-000033:mdna:68]
The Company has pension and other post-retirement benefit obligations not included in the table above which will result in estimated future payments of approximately $0.9 million in 2022. The Company also has unrecognized tax benefits, none of which are included in the table above. The unrecognized tax benefits of approximately $0.9 million have been recorded as liabilities and the Company is uncertain as to if or when such amounts may be settled. Related to the unrecognized tax benefits, the Company has also recorded a liability for potential penalties and interest of $0.1 million.

[0000038725-22-000033:mdna:69]
ACCOUNTING PRONOUNCEMENTS

[0000038725-22-000033:mdna:70]
For information regarding recent accounting pronouncements, refer to Note 2 - Accounting Pronouncements, in the Notes to Consolidated Financial Statements in the sections entitled ""Adoption of New Accounting Standards" and "Accounting Standards Issued But Not Yet Adopted", included in Part II, Item 8, "Financial Statements and Supplementary Data" of this Annual Report on Form 10-K.

[0000038725-22-000033:mdna:71]
CRITICAL ACCOUNTING ESTIMATES

[0000038725-22-000033:mdna:72]
Management’s discussion and analysis of its financial condition and results of operations are based upon the Company’s consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires management to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and the related disclosure of contingent assets and liabilities. Management evaluates estimates on an ongoing basis. Estimates are based on historical experience and on other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. There were no material changes to estimates or methodologies used to develop those estimates in 2021. The Company’s critical accounting estimates are identified below:

[0000038725-22-000033:mdna:73]
Inventory Valuation

[0000038725-22-000033:mdna:74]
The Company uses certain estimates and judgments to value inventory. Inventory is recorded at the lower of cost or market. The Company reviews its inventories for excess or obsolete products or components. Based on an analysis of historical usage, management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts, carrying values are adjusted. The carrying value is reduced regularly to reflect the age and current anticipated product demand. If actual demand differs from the estimates, additional reductions would be necessary in the period such determination is made. Excess and obsolete inventory is periodically disposed of through sale to third parties, scrapping, or other means.

[0000038725-22-000033:mdna:75]
Business Combinations and Valuation of Acquired Intangible Assets

[0000038725-22-000033:mdna:76]
The Company follows the guidance under FASB Accounting Standards Codification (“ASC”) Topic 805, Business Combinations. The acquisition purchase price is allocated to the assets acquired and liabilities assumed based upon their respective fair values. The Company utilizes management estimates and an independent third-party valuation firm to assist in determining the fair values of assets acquired, including intangible assets, and liabilities assumed. The primary intangible assets acquired typically include customer relationships and trade names. Intangible assets are initially valued using a methodology commensurate with the intended use of the asset. The fair value of customer relationships is measured using the multi-period excess earnings method ("MPEEM"). The fair value of trade names is measured using a relief-from-royalty ("RFR") approach, which assumes the value of the trade name is the discounted amount of cash flows that would be paid to third parties had the Company not owned the trade name and instead licensed the trade name from another company. Higher royalty rates are assigned to premium brands within the marketplace based on name recognition and profitability, while other brands receive lower royalty rates. The basis for future sales projections for both the RFR and MPEEM are based on internal revenue forecasts which the Company believes represents reasonable market participant assumptions. The future cash flows are discounted using an applicable discount rate as well as any potential risk premium to reflect the inherent risk of holding a standalone intangible asset.  The key uncertainties in the RFR and MPEEM calculations, as applicable, are the selection of an appropriate royalty rate, assumptions used in developing estimates of future cash flows, including revenue growth and expense forecasts, assumed customer attrition rates, as well as the perceived risk associated with those forecasts in determining the discount rate and risk premium.  There is inherent uncertainty in forecasted future cash flows and therefore, actual results may differ and could result in subsequent impairment charges of acquired intangibles and/or goodwill.

[0000038725-22-000033:mdna:77]
Indefinite-Lived Intangible Asset and Goodwill Impairment Evaluation

[0000038725-22-000033:mdna:78]
According to FASB ASC Topic 350, Intangibles - Goodwill and Other, intangible assets with indefinite lives must be tested for impairment at least annually or more frequently as warranted by triggering events that indicate potential impairment. The Company uses a variety of methodologies in conducting impairment assessments including income and market approaches. For indefinite-lived assets apart from goodwill, primarily trade names for the Company, if the fair value is less than the carrying amount, an impairment charge is recognized in an amount equal to that excess. The Company has not made any material changes to the method of evaluating impairments during the last three years.

[0000038725-22-000033:mdna:79]
In compliance with FASB ASC Topic 350, goodwill is not amortized. Goodwill is tested at the reporting unit level for impairment annually or more frequently as warranted by triggering events that indicate potential impairment. Reporting units are operating segments or one level below, known as components, which can be aggregated for testing purposes. The Company’s goodwill is allocated to the Global Water Systems, Fueling Systems and Distribution reporting units. As the Company’s business model evolves, management will continue to evaluate its reporting units and review the aggregation criteria.

[0000038725-22-000033:mdna:80]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the market value and income approaches. The market value approach compares the reporting units’ current and projected financial results to entities of similar size and industry to determine the market value of the reporting unit. The income approach utilizes assumptions regarding estimated future cash flows and other factors to determine the fair value of the respective assets. These cash flows consider factors regarding expected future operating income and historical trends, as well as the effects of demand and competition. The Company may be required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units is below their associated carrying values. Goodwill included on the balance sheet as of the fiscal year ended 2021 was $329.6 million.

[0000038725-22-000033:mdna:81]
During the fourth quarter of 2021, the Company completed its annual impairment test of goodwill and trade names and determined the fair value of all intangibles were substantially in excess of the respective carrying values. Significant judgment is required to determine if an indication of impairment has taken place. Factors to be considered include the following: adverse changes in operating results, decline in strategic business plans, significantly lower future cash flows, and sustainable declines in market data such as market capitalization. A 10 percent decrease in the fair value estimates used in the impairment test would not have changed this determination. The sensitivity analysis required the use of numerous subjective assumptions, which, if actual experience varies, could result in material differences in the requirements for impairment charges. Further, an extended downturn in the economy may impact certain components of the operating segments more significantly and could result in changes to the aggregation assumptions and impairment determination.

[0000038725-22-000033:mdna:82]
Income Taxes

[0000038725-22-000033:mdna:83]
Under the requirements of FASB ASC Topic 740, Income Taxes, the Company records deferred tax assets and liabilities for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company analyzes the deferred tax assets and liabilities for their future realization based on the estimated existence of sufficient taxable income. This analysis considers the following sources of taxable income: prior year taxable income, future reversals of existing taxable temporary differences, future taxable income exclusive of reversing temporary differences and tax planning strategies that would generate taxable income in the relevant period. If sufficient taxable income is not projected then the Company will record a valuation allowance against the relevant deferred tax assets.

[0000038725-22-000033:mdna:84]
The Company’s operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions. These jurisdictions have different tax rates, and the Company determines the allocation of income to each of these jurisdictions based upon various estimates and assumptions. In the normal course of business, the Company will undergo tax audits by various tax jurisdictions. Such audits often require an extended period of time to complete and may result in income tax adjustments if changes to the allocation are required between jurisdictions with different tax rates. The final taxes paid are dependent upon many factors, including negotiations with taxing authorities in the various jurisdictions and resolution of disputes arising from federal, state, and international tax audits. Although the Company has recorded all income tax uncertainties in accordance with FASB ASC Topic 740, these accruals represent estimates that are subject to the inherent uncertainties associated with the tax audit process, and therefore include uncertainties. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, which, if actual experience varies, could result in material adjustments to tax expense and/or deferred tax assets and liabilities.

[0000038725-22-000033:mdna:85]
Pension and Employee Benefit Obligations

[0000038725-22-000033:mdna:86]
The Company consults with its actuaries to assist with the calculation of discount rates used in its pension and post retirement plans. The discount rates used to determine domestic pension and post-retirement plan liabilities are calculated using a full yield curve approach. Market conditions have caused the weighted-average discount rate to move from 2.31 percent last year to 2.68 percent this year for the domestic pension plans and from 2.12 percent last year to 2.57 percent this year for the postretirement health and life insurance plan. A change in the discount rate selected by the Company of 25 basis points would result in a change of about $0.1 million to employee benefit expense and a change of about $4.3 million of liability.

[0000038725-22-000033:mdna:87]
The Company consults with actuaries and investment advisors in making its determination of the expected long-term rate of return on plan assets. Using input from these consultations such as long-term investment sector expected returns, the correlations and standard deviations thereof, and the plan asset allocation, the Company has assumed an expected long-term rate of return on plan assets of 4.50 percent as of the fiscal year ended  2021. Market conditions have caused the expected long-term rate of return to increase from 4.00 percent as of the fiscal year ended 2020. A change in the long-term rate of return selected by the Company of 25 basis points would result in a change of about $0.4 million of employee benefit expense.

[0000038725-22-000033:mdna:88]
FACTORS THAT MAY AFFECT FUTURE RESULTS
