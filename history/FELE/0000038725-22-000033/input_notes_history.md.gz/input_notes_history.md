# FELE note change history — 0000038725-21-000175 → 0000038725-21-000210


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0000038725-21-000210:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. The subject-matter expert has issued its preliminary report, which indicates that total damages incurred by Esso amounted to approximately 12 million euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company has retained experts to demonstrate that its products did not cause the damage, and in January 2021, submitted its response to the expert’s preliminary report for each station. The expert's response to the Company's report is due to the Court in June 2022. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position,  results of operations, or cash flows.
  (was, 2021-08-03, similarity 0.9724):
[0000038725-21-000175:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. The subject-matter expert has issued their preliminary report, which indicates that total damages incurred by Esso amounted to approximately 12 million euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company has retained experts to demonstrate that its products did not cause the damage, and in January 2021, submitted its response to the expert’s preliminary report for each station. The expert's response to the Company's report is due to the Court in June 2022. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s results of operations.

- changed (2021-11-02):
[0000038725-21-000210:note_history:2]
At September 30, 2021, the Company had $14.1 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2021-08-03, similarity 0.9625):
[0000038725-21-000175:note_history:2]
At June 30, 2021, the Company had $7.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2021-11-02):
[0000038725-21-000210:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2021, are as follows:
  (was, 2021-08-03, similarity 0.9582):
[0000038725-21-000175:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2021, are as follows:

- changed (2021-11-02):
[0000038725-21-000210:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2020 |  | $ | 9.7 |  |
| Accruals related to product warranties |  | 7.0 |  |
| Additions related to acquisitions |  | 0.1 |  |
| Reductions for payments made |  | (6.5) |  |
| Balance as of September 30, 2021 |  | $ | 10.3 |  |
  (was, 2021-08-03, similarity 0.9695):
[0000038725-21-000175:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2020 |  | $ | 9.7 |  |
| Accruals related to product warranties |  | 6.5 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (6.4) |  |
| Balance as of June 30, 2021 |  | $ | 9.8 |  |

- changed (2021-11-02):
[0000038725-21-000210:note_history:5]
The components of the Company’s operating lease portfolio as of the third quarter and nine months ended September 30, 2021 are as follows:
  (was, 2021-08-03, similarity 0.9042):
[0000038725-21-000175:note_history:5]
The components of the Company’s operating lease portfolio as of the second quarter and six months ended June 30, 2021 are as follows:

- changed (2021-11-02):
[0000038725-21-000210:note_history:6]
| Lease Cost (in millions): | Third Quarter Ended |  | Nine Months Ended |
| Operating lease cost | $ | 3.5 |  |  | $ | 9.2 |  |
| Short-term lease cost | 0.1 |  |  | 0.5 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4.1 years |
| Weighted-average discount rate |  |  | 4.1 | % |
  (was, 2021-08-03, similarity 0.9726):
[0000038725-21-000175:note_history:6]
| Lease Cost (in millions): | Second Quarter Ended |  | Six Months Ended |
| Operating lease cost | $ | 2.7 |  |  | $ | 5.7 |  |
| Short-term lease cost | 0.1 |  |  | 0.4 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4.1 years |
| Weighted-average discount rate |  |  | 4.0 | % |

- changed (2021-11-02):
[0000038725-21-000210:note_history:7]
The minimum rental payments for non-cancellable operating leases as of September 30, 2021, are as follows:
  (was, 2021-08-03, similarity 0.9436):
[0000038725-21-000175:note_history:7]
The minimum rental payments for non-cancellable operating leases as of June 30, 2021, are as follows:

- removed (2021-11-02):
[0000038725-21-000175:note_history:8]
As of June 30, 2021, the Company has approximately $2.5 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0000038725-21-000210:note_history:9]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2020, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2021, and for the third quarters and nine months ended September 30, 2021 and September 30, 2020 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2021. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2020.
  (was, 2021-08-03, similarity 0.9345):
[0000038725-21-000175:note_history:9]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2020, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2021, and for the second quarters and six months ended June 30, 2021 and June 30, 2020 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2021. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2020.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0000038725-21-000210:note_history:10]
| (In millions) |  | September 30, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 105.0 |  |  | — |  |
| Tax increment financing debt |  | 16.5 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 0.6 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.3) |  |  | (0.1) |  |
|  |  | $ | 196.8 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (106.3) |  |  | (2.6) |  |
| Long-term debt |  | $ | 90.5 |  |  | 92.0 |
  (was, 2021-08-03, similarity 0.9859):
[0000038725-21-000175:note_history:10]
| (In millions) |  | June 30, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 130.0 |  |  | — |  |
| Tax increment financing debt |  | 17.1 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.7 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 223.7 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (132.4) |  |  | (2.6) |  |
| Long-term debt |  | $ | 91.3 |  |  | 92.0 |

- changed (2021-11-02):
[0000038725-21-000210:note_history:11]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2021 matures as follows:
  (was, 2021-08-03, similarity 0.9418):
[0000038725-21-000175:note_history:11]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2021 matures as follows:

- added (2021-11-02):
[0000038725-21-000210:note_history:12]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates, which was renewed on July 30, 2021 and expires on July 30, 2024.  The Prudential Agreement has an initial borrowing capacity of $150.0 million. As of September 30, 2021, the Company had no notes issued and  $150.0 million borrowing capacity available under the Prudential Agreement.

- added (2021-11-02):
[0000038725-21-000210:note_history:13]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC and its affiliates (the "New York Life Agreement"), which was renewed on July 30, 2021 and expires on July 30, 2024. The New York Life Agreement has a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2021, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

- changed (2021-11-02):
[0000038725-21-000210:note_history:14]
The Company maintains the Fourth Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement was renewed on May 13, 2021, has a maturity date of May 13, 2026, and commitment amount of $250.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million subject to agreement of the lenders (not to exceed a total commitment of $375.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based
  (was, 2021-08-03, similarity 0.8978):
[0000038725-21-000175:note_history:14]
The Company maintains the Fourth Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement was renewed on May 13, 2021, has a maturity date of May 13, 2026, and commitment amount of $250.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million subject to agreement of the lenders (not to exceed a total commitment of $375.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.85% to 1.88% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

- added (2021-11-02):
[0000038725-21-000210:note_history:15]
on LIBOR plus an applicable margin of 0.85% to 1.88% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

- changed (2021-11-02):
[0000038725-21-000210:note_history:16]
As of September 30, 2021, the Company had $105.0 million outstanding borrowings, $4.1 million in letters of credit outstanding, and $140.9 million of available capacity under the Credit Agreement.
  (was, 2021-08-03, similarity 0.969):
[0000038725-21-000175:note_history:16]
As of June 30, 2021, the Company had $130.0 million outstanding borrowings, $4.0 million in letters of credit outstanding, and $116.0 million of available capacity under the Credit Agreement.

- added (2021-11-02):
[0000038725-21-000210:note_history:17]
Covenants

- changed (2021-11-02):
[0000038725-21-000210:note_history:18]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of September 30, 2021.
  (was, 2021-08-03, similarity 0.9903):
[0000038725-21-000175:note_history:18]
Covenants 
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2021.

- removed (2021-11-02):
[0000038725-21-000175:note_history:19]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million. As of June 30, 2021, the Company had no notes issued and  $150.0 million borrowing capacity available under the Prudential Agreement.

- removed (2021-11-02):
[0000038725-21-000175:note_history:20]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of June 30, 2021, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0000038725-21-000210:note_history:21]
| (In millions) |  | September 30, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 105.0 |  |  | — |  |
| Tax increment financing debt |  | 16.5 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 0.6 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.3) |  |  | (0.1) |  |
|  |  | $ | 196.8 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (106.3) |  |  | (2.6) |  |
| Long-term debt |  | $ | 90.5 |  |  | 92.0 |
  (was, 2021-08-03, similarity 0.9859):
[0000038725-21-000175:note_history:21]
| (In millions) |  | June 30, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 130.0 |  |  | — |  |
| Tax increment financing debt |  | 17.1 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.7 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 223.7 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (132.4) |  |  | (2.6) |  |
| Long-term debt |  | $ | 91.3 |  |  | 92.0 |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0000038725-21-000210:note_history:22]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2021 matures as follows:
  (was, 2021-08-03, similarity 0.9418):
[0000038725-21-000175:note_history:22]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2021 matures as follows:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-11-02):
[0000038725-21-000175:note_history:23]
SUBSEQUENT EVENT
Amended and Restated Note Purchase and Private Shelf Agreement - NYL Shelf Agreement

- removed (2021-11-02):
[0000038725-21-000175:note_history:24]
On July 30, 2021, Franklin Electric Co., Inc. and Franklin Electric B.V. ("Dutch Subsidiary Issuer") entered into a new unsecured $200.0 million uncommitted maximum aggregate principal amount private shelf facility for a period of up to 3 years pursuant to that certain Amended and Restated Note Purchase and Private Shelf Agreement with NYL Investors LLC, New York Life Insurance Company and New York Life Insurance and Annuity Corporation (collectively, “New York Life”) dated as of July 30, 2021 (the “NYL Shelf Agreement”). Subject to the terms and conditions set forth therein, the NYL Shelf Agreement allows the Company to issue senior promissory notes to New York Life at floating or fixed rate economic terms to be agreed upon at the time of issuance, from time to time during a three year issuance period ending July 30, 2024.

- removed (2021-11-02):
[0000038725-21-000175:note_history:25]
The minimum principal amount of the private shelf note that can be issued under the NYL Shelf Agreement is $5.0 million with an issuance fee of 0.10% of the aggregate principal amount of the issued shelf note, payable on the date of issuance in Dollars. The NYL Shelf Agreement also provides for other fees, including a varying leverage fee payable for periods during which the ratio of the Company’s consolidated total debt to earnings before interest, taxes, depreciation and amortization is equal to or greater than 2.00 to 1.00.

- removed (2021-11-02):
[0000038725-21-000175:note_history:26]
The term of each note issuance under the NYL Shelf Agreement will be selected by the Company and will not exceed 12 years for fixed rate notes and 10 years for floating rate notes. The proceeds of any issuance under the NYL Shelf Agreement will be used as set forth in the applicable Request for Purchase.

- removed (2021-11-02):
[0000038725-21-000175:note_history:27]
The NYL Shelf Agreement has customary affirmative and negative covenants for agreements of these types. The affirmative covenants include delivery of financial statements, permitting of inspections of the property of the Company and its subsidiaries, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans or advances, acquisitions (including investments), and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Under specific acquisition factors, the maximum leverage ratio can increase to 4.00 to 1.00 for up to four consecutive Fiscal Quarters. Cross default is applicable with the NYL Shelf Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million. The NYL Shelf Agreement also contains customary events of default (with customary grace periods, as applicable, for certain of those events of default). If an event of default occurs, all payment obligations under the private shelf notes outstanding plus a yield maintenance amount (if any) may be declared due and payable. For certain events of default relating to insolvency, bankruptcy or liquidation, all payment obligations under outstanding private shelf notes plus a yield maintenance amount (if any) automatically become due and payable. The covenants in the NYL Shelf Agreement are subject to a number of important exceptions and qualifications set forth therein.

- removed (2021-11-02):
[0000038725-21-000175:note_history:28]
All notes issued under the NYL Shelf Agreement are unsecured and rank pari passu in right of payment with the Company’s other senior unsecured indebtedness. The payment of outstanding amounts due under any notes and the performance by the Company of its obligations under the NYL Shelf Agreement have been guaranteed by certain wholly-owned U.S. subsidiaries of the Company.

- removed (2021-11-02):
[0000038725-21-000175:note_history:29]
The description of the NYL Shelf Agreement contained herein is qualified in its entirety by reference to the NYL Shelf Agreement, a copy of which is filed hereto as Exhibit 10.5.

- removed (2021-11-02):
[0000038725-21-000175:note_history:30]
Fourth Amended and Restated Note Purchase and Private Shelf Agreement - Pru Shelf Agreement

- removed (2021-11-02):
[0000038725-21-000175:note_history:31]
Also on July 30, 2021, Franklin Electric Co., Inc. and Franklin Electric B.V. ("Dutch Subsidiary Issuer") entered into an unsecured $150.0 million uncommitted maximum aggregate principal amount private shelf facility for a period of up to 3 years pursuant to that certain Fourth Amended and Restated Note Purchase and Private Shelf Agreement, dated as of July 30, 2021, with Prudential Investment Management, Inc. (“Prudential”) and the purchasers named therein (the “Pru Shelf Agreement”). The Pru Shelf Agreement amended and restated the Third Amended and Restated Note Purchase and Private Shelf Agreement, dated as of May 28, 2015, between the Company and Prudential and the purchasers named therein (the “Existing 2015 Shelf Agreement”) and amended and restated the Existing 2004 Shelf Agreement and the Series B-1 Notes and Series B-2 Notes (collectively, the "Series B Notes"). The Series B Notes that were issued under the 2004 Shelf Agreement that were outstanding under the Existing 2015 Shelf Agreement in the original principal amount of $150.0 million became outstanding under the Pru Shelf Agreement. The minimum principal amount of the private shelf note that can be issued under the Pru Shelf Agreement is $5.0 million payable on the date of issuance. The Pru Shelf Agreement also provides for other fees,

- removed (2021-11-02):
[0000038725-21-000175:note_history:32]
including a varying leverage fee payable for periods during which the ratio of the Company’s consolidated total debt to earnings before interest, taxes, depreciation and amortization is equal to or greater than 2.00 to 1.00.

- removed (2021-11-02):
[0000038725-21-000175:note_history:33]
Any private shelf note issued under the Pru Shelf Agreement during the issuance period may have a maturity of up to 15 years, provided that the average life for each private shelf note issued is no more than 12 years after the date of original issuance. The private shelf notes may be issued in U.S. dollars or in the equivalent thereof at the time of issuance in British Pounds and Euros. The proceeds of any issuance under the Pru Shelf Agreement will be used for general corporate purposes, including the repayment of existing indebtedness.

- removed (2021-11-02):
[0000038725-21-000175:note_history:34]
The Pru Shelf Agreement has customary affirmative and negative covenants for agreements of these types. The affirmative covenants include delivery of financial statements, permitting of inspections of the property of the Company and its subsidiaries, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans or advances, acquisitions (including investments), and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Under specific acquisition factors, the maximum leverage ratio can increase to 4.00 to 1.00 for up to four consecutive Fiscal Quarters. Cross default is applicable with the Pru Shelf Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million. The Pru Shelf Agreement also contains customary events of default (with customary grace periods, as applicable, for certain of those events of default). If an event of default occurs, all payment obligations under the private shelf notes outstanding plus a yield maintenance amount (if any) may be declared due and payable. For certain events of default relating to insolvency, bankruptcy or liquidation, all payment obligations under outstanding private shelf notes plus a yield maintenance amount (if any) automatically become due and payable. The covenants in the Pru Shelf Agreement are subject to a number of important exceptions and qualifications set forth therein.

- removed (2021-11-02):
[0000038725-21-000175:note_history:35]
All notes issued under the Pru Shelf Agreement are unsecured and rank pari passu in right of payment with the Company’s other senior unsecured indebtedness. The payment of outstanding amounts due under any notes and the performance by the Company of its obligations under the Pru Shelf Agreement have been guaranteed by certain wholly-owned U.S. subsidiaries of the Company.

- removed (2021-11-02):
[0000038725-21-000175:note_history:36]
The description of the Pru Shelf Agreement contained herein is qualified in its entirety by reference to the Pru Shelf Agreement, a copy of which is filed hereto as Exhibit 10.6.
