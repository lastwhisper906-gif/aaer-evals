# FELE 8-K — 0000038725-22-000007 filed 2022-02-15

## item codes, every 8-K on or before 2022-02-25

- 2022-02-15 0000038725-22-000007 — 2.02, 9.01
- 2022-01-04 0000038725-22-000002 — 7.01, 9.01
- 2021-11-03 0000038725-21-000212 — 7.01, 9.01
- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2022-02-25

- none on or before 2022-02-25

## item 2.02 — earnings release, exhibit 99.1

[0000038725-22-000007:8k_2_02:1]
EX-99.1
2
a202202158-kexhibit991.htm
EX-99.1

[0000038725-22-000007:8k_2_02:2]
Document

[0000038725-22-000007:8k_2_02:3]
Exhibit 99.1

[0000038725-22-000007:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-22-000007:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS RECORD FOURTH QUARTER 2021 AND RECORD FULL YEAR 2021 RESULTS

[0000038725-22-000007:8k_2_02:6]
Fourth Quarter 2021 Highlights

[0000038725-22-000007:8k_2_02:7]
•Record sales of $432.5 million, compared to fourth quarter 2020 sales of $321.1 million, an increase of 35%

[0000038725-22-000007:8k_2_02:8]
•Strong organic sales growth in all three Segments; Distribution 39%, Water Systems 23%, and Fueling Systems 21%

[0000038725-22-000007:8k_2_02:9]
•Operating income was a record at $47.2 million, compared to fourth quarter operating income in 2020 of $34.4 million, an increase of 37%

[0000038725-22-000007:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $0.85, a new record for any fourth quarter

[0000038725-22-000007:8k_2_02:11]
•Working capital as a percentage of trailing twelve months sales improved 70 basis points to 26.9%

[0000038725-22-000007:8k_2_02:12]
Full Year 2021 Highlights

[0000038725-22-000007:8k_2_02:13]
•Full Year 2021 sales of $1,661.9 million, a record compared to 2020 sales of $1,247.3 million, an increase of 33%

[0000038725-22-000007:8k_2_02:14]
•Operating income for 2021 was a record at $189.2 million, compared to operating income in 2020 of $130.5 million, an increase of 45%

[0000038725-22-000007:8k_2_02:15]
•GAAP fully diluted earnings per share (EPS) of $3.25, an increase of 52% from prior year

[0000038725-22-000007:8k_2_02:16]
Fort Wayne, IN – February 15, 2021 – Franklin Electric Co. Inc. today announced fourth quarter and full year financial results for fiscal year 2021.

[0000038725-22-000007:8k_2_02:17]
Fourth quarter 2021 sales were $432.5 million, compared to fourth quarter 2020 sales of $321.1 million.  Fourth quarter 2021 operating income was $47.2 million, compared to fourth quarter operating income in 2020 of $34.4 million, an increase of 37 percent.

[0000038725-22-000007:8k_2_02:18]
Fourth quarter 2021 GAAP fully diluted earnings per share (EPS) was $0.85, versus GAAP fully diluted EPS in the fourth quarter 2020 of $0.57.  The Company’s fourth quarter 2021 results included a $6.5 million one-time income gain on a bargain purchase price transaction on the income statement in the ‘Other Income/Expense’ section. Although it is not the Company’s practice to note items as non-GAAP adjustments in reported results, we are mentioning this gain due to its size and since the Company does not consider it to be operational in nature.

[0000038725-22-000007:8k_2_02:19]
Full year 2021 sales were $1,661.9 million, compared to full year 2020 sales of $1,247.3 million.  Full year 2021 operating income was $189.2 million, compared to full year operating income in 2020 of $130.5 million, an increase of 45 percent.

[0000038725-22-000007:8k_2_02:20]
Full year 2021 GAAP fully diluted earnings per share (EPS) was $3.25, versus GAAP fully diluted EPS in 2020 of $2.14.

[0000038725-22-000007:8k_2_02:21]
“Finishing the year on a high note, we once again delivered record fourth quarter sales and earnings results. We saw strong demand across all business segments, with exceptional performance in our Distribution business which posted year-over-year sales growth of 50 percent, and Water Systems and

[0000038725-22-000007:8k_2_02:22]
Fueling Systems delivering sales growth of 36 percent and 21 percent, respectively. We also continued to execute our inorganic growth strategy through our acquisitions of a leading groundwater distribution company covering the Northeastern United States and a water treatment business based in the Southwest, which we believe have ample runway for growth,” commented Gregg Sengstack, Franklin Electric’s Chairperson and Chief Executive Officer.

[0000038725-22-000007:8k_2_02:23]
“2021 was a pivotal year for our business, as we delivered record-breaking results, further extended our geographic footprint and enhanced our product offerings. While supply chain challenges have continued, we believe they have stabilized, and we enter 2022 on strong footing with robust demand across our end markets. As the innovation leader in water systems, distribution, and fueling, Franklin is positioned for growth to meet rapidly accelerating clean water demand worldwide, as well as to address increasing environmental and sustainability concerns around both water and fueling,” concluded Mr. Sengstack.

[0000038725-22-000007:8k_2_02:24]
Segment Summaries

[0000038725-22-000007:8k_2_02:25]
Water Systems sales, a new record for any fourth quarter, were $258.0 million in the fourth quarter 2021, an increase of $68.7 million or 36 percent versus the fourth quarter 2020. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 23 percent compared to the fourth quarter 2020.  Sales of groundwater pumping equipment and sales of both surface pumping and dewatering equipment increased due to strong end market demand.  Water Systems operating income in the fourth quarter was $36.4 million driven by higher sales.  Fourth quarter 2020 Water Systems operating income was $30.4 million.

[0000038725-22-000007:8k_2_02:26]
Distribution sales, a new record for any fourth quarter, were $116.9 million in the fourth quarter 2021.  The Distribution segment organic sales increased 39 percent compared to the fourth quarter of 2020.  Revenue growth was driven by broad-based demand in all regions and product categories in addition to the growth from acquisition. The Distribution segment operating income was $5.6 million in the fourth quarter of 2021 compared to fourth quarter 2020 operating income of $0.5 million.

[0000038725-22-000007:8k_2_02:27]
Fueling Systems sales, a new record for any fourth quarter, were $79.0 million in the fourth quarter 2021, an increase of $13.5 million versus the fourth quarter 2020. Fueling Systems sales in the U.S. and Canada increased by about 30 percent compared to the fourth quarter 2020. The increase was due to higher demand for Fuel Management and Pumping Systems and Piping. Outside the U.S. and Canada, Fueling Systems revenues were flat, as sales increases of 2 percent in the rest of the world outside of China were offset by lower sales in China. Fueling Systems operating income in the fourth quarter was $22.2 million, compared to $18.8 million in the fourth quarter of 2020.

[0000038725-22-000007:8k_2_02:28]
Cash Flow

[0000038725-22-000007:8k_2_02:29]
Net cash flows from operating activities for 2021 were $129.8 million versus $211.9 million in the same period in 2020. The decrease was primarily due to higher working capital requirements in support of higher revenues.

[0000038725-22-000007:8k_2_02:30]
2022 Guidance

[0000038725-22-000007:8k_2_02:31]
The Company expects its full year 2022 sales to be in the range of $1.90 billion to $2.05 billion and full year 2022 earnings per share before restructuring expenses to be in the range from $3.50 to $3.75.

[0000038725-22-000007:8k_2_02:32]
Earnings Conference Call

[0000038725-22-000007:8k_2_02:33]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The fourth quarter and fiscal year 2021 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-22-000007:8k_2_02:34]
https://edge.media-server.com/mmc/p/zo5q3gcj

[0000038725-22-000007:8k_2_02:35]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls. The conference ID is 6963617.

[0000038725-22-000007:8k_2_02:36]
A replay of the conference call will be available Tuesday, February 15, 2022, at 12:00 noon ET through noon ET on Tuesday, February 22, 2022, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls. The replay passcode is 6963617.

[0000038725-22-000007:8k_2_02:37]
Forward Looking Statements

[0000038725-22-000007:8k_2_02:38]
About Franklin Electric

[0000038725-22-000007:8k_2_02:39]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-22-000007:8k_2_02:40]
Franklin Electric Contact:

[0000038725-22-000007:8k_2_02:41]
Jeffery L. Taylor

[0000038725-22-000007:8k_2_02:42]
Franklin Electric Co., Inc.

[0000038725-22-000007:8k_2_02:43]
260-824-2900

[0000038725-22-000007:8k_2_02:44]
Email: jeffery.taylor@fele.com

[0000038725-22-000007:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |  |
|  | Fourth Quarter Ended |  |  | Fiscal Year End |
|  | December 31, 2021 |  | December 31, 2020 |  |  | December 31, 2021 |  | December 31, 2020 |
| Net sales | $ | 432,520 |  |  | $ | 321,106 |  |  |  | $ | 1,661,865 |  |  | $ | 1,247,331 |  |
| Cost of sales | 287,332 |  |  | 209,703 |  |  |  | 1,085,776 |  |  | 814,192 |  |
| Gross profit | 145,188 |  |  | 111,403 |  |  |  | 576,089 |  |  | 433,139 |  |
| Selling, general, and administrative expenses | 97,741 |  |  | 76,713 |  |  |  | 386,275 |  |  | 300,122 |  |
| Restructuring expense | 240 |  |  | 317 |  |  |  | 621 |  |  | 2,506 |  |
| Operating income | 47,207 |  |  | 34,373 |  |  |  | 189,193 |  |  | 130,511 |  |
| Interest expense | (1,356) |  |  | (1,131) |  |  |  | (5,196) |  |  | (4,627) |  |
| Other income/(expense), net | 6,447 |  |  | 267 |  |  |  | 7,978 |  |  | (795) |  |
| Foreign exchange income/(expense) | (615) |  |  | (1,308) |  |  |  | (2,269) |  |  | (1,392) |  |
| Income before income taxes | 51,683 |  |  | 32,201 |  |  |  | 189,706 |  |  | 123,697 |  |
| Income tax (benefit)/ expense | 10,688 |  |  | 5,213 |  |  |  | 34,731 |  |  | 22,540 |  |
| Net income | $ | 40,995 |  |  | $ | 26,988 |  |  |  | $ | 154,975 |  |  | $ | 101,157 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (328) |  |  | (194) |  |  |  | (1,115) |  |  | (697) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 40,667 |  |  | $ | 26,794 |  |  |  | $ | 153,860 |  |  | $ | 100,460 |  |
| Income per share: |  |  |  |  |  |  |  |  |
| Basic | $ | 0.87 |  |  | $ | 0.58 |  |  |  | $ | 3.29 |  |  | $ | 2.16 |  |
| Diluted | $ | 0.85 |  |  | $ | 0.57 |  |  |  | $ | 3.25 |  |  | $ | 2.14 |  |

[0000038725-22-000007:8k_2_02:46]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | December 31, 2021 |  | December 31, 2020 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 40,536 |  |  | $ | 130,787 |  |
| Receivables (net) | 196,173 |  |  | 159,827 |  |
| Inventories | 449,975 |  |  | 300,932 |  |
| Other current assets | 37,963 |  |  | 27,708 |  |
| Total current assets | 724,647 |  |  | 619,254 |  |
| Property, plant, and equipment, net | 210,654 |  |  | 209,021 |  |
| Right-of-use asset, net | 48,379 |  |  | 31,954 |  |
| Goodwill and other assets | 591,485 |  |  | 412,078 |  |
| Total assets | $ | 1,575,165 |  |  | $ | 1,272,307 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 164,758 |  |  | $ | 95,903 |  |
| Accrued expenses and other current liabilities | 117,955 |  |  | 94,160 |  |
| Current lease liability | 15,320 |  |  | 11,090 |  |
| Current maturities of long-term debt and short-term borrowings | 97,981 |  |  | 2,551 |  |
| Total current liabilities | 396,014 |  |  | 203,704 |  |
| Long-term debt | 90,535 |  |  | 91,966 |  |
| Long-term lease liability | 32,937 |  |  | 20,866 |  |
| Income taxes payable non-current | 11,610 |  |  | 11,965 |  |
| Deferred income taxes | 28,162 |  |  | 25,671 |  |
| Employee benefit plans | 40,696 |  |  | 44,443 |  |
| Other long-term liabilities | 26,568 |  |  | 23,988 |  |
| Redeemable noncontrolling interest | (19) |  |  | (245) |  |
| Total equity | 948,662 |  |  | 849,949 |  |
| Total liabilities and equity | $ | 1,575,165 |  |  | $ | 1,272,307 |  |

[0000038725-22-000007:8k_2_02:47]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Twelve Months Ended |
| (In thousands) |  |  |  |
|  | December 31, 2021 |  | December 31, 2020 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 154,975 |  |  | $ | 101,157 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 44,572 |  |  | 36,488 |  |
| Non-cash lease expense | 13,808 |  |  | 11,699 |  |
| Share-based compensation | 11,731 |  |  | 10,066 |  |
| Gain from bargain purchase of business | (6,482) |  |  | — |  |
| Other | 2,126 |  |  | (1,635) |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (31,925) |  |  | 22,053 |  |
| Inventory | (123,076) |  |  | 13,144 |  |
| Accounts payable and accrued expenses | 89,038 |  |  | 20,519 |  |
| Operating leases | (13,808) |  |  | (11,698) |  |
| Other | (11,196) |  |  | 10,061 |  |
| Net cash flows from operating activities | 129,763 |  |  | 211,854 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (30,116) |  |  | (22,856) |  |
| Proceeds from sale of property, plant, and equipment | 979 |  |  | 34 |  |
| Acquisitions and investments | (235,701) |  |  | (55,915) |  |
| Other investing activities | 33 |  |  | (74) |  |
| Net cash flows from investing activities | (264,805) |  |  | (78,811) |  |
| Cash flows from financing activities: |  |  |  |
| Net change in debt | 94,716 |  |  | (21,073) |  |
| Proceeds from issuance of common stock | 15,524 |  |  | 3,721 |  |
| Purchases of common stock | (25,949) |  |  | (19,553) |  |
| Dividends paid | (33,398) |  |  | (29,675) |  |
| Purchase of redeemable non-controlling shares | — |  |  | — |  |
| Net cash flows from financing activities | 50,893 |  |  | (66,580) |  |
| Effect of exchange rate changes on cash | (6,102) |  |  | (81) |  |
| Net change in cash and equivalents | (90,251) |  |  | 66,382 |  |
| Cash and equivalents at beginning of period | 130,787 |  |  | 64,405 |  |
| Cash and equivalents at end of period | $ | 40,536 |  |  | $ | 130,787 |  |

[0000038725-22-000007:8k_2_02:48]
Key Performance Indicators: Earnings Per Share Calculations

[0000038725-22-000007:8k_2_02:49]
| Earnings Before and After Restructuring |  | For the Fourth Quarter |  | For the Full Year of |
| (in millions) |  | 2021 | 2020 | Change |  | 2021 | 2020 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 40.7 |  | $ | 26.8 |  | 52 | % |  | $ | 153.9 |  | $ | 100.5 |  | 53 | % |
| Allocated Earnings |  | $ | (0.2) |  | $ | (0.2) |  |  |  | $ | (0.9) |  | $ | (0.7) |  |  |
| Earnings for EPS Calculations |  | $ | 40.5 |  | $ | 26.6 |  | 52 | % |  | $ | 153.0 |  | $ | 99.8 |  | 53 | % |
| Restructuring (before tax): |  | $ | 0.2 |  | $ | 0.3 |  |  |  | $ | 0.6 |  | $ | 2.5 |  |  |
| Restructuring, net of tax: |  | $ | 0.2 |  | $ | 0.2 |  |  |  | $ | 0.5 |  | $ | 2.0 |  |  |
| Earnings Before Restructuring |  | $ | 40.7 |  | $ | 26.8 |  | 52 | % |  | $ | 153.5 |  | $ | 101.8 |  | 51 | % |
| Earnings Per Share |  | For the Fourth Quarter |  | For the Full Year of |
| Before and After Restructuring |  | 2021 | 2020 | Change |  | 2021 | 2020 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.0 |  | 46.8 |  | — | % |  | 47.0 |  | 46.7 |  | 1 | % |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.85 |  | $ | 0.57 |  | 49 | % |  | $ | 3.25 |  | $ | 2.14 |  | 52 | % |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | — |  |  |  | $ | 0.01 |  | $ | 0.04 |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.86 |  | $ | 0.57 |  | 51 | % |  | $ | 3.26 |  | $ | 2.18 |  | 50 | % |

[0000038725-22-000007:8k_2_02:50]
Key Performance Indicators: Net Sales Summary

[0000038725-22-000007:8k_2_02:51]
|  | Net Sales For the Fourth Quarter |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q4 2020 | $ | 94.1 |  | $ | 36.0 |  | $ | 41.3 |  | $ | 17.9 |  | $ | 189.3 |  | $ | 65.5 |  | $ | 77.9 |  | $ | (11.6) |  | $ | 321.1 |  |
| Q4 2021 | $ | 148.9 |  | $ | 36.6 |  | $ | 47.3 |  | $ | 25.2 |  | $ | 258.0 |  | $ | 79.0 |  | $ | 116.9 |  | $ | (21.4) |  | $ | 432.5 |  |
| Change | $ | 54.8 |  | $ | 0.6 |  | $ | 6.0 |  | $ | 7.3 |  | $ | 68.7 |  | $ | 13.5 |  | $ | 39.0 |  | $ | (9.8) |  | $ | 111.4 |  |
| % Change | 58 | % | 2 | % | 15 | % | 41 | % | 36 | % | 21 | % | 50 | % |  | 35 | % |
| Foreign currency translation | $ | 0.6 |  | $ | (2.3) |  | $ | (4.5) |  | $ | (0.1) |  | $ | (6.3) |  | $ | (0.3) |  | $ | — |  |  |  |
| % Change | 1 | % | (6) | % | (11) | % | (1) | % | (3) | % | — | % | — | % |  |  |
| Acquisitions | $ | 29.6 |  | $ | — |  | $ | — |  | $ | 1.9 |  | $ | 31.5 |  | $ | — |  | $ | 8.5 |  |  |  |
| Volume/Price | $ | 24.6 |  | $ | 2.9 |  | $ | 10.5 |  | $ | 5.5 |  | $ | 43.5 |  | $ | 13.8 |  | $ | 30.5 |  |  |  |
| % Change | 26 | % | 8 | % | 25 | % | 31 | % | 23 | % | 21 | % | 39 | % |  |  |
|  | Net Sales For the Full Year |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| FY 2020 | $ | 388.5 |  | $ | 118.5 |  | $ | 156.8 |  | $ | 70.9 |  | $ | 734.7 |  | $ | 245.1 |  | $ | 328.4 |  | $ | (60.9) |  | $ | 1,247.3 |  |
| FY 2021 | $ | 549.2 |  | $ | 139.5 |  | $ | 189.8 |  | $ | 85.1 |  | $ | 963.6 |  | $ | 289.1 |  | $ | 497.6 |  | $ | (88.4) |  | $ | 1,661.9 |  |
| Change | $ | 160.7 |  | $ | 21.0 |  | $ | 33.0 |  | $ | 14.2 |  | $ | 228.9 |  | $ | 44.0 |  | $ | 169.2 |  | $ | (27.5) |  | $ | 414.6 |  |
| % Change | 41 | % | 18 | % | 21 | % | 20 | % | 31 | % | 18 | % | 52 | % |  | 33 | % |
| Foreign currency translation | $ | 4 |  | $ | (8.5) |  | $ | (1.7) |  | $ | 1.7 |  | $ | (4.5) |  | $ | 2.2 |  | $ | — |  |  |  |
| % Change | 1 | % | (7) | % | (1) | % | 2 | % | (1) | % | 1 | % | — | % |  |  |
| Acquisitions | $ | 94.3 |  | $ | — |  | $ | — |  | $ | 2.4 |  | $ | 96.7 |  | $ | — |  | $ | 53.1 |  |  |  |
| Volume/Price | $ | 62.4 |  | $ | 29.5 |  | $ | 34.7 |  | $ | 10.1 |  | $ | 136.7 |  | $ | 41.8 |  | $ | 116.1 |  |  |  |
| % Change | 16 | % | 25 | % | 22 | % | 14 | % | 19 | % | 17 | % | 35 | % |  |  |

[0000038725-22-000007:8k_2_02:52]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-22-000007:8k_2_02:53]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2021 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 36.4 |  | $ | 22.2 |  | $ | 5.6 |  | $ | (17.0) |  | $ | 47.2 |  |
| % Operating Income To Net Sales | 14.1 | % | 28.1 | % | 4.8 | % |  | 10.9 | % |
| Restructuring | $ | 0.2 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.2 |  |
| Operating Income/(Loss) Before Restructuring | $ | 36.6 |  | $ | 22.2 |  | $ | 5.6 |  | $ | (17.0) |  | $ | 47.4 |  |
| % Operating Income to Net Sales Before Restructuring | 14.2 | % | 28.1 | % | 4.8 | % |  | 11.0 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2020 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 30.4 |  | $ | 18.8 |  | $ | 0.5 |  | $ | (15.3) |  | $ | 34.4 |  |
| % Operating Income To Net Sales | 16.1 | % | 28.7 | % | 0.6 | % |  | 10.7 | % |
| Restructuring | $ | 0.3 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.3 |  |
| Operating Income/(Loss) Before Restructuring | $ | 30.7 |  | $ | 18.8 |  | $ | 0.5 |  | $ | (15.3) |  | $ | 34.7 |  |
| % Operating Income to Net Sales Before Restructuring | 16.2 | % | 28.7 | % | 0.6 | % |  | 10.8 | % |

[0000038725-22-000007:8k_2_02:54]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year of 2021 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 139.1 |  | $ | 79.5 |  | $ | 35.9 |  | $ | (65.3) |  | $ | 189.2 |  |
| % Operating Income To Net Sales | 14.4 | % | 27.5 | % | 7.2 | % |  | 11.4 | % |
| Restructuring | $ | 0.5 |  | $ | — |  | $ | 0.1 |  | $ | — |  | $ | 0.6 |  |
| Operating Income/(Loss) Before Restructuring | $ | 139.6 |  | $ | 79.5 |  | $ | 36.0 |  | $ | (65.3) |  | $ | 189.8 |  |
| % Operating Income to Net Sales Before Restructuring | 14.5 | % | 27.5 | % | 7.2 | % |  | 11.4 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year of 2020 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 114.4 |  | $ | 63.4 |  | $ | 11.5 |  | $ | (58.8) |  | $ | 130.5 |  |
| % Operating Income To Net Sales | 15.6 | % | 25.9 | % | 3.5 | % |  | 10.5 | % |
| Restructuring | $ | 2.3 |  | $ | 0.1 |  | $ | 0.1 |  | $ | — |  | $ | 2.5 |  |
| Operating Income/(Loss) Before Restructuring | $ | 116.7 |  | $ | 63.5 |  | $ | 11.6 |  | $ | (58.8) |  | $ | 133.0 |  |
| % Operating Income to Net Sales Before Restructuring | 15.9 | % | 25.9 | % | 3.5 | % |  | 10.7 | % |
