# FELE note change history — 0000038725-16-000333 → 0000038725-16-000385


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2016-08-02):
[0000038725-16-000333:note_history:1]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be successfully defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

- removed (2016-08-02):
[0000038725-16-000333:note_history:2]
At April 2, 2016, the Company had $18.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- removed (2016-08-02):
[0000038725-16-000333:note_history:3]
The Company provides warranties on most of its products.  The warranty terms vary but are generally 2 years from date of manufacture or 1 year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to 5 years from date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

- removed (2016-08-02):
[0000038725-16-000333:note_history:4]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended April 2, 2016, are as follows:

- removed (2016-08-02):
[0000038725-16-000333:note_history:5]
| (In millions) |  |  |
| Balance as of January 2, 2016 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 1.2 |  |
| Reductions for payments made |  | (1.7 | ) |
| Balance as of April 2, 2016 |  | $ | 8.8 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2016-08-02):
[0000038725-16-000385:note_history:6]
COMMITMENTS AND CONTINGENCIES

- added (2016-08-02):
[0000038725-16-000385:note_history:7]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be successfully defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

- added (2016-08-02):
[0000038725-16-000385:note_history:8]
At July 2, 2016, the Company had $17.5 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- added (2016-08-02):
[0000038725-16-000385:note_history:9]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two to five years from date of manufacture or one to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

- added (2016-08-02):
[0000038725-16-000385:note_history:10]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended July 2, 2016, are as follows:

- added (2016-08-02):
[0000038725-16-000385:note_history:11]
| (In millions) |  |  |
| Balance as of January 2, 2016 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 3.3 |  |
| Reductions for payments made |  | (3.6 | ) |
| Balance as of July 2, 2016 |  | $ | 9.0 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-08-02):
[0000038725-16-000385:note_history:12]
The accompanying condensed consolidated balance sheet as of January 2, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of July 2, 2016, and for the second quarters and six months ended July 2, 2016 and July 4, 2015 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the second quarter and six months ended July 2, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2016.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended January 2, 2016.
  (was, 2016-05-10, similarity 0.9413):
[0000038725-16-000333:note_history:12]
The accompanying condensed consolidated balance sheet as of January 2, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of April 2, 2016, and for the first quarters ended April 2, 2016 and April 4, 2015 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended April 2, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2016.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended January 2, 2016.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-02):
[0000038725-16-000385:note_history:13]
| (In millions) |  | July 2, 2016 |  | January 2, 2016 |
| Prudential Agreement |  | $ | 90.0 |  |  | $ | 120.0 |  |
| Tax increment financing debt |  | 22.3 |  |  | 22.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 22.0 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.8 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 212.9 |  |  | $ | 220.7 |  |
| Less: current maturities |  | (55.7 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 157.2 |  |  | $ | 187.8 |  |
  (was, 2016-05-10, similarity 0.9488):
[0000038725-16-000333:note_history:13]
| (In millions) |  | April 2, 2016 |  | January 2, 2016 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 120.0 |  |
| Tax increment financing debt |  | 22.3 |  |  | 22.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 11.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.0 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 232.6 |  |  | $ | 220.7 |  |
| Less: current maturities |  | (45.3 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 187.3 |  |  | $ | 187.8 |  |

- changed (2016-08-02):
[0000038725-16-000385:note_history:14]
During the six months and second quarter ended July 2, 2016, a portion of the Revolver borrowing was used for seasonal working capital needs.
  (was, 2016-05-10, similarity 0.8872):
[0000038725-16-000333:note_history:14]
During the first quarter ended April 2, 2016, a portion of the revolver borrowing was used for seasonal working capital needs.

- changed (2016-08-02):
[0000038725-16-000385:note_history:15]
Debt outstanding, excluding unamortized debt issuance costs, at July 2, 2016 matures as follows:
  (was, 2016-05-10, similarity 0.9622):
[0000038725-16-000333:note_history:15]
Debt outstanding, excluding unamortized debt issuance costs, at April 2, 2016 matures as follows:


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-02):
[0000038725-16-000385:note_history:16]
| (In millions) |  | July 2, 2016 |  | January 2, 2016 |
| Prudential Agreement |  | $ | 90.0 |  |  | $ | 120.0 |  |
| Tax increment financing debt |  | 22.3 |  |  | 22.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 22.0 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.8 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 212.9 |  |  | $ | 220.7 |  |
| Less: current maturities |  | (55.7 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 157.2 |  |  | $ | 187.8 |  |
  (was, 2016-05-10, similarity 0.9488):
[0000038725-16-000333:note_history:16]
| (In millions) |  | April 2, 2016 |  | January 2, 2016 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 120.0 |  |
| Tax increment financing debt |  | 22.3 |  |  | 22.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 11.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.0 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 232.6 |  |  | $ | 220.7 |  |
| Less: current maturities |  | (45.3 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 187.3 |  |  | $ | 187.8 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-02):
[0000038725-16-000385:note_history:17]
Debt outstanding, excluding unamortized debt issuance costs, at July 2, 2016 matures as follows:
  (was, 2016-05-10, similarity 0.9622):
[0000038725-16-000333:note_history:17]
Debt outstanding, excluding unamortized debt issuance costs, at April 2, 2016 matures as follows:
