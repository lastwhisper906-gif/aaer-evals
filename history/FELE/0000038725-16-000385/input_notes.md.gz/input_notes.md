# FELE notes — 0000038725-16-000385


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-16-000385:notes:1]
COMMITMENTS AND CONTINGENCIES

[0000038725-16-000385:notes:2]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be successfully defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-16-000385:notes:3]
At July 2, 2016, the Company had $17.5 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-16-000385:notes:4]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two to five years from date of manufacture or one to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-16-000385:notes:5]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended July 2, 2016, are as follows:

[0000038725-16-000385:notes:6]
| (In millions) |  |  |
| Balance as of January 2, 2016 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 3.3 |  |
| Reductions for payments made |  | (3.6 | ) |
| Balance as of July 2, 2016 |  | $ | 9.0 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-16-000385:notes:7]
[same as prior period, unchanged from 0000038725-16-000333:notes:12]

[0000038725-16-000385:notes:8]
Changes in accumulated other comprehensive income/(loss) by component for the six months ended July 2, 2016 and July 4, 2015, are summarized below:

[0000038725-16-000385:notes:9]
| (In millions) |  |  |  |  |  |
| For the six months ended July 2, 2016: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance as of January 2, 2016 | $ | (110.1 | ) |  | $ | (51.5 | ) |  | $ | (161.6 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | 14.0 |  |  | — |  |  | 14.0 |  |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | 14.0 |  |  | — |  |  | 14.0 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income/(loss) | — |  |  | 1.5 |  | (1) | 1.5 |  |
| Income tax (expense)/benefit | — |  |  | (0.6 | ) |  | (0.6 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 0.9 |  |  | 0.9 |  |
| Net current period other comprehensive income/(loss), net of income taxes | 14.0 |  |  | 0.9 |  |  | 14.9 |  |
| Less: Other comprehensive income/(loss) attributable to noncontrolling interests | 0.1 |  |  | — |  |  | 0.1 |  |
| Balance as of July 2, 2016 | $ | (96.2 | ) |  | $ | (50.6 | ) |  | $ | (146.8 | ) |
| For the six months ended July 4, 2015: |  |  |  |  |  |
| Balance as of January 3, 2015 | $ | (51.8 | ) |  | $ | (56.1 | ) |  | $ | (107.9 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (28.2 | ) |  | — |  |  | (28.2 | ) |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (28.2 | ) |  | — |  |  | (28.2 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income/(loss) | — |  |  | 2.0 |  | (1) | 2.0 |  |
| Income tax (expense)/benefit | — |  |  | (0.7 | ) |  | (0.7 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 1.3 |  |  | 1.3 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (28.2 | ) |  | 1.3 |  |  | (26.9 | ) |
| Less: Other comprehensive income/(loss) attributable to noncontrolling interests | (0.4 | ) |  | — |  |  | (0.4 | ) |
| Balance as of July 4, 2015 | $ | (79.6 | ) |  | $ | (54.8 | ) |  | $ | (134.4 | ) |

[0000038725-16-000385:notes:10]
[same as prior period, unchanged from 0000038725-16-000333:notes:15]


## us-gaap:DebtDisclosureTextBlock

[0000038725-16-000385:notes:11]
DEBT

[0000038725-16-000385:notes:12]
Debt consisted of the following:

[0000038725-16-000385:notes:13]
| (In millions) |  | July 2, 2016 |  | January 2, 2016 |
| Prudential Agreement |  | $ | 90.0 |  |  | $ | 120.0 |  |
| Tax increment financing debt |  | 22.3 |  |  | 22.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 22.0 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.8 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 212.9 |  |  | $ | 220.7 |  |
| Less: current maturities |  | (55.7 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 157.2 |  |  | $ | 187.8 |  |

[0000038725-16-000385:notes:14]
During the six months and second quarter ended July 2, 2016, a portion of the Revolver borrowing was used for seasonal working capital needs.

[0000038725-16-000385:notes:15]
Debt outstanding, excluding unamortized debt issuance costs, at July 2, 2016 matures as follows:

[0000038725-16-000385:notes:16]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 213.1 |  |  | $ | 55.7 |  |  | $ | 31.1 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 92.6 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 213.2 |  |  | $ | 55.7 |  |  | $ | 31.2 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 92.6 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-16-000385:notes:17]
[same as prior period, unchanged from 0000038725-16-000333:notes:22]

[0000038725-16-000385:notes:18]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements ("the swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  As of July 2, 2016, the swap had a notional value based on 205,000 shares.  For the second quarter and six months ended July 2, 2016, the swap resulted in gains of $0.3 million and $1.1 million, respectively.  For the second quarter and six months ended July 4, 2015, the swap resulted in losses of $0.9 million and $1.0 million, respectively.  Gains and losses on the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-16-000385:notes:19]
[same as prior period, unchanged from 0000038725-16-000333:notes:24]

[0000038725-16-000385:notes:20]
[same as prior period, unchanged from 0000038725-16-000333:notes:25]

[0000038725-16-000385:notes:21]
The 2012 Stock Plan authorized 2,400,000 shares for issuance as follows:

[0000038725-16-000385:notes:22]
| 2012 Stock Plan |  | Authorized Shares |
| Stock Options |  | 1,680,000 |
| Stock/Stock Unit Awards |  | 720,000 |

[0000038725-16-000385:notes:23]
The Company also maintains the Amended and Restated Franklin Electric Co., Inc. Stock Plan (the "2009 Stock Plan") which, as amended in 2009, provided for discretionary grants of stock options and stock awards.  The 2009 Stock Plan authorized 4,400,000 shares for issuance as follows:

[0000038725-16-000385:notes:24]
| 2009 Stock Plan | Authorized Shares |
| Stock Options | 3,200,000 |
| Stock Awards | 1,200,000 |

[0000038725-16-000385:notes:25]
[same as prior period, unchanged from 0000038725-16-000333:notes:26]

[0000038725-16-000385:notes:26]
[same as prior period, unchanged from 0000038725-16-000333:notes:27]

[0000038725-16-000385:notes:27]
[same as prior period, unchanged from 0000038725-16-000333:notes:28]

[0000038725-16-000385:notes:28]
[same as prior period, unchanged from 0000038725-16-000333:notes:29]

[0000038725-16-000385:notes:29]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the six months ended July 2, 2016 and July 4, 2015 are as follows:

[0000038725-16-000385:notes:30]
|  |  | July 2, 2016 |  | July 4, 2015 |
| Risk-free interest rate |  | 1.21 | % |  | 1.59 | % |
| Dividend yield |  | 1.32 | % |  | 0.95 | % |
| Volatility factor |  | 0.377 |  |  | 0.379 |  |
| Expected term |  | 5.5 years |  |  | 5.5 years |  |
| Forfeiture rate |  | 3.77 | % |  | 3.67 | % |

[0000038725-16-000385:notes:31]
There were no stock options granted during the second quarters ended July 2, 2016 or July 4, 2015.

[0000038725-16-000385:notes:32]
A summary of the Company’s outstanding stock option activity and related information for the six months ended July 2, 2016 and July 4, 2015 is as follows:

[0000038725-16-000385:notes:33]
| (Shares in thousands) |  | July 2, 2016 |  | July 4, 2015 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,472 |  |  | $ | 23.26 |  |  | 1,397 |  |  | $ | 21.17 |  |
| Granted |  | 265 |  |  | 29.08 |  |  | 185 |  |  | 36.67 |  |
| Exercised |  | (36 | ) |  | 16.92 |  |  | (70 | ) |  | 17.63 |  |
| Forfeited |  | (2 | ) |  | 37.75 |  |  | (2 | ) |  | 34.93 |  |
| Outstanding at end of period |  | 1,699 |  |  | $ | 24.29 |  |  | 1,510 |  |  | $ | 23.22 |  |
| Expected to vest after applying forfeiture rate |  | 1,668 |  |  | $ | 24.14 |  |  | 1,488 |  |  | $ | 23.02 |  |
| Vested and exercisable at end of period |  | 1,214 |  |  | $ | 20.83 |  |  | 1,144 |  |  | $ | 19.13 |  |

[0000038725-16-000385:notes:34]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of July 2, 2016 is as follows:

[0000038725-16-000385:notes:35]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.57 years |  | $ | 17,091 |  |
| Expected to vest after applying forfeiture rate |  | 5.50 years |  | $ | 17,005 |  |
| Vested and exercisable at end of period |  | 4.21 years |  | $ | 15,923 |  |

[0000038725-16-000385:notes:36]
The total intrinsic value of options exercised during the six months ended July 2, 2016 and July 4, 2015 was $0.5 million and $1.3 million, respectively.

[0000038725-16-000385:notes:37]
As of July 2, 2016, there was $2.2 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.55 years.

[0000038725-16-000385:notes:38]
[same as prior period, unchanged from 0000038725-16-000333:notes:39]

[0000038725-16-000385:notes:39]
A summary of the Company’s restricted stock/stock unit award activity and related information for the six months ended July 2, 2016 and July 4, 2015 is as follows:

[0000038725-16-000385:notes:40]
| (Shares in thousands) |  | July 2, 2016 |  | July 4, 2015 |
| Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 510 |  |  | $ | 34.43 |  |  | 554 |  |  | $ | 32.72 |  |
| Awarded |  | 166 |  |  | 29.16 |  |  | 132 |  |  | 36.67 |  |
| Vested |  | (142 | ) |  | 28.08 |  |  | (167 | ) |  | 30.52 |  |
| Forfeited |  | (21 | ) |  | 34.74 |  |  | (9 | ) |  | 32.31 |  |
| Non-vested at end of period |  | 513 |  |  | $ | 34.47 |  |  | 510 |  |  | $ | 34.40 |  |

[0000038725-16-000385:notes:41]
As of July 2, 2016, there was $10.7 million of total unrecognized compensation cost related to non-vested stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.44 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-16-000385:notes:42]
[same as prior period, unchanged from 0000038725-16-000333:notes:43]

[0000038725-16-000385:notes:43]
[same as prior period, unchanged from 0000038725-16-000333:notes:44]

[0000038725-16-000385:notes:44]
[same as prior period, unchanged from 0000038725-16-000333:notes:45]

[0000038725-16-000385:notes:45]
[same as prior period, unchanged from 0000038725-16-000333:notes:46]

[0000038725-16-000385:notes:46]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions, except per share amounts) | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 24.0 |  |  | $ | 16.2 |  |  | $ | 37.4 |  |  | $ | 36.0 |  |
| Less: Undistributed earnings allocated to participating securities | 0.2 |  |  | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | 0.3 |  |  | 0.1 |  |  | 0.8 |  |  | 0.2 |  |
|  | $ | 23.5 |  |  | $ | 16.0 |  |  | $ | 36.3 |  |  | $ | 35.5 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  |  |  |  |  |
| Weighted average common shares | 46.2 |  |  | 47.6 |  |  | 46.2 |  |  | 47.6 |  |
| Diluted |  |  |  |  |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.5 |  |  | 0.5 |  |  | 0.4 |  |  | 0.5 |  |
| Adjusted weighted average common shares | 46.7 |  |  | 48.1 |  |  | 46.6 |  |  | 48.1 |  |
| Basic earnings per share | $ | 0.51 |  |  | $ | 0.33 |  |  | $ | 0.79 |  |  | $ | 0.74 |  |
| Diluted earnings per share | $ | 0.50 |  |  | $ | 0.33 |  |  | $ | 0.78 |  |  | $ | 0.74 |  |
| Anti-dilutive stock options | 0.5 |  |  | 0.3 |  |  | 0.7 |  |  | 0.3 |  |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000038725-16-000385:notes:47]
OTHER ASSETS

[0000038725-16-000385:notes:48]
The Company has equity interests in various companies for various strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s condensed consolidated balance sheets.  The carrying amount of the investments is adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income, net" line of the Company's condensed consolidated statements of income, were immaterial for the second quarters and six months ended July 2, 2016 and July 4, 2015.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-16-000385:notes:49]
As of July 2, 2016 and January 2, 2016, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-16-000385:notes:50]
| (In millions) | July 2, 2016 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 2.5 |  | $ | 2.5 |  | $ | — |  | $ | — |  |
|  | January 2, 2016 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.9 |  | $ | 3.9 |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-16-000385:notes:51]
[same as prior period, unchanged from 0000038725-16-000333:notes:52]

[0000038725-16-000385:notes:52]
[same as prior period, unchanged from 0000038725-16-000333:notes:53]

[0000038725-16-000385:notes:53]
[same as prior period, unchanged from 0000038725-16-000333:notes:54]

[0000038725-16-000385:notes:54]
[same as prior period, unchanged from 0000038725-16-000333:notes:55]

[0000038725-16-000385:notes:55]
[same as prior period, unchanged from 0000038725-16-000333:notes:56]

[0000038725-16-000385:notes:56]
[same as prior period, unchanged from 0000038725-16-000333:notes:57]

[0000038725-16-000385:notes:57]
Total debt, including current maturities, have carrying amounts of $212.9 million and $220.7 million and estimated fair values of $218 million and $225 million as of July 2, 2016 and January 2, 2016, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.

[0000038725-16-000385:notes:58]
As of July 2, 2016 and January 2, 2016, the Company also had $2.0 million and $1.6 million of assets held for sale, respectively, recorded at carrying value in the Water Systems segment relating to an idle facility in Brazil.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-16-000385:notes:59]
[same as prior period, unchanged from 0000038725-16-000333:notes:61]

[0000038725-16-000385:notes:60]
The carrying amounts of the Company’s intangible assets are as follows:

[0000038725-16-000385:notes:61]
| (In millions) |  | July 2, 2016 |  | January 2, 2016 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.3 | ) |  | $ | 7.4 |  |  | $ | (6.2 | ) |
| Technology |  | 7.5 |  |  | (5.1 | ) |  | 7.5 |  |  | (4.8 | ) |
| Customer relationships |  | 135.4 |  |  | (46.6 | ) |  | 132.6 |  |  | (42.3 | ) |
| Software |  | 2.5 |  |  | (1.8 | ) |  | 2.5 |  |  | (1.7 | ) |
| Other |  | 0.3 |  |  | (0.3 | ) |  | 1.0 |  |  | (1.0 | ) |
| Total |  | $ | 153.2 |  |  | $ | (60.1 | ) |  | $ | 151.0 |  |  | $ | (56.0 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 47.8 |  |  | — |  |  | 46.4 |  |  | — |  |
| Total intangibles |  | $ | 201.0 |  |  | $ | (60.1 | ) |  | $ | 197.4 |  |  | $ | (56.0 | ) |

[0000038725-16-000385:notes:62]
Amortization expense related to intangible assets for the second quarters ended July 2, 2016 and July 4, 2015 was $2.1 million and $2.2 million, respectively and $4.1 million and $4.4 million for the six months ended July 2, 2016 and July 4, 2015, respectively.

[0000038725-16-000385:notes:63]
[same as prior period, unchanged from 0000038725-16-000333:notes:63]

[0000038725-16-000385:notes:64]
| (In millions) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |
|  |  | $ | 8.6 |  |  | $ | 8.5 |  |  | $ | 8.5 |  |  | $ | 8.3 |  |  | $ | 8.2 |  |

[0000038725-16-000385:notes:65]
The change in the carrying amount of goodwill by reporting segment for the six months ended July 2, 2016, is as follows:

[0000038725-16-000385:notes:66]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of January 2, 2016 |  | $ | 136.8 |  |  | $ | 63.0 |  |  | $ | 199.8 |  |
| Foreign currency translation |  | 1.9 |  |  | (0.3 | ) |  | 1.6 |  |
| Balance as of July 2, 2016 |  | $ | 138.7 |  |  | $ | 62.7 |  |  | $ | 201.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-16-000385:notes:67]
[same as prior period, unchanged from 0000038725-16-000333:notes:67]

[0000038725-16-000385:notes:68]
The Company’s effective tax rate for the six month period ended July 2, 2016 was 25.5 percent as compared to 5.2 percent for the six month period ended July 4, 2015.

[0000038725-16-000385:notes:69]
The effective tax rate continues to be lower than the U.S. statutory rate primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate as well as recognition of U.S. incentives and credits.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations as well as cash on hand and available credit.

[0000038725-16-000385:notes:70]
In addition during the three month period ended April 4, 2015, the Company settled the liability for the noncontrolling interest of a subsidiary during the first quarter.  This transaction created additional accretive benefits for the Company from the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest, and realized a gain on the then equity investment in, such subsidiary. The Company also realized a gain on the mandatorily redeemable noncontrolling interest liability.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-16-000385:notes:71]
ACCOUNTING PRONOUNCEMENTS

[0000038725-16-000385:notes:72]
Adoption of New Accounting Standards

[0000038725-16-000385:notes:73]
In March 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-09, Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.  This standard simplifies several aspects of the accounting for employee share-based payment transactions including the recognition of excess tax benefits and deficiencies, the classification of those excess tax benefits on the statement of cash flows, an accounting policy election for forfeitures, the amount an employer can withhold to cover income taxes and still qualify for equity classification, and the classification of those taxes paid on the statement of cash flows. This ASU is effective for annual and interim periods beginning after December 15, 2016 with early adoption permitted.

[0000038725-16-000385:notes:74]
The Company early adopted ASU 2016-09 during the second quarter ended July 2, 2016.  The primary impact of adoption was the recognition of excess tax benefits or deficiencies in the provision for income taxes rather than paid-in capital for all periods in fiscal year 2016.  The Company has elected to continue its current policy of estimating forfeitures rather than recognizing forfeitures when they occur.

[0000038725-16-000385:notes:75]
Under ASU 2016-09, excess income tax benefits from stock-based compensation arrangements are classified as cash flows from operations, rather than as cash flows from financing activities.  The Company elected to apply the cash flow presentation requirements prospectively.

[0000038725-16-000385:notes:76]
The standard also clarifies that cash flows related to employee taxes paid by withheld shares should be classified as a financing activity.  This provision had no impact to the Company, because these cash flows have historically been presented as financing activities.

[0000038725-16-000385:notes:77]
Early adoption of the standard requires reflected adjustments as of January 3, 2016, the beginning of the annual period that includes the interim period of adoption.  As such, previously reported first quarter 2016 results were impacted as follows:

[0000038725-16-000385:notes:78]
| (In thousands, except per share amounts) | First Quarter Ended April 2, 2016 |
|  | As previously reported |  | Adjustment |  | As adjusted |
| Income statements: |  |  |  |  |  |
| Income tax expense | $ | 4,955 |  |  | $ | 12 |  |  | $ | 4,967 |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 13,457 |  |  | $ | (12 | ) |  | $ | 13,445 |  |
| Basic earnings per share | $ | 0.28 |  |  | $ | — |  |  | $ | 0.28 |  |
| Diluted earnings per share | $ | 0.28 |  |  | $ | — |  |  | $ | 0.28 |  |
| Diluted weighted average shares outstanding | 46,445 |  |  | 60 |  |  | 46,505 |  |
| Cash flow statements: |  |  |  |  |  |
| Net cash from operating activities | $ | (437 | ) |  | $ | 53 |  |  | $ | (384 | ) |
| Net cash from financing activities | $ | 3,572 |  |  | $ | (53 | ) |  | $ | 3,519 |  |
| Balance sheets: |  |  |  |  |  |
| Additional capital | $ | 219,400 |  |  | $ | 12 |  |  | $ | 219,412 |  |
| Retained earnings | $ | 502,512 |  |  | $ | (12 | ) |  | $ | 502,500 |  |

[0000038725-16-000385:notes:79]
In April 2015, the FASB issued ASU 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs, which requires debt issuance costs to be presented in the balance sheet as a direct deduction from the associated debt liability instead of a deferred asset.  The standard does not change the amortization of debt issuance costs, which will continue to follow the existing accounting guidance.  The Company adopted ASU 2015-03 during the first quarter ended April 2, 2016.  The retrospective adoption of this ASU required a total of approximately $0.3 million of unamortized debt issuance costs as of year-end 2015 to be reclassified from "Other assets" and "Other current assets" to a direct deduction from "Long-term debt" in the Company's condensed consolidated balance sheet as of January 2, 2016.  In addition, there were no impacts to the Company's results of operations, retained earnings, or cash flows in the current or previous interim and annual reporting periods.

[0000038725-16-000385:notes:80]
Accounting Standards Issued But Not Yet Adopted

[0000038725-16-000385:notes:81]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification ("ASC") Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.

[0000038725-16-000385:notes:82]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606).  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  In March 2016, the FASB issued ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net).  ASU 2016-08 clarifies the implementation guidance on principal versus agent considerations.  In April 2016, the FASB issued ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing.  ASU 2016-10 clarifies the implementation guidance on identifying performance obligations.  These ASUs are effective for interim and annual reporting periods beginning after December 15, 2017.  Early adoption is permitted, but not before interim and annual reporting periods beginning after December 15, 2016.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt these standards.  The Company is still in the process of analyzing the effect of these new standards, including the transition method, to determine the impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-16-000385:notes:83]
[same as prior period, unchanged from 0000038725-16-000333:notes:78]

[0000038725-16-000385:notes:84]
The accompanying condensed consolidated balance sheet as of January 2, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of July 2, 2016, and for the second quarters and six months ended July 2, 2016 and July 4, 2015 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the second quarter and six months ended July 2, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2016.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended January 2, 2016.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-16-000385:notes:85]
[same as prior period, unchanged from 0000038725-16-000333:notes:82]

[0000038725-16-000385:notes:86]
Defined Benefit Plans - As of July 2, 2016, the Company maintained two domestic pension plans and three German pension plans.  The Company used a January 2, 2016 measurement date for these plans.  One of the Company's domestic pension plans covers two management employees (one active employee and one former employee), while the other domestic plan covers all other eligible employees.  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-16-000385:notes:87]
[same as prior period, unchanged from 0000038725-16-000333:notes:84]

[0000038725-16-000385:notes:88]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the second quarters and six months ended July 2, 2016 and July 4, 2015:

[0000038725-16-000385:notes:89]
| (In millions) | Pension Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Service cost | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.5 |  |  | $ | 0.6 |  |
| Interest cost | 1.6 |  |  | 1.8 |  |  | 3.1 |  |  | 3.6 |  |
| Expected return on assets | (2.4 | ) |  | (2.5 | ) |  | (4.7 | ) |  | (5.0 | ) |
| Amortization of loss | 0.7 |  |  | 0.8 |  |  | 1.3 |  |  | 1.6 |  |
| Net periodic benefit cost | $ | 0.2 |  |  | $ | 0.4 |  |  | $ | 0.2 |  |  | $ | 0.8 |  |
| Settlement cost | 0.3 |  |  | 0.3 |  |  | 0.6 |  |  | 0.6 |  |
| Total net periodic benefit cost | $ | 0.5 |  |  | $ | 0.7 |  |  | $ | 0.8 |  |  | $ | 1.4 |  |

[0000038725-16-000385:notes:90]
In the six months ended July 2, 2016, the Company made contributions of $1.1 million to the funded plans.  The amount of contributions to be made to the plans during the calendar year 2016 will be finalized by September 15, 2016, based upon the plans' year-end valuation at January 2, 2016, and the funding level required for the plans' year ended January 2, 2016.

[0000038725-16-000385:notes:91]
The following table sets forth the aggregated net periodic benefit cost for the postretirement benefit plan for the second quarters and six months ended July 2, 2016 and July 4, 2015, respectively:

[0000038725-16-000385:notes:92]
| (In millions) | Other Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Amortization of loss | — |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Net periodic benefit cost | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.6 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.6 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-16-000385:notes:93]
[same as prior period, unchanged from 0000038725-16-000333:notes:88]

[0000038725-16-000385:notes:94]
On July 1, 2014, the Company announced a plan to close its Wittlich, Germany manufacturing facility.  As part of this action, the Company is transferring the existing Wittlich manufacturing activity to its Brno, Czech Republic facility.  The Company will maintain its European Water Systems headquarters and distribution center in Wittlich, only the manufacturing operations are relocating.  The realignment began in the third quarter of 2014 and is estimated to conclude by the end of 2016.  Charges for the realignment are expected to be approximately $19.4 million and will include severance expenses, professional service fees, asset write-offs, and temporarily leased facilities costs.

[0000038725-16-000385:notes:95]
Costs incurred in the second quarter and six months ended July 2, 2016, included in the “Restructuring expense” line of the Company's condensed consolidated statements of income, are as follows:

[0000038725-16-000385:notes:96]
|  |  | Second Quarter Ended |
|  |  | July 2, 2016 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | (0.1 | ) |  | $ | — |  |  | $ | — |  |  | $ | (0.1 | ) |
| Equipment relocation |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Asset write-off |  | — |  |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Other |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000038725-16-000385:notes:97]
|  |  | Six Months Ended |
|  |  | July 2, 2016 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Equipment relocation |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Asset write-off |  | — |  |  | 0.4 |  |  | — |  |  | 0.4 |  |
| Other |  | 0.4 |  |  | — |  |  | — |  |  | 0.4 |  |
| Total |  | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | — |  |  | $ | 0.9 |  |

[0000038725-16-000385:notes:98]
Restructuring expenses for the second quarter and six months ended July 4, 2015 were approximately $0.8 million and $1.2 million, primarily for the Water Systems realignment.

[0000038725-16-000385:notes:99]
As of July 2, 2016, there were no restructuring reserves.  As of July 4, 2015, there were $4.3 million of restructuring reserves.  The restructuring reserves were primarily for severance.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-16-000385:notes:100]
[same as prior period, unchanged from 0000038725-16-000333:notes:94]

[0000038725-16-000385:notes:101]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions) | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
|  | Net sales to external customers |
| Water Systems | $ | 194.6 |  |  | $ | 191.6 |  |  | $ | 363.4 |  |  | $ | 370.9 |  |
| Fueling Systems | 57.5 |  |  | 55.8 |  |  | 107.1 |  |  | 102.3 |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |
| Consolidated | $ | 252.1 |  |  | $ | 247.4 |  |  | $ | 470.5 |  |  | $ | 473.2 |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
|  | Operating income/(loss) |
| Water Systems | $ | 31.5 |  |  | $ | 24.3 |  |  | $ | 55.6 |  |  | $ | 43.7 |  |
| Fueling Systems | 15.5 |  |  | 12.4 |  |  | 25.8 |  |  | 22.0 |  |
| Other | (14.3 | ) |  | (13.5 | ) |  | (27.6 | ) |  | (26.7 | ) |
| Consolidated | $ | 32.7 |  |  | $ | 23.2 |  |  | $ | 53.8 |  |  | $ | 39.0 |  |
|  | July 2, 2016 |  | January 2, 2016 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 715.7 |  |  | $ | 677.6 |  |  |  |  |  |
| Fueling Systems | 247.0 |  |  | 248.5 |  |  |  |  |  |
| Other | 78.3 |  |  | 70.0 |  |  |  |  |  |
| Consolidated | $ | 1,041.0 |  |  | $ | 996.1 |  |  |  |  |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-16-000385:notes:102]
The schedule below sets forth equity changes in the six months ended July 2, 2016:

[0000038725-16-000385:notes:103]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of January 2, 2016 | $ | 4,622 |  |  | $ | 216,472 |  |  | $ | 498,214 |  |  | $ | (51,558 | ) |  | $ | (110,050 | ) |  | $ | 1,765 |  |  | $ | 559,465 |  |  | $ | 6,856 |  |
| Net income |  |  |  |  | 37,439 |  |  |  |  |  |  | 345 |  |  | 37,784 |  |  | (17 | ) |
| Adjustment to Impo redemption value |  |  |  |  | (778 | ) |  |  |  |  |  |  |  | (778 | ) |  | 778 |  |
| Dividends on common stock |  |  |  |  | (9,148 | ) |  |  |  |  |  |  |  | (9,148 | ) |  |  |
| Common stock issued | 3 |  |  | 607 |  |  |  |  |  |  |  |  |  |  | 610 |  |  |  |
| Common stock repurchased | (17 | ) |  |  |  | (4,719 | ) |  |  |  |  |  |  |  | (4,736 | ) |  |  |
| Share-based compensation | 13 |  |  | 4,142 |  |  |  |  |  |  |  |  |  |  | 4,155 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (673 | ) |  | (673 | ) |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 13,899 |  |  | 34 |  |  | 13,933 |  |  | — |  |
| Pension liability, net of tax |  |  |  |  |  |  | 953 |  |  |  |  |  |  | 953 |  |  |  |
| Balance as of July 2, 2016 | $ | 4,621 |  |  | $ | 221,221 |  |  | $ | 521,008 |  |  | $ | (50,605 | ) |  | $ | (96,151 | ) |  | $ | 1,471 |  |  | $ | 601,565 |  |  | $ | 7,617 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-16-000385:notes:104]
[same as prior period, unchanged from 0000038725-16-000333:notes:98]

[0000038725-16-000385:notes:105]
Property, plant, and equipment is the major asset group in "Other" of total assets as of July 2, 2016 and January 2, 2016.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-16-000385:notes:106]
[same as prior period, unchanged from 0000038725-16-000333:notes:100]
