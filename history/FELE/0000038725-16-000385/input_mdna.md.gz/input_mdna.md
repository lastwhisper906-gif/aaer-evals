# FELE MD&A — 0000038725-16-000385


## mdna

[0000038725-16-000385:mdna:1]
[same as prior period, unchanged from 0000038725-16-000333:mdna:1]

[0000038725-16-000385:mdna:2]
Second Quarter 2016 vs. Second Quarter 2015

[0000038725-16-000385:mdna:3]
[same as prior period, unchanged from 0000038725-16-000333:mdna:3]

[0000038725-16-000385:mdna:4]
Sales and earnings in the second quarter of 2016 increased from the second quarter last year.  The sales increase was primarily due to price and volume increases exceeding the negative impact of foreign currency translation. The Company's consolidated gross profit was $90.7 million for the second quarter of 2016, an increase of $10.5 million or about 13 percent from the prior year’s second quarter.

[0000038725-16-000385:mdna:5]
[same as prior period, unchanged from 0000038725-16-000333:mdna:5]

[0000038725-16-000385:mdna:6]
[same as prior period, unchanged from 0000038725-16-000333:mdna:6]

[0000038725-16-000385:mdna:7]
Net sales in the second quarter of 2016 were $252.1 million, an increase of $4.7 million or about 2 percent compared to 2015 second quarter sales of $247.4 million.  Sales revenue decreased by $7.5 million or about 3 percent in the second quarter of 2016 due to foreign currency translation. The sales change in the second quarter of 2016, excluding foreign currency translation, was an increase of $12.2 million or about 5 percent.

[0000038725-16-000385:mdna:8]
|  | Net Sales |
| (In millions) | Q2 2016 |  | Q2 2015 |  | 2016 v 2015 |
| Water Systems | $ | 194.6 |  |  | $ | 191.6 |  |  | $ | 3.0 |  |
| Fueling Systems | 57.5 |  |  | 55.8 |  |  | 1.7 |  |
| Consolidated | $ | 252.1 |  |  | $ | 247.4 |  |  | $ | 4.7 |  |

[0000038725-16-000385:mdna:9]
[same as prior period, unchanged from 0000038725-16-000333:mdna:9]

[0000038725-16-000385:mdna:10]
Water Systems sales were $194.6 million in the second quarter 2016, an increase of $3.0 million or about 2 percent versus the second quarter 2015 sales of $191.6 million. Water Systems sales were reduced by $7.2 million or about 4 percent in the quarter due to foreign currency translation. Excluding foreign currency translation, Water Systems sales were up about 6 percent compared to the second quarter 2015.

[0000038725-16-000385:mdna:11]
Water Systems sales in the U.S. and Canada represented 38 percent of consolidated sales and increased by about 6 percent compared to the prior year. Water Systems sales in the U.S and Canada were reduced by $0.7 million or about 1 percent in the quarter due to foreign currency translation. Water Systems sales in the U.S. and Canada were up about 7 percent compared to the prior year second quarter, excluding the impact of foreign currency. In the second quarter 2016, sales of groundwater pumping equipment grew by about 9 percent.  The growth in groundwater equipment sales was led by a 13 percent increase in agricultural products and an 8 percent increase in residential systems.

[0000038725-16-000385:mdna:12]
Water Systems sales in Latin America were about 13 percent of consolidated sales for the second quarter and grew by about 1 percent compared to the second quarter of the prior year. Water Systems sales were reduced by $3.9 million or about 12 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, Latin American sales increased by about 13 percent compared to the second quarter 2015.  Water Systems sales growth in Latin American was led by improved sales in Brazil.  Business in Brazil recovered from a soft first quarter, delivering 14 percent organic growth, more than offsetting lower sales in Mexico and Argentina.

[0000038725-16-000385:mdna:13]
Water Systems sales in the Middle East and Africa were about 10 percent of consolidated sales and decreased by about 18 percent compared to the second quarter 2015. Water Systems sales were reduced by about 9 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, sales decreased by about 9 percent compared to the second quarter 2015. The decline was due to generally weak demand in the Gulf region due to reduced investment by the public sector and weak end-market demand in Turkey.

[0000038725-16-000385:mdna:14]
Water Systems sales in the Asia Pacific region were 9 percent of consolidated sales and were up about 14 percent compared to the second quarter prior year. Asia Pacific sales were reduced by about 1 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, Asia Pacific sales increased by about 15 percent compared to the second quarter 2015. The Asia Pacific sales growth was due to generally favorable weather conditions in Southeast Asia and

[0000038725-16-000385:mdna:15]
strong performance in Australia.

[0000038725-16-000385:mdna:16]
Water Systems sales in Europe were about 7 percent of consolidated sales and increased by about 2 percent compared to the second quarter of the prior year. The impact of foreign currency translation increased sales by about 2 percent compared to the second quarter 2015. Excluding the impact of foreign currency translation, European sales were flat.

[0000038725-16-000385:mdna:17]
[same as prior period, unchanged from 0000038725-16-000333:mdna:17]

[0000038725-16-000385:mdna:18]
Fueling Systems sales represented 23 percent of consolidated sales and were $57.5 million in the second quarter 2016, an increase of $1.7 million or about 3 percent versus the second quarter 2015 sales of $55.8 million. Fueling Systems sales decreased by $0.3 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems sales increased by $2.0 million or about 4 percent after excluding foreign currency translation.

[0000038725-16-000385:mdna:19]
Fueling Systems sales in the U.S. and Canada grew by about 6 percent during the quarter with most of the sales growth coming from fuel management systems.  Internationally, Fueling Systems revenues were down overall with Asia Pacific sales growth being more than offset by lower sales in Europe and Latin America.

[0000038725-16-000385:mdna:20]
[same as prior period, unchanged from 0000038725-16-000333:mdna:19]

[0000038725-16-000385:mdna:21]
Cost of sales as a percent of net sales for the second quarter of 2016 and 2015 was 64.0 percent and 67.6 percent, respectively. Correspondingly, the gross profit margin increased to 36.0 percent from 32.4 percent, a 360 basis point improvement. The gross profit margin increase was due to favorable pricing, lower direct material costs, a better sales mix and lower fixed costs. The Company’s consolidated gross profit was $90.7 million for the second quarter of 2016, an increase of $10.5 million, or about 13 percent, from the second quarter of 2015 gross profit of $80.2 million.

[0000038725-16-000385:mdna:22]
[same as prior period, unchanged from 0000038725-16-000333:mdna:21]

[0000038725-16-000385:mdna:23]
Selling, general, and administrative (SG&A) expenses were $58.0 million in the second quarter of 2016 compared to $56.3 million in the second quarter of prior year, an increase of $1.7 million or about 3 percent. The Company’s SG&A expenses increased by $2.5 million in the quarter due to higher variable compensation expenses, which were partially offset by lower fixed cost from the effect of foreign currency translation of about $1.4 million.

[0000038725-16-000385:mdna:24]
[same as prior period, unchanged from 0000038725-16-000333:mdna:23]

[0000038725-16-000385:mdna:25]
There were minimal net restructuring expenses for the second quarter of 2016. Restructuring expenses for the second quarter of 2015 were $0.8 million and had a $0.01 impact on diluted earnings per share and were related to severance expenses and other miscellaneous manufacturing realignment activities.

[0000038725-16-000385:mdna:26]
[same as prior period, unchanged from 0000038725-16-000333:mdna:25]

[0000038725-16-000385:mdna:27]
Operating income was $32.7 million in the second quarter of 2016, up $9.5 million or about 41 percent from $23.2 million in the second quarter of 2015.

[0000038725-16-000385:mdna:28]
|  |  | Operating income (loss) |
| (In millions) |  | Q2 2016 |  | Q2 2015 |  | 2016 v 2015 |
| Water Systems |  | $ | 31.5 |  |  | $ | 24.3 |  |  | $ | 7.2 |  |
| Fueling Systems |  | 15.5 |  |  | 12.4 |  |  | 3.1 |  |
| Other |  | (14.3 | ) |  | (13.5 | ) |  | (0.8 | ) |
| Consolidated |  | $ | 32.7 |  |  | $ | 23.2 |  |  | $ | 9.5 |  |

[0000038725-16-000385:mdna:29]
There were specific items in the second quarter of 2016 and 2015 that impacted operating income that were not operational in nature.  In the second quarter of 2016 there was only one such item: $0.3 million related to executive transition. In the second quarter of 2015 there were four such items: $0.8 million of restructuring charges, $0.5 million related to business realignment cost, primarily severance, in targeted fixed cost reduction actions, $0.3 million related to executive transition and $0.1 million for pending and completed acquisition-related activities.

[0000038725-16-000385:mdna:30]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments to net sales (operating income margin after non-GAAP adjustments).  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial

[0000038725-16-000385:mdna:31]
measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000385:mdna:32]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (In millions) | For the Second Quarter 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income / (Loss) | $ | 31.5 |  | $ | 15.5 |  | $ | (14.3 | ) | $ | 32.7 |  |
| % Operating Income To Net Sales | 16.2 | % | 27.0 | % |  | 13.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | — |  | $ | — |  | $ | — |  | $ | — |  |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.3 |  | $ | 0.3 |  |
| Operating Income / (Loss) after Non-GAAP Adjustments | $ | 31.5 |  | $ | 15.5 |  | $ | (14.0 | ) | $ | 33.0 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 16.2 | % | 27.0 | % |  | 13.1 | % |
|  | For the Second Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income / (Loss) | $ | 24.3 |  | $ | 12.4 |  | $ | (13.5 | ) | $ | 23.2 |  |
| % Operating Income To Net Sales | 12.7 | % | 22.2 | % |  | 9.4 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.6 |  | $ | 0.2 |  | $ | — |  | $ | 0.8 |  |
| Non-GAAP | $ | 0.5 |  | $ | 0.1 |  | $ | 0.3 |  | $ | 0.9 |  |
| Operating Income / (Loss) after Non-GAAP Adjustments | $ | 25.4 |  | $ | 12.7 |  | $ | (13.2 | ) | $ | 24.9 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 13.3 | % | 22.8 | % |  | 10.1 | % |

[0000038725-16-000385:mdna:33]
[same as prior period, unchanged from 0000038725-16-000333:mdna:32]

[0000038725-16-000385:mdna:34]
Water Systems operating income was $31.5 million in the second quarter 2016, up $7.2 million versus the second quarter 2015. The second quarter operating income margin was 16.2 percent, up 350 basis points from 12.7 percent in the second quarter of 2015. Water Systems operating income, after non-GAAP adjustments, was $31.5 million in the second quarter 2016, up $6.1 million versus the second quarter 2015. The second quarter operating income margin after non-GAAP adjustments was 16.2 percent, up 290 basis points from 13.3 percent in the second quarter of 2015. Operating income margin after non-GAAP adjustments increased in Water Systems primarily due to favorable pricing, lower direct material costs and lower fixed costs.

[0000038725-16-000385:mdna:35]
[same as prior period, unchanged from 0000038725-16-000333:mdna:34]

[0000038725-16-000385:mdna:36]
Fueling Systems operating income was $15.5 million in the second quarter of 2016 compared to $12.4 million in the second quarter of 2015, an increase of about 25 percent. The second quarter operating income margin was 27.0 percent, an increase of 480 basis points from the 22.2 percent of net sales in the second quarter of 2015.  Fueling Systems operating income after non-GAAP adjustments was $15.5 million in the second quarter of 2016 compared to $12.7 million after non-GAAP adjustments in the second quarter of 2015, an increase of about 22 percent. The second quarter operating income margin after non-GAAP adjustments was 27.0 percent, an increase of 420 basis points from the 22.8 percent of net sales in the second quarter of 2015. The increase in basis points was primarily due to favorable pricing, lower direct material costs, a better sales mix and lower fixed costs.

[0000038725-16-000385:mdna:37]
Operating Income-Other

[0000038725-16-000385:mdna:38]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses were higher due to increases in variable compensation expenses.

[0000038725-16-000385:mdna:39]
[same as prior period, unchanged from 0000038725-16-000333:mdna:38]

[0000038725-16-000385:mdna:40]
Interest expense for the second quarter of 2016 and 2015 was $2.2 million and $2.4 million, respectively.

[0000038725-16-000385:mdna:41]
[same as prior period, unchanged from 0000038725-16-000333:mdna:40]

[0000038725-16-000385:mdna:42]
Other income or expense was income of $1.4 million in both the second quarter of 2016 and 2015.  Included in other income in the second quarter of 2016 was minority income of $0.7 million and interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities. Included in other income in the second quarter of 2015 was minority income of $1.4 million and interest income of $0.1 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-16-000385:mdna:43]
[same as prior period, unchanged from 0000038725-16-000333:mdna:43]

[0000038725-16-000385:mdna:44]
Foreign currency-based transactions produced a gain for the second quarter of 2016 of $0.3 million, due to movements in several currencies relative to the U.S. dollar, none of which individually were significant.   Foreign currency-based transactions produced a loss for the second quarter of 2015 of $0.4 million, primarily due to the euro relative to the U.S. dollar.

[0000038725-16-000385:mdna:45]
[same as prior period, unchanged from 0000038725-16-000333:mdna:45]

[0000038725-16-000385:mdna:46]
The provision for income taxes in the second quarter of 2016 and 2015 was $8.0 million and $5.4 million, respectively. The effective tax rate for the second quarter of 2016 was flat to last year at about 25 percent and, before the impact of discrete events, was about 27 percent.  The effective tax rate for the second quarter of 2015 was 25 percent and, before the impact of discrete events, was about 27 percent.  The average effective tax rate after discrete events for the back half of 2016 is projected to be 25 percent. The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-16-000385:mdna:47]
[same as prior period, unchanged from 0000038725-16-000333:mdna:47]

[0000038725-16-000385:mdna:48]
Net income for the second quarter of 2016 was $24.2 million compared to the prior year second quarter net income of $16.4 million.  Net income attributable to Franklin Electric Co., Inc. for the second quarter of 2016 was $24.0 million, or $0.50 per diluted share, compared to the prior year second quarter net income attributable to Franklin Electric Co., Inc. of $16.2 million or $0.33 per diluted share. Earnings after non-GAAP adjustments for the second quarter of 2016 were $23.7 million, or $0.51 per diluted share, compared to the prior year second quarter earnings after non-GAAP adjustments of $17.0 million or $0.35 per diluted share.

[0000038725-16-000385:mdna:49]
There were specific items in the second quarter of 2016 and 2015 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The elements of the non-GAAP adjustments are explained above under the caption "Operating Income."  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000385:mdna:50]
| Earnings Before and After Non-GAAP Adjustments | For the Second Quarter Ended |
| (In millions) | 2016 | 2015 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 24.0 |  | $ | 16.2 |  | 48 | % |
| Allocated Undistributed Earnings | $ | (0.5 | ) | $ | (0.2 | ) |  |
| Earnings for EPS Calculations | $ | 23.5 |  | $ | 16.0 |  | 47 | % |
| Non-GAAP adjustments, before tax: |  |  |  |
| Restructuring | $ | — |  | $ | 0.8 |  |  |
| Non-GAAP items | $ | 0.3 |  | $ | 0.9 |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | — |  | $ | 0.5 |  |  |
| Non-GAAP items | $ | 0.2 |  | $ | 0.5 |  |  |
| Earnings after Non-GAAP Adjustments | $ | 23.7 |  | $ | 17.0 |  | 39 | % |

[0000038725-16-000385:mdna:51]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the Second Quarter Ended |
| (In millions, except per share data) | 2016 | 2015 | Change |
| Average Fully Diluted Shares Outstanding | 46.7 |  | 48.1 |  | (3 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.50 |  | $ | 0.33 |  | 52 | % |
| Restructuring per Share, net of tax | $ | — |  | $ | 0.01 |  |  |
| Non-GAAP items, net of tax | $ | 0.01 |  | $ | 0.01 |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.51 |  | $ | 0.35 |  | 46 | % |

[0000038725-16-000385:mdna:52]
First Half of 2016 vs. First Half of 2015

[0000038725-16-000385:mdna:53]
OVERVIEW

[0000038725-16-000385:mdna:54]
Sales in the first half of 2016 were down from the same period last year.  The sales decrease was related to the negative impact of foreign currency translation on sales more than offsetting price and volume increases. The Company's consolidated gross profit was $164.9 million for the first half of 2016, an increase of $13.2 million or about 9 percent from the first half of 2015. Earnings in the first half of 2016 were up from the same period last year.

[0000038725-16-000385:mdna:55]
RESULTS OF OPERATIONS

[0000038725-16-000385:mdna:56]
Net Sales

[0000038725-16-000385:mdna:57]
Net sales in the first half of 2016 were $470.5 million, a decrease of $2.7 million or about 1 percent compared to 2015 first half sales of $473.2 million.  The incremental impact of sales from acquired businesses was $0.7 million or less than 1 percent.  Sales revenue decreased by $21.3 million or about 5 percent in the first half of 2016 due to foreign currency translation. The sales change in the first half of 2016, excluding acquisitions and foreign currency translation, was an increase of $17.9 million or about 4 percent.

[0000038725-16-000385:mdna:58]
| (In millions) | YTD July 2, 2016 |  | YTD July 4, 2015 |  | 2016 v 2015 |
|  | Net Sales |
| Water Systems | $ | 363.4 |  |  | $ | 370.9 |  |  | $ | (7.5 | ) |
| Fueling Systems | 107.1 |  |  | 102.3 |  |  | 4.8 |  |
| Consolidated | $ | 470.5 |  |  | $ | 473.2 |  |  | $ | (2.7 | ) |

[0000038725-16-000385:mdna:59]
Net Sales-Water Systems

[0000038725-16-000385:mdna:60]
Water Systems sales were $363.4 million in the first half 2016, a decrease of $7.5 million or about 2 percent versus the first half 2015. The incremental impact of sales from acquired businesses was $0.7 million or less than 1 percent. Foreign currency translation rate changes decreased sales $20.5 million, or about 5 percent, compared to sales in the first half of 2015. The Water Systems sales change in the first half of 2016, excluding acquisitions and foreign currency translation, was an increase of $12.3 million or about 3 percent.

[0000038725-16-000385:mdna:61]
Water Systems sales in the U.S. and Canada were 37 percent of consolidated sales and increased by about 2 percent compared to the first half of 2015. Sales revenue decreased by $1.8 million or about 1 percent in the first half of 2016 due to foreign currency translation. The sales change in the first half of 2016, excluding foreign currency translation, was an increase of about 3 percent.  In the first half of 2016, U.S. and Canada sales of groundwater pumping equipment increased by about 6 percent, and sales of surface water pumping equipment declined by about 2 percent versus the first half of 2015.

[0000038725-16-000385:mdna:62]
Water Systems sales in Latin America were about 12 percent of consolidated sales for the first half and declined by 13 percent

[0000038725-16-000385:mdna:63]
compared to the prior year first half.  Sales revenue decreased by $11.0 million or about 16 percent in the first half of 2016 due to foreign currency translation. The sales change in the first half of 2016, excluding foreign currency translation, was an increase of $2.3 million or about 3 percent. The growth in sales was led by increased sales in Mexico and Brazil, in local currency. This sales growth is a result of increasing demand for the Company's submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions.

[0000038725-16-000385:mdna:64]
Water Systems sales in the Middle East and Africa were about 10 percent of consolidated sales and declined by about 14 percent compared to the first half of 2015. Water Systems in the Middle East and Africa were reduced by $6.8 million or about 12 percent in the first half due to foreign currency translation. Excluding the impact of foreign currency translation, sales were down about 2 percent compared to the first half of 2015 due to weaker demand in the Gulf region.

[0000038725-16-000385:mdna:65]
Water Systems sales in the Asia Pacific region were 10 percent of consolidated sales and increased by about 13 percent compared to the first half of the prior year. Sales revenue decreased by about 2 percent in the first half of 2016 due to foreign currency translation. The sales change in the first half of 2016, excluding foreign currency translation, was an increase about 15 percent. The Asia Pacific region experienced strong year over year growth in Southeast Asia and Australia due to generally favorable weather conditions.

[0000038725-16-000385:mdna:66]
Water Systems sales in Europe were about 8 percent of consolidated sales and increased by about 2 percent compared to the first half of 2015.  Sales in Europe in the first half of 2016 decreased by $0.2 million or about 1 percent due to foreign currency translation. Excluding the impact of foreign currency translation, European sales increased $1.0 million or about 3 percent compared to the first half of 2015.

[0000038725-16-000385:mdna:67]
Net Sales-Fueling Systems

[0000038725-16-000385:mdna:68]
Fueling Systems sales were $107.1 million or about 23 percent of consolidated sales in the first half of 2016 and increased $4.8 million or about 5 percent from the first half of 2015. Foreign currency translation rate changes decreased sales $0.8 million or about 1 percent compared to sales in the first half of 2015. The Fueling Systems sales change in the first half of 2016, excluding foreign currency translation, was an increase of $5.6 million or about 6 percent.

[0000038725-16-000385:mdna:69]
Fueling Systems sales in the U.S. and Canada grew by about 7 percent during the first half with most of the sales growth coming from fuel management systems and piping. Internationally, Fueling Systems revenues were up overall with increased sales in India more than offsetting a sales decline in Europe principally due to a reduction in the sale of storage tanks that support North Sea oil production.

[0000038725-16-000385:mdna:70]
Cost of Sales

[0000038725-16-000385:mdna:71]
Cost of sales as a percent of net sales for the first half of 2016 and 2015 was 65.0 percent and 67.9 percent, respectively. Correspondingly, the gross profit margin was 35.0 percent and 32.1 percent for both first halves. The Company's consolidated gross profit was $164.9 million for the first half of 2016, up $13.2 million from the gross profit of $151.7 million in the first half of 2015. The gross profit margin decrease was primarily due to favorable pricing, lower direct material costs, a better sales mix and lower fixed costs.

[0000038725-16-000385:mdna:72]
Selling, General, and Administrative (“SG&A”)

[0000038725-16-000385:mdna:73]
Selling, general, and administrative expenses were $110.3 million in the first half of 2016 and decreased by $1.1 million or 1 percent in the first half of 2016 compared to $111.4 million the first half of last year. There were $0.6 million of costs included in non-GAAP adjustments (see discussion of non-GAAP adjustments below) related to executive transition in the first half of 2016. There were $1.2 million of costs included in non-GAAP adjustments related to executive transition, business realignment and pending or completed acquisitions in the first half of 2015. After non-GAAP adjustments, SG&A expenses were $109.7 million in the first half of 2016 and decreased by $0.5 million or less than 1 percent in the first half of 2016 compared to $110.2 million the first half of last year. The Company’s SG&A expenses increased by $2.5 million in the first half due to higher variable compensation expenses, which were offset by lower fixed costs from the effect of foreign currency translation of $3.9 million.

[0000038725-16-000385:mdna:74]
Restructuring Expenses

[0000038725-16-000385:mdna:75]
Restructuring expenses for the first half of 2016 were $0.9 million and reduced diluted earnings per share by approximately $0.01. Restructuring expenses were split across both segments, $0.4 million in Water and $0.5 million in Fueling, and included asset write-offs, severance expenses and other miscellaneous manufacturing realignment activities.  Restructuring expenses for the first half of 2015 were $1.2 million and reduced diluted earnings per share by approximately $0.02. Restructuring expenses were primarily related to the European manufacturing realignment.

[0000038725-16-000385:mdna:76]
Operating Income

[0000038725-16-000385:mdna:77]
Operating income was $53.8 million in the first half of 2016, up $14.8 million from $39.0 million in the first half of 2015.

[0000038725-16-000385:mdna:78]
| (In millions) |  | YTDJuly 2, 2016 |  | YTDJuly 4, 2015 |  | 2016 v 2015 |
|  |  | Operating income (loss) |
| Water Systems |  | $ | 55.6 |  |  | $ | 43.7 |  |  | $ | 11.9 |  |
| Fueling Systems |  | 25.8 |  |  | 22.0 |  |  | 3.8 |  |
| Other |  | (27.6 | ) |  | (26.7 | ) |  | (0.9 | ) |
| Consolidated |  | $ | 53.8 |  |  | $ | 39.0 |  |  | $ | 14.8 |  |

[0000038725-16-000385:mdna:79]
There were specific items in the first half of 2016 and 2015 that impacted operating income that were not operational in nature.  In the first half of 2016 there were two such items: $0.9 million of restructuring charges and $0.6 million related to executive transition. In the first half of 2015 there were four such items: $1.2 million of restructuring charges, $0.6 million related to executive transition, $0.4 million related to business realignment cost, primarily severance, in targeted fixed cost reduction actions, and $0.2 million for pending and completed acquisition related activities

[0000038725-16-000385:mdna:80]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income after non-GAAP adjustments to net sales.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000385:mdna:81]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the First Half of 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income / (Loss) | $ | 55.6 |  | $ | 25.8 |  | $ | (27.6 | ) | $ | 53.8 |  |
| % Operating Income To Net Sales | 15.3 | % | 24.1 | % |  | 11.4 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.4 |  | $ | 0.5 |  | $ | — |  | $ | 0.9 |  |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.6 |  | $ | 0.6 |  |
| Operating Income / (Loss) after Non-GAAP Adjustments | $ | 56.0 |  | $ | 26.3 |  | $ | (27.0 | ) | $ | 55.3 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.4 | % | 24.6 | % |  | 11.8 | % |
|  | For the First Half of 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income / (Loss) | $ | 43.7 |  | $ | 22.0 |  | $ | (26.7 | ) | $ | 39.0 |  |
| % Operating Income To Net Sales | 11.8 | % | 21.5 | % |  | 8.2 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.9 |  | $ | 0.3 |  | $ | — |  | $ | 1.2 |  |
| Non-GAAP | $ | 0.5 |  | $ | 0.1 |  | $ | 0.6 |  | $ | 1.2 |  |
| Operating Income / (Loss) after Non-GAAP Adjustments | $ | 45.1 |  | $ | 22.4 |  | $ | (26.1 | ) | $ | 41.4 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.2 | % | 21.9 | % |  | 8.7 | % |

[0000038725-16-000385:mdna:82]
28

[0000038725-16-000385:mdna:83]
Operating Income-Water Systems

[0000038725-16-000385:mdna:84]
Water Systems operating income was $55.6 million in the first half of 2016 compared to $43.7 million in the first half of 2015, an increase of 27 percent. The first half operating income margin was 15.3 percent and increased by 350 basis points compared to the first half of 2015. Water Systems operating income, after non-GAAP adjustments, was $56.0 million in the first half of 2016 compared to $45.1 million after non-GAAP adjustments in the first half of 2015, an increase of 24 percent. The first half operating income margin after non-GAAP adjustments was 15.4 percent and increased by 320 basis points compared to the first half of 2015. Operating income margin after non-GAAP adjustments increased in Water Systems primarily due to pricing, lower material costs and lower fixed costs.

[0000038725-16-000385:mdna:85]
Operating Income-Fueling Systems

[0000038725-16-000385:mdna:86]
Fueling Systems operating income was $25.8 million in the first half of 2016 compared to $22.0 million in the first half of 2015, an increase of 17 percent. The first half operating income margin was 24.1 percent compared to 21.5 percent of net sales in the first half of 2015. Fueling Systems operating income after non-GAAP adjustments was $26.3 million in the first half of 2016 compared to $22.4 million after non-GAAP adjustments in the first half of 2015, an increase of 17 percent. The first half operating income margin after non-GAAP adjustments was 24.6 percent compared to 21.9 percent of net sales in the first half of 2015, an increase of 270 basis points. Operating income margin after non-GAAP adjustments increased in Fueling Systems primarily due to pricing, lower material costs, a better sales mix and lower fixed costs.

[0000038725-16-000385:mdna:87]
Operating Income-Other

[0000038725-16-000385:mdna:88]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses were higher in the first half of 2016 compared to the same period last year due to increases in variable compensation expenses.

[0000038725-16-000385:mdna:89]
Interest Expense

[0000038725-16-000385:mdna:90]
Interest expense for the first half of 2016 and 2015 was $4.6 million and $5.1 million, respectively.

[0000038725-16-000385:mdna:91]
Other Income or Expense

[0000038725-16-000385:mdna:92]
Other income or expense was a gain of $1.3 million in the first half of 2016. Included in other income in the first half of 2016 was minority income $0.4 million and interest income of $0.6 million, primarily derived from the investment of cash balances in short-term securities. The first half of 2015 other income or expense was a gain of $4.4 million. Included in other income in the first half of 2015 was minority income $1.7 million and interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities. The Company also realized a gain on the settlement of the share purchase liability in the first half of 2015 of about $2.7 million.

[0000038725-16-000385:mdna:93]
Foreign Exchange

[0000038725-16-000385:mdna:94]
Foreign currency-based transactions produced a gain for the first half of 2016 of $0.2 million and a gain for the first half of 2015 of $0.1 million.

[0000038725-16-000385:mdna:95]
Income Taxes

[0000038725-16-000385:mdna:96]
The provision for income taxes in the first half of 2016 and 2015 was $12.9 million and $2.0 million, respectively. The effective tax rate for the first half of 2016 was about 25 percent and, before the impact of discrete events, was about 26 percent.  The effective tax rate for the first half of 2015 was about 5 percent and, before the impact of discrete events, was about 27 percent. Discrete adjustments during the first half of 2015 included the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer. This first half 2015 tax benefit of about $4.8 million was treated as a non-GAAP adjustment. Because in 2012, the gain was treated as a non-GAAP adjustment, the Company is consistently treating the reversal of the tax liability related to that gain as a non-GAAP adjustment, reducing reported Earnings per Share in the first half of 2015 by $0.10 cents. The Company also realized a gain on the redeemable non-controlling interest liability in the first half of 2015 of about $2.7 million which is included in ‘Other income’. This purchase transaction also resulted in other tax benefits of about $2.5 million, which were expensed through the Company’s earnings in prior years as well as a current period benefit of about $1.0 million related to the 2015 gain. The average effective tax rate after discrete events for the back half of 2016 is projected to be 25 percent. The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-16-000385:mdna:97]
Net Income

[0000038725-16-000385:mdna:98]
Net income for the first half of 2016 was $37.8 million compared to 2015 first half net income of $36.4 million.  Net income

[0000038725-16-000385:mdna:99]
attributable to Franklin Electric Co., Inc. for the first half of 2016 was $37.4 million, or $0.78 per diluted share, compared to 2015 first half net income attributable to Franklin Electric Co., Inc. of $36.0 million or $0.74 per diluted share. Earnings after non-GAAP adjustments for the first half of 2016 were $37.2 million, or $0.80 per diluted share, compared to the prior year first half earnings after non-GAAP adjustments of $32.1 million or $0.67 per diluted share.

[0000038725-16-000385:mdna:100]
There were specific items in the first half of 2016 and 2015 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000385:mdna:101]
| Earnings Before and After Non-GAAP Adjustments | For the First Half |
| (in millions) | 2016 | 2015 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 37.4 |  | $ | 36.0 |  | 4 | % |
| Allocated Undistributed Earnings | $ | (1.1 | ) | $ | (0.5 | ) |  |
| Earnings for EPS Calculations | $ | 36.3 |  | $ | 35.5 |  | 2 | % |
| Non-GAAP adjustments (before tax): |  |  |  |
| Restructuring | $ | 0.9 |  | $ | 1.2 |  |  |
| Non-GAAP items | $ | 0.6 |  | $ | 1.2 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | (4.8 | ) |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 0.5 |  | $ | 0.7 |  |  |
| Non-GAAP items | $ | 0.4 |  | $ | 0.7 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | (4.8 | ) |  |
| Earnings after Non-GAAP Adjustments | $ | 37.2 |  | $ | 32.1 |  | 16 | % |

[0000038725-16-000385:mdna:102]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the First Half |
| (in millions except Earnings Per Share) | 2016 | 2015 | Change |
| Average Fully Diluted Shares Outstanding | 46.6 |  | 48.1 |  | (3 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.78 |  | $ | 0.74 |  | 5 | % |
| Restructuring Per Share, net of tax | $ | 0.01 |  | $ | 0.02 |  |  |
| Non-GAAP items, net of tax | $ | 0.01 |  | $ | 0.01 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | (0.10 | ) |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.80 |  | $ | 0.67 |  | 19 | % |

[0000038725-16-000385:mdna:103]
[same as prior period, unchanged from 0000038725-16-000333:mdna:52]

[0000038725-16-000385:mdna:104]
[same as prior period, unchanged from 0000038725-16-000333:mdna:53]

[0000038725-16-000385:mdna:105]
[same as prior period, unchanged from 0000038725-16-000333:mdna:54]

[0000038725-16-000385:mdna:106]
30

[0000038725-16-000385:mdna:107]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of July 2, 2016, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-16-000385:mdna:108]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement.  Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)."  The aggregate principal amount of the Project Bonds that were issued and authenticated was limited to $25.0 million.  The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (tax increment financing debt) bear interest at 3.6 percent per annum.  Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.  On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-16-000385:mdna:109]
On April 9, 2007, the Company entered into the Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") in the amount of $175.0 million.  Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”).  The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had at issuance an average life of 10 years with a final maturity in 2019.  On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million.  On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Credit Agreement.  On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015.  On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement.   This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of July 2, 2016, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.

[0000038725-16-000385:mdna:110]
On December 14, 2006, the Company entered into an amended and restated unsecured, 60-month $120.0 million revolving credit agreement (the “Credit Agreement”).  The Credit Agreement provides for various borrowing rate options including interest rates based on the London Interbank Offered Rates (LIBOR) plus interest spreads keyed to the Company’s ratio of debt to earnings before interest, taxes, depreciation, and amortization (“EBITDA”).  On December 14, 2011, the Company executed the Second Amended and Restated Credit Agreement, which extended the maturity of the Credit Agreement to December 14, 2016, and increased the commitment amount to $150.0 million.  On May 5, 2015, the Company entered into Amendment No. 3 to the Credit Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  As of July 2, 2016, the Company had $122.5 million borrowing capacity under the Credit Agreement as $5.5 million in letters of commercial and standby letters of credit were outstanding and undrawn and $22.0 million of revolver borrowing was drawn and outstanding as of the end of the quarter.

[0000038725-16-000385:mdna:111]
The New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws, and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales, and transfers of assets. The covenants also include financial requirements, including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million.  As of July 2, 2016, the Company was in compliance with all financial covenants.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-16-000385:mdna:112]
At July 2, 2016, the Company had $71.6 million of cash on hand at various locations worldwide.  Approximately 20 percent of the cash on hand was in the U.S. and readily accessible.  Approximately 56 percent was in Europe, and the remaining 24 percent was in Mexico, Asia Pacific, and other locations combined.  On a regular basis the Company reviews international cash balances and, if appropriate based on forecasted expenditures and considerations for the post-tax economic efficiency, will reposition cash among its global entities.  Global cash balances are invested according to a written policy, and are generally in bank demand accounts and bank time deposits with the preservation of principal as the highest priority.

[0000038725-16-000385:mdna:113]
[same as prior period, unchanged from 0000038725-16-000333:mdna:63]

[0000038725-16-000385:mdna:114]
Net cash provided by operating activities was $29.3 million for the six months ended July 2, 2016 compared to $7.0 million for the six months ended July 4, 2015.  The increase in cash provided by operations in the first half of 2016 in comparison to the first half of 2015 was largely attributable to large cash outflows in the first half of 2015 related to restructuring costs previously accrued at year-end 2014.  In addition, during the first quarter of 2015, the mandatory share purchase liability of $22.9 million for Pioneer was settled, resulting in a non-cash gain and reversal of certain deferred tax liabilities, also non-cash, both of which were adjustments to net income.

[0000038725-16-000385:mdna:115]
[same as prior period, unchanged from 0000038725-16-000333:mdna:66]

[0000038725-16-000385:mdna:116]
Net cash used in investing activities was $17.1 million for six months ended July 2, 2016 compared to $13.2 million for the six months ended July 4, 2015.  This increase was primarily attributable to an increase in capital expenditures including the purchase of a building during the first quarter of 2016.

[0000038725-16-000385:mdna:117]
[same as prior period, unchanged from 0000038725-16-000333:mdna:68]

[0000038725-16-000385:mdna:118]
Net cash used in financing activities was $21.8 million for the six months ended July 2, 2016 compared to cash provided of $13.6 million for the six months ended July 4, 2015.  During the first half of 2015, cash provided from financing activities was higher primarily due to increased borrowings to fund operating requirements, partially offset by the payment made during the first half of 2015 for the Pioneer mandatory share purchase liability.

[0000038725-16-000385:mdna:119]
[same as prior period, unchanged from 0000038725-16-000333:mdna:70]
