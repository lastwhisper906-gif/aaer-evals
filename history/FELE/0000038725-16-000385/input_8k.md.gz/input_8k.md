# FELE 8-K — 0000038725-16-000381 filed 2016-07-26

## item codes, every 8-K on or before 2016-08-02

- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2016-08-02

- none on or before 2016-08-02

## item 2.02 — earnings release, exhibit 99.1

[0000038725-16-000381:8k_2_02:1]
EX-99.1
2
a201607268-kexhibit991.htm
EXHIBIT 99.1

[0000038725-16-000381:8k_2_02:2]
Exhibit

[0000038725-16-000381:8k_2_02:3]
Exhibit 99.1

[0000038725-16-000381:8k_2_02:4]
For Immediate Release

[0000038725-16-000381:8k_2_02:5]
For Further Information

[0000038725-16-000381:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-16-000381:8k_2_02:7]
260-824-2900

[0000038725-16-000381:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS SECOND QUARTER

[0000038725-16-000381:8k_2_02:9]
2016 SALES AND EARNINGS

[0000038725-16-000381:8k_2_02:10]
Fort Wayne, Indiana - July 26, 2016 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported second quarter 2016 GAAP fully diluted earnings per share (EPS) of $0.50, versus a GAAP fully diluted EPS in the second quarter 2015 of $0.33, an increase of 52 percent.  In the second quarter of 2016, the Company’s adjusted EPS was $0.51 compared to 2015 second quarter adjusted EPS of $0.35, a 46 percent increase (see table below for a reconciliation of GAAP EPS to the adjusted EPS).

[0000038725-16-000381:8k_2_02:11]
Second quarter 2016 sales were $252.1 million, an increase of 2 percent compared to 2015 second quarter sales of $247.4 million.  The Company’s organic sales growth was 5 percent excluding the impact of foreign currency translation.

[0000038725-16-000381:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-16-000381:8k_2_02:13]
“We’re pleased with the overall performance of our Company in the second quarter in which we achieved five percent organic sales growth that was broad based and led by higher groundwater sales in the United States combined with strong Water Systems sales in Latin America and Asia Pacific.  Consolidated adjusted operating income increased 33 percent as we realized the continuing benefits of lower raw material costs, pricing and a favorable sales mix. Fueling Systems adjusted operating income was $15.5 million, an increase of 22 percent versus the second quarter 2015 and a record for any second quarter in the segment’s history.”

[0000038725-16-000381:8k_2_02:14]
Key Performance Indicators:

[0000038725-16-000381:8k_2_02:15]
| Earnings Before and After Non-GAAP Adjustments |  | For the Second Quarter |
| (in millions) |  | 2016 | 2015 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 24.0 |  | $ | 16.2 |  | 48 | % |
| Allocated Undistributed Earnings |  | $ | (0.5 | ) | $ | (0.2 | ) |  |
| Earnings for EPS Calculations |  | $ | 23.5 |  | $ | 16.0 |  | 47 | % |
| Non-GAAP adjustments (before tax): |  |  |  |  |
| Restructuring |  | $ | — |  | $ | 0.8 |  |  |
| Non-GAAP items |  | $ | 0.3 |  | $ | 0.9 |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |
| Restructuring |  | $ | — |  | $ | 0.5 |  |  |
| Non-GAAP items |  | $ | 0.2 |  | $ | 0.5 |  |  |
| Earnings after Non-GAAP Adjustments |  | $ | 23.7 |  | $ | 17.0 |  | 39 | % |
| Earnings Per Share |  | For the Second Quarter |
| Before and After Non-GAAP Adjustments |  | 2016 | 2015 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.7 |  | 48.1 |  | (3 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.50 |  | $ | 0.33 |  | 52 | % |
| Restructuring Per Share, net of tax |  | $ | — |  | $ | 0.01 |  |  |
| Non-GAAP items, net of tax |  | $ | 0.01 |  | $ | 0.01 |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments(Adjusted EPS) |  | $ | 0.51 |  | $ | 0.35 |  | 46 | % |

[0000038725-16-000381:8k_2_02:16]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Consolidated |
| Q2 2015 | $ | 91.2 |  | $ | 31.3 |  | $ | 48.4 |  | $ | 20.7 |  | $ | 191.6 |  | $ | 55.8 |  | $ | 247.4 |  |
| Q2 2016 | $ | 96.3 |  | $ | 31.7 |  | $ | 43.1 |  | $ | 23.5 |  | $ | 194.6 |  | $ | 57.5 |  | $ | 252.1 |  |
| Change | $ | 5.1 |  | $ | 0.4 |  | $ | (5.3 | ) | $ | 2.8 |  | $ | 3.0 |  | $ | 1.7 |  | $ | 4.7 |  |
| % Change | 6 | % | 1 | % | (11 | )% | 14 | % | 2 | % | 3 | % | 2 | % |
| Foreign currency translation | $ | (0.7 | ) | $ | (3.9 | ) | $ | (2.4 | ) | $ | (0.2 | ) | $ | (7.2 | ) | $ | (0.3 | ) | $ | (7.5 | ) |
| % Change | (1 | )% | (12 | )% | (5 | )% | (1 | )% | (4 | )% | (1 | )% | (3 | )% |
| Volume/Price | $ | 5.8 |  | $ | 4.3 |  | $ | (2.9 | ) | $ | 3.0 |  | $ | 10.2 |  | $ | 2.0 |  | $ | 12.2 |  |
| % Change | 7 | % | 13 | % | (6 | )% | 15 | % | 6 | % | 4 | % | 5 | % |

[0000038725-16-000381:8k_2_02:17]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Second Quarter 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 31.5 |  | $ | 15.5 |  | $ | (14.3 | ) | $ | 32.7 |  |
| % Operating Income To Net Sales | 16.2 | % | 27.0 | % |  | 13.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | — |  | $ | — |  | $ | — |  | $ | — |  |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.3 |  | $ | 0.3 |  |
| Operating Income/(Loss) after Non-GAAP Adjustments | $ | 31.5 |  | $ | 15.5 |  | $ | (14.0 | ) | $ | 33.0 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 16.2 | % | 27.0 | % |  | 13.1 | % |
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Second Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 24.3 |  | $ | 12.4 |  | $ | (13.5 | ) | $ | 23.2 |  |
| % Operating Income To Net Sales | 12.7 | % | 22.2 | % |  | 9.4 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.6 |  | $ | 0.2 |  | $ | — |  | $ | 0.8 |  |
| Non-GAAP | $ | 0.5 |  | $ | 0.1 |  | $ | 0.3 |  | $ | 0.9 |  |
| Operating Income/(Loss) after Non-GAAP Adjustments | $ | 25.4 |  | $ | 12.7 |  | $ | (13.2 | ) | $ | 24.9 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 13.3 | % | 22.8 | % |  | 10.1 | % |

[0000038725-16-000381:8k_2_02:18]
Water Systems

[0000038725-16-000381:8k_2_02:19]
Water Systems sales were $194.6 million in the second quarter 2016, an increase of $3.0 million or about 2 percent versus the second quarter 2015 sales of $191.6 million.  Foreign currency translation reduced Water Systems sales by $7.2 million or about 4 percent in the quarter.  Excluding foreign currency translation, Water Systems sales grew about 6 percent compared to the second quarter 2015.

[0000038725-16-000381:8k_2_02:20]
Water Systems sales in the U.S. and Canada were up about 7 percent compared to the prior year second quarter, excluding the impact of foreign currency. In the second quarter 2016, sales of groundwater pumping equipment grew by about 9 percent.  The growth in groundwater equipment sales was led by an 8 percent increase in residential systems and a 13 percent increase in agricultural products.  Water Systems sales in markets outside the U.S. and Canada experienced overall growth of about 4 percent, after excluding the impact of foreign currency translation.  International Water Systems sales growth was led by improved groundwater product sales in the Asia Pacific and Latin America markets, but was offset by a decline in sales in Europe, the Middle East and Gulf regions.

[0000038725-16-000381:8k_2_02:21]
Water Systems operating income was $31.5 million in the second quarter 2016, up $7.2 million or 30 percent versus the second quarter 2015 as reported and up $6.1 million or 24 percent versus the second quarter 2015 after non-GAAP adjustments. The second quarter operating income margin was 16.2 percent, up 290 basis points from 13.3 percent in the second quarter of 2015 after non-GAAP adjustments.

[0000038725-16-000381:8k_2_02:22]
Fueling Systems

[0000038725-16-000381:8k_2_02:23]
Fueling Systems sales were $57.5 million in the second quarter 2016, an increase of $1.7 million or about 3 percent versus the second quarter 2015 sales of $55.8 million.  Fueling Systems sales decreased by $0.3 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems sales were up about 4 percent, after excluding foreign currency translation.

[0000038725-16-000381:8k_2_02:24]
Fueling Systems sales in the U.S. and Canada grew by about 6 percent during the quarter with most of the sales growth coming from fuel management systems.  Internationally, Fueling Systems revenues were down overall with Asia Pacific sales growth being more than offset by lower sales in Europe and Latin America.

[0000038725-16-000381:8k_2_02:25]
Fueling Systems operating income was $15.5 million in the second quarter of 2016, up $3.1 million or about 25 percent compared to $12.4 million in the second quarter of 2015 as reported, and up $2.8 million or 22 percent compared to $12.7 million after non-GAAP adjustments in the second quarter of 2015. The second quarter operating income margin was 27.0 percent, an increase of 420 basis points from the 22.8 percent of net sales in the second quarter of 2015 after non-GAAP adjustments. Fueling Systems operating income in the second quarter of 2016 was a record for any second quarter in the history of the segment.

[0000038725-16-000381:8k_2_02:26]
Overall

[0000038725-16-000381:8k_2_02:27]
The Company’s consolidated gross profit was $90.7 million for the second quarter of 2016, an increase of $10.5 million, or about 13 percent, from the second quarter of 2015 gross profit of $80.2 million. The gross profit as a percent of net sales was 36.0 percent in the second quarter of 2016 and increased about 360 basis points versus 32.4 percent during the second quarter 2015.  The gross profit margin increase was primarily due to favorable pricing, lower direct material costs, a better sales mix and lower fixed cost.

[0000038725-16-000381:8k_2_02:28]
Selling, general, and administrative (SG&A) expenses were $58.0 million in the second quarter of 2016 compared to $56.3 million in the second quarter of the prior year, an increase of $1.7 million or about 3 percent.  The Company’s SG&A expenses increased by $2.5 million in the quarter due to higher variable compensation expenses, which were partially offset by lower fixed cost from the effect of foreign currency translation.

[0000038725-16-000381:8k_2_02:29]
The Company ended the second quarter of 2016 with a cash balance of about $72 million, which was $10 million lower than at the end of 2015.  The cash balance decreased primarily due to higher capital expenditures and seasonal working capital requirements in the Northern hemisphere.

[0000038725-16-000381:8k_2_02:30]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-16-000381:8k_2_02:31]
“As we look to the second half of the year we believe the underlying organic demand for our products is steadily improving.  We remain cautious about our business in the Middle East and specifically, Turkey, as recent political disruptions create uncertainty.  Considering these factors, we re-affirm our annual guidance of $1.60 to $1.70 adjusted earnings per share for full year 2016.”

[0000038725-16-000381:8k_2_02:32]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The second quarter 2016 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-16-000381:8k_2_02:33]
http://edge.media-server.com/m/p/9vfv3icq

[0000038725-16-000381:8k_2_02:34]
If you intend to ask questions during the call, please dial in using (877) 643-7158 for domestic calls and (914) 495-8565 for international calls.  The conference ID is: 47328288.

[0000038725-16-000381:8k_2_02:35]
A replay of the conference call will be available Tuesday, July 26, 2016 at 12:00 noon EDT through midnight EDT on Tuesday, August 2, 2016, by dialing (855) 859-2056 for domestic calls and (404) 537-3406 for international calls. The replay passcode is: 47328288.

[0000038725-16-000381:8k_2_02:36]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-16-000381:8k_2_02:37]
The Company presents the non-GAAP financial measures of earnings after non-GAAP adjustments, fully diluted earnings per share after non-GAAP adjustments (or adjusted EPS), operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments (or operating income margin after non-GAAP adjustments) because the Company believes the information helps investors understand underlying trends in the Company's business more easily. The differences between these measures and the most comparable GAAP measures are reconciled in the tables above.

[0000038725-16-000381:8k_2_02:38]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | July 2, 2016 |  | July 4, 2015 |  | July 2, 2016 |  | July 4, 2015 |
| Net sales | $ | 252,081 |  |  | $ | 247,427 |  |  | $ | 470,511 |  |  | $ | 473,155 |  |
| Cost of sales | 161,403 |  |  | 167,219 |  |  | 305,597 |  |  | 321,457 |  |
| Gross profit | 90,678 |  |  | 80,208 |  |  | 164,914 |  |  | 151,698 |  |
| Selling, general, and administrative expenses | 57,954 |  |  | 56,278 |  |  | 110,299 |  |  | 111,438 |  |
| Restructuring expense | 45 |  |  | 758 |  |  | 865 |  |  | 1,221 |  |
| Operating income | 32,679 |  |  | 23,172 |  |  | 53,750 |  |  | 39,039 |  |
| Interest expense | (2,221 | ) |  | (2,405 | ) |  | (4,648 | ) |  | (5,113 | ) |
| Other income, net | 1,373 |  |  | 1,390 |  |  | 1,341 |  |  | 4,409 |  |
| Foreign exchange income/(expense) | 315 |  |  | (359 | ) |  | 238 |  |  | 57 |  |
| Income before income taxes | 32,146 |  |  | 21,798 |  |  | 50,681 |  |  | 38,392 |  |
| Income tax expense | 7,959 |  |  | 5,360 |  |  | 12,914 |  |  | 1,978 |  |
| Net income | $ | 24,187 |  |  | $ | 16,438 |  |  | $ | 37,767 |  |  | $ | 36,414 |  |
| Less: Net income attributable to noncontrolling interests | (205 | ) |  | (274 | ) |  | (328 | ) |  | (455 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 23,982 |  |  | $ | 16,164 |  |  | $ | 37,439 |  |  | $ | 35,959 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.51 |  |  | $ | 0.33 |  |  | $ | 0.79 |  |  | $ | 0.74 |  |
| Diluted | $ | 0.50 |  |  | $ | 0.33 |  |  | $ | 0.78 |  |  | $ | 0.74 |  |

[0000038725-16-000381:8k_2_02:39]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | July 2, 2016 |  | January 2, 2016 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 71,582 |  |  | $ | 81,561 |  |
| Receivables | 161,972 |  |  | 127,251 |  |
| Inventories | 210,642 |  |  | 194,594 |  |
| Other current assets | 29,531 |  |  | 34,715 |  |
| Total current assets | 473,727 |  |  | 438,121 |  |
| Property, plant, and equipment, net | 195,916 |  |  | 190,039 |  |
| Goodwill and other assets | 371,320 |  |  | 367,951 |  |
| Total assets | $ | 1,040,963 |  |  | $ | 996,111 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 56,983 |  |  | $ | 57,822 |  |
| Accrued expenses and other current liabilities | 61,636 |  |  | 53,903 |  |
| Current maturities of long-term debt and short-term borrowings | 55,673 |  |  | 32,946 |  |
| Total current liabilities | 174,292 |  |  | 144,671 |  |
| Long-term debt | 157,203 |  |  | 187,806 |  |
| Deferred income taxes | 39,289 |  |  | 33,404 |  |
| Employee benefit plans | 42,337 |  |  | 47,398 |  |
| Other long-term liabilities | 18,660 |  |  | 16,511 |  |
| Redeemable noncontrolling interest | 7,617 |  |  | 6,856 |  |
| Total equity | 601,565 |  |  | 559,465 |  |
| Total liabilities and equity | $ | 1,040,963 |  |  | $ | 996,111 |  |

[0000038725-16-000381:8k_2_02:40]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Six Months Ended |
| (In thousands) | July 2, 2016 |  | July 4, 2015 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 37,767 |  |  | $ | 36,414 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 17,633 |  |  | 18,044 |  |
| Share-based compensation | 4,155 |  |  | 3,457 |  |
| Realized gain on share purchase liability | — |  |  | (2,723 | ) |
| Other | 4,404 |  |  | (6,777 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (31,221 | ) |  | (16,655 | ) |
| Inventory | (10,982 | ) |  | (6,355 | ) |
| Accounts payable and accrued expenses | 3,091 |  |  | (15,110 | ) |
| Other | 4,464 |  |  | (3,263 | ) |
| Net cash flows from operating activities | 29,311 |  |  | 7,032 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (19,490 | ) |  | (9,758 | ) |
| Proceeds from sale of property, plant, and equipment | 2,166 |  |  | 402 |  |
| Acquisitions and investments | — |  |  | (4,028 | ) |
| Other investing activities | 178 |  |  | 174 |  |
| Net cash flows from investing activities | (17,146 | ) |  | (13,210 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (7,851 | ) |  | 47,777 |  |
| Proceeds from issuance of common stock | 610 |  |  | 1,240 |  |
| Excess tax from share-based payment arrangements | — |  |  | 811 |  |
| Purchases of common stock | (4,736 | ) |  | (6,218 | ) |
| Dividends paid | (9,821 | ) |  | (9,783 | ) |
| Share purchase liability payment | — |  |  | (20,200 | ) |
| Net cash flows from financing activities | (21,798 | ) |  | 13,627 |  |
| Effect of exchange rate changes on cash | (346 | ) |  | (3,556 | ) |
| Net change in cash and equivalents | (9,979 | ) |  | 3,893 |  |
| Cash and equivalents at beginning of period | 81,561 |  |  | 59,141 |  |
| Cash and equivalents at end of period | $ | 71,582 |  |  | $ | 63,034 |  |
