# FELE note change history — 0000038725-17-000168 → 0000038725-18-000096


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0000038725-18-000096:note_history:1]
At March 31, 2018, the Company had $6.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2017-10-31, similarity 0.966):
[0000038725-17-000168:note_history:1]
At September 30, 2017, the Company had $8.7 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2018-05-08):
[0000038725-18-000096:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2018, are as follows:
  (was, 2017-10-31, similarity 0.8921):
[0000038725-17-000168:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2017, are as follows:

- changed (2018-05-08):
[0000038725-18-000096:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2017 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 2.0 |  |
| Additions related to acquisitions |  | 0.1 |  |
| Reductions for payments made |  | (2.9 | ) |
| Balance as of March 31, 2018 |  | $ | 8.7 |  |
  (was, 2017-10-31, similarity 0.9717):
[0000038725-17-000168:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2016 |  | $ | 8.2 |  |
| Accruals related to product warranties |  | 7.3 |  |
| Additions related to acquisitions |  | 1.3 |  |
| Reductions for payments made |  | (6.8 | ) |
| Balance as of September 30, 2017 |  | $ | 10.0 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0000038725-18-000096:note_history:4]
The accompanying condensed consolidated balance sheet as of December 31, 2017, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2018, and for the first quarters ended March 31, 2018 and March 31, 2017 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended March 31, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2018.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2017.
  (was, 2017-10-31, similarity 0.9353):
[0000038725-17-000168:note_history:4]
The accompanying condensed consolidated balance sheet as of December 31, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2017, and for the third quarters and nine months ended September 30, 2017 and October 1, 2016 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the third quarter and nine months ended September 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2017.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2016.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0000038725-18-000096:note_history:5]
| (In millions) |  | March 31, 2018 |  | December 31, 2017 |
| Prudential Agreement |  | $ | 60.0 |  |  | $ | 60.0 |  |
| Tax increment financing debt |  | 20.3 |  |  | 20.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 118.8 |  |  | 67.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.1 |  |  | 3.5 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 278.0 |  |  | $ | 226.1 |  |
| Less: current maturities |  | (152.9 | ) |  | (100.5 | ) |
| Long-term debt |  | $ | 125.1 |  |  | $ | 125.6 |  |
  (was, 2017-10-31, similarity 0.8771):
[0000038725-17-000168:note_history:5]
| (In millions) |  | September 30, 2017 |  | December 31, 2016 |
| Prudential Agreement |  | $ | 60.0 |  |  | $ | 90.0 |  |
| Tax increment financing debt |  | 20.8 |  |  | 21.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 69.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.6 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 229.7 |  |  | $ | 190.2 |  |
| Less: current maturities |  | (104.1 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 125.6 |  |  | $ | 156.5 |  |

- changed (2018-05-08):
[0000038725-18-000096:note_history:6]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2018 matures as follows:
  (was, 2017-10-31, similarity 0.9474):
[0000038725-17-000168:note_history:6]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2017 matures as follows:

- changed (2018-05-08):
[0000038725-18-000096:note_history:7]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 278.2 |  |  | $ | 152.9 |  |  | $ | 31.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 90.2 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 278.3 |  |  | $ | 152.9 |  |  | $ | 31.4 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 90.2 |  |
  (was, 2017-10-31, similarity 0.6306):
[0000038725-17-000168:note_history:7]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 229.9 |  |  | $ | 104.0 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 90.8 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 230.0 |  |  | $ | 104.1 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 90.8 |  |

- changed (2018-05-08):
[0000038725-18-000096:note_history:8]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of March 31, 2018, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.
  (was, 2017-10-31, similarity 0.9884):
[0000038725-17-000168:note_history:8]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of September 30, 2017, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.

- changed (2018-05-08):
[0000038725-18-000096:note_history:9]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (1.88 percent as of March 31, 2018) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of March 31, 2018, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.
  (was, 2017-10-31, similarity 0.9771):
[0000038725-17-000168:note_history:9]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (1.24 percent as of September 30, 2017) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of September 30, 2017, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

- changed (2018-05-08):
[0000038725-18-000096:note_history:10]
As of March 31, 2018, the Company had $118.8 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $5.3 million in letters of credit outstanding, and $175.9 million of available capacity under the Credit Agreement.
  (was, 2017-10-31, similarity 0.9719):
[0000038725-17-000168:note_history:10]
As of September 30, 2017, the Company had $69.5 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $5.5 million in letters of credit outstanding, and $225.0 million of available capacity under the Credit Agreement.

- changed (2018-05-08):
[0000038725-18-000096:note_history:11]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2018.
  (was, 2017-10-31, similarity 0.9629):
[0000038725-17-000168:note_history:11]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with these significant financial covenants as of September 30, 2017.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0000038725-18-000096:note_history:12]
| (In millions) |  | March 31, 2018 |  | December 31, 2017 |
| Prudential Agreement |  | $ | 60.0 |  |  | $ | 60.0 |  |
| Tax increment financing debt |  | 20.3 |  |  | 20.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 118.8 |  |  | 67.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.1 |  |  | 3.5 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 278.0 |  |  | $ | 226.1 |  |
| Less: current maturities |  | (152.9 | ) |  | (100.5 | ) |
| Long-term debt |  | $ | 125.1 |  |  | $ | 125.6 |  |
  (was, 2017-10-31, similarity 0.8771):
[0000038725-17-000168:note_history:12]
| (In millions) |  | September 30, 2017 |  | December 31, 2016 |
| Prudential Agreement |  | $ | 60.0 |  |  | $ | 90.0 |  |
| Tax increment financing debt |  | 20.8 |  |  | 21.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 69.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.6 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 229.7 |  |  | $ | 190.2 |  |
| Less: current maturities |  | (104.1 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 125.6 |  |  | $ | 156.5 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0000038725-18-000096:note_history:13]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2018 matures as follows:
  (was, 2017-10-31, similarity 0.9474):
[0000038725-17-000168:note_history:13]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2017 matures as follows:

- changed (2018-05-08):
[0000038725-18-000096:note_history:14]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 278.2 |  |  | $ | 152.9 |  |  | $ | 31.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 90.2 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 278.3 |  |  | $ | 152.9 |  |  | $ | 31.4 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 90.2 |  |
  (was, 2017-10-31, similarity 0.6306):
[0000038725-17-000168:note_history:14]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 229.9 |  |  | $ | 104.0 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 90.8 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 230.0 |  |  | $ | 104.1 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 90.8 |  |
