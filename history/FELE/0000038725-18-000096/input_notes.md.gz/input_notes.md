# FELE notes — 0000038725-18-000096


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000038725-18-000096:notes:1]
| FRANKLIN ELECTRIC CO., INC. |
| PROFORMA CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
|  |  | First Quarter Ended |
| (in millions, except per share amounts) |  | March 31, 2018 |  | March 31, 2017 |
| Revenue: |  |  |  |  |
| As reported |  | $ | 295.6 |  |  | $ | 220.3 |  |
| Proforma |  | 295.6 |  |  | 270.3 |  |
| Net income: |  |  |  |  |
| As reported |  | $ | 21.2 |  |  | $ | 15.7 |  |
| Proforma |  | 21.2 |  |  | 16.6 |  |
| Basic earnings per share: |  |  |  |  |
| As reported |  | $ | 0.45 |  |  | $ | 0.33 |  |
| Proforma |  | 0.45 |  |  | 0.35 |  |
| Diluted earnings per share: |  |  |  |  |
| As reported |  | $ | 0.45 |  |  | $ | 0.33 |  |
| Proforma |  | 0.45 |  |  | 0.35 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-18-000096:notes:2]
[same as prior period, unchanged from 0000038725-17-000168:notes:2]

[0000038725-18-000096:notes:3]
During the first quarter ended March 31, 2018, the Company acquired 100 percent of the ownership interests of Lansing, Michigan-based Valley Farms Supply, Inc. ("Valley Farms"), for a purchase price of approximately $9.2 million.  Valley Farms is a professional groundwater distributor operating three locations in the State of Michigan and one in the State of Indiana.  Valley Farms was acquired to serve customers in this region of the United States as part of the Company’s Distribution Segment, which is a collection of leading groundwater distributors.  The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2018, as results of operations for this acquisition is immaterial.

[0000038725-18-000096:notes:4]
During the second quarter of 2017, the Company redeemed 10 percent of the noncontrolling interest of Impo, a Turkish subsidiary, increasing the Company’s ownership to 100 percent for approximately TRY 17.0 million, $5.0 million at the then current exchange rate.  The 10 percent redemption value was calculated using a specified formula and resulted in a reduction to the carrying value of TRY 0.6 million ($0.2 million).  Due to the immaterial nature of the redemption, the Company has not included full year proforma statements of income for the periods presented.

[0000038725-18-000096:notes:5]
During the second quarter of 2017, the Company acquired controlling interests in three distributors (2M Company, Inc. (“2M”), Drillers Service, Inc. (“DSI”), and Western Hydro, LLC (“Western Hydro”), collectively referred to below as the “Headwater acquisitions”) in the U.S. professional groundwater market for a combined purchase price of approximately $57.4 million, subject to certain terms and conditions.  The Company had previously prepaid a $3.0 million portion of the purchase price at the time of original investment.  The Company funded the Headwater acquisitions with cash on hand and short-term borrowings from the Company’s Revolver (see Note 10 - Debt).  The Headwater acquisitions provide the Company with a professional groundwater distribution channel throughout the United States.

[0000038725-18-000096:notes:6]
The Company previously held equity interests in these entities, each of which was less than 50 percent, and accounted for by the equity method of accounting.  The Company’s total interest in each of the entities is now 100 percent and the entities are included in the Company’s consolidated results effective from the date of acquisition.  The original equity interests in the acquired entities were remeasured to their fair values as of the acquisition date (which aggregated was $20.6 million) based on the income approach, which utilized management estimates and consultation with an independent third-party valuation firm.  Inputs included an analysis of the enterprise value based on financial projections and ownership percentages.

[0000038725-18-000096:notes:7]
The preliminary identifiable intangible assets recognized due to the Headwater acquisitions were $5.7 million and consist of customer relationships, which will be amortized utilizing the straight-line method over 15 years.  The fair value of the identifiable intangible assets has been estimated using an income approach, a valuation method that values an intangible asset by discounting the future incremental earnings that may be achieved by the subject intangible asset.

[0000038725-18-000096:notes:8]
The preliminary goodwill of $33.9 million resulting from the Headwater acquisitions consists primarily of the benefits of forward channel integration opportunities and broadened product offerings. All of the goodwill was recorded as part of the Distribution segment, and only a portion ($7.8 million) is expected to be deductible for tax purposes.

[0000038725-18-000096:notes:9]
[same as prior period, unchanged from 0000038725-17-000168:notes:8]

[0000038725-18-000096:notes:10]
| (In millions) |  |  |
| Cash |  | $ | 2.7 |  |
| Receivables |  | 29.9 |  |
| Inventory |  | 56.0 |  |
| Other current assets |  | 5.1 |  |
| Total current assets |  | 93.7 |  |
| Property, plant, and equipment |  | 9.8 |  |
| Intangible assets |  | 5.7 |  |
| Goodwill |  | 33.9 |  |
| Other assets |  | 0.2 |  |
| Total assets |  | 143.3 |  |
| Accounts payable |  | (19.6 | ) |
| Accrued liabilities and other current liabilities |  | (11.4 | ) |
| Current maturities of long-term debt |  | (31.6 | ) |
| Total current liabilities |  | (62.6 | ) |
| Long-term debt |  | (2.0 | ) |
| Other long-term liabilities |  | (0.7 | ) |
| Total liabilities |  | (65.3 | ) |
| Total |  | 78.0 |  |
| Less: Fair value of original equity interest |  | (20.6 | ) |
| Total purchase price |  | $ | 57.4 |  |

[0000038725-18-000096:notes:11]
The fair values of the assets acquired and liabilities assumed related to the Headwater acquisitions are provisional amounts as of March 31, 2018, pending final valuations and purchase accounting adjustments. The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation process.

[0000038725-18-000096:notes:12]
The following unaudited proforma financial information for the first quarters ended March 31, 2018 and March 31, 2017 gives effect to the Headwater acquisitions by the Company as if the acquisitions had occurred as of January 1, 2017.  These unaudited proforma condensed consolidated financial statements are prepared for informational purposes only and are not necessarily indicative of actual results or financial position that would have been achieved had the acquisitions been consummated on the dates indicated and are not necessarily indicative of future operating results or financial position of the consolidated companies.  The unaudited proforma condensed consolidated financial statements do not give effect to any cost savings or incremental costs that may result from the integration of the Headwater acquisitions with the Company.

[0000038725-18-000096:notes:13]
The Headwater entities contributed a total of $56.2 million of revenue and $0.9 million of net loss to the Company's condensed consolidated statements of income for the first quarter ended March 31, 2018.

[0000038725-18-000096:notes:14]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations.  There were $0.1 million and $0.2 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the first quarters ended March 31, 2018 and March 31, 2017, respectively.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-18-000096:notes:15]
COMMITMENTS AND CONTINGENCIES

[0000038725-18-000096:notes:16]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-18-000096:notes:17]
At March 31, 2018, the Company had $6.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-18-000096:notes:18]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two to five years from date of manufacture or one to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-18-000096:notes:19]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2018, are as follows:

[0000038725-18-000096:notes:20]
| (In millions) |  |  |
| Balance as of December 31, 2017 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 2.0 |  |
| Additions related to acquisitions |  | 0.1 |  |
| Reductions for payments made |  | (2.9 | ) |
| Balance as of March 31, 2018 |  | $ | 8.7 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-18-000096:notes:21]
[same as prior period, unchanged from 0000038725-17-000168:notes:20]

[0000038725-18-000096:notes:22]
Changes in accumulated other comprehensive income/(loss) by component for the first quarters ended March 31, 2018 and March 31, 2017, are summarized below:

[0000038725-18-000096:notes:23]
| (In millions) |  |  |  |  |  |
| For the first quarter ended March 31, 2018: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2017 | $ | (99.7 | ) |  | $ | (49.3 | ) |  | $ | (149.0 | ) |
| Other comprehensive income/(loss) before reclassifications | 6.9 |  | — |  |  | 6.9 |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.6 |  |  | 0.6 |  |
| Net other comprehensive income/(loss) | 6.9 |  |  | 0.6 |  |  | 7.5 |  |
| Balance as of March 31, 2018 | $ | (92.8 | ) |  | $ | (48.7 | ) |  | $ | (141.5 | ) |
| For the first quarter ended March 31, 2017 |  |  |  |  |  |
| Balance as of December 31, 2016 | $ | (118.4 | ) |  | $ | (51.5 | ) |  | $ | (169.9 | ) |
| Other comprehensive income/(loss) before reclassifications | 8.4 |  |  | — |  |  | 8.4 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.5 |  |  | 0.5 |  |
| Net other comprehensive income/(loss) | 8.4 |  |  | 0.5 |  |  | 8.9 |  |
| Balance as of March 31, 2017 | $ | (110.0 | ) |  | $ | (51.0 | ) |  | $ | (161.0 | ) |

[0000038725-18-000096:notes:24]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 8 for additional details) and is included in the "Other income/(expense), net" line of the Company's condensed consolidated statements of income.

[0000038725-18-000096:notes:25]
(2) Net of tax expense of $0.2 million and $0.3 million for the first quarters ended March 31, 2018 and March 31, 2017, respectively.

[0000038725-18-000096:notes:26]
[same as prior period, unchanged from 0000038725-17-000168:notes:25]


## us-gaap:DebtDisclosureTextBlock

[0000038725-18-000096:notes:27]
DEBT

[0000038725-18-000096:notes:28]
Debt consisted of the following:

[0000038725-18-000096:notes:29]
| (In millions) |  | March 31, 2018 |  | December 31, 2017 |
| Prudential Agreement |  | $ | 60.0 |  |  | $ | 60.0 |  |
| Tax increment financing debt |  | 20.3 |  |  | 20.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 118.8 |  |  | 67.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.1 |  |  | 3.5 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 278.0 |  |  | $ | 226.1 |  |
| Less: current maturities |  | (152.9 | ) |  | (100.5 | ) |
| Long-term debt |  | $ | 125.1 |  |  | $ | 125.6 |  |

[0000038725-18-000096:notes:30]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2018 matures as follows:

[0000038725-18-000096:notes:31]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 278.2 |  |  | $ | 152.9 |  |  | $ | 31.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 90.2 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 278.3 |  |  | $ | 152.9 |  |  | $ | 31.4 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 90.2 |  |

[0000038725-18-000096:notes:32]
Prudential Agreement

[0000038725-18-000096:notes:33]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of March 31, 2018, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-18-000096:notes:34]
Project Bonds

[0000038725-18-000096:notes:35]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-18-000096:notes:36]
New York Life

[0000038725-18-000096:notes:37]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (1.88 percent as of March 31, 2018) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of March 31, 2018, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-18-000096:notes:38]
Credit Agreement

[0000038725-18-000096:notes:39]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-18-000096:notes:40]
As of March 31, 2018, the Company had $118.8 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $5.3 million in letters of credit outstanding, and $175.9 million of available capacity under the Credit Agreement.

[0000038725-18-000096:notes:41]
Covenants

[0000038725-18-000096:notes:42]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-18-000096:notes:43]
[same as prior period, unchanged from 0000038725-17-000168:notes:42]

[0000038725-18-000096:notes:44]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements ("the swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of March 31, 2018, the swap had a notional value based on 215,000 shares.  For the first quarters ended March 31, 2018 and March 31, 2017, the swap resulted in a loss of $1.1 million and a gain of $0.8 million, respectively.  Gains and losses resulting from the the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-18-000096:notes:45]
[same as prior period, unchanged from 0000038725-17-000168:notes:44]

[0000038725-18-000096:notes:46]
The Franklin Electric Co., Inc. 2017 Stock Plan (the "2017 Stock Plan") is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, stock unit awards, and stock appreciation rights ("SARs") to key employees and non-employee directors.  The number of shares that may be issued under the Plan is 1,400,000.  Stock options and SARs reduce the number of available shares by one share for each share subject to the option or SAR, and stock awards and stock unit awards settled in shares reduce the number of available shares by 1.5 shares for every one share delivered.

[0000038725-18-000096:notes:47]
[same as prior period, unchanged from 0000038725-17-000168:notes:46]

[0000038725-18-000096:notes:48]
[same as prior period, unchanged from 0000038725-17-000168:notes:47]

[0000038725-18-000096:notes:49]
[same as prior period, unchanged from 0000038725-17-000168:notes:48]

[0000038725-18-000096:notes:50]
[same as prior period, unchanged from 0000038725-17-000168:notes:49]

[0000038725-18-000096:notes:51]
[same as prior period, unchanged from 0000038725-17-000168:notes:50]

[0000038725-18-000096:notes:52]
[same as prior period, unchanged from 0000038725-17-000168:notes:51]

[0000038725-18-000096:notes:53]
[same as prior period, unchanged from 0000038725-17-000168:notes:52]

[0000038725-18-000096:notes:54]
[same as prior period, unchanged from 0000038725-17-000168:notes:53]

[0000038725-18-000096:notes:55]
[same as prior period, unchanged from 0000038725-17-000168:notes:54]

[0000038725-18-000096:notes:56]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the first quarters ended March 31, 2018 and March 31, 2017 are as follows:

[0000038725-18-000096:notes:57]
|  |  | March 31, 2018 |  | March 31, 2017 |
| Risk-free interest rate |  | 2.69 | % |  | 1.89 | % |
| Dividend yield |  | 1.05 | % |  | 0.94 | % |
| Volatility factor |  | 28.71 | % |  | 31.19 | % |
| Expected term |  | 5.6 years |  |  | 5.5 years |  |

[0000038725-18-000096:notes:58]
A summary of the Company’s outstanding stock option activity and related information for the first quarter ended March 31, 2018 is as follows:

[0000038725-18-000096:notes:59]
| (Shares in thousands) |  | March 31, 2018 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,388 |  |  | $ | 28.79 |  |
| Granted |  | 239 |  |  | 40.25 |  |
| Exercised |  | (25 | ) |  | 25.68 |  |
| Forfeited |  | (2 | ) |  | 38.67 |  |
| Outstanding at end of period |  | 1,600 |  |  | $ | 30.54 |  |
| Expected to vest after applying forfeiture rate |  | 1,569 |  |  | $ | 30.37 |  |
| Vested and exercisable at end of period |  | 1,064 |  |  | $ | 26.73 |  |

[0000038725-18-000096:notes:60]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of March 31, 2018 is as follows:

[0000038725-18-000096:notes:61]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.93 years |  | $ | 16,890 |  |
| Expected to vest after applying forfeiture rate |  | 5.86 years |  | $ | 16,823 |  |
| Vested and exercisable at end of period |  | 4.41 years |  | $ | 15,232 |  |

[0000038725-18-000096:notes:62]
The total intrinsic value of options exercised during the first quarters ended March 31, 2018 and March 31, 2017 was $0.4 million and $0.6 million, respectively.

[0000038725-18-000096:notes:63]
As of March 31, 2018, there was $2.6 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.85 years.

[0000038725-18-000096:notes:64]
[same as prior period, unchanged from 0000038725-17-000168:notes:63]

[0000038725-18-000096:notes:65]
A summary of the Company’s restricted stock/stock unit award activity and related information for the quarter ended March 31, 2018 is as follows:

[0000038725-18-000096:notes:66]
| (Shares in thousands) |  | March 31, 2018 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 463 |  |  | $ | 36.71 |  |
| Awarded |  | 148 |  |  | 40.43 |  |
| Vested |  | (54 | ) |  | 42.64 |  |
| Forfeited |  | (11 | ) |  | 36.26 |  |
| Non-vested at end of period |  | 546 |  |  | $ | 37.14 |  |

[0000038725-18-000096:notes:67]
As of March 31, 2018, there was $13.3 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.69 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-18-000096:notes:68]
[same as prior period, unchanged from 0000038725-17-000168:notes:67]

[0000038725-18-000096:notes:69]
[same as prior period, unchanged from 0000038725-17-000168:notes:68]

[0000038725-18-000096:notes:70]
[same as prior period, unchanged from 0000038725-17-000168:notes:69]

[0000038725-18-000096:notes:71]
[same as prior period, unchanged from 0000038725-17-000168:notes:70]

[0000038725-18-000096:notes:72]
|  | First Quarter Ended |
| (In millions, except per share amounts) | March 31, 2018 |  | March 31, 2017 |
| Numerator: |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 21.2 |  |  | $ | 15.7 |  |
| Less: Undistributed earnings allocated to participating securities | 0.2 |  |  | 0.1 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | — |  |  | 0.1 |  |
| Net income available to common shareholders | $ | 21.0 |  |  | $ | 15.5 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.6 |  |  | 46.4 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.5 |  |  | 0.6 |  |
| Diluted weighted average common shares outstanding | 47.1 |  |  | 47.0 |  |
| Basic earnings per share | $ | 0.45 |  |  | $ | 0.33 |  |
| Diluted earnings per share | $ | 0.45 |  |  | $ | 0.33 |  |

[0000038725-18-000096:notes:73]
There were 0.3 million and 0.2 million stock options outstanding for the first quarters ended March 31, 2018 and March 31, 2017, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000038725-18-000096:notes:74]
[same as prior period, unchanged from 0000038725-17-000168:notes:73]

[0000038725-18-000096:notes:75]
Through the second quarter of 2017, the Company held equity interests in the acquired companies identified in Note 3 - Acquisitions for various strategic purposes.  The investments were accounted for under the equity method and were included in “Other assets” on the Company’s condensed consolidated balance sheets.  The carrying amount of the investments were adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments were not considered material to the Company’s financial position, either individually or in the aggregate.  During the second quarter of 2017, the remaining interests of these equity method investments were purchased (see Note 3 - Acquisitions), bringing total ownership of these entities to 100 percent.  As of March 31, 2018, there were no equity method investments recorded on the Company's condensed consolidated balance sheets.  Prior to the purchase of the remaining interests, the Company’s proportionate share of earnings from its equity interests, were included in the "Other income, net" line of the Company's condensed consolidated statements of income.  This amount was immaterial for the first quarter ended March 31, 2017.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-18-000096:notes:76]
As of March 31, 2018 and December 31, 2017, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-18-000096:notes:77]
| (In millions) | March 31, 2018 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.5 |  | $ | 3.5 |  | $ | — |  | $ | — |  |
|  | December 31, 2017 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.0 |  | $ | 3.0 |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-18-000096:notes:78]
[same as prior period, unchanged from 0000038725-17-000168:notes:77]

[0000038725-18-000096:notes:79]
[same as prior period, unchanged from 0000038725-17-000168:notes:78]

[0000038725-18-000096:notes:80]
[same as prior period, unchanged from 0000038725-17-000168:notes:79]

[0000038725-18-000096:notes:81]
[same as prior period, unchanged from 0000038725-17-000168:notes:80]

[0000038725-18-000096:notes:82]
[same as prior period, unchanged from 0000038725-17-000168:notes:81]

[0000038725-18-000096:notes:83]
[same as prior period, unchanged from 0000038725-17-000168:notes:82]

[0000038725-18-000096:notes:84]
[same as prior period, unchanged from 0000038725-17-000168:notes:83]

[0000038725-18-000096:notes:85]
Total debt, including current maturities, have carrying amounts of $278.0 million and $226.0 million and estimated fair values of $280 million and $230 million as of March 31, 2018 and December 31, 2017, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-18-000096:notes:86]
[same as prior period, unchanged from 0000038725-17-000168:notes:85]

[0000038725-18-000096:notes:87]
[same as prior period, unchanged from 0000038725-17-000168:notes:86]

[0000038725-18-000096:notes:88]
| (In millions) |  | March 31, 2018 |  | December 31, 2017 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.6 |  |  | $ | (6.8 | ) |  | $ | 7.5 |  |  | $ | (6.7 | ) |
| Technology |  | 7.5 |  |  | (6.0 | ) |  | 7.5 |  |  | (5.8 | ) |
| Customer relationships |  | 139.4 |  |  | (59.6 | ) |  | 138.9 |  |  | (57.6 | ) |
| Other |  | 3.0 |  |  | (2.6 | ) |  | 2.9 |  |  | (2.4 | ) |
| Total |  | $ | 157.5 |  |  | $ | (75.0 | ) |  | $ | 156.8 |  |  | $ | (72.5 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 47.4 |  |  | — |  |  | 47.2 |  |  | — |  |
| Total intangibles |  | $ | 204.9 |  |  | $ | (75.0 | ) |  | $ | 204.0 |  |  | $ | (72.5 | ) |

[0000038725-18-000096:notes:89]
Amortization expense related to intangible assets for the first quarters ended March 31, 2018 and March 31, 2017 was $2.2 million and $2.1 million, respectively.

[0000038725-18-000096:notes:90]
[same as prior period, unchanged from 0000038725-17-000168:notes:89]

[0000038725-18-000096:notes:91]
| (In millions) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |
|  |  | $ | 8.8 |  |  | $ | 8.6 |  |  | $ | 8.5 |  |  | $ | 8.1 |  |  | $ | 7.9 |  |

[0000038725-18-000096:notes:92]
The change in the carrying amount of goodwill by reporting segment for the three months ended March 31, 2018, is as follows:

[0000038725-18-000096:notes:93]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2017 |  | $ | 139.3 |  |  | $ | 63.6 |  |  | $ | 33.9 |  |  | $ | 236.8 |  |
| Acquisitions |  | — |  |  | — |  |  | 1.5 |  |  | 1.5 |  |
| Foreign currency translation |  | 0.6 |  |  | 0.1 |  |  | — |  |  | 0.7 |  |
| Balance as of March 31, 2018 |  | $ | 139.9 |  |  | $ | 63.7 |  |  | $ | 35.4 |  |  | $ | 239.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-18-000096:notes:94]
[same as prior period, unchanged from 0000038725-17-000168:notes:93]

[0000038725-18-000096:notes:95]
The Company’s effective tax rate from continuing operations for the three month period ended March 31, 2018 was negative 8.7 percent as compared to 1.3 percent for the three month period ended March 31, 2017. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to the recognition of the foreign-derived intangible income (FDII) provisions in the U.S. Tax Cuts and Jobs Act (Tax Act) and certain discrete events.

[0000038725-18-000096:notes:96]
The decrease in the effective tax rate for the three months ended March 31, 2018, compared with the same period in 2017, was primarily affected by the Tax Act, which reduced the U.S. federal corporate income tax rate from 35 percent to 21 percent effective January 1, 2018. The Company also reflected an estimated tax benefit of $3.1 million associated with the FDII provisions of the Tax Act that were effective for the first time during 2018. In addition, during the three month period ended March 31, 2018, the Company released a valuation allowance of $5.4 million related to state NOLs and incentives as it is no longer in a three-year cumulative loss position for certain state income tax purposes.

[0000038725-18-000096:notes:97]
The Company’s accounting for certain aspects of the Tax Act remains provisional. As noted at year-end 2017, the Company was able to reasonably estimate certain effects and, therefore, recorded provisional adjustments associated with the deemed repatriation transition tax and the remeasurement of deferred taxes. The Company has not made any additional measurement-period adjustments related to these items during the quarter as the analysis requires significant data from foreign subsidiaries that is not yet final due to future statutory deadlines as well as pending guidance from state and local tax authorities in the U.S. However, the Company is continuing to gather additional information to complete our accounting for these items. The accounting for the tax effects of the Tax Act will be completed in 2018.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-18-000096:notes:98]
ACCOUNTING PRONOUNCEMENTS

[0000038725-18-000096:notes:99]
Adoption of New Accounting Standards

[0000038725-18-000096:notes:100]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2017-07, Compensation - Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  This ASU requires entities to present only the service cost component of net periodic benefit cost as an operating expense (consistent with the presentation of other employee compensation costs).  The other components of net periodic benefit cost are to be presented as a non-operating expense.  The Company adopted ASU 2017-07 during the first quarter ended March 31, 2018. The prior year non-service cost component of net periodic benefit costs as of March 31, 2017 was less than $0.1 million and is not considered significant.  The Company has included current year non-service costs as non-operating expense.  The adoption of this pronouncement did not have a material impact to the Company’s condensed consolidated financial position, results of operations, or cash flows.

[0000038725-18-000096:notes:101]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) as modified by subsequently issued ASUs 2015-14, 2016-08, 2016-10, 2016-12 and 2016-20 (collectively ASU 2014-09).  Topic 606 supersedes the revenue recognition requirements in Accounting Standards Codification (“ASC”) Topic 605, Revenue Recognition (“Topic 605”), and requires the recognition of revenue when promised goods or services are transferred to customers in an amount that reflects the considerations to which the entity expects to be entitled to in exchange for those goods or services.  The Company made the accounting policy election allowed by ASC 606-10-32-2A to continue to present sales tax on a net basis, consistent with current guidance in ASC 605-45-15-2(e).  The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method).  The Company adopted ASU 2014-09 during the first quarter ended March 31, 2018 utilizing the modified retrospective approach. The adoption of this ASU did not have a material impact to the Company’s condensed consolidated financial position, results of operations, or cash flow; however, the adoption of this ASU requires the Company to disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company completed its assessment of the additional disclosure requirements with the following results:

[0000038725-18-000096:notes:102]
Disaggregation of Revenue

[0000038725-18-000096:notes:103]
The adoption of this ASU requires the company to disaggregate revenue into categories to depict how the nature, timing, and uncertainty of revenue and cash flows are affected by economic factors.  As evidenced in Footnote 14 Segment and Geographic Information, the Company’s business consists of the Water, Fueling, Distribution, and Other segments. The Other segment includes unallocated corporate expenses and intersegment eliminations. A reconciliation of disaggregated revenue to segment revenue as well as Water Segment revenue by geographical regions is provided in Footnote 14, consistent with how the Company evaluates financial performance.

[0000038725-18-000096:notes:104]
Performance Obligations

[0000038725-18-000096:notes:105]
A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in ASC Topic 606.  The Company typically sells its products to customers by purchase order, and does not have any additional performance obligations included in contracts to customers other than the shipment of products. The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience. The Company typically ships products FOB shipping at which point control of the products passes to the customers. Any shipping and handling fees prior to shipment are considered activities required to fulfill the Company’s promise to transfer goods, and do not qualify as a separate performance obligation. Shipping and handling costs are recorded as a component of cost of sales.  Additionally, the Company offers assurance-type warranties (vs. service warranties) which do not qualify as a separate performance obligation. Therefore, the Company allocates the transaction price based on a single performance obligation.  The Company offers normal and customary trade terms to its customers, no significant part of which is of an extended nature.  The Company considers the performance obligation satisfied and recognizes revenue at a point in time, the time of shipment.  The Company does not generally allow for refunds or returns to customers and does not have outstanding performance obligations for contracts with original durations of greater than one year at the end of the reporting period.

[0000038725-18-000096:notes:106]
Contract Costs

[0000038725-18-000096:notes:107]
The Company does not have outstanding contracts with an original term greater than one year; therefore, the Company expenses costs to obtain a contract as incurred.

[0000038725-18-000096:notes:108]
Accounting Standards Issued But Not Yet Adopted

[0000038725-18-000096:notes:109]
In February 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The ASU is effective for interim and annual periods beginning after December 15, 2018, with early adoption permitted, and may be applied either at the beginning of the period of adoption or retrospectively to each period in which the effect of the change in the U.S. federal corporate income tax rate in the Tax Act is recognized. The Company is currently assessing the impact of the ASU on the Company’s consolidated financial position, results of operations, and cash flows.

[0000038725-18-000096:notes:110]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-18-000096:notes:111]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification (“ASC”) Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company has begun the evaluation process for the adoption of the ASU, and anticipates that the majority of the Company’s outstanding operating leases would be recognized as right-of-use assets and lease liabilities upon adoption, resulting in a significant impact to the Company’s consolidated balance sheets. The Company is implementing a lease accounting software package for lease administration and compliance reporting and is in the process of entering its lease data into this package. The impact of this ASU is non-cash in nature and will not affect the Company’s cash position.  The impact to the Company’s results of operations is still being evaluated.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-18-000096:notes:112]
[same as prior period, unchanged from 0000038725-17-000168:notes:105]

[0000038725-18-000096:notes:113]
The accompanying condensed consolidated balance sheet as of December 31, 2017, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2018, and for the first quarters ended March 31, 2018 and March 31, 2017 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended March 31, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2018.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2017.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-18-000096:notes:114]
[same as prior period, unchanged from 0000038725-17-000168:notes:107]

[0000038725-18-000096:notes:115]
Defined Benefit Plans - As of March 31, 2018, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2017 measurement date for these plans.  One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-18-000096:notes:116]
[same as prior period, unchanged from 0000038725-17-000168:notes:109]

[0000038725-18-000096:notes:117]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the first quarters ended March 31, 2018 and March 31, 2017:

[0000038725-18-000096:notes:118]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | First Quarter Ended |  | First Quarter Ended |
|  | March 31, 2018 |  | March 31, 2017 |  | March 31, 2018 |  | March 31, 2017 |
| Service cost | $ | 0.2 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 1.3 |  |  | 1.4 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | (2.1 | ) |  | (2.2 | ) |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Actuarial loss | 0.7 |  |  | 0.6 |  |  | 0.1 |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | (0.1 | ) |  | $ | 0.2 |  |  | $ | 0.2 |  |

[0000038725-18-000096:notes:119]
The Company adopted ASU 2017-07 in the first quarter ended March 31, 2018.  The service cost component of net periodic benefit cost above is recorded in Selling, general, and administrative expenses within the Condensed Consolidated Statements of Income, while the remaining components are recorded to Other income/(expense), net.  The prior year amounts have been reclassified to provide comparable presentation in line with the guidance.

[0000038725-18-000096:notes:120]
In the first quarter ended March 31, 2018, the Company made contributions of $0.7 million to the funded plans.   The amount of contributions to be made to the plans during the calendar year 2018 will be finalized by September 15, 2018, based upon the funding level requirements identified and year-end valuation performed at December 31, 2017.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-18-000096:notes:121]
[same as prior period, unchanged from 0000038725-17-000168:notes:115]

[0000038725-18-000096:notes:122]
|  | First Quarter Ended |
| (In millions) | March 31, 2018 |  | March 31, 2017 |
|  | Net sales |
| Water Systems |  |  |  |
| External sales |  |  |  |
| United States & Canada | $ | 80.8 |  |  | $ | 71.7 |  |
| Latin America | 29.1 |  |  | 33.0 |  |
| Europe, Middle East & Africa | 49.3 |  |  | 41.4 |  |
| Asia Pacific | 20.8 |  |  | 21.5 |  |
| Intersegment sales |  |  |  |
| United States & Canada | 11.8 |  |  | — |  |
| Total sales | 191.8 |  |  | 167.6 |  |
| Distribution |  |  |  |
| External sales | — |  |  | — |  |
| United States & Canada | 56.2 |  |  | — |  |
| Intersegment sales | — |  |  | — |  |
| Total sales | 56.2 |  |  | — |  |
| Fueling Systems |  |  |  |
| External sales | — |  |  | — |  |
| United States & Canada | 32.8 |  |  | 29.5 |  |
| All other | 26.6 |  |  | 23.2 |  |
| Intersegment sales | — |  |  | — |  |
| Total sales | 59.4 |  |  | 52.7 |  |
| Intersegment Eliminations/Other | (11.8 | ) |  | — |  |
| Consolidated | $ | 295.6 |  |  | $ | 220.3 |  |
|  | First Quarter Ended |
|  | March 31, 2018 |  | March 31, 2017 |
|  | Operating income/(loss) |
| Water Systems | $ | 25.2 |  |  | $ | 21.4 |  |
| Distribution | (0.8 | ) |  | — |  |
| Fueling Systems | 13.6 |  |  | 11.0 |  |
| Intersegment Eliminations/Other | (15.3 | ) |  | (13.9 | ) |
| Consolidated | $ | 22.7 |  |  | $ | 18.5 |  |

[0000038725-18-000096:notes:123]
|  | March 31, 2018 |  | December 31, 2017 |
|  | Total assets |
| Water Systems | $ | 710.1 |  |  | $ | 695.4 |  |
| Distribution | 171.8 |  |  | 153.1 |  |
| Fueling Systems | 277.6 |  |  | 265.7 |  |
| Other | 81.2 |  |  | 71.2 |  |
| Consolidated | $ | 1,240.7 |  |  | $ | 1,185.4 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-18-000096:notes:124]
The schedule below sets forth equity changes in the first quarter ended March 31, 2018:

[0000038725-18-000096:notes:125]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2017 | $ | 4,663 |  |  | $ | 240,136 |  |  | $ | 604,905 |  |  | $ | (49,364 | ) |  | $ | (99,683 | ) |  | $ | 1,964 |  |  | $ | 702,621 |  |  | $ | 1,502 |  |
| Net income |  |  |  |  | 21,174 |  |  |  |  |  |  | 195 |  |  | 21,369 |  |  | (154 | ) |
| Dividends on common stock |  |  |  |  | (5,037 | ) |  |  |  |  |  |  |  | (5,037 | ) |  |  |
| Common stock issued | 3 |  |  | 639 |  |  |  |  |  |  |  |  |  |  | 642 |  |  |  |
| Common stock repurchased | (20 | ) |  |  |  | (7,929 | ) |  |  |  |  |  |  |  | (7,949 | ) |  |  |
| Share-based compensation | 6 |  |  | 3,320 |  |  |  |  |  |  |  |  |  |  | 3,326 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 6,943 |  |  | 40 |  |  | 6,983 |  |  | 12 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 601 |  |  |  |  |  |  | 601 |  |  |  |
| Balance as of March 31, 2018 | $ | 4,652 |  |  | $ | 244,095 |  |  | $ | 613,113 |  |  | $ | (48,763 | ) |  | $ | (92,740 | ) |  | $ | 2,199 |  |  | $ | 722,556 |  |  | $ | 1,360 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-18-000096:notes:126]
SEGMENT AND GEOGRAPHIC INFORMATION

[0000038725-18-000096:notes:127]
The accounting policies of the operating segments are the same as those described in Note 1 of the Company's Form 10-K.  Revenue is recognized based on the invoice price at the point in time when the customer obtains control of the product, which is typically upon shipment to the customer.  During the second quarter of 2017, as a result of  acquisitions, the Company revised its reportable segments to include a Distribution segment.  This change in reporting segments required the Company to realign its internal and external reporting.  The Company retrospectively revised prior periods results to conform with current period presentations.  There is no impact on the Company's previously reported consolidated financial position, results of operations, or cash flows.  The Water and Fueling segments include manufacturing operations and supply certain components and finished goods, both between segments and to the Distribution segment.  The Company accounts for intersegment revenue transactions consistent with independent third party transactions, that is, at current market prices.  Operating income by segment is based on net sales less identifiable operating expenses and allocations and includes profits recorded on sales to other segments of the Company.

[0000038725-18-000096:notes:128]
[same as prior period, unchanged from 0000038725-17-000168:notes:122]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-18-000096:notes:129]
[same as prior period, unchanged from 0000038725-17-000168:notes:123]
