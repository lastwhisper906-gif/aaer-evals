# FELE 8-K — 0000038725-18-000085 filed 2018-05-01

## item codes, every 8-K on or before 2018-05-08

- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2018-05-08

- none on or before 2018-05-08

## item 2.02 — earnings release, exhibit 99.1

[0000038725-18-000085:8k_2_02:1]
EX-99.1
2
a201805018-kexhibit991.htm
EXHIBIT 99.1

[0000038725-18-000085:8k_2_02:2]
Exhibit

[0000038725-18-000085:8k_2_02:3]
Exhibit 99.1

[0000038725-18-000085:8k_2_02:4]
For Immediate Release

[0000038725-18-000085:8k_2_02:5]
For Further Information

[0000038725-18-000085:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-18-000085:8k_2_02:7]
260-824-2900

[0000038725-18-000085:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS FIRST

[0000038725-18-000085:8k_2_02:9]
QUARTER 2018 SALES AND EARNINGS

[0000038725-18-000085:8k_2_02:10]
Fort Wayne, IN - May 1, 2018 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported first quarter 2018 GAAP fully diluted earnings per share (EPS) of $0.45, versus a GAAP fully diluted EPS in the first quarter 2017 of $0.33.  First quarter 2018 sales were $295.6 million, compared to 2017 first quarter sales of $220.3 million.    First quarter 2018 organic sales increased about 10 percent when excluding the impact of foreign currency translation.

[0000038725-18-000085:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-18-000085:8k_2_02:12]
“We had a strong start to 2018 from both a growth and earnings perspective.  Our Water Systems business grew organically by 11 percent on strength in the U.S. and Canada markets and our Fueling Systems business grew organically by 9 percent on broad based strength internationally and in North America.  In our Distribution segment, first quarter proforma revenue was down less than 3 percent compared to the first quarter of 2017 and ahead of our expectations.  Our first quarter operating income grew by 23 percent and our earnings per share grew by 36 percent compared to the first quarter 2017.”

[0000038725-18-000085:8k_2_02:13]
Key Performance Indicators:

[0000038725-18-000085:8k_2_02:14]
| Earnings Before and After Restructuring |  | For the First Quarter |
| (in millions) |  | 2018 | 2017 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 21.2 |  | $ | 15.7 |  | 35 | % |
| Allocated Undistributed Earnings |  | $ | (0.2 | ) | $ | (0.2 | ) |  |
| Earnings for EPS Calculations |  | $ | 21.0 |  | $ | 15.5 |  | 35 | % |
| Restructuring (before tax): |  | $ | — |  | $ | 0.3 |  |  |
| Restructuring, net of tax: |  | $ | — |  | $ | 0.2 |  |  |
| Earnings Before Restructuring |  | $ | 21.0 |  | $ | 15.7 |  | 34 | % |
| Earnings Per Share |  | For the First Quarter |
| Before and After Restructuring |  | 2018 | 2017 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.1 |  | 47.0 |  | — | % |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.45 |  | $ | 0.33 |  | 36 | % |
| Restructuring Per Share, net of tax |  | $ | — |  | $ | — |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.45 |  | $ | 0.33 |  | 36 | % |

[0000038725-18-000085:8k_2_02:15]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q1 2017 | $ | 71.7 |  | $ | 33.0 |  | $ | 41.4 |  | $ | 21.5 |  | $ | 167.6 |  | $ | 52.7 |  | $ | — |  | $ | — |  | $ | 220.3 |  |
| Q1 2018 | $ | 92.6 |  | $ | 29.1 |  | $ | 49.3 |  | $ | 20.8 |  | $ | 191.8 |  | $ | 59.4 |  | $ | 56.2 |  | $ | (11.8 | ) | $ | 295.6 |  |
| Change | $ | 20.9 |  | $ | (3.9 | ) | $ | 7.9 |  | $ | (0.7 | ) | $ | 24.2 |  | $ | 6.7 |  | $ | 56.2 |  | $ | (11.8 | ) | $ | 75.3 |  |
| % Change | 29 | % | (12 | )% | 19 | % | (3 | )% | 14 | % | 13 | % |  |  | 34 | % |
| Foreign currency translation | $ | 0.9 |  | $ | (0.2 | ) | $ | 4.8 |  | $ | 0.3 |  | $ | 5.8 |  | $ | 2.2 |  |  |  |  |
| % Change | 1 | % | (1 | )% | 12 | % | 2 | % | 3 | % | 4 | % |  |  |  |
| Volume/Price | $ | 20.0 |  | $ | (3.7 | ) | $ | 3.1 |  | $ | (1.0 | ) | $ | 18.4 |  | $ | 4.5 |  |  |  |  |
| % Change | 28 | % | (11 | )% | 7 | % | (5 | )% | 11 | % | 9 | % |  |  |  |

[0000038725-18-000085:8k_2_02:16]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2018 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 25.2 |  | $ | 13.6 |  | $ | (0.8 | ) | $ | (15.3 | ) | $ | 22.7 |  |
| % Operating Income To Net Sales | 13.1 | % | 22.9 | % | (1.4 | )% |  | 7.7 | % |
| Restructuring | $ | — |  | $ | — |  | $ | — |  | $ | — |  | $ | — |  |
| Operating Income/(Loss) Before Restructuring | $ | 25.2 |  | $ | 13.6 |  | $ | (0.8 | ) | $ | (15.3 | ) | $ | 22.7 |  |
| % Operating Income to Net Sales Before Restructuring | 13.1 | % | 22.9 | % |  |  | 7.7 | % |
|  | For the First Quarter 2017 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 21.4 |  | $ | 11.0 |  | $ | — |  | $ | (13.9 | ) | $ | 18.5 |  |
| % Operating Income To Net Sales | 12.8 | % | 20.9 | % |  |  | 8.4 | % |
| Restructuring | $ | 0.3 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.3 |  |
| Operating Income/(Loss) Before Restructuring | $ | 21.7 |  | $ | 11.0 |  | $ | — |  | $ | (13.9 | ) | $ | 18.8 |  |
| % Operating Income to Net Sales Before Restructuring | 12.9 | % | 20.9 | % |  |  | 8.5 | % |

[0000038725-18-000085:8k_2_02:17]
Water Systems

[0000038725-18-000085:8k_2_02:18]
Water Systems sales were $191.8 million in the first quarter 2018, versus the first quarter 2017 sales of $167.6 million.  Water Systems sales increased about 3 percent in the quarter due to foreign currency translation.

[0000038725-18-000085:8k_2_02:19]
Water Systems sales in the U.S. and Canada increased by about 29 percent compared to the first quarter 2017. The impact of foreign currency translation increased sales by about 1 percent.  Sales of Pioneer branded dewatering equipment more than doubled in the first quarter when compared to the prior year due to strength in North American oil and gas markets and continued diversification of product sales channels and geographies. Sales of groundwater pumping equipment increased by about 30 percent on stronger residential and agricultural system sales primarily to the Headwater companies, versus the first quarter 2017. Sales of other surface pumping equipment increased by about 10 percent primarily in wastewater products.

[0000038725-18-000085:8k_2_02:20]
Water Systems sales in markets outside the U.S. and Canada increased by about 3 percent overall. The impact of foreign currency translation increased sales by about 5 percent.  International Water Systems sales improved in Europe, the Middle East, and Africa, but were offset by lower sales in Brazil and Asia when compared to the first quarter 2017.

[0000038725-18-000085:8k_2_02:21]
Water Systems operating income was $25.2 million in the first quarter 2018, up $3.8 million versus the first quarter 2017.  The increase in operating income is primarily related to higher sales.

[0000038725-18-000085:8k_2_02:22]
Fueling Systems

[0000038725-18-000085:8k_2_02:23]
Fueling Systems sales were $59.4 million in the first quarter 2018, versus the first quarter 2017 sales of $52.7 million.  Fueling System sales increased by about 4 percent due to foreign currency translation.

[0000038725-18-000085:8k_2_02:24]
Fueling Systems sales in the U.S. and Canada increased by about 11 percent compared to the first quarter 2017.  The increase was broad based and included numerous product categories including fuel management, pumping, piping and containment systems.  Outside the U.S. and Canada, Fueling Systems revenues grew by about 16 percent, led by stronger sales in China and Europe, partially offset by lower sales in India.

[0000038725-18-000085:8k_2_02:25]
Fueling Systems operating income was $13.6 million in the first quarter of 2018, compared to $11.0 million in the first quarter of 2017.  The increase in operating income is primarily related to higher sales.

[0000038725-18-000085:8k_2_02:26]
Distribution

[0000038725-18-000085:8k_2_02:27]
Distribution sales were $56.2 million in the first quarter 2018.  The Company estimates that compared to the 2017 first quarter, proforma revenue in the distribution segment declined by just under three percent.  The Distribution segment recorded an operating loss of $0.8 million in the first quarter of 2018.

[0000038725-18-000085:8k_2_02:28]
Overall

[0000038725-18-000085:8k_2_02:29]
The Company’s consolidated gross profit was $99.0 million for the first quarter of 2018, an increase from the first quarter of 2017 gross profit of $75.8 million. The gross profit as a percent of net sales was 33.5 percent in the first quarter of 2018 versus 34.4 percent during the first quarter 2017.  The gross profit

[0000038725-18-000085:8k_2_02:30]
increase was primarily due to higher sales.  The decline in gross profit margin percentage is primarily due to product and geographic sales mix shifts, as realized sales price offset material cost inflation in the quarter.

[0000038725-18-000085:8k_2_02:31]
Selling, general, and administrative (SG&A) expenses were $76.3 million in the first quarter of 2018 compared to $57.0 million in the first quarter of the prior year.  The increase in SG&A expenses from acquired businesses was $17.7 million.  Excluding the acquired entities, the Company’s SG&A expenses in the first quarter of 2018 were $58.6 million, an increase of about 3 percent from the first quarter 2017.

[0000038725-18-000085:8k_2_02:32]
The Company recognized discrete income tax benefits related to certain deferred tax positions in the first quarter of about $5 million which lowered the first quarter effective tax rate to a 9 percent benefit.  Consistent with our previous guidance, the Company believes the full year 2018 effective tax rate will be about 15 percent expense on pre-tax earnings.

[0000038725-18-000085:8k_2_02:33]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-18-000085:8k_2_02:34]
“Given our strong start to the year in both the Water and Fueling Systems segments, and our better than expected sequential growth in Distribution, we are raising our revenue guidance for 2018.  We now believe our organic revenue growth, which excludes the impact of foreign currency translation will more likely be in the 6 to 8 percent range.  This is an increase from the 4 to 5 percent range for Water and Distribution and from the 5 to 7 percent range for Fueling, provided in our previous guidance.

[0000038725-18-000085:8k_2_02:35]
Based on these higher growth assumptions and resultant earnings, we are raising our full year 2018 estimate for earnings per share to a range of $2.27 to $2.37, an increase from the $2.16 to $2.28 provided in our previous guidance.  The discrete tax benefits we realized in the first quarter were planned and included in our previous earnings guidance.”

[0000038725-18-000085:8k_2_02:36]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The first quarter 2018 earnings call will be available via a live webcast.  The webcast will be available in a listen only mode by going to:

[0000038725-18-000085:8k_2_02:37]
https://edge.media-server.com/m6/p/vyisocdo

[0000038725-18-000085:8k_2_02:38]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 6991834.

[0000038725-18-000085:8k_2_02:39]
A replay of the conference call will be available Tuesday, May 1, 2018 at 12:00 noon EDT through noon EDT on Tuesday, May 8, 2018, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 6991834.

[0000038725-18-000085:8k_2_02:40]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-18-000085:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |
|  | First Quarter Ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Net sales | $ | 295,630 |  |  | $ | 220,252 |  |
| Cost of sales | 196,648 |  |  | 144,436 |  |
| Gross profit | 98,982 |  |  | 75,816 |  |
| Selling, general, and administrative expenses | 76,275 |  |  | 56,996 |  |
| Restructuring expense | 7 |  |  | 315 |  |
| Operating income | 22,700 |  |  | 18,505 |  |
| Interest expense | (2,428 | ) |  | (3,514 | ) |
| Other income/(expense), net | (204 | ) |  | 672 |  |
| Foreign exchange income/(expense) | (551 | ) |  | 475 |  |
| Income before income taxes | 19,517 |  |  | 16,138 |  |
| Income tax (benefit)/expense | (1,698 | ) |  | 204 |  |
| Net income | $ | 21,215 |  |  | $ | 15,934 |  |
| Less: Net income attributable to noncontrolling interests | (41 | ) |  | (204 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 21,174 |  |  | $ | 15,730 |  |
| Income per share: |  |  |  |
| Basic | $ | 0.45 |  |  | $ | 0.33 |  |
| Diluted | $ | 0.45 |  |  | $ | 0.33 |  |

[0000038725-18-000085:8k_2_02:42]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | March 31, 2018 |  | December 31, 2017 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 67,370 |  |  | $ | 67,233 |  |
| Receivables | 192,771 |  |  | 171,007 |  |
| Inventories | 343,316 |  |  | 312,325 |  |
| Other current assets | 38,394 |  |  | 38,566 |  |
| Total current assets | 641,851 |  |  | 589,131 |  |
| Property, plant, and equipment, net | 217,368 |  |  | 215,694 |  |
| Goodwill and other assets | 381,445 |  |  | 380,528 |  |
| Total assets | $ | 1,240,664 |  |  | $ | 1,185,353 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 84,829 |  |  | $ | 79,348 |  |
| Accrued expenses and other current liabilities | 50,943 |  |  | 66,100 |  |
| Current maturities of long-term debt and short-term borrowings | 152,945 |  |  | 100,453 |  |
| Total current liabilities | 288,717 |  |  | 245,901 |  |
| Long-term debt | 125,076 |  |  | 125,596 |  |
| Income taxes payable non-current | 17,391 |  |  | 17,391 |  |
| Deferred income taxes | 26,021 |  |  | 30,913 |  |
| Employee benefit plans | 41,058 |  |  | 42,178 |  |
| Other long-term liabilities | 18,485 |  |  | 19,251 |  |
| Redeemable noncontrolling interest | 1,360 |  |  | 1,502 |  |
| Total equity | 722,556 |  |  | 702,621 |  |
| Total liabilities and equity | $ | 1,240,664 |  |  | $ | 1,185,353 |  |

[0000038725-18-000085:8k_2_02:43]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
| (In thousands) | March 31, 2018 |  | March 31, 2017 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 21,215 |  |  | $ | 15,934 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 9,896 |  |  | 8,924 |  |
| Share-based compensation | 3,326 |  |  | 2,941 |  |
| Other | (5,262 | ) |  | (1,879 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (17,242 | ) |  | (6,560 | ) |
| Inventory | (23,932 | ) |  | (29,661 | ) |
| Accounts payable and accrued expenses | (15,378 | ) |  | (10,539 | ) |
| Other | 193 |  |  | (3,731 | ) |
| Net cash flows from operating activities | (27,184 | ) |  | (24,571 | ) |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (5,921 | ) |  | (4,908 | ) |
| Proceeds from sale of property, plant, and equipment | 208 |  |  | 34 |  |
| Acquisitions and investments | (8,428 | ) |  | — |  |
| Other investing activities | — |  |  | (7 | ) |
| Net cash flows from investing activities | (14,141 | ) |  | (4,881 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 52,007 |  |  | (460 | ) |
| Proceeds from issuance of common stock | 642 |  |  | 481 |  |
| Purchases of common stock | (7,949 | ) |  | (665 | ) |
| Dividends paid | (5,037 | ) |  | (4,668 | ) |
| Net cash flows from financing activities | 39,663 |  |  | (5,312 | ) |
| Effect of exchange rate changes on cash | 1,799 |  |  | 1,084 |  |
| Net change in cash and equivalents | 137 |  |  | (33,680 | ) |
| Cash and equivalents at beginning of period | 67,233 |  |  | 104,331 |  |
| Cash and equivalents at end of period | $ | 67,370 |  |  | $ | 70,651 |  |
