# FELE MD&A — 0000038725-18-000096


## mdna

[0000038725-18-000096:mdna:1]
[same as prior period, unchanged from 0000038725-17-000168:mdna:1]

[0000038725-18-000096:mdna:2]
First Quarter 2018 vs. First Quarter 2017

[0000038725-18-000096:mdna:3]
[same as prior period, unchanged from 0000038725-17-000168:mdna:3]

[0000038725-18-000096:mdna:4]
Sales in the first quarter of 2018 increased from the first quarter of last year. The sales increase was primarily from acquired distribution entities, as well as organic sales increases in both Water Systems and Fueling Systems of about 10 percent. Sales increased by about 4 percent in the quarter due to foreign currency translation. The Company's consolidated gross profit was $99.0 million for the first quarter of 2018, an increase of $23.2 million or about 31 percent from the prior year’s first quarter. The gross profit increase was primarily due to higher sales. The gross profit as a percent of net sales was 33.5 percent in the first quarter of 2018 versus 34.4 percent during the first quarter 2017.

[0000038725-18-000096:mdna:5]
[same as prior period, unchanged from 0000038725-17-000168:mdna:5]

[0000038725-18-000096:mdna:6]
[same as prior period, unchanged from 0000038725-17-000168:mdna:6]

[0000038725-18-000096:mdna:7]
Net sales in the first quarter of 2018 were $295.6 million, an increase of $75.3 million or about 34 percent compared to 2017 first quarter sales of $220.3 million.  The sales increase was primarily from acquisition related sales.  Sales revenue increased by $8.0 million or about 4 percent in the first quarter of 2018 due to foreign currency translation. Excluding the impact of foreign currency translation, the Company’s organic sales growth was about 10 percent.

[0000038725-18-000096:mdna:8]
|  | Net Sales |
| (In millions) | Q1 2018 |  | Q1 2017 |  | 2018 v 2017 |
| Water Systems | $ | 191.8 |  |  | $ | 167.6 |  |  | $ | 24.2 |  |
| Fueling Systems | 59.4 |  |  | 52.7 |  |  | 6.7 |  |
| Distribution | 56.2 |  |  | — |  |  | 56.2 |  |
| Eliminations/Other | (11.8 | ) |  | — |  |  | (11.8 | ) |
| Consolidated | $ | 295.6 |  |  | $ | 220.3 |  |  | $ | 75.3 |  |

[0000038725-18-000096:mdna:9]
[same as prior period, unchanged from 0000038725-17-000168:mdna:9]

[0000038725-18-000096:mdna:10]
Water Systems revenues were $191.8 million in the first quarter 2018, an increase of $24.2 million or about 14 percent versus the first quarter 2017 sales of $167.6 million. Sales were increased by $5.8 million or 3 percent in the quarter due to foreign currency translation.  Water Systems sales were up about 11 percent, excluding foreign currency translation, in the first quarter of 2018 versus the first quarter of 2017.

[0000038725-18-000096:mdna:11]
Water Systems sales in the U.S. and Canada, including Intersegment sales, increased by about 29 percent compared to the first quarter 2017. The impact of foreign currency translation increased sales by about 1 percent.  Sales of Pioneer branded dewatering equipment more than doubled in the first quarter when compared to the prior year due to strength in North American oil and gas markets and continued diversification of product sales channels and geographies. Sales of groundwater pumping equipment increased by about 30 percent on stronger residential and agricultural system sales primarily to the Headwater companies, versus the first quarter 2017.   Sales of other surface pumping equipment increased by about 10 percent primarily in wastewater products.

[0000038725-18-000096:mdna:12]
Water Systems sales in markets outside the U.S. and Canada increased by about 3 percent overall. The impact of foreign currency translation increased sales by about 5 percent.  International Water Systems sales improved in Europe, the Middle East, and Africa, but were offset by lower sales in Brazil and Asia when compared to the first quarter 2017.

[0000038725-18-000096:mdna:13]
[same as prior period, unchanged from 0000038725-17-000168:mdna:13]

[0000038725-18-000096:mdna:14]
Fueling Systems sales were $59.4 million in the first quarter of 2018, an increase of $6.7 million or about 13 percent versus the first quarter 2017 sales of $52.7 million. Fueling Systems sales were increased by $2.2 million or 4 percent in the quarter due to foreign currency translation. Fueling Systems sales growth, excluding foreign currency translation, was about 9 percent.  Fueling Systems sales in the U.S. and Canada increased by about 11 percent compared to the first quarter 2017.  The increase was broad based and included numerous product categories including fuel management, pumping, piping and containment systems.  Outside the U.S. and Canada, Fueling Systems revenues grew by about 16 percent, led by stronger sales in China and Europe, partially offset by lower sales in India.

[0000038725-18-000096:mdna:15]
[same as prior period, unchanged from 0000038725-17-000168:mdna:15]

[0000038725-18-000096:mdna:16]
Distribution sales were $56.2 million in the first quarter of 2018 and were all acquisition related. Management estimates Distribution sales declined by about 3 percent from the first quarter of 2017.  During 2017, three significant pump suppliers elected to discontinue selling to the Distribution entities which had a short-term impact on product availability. In the fourth quarter last year, proforma revenue was down 11 percent. However, with the addition of new pump lines and a focus on customer service, the Distribution segment sales improved in the first quarter 2018 compared to the fourth quarter 2017.

[0000038725-18-000096:mdna:17]
[same as prior period, unchanged from 0000038725-17-000168:mdna:17]

[0000038725-18-000096:mdna:18]
Cost of sales as a percentage of net sales for the first quarters of 2018 and 2017 was 66.5 percent and 65.6 percent, respectively. Correspondingly, the gross profit margin decreased to 33.5 percent from 34.4 percent, a decline of 90 basis points. The Company’s consolidated gross profit was $99.0 million for the first quarter of 2018, an increase from the first quarter of 2017 gross profit of $75.8 million. The gross profit increase was primarily due to higher sales.  The decline in gross profit margin percentage is primarily due to product and geographic sales mix shifts, as realized price offset material costs in the quarter.   Going forward, sales price actions are intended to offset cost increases including Section 232 tariffs on steel and aluminum imports.

[0000038725-18-000096:mdna:19]
[same as prior period, unchanged from 0000038725-17-000168:mdna:19]

[0000038725-18-000096:mdna:20]
Selling, general, and administrative (SG&A) expenses were $76.3 million in the first quarter of 2018 compared to $57.0 million in the first quarter of the prior year.  The increase in SG&A expenses from acquired businesses was $17.7 million.  Excluding the acquired entities, the Company’s SG&A expenses in the first quarter of 2018 were $58.6 million, an increase of about 3 percent from the first quarter 2017.

[0000038725-18-000096:mdna:21]
[same as prior period, unchanged from 0000038725-17-000168:mdna:21]

[0000038725-18-000096:mdna:22]
There were no meaningful restructuring expenses for the first quarter of 2018 and $0.3 million of restructuring expenses for the first quarter of 2017.  Restructuring expenses for the first quarter of 2017 were in Brazil and related to continued manufacturing realignments and include severance expenses and other miscellaneous manufacturing realignment activities.

[0000038725-18-000096:mdna:23]
[same as prior period, unchanged from 0000038725-17-000168:mdna:24]

[0000038725-18-000096:mdna:24]
Operating income was $22.7 million in the first quarter of 2018, up $4.2 million or about 23 percent from $18.5 million in the first quarter of 2017.

[0000038725-18-000096:mdna:25]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2018 |  | Q1 2017 |  | 2018 v 2017 |
| Water Systems |  | $ | 25.2 |  |  | $ | 21.4 |  |  | $ | 3.8 |  |
| Fueling Systems |  | 13.6 |  |  | 11.0 |  |  | 2.6 |  |
| Distribution |  | (0.8 | ) |  | — |  |  | (0.8 | ) |
| Eliminations/Other |  | (15.3 | ) |  | (13.9 | ) |  | (1.4 | ) |
| Consolidated |  | $ | 22.7 |  |  | $ | 18.5 |  |  | $ | 4.2 |  |

[0000038725-18-000096:mdna:26]
[same as prior period, unchanged from 0000038725-17-000168:mdna:27]

[0000038725-18-000096:mdna:27]
Water Systems operating income was $25.2 million in the first quarter 2018, up $3.8 million versus the first quarter 2017. The first quarter operating income margin was 13.1 percent, up 30 basis points from 12.8 percent in the first quarter of 2017. Operating income increased in Water Systems primarily due to higher sales.

[0000038725-18-000096:mdna:28]
[same as prior period, unchanged from 0000038725-17-000168:mdna:29]

[0000038725-18-000096:mdna:29]
Fueling Systems operating income was $13.6 million in the first quarter of 2018 compared to $11.0 million in the first quarter of 2017, an increase of about 24 percent.  The increase in operating income was primarily related to higher sales.  The first quarter Fueling Systems operating income margin was 22.9 percent, an increase of 200 basis points from the 20.9 percent of net sales in the first quarter of 2017.  Operating income margin improved primarily due to leverage on fixed cost from higher sales.

[0000038725-18-000096:mdna:30]
[same as prior period, unchanged from 0000038725-17-000168:mdna:31]

[0000038725-18-000096:mdna:31]
The Distribution segment recorded an operating loss of $0.8 million in the first quarter of 2018.  The Distribution segment’s operations are seasonal and product sales are significantly slower during the fourth and first quarters, i.e., the winter months in North America.

[0000038725-18-000096:mdna:32]
[same as prior period, unchanged from 0000038725-17-000168:mdna:33]

[0000038725-18-000096:mdna:33]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses.  The intersegment profit elimination impact in 2018 was $0.6 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer.  General and administrative expenses were higher by $0.8 million or about 6 percent to last year.

[0000038725-18-000096:mdna:34]
[same as prior period, unchanged from 0000038725-17-000168:mdna:35]

[0000038725-18-000096:mdna:35]
Interest expense for the first quarters of 2018 and 2017 was $2.4 million and $3.5 million, respectively.

[0000038725-18-000096:mdna:36]
[same as prior period, unchanged from 0000038725-17-000168:mdna:37]

[0000038725-18-000096:mdna:37]
Other income or expense was a loss in the first quarter of 2018 of $0.2 million and income of $0.7 million in the first quarter of 2017. Included in other income in the first quarter of 2018 was interest income of $0.1 million, primarily derived from the investment of cash balances in short-term securities.  Included in other income in the first quarter of 2017 was income from minority interests of $0.5 million and interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-18-000096:mdna:38]
[same as prior period, unchanged from 0000038725-17-000168:mdna:39]

[0000038725-18-000096:mdna:39]
Foreign currency-based transactions produced a loss of $0.6 million for the first quarter of 2018. Foreign currency-based transactions produced a gain of $0.5 million for the first quarter of 2017.

[0000038725-18-000096:mdna:40]
[same as prior period, unchanged from 0000038725-17-000168:mdna:41]

[0000038725-18-000096:mdna:41]
The provision for income taxes in the first quarter of 2018 was a benefit of $1.7 million and for the same period 2017 an expense of $0.2 million. The effective tax rate for the first quarter of 2018 was a benefit of about 9 percent and, before the impact of discrete events, was about 19 percent.  The effective tax rate for the first quarter of 2017 was about 1 percent and, before the impact of discrete events, was about 27 percent.   The tax rate as a percentage of pre-tax earnings for the full year of 2018 is projected to be about 19 percent, compared to the full year 2017 tax rate of about 25 percent, both before discrete adjustments.  The decrease in the effective tax rate was primarily affected by the Tax Act, which reduced the U.S. federal corporate income tax rate from 35 percent to 21 percent effective January 1, 2018. The Company also recorded a provisional tax benefit of $3.1 million associated with the Foreign Derived Intangible Income provisions of the Tax Act that were effective for the first time during 2018.  In addition, the Company released a valuation allowance of $5.4 million related to state net operating losses and incentives.

[0000038725-18-000096:mdna:42]
[same as prior period, unchanged from 0000038725-17-000168:mdna:43]

[0000038725-18-000096:mdna:43]
Net income for the first quarter of 2018 was $21.2 million compared to the prior year first quarter net income of $15.9 million.  Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2018 was $21.2 million, or $0.45 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $15.7 million or $0.33 per diluted share.

[0000038725-18-000096:mdna:44]
[same as prior period, unchanged from 0000038725-17-000168:mdna:90]

[0000038725-18-000096:mdna:45]
[same as prior period, unchanged from 0000038725-17-000168:mdna:91]

[0000038725-18-000096:mdna:46]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at March 31, 2018 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-18-000096:mdna:47]
As of March 31, 2018 the Company had a $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of March 31, 2018, the Company had $175.9 million borrowing capacity under the Credit Agreement as $5.3 million in letters of commercial and standby letters of credit were outstanding and undrawn and $118.8 million in revolver borrowings were drawn and outstanding which were primarily used for acquisition and working capital needs.

[0000038725-18-000096:mdna:48]
The Company also has other long-term debt borrowings outstanding as of March 31, 2018. See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-18-000096:mdna:49]
At March 31, 2018, the Company had $59.6 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-18-000096:mdna:50]
[same as prior period, unchanged from 0000038725-17-000168:mdna:96]

[0000038725-18-000096:mdna:51]
The following table summarizes significant sources and uses of cash and cash equivalents for the first quarters of 2018 and 2017.

[0000038725-18-000096:mdna:52]
| (in millions) |  | 2018 |  | 2017 |
| Net cash used in operating activities |  | $ | (27.2 | ) |  | $ | (24.6 | ) |
| Net cash used in investing activities |  | (14.2 | ) |  | (4.8 | ) |
| Net cash provided by (used in) financing activities |  | 39.7 |  |  | (5.3 | ) |
| Impact of exchange rates on cash and cash equivalents |  | 1.8 |  |  | 1.0 |  |
| Change in cash and cash equivalents |  | $ | 0.1 |  |  | $ | (33.7 | ) |

[0000038725-18-000096:mdna:53]
Cash Flows Used in Operating Activities

[0000038725-18-000096:mdna:54]
2018 vs. 2017

[0000038725-18-000096:mdna:55]
Net cash used in operating activities was $27.2 million for the first quarter ended March 31, 2018 compared to $24.6 million for the first quarter ended March 31, 2017.  The most significant use of cash during the first quarter of 2018 was related to working capital.  Accounts receivable increased about $17 million, and about $11 million more than the first quarter prior year due to increased sales.  Inventory increased about $24 million, about $6 million less than the prior year but consistent with pre-season inventory builds.  Other sources of cash in the current year were increased earnings, accruals and reserves and were more than the first quarter prior year.

[0000038725-18-000096:mdna:56]
[same as prior period, unchanged from 0000038725-17-000168:mdna:102]

[0000038725-18-000096:mdna:57]
2018 vs. 2017

[0000038725-18-000096:mdna:58]
Net cash used in investing activities was $14.2 million for the first quarter ended March 31, 2018 compared to $4.8 million for the first quarter ended March 31, 2017.  The increase in cash used in investing activities was primarily attributable to the purchase of Valley Farms Supply, Inc. as described in Footnote 3 - Acquisitions.

[0000038725-18-000096:mdna:59]
[same as prior period, unchanged from 0000038725-17-000168:mdna:105]

[0000038725-18-000096:mdna:60]
2018 vs. 2017

[0000038725-18-000096:mdna:61]
Net cash provided by financing activities was $39.7 million for the first quarter ended March 31, 2018 compared to $5.3 million used in financing activities for the quarter ended March 31, 2017.  Net borrowings of about $52.0 million was the source of increased cash and was partially offset by uses of cash for stock repurchases of about $7.9 million and dividends of about $5.0 million during the first quarter ended March 31, 2018.

[0000038725-18-000096:mdna:62]
[same as prior period, unchanged from 0000038725-17-000168:mdna:108]
