# FELE 8-K — 0000038725-25-000011 filed 2025-02-18

## item codes, every 8-K on or before 2025-02-21

- 2025-02-18 0000038725-25-000013 — 7.01, 9.01
- 2025-02-18 0000038725-25-000011 — 2.02, 9.01
- 2025-02-14 0000038725-25-000009 — 7.01, 9.01
- 2024-11-12 0000038725-24-000175 — 7.01, 9.01
- 2024-11-06 0000038725-24-000169 — 7.01, 9.01
- 2024-10-29 0000038725-24-000164 — 7.01, 9.01
- 2024-10-29 0000038725-24-000162 — 2.02, 9.01
- 2024-07-24 0000038725-24-000140 — 7.01, 9.01
- 2024-07-23 0000038725-24-000138 — 2.02, 9.01
- 2024-07-01 0000038725-24-000132 — 5.02
- 2024-05-22 0000038725-24-000119 — 5.02, 9.01 — amendment of 0000038725-24-000101
- 2024-05-16 0000038725-24-000105 — 1.01, 2.03, 9.01
- 2024-05-14 0000038725-24-000101 — 5.02, 7.01, 9.01
- 2024-05-03 0000038725-24-000097 — 7.01, 9.01
- 2024-05-03 0000038725-24-000096 — 5.07
- 2024-04-30 0000038725-24-000074 — 2.02, 9.01
- 2024-02-13 0000038725-24-000012 — 7.01, 9.01
- 2024-02-13 0000038725-24-000010 — 2.02, 9.01
- 2023-11-06 0000038725-23-000184 — 7.01, 9.01
- 2023-10-24 0000038725-23-000177 — 2.02, 9.01
- 2023-08-04 0000038725-23-000160 — 5.02, 9.01
- 2023-08-03 0000038725-23-000158 — 7.01, 9.01
- 2023-07-25 0000038725-23-000149 — 2.02, 9.01
- 2023-07-05 0000038725-23-000144 — 5.02, 7.01, 9.01
- 2023-05-09 0000038725-23-000094 — 5.02, 9.01
- 2023-05-09 0000038725-23-000092 — 5.07
- 2023-05-08 0000038725-23-000087 — 7.01, 9.01
- 2023-05-02 0000038725-23-000065 — 2.02, 9.01
- 2023-03-08 0000038725-23-000046 — 7.01, 9.01
- 2023-02-21 0000038725-23-000016 — 8.01, 9.01
- 2023-02-14 0000038725-23-000002 — 2.02, 9.01
- 2022-10-28 0000038725-22-000180 — 7.01, 9.01
- 2022-10-25 0000038725-22-000177 — 2.02, 9.01
- 2022-08-04 0000038725-22-000150 — 7.01, 9.01
- 2022-07-26 0000038725-22-000142 — 2.02, 9.01
- 2022-05-11 0000038725-22-000106 — 2.03, 9.01
- 2022-05-06 0000038725-22-000082 — 5.07
- 2022-05-06 0000038725-22-000081 — 5.02, 9.01
- 2022-05-03 0000038725-22-000075 — 7.01, 9.01
- 2022-04-26 0000038725-22-000073 — 2.02, 9.01
- 2022-03-24 0000038725-22-000056 — 5.02, 9.01
- 2022-03-08 0000038725-22-000049 — 7.01, 9.01
- 2022-02-15 0000038725-22-000007 — 2.02, 9.01
- 2022-01-04 0000038725-22-000002 — 7.01, 9.01
- 2021-11-03 0000038725-21-000212 — 7.01, 9.01
- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2025-02-21

- none on or before 2025-02-21

## item 2.02 — earnings release, exhibit 99.1

[0000038725-25-000011:8k_2_02:1]
EX-99.1
2
a20250218ex991earningsrele.htm
EX-99.1

[0000038725-25-000011:8k_2_02:2]
Document

[0000038725-25-000011:8k_2_02:3]
Exhibit 99.1

[0000038725-25-000011:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-25-000011:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS FOURTH QUARTER 2024 AND FULL YEAR 2024 RESULTS

[0000038725-25-000011:8k_2_02:6]
Fourth Quarter 2024 Highlights

[0000038725-25-000011:8k_2_02:7]
•Consolidated net sales of $485.7 million, an increase of 3% to the prior year

[0000038725-25-000011:8k_2_02:8]
•Energy Systems and Distribution net sales increased 5% and 6%, respectively, while Water Systems net sales were flat

[0000038725-25-000011:8k_2_02:9]
•Operating income was $43.0 million with operating margin of 8.9%

[0000038725-25-000011:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $0.72

[0000038725-25-000011:8k_2_02:11]
Full Year 2024 Highlights

[0000038725-25-000011:8k_2_02:12]
•Consolidated net sales of $2.0 billion, a decrease of 2% to the prior year

[0000038725-25-000011:8k_2_02:13]
•Distribution net sales increased 2%, while Water Systems and Energy Systems net sales decreased 2% and 8%, respectively

[0000038725-25-000011:8k_2_02:14]
•Operating income was $243.6 million with operating margin of 12.1%

[0000038725-25-000011:8k_2_02:15]
•GAAP fully diluted earnings per share (EPS) was $3.86

[0000038725-25-000011:8k_2_02:16]
•Cash flows from operating activities were $261.4 million

[0000038725-25-000011:8k_2_02:17]
Fort Wayne, IN – February 18, 2025 – Franklin Electric Co., Inc. today announced its fourth quarter and full year financial results for fiscal year 2024.

[0000038725-25-000011:8k_2_02:18]
Fourth quarter 2024 net sales were $485.7 million, compared to fourth quarter 2023 net sales of $473.0 million. Fourth quarter 2024 operating income was $43.0 million, compared to fourth quarter 2023 operating income of $50.8 million. Fourth quarter 2024 EPS was $0.72, versus EPS in the fourth quarter 2023 of $0.82.

[0000038725-25-000011:8k_2_02:19]
Full year 2024 net sales were $2.0 billion, compared to full year 2023 net sales of $2.1 billion. Full year 2024 operating income was $243.6 million, compared to full year 2023 operating income of $262.4 million. Full year 2024 EPS was $3.86, versus EPS in the full year 2023 of $4.11.

[0000038725-25-000011:8k_2_02:20]
“The fourth quarter marked a solid finish to a challenging year. Our results were driven by strong performance in our newly renamed Energy Systems segment. While we have worked through the elevated post-COVID backlogs at this time, underlying demand remains healthy, and we continue to execute on productivity initiatives as we align our businesses with the more normalized environment,” commented Joe Ruzynski, Franklin Electric’s CEO.

[0000038725-25-000011:8k_2_02:21]
“Our resiliency is supported by the breadth of our global portfolio, which has proven to be a strategic asset as we closed out a year shaped by macroeconomic pressures. Order trends have improved, and with the support of a very healthy balance sheet, we are well-positioned to capitalize on opportunities in the year ahead. In 2025, our focus turns to driving revenue growth and margin expansion as we accelerate innovation and growth,” concluded Mr. Ruzynski.

[0000038725-25-000011:8k_2_02:22]
Segment Summaries

[0000038725-25-000011:8k_2_02:23]
Water Systems net sales were $279.6 million in the fourth quarter, flat compared to the fourth quarter 2023. Results were driven by higher sales of groundwater products, water treatment products and all other surface products. These sales increases were offset by lower sales of large dewatering pumps,

[0000038725-25-000011:8k_2_02:24]
which had a record fourth quarter last year. Water Systems operating income in the fourth quarter 2024 was $35.6 million. Fourth quarter 2023 Water Systems operating income was $44.1 million.

[0000038725-25-000011:8k_2_02:25]
Distribution net sales were $157.2 million, an increase of $9.2 million or 6 percent compared to the fourth quarter 2023. Sales increases were driven by higher volumes and the incremental impact from a recent acquisition. The Distribution segment operating income in the fourth quarter 2024 was $0.5 million. Fourth quarter 2023 Distribution operating income was $1.0 million.

[0000038725-25-000011:8k_2_02:26]
Energy Systems net sales were $68.8 million in the fourth quarter 2024, an increase of $3.1 million or 5 percent compared to the fourth quarter 2023. Sales increases were driven by higher volumes and price realization. Energy Systems operating income in the fourth quarter 2024 was a record for any fourth quarter at $24.7 million. Fourth quarter 2023 Energy Systems operating income was $19.4 million. The Company has changed the name of the Fueling Systems segment to Energy Systems to reflect its diverse portfolio and growth strategy, as well as to better reflect the markets and customers served by the segment.

[0000038725-25-000011:8k_2_02:27]
Cash Flow

[0000038725-25-000011:8k_2_02:28]
The Company ended 2024 with a cash balance of $220.5 million, an increase of $135.5 million compared to the end of 2023.  Net cash flows from operating activities for 2024 were $261.4 million versus $315.7 million in the same period in 2023.  Cash flow in 2023 benefitted from actions the Company took to improve working capital including inventory reductions as its supply chain resiliency and lead times improved during the year.

[0000038725-25-000011:8k_2_02:29]
2024 Guidance

[0000038725-25-000011:8k_2_02:30]
The Company expects its full year 2025 sales including the impact of its recently announced acquisitions to be in the range of $2.09 billion to $2.15 billion and full year 2025 EPS to be in the range of $4.05 to $4.25.

[0000038725-25-000011:8k_2_02:31]
Earnings Conference Call

[0000038725-25-000011:8k_2_02:32]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The fourth quarter 2024 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-25-000011:8k_2_02:33]
https://edge.media-server.com/mmc/p/9jnstij5

[0000038725-25-000011:8k_2_02:34]
For those interested in participating in the question-and-answer portion of the call, please register for the call at the link below.

[0000038725-25-000011:8k_2_02:35]
https://register.vevent.com/register/BI4b232e4ceea6435ba8f046e92e18e563

[0000038725-25-000011:8k_2_02:36]
All registrants will receive dial-in information and a PIN allowing them to access the live call. It is recommended that you join 10 minutes prior to the event start (although you may register and dial in at any time during the call).

[0000038725-25-000011:8k_2_02:37]
A replay of the conference call will be available from Tuesday, February 18, 2025, through 9:00 am ET on Tuesday, February 25, 2025, by visiting the listen-only webcast link above.

[0000038725-25-000011:8k_2_02:38]
Forward Looking Statements

[0000038725-25-000011:8k_2_02:39]
About Franklin Electric

[0000038725-25-000011:8k_2_02:40]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and energy. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications. Franklin Electric is proud to be named in Newsweek’s lists of America’s Most Responsible Companies and Most Trustworthy Companies for 2024 and America’s Climate Leaders 2024 by USA Today.

[0000038725-25-000011:8k_2_02:41]
Franklin Electric Contact:

[0000038725-25-000011:8k_2_02:42]
Jeffery L. Taylor

[0000038725-25-000011:8k_2_02:43]
Franklin Electric Co., Inc.

[0000038725-25-000011:8k_2_02:44]
InvestorRelations@fele.com

[0000038725-25-000011:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Fourth Quarter Ended |  | Fiscal Year End |
|  | December 31, 2024 |  | December 31, 2023 |  | December 31, 2024 |  | December 31, 2023 |
| Net sales | $ | 485,745 |  |  | $ | 472,970 |  |  | $ | 2,021,341 |  |  | $ | 2,065,133 |  |
| Cost of sales | 321,505 |  |  | 312,961 |  |  | 1,304,061 |  |  | 1,368,125 |  |
| Gross profit | 164,240 |  |  | 160,009 |  |  | 717,280 |  |  | 697,008 |  |
| Selling, general, and administrative expenses | 117,846 |  |  | 108,825 |  |  | 470,136 |  |  | 433,476 |  |
| Restructuring expense | 3,360 |  |  | 356 |  |  | 3,499 |  |  | 1,091 |  |
| Operating income | 43,034 |  |  | 50,828 |  |  | 243,645 |  |  | 262,441 |  |
| Interest expense | (1,339) |  |  | (1,481) |  |  | (6,319) |  |  | (11,790) |  |
| Other income, net | 630 |  |  | 1,831 |  |  | 1,339 |  |  | 3,696 |  |
| Foreign exchange expense, net | (1,590) |  |  | (4,026) |  |  | (6,818) |  |  | (12,124) |  |
| Income before income taxes | 40,735 |  |  | 47,152 |  |  | 231,847 |  |  | 242,223 |  |
| Income tax expense | 6,443 |  |  | 8,322 |  |  | 50,238 |  |  | 47,489 |  |
| Net income | $ | 34,292 |  |  | $ | 38,830 |  |  | $ | 181,609 |  |  | $ | 194,734 |  |
| Less: Net income attributable to noncontrolling interests | (637) |  |  | (281) |  |  | (1,300) |  |  | (1,462) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 33,655 |  |  | $ | 38,549 |  |  | $ | 180,309 |  |  | $ | 193,272 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.73 |  |  | $ | 0.83 |  |  | $ | 3.92 |  |  | $ | 4.17 |  |
| Diluted | $ | 0.72 |  |  | $ | 0.82 |  |  | $ | 3.86 |  |  | $ | 4.11 |  |

[0000038725-25-000011:8k_2_02:46]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | December 31, 2024 |  | December 31, 2023 |
| ASSETS |  |
| Cash and cash equivalents | $ | 220,540 |  |  | $ | 84,963 |  |
| Receivables (net) | 226,826 |  |  | 222,418 |  |
| Inventories | 483,875 |  |  | 508,696 |  |
| Other current assets | 32,950 |  |  | 37,718 |  |
| Total current assets | 964,191 |  |  | 853,795 |  |
| Property, plant, and equipment, net | 223,566 |  |  | 229,739 |  |
| Lease right-of-use assets, net | 62,637 |  |  | 57,014 |  |
| Goodwill and other assets | 570,212 |  |  | 587,574 |  |
| Total assets | $ | 1,820,606 |  |  | $ | 1,728,122 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 157,046 |  |  | $ | 152,419 |  |
| Accrued expenses and other current liabilities | 139,989 |  |  | 104,949 |  |
| Current lease liability | 18,878 |  |  | 17,316 |  |
| Current maturities of long-term debt and short-term borrowings | 117,814 |  |  | 12,355 |  |
| Total current liabilities | 433,727 |  |  | 287,039 |  |
| Long-term debt | 11,622 |  |  | 88,056 |  |
| Long-term lease liability | 43,304 |  |  | 38,549 |  |
| Income taxes payable non-current | — |  |  | 4,837 |  |
| Deferred income taxes | 10,193 |  |  | 29,461 |  |
| Employee benefit plans | 29,808 |  |  | 35,973 |  |
| Other long-term liabilities | 22,118 |  |  | 33,914 |  |
| Redeemable noncontrolling interest | 1,224 |  |  | 1,145 |  |
| Total equity | 1,268,610 |  |  | 1,209,148 |  |
| Total liabilities and equity | $ | 1,820,606 |  |  | $ | 1,728,122 |  |

[0000038725-25-000011:8k_2_02:47]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Twelve Months Ended |
| (In thousands) |  |  |  |
|  | December 31, 2024 |  | December 31, 2023 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 181,609 |  |  | $ | 194,734 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 56,073 |  |  | 52,260 |  |
| Non-cash lease expense | 21,438 |  |  | 18,852 |  |
| Share-based compensation | 12,061 |  |  | 10,133 |  |
| Other | (13,327) |  |  | 10,259 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (17,045) |  |  | 19,150 |  |
| Inventory | 10,889 |  |  | 48,176 |  |
| Accounts payable and accrued expenses | 15,285 |  |  | (23,085) |  |
| Operating leases | (21,129) |  |  | (18,874) |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | (3,870) |  | (2,902) |
| Other | 19,369 |  |  | 7,007 |  |
| Net cash flows from operating activities | 261,353 |  |  | 315,710 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (41,682) |  |  | (41,415) |  |
| Proceeds from sale of property, plant, and equipment | 1,182 |  |  | 1,494 |  |
| Acquisitions and investments | (5,201) |  |  | (34,831) |  |
| Other investing activities | 73 |  |  | 463 |  |
| Net cash flows from investing activities | (45,628) |  |  | (74,289) |  |
| Cash flows from financing activities: |  |  |  |
| Net change in debt | 29,235 |  |  | (115,529) |  |
| Proceeds from issuance of common stock | 7,204 |  |  | 9,193 |  |
| Purchases of common stock | (61,041) |  |  | (43,332) |  |
| Dividends paid | (46,876) |  |  | (41,723) |  |
| Deferred payments for acquisitions | (2,591) |  |  | (802) |  |
| Net cash flows from financing activities | (74,069) |  |  | (192,193) |  |
| Effect of exchange rate changes on cash and cash equivalents | (6,079) |  |  | (10,055) |  |
| Net change in cash and cash equivalents | 135,577 |  |  | 39,173 |  |
| Cash and cash equivalents at beginning of period | 84,963 |  |  | 45,790 |  |
| Cash and cash equivalents at end of period | $ | 220,540 |  |  | $ | 84,963 |  |

[0000038725-25-000011:8k_2_02:48]
Key Performance Indicators: Net Sales Summary

[0000038725-25-000011:8k_2_02:49]
|  | Net Sales For the Fourth Quarter |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Energy** | Distribution | Other/Elims | Consolidated |
| Q4 2023 | $ | 161.2 |  | $ | 46.6 |  | $ | 45.5 |  | $ | 26.3 |  | $ | 279.6 |  | $ | 65.7 |  | $ | 148.0 |  | $ | (20.3) |  | $ | 473.0 |  |
| Q4 2024 | $ | 158.5 |  | $ | 44.3 |  | $ | 49.7 |  | $ | 27.1 |  | $ | 279.6 |  | $ | 68.8 |  | $ | 157.2 |  | $ | (19.9) |  | $ | 485.7 |  |
| Change | $ | (2.7) |  | $ | (2.3) |  | $ | 4.2 |  | $ | 0.8 |  | $ | — |  | $ | 3.1 |  | $ | 9.2 |  | $ | 0.4 |  | $ | 12.7 |  |
| % Change | (2) | % | (5) | % | 9 | % | 3 | % | — | % | 5 | % | 6 | % |  | 3 | % |
| Foreign currency translation, net* | $ | (0.4) |  | $ | (5.5) |  | $ | (0.8) |  | $ | (0.8) |  | $ | (7.5) |  | $ | — |  | $ | — |  |  | $ | (7.5) |  |
| % Change | — | % | (12) | % | (2) | % | (3) | % | (3) | % | — | % | — | % |  | (2) | % |
| Acquisitions | $ | 3.1 |  | $ | — |  | $ | — |  | $ | — |  | $ | 3.1 |  | $ | — |  | $ | 4.0 |  |  | $ | 7.1 |  |
| % Change | 2 | % | — | % | — | % | — | % | 1 | % | — | % | 3 | % |  | 2 | % |
| Volume/Price | $ | (5.4) |  | $ | 3.2 |  | $ | 5.0 |  | $ | 1.6 |  | $ | 4.4 |  | $ | 3.1 |  | $ | 5.2 |  | $ | 0.4 |  | $ | 13.1 |  |
| % Change | (3) | % | 7 | % | 11 | % | 6 | % | 2 | % | 5 | % | 4 | % | (2) | % | 3 | % |

[0000038725-25-000011:8k_2_02:50]
|  | Net Sales For the Full Year |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Energy** | Distribution | Other/Elims | Consolidated |
| FY 2023 | $ | 744.4 |  | $ | 174.2 |  | $ | 198.3 |  | $ | 86.8 |  | $ | 1,203.7 |  | $ | 296.5 |  | $ | 673.3 |  | $ | (108.4) |  | $ | 2,065.1 |  |
| FY 2024 | $ | 708.5 |  | $ | 170.9 |  | $ | 211.4 |  | $ | 93.2 |  | $ | 1,184.0 |  | $ | 273.7 |  | $ | 685.5 |  | $ | (121.9) |  | $ | 2,021.3 |  |
| Change | $ | (35.9) |  | $ | (3.3) |  | $ | 13.1 |  | $ | 6.4 |  | $ | (19.7) |  | $ | (22.8) |  | $ | 12.2 |  | $ | (13.5) |  | $ | (43.8) |  |
| % Change | (5) | % | (2) | % | 7 | % | 7 | % | (2) | % | (8) | % | 2 | % |  | (2) | % |
| Foreign currency translation | $ | (0.9) |  | $ | (9.7) |  | $ | (6.3) |  | $ | (2.4) |  | $ | (19.3) |  | $ | — |  | $ | — |  |  | $ | (19.3) |  |
| % Change | — | % | (6) | % | (3) | % | (3) | % | (2) | % | — | % | — | % |  | (1) | % |
| Acquisitions | $ | 17.6 |  | $ | — |  | $ | — |  | $ | — |  | $ | 17.6 |  | $ | — |  | $ | 17.1 |  |  | $ | 34.7 |  |
| % Change | 2 | % | — | % | — | % | — | % | 1 | % | — | % | 3 | % |  | 2 | % |
| Volume/Price | $ | (52.6) |  | $ | 6.4 |  | $ | 19.4 |  | $ | 8.8 |  | $ | (18.0) |  | $ | (22.8) |  | $ | (4.9) |  | $ | (13.5) |  | $ | (59.2) |  |
| % Change | (7) | % | 4 | % | 10 | % | 10 | % | (1) | % | (8) | % | (1) | % | 12 | % | (3) | % |

[0000038725-25-000011:8k_2_02:51]
*The Company has presented local currency price increases used to offset currency devaluation in the Argentina and Turkey hyperinflationary economies within the foreign currency translation, net row above.

[0000038725-25-000011:8k_2_02:52]
** Recognizing the Company’s diverse portfolio and growth strategy, it renamed its Fueling Systems segment to Energy Systems to better reflect the markets and customers served by this business.

[0000038725-25-000011:8k_2_02:53]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-25-000011:8k_2_02:54]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2024 |
|  | Water | Energy | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 35.6 |  | $ | 24.7 |  | $ | 0.5 |  | $ | (17.8) |  | $ | 43.0 |  |
| % Operating Income To Net Sales | 12.7 | % | 35.9 | % | 0.3 | % |  | 8.9 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2023 |
|  | Water | Energy | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 44.1 |  | $ | 19.4 |  | $ | 1.0 |  | $ | (13.7) |  | $ | 50.8 |  |
| % Operating Income To Net Sales | 15.8 | % | 29.5 | % | 0.7 | % |  | 10.7 | % |

[0000038725-25-000011:8k_2_02:55]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year of 2024 |
|  | Water | Energy | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 197.9 |  | $ | 93.6 |  | $ | 24.3 |  | $ | (72.2) |  | $ | 243.6 |  |
| % Operating Income To Net Sales | 16.7 | % | 34.2 | % | 3.5 | % |  | 12.1 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year of 2023 |
|  | Water | Energy | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 196.6 |  | $ | 92.7 |  | $ | 34.3 |  | $ | (61.2) |  | $ | 262.4 |  |
| % Operating Income To Net Sales | 16.3 | % | 31.3 | % | 5.1 | % |  | 12.7 | % |
