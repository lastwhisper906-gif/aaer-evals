# FELE notes — 0000038725-25-000026


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000038725-25-000026:notes:1]
A portion of the Proxy Statement for the Annual Meeting of Shareholders to be held on May 2, 2025 (Part III).


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000038725-25-000026:notes:2]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Company--“Franklin Electric” or the “Company” shall refer to Franklin Electric Co., Inc. and its consolidated subsidiaries.

[0000038725-25-000026:notes:3]
Fiscal Year--The financial statements and accompanying notes are as of and for the years ended December 31, 2024, December 31, 2023 and December 31, 2022, and referred to as 2024, 2023 and 2022, respectively.

[0000038725-25-000026:notes:4]
Principles of Consolidation--The consolidated financial statements include the accounts of Franklin Electric Co., Inc. and its consolidated subsidiaries. All intercompany transactions have been eliminated.

[0000038725-25-000026:notes:5]
Business Combinations--The Company allocates the purchase price of its acquisitions to the assets acquired, liabilities assumed, and noncontrolling interests based upon their respective fair values at the acquisition date. The Company utilizes management estimates and may use inputs from an independent third-party valuation firm to assist in determining these fair values. The excess of the acquisition price over estimated fair values of the net assets acquired is recorded as goodwill. Goodwill is adjusted for any changes to acquisition date fair value amounts made within the measurement period, which may be up to one year from the acquisition date. If the preliminary, estimated fair values of the net assets acquired are in excess of the acquisition price, that represents a bargain purchase gain, and the Company records this amount in "Accrued expenses and other current liabilities" on the consolidated balance sheet until it completes its determination of fair values for the net assets acquired. Once that fair value determination is completed, the bargain purchase gain is recognized on the consolidated statements of income in "Other income/(expense), net". Acquisition-related transaction costs are recognized separately from the business combination and expensed as incurred.

[0000038725-25-000026:notes:6]
Revenue Recognition--Revenue is recognized when promised goods or services are transferred to customers in an amount that reflects the consideration to which the entity expects to be entitled to in exchange for those goods or services. The promise in a contract to transfer goods or services to a customer represents a performance obligation. The Company typically sells its products to customers by purchase order and does not have any additional performance obligations included in contracts to customers. Shipping and handling activities are considered to be fulfillment activities and are not considered to be a separate performance obligation. Therefore, the Company allocates the transaction price based on a single performance obligation. The Company typically ships products Free on Board (FOB) shipping point at which point control of the products passes to the customers. The Company considers the performance obligation satisfied and recognizes revenue at a point in time, the time of shipment. The Company applies a practical expedient to expense as incurred costs to obtain a contract with a customer when the amortization period would have been one year or less as well as applies the financing component practical expedient when the duration of the financing is one year or less.

[0000038725-25-000026:notes:7]
The Company’s products may include routine assurance-type warranties which do not qualify as separate performance obligations. In the event that significant post-shipment obligations were to exist for the Company’s products, revenue recognition would be deferred until the performance obligations were satisfied.

[0000038725-25-000026:notes:8]
The Company records net sales after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience.

[0000038725-25-000026:notes:9]
The following table disaggregates the Company's net sales from contracts with customers by segment:

[0000038725-25-000026:notes:10]
| Net Sales |
| (In millions) | 2024 |  | 2023 |  | 2022 |
| Water Systems |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | $ | 586.6 |  |  | $ | 636.0 |  |  | $ | 596.9 |  |
| Latin America | 170.9 |  |  | 174.2 |  |  | 159.3 |  |
| Europe, Middle East & Africa | 211.4 |  |  | 198.3 |  |  | 192.8 |  |
| Asia Pacific | 93.2 |  |  | 86.8 |  |  | 92.5 |  |
| Intersegment sales |  |  |  |  |  |
| United States & Canada | 121.9 |  |  | 108.4 |  |  | 116.0 |  |
| Total sales | 1,184.0 |  |  | 1,203.7 |  |  | 1,157.5 |  |
| Distribution |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 685.5 |  |  | 673.3 |  |  | 668.1 |  |
| Total sales | 685.5 |  |  | 673.3 |  |  | 668.1 |  |
| Energy Systems |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 212.4 |  |  | 220.9 |  |  | 242.6 |  |
| All other | 61.3 |  |  | 75.6 |  |  | 91.5 |  |
| Total sales | 273.7 |  |  | 296.5 |  |  | 334.1 |  |
| Intersegment Eliminations/Other | (121.9) |  |  | (108.4) |  |  | (116.0) |  |
| Consolidated | $ | 2,021.3 |  |  | $ | 2,065.1 |  |  | $ | 2,043.7 |  |

[0000038725-25-000026:notes:11]
Shipping and Handling Costs--Shipping and handling costs are considered activities required to fulfill the Company’s promise to transfer goods, and do not qualify as a separate performance obligation. Shipping and handling costs in the Company's Water Systems and Energy Systems segments are recorded as a component of cost of sales whereas shipping and handling costs in the Company's Distribution segment are recorded as a component of selling, general and administrative expenses.

[0000038725-25-000026:notes:12]
Research and Development Expense--The Company’s research and development activities are charged to expense in the period incurred. The Company incurred expenses of approximately $21.5 million in 2024, $17.7 million in 2023, and $16.7 million in 2022 related to research and development.

[0000038725-25-000026:notes:13]
Cash and Cash Equivalents--The Company considers cash on hand, demand deposits, and highly liquid investments with an original maturity date of three months or less to be cash and cash equivalents.

[0000038725-25-000026:notes:14]
Fair Value of Financial Instruments--Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value. The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-25-000026:notes:15]
Level 1 – Quoted prices for identical assets and liabilities in active markets;

[0000038725-25-000026:notes:16]
Level 2 – Quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets; and

[0000038725-25-000026:notes:17]
Level 3 – Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable.

[0000038725-25-000026:notes:18]
Accounts Receivable, Earned Discounts, and Allowance for Credit Losses--Accounts receivable are stated at estimated net realizable value. Accounts receivable are comprised of balances due from customers, net of earned discounts and estimated allowances for credit losses. Earned discounts are based on specific customer agreement terms. In determining allowances for credit losses, historical collection experience, current trends and reasonable, supportable future forecasts, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are reviewed.

[0000038725-25-000026:notes:19]
Inventories--Inventories are stated at the lower of cost or net realizable value. The majority of the cost of inventories is determined using the first in, first out (FIFO) method with a portion of inventory costs determined using the average cost method. The Company reviews its inventories for excess or obsolete products or components based on an analysis of historical usage and management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts.

[0000038725-25-000026:notes:20]
Property, Plant, and Equipment--Property, plant, and equipment are stated at historical cost. The Company capitalizes certain computer software and software development costs incurred in connection with developing or obtaining computer software for internal use, which are included in property, plant, and equipment. Depreciation of property, plant and equipment is calculated on a straight line basis over the following estimated useful lives:

[0000038725-25-000026:notes:21]
| Land improvement and buildings | 10 - 40 years |
| Machinery and equipment | 5 - 10 years |
| Software | 3 - 7 years |
| Furniture and fixtures | 3 - 7 years |

[0000038725-25-000026:notes:22]
Maintenance, repairs, and renewals of a minor nature are expensed as incurred. Betterments and major renewals which extend the useful lives or add to the productive capacity of buildings, improvements, and equipment are capitalized. The Company reviews its property, plant, and equipment for impairment at the asset group level whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. If an indicator is present, the Company compares carrying values to undiscounted future cash flows; if the undiscounted future cash flows are less than the carrying value, an impairment would be recognized for the difference between the fair value and the carrying value.

[0000038725-25-000026:notes:23]
The Company’s depreciation expense was $37.2 million, $35.1 million, and $33.1 million in 2024, 2023, and 2022, respectively.

[0000038725-25-000026:notes:24]
Leases--The Company determines if an arrangement is a lease, or contains a lease, at the inception of the arrangement and determines whether it is an operating or financing lease. Operating and financing leases result in the Company recording a right-of-use ("ROU") asset, current lease liability, and long term lease liability on its balance sheet. The Company has elected to not present leases with an initial term of 12 months or less on the balance sheet. The ROU assets and liabilities are initially recognized based on the present value of lease payments over the lease term. Initial direct costs and lease incentives are generally not material when measuring the ROU asset present value. Lease expense for operating lease payments is recognized on a straight-line basis over the lease term.

[0000038725-25-000026:notes:25]
In determining the present value of the ROU liability, the Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the Company’s borrowing information available at inception of the lease. A portion of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised. In addition, the Company has elected not to separate non-lease components from lease components when initially recording the ROU asset and liability.

[0000038725-25-000026:notes:26]
Goodwill and Other Intangible Assets--Goodwill is the excess of the purchase price over the fair value of acquired assets and liabilities in a business combination. Goodwill is not amortized but is subject to an impairment review annually and whenever indicators of impairment exist. The Company has the option to assess goodwill for impairment by initially performing a qualitative assessment to determine whether it is more-likely-than-not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more-likely-than-not that the fair value of a reporting unit is less than its carrying amount, then the quantitative goodwill impairment test is not required to be performed. If the Company determines that it is more-likely-than-not that the fair value of a reporting unit is less than its carrying amount, or if it does not elect the option to perform an initial qualitative assessment, the Company performs a quantitative goodwill impairment test. In the quantitative impairment test, the Company calculates the estimated fair value of the reporting unit. If the carrying amount of the reporting unit exceeds the estimated fair value, an impairment charge is recorded for the amount that its carrying amount, including goodwill, exceeds its fair value, limited to the total amount of goodwill allocated to that reporting unit.

[0000038725-25-000026:notes:27]
Indefinite-lived intangible assets, such as certain trade names with indefinite lives, are subject to an impairment review annually and whenever indicators of impairment exist. The Company has the option to assess indefinite-lived intangible assets for impairment by first performing qualitative assessments to determine whether it is more-likely-than-not that the fair values of the indefinite-lived intangible assets are less than the carrying amounts. If the Company determines that it is more-likely-than-not that an indefinite-lived intangible asset is impaired, or if the Company elects not to perform an initial qualitative assessment, the Company then performs the quantitative impairment test by comparing the fair value of the indefinite-lived intangible asset with its carrying amount. If the carrying amount exceeds the fair value of the indefinite-lived intangible asset, the Company writes the carrying amount down to the fair value.

[0000038725-25-000026:notes:28]
Amortization is recorded and calculated for definite-lived intangible assets on a basis that reflects cash flows over the estimated useful lives. The estimated useful lives over which each intangible class is amortized is as follows:

[0000038725-25-000026:notes:29]
| Customer relationships | 9 - 20 years |
| Patents | 17 years |
| Technology | 15 years |
| Trade names | 5 - 20 years |
| Other | 5 - 8 years |

[0000038725-25-000026:notes:30]
Definite-lived intangible assets are evaluated for impairment whenever a triggering event, including a significant change in the use of the asset or unexpected change in financial condition, occurs that indicates the carrying value may be impaired. The Company tests for impairment at the asset group level by comparing the carrying value of an asset group that includes the applicable definite lived intangible asset(s) to that asset group's undiscounted future cash flows. An impairment exists if the carrying value of the definite-lived intangible asset(s) is higher than the fair value, and the Company would record an impairment charge for the difference.

[0000038725-25-000026:notes:31]
Warranty Obligations--The Company provides warranties on most of its products. The warranty terms vary but are generally 2 years to 5 years from the date of manufacture or 1 year to 5 years from the date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.

[0000038725-25-000026:notes:32]
Income Taxes--Deferred tax assets and liabilities are determined based on the difference between the financial statement and tax basis of assets and liabilities and net operating loss and credit carry forwards using enacted tax rates in effect for the year in which the differences are expected to reverse. Valuation allowances are established when necessary to reduce deferred tax assets to the amounts expected to be realized. The Company records a liability for uncertain tax positions by establishing a more likely than not recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return.

[0000038725-25-000026:notes:33]
Defined Benefit Plans--The Company makes its determination for pension, post retirement, and post employment benefit plans liabilities based on management estimates and consultation with actuaries. The Company incorporates estimates and assumptions of future plan service costs, future interest costs on projected benefit obligations, rates of compensation increases, employee turnover rates, anticipated mortality rates, expected investment returns on plan assets, asset allocation assumptions of plan assets, and other factors.

[0000038725-25-000026:notes:34]
Earnings Per Common Share--The Company utilizes the two-class method to compute earnings available to common shareholders. Under the two-class method, the Company allocates net earnings to each class of common stock and participating security as if all of the net earnings for the period had been distributed. The Company’s participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders. Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period. Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards and non-employee deferred shares.

[0000038725-25-000026:notes:35]
Translation of Foreign Currency Financial Statements--All assets and liabilities of foreign subsidiaries in a functional currency other than the U.S. dollar are translated at year-end exchange rates. All revenue and expense accounts are translated at

[0000038725-25-000026:notes:36]
average rates in effect during the respective period. Transaction gains and losses and highly inflationary accounting adjustments are included in “Foreign exchange expense” within the Company’s consolidated statements of income, as incurred.

[0000038725-25-000026:notes:37]
In the second quarter of 2022, the Company concluded that Turkey represents a highly inflationary economy as its three-year cumulative inflation rate exceeded 100 percent. As a result, the Company started remeasuring the financial statements for the Company’s Turkish operations in accordance with the highly inflationary accounting rules as of April 1, 2022. As a result, all gains and losses resulting from the remeasurement of the financial results of operations and other transactional foreign exchange gains and losses are reflected in earnings rather than as a component of the Company’s comprehensive income within shareholders’ equity. Additionally, the Company’s operations in Argentina have also been accounted for using the highly inflationary accounting rules since the date they were acquired in 2018.

[0000038725-25-000026:notes:38]
Significant Estimates--The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make significant estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of expenses during the reporting periods. Although the Company regularly assesses these estimates, actual results could materially differ. The Company bases its estimates on historical experience and various other assumptions that it believes to be reasonable under the circumstances.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-25-000026:notes:39]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-25-000026:notes:40]
In November 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 is intended to improve reportable segment disclosure requirements, primarily through additional and more detailed information about a reportable segment's expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The guidance is to be applied retrospectively to all prior periods presented in the financial statements. The Company adopted this ASU in 2024 and the required disclosures are included in Note 15 - Segment and Geographic Information.

[0000038725-25-000026:notes:41]
Accounting Standards Issued But Not Yet Adopted

[0000038725-25-000026:notes:42]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. This amendment modifies the rules on income tax disclosures to require entities to disclose (1) specific categories in the rate reconciliation and additional information for reconciling items that meet a quantitative threshold, (2) the amount of income taxes paid (net of refunds received) (disaggregated by federal, state, and foreign taxes) as well as individual jurisdictions in which income taxes paid is equal to or greater than 5 percent of total income taxes paid net of refunds, (3) the income or loss from continuing operations before income tax expense or benefit (disaggregated between domestic and foreign) and (4) income tax expense or benefit from continuing operations (disaggregated by federal, state and foreign). ASU 2023-09 is effective for annual periods beginning after December 15, 2024, with early adoption permitted. ASU 2023-09 should be applied on a prospective basis, while retrospective application is permitted. The Company will adopt this ASU effective with its 2025 annual financial statements and does not anticipate the adoption to have a material impact on its financial statements.

[0000038725-25-000026:notes:43]
In November 2024, the FASB issued ASU 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires additional disclosure of the nature of expenses included in the income statement. The standard requires disclosures about specific types of expenses included in the expense captions presented in the income statement. This ASU is effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027, with early adoption permitted. The requirements should be applied on a prospective basis while retrospective application is permitted. The Company is currently evaluating the impact that the adoption of this guidance will have on its disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-25-000026:notes:44]
ACQUISITIONS
2024

[0000038725-25-000026:notes:45]
During the fourth quarter ended December 31, 2024, the Company acquired substantially all of the assets of FSHS Incorporated, a water treatment systems distributor.  The all-cash purchase price for the acquisition was $4.5 million. The fair value of the assets acquired and liabilities assumed is preliminary as of December 31, 2024.

[0000038725-25-000026:notes:46]
2023

[0000038725-25-000026:notes:47]
During the fourth quarter ended December 31, 2023, the Company acquired substantially all of the assets of Aqua Systems of Fort Myers, a water treatment systems distributor.  In another separate transaction, the Company acquired substantially all of the assets of Action Manufacturing and Supply, Inc., a water treatment equipment provider located in southwest Florida. The

[0000038725-25-000026:notes:48]
Company also acquired, in a separate transaction, substantially all of the assets of LCA Pump, LLC, which operates Water Works Pump, a Missouri based professional groundwater distributor. The combined, all-cash purchase price for the acquisitions in the fourth quarter of 2023 was $36.0 million, including contingent consideration with an estimated fair value of $4.3 million, after purchase price adjustments based on the level of working capital acquired. In 2024, the Company recorded a measurement period adjustment of $1.3 million to increase the acquisition-date fair value of the contingent consideration transferred. The measurement period adjustment resulted in an increase to acquired identifiable intangible assets of $2.3 million and a reduction to acquired goodwill of $1.0 million. The measurement period adjustments did not have a significant impact on the Company’s results of operations.

[0000038725-25-000026:notes:49]
During the first quarter ended March 31, 2023, the Company acquired substantially all of the assets of Phil-Good Products, Inc. ("Phil-Good"). Phil-Good is an injection molded plastics component manufacturer. In another separate transaction in the first quarter of 2023, the Company acquired 100 percent of the ownership interests of Hydropompe S.r.l. ("Hydropompe"). Hydropompe is a pump manufacturer with a focus in dewatering and sewage products. The combined, all-cash purchase price for both acquisitions in the first quarter of 2023 was $8.7 million after purchase price adjustments based on the level of working capital acquired.

[0000038725-25-000026:notes:50]
The fair value of the assets acquired and liabilities assumed for all 2023 acquisitions is final as of December 31, 2024.

[0000038725-25-000026:notes:51]
2022

[0000038725-25-000026:notes:52]
During the fourth quarter ended December 31, 2022, the Company acquired 100 percent of the ownership interests of Casper Well Products ("Casper") for a purchase price of $2.0 million after working capital adjustments. Casper conducts the sale and distribution of pumps, drilling equipment, tanks, pipe, accessories and other equipment used in drilling water wells and distribution of water-related products. The fair value of the assets acquired and liabilities assumed was final as of December 31, 2023.

[0000038725-25-000026:notes:53]
The Company has not included various disclosures for the 2022 through 2024 acquisitions including presenting separate results of operations of any of the acquired companies since the closing of the acquisitions or combined pro forma financial information of the Company and the acquired interests, as the Company does not consider any of the acquisitions to be material individually or in the aggregate.

[0000038725-25-000026:notes:54]
Transaction costs for all acquisition-related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations. Transaction costs are included in the "Selling, general, and administrative expenses" line of the Company’s consolidated statements of income and were immaterial for all periods presented.

[0000038725-25-000026:notes:55]
Subsequent Event

[0000038725-25-000026:notes:56]
In February 2025, the Company acquired 100 percent of the ownership interests of PumpEng Pty Ltd ("PumpEng") for a purchase price of AUD 24.0 million (approximately $15.0 million), subject to working capital and net debt closing adjustments. PumpEng, based in Australia, specializes in the design, manufacture and service of submersible pumps for the mining sector. The Company expects the purchase price to be primarily allocated to goodwill and other intangible assets.
Also in February 2025, the Company signed a definitive agreement to acquire Barnes de Colombia S.A., a leading manufacturer and distributor of industrial and commercial pumps based in Colombia for an enterprise value of $110.0 million, subject to working capital and net debt closing adjustments. The acquisition is subject to customary closing conditions, including Colombian antitrust clearance, and is expected to close on or about March 1, 2025.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-25-000026:notes:57]
GOODWILL AND OTHER INTANGIBLE ASSETS
The carrying amounts of the Company’s intangible assets, excluding goodwill, are as follows:

[0000038725-25-000026:notes:58]
| (In millions) |  | 2024 |  | 2023 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 263.4 |  |  | $ | (128.8) |  |  | $ | 263.7 |  |  | $ | (115.5) |  |
| Patents |  | 7.2 |  |  | (7.2) |  |  | 7.3 |  |  | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.5) |  |  | 7.5 |  |  | (7.5) |  |
| Trade names |  | 44.5 |  |  | (8.1) |  |  | 44.1 |  |  | (5.8) |  |
| Other |  | 2.8 |  |  | (2.4) |  |  | 3.4 |  |  | (2.8) |  |
| Total |  | $ | 325.4 |  |  | $ | (154.0) |  |  | $ | 326.0 |  |  | $ | (138.9) |  |
| Non-amortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 41.6 |  |  | — |  |  | 42.9 |  |  | — |  |
| Total intangibles |  | $ | 367.0 |  |  | $ | (154.0) |  |  | $ | 368.9 |  |  | $ | (138.9) |  |

[0000038725-25-000026:notes:59]
Amortization expense related to intangible assets for the years ended December 31, 2024, 2023, and 2022, was $18.8 million, $17.1 million, and $17.2 million, respectively.

[0000038725-25-000026:notes:60]
Amortization expense for each of the five succeeding years is projected as follows:

[0000038725-25-000026:notes:61]
| (In millions) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |
|  |  | $ | 18.0 |  |  | $ | 17.1 |  |  | $ | 15.6 |  |  | $ | 15.1 |  |  | $ | 14.0 |  |

[0000038725-25-000026:notes:62]
The change in the carrying amount of goodwill by reportable segment for 2024 and 2023, is as follows:

[0000038725-25-000026:notes:63]
| (In millions) |  | Water Systems |  | Energy Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2022 |  | $ | 211.9 |  |  | $ | 70.3 |  |  | $ | 45.8 |  |  | $ | 328.0 |  |
| Acquisitions |  | 8.0 |  |  | — |  |  | 4.8 |  |  | 12.8 |  |
| Adjustments to prior year acquisitions |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Foreign currency translation |  | 1.4 |  |  | 0.1 |  |  | — |  |  | 1.5 |  |
| Balance as of December 31, 2023 |  | $ | 221.4 |  |  | $ | 70.4 |  |  | $ | 50.6 |  |  | $ | 342.4 |  |
| Acquisitions |  | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| Adjustments to prior year acquisitions |  | (1.0) |  |  | — |  |  | — |  |  | (1.0) |  |
| Foreign currency translation |  | (3.6) |  |  | (0.1) |  |  | — |  |  | (3.7) |  |
| Balance as of December 31, 2024 |  | $ | 217.6 |  |  | $ | 70.3 |  |  | 50.6 |  |  | $ | 338.5 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000038725-25-000026:notes:64]
ACCRUED EXPENSES AND OTHER CURRENT LIABILITIES
Accrued expenses and other current liabilities consist of:

[0000038725-25-000026:notes:65]
| (In millions) |  | 2024 |  | 2023 |
| Salaries, wages, and commissions |  | $ | 49.0 |  |  | $ | 45.9 |  |
| Product warranty costs |  | 9.0 |  |  | 9.3 |  |
| Insurance |  | 2.4 |  |  | 2.5 |  |
| Employee benefits |  | 19.9 |  |  | 13.8 |  |
| Other |  | 39.5 |  |  | 28.7 |  |
|  |  | $ | 119.8 |  |  | $ | 100.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0000038725-25-000026:notes:66]
DEBT
Debt consisted of the following:

[0000038725-25-000026:notes:67]
| (In millions) |  | 2024 |  | 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 41.4 |  |  | 11.0 |  |
| Tax increment financing debt |  | 12.8 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.3 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | 129.4 |  |  | 100.5 |  |
| Less current maturities |  | (117.8) |  |  | (12.4) |  |
| Long-term debt |  | $ | 11.6 |  |  | $ | 88.1 |  |

[0000038725-25-000026:notes:68]
Debt outstanding at December 31, 2024, excluding unamortized debt issuance costs, matures as follows:

[0000038725-25-000026:notes:69]
| (In millions) |  | Total |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | Thereafter |
| Debt |  | $ | 129.5 |  |  | $ | 117.8 |  |  | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 1.4 |  |  | $ | 1.5 |  |  | $ | 5.8 |  |

[0000038725-25-000026:notes:70]
New York Life Agreement

[0000038725-25-000026:notes:71]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the “New York Life Agreement”) for $150.0 million maximum aggregate principal borrowing capacity. On October 28, 2016, the Company entered into the First Amendment to the Note Purchase and Private Shelf Agreement. The Amendment was intended to make the covenants within the New York Life Agreement consistent with the covenants that were modified in the Third Amended and Restated Credit Agreement (the “Credit Agreement”). On September 26, 2018, the Company entered into the Second Amendment to the Note Purchase and Private Shelf Agreement which increased the aggregate borrowing capacity to $200.0 million and authorized the issuance of $75.0 million of fixed rate senior noted due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable rate indebtedness with New York Life. On July 30, 2021, the New York Life agreement was renewed with an expiration date of July 30, 2024. On May 15, 2024, the Company entered into Amendment No. 1 to the renewal that increased the total available facility amount from lenders to $250.0 million from $200.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. As of December 31, 2024, there was $175.0 million of remaining borrowing capacity under the New York Life Agreement.

[0000038725-25-000026:notes:72]
Project Bonds

[0000038725-25-000026:notes:73]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).” The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (“Tax increment financing debt”) bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033. The use of the proceeds from the Project Notes was limited to assist the financing of the new Global Corporate Headquarters and Engineering Center. On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement. This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-25-000026:notes:74]
Prudential Agreement

[0000038725-25-000026:notes:75]
On April 9, 2007, the Company entered into the uncommitted and unsecured Amended and Restated Note Purchase and Private Shelf Agreement (the “Prudential Agreement”) in the amount of $175.0 million. Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”). The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had, at issuance, an average life of 10 years with a final maturity in 2019. On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million. On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to

[0000038725-25-000026:notes:76]
EBITDA ratio covenant in order to be equivalent to that under the Agreement. On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015. On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement. This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees. On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million. On October 28, 2016, the Company entered into Amendment No. 1 to the Third Amended and Restated Note Purchase and Private Shelf Agreement. This amendment was intended to make the covenants within the Prudential Agreement consistent with the covenants that were modified in the Credit Agreement (below). On July 30, 2021, the Company entered into the Fourth Amended and Restated Note Purchase and Private Shelf Agreement, which reduced the borrowing capacity to $150.0 million and extended the expiration date to July 30, 2024. On May 15, 2024, the Company entered into Amendment No. 1 to the Fourth Amended and Restated Note Purchase and Private Shelf Agreement that increased the total available facility amount from lenders to $250.0 million from $150.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. As of December 31, 2024, the Company has $250.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-25-000026:notes:77]
Credit Agreement

[0000038725-25-000026:notes:78]
On May 13, 2021, the Company entered into the Fourth Amended and Restated Credit Agreement (the “Credit Agreement”). The Credit Agreement extended the maturity date of the Company’s previous credit agreement to May 13, 2026, and decreased the commitment amount from $300.0 million to $250.0 million. On May 11, 2022, the Company entered into Amendment No. 1 that increased the commitment amount from $250.0 million to $350.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million (not to exceed a total commitment of $475.0 million) subject to the conditions contained therein. All of the Company’s present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers’ obligations under and in connection with the Credit Agreement. Additionally, the Company unconditionally guaranties all of the obligations of Franklin Electric B.V. under the Credit Agreement. Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100 percent to 0.275 percent (depending on the Company’s leverage ratio) of the aggregate commitment, payable quarterly in arrears. USD loans may be made either at (i) a Secured Overnight Financing Rate (SOFR) Term Benchmark, with a zero percent floor, plus an applicable margin of 0.950 percent to 1.975 percent (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement. EUR loans may be made in Euro Interbank Offer Rate (EURIBOR) Term Benchmark, with a zero percent floor, plus an applicable margin of 0.850 percent to 1.875 percent (depending on the Company’s leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-25-000026:notes:79]
As of December 31, 2024, the Company had $41.4 million outstanding borrowings with a weighted-average interest rate of 3.7 percent, $4.5 million in letters of credit outstanding, and $304.1 million of available capacity under the Credit Agreement. As of December 31, 2023, the Company had $11.0 million outstanding borrowings with a weighted average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $335.4 million of available capacity under the Credit Agreement.

[0000038725-25-000026:notes:80]
The Company also has lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $16.8 million. As of December 31, 2024, there were no outstanding borrowings and $16.8 million of available capacity under these lines of credit. As of December 31, 2023, there were $17.9 million overdraft lines of credit with no outstanding borrowings and $17.9 million of available capacity under these lines of credit.

[0000038725-25-000026:notes:81]
Covenants
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Credit Agreement, the Prudential Agreement, the Project Bonds, and the New York Life Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of December 31, 2024.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-25-000026:notes:82]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of

[0000038725-25-000026:notes:83]
those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor reasonably estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position,  results of operations, or cash flows.

[0000038725-25-000026:notes:84]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-25-000026:notes:85]
At December 31, 2024, the Company had $12.6 million of commitments primarily for capital expenditures and the purchase of raw materials to be used in production.

[0000038725-25-000026:notes:86]
At December 31, 2024, the Company has a contingent consideration liability with an estimated fair value of $5.0 million, the maximum potential payout, that was paid in early 2025.

[0000038725-25-000026:notes:87]
The changes in the carrying amount of the warranty accrual, as recorded in the “Accrued expenses and other current liabilities” line of the Company’s consolidated balance sheets for 2024 and 2023, are as follows:

[0000038725-25-000026:notes:88]
| (In millions) |  | 2024 |  | 2023 |
| Beginning balance |  | $ | 9.3 |  |  | $ | 11.2 |  |
| Accruals related to product warranties |  | 12.7 |  |  | 11.8 |  |
| Additions related to acquisitions |  | — |  |  | — |  |
| Reductions for payments made |  | (13.0) |  |  | (13.7) |  |
| Ending balance |  | $ | 9.0 |  |  | $ | 9.3 |  |

[0000038725-25-000026:notes:89]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. However, these financing leases are immaterial to the Company.

[0000038725-25-000026:notes:90]
The components of the Company's operating lease portfolio as of 2024, 2023, and 2022 are as follows:

[0000038725-25-000026:notes:91]
| Lease Cost (In millions): |  | 2024 |  | 2023 |  | 2022 |
| Operating lease cost |  | $ | 22.0 |  |  | $ | 18.8 |  |  | $ | 17.4 |  |
| Variable lease cost |  | $ | 8.1 |  |  | $ | 7.6 |  |  | $ | 6.9 |  |
| Other Information: |  |  |  |  |  |  |
| Weighted-average remaining lease term |  | 4.2 years |  | 4.0 years |  |  |
| Weighted-average discount rate |  | 5.0 | % |  | 4.3 | % |  |  |

[0000038725-25-000026:notes:92]
The Company has entered into lease agreements with aggregate future minimum payments of approximately $2.3 million that have not yet commenced as of December 31, 2024.

[0000038725-25-000026:notes:93]
The future minimum rental payments for non-cancellable operating leases as of December 31, 2024, are as follows:

[0000038725-25-000026:notes:94]
| (In millions) | Total |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | Thereafter |
| Undiscounted future minimum rental payments | $ | 73.5 |  |  | $ | 22.7 |  |  | $ | 17.6 |  |  | $ | 12.6 |  |  | $ | 9.0 |  |  | $ | 4.9 |  |  | $ | 6.7 |  |
| Less: Imputed Interest | 11.3 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | $ | 62.2 |  |  |  |  |  |  |  |  |  |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-25-000026:notes:95]
Share-based Compensation

[0000038725-25-000026:notes:96]
In 2023, the Company amended The Franklin Electric Co., Inc. 2017 Stock Plan, which is called The Franklin Electric Co., Inc. Amended and Restated 2017 Stock Plan ("the 2017 Amended and Restated Stock Plan") and increased the number of shares available under the Plan by 900,000 to 2,300,000. The 2017 Amended and Restated Stock Plan is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, stock unit awards, and stock appreciation rights (“SARs”) to key employees and non-employee directors. Stock options and SARs reduce the number of available shares by one share for each share subject to the option or SAR, and stock awards and stock unit awards settled in shares reduce the number of available shares by 1.5 shares for every one share delivered.

[0000038725-25-000026:notes:97]
The Company also maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the “2012 Stock Plan”), which is a share-based compensation plan that provides for discretionary grants of stock options, stock awards and stock unit awards to key employees and non-employee directors.

[0000038725-25-000026:notes:98]
The 2012 Stock Plan authorized 2,400,000 shares for issuance as follows:

[0000038725-25-000026:notes:99]
| 2012 Stock Plan |  | Authorized Shares |
| Stock Options |  | 1,680,000 |
| Stock/Stock Unit Awards |  | 720,000 |

[0000038725-25-000026:notes:100]
No additional options and awards are granted out of the 2012 Stock Plan. However, there are still unvested awards and unexercised options under this plan.

[0000038725-25-000026:notes:101]
The Company currently issues new shares from its common stock balance to satisfy option exercises and the settlement of stock awards and stock unit awards made under the outstanding stock plans.

[0000038725-25-000026:notes:102]
The Company recognizes share-based compensation expense only for the portion of shares that it expects to vest. As such, an estimated forfeiture rate is applied to calculate the share-based compensation expense, which is based on historical forfeiture data. The total share-based compensation expense recognized in 2024, 2023, and 2022 was $12.1 million, $10.1 million, and $11.0 million, respectively. The tax benefit recognized in 2024, 2023, and 2022 was $5.0 million, $5.6 million, and $4.7 million. Included in the benefit in 2024, 2023, and 2022 were excess tax benefits on share-based compensation of $2.3 million,  $3.2 million, and $2.1 million, respectively.

[0000038725-25-000026:notes:103]
Stock Options:

[0000038725-25-000026:notes:104]
Under the above plans, the exercise price of each option equals the market price of the Company’s common stock on the date of grant, and the options expire 10 years after the date of the grant. Options vest at 33 percent a year and become fully vested and fully exercisable after 3 years. Vesting is accelerated upon retirement, death or disability. Subject to the terms of the plans, in general, the aggregate option exercise price and any applicable tax withholding may be satisfied in cash or its equivalent, by the plan participant’s delivery of shares of the Company’s common stock having a fair market value at the time of exercise equal to the aggregate option exercise price and/or the applicable tax withholding or by having shares otherwise subject to the award withheld by the Company or via cashless exercise through a broker-dealer.

[0000038725-25-000026:notes:105]
The fair value of each option award is estimated on the date of grant using the Black-Scholes option valuation model with a single approach and amortized using a straight-line attribution method over the option’s vesting period. Options granted to retirement eligible employees are immediately expensed. The Company uses historical data to estimate the expected volatility of its stock, the weighted average expected life, the period of time options granted are expected to be outstanding, and its dividend yield. The risk-free rates for periods within the contractual life of the option are based on the U.S. Treasury yield curve in effect at the time of the grant.

[0000038725-25-000026:notes:106]
The table below provides the weighted average grant-date fair values and key assumptions used for the Black-Scholes model to determine the fair value of options granted during 2024, 2023, and 2022:

[0000038725-25-000026:notes:107]
|  |  | 2024 |  | 2023 |  | 2022 |
| Risk-free interest rate |  | 4.38 | % |  | 4.02 | % |  | 1.87 | % |
| Dividend yield |  | 1.03 | % |  | 0.95 | % |  | 0.93 | % |
| Volatility factor |  | 33.01 | % |  | 33.81 | % |  | 33.88 | % |
| Expected term |  | 6.0 years |  | 6.0 years |  | 5.5 years |
| Weighted average grant-date fair value of options |  | $ | 35.03 |  |  | $ | 34.51 |  |  | $ | 26.05 |  |

[0000038725-25-000026:notes:108]
A summary of the Company’s outstanding stock option activity and related information is as follows:

[0000038725-25-000026:notes:109]
| (Shares in thousands) |  | Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | AggregateIntrinsic Value (000’s) |
| Stock Options |  |  |  |  |
| Outstanding at beginning of 2024 |  | 900 |  |  | $ | 58.96 |  |  |  |  |  |
| Granted |  | 116 |  |  | 96.90 |  |  |  |  |  |
| Exercised |  | (153) |  |  | 46.88 |  |  |  |  |  |
| Forfeited |  | (2) |  |  | 95.07 |  |  |  |  |  |
| Expired |  | — |  |  | — |  |  |  |  |  |
| Outstanding at end of 2024 |  | 861 |  |  | $ | 66.15 |  |  | 5.06 years |  | $ | 27,010 |  |
| Expected to vest after applying forfeiture rate |  | 857 |  |  | $ | 66.03 |  |  | 5.04 years |  | $ | 27,001 |  |
| Vested and exercisable at end of period |  | 674 |  |  | $ | 58.34 |  |  | 4.06 years |  | $ | 26,362 |  |

[0000038725-25-000026:notes:110]
| (In millions) |  | 2024 |  | 2023 |  | 2022 |
| Intrinsic value of options exercised |  | $ | 8.8 |  |  | $ | 11.6 |  |  | $ | 3.7 |  |
| Cash received from the exercise of options |  | 7.2 |  |  | 9.2 |  |  | 3.9 |  |
| Fair value of shares vested |  | 2.5 |  |  | 3.1 |  |  | 3.1 |  |
| Tax benefit of options exercised |  | 1.8 |  |  | 2.9 |  |  | 0.9 |  |

[0000038725-25-000026:notes:111]
As of December 31, 2024, there was $2.2 million of total unrecognized compensation cost related to non-vested stock options granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.90 years.

[0000038725-25-000026:notes:112]
Stock/Stock Unit Awards:

[0000038725-25-000026:notes:113]
Under the 2017 Stock Plan, non-employee directors and employees may be granted stock awards and stock units. Stock awards to non-employee directors are generally fully vested when made. Stock/stock unit awards to employees cliff vest over 3 years (subject to accelerated vesting of a pro rata portion in the case of retirement, death or disability) and may be contingent on the attainment of certain performance goals. Dividends are paid to the recipient prior to vesting, except that dividends on performance-based stock awards under the 2012 Stock Plan and the 2017 Stock Plan will be paid only to the extent the performance goals are met.

[0000038725-25-000026:notes:114]
Stock/stock unit awards granted to retirement eligible employees are expensed over the vesting period. Compensation cost for the performance stock/stock unit awards is accrued based on the probable outcome of specified performance conditions.

[0000038725-25-000026:notes:115]
A summary of the Company’s restricted stock/stock unit award activity and related information is as follows:

[0000038725-25-000026:notes:116]
| (Shares in thousands) |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Restricted Stock/Stock Unit Awards |  |  |
| Non-vested at beginning of 2024 |  | 259 |  |  | $ | 85.05 |  |
| Awarded |  | 174 |  |  | 93.97 |  |
| Vested |  | (104) |  |  | 75.70 |  |
| Forfeited |  | (15) |  |  | 90.30 |  |
| Non-vested at end of 2024 |  | 314 |  |  | $ | 92.83 |  |

[0000038725-25-000026:notes:117]
The weighted-average grant date fair value of restricted stock/stock unit awards granted in 2024, 2023, and 2022, is $93.97, $87.31, and $81.16, respectively. The fair value of restricted stock/stock unit awards that vested in 2024, 2023, and 2022, was $7.9 million, $8.0 million, and $9.1 million, respectively. 
As of December 31, 2024, there was $8.8 million of total unrecognized compensation cost related to non-vested stock/stock unit awards granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.42 years.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-25-000026:notes:118]
Authorized Shares

[0000038725-25-000026:notes:119]
The Company has the authority to issue 65,000,000, $0.10 par value common shares.

[0000038725-25-000026:notes:120]
The Company also has the authority to issue 100,000 preference shares with no par value and 5,000,000 preferred shares with no par value. No preference or preferred shares have been issued.

[0000038725-25-000026:notes:121]
Repurchased Shares

[0000038725-25-000026:notes:122]
During 2024, 2023, and 2022, pursuant to a stock repurchase program authorized by the Company’s Board of Directors, the Company repurchased and retired the following amounts and number of shares:

[0000038725-25-000026:notes:123]
| (In millions, except share amounts) |  | 2024 |  | 2023 |  | 2022 |
| Repurchases |  | $ | 53.1 |  |  | $ | 32.5 |  |  | $ | 36.3 |  |
| Shares |  | 549,062 |  |  | 371,452 |  |  | 453,207 |  |

[0000038725-25-000026:notes:124]
The Company retired shares in the amount of 74,513, 101,690, and 63,133 in 2024, 2023, and 2022, respectively, that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards. The Company also reduced outstanding shares in the amount of 5,930, 0, and 16,839 in 2024, 2023, and 2022, respectively, that had been previously granted as stock awards to employees but were forfeited upon not meeting the required restriction criteria or termination.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-25-000026:notes:125]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss), net of tax, by component are summarized below:

[0000038725-25-000026:notes:126]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance, December 31, 2021 | $ | (179.6) |  |  | $ | (49.0) |  |  | $ | (228.6) |  |
| Other comprehensive income/(loss) before reclassifications(1) | (11.7) |  |  | 4.9 |  |  | (6.8) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (2)(3) | — |  |  | 4.0 |  |  | 4.0 |  |
| Net other comprehensive income/(loss) | (11.7) |  |  | 8.9 |  |  | (2.8) |  |
| Balance, December 31, 2022 | $ | (191.3) |  |  | $ | (40.1) |  |  | $ | (231.4) |  |
| Other comprehensive income/(loss) before reclassifications(1) | 12.0 |  |  | (3.3) |  |  | 8.7 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (2)(3) | — |  |  | 1.6 |  |  | 1.6 |  |
| Net other comprehensive income/(loss) | 12.0 |  |  | (1.7) |  |  | 10.3 |  |
| Balance, December 31, 2023 | $ | (179.3) |  |  | $ | (41.8) |  |  | $ | (221.1) |  |
| Other comprehensive income/(loss) before reclassifications(1) | (35.7) |  |  | 1.1 |  |  | (34.6) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (2)(3) | — |  |  | 1.7 |  |  | 1.7 |  |
| Net other comprehensive income/(loss) | (35.7) |  |  | 2.8 |  |  | (32.9) |  |
| Balance, December 31, 2024 | $ | (215.0) |  |  | $ | (39.0) |  |  | $ | (254.0) |  |

[0000038725-25-000026:notes:127]
(1) Net of tax (benefit)/expense of $0.3 million,  $(1.1) million and $1.8 million for 2024, 2023, and 2022, respectively.

[0000038725-25-000026:notes:128]
(2) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 10 - Employee Benefit Plans for additional details) and is included in the “Other income/(expense), net” line of the Company’s consolidated statements of income.

[0000038725-25-000026:notes:129]
(3) Net of tax expense of $0.6 million, $0.5 million and $1.8 million for 2024, 2023, and 2022, respectively.
Amounts related to noncontrolling interests were not material.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-25-000026:notes:130]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of December 31, 2024, the Company maintained two domestic pension plans and three German pension plans. The Company used a December 31, 2024 measurement date for these plans. One of the Company’s domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees. Both domestic plans were frozen as of December 31, 2011. The two domestic and three German plans collectively comprise the ‘Pension Benefits’ disclosure caption.

[0000038725-25-000026:notes:131]
Other Benefits - The Company’s other post-retirement benefit plan provides health and life insurance to domestic employees hired prior to 1992. The Company effectively capped its cost for those benefits through plan amendments made in 1992, freezing Company contributions for insurance benefits at 1991 levels for current and future beneficiaries with actuarially reduced benefits for employees who retire before age 65. The disclosures surrounding this plan are reflected in the “Other Benefits” caption.

[0000038725-25-000026:notes:132]
The following table sets forth aggregated information related to the Company’s pension benefits and other postretirement benefits, including changes in the benefit obligations, changes in plan assets, funded status, amounts recognized in the balance sheet, amounts recognized in accumulated other comprehensive income, and actuarial assumptions that the Company considered in its determination of benefit obligations and plan costs.

[0000038725-25-000026:notes:133]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Accumulated benefit obligation, end of year |  | $ | 127.1 |  |  | $ | 136.4 |  |  | $ | 4.6 |  |  | $ | 5.6 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |  |
| Benefit obligation, beginning of year |  | $ | 137.5 |  |  | $ | 135.2 |  |  | $ | 5.6 |  |  | $ | 6.0 |  |
| Service cost |  | 0.6 |  |  | 0.6 |  |  | — |  |  | — |  |
| Interest cost |  | 6.1 |  |  | 6.4 |  |  | 0.3 |  |  | 0.3 |  |
| Actuarial (gain)/loss |  | (5.3) |  |  | 4.2 |  |  | (0.6) |  |  | — |  |
| Settlements paid |  | — |  |  | (0.5) |  |  | — |  |  | — |  |
| Benefits paid |  | (9.8) |  |  | (8.9) |  |  | (0.7) |  |  | (0.7) |  |
| Foreign currency exchange |  | (1.2) |  |  | 0.5 |  |  | — |  |  | — |  |
| Benefit obligation, end of year |  | $ | 127.9 |  |  | $ | 137.5 |  |  | $ | 4.6 |  |  | $ | 5.6 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of assets, beginning of year |  | $ | 111.7 |  |  | $ | 113.4 |  |  | $ | — |  |  | $ | — |  |
| Actual return on plan assets |  | 3.1 |  |  | 6.9 |  |  | — |  |  | — |  |
| Company contributions |  | 0.6 |  |  | 0.6 |  |  | 0.7 |  |  | 0.7 |  |
| Settlements paid |  | — |  |  | (0.4) |  |  | — |  |  | — |  |
| Benefits paid |  | (9.8) |  |  | (8.9) |  |  | (0.7) |  |  | (0.7) |  |
| Foreign currency exchange |  | (0.3) |  |  | 0.1 |  |  | — |  |  | — |  |
| Plan assets, end of year |  | $ | 105.3 |  |  | $ | 111.7 |  |  | $ | — |  |  | $ | — |  |
| Funded status |  | $ | (22.6) |  |  | $ | (25.8) |  |  | $ | (4.6) |  |  | $ | (5.6) |  |
| Amounts recognized in balance sheet: |  |  |  |  |  |  |  |  |
| Non current assets |  | $ | 7.6 |  |  | $ | 4.2 |  |  | $ | — |  |  | $ | — |  |
| Current liabilities |  | (6.1) |  |  | (0.5) |  |  | (0.7) |  |  | (0.7) |  |
| Non current liabilities |  | (24.1) |  |  | (29.5) |  |  | (3.9) |  |  | (4.9) |  |
| Net liability, end of year |  | $ | (22.6) |  |  | $ | (25.8) |  |  | $ | (4.6) |  |  | $ | (5.6) |  |
| Amount recognized in accumulated other comprehensive income/(loss): |  |  |  |  |  |  |  |  |
| Prior service cost |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net actuarial gain (loss) |  | (39.8) |  |  | (42.1) |  |  | 0.8 |  |  | 0.3 |  |
| Settlement |  | — |  |  | — |  |  | — |  |  | — |  |
| Total recognized in accumulated other comprehensive income/(loss) |  | $ | (39.8) |  |  | $ | (42.1) |  |  | $ | 0.8 |  |  | $ | 0.3 |  |

[0000038725-25-000026:notes:134]
As of December 31, 2024, the pension benefits' aggregate accumulated benefit obligation and projected benefit obligation for plans that have an accumulated benefit obligation and projected benefit obligation in excess of plan assets was $33.6 million and $34.5 million, respectively and as of December 31, 2023, was $33.3 million and $34.4 million, respectively.  As of December 31, 2024 and December 31, 2023, the aggregate fair value of plan assets related to these plans was $4.3 million and $4.4 million, respectively.

[0000038725-25-000026:notes:135]
The following table sets forth other changes in plan assets and benefit obligation recognized in other comprehensive income for 2024 and 2023:

[0000038725-25-000026:notes:136]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net actuarial (gain)/loss |  | $ | (0.9) |  |  | $ | 4.4 |  |  | $ | (0.6) |  |  | $ | — |  |
| Amortization of: |  |  |  |  |  |  |  |  |
| Net actuarial loss |  | (2.3) |  |  | (2.1) |  |  | — |  |  | — |  |
| Prior service credit |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement recognition |  | — |  |  | — |  |  | — |  |  | — |  |
| Deferred tax asset |  | 0.8 |  |  | (0.6) |  |  | 0.1 |  |  | — |  |
| Foreign currency exchange |  | 0.1 |  |  | — |  |  | — |  |  | — |  |
| Total recognized in other comprehensive income |  | $ | (2.3) |  |  | $ | 1.7 |  |  | $ | (0.5) |  |  | $ | — |  |

[0000038725-25-000026:notes:137]
The increased discount rate, partially offset by unfavorable returns on assets were the largest contributors to the net actuarial gains recorded in 2024. The decreased discount rate is the largest contributor to the net actuarial losses affecting the benefit obligation for the defined benefit pension plans in 2023.

[0000038725-25-000026:notes:138]
Weighted-average assumptions used to determine domestic benefit obligations:

[0000038725-25-000026:notes:139]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Discount rate |  | 5.48 | % |  | 4.90 | % |  | 5.47 | % |  | 4.88 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | 2.00 - 9.00%(Graded) |  | 2.00 - 9.00%(Graded) |

[0000038725-25-000026:notes:140]
*No rate of increases in future compensation were used in the assumptions for 2024 and 2023, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation. The weighted-average interest crediting rate of the cash balance component of the domestic Pension Plan was 4.5 percent for 2024, 2023, and 2022 and is based on the approximate 30-year Treasury rate as of November of the prior year with a minimum of 4.5 percent.

[0000038725-25-000026:notes:141]
Assumptions used to determine domestic periodic benefit cost:

[0000038725-25-000026:notes:142]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2024 |  | 2023 |  | 2022 |  | 2024 |  | 2023 |  | 2022 |
| Discount rate |  | 4.95 | % |  | 5.14 | % |  | 2.79 | % |  | 4.88 | % |  | 5.08 | % |  | 2.57 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | — | % | * | 2.00 - 9.00%(Graded) |  | 2.00 - 9.00%(Graded) |  | 2.00 - 9.00%(Graded) |
| Expected long-term rate of return on plan assets |  | 6.20 | % |  | 5.70 | % |  | 4.50 | % |  | — | % |  | — | % |  | — | % |

[0000038725-25-000026:notes:143]
*No rate of increases in future compensation were used in the assumptions for 2024, 2023, and 2022, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation.

[0000038725-25-000026:notes:144]
For the years ended December 31, 2024 and December 31, 2023, the Company used the PRI-2012 aggregate mortality table, and then projected forward from 2012 using Scale MP-2021 released by the Society of Actuaries during 2021 to estimate future mortality rates based upon current data.

[0000038725-25-000026:notes:145]
The following table sets forth the aggregated net periodic benefit cost for all defined benefit plans for 2024, 2023, and 2022:

[0000038725-25-000026:notes:146]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | 2024 |  | 2023 |  | 2022 |  | 2024 |  | 2023 |  | 2022 |
| Service cost | $ | 0.6 |  |  | $ | 0.6 |  |  | $ | 0.7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 6.1 |  |  | 6.4 |  |  | 3.3 |  |  | 0.3 |  |  | 0.3 |  |  | 0.1 |  |
| Expected return on assets | (7.5) |  |  | (7.2) |  |  | (6.1) |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Transition obligation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 2.3 |  |  | 2.1 |  |  | 5.6 |  |  | — |  |  | — |  |  | 0.1 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 1.5 |  |  | $ | 1.9 |  |  | $ | 3.5 |  |  | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.2 |  |

[0000038725-25-000026:notes:147]
The Company consults with a third party investment manager for the assets of the funded domestic defined benefit plan. The plan assets are currently invested primarily in pooled funds, where each fund in turn is composed of mutual funds that have at least daily net asset valuations. Thus, the Company’s funded domestic defined benefit plan assets are invested in a “fund of funds” approach.

[0000038725-25-000026:notes:148]
The Company’s Board has delegated oversight and guidance to an appointed Employee Benefits Committee. The Committee has the tasks of reviewing plan performance and asset allocation, ensuring plan compliance with applicable laws, establishing plan policies, procedures, and controls, monitoring expenses, and other related activities.

[0000038725-25-000026:notes:149]
The plan’s investment policies and strategies focus on the ability to fund benefit obligations as they come due. Considerations include the plan’s current funded level, plan design, benefit payment assumptions, funding regulations, impact of potentially volatile business results on the Company’s ability to make certain levels of contributions, and interest rate and asset return volatility among other considerations. The Company currently attempts to maintain plan funded status at approximately 80 percent or greater pursuant to the Pension Protection Act of 2007. Given the plan’s current funded status, the Company’s cash on hand, cash historically generated from business operations, and cash available under committed credit facilities, the Company sees ample liquidity to achieve this goal.

[0000038725-25-000026:notes:150]
Risk management and continuous monitoring requirements are met through monthly investment portfolio reports, quarterly Employee Benefits Committee meetings, annual valuations, asset/liability studies, and the annual assumption process focusing primarily on the return on asset assumption and the discount rate assumption. As of December 31, 2024 and December 31, 2023, funds were invested in equity, fixed income, and other investments as follows:

[0000038725-25-000026:notes:151]
|  |  | Target Percentage |  | Plan Asset Allocation at Year-End |
| Asset Category |  | at Year-End 2024 |  | 2024 |  | 2023 |
| Equity securities |  | 16 | % |  | 16 | % |  | 16 | % |
| Fixed income securities |  | 79 | % |  | 79 | % |  | 79 | % |
| Other |  | 5 | % |  | 5 | % |  | 5 | % |
| Total |  | 100 | % |  | 100 | % |  | 100 | % |

[0000038725-25-000026:notes:152]
The Company does not see any particular concentration of risk within the plans, nor any plan assets that pose difficulties for fair value assessment. The Company currently has no allocation to potentially illiquid or potentially difficult to value assets such as hedge funds, venture capital, private equity, and real estate.

[0000038725-25-000026:notes:153]
The Company works with actuaries and consultants in making its determination of the asset rate of return assumption and also the discount rate assumption.

[0000038725-25-000026:notes:154]
Asset class assumptions are set using a combination of empirical and forward-looking analysis for long-term rate of return on plan assets. A variety of models are applied for filtering historical data and isolating the fundamental characteristics of asset classes. These models provide empirical return estimates for each asset class, which are then reviewed and combined with a qualitative assessment of long-term relationships between asset classes before a return estimate is finalized. This provides an

[0000038725-25-000026:notes:155]
additional means for correcting for the effect of unrealistic or unsustainable short-term valuations or trends, opting instead for return levels and behavior that are more likely to prevail over long periods. With that, the Company has assumed an expected long-term rate of return on plan assets of 5.75 percent for the 2025 net periodic benefit cost, down from 6.20 percent in the prior year.

[0000038725-25-000026:notes:156]
The Company uses the Aon Hewitt AA Above Median curve to determine the discount rate. All cash flow obligations under the plan are matched to bonds in the Aon Hewitt universe of liquid, high-quality, non-callable / non-puttable corporate bonds with outliers removed. From that matching exercise, a discount rate is determined.

[0000038725-25-000026:notes:157]
The Company’s German pension plans are funded by insurance contract policies whereby the insurance company guarantees a fixed minimum return. Due to tax legislation, individual pension benefits can only be financed using direct insurance policies up to certain maximums. These maximum amounts in respect of each member are paid into such an arrangement on a yearly basis.

[0000038725-25-000026:notes:158]
The Company designated all equity and most domestic fixed income plan assets as Level 1, as they are mutual funds with prices that are readily available. The U.S. Treasury securities and German plan assets are designated as Level 2 inputs. The fair value of the German plan assets are measured by the reserve that is supervised by the German Federal Financial Supervisory Authority. The U.S. Treasury securities are administered by the United States government.

[0000038725-25-000026:notes:159]
The fair values of the Company’s pension plan assets for 2024 and 2023 by asset category are as follows:

[0000038725-25-000026:notes:160]
| (In millions) |  | 2024 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| International equity mutual funds |  | $ | 17.2 |  |  | $ | 17.2 |  |  | $ | — |  |  | $ | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 11.1 |  |  | — |  |  | 11.1 |  |  | — |  |
| Fixed income mutual funds |  | 72.1 |  |  | 72.1 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.3 |  |  | — |  |  | 4.3 |  |  | — |  |
| Cash and equivalents |  | 0.6 |  |  | 0.6 |  |  | — |  |  | — |  |
| Total |  | $ | 105.3 |  |  | $ | 89.9 |  |  | $ | 15.4 |  |  | $ | — |  |

[0000038725-25-000026:notes:161]
| (In millions) |  | 2023 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| International equity mutual funds |  | $ | 18.3 |  |  | $ | 18.3 |  |  | $ | — |  |  | $ | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 12.3 |  |  | — |  |  | 12.3 |  |  | — |  |
| Fixed income mutual funds |  | 76.0 |  |  | 76.0 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.4 |  |  | — |  |  | 4.4 |  |  | — |  |
| Cash and equivalents |  | 0.7 |  |  | 0.7 |  |  | — |  |  | — |  |
| Total |  | $ | 111.7 |  |  | $ | 95.0 |  |  | $ | 16.7 |  |  | $ | — |  |

[0000038725-25-000026:notes:162]
The Company estimates total contributions to the plans of about $7.3 million in 2025.

[0000038725-25-000026:notes:163]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid in accordance with the following schedule:

[0000038725-25-000026:notes:164]
| (In millions) |  | Pension Benefits |  | Other Benefits |
| 2025 |  | $ | 16.0 |  |  | $ | 0.6 |  |
| 2026 |  | $ | 15.7 |  |  | $ | 0.6 |  |
| 2027 |  | $ | 14.8 |  |  | $ | 0.6 |  |
| 2028 |  | $ | 9.4 |  |  | $ | 0.5 |  |
| 2029 |  | $ | 9.1 |  |  | $ | 0.5 |  |
| Years 2030 through 2034 |  | $ | 41.7 |  |  | $ | 2.0 |  |

[0000038725-25-000026:notes:165]
Defined Contribution Plans - The Company maintained two defined contribution plans during 2024, 2023, and 2022. The Company’s cash contributions are allocated to participant’s accounts based on investment elections.

[0000038725-25-000026:notes:166]
The following table sets forth Company contributions to the defined contribution plans:

[0000038725-25-000026:notes:167]
| (In millions) |  | 2024 |  | 2023 |  | 2022 |
| Company contributions to the plans |  | $ | 11.4 |  |  | $ | 11.5 |  |  | $ | 11.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-25-000026:notes:168]
INCOME TAXES
Income before income taxes consisted of the following:

[0000038725-25-000026:notes:169]
| (In millions) |  | 2024 |  | 2023 |  | 2022 |
| Domestic |  | $ | 169.5 |  |  | $ | 163.9 |  |  | $ | 157.6 |  |
| Foreign |  | 62.3 |  |  | 78.3 |  |  | 77.6 |  |
|  |  | $ | 231.8 |  |  | $ | 242.2 |  |  | $ | 235.2 |  |

[0000038725-25-000026:notes:170]
The income tax provision/(benefit) consisted of the following:

[0000038725-25-000026:notes:171]
| (In millions) |  | 2024 |  | 2023 |  | 2022 |
| Current: |  |  |  |  |  |  |
| Federal |  | $ | 42.5 |  |  | $ | 27.0 |  |  | $ | 25.3 |  |
| Foreign |  | 17.3 |  |  | 14.9 |  |  | 15.3 |  |
| State |  | 10.0 |  |  | 7.2 |  |  | 7.0 |  |
| Total current |  | 69.8 |  |  | 49.1 |  |  | 47.6 |  |
| Deferred: |  |  |  |  |  |  |
| Federal |  | (16.0) |  |  | (1.1) |  |  | (0.1) |  |
| Foreign |  | (0.8) |  |  | (0.3) |  |  | (2.6) |  |
| State |  | (2.8) |  |  | (0.2) |  |  | 1.5 |  |
| Total deferred |  | $ | (19.6) |  |  | $ | (1.6) |  |  | $ | (1.2) |  |
|  |  | $ | 50.2 |  |  | $ | 47.5 |  |  | $ | 46.4 |  |

[0000038725-25-000026:notes:172]
A reconciliation of the tax provision for continuing operations at the U.S. statutory rate to the effective income tax expense rate as reported is as follows:

[0000038725-25-000026:notes:173]
|  |  | 2024 |  | 2023 |  | 2022 |
| U.S. Federal statutory rate |  | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income taxes, net of federal benefit |  | 2.3 |  |  | 2.3 |  |  | 2.9 |  |
| Foreign operations |  | 1.0 |  |  | (0.7) |  |  | (0.5) |  |
| R&D tax credits |  | (0.6) |  |  | (0.4) |  |  | (0.4) |  |
| Uncertain tax position adjustments |  | 0.2 |  |  | (0.1) |  |  | 0.1 |  |
| Valuation allowance on state and foreign deferred tax |  | 0.2 |  |  | (0.2) |  |  | (0.6) |  |
| Share-based compensation |  | (0.8) |  |  | (1.0) |  |  | (0.7) |  |
| Other items |  | 0.9 |  |  | (0.1) |  |  | (0.5) |  |
| Foreign Derived Intangible Income |  | (3.5) |  |  | (2.4) |  |  | (2.6) |  |
| Nondeductible officer's compensation |  | 1.0 |  |  | 1.2 |  |  | 1.0 |  |
| Effective tax rate |  | 21.7 | % |  | 19.6 | % |  | 19.7 | % |

[0000038725-25-000026:notes:174]
The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to U.S. state taxes, foreign earnings taxed at rates higher than the U.S. statutory rate, and nondeductible officer’s compensation, which were partially offset by the recognition of the U.S. foreign-derived intangible income (FDII) provisions, certain incentives, and discrete events.

[0000038725-25-000026:notes:175]
The Company recorded discrete excess tax benefits from share-based compensation of $2.3 million in the year ended December 31, 2024. The Company recorded an increased benefit in the U.S. foreign-derived intangible income (FDII) provisions related to a prepayment of inventory from foreign subsidiaries, that is unlikely to recur in future periods.

[0000038725-25-000026:notes:176]
Significant components of the Company’s deferred tax assets and liabilities were as follows:

[0000038725-25-000026:notes:177]
| (In millions) |  | 2024 |  | 2023 |
| Deferred tax assets: |  |  |  |  |
| Accrued expenses and reserves |  | $ | 15.5 |  |  | $ | 15.1 |  |
| Compensation and employee benefits |  | 16.0 |  |  | 17.4 |  |
| Intercompany prepayments (FDII related) |  | 16.9 |  |  | — |  |
| Net operating losses, tax credit carryforwards, and other |  | 11.8 |  |  | 13.2 |  |
| Lease liability |  | 15.7 |  |  | 14.7 |  |
| Research and development expenditures, net |  | 7.4 |  |  | 7.0 |  |
| Valuation allowance on state and foreign deferred tax |  | (4.4) |  |  | (4.1) |  |
| Other items |  | — |  |  | 0.1 |  |
| Total deferred tax assets |  | 78.9 |  |  | 63.4 |  |
| Deferred tax liabilities: |  |  |  |  |
| Accelerated depreciation on fixed assets |  | 15.6 |  |  | 17.7 |  |
| Amortization of intangibles |  | 49.2 |  |  | 51.3 |  |
| Lease right-of-use asset, net |  | 15.7 |  |  | 14.7 |  |
| Other items |  | 0.4 |  |  | 0.4 |  |
| Total deferred tax liabilities |  | 80.9 |  |  | 84.1 |  |
| Net deferred tax liabilities |  | $ | (2.0) |  |  | $ | (20.7) |  |

[0000038725-25-000026:notes:178]
The Company assesses the available positive and negative evidence to estimate whether sufficient future taxable income will be generated to permit use of the existing deferred tax assets. A significant piece of objective negative evidence evaluated was the cumulative loss for certain U.S. state and foreign income tax purposes incurred over the 3-year period ended December 31, 2024. Such objective evidence limits the ability to consider other subjective evidence, such as the Company's projections for future growth.

[0000038725-25-000026:notes:179]
On the basis of this evaluation, as of December 31, 2024, a valuation allowance of $4.4 million has been recorded to recognize only the portion of the deferred tax asset that is more likely than not to be realized. The Company has foreign income tax net operating loss (“NOL”) and credit carryforwards of $8.1 million and U.S. state income tax credit carryforwards of $3.7 million, which will expire on various dates as follows:

[0000038725-25-000026:notes:180]
| (In millions) |  |
| 2025-2029 | $ | 4.8 |  |
| 2030-2034 | 0.4 |  |
| 2035-2039 | 0.5 |  |
| Unlimited | 6.1 |  |
|  | $ | 11.8 |  |

[0000038725-25-000026:notes:181]
The Company believes that it is more likely than not that the benefit from certain foreign NOL carryforwards as well as certain U.S. state credit carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance of $3.2 million on the deferred tax assets related to these foreign NOL carryforwards and a valuation allowance of $1.2 million on the deferred tax assets related to these U.S. state credit carryforwards.

[0000038725-25-000026:notes:182]
As of December 31, 2024, the Company has estimated accumulated undistributed earnings generated by the Company's foreign subsidiaries of approximately $542.4 million. Any taxes due with respect to such earnings or the excess of the amount for financial reporting over the tax basis of its foreign investments would generally be limited to foreign and U.S. state taxes. The Company intends, however, to indefinitely reinvest these earnings and expects future U.S. cash generation to be sufficient to meet future U.S. cash needs. The Company, therefore, has not recorded a deferred tax liability of approximately $4.4 million.

[0000038725-25-000026:notes:183]
As of the beginning of 2024, the Company had gross unrecognized tax benefits of $0.8 million, excluding accrued interest and penalties. The unrecognized tax benefits increased due to uncertain tax positions identified for the current and prior years based on evaluations made during 2024, which were offset by statute expirations. The Company had gross unrecognized tax benefits, excluding accrued interest and penalties, of $1.3 million as of December 31, 2024.

[0000038725-25-000026:notes:184]
A reconciliation of the beginning and ending amount of gross unrecognized tax benefits for 2024, 2023, and 2022 (excluding interest and penalties) is as follows:

[0000038725-25-000026:notes:185]
| (In millions) |  | 2024 |  | 2023 |  | 2022 |
| Beginning balance |  | $ | 0.8 |  |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Additions for tax positions of the current year |  | 0.6 |  |  | 0.3 |  |  | 0.1 |  |
| Additions for tax positions of prior years |  | 0.2 |  |  | — |  |  | — |  |
| Reductions for tax positions of prior years |  | — |  |  | — |  |  | — |  |
| Statute expirations |  | (0.3) |  |  | (0.4) |  |  | (0.1) |  |
| Settlements |  | — |  |  | — |  |  | — |  |
| Ending balance |  | $ | 1.3 |  |  | $ | 0.8 |  |  | $ | 0.9 |  |

[0000038725-25-000026:notes:186]
If recognized, each annual effective tax rate would be affected by the net unrecognized tax benefits of $1.3 million, $0.8 million, and $0.9 million as of year-end 2024, 2023, and 2022, respectively.

[0000038725-25-000026:notes:187]
The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense. The Company has accrued interest and penalties as of December 31, 2024, December 31, 2023, and December 31, 2022 of approximately $0.1 million, $0.1 million, and $0.2 million, respectively.

[0000038725-25-000026:notes:188]
The Company is subject to taxation in the United States and various U.S. state and foreign jurisdictions. With few exceptions, as of  December 31, 2024, the Company is no longer subject to U.S. federal income tax examinations by tax authorities for years before 2021 and is no longer subject to foreign or U.S. state income tax examinations by tax authorities for years before 2019.
It is reasonably possible that the amounts of unrecognized tax benefits could change in the next twelve months as a result of an audit or due to the expiration of a statute of limitation. Based on the current audits in process and pending statute expirations, the payment of taxes as a result could be up to $0.1 million.


## us-gaap:EarningsPerShareTextBlock

[0000038725-25-000026:notes:189]
EARNINGS PER SHARE
The Company calculates basic and diluted earnings per common share using the two-class method. Under the two-class method, net earnings are allocated to each class of common stock and participating security as if all of the net earnings for the period had been distributed. The Company’s participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.

[0000038725-25-000026:notes:190]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period. Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-25-000026:notes:191]
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-25-000026:notes:192]
| (In millions, except per share amounts) |  | 2024 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. |  | $ | 180.3 |  |  | $ | 193.3 |  |  | $ | 187.3 |  |
| Less: Earnings allocated to participating securities |  | 0.7 |  |  | 0.7 |  |  | 0.7 |  |
| Net income available to common shareholders |  | $ | 179.6 |  |  | $ | 192.6 |  |  | $ | 186.6 |  |
| Denominator: |  |  |  |  |  |  |
| Basic weighted average common shares outstanding |  | 45.9 |  |  | 46.2 |  |  | 46.3 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors |  | 0.6 |  |  | 0.7 |  |  | 0.7 |  |
| Diluted weighted average common shares outstanding |  | 46.5 |  |  | 46.9 |  |  | 47.0 |  |
| Basic earnings per share |  | $ | 3.92 |  |  | $ | 4.17 |  |  | $ | 4.02 |  |
| Diluted earnings per share |  | $ | 3.86 |  |  | $ | 4.11 |  |  | $ | 3.97 |  |

[0000038725-25-000026:notes:193]
There were 0.1 million stock options outstanding as of 2024, 2023, and 2022, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-25-000026:notes:194]
FINANCIAL INSTRUMENTS
The Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (“the swap”) to mitigate the Company’s exposure to these fluctuations in the Company’s stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party. As of December 31, 2024 and December 31, 2023, the swap had a notional value based on 250,000 shares and 240,000 shares, respectively. For the years ended December 31, 2024, December 31, 2023, and December 31, 2022, the swap resulted in a loss of $1.3 million, a gain of $2.5 million, and a loss of $3.4 million, respectively. Gains and losses resulting from the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the deferred compensation stock liability and the swap are recorded in the Company’s consolidated statements of income within the “Selling, general, and administrative expenses” line.
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of December 31, 2024 and December 31, 2023, the Company had no foreign currency contracts outstanding. For the years ended December 31, 2024, December 31, 2023, and December 31, 2022, the forward currency contracts resulted in a loss of $0.2 million, a gain of $1.6 million, and a gain of $1.2 million, respectively. This is recorded in the Company's consolidated statements of income within the "Foreign exchange expense" line.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-25-000026:notes:195]
FAIR VALUE MEASUREMENTS
As of December 31, 2024 and December 31, 2023, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-25-000026:notes:196]
| (In millions) |  | December 31, 2024 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 5.0 |  |  | $ | 5.0 |  |  | $ | — |  |  | $ | — |  |
| Total assets |  | $ | 5.0 |  |  | $ | 5.0 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Share swap transaction |  | $ | 2.5 |  |  | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |
| Contingent payments related to acquisition |  | 5.0 |  |  | — |  |  | — |  |  | 5.0 |  |
| Total liabilities |  | $ | 7.5 |  |  | $ | 2.5 |  |  | $ | — |  |  | $ | 5.0 |  |
|  |  | December 31, 2023 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 10.9 |  |  | $ | 10.9 |  |  | $ | — |  |  | $ | — |  |
| Share swap transaction |  | 1.1 |  |  | 1.1 |  |  | — |  |  | — |  |
| Total assets |  | $ | 12.0 |  |  | $ | 12.0 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Contingent payments related to acquisition |  | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Total liabilities |  | $ | 3.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 3.0 |  |

[0000038725-25-000026:notes:197]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The share swap transaction is recorded within the "Accounts Payable" and "Receivables" lines of the consolidated balance sheets and is further described in Note 13 - Financial Instruments.

[0000038725-25-000026:notes:198]
The Company has no assets measured on a recurring basis classified as Level 2 excluding the recurring fair value measurements in the Company's pension and other retirement plans as discussed in Note 10 - Employee Benefit Plans.

[0000038725-25-000026:notes:199]
The Company's Level 3 category includes contingent consideration related to acquisitions, which valuation inputs are unobservable and significant to the fair value measurement.  Projections and estimated probabilities are used to estimate future contingent earn-out payments, which are discounted back to present value to compute contingent earn-out liabilities. The following table provides a roll-forward of the contingent consideration liability, which is included in "Accrued expenses and other liabilities" as of December 31, 2024 and "Other long-term liabilities" as of December 31, 2023 in the consolidated balance sheets:

[0000038725-25-000026:notes:200]
| (In millions) | 2024 |  | 2023 |
| Fair value at beginning of period | $ | 3.0 |  |  | $ | — |  |
| Additions | — |  |  | 3.0 |  |
| Adjustment to prior year acquisition | 1.3 |  |  | — |  |
| Change in fair value recognized in earnings | 0.7 |  |  | — |  |
| Payments | — |  |  | — |  |
| Fair value at end of period | $ | 5.0 |  |  | 3.0 |  |

[0000038725-25-000026:notes:201]
Total debt, including current maturities, have carrying amounts of $129.4 million as of December 31, 2024 and $100.5 million at December 31, 2023. The estimated fair value of all debt was $128.0 million and $98.6 million as of December 31, 2024 and 
December 31, 2023, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-25-000026:notes:202]
SEGMENT AND GEOGRAPHIC INFORMATION
The Company’s business consists of the Water Systems, Distribution, and Energy Systems reportable segments, based on the principal end market served. The Company changed the name of the Fueling Systems segment to Energy Systems to reflect its diverse portfolio and growth strategy, as well as to better reflect the markets and customers served by the segment. The Company includes unallocated corporate expenses and intercompany eliminations that are not part of a reportable segment in its reconciliations to consolidated results.

[0000038725-25-000026:notes:203]
The Water Systems segment designs, manufactures and sells motors, pumps, electronic controls, water treatment systems and related parts and equipment primarily for use in submersible water or other fluid system applications. The Energy Systems segment designs, manufactures and sells pumps, electronic controls and related parts and equipment primarily for use in submersible fueling system applications. The Energy Systems segment integrates and sells motors and electronic controls produced by the Water Systems segment. The Company reports these product transfers between Water Systems and Energy Systems as inventory transfers since a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes. The Distribution segment sells to and provides presale support and specifications to the installing contractors. The Distribution segment sells products produced by the Water Systems segment. The Company reports intersegment transfers from Water Systems to Distribution as intersegment sales at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water Systems and Distribution segments.

[0000038725-25-000026:notes:204]
The accounting policies of the Company’s reportable segments are the same as those described in Note 1 - Summary of Significant Accounting Policies. The Company's chief operating decision maker is its Chief Executive Officer. Performance is evaluated based on the sales and operating income of the segments. Operating income and margin are used to evaluate income generated from segment assets in deciding whether to reinvest profits into each segment or other parts of the entity.  Operating income is also used to monitor budget versus actual results, for purposes of determining portions of management compensation and for benchmarking against similar measures used by peers and competitors. These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented as corporate expenses are not allocated to segments. Interest expense, other income (expense), net, foreign exchange expense and income tax expense are also not allocated to each segment.

[0000038725-25-000026:notes:205]
Financial information by reportable business segment is included in the following summary:

[0000038725-25-000026:notes:206]
| 2024 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 1,062.1 |  |  | $ | 685.5 |  |  | $ | 273.7 |  |  | $ | 2,021.3 |  |
| Intersegment sales | 121.9 |  |  | — |  |  | — |  |  | 121.9 |  |
|  | $ | 1,184.0 |  |  | $ | 685.5 |  |  | $ | 273.7 |  |  | $ | 2,143.2 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (121.9) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 2,021.3 |  |
| Cost of sales | $ | 782.0 |  |  | $ | 505.9 |  |  | $ | 137.6 |  |  |  |
| Selling, general and administrative expenses | 201.7 |  |  | 154.6 |  |  | 42.1 |  |  |  |
| Restructuring expense | 2.4 |  |  | 0.7 |  |  | 0.4 |  |  |  |
| Segment operating income | $ | 197.9 |  |  | $ | 24.3 |  |  | $ | 93.6 |  |  | $ | 315.8 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | (0.5) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (71.7) |  |
| Interest expense |  |  |  |  |  |  | (6.3) |  |
| Other income/(expense), net |  |  |  |  |  |  | 1.3 |  |
| Foreign exchange expense |  |  |  |  |  |  | (6.8) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 231.8 |  |

[0000038725-25-000026:notes:207]
| 2023 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 1,095.3 |  |  | $ | 673.3 |  |  | $ | 296.5 |  |  | $ | 2,065.1 |  |
| Intersegment sales | 108.4 |  |  | — |  |  | — |  |  | 108.4 |  |
|  | $ | 1,203.7 |  |  | $ | 673.3 |  |  | $ | 296.5 |  |  | $ | 2,173.5 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (108.4) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 2,065.1 |  |
| Cost of sales | $ | 819.3 |  |  | $ | 497.4 |  |  | $ | 162.0 |  |  |  |
| Selling, general and administrative expenses | 187.3 |  |  | 141.6 |  |  | 41.2 |  |  |  |
| Restructuring expense | 0.5 |  |  | — |  |  | 0.6 |  |  |  |
| Segment operating income | $ | 196.6 |  |  | $ | 34.3 |  |  | $ | 92.7 |  |  | $ | 323.6 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | 2.2 |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (63.4) |  |
| Interest expense |  |  |  |  |  |  | (11.8) |  |
| Other income/(expense), net |  |  |  |  |  |  | 3.7 |  |
| Foreign exchange expense |  |  |  |  |  |  | (12.1) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 242.2 |  |

[0000038725-25-000026:notes:208]
| 2022 | Water Systems |  | Distribution |  | Energy Systems |  | Consolidated |
| (In millions) |
| External sales | $ | 1,041.5 |  |  | $ | 668.1 |  |  | $ | 334.1 |  |  | $ | 2,043.7 |  |
| Intersegment sales | 116.0 |  |  | — |  |  | — |  |  | 116.0 |  |
|  | $ | 1,157.5 |  |  | $ | 668.1 |  |  | $ | 334.1 |  |  | $ | 2,159.7 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (116.0) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 2,043.7 |  |
| Cost of sales | $ | 801.8 |  |  | 471.6 |  | $ | 191.0 |  |  |  |
| Selling, general and administrative expenses | 182.1 |  |  | 141.8 |  |  | 45.7 |  |  |  |
| Restructuring expense | 1.4 |  |  | 0.2 |  |  | 0.6 |  |  |  |
| Segment operating income | $ | 172.2 |  |  | $ | 54.5 |  |  | $ | 96.8 |  |  | $ | 323.5 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | (3.9) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (62.5) |  |
| Interest expense |  |  |  |  |  |  | (11.5) |  |
| Other income/(expense), net |  |  |  |  |  |  | (3.2) |  |
| Foreign exchange expense |  |  |  |  |  |  | (7.2) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 235.2 |  |

[0000038725-25-000026:notes:209]
| (In millions) | 2024 |  | 2023 |  | 2022 |
| Depreciation and amortization |  |  |  |  |  |
| Water Systems | $ | 39.0 |  |  | $ | 36.9 |  |  | $ | 35.2 |  |
| Distribution | 9.6 |  | 7.6 |  | 6.9 |
| Energy Systems | 4.3 |  | 4.2 |  | 4.2 |
| Total segment depreciation and amortization | $ | 52.9 |  |  | $ | 48.7 |  |  | $ | 46.3 |  |
| Corporate | 3.2 |  | 3.6 |  | 4.1 |
| Total depreciation and amortization | $ | 56.1 |  |  | $ | 52.3 |  |  | $ | 50.4 |  |
| Capital Expenditures |  |  |  |  |  |
| Water Systems | $ | 27.8 |  |  | $ | 28.6 |  |  | $ | 23.4 |  |
| Distribution | 9.3 |  | 9.3 |  | 13.4 |
| Energy Systems | 2.3 |  | 3.0 |  | 2.7 |
| Total segment capital expenditure | $ | 39.4 |  |  | $ | 40.9 |  |  | $ | 39.5 |  |
| Corporate | 1.8 |  | 2.3 |  | 1.6 |
| Total capital expenditure | $ | 41.2 |  |  | $ | 43.2 |  |  | $ | 41.1 |  |
| Assets |  |  |  |  |  |
| Water Systems | $ | 998.8 |  |  | $ | 1,044.4 |  |  | $ | 1,017.5 |  |
| Distribution | 358.9 |  | 365.6 |  | 360.4 |
| Energy Systems | 250.4 |  | 256.4 |  | 269.1 |
| Total segment assets | $ | 1,608.1 |  |  | $ | 1,666.4 |  |  | $ | 1,647.0 |  |
| Corporate | 212.5 |  | 61.7 |  | 47.2 |
| Total assets | $ | 1,820.6 |  |  | $ | 1,728.1 |  |  | $ | 1,694.2 |  |

[0000038725-25-000026:notes:210]
Cash and property, plant and equipment are the major asset groups in “Corporate” of total assets for the years ended December 31, 2024 and December 31, 2023.

[0000038725-25-000026:notes:211]
Financial information by geographic region is as follows:

[0000038725-25-000026:notes:212]
|  | Net sales |  | Long-lived assets |
| (In millions) | 2024 |  | 2023 |  | 2022 |  | 2024 |  | 2023 |  | 2022 |
| United States | $ | 1,400.4 |  |  | $ | 1,441.6 |  |  | $ | 1,414.1 |  |  | $ | 626.6 |  |  | $ | 625.3 |  |  | $ | 601.7 |  |
| Foreign | 620.9 |  |  | 623.5 |  |  | 629.6 |  |  | 221.6 |  |  | 240.3 |  |  | 227.6 |  |
| Consolidated | $ | 2,021.3 |  |  | $ | 2,065.1 |  |  | $ | 2,043.7 |  |  | $ | 848.2 |  |  | $ | 865.6 |  |  | $ | 829.3 |  |

[0000038725-25-000026:notes:213]
Net sales are attributed to geographic regions based upon the ship to location of the customer. Long-lived assets are attributed to geographic regions based upon the country of domicile.

[0000038725-25-000026:notes:214]
The Company offers a large array of products and systems to multiple markets and customers. Product sales information is tracked regionally and products are categorized differently between regions based on local needs and reporting requirements. However, net sales by segment are representative of the Company’s sales by major product category. The Company sells its products through various distribution channels including wholesale and retail distributors, specialty distributors, industrial and petroleum equipment distributors, as well as major oil and utility companies and original equipment manufacturers.

[0000038725-25-000026:notes:215]
No single customer accounted for more than 10 percent of the Company’s net sales in 2024, 2023, or 2022. No single customer accounted for more than 10 percent of the Company’s gross accounts receivable in 2024 or 2023.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000038725-25-000026:notes:216]
None of the Company’s directors or officers adopted, modified, or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement during the Company’s fiscal quarter ended December 31, 2024.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000038725-25-000026:notes:217]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000038725-25-000026:notes:218]
| (In millions) |  | Balance at Beginning of Period |  | Charged to Costs and Expenses |  | Deductions (a) |  | Other (b) |  | Balance at End of Period |
| 2024 |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 3.6 |  |  | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | — |  |  | $ | 3.5 |  |
| Allowance for deferred taxes |  | 4.1 |  |  | 0.7 |  |  | 0.4 |  |  | — |  |  | 4.4 |  |
| 2023 |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 4.2 |  |  | $ | (0.3) |  |  | $ | 0.4 |  |  | $ | 0.1 |  |  | $ | 3.6 |  |
| Allowance for deferred taxes |  | 4.9 |  |  | — |  |  | 0.8 |  |  | — |  |  | 4.1 |  |
| 2022 |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 4.0 |  |  | $ | 0.1 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | 4.2 |  |
| Allowance for deferred taxes |  | 6.5 |  |  | 0.4 |  |  | 2.0 |  |  | — |  |  | 4.9 |  |

[0000038725-25-000026:notes:219]
(a) Charges for which allowances were created.

[0000038725-25-000026:notes:220]
(b) Primarily related to acquisitions
