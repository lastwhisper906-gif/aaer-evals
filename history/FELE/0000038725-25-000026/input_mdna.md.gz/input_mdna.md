# FELE MD&A — 0000038725-25-000026


## mdna

[0000038725-25-000026:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-25-000026:mdna:2]
Discussion of the year-over-year comparison of changes in the Company's financial condition and results of operation as of and for the fiscal years ended December 31, 2023 and December 31, 2022 can be found in Part II, Item 7. "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our Annual Report on Form 10-K for the fiscal year ended December 31, 2023.

[0000038725-25-000026:mdna:3]
2024 vs. 2023

[0000038725-25-000026:mdna:4]
OVERVIEW

[0000038725-25-000026:mdna:5]
Net sales in 2024 decreased 2 percent compared to the prior year.  The sales decrease in 2024 was primarily due to lower volumes and the negative impact of foreign currency translation, partially offset by the incremental sales impact from recent acquisitions. The Company's consolidated gross profit was $717.3 million for 2024, an increase of $20.3 million from the prior year. Diluted earnings per share was $3.86 for 2024, a decrease of $0.25 or 6 percent from the prior year.

[0000038725-25-000026:mdna:6]
RESULTS OF OPERATIONS

[0000038725-25-000026:mdna:7]
Net Sales

[0000038725-25-000026:mdna:8]
Net sales in 2024 were $2.0 billion and decreased 2 percent compared to the prior year. Sales were negatively impacted by changes in foreign exchange rates, principally due to the strengthening of the U.S. Dollar relative to the Argentine Peso, Turkish Lira and Brazilian Real. However, the Company increases prices in the local currency to offset the impact of currency devaluation in the Argentina and Turkey highly inflationary economies. As a result, the net negative impact of foreign currency exchange rates on net sales was 1 percent in 2024.

[0000038725-25-000026:mdna:9]
|  | Net Sales |
| (In millions) | 2024 |  | 2023 |  | 2024 v 2023 |
| Water Systems | $ | 1,184.0 |  |  | $ | 1,203.7 |  |  | $ | (19.7) |  |
| Energy Systems | 273.7 |  |  | 296.5 |  |  | (22.8) |  |
| Distribution | 685.5 |  |  | 673.3 |  |  | 12.2 |  |
| Eliminations | (121.9) |  |  | (108.4) |  |  | (13.5) |  |
| Consolidated | $ | 2,021.3 |  |  | $ | 2,065.1 |  |  | $ | (43.8) |  |

[0000038725-25-000026:mdna:10]
Net Sales-Water Systems

[0000038725-25-000026:mdna:11]
Water Systems net sales decreased 2 percent in 2024, as compared to the prior year. This sales decline was primarily due to lower volumes, which decreased due to weaker end market demand for large dewatering equipment. Additionally, net sales decreased 2 percent in 2024 due to the negative impact from foreign exchange rates, as compared to prior year while the incremental sales impact from recent acquisitions favorably impacted sales 1 percent in 2024.

[0000038725-25-000026:mdna:12]
Water Systems net sales in the U.S. and Canada decreased 5 percent in 2024, as compared to the prior year. In 2024, sales of large dewatering equipment decreased 41 percent, sales of water treatment products increased 11 percent, sales of groundwater pumping equipment increased 4 percent and sales of all other surface pumping equipment increased 5 percent compared to 2023.

[0000038725-25-000026:mdna:13]
Water Systems net sales in markets outside the U.S. and Canada increased 4 percent in 2024, as compared to the prior year. Sales decreased 4 percent in 2024 due to the negative impact from foreign exchange rates, as compared to prior year.  In 2024 excluding the impact of foreign currency translation, sales increased in all three major regions: EMEA, Latin America and Asia Pacific.

[0000038725-25-000026:mdna:14]
Net Sales-Energy Systems

[0000038725-25-000026:mdna:15]
Energy Systems net sales decreased 8 percent in 2024, as compared to the prior year. This sales decline was primarily due to lower volumes.

[0000038725-25-000026:mdna:16]
Energy Systems net sales in the U.S. and Canada decreased 3 percent in 2024, as compared to the prior year. Outside the U.S. and Canada, Energy Systems sales decreased 18 percent in 2024, as compared to the prior year. The decreases were across all product lines.

[0000038725-25-000026:mdna:17]
Net Sales-Distribution

[0000038725-25-000026:mdna:18]
Distribution net sales increased 2 percent in 2024, as compared to the prior year. The Distribution segment sales increase was primarily due to the incremental sales impact from a recent acquisition, which favorably impacted net sales by 3 percent, partially offset by the negative impact of commodity pricing declines and unfavorable weather.

[0000038725-25-000026:mdna:19]
Gross Profit and Expense Ratios

[0000038725-25-000026:mdna:20]
|  | Fiscal Year |
| (In Millions) | 2024 |  | % of Net Sales |  | 2023 |  | % of Net Sales |
| Gross Profit | $ | 717.3 |  |  | 35.5 | % |  | $ | 697.0 |  |  | 33.8 | % |
| Selling, General and Administrative Expense | 470.1 |  |  | 23.3 | % |  | 433.5 |  |  | 21.0 | % |

[0000038725-25-000026:mdna:21]
Gross Profit

[0000038725-25-000026:mdna:22]
The gross profit margin ratio was 35.5 percent and 33.8 percent in 2024 and 2023, respectively. The gross profit margin was favorably impacted in 2024 by cost management, including lower freight costs in Water Systems and Energy Systems, and a favorable product and geographic sales mix shift.

[0000038725-25-000026:mdna:23]
Selling, General and Administrative (“SG&A”)

[0000038725-25-000026:mdna:24]
SG&A expenses were $470.1 million in 2024 compared to $433.5 million in 2023. SG&A expenses increased in 2024 primarily due to higher employee compensation costs, including incremental expenses associated with the Company's CEO transition, and the incremental expense impact of recent acquisitions. The SG&A expenses ratio was 23.3 percent and 21.0 percent in 2024 and 2023, respectively.

[0000038725-25-000026:mdna:25]
Restructuring Expenses

[0000038725-25-000026:mdna:26]
Restructuring expenses were $3.5 million and $1.1 million in 2024 and 2023, respectively. Restructuring actions in 2024 were primarily related to headcount reductions and facility closures to optimize the Company's cost structure. Restructuring expenses in 2023 were primarily from continued miscellaneous manufacturing realignment activities, branch closings and consolidations.

[0000038725-25-000026:mdna:27]
Operating Income

[0000038725-25-000026:mdna:28]
Operating income decreased 7 percent in 2024, as compared to the prior year.

[0000038725-25-000026:mdna:29]
|  |  | Operating income (loss) |
| (In millions) |  | 2024 |  | 2023 |  | 2024 v 2023 |
| Water Systems |  | $ | 197.9 |  |  | $ | 196.6 |  |  | $ | 1.3 |  |
| Energy Systems |  | 93.6 |  |  | 92.7 |  |  | 0.9 |  |
| Distribution |  | 24.3 |  |  | 34.3 |  |  | (10.0) |  |
| Corporate Expenses and Eliminations |  | (72.2) |  |  | (61.2) |  |  | (11.0) |  |
| Consolidated |  | $ | 243.6 |  |  | $ | 262.4 |  |  | $ | (18.8) |  |

[0000038725-25-000026:mdna:30]
Operating Income-Water Systems

[0000038725-25-000026:mdna:31]
Water Systems operating income in 2024 was $197.9 million, an increase of $1.3 million as compared to the prior year. The 2024 operating income margin was 16.7 percent, an increase of 40 basis points from 16.3 percent in 2023. Operating income and operating margin increased in 2024 primarily due to price realization, cost management and a favorable product and geographic sales mix shift.

[0000038725-25-000026:mdna:32]
Operating Income-Energy Systems

[0000038725-25-000026:mdna:33]
Energy Systems operating income in 2024 was $93.6 million, an increase of $0.9 million as compared to the prior year. The 2024 operating income margin was 34.2 percent, an increase of 290 basis points from 31.3 percent in 2023. Operating income and operating margin increased primarily due to a favorable geographic mix of sales, price realization and cost management.

[0000038725-25-000026:mdna:34]
Operating Income-Distribution

[0000038725-25-000026:mdna:35]
Distribution operating income in 2024 was $24.3 million, a decrease of $10.0 million as compared to the prior-year period. The 2024 operating income margin was 3.5 percent, a decrease of 160 basis points from 5.1 percent in 2023. Operating income and operating income margin decreased in 2024 primarily due to the negative impact on sales from wet weather across much of the United States, decreases in pricing of commodity-based products sold through the business and increased SG&A costs.

[0000038725-25-000026:mdna:36]
Operating Income-Corporate Expenses and Eliminations

[0000038725-25-000026:mdna:37]
Operating income-corporate expenses and eliminations is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in 2024 compared to 2023 was an unfavorable $2.7 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses increased $8.3 million, compared to the prior year. The increase was primarily driven by to higher employee compensation costs, including incremental expenses associated with the Company’s CEO transition.

[0000038725-25-000026:mdna:38]
Interest Expense

[0000038725-25-000026:mdna:39]
Interest expense was $6.3 million in 2024 and $11.8 million in 2023, respectively. The decrease in 2024 was primarily driven by lower average borrowings in 2024.

[0000038725-25-000026:mdna:40]
Other Income or Expense

[0000038725-25-000026:mdna:41]
Other income (expense), net was a benefit of $1.3 million in 2024 and $3.7 million in 2023. The benefit in 2024 was lower than 2023 due to lower interest income realized in Argentina as excess cash balances and interest rates have declined in 2024 compared to 2023.

[0000038725-25-000026:mdna:42]
Foreign Exchange

[0000038725-25-000026:mdna:43]
Foreign currency-based transactions produced an expense of $6.8 million in 2024 and $12.1 million in 2023, respectively. The expense in 2024 and 2023 was primarily due to transaction losses associated with the Turkish Lira and Argentine Peso relative to the U.S. dollar. The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-25-000026:mdna:44]
Income Taxes

[0000038725-25-000026:mdna:45]
The provision for income taxes in 2024 and 2023 were $50.2 million and $47.5 million, respectively. The effective tax rate for 2024 was about 22 percent and included a favorable benefit from discrete events of 1 percent. The effective tax rate for 2023 was about 20 percent and included a favorable benefit from discrete events of 1 percent. The effective tax rate differs from the U.S. statutory rate of 21 percent, primarily due to U.S. states taxes, foreign earnings taxed at rates higher than the U.S. statutory rate, and nondeductible officer’s compensation, partially offset by the recognition of the U.S. foreign-derived intangible income (FDII) provisions, certain incentives, and discrete events.

[0000038725-25-000026:mdna:46]
Net Income

[0000038725-25-000026:mdna:47]
Net income for 2024 was $181.6 million compared to 2023 net income of $194.7 million. Net income attributable to Franklin Electric Co., Inc. for 2024 was $180.3 million, or $3.86 per diluted share, compared to 2023 net income attributable to Franklin Electric Co., Inc. of $193.3 million, or $4.11 per diluted share.

[0000038725-25-000026:mdna:48]
CAPITAL RESOURCES AND LIQUIDITY

[0000038725-25-000026:mdna:49]
Sources of Liquidity

[0000038725-25-000026:mdna:50]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at December 31, 2024 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-25-000026:mdna:51]
As of December 31, 2024, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of December 31, 2024, the Company had $304.1 million borrowing capacity under the Credit Agreement as $4.5 million in letters of commercial and standby letters of credit were outstanding and undrawn and $41.4 million in revolver borrowings were drawn or outstanding.

[0000038725-25-000026:mdna:52]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $200.0 million. As of December 31, 2024, the remaining borrowing capacity on the New York Life Agreement was $175.0 million. The Company also maintains an uncommitted and unsecured note purchase and private shelf agreement with PGIM, Inc. and its affiliates (the "Prudential Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million. The maturity dates of both agreements were extended from July 30, 2024 to May 15, 2027.

[0000038725-25-000026:mdna:53]
At December 31, 2024, the Company had $47.1 million of cash and cash equivalents held in foreign jurisdictions, which the Company intends to use to fund foreign operations. There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-25-000026:mdna:54]
Cash Flows

[0000038725-25-000026:mdna:55]
The following table summarizes significant sources and uses of cash and cash equivalents:

[0000038725-25-000026:mdna:56]
| (in millions) | 2024 |  | 2023 |
| Cash flows from operating activities | $ | 261.4 |  |  | $ | 315.7 |  |
| Cash flows from investing activities | $ | (45.6) |  |  | $ | (74.3) |  |
| Cash flows from financing activities | $ | (74.1) |  |  | $ | (192.2) |  |
| Impact of exchange rates on cash and cash equivalents | $ | (6.1) |  |  | $ | (10.0) |  |
| Change in cash and cash equivalents | $ | 135.6 |  |  | $ | 39.2 |  |

[0000038725-25-000026:mdna:57]
Cash Flows from Operating Activities

[0000038725-25-000026:mdna:58]
2024 vs 2023

[0000038725-25-000026:mdna:59]
Net cash provided by operating activities was $261.4 million for 2024 compared to $315.7 million for 2023. The change in operating cash flow was primarily attributable to changes in working capital and lower earnings. In 2023, the Company's cash flow benefited from actions it took to improve working capital including inventory reductions as its supply chain resiliency and lead times improved significantly compared to 2022.

[0000038725-25-000026:mdna:60]
Cash Flows from Investing Activities

[0000038725-25-000026:mdna:61]
2024 vs. 2023

[0000038725-25-000026:mdna:62]
Net cash used in investing activities was $45.6 million in 2024 compared to $74.3 million in 2023. The change in investing cash flow was primarily attributable to decreased acquisition activity in 2024.

[0000038725-25-000026:mdna:63]
In February 2025, the Company acquired 100 percent of the ownership interests of PumpEng for a purchase price of AUD 24.0 million (approximately $15 million), subject to working capital and net debt closing adjustments. Also in February 2025, the Company signed a definitive agreement to acquire Barnes for an enterprise value of $110.0 million, subject to working capital and net debt closing adjustments. The acquisition is subject to customary closing conditions, including Colombian antitrust clearance, and is expected to close on or about March 1, 2025.

[0000038725-25-000026:mdna:64]
Cash Flows from Financing Activities

[0000038725-25-000026:mdna:65]
2024 vs. 2023

[0000038725-25-000026:mdna:66]
Net cash used by financing activities was $74.1 million in 2024 compared to $192.2 million in 2023. The change in financing cash flow was primarily due to net borrowings under the Company's credit facility in 2024 compared to net repayments in 2023, partially offset by lower proceeds from option exercises, increased share repurchase activity and higher dividends.

[0000038725-25-000026:mdna:67]
AGGREGATE CONTRACTUAL OBLIGATIONS

[0000038725-25-000026:mdna:68]
The majority of the Company’s contractual obligations to third parties relate to debt obligations. In addition, the Company has certain contractual obligations for future lease payments and purchase obligations. The payment schedule for these contractual obligations is as follows:

[0000038725-25-000026:mdna:69]
| (In millions) |  |  |  |  |  |  |  |  | More than |
|  | Total |  | 2025 |  | 2026-2027 |  | 2028-2029 |  | 5 years |
| Debt | $ | 129.5 |  |  | $ | 117.8 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |  | $ | 5.8 |  |
| Debt interest | 9.4 |  |  | 7.5 |  |  | 1.0 |  |  | 0.5 |  |  | 0.4 |  |
| Operating leases | 73.5 |  |  | 22.7 |  |  | 30.2 |  |  | 13.9 |  |  | 6.7 |  |
| Purchase obligations | 12.6 |  |  | 12.6 |  |  | — |  |  | — |  |  | — |  |
| Income Taxes-U.S. Tax Cuts and Jobs Act transition tax | $ | 4.8 |  |  | $ | 4.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
|  | $ | 229.8 |  |  | $ | 165.4 |  |  | $ | 34.2 |  |  | $ | 17.3 |  |  | $ | 12.9 |  |

[0000038725-25-000026:mdna:70]
Interest payments on debt obligations are calculated for future periods using interest rates in effect at the end of 2024. Certain of these projected interest payments may differ in the future based on interest rates or other factors or events. The projected interest payments only pertain to obligations and agreements outstanding at December 31, 2024.

[0000038725-25-000026:mdna:71]
The Company has pension and other post-retirement benefit obligations not included in the table above which will result in estimated future payments of approximately $7.3 million in 2025. In addition, due to the timing of funding in future periods being uncertain and dependent on future movements in interest rates, investment returns, changes in laws and regulations and other variables, the table above excludes the non-current liability of $24.1 million for cash outflows related to the Company's pension plans.

[0000038725-25-000026:mdna:72]
The Company also has unrecognized tax benefits, none of which are included in the table above. The unrecognized tax benefits of approximately $1.3 million have been recorded as liabilities and the Company is uncertain as to if or when such amounts may be settled. Related to the unrecognized tax benefits, the Company has also recorded a liability for potential penalties and interest of $0.1 million.

[0000038725-25-000026:mdna:73]
ACCOUNTING PRONOUNCEMENTS

[0000038725-25-000026:mdna:74]
For information regarding recent accounting pronouncements, refer to Note 2 - Accounting Pronouncements, in the Notes to Consolidated Financial Statements in the sections entitled ""Adoption of New Accounting Standards" and "Accounting Standards Issued But Not Yet Adopted", included in Part II, Item 8, "Financial Statements and Supplementary Data" of this Annual Report on Form 10-K.

[0000038725-25-000026:mdna:75]
CRITICAL ACCOUNTING ESTIMATES

[0000038725-25-000026:mdna:76]
Management’s discussion and analysis of its financial condition and results of operations are based upon the Company’s consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires management to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and the related disclosure of contingent assets and liabilities. Management evaluates estimates on an ongoing basis. Estimates are based on historical experience and on other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. There were no material changes to estimates or methodologies used to develop those estimates in 2024. The Company’s critical accounting estimates are identified below:

[0000038725-25-000026:mdna:77]
Inventory Valuation

[0000038725-25-000026:mdna:78]
The Company uses certain estimates and judgments to value inventory. Inventory is recorded at the lower of cost or net realizable value. The Company reviews its inventories for excess or obsolete products or components. Based on an analysis of historical usage, management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts, carrying values are adjusted. The carrying value is reduced regularly to reflect the age and current anticipated product demand. If actual demand differs from the estimates, additional reductions would be necessary in the period such determination is made. Excess and obsolete inventory is periodically disposed of through sale to third parties, scrapping, or other means.

[0000038725-25-000026:mdna:79]
Business Combinations and Valuation of Acquired Intangible Assets

[0000038725-25-000026:mdna:80]
The Company follows the guidance under FASB ASC Topic 805, Business Combinations. The acquisition purchase price is allocated to the assets acquired and liabilities assumed based upon their respective fair values. The Company utilizes management estimates and may use an independent third-party valuation firm to assist in determining the fair values of assets acquired, including intangible assets, and liabilities assumed. The identifiable intangible assets acquired typically include customer relationships and trade names. Identifiable intangible assets are initially valued using a methodology commensurate with the intended use of the asset. The fair value of customer relationships is measured using the multi-period excess earnings method ("MPEEM"). The fair value of trade names is measured using a relief-from-royalty ("RFR") approach, which assumes the value of the trade name is the discounted amount of cash flows that would be paid to third parties had the Company not owned the trade name and instead licensed the trade name from another company. Higher royalty rates are assigned to premium brands within the marketplace based on name recognition and profitability, while other brands receive lower royalty rates. The basis for future sales projections for both the RFR and MPEEM are based on internal revenue forecasts which the Company believes represents reasonable market participant assumptions. The future cash flows are discounted using an applicable discount rate as well as any potential risk premium to reflect the inherent risk of holding a standalone intangible asset.  The key uncertainties in the RFR and MPEEM calculations, as applicable, are the selection of an appropriate royalty rate, assumptions used in developing estimates of future cash flows, including revenue growth and expense forecasts, assumed customer attrition rates, as well as the perceived risk associated with those forecasts in determining the discount rate and risk premium.  There is inherent uncertainty in forecasted future cash flows and therefore, actual results may differ and could result in subsequent impairment charges of acquired intangible assets and/or goodwill.

[0000038725-25-000026:mdna:81]
Indefinite-Lived Intangible Asset and Goodwill Impairment Evaluation

[0000038725-25-000026:mdna:82]
According to FASB ASC Topic 350, Intangibles - Goodwill and Other, goodwill and other intangible assets with indefinite lives must be tested for impairment at least annually or more frequently as warranted by triggering events that indicate potential impairment. The Company has the option to assess goodwill and other indefinite-lived intangible assets for impairment by initially performing a qualitative assessment to determine whether it is more-likely-than-not that the fair value of a reporting unit or indefinite-lived intangible asset is less than its carrying amount. If the Company determines that it is not more-likely-than-not that the fair value of a reporting unit or indefinite-lived intangible asset is less than its carrying amount, then a quantitative impairment test is not required to be performed. If the Company determines that it is more-likely-than-not that the fair value of a reporting unit or indefinite-lived intangible asset is less than its carrying amount, or if it does not elect the option to perform an initial qualitative assessment, it performs a quantitative impairment test.

[0000038725-25-000026:mdna:83]
The Company uses a variety of methodologies in conducting impairment assessments including qualitative reviews as well as quantitative reviews using the income and market approaches.

[0000038725-25-000026:mdna:84]
The market value approach compares the reporting units’ current and projected financial results to entities of similar size and industry to determine the market value of the reporting unit. The income approach utilizes assumptions regarding estimated future cash flows and other factors to determine the fair value of the respective assets. These cash flows consider factors regarding expected future operating income and historical trends, as well as the effects of demand and competition. The Company is required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units or indefinite-lived intangible assets are below their associated carrying values.

[0000038725-25-000026:mdna:85]
During the fourth quarter of 2024, the Company completed its annual impairment tests of goodwill and indefinite-lived trade names. The Company determined it was not more likely than not that the fair values of its reporting units were lower than their carrying values. The Company also determined the fair value of all other indefinite-lived intangible assets were in excess of their respective carrying values. Significant judgment is required to determine if an indication of impairment has taken place. Factors to be considered include the following: adverse changes in operating results, decline in strategic business plans, significantly lower future cash flows, and sustainable declines in market data such as market capitalization. A 10 percent decrease in the estimated fair value of any of the indefinite-lived trade names would not have changed this determination. The sensitivity analysis required the use of numerous subjective assumptions, which, if actual experience varies, could result in material differences in the requirements for impairment charges. Further, an extended downturn in the economy may impact certain components of the operating segments more significantly and could result in an impairment determination.

[0000038725-25-000026:mdna:86]
Income Taxes

[0000038725-25-000026:mdna:87]
Under the requirements of FASB ASC Topic 740, Income Taxes, the Company records deferred tax assets and liabilities for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company analyzes the deferred tax assets and liabilities for their future realization based on the estimated existence of sufficient taxable income. This analysis considers the following sources of taxable income: prior year taxable income, future reversals of existing taxable temporary differences, future taxable income exclusive of reversing temporary differences and tax planning strategies that would generate taxable income in the relevant period. If sufficient taxable income is not projected then the Company will record a valuation allowance against the relevant deferred tax assets.

[0000038725-25-000026:mdna:88]
The Company’s operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions. These jurisdictions have different tax rates, and the Company determines the allocation of income to each of these jurisdictions based upon various estimates and assumptions. In the normal course of business, the Company will undergo tax audits by various tax jurisdictions. Such audits often require an extended period of time to complete and may result in income tax adjustments if changes to the allocation are required between jurisdictions with different tax rates. The final taxes paid are dependent upon many factors, including negotiations with taxing authorities in the various jurisdictions and resolution of disputes arising from federal, state, and international tax audits. Although the Company has recorded all income tax uncertainties in accordance with FASB ASC Topic 740, these accruals represent estimates that are subject to the inherent uncertainties associated with the tax audit process. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, which, if actual experience varies, could result in material adjustments to tax expense and/or deferred tax assets and liabilities.

[0000038725-25-000026:mdna:89]
Pension and Employee Benefit Obligations

[0000038725-25-000026:mdna:90]
The Company consults with its actuaries to assist with the calculation of discount rates used in its pension and post retirement plans. The discount rates used to determine domestic pension and post-retirement plan liabilities are calculated using a full yield curve approach. Market conditions have caused the weighted-average discount rate to move from 4.90 percent last year to 5.48

[0000038725-25-000026:mdna:91]
percent this year for the domestic pension plans and from 4.88 percent last year to 5.47 percent this year for the postretirement health and life insurance plan. A change in the discount rate selected by the Company of 25 basis points would result in a change of about $0.1 million to employee benefit expense and a change of about $2.4 million of liability.

[0000038725-25-000026:mdna:92]
The Company consults with actuaries and investment advisors in making its determination of the expected long-term rate of return on plan assets. Using input from these consultations such as long-term investment sector expected returns, the correlations and standard deviations thereof, and the plan asset allocation, the Company will use an expected long-term rate of return on plan assets of 5.75 percent in measuring net periodic cost for 2025. Market conditions have caused the expected long-term rate or return to decrease from 6.20 percent as used in measuring net periodic cost for 2024. A change in the long-term rate of return selected by the Company of 25 basis points would result in a change of about $0.3 million of employee benefit expense.

[0000038725-25-000026:mdna:93]
FACTORS THAT MAY AFFECT FUTURE RESULTS
