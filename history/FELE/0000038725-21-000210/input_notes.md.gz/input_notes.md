# FELE notes — 0000038725-21-000210


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-21-000210:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2020, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2021, and for the third quarters and nine months ended September 30, 2021 and September 30, 2020 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2021. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2020.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-21-000210:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-21-000210:notes:3]
In August 2021, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2021-06, Presentation of Financial Statements (Topic 205), Financial Services—Depository and Lending (Topic 942), and Financial Services— Investment Companies (Topic 946): Amendments to SEC Paragraphs Pursuant to SEC Final Rule Releases No. 33-10786, Amendments to Financial Disclosures about Acquired and Disposed Businesses, and No. 33-10835, Update of Statistical Disclosures for Bank and Savings and Loan Registrants. This update amends certain SEC disclosure guidance that is included in the accounting standards codification to reflect the SEC’s recent issuance of rules intended to modernize and streamline disclosure requirements, including updates to business acquisition and disposition significance tests used, the significance thresholds for proforma statement disclosures, the number of preceding years of financial statements required for disclosure as well as other provisions in the SEC releases. The Company adopted the SEC’s guidance on January 1, 2021, the effective date of the release, relating to the amendments to financial disclosures about acquired and disposed businesses, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-21-000210:notes:4]
In March 2020, the FASB issued Accounting Standards Update ("ASU") 2020-04, Facilitation of the Effects of Reference Rate Reform on Financial Reporting, which provides optional expedients and exceptions for applying U.S. generally accepted accounting principles to contracts, hedging relationships, and other transactions affected by the discontinuation of the London Interbank Offered Rate ("LIBOR") and other reference rates which are expected to be discontinued due to reference rate reform. ASU 2020-04 is effective on a prospective basis between March 12, 2020 and December 31, 2022. The Company adopted the standard effective January 1, 2021, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-21-000210:notes:5]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is expected to reduce cost and complexity related to accounting for income taxes. ASU 2019-12 eliminates the need for the Company to analyze whether certain exceptions apply and improves financial statement preparers' application of income tax-related guidance. ASU 2019-12 is effective for interim and annual periods beginning after December 15, 2020 with early adoption permitted. Amendments related to franchise taxes that are partially based on income should be applied on either a retrospective or modified retrospective basis. All other amendments should be applied on a prospective basis. The Company adopted the standard effective January 1, 2021, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-21-000210:notes:6]
Accounting Standards Issued But Not Yet Adopted

[0000038725-21-000210:notes:7]
In August 2020, the FASB issued ASU 2020-06, Debt – Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging – Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity. ASU 2020-06 reduces the number of accounting models for various convertible instruments and reduces form-over-substance-based accounting conclusions for the derivatives scope exception for contracts in an entity’s own equity. The FASB also updated Earnings Per Share (“EPS”) guidance under Topic 260 by requiring an entity to consider the potential effect of share settlement in the diluted EPS calculation for instruments that may be settled in cash or shares as well as other amendments. ASU 2020-06 is effective for interim and annual periods beginning after December 15, 2021 with early adoption permitted but no earlier than fiscal years beginning after December 15, 2020. The guidance should be adopted at the beginning of a fiscal year. ASU 2020-06 should be applied on either a retrospective or modified retrospective basis. The Company is planning to adopt on January 1, 2022, but does not expect the ASU to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-21-000210:notes:8]
ACQUISITIONS
During the third quarter ended September 30, 2021, the Company acquired 100 percent of the ownership interests of Minetuff Dewatering Pumps Australia Pty Ltd for a cash purchase price of $13.7 million after purchase price adjustments based on the level of working capital acquired. Minetuff manufactures and sells submersible pumps, spare parts, and accessories to the mining industry and will expand the Company’s existing product offerings and channel access in the Water Systems segment. The fair value of the assets acquired and liabilities assumed for the acquisition is preliminary as of September 30, 2021, and is classified as Level 3 within the valuation hierarchy.

[0000038725-21-000210:notes:9]
During the second quarter ended June 30, 2021, the Company acquired, in separate transactions, 100 percent of the ownership interests of Puronics, Inc. and its wholly owned subsidiaries, headquartered in Livermore, California, and 100 percent of the ownership interests of New Aqua, LLC and its wholly owned subsidiaries, headquartered in Indianapolis, Indiana. Both Puronics and New Aqua are water treatment equipment providers and will be included as a part of the Water Systems segment of the Company. In a separate transaction during the second quarter ended June 30, 2021, the Company acquired all of the assets of Power Integrity Services, LLC, a North Carolina-based company, which will be included in the Fueling Systems segment of the Company.

[0000038725-21-000210:notes:10]
In another separate transaction during the second quarter ended June 30, 2021, the Company acquired all of the assets of Atlantic Turbine Pump, LLC, a Georgia-based company, which will be included in the Distribution segment of the Company. As of September 30, 2021, the Company has recorded estimated fair values that exceed the acquisition price by $0.5 million, representing a bargain purchase gain due to favorable market conditions within accrued expenses and other current liabilities in the consolidated balance sheets for the Atlantic Turbine Pump acquisition. Once the determination of fair values is complete in 2022, the Company will recognize the bargain purchase gain in the consolidated statements of income.

[0000038725-21-000210:notes:11]
The combined purchase price for all acquisitions in the second quarter was $185.1 million after purchase price adjustments based on the level of working capital acquired, which were all cash transactions. All acquisitions in the second quarter expand the Company's geographical presence and product channels. The fair value of the assets acquired and liabilities assumed for all acquisitions are preliminary as of September 30, 2021 and is classified as Level 3 within the valuation hierarchy.

[0000038725-21-000210:notes:12]
The identifiable intangible assets recognized in the separate transactions in 2021, were $121.4 million, and consist primarily of customer relationships and trade names, which will be amortized using the straight-line method over 12 - 20 years.

[0000038725-21-000210:notes:13]
The goodwill of $55.5 million resulting from the acquisitions in 2021 consists primarily of expanded geographical presence and product channel expansion.  Goodwill deductible for tax purposes is $52.1 million from the acquisitions in 2021. Goodwill was recorded in the Water Systems and Fueling Systems segments (see Note 6 - Goodwill and Other Intangible Assets).

[0000038725-21-000210:notes:14]
For all acquisitions in 2021, consolidated annual revenue for the full year 2020 was $102.4 million, which would be incremental to the Company's revenue had the acquisitions occurred on the first day of 2020. Since acquisition in 2021, consolidated revenue was $42.9 million. The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for all acquisitions is immaterial.

[0000038725-21-000210:notes:15]
During the fourth quarter ended December 31, 2020, the Company acquired 100 percent of the ownership interests of Gicon Pumps & Equipment, Inc., a professional groundwater distributor operating seven locations in the state of Texas for a purchase price of $28.1 million after purchase price adjustments based on the level of working capital acquired. Gicon will be included as part of the Distribution segment of the Company. As of September 30, 2021, the Company has recorded estimated fair values that exceed the acquisition price by $5.6 million, representing a bargain purchase gain due to favorable market conditions within accrued expenses and other current liabilities in the consolidated balance sheets. Once the determination of fair values is complete in 2021, the Company will recognize the bargain purchase gain in the consolidated statements of income. In a separate transaction during the fourth quarter ended December 31, 2020, the Company acquired 100 percent of the ownership interests in Waterite Inc. and its affiliate Waterite America Inc., headquartered in Winnipeg, Manitoba, Canada, for a purchase price of $21.9 million after purchase price adjustments based on the level of working capital acquired. Waterite will be included as a part of the Water Systems segment of the Company. The fair value of the assets acquired and liabilities assumed for both acquisitions are preliminary as of September 30, 2021 and is classified as Level 3 within the valuation hierarchy. In addition, the Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for both acquisitions is immaterial.

[0000038725-21-000210:notes:16]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations. There were $0.0 million and $0.8 million of transaction costs included in the "Selling, general, and 
administrative expenses" line of the Company's condensed consolidated statements of income for the third quarter and nine months ended September 30, 2021, respectively. Transaction costs were immaterial in the third quarter and nine months ended September 30, 2020.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-21-000210:notes:17]
[same as prior period, unchanged from 0000038725-21-000175:notes:16]

[0000038725-21-000210:notes:18]
[same as prior period, unchanged from 0000038725-21-000175:notes:17]

[0000038725-21-000210:notes:19]
[same as prior period, unchanged from 0000038725-21-000175:notes:18]

[0000038725-21-000210:notes:20]
[same as prior period, unchanged from 0000038725-21-000175:notes:19]

[0000038725-21-000210:notes:21]
As of September 30, 2021 and December 31, 2020, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-21-000210:notes:22]
| (In millions) | September 30, 2021 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 6.2 |  | $ | 6.2 |  | $ | — |  | $ | — |  |
|  | December 31, 2020 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 20.2 |  | $ | 20.2 |  | $ | — |  | $ | — |  |

[0000038725-21-000210:notes:23]
[same as prior period, unchanged from 0000038725-21-000175:notes:22]

[0000038725-21-000210:notes:24]
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3.
Total debt, including current maturities, have carrying amounts of $196.8 million and $94.6 million and estimated fair values of $206.7 million and $107.3 million as of September 30, 2021 and December 31, 2020, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-21-000210:notes:25]
FINANCIAL INSTRUMENTSThe Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of September 30, 2021, the swap had a notional value based on 210,000 shares. For the third quarter and nine months ended September 30, 2021, the swap resulted in a loss of $0.2 million and a gain of $3.1 million, respectively. For the third quarter and nine months ended September 30, 2020 the swap resulted in gains of $1.8 million and $0.3 million respectively. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-21-000210:notes:26]
[same as prior period, unchanged from 0000038725-21-000175:notes:25]

[0000038725-21-000210:notes:27]
| (In millions) |  | September 30, 2021 |  | December 31, 2020 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | 250.7 |  |  | (86.1) |  |  | 165.1 |  |  | (78.5) |  |
| Patents |  | $ | 7.4 |  |  | $ | (7.3) |  |  | $ | 7.5 |  |  | $ | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.3) |  |  | 7.5 |  |  | (7.2) |  |
| Trade names |  | 37.1 |  |  | (1.0) |  |  | $ | 3.4 |  |  | (0.2) |  |
| Other |  | 3.1 |  |  | (2.9) |  |  | 2.9 |  |  | (2.8) |  |
| Total |  | $ | 305.8 |  |  | $ | (104.6) |  |  | $ | 186.4 |  |  | $ | (96.0) |  |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.9 |  |  | — |  |  | 43.4 |  |  | — |  |
| Total intangibles |  | $ | 348.7 |  |  | $ | (104.6) |  |  | $ | 229.8 |  |  | $ | (96.0) |  |

[0000038725-21-000210:notes:28]
Amortization expense related to intangible assets for the third quarters ended September 30, 2021 and September 30, 2020 was $4.3 million and $2.4 million, respectively, and for the nine months ended September 30, 2021 and September 30, 2020, $10.2 million and $7.0 million,  respectively.

[0000038725-21-000210:notes:29]
[same as prior period, unchanged from 0000038725-21-000175:notes:28]

[0000038725-21-000210:notes:30]
| (In millions) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |
|  |  | $ | 12.9 |  |  | $ | 14.8 |  |  | $ | 14.6 |  |  | $ | 14.4 |  |  | $ | 13.6 |  |

[0000038725-21-000210:notes:31]
The change in the carrying amount of goodwill by reportable segment for the nine months ended September 30, 2021, is as follows:

[0000038725-21-000210:notes:32]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2020 |  | $ | 161.5 |  |  | $ | 67.7 |  |  | $ | 37.5 |  |  | $ | 266.7 |  |
| Acquisitions |  | 52.9 |  |  | 2.6 |  |  | — |  |  | 55.5 |  |
| Adjustments to prior year acquisitions |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Foreign currency translation |  | (2.0) |  |  | — |  |  | — |  |  | (2.0) |  |
| Balance as of September 30, 2021 |  | $ | 212.5 |  |  | $ | 70.3 |  |  | $ | 37.5 |  |  | $ | 320.3 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-21-000210:notes:33]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of September 30, 2021, the Company maintained two domestic pension plans and three German pension plans. The Company used a December 31, 2020 measurement date for these plans. One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011). The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-21-000210:notes:34]
[same as prior period, unchanged from 0000038725-21-000175:notes:33]

[0000038725-21-000210:notes:35]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the third quarters and nine months ended September 30, 2021 and September 30, 2020:

[0000038725-21-000210:notes:36]
| (In millions) | Pension Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2021 |  | September 30, 2020 |  | September 30, 2021 |  | September 30, 2020 |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.6 |  |  | $ | 0.5 |  |
| Interest cost | 0.7 |  |  | 1.1 |  |  | 2.1 |  |  | 3.3 |  |
| Expected return on assets | (1.3) |  |  | (1.7) |  |  | (4.1) |  |  | (5.1) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | 1.2 |  |  | — |  |  | 3.3 |  |  | — |  |
| Actuarial loss | — |  |  | 1.0 |  |  | — |  |  | 2.8 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.8 |  |  | $ | 0.6 |  |  | $ | 1.9 |  |  | $ | 1.5 |  |

[0000038725-21-000210:notes:37]
In the nine months ended September 30, 2021, the Company made contributions of $0.1 million to the funded plans. The amount of contributions to be made to the plans during the calendar year 2021 was finalized by September 15, 2021, based upon the funding level requirements identified and year-end valuation performed at December 31, 2020.

[0000038725-21-000210:notes:38]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the third quarters and nine months ended September 30, 2021 and September 30, 2020:

[0000038725-21-000210:notes:39]
| (In millions) | Other Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2021 |  | September 30, 2020 |  | September 30, 2021 |  | September 30, 2020 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | — |  |  | 0.1 |  |  | 0.1 |  |  | 0.2 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | — |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.2 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-21-000210:notes:40]
ACCRUED EXPENSES AND OTHER CURRENT LIABILITIES
Accrued expenses and other current liabilities consist of:

[0000038725-21-000210:notes:41]
| (In millions) |  | September 30, 2021 |  | December 31, 2020 |
| Salaries, wages, and commissions |  | 54.5 |  |  | 36.4 |  |
| Product warranty costs |  | 10.3 |  |  | 9.7 |  |
| Insurance |  | 2.6 |  |  | 2.4 |  |
| Employee benefits |  | 10.0 |  |  | 9.8 |  |
| Other |  | 37.3 |  |  | 30.7 |  |
|  |  | 114.7 |  |  | 89.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-21-000210:notes:42]
INCOME TAXESThe Company’s effective tax rate from continuing operations for the nine month period ended September 30, 2021 was 17.4 percent as compared to 18.9 percent for the nine month period ended September 30, 2020. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to foreign earnings taxed at rates below the U.S. statutory rate, the recognition of the U.S. foreign-derived intangible income (FDII) provisions, and certain discrete events including excess tax benefits from share-based compensation partially offset by state taxes.  For the third quarter of 2021, the effective tax rate was 18.3 percent as compared to 17.3 percent for the third quarter of 2020.The decrease in the effective tax rate for the nine month period ended September 30, 2021, as compared to the nine month period ended September 30, 2020, was primarily a result of net favorable discrete events of $4.0 million in 2021, including increased excess tax benefits from share-based compensation, compared to net favorable discrete events of $0.7 million in 2020.


## us-gaap:DebtDisclosureTextBlock

[0000038725-21-000210:notes:43]
DEBT
Debt consisted of the following:

[0000038725-21-000210:notes:44]
| (In millions) |  | September 30, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 105.0 |  |  | — |  |
| Tax increment financing debt |  | 16.5 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 0.6 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.3) |  |  | (0.1) |  |
|  |  | $ | 196.8 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (106.3) |  |  | (2.6) |  |
| Long-term debt |  | $ | 90.5 |  |  | 92.0 |

[0000038725-21-000210:notes:45]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2021 matures as follows:

[0000038725-21-000210:notes:46]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 197.1 |  |  | $ | 106.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 1.4 |  |  | $ | 76.5 |  |  | $ | 10.2 |  |

[0000038725-21-000210:notes:47]
Prudential Agreement

[0000038725-21-000210:notes:48]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates, which was renewed on July 30, 2021 and expires on July 30, 2024.  The Prudential Agreement has an initial borrowing capacity of $150.0 million. As of September 30, 2021, the Company had no notes issued and  $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-21-000210:notes:49]
Project Bonds

[0000038725-21-000210:notes:50]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Bonds ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Bonds are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-21-000210:notes:51]
New York Life Agreement

[0000038725-21-000210:notes:52]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC and its affiliates (the "New York Life Agreement"), which was renewed on July 30, 2021 and expires on July 30, 2024. The New York Life Agreement has a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2021, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-21-000210:notes:53]
Credit Agreement

[0000038725-21-000210:notes:54]
The Company maintains the Fourth Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement was renewed on May 13, 2021, has a maturity date of May 13, 2026, and commitment amount of $250.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million subject to agreement of the lenders (not to exceed a total commitment of $375.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based

[0000038725-21-000210:notes:55]
on LIBOR plus an applicable margin of 0.85% to 1.88% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-21-000210:notes:56]
As of September 30, 2021, the Company had $105.0 million outstanding borrowings, $4.1 million in letters of credit outstanding, and $140.9 million of available capacity under the Credit Agreement.

[0000038725-21-000210:notes:57]
Covenants

[0000038725-21-000210:notes:58]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of September 30, 2021.


## us-gaap:EarningsPerShareTextBlock

[0000038725-21-000210:notes:59]
[same as prior period, unchanged from 0000038725-21-000175:notes:55]

[0000038725-21-000210:notes:60]
[same as prior period, unchanged from 0000038725-21-000175:notes:56]

[0000038725-21-000210:notes:61]
[same as prior period, unchanged from 0000038725-21-000175:notes:57]

[0000038725-21-000210:notes:62]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions, except per share amounts) | September 30, 2021 |  | September 30, 2020 |  | September 30, 2021 |  | September 30, 2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 46.2 |  |  | $ | 38.4 |  |  | $ | 113.2 |  |  | $ | 73.7 |  |
| Less: Earnings allocated to participating securities | 0.3 |  |  | 0.3 |  |  | 0.7 |  |  | 0.5 |  |
| Net income available to common shareholders | $ | 45.9 |  |  | $ | 38.1 |  |  | $ | 112.5 |  |  | $ | 73.2 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.5 |  |  | 46.2 |  |  | 46.4 |  |  | 46.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.5 |  |  | 0.4 |  |  | 0.6 |  |  | 0.4 |  |
| Diluted weighted average common shares outstanding | 47.0 |  |  | 46.6 |  |  | 47.0 |  |  | 46.6 |  |
| Basic earnings per share | $ | 0.99 |  |  | $ | 0.82 |  |  | $ | 2.43 |  |  | $ | 1.58 |  |
| Diluted earnings per share | $ | 0.98 |  |  | $ | 0.82 |  |  | $ | 2.40 |  |  | $ | 1.57 |  |

[0000038725-21-000210:notes:63]
There were 0.0 million and 0.3 million stock options outstanding for the third quarters ended September 30, 2021 and September 30, 2020, and 0.1 million and 0.4 million  stock options outstanding for the nine months ended September 30, 2021 and September 30, 2020 respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-21-000210:notes:64]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the third quarters ended September 30, 2021 and September 30, 2020:

[0000038725-21-000210:notes:65]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of June 30, 2021 | $ | 4,645 |  |  | $ | 298,944 |  |  | $ | 804,047 |  |  | $ | (50,897) |  |  | $ | (155,440) |  |  | $ | 2,541 |  |  | $ | 903,840 |  |  | $ | (209) |  |
| Net income |  |  |  |  | 46,172 |  |  |  |  |  |  | 218 |  |  | 46,390 |  |  | 64 |  |
| Dividends on common stock ($0.175/share) |  |  |  |  | (8,179) |  |  |  |  |  |  |  |  | (8,179) |  |  |  |
| Common stock issued | 7 |  |  | 2,394 |  |  |  |  |  |  |  |  |  |  | 2,401 |  |  |  |
| Common stock repurchased | (12) |  |  |  |  | (9,895) |  |  |  |  |  |  |  |  | (9,907) |  |  |  |
| Share-based compensation | 1 |  |  | 2,347 |  |  |  |  |  |  |  |  |  |  | 2,348 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (12,034) |  |  | (50) |  |  | (12,084) |  |  | (1) |  |
| Pension liability, net of tax |  |  |  |  |  |  | 915 |  |  |  |  |  |  | 915 |  |  |  |
| Balance as of September 30, 2021 | $ | 4,641 |  |  | $ | 303,685 |  |  | $ | 832,145 |  |  | $ | (49,982) |  |  | $ | (167,474) |  |  | $ | 2,709 |  |  | $ | 925,724 |  |  | $ | (146) |  |

[0000038725-21-000210:notes:66]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of June 30, 2020 | $ | 4,618 |  |  | $ | 278,175 |  |  | $ | 715,621 |  |  | $ | (48,657) |  |  | $ | (175,893) |  |  | $ | 1,647 |  |  | $ | 775,511 |  |  | $ | (262) |  |
| Net Income |  |  |  |  | 38,372 |  |  |  |  |  |  | 178 |  |  | 38,550 |  |  | 25 |  |
| Dividends on common stock ($0.155/share) |  |  |  |  | (7,195) |  |  |  |  |  |  |  |  | (7,195) |  |  |  |
| Common stock issued | 6 |  |  | 1,488 |  |  |  |  |  |  |  |  |  |  | 1,494 |  |  |  |
| Common stock repurchased | (3) |  |  |  |  | (1,364) |  |  |  |  |  |  |  |  | (1,367) |  |  |  |
| Share-based compensation | (1) |  |  | 1,298 |  |  |  |  |  |  |  |  |  |  | 1,297 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 3,330 |  |  | 48 |  |  | 3,378 |  |  | (14) |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 774 |  |  |  |  |  |  | 774 |  |  |  |
| Balance as of September 30, 2020 | $ | 4,620 |  |  | $ | 280,961 |  |  | $ | 745,434 |  |  | $ | (47,883) |  |  | $ | (172,563) |  |  | $ | 1,873 |  |  | $ | 812,442 |  |  | $ | (251) |  |

[0000038725-21-000210:notes:67]
The schedule below set forth equity changes in the nine months ended September 30, 2021 and September 30, 2020:

[0000038725-21-000210:notes:68]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2020 | $ | 4,622 |  |  | $ | 283,420 |  |  | $ | 764,562 |  |  | $ | (52,666) |  |  | $ | (152,105) |  |  | $ | 2,116 |  |  | $ | 849,949 |  |  | $ | (245) |  |
| Net Income |  |  |  |  | 113,193 |  |  |  |  |  |  | 695 |  |  | 113,888 |  |  | 92 |  |
| Dividends on common stock ($0.525/share) |  |  |  |  | (24,499) |  |  |  |  |  |  |  |  | (24,499) |  |  |  |
| Common stock issued | 33 |  |  | 11,357 |  |  |  |  |  |  |  |  |  |  | 11,390 |  |  |  |
| Common stock repurchased | (27) |  |  |  |  | (21,111) |  |  |  |  |  |  |  |  | (21,138) |  |  |  |
| Share-based compensation | 13 |  |  | 8,908 |  |  |  |  |  |  |  |  |  |  | 8,921 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (15,369) |  |  | (102) |  |  | (15,471) |  |  | 7 |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 2,684 |  |  |  |  |  |  | 2,684 |  |  |  |
| Balance as of September 30, 2021 | $ | 4,641 |  |  | $ | 303,685 |  |  | $ | 832,145 |  |  | $ | (49,982) |  |  | $ | (167,474) |  |  | $ | 2,709 |  |  | $ | 925,724 |  |  | $ | (146) |  |
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2019 | $ | 4,639 |  |  | $ | 269,656 |  |  | $ | 712,460 |  |  | $ | (50,089) |  |  | $ | (140,121) |  |  | $ | 2,124 |  |  | $ | 798,669 |  |  | $ | (236) |  |
| Net Income |  |  |  |  | 73,666 |  |  |  |  |  |  | 534 |  |  | 74,200 |  |  | (31) |  |
| Dividends on common stock ($0.465/share) |  |  |  |  | (21,641) |  |  |  |  |  |  |  |  | (21,641) |  |  |  |
| Common stock issued | 10 |  |  | 3,004 |  |  |  |  |  |  |  |  |  |  | 3,014 |  |  |  |
| Common stock repurchased | (40) |  |  |  |  | (19,051) |  |  |  |  |  |  |  |  | (19,091) |  |  |  |
| Share-based compensation | 11 |  |  | 8,301 |  |  |  |  |  |  |  |  |  |  | 8,312 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (830) |  |  | (830) |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (32,442) |  |  | 45 |  |  | (32,397) |  |  | 16 |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 2,206 |  |  |  |  |  |  | 2,206 |  |  |  |
| Balance as of September 30, 2020 | $ | 4,620 |  |  | $ | 280,961 |  |  | $ | 745,434 |  |  | $ | (47,883) |  |  | $ | (172,563) |  |  | $ | 1,873 |  |  | $ | 812,442 |  |  | $ | (251) |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-21-000210:notes:69]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the nine months ended September 30, 2021 and September 30, 2020, are summarized below:

[0000038725-21-000210:notes:70]
| (In millions) |  |  |  |  |  |
| For the nine months ended September 30, 2021: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2020 | $ | (152.2) |  |  | $ | (52.6) |  |  | $ | (204.8) |  |
| Other comprehensive income/(loss) before reclassifications | (15.3) |  |  | — |  |  | (15.3) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 2.7 |  |  | 2.7 |  |
| Net other comprehensive income/(loss) | (15.3) |  |  | 2.7 |  |  | (12.6) |  |
| Balance as of September 30, 2021 | $ | (167.5) |  |  | $ | (49.9) |  |  | $ | (217.4) |  |
| For the nine months ended September 30, 2020: |  |  |  |  |  |
| Balance as of December 31, 2019 | $ | (140.2) |  |  | $ | (50.0) |  |  | $ | (190.2) |  |
| Other comprehensive income/(loss) before reclassifications | (32.4) |  |  | — |  |  | (32.4) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 2.2 |  |  | 2.2 |  |
| Net other comprehensive income/(loss) | (32.4) |  |  | 2.2 |  |  | (30.2) |  |
| Balance as of September 30, 2020 | $ | (172.6) |  |  | $ | (47.8) |  |  | $ | (220.4) |  |

[0000038725-21-000210:notes:71]
[same as prior period, unchanged from 0000038725-21-000175:notes:67]

[0000038725-21-000210:notes:72]
(2) Net of tax expense of $0.7 million and $0.6 million for the nine months ended September 30, 2021 and September 30, 2020, respectively.

[0000038725-21-000210:notes:73]
[same as prior period, unchanged from 0000038725-21-000175:notes:69]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-21-000210:notes:74]
[same as prior period, unchanged from 0000038725-21-000175:notes:70]

[0000038725-21-000210:notes:75]
[same as prior period, unchanged from 0000038725-21-000175:notes:71]

[0000038725-21-000210:notes:76]
[same as prior period, unchanged from 0000038725-21-000175:notes:72]

[0000038725-21-000210:notes:77]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions) | September 30, 2021 |  | September 30, 2020 |  | September 30, 2021 |  | September 30, 2020 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 134.8 |  |  | $ | 93.4 |  |  | $ | 333.1 |  |  | $ | 245.1 |  |
| Latin America | 36.5 |  |  | 30.1 |  |  | 102.9 |  |  | 82.5 |  |
| Europe, Middle East & Africa | 46.9 |  |  | 41.8 |  |  | 142.7 |  |  | 115.5 |  |
| Asia Pacific | 19.6 |  |  | 19.5 |  |  | 59.9 |  |  | 53.0 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 22.9 |  |  | 18.1 |  |  | 66.9 |  |  | 49.3 |  |
| Total sales | 260.7 |  |  | 202.9 |  |  | 705.5 |  |  | 545.4 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 140.2 |  |  | 98.0 |  |  | 380.7 |  |  | 250.5 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 140.2 |  |  | 98.0 |  |  | 380.7 |  |  | 250.5 |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 58.9 |  |  | 46.4 |  |  | 146.6 |  |  | 119.0 |  |
| All other | 22.1 |  |  | 22.0 |  |  | 63.4 |  |  | 60.6 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 81.0 |  |  | 68.4 |  |  | 210.0 |  |  | 179.6 |  |
| Intersegment Eliminations/Other | (22.9) |  |  | (18.1) |  |  | (66.9) |  |  | (49.3) |  |
| Consolidated | $ | 459.0 |  |  | $ | 351.2 |  |  | $ | 1,229.3 |  |  | $ | 926.2 |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2021 |  | September 30, 2020 |  | September 30, 2021 |  | September 30, 2020 |
|  | Operating income/(loss) |
| Water Systems | $ | 36.8 |  |  | $ | 36.6 |  |  | $ | 102.7 |  |  | $ | 84.1 |  |
| Distribution | 12.3 |  |  | 6.4 |  |  | 30.3 |  |  | 10.9 |  |
| Fueling Systems | 23.9 |  |  | 18.9 |  |  | 57.3 |  |  | 44.5 |  |
| Intersegment Eliminations/Other | (16.4) |  |  | (13.5) |  |  | (48.3) |  |  | (43.4) |  |
| Consolidated | $ | 56.6 |  |  | $ | 48.4 |  |  | $ | 142.0 |  |  | $ | 96.1 |  |

[0000038725-21-000210:notes:78]
|  | September 30, 2021 |  | December 31, 2020 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 909.7 |  |  | $ | 645.9 |  |  |  |  |  |
| Distribution | 293.6 |  |  | 249.0 |  |  |  |  |  |
| Fueling Systems | 282.5 |  |  | 268.9 |  |  |  |  |  |
| Other | 60.2 |  |  | 108.5 |  |  |  |  |  |
| Consolidated | $ | 1,546.0 |  |  | $ | 1,272.3 |  |  |  |  |  |

[0000038725-21-000210:notes:79]
[same as prior period, unchanged from 0000038725-21-000175:notes:75]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-21-000210:notes:80]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. The subject-matter expert has issued its preliminary report, which indicates that total damages incurred by Esso amounted to approximately 12 million euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company has retained experts to demonstrate that its products did not cause the damage, and in January 2021, submitted its response to the expert’s preliminary report for each station. The expert's response to the Company's report is due to the Court in June 2022. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position,  results of operations, or cash flows.

[0000038725-21-000210:notes:81]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-21-000210:notes:82]
At September 30, 2021, the Company had $14.1 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-21-000210:notes:83]
The Company provides warranties on most of its products. The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims. The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-21-000210:notes:84]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2021, are as follows:

[0000038725-21-000210:notes:85]
| (In millions) |  |  |
| Balance as of December 31, 2020 |  | $ | 9.7 |  |
| Accruals related to product warranties |  | 7.0 |  |
| Additions related to acquisitions |  | 0.1 |  |
| Reductions for payments made |  | (6.5) |  |
| Balance as of September 30, 2021 |  | $ | 10.3 |  |

[0000038725-21-000210:notes:86]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. These financing leases are immaterial to the Company.

[0000038725-21-000210:notes:87]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the information available as of the adoption of ASU 2016-02 or at the inception of any new leases entered into thereafter when determining the present value of future lease payments.

[0000038725-21-000210:notes:88]
Some of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.

[0000038725-21-000210:notes:89]
The components of the Company’s operating lease portfolio as of the third quarter and nine months ended September 30, 2021 are as follows:

[0000038725-21-000210:notes:90]
| Lease Cost (in millions): | Third Quarter Ended |  | Nine Months Ended |
| Operating lease cost | $ | 3.5 |  |  | $ | 9.2 |  |
| Short-term lease cost | 0.1 |  |  | 0.5 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4.1 years |
| Weighted-average discount rate |  |  | 4.1 | % |

[0000038725-21-000210:notes:91]
The minimum rental payments for non-cancellable operating leases as of September 30, 2021, are as follows:

[0000038725-21-000210:notes:92]
| (In millions) | 2021 | 2022 | 2023 | 2024 | 2025 | Thereafter |
| Future Minimum Rental Payments | $ | 3.9 |  | $ | 12.1 |  | $ | 8.5 |  | $ | 5.1 |  | $ | 3.3 |  | $ | 7.1 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-21-000210:notes:93]
[same as prior period, unchanged from 0000038725-21-000175:notes:90]

[0000038725-21-000210:notes:94]
[same as prior period, unchanged from 0000038725-21-000175:notes:91]

[0000038725-21-000210:notes:95]
[same as prior period, unchanged from 0000038725-21-000175:notes:92]

[0000038725-21-000210:notes:96]
[same as prior period, unchanged from 0000038725-21-000175:notes:93]

[0000038725-21-000210:notes:97]
[same as prior period, unchanged from 0000038725-21-000175:notes:94]

[0000038725-21-000210:notes:98]
[same as prior period, unchanged from 0000038725-21-000175:notes:95]

[0000038725-21-000210:notes:99]
[same as prior period, unchanged from 0000038725-21-000175:notes:96]

[0000038725-21-000210:notes:100]
[same as prior period, unchanged from 0000038725-21-000175:notes:97]

[0000038725-21-000210:notes:101]
[same as prior period, unchanged from 0000038725-21-000175:notes:98]

[0000038725-21-000210:notes:102]
[same as prior period, unchanged from 0000038725-21-000175:notes:99]

[0000038725-21-000210:notes:103]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the nine months ended September 30, 2021 and September 30, 2020 are as follows:

[0000038725-21-000210:notes:104]
|  |  | September 30, 2021 |  | September 30, 2020 |
| Risk-free interest rate |  | 0.66 | % |  | 1.39 | % |
| Dividend yield |  | 0.96 | % |  | 1.04 | % |
| Volatility factor |  | 34.98 | % |  | 29.45 | % |
| Expected term |  | 5.5 years |  | 5.5 years |

[0000038725-21-000210:notes:105]
A summary of the Company’s outstanding stock option activity and related information for the nine months ended September 30, 2021 is as follows:

[0000038725-21-000210:notes:106]
| (Shares in thousands) |  | September 30, 2021 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,331 |  |  | $ | 41.90 |  |
| Granted |  | 152 |  |  | 73.14 |  |
| Exercised |  | (333) |  |  | 34.18 |  |
| Forfeited |  | — |  |  | — |  |
| Outstanding at end of period |  | 1,150 |  |  | $ | 48.25 |  |
| Expected to vest after applying forfeiture rate |  | 1,147 |  |  | $ | 48.22 |  |
| Vested and exercisable at end of period |  | 764 |  |  | $ | 41.45 |  |

[0000038725-21-000210:notes:107]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of September 30, 2021 is as follows:

[0000038725-21-000210:notes:108]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 6.22 years |  | $ | 24,688 |  |
| Expected to vest after applying forfeiture rate |  | 6.21 years |  | $ | 24,676 |  |
| Vested and exercisable at end of period |  | 5.13 years |  | $ | 21,223 |  |

[0000038725-21-000210:notes:109]
The total intrinsic value of options exercised during the nine months ended September 30, 2021 and September 30, 2020 was $15.1 million and $2.4 million, respectively.

[0000038725-21-000210:notes:110]
As of September 30, 2021, there was $1.2 million of total unrecognized compensation cost related to non-vested stock options granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.49 years.

[0000038725-21-000210:notes:111]
[same as prior period, unchanged from 0000038725-21-000175:notes:108]

[0000038725-21-000210:notes:112]
A summary of the Company’s restricted stock/stock unit award activity and related information for the nine months ended September 30, 2021 is as follows:

[0000038725-21-000210:notes:113]
| (Shares in thousands) |  | September 30, 2021 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 403 |  |  | $ | 49.34 |  |
| Awarded |  | 104 |  |  | 74.23 |  |
| Vested |  | (124) |  |  | 43.52 |  |
| Forfeited |  | (11) |  |  | 50.06 |  |
| Non-vested at end of period |  | 372 |  |  | $ | 58.21 |  |

[0000038725-21-000210:notes:114]
As of September 30, 2021, there was $9.7 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.13 years.
