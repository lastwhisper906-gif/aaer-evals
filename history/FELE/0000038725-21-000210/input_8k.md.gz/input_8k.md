# FELE 8-K — 0000038725-21-000203 filed 2021-10-26

## item codes, every 8-K on or before 2021-11-02

- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2021-11-02

- none on or before 2021-11-02

## item 2.02 — earnings release, exhibit 99.1

[0000038725-21-000203:8k_2_02:1]
EX-99.1
2
a20211026ex991earningsrele.htm
EX-99.1

[0000038725-21-000203:8k_2_02:2]
Document

[0000038725-21-000203:8k_2_02:3]
Exhibit 99.1

[0000038725-21-000203:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-21-000203:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS RECORD THIRD QUARTER 2021 RESULTS

[0000038725-21-000203:8k_2_02:6]
Third Quarter 2021 Highlights

[0000038725-21-000203:8k_2_02:7]
•Record sales of $459.0 million, compared to third quarter 2020 sales of $351.2 million, an increase of 31%

[0000038725-21-000203:8k_2_02:8]
•Strong organic sales growth in all three Segments; Distribution 30%, Fueling Systems 18%, and Water Systems 11%

[0000038725-21-000203:8k_2_02:9]
•Operating income was $56.6 million, compared to third quarter operating income in 2020 of $48.4 million, an increase of 17%

[0000038725-21-000203:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $0.98, a record for any quarter

[0000038725-21-000203:8k_2_02:11]
•Working capital as a percent of trailing twelve months sales improved 150 basis points to 27.6%

[0000038725-21-000203:8k_2_02:12]
Fort Wayne, IN – October 26, 2021 – Franklin Electric Co. Inc. today announced third quarter 2021 financial results.

[0000038725-21-000203:8k_2_02:13]
Third quarter 2021 sales were $459.0 million, compared to third quarter 2020 sales of $351.2 million.  Third quarter 2021 operating income was $56.6 million, compared to third quarter operating income in 2020 of $48.4 million, an increase of 17 percent.

[0000038725-21-000203:8k_2_02:14]
Third quarter 2021 GAAP fully diluted earnings per share (EPS) was $0.98, versus GAAP fully diluted EPS in the third quarter 2020 of $0.82.

[0000038725-21-000203:8k_2_02:15]
“We continued to break records in the third quarter of 2021, as we once again delivered the highest consolidated net sales, operating income, and EPS for any quarter in Franklin’s history. Demand remains strong across the business, with notably strong performance in our Distribution business, which posted impressive year-over-year sales growth of 43 percent. At the same time, our Water Systems and Fueling Systems segments maintained a remarkable pace with sales growing 28 and 18 percent, respectively,” commented Gregg Sengstack, Franklin Electric’s Chairperson and Chief Executive Officer.

[0000038725-21-000203:8k_2_02:16]
“While supply chain challenges continue throughout the global economy, our team remains focused on managing these on-going challenges to meet our customers’ needs. The integration of recent acquisitions within Water Treatment continues to progress and offers a promising foundation to drive growth in our Global Water business. We look forward to capitalizing on sustained momentum in all of our business segments across the globe and drive value for our shareholders as we execute our strategic plan,” Mr. Sengstack concluded.

[0000038725-21-000203:8k_2_02:17]
Segment Summaries

[0000038725-21-000203:8k_2_02:18]
Water Systems sales, a new record for any quarter, were $260.7 million in the third quarter 2021, an increase of $57.8 million or 28 percent versus the third quarter 2020. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 11 percent compared to the third quarter 2020.  Sales of groundwater pumping equipment and sales of both surface pumping and dewatering equipment increased due to strong end market demand.  Water Systems operating income in the third quarter was $36.8 million driven by higher sales.  Third quarter 2020 Water Systems operating income was $36.6 million.

[0000038725-21-000203:8k_2_02:19]
Distribution sales, a new third quarter record, were $140.2 million in the third quarter 2021.  The Distribution segment organic sales increased 30 percent compared to the third quarter of 2020.  Revenue growth was driven by broad-based demand in all regions and product categories. The Distribution segment operating income was $12.3 million in the third quarter of 2021 compared to third quarter 2020 operating income of $6.4 million.

[0000038725-21-000203:8k_2_02:20]
Fueling Systems sales, a new record for any quarter, were $81.0 million in the third quarter 2021, an increase of $12.6 million versus the third quarter 2020. Fueling Systems sales in the U.S. and Canada increased by about 27 percent compared to the third quarter 2020. The increase was due to higher demand for Fuel Management and Pumping Systems and Piping. Outside the U.S. and Canada, Fueling Systems revenues decreased by about 1 percent, as sales increases of 11 percent in the rest of the world outside of China were offset by lower sales in China. Fueling Systems operating income in the third quarter was $23.9 million, compared to $18.9 million in the third quarter of 2020, driven by higher sales, as well as favorable geographic and product mix.

[0000038725-21-000203:8k_2_02:21]
Cash Flow

[0000038725-21-000203:8k_2_02:22]
Net cash flows from operating activities for the first nine months of 2021 were $93.9 million versus $133.7 million in the same period in 2020. The decrease was primarily due to higher working capital requirements in support of higher revenues.

[0000038725-21-000203:8k_2_02:23]
2021 Guidance

[0000038725-21-000203:8k_2_02:24]
The Company is raising our most recent full year 2021 earnings per share before restructuring expenses to be in the range from $2.99 to $3.07.

[0000038725-21-000203:8k_2_02:25]
Earnings Conference Call

[0000038725-21-000203:8k_2_02:26]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The third quarter 2021 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-21-000203:8k_2_02:27]
https://edge.media-server.com/mmc/p/g2j853js

[0000038725-21-000203:8k_2_02:28]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls. The conference ID is 6199466.

[0000038725-21-000203:8k_2_02:29]
A replay of the conference call will be available Tuesday, October 26, 2021, at 12:00 noon ET through noon ET on Tuesday, November 2, 2021, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls. The replay passcode is 6199466.

[0000038725-21-000203:8k_2_02:30]
Forward Looking Statements

[0000038725-21-000203:8k_2_02:31]
About Franklin Electric

[0000038725-21-000203:8k_2_02:32]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-21-000203:8k_2_02:33]
Franklin Electric Contact:

[0000038725-21-000203:8k_2_02:34]
Jeffery L. Taylor

[0000038725-21-000203:8k_2_02:35]
Franklin Electric Co., Inc.

[0000038725-21-000203:8k_2_02:36]
260-824-2900

[0000038725-21-000203:8k_2_02:37]
Email: jeffery.taylor@fele.com

[0000038725-21-000203:8k_2_02:38]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2021 |  | September 30, 2020 |  | September 30, 2021 |  | September 30, 2020 |
| Net sales | $ | 459,019 |  |  | $ | 351,190 |  |  | $ | 1,229,345 |  |  | $ | 926,225 |  |
| Cost of sales | 295,903 |  |  | 226,893 |  |  | 798,444 |  |  | 604,489 |  |
| Gross profit | 163,116 |  |  | 124,297 |  |  | 430,901 |  |  | 321,736 |  |
| Selling, general, and administrative expenses | 106,446 |  |  | 75,472 |  |  | 288,534 |  |  | 223,409 |  |
| Restructuring expense | 76 |  |  | 441 |  |  | 381 |  |  | 2,189 |  |
| Operating income | 56,594 |  |  | 48,384 |  |  | 141,986 |  |  | 96,138 |  |
| Interest expense | (1,384) |  |  | (1,130) |  |  | (3,840) |  |  | (3,496) |  |
| Other income/(expense), net | 2,061 |  |  | (463) |  |  | 1,531 |  |  | (1,062) |  |
| Foreign exchange income/(expense) | (408) |  |  | (140) |  |  | (1,654) |  |  | (84) |  |
| Income before income taxes | 56,863 |  |  | 46,651 |  |  | 138,023 |  |  | 91,496 |  |
| Income tax (benefit)/ expense | 10,409 |  |  | 8,076 |  |  | 24,043 |  |  | 17,327 |  |
| Net income | $ | 46,454 |  |  | $ | 38,575 |  |  | $ | 113,980 |  |  | $ | 74,169 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (282) |  |  | (203) |  |  | (787) |  |  | (503) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 46,172 |  |  | $ | 38,372 |  |  | $ | 113,193 |  |  | $ | 73,666 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.99 |  |  | $ | 0.82 |  |  | $ | 2.43 |  |  | $ | 1.58 |  |
| Diluted | $ | 0.98 |  |  | $ | 0.82 |  |  | $ | 2.40 |  |  | $ | 1.57 |  |

[0000038725-21-000203:8k_2_02:39]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | September 30, 2021 |  | December 31, 2020 |
| ASSETS |  |
| Cash and equivalents | $ | 75,952 |  |  | $ | 130,787 |  |
| Receivables (net) | 218,175 |  |  | 159,827 |  |
| Inventories | 395,531 |  |  | 300,932 |  |
| Other current assets | 38,472 |  |  | 27,708 |  |
| Total current assets | 728,130 |  |  | 619,254 |  |
| Property, plant, and equipment, net | 205,970 |  |  | 209,021 |  |
| Right-of-use asset, net | 36,181 |  |  | 31,954 |  |
| Goodwill and other assets | 575,700 |  |  | 412,078 |  |
| Total assets | $ | 1,545,981 |  |  | $ | 1,272,307 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 163,941 |  |  | $ | 95,903 |  |
| Accrued expenses and other current liabilities | 118,999 |  |  | 94,160 |  |
| Current lease liability | 12,240 |  |  | 11,090 |  |
| Current maturities of long-term debt and short-term borrowings | 106,293 |  |  | 2,551 |  |
| Total current liabilities | 401,473 |  |  | 203,704 |  |
| Long-term debt | 90,527 |  |  | 91,966 |  |
| Long-term lease liability | 24,087 |  |  | 20,866 |  |
| Income taxes payable non-current | 11,610 |  |  | 11,965 |  |
| Deferred income taxes | 27,540 |  |  | 25,671 |  |
| Employee benefit plans | 39,899 |  |  | 44,443 |  |
| Other long-term liabilities | 25,267 |  |  | 23,988 |  |
| Redeemable noncontrolling interest | (146) |  |  | (245) |  |
| Total equity | 925,724 |  |  | 849,949 |  |
| Total liabilities and equity | $ | 1,545,981 |  |  | $ | 1,272,307 |  |

[0000038725-21-000203:8k_2_02:40]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Nine Months Ended |
| (In thousands) |  |  |  |
|  | September 30, 2021 |  | September 30, 2020 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 113,980 |  |  | $ | 74,169 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 32,767 |  |  | 26,917 |  |
| Non-cash lease expense | 9,394 |  |  | 8,478 |  |
| Share-based compensation | 8,921 |  |  | 8,312 |  |
| Other | 1,978 |  |  | (622) |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (57,434) |  |  | (5,147) |  |
| Inventory | (85,873) |  |  | 4,322 |  |
| Accounts payable and accrued expenses | 92,214 |  |  | 26,069 |  |
| Operating leases | (9,394) |  |  | (8,478) |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | (355) |  | — |
| Other | (12,296) |  |  | (312) |  |
| Net cash flows from operating activities | 93,902 |  |  | 133,708 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (20,274) |  |  | (15,239) |  |
| Proceeds from sale of property, plant, and equipment | 839 |  |  | 28 |  |
| Acquisitions and investments | (193,987) |  |  | (6,089) |  |
| Other investing activities | 38 |  |  | (74) |  |
| Net cash flows from investing activities | (213,384) |  |  | (21,374) |  |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 102,395 |  |  | (20,748) |  |
| Proceeds from issuance of common stock | 11,390 |  |  | 3,014 |  |
| Purchases of common stock | (21,138) |  |  | (19,091) |  |
| Dividends paid | (24,499) |  |  | (21,641) |  |
| Net cash flows from financing activities | 68,148 |  |  | (58,466) |  |
| Effect of exchange rate changes on cash | (3,501) |  |  | (3,793) |  |
| Net change in cash and equivalents | (54,835) |  |  | 50,075 |  |
| Cash and equivalents at beginning of period | 130,787 |  |  | 64,405 |  |
| Cash and equivalents at end of period | $ | 75,952 |  |  | $ | 114,480 |  |

[0000038725-21-000203:8k_2_02:41]
Key Performance Indicators: Earnings Per Share Calculations

[0000038725-21-000203:8k_2_02:42]
| Earnings Before and After Restructuring |  | For the Third Quarter |  |  |
| (in millions) |  | 2021 | 2020 | Change |  |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 46.2 |  | $ | 38.4 |  | 20 | % |  |  |  |  |
| Allocated Earnings |  | $ | (0.3) |  | $ | (0.3) |  |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 45.9 |  | $ | 38.1 |  | 20 | % |  |  |  |  |
| Restructuring (before tax): |  | $ | 0.1 |  | $ | 0.4 |  |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 0.1 |  | $ | 0.3 |  |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 46.0 |  | $ | 38.4 |  | 20 | % |  |  |  |  |
| Earnings Per Share |  | For the Third Quarter |  |  |
| Before and After Restructuring |  | 2021 | 2020 | Change |  |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.0 |  | 46.6 |  | 1 | % |  |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.98 |  | $ | 0.82 |  | 20 | % |  |  |  |  |
| Restructuring Per Share, net of tax |  | $ | — |  | $ | 0.01 |  |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.98 |  | $ | 0.83 |  | 18 | % |  |  |  |  |

[0000038725-21-000203:8k_2_02:43]
Key Performance Indicators: Net Sales Summary

[0000038725-21-000203:8k_2_02:44]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q3 2020 | $ | 111.5 |  | $ | 30.1 |  | $ | 41.8 |  | $ | 19.5 |  | $ | 202.9 |  | $ | 68.4 |  | $ | 98.0 |  | $ | (18.1) |  | $ | 351.2 |  |
| Q3 2021 | $ | 157.7 |  | $ | 36.5 |  | $ | 46.9 |  | $ | 19.6 |  | $ | 260.7 |  | $ | 81.0 |  | $ | 140.2 |  | $ | (22.9) |  | $ | 459.0 |  |
| Change | $ | 46.2 |  | $ | 6.4 |  | $ | 5.1 |  | $ | 0.1 |  | $ | 57.8 |  | $ | 12.6 |  | $ | 42.2 |  | $ | (4.8) |  | $ | 107.8 |  |
| % Change | 41 | % | 21 | % | 12 | % | 1 | % | 28 | % | 18 | % | 43 | % |  | 31 | % |
| Foreign currency translation | $ | 0.9 |  | $ | (0.3) |  | $ | (0.1) |  | $ | 0.2 |  | $ | 0.7 |  | $ | 0.4 |  | $ | — |  |  |  |
| % Change | 1 | % | (1) | % | — | % | 1 | % | — | % | 1 | % | — | % |  |  |
| Acquisitions | $ | 33.7 |  | $ | — |  | $ | — |  | $ | 0.5 |  | $ | 34.2 |  | $ | — |  | $ | 13.2 |  |  |  |
| Volume/Price | $ | 11.6 |  | $ | 6.7 |  | $ | 5.2 |  | $ | (0.6) |  | $ | 22.9 |  | $ | 12.2 |  | $ | 29.0 |  |  |  |
| % Change | 10 | % | 22 | % | 12 | % | (3) | % | 11 | % | 18 | % | 30 | % |  |  |

[0000038725-21-000203:8k_2_02:45]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-21-000203:8k_2_02:46]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2021 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 36.8 |  | $ | 23.9 |  | $ | 12.3 |  | $ | (16.4) |  | $ | 56.6 |  |
| % Operating Income To Net Sales | 14.1 | % | 29.5 | % | 8.8 | % |  | 12.3 | % |
| Restructuring | $ | 0.1 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.1 |  |
| Operating Income/(Loss) Before Restructuring | $ | 36.9 |  | $ | 23.9 |  | $ | 12.3 |  | $ | (16.4) |  | $ | 56.7 |  |
| % Operating Income to Net Sales Before Restructuring | 14.2 | % | 29.5 | % | 8.8 | % |  | 12.4 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2020 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 36.6 |  | $ | 18.9 |  | $ | 6.4 |  | $ | (13.5) |  | $ | 48.4 |  |
| % Operating Income To Net Sales | 18.0 | % | 27.6 | % | 6.5 | % |  | 13.8 | % |
| Restructuring | $ | 0.4 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.4 |  |
| Operating Income/(Loss) Before Restructuring | $ | 37.0 |  | $ | 18.9 |  | $ | 6.4 |  | $ | (13.5) |  | $ | 48.8 |  |
| % Operating Income to Net Sales Before Restructuring | 18.2 | % | 27.6 | % | 6.5 | % |  | 13.9 | % |
