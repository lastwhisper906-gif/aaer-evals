# FELE MD&A — 0000038725-21-000210


## mdna

[0000038725-21-000210:mdna:1]
[same as prior period, unchanged from 0000038725-21-000175:mdna:1]

[0000038725-21-000210:mdna:2]
Third Quarter 2021 vs. Third Quarter 2020

[0000038725-21-000210:mdna:3]
[same as prior period, unchanged from 0000038725-21-000175:mdna:3]

[0000038725-21-000210:mdna:4]
Sales in the third quarter of 2021 increased from the third quarter last year. The sales increase was led by increases from volume, price, and acquisitions. The Company's consolidated gross profit was $163.1 million for the third quarter of 2021, an increase of $38.8 million or about 31 percent from the prior year’s third quarter. Earnings per share in the third quarter of 2021 were up to the same period last year by about 20 percent.

[0000038725-21-000210:mdna:5]
[same as prior period, unchanged from 0000038725-21-000175:mdna:5]

[0000038725-21-000210:mdna:6]
[same as prior period, unchanged from 0000038725-21-000175:mdna:6]

[0000038725-21-000210:mdna:7]
Net sales in the third quarter of 2021 were $459.0 million, an increase of $107.8 million or about 31 percent compared to 2020 third quarter sales of $351.2 million. Acquisition related sales were $47.4 million. Sales revenue increased by $1.1 million or less than 1 percent in the third quarter of 2021 due to foreign currency translation.

[0000038725-21-000210:mdna:8]
|  | Net Sales |
| (In millions) | Q3 2021 |  | Q3 2020 |  | 2021 v 2020 |
| Water Systems | $ | 260.7 |  |  | $ | 202.9 |  |  | $ | 57.8 |  |
| Fueling Systems | 81.0 |  |  | 68.4 |  |  | $ | 12.6 |  |
| Distribution | 140.2 |  |  | 98.0 |  |  | $ | 42.2 |  |
| Eliminations/Other | (22.9) |  |  | (18.1) |  |  | $ | (4.8) |  |
| Consolidated | $ | 459.0 |  |  | $ | 351.2 |  |  | $ | 107.8 |  |

[0000038725-21-000210:mdna:9]
[same as prior period, unchanged from 0000038725-21-000175:mdna:9]

[0000038725-21-000210:mdna:10]
Water Systems sales were $260.7 million in the third quarter 2021, an increase of $57.8 million versus the third quarter 2020 sales of $202.9 million. In the third quarter of 2021, sales from businesses acquired since the third quarter of 2020 were $34.2 million. Water Systems sales increased by $0.7 million or less than 1 percent in the quarter due to foreign currency translation. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 11 percent compared to the third quarter 2020.

[0000038725-21-000210:mdna:11]
Water Systems sales in the U.S. and Canada were up overall by 41 percent compared to the third quarter 2020. In the third quarter of 2021, sales from businesses acquired since the third quarter of 2020 were $33.7 million.  In the U.S. and Canada, Water Systems organic sales increased by 10 percent.  Sales of groundwater pumping equipment increased by about 12 percent, and sales of dewatering equipment were up about 60 percent, both due to strong end market demand.  Sales of surface pumping equipment increased by about 3 percent versus the third quarter 2020, as supply constraints with certain utility pumps and lower overall sales of sump pumps limited their growth rate.

[0000038725-21-000210:mdna:12]
Water Systems sales in markets outside the U.S. and Canada increased by 13 percent overall. Foreign currency translation had no effect on sales. In the third quarter of 2021, sales from businesses acquired since the third quarter of 2020 were $0.5 million. Outside the U.S. and Canada, Water Systems organic sales increased by 12 percent, driven by higher sales in Latin America, Europe, the Middle East and Africa, partially offset by lower sales in the Asia Pacific markets.

[0000038725-21-000210:mdna:13]
[same as prior period, unchanged from 0000038725-21-000175:mdna:13]

[0000038725-21-000210:mdna:14]
Fueling Systems sales were $81.0 million in the third quarter 2021, an increase of $12.6 million versus the third quarter 2020 sales of $68.4 million. In the third quarter of 2021, sales increased by $0.4 million or about 1 percent due to foreign currency translation. Fueling Systems organic sales increased about 18 percent compared to the third quarter of 2020.

[0000038725-21-000210:mdna:15]
Fueling Systems sales in the U.S. and Canada increased by about 27 percent compared to the third quarter 2020. The increase was due to higher demand for Fuel Management and Pumping Systems, and Piping. Outside the U.S. and Canada, Fueling Systems revenues decreased by about 1 percent, as sales increases of 11 percent in the rest of the world outside of China were offset by lower sales in China. China sales were about $4 million in the third quarter of 2021 compared to the third quarter of 2020 Fueling Systems China sales of about $6 million.

[0000038725-21-000210:mdna:16]
[same as prior period, unchanged from 0000038725-21-000175:mdna:16]

[0000038725-21-000210:mdna:17]
Distribution sales were $140.2 million in the third quarter 2021, versus third quarter 2020 sales of $98.0 million. In the third quarter of 2021, sales from businesses acquired since the third quarter of 2020 were $13.2 million.  The Distribution segment organic sales increased about 30 percent compared to the third quarter of 2020. Revenue growth was driven by broad-based demand in all regions and product categories.

[0000038725-21-000210:mdna:18]
[same as prior period, unchanged from 0000038725-21-000175:mdna:18]

[0000038725-21-000210:mdna:19]
Cost of sales as a percent of net sales for the third quarter of 2021 and 2020 was 64.5 percent and 64.6 percent, respectively. Correspondingly, the gross profit margin as a percent of net sales was 35.5 percent in the third quarter of 2021 compared to 35.4 percent in the third quarter of 2020. The gross profit margin was flat as material inflation costs were offset by price increases.  The Company's consolidated gross profit was $163.1 million for the third quarter of 2021, an increase of $38.8 million from the gross profit of $124.3 million in the third quarter of 2020. The gross profit increase was primarily due to higher sales.

[0000038725-21-000210:mdna:20]
[same as prior period, unchanged from 0000038725-21-000175:mdna:20]

[0000038725-21-000210:mdna:21]
Selling, general, and administrative (SG&A) expenses were $106.4 million in the third quarter of 2021 compared to $75.5 million in the third quarter of the prior year. SG&A expenses from acquired businesses were about $12 million. Excluding acquisitions, SG&A expenses were higher by $19.0 million, about $11 million of which is variable compensation expense and commissions on higher sales.

[0000038725-21-000210:mdna:22]
[same as prior period, unchanged from 0000038725-21-000175:mdna:22]

[0000038725-21-000210:mdna:23]
Restructuring expenses for the third quarter of 2021 were $0.1 million, primarily in the Water segment and related to miscellaneous manufacturing realignment activities. Restructuring expenses for the third quarter of 2020 were $0.4 million, primarily in the Water segment and related to miscellaneous manufacturing realignment activities.

[0000038725-21-000210:mdna:24]
[same as prior period, unchanged from 0000038725-21-000175:mdna:24]

[0000038725-21-000210:mdna:25]
Operating income was $56.6 million in the third quarter of 2021, up $8.2 million or 17 percent from $48.4 million in the third quarter of 2020.

[0000038725-21-000210:mdna:26]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2021 |  | Q3 2020 |  | 2021 v 2020 |
| Water Systems |  | 36.8 |  |  | $ | 36.6 |  |  | $ | 0.2 |  |
| Fueling Systems |  | 23.9 |  |  | 18.9 |  |  | 5.0 |  |
| Distribution |  | 12.3 |  |  | 6.4 |  |  | 5.9 |  |
| Eliminations/Other |  | (16.4) |  |  | (13.5) |  |  | (2.9) |  |
| Consolidated |  | $ | 56.6 |  |  | $ | 48.4 |  |  | $ | 8.2 |  |

[0000038725-21-000210:mdna:27]
[same as prior period, unchanged from 0000038725-21-000175:mdna:27]

[0000038725-21-000210:mdna:28]
Water Systems operating income was $36.8 million in the third quarter 2021, up $0.2 million compared to $36.6 million in the third quarter 2020. The third quarter of 2021 operating income margin was 14.1 percent versus 18.0 percent of net sales in the third quarter of 2020. The decline in operating margin was due to higher SG&A expenses; primarily higher variable compensation and other operating expenses relating to increased commercial activity. Additionally, significant cost inflation in materials, components, freight, and tariffs, all of which the Company strived to fully offset with pricing, and a higher mix of Water Treatment sales at a lower margin also contributed to the lower operating margin.

[0000038725-21-000210:mdna:29]
[same as prior period, unchanged from 0000038725-21-000175:mdna:29]

[0000038725-21-000210:mdna:30]
Fueling Systems operating income was $23.9 million in the third quarter of 2021, up $5.0 million or about 26 percent compared to $18.9 million in the third quarter of 2020. The increase in operating income was primarily due to higher sales revenues. The third quarter of 2021 operating income margin was 29.5 percent versus 27.6 percent of net sales in the third

[0000038725-21-000210:mdna:31]
quarter of 2020. Operating income margin in the third quarter increased in Fueling Systems primarily due leverage on higher sales volumes, favorable product, and geographic sales mix shifts.

[0000038725-21-000210:mdna:32]
[same as prior period, unchanged from 0000038725-21-000175:mdna:31]

[0000038725-21-000210:mdna:33]
Distribution operating income was $12.3 million in the third quarter of 2021 and the third quarter operating income margin was 8.8 percent. Distribution operating income was $6.4 million in the third quarter of 2020 and the third quarter operating income margin was 6.5 percent. Distribution’s operating income was higher in the third quarter due to higher sales volumes. The increase in operating income margin was primarily due to revenue growth and operating leverage.

[0000038725-21-000210:mdna:34]
[same as prior period, unchanged from 0000038725-21-000175:mdna:34]

[0000038725-21-000210:mdna:35]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses. The inter-segment profit elimination impact in the third quarter of 2021 compared to the third quarter of 2020 negative impact of $0.3 million on operating income. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its customer. Unallocated general and administrative expenses were higher by $2.6 million or about 19 percent, primarily higher due to higher variable compensation expense.

[0000038725-21-000210:mdna:36]
[same as prior period, unchanged from 0000038725-21-000175:mdna:36]

[0000038725-21-000210:mdna:37]
Interest expense for the third quarter of 2021 and 2020 was $1.4 million and $1.1 million, respectively.

[0000038725-21-000210:mdna:38]
[same as prior period, unchanged from 0000038725-21-000175:mdna:38]

[0000038725-21-000210:mdna:39]
Other income or expense was a gain of $2.1 million and a loss of $0.5 million in the third quarter of 2021 and 2020, respectively. Included in other income or expense in the third quarter of 2021 was a gain of $2.5 million related to a settlement of an indirect tax dispute.

[0000038725-21-000210:mdna:40]
[same as prior period, unchanged from 0000038725-21-000175:mdna:40]

[0000038725-21-000210:mdna:41]
Foreign currency-based transactions produced a loss for the third quarter of 2021 of $0.4 million. Foreign currency-based transactions produced a loss for the third quarter of 2020 of $0.1 million.

[0000038725-21-000210:mdna:42]
[same as prior period, unchanged from 0000038725-21-000175:mdna:42]

[0000038725-21-000210:mdna:43]
The provision for income taxes in the third quarter of 2021 and 2020 was $10.4 million and $8.1 million, respectively. The effective tax rate for the third quarter of 2021 was about 18 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate for the third quarter of 2020 was about 17 percent and, before the impact of discrete events, was about 20 percent. The tax rate as a percentage of pre-tax earnings for the full year 2021 is projected to be about 20 percent, compared to the full year 2020 tax rate of about 21 percent, both before discrete adjustments.

[0000038725-21-000210:mdna:44]
[same as prior period, unchanged from 0000038725-21-000175:mdna:44]

[0000038725-21-000210:mdna:45]
Net income for the third quarter of 2021 was $46.5 million compared to the prior year third quarter net income of $38.6 million. Net income attributable to Franklin Electric Co., Inc. for the third quarter of 2021 was $46.2 million, or $0.98 per diluted share, compared to the prior year third quarter net income attributable to Franklin Electric Co., Inc. of $38.4 million or $0.82 per diluted share.

[0000038725-21-000210:mdna:46]
First Nine Months of 2021 vs. First Nine Months of 2020

[0000038725-21-000210:mdna:47]
[same as prior period, unchanged from 0000038725-21-000175:mdna:47]

[0000038725-21-000210:mdna:48]
Sales in the first nine months of 2021 were up from the same period last year. The sales increase was primarily from higher volumes, price, and acquisitions.  The impact of foreign currency translation increased sales by less than 1 percent. The Company's consolidated gross profit was $430.9 million for the first nine months of 2021, an increase of $109.2 million or about 34 percent from the first nine months of 2020. Earnings in the first nine months of 2021 were up from the same period last year.

[0000038725-21-000210:mdna:49]
[same as prior period, unchanged from 0000038725-21-000175:mdna:49]

[0000038725-21-000210:mdna:50]
[same as prior period, unchanged from 0000038725-21-000175:mdna:50]

[0000038725-21-000210:mdna:51]
Net sales in the first nine months of 2021 were $1,229.3 million, an increase of $303.1 million or about 33 percent compared to 2020 first nine months sales of $926.2 million. The incremental impact of sales from acquired businesses was $109.8 million. Sales revenue increased by $4.3 million or less than 1 percent in the first nine months of 2021 due to foreign currency translation.

[0000038725-21-000210:mdna:52]
|  | Net Sales |
| (In millions) | YTD September 30, 2021 |  | YTD September 30, 2020 |  | 2021 v 2020 |
| Water Systems | $ | 705.5 |  |  | $ | 545.4 |  |  | $ | 160.1 |  |
| Fueling Systems | 210.0 |  |  | 179.6 |  |  | $ | 30.4 |  |
| Distribution | 380.7 |  |  | 250.5 |  |  | $ | 130.2 |  |
| Eliminations/Other | (66.9) |  |  | (49.3) |  |  | $ | (17.6) |  |
| Consolidated | $ | 1,229.3 |  |  | $ | 926.2 |  |  | $ | 303.1 |  |

[0000038725-21-000210:mdna:53]
[same as prior period, unchanged from 0000038725-21-000175:mdna:53]

[0000038725-21-000210:mdna:54]
Water Systems sales were $705.5 million in the first nine months 2021, an increase of $160.1 million or about 29 percent versus the first nine months of 2020. The incremental impact of sales from acquired businesses was $65.2 million. Foreign currency translation changes increased sales $1.8 million, or less than 1 percent, compared to sales in the first nine months of 2020. The Water Systems sales change in the first nine months of 2021, excluding acquisitions and foreign currency translation, was an increase of $93.2 million or about 17 percent.

[0000038725-21-000210:mdna:55]
Water Systems sales in the U.S. and Canada increased by about 36 percent compared to the first nine months of 2020. The incremental impact of sales from acquired businesses was $64.7 million. Sales revenue increased by $3.4 million in the first nine months of 2021 due to foreign currency translation. In the first nine months of 2021, sales of groundwater pumping equipment increased by about 17 percent, sales of dewatering equipment were up about 42 percent, and sales of surface pumping equipment increased by about 8 percent versus the third quarter 2020, all due to strong end market demand

[0000038725-21-000210:mdna:56]
Water Systems sales in markets outside the U.S. and Canada increased by about 22 percent compared to the first nine months of 2020. The incremental impact of sales from acquired businesses was $0.5 million. Sales revenue decreased by $1.6 million in the first nine months of 2021 due to foreign currency translation. The change in the first nine months of 2021, excluding acquisitions and foreign currency translation, was an increase of about 22 percent. Sales grew organically in all major markets; Latin America, EMENA, and Asia Pacific.

[0000038725-21-000210:mdna:57]
[same as prior period, unchanged from 0000038725-21-000175:mdna:57]

[0000038725-21-000210:mdna:58]
Fueling Systems sales were $210.0 million in the first nine months of 2021, an increase of $30.4 million or about 17 percent from the first nine months of 2020. Foreign currency translation changes increased sales $2.5 million or about 1 percent compared to sales in the first nine months of 2020. The Fueling Systems sales change in the first nine months of 2021, excluding foreign currency translation, was an increase of $27.9 million or about 16 percent.

[0000038725-21-000210:mdna:59]
Fueling Systems sales in the U.S. and Canada increased by about 23 percent during the first nine months of 2021, the increase was due to higher demand for Fuel Management and Pumping Systems, and Piping.  Outside the U.S. and Canada, Fueling Systems revenues increased by about 4 percent overall, as sales increases of 14 percent in the rest of the world outside of China were offset by lower sales in China.  China sales were about $9 million in the first nine months of 2021 compared to the first nine months of 2020 Fueling Systems China sales of about $14 million.

[0000038725-21-000210:mdna:60]
[same as prior period, unchanged from 0000038725-21-000175:mdna:60]

[0000038725-21-000210:mdna:61]
Distribution sales were $380.7 million in the first nine months of 2021, versus the first nine months of 2020 sales of $250.5 million. The incremental impact of sales from acquired businesses was $44.6 million.  Distribution segment organic sales increased about 34 percent compared to the first nine months of 2020. Revenue growth was driven by broad-based demand in all regions and product categories.

[0000038725-21-000210:mdna:62]
[same as prior period, unchanged from 0000038725-21-000175:mdna:62]

[0000038725-21-000210:mdna:63]
Cost of sales as a percent of net sales for the first nine months of 2021 and 2020 was 64.9 percent and 65.3 percent, respectively. Correspondingly, the gross profit margin was 35.1 percent and 34.7 percent, respectively. The increase in gross profit margin was primarily driven by price realization, product sales mix and cost management. The Company's consolidated gross profit was $430.9 million for the first nine months of 2021, up $109.2 million from the gross profit of $321.7 million in the first nine months of 2020. The gross profit increase was primarily due to higher sales.

[0000038725-21-000210:mdna:64]
[same as prior period, unchanged from 0000038725-21-000175:mdna:64]

[0000038725-21-000210:mdna:65]
Selling, general, and administrative expenses were $288.5 million in the first nine months of 2021 and increased by $65.1 million compared to $223.4 million in the first nine months of last year. SG&A expenses from acquired businesses were $26.8

[0000038725-21-000210:mdna:66]
million. Excluding acquisitions, SG&A expenses were higher by $38.3 million, about $23 million of which is variable compensation expense and commissions on higher sales. The remaining SG&A increases were primarily related to other operating expenses relating to increased commercial activity.

[0000038725-21-000210:mdna:67]
[same as prior period, unchanged from 0000038725-21-000175:mdna:66]

[0000038725-21-000210:mdna:68]
Restructuring expenses for the first nine months of 2021 were $0.4 million.  Restructuring expenses were $0.3 million in the Water segment and $0.1 million in Distribution segments. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution segment. Restructuring expenses for the first nine months of 2020 were $2.2 million. Restructuring expenses were $2.0 million in the Water segment and $0.1 million in both the Fueling and Distribution segments. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution segment.

[0000038725-21-000210:mdna:69]
[same as prior period, unchanged from 0000038725-21-000175:mdna:68]

[0000038725-21-000210:mdna:70]
Operating income was $142.0 million in the first nine months of 2021, up $45.9 million or 48 percent from $96.1 million in the first nine months of 2020.

[0000038725-21-000210:mdna:71]
|  |  | Operating income (loss) |
| (In millions) |  | YTD September 30, 2021 |  | YTD September 30, 2020 |  | 2021 v 2020 |
| Water Systems |  | 102.7 |  |  | 84.1 |  |  | $ | 18.6 |  |
| Fueling Systems |  | 57.3 |  |  | 44.5 |  |  | 12.8 |  |
| Distribution |  | 30.3 |  |  | 10.9 |  |  | 19.4 |  |
| Eliminations/Other |  | (48.3) |  |  | (43.4) |  |  | (4.9) |  |
| Consolidated |  | $ | 142.0 |  |  | $ | 96.1 |  |  | $ | 45.9 |  |

[0000038725-21-000210:mdna:72]
[same as prior period, unchanged from 0000038725-21-000175:mdna:71]

[0000038725-21-000210:mdna:73]
Water Systems operating income was $102.7 million in the first nine months of 2021 compared to $84.1 million in the first nine months of 2020, an increase of 22 percent. Operating income increased in Water Systems primarily due to higher sales volumes. The first nine months operating income margin was 14.6 percent compared to the first nine months of 2020 operating income margin of 15.4 percent. Operating income margin decreased in Water Systems primarily due to significant cost inflation in materials, components, freight, and tariffs; all of which the Company strived to fully offset with pricing; and a higher mix of Water Treatment sales at a lower margin also contributed to the lower operating margin.

[0000038725-21-000210:mdna:74]
[same as prior period, unchanged from 0000038725-21-000175:mdna:73]

[0000038725-21-000210:mdna:75]
Fueling Systems operating income was $57.3 million in the first nine months of 2021 compared to $44.5 million in the first nine months of 2020. Operating income increased in Fueling Systems primarily due to higher sales volumes.  The first nine months operating income margin was 27.3 percent compared to 24.8 percent of net sales in the first nine months of 2020. Operating income margin increased in Fueling Systems primarily due to operating leverage on higher sales, favorable product and geographic sales mix shifts.

[0000038725-21-000210:mdna:76]
[same as prior period, unchanged from 0000038725-21-000175:mdna:75]

[0000038725-21-000210:mdna:77]
Distribution operating income was $30.3 million in the first nine months of 2021 and operating income margin was 8.0 percent. Distribution operating income was $10.9 million in the first nine months of 2020 and operating income margin was 4.4 percent. Distribution’s operating income in the first nine months was higher in due to higher sales volumes. The increase in operating income margin was primarily due to revenue growth and operating leverage.

[0000038725-21-000210:mdna:78]
[same as prior period, unchanged from 0000038725-21-000175:mdna:77]

[0000038725-21-000210:mdna:79]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses. The inter-segment profit elimination impact in the first nine months of 2021 increased operating income about $0.1 million versus the impact in the first nine months of 2020. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its third-party customer. Unallocated general and administrative expenses were higher by $5.0 million or about 12 percent to last year in the first nine months, primarily due to higher variable compensation expense.

[0000038725-21-000210:mdna:80]
[same as prior period, unchanged from 0000038725-21-000175:mdna:79]

[0000038725-21-000210:mdna:81]
Interest expense for the first nine months of 2021 and 2020 was $3.8 million and $3.5 million, respectively, primarily as a result of higher debt levels.

[0000038725-21-000210:mdna:82]
[same as prior period, unchanged from 0000038725-21-000175:mdna:81]

[0000038725-21-000210:mdna:83]
Other income or expense was a gain of $1.5 million and a loss of 1.1 million, respectively in the first nine months of 2021 and 2020. Included in other income or expense in 2021 was a gain of $2.5 million related to a settlement of an indirect tax dispute.

[0000038725-21-000210:mdna:84]
[same as prior period, unchanged from 0000038725-21-000175:mdna:83]

[0000038725-21-000210:mdna:85]
Foreign currency–based transactions produced a loss for the first nine months of 2021 of $1.7 million, primarily from the Argentinian peso. Foreign currency–based transactions produced a loss for the first nine months of 2020 of $0.1 million.

[0000038725-21-000210:mdna:86]
[same as prior period, unchanged from 0000038725-21-000175:mdna:85]

[0000038725-21-000210:mdna:87]
The provision for income taxes in the first nine months of 2021 and 2020 was $24.0 million and $17.3 million, respectively. The effective tax rate for the first nine months of 2021 was about 17 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate in the first nine months of 2020 was about 19 percent and, before the impact of discrete events, was about 20 percent. The decrease in the effective tax rate was primarily a result of increased net favorable discrete events recorded in the first nine months of 2021 compared to the first nine months of 2020. The tax rate as a percentage of pre-tax earnings for the full year of 2021 is projected to be about 20 percent, compared to the full year 2020 tax rate of about 21 percent, both before discrete adjustments.

[0000038725-21-000210:mdna:88]
[same as prior period, unchanged from 0000038725-21-000175:mdna:87]

[0000038725-21-000210:mdna:89]
Net income for the first nine months of 2021 was $114.0 million compared to 2020 first nine months net income of $74.2 million. Net income attributable to Franklin Electric Co., Inc. for the first nine months of 2021 was $113.2 million, or $2.40 per diluted share, compared to 2020 first nine months net income attributable to Franklin Electric Co., Inc. of $73.7 million or $1.57 per diluted share.

[0000038725-21-000210:mdna:90]
[same as prior period, unchanged from 0000038725-21-000175:mdna:89]

[0000038725-21-000210:mdna:91]
[same as prior period, unchanged from 0000038725-21-000175:mdna:90]

[0000038725-21-000210:mdna:92]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at September 30, 2021 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-21-000210:mdna:93]
As of September 30, 2021 the Company had a $250.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of September 30, 2021, the Company had $140.9 million borrowing capacity under the Credit Agreement as $4.1 million in letters of commercial and standby letters of credit were outstanding and undrawn and $105 million in revolver borrowings were drawn and outstanding, which were primarily used for funding recent acquisitions.

[0000038725-21-000210:mdna:94]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of  $125.0 million as of September 30, 2021. The Company also has other long-term debt borrowings outstanding as of September 30, 2021. See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-21-000210:mdna:95]
At September 30, 2021, the Company had $61.1 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-21-000210:mdna:96]
[same as prior period, unchanged from 0000038725-21-000175:mdna:95]

[0000038725-21-000210:mdna:97]
The following table summarizes significant sources and uses of cash and cash equivalents for the first nine months of 2021 and 2020.

[0000038725-21-000210:mdna:98]
| (in millions) |  | 2021 |  | 2020 |
| Net cash flows from operating activities |  | $ | 93.9 |  |  | $ | 133.7 |  |
| Net cash flows from investing activities |  | (213.4) |  |  | (21.4) |  |
| Net cash flows from financing activities |  | 68.2 |  |  | (58.5) |  |
| Impact of exchange rates on cash and cash equivalents |  | (3.5) |  |  | (3.8) |  |
| Change in cash and cash equivalents |  | $ | (54.8) |  |  | $ | 50.0 |  |

[0000038725-21-000210:mdna:99]
[same as prior period, unchanged from 0000038725-21-000175:mdna:98]

[0000038725-21-000210:mdna:100]
[same as prior period, unchanged from 0000038725-21-000175:mdna:99]

[0000038725-21-000210:mdna:101]
Net cash provided by operating activities was $93.9 million for the nine months ended September 30, 2021 compared to $133.7 million provided by operating activities for the nine months ended September 30, 2020. The decrease in cash provided by operating activities was primarily due to increased working capital requirements in support of higher revenues.

[0000038725-21-000210:mdna:102]
[same as prior period, unchanged from 0000038725-21-000175:mdna:101]

[0000038725-21-000210:mdna:103]
[same as prior period, unchanged from 0000038725-21-000175:mdna:102]

[0000038725-21-000210:mdna:104]
Net cash used in investing activities was $213.4 million for the nine months ended September 30, 2021 compared to $21.4 million used in investing activities for the  nine months ended September 30, 2020. The increase in cash used in investing activities was attributable to increased acquisition activity in 2021.

[0000038725-21-000210:mdna:105]
[same as prior period, unchanged from 0000038725-21-000175:mdna:104]

[0000038725-21-000210:mdna:106]
[same as prior period, unchanged from 0000038725-21-000175:mdna:105]

[0000038725-21-000210:mdna:107]
Net cash provided by financing activities was $68.2  million for the nine months ended September 30, 2021 compared to $58.5 million used in financing activities for the nine months ended September 30, 2020. The increase in cash provided by financing activities was attributable to increased debt proceeds and issuance of common stock, primarily through stock option exercises, offset by increased dividend payments and common stock repurchases.

[0000038725-21-000210:mdna:108]
[same as prior period, unchanged from 0000038725-21-000175:mdna:107]
