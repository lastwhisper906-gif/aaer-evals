# FELE MD&A — 0000038725-18-000039


## mdna

[0000038725-18-000039:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-18-000039:mdna:2]
2017 vs. 2016

[0000038725-18-000039:mdna:3]
OVERVIEW

[0000038725-18-000039:mdna:4]
Sales in 2017 were up from last year. Net sales in 2017 were $1,124.9 million, an increase of $175.0 million or about 18 percent compared to 2016 sales of $949.9 million. The sales increase was primarily related to acquisitions.   In 2017, the Company acquired a controlling interest in several distribution companies.  The distribution companies are reported collectively as a new segment. The Company's consolidated gross profit was $377.0 million for 2017, an increase of $45.6 million or about 14 percent from 2016.  The gross profit as a percent of net sales decreased 140 basis points to 33.5 percent in 2017 from 34.9 percent in 2016.  The decline in gross profit margin percentage is primarily due to product and geographic sales mix shifts and higher raw material costs.  For 2017, diluted earnings per share were $1.65, flat to 2016 diluted earnings per share of $1.65.  The Company recorded a net tax expense of $10.2 million, or $0.21 in diluted earnings per share related to the enactment of the U.S. Tax Cuts and Jobs Act of 2017. Before the impact of the U.S. Tax Cuts and Jobs Act of 2017, diluted earnings per share for 2017 were $1.86 compared to the 2016 diluted earnings per share of $1.65 or an increase of about 13 percent.

[0000038725-18-000039:mdna:5]
RESULTS OF OPERATIONS

[0000038725-18-000039:mdna:6]
Net Sales

[0000038725-18-000039:mdna:7]
Net sales in 2017 were $1,124.9 million, an increase of $175.0 million or about 18 percent compared to sales in 2016 of $949.9 million.  The sales increase was primarily from acquisition related sales.  Sales revenue increased by $2.7 million or less than 1 percent in 2017 due to foreign currency translation. The sales change in 2017, excluding acquisitions and foreign currency translation, was a decrease of $4.4 million or less than 1 percent.

[0000038725-18-000039:mdna:8]
|  | Net Sales |
| (In millions) | 2017 |  | 2016 |  | 2017 v 2016 |
| Water Systems | $ | 748.6 |  |  | $ | 723.2 |  |  | $ | 25.4 |  |
| Fueling Systems | 245.9 |  |  | 226.7 |  |  | 19.2 |  |
| Distribution | 176.7 |  |  | — |  |  | 176.7 |  |
| Eliminations/Other | (46.3 | ) |  | — |  |  | (46.3 | ) |
| Consolidated | $ | 1,124.9 |  |  | $ | 949.9 |  |  | $ | 175.0 |  |

[0000038725-18-000039:mdna:9]
Net Sales-Water Systems

[0000038725-18-000039:mdna:10]
Water Systems sales were $748.6 million in 2017 and increased by $25.4 million or about 4 percent versus 2016. Foreign currency translation rate changes increased sales $2.0 million compared to sales in 2016. The Water Systems sales change in 2017, excluding foreign currency translation, was an increase of $23.4 million or about 3 percent.

[0000038725-18-000039:mdna:11]
Water Systems sales in the U.S. and Canada were up about 3 percent compared to 2016. The impact of foreign currency translation was not significant.  Sales of Pioneer branded dewatering equipment increased by about 50 percent in 2017 when compared to the prior year resulting from the continued diversification of customers and strengthening in U.S. oil and gas end markets. Sales of other surface pumping equipment increased by 2 percent primarily in wastewater related products. Sales of groundwater pumping equipment were down by about 2 percent overall with flat residential water systems offset with declines in agricultural systems.

[0000038725-18-000039:mdna:12]
Water Systems sales in markets outside the U.S. and Canada overall increased by about 4 percent. The impact of foreign currency translation was not significant. International Water Systems sales were led by improved sales in Europe, including higher sales of Pioneer branded equipment, and the Middle East and Africa, but were offset by lower sales, in local currency, in the Latin American markets compared to last year.

[0000038725-18-000039:mdna:13]
Net Sales-Fueling Systems

[0000038725-18-000039:mdna:14]
Fueling Systems sales were $245.9 million in 2017 and increased $19.2 million or about 8 percent from 2016. Foreign currency translation rate changes increased sales $0.7 million or less than 1 percent compared to sales in 2016. The Fueling Systems sales change in 2017, excluding foreign currency translation, was an increase of $18.5 million or about 8 percent.

[0000038725-18-000039:mdna:15]
Fueling Systems sales in the U.S. and Canada grew by about 4 percent during 2017 with sales growth coming from all product lines. Outside the U.S. and Canada, Fueling Systems revenues were up by about 14 percent overall with increased sales in China and Europe partially offset by lower sales in India.

[0000038725-18-000039:mdna:16]
Net Sales-Distribution

[0000038725-18-000039:mdna:17]
Distribution sales were $176.7 million in 2017 and were all acquisition related. Management estimates Distribution sales declined by about 6 percent from 2016 primarily driven by supply chain disruptions and weak end market conditions in the Southeast region of the United States.

[0000038725-18-000039:mdna:18]
Cost of Sales

[0000038725-18-000039:mdna:19]
Cost of sales as a percent of net sales for 2017 and 2016 was 66.5 percent and 65.1 percent, respectively. Correspondingly, the gross profit margin was 33.5 percent and 34.9 percent for both years. The Company’s consolidated gross profit was $377.0 million for 2017, up $45.6 million from the gross profit of $331.4 million in 2016. The gross profit increase was primarily due to higher sales. The decline in gross profit margin percentage is partially attributable to the inclusion of the Distribution segment which impacted the margin by about 20 basis points and the balance is due to product and geographic sales mix shifts and higher raw material costs.

[0000038725-18-000039:mdna:20]
Selling, General and Administrative (“SG&A”)

[0000038725-18-000039:mdna:21]
Selling, general, and administrative expenses were $265.7 million in 2017 and increased by $44.5 million or 20 percent in 2017 compared to $221.2 million last year. The increase in SG&A expenses from acquired businesses were $45.1 million. Excluding the acquired entities, the Company’s SG&A expenses in 2017 were $220.6 and decreased by $0.6 million or flat to last year.

[0000038725-18-000039:mdna:22]
Restructuring Expenses

[0000038725-18-000039:mdna:23]
Restructuring expenses for 2017 were $4.3 million. Restructuring expenses were $2.7 million in the Water segment primarily related to the continuing Brazilian manufacturing realignments. Restructuring expenses were primarily severance expenses and other miscellaneous manufacturing realignment activities. The Fueling segment restructuring expenses in 2017 were $1.6 million.  The Company wrote off its ownership share in a Fueling Systems joint venture in India.  Restructuring charges for 2016 resulted in a net gain of $0.6 million. Restructuring expenses for 2016 included a gain of $2.0 million from the sale of land and building in Brazil and $1.4 million in expenses related to severance, equipment transfers, freight and relocation cost related to the transfer of production activities and other restructuring costs from continued manufacturing realignments.

[0000038725-18-000039:mdna:24]
Operating Income

[0000038725-18-000039:mdna:25]
Operating income was $107.0 million in 2017, down $3.8 million or about 3 percent from $110.8 million in 2016.

[0000038725-18-000039:mdna:26]
|  |  | Operating income (loss) |
| (In millions) |  | 2017 |  | 2016 |  | 2017 v 2016 |
| Water Systems |  | $ | 102.0 |  |  | $ | 108.2 |  |  | $ | (6.2 | ) |
| Fueling Systems |  | 60.0 |  |  | 56.3 |  |  | 3.7 |  |
| Distribution |  | 3.7 |  |  | — |  |  | 3.7 |  |
| Eliminations/Other |  | (58.7 | ) |  | (53.7 | ) |  | (5.0 | ) |
| Consolidated |  | $ | 107.0 |  |  | $ | 110.8 |  |  | $ | (3.8 | ) |

[0000038725-18-000039:mdna:27]
Operating Income-Water Systems

[0000038725-18-000039:mdna:28]
Water Systems operating income was $102.0 million in 2017, down $6.2 million or about 6 percent versus 2016 of $108.2 million and operating income margin was 13.6 percent in 2017 compared to the 15.0 percent in 2016. As mentioned above Water Systems operating income was negatively impacted by $2.7 million in restructuring expenses in 2017 and favorably impacted by $1.2 million in the prior year. Water Systems operating income before restructuring was $104.7 million in 2017 and $107.0 million in 2016 and operating income margin before restructuring was 14.0 percent compared to the 14.8 percent in 2016. The decline in operating income margin is primarily related to product and geographic sales mix shifts and higher raw material costs.

[0000038725-18-000039:mdna:29]
Operating Income-Fueling Systems

[0000038725-18-000039:mdna:30]
Fueling Systems operating income was $60.0 million in 2017, up $3.7 million or about 7 percent compared to $56.3 million in 2016. The 2017 operating income margin was 24.4 percent compared to the 24.8 percent of net sales in 2016. As mentioned above Fueling Systems operating income was negatively impacted by $1.6 million in restructuring expenses in 2017 and

[0000038725-18-000039:mdna:31]
impacted by $0.6 million in the prior year. Fueling Systems operating income before restructuring was $61.6 million in 2017 and $56.9 million in 2016 and operating income margin before restructuring was 25.1 percent in both 2017 and 2016.  The increase in operating income was primarily due to higher sales.

[0000038725-18-000039:mdna:32]
Operating Income-Distribution

[0000038725-18-000039:mdna:33]
Distribution operating income was $3.7 million in 2017 and the operating income margin was 2.1 percent.

[0000038725-18-000039:mdna:34]
Operating Income-Eliminations/Other

[0000038725-18-000039:mdna:35]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in 2017 was $5.5 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer.  General and administrative expenses were lower by $0.5 million or flat to last year.

[0000038725-18-000039:mdna:36]
Interest Expense

[0000038725-18-000039:mdna:37]
Interest expense for 2017 and 2016 was $10.3 million and $8.7 million, respectively. The increase in interest expense in 2017 is due to interest charges on prior years VAT taxes as a result of an audit in an international jurisdiction and due to higher average borrowings resulting from the Headwater acquisitions.

[0000038725-18-000039:mdna:38]
Other Income or Expense

[0000038725-18-000039:mdna:39]
Other income or expense was income of $6.9 million in 2017. Included in other income in 2017 was a gain of $5.2 million related to the acquisition of controlling interests in three Distribution entities previously held as equity investments. Also, included in other income in 2017 was minority income of $0.6 million and interest income of $0.9 million, primarily derived from the investment of cash balances in short-term securities. 2016 was income of $1.0 million. Included in other income in 2016 was minority income $1.7 million and interest income of $1.0 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-18-000039:mdna:40]
Foreign Exchange

[0000038725-18-000039:mdna:41]
Foreign currency-based transactions produced a gain for 2017 and 2016 of $1.0 million and $1.1 million, respectively.

[0000038725-18-000039:mdna:42]
Income Taxes

[0000038725-18-000039:mdna:43]
The provision for income taxes in 2017 and 2016 was $26.0 million and $24.8 million, respectively.  The effective tax rate for 2016 was about 24 percent and, before the impact of discrete events, was about 26 percent. The effective tax rate for 2017 was about 25 percent, both before and after the impact of discrete events.  The tax rate was lower than the statutory rate of 35 percent primarily due to foreign earnings taxed at lower statutory rates and the recognition of US incentives.  The Company recorded a provisional net tax expense of $10.2 million relating to the enactment of the U.S. Tax Cuts and Jobs Act of 2017. This expense was primarily derived from the recognition of a U.S. tax liability for the deemed repatriation of foreign earnings partially offset by the revaluation of other deferred tax liabilities.  Other discrete benefits of $10.3 million offset the expense including a foreign currency translation loss on the repayment of an intercompany loan that was a long-term-investment in nature, a tax restructuring in a foreign tax jurisdiction that released a valuation allowance on a deferred tax asset, a tax benefit on the non-taxable gain recorded on the previously held equity investments, excess tax benefits from share-based compensation and the statute expiration on foreign uncertain tax positions.  In 2018, the Company estimates its effective tax rate will be 13 to 17 percent, or about 10 points lower than the effective tax rate of 25 percent in 2017. The lower tax rate is primarily the result of the U.S. Tax Cuts and Jobs Act of 2017.

[0000038725-18-000039:mdna:44]
Net Income

[0000038725-18-000039:mdna:45]
Net income for 2017 was $78.6 million compared to 2016 net income of $79.3 million.  Net income attributable to Franklin Electric Co., Inc. for 2017 was $78.2 million, or $1.65 per diluted share, compared to 2016 net income attributable to Franklin Electric Co., Inc. of $78.7 million or $1.65 per diluted share.

[0000038725-18-000039:mdna:46]
2016 vs. 2015

[0000038725-18-000039:mdna:47]
OVERVIEW

[0000038725-18-000039:mdna:48]
Sales in 2016 increased from the prior year.  Net sales in 2016 were $949.9 million, an increase of about 3 percent compared to 2015 sales of $924.9 million. The sales increase was attributable to both volume and price increases partially offset by the impact of foreign currency translation as the US dollar strengthened against certain foreign currencies. The Company’s consolidated gross profit was $331.4 million for 2016, an increase of $33.8 million or about 11 percent from 2015. The gross profit as a percent of net sales increased 270 basis points to 34.9 percent in 2016 from 32.2 percent in 2015. The gross profit

[0000038725-18-000039:mdna:49]
margin change was due primarily to favorable pricing, lower direct material costs and lower fixed cost on higher sales. For 2016, diluted earnings per share were $1.65, an increase of 10 percent compared to 2015 diluted earnings per share of $1.50.

[0000038725-18-000039:mdna:50]
RESULTS OF OPERATIONS

[0000038725-18-000039:mdna:51]
Net Sales

[0000038725-18-000039:mdna:52]
Net sales in 2016 were $949.9 million, an increase of $25.0 million or about 3 percent compared to 2015 sales of $924.9 million.  The incremental impact of sales from acquired businesses was $0.7 million.  Sales revenue decreased by $23.2 million or about 2 percent in 2016 due to foreign currency translation. The sales change in 2016, excluding acquisitions and foreign currency translation, was an increase of $47.5 million or about 5 percent.

[0000038725-18-000039:mdna:53]
|  |  | Net Sales |
| (In millions) |  | 2016 |  | 2015 |  | 2016 v 2015 |
| Water Systems |  | $ | 723.2 |  |  | $ | 707.6 |  |  | $ | 15.6 |  |
| Fueling Systems |  | 226.7 |  |  | 217.3 |  |  | 9.4 |  |
| Consolidated |  | $ | 949.9 |  |  | $ | 924.9 |  |  | $ | 25.0 |  |

[0000038725-18-000039:mdna:54]
Net Sales-Water Systems

[0000038725-18-000039:mdna:55]
Water Systems sales were $723.2 million in 2016, an increase of $15.6 million or 2 percent versus 2015. The incremental impact of sales from acquired businesses was $0.7 million.  Foreign currency translation rate changes decreased sales $21.4 million, or about 3 percent, compared to sales in 2015. The sales change in 2016, excluding acquisitions and foreign currency translation, was an increase of $36.3 million or about 5 percent.

[0000038725-18-000039:mdna:56]
Water Systems sales in the U.S. and Canada were 36 percent of consolidated sales and increased by about 5 percent in 2016 compared to the prior year. Sales revenue decreased by $2.1 million or less than 1 percent in 2016 due to foreign currency translation. The sales change in 2016, excluding acquisitions and foreign currency translation, was an increase of $16.4 million or about 5 percent. In 2016, sales of groundwater pumping equipment increased by about 9 percent. The growth in groundwater equipment sales was led by a 12 percent increase in sales of products for both residential and agricultural applications. Sales of Pioneer branded mobile dewatering equipment declined by about 12 percent. The decline in mobile dewatering equipment is primarily attributed to reduced demand in the oil and gas end markets.

[0000038725-18-000039:mdna:57]
Water Systems sales in Europe, Middle East and Africa were about 17 percent of consolidated sales and declined by about 4 percent compared to 2015. Water Systems in Europe, the Middle East and Africa were reduced by $10.5 million or about 6 percent due to foreign currency translation. Excluding the impact of foreign currency translation, sales were up in 2016 by about 2 percent compared to 2015. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-18-000039:mdna:58]
In local currency sales in Turkey grew; however, this growth was offset by sales declines in other parts of the region due to political and economic turmoil and the lower price of oil which reduced investment by the public sector, particularly in Saudi Arabia.

[0000038725-18-000039:mdna:59]
Water Systems sales in Latin America were about 14 percent of consolidated sales for 2016 and declined by about 1 percent compared to 2015.  Sales revenue decreased by $8.5 million or about 7 percent in 2016 due to foreign currency translation. The sales change in 2016, excluding foreign currency translation, was an increase of $7.4 million or about 6 percent. The growth in sales was led by increased sales in Mexico and Brazil, in local currency. This sales growth is a result of increasing demand for Franklin submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions.

[0000038725-18-000039:mdna:60]
Water Systems sales in the Asia Pacific region were 9 percent of consolidated sales and grew by about 12 percent compared to the prior year. Foreign currency translation rate changes decreased sales in 2016 in the Asia Pacific region by less than a percent. The Asia Pacific region experienced strong year over year growth in Southeast Asia and Australia.

[0000038725-18-000039:mdna:61]
Net Sales-Fueling Systems

[0000038725-18-000039:mdna:62]
Fueling Systems sales which represented 24 percent of consolidated sales were $226.7 million in 2016, an increase of $9.4 million or about 4 percent versus 2015. Foreign currency translation rate changes decreased sales $1.8 million or about 1 percent compared to sales in 2015. The sales change in 2016, excluding acquisitions and foreign currency translation, was an increase of $11.2 million or about 5 percent.

[0000038725-18-000039:mdna:63]
Fueling Systems sales in the U.S. and Canada grew by about 8 percent in 2016 compared to the prior year with sales growth coming from most product lines, most significantly our pumping and fuel management systems. Fueling Systems sales in the

[0000038725-18-000039:mdna:64]
rest of the world were down about 2 percent year over year. In 2016, Fueling Systems revenues increased in the Asia Pacific regions by about 14 percent, driven by higher sales in India. This growth in Asia was more than offset by a sales decline in Europe principally due to a 42 percent decline in the sale of storage tanks that support North Sea oil production.

[0000038725-18-000039:mdna:65]
Cost of Sales

[0000038725-18-000039:mdna:66]
Cost of sales as a percent of net sales for 2016 and 2015 was 65.1 percent and 67.8 percent, respectively. Correspondingly, the gross profit margin increased to 34.9 percent from 32.2 percent, a 270 basis point improvement. The gross profit margin increase was primarily due to lower raw material costs and lower fixed costs. Direct materials as a percentage of sales was 44.8 percent down 210 basis points compared to 46.9 percent last year. This decrease in direct materials was primarily due to favorable pricing and lower direct material costs. The Company’s consolidated gross profit was $331.4 million for 2016, up $33.8 million or 11 percent from 2015.

[0000038725-18-000039:mdna:67]
Selling, General and Administrative (“SG&A”)

[0000038725-18-000039:mdna:68]
Selling, general, and administrative (SG&A) expenses were $221.2 million in 2016 and increased by $16.9 million or about 8 percent in 2016 compared to last year. In 2016, increases in SG&A attributable to higher variable compensation expenses were about $12 million or about 6 percent. Additional year over year changes in SG&A costs were primarily in Marketing and Selling related expenses which increased about $2.5 million to support sales growth and, also, Research, Development & Engineering expense which increased by $2.3 million in the year.

[0000038725-18-000039:mdna:69]
Restructuring (Income)/Expense

[0000038725-18-000039:mdna:70]
Restructuring expenses for 2016 netted to a gain of $(0.6) million and increased diluted earnings per share about $0.01. Restructuring expenses for 2016 included a gain of $(2.0) million from the sale of land and building in Brazil and $1.4 million in expenses related to severance and pension costs, equipment relocation expenses, asset write-downs and other costs related to the transfer of production activities and other restructuring costs from continued manufacturing realignments.

[0000038725-18-000039:mdna:71]
Restructuring expenses for 2015 were $3.0 million and decreased diluted earnings per share about $0.04. Restructuring expenses in 2015 included severance and pension costs, equipment relocation expenses, and asset write-downs primarily related to the closure of the Wittlich, Germany facility and other manufacturing realignment activities in Europe and Brazil.

[0000038725-18-000039:mdna:72]
Operating Income

[0000038725-18-000039:mdna:73]
Operating income was $110.8 million in 2016, up $20.4 million from $90.4 million in 2015.

[0000038725-18-000039:mdna:74]
|  |  | Operating income (loss) |
| (In millions) |  | 2016 |  | 2015 |  | 2016 v 2015 |
| Water Systems |  | $ | 108.2 |  |  | $ | 86.7 |  |  | $ | 21.5 |  |
| Fueling Systems |  | 56.3 |  |  | 51.5 |  |  | 4.8 |  |
| Other |  | (53.7 | ) |  | (47.8 | ) |  | (5.9 | ) |
| Consolidated |  | $ | 110.8 |  |  | $ | 90.4 |  |  | $ | 20.4 |  |

[0000038725-18-000039:mdna:75]
Operating Income-Water Systems

[0000038725-18-000039:mdna:76]
Water Systems operating income was $108.2 million in 2016, up $21.5 million or 25 percent versus the 2015. The 2016 operating income margin was 15.0 percent, up 270 basis points from 12.3 percent in 2015. The increase in basis points was primarily due to improved margins from lower variable costs.

[0000038725-18-000039:mdna:77]
Operating Income-Fueling Systems

[0000038725-18-000039:mdna:78]
Fueling Systems operating income was $56.3 million in 2016, up $4.8 million or about 9 percent compared to $51.5 million in 2015. The 2016 operating income margin was 24.8 percent, an increase of 110 basis points from the as reported 23.7 percent of net sales in 2015. The increase in basis points was primarily due to improved margins from lower variable costs.

[0000038725-18-000039:mdna:79]
Operating Income-Other

[0000038725-18-000039:mdna:80]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses were higher, primarily due to higher variable compensation expenses.

[0000038725-18-000039:mdna:81]
Interest Expense

[0000038725-18-000039:mdna:82]
Interest expense for 2016 and 2015 was $8.7 million and $10.0 million, respectively.

[0000038725-18-000039:mdna:83]
Other Income or Expense

[0000038725-18-000039:mdna:84]
Other income or expense was a gain of $1.0 million in 2016. Included in other income or expense in 2016 was minority income of $1.7 million and interest income of $1.0 million, primarily derived from the investment of cash balances in short-term securities. In 2016, other expenses also included the reversal of an indemnification receivable related to a contingent tax liability for $1.9 million recorded at the time of a foreign acquisition.  The contingent tax liability was for the same amount and was also reversed in 2016 and the benefit was recorded in the income tax provision. Other income or expense was income of $6.9 million in 2015. Included in other income or expense in 2016 was minority income of $2.8 million and interest income of $1.3 million, primarily derived from the investment of cash balances in short-term securities. The Company also realized a gain on the settlement of the redeemable non-controlling interest liability in the first quarter of 2015 of about $2.7 million.

[0000038725-18-000039:mdna:85]
Foreign Exchange

[0000038725-18-000039:mdna:86]
Foreign currency-based transactions produced a gain for 2016 of $1.1 million, primarily due to the Turkish lira relative to the U.S. dollar and euro.  Foreign currency-based transactions produced a loss for 2015 of $0.9 million, primarily due to the South African rand, Colombian peso and Australian dollar relative to the U.S. dollar, none of which individually were significant.

[0000038725-18-000039:mdna:87]
Income Taxes

[0000038725-18-000039:mdna:88]
The provision for income taxes in 2016 and 2015 was $24.8 million and $12.6 million, respectively. The tax rate for 2016 was 23.8 percent and 2015 was 14.6 percent. Discrete adjustments in 2016 were primarily due to the favorable impact from equity compensation share based payments and the reversal of a contingent tax liability offset by adjustments to the Company’s valuation allowance against certain state deferred tax assets that are not likely to be realized. Discrete adjustments during 2015 were the reversal of a deferred tax liability of about $4.8 million created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer. This purchase transaction also resulted in other tax benefits of about $3.5 million. The tax rate before discrete adjustments for 2016 was about 26 percent and 2015 was about 27 percent. The tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-18-000039:mdna:89]
Net Income

[0000038725-18-000039:mdna:90]
Net income for 2016 was $79.3 million compared to 2015 net income of $73.7 million.  Net income attributable to Franklin Electric Co., Inc. for 2016 was $78.7 million, or $1.65 per diluted share, compared to 2015 net income attributable to Franklin Electric Co., Inc. of $72.9 million or $1.50 per diluted share.

[0000038725-18-000039:mdna:91]
CAPITAL RESOURCES AND LIQUIDITY

[0000038725-18-000039:mdna:92]
Sources of Liquidity

[0000038725-18-000039:mdna:93]
The Company’s primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at December 31, 2017 is adequate to meet projected needs for the foreseeable future.  The Company expects ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-18-000039:mdna:94]
On December 22, 2017, the U.S. Tax Cuts and Jobs Act of 2017 was enacted, and the Company recorded a tax liability for the transition tax on accumulated foreign subsidiary earnings of $18.9 million, of which $1.5 million and $17.4 million were presented within the “income taxes” and “income taxes payable non-current” respectively on the Company’s Consolidated Balance Sheets as of December 31, 2017. As permitted by the Tax Act, the Company intends to pay the transition tax in eight variable annual interest-free installments beginning in 2018.

[0000038725-18-000039:mdna:95]
As of December 31, 2017, the Company had a $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of December 31, 2017, the Company had $227.5 million borrowing capacity under the Credit Agreement as $5.5 million in letters of commercial and standby letters of credit were outstanding and undrawn and $67.0 million in revolver borrowings were drawn and outstanding as of the end of the year which were primarily used for acquisition and working capital needs.

[0000038725-18-000039:mdna:96]
The Company also has other long-term debt borrowings outstanding as of December 31, 2017.  See Note 11 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-18-000039:mdna:97]
At December 31, 2017, the Company had $59.2 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-18-000039:mdna:98]
Cash Flows

[0000038725-18-000039:mdna:99]
The following table summarizes significant sources and uses of cash and cash equivalents:

[0000038725-18-000039:mdna:100]
| (in thousands) | 2017 |  | 2016 |  | 2015 |
| Net cash provided by operating activities | $ | 66.8 |  |  | $ | 115.4 |  |  | $ | 99.6 |  |
| Net cash used in investing activities | (84.7 | ) |  | (33.8 | ) |  | (29.6 | ) |
| Net cash used in financing activities | (22.6 | ) |  | (51.7 | ) |  | (41.1 | ) |
| Impact of exchange rates on cash and cash equivalents | 3.4 |  |  | (7.1 | ) |  | (6.5 | ) |
| Change in cash and cash equivalents | $ | (37.1 | ) |  | $ | 22.8 |  |  | $ | 22.4 |  |

[0000038725-18-000039:mdna:101]
Cash Flows Provided by Operating Activities

[0000038725-18-000039:mdna:102]
2017 vs. 2016

[0000038725-18-000039:mdna:103]
Net cash provided by operating activities was $66.8 million for 2017 compared to $115.4 million for 2016.  A decrease in cash provided by operations in 2017 was largely attributable to an increase in inventory. Inventory increased primarily as actual shipments were less than sales projections for 2017 as well as advance purchases of strategic inventory products.  The Company also had higher uses of cash related to payments to vendors and reduction of other accrued liabilities, primarily payments of incentive compensation

[0000038725-18-000039:mdna:104]
2016 vs. 2015

[0000038725-18-000039:mdna:105]
Net cash provided by operating activities was $115.4 million for 2016 compared to $99.6 million for 2015.  An increase in cash provided by operations in 2016 was partially attributable to large cash outflows in 2015 related to restructuring costs previously accrued at year-end 2014.  The increase in cash provided was partially offset by increased cash used during 2016 for higher receivables and inventory balances compared to year-end 2015, driven by higher sales volumes in 2016.  Finally, during 2015 the mandatory share purchase liability of $22.9 million for Pioneer was settled, resulting in a non-cash gain and reversal of certain deferred tax liabilities, also non-cash, both of which were adjustments to net income.

[0000038725-18-000039:mdna:106]
Cash Flows Used in Investing Activities

[0000038725-18-000039:mdna:107]
2017 vs. 2016

[0000038725-18-000039:mdna:108]
Net cash used in investing activities was $84.7 million in 2017 compared to $33.8 million in 2016.  The increase was almost entirely attributable to cash paid related to the Distribution acquisitions during the second quarter of 2017.  The remainder of the change was partially offset by decreased capital expenditures in the current year due to the purchase of a building in the first quarter of 2016.

[0000038725-18-000039:mdna:109]
2016 vs. 2015

[0000038725-18-000039:mdna:110]
Net cash used in investing activities was $33.8 million in 2016 compared to $29.6 million in 2015. During 2016, the Company had increased capital expenditures compared to 2015, primarily attributable to the purchase of a building in the first quarter.  Cash expended on this purchase was partially offset with proceeds realized from the sale of an idle building in Brazil which completed during the third quarter of 2016.

[0000038725-18-000039:mdna:111]
Cash Flows Used in Financing Activities

[0000038725-18-000039:mdna:112]
2017 vs. 2016

[0000038725-18-000039:mdna:113]
Net cash flows from financing activities were uses of cash of $22.6 million in 2017 compared to $51.7 million in 2016.  The decrease of cash used in financing activities was primarily attributable to decreased repayment relative to overall borrowings in the current year.

[0000038725-18-000039:mdna:114]
2016 vs. 2015

[0000038725-18-000039:mdna:115]
Net cash flows from financing activities were uses of cash of $51.7 million in 2016 compared to $41.1 million in 2015.  During 2016, the Company had net repayments of debt of about $30.4 million compared to net borrowings during 2015 of about $43.6 million, resulting in a greater use of cash.  The Company paid dividends of $19.1 million in 2016, which was up slightly from $18.9 million in 2015.  In addition, in 2015 the Company made a payment of $20.2 million for the Pioneer mandatory share purchase liability and repurchased a significant amount of the Company’s common stock, which were both large uses of cash that did not repeat in 2016.

[0000038725-18-000039:mdna:116]
AGGREGATE CONTRACTUAL OBLIGATIONS

[0000038725-18-000039:mdna:117]
The majority of the Company’s contractual obligations to third parties relate to debt obligations.  In addition, the Company has certain contractual obligations for future lease payments and purchase obligations.  The payment schedule for these contractual obligations is as follows:

[0000038725-18-000039:mdna:118]
| (In millions) |  |  |  |  |  |  |  |  | More than |
|  | Total |  | 2018 |  | 2019-2020 |  | 2021-2022 |  | 5 years |
| Debt | $ | 226.3 |  |  | $ | 100.4 |  |  | $ | 32.6 |  |  | $ | 2.5 |  |  | $ | 90.8 |  |
| Debt interest | 26.8 |  |  | 5.7 |  |  | 6.8 |  |  | 5.7 |  |  | 8.6 |  |
| Capital leases | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |
| Operating leases | 37.2 |  |  | 12.0 |  |  | 15.0 |  |  | 7.9 |  |  | 2.3 |  |
| Purchase obligations | 5.9 |  |  | 5.9 |  |  | — |  |  | — |  |  | — |  |
| Income Taxes-U.S. Tax Cuts and Jobs Act transition tax | $ | 18.9 |  |  | $ | 1.5 |  |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 11.4 |  |
|  | $ | 315.2 |  |  | $ | 125.6 |  |  | $ | 57.4 |  |  | $ | 19.1 |  |  | $ | 113.1 |  |

[0000038725-18-000039:mdna:119]
The Company has pension and other post-retirement benefit obligations not included in the table above which will result in estimated future payments of approximately $4 million in 2018.  The Company also has unrecognized tax benefits, none of which are included in the table above.  The unrecognized tax benefits of approximately $1.3 million have been recorded as liabilities and the Company is uncertain as to if or when such amounts may be settled.  Related to the unrecognized tax benefits, the Company has also recorded a liability for potential penalties and interest of $0.6 million.

[0000038725-18-000039:mdna:120]
ACCOUNTING PRONOUNCEMENTS

[0000038725-18-000039:mdna:121]
Accounting Standards Issued But Not Yet Adopted

[0000038725-18-000039:mdna:122]
In February 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-02: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The ASU is effective for interim and annual periods beginning after December 15, 2018, with early adoption permitted, and may be applied either at the beginning of the period of adoption or retrospectively to each period in which the effect of the change in the U.S. federal corporate income tax rate in the Tax Act is recognized. The Company is currently assessing the impact of the ASU on the Company’s consolidated financial statements and the notes to the financial statements.

[0000038725-18-000039:mdna:123]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2017-07, Compensation - Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  This ASU requires entities to present only the service cost component of net periodic benefit cost as an operating expense (consistent with the presentation of other employee compensation costs).  The other components of net periodic benefit cost are to be presented as a non-operating expense.  The ASU is effective on a retrospective basis for interim and annual periods beginning after December 15, 2017.  Early adoption is permitted as of the beginning of any annual period for which an entity’s financial statements have not been issued or made available for issuance.  The Company plans to adopt the ASU in the first quarter ending March 31, 2018 and does not expect the adoption to have a material impact on the Company’s consolidated financial position, results of operations, or cash flows.

[0000038725-18-000039:mdna:124]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit’s fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company’s consolidated financial position, results of operations, or cash flows.

[0000038725-18-000039:mdna:125]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification (“ASC”) Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company has

[0000038725-18-000039:mdna:126]
begun the evaluation process for the adoption of the ASU, and anticipates that the majority of the Company’s outstanding operating leases would be recognized as right-of-use assets and lease liabilities upon adoption, resulting in a material impact to the Company’s consolidated balance sheets. The impact of this ASU is non-cash in nature and will not affect the Company’s cash position.  The impact to the Company’s results of operations is still being evaluated.

[0000038725-18-000039:mdna:127]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) as modified by subsequently issued ASUs 2015-14, 2016-08, 2016-10, 2016-12 and 2016-20 (collectively ASU 2014-09).  Topic 606 supersedes the revenue recognition requirements in Accounting Standards Codification (“ASC”) Topic 605, Revenue Recognition (“Topic 605”), and requires the recognition of revenue when promised goods or services are transferred to customers in an amount that reflects the considerations to which the entity expects to be entitled to in exchange for those goods or services.The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method).  The Company will adopt the standard effective January 1, 2018 utilizing the modified retrospective approach method of transition.The Company utilized questionnaires, reviewed contracts, and assessed revenue streams that may be impacted from the adoption of this ASU.  From this analysis, the Company concluded that a significant majority of the Company’s revenues are not subject to the new guidance, accordingly the adoption of ASU 2014-09 is not expected to have a material impact on the Company’s consolidated financial position, results of operations, equity or cash flows as of the adoption date.  The Company will continue to monitor revenue recognition processes after the adoption of the ASU.

[0000038725-18-000039:mdna:128]
CRITICAL ACCOUNTING ESTIMATES

[0000038725-18-000039:mdna:129]
Management’s discussion and analysis of its financial condition and results of operations are based upon the Company’s consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires management to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and the related disclosure of contingent assets and liabilities.  Management evaluates estimates on an ongoing basis.  Estimates are based on historical experience and on other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions.  There were no material changes to estimates or methodologies used to develop those estimates in 2017.

[0000038725-18-000039:mdna:130]
The Company’s critical accounting estimates are identified below:

[0000038725-18-000039:mdna:131]
Inventory Valuation

[0000038725-18-000039:mdna:132]
The Company uses certain estimates and judgments to value inventory. Inventory is recorded at the lower of cost or market. The Company reviews its inventories for excess or obsolete products or components. Based on an analysis of historical usage, management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts, carrying values are adjusted.  The carrying value is reduced regularly to reflect the age and current anticipated product demand. If actual demand differs from the estimates, additional reductions would be necessary in the period such determination is made.  Excess and obsolete inventory is periodically disposed of through sale to third parties, scrapping, or other means.

[0000038725-18-000039:mdna:133]
Business Combinations

[0000038725-18-000039:mdna:134]
The Company follows the guidance under FASB Accounting Standards Codification (“ASC”) Topic 805, Business Combinations.  The acquisition purchase price is allocated to the assets acquired and liabilities assumed based upon their respective fair values.  The Company shall report in its financial statements provisional amounts for the items for which accounting is incomplete.  Goodwill is adjusted for any changes to provisional amounts made within the measurement period.  The Company utilizes management estimates and an independent third-party valuation firm to assist in determining the fair values of assets acquired and liabilities assumed.  Such estimates and valuations require the Company to make significant assumptions, including projections of future events and operating performance.  The Company has not made any material changes to the method of valuing fair values of assets acquired and liabilities assumed during the last three years.

[0000038725-18-000039:mdna:135]
Trade Names and Goodwill

[0000038725-18-000039:mdna:136]
According to FASB ASC Topic 350, Intangibles - Goodwill and Other, intangible assets with indefinite lives must be tested for impairment at least annually or more frequently as warranted by triggering events that indicate potential impairment.  The Company uses a variety of methodologies in conducting impairment assessments including income and market approaches.  For indefinite-lived assets apart from goodwill, primarily trade names for the Company, if the fair value is less than the carrying amount, an impairment charge is recognized in an amount equal to that excess.  The Company has not made any material changes to the method of evaluating impairments during the last three years.

[0000038725-18-000039:mdna:137]
In compliance with FASB ASC Topic 350, goodwill is not amortized. Goodwill is tested at the reporting unit level for impairment annually or more frequently as warranted by triggering events that indicate potential impairment.  Reporting units are operating segments or one level below, known as components, which can be aggregated for testing purposes.  The Company’s goodwill is allocated to the North America Water Systems, International Water, and Fueling Systems units, as components within the North America Water Systems and International Water reporting units can be aggregated.  In 2017, as a result of the Headwater acquisition, the Company added a Distribution reporting unit. The Distribution reporting unit was subject to qualitative testing in the year of acquisition.  Starting in 2018 the Distribution reporting unit will be tested in conjunction with the other reporting units using quantitative assessments.  As the Company’s business model evolves, management will continue to evaluate its reporting units and review the aggregation criteria.

[0000038725-18-000039:mdna:138]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the market value and income approaches. The market value approach compares the reporting units’ current and projected financial results to entities of similar size and industry to determine the market value of the reporting unit. The income approach utilizes assumptions regarding estimated future cash flows and other factors to determine the fair value of the respective assets. These cash flows consider factors regarding expected future operating income and historical trends, as well as the effects of demand and competition. The Company may be required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units is below their associated carrying values. Goodwill included on the balance sheet as of the fiscal year ended 2017 was $236.8 million.

[0000038725-18-000039:mdna:139]
During the fourth quarter of 2017, the Company completed its annual impairment test of goodwill and tradenames and determined the fair value of all intangibles were substantially in excess of the respective carrying values.  Significant judgment is required to determine if an indication of impairment has taken place.  Factors to be considered include the following: adverse changes in operating results, decline in strategic business plans, significantly lower future cash flows, and sustainable declines in market data such as market capitalization.  A 10 percent decrease in the fair value estimates used in the impairment test would not have changed this determination.  The sensitivity analysis required the use of numerous subjective assumptions, which, if actual experience varies, could result in material differences in the requirements for impairment charges.  Further, an extended downturn in the economy may impact certain components of the operating segments more significantly and could result in changes to the aggregation assumptions and impairment determination.

[0000038725-18-000039:mdna:140]
Income Taxes

[0000038725-18-000039:mdna:141]
Under the requirements of FASB ASC Topic 740, Income Taxes, the Company records deferred tax assets and liabilities for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company analyzes the deferred tax assets and liabilities for their future realization based on the estimated existence of sufficient taxable income.  This analysis considers the following sources of taxable income: prior year taxable income, future reversals of existing taxable temporary differences, future taxable income exclusive of reversing temporary differences and tax planning strategies that would generate taxable income in the relevant period.  If sufficient taxable income is not projected then the Company will record a valuation allowance against the relevant deferred tax assets.

[0000038725-18-000039:mdna:142]
The Company’s operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions.  These jurisdictions have different tax rates, and the Company determines the allocation of income to each of these jurisdictions based upon various estimates and assumptions. In the normal course of business, the Company will undergo tax audits by various tax jurisdictions. Such audits often require an extended period of time to complete and may result in income tax adjustments if changes to the allocation are required between jurisdictions with different tax rates.  The final taxes paid are dependent upon many factors, including negotiations with taxing authorities in the various jurisdictions and resolution of disputes arising from federal, state, and international tax audits.  Although the Company has recorded all income tax uncertainties in accordance with FASB ASC Topic 740, these accruals represent estimates that are subject to the inherent uncertainties associated with the tax audit process, and therefore include uncertainties.  Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, which, if actual experience varies, could result in material adjustments to tax expense and/or deferred tax assets and liabilities.

[0000038725-18-000039:mdna:143]
Pension and Employee Benefit Obligations

[0000038725-18-000039:mdna:144]
The Company consults with its actuaries to assist with the calculation of discount rates used in its pension and post retirement plans.  Beginning in 2016, the discount rates used to determine domestic pension and post-retirement plan liabilities are calculated using a full yield curve approach.  The change compared to the previous method resulted in different service and interest components of net periodic benefit cost in the 2016 fiscal year.  Historically, the Company estimated these service and interest cost components utilizing a single weighted-average discount rate derived from the yield curve used to measure the

[0000038725-18-000039:mdna:145]
benefit obligation at the beginning of the period.  The Company made this change to provide a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot yield curve rates. Market conditions have caused the weighted-average discount rate to move from 4.13 percent last year to 3.61 percent this year for the domestic pension plans and from 3.89 percent last year to 3.51 percent this year for the postretirement health and life insurance plan. A change in the discount rate selected by the Company of 25 basis points would result in a change of about $0.1 million to employee benefit expense and a change of about $4.0 million of liability.

[0000038725-18-000039:mdna:146]
The Company consults with actuaries and investment advisors in making its determination of the expected long-term rate of return on plan assets. Using input from these consultations such as long-term investment sector expected returns, the correlations and standard deviations thereof, and the plan asset allocation, the Company has assumed an expected long-term rate of return on plan assets of 6 percent as of the fiscal year ended 2017.  A change in the long-term rate of return selected by the Company of 25 basis points would result in a change of about $0.4 million of employee benefit expense.

[0000038725-18-000039:mdna:147]
According to FASB ASC 715, Compensation - Retirement Benefits, settlement accounting is triggered when lump sum payouts from a defined benefit plan exceed the sum of service cost and interest cost for the year. During 2016, one of the Company’s domestic pension plans required settlement accounting as a payout to a participant exceeded these criteria.

[0000038725-18-000039:mdna:148]
FACTORS THAT MAY AFFECT FUTURE RESULTS
