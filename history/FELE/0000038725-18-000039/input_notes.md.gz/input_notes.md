# FELE notes — 0000038725-18-000039


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000038725-18-000039:notes:1]
ACCRUED EXPENSES AND OTHER CURRENT LIABILITIES

[0000038725-18-000039:notes:2]
Accrued expenses and other current liabilities consist of:

[0000038725-18-000039:notes:3]
| (In millions) |  | 2017 |  | 2016 |
| Salaries, wages, and commissions |  | $ | 29.6 |  |  | $ | 28.4 |  |
| Product warranty costs |  | 9.5 |  |  | 8.2 |  |
| Insurance |  | 1.9 |  |  | 2.0 |  |
| Employee benefits |  | 9.1 |  |  | 7.9 |  |
| Other |  | 13.8 |  |  | 10.3 |  |
|  |  | $ | 63.9 |  |  | $ | 56.8 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000038725-18-000039:notes:4]
| FRANKLIN ELECTRIC CO., INC. |
| PROFORMA CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (in millions, except per share amounts) |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |
| As reported |  | $ | 1,124.9 |  |  | $ | 949.9 |  |
| Proforma |  | 1,184.8 |  |  | 1,144.6 |  |
| Net income: |  |  |  |  |
| As reported |  | $ | 78.2 |  |  | $ | 78.7 |  |
| Proforma |  | 79.4 |  |  | 85.0 |  |
| Basic earnings per share: |  |  |  |  |
| As reported |  | $ | 1.67 |  |  | $ | 1.67 |  |
| Proforma |  | 1.70 |  |  | 1.80 |  |
| Diluted earnings per share: |  |  |  |  |
| As reported |  | $ | 1.65 |  |  | $ | 1.65 |  |
| Proforma |  | 1.68 |  |  | 1.78 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-18-000039:notes:5]
ACQUISITIONS

[0000038725-18-000039:notes:6]
During the second quarter of 2017, the Company redeemed 10 percent of the noncontrolling interest of Impo, a Turkish subsidiary, increasing the Company’s ownership to 100 percent for approximately Turkish Lira (TRY) 17.0 million, $5.0 million at the then current exchange rate.  The 10 percent redemption value was calculated using a specified formula and resulted in a reduction of the carrying value of TRY 0.6 million ($0.2 million).  Due to the immaterial nature of the redemption, the Company has not included full year proforma statements of income for the acquisition year or previous year.

[0000038725-18-000039:notes:7]
During the second quarter of 2017, the Company acquired controlling interests in three distributors (2M Company, Inc. (“2M”), Drillers Service, Inc. (“DSI”), and Western Hydro, LLC (“Western Hydro”), collectively referred to below as the “Headwater acquisitions”) in the U.S. professional groundwater market for a combined purchase price of approximately $57.4 million, subject to certain terms and conditions.  The Company had previously prepaid a $3.0 million portion of the purchase price at the time of original investment.  The Company funded the Headwater acquisitions with cash on hand and short-term borrowings from the Company’s Revolver (see Note 11 - Debt).  The Headwater acquisitions are reported within a new “Distribution” segment (see Note 16 - Segment Information).  The Headwater acquisitions provide the Company with a robust groundwater distribution channel throughout the United States.

[0000038725-18-000039:notes:8]
The Company previously held equity interests in these entities, each of which was less than 50 percent, and accounted for by the equity method of accounting.  The Company’s total interest in each of the entities is now 100 percent and the entities are included in the Company’s consolidated results effective from the date of acquisition.  The original equity interests in the acquired entities were remeasured to their fair values as of the acquisition date (which aggregated was $20.6 million) based on the income approach, which utilized management estimates and consultation with an independent third-party valuation firm.  Inputs included an analysis of the enterprise value based on financial projections and ownership percentages.  As a result, the Company has recognized an aggregate gain on the acquisitions of $5.2 million. These gains are included in the “Other income, net” line of the Company’s consolidated statements of income.

[0000038725-18-000039:notes:9]
The preliminary identifiable intangible assets recognized due to the Headwater acquisitions were $5.7 million, and consist of customer relationships, which will be amortized utilizing the straight-line method over 15 years.  The fair value of the identifiable intangible assets has been estimated using an income approach, a valuation method that values an intangible asset by discounting the future incremental earnings that may be achieved by the subject intangible asset.

[0000038725-18-000039:notes:10]
The preliminary goodwill of $33.9 million resulting from the Headwater acquisitions consists primarily of the benefits of forward channel integration opportunities and broadened product offerings. All of the goodwill was recorded as part of the Distribution segment, and only a portion ($7.8 million) is expected to be deductible for tax purposes.

[0000038725-18-000039:notes:11]
The preliminary purchase price assigned to the major identifiable assets and liabilities for the Headwater acquisitions on an aggregated basis is as follows:

[0000038725-18-000039:notes:12]
| (In millions) |  |  |
| Cash |  | $ | 2.7 |  |
| Receivables |  | 29.9 |  |
| Inventory |  | 56.0 |  |
| Other current assets |  | 5.1 |  |
| Total current assets |  | 93.7 |  |
| Property, plant, and equipment |  | 9.8 |  |
| Intangible assets |  | 5.7 |  |
| Goodwill |  | 33.9 |  |
| Other assets |  | 0.2 |  |
| Total assets |  | 143.3 |  |
| Accounts payable |  | (19.6 | ) |
| Accrued liabilities and other current liabilities |  | (11.4 | ) |
| Current maturities of long-term debt |  | (31.6 | ) |
| Total current liabilities |  | (62.6 | ) |
| Long-term debt |  | (2.0 | ) |
| Other long-term liabilities |  | (0.7 | ) |
| Total liabilities |  | (65.3 | ) |
| Total |  | 78.0 |  |
| Less: Fair value of original equity interest |  | (20.6 | ) |
| Total purchase price |  | $ | 57.4 |  |

[0000038725-18-000039:notes:13]
The fair values of the assets acquired and liabilities assumed related to the Headwater acquisitions are provisional amounts as of December 31, 2017, pending final valuations and purchase accounting adjustments.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation process.

[0000038725-18-000039:notes:14]
The following unaudited proforma financial information for the year ended December 31, 2017 and December 31, 2016 gives effect to the Headwater acquisitions as if the acquisitions had occurred as of January 3, 2016.  These unaudited proforma condensed consolidated financial statements are prepared for informational purposes only and are not necessarily indicative of actual results or financial position that would have been achieved had the acquisitions been consummated on the dates indicated and are not necessarily indicative of future operating results or financial position of the consolidated companies.  The unaudited proforma condensed consolidated financial statements do not give effect to any cost savings or incremental costs that may result from the integration of the Headwater acquisitions.

[0000038725-18-000039:notes:15]
The Headwater entities contributed a total of $176.7 million of revenue and $1.4 million of net income to the Company’s consolidated statements of income from their acquisition dates through December 31, 2017.

[0000038725-18-000039:notes:16]
In 2012, the Company acquired a controlling interest in Pioneer Pump Holdings, Inc. (“PPH”).  Pursuant to the terms of the 2012 stock purchase agreement, the remaining 29.5 percent noncontrolling interest was recorded at $22.9 million and accounted for as a share purchase liability.  During the first quarter of 2015, the Company purchased the remaining 29.5 percent of outstanding shares of PPH for $20.2 million, increasing the Company’s ownership in PPH to 100 percent.  The purchase was considered the settlement of a financing obligation, and the resulting $2.7 million gain was recorded in the Company’s consolidated statements of income in the “Other income, net” line during the first quarter of 2015.

[0000038725-18-000039:notes:17]
Transaction costs for all acquisition related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations.  Transaction costs included in selling, general, and administrative expense in the Company’s consolidated statements of income were $0.6 million, $0.1 million, and $0.2 million for the fiscal years ended 2017, 2016, and 2015, respectively.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000038725-18-000039:notes:18]
Cash and Cash Equivalents--The Company considers cash on hand, demand deposits, and highly liquid investments with an original maturity date of three months or less to be cash and cash equivalents.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-18-000039:notes:19]
COMMITMENTS AND CONTINGENCIES

[0000038725-18-000039:notes:20]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-18-000039:notes:21]
Total rent expense charged to operations for operating leases including contingent rentals was $15.1 million, $11.7 million, and $11.9 million in 2017, 2016, and 2015, respectively.

[0000038725-18-000039:notes:22]
The future minimum rental payments for non-cancelable operating leases as of December 31, 2017, are as follows:

[0000038725-18-000039:notes:23]
| (In millions) | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Future minimum rental payments | $ | 12.0 |  |  | $ | 8.8 |  |  | $ | 6.2 |  |  | $ | 4.7 |  |  | $ | 3.2 |  |  | $ | 2.3 |  |

[0000038725-18-000039:notes:24]
At December 31, 2017, the Company had $5.9 million of commitments primarily for capital expenditures and the purchase of raw materials to be used in production.

[0000038725-18-000039:notes:25]
The changes in the carrying amount of the warranty accrual, as recorded in the “Accrued expenses and other current liabilities” line of the Company’s consolidated balance sheets for 2017 and 2016, are as follows:

[0000038725-18-000039:notes:26]
| (In millions) |  | 2017 |  | 2016 |
| Beginning balance |  | $ | 8.2 |  |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 9.5 |  |  | 5.9 |  |
| Additions related to acquisitions |  | 1.2 |  |  | — |  |
| Reductions for payments made |  | (9.4 | ) |  | (7.0 | ) |
| Ending balance |  | $ | 9.5 |  |  | $ | 8.2 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-18-000039:notes:27]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)

[0000038725-18-000039:notes:28]
Changes in accumulated other comprehensive income/(loss), net of tax, by component are summarized below:

[0000038725-18-000039:notes:29]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance, January 3, 2015 | $ | (51.8 | ) |  | $ | (56.1 | ) |  | $ | (107.9 | ) |
| Other comprehensive income/(loss) before reclassifications | (58.3 | ) |  | — |  |  | (58.3 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 4.6 |  |  | 4.6 |  |
| Net other comprehensive income/(loss) | (58.3 | ) |  | 4.6 |  |  | (53.7 | ) |
| Balance, January 2, 2016 | $ | (110.1 | ) |  | $ | (51.5 | ) |  | $ | (161.6 | ) |
| Other comprehensive income/(loss) before reclassifications | (8.3 | ) |  | — |  |  | (8.3 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | — |  |  | — |  |
| Net other comprehensive income/(loss) | (8.3 | ) |  | — |  |  | (8.3 | ) |
| Balance, December 31, 2016 | $ | (118.4 | ) |  | $ | (51.5 | ) |  | $ | (169.9 | ) |
| Other comprehensive income/(loss) before reclassifications | 18.7 |  |  | — |  |  | 18.7 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 2.2 |  |  | 2.2 |  |
| Net other comprehensive income/(loss) | 18.7 |  |  | 2.2 |  |  | 20.9 |  |
| Balance, December 31, 2017 | $ | (99.7 | ) |  | $ | (49.3 | ) |  | $ | (149.0 | ) |

[0000038725-18-000039:notes:30]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 8 for additional details) and is included in the “Selling, general, and administrative expenses” line of the Company’s consolidated statements of income.

[0000038725-18-000039:notes:31]
(2) Net of tax expense of $0.5 million, $0.5 million and $2.5 million for 2017, 2016, and 2015, respectively.

[0000038725-18-000039:notes:32]
Amounts related to noncontrolling interests were not material.


## us-gaap:ConsolidationPolicyTextBlock

[0000038725-18-000039:notes:33]
Principles of Consolidation--The consolidated financial statements include the accounts of Franklin Electric Co., Inc. and its consolidated subsidiaries.  All intercompany transactions have been eliminated.


## us-gaap:DebtDisclosureTextBlock

[0000038725-18-000039:notes:34]
DEBT

[0000038725-18-000039:notes:35]
Debt consisted of the following:

[0000038725-18-000039:notes:36]
| (In millions) |  | 2017 |  | 2016 |
| New York Life |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 67.0 |  |  | — |  |
| Prudential Agreement |  | 60.0 |  |  | 90.0 |  |
| Tax increment financing debt |  | 20.8 |  |  | 21.8 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.5 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | 226.1 |  |  | 190.2 |  |
| Less current maturities |  | (100.5 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 125.6 |  |  | $ | 156.5 |  |

[0000038725-18-000039:notes:37]
Debt outstanding at December 31, 2017, excluding unamortized debt issuance costs, matures as follows:

[0000038725-18-000039:notes:38]
| (In millions) |  | Total |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |
| Debt |  | $ | 226.3 |  |  | $ | 100.4 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 90.8 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 226.4 |  |  | $ | 100.5 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 90.8 |  |

[0000038725-18-000039:notes:39]
New York Life

[0000038725-18-000039:notes:40]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the “New York Life Agreement”) for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025.  These senior notes have a floating interest rate of one-month USD LIBOR (1.55 percent as of December 31, 2017) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  On October 28, 2016, the Company entered into the First Amendment to Note Purchase and Private Shelf Agreement.  The Amendment was intended to make the covenants within the New York Life Agreement consistent with the covenants that were modified in the Third Amended and Restated Credit Agreement (the “Credit Agreement”).  As of December 31, 2017, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-18-000039:notes:41]
Project Bonds

[0000038725-18-000039:notes:42]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement.  Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).”  The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million.  The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (“Tax increment financing debt”) bear interest at 3.6 percent per annum.  Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.  The use of the proceeds from the Project Notes was limited to assist the financing of the new Global Corporate Headquarters and Engineering Center.  On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-18-000039:notes:43]
Prudential Agreement

[0000038725-18-000039:notes:44]
On April 9, 2007, the Company entered into the Amended and Restated Note Purchase and Private Shelf Agreement (the “Prudential Agreement”) in the amount of $175.0 million.  Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”).  The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had at issuance an average life of 10 years with a final maturity in 2019.  On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million.  On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Agreement.  On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015.  On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement.   This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million.  On October 28, 2016, the Company entered into Amendment No. 1 to the Third Amended and Restated Note Purchase and Private Shelf Agreement.  This amendment was intended to make the covenants within the Prudential Agreement consistent with the covenants that were modified in the Credit Agreement (below).  As of December 31, 2017, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.

[0000038725-18-000039:notes:45]
Credit Agreement

[0000038725-18-000039:notes:46]
On October 28, 2016, the Company entered into the Third Amended and Restated Credit Agreement (the “Credit Agreement”). The Credit Agreement extended the maturity date of the Company’s previous credit agreement to October 28, 2021 and increased the commitment amount from $150.0 million to $300.0 million.  The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million) subject to the conditions contained therein. All of the Company’s present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers’ obligations under and in connection with the Credit Agreement. Additionally, the Company unconditionally guaranties all of the obligations of Franklin Electric B.V. under the Credit Agreement.  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company’s leverage ratio) of the aggregate commitment, payable quarterly in arrears. Borrowings may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company’s leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-18-000039:notes:47]
As of December 31, 2017, the Company had $67.0 million outstanding borrowings, $5.5 million in letters of credit outstanding, and $227.5 million of available capacity under the Credit Agreement.  As of December 31, 2016, the Company had no outstanding borrowings, $5.9 million in letters of credit outstanding, and $294.1 million of available capacity under the Credit Agreement.

[0000038725-18-000039:notes:48]
Covenants

[0000038725-18-000039:notes:49]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 (using net debt in the measure of leverage ratio, whereas the previous credit agreement used gross debt) and a minimum interest coverage ratio of 3.00 to 1.00 (using EBITDA in the measure, whereas the previous credit agreement used EBIT). Cross default is applicable with the Credit Agreement, the Prudential Agreement, the Project Bonds, and the New York Life Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million.  The Company was in compliance with all financial covenants as of December 31, 2017.


## us-gaap:DefinedContributionPlanDisclosuresTableTextBlock

[0000038725-18-000039:notes:50]
The following table sets forth Company contributions to the defined contribution plans:

[0000038725-18-000039:notes:51]
| (In millions) |  | 2017 |  | 2016 |  | 2015 |
| Company contributions to the plans |  | $ | 6.7 |  |  | $ | 5.9 |  |  | $ | 5.9 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-18-000039:notes:52]
FINANCIAL INSTRUMENTS

[0000038725-18-000039:notes:53]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements (“the swap”) to mitigate the Company’s exposure to these fluctuations in the Company’s stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  As of December 31, 2017, the swap has a notional value based on 215,000 shares.  For the years ended December 31, 2017, December 31, 2016, and January 2, 2016, the swap resulted in a gain of $1.4 million, a gain of $2.2 million, and a loss of $2.0 million, respectively.  Gains and losses resulting from the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company’s consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-18-000039:notes:54]
SHARE-BASED COMPENSATION

[0000038725-18-000039:notes:55]
Effective May 5, 2017, the shareholders of the Company approved the Franklin Electric Co., Inc. 2017 Stock Plan (the “2017 Stock Plan”).  The Board of Directors had previously approved the 2017 Stock Plan on March 15, 2017 subject to shareholder approval.  The 2017 Stock Plan was enacted in addition to the previously approved 2009 and 2012 Stock Plans and is a share-based compensation plan that provides for discretionary grants of stock options, stock awards, stock unit awards, and stock appreciation rights (“SARs”) to key employees and non-employee directors.  The number of shares that may be issued under the 2017 Stock Plan is 1,400,000.  Stock options and SARs reduce the number of available shares by one share for each share subject to the option or SAR, and stock awards and stock unit awards settled in shares reduce the number of available shares by 1.5 shares for every one share delivered.  No awards have been issued under the 2017 Stock Plan.

[0000038725-18-000039:notes:56]
The Company also maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the “2012 Stock Plan”), which is a share-based compensation plan that provides for discretionary grants of stock options, stock awards and stock unit awards to key employees and non-employee directors.

[0000038725-18-000039:notes:57]
The 2012 Stock Plan authorized 2,400,000 shares for issuance as follows:

[0000038725-18-000039:notes:58]
| 2012 Stock Plan |  | Authorized Shares |
| Stock Options |  | 1,680,000 |
| Stock/Stock Unit Awards |  | 720,000 |

[0000038725-18-000039:notes:59]
The Company also maintains the Amended and Restated Franklin Electric Co., Inc. Stock Plan (the “2009 Stock Plan”) which, as amended in 2009, provided for discretionary grants of stock options and stock awards.  The 2009 Stock Plan authorized 4,400,000 shares for issuance as follows:

[0000038725-18-000039:notes:60]
| 2009 Stock Plan | Authorized Shares |
| Stock Options | 3,200,000 |
| Stock Awards | 1,200,000 |

[0000038725-18-000039:notes:61]
All options in the 2009 Stock Plan have been awarded.

[0000038725-18-000039:notes:62]
The Company currently issues new shares from its common stock balance to satisfy option exercises and the settlement of stock awards and stock unit awards made under the 2009 Stock Plan and/or the 2012 Stock Plan.

[0000038725-18-000039:notes:63]
The total share-based compensation expense recognized in 2017, 2016, and 2015 was $7.1 million, $6.9 million, and $5.6 million, respectively.

[0000038725-18-000039:notes:64]
Stock Options:

[0000038725-18-000039:notes:65]
Under the above plans, the exercise price of each option equals the market price of the Company’s common stock on the date of grant, and the options expire 10 years after the date of the grant.  Options granted to employees vest at 25 percent a year and become fully vested and fully exercisable after 4 years (vesting is accelerated upon retirement, death, or disability).  Subject to the terms of the plans, in general, the aggregate option exercise price and any applicable tax withholdings may be satisfied in cash or its equivalent, by the plan participant’s delivery of shares of the Company’s common stock having a fair market value at the time of exercise equal to the aggregate option exercise price and/or the applicable tax withholdings or by having shares otherwise subject to the award withheld by the Company or via cashless exercise through a broker-dealer.

[0000038725-18-000039:notes:66]
The fair value of each option award is estimated on the date of grant using the Black-Scholes option valuation model with a single approach and amortized using a straight-line attribution method over the option’s vesting period.  Options granted to retirement eligible employees are immediately expensed.  The Company uses historical data to estimate the expected volatility of its stock, the weighted average expected life, the period of time options granted are expected to be outstanding, and its dividend yield.  The risk-free rates for periods within the contractual life of the option are based on the U.S. Treasury yield curve in effect at the time of the grant.

[0000038725-18-000039:notes:67]
The table below provides the weighted average grant-date fair values and key assumptions used for the Black-Scholes model to determine the fair value of options granted during 2017, 2016, and 2015:

[0000038725-18-000039:notes:68]
|  |  | 2017 |  | 2016 |  | 2015 |
| Risk-free interest rate |  | 1.89 | % |  | 1.21 | % |  | 1.59 | % |
| Dividend yield |  | 0.94 | % |  | 1.32 | % |  | 0.95 | % |
| Volatility factor |  | 31.19 | % |  | 37.70 | % |  | 37.90 | % |
| Expected term |  | 5.5 years |  |  | 5.5 years |  |  | 5.5 years |  |
| Weighted average grant-date fair value of options |  | $ | 12.30 |  |  | $ | 9.18 |  |  | $ | 12.34 |  |

[0000038725-18-000039:notes:69]
A summary of the Company’s outstanding stock option activity and related information is as follows:

[0000038725-18-000039:notes:70]
| (Shares in thousands) |  |  |  |  |  |  |  |  |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | AggregateIntrinsic Value (000’s) |
| Outstanding at beginning of 2017 |  | 1,455 |  |  | $ | 25.02 |  |  |  |  |  |
| Granted |  | 192 |  |  | 42.49 |  |  |  |  |  |
| Exercised |  | (256 | ) |  | 17.56 |  |  |  |  |  |
| Forfeited |  | (2 | ) |  | 35.99 |  |  |  |  |  |
| Expired |  | (1 | ) |  | 43.27 |  |  |  |  |  |
| Outstanding at end of 2017 |  | 1,388 |  |  | $ | 28.79 |  |  | 5.46 years |  | $ | 23,756 |  |
| Expected to vest after applying forfeiture rate |  | 1,371 |  |  | $ | 28.69 |  |  | 5.42 years |  | $ | 23,600 |  |
| Vested and exercisable at end of period |  | 903 |  |  | $ | 24.73 |  |  | 4.08 years |  | $ | 19,119 |  |

[0000038725-18-000039:notes:71]
| (In millions) |  | 2017 |  | 2016 |  | 2015 |
| Intrinsic value of options exercised |  | $ | 6.2 |  |  | $ | 5.2 |  |  | $ | 1.7 |  |
| Cash received from the exercise of options |  | 4.5 |  |  | 5.2 |  |  | 2.0 |  |
| Fair value of shares vested |  | 2.1 |  |  | 1.7 |  |  | 1.4 |  |
| Tax benefit of options exercised |  | 2.1 |  |  | 1.9 |  |  | 0.7 |  |

[0000038725-18-000039:notes:72]
As of December 31, 2017, there was $1.6 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 1.83 years.

[0000038725-18-000039:notes:73]
Stock/Stock Unit Awards:

[0000038725-18-000039:notes:74]
Under the 2009 Stock Plan, non-employee directors and employees may be granted stock awards.  Under the 2012 Stock Plan and the 2017 Stock Plan, non-employee directors and employees may be granted stock awards and stock units.

[0000038725-18-000039:notes:75]
Stock awards to non-employee directors are generally fully vested when made.  Stock/stock unit awards to employees cliff vest over 3 or 4 years (subject to accelerated vesting of a pro rata portion in the case of retirement, death or disability) and may be contingent on the attainment of certain performance goals.  Dividends are paid to the recipient prior to vesting, except that dividends on performance-based stock awards under the 2012 Stock Plan and the 2017 Stock Plan will be paid only to the extent the performance goals are met.

[0000038725-18-000039:notes:76]
Stock/stock unit awards granted to retirement eligible employees are expensed over the vesting period.  Compensation cost for the performance stock/stock unit awards is accrued based on the probable outcome of specified performance conditions.

[0000038725-18-000039:notes:77]
A summary of the Company’s restricted stock/stock unit award activity and related information is as follows:

[0000038725-18-000039:notes:78]
| (Shares in thousands) |  |  |  |  |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of 2017 |  | 473 |  |  | $ | 34.89 |  |
| Awarded |  | 136 |  |  | 42.23 |  |
| Vested |  | (109 | ) |  | 35.81 |  |
| Forfeited |  | (37 | ) |  | 36.51 |  |
| Non-vested at end of 2017 |  | 463 |  |  | $ | 36.71 |  |

[0000038725-18-000039:notes:79]
The weighted-average grant date fair value of restricted stock/stock unit awards granted in 2017, 2016, and 2015, is $42.23, $29.45, and $36.27, respectively.

[0000038725-18-000039:notes:80]
As of December 31, 2017, there was $8.9 million of total unrecognized compensation cost related to non-vested stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.14 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000038725-18-000039:notes:81]
Earnings Per Common Share--Basic and diluted earnings per share are computed and disclosed in accordance with FASB ASC Topic 260, Earnings Per Share.  The Company utilizes the two-class method to compute earnings available to common shareholders.  Under the two-class method, earnings are adjusted by accretion amounts to redeemable noncontrolling interests recorded at redemption value.  The adjustments represent dividend distributions, in substance, to the noncontrolling interest holder as the holders have contractual rights to receive an amount upon redemption other than the fair value of the applicable shares.  As a result, earnings are adjusted to reflect this in substance distribution that is different from other common shareholders.  In addition, the Company allocates net earnings to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company’s participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.  Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.


## us-gaap:EarningsPerShareTextBlock

[0000038725-18-000039:notes:82]
EARNINGS PER SHARE

[0000038725-18-000039:notes:83]
The Company calculates basic and diluted earnings per common share using the two-class method.  Under the two-class method, net earnings are allocated to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company’s participating securities consist of share-based payment awards that contain a nonforfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.

[0000038725-18-000039:notes:84]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-18-000039:notes:85]
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-18-000039:notes:86]
| (In millions, except per share amounts) |  | 2017 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. |  | $ | 78.2 |  |  | $ | 78.7 |  |  | $ | 72.9 |  |
| Less: Undistributed earnings allocated to participating securities |  | 0.6 |  |  | 0.7 |  |  | 0.7 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest |  | — |  |  | 1.0 |  |  | 0.8 |  |
| Net income available to common shareholders |  | $ | 77.6 |  |  | $ | 77.0 |  |  | $ | 71.4 |  |
| Denominator: |  |  |  |  |  |  |
| Basic weighted average common shares outstanding |  | 46.5 |  |  | 46.2 |  |  | 47.1 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Diluted weighted average common shares outstanding |  | 47.0 |  |  | 46.7 |  |  | 47.6 |  |
| Basic earnings per share |  | $ | 1.67 |  |  | $ | 1.67 |  |  | $ | 1.52 |  |
| Diluted earnings per share |  | $ | 1.65 |  |  | $ | 1.65 |  |  | $ | 1.50 |  |

[0000038725-18-000039:notes:87]
There were 0.3 million, 0.4 million, and 0.3 million stock options outstanding as of 2017, 2016, and 2015, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000038725-18-000039:notes:88]
OTHER ASSETS

[0000038725-18-000039:notes:89]
Through the second quarter of 2017, the Company held equity interests in the acquired companies identified in Note 3 - Acquisitions for various strategic purposes.  The investments were accounted for under the equity method and were included in “Other assets” on the Company’s consolidated balance sheet.  The carrying amount of the investments were adjusted for the Company’s proportionate share of earnings, losses, and dividends.  The investments were not considered material to the Company’s financial position, either individually or in the aggregate.  During the second quarter of 2017, the remaining interests of these equity method investments were purchased (see Note 3 - Acquisitions), bringing total ownership of these entities to 100 percent.  As of December 31, 2017, there were no equity method investments recorded on the Company’s consolidated balance sheet.  Prior to the purchase of the remaining interests, the Company’s proportionate share of earnings from its equity interests, were included in the “Other income, net” line of the Company’s consolidated statements of income. The amounts were immaterial for the years ended December 31, 2017,  December 31, 2016, and January 2, 2016, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-18-000039:notes:90]
As of December 31, 2017 and December 31, 2016, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-18-000039:notes:91]
| (In millions) |  | December 31, 2017 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | — |  |  |
|  |  | December 31, 2016 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 3.6 |  |  | $ | 3.6 |  |  | $ | — |  |  | $ | — |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-18-000039:notes:92]
FAIR VALUE MEASUREMENTS

[0000038725-18-000039:notes:93]
The Company’s Level 1 assets consist of cash equivalents which are generally comprised of foreign bank guaranteed certificates of deposit.

[0000038725-18-000039:notes:94]
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3.

[0000038725-18-000039:notes:95]
Total debt, including current maturities, have carrying amounts of $226.0 million at December 31, 2017 and $190.2 million at December 31, 2016.  The estimated fair value of all debt was $230 million and $195 million at December 31, 2017 and December 31, 2016, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000038725-18-000039:notes:96]
Translation of Foreign Currency Financial Statements--All assets and liabilities of foreign subsidiaries in functional currency other than the U.S. dollar are translated at year end exchange rates.  All revenue and expense accounts are translated at average rates in effect during the respective period.  Adjustments for translating longer term foreign currency assets and liabilities in U.S. dollars are included as a component of other comprehensive income.  Transaction gains and losses that arise from shorter term exchange rate fluctuations are included in the “Foreign exchange income/(expense)” line within the Company’s consolidated statements of income, as incurred.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-18-000039:notes:97]
GOODWILL AND OTHER INTANGIBLE ASSETS

[0000038725-18-000039:notes:98]
The carrying amounts of the Company’s intangible assets are as follows:

[0000038725-18-000039:notes:99]
| (In millions) |  | 2017 |  | 2016 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.7 | ) |  | $ | 7.4 |  |  | $ | (6.4 | ) |
| Technology |  | 7.5 |  |  | (5.8 | ) |  | 7.5 |  |  | (5.3 | ) |
| Customer relationships |  | 138.9 |  |  | (57.6 | ) |  | 133.4 |  |  | (49.6 | ) |
| Other |  | 2.9 |  |  | (2.4 | ) |  | 2.7 |  |  | (2.1 | ) |
| Total |  | $ | 156.8 |  |  | $ | (72.5 | ) |  | $ | 151.0 |  |  | $ | (63.4 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 47.2 |  |  | — |  |  | 47.1 |  |  | — |  |
| Total intangibles |  | $ | 204.0 |  |  | $ | (72.5 | ) |  | $ | 198.1 |  |  | $ | (63.4 | ) |

[0000038725-18-000039:notes:100]
Amortization expense related to intangible assets for fiscal years 2017, 2016, and 2015, was $8.6 million, $8.4 million, and $8.6 million, respectively.

[0000038725-18-000039:notes:101]
Amortization expense for each of the five succeeding years is projected as follows:

[0000038725-18-000039:notes:102]
| (In millions) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |
|  |  | $ | 8.7 |  |  | $ | 8.6 |  |  | $ | 8.4 |  |  | $ | 8.1 |  |  | $ | 7.9 |  |

[0000038725-18-000039:notes:103]
The change in the carrying amount of goodwill by reportable segment for 2017 and 2016, is as follows:

[0000038725-18-000039:notes:104]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of January 2, 2016 |  | $ | 136.8 |  |  | $ | 63.0 |  |  | $ | — |  |  | $ | 199.8 |  |
| Acquisitions |  | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Foreign currency translation |  | (0.5 | ) |  | (0.5 | ) |  | — |  |  | (1.0 | ) |
| Balance as of December 31, 2016 |  | $ | 136.3 |  |  | $ | 63.3 |  |  | $ | — |  |  | $ | 199.6 |  |
| Acquisitions |  | — |  |  | — |  |  | 33.9 |  |  | 33.9 |  |
| Foreign currency translation |  | 3.0 |  |  | 0.3 |  |  | — |  |  | 3.3 |  |
| Balance as of December 31, 2017 |  | $ | 139.3 |  |  | $ | 63.6 |  |  | 33.9 |  |  | $ | 236.8 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000038725-18-000039:notes:105]
Goodwill and Other Intangible Assets--Goodwill is tested at the reporting unit level, which the Company has determined to be the North America Water Systems, International Water, Fueling Systems, and Distribution units.  In compliance with FASB ASC Topic 350, Intangibles - Goodwill and Other, the Company has evaluated the aggregation criteria and determined that the individual components within the North America Water Systems and International Water reporting units, respectively, can be aggregated in 2017.

[0000038725-18-000039:notes:106]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the income and market valuation approaches.  The income approach estimates fair value based upon future revenue, expenses, and cash flows discounted to present value.  The market valuation approach estimates fair value using market multipliers of various financial measures compared to a set of comparable public companies.  The fair value calculated for each reporting unit is considered a Level 3 measurement within the fair value hierarchy.

[0000038725-18-000039:notes:107]
An indication of impairment exists if the carrying value of the reporting unit is higher than its fair value, as determined by the above approach.  The second step of testing as outlined in FASB ASC Topic 350 must be performed to measure the amount of impairment loss.  The amount of impairment is determined by comparing the implied fair value of the reporting unit’s goodwill to its carrying value in the same manner as if the reporting units were being acquired in a business combination.  The Company would allocate the fair value to all of the reporting unit’s assets and liabilities, including any unrecognized intangible assets, in a hypothetical analysis that would calculate the implied fair value of goodwill.  The Company would record an impairment charge for the difference between the implied fair value of goodwill and the recorded goodwill.

[0000038725-18-000039:notes:108]
Beginning in 2017, the Company completed its annual goodwill impairment test during the fourth quarter, using balances as of October 1. Additionally, in 2017 as a result of the Headwater acquisitions, the Company added the Distribution reporting unit. The Distribution reporting unit was subject to qualitative testing in the year of acquisition.  The Company did not recognize a goodwill impairment as a result of the qualitative assessment. Beginning in 2018, the Distribution reporting unit will be tested in conjunction with the other reporting units using a quantitative assessment. The Company will test goodwill for impairment more frequently if warranted by triggering events that indicate potential impairment.

[0000038725-18-000039:notes:109]
The Company also tests indefinite lived intangible assets, primarily trade names, for impairment on an annual basis during the fourth quarter of each year, or more frequently as warranted by triggering events that indicate potential impairment.  In assessing the recoverability of the trade names, the Company determines the fair value using an income approach.  The income approach estimates fair value based upon future revenue and estimated royalty rates.  The fair value calculated for indefinite lived intangible assets is considered a Level 3 measurement within the fair value hierarchy.  An indication of impairment exists if the carrying value of the trade names is higher than the fair value.  The Company would record an impairment charge for the difference.

[0000038725-18-000039:notes:110]
Amortization is recorded and calculated for other definite lived intangible assets on a basis that reflects cash flows over the estimated useful lives.  The weighted average number of years over which each intangible class is amortized is as follows:

[0000038725-18-000039:notes:111]
| Patents | 17 years |
| Technology | 15 years |
| Customer relationships | 13-20 years |
| Other | 5-8 years |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-18-000039:notes:112]
INCOME TAXES

[0000038725-18-000039:notes:113]
Income before income taxes consisted of the following:

[0000038725-18-000039:notes:114]
| (In millions) |  | 2017 |  | 2016 |  | 2015 |
| Domestic |  | $ | 47.1 |  |  | $ | 45.4 |  |  | $ | 23.6 |  |
| Foreign |  | 57.5 |  |  | 58.7 |  |  | 62.7 |  |
|  |  | $ | 104.6 |  |  | $ | 104.1 |  |  | $ | 86.3 |  |

[0000038725-18-000039:notes:115]
The income tax provision/(benefit) from continuing operations consisted of the following:

[0000038725-18-000039:notes:116]
| (In millions) |  | 2017 |  | 2016 |  | 2015 |
| Current: |  |  |  |  |  |  |
| Federal |  | $ | 29.7 |  |  | $ | 9.6 |  |  | $ | 1.2 |  |
| Foreign |  | 10.2 |  |  | 11.4 |  |  | 17.4 |  |
| State |  | 1.1 |  |  | 0.8 |  |  | 0.8 |  |
| Total current |  | 41.0 |  |  | 21.8 |  |  | 19.4 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Federal |  | (10.7 | ) |  | 2.9 |  |  | (1.8 | ) |
| Foreign |  | (4.5 | ) |  | (1.0 | ) |  | (4.0 | ) |
| State |  | 0.2 |  |  | 1.1 |  |  | (1.0 | ) |
| Total deferred |  | $ | (15.0 | ) |  | $ | 3.0 |  |  | $ | (6.8 | ) |
|  |  | $ | 26.0 |  |  | $ | 24.8 |  |  | $ | 12.6 |  |

[0000038725-18-000039:notes:117]
A reconciliation of the tax provision for continuing operations at the U.S. statutory rate to the effective income tax expense rate as reported is as follows:

[0000038725-18-000039:notes:118]
|  |  | 2017 |  | 2016 |  | 2015 |
| U.S. Federal statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State income taxes, net of federal benefit |  | 1.0 |  |  | (0.3 | ) |  | (0.3 | ) |
| Foreign operations |  | (10.2 | ) |  | (8.4 | ) |  | (13.1 | ) |
| R&D tax credits |  | (0.9 | ) |  | (0.6 | ) |  | (1.0 | ) |
| Uncertain tax position adjustments |  | (0.5 | ) |  | (2.5 | ) |  | (1.5 | ) |
| Deferred tax adjustments - restructuring and rate adjustments |  | (1.2 | ) |  | 0.3 |  |  | 1.1 |  |
| Valuation allowance on state and foreign deferred tax |  | (1.2 | ) |  | 2.4 |  |  | 4.1 |  |
| Purchase of noncontrolling interest |  | (2.3 | ) |  | — |  |  | (9.4 | ) |
| Share-based compensation |  | (1.9 | ) |  | (1.1 | ) |  | — |  |
| Realized foreign currency loss |  | (1.5 | ) |  | — |  |  | — |  |
| Other items |  | (1.3 | ) |  | (1.0 | ) |  | (0.3 | ) |
| Impact of the Tax Act |  |  |  |  |  |  |
| Transition tax |  | 18.1 |  |  | — |  |  | — |  |
| Deferred tax effects |  | (8.3 | ) |  | — |  |  | — |  |
| Effective tax rate |  | 24.8 | % |  | 23.8 | % |  | 14.6 | % |

[0000038725-18-000039:notes:119]
The effective tax rate continues to be lower than the statutory rate of 35 percent primarily due to foreign earnings taxed at rates below the U.S. statutory rate, offset by the recognition of the impact of the U.S. Tax Cuts and Jobs Act in 2017, further reduced by U.S. tax incentives, and certain discrete events.

[0000038725-18-000039:notes:120]
The U.S. Tax Cuts and Jobs Act (Tax Act) was enacted on December 22, 2017 and introduces significant changes to U.S. income tax law. Effective in 2018, the Tax Act reduces the U.S. statutory tax rate from 35 percent to 21 percent and creates new incentives on U.S. based foreign exports, referred to as Foreign Derived Intangible Income, and other provisions. In addition, in 2017 the Company was subject to a transition tax on accumulated foreign subsidiary earnings not previously subject to U.S. income tax.

[0000038725-18-000039:notes:121]
Due to the timing of the enactment and the complexity involved in applying the provisions of the Tax Act, the Company has made reasonable estimates of the effects and recorded provisional amounts in its financial statements as of December 31, 2017. As the Company collects and prepares necessary data, and interprets the Tax Act and any additional guidance issued by the U.S. Treasury Department, the IRS, and other standard-setting bodies, the Company may make adjustments to the provisional amounts during 2018. Those adjustments may materially impact the Company’s provision for income taxes and effective tax rate in the period in which the adjustments are made. The accounting for the tax effects of the Tax Act will be completed in 2018.

[0000038725-18-000039:notes:122]
Provisional amounts which net to $10.2 million for the following income tax effects of the Tax Act have been recorded as of December 31, 2017 and are subject to change during 2018.

[0000038725-18-000039:notes:123]
Transition tax

[0000038725-18-000039:notes:124]
The Tax Act requires the Company to pay U.S. income taxes on accumulated foreign subsidiary earnings not previously subject to U.S. income tax at a rate of 15.5 percent to the extent of foreign cash and certain other net current assets and 8 percent on the remaining earnings. The Company has recorded a provisional amount for the one-time transition tax liability and income tax expense of $18.9 million. The Company has recorded provisional amounts based on estimates of the effects of the Tax Act as the analysis requires significant data from foreign subsidiaries that is not yet final due to future statutory deadlines. In addition, further analysis is required pending guidance from state and local tax authorities in the U.S.

[0000038725-18-000039:notes:125]
Deferred tax effects

[0000038725-18-000039:notes:126]
The Tax Act reduces the U.S. statutory tax rate from 35 percent to 21 percent for years after 2017. Accordingly, the Company has remeasured its deferred taxes as of December 31, 2017 to reflect the reduced rate that will apply in future periods when these deferred taxes are settled or realized. The Company recognized a deferred tax benefit of $8.7 million. Although the tax rate reduction is known, all of the data is not yet available and further analysis is required to finalize the effect of the Tax Act on the underlying deferred taxes and as such, the amounts recorded as of December 31, 2017 are provisional.

[0000038725-18-000039:notes:127]
The Company recorded discrete excess tax benefits from share-based compensation of $1.8 million in the twelve-month period ended December 31, 2017 related to the adoption of ASU 2016-09 during 2016. The adoption of ASU 2016-09 for share-based compensation can add variability to the Company’s provision for income taxes, mainly due to the timing of stock option exercises, vesting of restricted stock, and the stock price.

[0000038725-18-000039:notes:128]
During the second quarter ended June 30, 2017, the Company acquired controlling interests in three U.S. distributors (see Note 3 - Acquisitions). These transactions created a discrete non-taxable gain recognized on the original minority equity investments resulting in a tax benefit of $1.9 million.

[0000038725-18-000039:notes:129]
During the first quarter ended March 31, 2017, the Company realized a foreign currency translation loss on discrete intercompany loans that were long-term-investment in nature resulting in a permanent tax benefit of $1.7 million and the Company released a valuation allowance on deferred tax of $1.9 million in a foreign jurisdiction where a restructuring occurred.

[0000038725-18-000039:notes:130]
Significant components of the Company’s deferred tax assets and liabilities were as follows:

[0000038725-18-000039:notes:131]
| (In millions) |  | 2017 |  | 2016 |
| Deferred tax assets: |  |  |  |  |
| Accrued expenses and reserves |  | $ | 9.6 |  |  | $ | 10.0 |  |
| Compensation and employee benefits |  | 17.4 |  |  | 24.2 |  |
| Other items |  | 15.0 |  |  | 10.9 |  |
| Valuation allowance on state and foreign deferred tax |  | (9.8 | ) |  | (9.8 | ) |
| Total deferred tax assets |  | 32.2 |  |  | 35.3 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Accelerated depreciation on fixed assets |  | 12.0 |  |  | 13.8 |  |
| Amortization of intangibles |  | 41.9 |  |  | 56.5 |  |
| Other items |  | 0.3 |  |  | 0.9 |  |
| Total deferred tax liabilities |  | 54.2 |  |  | 71.2 |  |
| Net deferred tax liabilities |  | $ | (22.0 | ) |  | $ | (35.9 | ) |

[0000038725-18-000039:notes:132]
The Company assesses the available positive and negative evidence to estimate whether sufficient future taxable income will be generated to permit use of the existing deferred tax assets. A significant piece of objective negative evidence evaluated was the cumulative loss for certain state and foreign income tax purposes incurred over the three-year period ended December 31, 2017. Such objective evidence limits the ability to consider other subjective evidence, such as projections for future growth.

[0000038725-18-000039:notes:133]
On the basis of this evaluation, as of December 31, 2017, a valuation allowance of $9.8 million has been recorded to recognize only the portion of the deferred tax assets that are more likely than not to be realized.  The Company has foreign income tax net operating loss (“NOL”) carryforwards of $7.0 million and state income tax NOL and credit carryforwards of $7.2 million, which will expire on various dates as follows:

[0000038725-18-000039:notes:134]
| (In millions) |  |
| 2018-2019 | $ | 1.1 |  |
| 2020-2024 | 3.0 |  |
| 2025-2029 | 2.2 |  |
| 2030-2034 | 2.6 |  |
| 2035-2039 | 0.2 |  |
| Unlimited | 5.1 |  |
|  | $ | 14.2 |  |

[0000038725-18-000039:notes:135]
The Company believes that it is more likely than not that the benefit from certain foreign NOL carryforwards as well as certain state NOL and state credit carryforwards will not be realized.  In recognition of this risk, the Company has provided a valuation allowance of $2.7 million on the deferred tax assets related to these foreign NOL carryforwards and a valuation allowance of $7.1 million on the deferred tax assets related to these state NOL and credit carryforwards.

[0000038725-18-000039:notes:136]
The Company continues to consider undistributed earnings from its foreign subsidiaries to be indefinitely reinvested with respect to the U.S. It is the Company’s policy to reinvest earnings as needed for operations, capital and acquisition spending. While the Tax Act resulted in the reduction of the excess of the amount for financial reporting over the tax basis in foreign subsidiaries, an actual repatriation from non-U.S. subsidiaries could still be subject to additional foreign withholding tax, foreign income tax, and U.S. state taxes. The Company considers the excess of the amount for financial reporting over the tax basis of its investments in its foreign subsidiaries of a provisional $325.2 million to be indefinitely reinvested and therefore have not recorded a deferred tax liability of $3.8 million.

[0000038725-18-000039:notes:137]
As of the beginning of fiscal year 2017, the Company had gross unrecognized tax benefits of $1.3 million, excluding accrued interest and penalties.  The unrecognized tax benefits increased due to uncertain tax positions identified in the current year based on evaluations made during 2017 which were offset by statue expirations.  The Company had gross unrecognized tax benefits, excluding accrued interest and penalties, of $1.3 million as of December 31, 2017.

[0000038725-18-000039:notes:138]
A reconciliation of the beginning and ending amount of gross unrecognized tax benefits for 2017, 2016, and 2015 (excluding interest and penalties) is as follows:

[0000038725-18-000039:notes:139]
| (In millions) |  | 2017 |  | 2016 |  | 2015 |
| Beginning balance |  | $ | 1.3 |  |  | $ | 2.4 |  |  | $ | 4.4 |  |
| Additions for tax positions of the current year |  | 0.4 |  |  | 0.1 |  |  | 0.2 |  |
| Additions for tax positions of prior years |  | 0.2 |  |  | 0.1 |  |  | 0.2 |  |
| Reductions for tax positions of prior years |  | — |  |  | (0.2 | ) |  | (0.8 | ) |
| Statute expirations |  | (0.6 | ) |  | (1.1 | ) |  | (1.6 | ) |
| Settlements |  | — |  |  | — |  |  | — |  |
| Ending balance |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 2.4 |  |

[0000038725-18-000039:notes:140]
If recognized, each annual effective tax rate would be affected by the net unrecognized tax benefits of $1.3 million, $1.3 million, and $2.3 million as of year-end 2017, 2016, and 2015, respectively.

[0000038725-18-000039:notes:141]
The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.  In 2017, interest and penalties decreased $0.5 million, for prior year tax positions.  The Company has accrued interest and penalties as of December 31, 2017, December 31, 2016, and January 2, 2016 of approximately $0.6 million, $1.1 million, and $2.3 million, respectively.

[0000038725-18-000039:notes:142]
The Company is subject to taxation in the United States and various state and foreign jurisdictions.  With few exceptions, as of December 31, 2017, the Company is no longer subject to U.S. federal income tax examinations by tax authorities for years before 2014 and is no longer subject to foreign or state income tax examinations by tax authorities for years before 2012.

[0000038725-18-000039:notes:143]
It is reasonably possible that the amounts of unrecognized tax benefits could change in the next twelve months as a result of an audit or due to the expiration of a statute of limitation.  Based on the current audits in process and pending statute expirations, the payment of taxes as a result could be up to $0.9 million.


## us-gaap:IncomeTaxPolicyTextBlock

[0000038725-18-000039:notes:144]
Income Taxes--Income taxes are accounted for in accordance with FASB ASC Topic 740, Income Taxes.  Under this guidance, deferred tax assets and liabilities are determined based on the difference between the financial statement and tax basis of assets and liabilities and net operating loss and credit carry forwards using enacted tax rates in effect for the year in which the differences are expected to reverse.  Valuation allowances are established when necessary to reduce deferred tax assets to the amounts expected to be realized.  The Company records a liability for uncertain tax positions by establishing a recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return.


## us-gaap:InventoryPolicyTextBlock

[0000038725-18-000039:notes:145]
Inventories--  Inventories are stated at the lower of cost or market.  The majority of the cost of domestic and foreign inventories is determined using the FIFO method with a portion of inventory costs determined using the average cost method.  The Company reviews its inventories for excess or obsolete products or components based on an analysis of historical usage and management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-18-000039:notes:146]
ACCOUNTING PRONOUNCEMENTS

[0000038725-18-000039:notes:147]
Accounting Standards Issued But Not Yet Adopted

[0000038725-18-000039:notes:148]
In February 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-02: Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The ASU is effective for interim and annual periods beginning after December 15, 2018, with early adoption permitted, and may be applied either at the beginning of the period of adoption or retrospectively to each period in which the effect of the change in the U.S. federal corporate income tax rate in the Tax Act is recognized. The Company is currently assessing the impact of the ASU on the Company’s consolidated financial position, results of operations, and cash flows.

[0000038725-18-000039:notes:149]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2017-07, Compensation - Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  This ASU requires entities to present only the service cost component of net periodic benefit cost as an operating expense (consistent with the presentation of other employee compensation costs).  The other components of net periodic benefit cost are to be presented as a non-operating expense.  The ASU is effective on a retrospective basis for interim and annual periods beginning after December 15, 2017.  Early adoption is permitted as of the beginning of any annual period for which an entity’s financial statements have not been issued or made available for issuance.  The Company plans to adopt the ASU in the first quarter ended March 31, 2018 and does not expect the adoption to have a material impact on the Company’s consolidated financial position, results of operations, or cash flows.

[0000038725-18-000039:notes:150]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit’s fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company’s consolidated financial position, results of operations, or cash flows.

[0000038725-18-000039:notes:151]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification (“ASC”) Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company has begun the evaluation process for the adoption of the ASU, and anticipates that the majority of the Company’s outstanding operating leases would be recognized as right-of-use assets and lease liabilities upon adoption, resulting in a significant impact to the Company’s consolidated balance sheets. The impact of this ASU is non-cash in nature and will not affect the Company’s cash position.  The impact to the Company’s results of operations is still being evaluated.

[0000038725-18-000039:notes:152]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) as modified by subsequently issued ASUs 2015-14, 2016-08, 2016-10, 2016-12 and 2016-20 (collectively ASU 2014-09).  Topic 606 supersedes the revenue recognition requirements in Accounting Standards Codification (“ASC”) Topic 605, Revenue Recognition (“Topic 605”), and requires the recognition of revenue when promised goods or services are transferred to customers in an amount that reflects the considerations to which the entity expects to be entitled to in exchange for those goods or services.  The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method).  The Company will adopt the standard effective January 1, 2018 utilizing the modified retrospective approach method of transition. The Company utilized questionnaires, reviewed contracts, and assessed revenue streams that may be impacted from the adoption of this ASU.  From this analysis, the Company concluded that the adoption of ASU 2014-09 is not expected to have a material impact on the Company’s consolidated financial position, results of operations, equity or cash flows.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-18-000039:notes:153]
EMPLOYEE BENEFIT PLANS

[0000038725-18-000039:notes:154]
Defined Benefit Plans - As of December 31, 2017, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2017 measurement date for these plans.  One of the Company’s domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the ‘Pension Benefits’ disclosure caption.

[0000038725-18-000039:notes:155]
Other Benefits - The Company’s other post-retirement benefit plan provides health and life insurance to domestic employees hired prior to 1992.  The Company effectively capped its cost for those benefits through plan amendments made in 1992, freezing Company contributions for insurance benefits at 1991 levels for current and future beneficiaries with actuarially reduced benefits for employees who retire before age 65.  The disclosures surrounding this plan are reflected in the “Other Benefits” caption.

[0000038725-18-000039:notes:156]
The following table sets forth aggregated information related to the Company’s pension benefits and other postretirement benefits, including changes in the benefit obligations, changes in plan assets, funded status, amounts recognized in the balance sheet, amounts recognized in accumulated other comprehensive income, and actuarial assumptions that the Company considered in its determination of benefit obligations and plan costs.  Benefit obligation balances presented below reflect the projected benefit obligation (PBO) for the Company’s pension plans, and accumulated postretirement benefit obligations (APBO) for the Company’s other benefit plans.

[0000038725-18-000039:notes:157]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Accumulated benefit obligation, end of year |  | $ | 180.5 |  |  | $ | 177.0 |  |  | $ | 10.3 |  |  | $ | 10.5 |  |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation, beginning of year |  | $ | 181.1 |  |  | $ | 186.9 |  |  | $ | 10.5 |  |  | $ | 11.3 |  |
| Service cost |  | 0.7 |  |  | 0.9 |  |  | — |  |  | 0.1 |  |
| Interest cost |  | 5.6 |  |  | 6.0 |  |  | 0.3 |  |  | 0.3 |  |
| Actuarial (gain)/loss |  | 7.0 |  |  | 4.1 |  |  | 0.6 |  |  | — |  |
| Settlements paid |  | (0.2 | ) |  | (0.6 | ) |  | — |  |  | — |  |
| Benefits paid |  | (11.9 | ) |  | (15.7 | ) |  | (1.1 | ) |  | (1.2 | ) |
| Curtailment |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign currency exchange |  | 2.8 |  |  | (0.5 | ) |  | — |  |  | — |  |
| Benefit obligation, end of year |  | $ | 185.1 |  |  | $ | 181.1 |  |  | $ | 10.3 |  |  | $ | 10.5 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of assets, beginning of year |  | $ | 146.1 |  |  | $ | 147.4 |  |  | $ | — |  |  | $ | — |  |
| Actual return on plan assets |  | 16.1 |  |  | 9.5 |  |  | — |  |  | — |  |
| Company contributions |  | 2.5 |  |  | 5.5 |  |  | 1.1 |  |  | 1.2 |  |
| Settlements paid |  | (0.1 | ) |  | (0.5 | ) |  | — |  |  | — |  |
| Benefits paid |  | (11.9 | ) |  | (15.7 | ) |  | (1.1 | ) |  | (1.2 | ) |
| Foreign currency exchange |  | 0.6 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Plan assets, end of year |  | $ | 153.3 |  |  | $ | 146.1 |  |  | $ | — |  |  | $ | — |  |
| Funded status |  | $ | (31.8 | ) |  | $ | (35.0 | ) |  | $ | (10.3 | ) |  | $ | (10.5 | ) |
| Amounts recognized in balance sheet: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities |  | $ | (0.4 | ) |  | $ | (0.3 | ) |  | $ | (1.1 | ) |  | $ | (1.1 | ) |
| Noncurrent liabilities |  | (31.4 | ) |  | (34.7 | ) |  | (9.2 | ) |  | (9.4 | ) |
| Net liability, end of year |  | $ | (31.8 | ) |  | $ | (35.0 | ) |  | $ | (10.3 | ) |  | $ | (10.5 | ) |
| Amount recognized in accumulated other comprehensive income/(loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior service cost |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | 0.2 |  |
| Net actuarial loss |  | 47.6 |  |  | 48.9 |  |  | 1.1 |  |  | 0.9 |  |
| Settlement |  | 0.5 |  |  | 1.5 |  |  | — |  |  | — |  |
| Total recognized in accumulated other comprehensive income/(loss) |  | $ | 48.1 |  |  | $ | 50.4 |  |  | $ | 1.2 |  |  | $ | 1.1 |  |

[0000038725-18-000039:notes:158]
The following table sets forth other changes in plan assets and benefit obligation recognized in other comprehensive income for 2017 and 2016:

[0000038725-18-000039:notes:159]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net actuarial (gain)/loss |  | $ | (0.2 | ) |  | $ | 3.8 |  |  | $ | 0.5 |  |  | $ | — |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net actuarial gain |  | (2.4 | ) |  | (2.3 | ) |  | (0.1 | ) |  | (0.1 | ) |
| Prior service credit |  | — |  |  | — |  |  | (0.3 | ) |  | (0.4 | ) |
| Settlement recognition |  | (0.5 | ) |  | (1.4 | ) |  | — |  |  | — |  |
| Deferred tax asset |  | 0.5 |  |  | 0.3 |  |  | — |  |  | 0.2 |  |
| Foreign currency exchange |  | 0.3 |  |  | (0.1 | ) |  | — |  |  | — |  |
| Total recognized in other comprehensive income |  | $ | (2.3 | ) |  | $ | 0.3 |  |  | $ | 0.1 |  |  | $ | (0.3 | ) |

[0000038725-18-000039:notes:160]
Weighted-average assumptions used to determine domestic benefit obligations:

[0000038725-18-000039:notes:161]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Discount rate |  | 3.61 | % |  | 4.13 | % |  | 3.51 | % |  | 3.89 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | 3.00 - 8.00%(Graded) |  |  | 3.00 - 8.00%(Graded) |  |

[0000038725-18-000039:notes:162]
*No rate of increases in future compensation used within assumptions for 2017 and 2016, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation.

[0000038725-18-000039:notes:163]
Assumptions used to determine domestic periodic benefit cost:

[0000038725-18-000039:notes:164]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| Discount rate |  | 4.13 | % |  | 4.40 | % |  | 4.00 | % |  | 3.91 | % |  | 4.09 | % |  | 3.75 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | — | % | * | 3.00 - 8.00%(Graded) |  |  | 3.00 - 8.00%(Graded) |  |  | 3.00 - 8.00%(Graded) |  |
| Expected long-term rate of return on plan assets |  | 6.25 | % |  | 6.50 | % |  | 7.00 | % |  | — | % |  | — | % |  | — | % |

[0000038725-18-000039:notes:165]
*No rate of increases in future compensation used within assumptions for 2017, 2016, and 2015, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation.

[0000038725-18-000039:notes:166]
For the fiscal year ended December 31, 2017, the Company used the RP-2014 aggregate table adjusted to back out estimated mortality improvements from 2006 to the measurement date using Scale MP-2014, and then projected forward using Scale MP-2017 released by the Society of Actuaries during 2017 to estimate future mortality rates based upon current data.   For the fiscal year ended December 31, 2016, the Company used the RP-2014 aggregate table adjusted to back out estimated mortality improvements from 2006 to the measurement date using Scale MP-2014, and then projected forward using Scale MP-2016 released by the Society of Actuaries during 2016 to estimate future mortality rates.

[0000038725-18-000039:notes:167]
The following table sets forth the aggregated net periodic benefit cost for all defined benefit plans for 2017, 2016, and 2015:

[0000038725-18-000039:notes:168]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| Service cost | $ | 0.7 |  |  | $ | 0.9 |  |  | $ | 1.4 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | 0.1 |  |
| Interest cost | 5.6 |  |  | 6.0 |  |  | 7.5 |  |  | 0.3 |  |  | 0.3 |  |  | 0.5 |  |
| Expected return on assets | (9.0 | ) |  | (9.2 | ) |  | (9.9 | ) |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Transition obligation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | 0.3 |  |  | 0.3 |  |  | 0.4 |  |
| Actuarial loss | 2.8 |  |  | 2.5 |  |  | 3.4 |  |  | 0.1 |  |  | 0.1 |  |  | 0.2 |  |
| Settlement cost | — |  |  | 1.2 |  |  | 1.2 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 1.5 |  |  | $ | 3.6 |  |  | $ | 0.7 |  |  | $ | 0.8 |  |  | $ | 1.2 |  |

[0000038725-18-000039:notes:169]
The estimated net actuarial (gain)/loss and prior service cost/(credit) that will be amortized from accumulated other comprehensive income into net periodic benefit cost during the 2018 fiscal year are $2.9 million and $0.0 million, respectively, for the pension plans and $0.2 million and $0.1 million, respectively, for all other benefits.

[0000038725-18-000039:notes:170]
The Company consults with a third party investment manager for the assets of the funded domestic defined benefit plan.  The plan assets are currently invested primarily in pooled funds, where each fund in turn is composed of mutual funds that have at least daily net asset valuations.  Thus, the Company’s funded domestic defined benefit plan assets are invested in a “fund of funds” approach.

[0000038725-18-000039:notes:171]
The Company’s Board has delegated oversight and guidance to an appointed Employee Benefits Committee.  The Committee has the tasks of reviewing plan performance and asset allocation, ensuring plan compliance with applicable laws, establishing plan policies, procedures, and controls, monitoring expenses, and other related activities.

[0000038725-18-000039:notes:172]
The plan’s investment policies and strategies focus on the ability to fund benefit obligations as they come due.  Considerations include the plan’s current funded level, plan design, benefit payment assumptions, funding regulations, impact of potentially volatile business results on the Company’s ability to make certain levels of contributions, and interest rate and asset return volatility among other considerations.  The Company currently attempts to maintain plan funded status at approximately 80 percent or greater pursuant to the Pension Protection Act of 2007.  Given the plan’s current funded status, the Company’s cash on hand, cash historically generated from business operations, and cash available under committed credit facilities, the Company sees ample liquidity to achieve this goal.

[0000038725-18-000039:notes:173]
Risk management and continuous monitoring requirements are met through monthly investment portfolio reports, quarterly Employee Benefits Committee meetings, annual valuations, asset/liability studies, and the annual assumption process focusing primarily on the return on asset assumption and the discount rate assumption.  As of December 31, 2017 and December 31, 2016, funds were invested in equity, fixed income, and other investments as follows:

[0000038725-18-000039:notes:174]
|  |  | Target Percentage |  | Plan Asset Allocation at Year-End |
| Asset Category |  | at Year-End 2017 |  | 2017 |  | 2016 |
| Equity securities |  | 26 | % |  | 26 | % |  | 31 | % |
| Fixed income securities |  | 70 | % |  | 70 | % |  | 65 | % |
| Other |  | 4 | % |  | 4 | % |  | 4 | % |
| Total |  | 100 | % |  | 100 | % |  | 100 | % |

[0000038725-18-000039:notes:175]
The Company does not see any particular concentration of risk within the plans, nor any plan assets that pose difficulties for fair value assessment.  The Company currently has no allocation to potentially illiquid or potentially difficult to value assets such as hedge funds, venture capital, private equity, and real estate.

[0000038725-18-000039:notes:176]
The Company works with actuaries and consultants in making its determination of the asset rate of return assumption and also the discount rate assumption.

[0000038725-18-000039:notes:177]
Asset class assumptions are set using a combination of empirical and forward-looking analysis for long-term rate of return on plan assets.  A variety of models are applied for filtering historical data and isolating the fundamental characteristics of asset classes.  These models provide empirical return estimates for each asset class, which are then reviewed and combined with a qualitative assessment of long-term relationships between asset classes before a return estimate is finalized.  This provides an additional means for correcting for the effect of unrealistic or unsustainable short-term valuations or trends, opting instead for return levels and behavior that are more likely to prevail over long periods.  With that, the Company has assumed an expected long-term rate of return on plan assets of 5.90 percent for the 2018 net periodic benefit cost, down from 6.25 percent in the prior year.  This decrease in the assumed long-term rate of return is primarily due to a higher percentage of assets in fixed income securities.

[0000038725-18-000039:notes:178]
The Company uses the Aon Hewitt AA Above Median curve to determine the discount rate.  All cash flow obligations under the plan are matched to bonds in the Aon Hewitt universe of liquid, high-quality, non-callable / non-putable corporate bonds with outliers removed.  From that matching exercise, a discount rate is determined.

[0000038725-18-000039:notes:179]
At January 2, 2016, the Company changed the method used to calculate the service and interest components of net periodic benefit cost for the domestic pension plans and other postretirement benefit plan.  This change compared to the previous method resulted in different service and interest components of net periodic benefit cost in the 2016 fiscal year.  Historically, the Company estimated these service and interest cost components utilizing a single weighted-average discount rate derived from the yield curve used to measure the benefit obligation at the beginning of the period.  The Company elected to utilize a full yield curve approach in the estimation of these components by applying the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows.  The Company made this change to provide a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot yield curve rates.  This change does not affect the measurement of the Company’s domestic pension and postretirement benefit obligations and is accounted for as a change in accounting estimate applied prospectively.

[0000038725-18-000039:notes:180]
The Company’s German pension plans are funded by insurance contract policies whereby the insurance company guarantees a fixed minimum return.  Due to tax legislation, individual pension benefits can only be financed using direct insurance policies up to certain maximums.  These maximum amounts in respect of each member are paid into such an arrangement on a yearly basis.

[0000038725-18-000039:notes:181]
The Company designated all equity and most domestic fixed income plan assets as Level 1, as they are mutual funds with prices that are readily available.  The U.S. Treasury securities and German plan assets are designated as Level 2 inputs.  The fair value of the German plan assets are measured by the reserve that is supervised by the German Federal Financial Supervisory Authority.  The U.S. Treasury securities are administered by the United States government.

[0000038725-18-000039:notes:182]
The fair values of the Company’s pension plan assets for 2017 and 2016 by asset category are as follows:

[0000038725-18-000039:notes:183]
| (In millions) |  | 2017 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| Domestic equity mutual funds |  | $ | 24.0 |  |  | $ | 24.0 |  |  | $ | — |  |  | $ | — |  |
| International equity mutual funds |  | 16.2 |  |  | 16.2 |  |  | — |  |  | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 19.2 |  |  | — |  |  | 19.2 |  |  | — |  |
| Fixed income mutual funds |  | 87.9 |  |  | 87.9 |  | — |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 5.3 |  |  | — |  |  | 5.3 |  |  | — |  |
| Cash and equivalents |  | 0.7 |  |  | 0.7 |  |  | — |  |  | — |  |
| Total |  | $ | 153.3 |  |  | $ | 128.8 |  |  | $ | 24.5 |  |  | $ | — |  |

[0000038725-18-000039:notes:184]
| (In millions) |  | 2016 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| Domestic equity mutual funds |  | $ | 27.8 |  |  | $ | 27.8 |  |  | $ | — |  |  | $ | — |  |
| International equity mutual funds |  | 17.5 |  |  | 17.5 |  |  | — |  |  | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 16.4 |  |  | — |  |  | 16.4 |  | — |  | — |  |
| Fixed income mutual funds |  | 79.1 |  |  | 79.1 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.5 |  |  | — |  |  | 4.5 |  |  | — |  |
| Cash and equivalents |  | 0.8 |  |  | 0.8 |  |  | — |  |  | — |  |
| Total |  | $ | 146.1 |  |  | $ | 125.2 |  |  | $ | 20.9 |  |  | $ | — |  |

[0000038725-18-000039:notes:185]
The Company estimates total contributions to the plans of $4 million in 2018.

[0000038725-18-000039:notes:186]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid in accordance with the following schedule:

[0000038725-18-000039:notes:187]
| (In millions) |  | Pension Benefits |  | Other Benefits |
| 2018 |  | $ | 12.2 |  |  | $ | 1.1 |  |
| 2019 |  | 11.6 |  |  | 1.0 |  |
| 2020 |  | 11.5 |  |  | 1.0 |  |
| 2021 |  | 11.4 |  |  | 0.9 |  |
| 2022 |  | 11.0 |  |  | 0.9 |  |
| Years 2023 through 2027 |  | 59.4 |  |  | 3.6 |  |

[0000038725-18-000039:notes:188]
Defined Contribution Plans - The Company maintained two defined contribution plans during 2017, 2016, and 2015.  The Company’s cash contributions are allocated to participant’s accounts based on investment elections.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000038725-18-000039:notes:189]
Property, Plant, and Equipment--Property, plant, and equipment are stated at historical cost.  The Company capitalizes certain computer software and software development costs incurred in connection with developing or obtaining computer software for internal use, which are included in property, plant, and equipment.  Depreciation of plant and equipment is calculated on a straight line basis over the following estimated useful lives:

[0000038725-18-000039:notes:190]
| Land improvement and buildings | 10-40 years |
| Machinery and equipment | 5-10 years |
| Software | 3-7 years |
| Furniture and fixtures | 3-7 years |

[0000038725-18-000039:notes:191]
Maintenance, repairs, and renewals of a minor nature are expensed as incurred.  Betterments and major renewals which extend the useful lives or add to the productive capacity of buildings, improvements, and equipment are capitalized.  The Company reviews its property, plant, and equipment for impairment at the asset group level whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable.  If an indicator is present, the Company compares carrying values to undiscounted future cash flows; if the undiscounted future cash flows are less than the carrying value, an impairment would be recognized for the difference between the fair value and the carrying value.

[0000038725-18-000039:notes:192]
The Company’s depreciation expense was $29.9 million, $27.1 million, and $26.8 million in 2017, 2016, and 2015, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000038725-18-000039:notes:193]
SELECTED QUARTERLY FINANCIAL DATA (UNAUDITED)

[0000038725-18-000039:notes:194]
Unaudited quarterly financial information for 2017 and 2016, is as follows:

[0000038725-18-000039:notes:195]
| (In millions, except per share amounts) |  |  |  |  |  |  |  |  |  |  |
|  | Net Sales |  | Gross Profit |  | Net Income |  | Net Income Attributable to Franklin Electric Co., Inc. |  | Basic Earnings Per Share |  | Diluted Earnings Per Share |
| 2017 |  |  |  |  |  |  |  |  |  |  |  |
| 1st quarter | $ | 220.3 |  |  | $ | 75.8 |  |  | $ | 15.9 |  |  | $ | 15.7 |  |  | $ | 0.33 |  |  | $ | 0.33 |  |
| 2nd quarter | 305.3 |  |  | 102.8 |  |  | 30.2 |  |  | 29.9 |  |  | 0.64 |  |  | 0.64 |  |
| 3rd quarter | 311.1 |  |  | 103.8 |  |  | 24.5 |  |  | 24.5 |  |  | 0.52 |  |  | 0.52 |  |
| 4th quarter | 288.2 |  |  | 94.6 |  |  | 8.0 |  |  | 8.1 |  |  | 0.17 |  |  | 0.17 |  |
|  | $ | 1,124.9 |  |  | $ | 377.0 |  |  | $ | 78.6 |  |  | $ | 78.2 |  |  | $ | 1.67 |  |  | $ | 1.65 |  |
| 2016 |  |  |  |  |  |  |  |  |  |  |  |  |
| 1st quarter | $ | 218.4 |  |  | $ | 74.2 |  |  | $ | 13.6 |  |  | $ | 13.5 |  |  | $ | 0.28 |  |  | $ | 0.28 |  |
| 2nd quarter | 252.1 |  |  | 90.7 |  |  | 24.2 |  |  | 24.0 |  |  | 0.51 |  |  | 0.50 |  |
| 3rd quarter | 239.8 |  |  | 85.5 |  |  | 23.7 |  |  | 23.7 |  |  | 0.51 |  |  | 0.50 |  |
| 4th quarter | 239.6 |  |  | 81.0 |  |  | 17.8 |  |  | 17.5 |  |  | 0.37 |  |  | 0.37 |  |
|  | $ | 949.9 |  |  | $ | 331.4 |  |  | $ | 79.3 |  |  | $ | 78.7 |  |  | $ | 1.67 |  |  | $ | 1.65 |  |

[0000038725-18-000039:notes:196]
Basic and diluted earnings per share amounts are computed independently for each of the quarters presented.  As a result, the sum of the quarterly earnings per share amounts may not equal the annual earnings per share amount.


## us-gaap:ReceivablesPolicyTextBlock

[0000038725-18-000039:notes:197]
Accounts Receivable, Earned Discounts, and Allowance for Uncollectible Accounts--Accounts receivable are stated at estimated net realizable value.  Accounts receivable are comprised of balances due from customers, net of earned discounts and estimated allowances for uncollectible accounts.  Earned discounts are based on specific customer agreement terms.  In determining allowances for uncollectible accounts, historical collection experience, current trends, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are reviewed.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-18-000039:notes:198]
RESTRUCTURING

[0000038725-18-000039:notes:199]
During the fourth quarter of 2017, the Company approved a plan to close the Wadcorpp India Private Limited (“Wadcorpp”) joint venture. The Company purchased a controlling interest in the Wadcorpp entity during the third quarter 2014, and included the entity as a fully consolidated subsidiary in the Fueling Systems segment. As part of this action, the Company will continue to sell fueling product in the India market, while the Wadcorpp manufacturing operations will cease. The closure began in the fourth quarter 2017 and is estimated to conclude by the end of 2018. Charges for the closure are expected to range between $2 million and $4 million and will include severance expenses, asset write-offs and other closure expenses.

[0000038725-18-000039:notes:200]
Costs incurred in the twelve months ended December 31, 2017, included in the “Restructuring (income)/expense” line of the Company’s consolidated statements of income, are as follows:

[0000038725-18-000039:notes:201]
| (In millions) |  | Water Systems |  | Fueling Systems |  | Distribution |  | Other |  | Consolidated |
| Employee severance |  | $ | 1.6 |  |  | $ | — |  |  | — |  |  | $ | — |  |  | $ | 1.6 |  |
| Equipment relocation |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Asset write-off, net of gain on disposal |  | — |  |  | 1.6 |  |  | — |  |  | — |  |  | 1.6 |  |
| Other |  | 1.0 |  |  | — |  |  | — |  |  | — |  |  | 1.0 |  |
| Total |  | $ | 2.7 |  |  | $ | 1.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 4.3 |  |

[0000038725-18-000039:notes:202]
Restructuring (income)/expense of $(0.6) million and $3.0 million were incurred in 2016 and 2015, respectively, primarily for the Water Systems realignment.

[0000038725-18-000039:notes:203]
As of December 31, 2017 and December 31, 2016, there were no material restructuring reserves.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000038725-18-000039:notes:204]
Revenue Recognition--Revenue is recognized when pervasive evidence of an arrangement exists, collectability is reasonably assured, the price is fixed or determinable, and shipment or delivery has occurred.  For product sales, the Company recognizes revenue once the transfer of ownership and risk of loss pass to the customer, which is generally when the products are shipped.

[0000038725-18-000039:notes:205]
Generally, the only post-shipment obligation on the Company’s products include routine warranty obligations.  In the event that significant post-shipment obligations were to exist for the Company’s products, revenue recognition would be deferred until substantially all obligations were satisfied.

[0000038725-18-000039:notes:206]
The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000038725-18-000039:notes:207]
The weighted average number of years over which each intangible class is amortized is as follows:


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000038725-18-000039:notes:208]
Financial information by geographic region is as follows:

[0000038725-18-000039:notes:209]
|  | Net sales |  | Long-lived assets |
| (In millions) | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| United States | $ | 596.6 |  |  | $ | 446.9 |  |  | $ | 418.5 |  |  | $ | 326.1 |  |  | $ | 349.2 |  |  | $ | 404.1 |  |
| Foreign | 528.3 |  |  | 503.0 |  |  | 506.4 |  |  | 261.2 |  |  | 202.3 |  |  | 150.7 |  |
| Consolidated | $ | 1,124.9 |  |  | $ | 949.9 |  |  | $ | 924.9 |  |  | $ | 587.3 |  |  | $ | 551.5 |  |  | $ | 554.8 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-18-000039:notes:210]
Financial information by reportable business segment is included in the following summary:

[0000038725-18-000039:notes:211]
| Net Sales |
| (In millions) | 2017 |  | 2016 |  | 2015 |
| Water Systems |  |  |  |  |  |
| External sales | 703.3 |  |  | 723.2 |  |  | 707.6 |  |
| Intersegment sales | 45.3 |  |  | — |  |  | — |  |
| Total sales | 748.6 |  |  | 723.2 |  |  | 707.6 |  |
| Distribution |  |  |  |  |  |
| External sales | 176.7 |  |  | — |  |  | — |  |
| Intersegment sales | — |  |  | — |  |  | — |  |
| Total sales | 176.7 |  |  | — |  |  | — |  |
| Fueling Systems |  |  |  |  |  |
| External sales | 244.9 |  |  | 226.7 |  |  | 217.3 |  |
| Intersegment sales | 1.0 |  |  | — |  |  | — |  |
| Total Sales | 245.9 |  |  | 226.7 |  |  | 217.3 |  |
| Intersegment Eliminations/Other | (46.3 | ) |  | — |  |  | — |  |
| Consolidated | $ | 1,124.9 |  |  | $ | 949.9 |  |  | $ | 924.9 |  |
| Operating income (loss) |
|  | 2017 |  | 2016 |  | 2015 |
| Water Systems | $ | 102.0 |  |  | $ | 108.2 |  |  | $ | 86.7 |  |
| Distribution | 3.7 |  |  | — |  |  | — |  |
| Fueling Systems | 60.0 |  |  | 56.3 |  |  | 51.5 |  |
| Intersegment Eliminations/Other | (58.7 | ) |  | (53.7 | ) |  | (47.8 | ) |
| Consolidated | $ | 107.0 |  |  | $ | 110.8 |  |  | $ | 90.4 |  |

[0000038725-18-000039:notes:212]
|  | Total assets |  | Depreciation |
|  | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| Water Systems | $ | 695.4 |  |  | $ | 671.5 |  |  | $ | 677.6 |  |  | $ | 20.9 |  |  | $ | 19.5 |  |  | $ | 19.5 |  |
| Distribution | 153.1 |  |  | — |  |  | — |  |  | 1.3 |  |  | — |  |  | — |  |
| Fueling Systems | 265.7 |  |  | 251.1 |  |  | 248.5 |  |  | 2.2 |  |  | 2.3 |  |  | 2.5 |  |
| Other | 71.2 |  |  | 117.3 |  |  | 70.0 |  |  | 5.5 |  |  | 5.3 |  |  | 4.8 |  |
| Consolidated | $ | 1,185.4 |  |  | $ | 1,039.9 |  |  | $ | 996.1 |  |  | $ | 29.9 |  |  | $ | 27.1 |  |  | $ | 26.8 |  |
|  | Amortization |  | Capital expenditures |
|  | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| Water Systems | $ | 6.2 |  |  | $ | 6.4 |  |  | $ | 6.6 |  |  | $ | 19.1 |  |  | $ | 31.8 |  |  | $ | 19.5 |  |
| Distribution | 0.4 |  |  | — |  |  | — |  |  | 1.1 |  |  | — |  |  | — |  |
| Fueling Systems | 1.9 |  |  | 1.9 |  |  | 1.9 |  |  | 11.0 |  |  | 2.1 |  |  | 1.4 |  |
| Other | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 2.2 |  |  | 3.7 |  |  | 5.0 |  |
| Consolidated | $ | 8.6 |  |  | $ | 8.4 |  |  | $ | 8.6 |  |  | $ | 33.4 |  |  | $ | 37.6 |  |  | $ | 25.9 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-18-000039:notes:213]
During 2017, 2016, and 2015, pursuant to a stock repurchase program authorized by the Company’s Board of Directors, the Company repurchased and retired the following amounts and number of shares:

[0000038725-18-000039:notes:214]
| (In millions, except share amounts) |  | 2017 |  | 2016 |  | 2015 |
| Repurchases |  | $ | — |  |  | $ | 3.8 |  |  | $ | 46.3 |  |
| Shares |  | — |  |  | 144,600 |  |  | 1,568,731 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000038725-18-000039:notes:215]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000038725-18-000039:notes:216]
| (In millions) |  | Balance at Beginning of Period |  | Additions Charged to Costs and Expenses |  | Deductions (a) |  | Other (b) |  | Balance at End of Period |
| 2017 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.6 |  |  | $ | (0.1 | ) |  | $ | 0.2 |  |  | $ | 1.1 |  |  | $ | 4.4 |  |
| Allowance for deferred taxes |  | 9.8 |  |  | 2.4 |  |  | 2.4 |  |  | — |  |  | 9.8 |  |
| 2016 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.8 |  |  | $ | 0.1 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | 3.6 |  |
| Allowance for deferred taxes |  | 7.2 |  |  | 2.9 |  |  | 0.3 |  |  | — |  |  | 9.8 |  |
| 2015 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.2 |  |  | $ | 1.1 |  |  | $ | 0.5 |  |  | $ | — |  |  | $ | 3.8 |  |
| Allowance for deferred taxes |  | 3.9 |  |  | 3.5 |  |  | 0.2 |  |  | — |  |  | 7.2 |  |

[0000038725-18-000039:notes:217]
(a) Charges for which allowances were created.

[0000038725-18-000039:notes:218]
(b) Primarily related to acquisitions


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-18-000039:notes:219]
SEGMENT AND GEOGRAPHIC INFORMATION

[0000038725-18-000039:notes:220]
The Company’s business consists of the Water Systems, Distribution, and Fueling Systems reportable segments, based on the principal end market served.  Within the Water Systems segment, North America Water Systems and International Water Systems have been identified as operating segments.  For reportable segment purposes, the Company aggregates North America Water Systems and International Water Systems into the Water Systems segment, as they meet the aggregation criteria in FASB ASC 280. The Company includes unallocated corporate expenses and inter-company eliminations in an “Intersegment Eliminations/Other” segment that together with the Water Systems, Distribution, and Fueling Systems segments, represent the Company.

[0000038725-18-000039:notes:221]
The Water Systems segment designs, manufactures and sells motors, pumps, electronic controls and related parts and equipment primarily for use in submersible water and other fluid system applications.  The Fueling Systems segment designs, manufactures and sells pumps, electronic controls and related parts and equipment primarily for use in submersible fueling system applications.  The Fueling Systems segment integrates and sells motors and electronic controls produced by the Water Systems segment. The Distribution segment sells to and provides pre sale support and specifications to the installing contractors. The Distribution segment sells products produced by the Water Systems segment.

[0000038725-18-000039:notes:222]
The accounting policies of the Company’s reportable segments are the same as those described in Note 1 (Summary of Significant Accounting Policies).  Performance is evaluated based on the sales and operating income of the segments and a variety of ratios to measure performance.  These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented.

[0000038725-18-000039:notes:223]
Property, plant and equipment is the major asset group in “Other” of total assets at December 31, 2017.  Cash is the major asset group in “Other” of total assets at December 31, 2016.

[0000038725-18-000039:notes:224]
Net sales are attributed to geographic regions based upon the ship to location of the customer.  Long-lived assets are attributed to geographic regions based upon the country of domicile.

[0000038725-18-000039:notes:225]
The Company offers a large array of products and systems to multiple markets and customers.  Product sales information is tracked regionally and products are categorized differently between regions based on local needs and reporting requirements. However, net sales by segment are representative of the Company’s sales by major product category. The Company sells its products through various distribution channels including wholesale and retail distributors, specialty distributors, industrial and petroleum equipment distributors, as well as major oil and utility companies and original equipment manufacturers.

[0000038725-18-000039:notes:226]
No single customer accounted for more than 10 percent of the Company’s consolidated sales in 2017, 2016, or 2015.  No single customer accounted for more than 10 percent of the Company’s gross accounts receivable in 2017 or 2016.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0000038725-18-000039:notes:227]
Shipping and Handling Costs--Shipping and handling costs are recorded as a component of cost of sales.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000038725-18-000039:notes:228]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0000038725-18-000039:notes:229]
Company--“Franklin Electric” or the “Company” shall refer to Franklin Electric Co., Inc. and its consolidated subsidiaries.

[0000038725-18-000039:notes:230]
Fiscal Year--In December 2016, the Company’s Board of Directors approved a change in reporting periods from fiscal periods to a calendar year.  This change took effect on January 1, 2017.  For fiscal years 2016 and prior, the Company’s fiscal year ended on the Saturday nearest December 31.  The financial statements and accompanying notes are as of and for the years ended December 31, 2017, December 31, 2016 (52 weeks), and January 2, 2016 (52 weeks), and referred to as 2017, 2016, and 2015, respectively.

[0000038725-18-000039:notes:231]
Business Combinations--The Company allocates the purchase price of its acquisitions to the assets acquired, liabilities assumed, and noncontrolling interests based upon their respective fair values at the acquisition date.  The Company utilizes management estimates and inputs from an independent third-party valuation firm to assist in determining these fair values.  The excess of the acquisition price over estimated fair values is recorded as goodwill.  Goodwill is adjusted for any changes to acquisition date fair value amounts made within the measurement period.  Acquisition-related transaction costs are recognized separately from the business combination and expensed as incurred.

[0000038725-18-000039:notes:232]
Research and Development Expense--The Company’s research and development activities are charged to expense in the period incurred.  The Company incurred expenses of approximately $20.8 million in 2017, $21.5 million in 2016, and $18.4 million in 2015 related to research and development.

[0000038725-18-000039:notes:233]
Fair Value of Financial Instruments--Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy.  Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date.  The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value.  The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-18-000039:notes:234]
Level 1 – Quoted prices for identical assets and liabilities in active markets;

[0000038725-18-000039:notes:235]
Level 2 – Quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets; and

[0000038725-18-000039:notes:236]
Level 3 – Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable.

[0000038725-18-000039:notes:237]
Warranty Obligations--The Company provides warranties on most of its products. The warranty terms vary but are generally two to five years from date of manufacture or one to five years from date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims. The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-18-000039:notes:238]
Defined Benefit Plans--The Company makes its determination for pension, post retirement, and post employment benefit plans liabilities based on management estimates and consultation with actuaries. The Company incorporates estimates and assumptions of future plan service costs, future interest costs on projected benefit obligations, rates of compensation increases, employee turnover rates, anticipated mortality rates, expected investment returns on plan assets, asset allocation assumptions of plan assets, and other factors.

[0000038725-18-000039:notes:239]
Significant Estimates--The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make significant estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of expenses during the reporting periods.  Significant estimates and assumptions by management affect inventory valuation, warranty, trade names and goodwill, income taxes, and pension and employee benefit obligations.

[0000038725-18-000039:notes:240]
Although the Company regularly assesses these estimates, actual results could materially differ.  The Company bases its estimates on historical experience and various other assumptions that it believes to be reasonable under the circumstances.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-18-000039:notes:241]
SHAREHOLDERS’ EQUITY

[0000038725-18-000039:notes:242]
Authorized Shares

[0000038725-18-000039:notes:243]
The Company has the authority to issue 65,000,000, $.10 par value shares.

[0000038725-18-000039:notes:244]
Share Repurchases

[0000038725-18-000039:notes:245]
In 2017, the Company retired 87,679 shares that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards.  The Company also retired 14,033 shares that had been previously granted as stock awards to employees, but were forfeited upon not meeting the required restriction criteria or termination.  In 2016, the Company retired 96,929 shares that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards.  The Company also retired 16,391 shares that had been previously granted as a stock award to employees, but were forfeited upon not meeting the required restriction criteria or termination.  In 2015, the Company retired 65,209 shares that were received from employees as payment for the exercise price of their stock options and taxes owned upon the exercise of their stock options and release of their restricted awards.  The Company also retired 958 shares that had been previously granted as stock awards to employees, but were forfeited upon not meeting the required restriction criteria or termination.

[0000038725-18-000039:notes:246]
In 2015 the Company recorded $1.4 million as a reduction in tax liability and an increase to shareholders’ equity as a result of stock option exercises and award vests.  In 2016, the Company early adopted ASU 2016-09; therefore, no amounts were recorded to equity as a result of stock option exercises and award vests for fiscal years 2017 and 2016.


## us-gaap:SubsequentEventsTextBlock

[0000038725-18-000039:notes:247]
SUBSEQUENT EVENT

[0000038725-18-000039:notes:248]
On January 2, 2018, Headwater Company, LLC, a wholly owned subsidiary of the Company, acquired 100 percent interest of Valley Farm Supply, Inc. (Valley Farms) of Lansing, Michigan for approximately $9.0 million. Valley Farms will continue to operate as a professional groundwater distributor and will be included as a part of the Distribution Segment of the Company.
