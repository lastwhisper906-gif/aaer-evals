# FELE 8-K — 0000038725-18-000020 filed 2018-02-20

## item codes, every 8-K on or before 2018-02-27

- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2018-02-27

- none on or before 2018-02-27

## item 2.02 — earnings release, exhibit 99.1

[0000038725-18-000020:8k_2_02:1]
EX-99.1
2
a201802208-kexhibit991.htm
EXHIBIT 99.1

[0000038725-18-000020:8k_2_02:2]
Exhibit

[0000038725-18-000020:8k_2_02:3]
Exhibit 99.1

[0000038725-18-000020:8k_2_02:4]
For Immediate Release

[0000038725-18-000020:8k_2_02:5]
For Further Information

[0000038725-18-000020:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-18-000020:8k_2_02:7]
260-824-2900

[0000038725-18-000020:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS FOURTH

[0000038725-18-000020:8k_2_02:9]
QUARTER AND FULL YEAR 2017 SALES AND EARNINGS

[0000038725-18-000020:8k_2_02:10]
Fort Wayne, IN - February 20, 2018 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported fourth quarter 2017 GAAP fully diluted earnings per share (EPS) of $0.17, versus a GAAP fully diluted EPS in the fourth quarter 2016 of $0.37.  In the fourth quarter of 2017, the Company’s EPS was $0.21 before restructuring compared to 2016 fourth quarter EPS of $0.37 before restructuring (see table below for a reconciliation of GAAP EPS to EPS before restructuring).  The Company incurred a tax expense of $0.21 per share related to the U.S. Tax Cuts and Jobs Act of 2017.  Before restructuring and the tax expense associated with the U.S. Tax Cuts and Jobs Act of 2017, the Company’s fourth quarter 2017 EPS was $0.42.

[0000038725-18-000020:8k_2_02:11]
Fourth quarter 2017 sales were $288.2 million, compared to 2016 fourth quarter sales of $239.6 million.  The sales increase was primarily from acquisitions.  Organic sales increased about 2 percent when excluding the impact of foreign currency translation.

[0000038725-18-000020:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-18-000020:8k_2_02:13]
“Our fourth quarter Water Systems operating income was below our expectations.  We saw a signficant downturn in our business in Brazil, in large part due to the overall economic environment in that region.  Our operating income before restructuring in Brazil was lower by over 60 percent versus the same quarter in 2016.  We had modest revenue growth in our Water Systems businesses in Europe, Africa and Asia during the quarter.  In North America, the recovery of oil and gas end markets nearly doubled our sales of dewatering pumps during the quarter while groundwater system sales declined about 9 percent, in line with our expectations, due to the intentional reduction of working capital in our distribution company, and a difficult comparison to a very strong fourth quarter in 2016.

[0000038725-18-000020:8k_2_02:14]
Our Fueling Systems segment had another record quarter for sales and earnings with fourth quarter sales up 10 percent and operating income before restructuring up 20 percent versus the fourth quarter of 2016.

[0000038725-18-000020:8k_2_02:15]
Considering seasonality and the disruption in the supply base, the sales of our U.S. Distribution segment were in line with our expectations.”

[0000038725-18-000020:8k_2_02:16]
Key Performance Indicators:

[0000038725-18-000020:8k_2_02:17]
| Earnings Before and After Restructuring and U.S. Tax Cuts and Jobs Act |  | For the Fourth Quarter |  | For the Full Year |
| (in millions) |  | 2017 | 2016 | Change |  | 2017 | 2016 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 8.1 |  | $ | 17.6 |  | (54 | )% |  | $ | 78.2 |  | $ | 78.7 |  | (1 | )% |
| Allocated Undistributed Earnings |  | $ | (0.1 | ) | $ | (0.3 | ) |  |  | $ | (0.6 | ) | $ | (1.7 | ) |  |
| Earnings for EPS Calculations |  | $ | 8.0 |  | $ | 17.3 |  | (54 | )% |  | $ | 77.6 |  | $ | 77.0 |  | 1 | % |
| Restructuring (before tax): |  | $ | 2.7 |  | $ | 0.3 |  |  |  | $ | 4.3 |  | $ | (0.6 | ) |  |
| Restructuring, net of tax: |  | $ | 1.6 |  | $ | 0.2 |  |  |  | $ | 2.6 |  | $ | (0.4 | ) |  |
| 2017 Impact of the U.S. Tax Cuts and Jobs Act |  | $ | 10.2 |  | $ | — |  |  |  | $ | 10.2 |  | $ | — |  |  |
| Earnings Before Restructuring and U.S. Tax Cuts and Jobs Act |  | $ | 19.8 |  | $ | 17.5 |  | 13 | % |  | $ | 90.4 |  | $ | 76.6 |  | 18 | % |
| Earnings Per Share |  | For the Fourth Quarter |  | For the Full Year |
| Before and After Restructuring |  | 2017 | 2016 | Change |  | 2017 | 2016 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.1 |  | 46.9 |  | — | % |  | 47.0 |  | 46.7 |  | 1 | % |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.17 |  | $ | 0.37 |  | (54 | )% |  | $ | 1.65 |  | $ | 1.65 |  | — | % |
| Restructuring Per Share, net of tax |  | $ | 0.04 |  | $ | — |  |  |  | $ | 0.06 |  | $ | (0.01 | ) |  |
| 2017 Impact of the U.S. Tax Cuts and Jobs Act |  | $ | 0.21 |  | $ | — |  |  |  | $ | 0.21 |  |  |  |
| Fully Diluted EPS Before Restructuring and U.S. Tax Cuts and Jobs Act |  | $ | 0.42 |  | $ | 0.37 |  | 14 | % |  | $ | 1.92 |  | $ | 1.64 |  | 17 | % |

[0000038725-18-000020:8k_2_02:18]
|  | Net Sales For the Fourth Quarter |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q4 2016 | $ | 82.0 |  | $ | 34.2 |  | $ | 41.3 |  | $ | 20.3 |  | $ | 177.8 |  | $ | 61.8 |  | $ | — |  | $ | — |  | $ | 239.6 |  |
| Q4 2017 | $ | 79.8 |  | $ | 33.5 |  | $ | 44.5 |  | $ | 23.7 |  | $ | 181.5 |  | $ | 67.9 |  | $ | 49.5 |  | $ | (10.7 | ) | $ | 288.2 |  |
| Change | $ | (2.2 | ) | $ | (0.7 | ) | $ | 3.2 |  | $ | 3.4 |  | $ | 3.7 |  | $ | 6.1 |  | $ | 49.5 |  | $ | (10.7 | ) | $ | 48.6 |  |
| % Change | (3 | )% | (2 | )% | 8 | % | 17 | % | 2 | % | 10 | % |  |  | 20 | % |
| Foreign currency translation | $ | 0.8 |  | $ | 0.5 |  | $ | 1.1 |  | $ | 0.3 |  | $ | 2.7 |  | $ | 1.6 |  |  |  |  |
| % Change | 1 | % | 1 | % | 3 | % | 2 | % | 1 | % | 3 | % |  |  |  |
| Volume/Price | $ | (3.0 | ) | $ | (0.9 | ) | $ | 2.1 |  | $ | 3.1 |  | $ | 1.3 |  | $ | 4.5 |  |  |  |  |
| % Change | (4 | )% | (3 | )% | 5 | % | 15 | % | 1 | % | 7 | % |  |  |  |

[0000038725-18-000020:8k_2_02:19]
|  | Net Sales For the Full Year |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| FY 2016 | $ | 343.1 |  | $ | 127.5 |  | $ | 167.3 |  | $ | 85.3 |  | $ | 723.2 |  | $ | 226.7 |  | $ | — |  | $ | — |  | $ | 949.9 |  |
| FY 2017 | $ | 354.2 |  | $ | 130.8 |  | $ | 177.5 |  | $ | 86.1 |  | $ | 748.6 |  | $ | 245.9 |  | $ | 176.7 |  | $ | (46.3 | ) | $ | 1,124.9 |  |
| Change | $ | 11.1 |  | $ | 3.3 |  | $ | 10.2 |  | $ | 0.8 |  | $ | 25.4 |  | $ | 19.2 |  | $ | 176.7 |  | $ | (46.3 | ) | $ | 175.0 |  |
| % Change | 3 | % | 3 | % | 6 | % | 1 | % | 4 | % | 8 | % |  |  | 18 | % |
| Foreign currency translation | $ | 0.3 |  | $ | 5.3 |  | $ | (4.1 | ) | $ | 0.5 |  | $ | 2.0 |  | $ | 0.7 |  |  |  |  |
| % Change | — | % | 4 | % | (3 | )% | 1 | % | 1 | % | — | % |  |  |  |
| Volume/Price | $ | 10.8 |  | $ | (1.7 | ) | $ | 14.3 |  | $ | 0.3 |  | $ | 23.7 |  | $ | 18.5 |  |  |  |  |
| % Change | 3 | % | (1 | )% | 9 | % | — | % | 3 | % | 8 | % |  |  |  |

[0000038725-18-000020:8k_2_02:20]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2017 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Reported Operating Income/(Loss) | $ | 19.5 |  | $ | 17.0 |  | $ | (2.0 | ) | $ | (12.1 | ) | $ | 22.4 |  |
| % Operating Income To Net Sales | 10.7 | % | 25.0 | % | (4.0 | )% |  | 7.8 | % |
| Restructuring | $ | 1.1 |  | $ | 1.6 |  | $ | — |  | $ | — |  | $ | 2.7 |  |
| Operating Income/(Loss) Before Restructuring | $ | 20.6 |  | $ | 18.6 |  | $ | (2.0 | ) | $ | (12.1 | ) | $ | 25.1 |  |
| % Operating Income to Net Sales Before Restructuring | 11.3 | % | 27.4 | % | (4.0 | )% |  | 8.7 | % |
|  | For the Fourth Quarter 2016 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Reported Operating Income/(Loss) | $ | 22.6 |  | $ | 15.4 |  | $ | — |  | $ | (12.8 | ) | $ | 25.2 |  |
| % Operating Income To Net Sales | 12.7 | % | 24.9 | % |  |  | 10.5 | % |
| Restructuring | $ | 0.2 |  | $ | 0.1 |  | $ | — |  | $ | — |  | $ | 0.3 |  |
| Operating Income/(Loss) Before Restructuring | $ | 22.8 |  | $ | 15.5 |  | $ | — |  | $ | (12.8 | ) | $ | 25.5 |  |
| % Operating Income to Net Sales Before Restructuring | 12.8 | % | 25.1 | % |  |  | 10.6 | % |

[0000038725-18-000020:8k_2_02:21]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year of 2017 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Reported Operating Income/(Loss) | $ | 102.0 |  | $ | 60.0 |  | $ | 3.7 |  | $ | (58.7 | ) | $ | 107.0 |  |
| % Operating Income To Net Sales | 13.6 | % | 24.4 | % | 2.1 | % |  | 9.5 | % |
| Restructuring | $ | 2.7 |  | $ | 1.6 |  | $ | — |  | $ | — |  | $ | 4.3 |  |
| Operating Income/(Loss) Before Restructuring | $ | 104.7 |  | $ | 61.6 |  | $ | 3.7 |  | $ | (58.7 | ) | $ | 111.3 |  |
| % Operating Income to Net Sales Before Restructuring | 14.0 | % | 25.1 | % | 2.1 | % |  | 9.9 | % |
|  | For the Full Year of 2016 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Reported Operating Income/(Loss) | $ | 108.2 |  | $ | 56.3 |  | $ | — |  | $ | (53.7 | ) | $ | 110.8 |  |
| % Operating Income To Net Sales | 15.0 | % | 24.8 | % |  |  | 11.7 | % |
| Restructuring | $ | (1.2 | ) | $ | 0.6 |  | $ | — |  | $ | — |  | $ | (0.6 | ) |
| Operating Income/(Loss) Before Restructuring | $ | 107.0 |  | $ | 56.9 |  | $ | — |  | $ | (53.7 | ) | $ | 110.2 |  |
| % Operating Income to Net Sales Before Restructuring | 14.8 | % | 25.1 | % |  |  | 11.6 | % |

[0000038725-18-000020:8k_2_02:22]
Water Systems

[0000038725-18-000020:8k_2_02:23]
Water Systems sales were $181.5 million in the fourth quarter 2017, versus the fourth quarter 2016 sales of $177.8 million.  Water Systems sales increased about 1 percent in the quarter due to foreign currency translation.

[0000038725-18-000020:8k_2_02:24]
Water Systems sales in the U.S. and Canada declined by about 3 percent compared to the fourth quarter 2016.   Sales of Pioneer branded dewatering equipment increased by about 80 percent in the fourth quarter when compared to the prior year resulting from the continued diversification of customers and strengthening in U.S. oil and gas end markets.  Sales of groundwater pumping equipment decreased by about 9 percent on weaker residential and agricultural system sales versus a difficult sales comparison in the fourth quarter 2016. Sales of other surface pumping equipment decreased by about 4 percent primarily in irrigation and agricultural related products.

[0000038725-18-000020:8k_2_02:25]
Water Systems sales in markets outside the U.S. and Canada increased by about 6 percent overall. The impact of foreign currency translation increased sales by about 2 percent.  International Water Systems sales were led by improved sales in Europe, the Middle East, Africa and Asia Pacific, but were offset by lower sales in Latin America when compared to the fourth quarter 2016.  Sales in Brazil declined by about 8 percent in the quarter.

[0000038725-18-000020:8k_2_02:26]
Water Systems operating income was $19.5 million in the fourth quarter 2017, down $3.1 million versus the fourth quarter 2016.  Water Systems operating income before restructuring was $20.6 million in the fourth quarter 2017, down $2.2 million versus the fourth quarter 2016.  The decline in operating income is primarily related to higher raw material and freight costs, product sales mix shifts and lower revenue in Brazil.

[0000038725-18-000020:8k_2_02:27]
Fueling Systems

[0000038725-18-000020:8k_2_02:28]
Fueling Systems sales were $67.9 million in the fourth quarter 2017, versus the fourth quarter 2016 sales of $61.8 million.  Fueling System sales increased by about 3 percent due to foreign currency translation.

[0000038725-18-000020:8k_2_02:29]
Fueling Systems sales in the U.S. and Canada declined by about 2 percent compared to the fourth quarter 2016.  The decrease was in piping and dispensing products.  Outside the U.S. and Canada, Fueling Systems revenues grew by about 26 percent, led by stronger sales in China, Southeast Asia and Europe.

[0000038725-18-000020:8k_2_02:30]
Fueling Systems operating income was $17.0 million in the fourth quarter of 2017, compared to $15.4 million in the fourth quarter of 2016.  Fueling Systems operating income before restructuring was $18.6 million in the fourth quarter of 2017, compared to $15.5 million in the fourth quarter of 2016.

[0000038725-18-000020:8k_2_02:31]
Distribution

[0000038725-18-000020:8k_2_02:32]
Distribution sales were $49.5 million in the fourth quarter 2017.  Management estimates fourth quarter Distribution sales declined by about 11 percent from the fourth quarter of 2016 primarily driven by supply chain disruptions and weak end market conditions in the West and Southeast regions of the United States.  The Distribution segment recorded an operating loss of $2.0 million in the fourth quarter of 2017.

[0000038725-18-000020:8k_2_02:33]
Overall

[0000038725-18-000020:8k_2_02:34]
The Company’s consolidated gross profit was $94.6 million for the fourth quarter of 2017, an increase from the fourth quarter of 2016 gross profit of $81.0 million. The gross profit as a percent of net sales was 32.8 percent in the fourth quarter of 2017 versus 33.8 percent during the fourth quarter 2016.  The gross profit increase was primarily due to higher sales.  The decline in gross profit margin percentage is primarily due to product and geographic sales mix shifts and higher raw material costs.

[0000038725-18-000020:8k_2_02:35]
Selling, general, and administrative (SG&A) expenses were $69.4 million in the fourth quarter of 2017 compared to $55.5 million in the fourth quarter of the prior year.  The increase in SG&A expenses from acquired businesses was $16.3 million.  Excluding the acquired entities, the Company’s SG&A expenses in the fourth quarter of 2017 were $53.1 million.

[0000038725-18-000020:8k_2_02:36]
Restructuring expenses for the fourth quarter of 2017 were $2.7 million and reduced fully diluted earnings per share by approximately $0.04.  The Company began the process of closing a Fueling Systems joint venture in India during the quarter and recorded $1.6 million of restructuring expenses.  The Company estimates there will be $1.5 million of additional expenses in 2018 related to the closure of this joint venture. The charge is primarily related to the write down and liquidation of the joint venture’s assets.  The balance of the fourth quarter 2017 restructuring expenses were primarily related to continuing realignment efforts in Brazil.  Restructuring expenses in the fourth quarter 2016 were $0.2 million.

[0000038725-18-000020:8k_2_02:37]
In the fourth quarter ended December 31, 2017, the Company recorded a net tax expense of $10.2 million, or $0.21 EPS relating to the enactment of the U.S. Tax Cuts and Jobs Act of 2017. This expense was primarily derived from the recognition of a U.S. tax liability for the deemed repatriation of foreign earnings partially offset by the revaluation of other deferred tax liabilities.  In 2018, the Company estimates its effective tax rate will be 13 to 17 percent, or about 10 percentage points lower than the effective tax rate of 25 percent in 2017. The lower tax rate is primarily the result of the U.S. Tax Cuts and Jobs Act of 2017.

[0000038725-18-000020:8k_2_02:38]
The Company ended 2017 with a cash balance of about $67 million versus about $104 million at the end of 2016, down primarily due to acquisitions and increased working capital.  Inventory levels at the end of 2017 were $312 million versus year end 2016 of $203 million.  About $65 million of the inventory increase is due to the Distribution segment acquisitions.

[0000038725-18-000020:8k_2_02:39]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-18-000020:8k_2_02:40]
“To set a baseline for 2018, here is a summary of the various components impacting our 2017 Earnings Per Share before restructuring and the impact of the U.S. Tax Cuts and Jobs Act:

[0000038725-18-000020:8k_2_02:41]
Full Year 2017 - Earnings Per Share Summary

[0000038725-18-000020:8k_2_02:42]
| 2017 Fully Diluted Earnings Per Share (EPS) Reported |  | $ | 1.65 |  |
| 2017 Restructuring Charges, per share, net of tax |  | $ | 0.06 |  |
| 2017 Impact of the U.S. Tax Cuts and Jobs Act changes |  | $ | 0.21 |  |
| 2017 Full Year Earnings Per Share Before Restructuring and U.S. Tax Cuts and Jobs Act Changes |  | $ | 1.92 |  |

[0000038725-18-000020:8k_2_02:43]
Looking forward, we are optimistic about our opportunities for growth.  We expect our Water Systems and Distribution segments to grow about 4 to 5 percent organically, in part due to our view that many of the International Water Systems markets in which we compete have generally seen their bottom and will begin to rebound in 2018.  Our businesses globally are facing raw material and freight costs inflation,

[0000038725-18-000020:8k_2_02:44]
which we have or intend to offset with price increases.  We also note that the Distribution segment will have greater seasonality in reported revenue and earnings than our Water Systems businesses.

[0000038725-18-000020:8k_2_02:45]
In the Fueling Systems segment, we continue to make inroads with U.S. retailers and are pursuing multiple international sales opportunities, particularly in China, for our market leading product portfolio.  We expect Fueling Systems organic growth to be between 5 and 7 percent in 2018. Overall, this translates to the following Earnings Per Share guidance:”

[0000038725-18-000020:8k_2_02:46]
|  | Guidance Range |
|  | Low |  | High |
| 2017 Earnings Per Share Before Restructuring |  |  |  |
| and U.S. Tax Cuts and Jobs Act Changes | $ | 1.92 |  |  | $ | 1.92 |  |
| Net Change in Tax, Rate less Discrete Items | $ | 0.07 |  | to | $ | 0.09 |  |
| All Other EPS Growth | $ | 0.17 |  | to | $ | 0.27 |  |
| 2018 Earnings Per Share Guidance | $ | 2.16 |  | to | $ | 2.28 |  |

[0000038725-18-000020:8k_2_02:47]
A conference call to review earnings and other developments in the business will commence at 9:00 am EST.  The fourth quarter and fiscal year 2017 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-18-000020:8k_2_02:48]
https://edge.media-server.com/m6/p/javgra8s

[0000038725-18-000020:8k_2_02:49]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 6570309.

[0000038725-18-000020:8k_2_02:50]
A replay of the conference call will be available Tuesday, February 20, 2018 at 12:00 noon EST through noon EST on Tuesday, February 27, 2018, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 6570309.

[0000038725-18-000020:8k_2_02:51]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-18-000020:8k_2_02:52]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Fourth Quarter Ended |  | Fiscal Year End |
|  | December 31, 2017 |  | December 31, 2016 |  | December 31, 2017 |  | December 31, 2016 |
| Net sales | $ | 288,195 |  |  | $ | 239,590 |  |  | $ | 1,124,909 |  |  | $ | 949,856 |  |
| Cost of sales | 193,624 |  |  | 158,567 |  |  | 747,927 |  |  | 618,450 |  |
| Gross profit | 94,571 |  |  | 81,023 |  |  | 376,982 |  |  | 331,406 |  |
| Selling, general, and administrative expenses | 69,411 |  |  | 55,537 |  |  | 265,686 |  |  | 221,209 |  |
| Restructuring (income)/expense | 2,732 |  |  | 252 |  |  | 4,307 |  |  | (598 | ) |
| Operating income | 22,428 |  |  | 25,234 |  |  | 106,989 |  |  | 110,795 |  |
| Interest expense | (2,267 | ) |  | (2,101 | ) |  | (10,322 | ) |  | (8,732 | ) |
| Other income/(expense), net | 81 |  |  | (1,794 | ) |  | 6,895 |  |  | 993 |  |
| Foreign exchange income | 729 |  |  | 420 |  |  | 1,025 |  |  | 1,057 |  |
| Income before income taxes | 20,971 |  |  | 21,759 |  |  | 104,587 |  |  | 104,113 |  |
| Income tax expense | 13,104 |  |  | 3,958 |  |  | 25,994 |  |  | 24,798 |  |
| Net income | $ | 7,867 |  |  | $ | 17,801 |  |  | $ | 78,593 |  |  | $ | 79,315 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | 204 |  |  | (159 | ) |  | (413 | ) |  | (570 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 8,071 |  |  | $ | 17,642 |  |  | $ | 78,180 |  |  | $ | 78,745 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.17 |  |  | $ | 0.37 |  |  | $ | 1.67 |  |  | $ | 1.67 |  |
| Diluted | $ | 0.17 |  |  | $ | 0.37 |  |  | $ | 1.65 |  |  | $ | 1.65 |  |

[0000038725-18-000020:8k_2_02:53]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | December 31, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 67,233 |  |  | $ | 104,331 |  |
| Receivables | 171,007 |  |  | 145,999 |  |
| Inventories | 312,325 |  |  | 203,471 |  |
| Other current assets | 38,566 |  |  | 30,018 |  |
| Total current assets | 589,131 |  |  | 483,819 |  |
| Property, plant, and equipment, net | 215,694 |  |  | 196,137 |  |
| Goodwill and other assets | 380,528 |  |  | 359,949 |  |
| Total assets | $ | 1,185,353 |  |  | $ | 1,039,905 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 79,348 |  |  | $ | 63,927 |  |
| Accrued expenses and other current liabilities | 66,100 |  |  | 60,119 |  |
| Current maturities of long-term debt and short-term borrowings | 100,453 |  |  | 33,715 |  |
| Total current liabilities | 245,901 |  |  | 157,761 |  |
| Long-term debt | 125,596 |  |  | 156,544 |  |
| Income taxes payable non-current | 17,391 |  |  | — |  |
| Deferred income taxes | 30,913 |  |  | 40,460 |  |
| Employee benefit plans | 42,178 |  |  | 45,307 |  |
| Other long-term liabilities | 19,251 |  |  | 17,093 |  |
| Redeemable noncontrolling interest | 1,502 |  |  | 7,652 |  |
| Total equity | 702,621 |  |  | 615,088 |  |
| Total liabilities and equity | $ | 1,185,353 |  |  | $ | 1,039,905 |  |

[0000038725-18-000020:8k_2_02:54]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
| (In thousands) | 2017 |  | 2016 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 78,593 |  |  | $ | 79,315 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 38,506 |  |  | 35,534 |  |
| Share-based compensation | 7,109 |  |  | 6,889 |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | 10,198 |  |  | — |  |
| Gain on equity investment | (5,165 | ) |  | — |  |
| Other | (5,764 | ) |  | 2,672 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | 9,948 |  |  | (21,334 | ) |
| Inventory | (46,372 | ) |  | (7,636 | ) |
| Accounts payable and accrued expenses | (11,071 | ) |  | 11,782 |  |
| Other | (9,228 | ) |  | 8,152 |  |
| Net cash flows from operating activities | 66,754 |  |  | 115,374 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (33,484 | ) |  | (39,136 | ) |
| Proceeds from sale of property, plant, and equipment | 211 |  |  | 6,028 |  |
| Acquisitions and investments | (51,783 | ) |  | (1,007 | ) |
| Other investing activities | 355 |  |  | 346 |  |
| Net cash flows from investing activities | (84,701 | ) |  | (33,769 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 1,882 |  |  | (30,385 | ) |
| Proceeds from issuance of common stock | 4,497 |  |  | 5,243 |  |
| Purchases of common stock | (3,621 | ) |  | (7,422 | ) |
| Dividends paid | (20,289 | ) |  | (19,137 | ) |
| Purchase of redeemable non-controlling shares | (5,047 | ) |  | — |  |
| Net cash flows from financing activities | (22,578 | ) |  | (51,701 | ) |
| Effect of exchange rate changes on cash | 3,427 |  |  | (7,134 | ) |
| Net change in cash and equivalents | (37,098 | ) |  | 22,770 |  |
| Cash and equivalents at beginning of period | 104,331 |  |  | 81,561 |  |
| Cash and equivalents at end of period | $ | 67,233 |  |  | $ | 104,331 |  |
