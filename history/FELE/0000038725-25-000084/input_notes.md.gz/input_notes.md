# FELE notes — 0000038725-25-000084


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-25-000084:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2024, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2025, and for the first quarters ended March 31, 2025 and March 31, 2024 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2025. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-25-000084:notes:2]
ACQUISITIONS
2025

[0000038725-25-000084:notes:3]
Barnes

[0000038725-25-000084:notes:4]
In March 2025, the Company acquired 100 percent of Barnes de Colombia S.A. (Barnes), a leading manufacturer and distributor of industrial and commercial pumps based in Cota, Cundinamarca, Colombia, for total upfront cash consideration of $96.6 million, net of cash acquired.

[0000038725-25-000084:notes:5]
The valuation of assets acquired and liabilities assumed has not yet been finalized as of March 31, 2025. As a result, the Company recorded preliminary estimates for the fair value of assets acquired and liabilities assumed as of the acquisition date. Finalization of the valuation during the measurement period could result in a change in the amounts recorded for the acquisition date fair value of intangible assets, goodwill and income taxes among other items. The completion of the valuation will occur no later than one year from the acquisition date. The following table summarizes the preliminary fair values of the assets acquired and liabilities assumed as of the acquisition date:

[0000038725-25-000084:notes:6]
| (in millions) |  |
| Assets acquired and liabilities assumed |  |
| Cash and cash equivalents | $ | 3.4 |  |
| Receivables | 9.6 |  |
| Inventories | 25.2 |  |
| Other current assets | 4.2 |  |
| Property, plant and equipment | 11.8 |  |
| Goodwill | 45.8 |  |
| Other intangible assets | 45.5 |  |
| Other non-current assets | 3.6 |  |
| Debt | (12.6) |  |
| Accounts payable | (9.7) |  |
| Accrued expenses and other current liabilities | (3.6) |  |
| Deferred tax liabilities | (20.4) |  |
| Other non-current liabilities | $ | (2.8) |  |
| Total assets acquired and liabilities assumed | $ | 100.0 |  |

[0000038725-25-000084:notes:7]
The Company allocated $33.4 million of the total consideration to customer relationships with a useful life of 8 years, $9.3 million to trade names with a useful life of 11 years, and $2.8 million to developed technology with a useful life of 7 years. The fair values of the intangible assets were determined using the income approach. The discount rates used to measure the intangible assets were 19 percent for customer relationships, 18 percent for trade names, and 18 percent for developed technology. The Company considers the fair value of the intangible assets to be Level 3 measurements due to the significant estimates and assumptions used by management in establishing the estimated fair values.

[0000038725-25-000084:notes:8]
The goodwill, which is not deductible for tax purposes, includes the value of an assembled workforce, potential future technologies as well as the overall strategic benefits provided to the Company’s product portfolio and is included in the Water Systems segment.

[0000038725-25-000084:notes:9]
The results of operations of the acquired business have been included in the Company’s consolidated statement of income since the date the business was acquired.  The Barnes acquisition contributed $3.2 million of net sales for the three months ended March 31, 2025 while the impact on net income was not significant. The Company has not presented pro forma financial information for the Barnes acquisition because its results are not material to the Company’s condensed consolidated financial statements.

[0000038725-25-000084:notes:10]
PumpEng

[0000038725-25-000084:notes:11]
In February 2025, the Company acquired 100 percent of the ownership interests of PumpEng Pty Ltd ("PumpEng") for a purchase price of AUD 24.0 million (approximately $15.0 million). PumpEng, based in Australia, specializes in the design, manufacture and service of submersible pumps for the mining sector.

[0000038725-25-000084:notes:12]
The valuation of assets acquired and liabilities assumed has not yet been finalized as of March 31, 2025. As a result, the Company recorded preliminary estimates for the fair value of assets acquired and liabilities assumed as of the acquisition date. Finalization of the valuation during the measurement period could result in a change in the amounts recorded for the acquisition date fair value of intangible assets, goodwill and income taxes among other items. The completion of the valuation will occur no later than one year from the acquisition date. The purchase price was primarily allocated to goodwill and other intangible assets as well as accounts receivable, inventory and fixed assets. The goodwill, which is not deductible for tax purposes, includes the value of an assembled workforce, potential future technologies as well as the overall strategic benefits provided to the Company’s product portfolio and is included in the Water Systems segment.

[0000038725-25-000084:notes:13]
The Company has not included various disclosures for the PumpEng acquisition including presenting separate results of operations of the acquired company since the closing of the acquisition or combined pro forma financial information of the Company and the acquired business, as the Company does not consider the acquisition to be material.

[0000038725-25-000084:notes:14]
Acquisition costs associated with the 2025 acquisitions were $1.5 million in the three months ended March 31, 2025.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-25-000084:notes:15]
[same as prior period, unchanged from 0000038725-24-000167:notes:23]

[0000038725-25-000084:notes:16]
| (In millions) |  | March 31, 2025 |  | December 31, 2024 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 301.8 |  |  | $ | (133.8) |  |  | $ | 263.4 |  |  | $ | (128.8) |  |
| Patents |  | 7.3 |  |  | (7.3) |  |  | 7.2 |  |  | (7.2) |  |
| Technology |  | 10.2 |  |  | (7.5) |  |  | 7.5 |  |  | (7.5) |  |
| Trade names |  | 56.4 |  |  | (8.8) |  |  | 44.5 |  |  | (8.1) |  |
| Other |  | 2.9 |  |  | (2.5) |  |  | 2.8 |  |  | (2.4) |  |
| Total |  | $ | 378.6 |  |  | $ | (159.9) |  |  | $ | 325.4 |  |  | $ | (154.0) |  |
| Non-amortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.1 |  |  | — |  |  | 41.6 |  |  | — |  |
| Total intangibles |  | $ | 420.7 |  |  | $ | (159.9) |  |  | $ | 367.0 |  |  | $ | (154.0) |  |

[0000038725-25-000084:notes:17]
Amortization expense related to intangible assets for the first quarters ended March 31, 2025 and March 31, 2024 was $5.1 million and $4.8 million, respectively.

[0000038725-25-000084:notes:18]
The change in the carrying amount of goodwill by reportable segment for the three months ended March 31, 2025 is as follows:

[0000038725-25-000084:notes:19]
| (In millions) |  |  |
|  |  | Water Systems |  | Energy Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2024 |  | $ | 217.6 |  |  | $ | 70.3 |  |  | $ | 50.6 |  |  | $ | 338.5 |  |
| Acquisitions |  | 50.7 |  |  | — |  |  | — |  |  | 50.7 |  |
| Adjustments to prior year acquisitions |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Foreign currency translation |  | 2.1 |  |  | 0.1 |  |  | — |  |  | 2.2 |  |
| Balance as of March 31, 2025 |  | $ | 270.5 |  |  | $ | 70.4 |  |  | $ | 50.6 |  |  | $ | 391.5 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-25-000084:notes:20]
[same as prior period, unchanged from 0000038725-24-000167:notes:32]

[0000038725-25-000084:notes:21]
| (In millions) |  | March 31, 2025 |  | December 31, 2024 |
| Salaries, wages, and commissions |  | $ | 36.2 |  |  | $ | 49.0 |  |
| Product warranty costs |  | 9.1 |  |  | 9.0 |  |
| Insurance |  | 2.5 |  |  | 2.4 |  |
| Employee benefits |  | 12.1 |  |  | 19.9 |  |
| Other |  | 38.1 |  |  | 39.5 |  |
| Total |  | $ | 98.0 |  |  | $ | 119.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0000038725-25-000084:notes:22]
DEBT
Debt consisted of the following:

[0000038725-25-000084:notes:23]
| (In millions) |  | March 31, 2025 |  | December 31, 2024 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 63.8 |  |  | 41.4 |  |
| Tax increment financing debt |  | 12.2 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 13.6 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 164.6 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (149.7) |  |  | (117.8) |  |
| Long-term debt |  | $ | 14.9 |  |  | $ | 11.6 |  |

[0000038725-25-000084:notes:24]
Credit Agreement

[0000038725-25-000084:notes:25]
As of March 31, 2025, the Company had $63.8 million outstanding borrowings with a weighted-average interest rate of 3.3 percent, $4.6 million in letters of credit outstanding, and $281.6 million of available capacity under its credit agreement. As of December 31, 2024, the Company had $41.4 million outstanding borrowings with a weighted-average interest rate of 3.7 percent, $4.5 million in letters of credit outstanding, and $304.1 million of available capacity under its credit agreement.

[0000038725-25-000084:notes:26]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $17.0 million. As of March 31, 2025, there were $1.1 million outstanding borrowings and $15.9 million of available capacity under these lines of credit. As of December 31, 2024, there were $16.8 million overdraft lines of credit with no outstanding borrowings and $16.8 million of available capacity under these lines of credit.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-25-000084:notes:27]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February

[0000038725-25-000084:notes:28]
2023. The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.

[0000038725-25-000084:notes:29]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-25-000084:notes:30]
At March 31, 2025, the Company had $10.9 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

[0000038725-25-000084:notes:31]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2025, are as follows:

[0000038725-25-000084:notes:32]
| (In millions) |  |  |
| Balance as of December 31, 2024 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 2.8 |  |
| Reductions for payments made |  | (2.7) |  |
| Balance as of March 31, 2025 |  | $ | 9.1 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-25-000084:notes:33]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the first quarters ended March 31, 2025 and March 31, 2024:

[0000038725-25-000084:notes:34]
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2024 | $ | 4,571 |  |  | $ | 363,956 |  |  | $ | 1,151,575 |  |  |  |  |  |  | $ | (254,003) |  |  | $ | 2,511 |  |  | $ | 1,268,610 |  |  | $ | 1,224 |  |
| Net income | — |  |  | — |  |  | 30,962 |  |  |  |  |  |  | — |  |  | 316 |  |  | 31,278 |  |  | 96 |  |
| Dividends on common stock ($0.265/share) | — |  |  | — |  |  | (12,198) |  |  |  |  |  |  | — |  |  | — |  |  | (12,198) |  |  | — |  |
| Common stock issued | 2 |  |  | 1,436 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 1,438 |  |  | — |  |
| Common stock repurchased | (8) |  |  | — |  |  | (7,466) |  |  |  |  |  |  | — |  |  | — |  |  | (7,474) |  |  | — |  |
| Share-based compensation | 7 |  |  | 4,955 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 4,962 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 13,147 |  |  | (152) |  |  | 12,995 |  |  | 53 |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 311 |  |  | — |  |  | 311 |  |  | — |  |
| Balance as of March 31, 2025 | $ | 4,572 |  |  | $ | 370,347 |  |  | $ | 1,162,873 |  |  |  |  |  |  | $ | (240,545) |  |  | $ | 2,675 |  |  | $ | 1,299,922 |  |  | $ | 1,373 |  |
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2023 | $ | 4,607 |  |  | $ | 344,717 |  |  | $ | 1,078,512 |  |  |  |  |  |  | $ | (221,114) |  |  | $ | 2,426 |  |  | $ | 1,209,148 |  |  | $ | 1,145 |  |
| Net income | — |  |  | — |  |  | 32,959 |  |  |  |  |  |  | — |  |  | 169 |  |  | 33,128 |  |  | (36) |  |
| Dividends on common stock ($0.250/share) | — |  |  | — |  |  | (11,560) |  |  |  |  |  |  | — |  |  | — |  |  | (11,560) |  |  | — |  |
| Common stock issued | 7 |  |  | 4,043 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 4,050 |  |  | — |  |
| Common stock repurchased | (10) |  |  | — |  |  | (9,037) |  |  |  |  |  |  | — |  |  | — |  |  | (9,047) |  |  | — |  |
| Share-based compensation | 5 |  |  | 4,037 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 4,042 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (7,174) |  |  | (41) |  |  | (7,215) |  |  | — |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 433 |  |  | — |  |  | 433 |  |  | — |  |
| Balance as of March 31, 2024 | $ | 4,609 |  |  | $ | 352,797 |  |  | $ | 1,090,874 |  |  |  |  |  |  | $ | (227,855) |  |  | $ | 2,554 |  |  | $ | 1,222,979 |  |  | $ | 1,109 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-25-000084:notes:35]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the three months ended March 31, 2025 and March 31, 2024, are summarized below:

[0000038725-25-000084:notes:36]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| For the three months ended March 31, 2025: |  |  |
| Balance as of December 31, 2024 | $ | (215.0) |  |  | $ | (39.0) |  |  | $ | (254.0) |  |
| Other comprehensive income/(loss) before reclassifications | 13.1 |  |  | — |  |  | 13.1 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.3 |  |  | 0.3 |  |
| Net other comprehensive income/(loss) | 13.1 |  |  | 0.3 |  |  | 13.4 |  |
| Balance as of March 31, 2025 | $ | (201.9) |  |  | $ | (38.7) |  |  | $ | (240.6) |  |
| For the three months ended March 31, 2024: |  |  |  |  |  |
| Balance as of December 31, 2023 | $ | (179.3) |  |  | $ | (41.8) |  |  | $ | (221.1) |  |
| Other comprehensive income/(loss) before reclassifications | (7.2) |  |  | — |  |  | (7.2) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.4 |  |  | 0.4 |  |
| Net other comprehensive income/(loss) | (7.2) |  |  | 0.4 |  |  | (6.8) |  |
| Balance as of March 31, 2024 | $ | (186.5) |  |  | $ | (41.4) |  |  | $ | (227.9) |  |

[0000038725-25-000084:notes:37]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 9 for additional details) and is included in the "Other (expense) income, net" line of the Company's condensed consolidated statements of income.

[0000038725-25-000084:notes:38]
(2) Net of tax expense of $0.1 million for the three months ended March 31, 2025 and March 31, 2024, respectively.

[0000038725-25-000084:notes:39]
[same as prior period, unchanged from 0000038725-24-000167:notes:57]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-25-000084:notes:40]
EMPLOYEE BENEFIT PLANS
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the first quarters ended March 31, 2025 and March 31, 2024:

[0000038725-25-000084:notes:41]
| (In millions) | Pension Benefits |
|  | First Quarter Ended |  |  |
|  | March 31, 2025 |  | March 31, 2024 |  |  |  |  |
| Service cost | $ | — |  |  | $ | 0.1 |  |  |  |  |  |
| Interest cost | 1.4 |  |  | 1.5 |  |  |  |  |  |
| Expected return on assets | (1.6) |  |  | (1.9) |  |  |  |  |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  |  |  |  |
| Actuarial loss | 0.4 |  |  | 0.6 |  |  |  |  |  |
| Settlement cost | — |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 0.2 |  |  | $ | 0.3 |  |  |  |  |  |

[0000038725-25-000084:notes:42]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the first quarters ended March 31, 2025 and March 31, 2024:

[0000038725-25-000084:notes:43]
| (In millions) | Other Benefits |
|  | First Quarter Ended |  |  |
|  | March 31, 2025 |  | March 31, 2024 |  |  |  |  |
| Service cost | $ | — |  |  | $ | — |  |  |  |  |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  |  |  |  |
| Expected return on assets | — |  |  | — |  |  |  |  |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  |  |  |  |
| Actuarial loss | — |  |  | — |  |  |  |  |  |
| Settlement cost | — |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.1 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-25-000084:notes:44]
INCOME TAXES
The Company’s effective tax rate for the three-month period ended March 31, 2025 was 25.0 percent as compared to 21.8 percent for the three-month period ended March 31, 2024. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to U.S state taxes and foreign earnings taxed at rates higher than the U.S. statutory rate partially offset by the recognition of the U.S. foreign-derived intangible income (FDII) provisions.

[0000038725-25-000084:notes:45]
The increase in the effective tax rate for the first quarter of 2025 compared to the comparable period in the prior year was primarily due to an increase in foreign earnings taxed at rates higher than the U.S. statutory rate, a decreased benefit in the U.S. foreign-derived intangible income (FDII) provision related to a prior year prepayment of inventory from foreign subsidiaries, and less favorable discrete events in 2025, primarily related to excess tax benefits from share-based compensation.

[0000038725-25-000084:notes:46]
During the first quarter of 2025, the Company recorded additional unrecognized tax benefits of $1.8 million. This amount is associated with uncertain tax positions taken by newly acquired companies in tax years prior to the acquisition of these companies. The stock purchase agreement related to the acquisition provides the Company the right to recover tax liabilities related to pre-acquisition tax years from the sellers and has accordingly recognized an indemnification receivable.


## us-gaap:EarningsPerShareTextBlock

[0000038725-25-000084:notes:47]
[same as prior period, unchanged from 0000038725-24-000167:notes:45]

[0000038725-25-000084:notes:48]
[same as prior period, unchanged from 0000038725-24-000167:notes:46]

[0000038725-25-000084:notes:49]
[same as prior period, unchanged from 0000038725-24-000167:notes:47]

[0000038725-25-000084:notes:50]
|  | First Quarter Ended |  |  |
| (In millions, except per share amounts) | March 31, 2025 |  | March 31, 2024 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 31.0 |  |  | $ | 33.0 |  |  |  |  |  |
| Less: Earnings allocated to participating securities | 0.1 |  |  | 0.1 |  |  |  |  |  |
| Net income available to common shareholders | $ | 30.9 |  |  | $ | 32.9 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 45.7 |  |  | 46.1 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors | 0.6 |  |  | 0.6 |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 46.3 |  |  | 46.7 |  |  |  |  |  |
| Basic earnings per share | $ | 0.67 |  |  | $ | 0.71 |  |  |  |  |  |
| Diluted earnings per share | $ | 0.67 |  |  | $ | 0.70 |  |  |  |  |  |

[0000038725-25-000084:notes:51]
There were 0.1 million stock options outstanding for the first quarters ended March 31, 2025 and March 31, 2024, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-25-000084:notes:52]
FINANCIAL INSTRUMENTS
The Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of March 31, 2025 and December 31, 2024, the swap had a notional value based on 250,000 shares. For the first quarters ended March 31, 2025 and March 31, 2024 , changes in the fair value of the swap resulted in a loss of $1.2 million and a gain of $2.1 million, respectively. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.

[0000038725-25-000084:notes:53]
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of March 31, 2025, the Company had a notional amount of $116.9 million in forward currency contracts outstanding and the related fair value of those contracts was $3.1 million. The forward currency contracts asset is recorded within the "Receivables" line of the condensed consolidated balance sheets. As of December 31, 2024, the Company had no foreign currency contracts outstanding.  For the first quarters ended March 31, 2025 and March 31, 2024, changes in the fair value of the forward currency contracts resulted in gains of $4.4 million and $0.6 million, respectively. These gains are recorded in the Company's condensed consolidated statements of income within the "Foreign exchange expense, net" line.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-25-000084:notes:54]
[same as prior period, unchanged from 0000038725-24-000167:notes:11]

[0000038725-25-000084:notes:55]
[same as prior period, unchanged from 0000038725-24-000167:notes:12]

[0000038725-25-000084:notes:56]
[same as prior period, unchanged from 0000038725-24-000167:notes:13]

[0000038725-25-000084:notes:57]
[same as prior period, unchanged from 0000038725-24-000167:notes:14]

[0000038725-25-000084:notes:58]
As of March 31, 2025 and December 31, 2024, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-25-000084:notes:59]
| (In millions) | March 31, 2025 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 7.7 |  | $ | 7.7 |  | $ | — |  | $ | — |  |
| Forward currency contracts | 3.1 |  | — |  | 3.1 |  | — |  |
| Total assets | $ | 10.8 |  | $ | 7.7 |  | $ | 3.1 |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Share swap transaction | $ | 1.2 |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| Total liabilities | $ | 1.2 |  | $ | 1.2 |  | $ | — |  | $ | — |  |
| (In millions) | December 31, 2024 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 5.0 |  | $ | 5.0 |  | $ | — |  | $ | — |  |
| Total assets | $ | 5.0 |  | $ | 5.0 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Share swap transaction | $ | 2.5 |  | $ | 2.5 |  | $ | — |  | $ | — |  |
| Contingent payments related to acquisition | $ | 5.0 |  | $ | — |  | $ | — |  | $ | 5.0 |  |
| Total liabilities | $ | 7.5 |  | $ | 2.5 |  | $ | — |  | $ | 5.0 |  |

[0000038725-25-000084:notes:60]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The forward currency contracts asset is recorded within the "Receivables" line of the condensed consolidated balance sheets. The share swap transaction liability is recorded within the "Accounts payable" line of the condensed consolidated balance sheets. The forward currency contracts and share swap transaction are further described in Note 12 - Financial Instruments.

[0000038725-25-000084:notes:61]
The Company's Level 3 category includes contingent consideration related to acquisitions, which valuation inputs are unobservable and significant to the fair value measurement.  Projections and estimated probabilities are used to estimate future contingent earn-out payments, which are discounted back to present value to compute contingent earn-out liabilities. The following table provides a roll-forward of the contingent consideration liability, which is included in "Accrued expenses and other current liabilities" as of March 31, 2025 and March 31, 2024:

[0000038725-25-000084:notes:62]
|  | First Quarter Ended |
| (In millions) | March 31, 2025 | March 31, 2024 |
| Fair value at beginning of period | $ | 5.0 |  | $ | 3.0 |  |
| Adjustments to prior year acquisition | — |  | 1.3 |  |
| Change in fair value recognized in earnings | — |  | 0.2 |  |
| Payments | (5.0) |  | — |  |
| Fair value at end of period | $ | — |  | $ | 4.5 |  |

[0000038725-25-000084:notes:63]
Total debt, including current maturities, have carrying amounts of $164.6 million and $129.4 million and estimated fair values of $163.5 million and $128.0 million as of March 31, 2025 and December 31, 2024, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-25-000084:notes:64]
SEGMENT AND GEOGRAPHIC INFORMATION
The Company’s business consists of the Water Systems, Distribution, and Energy Systems reportable segments, based on the principal end market served. The Company includes unallocated corporate expenses and intercompany eliminations that are not part of a reportable segment in its reconciliations to consolidated results.

[0000038725-25-000084:notes:65]
The accounting policies of the operating segments are the same as those described in Note 1 of the Company's Annual Report on Form 10-K for the year ended December 31, 2024. Revenue is recognized based on the invoice price at the point in time when the customer obtains control of the product, which is typically upon shipment to the customer. The Water Systems and Energy Systems segments include manufacturing operations and supply certain components and finished goods, both between segments and to the Distribution segment. The Company reports these product transfers between Water Systems and Energy Systems as inventory transfers as a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes. The Company reports intersegment transfers from Water Systems to Distribution as intersegment revenue at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water Systems and Distribution segments.

[0000038725-25-000084:notes:66]
The Company's chief operating decision maker is its Chief Executive Officer. Performance is evaluated based on the sales and operating income of the segments. Operating income and margin are used to evaluate income generated from segment assets in deciding whether to reinvest profits into each segment or other parts of the entity. Operating income is also used to monitor budget versus actual results, for purposes of determining portions of management compensation and for benchmarking against similar measures used by peers and competitors. These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented as corporate expenses are not allocated to segments. Interest expense, other income, net, foreign exchange expense and income tax expense are also not allocated to each segment.

[0000038725-25-000084:notes:67]
[same as prior period, unchanged from 0000038725-24-000167:notes:60]

[0000038725-25-000084:notes:68]
| March 31, 2025 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 246.5 |  |  | $ | 141.9 |  |  | $ | 66.8 |  |  | $ | 455.2 |  |
| Intersegment sales | 40.8 |  |  | — |  |  | — |  |  | 40.8 |  |
|  | $ | 287.3 |  |  | $ | 141.9 |  |  | $ | 66.8 |  |  | $ | 496.0 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (40.8) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 455.2 |  |
| Cost of sales | $ | 191.3 |  |  | $ | 102.4 |  |  | $ | 34.3 |  |  |  |
| Selling, general and administrative expenses | 52.6 |  |  | 37.2 |  |  | 10.6 |  |  |  |
| Restructuring expense | — |  |  | 0.2 |  |  | — |  |  |  |
| Segment operating income | $ | 43.4 |  |  | $ | 2.1 |  |  | $ | 21.9 |  |  | $ | 67.4 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | (4.1) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (19.2) |  |
| Interest expense |  |  |  |  |  |  | (1.8) |  |
| Other income, net |  |  |  |  |  |  | 0.8 |  |
| Foreign exchange expense |  |  |  |  |  |  | (1.3) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 41.8 |  |

[0000038725-25-000084:notes:69]
| March 31, 2024 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 251.8 |  |  | $ | 147.0 |  |  | $ | 62.1 |  |  | $ | 460.9 |  |
| Intersegment sales | 34.8 |  |  | — |  |  | — |  |  | 34.8 |  |
|  | $ | 286.6 |  |  | $ | 147.0 |  |  | $ | 62.1 |  |  | $ | 495.7 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (34.8) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 460.9 |  |
| Cost of sales | $ | 189.3 |  |  | $ | 107.4 |  |  | $ | 32.7 |  |  |  |
| Selling, general and administrative expenses | 50.2 |  |  | 37.8 |  |  | 10.6 |  |  |  |
| Restructuring expense | — |  |  | — |  |  | — |  |  |  |
| Segment operating income | $ | 47.1 |  |  | $ | 1.8 |  |  | $ | 18.8 |  |  | $ | 67.7 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | (2.7) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (17.1) |  |
| Interest expense |  |  |  |  |  |  | (1.4) |  |
| Other income, net |  |  |  |  |  |  | 0.7 |  |
| Foreign exchange expense |  |  |  |  |  |  | (4.9) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 42.3 |  |

[0000038725-25-000084:notes:70]
| (In millions) | March 31, 2025 |  | March 31, 2024 |  |  |  |  |
| Depreciation and amortization |  |  |  |  |  |  |  |
| Water Systems | $ | 10.2 |  |  | $ | 9.6 |  |  |  |  |  |
| Distribution | 2.3 |  |  | 2.3 |  |  |  |  |  |
| Energy Systems | 1.1 |  |  | 1.1 |  |  |  |  |  |
| Total segment depreciation and amortization | $ | 13.6 |  |  | $ | 13.0 |  |  |  |  |  |
| Corporate | 0.8 |  |  | 0.8 |  |  |  |  |  |
| Total depreciation and amortization | $ | 14.4 |  |  | $ | 13.8 |  |  |  |  |  |
| Capital Expenditures |  |  |  |  |  |  |  |
| Water Systems | 3.2 |  |  | 3.8 |  |  |  |  |  |
| Distribution | 1.7 |  |  | 2.6 |  |  |  |  |  |
| Energy Systems | 0.8 |  |  | 0.5 |  |  |  |  |  |
| Total segment capital expenditure | $ | 5.7 |  |  | $ | 6.9 |  |  |  |  |  |
| Corporate | 0.4 |  |  | 0.8 |  |  |  |  |  |
| Total capital expenditures | $ | 6.1 |  |  | $ | 7.7 |  |  |  |  |  |
| Assets |  |  |  |  |  |
| Water Systems | $ | 1,228.5 |  |  | $ | 1,053.7 |  |  |  |  |  |
| Distribution | 383.6 |  |  | 402.2 |  |  |  |  |  |
| Energy Systems | 255.6 |  |  | 254.5 |  |  |  |  |  |
| Total segment assets | 1,867.7 |  |  | 1,710.4 |  |  |  |  |  |
| Corporate | 61.2 |  |  | 62.7 |  |  |  |  |  |
| Total assets | $ | 1,928.9 |  |  | $ | 1,773.1 |  |  |  |  |  |

[0000038725-25-000084:notes:71]
Cash and property, plant and equipment are the major asset groups in “Corporate” of total assets for the quarters ended March 31, 2025 and March 31, 2024.

[0000038725-25-000084:notes:72]
The following table disaggregates the Company's net sales from contracts with customers by segment:

[0000038725-25-000084:notes:73]
|  | First Quarter Ended |  |  |
| (In millions) | March 31, 2025 |  | March 31, 2024 |  |  |  |  |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 134.9 |  |  | $ | 137.9 |  |  |  |  |  |
| Latin America | 39.5 |  |  | 41.3 |  |  |  |  |  |
| Europe, Middle East & Africa | 51.5 |  |  | 52.3 |  |  |  |  |  |
| Asia Pacific | 20.6 |  |  | 20.3 |  |  |  |  |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 40.8 |  |  | 34.8 |  |  |  |  |  |
| Total sales | 287.3 |  |  | 286.6 |  |  |  |  |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 141.9 |  |  | 147.0 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 141.9 |  |  | 147.0 |  |  |  |  |  |
| Energy Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 52.2 |  |  | 46.8 |  |  |  |  |  |
| All other | 14.6 |  |  | 15.3 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 66.8 |  |  | 62.1 |  |  |  |  |  |
| Intersegment Eliminations/Other | (40.8) |  |  | (34.8) |  |  |  |  |  |
| Consolidated | $ | 455.2 |  |  | $ | 460.9 |  |  |  |  |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000038725-25-000084:notes:74]
None of the Company’s directors or officers adopted, modified, or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement during the Company’s fiscal quarter ended March 31, 2025.
