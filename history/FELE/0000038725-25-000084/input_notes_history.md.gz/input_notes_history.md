# FELE note change history — 0000038725-24-000167 → 0000038725-25-000084


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000038725-25-000084:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February
  (was, 2024-10-31, similarity 0.8875):
[0000038725-24-000167:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.

- added (2025-05-01):
[0000038725-25-000084:note_history:2]
2023. The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.

- changed (2025-05-01):
[0000038725-25-000084:note_history:3]
At March 31, 2025, the Company had $10.9 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.
  (was, 2024-10-31, similarity 0.9699):
[0000038725-24-000167:note_history:3]
At September 30, 2024, the Company had $12.1 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

- changed (2025-05-01):
[0000038725-25-000084:note_history:4]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2025, are as follows:
  (was, 2024-10-31, similarity 0.894):
[0000038725-24-000167:note_history:4]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2024, are as follows:

- changed (2025-05-01):
[0000038725-25-000084:note_history:5]
| (In millions) |  |  |
| Balance as of December 31, 2024 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 2.8 |  |
| Reductions for payments made |  | (2.7) |  |
| Balance as of March 31, 2025 |  | $ | 9.1 |  |
  (was, 2024-10-31, similarity 0.965):
[0000038725-24-000167:note_history:5]
| (In millions) |  |  |
| Balance as of December 31, 2023 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 10.0 |  |
| Reductions for payments made |  | (10.0) |  |
| Balance as of September 30, 2024 |  | $ | 9.3 |  |

- removed (2025-05-01):
[0000038725-24-000167:note_history:6]
At September 30, 2024, the Company has a contingent consideration liability with an estimated fair value of $4.8 million that could result in a payment of up to $5.0 million if a future profitability milestone is achieved.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000038725-25-000084:note_history:7]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2024, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2025, and for the first quarters ended March 31, 2025 and March 31, 2024 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2025. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024.
  (was, 2024-10-31, similarity 0.9367):
[0000038725-24-000167:note_history:7]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2023, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2024, and for the third quarters and nine months ended September 30, 2024 and September 30, 2023 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2024. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000038725-25-000084:note_history:8]
| (In millions) |  | March 31, 2025 |  | December 31, 2024 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 63.8 |  |  | 41.4 |  |
| Tax increment financing debt |  | 12.2 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 13.6 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 164.6 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (149.7) |  |  | (117.8) |  |
| Long-term debt |  | $ | 14.9 |  |  | $ | 11.6 |  |
  (was, 2024-10-31, similarity 0.9758):
[0000038725-24-000167:note_history:8]
| (In millions) |  | September 30, 2024 |  | December 31, 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | — |  |  | 11.0 |  |
| Tax increment financing debt |  | 12.8 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.3 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 88.0 |  |  | $ | 100.5 |  |
| Less: current maturities |  | (76.4) |  |  | (12.4) |  |
| Long-term debt |  | $ | 11.6 |  |  | $ | 88.1 |  |

- added (2025-05-01):
[0000038725-25-000084:note_history:9]
As of March 31, 2025, the Company had $63.8 million outstanding borrowings with a weighted-average interest rate of 3.3 percent, $4.6 million in letters of credit outstanding, and $281.6 million of available capacity under its credit agreement. As of December 31, 2024, the Company had $41.4 million outstanding borrowings with a weighted-average interest rate of 3.7 percent, $4.5 million in letters of credit outstanding, and $304.1 million of available capacity under its credit agreement.

- added (2025-05-01):
[0000038725-25-000084:note_history:10]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $17.0 million. As of March 31, 2025, there were $1.1 million outstanding borrowings and $15.9 million of available capacity under these lines of credit. As of December 31, 2024, there were $16.8 million overdraft lines of credit with no outstanding borrowings and $16.8 million of available capacity under these lines of credit.

- removed (2025-05-01):
[0000038725-24-000167:note_history:11]
Prudential Agreement

- removed (2025-05-01):
[0000038725-24-000167:note_history:12]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates. On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million and changed the expiration date from July 30, 2024 to May 15, 2027.

- removed (2025-05-01):
[0000038725-24-000167:note_history:13]
New York Life Agreement

- removed (2025-05-01):
[0000038725-24-000167:note_history:14]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC and its affiliates (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $200.0 million and changed the expiration date from July 30, 2024 to May 15, 2027.

- removed (2025-05-01):
[0000038725-24-000167:note_history:15]
As of September 30, 2024, the Company had no outstanding borrowings, $4.6 million in letters of credit outstanding, and $345.4 million of available capacity under its credit agreement. As of December 31, 2023, the Company had $11.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $335.4 million of available capacity under its credit agreement.

- removed (2025-05-01):
[0000038725-24-000167:note_history:16]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $17.6 million. As of September 30, 2024, there were no outstanding borrowings and $17.6 million of available capacity under these lines of credit. As of December 31, 2023, there were $17.9 million overdraft lines of credit with no outstanding borrowings and $17.9 million of available capacity under these lines of credit.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000038725-25-000084:note_history:17]
| (In millions) |  | March 31, 2025 |  | December 31, 2024 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 63.8 |  |  | 41.4 |  |
| Tax increment financing debt |  | 12.2 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 13.6 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 164.6 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (149.7) |  |  | (117.8) |  |
| Long-term debt |  | $ | 14.9 |  |  | $ | 11.6 |  |
  (was, 2024-10-31, similarity 0.9758):
[0000038725-24-000167:note_history:17]
| (In millions) |  | September 30, 2024 |  | December 31, 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | — |  |  | 11.0 |  |
| Tax increment financing debt |  | 12.8 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.3 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 88.0 |  |  | $ | 100.5 |  |
| Less: current maturities |  | (76.4) |  |  | (12.4) |  |
| Long-term debt |  | $ | 11.6 |  |  | $ | 88.1 |  |
