# FELE MD&A — 0000038725-25-000084


## mdna

[0000038725-25-000084:mdna:1]
[same as prior period, unchanged from 0000038725-24-000167:mdna:1]

[0000038725-25-000084:mdna:2]
Refer to the Company's Annual Report on Form 10-K for the year ended December 31, 2024 for management’s discussion and analysis of its financial condition and results of operations. The following is management’s discussion and analysis of the Company's financial condition and results of operations for the three months ended March 31, 2025 and 2024.

[0000038725-25-000084:mdna:3]
In the first quarter of 2025, the Company acquired Barnes de Colombia S.A. (Barnes), a leading manufacturer and distributor of industrial and commercial pumps based in Colombia. Also in the first quarter of 2025, the Company acquired PumpEng Pty Ltd ("PumpEng"), an Australia-based company that specializes in the design, manufacture and service of submersible pumps for the mining sector. Acquisitions contributed approximately $5.7 million of incremental net sales in the first quarter of 2025. Refer to Note 2 in Item 1 of this Quarterly Report on Form 10-Q for additional information on the Barnes and PumpEng acquisitions.

[0000038725-25-000084:mdna:4]
The impact that the imposition of tariffs and changes to global trade policies will have on the Company's consolidated results of operations is uncertain. The Company expects tariffs on goods imported into the U.S. from Canada, Mexico, and China, and other countries upon which tariffs may be imposed, to continue to be met with retaliatory tariffs from those countries which would impact the Company's consolidated results of operations. The extent and duration of tariffs and the resulting impact on macroeconomic conditions and on the Company's business are uncertain and may depend on various factors, including negotiations between the U.S. and affected countries, retaliation imposed by other countries, tariff exemptions, negative sentiment toward U.S. companies and products, and availability of lower cost inputs that may be sourced domestically. The Company will continue to evaluate the nature and extent of the impact to its business and consolidated results of operations.

[0000038725-25-000084:mdna:5]
First Quarter 2025 vs. 2024

[0000038725-25-000084:mdna:6]
[same as prior period, unchanged from 0000038725-24-000167:mdna:3]

[0000038725-25-000084:mdna:7]
Net sales in the first quarter of 2025 decreased 1 percent from the prior-year period. The sales decrease was primarily due to lower volumes and the negative impact of foreign currency translation, partially offset by price realization and the incremental sales impact from recent acquisitions. The Company's consolidated gross profit was $163.9 million for the first quarter of 2025, an increase of $0.3 million from the prior-year period. Diluted earnings per share was $0.67 for the first quarter of 2025, a decrease of $0.03 from the prior-year period.

[0000038725-25-000084:mdna:8]
[same as prior period, unchanged from 0000038725-24-000167:mdna:5]

[0000038725-25-000084:mdna:9]
[same as prior period, unchanged from 0000038725-24-000167:mdna:6]

[0000038725-25-000084:mdna:10]
Net sales in the first quarter of 2025 were $455.2 million and decreased 1 percent as compared to the prior-year period. Sales were negatively impacted by changes in foreign exchange rates, partly due to the strengthening of the U.S. Dollar relative to the Argentine Peso and Turkish Lira. However, the Company increases prices in the local currency to offset the impact of currency devaluation in the Argentina and Turkey hyperinflationary economies. The Company's results in the first quarter of 2025 were also negatively impacted by the strengthening of the U.S. Dollar relative to the Brazilian Real and Canadian Dollar. As a result, the net negative impact of foreign currency exchange rates on net sales was 2 percent in the first quarter of 2025 compared to the same period in the prior year.

[0000038725-25-000084:mdna:11]
|  | Net Sales |
| (In millions) | Q1 2025 |  | Q1 2024 |  | 2025 v 2024 |
| Water Systems | $ | 287.3 |  |  | $ | 286.6 |  |  | $ | 0.7 |  |
| Energy Systems | 66.8 |  |  | 62.1 |  |  | 4.7 |  |
| Distribution | 141.9 |  |  | 147.0 |  |  | (5.1) |  |
| Eliminations/Other | (40.8) |  |  | (34.8) |  |  | (6.0) |  |
| Consolidated | $ | 455.2 |  |  | $ | 460.9 |  |  | $ | (5.7) |  |

[0000038725-25-000084:mdna:12]
[same as prior period, unchanged from 0000038725-24-000167:mdna:10]

[0000038725-25-000084:mdna:13]
Water Systems net sales increased less than 1 percent in the first quarter, as compared to the prior-year period. The sales growth in the first quarter was due to the incremental sales impact from recent acquisitions of approximately 2 percent and price realization.  Sales decreased 3 percent in the first quarter of 2025 due to the negative impact from foreign exchange rates, as compared to prior-year period.

[0000038725-25-000084:mdna:14]
Water Systems net sales in the U.S. and Canada increased 2 percent in the first quarter of 2025, as compared to the prior-year period. Sales decreased 1 percent in the first quarter due to the negative impact of foreign exchange rates, as compared to prior year, while sales increased 1 percent in the first quarter of 2025 due to the incremental sales impact from recent acquisitions. Sales of groundwater pumping equipment increased 6 percent and sales of water treatment products increased 7 percent compared to 2024. Partially offsetting the increase, sales of large dewatering equipment decreased 8 percent and sales of all other surface pumping equipment decreased 7 percent compared to 2024.

[0000038725-25-000084:mdna:15]
Water Systems net sales in markets outside the U.S. and Canada decreased 2 percent in the first quarter of 2025, as compared to the prior-year period. Sales decreased 5 percent in the first quarter due to the negative impact of foreign exchange rates, as compared to prior year, while sales increased 4 percent in the first quarter of 2025 due to the incremental sales impact from recent acquisitions. Excluding the impact of foreign currency translation and acquisitions, sales declines in the Latin America and Asia Pacific regions was partly offset by sales growth in the European region.

[0000038725-25-000084:mdna:16]
Net Sales-Energy Systems

[0000038725-25-000084:mdna:17]
Energy Systems net sales increased 8 percent in the first quarter of 2025, as compared to the prior-year period. The sales increase was primarily due to price realization and favorable volumes.

[0000038725-25-000084:mdna:18]
Energy Systems net sales in the U.S. and Canada increased 10 percent in the first quarter of 2025, as compared to the prior-year period due to higher sales of fuel pumping systems and piping. Outside the U.S. and Canada, Energy Systems net sales decreased 6 percent in the first quarter of 2025, as compared to the prior-year period primarily due to lower sales in Latin America.

[0000038725-25-000084:mdna:19]
[same as prior period, unchanged from 0000038725-24-000167:mdna:18]

[0000038725-25-000084:mdna:20]
Distribution net sales decreased 3 percent in the first quarter of 2025, as compared to the prior-year period. The Distribution segment sales decreased due to lower volumes and the negative impact of commodity pricing declines.

[0000038725-25-000084:mdna:21]
[same as prior period, unchanged from 0000038725-24-000167:mdna:20]

[0000038725-25-000084:mdna:22]
|  | Three Months Ended March 31, |
| (In millions) | 2025 |  | % of Net Sales |  | 2024 |  | % of Net Sales |
| Gross Profit | $ | 163.9 |  |  | 36.0 | % |  | $ | 163.6 |  |  | 35.5 | % |
| Selling, General and Administrative Expense | 119.6 |  |  | 26.3 | % |  | 115.6 |  |  | 25.1 | % |

[0000038725-25-000084:mdna:23]
[same as prior period, unchanged from 0000038725-24-000167:mdna:23]

[0000038725-25-000084:mdna:24]
The gross profit margin ratio was 36.0 percent in the first quarter of 2025 and 35.5 percent in the first quarter of 2024, respectively. The gross profit margin was favorably impacted in the first quarter of 2025 by a favorable geographic sales mix in Energy Systems and improved performance in Distribution.

[0000038725-25-000084:mdna:25]
[same as prior period, unchanged from 0000038725-24-000167:mdna:25]

[0000038725-25-000084:mdna:26]
SG&A expenses were $119.6 million in the first quarter of 2025 compared to $115.6 million in the first quarter of 2024. SG&A expenses increased in the first quarter of 2025 primarily due to higher employee compensation costs, including incremental expenses associated with the Company’s executive leadership transitions, and the incremental expense impact of recent acquisitions. The SG&A expenses ratio was 26.3 percent in the first quarter of 2025 and 25.1 percent in the first quarter of 2024, respectively.

[0000038725-25-000084:mdna:27]
[same as prior period, unchanged from 0000038725-24-000167:mdna:29]

[0000038725-25-000084:mdna:28]
Operating income decreased 8 percent in the first quarter of 2025, as compared to the prior-year period.

[0000038725-25-000084:mdna:29]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2025 |  | Q1 2024 |  | 2025 v 2024 |
| Water Systems |  | $ | 43.4 |  |  | $ | 47.1 |  |  | $ | (3.7) |  |
| Energy Systems |  | 21.9 |  |  | 18.8 |  |  | 3.1 |  |
| Distribution |  | 2.1 |  |  | 1.8 |  |  | 0.3 |  |
| Eliminations/Other |  | (23.3) |  |  | (19.8) |  |  | (3.5) |  |
| Consolidated |  | $ | 44.1 |  |  | $ | 47.9 |  |  | $ | (3.8) |  |

[0000038725-25-000084:mdna:30]
[same as prior period, unchanged from 0000038725-24-000167:mdna:33]

[0000038725-25-000084:mdna:31]
Water Systems operating income in the first quarter of 2025 was $43.4 million, a decrease of $3.7 million as compared to the prior-year period. The first quarter operating income margin was 15.1 percent, a decrease of 130 basis points from 16.4 percent in the first quarter of 2024. The decrease in operating income and margin was primarily due to incremental expenses associated with recent acquisitions.

[0000038725-25-000084:mdna:32]
Operating Income-Energy Systems

[0000038725-25-000084:mdna:33]
Energy Systems operating income in the first quarter of 2025 was $21.9 million, an increase of $3.1 million as compared to the prior-year period. The increase was primarily due to higher sales. The first quarter operating income margin was 32.8 percent, an increase of 250 basis points from 30.3 percent in the first quarter of 2024. Operating income margin increased primarily due to price realization and a favorable geographic sales mix shift.

[0000038725-25-000084:mdna:34]
[same as prior period, unchanged from 0000038725-24-000167:mdna:37]

[0000038725-25-000084:mdna:35]
Distribution operating income in the first quarter of 2025 was $2.1 million, an increase of $0.3 million as compared to the prior-year period. The first quarter operating income margin was 1.5 percent, an increase of 30 basis points from 1.2 percent in the first quarter of 2024. Operating income and operating income margin increased in the first quarter of 2025 primarily due to reduced SG&A expenses as a result of cost actions implemented in 2024 to improve the performance of the segment.

[0000038725-25-000084:mdna:36]
[same as prior period, unchanged from 0000038725-24-000167:mdna:39]

[0000038725-25-000084:mdna:37]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the first quarter of 2025 compared to the prior-year period of 2024 was an unfavorable $1.4 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses increased $2.1 million compared to the prior-year period.  The increase was primarily driven by higher employee compensation costs, including incremental expenses associated with the Company’s executive leadership transitions.

[0000038725-25-000084:mdna:38]
[same as prior period, unchanged from 0000038725-24-000167:mdna:42]

[0000038725-25-000084:mdna:39]
Interest expense was $1.8 million in the first quarter of 2025 and $1.4 million in the first quarter of 2024, respectively. The increase in the first quarter of 2025 was primarily driven by a higher average amount of outstanding debt.

[0000038725-25-000084:mdna:40]
Other Income, Net

[0000038725-25-000084:mdna:41]
Other income, net was $0.8 million in the first quarter of 2025 and $0.7 million in the first quarter of 2024, respectively.

[0000038725-25-000084:mdna:42]
[same as prior period, unchanged from 0000038725-24-000167:mdna:46]

[0000038725-25-000084:mdna:43]
Foreign currency-based transactions produced a net loss of $1.3 million in the first quarter of 2025 and $4.9 million in the first quarter of 2024, respectively. The results in the first quarters of 2025 and 2024 are primarily due to transaction losses associated with the Turkish Lira and Argentine Peso relative to the U.S. Dollar. The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-25-000084:mdna:44]
[same as prior period, unchanged from 0000038725-24-000167:mdna:48]

[0000038725-25-000084:mdna:45]
The provision for income taxes in the first quarters of 2025 and 2024 was $10.5 million and $9.2 million, respectively. The effective tax rate for the first quarters of 2025 and 2024 was 25.0 percent and 21.8 percent, respectively. The increase in the effective tax rate was due to an increase in foreign earnings taxed at rates higher than the U.S. statutory rate, a decreased benefit in the U.S. foreign-derived intangible income (FDII) provision related to a prior year prepayment of inventory from foreign subsidiaries, and less favorable discrete events in 2025, primarily related to excess tax benefits from share-based compensation.

[0000038725-25-000084:mdna:46]
[same as prior period, unchanged from 0000038725-24-000167:mdna:50]

[0000038725-25-000084:mdna:47]
Net income in the first quarters of 2025 and 2024 was $31.4 million and $33.1 million, respectively. Net income attributable to Franklin Electric Co., Inc. in the first quarters of 2025 and 2024 was $31.0 million and $33.0 million, respectively, or $0.67 and $0.70 per diluted share.

[0000038725-25-000084:mdna:48]
[same as prior period, unchanged from 0000038725-24-000167:mdna:52]

[0000038725-25-000084:mdna:49]
[same as prior period, unchanged from 0000038725-24-000167:mdna:53]

[0000038725-25-000084:mdna:50]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at March 31, 2025 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital

[0000038725-25-000084:mdna:51]
expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-25-000084:mdna:52]
As of March 31, 2025, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of March 31, 2025, the Company had $281.6 million borrowing capacity under its credit agreement as $4.6 million in letters of commercial and standby letters of credit were outstanding and undrawn and $63.8 million revolver borrowings were drawn or outstanding.

[0000038725-25-000084:mdna:53]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $200.0 million.  As of March 31, 2025, the remaining borrowing capacity on the New York Life Agreement was $175.0 million. The Company also maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates. On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million. The maturity dates of both agreements were extended from July 30, 2024 to May 15, 2027.

[0000038725-25-000084:mdna:54]
The Company also has other long-term debt borrowings outstanding as of March 31, 2025. See Note 6 - Debt included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024, for additional information regarding these obligations and future maturities as well as Note 5 - Debt of this current quarterly report for changes to these agreements since December 31, 2024.

[0000038725-25-000084:mdna:55]
At March 31, 2025, the Company had $65.2 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate the majority of these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-25-000084:mdna:56]
[same as prior period, unchanged from 0000038725-24-000167:mdna:59]

[0000038725-25-000084:mdna:57]
The following table summarizes significant sources and uses of cash and cash equivalents for the first three months of 2025 and 2024.

[0000038725-25-000084:mdna:58]
| (In millions) |  | 2025 |  | 2024 |
| Net cash flows from operating activities |  | $ | (19.5) |  |  | $ | (1.4) |  |
| Net cash flows from investing activities |  | (116.1) |  |  | (10.2) |  |
| Net cash flows from financing activities |  | (2.6) |  |  | (6.3) |  |
| Impact of exchange rates on cash and cash equivalents |  | 1.6 |  |  | (1.7) |  |
| Change in cash and cash equivalents |  | $ | (136.6) |  |  | $ | (19.6) |  |

[0000038725-25-000084:mdna:59]
[same as prior period, unchanged from 0000038725-24-000167:mdna:62]

[0000038725-25-000084:mdna:60]
2025 vs. 2024

[0000038725-25-000084:mdna:61]
Net cash used in operating activities was $19.5 million for the three months ended March 31, 2025 compared to $1.4 million used by operating activities for the three months ended March 31, 2024. The change in operating cash flow was primarily attributable to changes in working capital and lower earnings.

[0000038725-25-000084:mdna:62]
[same as prior period, unchanged from 0000038725-24-000167:mdna:65]

[0000038725-25-000084:mdna:63]
2025 vs. 2024

[0000038725-25-000084:mdna:64]
Net cash used in investing activities was $116.1 million for the three months ended March 31, 2025 compared to $10.2 million used in investing activities for the three months ended March 31, 2024. The change in investing cash flow was primarily attributable to the Barnes and PumpEng acquisitions in the first three months of 2025.

[0000038725-25-000084:mdna:65]
[same as prior period, unchanged from 0000038725-24-000167:mdna:68]

[0000038725-25-000084:mdna:66]
2025 vs. 2024

[0000038725-25-000084:mdna:67]
Net cash used in financing activities was $2.6 million for the three months ended March 31, 2025 compared to $6.3 million used in financing activities for the three months ended March 31, 2024. The change in financing cash flow was primarily due to higher net borrowings under the Company's credit facility in 2025 compared to 2024, partially offset by the payment of contingent consideration associated with a 2023 acquisition.

[0000038725-25-000084:mdna:68]
[same as prior period, unchanged from 0000038725-24-000167:mdna:71]

[0000038725-25-000084:mdna:69]
29
