# FELE 8-K — 0000038725-15-000024 filed 2015-02-24

## item codes, every 8-K on or before 2015-03-04

- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2015-03-04

- none on or before 2015-03-04

## item 2.02 — earnings release, exhibit 99.1

[0000038725-15-000024:8k_2_02:1]
EX-99.1
2
a20150224exhibit991.htm
EXHIBIT 99.1

[0000038725-15-000024:8k_2_02:2]
2015.02.24 Exhibit 99.1

[0000038725-15-000024:8k_2_02:3]
Exhibit 99.1

[0000038725-15-000024:8k_2_02:4]
For Immediate Release

[0000038725-15-000024:8k_2_02:5]
For Further Information

[0000038725-15-000024:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-15-000024:8k_2_02:7]
260-824-2900

[0000038725-15-000024:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS FOURTH QUARTER

[0000038725-15-000024:8k_2_02:9]
2014 SALES AND EARNINGS

[0000038725-15-000024:8k_2_02:10]
Fort Wayne, Indiana - February 24, 2015 - Franklin Electric Co., Inc. (NASDAQ:FELE) reported fourth quarter 2014 adjusted earnings per share (EPS) of $0.31 compared to 2013 fourth quarter adjusted EPS of $0.30, up 3 percent to last year (see table below for a reconciliation of GAAP EPS to the adjusted EPS).  In the fourth quarter of 2014, the Company’s GAAP fully diluted EPS was $0.06, which was down 78 percent to the GAAP fully diluted EPS from the fourth quarter of 2013.

[0000038725-15-000024:8k_2_02:11]
Fourth quarter 2014 sales were $253.8 million, an increase of 10 percent compared to 2013 fourth quarter sales of $229.7 million and a record for any fourth quarter in the Company’s history.  The Company’s organic sales growth was about 10 percent excluding acquisitions and the impact of foreign currency translation.

[0000038725-15-000024:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chief Executive Officer, commented:

[0000038725-15-000024:8k_2_02:13]
“We ended 2014 with broad based revenue growth across our Company.  We saw solid growth in our Water Systems segment from our businesses in Latin America, Southern Africa, and from our Pioneer mobile de-watering unit.

[0000038725-15-000024:8k_2_02:14]
“Despite the revenue growth, our Water Systems adjusted operating income declined in the quarter primarily as a result of higher global raw material costs, higher marketing and selling costs in our U.S. and Canada commercial business and, to a lesser extent, due to the continued sales mix shift to surface pumping equipment away from groundwater pumping equipment.

[0000038725-15-000024:8k_2_02:15]
“Our Fueling Systems business contributed solid results in the quarter with revenues growing organically by nearly 13 percent and adjusted operating income increasing by 10 percent.

[0000038725-15-000024:8k_2_02:16]
“During the fourth quarter we completed a number of international tax planning initiatives that have significantly reduced our effective tax rate.  Additionally, we also have taken the majority of the charges for the European restructuring actions primarily related to our Wittlich, Germany plant closure that was announced last year.  So, after considering the lower Water Systems operating income, the outstanding performance by Fueling Systems, our lower tax rate and the restructuring actions, our adjusted earnings per share grew to $0.31 per share or about 3 percent from the fourth quarter of 2013.”

[0000038725-15-000024:8k_2_02:17]
Key Performance Indicators:

[0000038725-15-000024:8k_2_02:18]
| Earnings Before and After Non-GAAP Adjustments |  | For the Fourth Quarter |  | For the Full Year |
| (in millions) |  | 2014 | 2013 | Change |  | 2014 | 2013 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 3.1 |  | $ | 13.3 |  | (77 | )% |  | $ | 69.8 |  | $ | 82.0 |  | (15 | )% |
| Allocated Undistributed Earnings |  | $ | (0.3 | ) | $ | (0.3 | ) |  |  | $ | (1.6 | ) | $ | (1.2 | ) |  |
| Adjusted Earnings for EPS Calculations |  | $ | 2.8 |  | $ | 13.0 |  | (78 | )% |  | $ | 68.2 |  | $ | 80.8 |  | (16 | )% |
| Non-GAAP adjustments (before tax): |  |  |  |  |  |  |  |  |
| Restructuring |  | $ | 15.1 |  | $ | 1.5 |  |  |  | $ | 16.6 |  | $ | 3.7 |  |  |
| Non-GAAP items |  | $ | 2.5 |  | $ | 0.9 |  |  |  | $ | 7.7 |  | $ | (0.1 | ) |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |  |  |  |  |
| Restructuring |  | $ | 10.5 |  | $ | 0.9 |  |  |  | $ | 11.4 |  | $ | 2.2 |  |  |
| Non-GAAP items |  | $ | 1.5 |  | $ | 0.6 |  |  |  | $ | 4.7 |  | $ | (0.1 | ) |  |
| Earnings after Non-GAAP Adjustments |  | $ | 14.8 |  | $ | 14.5 |  | 2 | % |  | $ | 84.3 |  | $ | 82.9 |  | 2 | % |
| Earnings Per Share |  | For the Fourth Quarter |  | For the Full Year |
| Before and After Non-GAAP Adjustments |  | 2014 | 2013 | Change |  | 2014 | 2013 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 48.1 |  | 48.2 |  | — | % |  | 48.2 |  | 48.1 |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.06 |  | $ | 0.27 |  | (78 | )% |  | $ | 1.41 |  | $ | 1.68 |  | (16 | )% |
| Restructuring Per Share, net of tax |  | $ | 0.22 |  | $ | 0.02 |  |  |  | $ | 0.24 |  | $ | 0.05 |  |  |
| Non-GAAP items |  | $ | 0.03 |  | $ | 0.01 |  |  |  | $ | 0.11 |  | $ | (0.01 | ) |  |
| Fully Diluted EPS after Non-GAAP Adjustments(Adjusted EPS) |  | $ | 0.31 |  | $ | 0.30 |  | 3 | % |  | $ | 1.76 |  | $ | 1.72 |  | 2 | % |

[0000038725-15-000024:8k_2_02:19]
| Net Sales | For the Fourth Quarter |  | For the Full Year |
| (in millions) | Water | Fueling | Consolidated |  | Water | Fueling | Consolidated |
| Sales for 2013 | $ | 178.4 |  | $ | 51.3 |  | $ | 229.7 |  |  | $ | 766.4 |  | $ | 199.1 |  | $ | 965.5 |  |
| Acquisitions | $ | 10.4 |  | $ | — |  | $ | 10.4 |  |  | $ | 23.4 |  | $ | 0.1 |  | $ | 23.5 |  |
| Foreign Exchange | $ | (8.9 | ) | $ | (1.1 | ) | $ | (10 | ) |  | $ | (24.8 | ) | $ | 0.7 |  | $ | (24.1 | ) |
| Volume/Price Change | $ | 16.8 |  | $ | 6.9 |  | $ | 23.7 |  |  | $ | 59.6 |  | $ | 23.3 |  | $ | 82.9 |  |
| Sales for 2014 | $ | 196.7 |  | $ | 57.1 |  | $ | 253.8 |  |  | $ | 824.6 |  | $ | 223.2 |  | $ | 1,047.8 |  |

[0000038725-15-000024:8k_2_02:20]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Fourth Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 4.7 |  | $ | 11.7 |  | $ | (13.8 | ) | $ | 2.6 |  |
| % Operating Income To Net Sales | 2.4 | % | 20.5 | % | — | % | 1.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 14.7 |  | $ | 0.4 |  | $ | — |  | $ | 15.1 |  |
| Non-GAAP | $ | 1.6 |  | $ | 0.9 |  | $ | — |  | $ | 2.5 |  |
| Operating Income after Non-GAAP Adjustments | $ | 21.0 |  | $ | 13.0 |  | $ | (13.8 | ) | $ | 20.2 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 10.7 | % | 22.8 | % |  | 8.0 | % |
|  | For the Fourth Quarter 2013 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 24.0 |  | $ | 11.5 |  | $ | (13.3 | ) | $ | 22.2 |  |
| % Operating Income To Net Sales | 13.5 | % | 22.4 | % |  | 9.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.5 |  | $ | — |  | $ | — |  | $ | 1.5 |  |
| Non-GAAP | $ | 0.6 |  | $ | 0.3 |  | $ | — |  | $ | 0.9 |  |
| Operating Income after Non-GAAP Adjustments | $ | 26.1 |  | $ | 11.8 |  | $ | (13.3 | ) | $ | 24.6 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.6 | % | 23.0 | % |  | 10.7 | % |

[0000038725-15-000024:8k_2_02:21]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Full Year of 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 103.9 |  | $ | 49.7 |  | $ | (53.5 | ) | $ | 100.1 |  |
| % Operating Income To Net Sales | 12.6 | % | 22.3 | % |  | 9.6 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 16.1 |  | $ | 0.5 |  | $ | — |  | $ | 16.6 |  |
| Non-GAAP | $ | 3.7 |  | $ | 1.5 |  | $ | 2.5 |  | $ | 7.7 |  |
| Operating Income after Non-GAAP Adjustments | $ | 123.7 |  | $ | 51.7 |  | $ | (51.0 | ) | $ | 124.4 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.0 | % | 23.2 | % |  | 11.9 | % |
|  | For the Full Year of 2013 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 131.3 |  | $ | 42.6 |  | $ | (50.1 | ) | $ | 123.8 |  |
| % Operating Income To Net Sales | 17.1 | % | 21.4 | % |  | 12.8 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 3.2 |  | $ | 0.5 |  | $ | — |  | $ | 3.7 |  |
| Non-GAAP | $ | 0.7 |  | $ | (0.8 | ) | $ | — |  | $ | (0.1 | ) |
| Operating Income after Non-GAAP Adjustments | $ | 135.2 |  | $ | 42.3 |  | $ | (50.1 | ) | $ | 127.4 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 17.6 | % | 21.2 | % |  | 13.2 | % |

[0000038725-15-000024:8k_2_02:22]
Water Systems

[0000038725-15-000024:8k_2_02:23]
Water Systems sales were $196.7 million in the fourth quarter 2014, an increase of $18.3 million or about 10 percent versus the fourth quarter 2013 sales of $178.4 million.  Sales from businesses acquired since the fourth quarter of 2013 were $10.4 million or about 6 percent.  Water Systems sales were reduced by $8.9 million or about 5 percent in the quarter due to foreign currency translation.  Water Systems sales growth, excluding acquisitions and foreign currency translation, was about 9 percent.

[0000038725-15-000024:8k_2_02:24]
Water Systems sales in the U.S. and Canada represented 36 percent of consolidated sales and increased by about 6 percent compared to the prior year.   Sales of surface water pumping equipment grew by 15 percent in the fourth quarter.  These sales increases in the U.S and Canada were partially offset by lower sales of groundwater pumping equipment which declined less than 2 percent in the quarter. U.S. and Canada sales of Pioneer branded mobile pumping equipment increased by over 10 percent in the fourth quarter of 2014 compared to the prior year.

[0000038725-15-000024:8k_2_02:25]
Water Systems sales in Latin America were about 16 percent of consolidated sales for the fourth quarter and increased by about 34 percent compared to the fourth quarter 2013.  Foreign currency translation decreased sales by about 10 percent in Latin America compared to the fourth quarter prior year.  Sales from the Bombas Leao acquisition increased Latin America sales by about 25 percent.  After excluding

[0000038725-15-000024:8k_2_02:26]
acquisitions and the impact of foreign currency translation, Latin American sales increased 19 percent.  Fourth quarter sales growth in Latin America was led by a nearly 20 percent increase in Mexico, driven by new Solar and other new Drive products.  Sales in Brazil were up 23 percent in the quarter and distribution outlets in Chile and Colombia also contributed to increased sales in these markets compared to the fourth quarter 2013.

[0000038725-15-000024:8k_2_02:27]
Water Systems sales in the Middle East and Africa were about 11 percent of consolidated sales and were down about 2 percent compared to the fourth quarter 2013.  The impact of foreign currency translation decreased sales by about 8 percent compared to the fourth quarter 2013.  Excluding the impact of foreign currency translation, sales increased by about 6 percent compared to the fourth quarter 2013. The growth was driven by strong sales of groundwater pumping equipment in Turkey and a 9 percent increase in sales in Southern Africa.

[0000038725-15-000024:8k_2_02:28]
Water Systems sales in Europe were about 7 percent of consolidated sales and increased by about 2 percent compared to the fourth quarter 2013.  The impact of foreign currency translation decreased sales by about 13 percent compared to the fourth quarter 2013.  Excluding the impact of foreign currency translation, European sales increased about 15 percent compared to the fourth quarter 2013. Sales increases in the fourth quarter 2014 were primarily of the Pioneer branded mobile pumping equipment products.

[0000038725-15-000024:8k_2_02:29]
Water Systems sales in the Asia Pacific region were about 8 percent of consolidated sales and increased by about 19 percent compared to the fourth quarter 2013.  Acquisition related sales were about 16 percent and foreign currency translation reduced sales in Asia Pacific by about 4 percent compared to the fourth quarter prior year.  After excluding acquisitions and the impact of foreign currency translation, Asia Pacific sales increased 7 percent compared to the fourth quarter prior year, led by sales in Australia which grew by 35 percent from improved Pioneer product sales in the region.

[0000038725-15-000024:8k_2_02:30]
Water Systems operating income, after non-GAAP adjustments, was $21.0 million in the fourth quarter 2014, a decrease of about 20 percent versus the fourth quarter 2013. The fourth quarter operating income margin after non-GAAP adjustments was 10.7 percent, down 390 basis points from 14.6 percent in the fourth quarter of 2013.

[0000038725-15-000024:8k_2_02:31]
Water Systems adjusted operating income margin declined primarily due to increases in raw material costs, including steel and purchased components, and higher selling and marketing expense for customer incentives supporting sales in the U.S. and Canada Water Systems units.  To a lesser extent, and not as significant as the third quarter of 2014, a sales mix shift also contributed to overall lower margins. During the fourth quarter 2014, ground water pumping equipment sales were about 62 percent of total Water Systems sales while in the fourth quarter of 2013 they were about 65 percent. Water Systems margins also declined in the quarter due to lower margins from recently acquired units still being integrated.

[0000038725-15-000024:8k_2_02:32]
Fueling Systems

[0000038725-15-000024:8k_2_02:33]
Fueling Systems sales represented 22 percent of consolidated sales and were $57.1 million in the fourth quarter 2014, an increase of $5.8 million or about 11 percent versus the fourth quarter 2013 sales of $51.3 million. Fueling Systems sales decreased by $1.1 million or about 2 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, Fueling Systems sales increased about 13 percent compared to the fourth quarter 2013.

[0000038725-15-000024:8k_2_02:34]
During the fourth quarter, Fueling Systems shipped about $2.0 million of equipment to India to partially fill a large customer order. Excluding the impact of these India sales, Fueling Systems sales grew by about 10 percent. Sales growth was broad based across most product lines and regions of the world.

[0000038725-15-000024:8k_2_02:35]
Fueling Systems operating income after non-GAAP adjustments was $13.0 million in the fourth quarter of 2014 compared to $11.8 million after non-GAAP adjustments in the fourth quarter of 2013, an increase of about 10 percent. The fourth quarter operating income margin after non-GAAP adjustments was 22.8 percent, flat to the fourth quarter of 2013. The increase in dollars was primarily driven by higher sales volume.

[0000038725-15-000024:8k_2_02:36]
Overall

[0000038725-15-000024:8k_2_02:37]
The Company’s consolidated gross profit was $77.8 million for the fourth quarter of 2014, an increase of $1.8 million, or about 2 percent, from the fourth quarter of 2013 gross profit of $76.0 million. The gross profit as a percent of net sales was 30.6 percent in the fourth quarter of 2014 down about 250 basis points versus 33.1 percent during the fourth quarter 2013.  The previously discussed items in the Water Systems segment contributed significantly to lower gross profit margins in the quarter.

[0000038725-15-000024:8k_2_02:38]
Selling, general, and administrative (SG&A) expenses were $60.1 million in the fourth quarter of 2014 compared to $52.3 million in the fourth quarter of prior year, an increase of $7.8 million or about 15 percent.  The increase in SG&A expenses from acquired businesses was $2.5 million.  Excluding the acquisitions, the Company’s overall SG&A expenses in the fourth quarter of 2014 increased by $5.3 million or 10 percent to prior year fourth quarter.  The remaining increases in SG&A were primarily driven by higher commissions, sales, marketing and selling related costs in support of higher sales and increases in Research Development and Engineering spending.

[0000038725-15-000024:8k_2_02:39]
The Company ended the fourth quarter of 2014 with a cash balance of $59.1 million, which was $75.5 million lower than at the end of 2013.  The cash balance decrease is primarily attributable to increased working capital needs and acquisitions.

[0000038725-15-000024:8k_2_02:40]
Commenting on the outlook for the first quarter of 2015, Mr. Sengstack said:

[0000038725-15-000024:8k_2_02:41]
“As we head into 2015, both the strong dollar and the reduction in oil and gas drilling activity in the United States are having a negative impact on our global sales volumes.  We estimate that if the dollar stays at current levels, the translation effect will reduce our global sales and earnings by about 6 percent in 2015 and reduced drilling activity will result in another 3 percent decline versus 2014.  With the additional steps we have taken to reset our U.S. groundwater business, we anticipate demand to be uneven and promotions to be heavier than normal until the market settles down, probably mid-year, when we anticipate a bounce back in our U.S. Water sales during the peak selling season as our new distribution network becomes fully functional.

[0000038725-15-000024:8k_2_02:42]
On the other hand, we are implementing price increases across most of our global Water and Fueling markets that will have a favorable impact on margins after they become effective.  In addition, we are forecasting another strong year for our Fueling business as global investment in filling station infrastructure continues to expand with particular growth in demand for Franklin pressure pumping and vapor recovery systems.

[0000038725-15-000024:8k_2_02:43]
Turning now to the first quarter and considering the factors outlined above, we believe it will be our toughest comparison to 2014.  We are anticipating low single digit growth in Water Systems sales, but, a

[0000038725-15-000024:8k_2_02:44]
low to mid-single digit percentage decline in Water Systems adjusted operating earnings. The earnings decline is attributable to the translation effect of the strong dollar and higher raw material costs, which we expect to be partially offset with the pricing actions that I mentioned earlier.

[0000038725-15-000024:8k_2_02:45]
We estimate that our Fueling Systems sales and adjusted operating earnings will grow in the first quarter of 2015 by 8 to 10 percent, representing record first quarter performance for this segment of our business.

[0000038725-15-000024:8k_2_02:46]
Overall, we expect first quarter 2015 adjusted earnings per share to be flat to down two cents when compared to the record 2014 first quarter adjusted earnings per share of $0.35.”

[0000038725-15-000024:8k_2_02:47]
A conference call to review earnings and other developments in the business will commence at 9:00 am EST.  The fourth quarter and fiscal year 2014 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-15-000024:8k_2_02:48]
http://edge.media-server.com/m/p/iz6a2oz4

[0000038725-15-000024:8k_2_02:49]
If you intend to ask questions during the call, please dial in using 877-643-7158 for domestic calls and 914-495-8565 for international calls.

[0000038725-15-000024:8k_2_02:50]
A replay of the conference call will be available Tuesday, February 24, 2015 at 12:00 noon EST through midnight EST on Tuesday, March 3, 2015, by dialing 855-859-2056 for domestic calls and 404-537-3406 for international calls. The replay passcode is: 84684806.

[0000038725-15-000024:8k_2_02:51]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and automotive fuels. Recognized as a technical leader in its specialties, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-15-000024:8k_2_02:52]
The Company presents the non-GAAP financial measures of earnings after non-GAAP adjustments, fully diluted earnings per share after non-GAAP adjustments (or adjusted EPS), operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments (or operating income margin after non-GAAP adjustments) because the Company believes the information helps investors understand underlying trends in the Company's business more easily.  The differences between these measures and the most comparable GAAP measures are reconciled in the tables above.

[0000038725-15-000024:8k_2_02:53]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Fourth Quarter Ended |  | Fiscal Year Ended |
|  | January 3, 2015 |  | December 28, 2013 |  | January 3, 2015 |  | December 28, 2013 |
| Net sales | $ | 253,837 |  |  | $ | 229,651 |  |  | $ | 1,047,777 |  |  | $ | 965,462 |  |
| Cost of sales | 176,083 |  |  | 153,640 |  |  | 703,367 |  |  | 633,948 |  |
| Gross profit | 77,754 |  |  | 76,011 |  |  | 344,410 |  |  | 331,514 |  |
| Selling, general, and administrative expenses | 60,090 |  |  | 52,346 |  |  | 227,711 |  |  | 204,014 |  |
| Restructuring (income)/expense | 15,094 |  |  | 1,484 |  |  | 16,611 |  |  | 3,719 |  |
| Operating income | 2,570 |  |  | 22,181 |  |  | 100,088 |  |  | 123,781 |  |
| Interest expense | (2,697 | ) |  | (2,786 | ) |  | (10,735 | ) |  | (10,597 | ) |
| Other income/(expense) | (202 | ) |  | 589 |  |  | 1,349 |  |  | 1,696 |  |
| Foreign exchange income/(expense) | (397 | ) |  | (2,153 | ) |  | (999 | ) |  | (3,331 | ) |
| Income before income taxes | (726 | ) |  | 17,831 |  |  | 89,703 |  |  | 111,549 |  |
| Income taxes | (3,894 | ) |  | 4,484 |  |  | 18,851 |  |  | 28,851 |  |
| Net income | $ | 3,168 |  |  | $ | 13,347 |  |  | $ | 70,852 |  |  | $ | 82,698 |  |
| Less: Net income attributable to noncontrolling interests | (66 | ) |  | (41 | ) |  | (1,046 | ) |  | (740 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 3,102 |  |  | $ | 13,306 |  |  | $ | 69,806 |  |  | $ | 81,958 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.06 |  |  | $ | 0.27 |  |  | $ | 1.43 |  |  | $ | 1.70 |  |
| Diluted | $ | 0.06 |  |  | $ | 0.27 |  |  | $ | 1.41 |  |  | $ | 1.68 |  |

[0000038725-15-000024:8k_2_02:54]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | January 3, 2015 |  | December 28, 2013 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 59,141 |  |  | $ | 134,553 |  |
| Receivables | 143,787 |  |  | 115,127 |  |
| Inventories | 220,528 |  |  | 191,561 |  |
| Other current assets | 46,083 |  |  | 31,113 |  |
| Total current assets | 469,539 |  |  | 472,354 |  |
| Property, plant, and equipment, net | 209,786 |  |  | 208,596 |  |
| Goodwill and other assets | 396,562 |  |  | 370,923 |  |
| Total assets | $ | 1,075,887 |  |  | $ | 1,051,873 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 70,806 |  |  | $ | 57,755 |  |
| Accrued expenses and other current liabilities | 96,207 |  |  | 65,356 |  |
| Current maturities of long-term debt and short-term borrowings | 34,092 |  |  | 15,363 |  |
| Total current liabilities | 201,105 |  |  | 138,474 |  |
| Long-term debt | 143,695 |  |  | 174,166 |  |
| Deferred income taxes | 45,568 |  |  | 54,618 |  |
| Employee benefit plans | 58,709 |  |  | 41,685 |  |
| Other long-term liabilities | 21,407 |  |  | 39,543 |  |
| Redeemable noncontrolling interest | 6,420 |  |  | 5,171 |  |
| Total equity | 598,983 |  |  | 598,216 |  |
| Total liabilities and equity | $ | 1,075,887 |  |  | $ | 1,051,873 |  |

[0000038725-15-000024:8k_2_02:55]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
| (In thousands) | 2014 |  | 2013 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 70,852 |  |  | $ | 82,698 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 37,210 |  |  | 31,356 |  |
| Share-based compensation | 7,471 |  |  | 4,875 |  |
| Other | (2,528 | ) |  | 1,424 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (29,064 | ) |  | (16,729 | ) |
| Inventory | (32,782 | ) |  | (7,612 | ) |
| Accounts payable and accrued expenses | 22,852 |  |  | 2,126 |  |
| Other | (26,662 | ) |  | 136 |  |
| Net cash flows from operating activities | 47,349 |  |  | 98,274 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (35,525 | ) |  | (67,557 | ) |
| Proceeds from sale of property, plant, and equipment | 1,608 |  |  | 138 |  |
| Acquisitions and investments | (42,315 | ) |  | (9,213 | ) |
| Other investing activities | (1,490 | ) |  | 180 |  |
| Net cash flows from investing activities | (77,722 | ) |  | (76,452 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (18,823 | ) |  | 25,045 |  |
| Proceeds from issuance of common stock | 2,929 |  |  | 14,068 |  |
| Excess tax from share-based payment arrangements | 2,463 |  |  | 5,153 |  |
| Purchases of common stock | (10,610 | ) |  | (12,364 | ) |
| Dividends paid | (17,421 | ) |  | (15,294 | ) |
| Purchase of redeemable non-controlling shares | (2,875 | ) |  | — |  |
| Payment of contingent consideration liability | — |  |  | (5,555 | ) |
| Net cash flows from financing activities | (44,337 | ) |  | 11,053 |  |
| Effect of exchange rate changes on cash | (702 | ) |  | (1,660 | ) |
| Net change in cash and equivalents | (75,412 | ) |  | 31,215 |  |
| Cash and equivalents at beginning of period | 134,553 |  |  | 103,338 |  |
| Cash and equivalents at end of period | $ | 59,141 |  |  | $ | 134,553 |  |
