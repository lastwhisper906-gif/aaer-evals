# FELE notes — 0000038725-15-000043


## fele:DisclosureOfShareBasedCompensationArrangementsAuthorizedSharesTableTextBlock

[0000038725-15-000043:notes:1]
is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards and stock unit awards, to key employees and non-employee directors.  Shares and per share data below have been adjusted for all periods presented to reflect the two-for-one stock split effective March 18, 2013.

[0000038725-15-000043:notes:2]
The 2012 Stock Plan authorizes 2,400,000 shares for issuance as follows:

[0000038725-15-000043:notes:3]
| 2012 Stock Plan |  | Authorized Shares |
| Stock Options |  | 1,680,000 |
| Stock/Stock Unit Awards |  | 720,000 |

[0000038725-15-000043:notes:4]
The Company also maintains the Amended and Restated Franklin Electric Co., Inc. Stock Plan (the "2009 Stock Plan") which, as amended in 2009, provided for discretionary grants of stock options and stock awards.  The 2009 Stock Plan authorized 4,400,000 shares for issuance as follows:

[0000038725-15-000043:notes:5]
| 2009 Stock Plan | Authorized Shares |
| Stock Options | 3,200,000 |
| Stock Awards | 1,200,000 |


## fele:ExtendedAndStandardProductWarrantyPolicyPolicyTextBlock

[0000038725-15-000043:notes:6]
Warranty terms are generally 2 years from date of manufacture or 1 year from date of installation.  The general warranty liability is recorded when revenue is recognized and is based on actual historical return rates from the most recent warranty periods.  In 2007, the Company began offering an extended warranty program to certain Water Systems segment customers, which provides warranty coverage up to 5 years from the date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims and expected customer returns.  The Company actively studies trends of warranty claims and takes action to improve product quality and minimize warranty claims.


## fele:ScheduleOfCompanyContributionsToEmployeeStockOwnershipPlanAnd401KPlansTableTextBlock

[0000038725-15-000043:notes:7]
The following table sets forth Company contributions to the 401(k) Plan:

[0000038725-15-000043:notes:8]
| (In millions) |  | 2014 |  | 2013 |  | 2012 |
| Company contributions to the plan |  | $ | 5.6 |  |  | $ | 5.3 |  |  | $ | 5.0 |  |


## fele:ScheduleOfFiniteAndIndefiniteLivedIntangibleAssetsTableTextBlock

[0000038725-15-000043:notes:9]
The carrying amounts of the Company’s intangible assets are as follows:

[0000038725-15-000043:notes:10]
| (In millions) |  | 2014 |  | 2013 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.6 |  |  | $ | (6.1 | ) |  | $ | 7.8 |  |  | $ | (5.9 | ) |
| Supply agreements |  | 4.4 |  |  | (4.4 | ) |  | 4.4 |  |  | (4.4 | ) |
| Technology |  | 7.5 |  |  | (4.3 | ) |  | 7.5 |  |  | (3.8 | ) |
| Customer relationships |  | 140.2 |  |  | (36.5 | ) |  | 125.1 |  |  | (29.7 | ) |
| Software |  | 2.9 |  |  | (1.7 | ) |  | 2.1 |  |  | (0.4 | ) |
| Other |  | 1.2 |  |  | (1.2 | ) |  | 1.3 |  |  | (1.2 | ) |
| Total |  | $ | 163.8 |  |  | $ | (54.2 | ) |  | $ | 148.2 |  |  | $ | (45.4 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 50.7 |  |  | — |  |  | 45.9 |  |  | — |  |
| Total intangibles |  | $ | 214.5 |  |  | $ | (54.2 | ) |  | $ | 194.1 |  |  | $ | (45.4 | ) |


## fele:ScheduleOfSharesRepurchasedAndRetiredDuringYearTableTextBlock

[0000038725-15-000043:notes:11]
During 2014, 2013, and 2012, pursuant to a stock repurchase program authorized by the Company’s Board of Directors, the Company repurchased and retired the following amounts and number of shares:

[0000038725-15-000043:notes:12]
| (In millions, except share amounts) |  | 2014 |  | 2013 |  | 2012 |
| Repurchases |  | $ | 9.0 |  |  | $ | 2.8 |  |  | $ | 10.0 |  |
| Shares |  | 243,020 |  |  | 88,200 |  |  | 400,000 |  |


## fele:ScheduleOfWeightedAverageNumberOfYearsOverWhichEachIntangibleClassIsAmortizedTableTextBlock

[0000038725-15-000043:notes:13]
The weighted average number of years over which each intangible class is amortized is as follows:

[0000038725-15-000043:notes:14]
| Class |  | Years |
| Patents |  | 17 |
| Supply agreements |  | 6 |
| Technology |  | 15 |
| Customer relationships |  | 13 - 20 |
| Software |  | 5 |
| Other |  | 8 |


## fele:ScheduleRelatedChangesInBenefitObligationsChangesInPlanAssetsFundedStatusAmountsRecognizedInBalanceSheetAmountsRecognizedInOtherAccumulatedComprehensiveIncomeTableTextBlock

[0000038725-15-000043:notes:15]
The following table sets forth aggregated information related to the Company’s pension benefits and other postretirement benefits, including changes in the benefit obligations, changes in plan assets, funded status, amounts recognized in the balance sheet, amounts recognized in accumulated other comprehensive income, and actuarial assumptions that the Company considered in its determination of benefit obligations and plan costs.  Benefit obligation balances presented below reflect the projected benefit obligation (PBO) for the Company's pension plans, and accumulated postretirement benefit obligations (APBO) for the Company's other benefit plans.

[0000038725-15-000043:notes:16]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Accumulated benefit obligation, end of year |  | $ | 203.4 |  |  | $ | 180.6 |  |  | $ | 13.0 |  |  | $ | 12.6 |  |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation, beginning of year |  | $ | 184.7 |  |  | $ | 196.3 |  |  | $ | 12.6 |  |  | $ | 14.5 |  |
| Service cost |  | 1.2 |  |  | 1.8 |  |  | 0.1 |  |  | 0.1 |  |
| Interest cost |  | 8.2 |  |  | 7.6 |  |  | 0.5 |  |  | 0.5 |  |
| Actuarial (gain)/loss |  | 33.0 |  |  | (10.2 | ) |  | 1.2 |  |  | (1.0 | ) |
| Settlements paid |  | (0.2 | ) |  | (0.8 | ) |  | — |  |  | — |  |
| Benefits paid |  | (15.0 | ) |  | (10.7 | ) |  | (1.4 | ) |  | (1.5 | ) |
| Foreign currency exchange |  | (2.4 | ) |  | 0.7 |  |  | — |  |  | — |  |
| Benefit obligation, end of year |  | $ | 209.5 |  |  | $ | 184.7 |  |  | $ | 13.0 |  |  | $ | 12.6 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of assets, beginning of year |  | $ | 151.1 |  |  | $ | 130.2 |  |  | $ | — |  |  | $ | — |  |
| Actual return on plan assets |  | 14.4 |  |  | 24.3 |  |  | — |  |  | — |  |
| Company contributions |  | 10.1 |  |  | 7.7 |  |  | 1.4 |  |  | 1.5 |  |
| Settlements paid |  | (0.1 | ) |  | (0.6 | ) |  | — |  |  | — |  |
| Benefits paid |  | (15.0 | ) |  | (10.7 | ) |  | (1.4 | ) |  | (1.5 | ) |
| Foreign currency exchange |  | (0.5 | ) |  | 0.2 |  |  | — |  |  | — |  |
| Plan assets, end of year |  | $ | 160.0 |  |  | $ | 151.1 |  |  | $ | — |  |  | $ | — |  |
| Funded status |  | $ | (49.5 | ) |  | $ | (33.6 | ) |  | $ | (13.0 | ) |  | $ | (12.6 | ) |
| Amounts recognized in balance sheet: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred tax asset |  | 30.4 |  |  | 21.2 |  |  | 1.5 |  |  | 1.2 |  |
| Current liabilities |  | (3.5 | ) |  | (3.2 | ) |  | (1.3 | ) |  | (1.3 | ) |
| Noncurrent liabilities |  | (46.0 | ) |  | (30.4 | ) |  | (11.7 | ) |  | (11.3 | ) |
| Net liability, end of year |  | $ | (19.1 | ) |  | $ | (12.4 | ) |  | $ | (11.5 | ) |  | $ | (11.4 | ) |
| Amount recognized in accumulated other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior service cost |  | — |  |  | — |  |  | 0.7 |  |  | 1.0 |  |
| Net actuarial loss |  | 52.3 |  |  | 36.8 |  |  | 1.7 |  |  | 0.9 |  |
| Settlement |  | 1.4 |  |  | — |  |  | — |  |  | — |  |
| Total recognized in accumulated other comprehensive income |  | $ | 53.7 |  |  | $ | 36.8 |  |  | $ | 2.4 |  |  | $ | 1.9 |  |


## fele:StockSplitDisclosureTextBlock

[0000038725-15-000043:notes:17]
STOCK SPLIT

[0000038725-15-000043:notes:18]
On February 22, 2013, the Company announced that its Board of Directors declared a two-for-one stock split of the Company's common stock in the form of a 100 percent stock distribution. The stock distribution was distributed or paid on March 18, 2013, to stockholders of record as of March 4, 2013. As a result of this action, approximately 23.7 million shares were issued to stockholders of record as of March 4, 2013. The par value of the common stock remains at $0.10 per share and, accordingly, approximately $2.37 million was transferred from retained earnings to common stock. Earnings and dividends declared per share and weighted average shares outstanding are presented in this Form 10-K after the effect of the 100 percent stock distribution. The two-for-one stock split is reflected in the share and per share amounts in all periods presented in this Form 10-K.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000038725-15-000043:notes:19]
ACCRUED EXPENSES AND OTHER CURRENT LIABILITIES

[0000038725-15-000043:notes:20]
Accrued expenses and other current liabilities consist of:

[0000038725-15-000043:notes:21]
| (In millions) |  | 2014 |  | 2013 |
| Salaries, wages, and commissions |  | $ | 38.8 |  |  | $ | 27.2 |  |
| Product warranty costs |  | 9.4 |  |  | 9.5 |  |
| Insurance |  | 2.8 |  |  | 3.4 |  |
| Employee benefits |  | 11.1 |  |  | 10.3 |  |
| Pioneer additional purchase price |  | 22.9 |  |  | — |  |
| Other |  | 9.8 |  |  | 11.7 |  |
|  |  | $ | 94.8 |  |  | $ | 62.1 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000038725-15-000043:notes:22]
The following unaudited proforma financial information for the years ended December 29, 2012 and December 31, 2011 gives effect to the acquisitions of Flex-ing, Cerus, and PPH by the Company as if the acquisitions had occurred at the beginning of the 2012 and 2011 years.  These unaudited proforma combined condensed financial statements are prepared for informational purposes only and are not necessarily indicative of actual results or financial position that would have been achieved had the acquisitions been consummated on the dates indicated and are not necessarily indicative of future operating results or financial position of the consolidated companies.  The unaudited proforma combined condensed financial statements do not give effect to any cost savings or incremental costs that may result from the integration of Flex-ing, Cerus, and PPH with the Company.

[0000038725-15-000043:notes:23]
FRANKLIN ELECTRIC CO., INC.

[0000038725-15-000043:notes:24]
PRO FORMA CONDENSED CONSOLIDATED STATEMENTS OF INCOME

[0000038725-15-000043:notes:25]
| (In millions, except per share amounts) | (Unaudited)2012 |  | (Unaudited)2011 |
| Net sales | $ | 925 |  |  | $ | 914 |  |
| Net income | 84 |  |  | 68 |  |
| Per share data: |  |  |  |
| Basic earnings per share | $ | 1.79 |  |  | $ | 1.46 |  |
| Diluted earnings per share | $ | 1.76 |  |  | $ | 1.43 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-15-000043:notes:26]
ACQUISITIONS

[0000038725-15-000043:notes:27]
During the third quarter 2014, the Company acquired controlling interests in two entities in India in separate unrelated transactions.  Neither of the acquisitions was individually material, and the combined purchase price paid was approximately $6.6 million.  The results of the two businesses from their respective dates of acquisition through January 3, 2015 were not material.

[0000038725-15-000043:notes:28]
In an agreement dated June 6, 2014, between the Company and Bombas Leao S.A. ("Bombas Leao"), the Company acquired rights to 100 percent of the outstanding shares of Bombas Leao for a cash purchase price of approximately BRL 69.0 million, $30.7 million at the then current exchange rate, subject to certain terms and conditions.  The Company also acquired debt and certain liabilities of Bombas Leao.  The Company funded the acquisition with cash on hand and short-term borrowings from the Company's revolving credit agreement.

[0000038725-15-000043:notes:29]
Bombas Leao, based in Monte Azul Paulista, State of Sao Paulo, Brazil, designs, manufactures, and distributes submersible groundwater pumping equipment through manufacturing and distribution facilities.

[0000038725-15-000043:notes:30]
The Bombas Leao intangible assets of $23.5 million consist primarily of customer relationships, which will be amortized utilizing the straight line method over 20 years, and trade names, which are classified as indefinite lived assets and will not be amortized.  Preliminary intangible asset values decreased by $3.0 million during 2014, primarily due to purchase accounting adjustments resulting from additional information provided for the provisional valuation and working capital adjustments.

[0000038725-15-000043:notes:31]
The preliminary goodwill of $3.1 million resulting from the Bombas Leao acquisition consists primarily of broadened product offerings and expanded customer base.  All of the goodwill was recorded as part of the Water Systems segment and is not expected to be deductible for tax purposes.  Preliminary goodwill decreased by $2.1 million during 2014, primarily due to purchase accounting adjustments to property, plant, and equipment and intangible assets resulting from additional information provided for the provisional valuation.

[0000038725-15-000043:notes:32]
The preliminary purchase price assigned to the major identifiable assets and liabilities for the acquisition is as follows:

[0000038725-15-000043:notes:33]
| (In millions) |  |
| Assets: |  |
| Cash acquired | $ | 1.1 |  |
| Current assets | 13.7 |  |
| Property, plant, and equipment | 6.5 |  |
| Intangible assets | 23.5 |  |
| Goodwill | 3.1 |  |
| Other assets | 3.1 |  |
| Total assets | 51.0 |  |
| Liabilities | (20.3 | ) |
| Total consideration paid | $ | 30.7 |  |

[0000038725-15-000043:notes:34]
The fair values of the Bombas Leao identifiable intangible assets and property, plant and equipment are provisional amounts as of January 3, 2015, pending the finalization of tax valuations and purchase accounting adjustments.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation process.

[0000038725-15-000043:notes:35]
The results of operations of Bombas Leao were included in the Company's consolidated statement of income from the acquisition date through the year ended January 3, 2015. The difference between actual sales for the Company and proforma sales including Bombas Leao as if it was acquired at the beginning of each year was not material as a component of the Company's consolidated sales for the years ended January 3, 2015 and December 28, 2013, respectively. Due to the immaterial nature of the acquisition, the Company has not included full year proforma statements of income for the acquisition year or previous year.

[0000038725-15-000043:notes:36]
During 2013, the Company made two acquisitions, neither of which was individually material, in the Water Systems segment for a total purchase price of approximately $3.6 million.  The results of the two acquired businesses from the dates of acquisition through December 28, 2013 were not material.

[0000038725-15-000043:notes:37]
In an agreement dated November 16, 2012, the Company added to its Fueling Systems segment by acquiring certain assets and 100 percent of the common stock of Flex-ing, Incorporated ("Flex-ing") for approximately $10.4 million in an all cash transaction.  Located in Sherman, Texas, Flex-ing designs and manufactures a variety of fueling equipment that is distributed through the same channels as the core product offering of the Fueling Systems segment.

[0000038725-15-000043:notes:38]
The Flex-ing intangible assets of $8.9 million consist primarily of customer relationships, which will be amortized utilizing the straight line method over 15 years, and trademarks, which are classified as indefinite lived assets and will not be amortized.  All of the goodwill was recorded as part of the Fueling Systems segment and is not expected to be deductible for tax purposes.

[0000038725-15-000043:notes:39]
The goodwill amount of $4.0 million resulting from the Flex-ing acquisition consists primarily of broadened product lines that can be distributed through the Company's existing international distribution channels.

[0000038725-15-000043:notes:40]
In an agreement dated August 9, 2012, between the Company and Cerus Industrial Corporation ("Cerus"), the Company acquired all of the outstanding shares of Cerus, net of debt acquired, for approximately $24.4 million, subject to certain terms and conditions.  The Company funded the acquisition with cash on hand and short-term borrowings paid back within the year.

[0000038725-15-000043:notes:41]
Cerus, located in Hillsboro, Oregon, designs, manufactures, and distributes motor controls, motor starters, contractors, protection devices, and variable frequency drives to a wide range of distributor and original equipment manufacturers in North America.

[0000038725-15-000043:notes:42]
The Cerus intangible assets of $17.3 million consist primarily of customer relationships, which will be amortized utilizing the straight line method over 17 years, and trademarks, which are classified as indefinite lived assets and will not be amortized.

[0000038725-15-000043:notes:43]
The goodwill amount of $5.4 million resulting from the Cerus acquisition consists primarily of accelerated growth resulting from increased technical and product development capacity, broadened product lines, reduced manufacturing costs, and movement into adjacent market areas.  All of the goodwill was recorded as part of the Water Systems segment and is not expected to be deductible for tax purposes.  Preliminary goodwill decreased by $0.1 million during the year ended December 28, 2013, due to an escrow refund received by the Company.

[0000038725-15-000043:notes:44]
In an agreement dated March 7, 2012, between the Company and Pioneer Pump Holdings, Inc. ("PPH"), the Company acquired an additional 39.5 percent of the outstanding shares of PPH, net of debt acquired, for approximately $30.3 million, subject to certain terms and conditions.  The Company funded the acquisition with approximately $30.3 million in cash.  The Company previously held a 31.0 percent equity interest in PPH (see Note 8).  As a result of the additional acquisition, the Company's total equity interest in PPH increased to 70.5 percent, resulting in the consolidation of PPH in the Company's financial statements.  Accordingly, the original equity interest in PPH was remeasured to its fair value of $23.9 million as of March 7, 2012, based on the income approach which utilized management estimates and consultation with an independent third-party valuation firm.  Inputs included an analysis of the enterprise value based on financial projections and ownership percentages.  As a result, the Company recognized a one-time gain of $12.2 million in the "Other income/(expense)" line of the Company's condensed consolidated statement of income for the first quarter ended March 31, 2012.

[0000038725-15-000043:notes:45]
PPH is the holding company for two wholly-owned subsidiaries, Pioneer Pump, Inc. ("PPI") located in Canby, Oregon, and Pioneer Pump, Ltd. ("PPL") located in Rattlesden, United Kingdom, which holds an additional subsidiary in Wadeville, Germiston, South Africa.  PPH is a leader in the manufacture of large, engine-driven centrifugal pumps used for dewatering in oil and gas, municipal, construction and mining applications.

[0000038725-15-000043:notes:46]
The Company also entered into a further stock purchase agreement with the noncontrolling interest holders to purchase the remaining shares of PPH during the first half of 2015, for a purchase price based on a multiple of PPH's adjusted average earnings for 2013 and 2014 less net indebtedness.  Accordingly, the resulting liability of $22.9 million is recorded in the "Accrued expenses and other current liabilities" line of the Company's consolidated balance sheet.  Any required adjustments to the liability driven by changes in the expected purchase price will be recorded in the "Interest expense" line of the Company's consolidated statement of income.  The mandatory share purchase liability remained recorded at the initial carrying amount as of January 3, 2015.  As a result, no adjustments were necessary for the years ended January 3, 2015, December 28, 2013 and December 29, 2012.

[0000038725-15-000043:notes:47]
The PPH intangible assets of $43.9 million consist primarily of customer relationships, which will be amortized utilizing the straight line method over 17 to 19 years, and trademarks, which are classified as indefinite lived assets and will not be amortized.

[0000038725-15-000043:notes:48]
The goodwill amount of $26.5 million resulting from the PPH acquisition consists primarily of expanding sales of packaged systems products and the recording of deferred taxes related to acquired assets.  PPH's presence in the oil and gas market will also complement the Company's initiative to introduce submersible pumping systems in this market.  All of the goodwill was recorded as part of the Water Systems segment and is not expected to be deductible for tax purposes.  Preliminary goodwill increased by $1.5 million during the year ended December 29, 2012, due to purchase accounting adjustments to intangible assets and inventory resulting from additional information provided for the provisional valuation.

[0000038725-15-000043:notes:49]
The final purchase prices assigned to the major identifiable assets and liabilities for the Flex-ing, Cerus, and PPH acquisitions are as follows:

[0000038725-15-000043:notes:50]
| (In millions) | Flex-ing | Cerus | PPH | Total |
| Assets: |  |  |  |  |
| Cash acquired | $ | 0.1 |  | $ | — |  | $ | 0.8 |  | $ | 0.9 |  |
| Current assets | 2.0 |  | 3.8 |  | 38.1 |  | 43.9 |  |
| Property, plant, and equipment | 0.4 |  | 0.3 |  | 3.6 |  | 4.3 |  |
| Intangible assets | 8.9 |  | 17.3 |  | 43.9 |  | 70.1 |  |
| Goodwill | 4.0 |  | 5.4 |  | 26.5 |  | 35.9 |  |
| Total assets | 15.4 |  | 26.8 |  | 112.9 |  | 155.1 |  |
| Liabilities | (5.0 | ) | (2.4 | ) | (58.7 | ) | (66.1 | ) |
| Total | 10.4 |  | 24.4 |  | 54.2 |  | 89.0 |  |
| Less: Fair value of original equity interest | — |  | — |  | (23.9 | ) | (23.9 | ) |
| Total purchase price | $ | 10.4 |  | $ | 24.4 |  | $ | 30.3 |  | $ | 65.1 |  |

[0000038725-15-000043:notes:51]
The fair values of the Flex-ing, Cerus, and PPH identifiable intangible assets and property, plant, and equipment are final amounts as of fiscal year end 2013 in conjunction with final valuations.  An additional valuation adjustment of $0.1 million was made to Cerus goodwill in 2013 and is reflected in the table above.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuations.

[0000038725-15-000043:notes:52]
Flex-ing, Cerus, and PPH contributed a total of $48.4 million of revenue and $1.7 million of earnings to the Company's consolidated statements of income from date of acquisition through December 29, 2012.

[0000038725-15-000043:notes:53]
Transaction costs were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations.  Transaction costs included in selling, general, and administrative expense in the Company’s consolidated statements of income were $2.4 million, $1.1 million, and $0.3 million for the fiscal years ended 2014, 2013, and 2012, respectively.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000038725-15-000043:notes:54]
The Company considers cash on hand, demand deposits, and highly liquid investments with an original maturity date of three months or less to be cash and cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000038725-15-000043:notes:55]
CONTINGENCIES AND COMMITMENTS

[0000038725-15-000043:notes:56]
In August 2010, the California Air Resources Board (“CARB”) and South Coast Air Quality Management District (“SCAQMD”) filed civil complaints in the Los Angeles Superior Court against the Company and Franklin Fueling Systems, Inc.  The complaints related to a third-party-supplied component part of the Company's Healy 900 Series nozzle, which is part of the Company's Enhanced Vapor Recovery (“EVR”) Systems installed in California gasoline filling stations.  This part, a diaphragm, was the subject of a retrofit during the first half of 2008.  As the Company previously reported, in October 2008 CARB issued a Notice of Violation to the Company alleging that the circumstances leading to the retrofit program violated California statutes and regulations.

[0000038725-15-000043:notes:57]
The claims in the complaints mirrored those that CARB presented to the Company in the Notice of Violation, and included claims that the Company negligently and intentionally sold nozzles with a modified diaphragm without required CARB certification. Those complaints were consolidated into one case in the Superior Court of California, County of Los Angeles (People of the State of California vs. Franklin Fueling Systems, Inc. et al.) which was tried in the later part of December 2012 and early part of January 2013 (“CARB Case”).

[0000038725-15-000043:notes:58]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company filed its response brief on December 23, 2014 and CARB filed its Reply brief on February 2, 2015. The case is now with the California Court of Appeals to either make a ruling on those briefs or schedule an oral argument.

[0000038725-15-000043:notes:59]
Neither of these suits has had any effect on CARB's certification of the Company's EVR System or any other products of the Company or its subsidiaries, and did not interfere with continuing sales.  CARB has never decertified the Company's EVR System and has never proposed to do so.

[0000038725-15-000043:notes:60]
The Company is defending various other claims and legal actions, including environmental matters, which have arisen in the

[0000038725-15-000043:notes:61]
ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with

[0000038725-15-000043:notes:62]
counsel, these claims and legal actions can be successfully defended or resolved without a material adverse effect on the

[0000038725-15-000043:notes:63]
Company’s financial position, results of operations, and net cash flows.

[0000038725-15-000043:notes:64]
Total rent expense charged to operations for operating leases including contingent rentals was $12.6 million, $11.0 million, and $9.5 million in 2014, 2013, and 2012, respectively.

[0000038725-15-000043:notes:65]
The future minimum rental payments for non-cancelable operating leases as of January 3, 2015, are as follows:

[0000038725-15-000043:notes:66]
| (In millions) | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |
| Future minimum rental payments | $ | 4.8 |  |  | $ | 4.1 |  |  | $ | 1.0 |  |  | $ | 0.6 |  |  | $ | 0.4 |  |

[0000038725-15-000043:notes:67]
Rental commitments subsequent to 2019 are not significant by year, but aggregated are $0.4 million in total.

[0000038725-15-000043:notes:68]
At January 3, 2015, the Company had $6.3 million of commitments primarily for the purchase of raw materials to be used in production.

[0000038725-15-000043:notes:69]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's consolidated balance sheets for 2014 and 2013, are as follows:

[0000038725-15-000043:notes:70]
| (In millions) |  | 2014 |  | 2013 |
| Beginning balance |  | $ | 9.5 |  |  | $ | 9.7 |  |
| Accruals related to product warranties |  | 8.9 |  |  | 9.1 |  |
| Reductions for payments made |  | (9.0 | ) |  | (9.3 | ) |
| Ending balance |  | $ | 9.4 |  |  | $ | 9.5 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-15-000043:notes:71]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0000038725-15-000043:notes:72]
Changes in accumulated other comprehensive income (loss) by component are summarized below:

[0000038725-15-000043:notes:73]
| (In millions) |  |  |  |  |  |
| For the Year Ended January 3, 2015: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance, December 28, 2013 | $ | (16.0 | ) |  | $ | (38.7 | ) |  | $ | (54.7 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (36.3 | ) |  | — |  |  | (36.3 | ) |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (36.3 | ) |  | — |  |  | (36.3 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |

[0000038725-15-000043:notes:74]
| Pre-tax income/(loss) | — |  |  | (26.0 | ) | (1) | (26.0 | ) |
| Income tax (expense)/benefit | — |  |  | 8.6 |  |  | 8.6 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | (17.4 | ) |  | (17.4 | ) |
| Net current period other comprehensive income/(loss), net of income taxes | (36.3 | ) |  | (17.4 | ) |  | (53.7 | ) |
| Other comprehensive (income)/loss attributable to noncontrolling interest | 0.5 |  |  | — |  |  | 0.5 |  |
| Balance, January 3, 2015 | $ | (51.8 | ) |  | $ | (56.1 | ) |  | $ | (107.9 | ) |
| For the Year Ended December 28, 2013: |  |  |  |  |  |
| Balance, December 29, 2012 | $ | (0.3 | ) |  | $ | (56.8 | ) |  | $ | (57.1 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (16.0 | ) |  | — |  |  | (16.0 | ) |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (16.0 | ) |  | — |  |  | (16.0 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income/(loss) | — |  |  | 30.2 |  | (1) | 30.2 |  |
| Income tax (expense)/benefit | — |  |  | (12.1 | ) |  | (12.1 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 18.1 |  |  | 18.1 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (16.0 | ) |  | 18.1 |  |  | 2.1 |  |
| Other comprehensive (income)/loss attributable to noncontrolling interest | 0.3 |  |  | — |  |  | 0.3 |  |
| Balance, December 28, 2013 | $ | (16.0 | ) |  | $ | (38.7 | ) |  | $ | (54.7 | ) |
| For the Year Ended December 29, 2012: |  |  |  |  |  |
| Balance, December 31, 2011 | $ | (2.2 | ) |  | $ | (47.1 | ) |  | $ | (49.3 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | 1.8 |  |  | — |  |  | 1.8 |  |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | 1.8 |  |  | $ | — |  |  | 1.8 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income/(loss) | — |  |  | (15.9 | ) | (1 | ) | (15.9 | ) |
| Income tax (expense)/benefit | — |  |  | 6.2 |  |  | 6.2 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | (9.7 | ) |  | (9.7 | ) |
| Net current period other comprehensive income/(loss), net of income taxes | 1.8 |  |  | (9.7 | ) |  | (7.9 | ) |
| Other comprehensive (income)/loss attributable to noncontrolling interest | 0.1 |  |  | — |  |  | 0.1 |  |
| Balance, December 29, 2012 | $ | (0.3 | ) |  | $ | (56.8 | ) |  | $ | (57.1 | ) |

[0000038725-15-000043:notes:75]
(1) This accumulated other comprehensive income (loss) component is included in the computation of net periodic pension cost (refer to Note 10 for additional details) and is included in the "Selling, general, and administrative expenses" line of the consolidated statements of income.


## us-gaap:ConsolidationPolicyTextBlock

[0000038725-15-000043:notes:76]
The consolidated financial statements include the accounts of Franklin Electric Co., Inc. and its consolidated subsidiaries.  All intercompany transactions have been eliminated.


## us-gaap:DebtDisclosureTextBlock

[0000038725-15-000043:notes:77]
DEBT

[0000038725-15-000043:notes:78]
On December 14, 2006, the Company entered into an amended and restated unsecured, 60-month $120.0 million revolving credit agreement (the “Agreement”).  The Agreement provides for various borrowing rate options including interest rates based on the London Interbank Offered Rates (LIBOR) plus interest spreads keyed to the Company’s ratio of debt to earnings before interest, taxes, depreciation, and amortization (“EBITDA”).  On December 14, 2011, the Company executed the Second Amended and Restated Credit Agreement, which extended the maturity of the Agreement to December 14, 2016, and increased the commitment amount to $150.0 million.

[0000038725-15-000043:notes:79]
The Agreement contains certain financial covenants with respect to borrowings, interest coverage, loans or advances and investments.  The Company was in compliance with the covenants as of January 3, 2015 and December 28, 2013.  The Company had zero borrowings under the Agreement at January 3, 2015 and December 28, 2013.

[0000038725-15-000043:notes:80]
On April 9, 2007, the Company entered into the Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") in the amount of $175.0 million.  Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”).  The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had at issuance an average life of 10 years with a final maturity in 2019.  On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million.  On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Agreement.

[0000038725-15-000043:notes:81]
As of January 3, 2015, the Company has $50.0 million borrowing capacity available under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.  The Prudential Agreement contains certain financial covenants with respect to borrowings, interest coverage, loans or advances and investments.

[0000038725-15-000043:notes:82]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement.  Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).”  The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million.  The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (tax increment financing debt) bear interest at 3.6 percent per annum.  Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.  The use of the proceeds from the Project Notes was limited to assist the financing of the new Global Corporate Headquarters and Engineering Center.

[0000038725-15-000043:notes:83]
The agreement contains customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio and a minimum interest coverage ratio. The agreement also contains a cross default provision in the event the Company defaults on any obligation exceeding $10.0 million.

[0000038725-15-000043:notes:84]
Also, on December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015.

[0000038725-15-000043:notes:85]
The Company also has certain overdraft facilities at its foreign subsidiaries, of which none were outstanding at January 3, 2015 and December 28, 2013.

[0000038725-15-000043:notes:86]
Debt consisted of the following:

[0000038725-15-000043:notes:87]
| (In millions) |  | 2014 |  | 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.7 |  |  | 24.6 |  |
| Capital leases |  | 0.6 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 3.5 |  |  | 14.2 |  |
|  |  | 177.8 |  |  | 189.6 |  |
| Less current maturities |  | (34.1 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 143.7 |  |  | $ | 174.2 |  |

[0000038725-15-000043:notes:88]
Foreign subsidiary debt denoted in the table above as of January 3, 2015 is predominately comprised of debt assumed with acquisitions made in 2014.  Foreign subsidiary debt as of December 28, 2013 is predominately comprised of debt at Impo.

[0000038725-15-000043:notes:89]
The following debt payments are expected to be paid in accordance with the following schedule:

[0000038725-15-000043:notes:90]
| (In millions) |  | Total |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | More than 5 years |
| Debt |  | $ | 177.2 |  |  | $ | 33.8 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.4 |  |  | $ | 31.0 |  |  | $ | 18.8 |  |
| Capital leases |  | 0.6 |  |  | 0.3 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |
|  |  | $ | 177.8 |  |  | $ | 34.1 |  |  | $ | 31.2 |  |  | $ | 31.2 |  |  | $ | 31.5 |  |  | $ | 31.0 |  |  | $ | 18.8 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-15-000043:notes:91]
FINANCIAL INSTRUMENTS

[0000038725-15-000043:notes:92]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  During February 2014, the Company entered into a share swap transaction agreement ("the swap") to mitigate the Company’s exposure to these fluctuations in the Company's stock price.  The swap was not designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  The swap has a notional value based on 147,750 shares.  For the year ended January 3, 2015, the swap transaction resulted in losses of $0.8 million which were offset by gains on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-15-000043:notes:93]
SHARE-BASED COMPENSATION

[0000038725-15-000043:notes:94]
The Company maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the "2012 Stock Plan"), which is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards and stock unit awards, to key employees and non-employee directors.  Shares and per share data below have been adjusted for all periods presented to reflect the two-for-one stock split effective March 18, 2013.

[0000038725-15-000043:notes:95]
All options in the 2009 Stock Plan have been awarded.

[0000038725-15-000043:notes:96]
The Company currently issues new shares from its common stock balance to satisfy option exercises and the settlement of stock awards and stock unit awards made under the 2009 Stock Plan and/or the 2012 Stock Plan.

[0000038725-15-000043:notes:97]
The total share-based compensation expense recognized in 2014, 2013, and 2012 was $7.5 million, $4.9 million, and $6.3 million, respectively.

[0000038725-15-000043:notes:98]
Stock Options:

[0000038725-15-000043:notes:99]
Under the above plans, the exercise price of each option equals the market price of the Company’s common stock on the date of grant, and the options expire 10 years after the date of the grant.  Options granted to employees vest at 25 percent a year and become fully vested and fully exercisable after 4 years (vesting is accelerated upon retirement, death, or disability).  Subject to the terms of the plans, in general, the aggregate option exercise price and any applicable tax withholdings may be satisfied in cash or its equivalent, by the plan participant’s delivery of shares of the Company’s common stock having a fair market value at the time of exercise equal to the aggregate option exercise price and/or the applicable tax withholdings or by having shares otherwise subject to the award withheld by the Company or via cash-less exercise through a broker-dealer.

[0000038725-15-000043:notes:100]
The fair value of each option award is estimated on the date of grant using the Black-Scholes option valuation model with a single approach and amortized using a straight-line attribution method over the option’s vesting period.  Options granted to retirement eligible employees are immediately expensed.  The Company uses historical data to estimate the expected volatility of its stock, the weighted average expected life, the period of time options granted are expected to be outstanding, and its dividend yield.  The risk-free rates for periods within the contractual life of the option are based on the U.S. Treasury yield curve in effect at the time of the grant.

[0000038725-15-000043:notes:101]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during 2014, 2013, and 2012, are as follows:

[0000038725-15-000043:notes:102]
|  |  | 2014 |  | 2013 |  | 2012 |
| Risk-free interest rate |  | 1.68 | % |  | 1.03 | % |  | 1.01 | % |
| Dividend yield |  | 0.70 | % |  | 0.89 | % |  | 1.12 | % |
| Volatility factor |  | 0.387 |  |  | 0.394 |  |  | 0.388 |  |
| Expected term |  | 5.6 years |  |  | 6.0 years |  |  | 6.0 years |  |
| Forfeiture rate |  | 3.81 | % |  | 4.52 | % |  | 3.99 | % |

[0000038725-15-000043:notes:103]
A summary of the Company’s outstanding stock option activity and related information is as follows:

[0000038725-15-000043:notes:104]
| (Shares in thousands) |  |  |  |  |  |  |  |  |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | AggregateIntrinsic Value (000’s) |
| Outstanding at beginning of 2012 |  | 3,138 |  |  | $ | 14.83 |  |  |  |  |  |
| Granted |  | 250 |  |  | 24.10 |  |  |  |  |  |
| Exercised |  | (1,158 | ) |  | 13.29 |  |  |  |  |  |
| Forfeited |  | (46 | ) |  | 22.91 |  |  |  |  |  |
| Expired |  | — |  |  | — |  |  |  |  |  |
| Outstanding at beginning of 2013 |  | 2,184 |  |  | $ | 16.69 |  |  |  |  |  |
| Granted |  | 176 |  |  | 32.53 |  |  |  |  |  |
| Exercised |  | (880 | ) |  | 15.98 |  |  |  |  |  |
| Forfeited |  | (4 | ) |  | 14.37 |  |  |  |  |  |
| Expired |  | — |  |  | — |  |  |  |  |  |
| Outstanding at beginning of 2014 |  | 1,476 |  |  | $ | 19.01 |  |  |  |  |  |
| Granted |  | 115 |  |  | 42.24 |  |  |  |  |  |
| Exercised |  | (171 | ) |  | 17.03 |  |  |  |  |  |
| Forfeited |  | (6 | ) |  | 26.28 |  |  |  |  |  |
| Expired |  | (17 | ) |  | 16.34 |  |  |  |  |  |
| Outstanding at end of period |  | 1,397 |  |  | $ | 21.17 |  |  | 5.46 years |  | $ | 23,122 |  |
| Expected to vest after applying forfeiture rate |  | 1,385 |  |  | $ | 21.04 |  |  | 5.43 years |  | $ | 23,074 |  |
| Vested and exercisable at end of period |  | 1,084 |  |  | $ | 17.79 |  |  | 4.69 years |  | $ | 21,177 |  |

[0000038725-15-000043:notes:105]
|  |  | 2014 |  | 2013 |  | 2012 |
| Weighted average grant-date fair value of options |  | $ | 15.09 |  |  | $ | 11.47 |  |  | $ | 8.19 |  |

[0000038725-15-000043:notes:106]
| (In millions) |  | 2014 |  | 2013 |  | 2012 |
| Intrinsic value of options exercised |  | $ | 3.8 |  |  | $ | 16.6 |  |  | $ | 16.5 |  |
| Cash received from the exercise of options |  | 2.9 |  |  | 14.1 |  |  | 15.4 |  |
| Fair value of shares vested |  | 2.8 |  |  | 2.1 |  |  | 2.4 |  |
| Tax benefit |  | 1.5 |  |  | 6.5 |  |  | 6.5 |  |

[0000038725-15-000043:notes:107]
There were no share-based liabilities paid during the 2014 and 2013 fiscal years.

[0000038725-15-000043:notes:108]
A summary of the Company’s non-vested stock option activity and related information is as follows:

[0000038725-15-000043:notes:109]
| (Shares in thousands) |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of 2013 |  | 802 |  |  | $ | 17.07 |  |
| Granted |  | 176 |  |  | 32.53 |  |
| Vested |  | (440 | ) |  | 13.31 |  |
| Forfeited |  | (4 | ) |  | 14.37 |  |
| Non-vested at beginning of 2014 |  | 534 |  |  | $ | 25.30 |  |
| Granted |  | 115 |  |  | 42.24 |  |
| Vested |  | (330 | ) |  | 23.98 |  |
| Forfeited |  | (6 | ) |  | 26.28 |  |
| Non-vested at end of period |  | 313 |  |  | $ | 32.91 |  |

[0000038725-15-000043:notes:110]
As of January 3, 2015, there was $1.5 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements granted under the 2012 Stock Plan and the 2009 Stock Plan related to stock options.  That cost is expected to be recognized over a weighted-average period of 2.28 years.

[0000038725-15-000043:notes:111]
Stock/Stock Unit Awards:

[0000038725-15-000043:notes:112]
Under the 2009 Stock Plan, non-employee directors and employees may be granted stock awards.  Under the 2012 Stock Plan, non-employee directors and employees may be granted stock awards and stock units, including grants of restricted shares of the Company’s common stock.

[0000038725-15-000043:notes:113]
Stock awards to non-employee directors are generally fully vested when made.  Stock/stock unit awards to employees cliff vest over 3 or 4 years (subject to accelerated vesting of a pro rata portion in the case of retirement, death or disability) and may be contingent on the attainment of certain performance goals.  Dividends are paid to the recipient prior to vesting, except that dividends on performance-based stock awards under the 2012 Stock Plan will be paid only to the extent the performance goals are met.  Stock/stock unit awards granted to retirement eligible employees are expensed over the 4 year vesting period.

[0000038725-15-000043:notes:114]
A summary of the Company’s restricted stock/stock unit award activity and related information is as follows:

[0000038725-15-000043:notes:115]
| (Shares in thousands) |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of 2013 |  | 458 |  |  | $ | 20.90 |  |
| Awarded |  | 165 |  |  | 32.90 |  |
| Vested |  | (66 | ) |  | 18.78 |  |
| Forfeited |  | (6 | ) |  | 20.05 |  |
| Non-vested at beginning of 2014 |  | 551 |  |  | $ | 24.75 |  |
| Awarded |  | 208 |  |  | 42.39 |  |
| Vested |  | (132 | ) |  | 17.08 |  |
| Forfeited |  | (73 | ) |  | 28.49 |  |
| Non-vested at end of period |  | 554 |  |  | $ | 32.72 |  |

[0000038725-15-000043:notes:116]
As of January 3, 2015, there was $8.6 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements granted under the 2012 Stock Plan and the 2009 Stock Plan related to stock awards.  That cost is expected to be recognized over a weighted-average period of 2.29 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000038725-15-000043:notes:117]
Basic and diluted earnings per share are computed and disclosed in accordance with FASB ASC Topic 260, Earnings Per Share.  The Company utilizes the two-class method to compute earnings available to common shareholders.  Under the two-class method, earnings are adjusted by accretion amounts to redeemable noncontrolling interests recorded at redemption value.  The adjustments represent dividend distributions, in substance, to the noncontrolling interest holder as the holders have contractual rights to receive an amount upon redemption other than the fair value of applicable shares.  As a result, earnings are adjusted to reflect this in substance distribution that is different from other common shareholders.  In addition, the Company allocates net earnings to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company's participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.  Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.


## us-gaap:EarningsPerShareTextBlock

[0000038725-15-000043:notes:118]
EARNINGS PER SHARE

[0000038725-15-000043:notes:119]
The Company calculates basic and diluted earnings per common share using the two-class method.  Under the two-class method, net earnings are allocated to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company's participating securities consist of share-based payment awards that contain a nonforfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.

[0000038725-15-000043:notes:120]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-15-000043:notes:121]
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-15-000043:notes:122]
| (In millions, except per share amounts) |  | 2014 |  | 2013 |  | 2012 |
| Numerator: |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. |  | $ | 69.8 |  |  | $ | 82.0 |  |  | $ | 82.9 |  |
| Less: Undistributed earnings allocated to participating securities |  | 0.7 |  |  | 1.0 |  |  | 0.6 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest |  | 0.9 |  |  | 0.2 |  |  | — |  |
|  |  | $ | 68.2 |  |  | $ | 80.8 |  |  | $ | 82.3 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  |  |  |  |  |
| Weighted average common shares |  | 47.7 |  |  | 47.5 |  |  | 46.9 |  |
| Diluted |  |  |  |  |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee and director incentive stock options and performance awards |  | 0.5 |  |  | 0.6 |  |  | 0.8 |  |
| Adjusted weighted average common shares |  | 48.2 |  |  | 48.1 |  |  | 47.7 |  |
| Basic earnings per share |  | $ | 1.43 |  |  | $ | 1.70 |  |  | $ | 1.76 |  |
| Diluted earnings per share |  | $ | 1.41 |  |  | $ | 1.68 |  |  | $ | 1.73 |  |
| Anti-dilutive stock options |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |

[0000038725-15-000043:notes:123]
Shares and per share data have been adjusted for all periods presented to reflect a two-for-one stock split effective March 18, 2013.


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000038725-15-000043:notes:124]
The following table summarizes information regarding the Company’s non-financial assets and liabilities measured at fair value on a non-recurring basis:

[0000038725-15-000043:notes:125]
|  |  | January 3, 2015 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Recognized Loss |
| Asset held for sale |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000038725-15-000043:notes:126]
|  |  | December 28, 2013 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Recognized Loss |
| Asset held for sale |  | $ | 1.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.8 |  |  | $ | 1.3 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-15-000043:notes:127]
As of January 3, 2015 and December 28, 2013, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below.  The "Recognized Loss" amounts in the table are accumulated totals since inception.

[0000038725-15-000043:notes:128]
| (In millions) |  | January 3, 2015 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Recognized Loss |
| Cash equivalents |  | $ | 5.4 |  |  | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
|  |  | December 28, 2013 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  | Recognized Loss |
| Cash equivalents |  | $ | 6.6 |  |  | $ | 6.6 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-15-000043:notes:129]
FAIR VALUE MEASUREMENTS

[0000038725-15-000043:notes:130]
FASB ASC Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy.  Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date.  The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value.  The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-15-000043:notes:131]
Level 1 – Quoted prices for identical assets and liabilities in active markets;

[0000038725-15-000043:notes:132]
Level 2 – Quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets; and

[0000038725-15-000043:notes:133]
Level 3 – Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable.

[0000038725-15-000043:notes:134]
The Company's Level 1 assets consist of cash equivalents which are generally comprised of foreign bank guaranteed certificates of deposit.

[0000038725-15-000043:notes:135]
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3.

[0000038725-15-000043:notes:136]
The Company's Level 3 assets consist of held for sale assets.  During the fourth quarter of 2013, the Company agreed upon the terms of a letter of intent to sell its Oklahoma City facility.  As a result, the Company reduced the carrying amount of the held for sale asset to approximate the agreed upon sales price less costs to sell.  The transaction was completed during the first quarter of 2014.

[0000038725-15-000043:notes:137]
As of January 3, 2015, the Company had $2.4 million of assets held for sale recorded at carrying value in the Water Systems segment relating to a facility in Brazil.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000038725-15-000043:notes:138]
All assets and liabilities of foreign subsidiaries in functional currency other than the U.S. dollar are translated at year end exchange rates.  All revenue and expense accounts are translated at average rates in effect during the respective period.  Adjustments for translating longer term foreign currency assets and liabilities in U.S. dollars are included as a component of other comprehensive income.  Transaction gains and losses that arise from shorter term exchange rate fluctuations are included in the results of operations in “Foreign exchange expense", as incurred.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-15-000043:notes:139]
GOODWILL AND OTHER INTANGIBLE ASSETS

[0000038725-15-000043:notes:140]
Amortization expense related to intangible assets for fiscal years 2014, 2013, and 2012, was $9.1 million, $8.0 million, and $7.2 million, respectively.

[0000038725-15-000043:notes:141]
Amortization expense for each of the five succeeding years is projected as follows:

[0000038725-15-000043:notes:142]
| (In millions) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |
|  |  | $ | 8.9 |  |  | $ | 8.9 |  |  | $ | 8.6 |  |  | $ | 8.6 |  |  | $ | 8.3 |  |

[0000038725-15-000043:notes:143]
The Company uses the acquisition method of accounting for business combinations.  Annual goodwill impairment testing and trade name impairment testing is performed during the fourth quarter of each year based on balances as of the last Saturday of the Company's eighth fiscal period, unless events or circumstances indicate earlier impairment testing is required.  No impairment loss was recognized for 2014, 2013, or 2012.

[0000038725-15-000043:notes:144]
The change in the carrying amount of goodwill by reporting segment for 2014 and 2013, is as follows:

[0000038725-15-000043:notes:145]
| (In millions) |  | 2014 |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of December 28, 2013 |  | $ | 144.1 |  |  | $ | 63.1 |  |  | $ | 207.2 |  |
| Acquisitions |  | 6.7 |  |  | 0.6 |  |  | 7.3 |  |
| Adjustments to prior year acquisitions |  | — |  |  | — |  |  | — |  |
| Foreign currency translation |  | (5.5 | ) |  | (0.2 | ) |  | (5.7 | ) |
| Balance as of January 3, 2015 |  | $ | 145.3 |  |  | $ | 63.5 |  |  | $ | 208.8 |  |

[0000038725-15-000043:notes:146]
| (In millions) |  | 2013 |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of December 29, 2012 |  | $ | 144.9 |  |  | $ | 63.2 |  |  | $ | 208.1 |  |
| Acquisitions |  | 1.2 |  |  | — |  |  | 1.2 |  |
| Adjustments to prior year acquisitions |  | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Foreign currency translation |  | (1.9 | ) |  | (0.1 | ) |  | (2.0 | ) |
| Balance as of December 28, 2013 |  | $ | 144.1 |  |  | $ | 63.1 |  |  | $ | 207.2 |  |

[0000038725-15-000043:notes:147]
The 2014 acquired goodwill in the Water Systems segment primarily related to the Company's acquisition of Bombas Leao.  The remaining acquired goodwill in both the Water Systems and Fueling Systems segments related to two immaterial controlling interest acquisitions made in India.  The 2013 acquired goodwill in the Water Systems segment related to a series of immaterial acquisitions by the Company during 2013.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000038725-15-000043:notes:148]
The Company tests goodwill for impairment on an annual basis during the fourth quarter or more frequently as warranted by triggering events that indicate potential impairment.  Goodwill is tested at the reporting unit level, which the company has determined to be the North America Water Systems, International Water, and Fueling Systems units.  In compliance with FASB ASC Topic 350, Intangibles - Goodwill and Other, the Company has evaluated the aggregation criteria and determined that the components within the North America Water Systems and International Water reporting units can be aggregated in 2014.

[0000038725-15-000043:notes:149]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the income and market valuation approaches.  The income approach estimates fair value based upon future revenue, expenses, and cash flows discounted to present value.  The market valuation approach estimates fair value using market multipliers of various financial measures compared to a set of comparable public companies.

[0000038725-15-000043:notes:150]
An indication of impairment exists if the carrying value of the reporting unit is higher than its fair value, as determined by the above approach.  The second step of testing as outlined in FASB ASC Topic 350 must be performed to measure the amount of impairment loss.  The amount of impairment is determined by comparing the implied fair value of the reporting unit's goodwill to its carrying value in the same manner as if the reporting units were being acquired in a business combination.  The Company would allocate the fair value to all of the reporting unit's assets and liabilities, including any unrecognized intangible assets, in a hypothetical analysis that would calculate the implied fair value of goodwill.  The Company would record an impairment charge for the difference between the implied fair value of goodwill and the recorded goodwill.

[0000038725-15-000043:notes:151]
The Company also tests indefinite lived intangible assets, primarily trade names, for impairment on an annual basis during the fourth quarter of each year, or more frequently as warranted by triggering events that indicate potential impairment.  In assessing the recoverability of the trade names, the Company determines the fair value using an income approach.  The income approach estimates fair value based upon future revenue and estimated royalty rates.  An indication of impairment exists if the carrying value of the trade names is higher than the fair value.  The Company would record an impairment charge for the difference.

[0000038725-15-000043:notes:152]
Amortization is recorded and calculated for other definite lived intangible assets on a basis that reflects cash flows over the estimated useful lives.  The weighted average number of years over which each intangible class is amortized is 17 years for patents, 6 years for supply agreements, 15 years for technology, 13 to 20 years for customer relationships, 5 years for software, and 8 years for all others.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-15-000043:notes:153]
INCOME TAXES

[0000038725-15-000043:notes:154]
Income before income taxes consisted of the following:

[0000038725-15-000043:notes:155]
| (In millions) |  | 2014 |  | 2013 |  | 2012 |
| Domestic |  | $ | 42.2 |  |  | $ | 53.5 |  |  | $ | 53.2 |  |
| Foreign |  | 47.5 |  |  | 58.0 |  |  | 62.8 |  |
|  |  | $ | 89.7 |  |  | $ | 111.5 |  |  | $ | 116.0 |  |

[0000038725-15-000043:notes:156]
The income tax provision/(benefit) from continuing operations consisted of the following:

[0000038725-15-000043:notes:157]
| (In millions) |  | 2014 |  | 2013 |  | 2012 |
| Current: |  |  |  |  |  |  |
| Federal |  | $ | 7.4 |  |  | $ | 10.8 |  |  | $ | 13.9 |  |
| Foreign |  | 12.2 |  |  | 14.3 |  |  | 7.9 |  |
| State |  | 1.7 |  |  | 2.1 |  |  | 1.9 |  |
| Total current |  | 21.3 |  |  | 27.2 |  |  | 23.7 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Federal |  | 3.3 |  |  | 4.3 |  |  | 4.6 |  |
| Foreign |  | (3.8 | ) |  | (1.3 | ) |  | 3.3 |  |
| State |  | (1.9 | ) |  | (1.3 | ) |  | 0.7 |  |
| Total deferred |  | $ | (2.4 | ) |  | $ | 1.7 |  |  | $ | 8.6 |  |
|  |  | $ | 18.9 |  |  | $ | 28.9 |  |  | $ | 32.3 |  |

[0000038725-15-000043:notes:158]
A reconciliation of the tax provision for continuing operations at the U.S. statutory rate to the effective income tax expense rate as reported is as follows:

[0000038725-15-000043:notes:159]
|  |  | 2014 |  | 2013 |  | 2012 |
| U.S. Federal statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State income taxes, net of federal benefit |  | 1.0 |  |  | 1.2 |  |  | 0.9 |  |
| Foreign operations |  | (9.2 | ) |  | (6.2 | ) |  | (7.6 | ) |
| R&D tax credits |  | (0.6 | ) |  | (1.1 | ) |  | — |  |
| Uncertain tax position adjustments |  | (1.6 | ) |  | (1.9 | ) |  | 2.8 |  |
| Deferred tax adjustments, rate and other |  | (3.9 | ) |  | — |  |  | (4.7 | ) |
| Valuation allowance on state deferred tax |  | (0.3 | ) |  | (0.8 | ) |  | 0.8 |  |
| Other items |  | 0.6 |  |  | (0.3 | ) |  | 0.6 |  |
| Effective tax rate |  | 21.0 | % |  | 25.9 | % |  | 27.8 | % |

[0000038725-15-000043:notes:160]
Significant components of the Company's deferred tax assets and liabilities were as follows:

[0000038725-15-000043:notes:161]
| (In millions) |  | 2014 |  | 2013 |
| Deferred tax assets: |  |  |  |  |
| Accrued expenses and reserves |  | $ | 12.2 |  |  | $ | 11.0 |  |
| Compensation and employee benefits |  | 32.6 |  |  | 25.1 |  |
| Other items |  | 7.3 |  |  | 5.1 |  |
| Valuation allowance on state deferred tax |  | (3.9 | ) |  | (3.5 | ) |
| Total deferred tax assets |  | 48.2 |  |  | 37.7 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Accelerated depreciation on fixed assets |  | 14.0 |  |  | 10.3 |  |
| Amortization of intangibles |  | 62.1 |  |  | 61.0 |  |
| Other items |  | 6.0 |  |  | 9.2 |  |
| Total deferred tax liabilities |  | 82.1 |  |  | 80.5 |  |
| Net deferred tax liabilities |  | $ | (33.9 | ) |  | $ | (42.8 | ) |

[0000038725-15-000043:notes:162]
The effective tax rate continues to be lower than the statutory rate primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate as well as recognition of foreign tax credits.  The tax rate declined in 2014 from the tax rate in 2013 primarily due to a reversal of deferred tax liabilities associated with earnings of certain foreign subsidiaries which have been realigned within the Company’s organization.  The realignment of certain foreign entities results in their unremitted earnings being indefinitely reinvested.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations as well as cash on hand and available credit.

[0000038725-15-000043:notes:163]
The Company assesses the available positive and negative evidence to estimate whether sufficient future taxable income will be generated to permit use of the existing deferred tax assets. A significant piece of objective negative evidence evaluated was the cumulative loss for state income tax purposes incurred over the three-year period ended January 3, 2015. Such objective evidence limits the ability to consider other subjective evidence, such as our projections for future growth.

[0000038725-15-000043:notes:164]
On the basis of this evaluation, as of January 3, 2015, a valuation allowance of $3.9 million has been recorded to recognize only the portion of the deferred tax asset that is more likely than not to be realized.

[0000038725-15-000043:notes:165]
The Company has foreign income tax net operating loss ("NOL") carryforwards of $3.1 million and state income tax NOL and credit carryforwards of $3.2 million, which will expire on various dates as follows:

[0000038725-15-000043:notes:166]
| (In millions) |  |
| 2015-2019 | $ | 0.3 |  |
| 2020-2024 | 1.0 |  |
| 2025-2029 | 0.2 |  |
| 2030-2034 | 1.9 |  |
| Unlimited | 2.9 |  |
|  | $ | 6.3 |  |

[0000038725-15-000043:notes:167]
The Company believes that it is more likely than not that the benefit from certain state NOL and credit carryforwards will not be realized.  In recognition of this risk, we have provided a valuation allowance of $3.2 million on the deferred tax assets related to these state NOL and credit carryforwards.

[0000038725-15-000043:notes:168]
The Company identifies the accumulated earnings for the affiliates that were not indefinitely reinvested and computes the tax associated with the subsequent repatriation.  This computation considers the impact of applicable withholding taxes and the availability of U.S. foreign tax credits. The Company has calculated the repatriation of all the accumulated earnings that are not indefinitely reinvested which resulted in a net deferred tax liability of $0.6 million recorded by the Company as of January 3, 2015.

[0000038725-15-000043:notes:169]
The Company does not provide for deferred taxes on the excess of the financial reporting over the tax basis in our investments in foreign subsidiaries that are essentially permanent in duration.  That excess is approximately $265.8 million as of January 3, 2015.  The determination of the additional deferred taxes that have not been provided is not practicable.

[0000038725-15-000043:notes:170]
As of the beginning of fiscal year 2014, the Company had gross unrecognized tax benefits of $5.1 million, excluding accrued interest and penalties.  The unrecognized tax benefits decreased $0.8 million for federal tax liabilities and increased $0.1 million for state income tax liabilities based on evaluations made during 2014 primarily due to statute expirations and offset by uncertain tax positions identified in the current year.  The Company had gross unrecognized tax benefits, excluding accrued interest and penalties, of $4.4 million as of January 3, 2015.

[0000038725-15-000043:notes:171]
A reconciliation of the beginning and ending amount of gross unrecognized tax benefits for 2014, 2013, and 2012 (excluding interest and penalties) is as follows:

[0000038725-15-000043:notes:172]
| (In millions) |  | 2014 |  | 2013 |  | 2012 |
| Beginning balance |  | $ | 5.1 |  |  | $ | 6.9 |  |  | $ | 5.6 |  |
| Additions for tax positions of the current year |  | 0.1 |  |  | — |  |  | — |  |
| Additions for tax positions of prior years |  | 1.7 |  |  | 1.7 |  |  | 3.6 |  |
| Reductions for tax positions of prior years |  | (1.1 | ) |  | (3.5 | ) |  | (1.7 | ) |
| Statute expirations |  | (1.4 | ) |  | — |  | — |  | — |  |
| Settlements |  | — |  |  | — |  |  | (0.6 | ) |
| Ending balance |  | $ | 4.4 |  |  | $ | 5.1 |  |  | $ | 6.9 |  |

[0000038725-15-000043:notes:173]
If recognized, each annual effective tax rate would be affected by the net unrecognized tax benefits of $4.3 million, $5.0 million, and $6.8 million as of January 3, 2015, December 28, 2013, and December 29, 2012, respectively.

[0000038725-15-000043:notes:174]
The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.  In 2014, interest and penalties increased $2.3 million, for prior year tax positions.  The Company has accrued interest and penalties as of January 3, 2015, December 28, 2013, and December 29, 2012 of approximately $2.5 million, $0.2 million, and $1.1 million, respectively.

[0000038725-15-000043:notes:175]
Of the unrecognized tax benefits at January 3, 2015, $1.8 million is related to acquisitions for which indemnification was provided for in the respective purchase agreement.  The stock purchase agreements related to these acquisitions provide the Company rights to recover tax liabilities related to pre-acquisition tax years from the sellers.

[0000038725-15-000043:notes:176]
The Company is subject to taxation in the United States and various state and foreign jurisdictions.  With few exceptions, as of January 3, 2015, the Company is no longer subject to U.S. federal income tax examinations by authorities for years before 2011 and is no longer subject to state or foreign income tax examinations by tax authorities for years before 2009.

[0000038725-15-000043:notes:177]
It is reasonably possible that the amounts of unrecognized tax benefits could change in the next twelve months as a result of an audit or due to the expiration of a statute of limitation.  Based on the current audits in process and pending statute expirations, the payment of taxes as a result could be up to $1.7 million.


## us-gaap:IncomeTaxPolicyTextBlock

[0000038725-15-000043:notes:178]
Income taxes are accounted for in accordance with FASB ASC Topic 740, Income Taxes.  Under this guidance, deferred tax assets and liabilities are determined based on the difference between the financial statement and tax basis of assets and liabilities and net operating loss and credit carry forwards using enacted tax rates in effect for the year in which the differences are expected to reverse.  Valuation allowances are established when necessary to reduce deferred tax assets to the amounts expected to be realized.  The Company records a liability for uncertain tax positions by establishing a recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return.


## us-gaap:InventoryPolicyTextBlock

[0000038725-15-000043:notes:179]
Inventories are stated at the lower of cost or market.  The majority of the cost of domestic and foreign inventories is determined using the FIFO method with a portion of inventory costs determined using the average cost method.  The Company reviews its inventories for excess or obsolete products or components based on an analysis of historical usage and management's evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000038725-15-000043:notes:180]
REDEEMABLE NONCONTROLLING INTERESTS

[0000038725-15-000043:notes:181]
During 2014, the Company completed two acquisitions that each contained a noncontrolling interest and a redemption feature.  The combination of the noncontrolling interest and the redemption feature resulted in the classification as a redeemable noncontrolling interest.  The total redeemable noncontrolling interest recorded as of the acquisition date for these acquisitions during 2014 was $3.1 million, and represents the fair value estimates of the redeemable noncontrolling interests as of the respective acquisition dates.  As of January 3, 2015, the redeemable noncontrolling interests related to these acquisitions were recorded at carrying value.

[0000038725-15-000043:notes:182]
On May 2, 2011, the Company completed the acquisition of 80 percent of Impo.  The original 20 percent noncontrolling interest was recorded at fair value as of the acquisition date.  The noncontrolling interest holders have the option, which is embedded in the noncontrolling interest, to require the Company to redeem their ownership interests after May 2, 2014, three years after the original agreement was signed.  The combination of a noncontrolling interest and a redemption feature resulted in a redeemable noncontrolling interest.

[0000038725-15-000043:notes:183]
During the second quarter of 2014, the Company redeemed 10 percent of the noncontrolling interest of Impo, increasing the Company's ownership to 90 percent for approximately TRY 6.2 million, $2.9 million at the then current exchange rate.  The 10 percent redemption value was calculated using a specified formula and resulted in a carrying value adjustment of TRY 0.2 million ($0.1 million).  The redemption reduced the "Redeemable noncontrolling interest" line in the Company's consolidated balance sheet.  The remaining 10 percent noncontrolling interest will continue to be recorded as a redeemable noncontrolling interest on the balance sheet.  Due to the immaterial nature of the redemption, the Company has not included full year proforma statements of income for the acquisition year or previous year.

[0000038725-15-000043:notes:184]
The Company uses the interest method to accrete changes in the anticipated redemption value of the Impo redeemable noncontrolling interest over an amortization period to the earliest projected redemption date.  Adjustments for both the redeemed and redeemable Impo noncontrolling interests were $0.9 million and $0.2 million for the fiscal years ended 2014 and 2013, respectively.  No adjustments were necessary for the fiscal year ended 2012.  These adjustments were reflected in the computation of earnings per share using the two-class method.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-15-000043:notes:185]
ACCOUNTING PRONOUNCEMENTS

[0000038725-15-000043:notes:186]
In May 2014, the FASB issued ASU 2014-09 Revenue from Contracts with Customers.  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  The ASU is effective for annual reporting periods beginning after December 15, 2016 and early adoption is not permitted.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt the new ASU.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, and cash flows.

[0000038725-15-000043:notes:187]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide That the Performance Target Could Be Achieved After the Requisite Service Period.  The amendments in the ASU require that a performance target that affects vesting and that could be achieved after the requisite service period be treated as a performance condition.  A reporting entity should apply existing guidance in Topic 718, Compensation - Stock Compensation, as it relates to awards with performance conditions that affect vesting to account for such awards.  The amendments in the ASU are effective for annual periods beginning after December 15, 2015, and interim periods within annual periods beginning on or after December 15, 2015, with early adoption permitted.  The Company has adopted this standard with no impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000038725-15-000043:notes:188]
OTHER ASSETS

[0000038725-15-000043:notes:189]
The Company has equity interests in various companies for strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s consolidated balance sheet.  The carrying amount of the investments are adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income, net" line of the Company's consolidated statements of income, was immaterial for the years ended January 3, 2015, December 28, 2013, and December 29, 2012.

[0000038725-15-000043:notes:190]
In 2005, the Company held a 35.0 percent equity interest in PPI, which was accounted for using the equity method.  During the first quarter of 2012, the shareholders of PPI and PPL contributed shares to form a new holding company, PPH, in exchange for equivalent value and control in PPH.  As a result of this contribution, the Company's equity interest decreased to 31.0 percent of PPH.  On March 7, 2012, the Company acquired a controlling interest in PPH, resulting in the consolidation of PPH in the Company's financial statements (see Note 4).  The carrying amount of the equity investment prior to the acquisition of the controlling interest was $11.7 million as of March 6, 2012.  The Company’s proportionate share of Pioneer Pump, Inc. earnings, included in the “Other income, net” line of the Company’s consolidated statements of income, was zero for both 2014 and 2013, respectively, and $0.4 million for 2012 .  The additional purchase was made in 2012 bringing total ownership to 70.5 percent  (see Note 4).


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-15-000043:notes:191]
EMPLOYEE BENEFIT PLANS

[0000038725-15-000043:notes:192]
Defined Benefit Plans - As of January 3, 2015, the Company maintained two domestic pension plans and three German pension plans.  The Company used a January 3 measurement date for these plans.  One of the Company’s domestic pension plans covers two management employees, while the other domestic plan covers all other eligible employees.  The two domestic and three German plans collectively comprise the ‘Pension Benefits’ disclosure caption.

[0000038725-15-000043:notes:193]
The Company redesigned certain retirement plan offerings in 2012.  The redesign was completed in order to increase standardization of retirement plans among U.S. salaried employees and to reduce the expected cash funding volatility of retirement plans, while at the same time keeping in place a competitive retirement plan offering to attract and retain talent.  The Company achieved this by freezing both the Basic Pension Plan and the Cash Balance Plan as of December 31, 2011, with the exception of a certain limited number of Basic Pension Plan participants who will still accrue benefits over a five year sunset period.  Also effective December 31, 2011, the Cash Balance Plan was closed (the Basic Pension Plan was previously closed) and the two plans were merged into a single plan.  The portion of the non-qualified pension plan related to the Cash Balance Plan was also frozen and the account balances were transferred out of the plan into the Company's qualified defined contribution plan.  As of January 1, 2012, the Company instituted new service-based contributions, supplemental to the existing Company match for employees, into the defined contribution retirement plan offering.

[0000038725-15-000043:notes:194]
The Company also maintains a postretirement benefit plan to provide health and life insurance benefits to employees hired prior to 1992.  The Company effectively capped its cost for those benefits through plan amendments made in 1992, freezing Company contributions for insurance benefits at 1991 levels for current and future beneficiaries with actuarially reduced benefits for employees who retire before age 65.  The disclosures surrounding this plan are reflected in the "Other Benefits" caption.

[0000038725-15-000043:notes:195]
The following table sets forth other changes in plan assets and benefit obligation recognized in other comprehensive income for 2014 and 2013:

[0000038725-15-000043:notes:196]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Net actuarial (gain)/loss |  | $ | 29.1 |  |  | $ | (24.6 | ) |  | $ | 1.3 |  |  | $ | (1.0 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net actuarial gain |  | (2.2 | ) |  | (3.2 | ) |  | (0.1 | ) |  | (0.3 | ) |
| Prior service credit |  | — |  |  | — |  |  | (0.4 | ) |  | (0.4 | ) |
| Settlement recognition |  | (1.4 | ) |  | (0.7 | ) |  | — |  |  | — |  |
| Transition asset |  | — |  |  | — |  |  | — |  |  | — |  |
| Deferred tax asset/(liability) |  | (8.3 | ) |  | 11.4 |  |  | (0.3 | ) |  | 0.7 |  |
| Foreign currency exchange |  | (0.3 | ) |  | — |  |  | — |  |  | — |  |
| Total recognized in other comprehensive income |  | $ | 16.9 |  |  | $ | (17.1 | ) |  | $ | 0.5 |  |  | $ | (1.0 | ) |

[0000038725-15-000043:notes:197]
Weighted-average assumptions used to determine domestic benefit obligations:

[0000038725-15-000043:notes:198]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Discount rate |  | 3.95 | % |  | 4.75 | % |  | 3.75 | % |  | 4.50 | % |
| Rate of increase in future compensation* |  | — | % |  | — | % |  | 3.00 - 8.00%(Graded) |  |  | 3.00 - 12.00%(Graded) |  |

[0000038725-15-000043:notes:199]
*No rate of increases in future compensation used within assumptions for 2014 and 2013, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation.

[0000038725-15-000043:notes:200]
Assumptions used to determine domestic periodic benefit cost:

[0000038725-15-000043:notes:201]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Discount rate |  | 4.75 | % |  | 4.00 | % |  | 4.75 | % |  | 4.50 | % |  | 3.50 | % |  | 4.50 | % |
| Rate of increase in future compensation |  | — | % |  | — | % |  | — | % |  | 3.00 - 12.00%(Graded) |  |  | 3.00 - 12.00%(Graded) |  |  | 3.00 - 12.00%(Graded) |  |
| Expected long-term rate of return on plan assets |  | 7.70 | % |  | 8.00 | % |  | 8.00 | % |  | — | % |  | — | % |  | — | % |

[0000038725-15-000043:notes:202]
For the fiscal year ended January 3, 2015, the Company adopted the RP-2014 and MP-2014 mortality tables released by the Society of Actuaries during 2014.  These tables provide assumptions for longer life expectancies for plan participants.

[0000038725-15-000043:notes:203]
The accumulated benefit obligation for the Company’s tax qualified plan and German benefit pension plans was $192.8 million and $168.4 million for the years ended 2014 and 2013.

[0000038725-15-000043:notes:204]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for 2014, 2013, and 2012:

[0000038725-15-000043:notes:205]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Service cost | $ | 1.2 |  |  | $ | 1.8 |  |  | $ | 1.5 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |
| Interest cost | 8.2 |  |  | 7.6 |  |  | 8.2 |  |  | 0.5 |  |  | 0.5 |  |  | 0.6 |  |
| Expected return on assets | (10.6 | ) |  | (10.0 | ) |  | (10.1 | ) |  | — |  |  | — |  |  | — |  |
| Amortization of transition obligation | — |  |  | — |  |  | — |  |  | — |  |  | 0.4 |  |  | 0.2 |  |
| Settlement cost | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | 0.4 |  |  | 0.4 |  |  | 0.3 |  |
| Loss | 2.5 |  |  | 3.6 |  |  | 2.0 |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Net periodic benefit cost | $ | 1.3 |  |  | $ | 3.1 |  |  | $ | 1.6 |  |  | $ | 1.1 |  |  | $ | 1.4 |  |  | $ | 1.3 |  |
| Curtailment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | 1.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 2.3 |  |  | $ | 3.1 |  |  | $ | 1.6 |  |  | $ | 1.1 |  |  | $ | 1.4 |  |  | $ | 1.3 |  |

[0000038725-15-000043:notes:206]
The estimated net actuarial (gain)/loss, prior service cost/(credit), and transition (asset)/obligation that will be amortized from accumulated other comprehensive income into net periodic benefit cost during the 2015 fiscal year are $3.4 million, $0.0 million, and $0.0 million, respectively, for the pension plans and $0.2 million, $0.4 million, and $0.0 million respectively, for all other benefits.

[0000038725-15-000043:notes:207]
The Company consults with a third party investment manager for the assets of the funded domestic defined benefit plan.  The plan assets are currently invested primarily in pooled funds, where each fund in turn is composed of mutual funds that have at least daily net asset valuations.  Thus, the Company’s funded domestic defined benefit plan assets are invested in a “fund of funds” approach.

[0000038725-15-000043:notes:208]
The Company’s Board has delegated oversight and guidance to an appointed Employee Benefits Committee.  The Committee has the tasks of reviewing plan performance and asset allocation, ensuring plan compliance with applicable laws, establishing plan policies, procedures, and controls, monitoring expenses, and other related activities.

[0000038725-15-000043:notes:209]
The plans’ investment policies and strategies focus on the ability to fund benefit obligations as they come due.  Considerations include the plan's current funded level, plan design, benefit payment assumptions, funding regulations, impact of potentially volatile business results on the Company’s ability to make certain levels of contributions, and interest rate and asset return volatility among other considerations.  The Company currently attempts to maintain plan funded status at approximately 80 percent or greater pursuant to the Pension Protection Act of 2007.  Given the plan’s current funded status, the Company’s cash on hand, cash historically generated from business operations, and cash available under committed credit facilities, the Company sees ample liquidity to achieve this goal.

[0000038725-15-000043:notes:210]
Risk management and continuous monitoring requirements are met through monthly investment portfolio reports, quarterly Employee Benefits Committee meetings, annual valuations, asset/liability studies, and the annual assumption process focusing primarily on the return on asset assumption and the discount rate assumption.  As of January 3, 2015, funds were invested in equity, fixed income, and other investments as follows:

[0000038725-15-000043:notes:211]
| Equity |  | Percentage |
| U.S. Large Cap |  | 14 | % |
| World Equity ex-U.S. |  | 13 | % |
| U.S. Small / Mid Cap |  | 6 | % |
| Subtotal |  | 33 | % |
| Fixed Income |  |  |
| U.S. Treasury and Government Agency Securities |  | 18 | % |
| Long Duration Bond |  | 39 | % |
| High Yield Fixed Income |  | 4 | % |
| Emerging Markets Debt |  | 3 | % |
| Subtotal |  | 64 | % |
| Other |  |  |
| Insurance Contracts |  | 3 | % |
| Total |  | 100 | % |

[0000038725-15-000043:notes:212]
The Company does not see any particular concentration of risk within the plans, nor any plan assets that pose difficulties for fair value assessment.  The Company currently has no allocation to potentially illiquid or potentially difficult to value assets such as hedge funds, venture capital, private equity, and real estate.

[0000038725-15-000043:notes:213]
The Company works with actuaries and consultants in making its determination of the asset rate of return assumption and also the discount rate assumption.

[0000038725-15-000043:notes:214]
Asset class assumptions are set using a combination of empirical and forward-looking analysis for long-term rate of return on plan assets.  A variety of models are applied for filtering historical data and isolating the fundamental characteristics of asset classes.  These models provide empirical return estimates for each asset class, which are then reviewed and combined with a qualitative assessment of long-term relationships between asset classes before a return estimate is finalized.  This provides an additional means for correcting for the effect of unrealistic or unsustainable short-term valuations or trends, opting instead for return levels and behavior that are more likely to prevail over long periods.  With that, the Company has assumed an expected long-term rate of return on plan assets of 7.00 percent for the 2015 net periodic benefit cost, down from 7.70 percent in the prior year.  This decrease in the assumed long-term rate of return is due to a higher mix of fixed income securities in the plan asset portfolios beginning in 2014.

[0000038725-15-000043:notes:215]
The Company uses the Aon Hewitt AA Above Median curve to determine the discount rate.  All cash flow obligations under the plan are matched to bonds in the Aon Hewitt universe of liquid, high-quality, non-callable / non-putable corporate bonds with outliers removed.  From that matching exercise, a discount rate is determined.

[0000038725-15-000043:notes:216]
The Company’s German pension plans are funded by insurance contract policies whereby the insurance company guarantees a fixed minimum return.  Due to tax legislation, individual pension benefits can only be financed using direct insurance policies up to certain maximums.  These maximum amounts in respect of each member are paid into such an arrangement on a yearly basis.

[0000038725-15-000043:notes:217]
The Company designated all equity and most domestic fixed income plan assets as Level 1, as they are mutual funds with prices that are readily available.  The U.S. Treasury securities and German plan assets are designated as Level 2 inputs.  The fair value of the German plan assets are measured by the reserve that is supervised by the German Federal Financial Supervisory Authority.  The U.S. Treasury securities are administered by the United States government.

[0000038725-15-000043:notes:218]
The fair values of the Company’s pension plan assets for 2014 and 2013 by asset category are as follows:

[0000038725-15-000043:notes:219]
| (In millions) |  | 2014 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| U.S. Large Cap |  | $ | 23.0 |  |  | $ | 23.0 |  |  | $ | — |  |  | $ | — |  |
| U.S. Small / Mid Cap |  | 8.9 |  |  | 8.9 |  |  | — |  |  | — |  |
| World Equity ex-U.S. |  | 19.9 |  |  | 19.9 |  |  | — |  |  | — |  |
| Fixed Income |  |  |  |  |  |  |  |  |
| U.S. Treasury and Government Agency Securities |  | 27.9 |  |  | — |  |  | 27.9 |  |  | — |  |
| U.S. Core Fixed Income |  | — |  |  | — |  | — |  | — |  |  | — |  |
| Long Duration Bond |  | 62.7 |  |  | 62.7 |  |  | — |  |  | — |  |
| High Yield Fixed Income |  | 7.0 |  |  | 7.0 |  |  | — |  |  | — |  |
| Emerging Markets Debt |  | 5.4 |  |  | 5.4 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance Contracts |  | 5.2 |  |  | — |  |  | 5.2 |  |  | — |  |
| Total |  | $ | 160.0 |  |  | $ | 126.9 |  |  | $ | 33.1 |  |  | $ | — |  |

[0000038725-15-000043:notes:220]
| (In millions) |  | 2013 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| U.S. Large Cap |  | $ | 69.4 |  |  | $ | 69.4 |  |  | $ | — |  |  | $ | — |  |
| U.S. Small / Mid Cap |  | 12.8 |  |  | 12.8 |  |  | — |  |  | — |  |
| World Equity ex-U.S. |  | 25.6 |  |  | 25.6 |  |  | — |  |  | — |  |
| Fixed Income |  |  |  |  |  |  |  |  |
| U.S. Treasury and Government Agency Securities |  | — |  |  | — |  | — |  | — |  | — |  | — |  |
| U.S. Core Fixed Income |  | 17.9 |  |  | 17.9 |  |  | — |  |  | — |  |
| Long Duration Bond |  | 11.5 |  |  | 11.5 |  |  | — |  |  | — |  |
| High Yield Fixed Income |  | 4.4 |  |  | 4.4 |  |  | — |  |  | — |  |
| Emerging Markets Debt |  | 3.7 |  |  | 3.7 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance Contracts |  | 5.8 |  |  | — |  |  | 5.8 |  |  | — |  |
| Total |  | $ | 151.1 |  |  | $ | 145.3 |  |  | $ | 5.8 |  |  | $ | — |  |

[0000038725-15-000043:notes:221]
One of the Company’s domestic pension plans covers only two management employees.  The Company does not fund this plan, and its assets were zero in both 2014 and 2013.  The plan’s projected benefit obligation and accumulated benefit obligation were $12.4 million and $10.5 million, respectively, for 2014, and $12.4 million and $12.3 million, respectively, for 2013.

[0000038725-15-000043:notes:222]
The Company estimates total contributions to the plans of $10.3 million in 2015.

[0000038725-15-000043:notes:223]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid in accordance with the following schedule:

[0000038725-15-000043:notes:224]
| (In millions) |  | Pension Benefits |  | Other Benefits |
| 2015 |  | $ | 14.6 |  |  | $ | 1.3 |  |
| 2016 |  | 14.2 |  |  | 1.2 |  |
| 2017 |  | 11.2 |  |  | 1.1 |  |
| 2018 |  | 11.4 |  |  | 1.0 |  |
| 2019 |  | 11.1 |  |  | 1.0 |  |
| Years 2020 through 2024 |  | 60.2 |  |  | 4.2 |  |

[0000038725-15-000043:notes:225]
Defined Contribution Plans - The Company maintained a 401(k) Plan during 2014 and 2013.  The Company's cash contributions are allocated to participant's accounts based on investment elections.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000038725-15-000043:notes:226]
Property, plant, and equipment are stated at cost.  Depreciation of plant and equipment is calculated on a straight line basis over the estimated useful lives of 5 to 20 years for land improvements and buildings, 5 to 10 years for machinery and equipment, and 5 years for furniture and fixtures.  Maintenance, repairs, and renewals of a minor nature are expensed as incurred.  Betterments and major renewals which extend the useful lives or add to the productive capacity of buildings, improvements, and equipment are capitalized.  The Company reviews its property, plant, and equipment for impairment at the asset group level whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000038725-15-000043:notes:227]
SELECTED QUARTERLY FINANCIAL DATA (UNAUDITED)

[0000038725-15-000043:notes:228]
Unaudited quarterly financial information for 2014 and 2013, from continuing operations, is as follows:

[0000038725-15-000043:notes:229]
| (In millions, except per share amounts) |  |  |  |  |  |  |  |  |  |  |
|  | Net Sales |  | Gross Profit |  | Net Income |  | Net Income Attributable to Franklin Electric Co., Inc. |  | Basic Earnings Per Share |  | Diluted Earnings Per Share |
| 2014 |  |  |  |  |  |  |  |  |  |  |  |
| 1st quarter | $ | 231.4 |  |  | $ | 78.1 |  |  | $ | 17.4 |  |  | $ | 17.0 |  |  | $ | 0.35 |  |  | $ | 0.35 |  |
| 2nd quarter | 284.5 |  |  | 99.4 |  |  | 27.5 |  |  | 27.1 |  |  | 0.56 |  |  | 0.55 |  |
| 3rd quarter | 278.1 |  |  | 89.2 |  |  | 22.8 |  |  | 22.7 |  |  | 0.46 |  |  | 0.46 |  |
| 4th quarter | 253.8 |  |  | 77.7 |  |  | 3.2 |  |  | 3.0 |  |  | 0.06 |  |  | 0.06 |  |
|  | $ | 1,047.8 |  |  | $ | 344.4 |  |  | $ | 70.9 |  |  | $ | 69.8 |  |  | $ | 1.43 |  |  | $ | 1.41 |  |
| 2013 |  |  |  |  |  |  |  |  |  |  |  |  |
| 1st quarter | $ | 222.5 |  |  | $ | 73.9 |  |  | $ | 15.6 |  |  | $ | 15.5 |  |  | $ | 0.32 |  |  | $ | 0.32 |  |
| 2nd quarter | 263.4 |  |  | 94.6 |  |  | 28.4 |  |  | 28.1 |  |  | 0.59 |  |  | 0.58 |  |
| 3rd quarter | 249.8 |  |  | 87.0 |  |  | 25.3 |  |  | 25.1 |  |  | 0.52 |  |  | 0.51 |  |
| 4th quarter | 229.8 |  |  | 76.0 |  |  | 13.4 |  |  | 13.3 |  |  | 0.27 |  |  | 0.27 |  |
|  | $ | 965.5 |  |  | $ | 331.5 |  |  | $ | 82.7 |  |  | $ | 82.0 |  |  | $ | 1.70 |  |  | $ | 1.68 |  |

[0000038725-15-000043:notes:230]
Basic and diluted earnings per share amounts are computed independently for each of the quarters presented.  As a result, the sum of the quarterly earnings per share amounts may not equal the annual earnings per share amount.


## us-gaap:ReceivablesPolicyTextBlock

[0000038725-15-000043:notes:231]
Accounts receivable are stated at estimated net realizable value.  Accounts receivable are comprised of balances due from customers, net of earned discounts and estimated allowances for uncollectible accounts.  Earned discounts are based on specific customer agreement terms.  In determining allowances for uncollectible accounts, historical collection experience, current trends, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are reviewed.  The Company believes that the allowance is appropriate; however, actual experience could differ from the original estimates, requiring adjustments to the reserve.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-15-000043:notes:232]
RESTRUCTURING

[0000038725-15-000043:notes:233]
On July 1, 2014, the Company announced a plan to close its Wittlich, Germany manufacturing facility.  As part of this action, the Company will transfer the existing Wittlich manufacturing activity to its Brno, Czech Republic facility.  The Company will maintain its European Water Systems headquarters and distribution center in Wittlich, only the manufacturing operations will be relocating.  The realignment began in the third quarter of 2014 and is estimated to conclude by the end of 2016.  Charges for the realignment are expected to be approximately $19.4 million and will include severance expenses, professional service fees, asset write-offs, and temporarily leased facilities costs.

[0000038725-15-000043:notes:234]
Costs incurred in the twelve months ended January 3, 2015, included in the “Restructuring expense” line of the Company's consolidated statement of income, are as follows:

[0000038725-15-000043:notes:235]
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 14.3 |  |  | $ | 0.4 |  |  | $ | — |  |  | $ | 14.7 |  |
| Equipment relocation |  | 0.7 |  |  | — |  |  | — |  |  | 0.7 |  |
| Asset write-off |  | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |
| Other |  | 0.9 |  |  | 0.1 |  |  | — |  |  | 1.0 |  |
| Total |  | $ | 16.1 |  |  | $ | 0.5 |  |  | $ | — |  |  | $ | 16.6 |  |

[0000038725-15-000043:notes:236]
Restructuring expenses of $3.7 million and $0.2 million were incurred in 2013 and 2012, respectively, primarily for the Water Systems realignment.

[0000038725-15-000043:notes:237]
As of January 3, 2015 there was $13.1 million in restructuring reserves, primarily for severance.  As of December 28, 2013, there were no restructuring reserves.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000038725-15-000043:notes:238]
Products are shipped utilizing common carriers direct to customers or, for consignment products, to customer specified warehouse locations.  Sales are recognized when the Company’s products are shipped direct or, in the case of consignment products, transferred from the customer specified warehouse location to the customer, at which time transfer of ownership and risk of loss pass to the customer.  The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience.


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000038725-15-000043:notes:239]
Financial information by geographic region is as follows:

[0000038725-15-000043:notes:240]
|  | Net sales |  | Long-lived assets |
| (In millions) | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |
| United States | $ | 485.5 |  |  | $ | 460.5 |  |  | $ | 428.5 |  |  | $ | 418.0 |  |  | $ | 377.3 |  |
| Foreign | 562.3 |  |  | 505.0 |  |  | 462.8 |  |  | 184.4 |  |  | 199.2 |  |
| Consolidated | $ | 1,047.8 |  |  | $ | 965.5 |  |  | $ | 891.3 |  |  | $ | 602.4 |  |  | $ | 576.5 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-15-000043:notes:241]
Financial information by reportable segment is as follows:

[0000038725-15-000043:notes:242]
|  | Net sales to external customers |  | Operating income (loss) |
| (In millions) | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Water Systems | $ | 824.6 |  |  | $ | 766.4 |  |  | $ | 715.0 |  |  | $ | 103.9 |  |  | $ | 131.3 |  |  | $ | 124.1 |  |
| Fueling Systems | 223.2 |  |  | 199.1 |  |  | 176.3 |  |  | 49.7 |  |  | 42.6 |  |  | 36.6 |  |
| Other | — |  |  | — |  |  | — |  |  | (53.5 | ) |  | (50.1 | ) |  | (47.7 | ) |
| Consolidated | $ | 1,047.8 |  |  | $ | 965.5 |  |  | $ | 891.3 |  |  | $ | 100.1 |  |  | $ | 123.8 |  |  | $ | 113.0 |  |
|  | Total assets |  |  |  | Depreciation |
|  | 2014 |  | 2013 |  |  |  | 2014 |  | 2013 |  | 2012 |
| Water Systems | $ | 757.5 |  |  | $ | 714.7 |  |  |  |  |  | $ | 19.9 |  |  | $ | 18.1 |  |  | $ | 16.9 |  |
| Fueling Systems | 252.7 |  |  | 247.9 |  |  |  |  |  | 2.4 |  |  | 1.9 |  |  | 1.8 |  |
| Other | 65.7 |  |  | 89.3 |  |  |  |  |  | 5.8 |  |  | 3.4 |  |  | 2.4 |  |
| Consolidated | $ | 1,075.9 |  |  | $ | 1,051.9 |  |  |  |  |  | $ | 28.1 |  |  | $ | 23.4 |  |  | $ | 21.1 |  |
|  | Amortization |  | Capital expenditures |
|  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Water Systems | $ | 7.1 |  |  | $ | 6.0 |  |  | $ | 5.7 |  |  | $ | 33.8 |  |  | $ | 31.0 |  |  | $ | 25.2 |  |
| Fueling Systems | 1.8 |  |  | 1.9 |  |  | 1.5 |  |  | 3.9 |  |  | 4.0 |  |  | 3.3 |  |
| Other | 0.2 |  |  | 0.1 |  |  | — |  |  | 4.7 |  |  | 32.2 |  |  | 13.6 |  |
| Consolidated | $ | 9.1 |  |  | $ | 8.0 |  |  | $ | 7.2 |  |  | $ | 42.4 |  |  | $ | 67.2 |  |  | $ | 42.1 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000038725-15-000043:notes:243]
FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES

[0000038725-15-000043:notes:244]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000038725-15-000043:notes:245]
| (In millions) |  | Balance at Beginning of Period |  | Additions Charged to Costs and Expenses |  | Deductions (a) |  | Other (b) |  | Balance at End of Period |
| 2014 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.0 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 3.2 |  |
| Allowance for deferred taxes |  | 3.5 |  |  | 1.3 |  |  | 0.9 |  |  | — |  |  | 3.9 |  |
| 2013 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.2 |  |  | $ | (0.1 | ) |  | $ | 0.1 |  |  | $ | — |  |  | $ | 3.0 |  |
| Allowance for deferred taxes |  | 4.4 |  |  | (0.9 | ) |  | — |  |  | — |  |  | 3.5 |  |
| 2012 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.0 |  |  | $ | 0.4 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 3.2 |  |
| Allowance for deferred taxes |  | 3.6 |  |  | 0.8 |  |  | — |  |  | — |  |  | 4.4 |  |

[0000038725-15-000043:notes:246]
(a) Charges for which allowances were created.

[0000038725-15-000043:notes:247]
(b) Primarily related to acquisitions.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-15-000043:notes:248]
SEGMENT AND GEOGRAPHIC INFORMATION

[0000038725-15-000043:notes:249]
The Company’s business consists of the Water Systems and Fueling Systems reportable segments, based on the principal end market served.  The Company includes unallocated corporate expenses and inter-company eliminations in an “Other” segment that together with the Water Systems and Fueling Systems segments, represent the Company.

[0000038725-15-000043:notes:250]
The Water Systems segment designs, manufactures and sells motors, pumps, electronic controls and related parts and equipment primarily for use in submersible water and other fluid system applications.  The Fueling Systems segment designs, manufactures and sells pumps, electronic controls and related parts and equipment primarily for use in submersible fueling system applications.  The Fueling Systems segment integrates and sells motors and electronic controls produced by the Water Systems segment.

[0000038725-15-000043:notes:251]
The accounting policies of the Company's reportable segments are the same as those described in Note 1 (Summary of Significant Accounting Policies).  Performance is evaluated based on the sales and operating income of the segments and a variety of ratios to measure performance.  These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented.

[0000038725-15-000043:notes:252]
Property, plant and equipment is the major asset group in "Other" of total assets at January 3, 2015.  Cash is the major asset group in "Other" of total assets at December 28, 2013.

[0000038725-15-000043:notes:253]
No single customer accounted for more than 10 percent of the Company’s consolidated sales in 2014, 2013, or 2012.  No single customer accounted for more than 10 percent of the Company's gross accounts receivable in 2014 or 2013.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000038725-15-000043:notes:254]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0000038725-15-000043:notes:255]
Company--“Franklin Electric” or the “Company” shall refer to Franklin Electric Co., Inc. and its consolidated subsidiaries.

[0000038725-15-000043:notes:256]
Fiscal Year--The Company's fiscal year ends on the Saturday nearest December 31.  The financial statements and accompanying notes are as of and for the years ended January 3, 2015 (53 weeks), December 28, 2013 (52 weeks), and December 29, 2012 (52 weeks), and referred to as 2014, 2013, and 2012, respectively.

[0000038725-15-000043:notes:257]
Principles of Consolidation--The consolidated financial statements include the accounts of Franklin Electric Co., Inc. and its consolidated subsidiaries.  All intercompany transactions have been eliminated.

[0000038725-15-000043:notes:258]
Business Combinations--The Company allocates the purchase price of its acquisitions to the assets acquired, liabilities assumed, and noncontrolling interests acquired based upon their respective fair values at the acquisition date.  The Company utilizes management estimates and inputs from an independent third-party valuation firm to assist in determining these fair values.  The excess of the acquisition price over these estimated fair values is recorded as goodwill.  Goodwill is adjusted for any changes to acquisition date fair value amounts made within the measurement period.  Acquisition-related transaction costs are recognized separately from the business combination and expensed as incurred.

[0000038725-15-000043:notes:259]
Revenue Recognition--Products are shipped utilizing common carriers direct to customers or, for consignment products, to customer specified warehouse locations.  Sales are recognized when the Company’s products are shipped direct or, in the case of consignment products, transferred from the customer specified warehouse location to the customer, at which time transfer of ownership and risk of loss pass to the customer.  The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience.

[0000038725-15-000043:notes:260]
Research and Development Expense--The Company’s research and development activities are charged to expense in the period incurred.  The Company incurred expenses of approximately $19.3 million in 2014, $16.8 million in 2013, and $9.9 million in 2012 related to research and development.

[0000038725-15-000043:notes:261]
Cash and Cash Equivalents--The Company considers cash on hand, demand deposits, and highly liquid investments with an original maturity date of three months or less to be cash and cash equivalents.

[0000038725-15-000043:notes:262]
Fair Value of Financial Instruments--The carrying amount of long-term debt was $177.2 million at January 3, 2015 and $188.8 million at December 28, 2013.  The estimated fair value of all debt was $191.1 million and $203.7 million at January 3, 2015 and December 28, 2013, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its long-term debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  These level 2 inputs were valued using the same historical technique.  The Company’s off-balance sheet instruments consist of operating leases and certain derivative instruments with cancellation terms of thirty days or less.

[0000038725-15-000043:notes:263]
Accounts Receivable, Earned Discounts, and Allowance for Uncollectible Accounts--Accounts receivable are stated at estimated net realizable value.  Accounts receivable are comprised of balances due from customers, net of earned discounts and estimated allowances for uncollectible accounts.  Earned discounts are based on specific customer agreement terms.  In determining allowances for uncollectible accounts, historical collection experience, current trends, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are reviewed.  The Company believes that the allowance is appropriate; however, actual experience could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-15-000043:notes:264]
Inventories--  Inventories are stated at the lower of cost or market.  The majority of the cost of domestic and foreign inventories is determined using the FIFO method with a portion of inventory costs determined using the average cost method.  The Company reviews its inventories for excess or obsolete products or components based on an analysis of historical usage and management's evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts.

[0000038725-15-000043:notes:265]
Property, Plant, and Equipment--Property, plant, and equipment are stated at cost.  Depreciation of plant and equipment is calculated on a straight line basis over the estimated useful lives of 5 to 20 years for land improvements and buildings, 5 to 10 years for machinery and equipment, and 5 years for furniture and fixtures.  Maintenance, repairs, and renewals of a minor nature are expensed as incurred.  Betterments and major renewals which extend the useful lives or add to the productive capacity of buildings, improvements, and equipment are capitalized.  The Company reviews its property, plant, and equipment for impairment at the asset group level whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable.  The Company’s depreciation expense was $28.1 million, $23.4 million, and $21.1 million in 2014, 2013, and 2012, respectively.

[0000038725-15-000043:notes:266]
Goodwill and Other Intangible Assets--The Company tests goodwill for impairment on an annual basis during the fourth quarter or more frequently as warranted by triggering events that indicate potential impairment.  Goodwill is tested at the reporting unit level, which the company has determined to be the North America Water Systems, International Water, and Fueling Systems units.  In compliance with FASB ASC Topic 350, Intangibles - Goodwill and Other, the Company has evaluated the aggregation criteria and determined that the components within the North America Water Systems and International Water reporting units can be aggregated in 2014.

[0000038725-15-000043:notes:267]
Warranty Obligations--Warranty terms are generally 2 years from date of manufacture or 1 year from date of installation.  The general warranty liability is recorded when revenue is recognized and is based on actual historical return rates from the most recent warranty periods.  In 2007, the Company began offering an extended warranty program to certain Water Systems segment customers, which provides warranty coverage up to 5 years from the date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims and expected customer returns.  The Company actively studies trends of warranty claims and takes action to improve product quality and minimize warranty claims.

[0000038725-15-000043:notes:268]
Income Taxes--Income taxes are accounted for in accordance with FASB ASC Topic 740, Income Taxes.  Under this guidance, deferred tax assets and liabilities are determined based on the difference between the financial statement and tax basis of assets and liabilities and net operating loss and credit carry forwards using enacted tax rates in effect for the year in which the differences are expected to reverse.  Valuation allowances are established when necessary to reduce deferred tax assets to the amounts expected to be realized.  The Company records a liability for uncertain tax positions by establishing a recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return.

[0000038725-15-000043:notes:269]
Share-Based Compensation-- Share-based awards are issued to key employees and non-employee directors and include discretionary grants of stock options, stock awards, and stock unit awards.  Compensation costs resulting from share-based payment transactions are recognized within selling, general, and administrative expenses at the grant date fair value over the requisite service period on a straight-line basis.

[0000038725-15-000043:notes:270]
Pension--The Company makes its determination for pension, post retirement, and post employment benefit plans liabilities based on management estimates and consultation with actuaries, incorporating estimates and assumptions of future plan service costs, future interest costs on projected benefit obligations, rates of compensation increases, employee turnover rates, anticipated mortality rates, expected investment returns on plan assets, asset allocation assumptions of plan assets, and other factors.

[0000038725-15-000043:notes:271]
Earnings Per Common Share--Basic and diluted earnings per share are computed and disclosed in accordance with FASB ASC Topic 260, Earnings Per Share.  The Company utilizes the two-class method to compute earnings available to common shareholders.  Under the two-class method, earnings are adjusted by accretion amounts to redeemable noncontrolling interests recorded at redemption value.  The adjustments represent dividend distributions, in substance, to the noncontrolling interest holder as the holders have contractual rights to receive an amount upon redemption other than the fair value of applicable shares.  As a result, earnings are adjusted to reflect this in substance distribution that is different from other common shareholders.  In addition, the Company allocates net earnings to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company's participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.  Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-15-000043:notes:272]
Translation of Foreign Currency Financial Statements--All assets and liabilities of foreign subsidiaries in functional currency other than the U.S. dollar are translated at year end exchange rates.  All revenue and expense accounts are translated at average rates in effect during the respective period.  Adjustments for translating longer term foreign currency assets and liabilities in U.S. dollars are included as a component of other comprehensive income.  Transaction gains and losses that arise from shorter term exchange rate fluctuations are included in the results of operations in “Foreign exchange expense", as incurred.

[0000038725-15-000043:notes:273]
Significant Estimates--The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make significant estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of expenses during the reporting periods.  Significant estimates and assumptions by management affect the allowance for uncollectible accounts, inventory valuation, warranty, business combinations, redeemable noncontrolling interest, mandatory share purchase, trade names and goodwill, income taxes, pension and employee benefit obligations, and share-based compensation.

[0000038725-15-000043:notes:274]
Although the Company regularly assesses these estimates, actual results could materially differ.  The Company bases its estimates on historical experience and various other assumptions that it believes to be reasonable under the circumstances.

[0000038725-15-000043:notes:275]
Reclassifications--Certain prior year amounts in the investing activities section on the consolidated statement of cash flows were reclassified into the "Other, net" line to conform with the current year presentation.  The reclassification within the investing activities section of the consolidated statement of cash flows had no impact on the operating cash flows or any other financial statement.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-15-000043:notes:276]
SHAREOWNERS' EQUITY

[0000038725-15-000043:notes:277]
The Company has the authority to issue 65,000,000, $.10 par value shares.

[0000038725-15-000043:notes:278]
In 2014, the Company retired 40,679 shares that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards.  The Company also retired 68,675 shares that had been previously granted as stock awards to employees, but were forfeited upon not meeting the required restriction criteria or termination.  In 2013, the Company retired 273,799 shares that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards.  The Company also retired 6,190 shares that had been previously granted as a stock award to employees, but were forfeited upon termination.  In 2012, the Company retired 419,208 shares that were received from employees as payment for the exercise price of their stock options and taxes owned upon the exercise of their stock options and release of their restricted awards.  The Company also retired 16,712 shares that had been previously granted as stock awards to employees, but were forfeited upon termination.

[0000038725-15-000043:notes:279]
In 2014, 2013, and 2012, the Company recorded $2.3 million, $5.1 million, and $4.7 million, respectively, as a reduction in tax liability and an increase to shareowners’ equity as a result of stock option exercises.

[0000038725-15-000043:notes:280]
Accumulated other comprehensive loss consisted of the currency translation adjustment and the pension liability adjustment, $(51.8) million and $(56.1) million, respectively, as of January 3, 2015, and $(16.0) million and $(38.7) million, respectively, at December 28, 2013.
