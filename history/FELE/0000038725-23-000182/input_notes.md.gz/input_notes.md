# FELE notes — 0000038725-23-000182


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-23-000182:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2022, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2023, and for the third quarters and nine months ended September 30, 2023 and September 30, 2022 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2023. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-23-000182:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-23-000182:notes:3]
In October 2021, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires entities to recognize and measure contracts on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. This will improve comparability after the business combination by providing consistent recognition and measurement guidance for revenue contracts with customers acquired in a business combination and revenue contracts with customers not acquired in a business combination. ASU 2021-08 is effective for interim and annual periods beginning after December 15, 2022 with early adoption permitted. ASU 2021-08 should be applied on a prospective basis to business combinations that occur after the effective date. The Company adopted this ASU on January 1, 2023, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-23-000182:notes:4]
In September 2022, the FASB issued ASU 2022-04, Liabilities - Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations. ASU 2022-04 creates the obligation for a company that uses a supplier finance program to purchase goods or services to disclose qualitative and quantitative information about its supplier finance program(s). This will allow financial statement users to better consider the effect of the program(s) on the entity's working capital, liquidity and cash flow over time. ASU 2022-04 is effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years, except for the amendment on rollforward information, which is effective for fiscal years beginning after December 15, 2023 with early adoption permitted. ASU 2022-04 should be applied retrospectively to each period in which a balance sheet is presented except for the amendment on rollforward information, which should be applied prospectively. The Company adopted this ASU on January 1, 2023, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows, as the Company has no amounts outstanding under its current supplier finance program.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-23-000182:notes:5]
[same as prior period, unchanged from 0000038725-23-000151:notes:5]

[0000038725-23-000182:notes:6]
During the first quarter ended March 31, 2023, the Company acquired all of the assets of Phil-Good Products, Inc. ("Phil-Good"). Phil-Good is an injection molded plastics component manufacturer. In another separate transaction in the first quarter of 2023, the Company acquired 100 percent of the ownership interests of Hydropompe S.r.l. ("Hydropompe"). Hydropompe is a pump manufacturer with a focus in dewatering and sewage products. The combined, all-cash purchase price for both acquisitions in the first quarter of 2023 was $8.7 million after purchase price adjustments based on the level of working capital acquired. The fair value of the assets acquired and liabilities assumed for both acquisitions is preliminary as of September 30, 2023. In addition, the Company has not presented separate results of operations of the acquired companies since the closing of the acquisitions or combined pro forma financial information of the Company and the acquired interests since the beginning of 2022, as the results of operations for both acquisitions are immaterial.

[0000038725-23-000182:notes:7]
[same as prior period, unchanged from 0000038725-23-000151:notes:7]


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-23-000182:notes:8]
FAIR VALUE MEASUREMENTS
FASB ASC Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value. The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-23-000182:notes:9]
[same as prior period, unchanged from 0000038725-23-000151:notes:9]

[0000038725-23-000182:notes:10]
[same as prior period, unchanged from 0000038725-23-000151:notes:10]

[0000038725-23-000182:notes:11]
[same as prior period, unchanged from 0000038725-23-000151:notes:11]

[0000038725-23-000182:notes:12]
As of September 30, 2023 and December 31, 2022, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-23-000182:notes:13]
| (In millions) | September 30, 2023 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 13.2 |  | $ | 13.2 |  | $ | — |  | $ | — |  |
| Forward currency contracts | 0.3 |  | — |  | 0.3 |  | — |  |
| Total assets | $ | 13.5 |  | $ | 13.2 |  | $ | 0.3 |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Share swap transaction | $ | 1.0 |  | $ | 1.0 |  | $ | — |  | $ | — |  |
| Total liabilities | $ | 1.0 |  | $ | 1.0 |  | $ | — |  | $ | — |  |
|  | December 31, 2022 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 7.9 |  | $ | 7.9 |  | $ | — |  | $ | — |  |
| Total assets | $ | 7.9 |  | $ | 7.9 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Share swap transaction | $ | 0.1 |  | $ | 0.1 |  | $ | — |  | $ | — |  |
| Total liabilities | $ | 0.1 |  | $ | 0.1 |  | $ | — |  | $ | — |  |

[0000038725-23-000182:notes:14]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The share swap transaction and forward currency contracts assets and liabilities are recorded within the "Receivables" and "Accounts Payable" lines of the condensed consolidated balance sheets and are further described in Note 5 - Financial Instruments. 
Total debt, including current maturities, have carrying amounts of $128.4 million and $216.1 million and estimated fair values of $125.1 million and $213.2 million as of September 30, 2023 and December 31, 2022, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-23-000182:notes:15]
FINANCIAL INSTRUMENTSThe Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered 
into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of September 30, 2023 and December 31, 2022, respectively, the swap had a notional value based on 240,000 shares and 225,000 shares. For the third quarter and nine months ended September 30, 2023, changes in the fair value of the swap resulted in a loss of $3.6 million and a gain of $1.1 million, respectively. For the third quarter and nine months ended September 30, 2022, changes in the fair value of the swap resulted in a gain of $1.8 million and a loss of $2.8 million, respectively. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.

[0000038725-23-000182:notes:16]
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of September 30, 2023 and December 31, 2022, respectively, the Company had a notional amount of $29.0 million and $10.3 million in forward currency contracts outstanding and the related fair value of those contracts was not material.  For the third quarter and nine months ended September 30, 2023, changes in the fair value of the forward currency contracts resulted in gains of $0.0 million and $1.6 million, respectively. For the third quarter and nine months ended September 30, 2022, changes in the fair value of the forward currency contracts resulted in gains of $0.4 million and $0.7 million, respectively. These gains are recorded in the Company's condensed consolidated statements of income within the "Foreign exchange expense" line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-23-000182:notes:17]
[same as prior period, unchanged from 0000038725-23-000151:notes:17]

[0000038725-23-000182:notes:18]
| (In millions) |  | September 30, 2023 |  | December 31, 2022 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Definite-lived intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 250.6 |  |  | $ | (111.4) |  |  | $ | 251.6 |  |  | $ | (101.5) |  |
| Patents |  | 7.3 |  |  | (7.3) |  |  | 7.3 |  |  | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.5) |  |  | 7.5 |  |  | (7.4) |  |
| Trade names |  | 41.6 |  |  | (5.3) |  |  | 41.8 |  |  | (3.7) |  |
| Other |  | 3.3 |  |  | (2.8) |  |  | 3.4 |  |  | (2.7) |  |
| Total |  | $ | 310.3 |  |  | $ | (134.3) |  |  | $ | 311.6 |  |  | $ | (122.6) |  |
| Indefinite-lived intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.6 |  |  | — |  |  | 42.3 |  |  | — |  |
| Total intangibles |  | $ | 352.9 |  |  | $ | (134.3) |  |  | $ | 353.9 |  |  | $ | (122.6) |  |

[0000038725-23-000182:notes:19]
Amortization expense related to intangible assets for the third quarters ended September 30, 2023 and September 30, 2022 was $4.2 million and $4.2 million, respectively, and for the nine months ended September 30, 2023 and September 30, 2022 was $12.7 million and $12.9 million, respectively.
The change in the carrying amount of goodwill by reportable segment for the nine months ended September 30, 2023 is as follows:

[0000038725-23-000182:notes:20]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2022 |  | $ | 211.9 |  |  | $ | 70.3 |  |  | $ | 45.8 |  |  | $ | 328.0 |  |
| Acquisitions |  | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| Foreign currency translation |  | (0.2) |  |  | — |  |  | — |  |  | (0.2) |  |
| Balance as of September 30, 2023 |  | $ | 212.7 |  |  | $ | 70.3 |  |  | $ | 45.8 |  |  | $ | 328.8 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-23-000182:notes:21]
EMPLOYEE BENEFIT PLANS
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the third quarters and nine months ended September 30, 2023 and September 30, 2022:

[0000038725-23-000182:notes:22]
| (In millions) | Pension Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | September 30, 2022 |  | September 30, 2023 |  | September 30, 2022 |
| Service cost | $ | 0.2 |  |  | $ | 0.1 |  |  | $ | 0.5 |  |  | $ | 0.5 |  |
| Interest cost | 1.7 |  |  | 0.9 |  |  | 5.0 |  |  | 2.5 |  |
| Expected return on assets | (1.8) |  |  | (1.7) |  |  | (5.4) |  |  | (4.7) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | 0.5 |  |  | 1.5 |  |  | 1.6 |  |  | 3.9 |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.6 |  |  | $ | 0.8 |  |  | $ | 1.7 |  |  | $ | 2.2 |  |

[0000038725-23-000182:notes:23]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the third quarters and nine months ended September 30, 2023 and September 30, 2022:

[0000038725-23-000182:notes:24]
| (In millions) | Other Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | September 30, 2022 |  | September 30, 2023 |  | September 30, 2022 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.1 |  |  | — |  |  | 0.2 |  |  | 0.1 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.2 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-23-000182:notes:25]
[same as prior period, unchanged from 0000038725-23-000151:notes:26]

[0000038725-23-000182:notes:26]
| (In millions) |  | September 30, 2023 |  | December 31, 2022 |
| Salaries, wages, and commissions |  | $ | 46.2 |  |  | $ | 57.9 |  |
| Product warranty costs |  | 10.3 |  |  | 11.2 |  |
| Insurance |  | 1.9 |  |  | 1.7 |  |
| Employee benefits |  | 11.7 |  |  | 13.5 |  |
| Other |  | 29.1 |  |  | 36.3 |  |
| Total |  | $ | 99.2 |  |  | $ | 120.6 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-23-000182:notes:27]
INCOME TAXES
The Company’s effective tax rate for both the nine-month period ended September 30, 2023 and September 30, 2022 was 20.1 percent. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to the recognition of the U.S. foreign-derived intangible income (FDII) provisions, partially offset by state taxes, and certain discrete events including excess tax benefits from share-based compensation. For the third quarter of 2023, the effective tax rate was 20.2 percent compared to 18.5 percent for the third quarter of 2022.

[0000038725-23-000182:notes:28]
The increase in the effective tax rates for the third quarter of 2023 compared to the comparable period in the prior year was a result of less favorable discrete events in 2023. During the third quarter of 2022, the Company recorded $1.1 million of benefit from the reconciliation of the domestic federal return to the provision predominantly related to additional FDII benefit.


## us-gaap:DebtDisclosureTextBlock

[0000038725-23-000182:notes:29]
DEBT
Debt consisted of the following:

[0000038725-23-000182:notes:30]
| (In millions) |  | September 30, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 39.0 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.1 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 0.4 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 128.4 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (40.4) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.0 |  |  | $ | 89.3 |  |

[0000038725-23-000182:notes:31]
Credit Agreement

[0000038725-23-000182:notes:32]
As of September 30, 2023, the Company had $39.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $307.4 million of available capacity under its credit agreement. As of December 31, 2022, the Company had $122.8 million outstanding borrowings with a weighted-average interest rate of 5.0 percent, $4.0 million in letters of credit outstanding, and $223.2 million of available capacity under its credit agreement.

[0000038725-23-000182:notes:33]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $18.1 million. As of September 30, 2023, there were no outstanding borrowings and $18.1 million of available capacity under these lines of credit. As of December 31, 2022, there were $22.0 million overdraft lines of credit with $2.7 million of outstanding borrowings and $19.3 million of available capacity under these lines of credit.


## us-gaap:EarningsPerShareTextBlock

[0000038725-23-000182:notes:34]
[same as prior period, unchanged from 0000038725-23-000151:notes:35]

[0000038725-23-000182:notes:35]
[same as prior period, unchanged from 0000038725-23-000151:notes:36]

[0000038725-23-000182:notes:36]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions, except per share amounts) | September 30, 2023 |  | September 30, 2022 |  | September 30, 2023 |  | September 30, 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 57.8 |  |  | $ | 58.6 |  |  | $ | 154.7 |  |  | $ | 147.8 |  |
| Less: Earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.5 |  |  | 0.6 |  |
| Net income available to common shareholders | $ | 57.6 |  |  | $ | 58.4 |  |  | $ | 154.2 |  |  | $ | 147.2 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.2 |  |  | 46.3 |  |  | 46.2 |  |  | 46.4 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors | 0.7 |  |  | 0.7 |  |  | 0.7 |  |  | 0.7 |  |
| Diluted weighted average common shares outstanding | 46.9 |  |  | 47.0 |  |  | 46.9 |  |  | 47.1 |  |
| Basic earnings per share | $ | 1.25 |  |  | $ | 1.26 |  |  | $ | 3.34 |  |  | $ | 3.17 |  |
| Diluted earnings per share | $ | 1.23 |  |  | $ | 1.24 |  |  | $ | 3.29 |  |  | $ | 3.13 |  |

[0000038725-23-000182:notes:37]
There were 0.1 million and 0.0 million stock options outstanding for the third quarters ended September 30, 2023 and September 30, 2022, and 0.1 million stock options outstanding for the nine months ended September 30, 2023 and September 30, 2022, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-23-000182:notes:38]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the third quarters and nine months ended September 30, 2023 and September 30, 2022:

[0000038725-23-000182:notes:39]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of June 30, 2023 | $ | 4,626 |  |  | $ | 340,812 |  |  | $ | 1,020,883 |  |  |  |  |  |  | $ | (219,662) |  |  | $ | 2,842 |  |  | $ | 1,149,501 |  |  | $ | 901 |  |
| Net income | — |  |  | — |  |  | 57,798 |  |  |  |  |  |  | — |  |  | 234 |  |  | 58,032 |  |  | 136 |  |
| Dividends on common stock ($0.225/share) | — |  |  | — |  |  | (10,443) |  |  |  |  |  |  | — |  |  | — |  |  | (10,443) |  |  | — |  |
| Common stock repurchased | (6) |  |  | — |  |  | (5,231) |  |  |  |  |  |  | — |  |  | — |  |  | (5,237) |  |  | — |  |
| Share-based compensation | 1 |  |  | 2,038 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 2,039 |  |  | — |  |
| Dividend to noncontrolling interest | — |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | (821) |  |  | (821) |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (10,775) |  |  | (74) |  |  | (10,849) |  |  | (2) |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 385 |  |  | — |  |  | 385 |  |  | — |  |
| Balance as of September 30, 2023 | $ | 4,621 |  |  | $ | 342,850 |  |  | $ | 1,063,007 |  |  |  |  |  |  | $ | (230,052) |  |  | $ | 2,181 |  |  | $ | 1,182,607 |  |  | $ | 1,035 |  |
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of June 30, 2022 | $ | 4,628 |  |  | $ | 318,837 |  |  | $ | 900,135 |  |  |  |  |  |  | $ | (237,513) |  |  | $ | 2,486 |  |  | $ | 988,573 |  |  | $ | 284 |  |
| Net income | — |  |  | — |  |  | 58,624 |  |  |  |  |  |  | — |  |  | 180 |  |  | 58,804 |  |  | 168 |  |
| Dividends on common stock ($0.195/share) | — |  |  | — |  |  | (9,088) |  |  |  |  |  |  | — |  |  | — |  |  | (9,088) |  |  | — |  |
| Common stock issued | 4 |  |  | 1,664 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 1,668 |  |  | — |  |
| Common stock repurchased | — |  |  | — |  |  | (87) |  |  |  |  |  |  | — |  |  | — |  |  | (87) |  |  | — |  |
| Share-based compensation | — |  |  | 2,618 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 2,618 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (15,924) |  |  | (125) |  |  | (16,049) |  |  | 3 |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 1,277 |  |  | — |  |  | 1,277 |  |  | — |  |
| Balance as of September 30, 2022 | $ | 4,632 |  |  | $ | 323,119 |  |  | $ | 949,584 |  |  |  |  |  |  | $ | (252,160) |  |  | $ | 2,541 |  |  | $ | 1,027,716 |  |  | $ | 455 |  |

[0000038725-23-000182:notes:40]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2022 | $ | 4,619 |  |  | $ | 325,426 |  |  | $ | 969,261 |  |  |  |  |  |  | $ | (231,448) |  |  | $ | 2,276 |  |  | $ | 1,070,134 |  |  | $ | 620 |  |
| Net Income | — |  |  | — |  |  | 154,723 |  |  |  |  |  |  | — |  |  | 764 |  |  | 155,487 |  |  | 417 |  |
| Dividends on common stock ($0.675/share) | — |  |  | — |  |  | (31,315) |  |  |  |  |  |  | — |  |  | — |  |  | (31,315) |  |  | — |  |
| Common stock issued | 22 |  |  | 8,988 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 9,010 |  |  | — |  |
| Common stock repurchased | (33) |  |  | — |  |  | (29,662) |  |  |  |  |  |  | — |  |  | — |  |  | (29,695) |  |  | — |  |
| Share-based compensation | 13 |  |  | 8,436 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 8,449 |  |  | — |  |
| Dividend to noncontrolling interest | — |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | (821) |  |  | (821) |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 178 |  |  | (38) |  |  | 140 |  |  | (2) |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 1,218 |  |  | — |  |  | 1,218 |  |  | — |  |
| Balance as of September 30, 2023 | $ | 4,621 |  |  | $ | 342,850 |  |  | $ | 1,063,007 |  |  |  |  |  |  | $ | (230,052) |  |  | $ | 2,181 |  |  | $ | 1,182,607 |  |  | $ | 1,035 |  |
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2021 | $ | 4,648 |  |  | $ | 310,617 |  |  | $ | 859,817 |  |  |  |  |  |  | $ | (228,581) |  |  | $ | 2,161 |  |  | $ | 948,662 |  |  | $ | (19) |  |
| Net Income | — |  |  | — |  |  | 147,753 |  |  |  |  |  |  | — |  |  | 644 |  |  | 148,397 |  |  | 457 |  |
| Dividends on common stock ($0.585/share) | — |  |  | — |  |  | (27,293) |  |  |  |  |  |  | — |  |  | — |  |  | (27,293) |  |  | — |  |
| Common stock issued | 8 |  |  | 3,576 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 3,584 |  |  | — |  |
| Common stock repurchased | (38) |  |  | — |  |  | (30,693) |  |  |  |  |  |  | — |  |  | — |  |  | (30,731) |  |  | — |  |
| Share-based compensation | 14 |  |  | 8,926 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 8,940 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (26,712) |  |  | (264) |  |  | (26,976) |  |  | 17 |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 3,133 |  |  | — |  |  | 3,133 |  |  | — |  |
| Balance as of September 30, 2022 | $ | 4,632 |  |  | $ | 323,119 |  |  | $ | 949,584 |  |  |  |  |  |  | $ | (252,160) |  |  | $ | 2,541 |  |  | $ | 1,027,716 |  |  | $ | 455 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-23-000182:notes:41]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the nine months ended September 30, 2023 and September 30, 2022, are summarized below:

[0000038725-23-000182:notes:42]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| For the nine months ended September 30, 2023: |  |  |
| Balance as of December 31, 2022 | $ | (191.3) |  |  | $ | (40.1) |  |  | $ | (231.4) |  |
| Other comprehensive income/(loss) before reclassifications | 0.2 |  |  | — |  |  | 0.2 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.2 |  |  | 1.2 |  |
| Net other comprehensive income/(loss) | 0.2 |  |  | 1.2 |  |  | 1.4 |  |
| Balance as of September 30, 2023 | $ | (191.1) |  |  | $ | (38.9) |  |  | $ | (230.0) |  |
| For the nine months ended September 30, 2022: |  |  |  |  |  |
| Balance as of December 31, 2021 | $ | (179.6) |  |  | $ | (49.0) |  |  | $ | (228.6) |  |
| Other comprehensive income/(loss) before reclassifications | (26.7) |  |  | — |  |  | (26.7) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 3.1 |  |  | 3.1 |  |
| Net other comprehensive income/(loss) | (26.7) |  |  | 3.1 |  |  | (23.6) |  |
| Balance as of September 30, 2022 | $ | (206.3) |  |  | $ | (45.9) |  |  | $ | (252.2) |  |

[0000038725-23-000182:notes:43]
[same as prior period, unchanged from 0000038725-23-000151:notes:44]

[0000038725-23-000182:notes:44]
(2) Net of tax expense of $0.4 million and $0.9 million for the nine months ended September 30, 2023 and September 30, 2022, respectively.

[0000038725-23-000182:notes:45]
[same as prior period, unchanged from 0000038725-23-000151:notes:46]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-23-000182:notes:46]
[same as prior period, unchanged from 0000038725-23-000151:notes:47]

[0000038725-23-000182:notes:47]
[same as prior period, unchanged from 0000038725-23-000151:notes:48]

[0000038725-23-000182:notes:48]
[same as prior period, unchanged from 0000038725-23-000151:notes:49]

[0000038725-23-000182:notes:49]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions) | September 30, 2023 |  | September 30, 2022 |  | September 30, 2023 |  | September 30, 2022 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 157.7 |  |  | $ | 158.9 |  |  | $ | 494.0 |  |  | $ | 452.0 |  |
| Latin America | 45.5 |  |  | 41.3 |  |  | 127.8 |  |  | 120.9 |  |
| Europe, Middle East & Africa | 48.7 |  |  | 46.0 |  |  | 153.7 |  |  | 146.7 |  |
| Asia Pacific | 19.6 |  |  | 22.1 |  |  | 60.6 |  |  | 66.8 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 24.3 |  |  | 24.8 |  |  | 88.0 |  |  | 89.8 |  |
| Total sales | 295.8 |  |  | 293.1 |  |  | 924.1 |  |  | 876.2 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 189.2 |  |  | 193.2 |  |  | 525.3 |  |  | 519.2 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 189.2 |  |  | 193.2 |  |  | 525.3 |  |  | 519.2 |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 58.5 |  |  | 66.5 |  |  | 172.8 |  |  | 182.5 |  |
| All other | 19.2 |  |  | 23.7 |  |  | 58.0 |  |  | 66.2 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 77.7 |  |  | 90.2 |  |  | 230.8 |  |  | 248.7 |  |
| Intersegment Eliminations/Other | (24.3) |  |  | (24.8) |  |  | (88.0) |  |  | (89.8) |  |
| Consolidated | $ | 538.4 |  |  | $ | 551.7 |  |  | $ | 1,592.2 |  |  | $ | 1,554.3 |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2023 |  | September 30, 2022 |  | September 30, 2023 |  | September 30, 2022 |
|  | Operating income/(loss) |
| Water Systems | $ | 52.7 |  |  | $ | 45.5 |  |  | $ | 152.5 |  |  | $ | 127.7 |  |
| Distribution | 10.7 |  |  | 19.0 |  |  | 33.2 |  |  | 51.7 |  |
| Fueling Systems | 25.8 |  |  | 28.6 |  |  | 73.3 |  |  | 72.4 |  |
| Intersegment Eliminations/Other | (11.1) |  |  | (13.1) |  |  | (47.4) |  |  | (50.8) |  |
| Consolidated | $ | 78.1 |  |  | $ | 80.0 |  |  | $ | 211.6 |  |  | $ | 201.0 |  |

[0000038725-23-000182:notes:50]
|  | September 30, 2023 |  | December 31, 2022 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 1,033.4 |  |  | $ | 1,017.5 |  |  |  |  |  |
| Distribution | 375.6 |  |  | 360.4 |  |  |  |  |  |
| Fueling Systems | 268.1 |  |  | 269.1 |  |  |  |  |  |
| Other | 48.2 |  |  | 47.2 |  |  |  |  |  |
| Consolidated | $ | 1,725.3 |  |  | $ | 1,694.2 |  |  |  |  |  |

[0000038725-23-000182:notes:51]
[same as prior period, unchanged from 0000038725-23-000151:notes:52]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-23-000182:notes:52]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position,  results of operations, or cash flows.

[0000038725-23-000182:notes:53]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-23-000182:notes:54]
At September 30, 2023, the Company had $9.6 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-23-000182:notes:55]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2023, are as follows:

[0000038725-23-000182:notes:56]
| (In millions) |  |  |
| Balance as of December 31, 2022 |  | $ | 11.2 |  |
| Accruals related to product warranties |  | 9.4 |  |
| Reductions for payments made |  | (10.3) |  |
| Balance as of September 30, 2023 |  | $ | 10.3 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000038725-23-000182:notes:57]
None of the Company’s directors or officers adopted, modified, or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement during the Company’s fiscal quarter ended September 30, 2023.
