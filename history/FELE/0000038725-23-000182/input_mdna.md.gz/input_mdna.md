# FELE MD&A — 0000038725-23-000182


## mdna

[0000038725-23-000182:mdna:1]
[same as prior period, unchanged from 0000038725-23-000151:mdna:1]

[0000038725-23-000182:mdna:2]
Third Quarter and Year-to-Date 2023 vs. 2022

[0000038725-23-000182:mdna:3]
[same as prior period, unchanged from 0000038725-23-000151:mdna:3]

[0000038725-23-000182:mdna:4]
Net sales in the third quarter and first nine months of 2023 decreased 2 percent and increased 2 percent, respectively, from the prior-year periods. The sales decrease in the third quarter was primarily due to lower volumes and the negative impact of foreign currency translation, partially offset by price realization. The sales increase in the first nine months was primarily due to price realization, partially offset by the negative impact of foreign currency translation. The Company's consolidated gross profit was $186.3 million and $537.0 million, respectively, for the third quarter and first nine months of 2023, a decrease of $4.3 million and an increase of $11.8 million, respectively, from the prior-year periods. Diluted earnings per share was $1.23 and $3.29, respectively, for the third quarter and first nine months of 2023, a decrease of $0.01 and an increase $0.16, respectively, from the prior-year periods.

[0000038725-23-000182:mdna:5]
[same as prior period, unchanged from 0000038725-23-000151:mdna:5]

[0000038725-23-000182:mdna:6]
[same as prior period, unchanged from 0000038725-23-000151:mdna:6]

[0000038725-23-000182:mdna:7]
|  | Net Sales |
| (In millions) | Q3 2023 |  | Q3 2022 |  | 2023 v 2022 |
| Water Systems | $ | 295.8 |  |  | $ | 293.1 |  |  | $ | 2.7 |  |
| Fueling Systems | 77.7 |  |  | 90.2 |  |  | (12.5) |  |
| Distribution | 189.2 |  |  | 193.2 |  |  | (4.0) |  |
| Eliminations/Other | (24.3) |  |  | (24.8) |  |  | 0.5 |  |
| Consolidated | $ | 538.4 |  |  | $ | 551.7 |  |  | $ | (13.3) |  |

[0000038725-23-000182:mdna:8]
|  | Net Sales |
| (In millions) | YTD September 30, 2023 |  | YTD September 30, 2022 |  | 2023 v 2022 |
| Water Systems | $ | 924.1 |  |  | $ | 876.2 |  |  | $ | 47.9 |  |
| Fueling Systems | 230.8 |  |  | 248.7 |  |  | (17.9) |  |
| Distribution | 525.3 |  |  | 519.2 |  |  | 6.1 |  |
| Eliminations/Other | (88.0) |  |  | (89.8) |  |  | 1.8 |  |
| Consolidated | $ | 1,592.2 |  |  | $ | 1,554.3 |  |  | $ | 37.9 |  |

[0000038725-23-000182:mdna:9]
Net sales decreased 2 percent in the third quarter and increased 2 percent in the first nine months of 2023, as compared to the prior-year periods. Foreign currency unfavorably impacted net sales by 2 and 3 percentage points during the third quarter and first nine months of 2023, respectively, compared to the prior-year periods, principally due to the strengthening of the U.S. Dollar relative to the Turkish Lira and Argentine Peso.

[0000038725-23-000182:mdna:10]
[same as prior period, unchanged from 0000038725-23-000151:mdna:10]

[0000038725-23-000182:mdna:11]
Water Systems sales increased 1 percent in the third quarter and 5 percent in the first nine months of 2023, as compared to the prior-year periods. This sales growth was primarily due to price realization. Partially offsetting the increase, sales decreased 4 percent in both the third quarter and first nine months of 2023 due to the negative impact from foreign exchange rates, as compared to prior-year periods.

[0000038725-23-000182:mdna:12]
Water Systems sales in the U.S. and Canada decreased 1 percent in the third quarter and increased 7 percent in the first nine months of 2023, as compared to the prior-year periods. Sales decreased less than 1 percent in the third quarter and decreased 1 percent in first nine months of 2023 due to the negative impact from foreign exchange rates, as compared to prior-year periods. In the third quarter of 2023, sales of large dewatering equipment increased 32 percent, sales of groundwater pumping equipment decreased 9 percent and sales of all other surface pumping equipment decreased 4 percent compared to 2022. In the first nine months of 2023, sales of large dewatering equipment increased 86 percent, sales of groundwater pumping equipment decreased 7 percent and sales of all other surface pumping equipment increased 1 percent compared to 2022.

[0000038725-23-000182:mdna:13]
Water Systems sales in markets outside the U.S. and Canada increased 4 percent in the third quarter and 2 percent in the first nine months of 2023, as compared to the prior-year periods. Sales decreased 11 percent in both the third quarter and first nine months of 2023 due to the negative impact from foreign exchange rates, as compared to prior-year periods.  In both the third quarter and first nine months of 2023, excluding the impact of foreign currency translation, sales increases in EMEA and Latin America more than offset sales declines in the Asia Pacific markets.

[0000038725-23-000182:mdna:14]
[same as prior period, unchanged from 0000038725-23-000151:mdna:14]

[0000038725-23-000182:mdna:15]
Fueling Systems sales decreased 14 percent in the third quarter and 7 percent in the first nine months of 2023, as compared to the prior-year periods. This sales decline was primarily due to lower volumes.

[0000038725-23-000182:mdna:16]
Fueling Systems sales in the U.S. and Canada decreased 14 percent in the third quarter and 6 percent in the first nine months of 2023, as compared to the prior-year periods. The decrease was primarily in dispensing and piping. Outside the U.S. and Canada, Fueling Systems sales decreased 20 percent in the third quarter and 13 percent in the first nine months of 2023, as compared to the prior-year periods, due primarily to the divestiture of the above ground storage tank business in 2022 and lower sales in China.

[0000038725-23-000182:mdna:17]
[same as prior period, unchanged from 0000038725-23-000151:mdna:17]

[0000038725-23-000182:mdna:18]
Distribution sales decreased 2 percent in the third quarter and increased 1 percent in the first nine months of 2023, as compared to the prior-year periods. The Distribution segment sales decline in the third quarter was primarily due to lower commodity driven pricing while the sales growth in the first nine months was primarily due to price realization and higher volumes.

[0000038725-23-000182:mdna:19]
[same as prior period, unchanged from 0000038725-23-000151:mdna:19]

[0000038725-23-000182:mdna:20]
|  | Three months ended September 30, |
| (In Millions) | 2023 |  | % of Net Sales |  | 2022 |  | % of Net Sales |
| Gross Profit | $ | 186.3 |  |  | 34.6 | % |  | $ | 190.6 |  |  | 34.5 | % |
| Selling, General and Administrative Expense | 107.7 |  |  | 20.0 | % |  | 109.4 |  |  | 19.8 | % |

[0000038725-23-000182:mdna:21]
|  | Nine Months Ended September 30, |
| (In Millions) | 2023 |  | % of Net Sales |  | 2022 |  | % of Net Sales |
| Gross Profit | $ | 537.0 |  |  | 33.7 | % |  | $ | 525.2 |  |  | 33.8 | % |
| Selling, General and Administrative Expense | 324.7 |  |  | 20.4 | % |  | 322.4 |  |  | 20.7 | % |

[0000038725-23-000182:mdna:22]
[same as prior period, unchanged from 0000038725-23-000151:mdna:22]

[0000038725-23-000182:mdna:23]
The gross profit margin ratio was 34.6 percent and 33.7 percent in the third quarter and first nine months of 2023, respectively, and 34.5 percent and 33.8 percent in the third quarter and first nine months of 2022, respectively. The gross profit margin was favorably impacted in the third quarter and first nine months of 2023 by price realization, product mix and lower freight costs in Water Systems and Fueling, partially offset by margin compression from unfavorable pricing of commodity-based products sold through the Distribution business.

[0000038725-23-000182:mdna:24]
[same as prior period, unchanged from 0000038725-23-000151:mdna:24]

[0000038725-23-000182:mdna:25]
SG&A expenses were $107.7 million in the third quarter and $324.7 million in the first nine months of 2023 compared to $109.4 million in the third quarter and $322.4 million in the first nine months of 2022. SG&A expenses decreased in the third quarter of 2023 primarily due to lower incentive-based compensation expenses. SG&A expenses increased by less than 1 percent in the first nine months of 2023 primarily due to higher compensation costs, partially offset by lower advertising and marketing expenses. The SG&A expenses ratio was 20.0 percent and 20.4 percent in the third quarter and first nine months of 2023, respectively, and 19.8 percent and 20.7 percent in the third quarter and first nine months of 2022, respectively.

[0000038725-23-000182:mdna:26]
[same as prior period, unchanged from 0000038725-23-000151:mdna:26]

[0000038725-23-000182:mdna:27]
Restructuring expenses were $0.5 million and $0.7 million in the third quarter and first nine months of 2023, respectively, and $1.2 million and $1.9 million in the third quarter and first nine months of 2022, respectively. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities, branch closings and consolidations.

[0000038725-23-000182:mdna:28]
[same as prior period, unchanged from 0000038725-23-000151:mdna:28]

[0000038725-23-000182:mdna:29]
Operating income decreased 2 percent and increased 5 percent in the third quarter and first nine months of 2023, as compared to the prior-year periods.

[0000038725-23-000182:mdna:30]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2023 |  | Q3 2022 |  | 2023 v 2022 |
| Water Systems |  | $ | 52.7 |  |  | $ | 45.5 |  |  | $ | 7.2 |  |
| Fueling Systems |  | 25.8 |  |  | 28.6 |  |  | (2.8) |  |
| Distribution |  | 10.7 |  |  | 19.0 |  |  | (8.3) |  |
| Eliminations/Other |  | (11.1) |  |  | (13.1) |  |  | 2.0 |  |
| Consolidated |  | $ | 78.1 |  |  | $ | 80.0 |  |  | $ | (1.9) |  |

[0000038725-23-000182:mdna:31]
|  |  | Operating income (loss) |
| (In millions) |  | YTD September 30, 2023 |  | YTD September 30, 2022 |  | 2023 v 2022 |
| Water Systems |  | $ | 152.5 |  |  | $ | 127.7 |  |  | $ | 24.8 |  |
| Fueling Systems |  | 73.3 |  |  | 72.4 |  |  | 0.9 |  |
| Distribution |  | 33.2 |  |  | 51.7 |  |  | (18.5) |  |
| Eliminations/Other |  | (47.4) |  |  | (50.8) |  |  | 3.4 |  |
| Consolidated |  | $ | 211.6 |  |  | $ | 201.0 |  |  | $ | 10.6 |  |

[0000038725-23-000182:mdna:32]
[same as prior period, unchanged from 0000038725-23-000151:mdna:32]

[0000038725-23-000182:mdna:33]
Water Systems operating income increased $7.2 million in the third quarter and $24.8 million in the first nine months of 2023, as compared to the prior-year periods, primarily due to price realization and cost management, including lower freight costs. The third quarter operating income margin was 17.8 percent, an increase of 230 basis points from 15.5 percent in the third quarter of 2022. The first nine months of 2023 operating income margin was 16.5 percent, an increase of 190 basis points from 14.6 percent in the first nine months of 2022. Operating income margin increased primarily due to price realization and cost management.

[0000038725-23-000182:mdna:34]
[same as prior period, unchanged from 0000038725-23-000151:mdna:34]

[0000038725-23-000182:mdna:35]
Fueling Systems operating income decreased $2.8 million in the third quarter and increased $0.9 million in the first nine months of 2023, as compared to the prior-year periods.  The decrease in operating income in the third quarter was primarily related to lower sales.  The increase in operating income in the first nine months of 2023 was primarily due to a favorable product and geographic mix of net sales and disciplined cost management. The third quarter operating income margin was 33.2 percent, an increase of 150 basis points from 31.7 percent in the third quarter of 2022. The first nine months of 2023 operating income margin was 31.8 percent, an increase of 270 basis points from 29.1 percent in the first nine months of 2022. Operating income margin increased primarily due to price realization, a favorable product and geographic sales mix shift and disciplined cost management.

[0000038725-23-000182:mdna:36]
[same as prior period, unchanged from 0000038725-23-000151:mdna:36]

[0000038725-23-000182:mdna:37]
Distribution operating income decreased $8.3 million in the third quarter and $18.5 million in the first nine months of 2023, as compared to the prior-year periods. The third quarter operating income margin was 5.7 percent, a decrease of 410 basis points from 9.8 percent in the third quarter of 2022. The first nine months of 2023 operating income margin was 6.3 percent, a decrease of 370 basis points from 10.0 percent in the first nine months of 2022. Operating income and operating income margin decreased primarily due to lower sales as a result of wet weather across much of the United States and customer inventory destocking along with unfavorable pricing of commodity-based products sold through the business.

[0000038725-23-000182:mdna:38]
[same as prior period, unchanged from 0000038725-23-000151:mdna:38]

[0000038725-23-000182:mdna:39]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the third quarter and first nine months of 2023 compared to the prior-year periods of 2022 was a favorable $0.6 million and $3.7 million, respectively. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses decreased $1.4 million and increased $0.3 million, respectively, compared to the prior-year periods.

[0000038725-23-000182:mdna:40]
[same as prior period, unchanged from 0000038725-23-000151:mdna:40]

[0000038725-23-000182:mdna:41]
Interest expense was $3.0 million and $10.3 million in the third quarter and first nine months of 2023, respectively, and $3.1 million and $7.5 million in the third quarter and first nine months of 2022, respectively. The increase in the first nine months of 2023 was primarily driven by higher interest rates.

[0000038725-23-000182:mdna:42]
[same as prior period, unchanged from 0000038725-23-000151:mdna:42]

[0000038725-23-000182:mdna:43]
Other income (expense), net was a benefit of $0.3 million and $1.9 million in the third quarter and first nine months of 2023, respectively, and an expense of $1.3 million and $2.8 million in the third quarter and first nine months of 2022, respectively.

[0000038725-23-000182:mdna:44]
[same as prior period, unchanged from 0000038725-23-000151:mdna:44]

[0000038725-23-000182:mdna:45]
Foreign currency-based transactions produced an expense of $2.5 million and $8.1 million in the third quarter and first nine months of 2023, respectively, and an expense of $3.4 million and $4.3 million in the third quarter and first nine months of 2022, respectively. The expense in 2023 was primarily due to transaction losses associated with the Turkish Lira, Argentine and Mexican Peso relative to the U.S. dollar. The expense in 2022 was primarily due to transaction losses associated with the Argentine Peso and Turkish Lira. The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-23-000182:mdna:46]
[same as prior period, unchanged from 0000038725-23-000151:mdna:46]

[0000038725-23-000182:mdna:47]
The provision for income taxes in the third quarter and first nine months of 2023 was $14.7 million and $39.2 million, respectively, and $13.4 million and $37.5 million in the third quarter and first nine months of 2022, respectively. The effective tax rate for the third quarter and first nine months of 2023 was 20.2 percent and 20.1 percent, respectively, and 18.5 percent and 20.1 percent in the third quarter and the first nine months of 2022, respectively. The increase in the effective tax rate for the third quarter of 2023 compared to the comparable period in the prior year was a result of less favorable discrete events in 2023.

[0000038725-23-000182:mdna:48]
[same as prior period, unchanged from 0000038725-23-000151:mdna:48]

[0000038725-23-000182:mdna:49]
Net income in the third quarter and first nine months of 2023 was $58.2 million and $155.9 million, respectively, and $59.0 million and $148.9 million in the third quarter and first nine months of 2022, respectively.  Net income attributable to Franklin Electric Co., Inc. in the third quarter and first nine months of 2023 was $57.8 million and $154.7 million, respectively, or $1.23 and $3.29 per diluted share.  Net income attributable to Franklin Electric Co., Inc. in the third quarter and first nine months of 2022 was $58.6 million and $147.8 million, respectively, or $1.24 and $3.13 per diluted share.

[0000038725-23-000182:mdna:50]
[same as prior period, unchanged from 0000038725-23-000151:mdna:50]

[0000038725-23-000182:mdna:51]
[same as prior period, unchanged from 0000038725-23-000151:mdna:51]

[0000038725-23-000182:mdna:52]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at September 30, 2023 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-23-000182:mdna:53]
As of September 30, 2023, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of September 30, 2023, the Company had $307.4 million borrowing capacity under its credit agreement as $3.6 million in letters of commercial and standby letters of credit were outstanding and undrawn and $39.0 million in revolver borrowings were drawn and outstanding, which were primarily used for funding working capital requirements.

[0000038725-23-000182:mdna:54]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of  $125.0 million as of September 30, 2023. The Company also has other long-term debt borrowings outstanding as of September 30, 2023. See Note 10 - Debt included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022, for additional information regarding these obligations and future maturities as well as Note 10 - Debt of this current quarterly report for changes to these agreements since December 31, 2022.

[0000038725-23-000182:mdna:55]
At September 30, 2023, the Company had $54.9 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate the majority of these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-23-000182:mdna:56]
[same as prior period, unchanged from 0000038725-23-000151:mdna:56]

[0000038725-23-000182:mdna:57]
The following table summarizes significant sources and uses of cash and cash equivalents for the first nine months of 2023 and 2022.

[0000038725-23-000182:mdna:58]
| (in millions) |  | 2023 |  | 2022 |
| Net cash flows from operating activities |  | $ | 198.6 |  |  | $ | 7.2 |  |
| Net cash flows from investing activities |  | (36.8) |  |  | (30.9) |  |
| Net cash flows from financing activities |  | (140.3) |  |  | 29.2 |  |
| Impact of exchange rates on cash and cash equivalents |  | (4.8) |  |  | (6.5) |  |
| Change in cash and cash equivalents |  | $ | 16.7 |  |  | $ | (1.0) |  |

[0000038725-23-000182:mdna:59]
[same as prior period, unchanged from 0000038725-23-000151:mdna:60]

[0000038725-23-000182:mdna:60]
[same as prior period, unchanged from 0000038725-23-000151:mdna:61]

[0000038725-23-000182:mdna:61]
Net cash provided by operating activities was $198.6 million for the nine months ended September 30, 2023 compared to $7.2 million provided by operating activities for the nine months ended September 30, 2022. The change in operating cash flow was primarily due to decreased working capital requirements.

[0000038725-23-000182:mdna:62]
[same as prior period, unchanged from 0000038725-23-000151:mdna:63]

[0000038725-23-000182:mdna:63]
[same as prior period, unchanged from 0000038725-23-000151:mdna:64]

[0000038725-23-000182:mdna:64]
Net cash used in investing activities was $36.8 million for the nine months ended September 30, 2023 compared to $30.9 million used in investing activities for the nine months ended September 30, 2022. The increase in cash used in investing activities was attributable to increased acquisition activity in the first nine months of 2023.

[0000038725-23-000182:mdna:65]
[same as prior period, unchanged from 0000038725-23-000151:mdna:66]

[0000038725-23-000182:mdna:66]
[same as prior period, unchanged from 0000038725-23-000151:mdna:67]

[0000038725-23-000182:mdna:67]
Net cash used by financing activities was $140.3 million for the nine months ended September 30, 2023 compared to $29.2 million provided by financing activities for the nine months ended September 30, 2022. The change in financing cash flow was primarily attributable to net borrowings under the Company's revolving credit facility in 2022 compared to net repayments in 2023.

[0000038725-23-000182:mdna:68]
[same as prior period, unchanged from 0000038725-23-000151:mdna:69]
