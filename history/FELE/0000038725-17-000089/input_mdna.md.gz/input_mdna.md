# FELE MD&A — 0000038725-17-000089


## mdna

[0000038725-17-000089:mdna:1]
[same as prior period, unchanged from 0000038725-16-000438:mdna:1]

[0000038725-17-000089:mdna:2]
First Quarter 2017 vs. First Quarter 2016

[0000038725-17-000089:mdna:3]
[same as prior period, unchanged from 0000038725-16-000438:mdna:3]

[0000038725-17-000089:mdna:4]
Sales in the first quarter of 2017 increased from the first quarter last year.  The sales increase was primarily due to increased sales of Fueling Systems partially offset by lower sales in Water Systems.  Foreign currency translation had no net impact on sales after consolidation in the first quarter of 2017.   The Company’s organic sales growth was 1 percent excluding the impact of foreign currency.  The Company's consolidated gross profit was $75.8 million for the first quarter of 2017, an increase of $1.6 million or about 2 percent from the prior year’s first quarter. The gross profit as a percent of net sales increased 40 basis points to 34.4 percent in 2017 from 34.0 percent in first quarter of 2016.

[0000038725-17-000089:mdna:5]
[same as prior period, unchanged from 0000038725-16-000438:mdna:5]

[0000038725-17-000089:mdna:6]
[same as prior period, unchanged from 0000038725-16-000438:mdna:6]

[0000038725-17-000089:mdna:7]
Net sales in the first quarter of 2017 were $220.3 million, an increase of $1.9 million or about 1 percent compared to 2016 first quarter sales of $218.4 million.  The Company’s organic sales growth was 1 percent as the impact of foreign currency translation was not significant.

[0000038725-17-000089:mdna:8]
|  | Net Sales |
| (In millions) | Q1 2017 |  | Q1 2016 |  | 2017 v 2016 |
| Water Systems | $ | 167.2 |  |  | $ | 168.8 |  |  | $ | (1.6 | ) |
| Fueling Systems | 53.1 |  |  | 49.6 |  |  | 3.5 |  |
| Consolidated | $ | 220.3 |  |  | $ | 218.4 |  |  | $ | 1.9 |  |

[0000038725-17-000089:mdna:9]
[same as prior period, unchanged from 0000038725-16-000438:mdna:9]

[0000038725-17-000089:mdna:10]
Water Systems revenues were $167.2 million in the first quarter 2017, a decrease of $1.6 million or about 1 percent versus the first quarter 2016 sales of $168.8 million. Sales were not significantly impacted in the first quarter of 2017 by foreign currency translation. Water Systems sales were down about 1 percent, excluding foreign currency translation, in the first quarter of 2017 versus the first quarter of 2016.

[0000038725-17-000089:mdna:11]
Water Systems sales in the U.S. and Canada represented 32 percent of consolidated sales and declined by about 8 percent compared to the prior year. Water Systems sales were not significantly impacted in the quarter due to foreign currency translation.  On April 10, 2017, the Company announced the acquisition of three distribution companies in the U.S. groundwater market.  Groundwater sales declined about $7 million, of which approximately $6 million is attributable to the decision by the leadership of the acquired distribution companies to reduce their inventory of Franklin Electric products in anticipation of the acquisitions.

[0000038725-17-000089:mdna:12]
Outside of the sales to the acquired distribution companies, U.S. and Canada sales of groundwater pumping equipment were down about 4 percent due to higher channel inventory levels from significant fourth quarter 2016 purchases and to a lesser extent, adverse weather, especially in the West.  U.S. and Canada sales of dewatering equipment increased by 12 percent in the first quarter when compared to the prior year and sales of other surface pumping equipment declined by 3 percent.

[0000038725-17-000089:mdna:13]
Water Systems sales in Europe, the Middle East and Africa were about 19 percent of consolidated sales and decreased by about 4 percent compared to the first quarter 2016.  Water Systems sales were reduced by about 6 percent in the quarter due to foreign currency translation.  Excluding the impact of foreign currency translation, sales increased by about 2 percent compared to the first quarter 2016. The growth was driven by higher sales of groundwater pumping equipment, partially offset by decreased rental sales of Pioneer branded dewatering equipment and weakness in Southern Africa due to lower demand in the mining sector.

[0000038725-17-000089:mdna:14]
Water Systems sales in Latin America were about 15 percent of consolidated sales for the first quarter and grew by about 23 percent compared to the first quarter of the prior year.  Water Systems sales were up by $3.2 million or about 12 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, Latin American sales increased by about 11 percent compared to the first quarter 2016.  The growth in sales was primarily in Brazil.

[0000038725-17-000089:mdna:15]
Water Systems sales in the Asia Pacific region were 10 percent of consolidated sales and were up about 1 percent compared to the first quarter prior year.  Asia Pacific sales were higher by less than 1 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, Asia Pacific sales increased by about 1 percent compared to the first quarter 2016.

[0000038725-17-000089:mdna:16]
[same as prior period, unchanged from 0000038725-16-000438:mdna:15]

[0000038725-17-000089:mdna:17]
Fueling Systems sales were about 24 percent of consolidated sales at $53.1 million in the first quarter of 2017, an increase of $3.5 million or about 7 percent versus the first quarter 2016 sales of $49.6 million. Fueling Systems sales were decreased by $0.8 million or 2 percent in the quarter due to foreign currency translation. Fueling Systems sales growth, excluding foreign currency translation, was about 9 percent.  Fueling Systems sales in the U.S. and Canada grew by about 7 percent during the quarter with most of the sales growth coming from pump and fuel management systems.  Fueling Systems revenues in the rest of world were higher, excluding foreign exchange, by about 7 percent.  Asia Pacific grew by about 24 percent due to higher sales in China. These sales increases were partially offset by lower sales in Europe and Latin America.

[0000038725-17-000089:mdna:18]
[same as prior period, unchanged from 0000038725-16-000438:mdna:18]

[0000038725-17-000089:mdna:19]
Cost of sales as a percentage of net sales for the first quarters of 2017 and 2016 was 65.6 percent and 66.0 percent, respectively. Correspondingly, the gross profit margin increased to 34.4 percent from 34.0 percent, a 40 basis point improvement. The Company’s consolidated gross profit was $75.8 million for the first quarter of 2017, an increase of $1.6 million, or about 2 percent, from the first quarter of 2016 gross profit of $74.2 million.  The gross profit margin increase was primarily due to favorable pricing and lower direct material costs, partially offset by higher fixed costs.

[0000038725-17-000089:mdna:20]
[same as prior period, unchanged from 0000038725-16-000438:mdna:20]

[0000038725-17-000089:mdna:21]
Selling, general, and administrative (SG&A) expenses were $57.0 million in the first quarter of 2017 compared to $52.3 million in the first quarter of the prior year, an increase of $4.7 million or about 9 percent.   Sales related support cost, including marketing and selling related expenses, increased by about $3.3 million or 15 percent and the transaction and other costs associated with the recently acquired distribution companies were about $0.8 million.

[0000038725-17-000089:mdna:22]
Restructuring Expenses

[0000038725-17-000089:mdna:23]
Restructuring expenses for the first quarters of 2017 and 2016 were $0.3 million and $0.8 million, respectively.

[0000038725-17-000089:mdna:24]
Restructuring expenses for the first quarter of 2017 were in Brazil and related to continued manufacturing realignments and include severance expenses and other miscellaneous manufacturing realignment activities.  Restructuring expenses for the first quarter of 2016 were split $0.4 million across both segments, Water and Fueling, and included asset write-offs, severance expenses and other miscellaneous manufacturing realignment activities.

[0000038725-17-000089:mdna:25]
[same as prior period, unchanged from 0000038725-16-000438:mdna:25]

[0000038725-17-000089:mdna:26]
Operating income was $18.5 million in the first quarter of 2017, down $2.6 million or about 12 percent from $21.1 million in the first quarter of 2016.

[0000038725-17-000089:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2017 |  | Q1 2016 |  | 2017 v 2016 |
| Water Systems |  | $ | 21.4 |  |  | $ | 24.2 |  |  | $ | (2.8 | ) |
| Fueling Systems |  | 11.0 |  |  | 10.2 |  |  | 0.8 |  |
| Other |  | (13.9 | ) |  | (13.3 | ) |  | (0.6 | ) |
| Consolidated |  | $ | 18.5 |  |  | $ | 21.1 |  |  | $ | (2.6 | ) |

[0000038725-17-000089:mdna:28]
[same as prior period, unchanged from 0000038725-16-000438:mdna:33]

[0000038725-17-000089:mdna:29]
Water Systems operating income was $21.4 million in the first quarter 2017, down $2.8 million versus the first quarter 2016. The first quarter operating income margin was 12.8 percent, down 150 basis points from 14.3 percent in the first quarter of 2016.  Operating income decreased in Water Systems primarily due to higher fixed costs from marketing and selling related expenses.

[0000038725-17-000089:mdna:30]
[same as prior period, unchanged from 0000038725-16-000438:mdna:35]

[0000038725-17-000089:mdna:31]
Fueling Systems operating income was $11.0 million in the first quarter of 2017 compared to $10.2 million in the first quarter of 2016, an increase of about 8 percent. The first quarter Fueling Systems operating income margin was 20.7 percent, an

[0000038725-17-000089:mdna:32]
increase of 10 basis points from the 20.6 percent of net sales in the first quarter of 2016.

[0000038725-17-000089:mdna:33]
[same as prior period, unchanged from 0000038725-16-000438:mdna:38]

[0000038725-17-000089:mdna:34]
Operating income-other is composed primarily of unallocated general and administrative expenses and in the first quarter of 2017 included the transaction and other costs associated with the recently acquired distribution companies of about $0.8 million.

[0000038725-17-000089:mdna:35]
[same as prior period, unchanged from 0000038725-16-000438:mdna:40]

[0000038725-17-000089:mdna:36]
Interest expense for the first quarters of 2017 and 2016 was $3.5 million and $2.4 million, respectively, and in the first quarter of 2017 the Company recorded interest charges on prior years VAT taxes as a result of an audit in an international jurisdiction.

[0000038725-17-000089:mdna:37]
[same as prior period, unchanged from 0000038725-16-000438:mdna:42]

[0000038725-17-000089:mdna:38]
Other income or expense was income in the first quarter of 2017 of $0.7 million and was less than $0.1 million in the first quarter of 2016.  Included in other income in the first quarter of 2017 was income from minority interests of $0.5 million and interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities.  Included in other income in the first quarter of 2016 was interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-17-000089:mdna:39]
[same as prior period, unchanged from 0000038725-16-000438:mdna:44]

[0000038725-17-000089:mdna:40]
Foreign currency-based transactions produced a gain of $0.5 million for the first quarter of 2017.  Foreign currency-based transactions produced a loss of $0.1 million for the first quarter of 2016.

[0000038725-17-000089:mdna:41]
[same as prior period, unchanged from 0000038725-16-000438:mdna:46]

[0000038725-17-000089:mdna:42]
The provision for income taxes in the first quarters of 2017 and 2016 was $0.2 million and $5.0 million, respectively. The effective tax rate for the first quarter of 2017 was about 1 percent and, before the impact of discrete events, was about 27 percent.  The effective tax rate for the first quarter of 2016 was about 27 percent and, before the impact of discrete events, was about 26 percent.   In the first quarter of 2017, the Company realized a foreign currency translation loss on the repayment of an intercompany loan that was a long-term-investment in nature resulting in a discrete tax benefit of $1.7 million.  The Company also completed in the quarter tax restructuring in a foreign tax jurisdiction and released a $1.9 million valuation allowance on a deferred tax asset related to net operating losses now expected to be realized. The tax rate as a percentage of pre-tax earnings for the full year of 2017 is projected to be about 27 percent, compared to the full year 2016 tax rate of about 26 percent, both before discrete adjustments.  The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand, and available credit.

[0000038725-17-000089:mdna:43]
[same as prior period, unchanged from 0000038725-16-000438:mdna:48]

[0000038725-17-000089:mdna:44]
Net income for the first quarter of 2017 was $15.9 million compared to the prior year first quarter net income of $13.6 million.  Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2017 was $15.7 million, or $0.33 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $13.5 million or $0.28 per diluted share.

[0000038725-17-000089:mdna:45]
[same as prior period, unchanged from 0000038725-16-000438:mdna:110]

[0000038725-17-000089:mdna:46]
Sources of Liquidity

[0000038725-17-000089:mdna:47]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at March 31, 2017 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-17-000089:mdna:48]
As of March 31, 2017, the Company had a $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of March 31, 2017, the Company had $294.0 million borrowing capacity under the Credit Agreement as $6.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and no revolver borrowing was drawn and outstanding as of the end of the quarter.

[0000038725-17-000089:mdna:49]
The Company also has other long-term debt borrowing outstanding as of March 31, 2017.  See Footnote 9 for additional specifics regarding these obligations and future maturities.

[0000038725-17-000089:mdna:50]
At March 31, 2017, the Company had $49.9 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-17-000089:mdna:51]
Cash Flows

[0000038725-17-000089:mdna:52]
The following table summarizes significant sources and uses of cash and cash equivalents for the first quarters of 2017 and 2016.

[0000038725-17-000089:mdna:53]
| (in thousands) |  | 2017 |  | 2016 |
| Net cash used in operating activities |  | $ | (24.6 | ) |  | $ | (0.4 | ) |
| Net cash used in investing activities |  | (4.8 | ) |  | (11.0 | ) |
| Net cash provided by (used in) financing activities |  | (5.3 | ) |  | 3.6 |  |
| Impact of exchange rates on cash and cash equivalents |  | 1.0 |  |  | 0.9 |  |
| Change in cash and cash equivalents |  | $ | (33.7 | ) |  | $ | (6.9 | ) |

[0000038725-17-000089:mdna:54]
Cash Flows Used in Operating Activities

[0000038725-17-000089:mdna:55]
2017 vs. 2016

[0000038725-17-000089:mdna:56]
Net cash used in operating activities was $24.6 million for the first quarter ended March 31, 2017 compared to $0.4 million for the first quarter ended April 2, 2016.  The increase in cash used in operations in the first quarter of 2017 in comparison to the first quarter of 2016 was largely attributable to an increase in held inventory due to both seasonality and anticipated increased demand, a decrease in accrued liabilities attributable to higher incentive bonus payments, and reductions in income tax liabilities and reserves in the first quarter of 2017 compared to the first quarter of 2016.

[0000038725-17-000089:mdna:57]
Cash Flows Used in Investing Activities

[0000038725-17-000089:mdna:58]
2017 vs. 2016

[0000038725-17-000089:mdna:59]
Net cash used in investing activities was $4.8 million for the first quarter ended March 31, 2017 compared to $11.0 million for the first quarter ended April 2, 2016.  The decrease in cash used in investing activities was primarily attributable to higher capital expenditures in the first quarter of 2016 which included the purchase of a building.

[0000038725-17-000089:mdna:60]
Cash Flows Provided by (Used in) Financing Activities

[0000038725-17-000089:mdna:61]
2017 vs. 2016

[0000038725-17-000089:mdna:62]
Net cash used in financing activities was $5.3 million for the first quarter ended March 31, 2017 compared to $3.6 million provided by financing activities for the first quarter ended April 2, 2016.  The Company had net repayments of approximately $0.5 million in the first quarter of 2017 and net borrowings of approximately $11.8 million for the same period in 2016.  Repurchases of common stock were approximately $0.7 million in the first quarter ended March 31, 2017 compared to $4.2 million in the first quarter ended April 2, 2016.

[0000038725-17-000089:mdna:63]
[same as prior period, unchanged from 0000038725-16-000438:mdna:128]
