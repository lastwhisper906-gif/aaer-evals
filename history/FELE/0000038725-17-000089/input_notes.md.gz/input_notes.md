# FELE notes — 0000038725-17-000089


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-17-000089:notes:1]
COMMITMENTS AND CONTINGENCIES

[0000038725-17-000089:notes:2]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-17-000089:notes:3]
At March 31, 2017, the Company had $15.6 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-17-000089:notes:4]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two to five years from date of manufacture or one to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-17-000089:notes:5]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2017, are as follows:

[0000038725-17-000089:notes:6]
| (In millions) |  |  |
| Balance as of December 31, 2016 |  | $ | 8.2 |  |
| Accruals related to product warranties |  | 2.0 |  |
| Reductions for payments made |  | (1.5 | ) |
| Balance as of March 31, 2017 |  | $ | 8.7 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-17-000089:notes:7]
[same as prior period, unchanged from 0000038725-16-000438:notes:7]

[0000038725-17-000089:notes:8]
Changes in accumulated other comprehensive income/(loss) by component for the first quarters ended March 31, 2017 and April 2, 2016, are summarized below:

[0000038725-17-000089:notes:9]
| (In millions) |  |  |  |  |  |
| For the first quarter ended March 31, 2017: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2016 | $ | (118.4 | ) |  | $ | (51.5 | ) |  | $ | (169.9 | ) |
| Other comprehensive income/(loss) before reclassifications | 8.4 |  | — |  |  | 8.4 |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.5 |  |  | 0.5 |  |
| Net other comprehensive income/(loss) | 8.4 |  |  | 0.5 |  |  | 8.9 |  |
| Balance as of March 31, 2017 | $ | (110.0 | ) |  | $ | (51.0 | ) |  | $ | (161.0 | ) |
| For the first quarter ended April 2, 2016: |  |  |  |  |  |
| Balance as of January 2, 2016 | $ | (110.1 | ) |  | $ | (51.5 | ) |  | $ | (161.6 | ) |
| Other comprehensive income/(loss) before reclassifications | 13.0 |  |  | — |  |  | 13.0 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.4 |  |  | 0.4 |  |
| Net other comprehensive income/(loss) | 13.0 |  |  | 0.4 |  |  | 13.4 |  |
| Balance as of April 2, 2016 | $ | (97.1 | ) |  | $ | (51.1 | ) |  | $ | (148.2 | ) |

[0000038725-17-000089:notes:10]
[same as prior period, unchanged from 0000038725-16-000438:notes:10]

[0000038725-17-000089:notes:11]
(2) Net of tax (benefit)/expense of $0.3 million for both the first quarters ended March 31, 2017 and April 2, 2016.

[0000038725-17-000089:notes:12]
Amounts related to noncontrolling interests were not material.


## us-gaap:DebtDisclosureTextBlock

[0000038725-17-000089:notes:13]
DEBT

[0000038725-17-000089:notes:14]
Debt consisted of the following:

[0000038725-17-000089:notes:15]
| (In millions) |  | March 31, 2017 |  | December 31, 2016 |
| Prudential Agreement |  | $ | 90.0 |  |  | $ | 90.0 |  |
| Tax increment financing debt |  | 21.3 |  |  | 21.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.9 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 190.0 |  |  | $ | 190.2 |  |
| Less: current maturities |  | (33.8 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 156.2 |  |  | $ | 156.5 |  |

[0000038725-17-000089:notes:16]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2017 matures as follows:

[0000038725-17-000089:notes:17]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 190.2 |  |  | $ | 33.8 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 190.3 |  |  | $ | 33.8 |  |  | $ | 31.3 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |

[0000038725-17-000089:notes:18]
Prudential Agreement

[0000038725-17-000089:notes:19]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with a limited borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  As of March 31, 2017, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.

[0000038725-17-000089:notes:20]
Project Bonds

[0000038725-17-000089:notes:21]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-17-000089:notes:22]
New York Life

[0000038725-17-000089:notes:23]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (0.98 percent as of March 31, 2017) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of March 31, 2017, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-17-000089:notes:24]
Credit Agreement

[0000038725-17-000089:notes:25]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-17-000089:notes:26]
As of March 31, 2017, the Company had no outstanding borrowings, $6.0 million in letters of credit outstanding, and $294.0 million of available capacity under the Credit Agreement.

[0000038725-17-000089:notes:27]
Covenants

[0000038725-17-000089:notes:28]
The New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-17-000089:notes:29]
[same as prior period, unchanged from 0000038725-16-000438:notes:16]

[0000038725-17-000089:notes:30]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements ("the swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of March 31, 2017, the swap had a notional value based on 190,000 shares.  For both the first quarters ended March 31, 2017 and April 2, 2016, the swap resulted in gains of $0.8 million.  Gains/losses resulting from the the swap were primarily offset by gains/losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-17-000089:notes:31]
[same as prior period, unchanged from 0000038725-16-000438:notes:18]

[0000038725-17-000089:notes:32]
[same as prior period, unchanged from 0000038725-16-000438:notes:19]

[0000038725-17-000089:notes:33]
[same as prior period, unchanged from 0000038725-16-000438:notes:20]

[0000038725-17-000089:notes:34]
[same as prior period, unchanged from 0000038725-16-000438:notes:21]

[0000038725-17-000089:notes:35]
[same as prior period, unchanged from 0000038725-16-000438:notes:22]

[0000038725-17-000089:notes:36]
[same as prior period, unchanged from 0000038725-16-000438:notes:23]

[0000038725-17-000089:notes:37]
[same as prior period, unchanged from 0000038725-16-000438:notes:24]

[0000038725-17-000089:notes:38]
[same as prior period, unchanged from 0000038725-16-000438:notes:25]

[0000038725-17-000089:notes:39]
[same as prior period, unchanged from 0000038725-16-000438:notes:26]

[0000038725-17-000089:notes:40]
[same as prior period, unchanged from 0000038725-16-000438:notes:27]

[0000038725-17-000089:notes:41]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the first quarters ended March 31, 2017 and April 2, 2016 are as follows:

[0000038725-17-000089:notes:42]
|  |  | March 31, 2017 |  | April 2, 2016 |
| Risk-free interest rate |  | 1.89 | % |  | 1.21 | % |
| Dividend yield |  | 0.94 | % |  | 1.32 | % |
| Volatility factor |  | 31.19 | % |  | 37.70 | % |
| Expected term |  | 5.5 years |  |  | 5.5 years |  |

[0000038725-17-000089:notes:43]
A summary of the Company’s outstanding stock option activity and related information for the first quarter ended March 31, 2017 is as follows:

[0000038725-17-000089:notes:44]
| (Shares in thousands) |  | March 31, 2017 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,455 |  |  | $ | 25.02 |  |
| Granted |  | 192 |  |  | 42.49 |  |
| Exercised |  | (25 | ) |  | 18.92 |  |
| Forfeited |  | (2 | ) |  | 35.99 |  |
| Outstanding at end of period |  | 1,620 |  |  | $ | 27.17 |  |
| Expected to vest after applying forfeiture rate |  | 1,590 |  |  | $ | 26.99 |  |
| Vested and exercisable at end of period |  | 1,124 |  |  | $ | 23.13 |  |

[0000038725-17-000089:notes:45]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of March 31, 2017 is as follows:

[0000038725-17-000089:notes:46]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.74 years |  | $ | 25,734 |  |
| Expected to vest after applying forfeiture rate |  | 5.68 years |  | $ | 25,543 |  |
| Vested and exercisable at end of period |  | 4.31 years |  | $ | 22,416 |  |

[0000038725-17-000089:notes:47]
The total intrinsic value of options exercised during the first quarters ended March 31, 2017 and April 2, 2016 was $0.6 million and $0.2 million, respectively.

[0000038725-17-000089:notes:48]
As of March 31, 2017, there was $2.5 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.35 years.

[0000038725-17-000089:notes:49]
[same as prior period, unchanged from 0000038725-16-000438:notes:37]

[0000038725-17-000089:notes:50]
A summary of the Company’s restricted stock/stock unit award activity and related information for the first quarter ended March 31, 2017 is as follows:

[0000038725-17-000089:notes:51]
| (Shares in thousands) |  | March 31, 2017 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 473 |  |  | $ | 34.89 |  |
| Awarded |  | 127 |  |  | 42.38 |  |
| Vested |  | (77 | ) |  | 33.64 |  |
| Forfeited |  | (20 | ) |  | 33.80 |  |
| Non-vested at end of period |  | 503 |  |  | $ | 37.02 |  |

[0000038725-17-000089:notes:52]
As of March 31, 2017, there was $12.2 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.69 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-17-000089:notes:53]
[same as prior period, unchanged from 0000038725-16-000438:notes:41]

[0000038725-17-000089:notes:54]
[same as prior period, unchanged from 0000038725-16-000438:notes:42]

[0000038725-17-000089:notes:55]
[same as prior period, unchanged from 0000038725-16-000438:notes:43]

[0000038725-17-000089:notes:56]
[same as prior period, unchanged from 0000038725-16-000438:notes:44]

[0000038725-17-000089:notes:57]
|  | First Quarter Ended |
| (In millions, except per share amounts) | March 31, 2017 |  | April 2, 2016 |
| Numerator: |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 15.7 |  |  | $ | 13.5 |  |
| Less: Undistributed earnings allocated to participating securities | 0.1 |  |  | 0.1 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | 0.1 |  |  | 0.5 |  |
| Net income available to common shareholders | $ | 15.5 |  |  | $ | 12.9 |  |
| Denominator: |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.4 |  |  | 46.1 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.6 |  |  | 0.3 |  |
| Diluted weighted average common shares outstanding | 47.0 |  |  | 46.4 |  |
| Basic earnings per share | $ | 0.33 |  |  | $ | 0.28 |  |
| Diluted earnings per share | $ | 0.33 |  |  | $ | 0.28 |  |

[0000038725-17-000089:notes:58]
There were 0.2 million and 0.6 million stock options outstanding for the first quarters ended March 31, 2017 and April 2, 2016, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000038725-17-000089:notes:59]
[same as prior period, unchanged from 0000038725-16-000438:notes:46]

[0000038725-17-000089:notes:60]
The Company has equity interests in various companies for various strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s condensed consolidated balance sheets.  The carrying amount of the investments is adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income/(expense), net" line of the Company's condensed consolidated statements of income, were immaterial for the first quarters ended March 31, 2017 and April 2, 2016.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-17-000089:notes:61]
As of March 31, 2017 and December 31, 2016, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-17-000089:notes:62]
| (In millions) | March 31, 2017 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 5.3 |  | $ | 5.3 |  | $ | — |  | $ | — |  |
|  | December 31, 2016 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.6 |  | $ | 3.6 |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-17-000089:notes:63]
[same as prior period, unchanged from 0000038725-16-000438:notes:50]

[0000038725-17-000089:notes:64]
[same as prior period, unchanged from 0000038725-16-000438:notes:51]

[0000038725-17-000089:notes:65]
[same as prior period, unchanged from 0000038725-16-000438:notes:52]

[0000038725-17-000089:notes:66]
[same as prior period, unchanged from 0000038725-16-000438:notes:53]

[0000038725-17-000089:notes:67]
[same as prior period, unchanged from 0000038725-16-000438:notes:54]

[0000038725-17-000089:notes:68]
The Company's Level 1 assets consist of cash equivalents which are generally comprised of foreign bank guaranteed certificates of deposit.

[0000038725-17-000089:notes:69]
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3.

[0000038725-17-000089:notes:70]
Total debt, including current maturities, have carrying amounts of $190.0 million and $190.2 million and estimated fair values of $194 million and $195 million as of March 31, 2017 and December 31, 2016, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-17-000089:notes:71]
[same as prior period, unchanged from 0000038725-16-000438:notes:58]

[0000038725-17-000089:notes:72]
[same as prior period, unchanged from 0000038725-16-000438:notes:59]

[0000038725-17-000089:notes:73]
| (In millions) |  | March 31, 2017 |  | December 31, 2016 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.5 | ) |  | $ | 7.4 |  |  | $ | (6.4 | ) |
| Technology |  | 7.5 |  |  | (5.5 | ) |  | 7.5 |  |  | (5.3 | ) |
| Customer relationships |  | 134.3 |  |  | (51.7 | ) |  | 133.4 |  |  | (49.6 | ) |
| Other |  | 2.8 |  |  | (2.2 | ) |  | 2.7 |  |  | (2.1 | ) |
| Total |  | $ | 152.1 |  |  | $ | (65.9 | ) |  | $ | 151.0 |  |  | $ | (63.4 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 47.5 |  |  | — |  |  | 47.1 |  |  | — |  |
| Total intangibles |  | $ | 199.6 |  |  | $ | (65.9 | ) |  | $ | 198.1 |  |  | $ | (63.4 | ) |

[0000038725-17-000089:notes:74]
Amortization expense related to intangible assets for the first quarters ended March 31, 2017 and April 2, 2016 was $2.1 million and $2.0 million, respectively.

[0000038725-17-000089:notes:75]
[same as prior period, unchanged from 0000038725-16-000438:notes:62]

[0000038725-17-000089:notes:76]
| (In millions) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 |
|  |  | $ | 8.4 |  |  | $ | 8.4 |  |  | $ | 8.2 |  |  | $ | 8.1 |  |  | $ | 7.7 |  |

[0000038725-17-000089:notes:77]
The change in the carrying amount of goodwill by reporting segment for the three months ended March 31, 2017, is as follows:

[0000038725-17-000089:notes:78]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of December 31, 2016 |  | $ | 136.3 |  |  | $ | 63.3 |  |  | $ | 199.6 |  |
| Foreign currency translation |  | 0.7 |  |  | 0.1 |  |  | 0.8 |  |
| Balance as of March 31, 2017 |  | $ | 137.0 |  |  | $ | 63.4 |  |  | $ | 200.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-17-000089:notes:79]
[same as prior period, unchanged from 0000038725-16-000438:notes:66]

[0000038725-17-000089:notes:80]
The Company’s effective tax rate from continuing operations for the three month period ended March 31, 2017 was 1.3 percent as compared to 26.7 percent for the three month period ended April 2, 2016.

[0000038725-17-000089:notes:81]
[same as prior period, unchanged from 0000038725-16-000438:notes:68]

[0000038725-17-000089:notes:82]
In addition, during the three month period ended March 31, 2017, the Company realized a foreign currency translation loss on the repayment of an intercompany loan that was long-term-investment in nature resulting in a discrete benefit of $1.7 million. During the first quarter, the Company also completed tax restructuring in a foreign tax jurisdiction and released a $1.9 million valuation allowance on a deferred tax asset related to net operating losses now expected to be realized.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-17-000089:notes:83]
ACCOUNTING PRONOUNCEMENTS

[0000038725-17-000089:notes:84]
Accounting Standards Issued But Not Yet Adopted

[0000038725-17-000089:notes:85]
In March 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2017-07, Compensation - Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  This ASU requires entities to present only the service cost component of net periodic benefit cost as an operating expense (consistent with the presentation of other employee compensation costs).  The other components of net periodic benefit cost are to be presented as a non-operating expense.  The ASU is effective on a retrospective basis for interim and annual periods beginning after December 15, 2017.  Early adoption is permitted as of the beginning of any annual period for which an entity's financial statements have not been issued or made available for issuance.  The Company plans to adopt the ASU in the first quarter ended March 31, 2018 and is currently evaluating the impact of this ASU on its consolidated financial position, results of operations, and cash flows.

[0000038725-17-000089:notes:86]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact to the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-17-000089:notes:87]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification ("ASC") Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company has begun the evaluation process for the adoption of the ASU, and anticipates that the majority of the Company’s outstanding operating leases would be recognized as right-of-use assets and lease liabilities upon adoption, resulting in a significant impact to the Company’s consolidated balance sheets. The impact of this ASU is non-cash in nature and will not affect the Company’s cash position.  The impact to the Company’s results of operations is still being evaluated.

[0000038725-17-000089:notes:88]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606).  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  This ASU is effective for interim and annual reporting periods beginning after December 15, 2017.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt this standard.  The Company will adopt ASU 2014-09 beginning in the first quarter of 2018 using the modified retrospective approach.  The Company does not expect the adoption of this ASU to have a material impact on the Company’s consolidated financial position, results of operations, or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-17-000089:notes:89]
[same as prior period, unchanged from 0000038725-16-000438:notes:82]

[0000038725-17-000089:notes:90]
The accompanying condensed consolidated balance sheet as of December 31, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2017, and for the first quarters ended March 31, 2017 and April 2, 2016 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended March 31, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2017.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2016.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-17-000089:notes:91]
[same as prior period, unchanged from 0000038725-16-000438:notes:84]

[0000038725-17-000089:notes:92]
Defined Benefit Plans - As of March 31, 2017, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2016 measurement date for these plans.  One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all other eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-17-000089:notes:93]
[same as prior period, unchanged from 0000038725-16-000438:notes:86]

[0000038725-17-000089:notes:94]
The following table sets forth the aggregated net periodic benefit cost for all pension and postretirement plans for the first quarters ended March 31, 2017 and April 2, 2016:

[0000038725-17-000089:notes:95]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | First Quarter Ended |  | First Quarter Ended |
|  | March 31, 2017 |  | April 2, 2016 |  | March 31, 2017 |  | April 2, 2016 |
| Service cost | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 1.4 |  |  | 1.5 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | (2.2 | ) |  | (2.3 | ) |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Actuarial loss | 0.6 |  |  | 0.6 |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | 0.3 |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | (0.1 | ) |  | $ | 0.3 |  |  | $ | 0.2 |  |  | $ | 0.2 |  |

[0000038725-17-000089:notes:96]
In the first quarter ended March 31, 2017, the Company made contributions of $1.1 million to the funded plans.   The amount of contributions to be made to the plans during the calendar year 2017 will be finalized by September 15, 2017, based upon the funding level requirements identified and year-end valuation performed at December 31, 2016.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-17-000089:notes:97]
[same as prior period, unchanged from 0000038725-16-000438:notes:100]

[0000038725-17-000089:notes:98]
|  | First Quarter Ended |
| (In millions) | March 31, 2017 |  | April 2, 2016 |
|  | Net sales to external customers |
| Water Systems | $ | 167.2 |  |  | $ | 168.8 |  |
| Fueling Systems | 53.1 |  |  | 49.6 |  |
| Other | — |  |  | — |  |
| Consolidated | $ | 220.3 |  |  | $ | 218.4 |  |
|  | First Quarter Ended |
|  | March 31, 2017 |  | April 2, 2016 |
|  | Operating income/(loss) |
| Water Systems | $ | 21.4 |  |  | $ | 24.2 |  |
| Fueling Systems | 11.0 |  |  | 10.2 |  |
| Other | (13.9 | ) |  | (13.3 | ) |
| Consolidated | $ | 18.5 |  |  | $ | 21.1 |  |
|  | March 31, 2017 |  | December 31, 2016 |
|  | Total assets |
| Water Systems | $ | 723.0 |  |  | $ | 671.5 |  |
| Fueling Systems | 252.5 |  |  | 251.1 |  |
| Other | 79.8 |  |  | 117.3 |  |
| Consolidated | $ | 1,055.3 |  |  | $ | 1,039.9 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-17-000089:notes:99]
The schedule below sets forth equity changes in the first quarter ended March 31, 2017:

[0000038725-17-000089:notes:100]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2016 | $ | 4,638 |  |  | $ | 228,564 |  |  | $ | 550,095 |  |  | $ | (51,568 | ) |  | $ | (118,284 | ) |  | $ | 1,643 |  |  | $ | 615,088 |  |  | $ | 7,652 |  |
| Net income |  |  |  |  | 15,730 |  |  |  |  |  |  | 148 |  |  | 15,878 |  |  | 56 |  |
| Adjustment to Impo redemption value |  |  |  |  | (148 | ) |  |  |  |  |  |  |  | (148 | ) |  | 148 |  |
| Dividends on common stock |  |  |  |  | (4,668 | ) |  |  |  |  |  |  |  | (4,668 | ) |  |  |
| Common stock issued | 2 |  |  | 479 |  |  |  |  |  |  |  |  |  |  | 481 |  |  |  |
| Common stock repurchased | (2 | ) |  |  |  | (663 | ) |  |  |  |  |  |  |  | (665 | ) |  |  |
| Share-based compensation | 6 |  |  | 2,935 |  |  |  |  |  |  |  |  |  |  | 2,941 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 8,396 |  |  | 14 |  |  | 8,410 |  |  | (7 | ) |
| Pension liability, net of tax |  |  |  |  |  |  | 491 |  |  |  |  |  |  | 491 |  |  |  |
| Balance as of March 31, 2017 | $ | 4,644 |  |  | $ | 231,978 |  |  | $ | 560,346 |  |  | $ | (51,077 | ) |  | $ | (109,888 | ) |  | $ | 1,805 |  |  | $ | 637,808 |  |  | $ | 7,849 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-17-000089:notes:101]
[same as prior period, unchanged from 0000038725-16-000438:notes:104]

[0000038725-17-000089:notes:102]
Property, plant, and equipment is the major asset group in "Other" of total assets at March 31, 2017.  Cash is the major asset group in "Other" of total assets at December 31, 2016.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-17-000089:notes:103]
[same as prior period, unchanged from 0000038725-16-000438:notes:106]


## us-gaap:SubsequentEventsTextBlock

[0000038725-17-000089:notes:104]
SUBSEQUENT EVENT

[0000038725-17-000089:notes:105]
Subsequent to the end of the first quarter, the Company entered into agreements to acquire controlling interests in certain distributors in the U.S. professional groundwater market.  These companies will continue to operate as full line wholesale distributors with a focus on total water systems support, including products from other industry manufacturers.

[0000038725-17-000089:notes:106]
The Company previously held equity interests in these entities, each of which was less than 50 percent, and accounted for by the equity method of accounting.  As a result of the additional acquisition, the Company’s total interest in each of the entities is now 100 percent and the entities will be included in the Company’s consolidated results effective from the date of acquisition.

[0000038725-17-000089:notes:107]
The Company acquired the controlling interests of the entities for approximately $89 million, including assumed debt, subject to certain terms and conditions.

[0000038725-17-000089:notes:108]
For financial reporting purposes, the acquired businesses will be reported separately from the Company’s existing Water Systems segment within a newly-established Distribution segment.
