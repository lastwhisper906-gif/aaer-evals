# FELE 8-K — 0000038725-17-000086 filed 2017-04-27

## item codes, every 8-K on or before 2017-05-02

- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2017-05-02

- none on or before 2017-05-02

## item 2.02 — earnings release, exhibit 99.1

[0000038725-17-000086:8k_2_02:1]
EX-99.1
2
a201704278-kexhibit991.htm
EXHIBIT 99.1

[0000038725-17-000086:8k_2_02:2]
Exhibit

[0000038725-17-000086:8k_2_02:3]
Exhibit 99.1

[0000038725-17-000086:8k_2_02:4]
For Immediate Release

[0000038725-17-000086:8k_2_02:5]
For Further Information

[0000038725-17-000086:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-17-000086:8k_2_02:7]
260-824-2900

[0000038725-17-000086:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS FIRST QUARTER

[0000038725-17-000086:8k_2_02:9]
2017 SALES AND EARNINGS

[0000038725-17-000086:8k_2_02:10]
Fort Wayne, IN - April 27, 2017 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported first quarter 2017 GAAP fully diluted earnings per share (EPS) of $0.33, versus a GAAP fully diluted EPS in the first quarter 2016 of $0.28, an increase of 18 percent.  First quarter 2017 sales were $220.3 million, an increase of 1 percent compared to 2016 first quarter sales of $218.4 million.  The Company’s organic sales growth was 1 percent as the impact of foreign currency translation was not significant.

[0000038725-17-000086:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-17-000086:8k_2_02:12]
“We are pleased to report increased sales and earnings for the first quarter.  Our Fueling Systems segment achieved record first quarter sales and earnings and posted organic sales growth of 9 percent and our Water business outside the U.S. and Canada grew organically as well, with particularly strong results in Latin America.  Gross profit and gross profit margins both improved over the first quarter 2016.  Despite these improvements, our operating income declined in the quarter due to higher marketing and selling costs.  During the first quarter, we recognized discrete tax benefits that more than offset the operating income decline and allowed us to achieve an 18 percent increase in EPS.”

[0000038725-17-000086:8k_2_02:13]
Key Performance Indicators:

[0000038725-17-000086:8k_2_02:14]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Consolidated |
| Q1 2016 | $ | 77.6 |  | $ | 27.1 |  | $ | 42.8 |  | $ | 21.3 |  | $ | 168.8 |  | $ | 49.6 |  | $ | 218.4 |  |
| Q1 2017 | $ | 71.5 |  | $ | 33.3 |  | $ | 40.9 |  | $ | 21.5 |  | $ | 167.2 |  | $ | 53.1 |  | $ | 220.3 |  |
| Change | $ | (6.1 | ) | $ | 6.2 |  | $ | (1.9 | ) | $ | 0.2 |  | $ | (1.6 | ) | $ | 3.5 |  | $ | 1.9 |  |
| % Change | (8 | )% | 23 | % | (4 | )% | 1 | % | (1 | )% | 7 | % | 1 | % |
| Foreign currency translation | $ | — |  | $ | 3.2 |  | $ | (2.5 | ) | $ | 0.1 |  | $ | 0.8 |  | $ | (0.8 | ) | $ | — |  |
| % Change | — | % | 12 | % | (6 | )% | — | % | — | % | (2 | )% | — | % |
| Volume/Price | $ | (6.1 | ) | $ | 3.0 |  | $ | 0.6 |  | $ | 0.1 |  | $ | (2.4 | ) | $ | 4.3 |  | $ | 1.9 |  |
| % Change | (8 | )% | 11 | % | 2 | % | 1 | % | (1 | )% | 9 | % | 1 | % |

[0000038725-17-000086:8k_2_02:15]
| Operating Income and Margins |  |  |  |  |
| Before and After Restructuring Expenses |  |  |  |  |
| (in millions) | For the First Quarter 2017 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 21.4 |  | $ | 11.0 |  | $ | (13.9 | ) | $ | 18.5 |  |
| % Operating Income To Net Sales | 12.8 | % | 20.7 | % |  | 8.4 | % |
| Restructuring | $ | 0.3 |  | $ | — |  | $ | — |  | $ | 0.3 |  |
| Operating Income/(Loss) before Restructuring Expenses | $ | 21.7 |  | $ | 11.0 |  | $ | (13.9 | ) | $ | 18.8 |  |
| % Operating Income to Net Sales Before Restructuring | 13.0 | % | 20.7 | % |  | 8.5 | % |
| Operating Income and Margins |  |  |  |  |
| Before and After Restructuring Expenses |  |  |  |  |
| (in millions) | For the First Quarter 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 24.2 |  | $ | 10.2 |  | $ | (13.3 | ) | $ | 21.1 |  |
| % Operating Income To Net Sales | 14.3 | % | 20.6 | % |  | 9.7 | % |
| Restructuring | $ | 0.4 |  | $ | 0.4 |  | $ | — |  | $ | 0.8 |  |
| Operating Income/(Loss) before Restructuring Expenses | $ | 24.6 |  | $ | 10.6 |  | $ | (13.3 | ) | $ | 21.9 |  |
| % Operating Income to Net Sales Before Restructuring | 14.6 | % | 21.4 | % |  | 10.0 | % |

[0000038725-17-000086:8k_2_02:16]
Water Systems

[0000038725-17-000086:8k_2_02:17]
Water Systems sales were $167.2 million in the first quarter 2017, a decrease of $1.6 million or about 1 percent versus the first quarter 2016 sales of $168.8 million.  Water Systems organic sales were also down about 1 percent compared to the first quarter 2016.

[0000038725-17-000086:8k_2_02:18]
Water Systems sales in the U.S. and Canada were down about 8 percent compared to the prior year first quarter. On April 10, 2017, the Company announced the acquisition of three distribution companies in the U.S. groundwater market.  Groundwater sales declined about $7 million, of which approximately $6 million is attributable to the decision by the leadership of the acquired distribution companies to reduce their holdings of Franklin Electric inventory in anticipation of the acquisitions.

[0000038725-17-000086:8k_2_02:19]
Outside of the sales to the acquired distribution companies, U.S. and Canada sales of groundwater pumping equipment were down about 4 percent due to higher channel inventory levels from significant fourth quarter 2016 purchases and to a lesser extent, adverse weather, especially in the West.  U.S. and Canada sales of dewatering equipment increased by 12 percent in the first quarter when compared to the prior year and sales of other surface pumping equipment declined by 3 percent.

[0000038725-17-000086:8k_2_02:20]
Water Systems sales in markets outside the U.S. and Canada experienced overall growth of about 5 percent, of which about 1 percent was attributable to the impact of foreign currency translation.  International Water Systems sales growth was led by improved sales in the Latin American region which had organic sales growth of 11 percent, after excluding the impact of foreign currency translation. Sales in Europe, the Middle East, Africa and Asia Pacific markets also grew organically in the quarter compared to last year excluding the impact of foreign currency translation.

[0000038725-17-000086:8k_2_02:21]
Water Systems operating income was $21.4 million in the first quarter 2017, down $2.8 million or 12 percent versus the first quarter 2016 and operating income margin was 12.8 percent, a decline of 150 basis points from 14.3 percent in the first quarter 2016. Water Systems first quarter 2017 operating income and operating income margins before restructuring expenses were $21.7 million and 13.0 percent respectively.  The decline in Water Systems operating income and operating income margin is primarily attributed to lower sales volume and higher marketing and selling expenses.

[0000038725-17-000086:8k_2_02:22]
Fueling Systems

[0000038725-17-000086:8k_2_02:23]
Fueling Systems sales were $53.1 million in the first quarter 2017, an increase of $3.5 million or about 7 percent versus the first quarter 2016 sales of $49.6 million.  Fueling Systems sales decreased by $0.8 million or about 2 percent in the quarter due to foreign currency translation. Fueling Systems sales increased about 9 percent, after excluding foreign currency translation.

[0000038725-17-000086:8k_2_02:24]
Fueling Systems sales in the U.S. and Canada grew by about 7 percent during the quarter.  The increase was primarily in pumping and fuel management systems.  Outside of the U.S. and Canada, Fueling Systems revenues also grew by about 7 percent, led by stronger sales in Asia Pacific, especially China.  This growth was partially offset by a sales decline in Latin America.

[0000038725-17-000086:8k_2_02:25]
Fueling Systems operating income was $11.0 million in the first quarter of 2017, up $0.8 million or about 8 percent compared to $10.2 million in the first quarter of 2016 and the first quarter operating income margin was 20.7 percent, an increase of 10 basis points from the 20.6 percent of net sales in the first quarter of 2016.

[0000038725-17-000086:8k_2_02:26]
Overall

[0000038725-17-000086:8k_2_02:27]
The Company’s consolidated gross profit was $75.8 million for the first quarter of 2017, an increase of $1.6 million, or about 2 percent, from the first quarter of 2016 gross profit of $74.2 million. The gross profit as a percent of net sales was 34.4 percent in the first quarter of 2017 and increased about 40 basis points versus 34.0 percent during the first quarter 2016.  The gross profit margin increase was primarily due to favorable pricing and lower direct material costs, partially offset by higher fixed costs.

[0000038725-17-000086:8k_2_02:28]
Selling, general, and administrative (SG&A) expenses were $57.0 million in the first quarter of 2017 compared to $52.3 million in the first quarter of the prior year, an increase of $4.7 million or about 9 percent.  Sales related support cost, including marketing and selling related expenses, increased by about $3.3 million and transaction and other costs associated with the recently acquired distribution companies were about $0.8 million.

[0000038725-17-000086:8k_2_02:29]
The Company realized discrete income tax benefits related to foreign net operating losses and currency exchange losses in the first quarter of 2017 which lowered the consolidated effective tax rate to about 1 percent.  The effective tax rate in the first quarter 2016 was about 27 percent.

[0000038725-17-000086:8k_2_02:30]
The Company ended the first quarter of 2017 with a cash balance of about $71 million versus about $104 million at the end of 2016, down due primarily to increased inventory.  Inventory levels at the end of the first quarter 2017 were $236 million versus year end 2016 of $203 million. The inventory increase is primarily due to seasonal demand and due to lower than anticipated sales of groundwater pumping equipment in the U.S. and Canada markets.

[0000038725-17-000086:8k_2_02:31]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-17-000086:8k_2_02:32]
“Despite the slow start in the U.S. and Canada groundwater markets, we remain positive about the balance of 2017 and our ability to achieve organic top line growth in the five to seven percent range for our pre-acquisition segments.  This growth allows us to reaffirm our 2017 adjusted earnings per share guidance range of $1.77 to $1.87.

[0000038725-17-000086:8k_2_02:33]
As we had previously announced on April 10, our forward integration into distribution in the U.S. through the creation of the Headwater Distribution segment is a logical next step for Franklin Electric to serve and grow in the U.S. groundwater market.  We will begin reporting results for the new segment in the second quarter 2017.”

[0000038725-17-000086:8k_2_02:34]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The first quarter 2017 earnings call will be available via a live webcast.  The webcast will be available in a listen only mode by going to:

[0000038725-17-000086:8k_2_02:35]
http://edge.media-server.com/m/p/e89s6nuj

[0000038725-17-000086:8k_2_02:36]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 5094619.

[0000038725-17-000086:8k_2_02:37]
A replay of the conference call will be available Thursday, April 27, 2017 at 12:00 noon EDT through midnight EDT on Thursday, May 4, 2017, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 5094619.

[0000038725-17-000086:8k_2_02:38]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-17-000086:8k_2_02:39]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |
|  | First Quarter Ended |
|  | March 31, 2017 |  |  | April 2, 2016 |
| Net sales | $ | 220,252 |  |  | $ | 218,430 |  |
| Cost of sales | 144,436 |  |  | 144,194 |  |
| Gross profit | 75,816 |  |  | 74,236 |  |
| Selling, general, and administrative expenses | 56,991 |  |  | 52,345 |  |
| Restructuring expense | 315 |  |  | 820 |  |
| Operating income | 18,510 |  |  | 21,071 |  |
| Interest expense | (3,514 | ) |  | (2,427 | ) |
| Other income/(expense), net | 667 |  |  | (32 | ) |
| Foreign exchange income/(expense) | 475 |  |  | (77 | ) |
| Income before income taxes | 16,138 |  |  | 18,535 |  |
| Income tax expense | 204 |  |  | 4,955 |  |
| Net income | $ | 15,934 |  |  | $ | 13,580 |  |
| Less: Net income attributable to noncontrolling interests | (204 | ) |  | (123 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 15,730 |  |  | $ | 13,457 |  |
| Income per share: |  |  |  |
| Basic | $ | 0.33 |  |  | $ | 0.28 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.28 |  |

[0000038725-17-000086:8k_2_02:40]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | March 31, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 70,651 |  |  | $ | 104,331 |  |
| Receivables | 154,701 |  |  | 145,999 |  |
| Inventories | 235,724 |  |  | 203,471 |  |
| Other current assets | 33,803 |  |  | 30,018 |  |
| Total current assets | 494,879 |  |  | 483,819 |  |
| Property, plant, and equipment, net | 197,412 |  |  | 196,137 |  |
| Goodwill and other assets | 362,989 |  |  | 359,949 |  |
| Total assets | $ | 1,055,280 |  |  | $ | 1,039,905 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 69,042 |  |  | $ | 63,927 |  |
| Accrued expenses and other current liabilities | 46,667 |  |  | 60,119 |  |
| Current maturities of long-term debt and short-term borrowings | 33,783 |  |  | 33,715 |  |
| Total current liabilities | 149,492 |  |  | 157,761 |  |
| Long-term debt | 156,170 |  |  | 156,544 |  |
| Deferred income taxes | 42,067 |  |  | 40,460 |  |
| Employee benefit plans | 43,527 |  |  | 45,307 |  |
| Other long-term liabilities | 18,367 |  |  | 17,093 |  |
| Redeemable noncontrolling interest | 7,849 |  |  | 7,652 |  |
| Total equity | 637,808 |  |  | 615,088 |  |
| Total liabilities and equity | $ | 1,055,280 |  |  | $ | 1,039,905 |  |

[0000038725-17-000086:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Three Months Ended |
| (In thousands) | March 31, 2017 |  | April 2, 2016 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 15,934 |  |  | $ | 13,580 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 8,924 |  |  | 8,752 |  |
| Share-based compensation | 2,941 |  |  | 2,539 |  |
| Other | (1,879 | ) |  | 1,709 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (6,560 | ) |  | (20,609 | ) |
| Inventory | (29,661 | ) |  | (8,884 | ) |
| Accounts payable and accrued expenses | (10,539 | ) |  | (3,649 | ) |
| Other | (3,731 | ) |  | 6,125 |  |
| Net cash flows from operating activities | (24,571 | ) |  | (437 | ) |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (4,908 | ) |  | (11,153 | ) |
| Proceeds from sale of property, plant, and equipment | 34 |  |  | 185 |  |
| Other investing activities | (7 | ) |  | — |  |
| Net cash flows from investing activities | (4,881 | ) |  | (10,968 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (460 | ) |  | 11,789 |  |
| Proceeds from issuance of common stock | 481 |  |  | 411 |  |
| Excess tax from share-based payment arrangements | — |  |  | 53 |  |
| Purchases of common stock | (665 | ) |  | (4,175 | ) |
| Dividends paid | (4,668 | ) |  | (4,506 | ) |
| Net cash flows from financing activities | (5,312 | ) |  | 3,572 |  |
| Effect of exchange rate changes on cash | 1,084 |  |  | 914 |  |
| Net change in cash and equivalents | (33,680 | ) |  | (6,919 | ) |
| Cash and equivalents at beginning of period | 104,331 |  |  | 81,561 |  |
| Cash and equivalents at end of period | $ | 70,651 |  |  | $ | 74,642 |  |
