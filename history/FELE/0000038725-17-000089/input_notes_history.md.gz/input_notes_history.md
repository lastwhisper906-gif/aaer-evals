# FELE note change history — 0000038725-16-000438 → 0000038725-17-000089


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-02):
[0000038725-17-000089:note_history:1]
At March 31, 2017, the Company had $15.6 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2016-11-01, similarity 0.9658):
[0000038725-16-000438:note_history:1]
At October 1, 2016, the Company had $20.3 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2017-05-02):
[0000038725-17-000089:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2017, are as follows:
  (was, 2016-11-01, similarity 0.9042):
[0000038725-16-000438:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended October 1, 2016, are as follows:

- changed (2017-05-02):
[0000038725-17-000089:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2016 |  | $ | 8.2 |  |
| Accruals related to product warranties |  | 2.0 |  |
| Reductions for payments made |  | (1.5 | ) |
| Balance as of March 31, 2017 |  | $ | 8.7 |  |
  (was, 2016-11-01, similarity 0.9323):
[0000038725-16-000438:note_history:3]
| (In millions) |  |  |
| Balance as of January 2, 2016 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 4.6 |  |
| Reductions for payments made |  | (5.3 | ) |
| Balance as of October 1, 2016 |  | $ | 8.6 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-02):
[0000038725-17-000089:note_history:4]
The accompanying condensed consolidated balance sheet as of December 31, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2017, and for the first quarters ended March 31, 2017 and April 2, 2016 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended March 31, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2017.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2016.
  (was, 2016-11-01, similarity 0.8275):
[0000038725-16-000438:note_history:4]
The accompanying condensed consolidated balance sheet as of January 2, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of October 1, 2016, and for the third quarters and nine months ended October 1, 2016 and October 3, 2015 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the third quarter and nine months ended October 1, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2016.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended January 2, 2016.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-02):
[0000038725-17-000089:note_history:5]
| (In millions) |  | March 31, 2017 |  | December 31, 2016 |
| Prudential Agreement |  | $ | 90.0 |  |  | $ | 90.0 |  |
| Tax increment financing debt |  | 21.3 |  |  | 21.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.9 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 190.0 |  |  | $ | 190.2 |  |
| Less: current maturities |  | (33.8 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 156.2 |  |  | $ | 156.5 |  |
  (was, 2016-11-01, similarity 0.9495):
[0000038725-16-000438:note_history:5]
| (In millions) |  | October 1, 2016 |  | January 2, 2016 |
| Prudential Agreement |  | $ | 90.0 |  |  | $ | 120.0 |  |
| Tax increment financing debt |  | 21.8 |  |  | 22.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.5 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 190.1 |  |  | $ | 220.7 |  |
| Less: current maturities |  | (33.4 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 156.7 |  |  | $ | 187.8 |  |

- changed (2017-05-02):
[0000038725-17-000089:note_history:6]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2017 matures as follows:
  (was, 2016-11-01, similarity 0.9468):
[0000038725-16-000438:note_history:6]
Debt outstanding, excluding unamortized debt issuance costs, at October 1, 2016 matures as follows:

- added (2017-05-02):
[0000038725-17-000089:note_history:7]
Prudential Agreement

- added (2017-05-02):
[0000038725-17-000089:note_history:8]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with a limited borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  As of March 31, 2017, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.

- added (2017-05-02):
[0000038725-17-000089:note_history:9]
Project Bonds

- added (2017-05-02):
[0000038725-17-000089:note_history:10]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

- added (2017-05-02):
[0000038725-17-000089:note_history:11]
New York Life

- added (2017-05-02):
[0000038725-17-000089:note_history:12]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (0.98 percent as of March 31, 2017) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of March 31, 2017, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

- added (2017-05-02):
[0000038725-17-000089:note_history:13]
Credit Agreement

- added (2017-05-02):
[0000038725-17-000089:note_history:14]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

- added (2017-05-02):
[0000038725-17-000089:note_history:15]
As of March 31, 2017, the Company had no outstanding borrowings, $6.0 million in letters of credit outstanding, and $294.0 million of available capacity under the Credit Agreement.

- added (2017-05-02):
[0000038725-17-000089:note_history:16]
Covenants

- added (2017-05-02):
[0000038725-17-000089:note_history:17]
The New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2017.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-02):
[0000038725-17-000089:note_history:18]
| (In millions) |  | March 31, 2017 |  | December 31, 2016 |
| Prudential Agreement |  | $ | 90.0 |  |  | $ | 90.0 |  |
| Tax increment financing debt |  | 21.3 |  |  | 21.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.9 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 190.0 |  |  | $ | 190.2 |  |
| Less: current maturities |  | (33.8 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 156.2 |  |  | $ | 156.5 |  |
  (was, 2016-11-01, similarity 0.9495):
[0000038725-16-000438:note_history:18]
| (In millions) |  | October 1, 2016 |  | January 2, 2016 |
| Prudential Agreement |  | $ | 90.0 |  |  | $ | 120.0 |  |
| Tax increment financing debt |  | 21.8 |  |  | 22.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.5 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 190.1 |  |  | $ | 220.7 |  |
| Less: current maturities |  | (33.4 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 156.7 |  |  | $ | 187.8 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-02):
[0000038725-17-000089:note_history:19]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2017 matures as follows:
  (was, 2016-11-01, similarity 0.9468):
[0000038725-16-000438:note_history:19]
Debt outstanding, excluding unamortized debt issuance costs, at October 1, 2016 matures as follows:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-05-02):
[0000038725-17-000089:note_history:20]
Subsequent to the end of the first quarter, the Company entered into agreements to acquire controlling interests in certain distributors in the U.S. professional groundwater market.  These companies will continue to operate as full line wholesale distributors with a focus on total water systems support, including products from other industry manufacturers.

- added (2017-05-02):
[0000038725-17-000089:note_history:21]
The Company previously held equity interests in these entities, each of which was less than 50 percent, and accounted for by the equity method of accounting.  As a result of the additional acquisition, the Company’s total interest in each of the entities is now 100 percent and the entities will be included in the Company’s consolidated results effective from the date of acquisition.

- added (2017-05-02):
[0000038725-17-000089:note_history:22]
The Company acquired the controlling interests of the entities for approximately $89 million, including assumed debt, subject to certain terms and conditions.

- added (2017-05-02):
[0000038725-17-000089:note_history:23]
For financial reporting purposes, the acquired businesses will be reported separately from the Company’s existing Water Systems segment within a newly-established Distribution segment.

- removed (2017-05-02):
[0000038725-16-000438:note_history:24]
On October 28, 2016, the Company entered into the Third Amended and Restated Credit Agreement among Franklin Electric Co., Inc., Franklin Electric B.V., a Netherlands private company with limited liability (“Franklin B.V”, and together with Franklin Electric Co., Inc., the “Borrowers”), JPMorgan Chase Bank, N.A. (“JPMorgan”), as administrative agent, and Bank of America, N.A., as Syndication Agent, and the lenders identified therein (the “Third Amended and Restated Credit Agreement”.  JPMorgan and Bank of America Merrill Lynch were joint bookrunners and joint lead arrangers.  The Third Amended and Restated Credit Agreement extended the maturity date of the Company’s Second Amended and Restated Credit Agreement, as amended (which is referred to in this footnote as the “Previous Credit Agreement”) to October 28, 2021 and increased the commitment amount from $150.0 million to $300.0 million.

- removed (2017-05-02):
[0000038725-16-000438:note_history:25]
The Third Amended and Restated Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million) subject to the conditions contained therein.  All of the Company's present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers' obligations under and in connection with the Third Amended and Restated Credit Agreement.  Additionally, the Company unconditionally guaranties all of the obligations of Franklin B.V. under the Third Amended and Restated Credit Agreement.

- removed (2017-05-02):
[0000038725-16-000438:note_history:26]
Under the Third Amended and Restated Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of .100% to .275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears.

- removed (2017-05-02):
[0000038725-16-000438:note_history:27]
The Third Amended and Restated Credit Agreement contains customary affirmative and negative covenants. The affirmative covenants include financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The affirmative covenants also include financial covenants with a maximum leverage ratio of 3.50 to 1.00 (using net debt in the measure of leverage ratio, whereas the Previous Credit Agreement used gross debt in such measure) and an interest coverage ratio equal to or greater than 3.00 to 1.00 (using EBITDA in the measure, whereas the Previous Credit Agreement used EBIT). Under the Third Amended and Restated Credit Agreement, the priority debt cap is measured as 20 percent of total tangible assets, whereas the Previous Credit Agreement used net equity rather than total tangible assets. The negative covenants include limitations on loans or advances, investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets (which restrictions on sales and transfers of assets were reduced to some degree versus the Previous Credit Agreement).

- removed (2017-05-02):
[0000038725-16-000438:note_history:28]
As was the case in the Previous Credit Agreement, the Third Amended and Restated Credit Agreement also contains customary events of defaults (with customary grace periods, as applicable, for certain of those events of default). If an event of default occurs, the Third Amended and Restated Credit Agreement provides that (i) the commitments may be terminated and (ii) the loans then outstanding may be declared due and payable. For certain events of default relating to insolvency, bankruptcy or liquidation, the commitments are automatically terminated and the loans outstanding automatically become due and payable. The full amount of the aggregate commitment may be borrowed as multicurrency loans, in Euros, Japanese Yen, Australian Dollars, Pounds Sterling, Canadian Dollars or any other agreed currency.

- removed (2017-05-02):
[0000038725-16-000438:note_history:29]
As in the Previous Credit Agreement, the Third Amended and Restated Credit Agreement also provides for a swingline loan sub-facility of up to $15.0 million (with an additional discretionary amount of up to $15.0 million, which was not included under the Previous Credit Agreement), and a letter of credit subfacility of up to $50.0 million (increased from $25.0 million under the Previous Credit Agreement).

- removed (2017-05-02):
[0000038725-16-000438:note_history:30]
Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of .75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Third Amended and Restated Credit Agreement.  The Third Amended and Restated Credit Agreement also includes a competitive bid option that permits the Borrowers to request that the lenders provide bids for the interest rate that will apply to specific loans.

- removed (2017-05-02):
[0000038725-16-000438:note_history:31]
In addition, on October 28, 2016, the Company entered into (1) First Amendment (the “First Amendment”) to Note Purchase and Private Shelf Agreement dated as of May 27, 2015 (the “New York Life Agreement”) by and among NYL Investors LLC and each of the undersigned holders of notes that are signatories thereto, and (2) Amendment No. 1 (“Amendment No. 1” and together with the First Amendment, the “Private Shelf Amendments”) to Third Amended and Restated Note Purchase and Private Shelf Agreement dated as of May 28, 2015 (the “Prudential Agreement”) by and among the Company and PGIM, Inc. (“Prudential”) and the Prudential affiliates party thereto.  The Private Shelf Amendments were intended to make the covenants within the New York Life Agreement and Prudential Agreement consistent with those covenants that were modified in the Third Amended and Restated Credit Agreement as compared to the Previous Credit Agreement.

- removed (2017-05-02):
[0000038725-16-000438:note_history:32]
The foregoing description is qualified in its entirety by reference to the Third Amended and Restated Credit Agreement and the Private Shelf Amendments, copies of which are filed as Exhibits 10.2 - 10.4 to this Quarterly Report on Form 10-Q and are incorporated herein by reference.
