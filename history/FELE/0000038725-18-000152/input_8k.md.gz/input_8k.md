# FELE 8-K — 0000038725-18-000145 filed 2018-07-24

## item codes, every 8-K on or before 2018-07-31

- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2018-07-31

- none on or before 2018-07-31

## item 2.02 — earnings release, exhibit 99.1

[0000038725-18-000145:8k_2_02:1]
EX-99.1
2
a201807248-kexhibit991.htm
EXHIBIT 99.1

[0000038725-18-000145:8k_2_02:2]
Exhibit

[0000038725-18-000145:8k_2_02:3]
Exhibit 99.1

[0000038725-18-000145:8k_2_02:4]
For Immediate Release

[0000038725-18-000145:8k_2_02:5]
For Further Information

[0000038725-18-000145:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-18-000145:8k_2_02:7]
260-824-2900

[0000038725-18-000145:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS SECOND

[0000038725-18-000145:8k_2_02:9]
QUARTER 2018 SALES AND EARNINGS

[0000038725-18-000145:8k_2_02:10]
Fort Wayne, IN - July 24, 2018 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported second quarter 2018 GAAP fully diluted earnings per share (EPS) of $0.64, versus a GAAP fully diluted EPS in the second quarter 2017 of $0.64.  Second quarter 2018 sales were $344.0 million, compared to 2017 second quarter sales of $305.3 million.  Second quarter 2018 organic sales increased about 9 percent when excluding the impact of foreign currency translation.

[0000038725-18-000145:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-18-000145:8k_2_02:12]
“Overall, our second quarter results were strong.  Our Water Systems units in the U.S. and Canada grew organically by about 12 percent and our Fueling Systems organic revenue growth was 18 percent.  Our operating income grew by almost 20 percent and our earnings per share before restructuring expenses and the non-operational gain we realized in the second quarter last year, grew by 12 percent.  In Distribution, we continue to see revenue growth momentum and the overall results met our expectations for the quarter.  Our second quarter results were, however, held back by considerable weakness in two key international Water Systems end markets, Asia Pacific and Brazil, whose combined revenue declined over 20 percent versus the second quarter last year.  We estimate this decline resulted in our second quarter earnings per share being about 7 cents lower than we had expected.”

[0000038725-18-000145:8k_2_02:13]
Key Performance Indicators:

[0000038725-18-000145:8k_2_02:14]
| Earnings Before and After Restructuring |  | For the Second Quarter |
| (in millions) |  | 2018 | 2017 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 30.5 |  | $ | 29.9 |  | 2 | % |
| Allocated Undistributed Earnings |  | $ | (0.2 | ) | $ | — |  |  |
| Earnings for EPS Calculations |  | $ | 30.3 |  | $ | 29.9 |  | 1 | % |
| Restructuring (before tax): |  | $ | 0.6 |  | $ | 0.3 |  |  |
| Restructuring, net of tax: |  | $ | 0.5 |  | $ | 0.2 |  |  |
| Earnings Before Restructuring |  | $ | 30.8 |  | $ | 30.1 |  | 2 | % |
| Earnings Per Share |  | For the Second Quarter |
| Before and After Restructuring |  | 2018 | 2017 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.0 |  | 47.0 |  | — | % |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.64 |  | $ | 0.64 |  | — | % |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | — |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.65 |  | $ | 0.64 |  | 2 | % |

[0000038725-18-000145:8k_2_02:15]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q2 2017 | $ | 100.5 |  | $ | 31.0 |  | $ | 45.1 |  | $ | 21.7 |  | $ | 198.3 |  | $ | 61.0 |  | $ | 59.1 |  | $ | (13.1 | ) | $ | 305.3 |  |
| Q2 2018 | $ | 113.8 |  | $ | 29.0 |  | $ | 48.5 |  | $ | 19.1 |  | $ | 210.4 |  | $ | 74.1 |  | $ | 79.5 |  | $ | (20.0 | ) | $ | 344.0 |  |
| Change | $ | 13.3 |  | $ | (2.0 | ) | $ | 3.4 |  | $ | (2.6 | ) | $ | 12.1 |  | $ | 13.1 |  | $ | 20.4 |  | $ | (6.9 | ) | $ | 38.7 |  |
| % Change | 13 | % | (6 | )% | 8 | % | (12 | )% | 6 | % | 21 | % | 35 | % | 53 | % | 13 | % |
| Foreign currency translation | $ | 0.8 |  | $ | (2.0 | ) | $ | 0.2 |  | $ | (0.1 | ) | $ | (1.1 | ) | $ | 2.0 |  | $ | — |  |  |  |
| % Change | 1 | % | (6 | )% | 1 | % | — | % | (1 | )% | 3 | % | — | % |  |  |
| Acquisitions |  |  |  |  | $ | — |  | $ | — |  | $ | 16.6 |  |  |  |
| Volume/Price | $ | 12.5 |  | $ | — |  | $ | 3.2 |  | $ | (2.5 | ) | $ | 13.2 |  | $ | 11.1 |  | $ | 3.8 |  |  |  |
| % Change | 12 | % | — | % | 7 | % | (12 | )% | 7 | % | 18 | % | 6 | % |  |  |

[0000038725-18-000145:8k_2_02:16]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Second Quarter 2018 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 32.3 |  | $ | 18.9 |  | $ | 4.0 |  | $ | (14.7 | ) | $ | 40.5 |  |
| % Operating Income To Net Sales | 15.4 | % | 25.5 | % | 5.0 | % |  | 11.8 | % |
| Restructuring | $ | 0.4 |  | $ | 0.2 |  | $ | — |  | $ | — |  | $ | 0.6 |  |
| Operating Income/(Loss) Before Restructuring | $ | 32.7 |  | $ | 19.1 |  | $ | 4.0 |  | $ | (14.7 | ) | $ | 41.1 |  |
| % Operating Income to Net Sales Before Restructuring | 15.5 | % | 25.8 | % | 5.0 | % |  | 11.9 | % |
|  | For the Second Quarter 2017 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 32.8 |  | $ | 14.9 |  | $ | 3.7 |  | $ | (17.1 | ) | $ | 34.3 |  |
| % Operating Income To Net Sales | 16.5 | % | 24.4 | % | 6.3 | % |  | 11.2 | % |
| Restructuring | $ | 0.3 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.3 |  |
| Operating Income/(Loss) Before Restructuring | $ | 33.1 |  | $ | 14.9 |  | $ | 3.7 |  | $ | (17.1 | ) | $ | 34.6 |  |
| % Operating Income to Net Sales Before Restructuring | 16.7 | % | 24.4 | % | 6.3 | % |  | 11.3 | % |

[0000038725-18-000145:8k_2_02:17]
Water Systems

[0000038725-18-000145:8k_2_02:18]
Water Systems sales were $210.4 million in the second quarter 2018, versus the second quarter 2017 sales of $198.3 million.  Water Systems sales decreased about 1 percent in the quarter due to foreign currency translation. Water Systems organic sales increased about 7 percent compared to the second quarter of 2017.

[0000038725-18-000145:8k_2_02:19]
Water Systems sales in the U.S. and Canada increased by about 13 percent compared to the second quarter 2017. The impact of foreign currency translation increased sales by about 1 percent.  Sales of Pioneer branded dewatering equipment increased by over 70 percent in the second quarter when compared to the prior year due to strength in North American oil and gas markets and continued diversification of product sales channels and geographies. Sales of groundwater pumping equipment increased by about 11 percent on stronger residential and agricultural system sales primarily to the Headwater companies, versus the second quarter 2017. Sales of other surface pumping equipment were flat to the prior year.

[0000038725-18-000145:8k_2_02:20]
Water Systems sales in markets outside the U.S. and Canada grew organically by 1 percent overall. The impact of foreign currency translation decreased sales by about 2 percent.  International Water Systems sales improved in Europe, the Middle East, and Africa, but were offset by lower sales in Asia Pacific and Brazil when compared to the second quarter 2017.   Combined, sales in Asia Pacific and Brazil declined by over 20 percent.  In Asia Pacific, the Company’s sales in Korea declined due to an overall slowdown of the economic environment and strong first quarter sales; and in Thailand, sales were adversely impacted by declines in government funding for water related projects and by weather.  In Brazil, the impact of a prolonged trucking strike in the second quarter significantly hurt the Company’s ability to deliver product to its customers.

[0000038725-18-000145:8k_2_02:21]
Water Systems operating income was $32.3 million in the second quarter 2018, compared to $32.8 million in the second quarter 2017.  The decline in operating income is due to lower revenue in Asia Pacific and Brazil, higher raw material costs, and product sales mix shifts.

[0000038725-18-000145:8k_2_02:22]
Fueling Systems

[0000038725-18-000145:8k_2_02:23]
Fueling Systems sales were $74.1 million in the second quarter 2018, versus the second quarter 2017 sales of $61.0 million.  Fueling System sales increased by about 3 percent due to foreign currency translation. Fueling Systems organic sales were up about 18 percent compared to the second quarter of 2017.

[0000038725-18-000145:8k_2_02:24]
Fueling Systems sales in the U.S. and Canada increased by about 7 percent compared to the second quarter 2017.  The increase was broad based and included numerous product categories including fuel management, pumping, piping and containment systems.  Outside the U.S. and Canada, Fueling Systems revenues grew by about 43 percent, led by stronger sales in China and Europe, partially offset by lower sales in India.

[0000038725-18-000145:8k_2_02:25]
Fueling Systems operating income was $18.9 million in the second quarter of 2018, compared to $14.9 million in the second quarter of 2017.  The increase in operating income is primarily related to higher sales.

[0000038725-18-000145:8k_2_02:26]
Distribution

[0000038725-18-000145:8k_2_02:27]
Distribution sales were $79.5 million in the second quarter 2018, versus second quarter 2017 sales of $59.1 million.  In the second quarter of 2018, sales from businesses acquired since the second quarter of 2017 were $16.6 million.  The Distribution segment organic sales increased about 6 percent compared to the second quarter of 2017.

[0000038725-18-000145:8k_2_02:28]
The Distribution segment operating income was $4.0 million in the second quarter of 2018, compared to $3.7 million in the second quarter of 2017.  The increase in operating income is primarily related to higher sales, partially offset by higher operating expenses.

[0000038725-18-000145:8k_2_02:29]
Overall

[0000038725-18-000145:8k_2_02:30]
The Company’s consolidated gross profit was $116.1 million for the second quarter of 2018, an increase from the second quarter of 2017 gross profit of $102.8 million. The gross profit as a percent of net sales was 33.7 percent in both the second quarters of 2018 and 2017.  The gross profit increase was primarily due to higher sales.

[0000038725-18-000145:8k_2_02:31]
Selling, general, and administrative (SG&A) expenses were $75.0 million in the second quarter of 2018 compared to $68.2 million in the second quarter of the prior year.  The increase in SG&A expenses from acquired businesses was $3.3 million.  Excluding the acquired entities, the Company’s SG&A expenses in the second quarter of 2018 were $71.7 million, an increase of about 5 percent from the second quarter 2017, driven by an increase in research and development spending.

[0000038725-18-000145:8k_2_02:32]
The Company ended the second quarter of 2018 with a cash balance of $70 million, which was $2.8 million higher than at the end of 2017.  The cash balance increase is attributable to higher borrowings and cash generated from operations of about $5 million compared to the first half of the prior year when cash used in operations was about $12 million.

[0000038725-18-000145:8k_2_02:33]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-18-000145:8k_2_02:34]
“As we look forward to the back half of 2018, we remain encouraged by the momentum we have in our North America Water Systems end markets and in the global performance of Fueling Systems.  We expect our 2018 results for both business segments to be above our original expectations and to offset the lower results in the water end markets of Asia Pacific and Brazil.  We believe announced pricing actions will offset estimated inflation and tariffs in the second half of 2018.

[0000038725-18-000145:8k_2_02:35]
Our earnings per share guidance range is unchanged at $2.27 to $2.37.”

[0000038725-18-000145:8k_2_02:36]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The second quarter 2018 earnings call will be available via a live webcast.  The webcast will be available in a listen only mode by going to:

[0000038725-18-000145:8k_2_02:37]
https://edge.media-server.com/m6/p/fbf5vv8m

[0000038725-18-000145:8k_2_02:38]
If you intend to ask questions during the call, please dial in using 877.644.1285 for domestic calls and 914.495.8542 for international calls.  The conference ID is: 9176559.

[0000038725-18-000145:8k_2_02:39]
A replay of the conference call will be available Tuesday, July 24, 2018 at 12:00 noon EDT through noon EDT on Tuesday, July 31, 2018, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 9176559.

[0000038725-18-000145:8k_2_02:40]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-18-000145:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Net sales | $ | 343,970 |  |  | $ | 305,349 |  |  | $ | 639,600 |  |  | $ | 525,601 |  |
| Cost of sales | 227,894 |  |  | 202,596 |  |  | 424,542 |  |  | 347,032 |  |
| Gross profit | 116,076 |  |  | 102,753 |  |  | 215,058 |  |  | 178,569 |  |
| Selling, general, and administrative expenses | 74,965 |  |  | 68,231 |  |  | 151,240 |  |  | 125,227 |  |
| Restructuring expense | 637 |  |  | 251 |  |  | 644 |  |  | 566 |  |
| Operating income | 40,474 |  |  | 34,271 |  |  | 63,174 |  |  | 52,776 |  |
| Interest expense | (2,606 | ) |  | (2,244 | ) |  | (5,034 | ) |  | (5,758 | ) |
| Other income/(expense), net | 45 |  |  | 5,506 |  |  | (159 | ) |  | 6,178 |  |
| Foreign exchange income/(expense) | (999 | ) |  | (372 | ) |  | (1,550 | ) |  | 103 |  |
| Income before income taxes | 36,914 |  |  | 37,161 |  |  | 56,431 |  |  | 53,299 |  |
| Income tax expense | 6,875 |  |  | 6,917 |  |  | 5,177 |  |  | 7,121 |  |
| Net income | $ | 30,039 |  |  | $ | 30,244 |  |  | $ | 51,254 |  |  | $ | 46,178 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | 458 |  |  | (335 | ) |  | 417 |  |  | (539 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 30,497 |  |  | $ | 29,909 |  |  | $ | 51,671 |  |  | $ | 45,639 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.65 |  |  | $ | 0.64 |  |  | $ | 1.10 |  |  | $ | 0.97 |  |
| Diluted | $ | 0.64 |  |  | $ | 0.64 |  |  | $ | 1.09 |  |  | $ | 0.97 |  |

[0000038725-18-000145:8k_2_02:42]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | June 30, 2018 |  | December 31, 2017 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 70,044 |  |  | $ | 67,233 |  |
| Receivables | 206,542 |  |  | 171,007 |  |
| Inventories | 328,632 |  |  | 312,325 |  |
| Other current assets | 34,735 |  |  | 38,566 |  |
| Total current assets | 639,953 |  |  | 589,131 |  |
| Property, plant, and equipment, net | 205,097 |  |  | 215,694 |  |
| Goodwill and other assets | 370,696 |  |  | 380,528 |  |
| Total assets | $ | 1,215,746 |  |  | $ | 1,185,353 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 82,123 |  |  | $ | 79,348 |  |
| Accrued expenses and other current liabilities | 61,152 |  |  | 66,100 |  |
| Current maturities of long-term debt and short-term borrowings | 167,803 |  |  | 100,453 |  |
| Total current liabilities | 311,078 |  |  | 245,901 |  |
| Long-term debt | 94,920 |  |  | 125,596 |  |
| Income taxes payable non-current | 12,971 |  |  | 17,391 |  |
| Deferred income taxes | 25,397 |  |  | 30,913 |  |
| Employee benefit plans | 38,472 |  |  | 42,178 |  |
| Other long-term liabilities | 17,300 |  |  | 19,251 |  |
| Redeemable noncontrolling interest | 764 |  |  | 1,502 |  |
| Total equity | 715,024 |  |  | 702,621 |  |
| Total liabilities and equity | $ | 1,215,746 |  |  | $ | 1,185,353 |  |

[0000038725-18-000145:8k_2_02:43]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
| (In thousands) | June 30, 2018 |  | June 30, 2017 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 51,254 |  |  | $ | 46,178 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 19,595 |  |  | 18,412 |  |
| Share-based compensation | 4,769 |  |  | 4,546 |  |
| Gain on equity investment | — |  |  | (4,788 | ) |
| Other | (3,083 | ) |  | (3,286 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (40,812 | ) |  | (9,289 | ) |
| Inventory | (20,614 | ) |  | (31,792 | ) |
| Accounts payable and accrued expenses | (1,072 | ) |  | (24,712 | ) |
| Income taxes-U.S. Tax Cuts and Jobs Act | (4,600 | ) |  | — |  |
| Other | (268 | ) |  | (7,774 | ) |
| Net cash flows from operating activities | 5,169 |  |  | (12,505 | ) |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (11,446 | ) |  | (18,621 | ) |
| Proceeds from sale of property, plant, and equipment | 306 |  |  | 109 |  |
| Acquisitions and investments | (8,428 | ) |  | (52,255 | ) |
| Other investing activities | 199 |  |  | 153 |  |
| Net cash flows from investing activities | (19,369 | ) |  | (70,614 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 37,333 |  |  | 47,196 |  |
| Proceeds from issuance of common stock | 1,795 |  |  | 2,047 |  |
| Purchases of common stock | (10,953 | ) |  | (2,374 | ) |
| Dividends paid | (10,658 | ) |  | (10,199 | ) |
| Purchase of redeemable non-controlling shares | — |  |  | (5,047 | ) |
| Net cash flows from financing activities | 17,517 |  |  | 31,623 |  |
| Effect of exchange rate changes on cash | (506 | ) |  | 2,260 |  |
| Net change in cash and equivalents | 2,811 |  |  | (49,236 | ) |
| Cash and equivalents at beginning of period | 67,233 |  |  | 104,331 |  |
| Cash and equivalents at end of period | $ | 70,044 |  |  | $ | 55,095 |  |
