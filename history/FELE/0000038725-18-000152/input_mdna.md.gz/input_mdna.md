# FELE MD&A — 0000038725-18-000152


## mdna

[0000038725-18-000152:mdna:1]
[same as prior period, unchanged from 0000038725-18-000096:mdna:1]

[0000038725-18-000152:mdna:2]
Second Quarter 2018 vs. Second Quarter 2017

[0000038725-18-000152:mdna:3]
[same as prior period, unchanged from 0000038725-18-000096:mdna:3]

[0000038725-18-000152:mdna:4]
Sales in the second quarter of 2018 increased from the second quarter last year.  The sales increase was led by acquisition related sales, as well as all three segments experienced sales increases from volume and price.  The impact of foreign currency translation on sales was less than 1 percent. The Company's consolidated gross profit was $116.1 million for the second quarter of 2018, an increase of $13.3 million or about 13 percent from the prior year’s second quarter. Earnings per share in the second quarter of 2018 were flat to the same period last year.

[0000038725-18-000152:mdna:5]
[same as prior period, unchanged from 0000038725-18-000096:mdna:5]

[0000038725-18-000152:mdna:6]
[same as prior period, unchanged from 0000038725-18-000096:mdna:6]

[0000038725-18-000152:mdna:7]
Net sales in the second quarter of 2018 were $344.0 million, an increase of $38.7 million or about 13 percent compared to 2017 second quarter sales of $305.3 million.  Acquisition related sales were $16.6 million. Sales revenue increased by $0.9 million or less than 1 percent in the second quarter of 2018 due to foreign currency translation.

[0000038725-18-000152:mdna:8]
|  | Net Sales |
| (In millions) | Q2 2018 |  | Q2 2017 |  | 2018 v 2017 |
| Water Systems | $ | 210.4 |  |  | $ | 198.3 |  |  | $ | 12.1 |  |
| Fueling Systems | 74.1 |  |  | 61.0 |  |  | 13.1 |  |
| Distribution | 79.5 |  |  | 59.1 |  |  | 20.4 |  |
| Eliminations/Other | (20.0 | ) |  | (13.1 | ) |  | (6.9 | ) |
| Consolidated | $ | 344.0 |  |  | $ | 305.3 |  |  | $ | 38.7 |  |

[0000038725-18-000152:mdna:9]
[same as prior period, unchanged from 0000038725-18-000096:mdna:9]

[0000038725-18-000152:mdna:10]
Water Systems sales were $210.4 million in the second quarter 2018, an increase of $12.1 million or about 6 percent versus the second quarter 2017 sales of $198.3 million. Water Systems sales were reduced by $1.1 million or about 1 percent in the quarter due to foreign currency translation. Excluding foreign currency translation, Water Systems sales were up about 7 percent compared to the second quarter 2017.

[0000038725-18-000152:mdna:11]
Water Systems sales in the U.S. and Canada increased by about 13 percent compared to the second quarter 2017. The impact of foreign currency translation increased sales by about 1 percent.  Sales of Pioneer branded dewatering equipment increased by over 70 percent in the second quarter when compared to the prior year due to strength in North American oil and gas markets and continued diversification of product sales channels and geographies. Sales of groundwater pumping equipment increased by about 11 percent on stronger residential and agricultural system sales primarily to the Headwater business units, versus the second quarter 2017. Sales of other surface pumping equipment were flat to the prior year.

[0000038725-18-000152:mdna:12]
Water Systems sales in markets outside the U.S. and Canada declined by 1 percent overall. The impact of foreign currency translation decreased sales by about 2 percent.  Excluding the impact of foreign currency translation, Water Systems sales in markets outside the U.S. and Canada grew organically by 1 percent.  International Water Systems sales improved in Europe, the Middle East, and Africa by 7 percent due to volume and price, but were offset by lower sales in Asia Pacific and Latin America when compared to the second quarter 2017.   In Asia Pacific, the Company’s sales in Korea declined due to an overall slowdown of the economic environment and strong first quarter sales; and in Thailand, sales were adversely impacted by declines in government funding for water related projects and by weather.  In Brazil, the impact of a prolonged trucking strike in the second quarter significantly hurt the Company’s ability to deliver product to its customers.

[0000038725-18-000152:mdna:13]
[same as prior period, unchanged from 0000038725-18-000096:mdna:13]

[0000038725-18-000152:mdna:14]
Fueling Systems sales were $74.1 million in the second quarter 2018, an increase of $13.1 million or about 21 percent versus the second quarter 2017 sales of $61.0 million. Fueling Systems sales increased by $2.0 million or about 3 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased about 18 percent compared to the second quarter of 2017.

[0000038725-18-000152:mdna:15]
Fueling Systems sales in the U.S. and Canada increased by about 7 percent compared to the second quarter 2017.  The increase was broad based and included numerous product categories including fuel management, pumping, piping and containment systems.  Outside the U.S. and Canada, Fueling Systems revenue grew by about 43 percent, led by stronger sales in China and Europe, partially offset by lower sales in India.  China sales were $12.7 million in the second quarter of 2018 compared to second quarter of 2017 Fueling Systems China sales of $4.3 million.

[0000038725-18-000152:mdna:16]
[same as prior period, unchanged from 0000038725-18-000096:mdna:15]

[0000038725-18-000152:mdna:17]
Distribution sales were $79.5 million in the second quarter 2018, versus second quarter 2017 sales of $59.1 million.  In the second quarter of 2018, sales from businesses acquired since the second quarter of 2017 were $16.6 million.  The Distribution segment organic sales increased about 6 percent compared to the second quarter of 2017.

[0000038725-18-000152:mdna:18]
[same as prior period, unchanged from 0000038725-18-000096:mdna:17]

[0000038725-18-000152:mdna:19]
Cost of sales as a percent of net sales for both the second quarter of 2018 and 2017 was 66.3 percent.  Correspondingly, the gross profit margin was unchanged for both second quarters at 33.7 percent. The Company's consolidated gross profit was $116.1 million for the second quarter of 2018, up $13.3 million from the gross profit of $102.8 million in the second quarter of 2017. The gross profit increase was primarily due to higher sales. In the second quarter, management believes realized selling price increases offset inflation.

[0000038725-18-000152:mdna:20]
[same as prior period, unchanged from 0000038725-18-000096:mdna:19]

[0000038725-18-000152:mdna:21]
Selling, general, and administrative (SG&A) expenses were $75.0 million in the second quarter of 2018 compared to $68.2 million in the second quarter of the prior year.  The increase in SG&A expenses from acquired businesses was $3.3 million.  Excluding the acquired entities, the Company’s SG&A expenses in the second quarter of 2018 were $71.7 million, an increase of about 5 percent from the second quarter 2017, driven by an increase in research, development and engineering spending.

[0000038725-18-000152:mdna:22]
[same as prior period, unchanged from 0000038725-18-000096:mdna:21]

[0000038725-18-000152:mdna:23]
Restructuring expenses for the second quarter of 2018 were $0.6 million, with $0.4 million in the Water segment and $0.2 in Fueling from continued miscellaneous manufacturing realignment activities in North America and India. Restructuring expenses for the second quarter of 2017 were $0.3 million, primarily from continued Brazilian miscellaneous manufacturing realignment activities.

[0000038725-18-000152:mdna:24]
[same as prior period, unchanged from 0000038725-18-000096:mdna:23]

[0000038725-18-000152:mdna:25]
Operating income was $40.5 million in the second quarter of 2018, up $6.2 million or about 18 percent from $34.3 million in the second quarter of 2017.

[0000038725-18-000152:mdna:26]
|  |  | Operating income (loss) |
| (In millions) |  | Q2 2018 |  | Q2 2017 |  | 2018 v 2017 |
| Water Systems |  | $ | 32.3 |  |  | $ | 32.8 |  |  | $ | (0.5 | ) |
| Fueling Systems |  | 18.9 |  |  | 14.9 |  |  | 4.0 |  |
| Distribution |  | 4.0 |  |  | 3.7 |  |  | 0.3 |  |
| Eliminations/Other |  | (14.7 | ) |  | (17.1 | ) |  | 2.4 |  |
| Consolidated |  | $ | 40.5 |  |  | $ | 34.3 |  |  | $ | 6.2 |  |

[0000038725-18-000152:mdna:27]
[same as prior period, unchanged from 0000038725-18-000096:mdna:26]

[0000038725-18-000152:mdna:28]
Water Systems operating income was $32.3 million in the second quarter 2018, down $0.5 million or 2 percent versus the second quarter 2017 and operating income margin was 15.4 percent compared to the 16.5 percent in the second quarter 2017 primarily due to product and geographic sales mix shifts.

[0000038725-18-000152:mdna:29]
[same as prior period, unchanged from 0000038725-18-000096:mdna:28]

[0000038725-18-000152:mdna:30]
Fueling Systems operating income was $18.9 million in the second quarter of 2018, up $4.0 million or about 27 percent compared to $14.9 million in the second quarter of 2017 and the second quarter operating income margin was 25.5 percent, an increase of 110 basis points from the 24.4 percent of net sales in the second quarter of 2017. The increase in operating income was primarily due to leverage on fixed cost from higher sales.

[0000038725-18-000152:mdna:31]
[same as prior period, unchanged from 0000038725-18-000096:mdna:30]

[0000038725-18-000152:mdna:32]
Distribution operating income was $4.0 million in the second quarter of 2018 and the second quarter operating income margin was 5.0 percent.   Distribution operating income was $3.7 million in the second quarter of 2017 and the second quarter

[0000038725-18-000152:mdna:33]
operating income margin was 6.3 percent.  The increase in operating income is primarily related to acquisitions, while the decrease in operating income margin is due to higher SG&A expenses.

[0000038725-18-000152:mdna:34]
[same as prior period, unchanged from 0000038725-18-000096:mdna:32]

[0000038725-18-000152:mdna:35]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the second quarter of 2018 was $0.8 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its customer. General and administrative expenses were higher by $0.1 million or less than 1 percent.

[0000038725-18-000152:mdna:36]
[same as prior period, unchanged from 0000038725-18-000096:mdna:34]

[0000038725-18-000152:mdna:37]
Interest expense for the second quarter of 2018 and 2017 was $2.6 million and $2.2 million, respectively.

[0000038725-18-000152:mdna:38]
[same as prior period, unchanged from 0000038725-18-000096:mdna:36]

[0000038725-18-000152:mdna:39]
Other income or expense was $0 and $5.6 million in the second quarter of 2018 and 2017, respectively. Included in other income in the second quarter of 2018 was interest income of $0.2 million, primarily derived from the investment of cash balances in short-term.  Included in other income in the second quarter of 2017 was a gain of $4.8 million on the previously held equity investments in three Distribution entities acquired in the second quarter 2017. Also, included in other income in the second quarter of 2017 was minority income of $0.1 million and interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-18-000152:mdna:40]
[same as prior period, unchanged from 0000038725-18-000096:mdna:38]

[0000038725-18-000152:mdna:41]
Foreign currency-based transactions produced a loss for the second quarter of 2018 of $1.0 million, primarily due to the Mexican Peso relative to the U.S. dollar.  Foreign currency-based transactions produced a loss for the second quarter of 2017 of $0.3 million, due to movements in several currencies relative to the U.S. dollar, none of which individually were significant.

[0000038725-18-000152:mdna:42]
[same as prior period, unchanged from 0000038725-18-000096:mdna:40]

[0000038725-18-000152:mdna:43]
The provision for income taxes in the second quarter of both 2018 and 2017 was $6.9 million. The effective tax rate for the second quarter of 2018 was about 19 percent and, before the impact of discrete events, was about 21 percent.  The effective tax rate for the second quarter of 2017 was about 19 percent; however, before the impact of discrete events, the tax rate was about 27 percent.  Discrete events in the second quarter 2017 included the tax benefit on the non-taxable gain recorded on the previously held equity investments and the statute expiration on foreign uncertain tax positions. The tax rate as a percentage of pre-tax earnings for the full year of 2018 is projected to be about 20 percent, compared to the full year 2017 tax rate of about 25 percent, both before discrete adjustments.  The decrease in the effective tax rate was primarily affected by the Tax Act, which reduced the U.S. federal corporate income tax rate from 35 percent to 21 percent effective January 1, 2018. The Company has estimated a provisional tax benefit for the full year 2018 of about $3 million associated with the Foreign Derived Intangible Income provisions of the Tax Act that were effective for the first time during 2018.

[0000038725-18-000152:mdna:44]
[same as prior period, unchanged from 0000038725-18-000096:mdna:42]

[0000038725-18-000152:mdna:45]
Net income for the second quarter of 2018 was $30.0 million compared to the prior year second quarter net income of $30.2 million.  Net income attributable to Franklin Electric Co., Inc. for the second quarter of 2018 was $30.5 million, or $0.64 per diluted share, compared to the prior year second quarter net income attributable to Franklin Electric Co., Inc. of $29.9 million or $0.64 per diluted share.

[0000038725-18-000152:mdna:46]
First Half of 2018 vs. First Half of 2017

[0000038725-18-000152:mdna:47]
OVERVIEW

[0000038725-18-000152:mdna:48]
Sales in the first half of 2018 were up from the same period last year.  The sales increase was led by acquisition related sales, as well as volume and price increases from all three segments.  The impact of foreign currency translation increased sales by about 2 percent. The Company's consolidated gross profit was $215.1 million for the first half of 2018, an increase of $36.5 million or about 20 percent from the first half of 2017. Earnings in the first half of 2018 were up from the same period last year.

[0000038725-18-000152:mdna:49]
RESULTS OF OPERATIONS

[0000038725-18-000152:mdna:50]
Net Sales

[0000038725-18-000152:mdna:51]
Net sales in the first half of 2018 were $639.6 million, an increase of $114.0 million or about 22 percent compared to 2017 first half sales of $525.6 million.  The incremental impact of sales from acquired businesses was $72.8 million or 14 percent.  Sales revenue increased by $9.0 million or about 2 percent in the first half of 2018 due to foreign currency translation.

[0000038725-18-000152:mdna:52]
|  | Net Sales |
| (In millions) | YTD June 30, 2018 |  | YTD June 30, 2017 |  | 2018 v 2017 |
| Water Systems | $ | 402.2 |  |  | $ | 365.9 |  |  | $ | 36.3 |  |
| Fueling Systems | 133.5 |  |  | 113.7 |  |  | 19.8 |  |
| Distribution | 135.7 |  |  | 59.1 |  |  | 76.6 |  |
| Eliminations/Other | (31.8 | ) |  | (13.1 | ) |  | (18.7 | ) |
| Consolidated | $ | 639.6 |  |  | $ | 525.6 |  |  | $ | 114.0 |  |

[0000038725-18-000152:mdna:53]
Net Sales-Water Systems

[0000038725-18-000152:mdna:54]
Water Systems sales were $402.2 million in the first half 2018, an increase of $36.3 million or about 10 percent versus the first half 2017. Foreign currency translation changes increased sales $4.9 million, or about 1 percent, compared to sales in the first half of 2017. The Water Systems sales change in the first half of 2018, excluding foreign currency translation, was an increase of $31.4 million or about 9 percent.

[0000038725-18-000152:mdna:55]
Water Systems sales in the U.S. and Canada increased by about 20 percent compared to the first half of 2017. Sales revenue increased by $1.7 million or about 1 percent in the first half of 2018 due to foreign currency translation. In the first half of 2018, sales of Pioneer branded dewatering equipment doubled when compared to the prior year due to strength in North American oil and gas markets and continued diversification of product sales channels and geographies. Sales of groundwater pumping equipment increased by about 19 percent on stronger residential and agricultural system sales primarily to the Headwater companies, versus the first half of 2017.  Sales of other surface pumping equipment increased by 4 percent in part due to wet weather conditions in the upper Midwest and Canada.

[0000038725-18-000152:mdna:56]
Water Systems sales in markets outside the U.S. and Canada increased by about 1 percent compared to the first half of 2017. Sales revenue increased by $3.0 million or about 2 percent in the first half of 2018 due to foreign currency translation. International Water Systems sales improved in Europe, the Middle East and Africa by about 7 percent, but were more than offset by lower sales volumes in Asia Pacific and Brazil in the first half of 2018 compared to last year.  Combined, sales in Latin America and Asia Pacific declined by about 7 percent. In Latin America, the sales decline was primarily in Brazil.  The sales decline in Brazil was due to an overall slowdown of the economic environment and from the impact of a trucking strike that hurt the Company’s ability to deliver product to its customers.  In Asia Pacific, the Company’s sales in Korea declined due to an overall slowdown of the economic environment; and in Thailand, sales were adversely impacted by declines in government funding for water related projects and by weather.

[0000038725-18-000152:mdna:57]
Net Sales-Fueling Systems

[0000038725-18-000152:mdna:58]
Fueling Systems sales were $133.5 million in the first half 2018, an increase of $19.8 million or about 17 percent from the first half of 2017. Foreign currency translation changes increased sales $4.1 million or about 4 percent compared to sales in the first half of 2017. The Fueling Systems sales change in the first half of 2018, excluding foreign currency translation, was an increase of $15.7 million or about 14 percent.

[0000038725-18-000152:mdna:59]
Fueling Systems sales in the U.S. and Canada grew by about 9 percent during the first half with most of the sales growth coming from fuel management systems and piping. Internationally, Fueling Systems revenues grew by about 30 percent led by stronger sales in China and Europe, partially offset by lower sales in India.  China sales were $20.7 million in the first half of 2018 compared to the first half of 2017 Fueling Systems China sales of $8.3 million.

[0000038725-18-000152:mdna:60]
Net Sales-Distribution

[0000038725-18-000152:mdna:61]
Distribution sales were $135.7 million in the first half of 2018, versus the first half of 2017 sales of $59.1 million.  The incremental impact of sales from acquired businesses was $72.8 million.  Distribution segment organic sales increased about 6 percent compared to the first half of 2017.

[0000038725-18-000152:mdna:62]
Cost of Sales

[0000038725-18-000152:mdna:63]
Cost of sales as a percent of net sales for the first half of 2018 and 2017 was 66.4 percent and 66.0 percent, respectively. Correspondingly, the gross profit margin was 33.6 percent and 34.0 percent, respectively. The Company's consolidated gross profit was $215.1 million for the first half of 2018, up $36.5 million from the gross profit of $178.6 million in the first half of 2017. The gross profit increase was primarily due to higher sales.  In the back half of the year, management expects there to be about 250 to 300 basis points of selling price increases, in part from announced pricing actions, and that these price increases will offset projected inflation, including tariffs.

[0000038725-18-000152:mdna:64]
Selling, General, and Administrative (“SG&A”)

[0000038725-18-000152:mdna:65]
Selling, general, and administrative expenses were $151.2 million in the first half of 2018 and increased by $26.0 million or 21 percent in the first half of 2018 compared to $125.2 million the first half of last year. The increase in SG&A expenses from acquired businesses were $21.0 million. Excluding the acquired entities, the Company’s SG&A expenses in the second quarter of 2018 increased by $5.0 million or about 4 percent.

[0000038725-18-000152:mdna:66]
Restructuring Expenses

[0000038725-18-000152:mdna:67]
Restructuring expenses for the first half of 2018 were $0.6 million. Restructuring expenses were $0.4 million in the Water segment and $0.2 in Fueling from continued miscellaneous manufacturing realignment activities. Restructuring expenses for the first half of 2017 were $0.6 million, primarily from continued Brazilian miscellaneous manufacturing realignment activities.

[0000038725-18-000152:mdna:68]
Operating Income

[0000038725-18-000152:mdna:69]
Operating income was $63.2 million in the first half of 2018, up $10.4 million from $52.8 million in the first half

[0000038725-18-000152:mdna:70]
of 2017.

[0000038725-18-000152:mdna:71]
|  |  | Operating income (loss) |
| (In millions) |  | YTD June 30, 2018 |  | YTD June 30, 2017 |  | 2018 v 2017 |
| Water Systems |  | $ | 57.5 |  |  | $ | 54.2 |  |  | $ | 3.3 |  |
| Fueling Systems |  | 32.5 |  |  | 25.9 |  |  | 6.6 |  |
| Distribution |  | 3.2 |  |  | 3.7 |  |  | (0.5 | ) |
| Eliminations/Other |  | (30.0 | ) |  | (31.0 | ) |  | 1.0 |  |
| Consolidated |  | $ | 63.2 |  |  | $ | 52.8 |  |  | $ | 10.4 |  |

[0000038725-18-000152:mdna:72]
Operating Income-Water Systems

[0000038725-18-000152:mdna:73]
Water Systems operating income was $57.5 million in the first half of 2018 compared to $54.2 million in the first half of 2017, an increase of 6 percent. The first half operating income margin was 14.3 percent and decreased by 50 basis points compared to the first half of 2017. Operating income margin decreased in Water Systems primarily due to product and geographic sales mix shifts.

[0000038725-18-000152:mdna:74]
Operating Income-Fueling Systems

[0000038725-18-000152:mdna:75]
Fueling Systems operating income was $32.5 million in the first half of 2018 compared to $25.9 million in the first half of 2017. The first half operating income margin was 24.3 percent compared to 22.8 percent of net sales in the first half of 2017, an increase of 150 basis points due to leverage on fixed cost from higher sales.

[0000038725-18-000152:mdna:76]
Operating Income-Distribution

[0000038725-18-000152:mdna:77]
Distribution operating income was $3.2 million in the first half of 2018 and operating income margin was 2.4 percent. Distribution operating income was $3.7 million in the first half of 2017 and operating income margin was 6.3 percent.  The Distribution segment’s operations are seasonal and product sales are significantly slower during the fourth and first quarters, i.e., the winter months in North America.  The 2017 first half results were not impacted by this seasonality as the acquisitions of the Distribution entities occurred during the second quarter of 2017.

[0000038725-18-000152:mdna:78]
Operating Income-Eliminations/Other

[0000038725-18-000152:mdna:79]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the first half of 2018 was $1.4 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses were higher by $0.9 million or about 3 percent to last year in the first half.

[0000038725-18-000152:mdna:80]
Interest Expense

[0000038725-18-000152:mdna:81]
Interest expense for the first half of 2018 and 2017 was $5.0 million and $5.8 million, respectively.

[0000038725-18-000152:mdna:82]
Other Income or Expense

[0000038725-18-000152:mdna:83]
Other income or expense was a loss of $0.2 million in the first half of 2018. Included in other income in the first half of 2018 was interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities.  The first half of 2017 other income or expense was income of $6.2 million. Included in other income in the first half of 2017 was a gain of $4.8 million on the previously held equity investments in three Distribution entities. Also, included in other income in the first half of 2017 was minority income $0.6 million and interest income of $0.6 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-18-000152:mdna:84]
Foreign Exchange

[0000038725-18-000152:mdna:85]
Foreign currency-based transactions for the first half of 2018 was a loss of $1.6 million due to movements in several currencies relative to the U.S. dollar, with the Mexican Peso and South African Rand being the most significant.  Foreign currency-based transactions for the first half of 2017 was a gain $0.1 million, due to movements in several currencies relative to the U.S. dollar, none of which individually were significant.

[0000038725-18-000152:mdna:86]
Income Taxes

[0000038725-18-000152:mdna:87]
The provision for income taxes in the first half of 2018 and 2017 was $5.2 million and $7.1 million, respectively. The effective tax rate for the first half of 2018 was about 9 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate in the first half of 2017 was about 13 percent and, before the impact of discrete events, was about 27 percent. The Company estimates its effective tax rate for 2018 after discrete events will be 13 to 17 percent, or about 10 points lower than the effective tax rate of 25 percent in 2017.  The lower tax rate before discrete events is primarily the result of the U.S. Tax Cuts and Jobs Act of 2017.  Discrete events in the first half of 2018 include the release of a valuation allowance related to state net operating losses and incentives; and in 2017 included a realized foreign currency translation loss, the release of a valuation allowance related to foreign net operating losses and the recording of a tax benefit on a non-taxable gain recorded on the previously held equity investments.

[0000038725-18-000152:mdna:88]
Net Income

[0000038725-18-000152:mdna:89]
Net income for the first half of 2018 was $51.3 million compared to 2017 first half net income of $46.2 million.  Net income attributable to Franklin Electric Co., Inc. for the first half of 2018 was $51.7 million, or $1.09 per diluted share, compared to 2017 first half net income attributable to Franklin Electric Co., Inc. of $45.6 million or $0.97 per diluted share.

[0000038725-18-000152:mdna:90]
[same as prior period, unchanged from 0000038725-18-000096:mdna:44]

[0000038725-18-000152:mdna:91]
[same as prior period, unchanged from 0000038725-18-000096:mdna:45]

[0000038725-18-000152:mdna:92]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at June 30, 2018 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and exiting credit agreements.

[0000038725-18-000152:mdna:93]
As of June 30, 2018 the Company had $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of June 30, 2018, the Company had $160.6 million borrowing capacity under the Credit Agreement as $5.6 million in letters of commercial and standby letters of credit were outstanding and undrawn and $133.8 million in revolver borrowings were drawn and outstanding which were primarily used for acquisition and working capital needs.

[0000038725-18-000152:mdna:94]
The Company also has other long-term debt borrowing outstanding as of June 30, 2018.  See Note 9 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-18-000152:mdna:95]
At June 30, 2018, the Company had $59.9 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-18-000152:mdna:96]
[same as prior period, unchanged from 0000038725-18-000096:mdna:50]

[0000038725-18-000152:mdna:97]
The following table summarizes significant sources and uses of cash and cash equivalents for the first six months of 2018 and 2017.

[0000038725-18-000152:mdna:98]
| (in millions) |  | 2018 |  | 2017 |
| Net cash provided by (used in) operating activities |  | $ | 5.2 |  |  | $ | (12.5 | ) |
| Net cash used in investing activities |  | (19.4 | ) |  | (70.6 | ) |
| Net cash provided by financing activities |  | 17.5 |  |  | 31.6 |  |
| Impact of exchange rates on cash and cash equivalents |  | (0.5 | ) |  | 2.3 |  |
| Change in cash and cash equivalents |  | $ | 2.8 |  |  | $ | (49.2 | ) |

[0000038725-18-000152:mdna:99]
Cash Flows Provided by (Used in) Operating Activities

[0000038725-18-000152:mdna:100]
[same as prior period, unchanged from 0000038725-18-000096:mdna:54]

[0000038725-18-000152:mdna:101]
Net cash provided by operating activities was $5.2 million for the six months ended June 30, 2018 compared to $12.5 million used in operating activities for the six months ended June 30, 2017.  The increase in cash provided by operating activities was due to an increase in net income of about $5 million, a reduction in other prepaid assets of about $4 million and timing of payments and cash receipts related to working capital which resulted in more cash generated through the first half of 2018 than the same period of the prior year.

[0000038725-18-000152:mdna:102]
[same as prior period, unchanged from 0000038725-18-000096:mdna:56]

[0000038725-18-000152:mdna:103]
[same as prior period, unchanged from 0000038725-18-000096:mdna:57]

[0000038725-18-000152:mdna:104]
Net cash used in investing activities was $19.4 million for the six months ended June 30, 2018 compared to $70.6 million in the six months ended June 30, 2017.  The decrease in cash used in investing activities is primarily attributable to decreased acquisition activity and lower spending for property, plant and equipment during the current year.

[0000038725-18-000152:mdna:105]
Cash Flows Provided by Financing Activities

[0000038725-18-000152:mdna:106]
[same as prior period, unchanged from 0000038725-18-000096:mdna:60]

[0000038725-18-000152:mdna:107]
Net cash provided by financing activities was $17.5 million for the six months ended June 30, 2018 compared to $31.6 million in the six months ended June 30, 2017 .  The overall decrease in cash provided by financing activities was attributable to lower net borrowings of $37 million in the current year compared to approximately $47 million in the prior year along with increased stock repurchases of approximately $9.2 million for the six months ended June 30, 2018.

[0000038725-18-000152:mdna:108]
[same as prior period, unchanged from 0000038725-18-000096:mdna:62]
