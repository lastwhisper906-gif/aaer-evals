# FELE notes — 0000038725-18-000152


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-18-000152:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2017, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2018, and for the second quarters and six months ended June 30, 2018 and June 30, 2017 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the second quarter and six months ended June 30, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2018.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2017.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-18-000152:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-18-000152:notes:3]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2017-07, Compensation - Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  This ASU requires entities to present only the service cost component of net periodic benefit cost as an operating expense (consistent with the presentation of other employee compensation costs).  The other components of net periodic benefit cost are to be presented as a non-operating expense.  The Company adopted ASU 2017-07 during the first quarter ended March 31, 2018. The prior year non-service cost component of net periodic benefit costs as of June 30, 2017 was less than $0.1 million and is not considered significant.  The Company has included current year non-service costs as non-operating expense.  The adoption of this pronouncement did not have a material impact to the Company’s condensed consolidated financial position, results of operations, or cash flows.

[0000038725-18-000152:notes:4]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) as modified by subsequently issued ASUs 2015-14, 2016-08, 2016-10, 2016-12 and 2016-20 (collectively ASU 2014-09).  Topic 606 supersedes the revenue recognition requirements in Accounting Standards Codification (“ASC”) Topic 605, Revenue Recognition (“Topic 605”), and requires the recognition of revenue when promised goods or services are transferred to customers in an amount that reflects the considerations to which the entity expects to be entitled to in exchange for those goods or services.  The Company made the accounting policy election allowed by ASC 606-10-32-2A to continue to present sales tax on a net basis, consistent with current guidance in ASC 605-45-15-2(e).  The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method).  The Company adopted ASU 2014-09 during the first quarter ended March 31, 2018 utilizing the modified retrospective approach. The adoption of this ASU did not have a material impact to the Company’s condensed consolidated financial position, results of operations, or cash flow; however, the adoption of this ASU requires the Company to disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company completed its assessment of the additional disclosure requirements with the following results:

[0000038725-18-000152:notes:5]
Disaggregation of Revenue

[0000038725-18-000152:notes:6]
The adoption of this ASU requires the Company to disaggregate revenue into categories to depict how the nature, timing, and uncertainty of revenue and cash flows are affected by economic factors.  As evidenced in Footnote 14 Segment and Geographic Information, the Company’s business consists of the Water, Fueling, Distribution, and Other segments. The Other segment includes unallocated corporate expenses and intersegment eliminations. A reconciliation of disaggregated revenue to segment revenue as well as Water Segment revenue by geographical regions is provided in Footnote 14, consistent with how the Company evaluates financial performance.

[0000038725-18-000152:notes:7]
Performance Obligations

[0000038725-18-000152:notes:8]
A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in ASC Topic 606.  The Company typically sells its products to customers by purchase order, and does not have any additional performance obligations included in contracts to customers other than the shipment of products. The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience. The Company typically ships products FOB shipping at

[0000038725-18-000152:notes:9]
which point control of the products passes to the customers. Any shipping and handling fees prior to shipment are considered activities required to fulfill the Company’s promise to transfer goods, and do not qualify as a separate performance obligation. Shipping and handling costs are recorded as a component of cost of sales.  Additionally, the Company offers assurance-type warranties (vs. service warranties) which do not qualify as a separate performance obligation. Therefore, the Company allocates the transaction price based on a single performance obligation.  The Company offers normal and customary trade terms to its customers, no significant part of which is of an extended nature.  The Company considers the performance obligation satisfied and recognizes revenue at a point in time, the time of shipment.  The Company does not generally allow for refunds or returns to customers and does not have outstanding performance obligations for contracts with original durations of greater than one year at the end of the reporting period.

[0000038725-18-000152:notes:10]
Contract Costs

[0000038725-18-000152:notes:11]
The Company does not have outstanding contracts with an original term greater than one year; therefore, the Company expenses costs to obtain a contract as incurred.

[0000038725-18-000152:notes:12]
Accounting Standards Issued But Not Yet Adopted

[0000038725-18-000152:notes:13]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 ("Tax Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The ASU is effective for interim and annual periods beginning after December 15, 2018, with early adoption permitted, and may be applied either at the beginning of the period of adoption or retrospectively to each period in which the effect of the change in the U.S. federal corporate income tax rate in the Tax Act is recognized. The Company is currently assessing the impact of the ASU on the Company’s consolidated financial position, results of operations, and cash flows.

[0000038725-18-000152:notes:14]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-18-000152:notes:15]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification (“ASC”) Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company has begun the evaluation process for the adoption of the ASU, and anticipates that the majority of the Company’s outstanding operating leases would be recognized as right-of-use assets and lease liabilities upon adoption, resulting in a significant impact to the Company’s consolidated balance sheets. The Company is implementing a lease accounting software package for lease administration and compliance reporting and is in the process of entering its lease data into this package. The impact of this ASU is non-cash in nature and will not affect the Company’s cash position.  The impact to the Company’s results of operations is still being evaluated.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-18-000152:notes:16]
ACQUISITIONS
During the first quarter ended March 31, 2018, the Company acquired 100 percent of the ownership interests of Lansing, Michigan-based Valley Farms Supply, Inc. ("Valley Farms"), for a purchase price of approximately $9.2 million.  Valley Farms is a professional groundwater distributor operating four locations in the State of Michigan and one in the State of Indiana.  Valley Farms was acquired to serve customers in this region of the United States as part of the Company’s Distribution Segment, which is a collection of professional groundwater equipment distributors.  The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2018, as results of operations for this acquisition is immaterial.

[0000038725-18-000152:notes:17]
[same as prior period, unchanged from 0000038725-18-000096:notes:4]

[0000038725-18-000152:notes:18]
During the second quarter of 2017, the Company acquired controlling interests in three distributors (2M Company, Inc. (“2M”), Drillers Service, Inc. (“DSI”), and Western Hydro, LLC (“Western Hydro”), collectively referred to below as the “Headwater acquisitions”) in the U.S. professional groundwater market for a combined purchase price of approximately $57.4 million, subject to certain terms and conditions.  The Company had previously prepaid a $3.0 million portion of the purchase price at the time of original investment.  The Company funded the Headwater acquisitions with cash on hand and short-term borrowings from the Company’s Revolver (see Note 9 - Debt).  The Headwater acquisitions provide the Company with a professional groundwater distribution channel throughout the United States.

[0000038725-18-000152:notes:19]
[same as prior period, unchanged from 0000038725-18-000096:notes:6]

[0000038725-18-000152:notes:20]
Intangible assets recognized due to the Headwater acquisitions were $5.7 million and consist of customer relationships, which will be amortized utilizing the straight-line method over 15 years.  The fair value of the identifiable intangible assets has been estimated using an income approach, a valuation method that values an intangible asset by discounting the future incremental earnings that may be achieved by the subject intangible asset.

[0000038725-18-000152:notes:21]
The goodwill of $33.9 million resulting from the Headwater acquisitions consists primarily of the benefits of forward channel integration opportunities and broadened product offerings. All of the goodwill was recorded as part of the Distribution segment, and only a portion ($7.8 million) is expected to be deductible for tax purposes.

[0000038725-18-000152:notes:22]
The final purchase price assigned to the major identifiable assets and liabilities for the Headwater acquisitions on an aggregated basis is as follows:

[0000038725-18-000152:notes:23]
[same as prior period, unchanged from 0000038725-18-000096:notes:10]

[0000038725-18-000152:notes:24]
The fair values of the assets acquired and liabilities assumed related to the Headwater acquisitions were final as of June 30, 2018.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation process.

[0000038725-18-000152:notes:25]
The following unaudited proforma financial information for the second quarters and six months ended June 30, 2018 and June 30, 2017 gives effect to the Headwater acquisitions by the Company as if the acquisitions had occurred as of January 1, 2017.  These unaudited proforma condensed consolidated financial statements are prepared for informational purposes only and are not necessarily indicative of actual results or financial position that would have been achieved had the acquisitions been consummated on the dates indicated and are not necessarily indicative of future operating results or financial position of the consolidated companies.  The unaudited proforma condensed consolidated financial statements do not give effect to any cost savings or incremental costs that may result from the integration of the Headwater acquisitions with the Company.

[0000038725-18-000152:notes:26]
| FRANKLIN ELECTRIC CO., INC. |
| PROFORMA CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
|  | Second Quarter Ended |  | Six Months Ended |
| (in millions, except per share amounts) | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Revenue: |  |  |  |  |  |  |  |
| As reported | $ | 344.0 |  |  | $ | 305.3 |  |  | $ | 639.6 |  |  | $ | 525.6 |  |
| Proforma | 344.0 |  |  | 315.2 |  |  | 639.6 |  |  | 585.5 |  |
| Net income: |  |  |  |  |  |  |  |
| As reported | $ | 30.5 |  |  | $ | 29.9 |  |  | $ | 51.7 |  |  | $ | 45.6 |  |
| Proforma | 30.5 |  |  | 30.3 |  |  | 51.7 |  |  | 46.9 |  |
| Basic earnings per share: |  |  |  |  |  |  |  |
| As reported | $ | 0.65 |  |  | $ | 0.64 |  |  | $ | 1.10 |  |  | $ | 0.97 |  |
| Proforma | 0.65 |  |  | 0.65 |  |  | 1.10 |  |  | 1.00 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |
| As reported | $ | 0.64 |  |  | $ | 0.64 |  |  | $ | 1.09 |  |  | $ | 0.97 |  |
| Proforma | 0.64 |  |  | 0.64 |  |  | 1.09 |  |  | 0.99 |  |

[0000038725-18-000152:notes:27]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations.  There were $0.1 million and $0.2 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the second quarter and six months ended June 30, 2018, respectively.  There were $0.1 million and $0.3 million of transactions costs incurred in the second quarter and six months ended June 30, 2017, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-18-000152:notes:28]
FAIR VALUE MEASUREMENTS
FASB ASC Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy.  Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date.  The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value.  The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-18-000152:notes:29]
[same as prior period, unchanged from 0000038725-18-000096:notes:80]

[0000038725-18-000152:notes:30]
[same as prior period, unchanged from 0000038725-18-000096:notes:81]

[0000038725-18-000152:notes:31]
[same as prior period, unchanged from 0000038725-18-000096:notes:82]

[0000038725-18-000152:notes:32]
As of June 30, 2018 and December 31, 2017, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-18-000152:notes:33]
| (In millions) | June 30, 2018 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.0 |  | $ | 3.0 |  | $ | — |  | $ | — |  |
|  | December 31, 2017 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.0 |  | $ | 3.0 |  | $ | — |  | $ | — |  |

[0000038725-18-000152:notes:34]
[same as prior period, unchanged from 0000038725-18-000096:notes:83]

[0000038725-18-000152:notes:35]
[same as prior period, unchanged from 0000038725-18-000096:notes:84]

[0000038725-18-000152:notes:36]
Total debt, including current maturities, have carrying amounts of $262.6 million and $226.0 million and estimated fair values of $264 million and $230 million as of June 30, 2018 and December 31, 2017, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-18-000152:notes:37]
FINANCIAL INSTRUMENTSThe Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of June 30, 2018, the swap had a notional value based on 235,000 shares.  For the second quarter and six months ended June 30, 2018, the swap resulted in a gain of $0.8 million and a loss of $0.3 million, respectively.  For the second quarter and six months ended June 30, 2017, the swap resulted in a loss of $0.4 million and a gain of $0.4 million, respectively.  Gains and losses resulting from the the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-18-000152:notes:38]
GOODWILL AND OTHER INTANGIBLE ASSETS
The carrying amounts of the Company’s intangible assets are as follows:

[0000038725-18-000152:notes:39]
| (In millions) |  | June 30, 2018 |  | December 31, 2017 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.8 | ) |  | $ | 7.5 |  |  | $ | (6.7 | ) |
| Technology |  | 7.5 |  |  | (6.1 | ) |  | 7.5 |  |  | (5.8 | ) |
| Customer relationships |  | 135.6 |  |  | (60.2 | ) |  | 138.9 |  |  | (57.6 | ) |
| Other |  | 2.9 |  |  | (2.5 | ) |  | 2.9 |  |  | (2.4 | ) |
| Total |  | $ | 153.5 |  |  | $ | (75.6 | ) |  | $ | 156.8 |  |  | $ | (72.5 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 45.6 |  |  | — |  |  | 47.2 |  |  | — |  |
| Total intangibles |  | $ | 199.1 |  |  | $ | (75.6 | ) |  | $ | 204.0 |  |  | $ | (72.5 | ) |

[0000038725-18-000152:notes:40]
Amortization expense related to intangible assets for the second quarters ended June 30, 2018 and June 30, 2017 was $2.2 million and 4.3 million for the six months ended June 30, 2018 and June 30, 2017.

[0000038725-18-000152:notes:41]
[same as prior period, unchanged from 0000038725-18-000096:notes:90]

[0000038725-18-000152:notes:42]
| (In millions) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |
|  |  | $ | 8.5 |  |  | $ | 8.4 |  |  | $ | 8.3 |  |  | $ | 7.9 |  |  | $ | 7.7 |  |

[0000038725-18-000152:notes:43]
The change in the carrying amount of goodwill by reportable segment for the six months ended June 30, 2018, is as follows:

[0000038725-18-000152:notes:44]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2017 |  | $ | 139.3 |  |  | $ | 63.6 |  |  | $ | 33.9 |  |  | $ | 236.8 |  |
| Acquisitions |  | — |  |  | — |  |  | 1.5 |  |  | 1.5 |  |
| Foreign currency translation |  | (2.8 | ) |  | (0.1 | ) |  | — |  |  | (2.9 | ) |
| Balance as of June 30, 2018 |  | $ | 136.5 |  |  | $ | 63.5 |  |  | $ | 35.4 |  |  | $ | 235.4 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-18-000152:notes:45]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of June 30, 2018, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2017 measurement date for these plans.  One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-18-000152:notes:46]
[same as prior period, unchanged from 0000038725-18-000096:notes:116]

[0000038725-18-000152:notes:47]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the second quarters and six months ended June 30, 2018 and June 30, 2017:

[0000038725-18-000152:notes:48]
| (In millions) | Pension Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.4 |  |  | $ | 0.3 |  |
| Interest cost | 1.4 |  |  | 1.5 |  |  | 2.7 |  |  | 2.9 |  |
| Expected return on assets | (2.2 | ) |  | (2.3 | ) |  | (4.3 | ) |  | (4.5 | ) |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.8 |  |  | 0.7 |  |  | 1.5 |  |  | 1.3 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.2 |  |  | $ | 0.1 |  |  | $ | 0.3 |  |  | $ | — |  |

[0000038725-18-000152:notes:49]
In the six months ended June 30, 2018, the Company made contributions of $1.1 million to the funded plans.   The amount of contributions to be made to the plans during the calendar year 2018 will be finalized by September 15, 2018, based upon the funding level requirements identified and year-end valuation performed at December 31, 2017.

[0000038725-18-000152:notes:50]
The following table sets fort the aggregated net periodic benefit cost for the post-retirement benefit plan for the second quarters and six months ended June 30, 2018 and June 30, 2017.

[0000038725-18-000152:notes:51]
| (In millions) | Other Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Actuarial loss | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |

[0000038725-18-000152:notes:52]
The Company adopted ASU 2017-07 in the first quarter ended March 31, 2018.  The service cost component of net periodic benefit cost above is recorded in Selling, general, and administrative expenses within the Condensed Consolidated Statements of Income, while the remaining components are recorded to Other income/(expense), net.  The prior year amounts have been reclassified to provide comparable presentation in line with the guidance.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-18-000152:notes:53]
INCOME TAXES
The Company’s effective tax rate from continuing operations for the six month period ended June 30, 2018 was 9.2 percent as compared to 13.4 percent for the six month period ended June 30, 2017. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to the recognition of the foreign-derived intangible income (FDII) provisions in the U.S. Tax Cuts and Jobs Act (Tax Act) and certain discrete events.  For the second quarters of both 2018 and 2017 the effective tax rate was 18.6 percent.

[0000038725-18-000152:notes:54]
The decrease in the effective tax rate for the six months ended June 30, 2018, compared with the same period in 2017, was primarily affected by the Tax Act, which reduced the U.S. federal corporate income tax rate from 35 percent to 21 percent effective January 1, 2018. The Company also reflected an estimated tax benefit of $3 million associated with the FDII provisions of the Tax Act that were effective for the first time during 2018. In addition, during the three month period ended March 31, 2018, the Company released a valuation allowance of $5.4 million related to state NOLs and incentives as it is no longer in a three-year cumulative loss position for certain state income tax purposes.

[0000038725-18-000152:notes:55]
During the second quarter 2018, the Company paid $1.6 million to the one time transition tax liability imposed by the Tax Act, and in accordance with the IRS regulations has applied an estimated $3.0 million of 2017 overpayments.

[0000038725-18-000152:notes:56]
[same as prior period, unchanged from 0000038725-18-000096:notes:97]


## us-gaap:DebtDisclosureTextBlock

[0000038725-18-000152:notes:57]
DEBT
Debt consisted of the following:

[0000038725-18-000152:notes:58]
| (In millions) |  | June 30, 2018 |  | December 31, 2017 |
| Prudential Agreement |  | $ | 30.0 |  |  | $ | 60.0 |  |
| Tax increment financing debt |  | 20.3 |  |  | 20.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 133.8 |  |  | 67.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.8 |  |  | 3.5 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 262.7 |  |  | $ | 226.1 |  |
| Less: current maturities |  | (167.8 | ) |  | (100.5 | ) |
| Long-term debt |  | $ | 94.9 |  |  | $ | 125.6 |  |

[0000038725-18-000152:notes:59]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2018 matures as follows:

[0000038725-18-000152:notes:60]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 262.9 |  |  | $ | 167.8 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 90.0 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 263.0 |  |  | $ | 167.8 |  |  | $ | 1.4 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 90.0 |  |

[0000038725-18-000152:notes:61]
Prudential Agreement

[0000038725-18-000152:notes:62]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of June 30, 2018, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-18-000152:notes:63]
Project Bonds

[0000038725-18-000152:notes:64]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-18-000152:notes:65]
New York Life

[0000038725-18-000152:notes:66]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (2.10 percent as of June 30, 2018) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of June 30, 2018, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-18-000152:notes:67]
Credit Agreement

[0000038725-18-000152:notes:68]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable

[0000038725-18-000152:notes:69]
quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-18-000152:notes:70]
As of June 30, 2018, the Company had $133.8 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $5.6 million in letters of credit outstanding, and $160.6 million of available capacity under the Credit Agreement.

[0000038725-18-000152:notes:71]
Covenants
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2018.


## us-gaap:EarningsPerShareTextBlock

[0000038725-18-000152:notes:72]
EARNINGS PER SHARE
The Company calculates basic and diluted earnings per common share using the two-class method.  Under the two-class method, net earnings are allocated to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company's participating securities consist of share-based payment awards that contain a nonforfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.

[0000038725-18-000152:notes:73]
[same as prior period, unchanged from 0000038725-18-000096:notes:70]

[0000038725-18-000152:notes:74]
[same as prior period, unchanged from 0000038725-18-000096:notes:71]

[0000038725-18-000152:notes:75]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions, except per share amounts) | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 30.5 |  |  | $ | 29.9 |  |  | $ | 51.7 |  |  | $ | 45.6 |  |
| Less: Undistributed earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.4 |  |  | 0.3 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | — |  |  | (0.2 | ) |  | — |  |  | — |  |
| Net income available to common shareholders | $ | 30.3 |  |  | $ | 29.9 |  |  | $ | 51.3 |  |  | $ | 45.3 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.5 |  |  | 46.5 |  |  | 46.5 |  |  | 46.4 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.5 |  |  | 0.5 |  |  | 0.5 |  |  | 0.6 |  |
| Diluted weighted average common shares outstanding | 47.0 |  |  | 47.0 |  |  | 47.0 |  |  | 47.0 |  |
| Basic earnings per share | $ | 0.65 |  |  | $ | 0.64 |  |  | $ | 1.10 |  |  | $ | 0.97 |  |
| Diluted earnings per share | $ | 0.64 |  |  | $ | 0.64 |  |  | $ | 1.09 |  |  | $ | 0.97 |  |

[0000038725-18-000152:notes:76]
There were 0.2 million and 0.4 million stock options outstanding for the second quarters ended June 30, 2018 and June 30, 2017, and 0.2 million and 0.3 million stock options outstanding for the six months ended June 30, 2018 and June 30, 2017, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-18-000152:notes:77]
EQUITY ROLL FORWARD
The schedule below sets forth equity changes in the six months ended June 30, 2018:

[0000038725-18-000152:notes:78]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2017 | $ | 4,663 |  |  | $ | 240,136 |  |  | $ | 604,905 |  |  | $ | (49,364 | ) |  | $ | (99,683 | ) |  | $ | 1,964 |  |  | $ | 702,621 |  |  | $ | 1,502 |  |
| Net income |  |  |  |  | 51,671 |  |  |  |  |  |  | 385 |  |  | 52,056 |  |  | (802 | ) |
| Dividends on common stock |  |  |  |  | (10,658 | ) |  |  |  |  |  |  |  | (10,658 | ) |  |  |
| Common stock issued | 9 |  |  | 1,786 |  |  |  |  |  |  |  |  |  |  | 1,795 |  |  |  |
| Common stock repurchased | (27 | ) |  |  |  | (10,926 | ) |  |  |  |  |  |  |  | (10,953 | ) |  |  |
| Share-based compensation | 9 |  |  | 4,760 |  |  |  |  |  |  |  |  |  |  | 4,769 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (25,782 | ) |  | (23 | ) |  | (25,805 | ) |  | 64 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 1,199 |  |  |  |  |  |  | 1,199 |  |  |  |
| Balance as of June 30, 2018 | $ | 4,654 |  |  | $ | 246,682 |  |  | $ | 634,992 |  |  | $ | (48,165 | ) |  | $ | (125,465 | ) |  | $ | 2,326 |  |  | $ | 715,024 |  |  | $ | 764 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-18-000152:notes:79]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS) 
Changes in accumulated other comprehensive income/(loss) by component for the six months ended June 30, 2018 and June 30, 2017, are summarized below:

[0000038725-18-000152:notes:80]
| (In millions) |  |  |  |  |  |
| For the six months ended June 30, 2018: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2017 | $ | (99.7 | ) |  | $ | (49.3 | ) |  | $ | (149.0 | ) |
| Other comprehensive income/(loss) before reclassifications | (25.8 | ) |  | — |  |  | (25.8 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.2 |  |  | 1.2 |  |
| Net other comprehensive income/(loss) | (25.8 | ) |  | 1.2 |  |  | (24.6 | ) |
| Balance as of June 30, 2018 | $ | (125.5 | ) |  | $ | (48.1 | ) |  | $ | (173.6 | ) |
| For the six months ended June 30, 2017 |  |  |  |  |  |
| Balance as of December 31, 2016 | $ | (118.4 | ) |  | $ | (51.5 | ) |  | $ | (169.9 | ) |
| Other comprehensive income/(loss) before reclassifications | 15.2 |  |  | — |  |  | 15.2 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.0 |  |  | 1.0 |  |
| Net other comprehensive income/(loss) | 15.2 |  |  | 1.0 |  |  | 16.2 |  |
| Balance as of June 30, 2017 | $ | (103.2 | ) |  | $ | (50.5 | ) |  | $ | (153.7 | ) |

[0000038725-18-000152:notes:81]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 7 for additional details) and is included in the "Other income/(expense), net" line of the Company's condensed consolidated statements of income.

[0000038725-18-000152:notes:82]
(2) Net of tax expense of $0.4 million and $0.5 million for the six months ended June 30, 2018 and June 30, 2017, respectively.

[0000038725-18-000152:notes:83]
[same as prior period, unchanged from 0000038725-18-000096:notes:26]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-18-000152:notes:84]
SEGMENT AND GEOGRAPHIC INFORMATION
The accounting policies of the operating segments are the same as those described in Note 1 of the Company's Form 10-K.  Revenue is recognized based on the invoice price at the point in time when the customer obtains control of the product, which is typically upon shipment to the customer.  During the second quarter of 2017, as a result of acquisitions, the Company revised its reportable segments to include a Distribution segment.  The Company realigned its internal and external reporting in accordance with the Company’s revised organization and its review of performance.  The Water and Fueling segments include manufacturing operations and supply certain components and finished goods, both between segments and to the Distribution segment.  In the prior year, the Company reported certain product transfers between Water and Fueling as intersegment revenue.  The Company is now reporting these product transfers between Water and Fueling as inventory transfers as a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes.  The Company continues to report intersegment transfers from Water to Distribution as intersegment revenue at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water and Distribution segments.  Segment operating income is a key financial performance measure. Operating income by segment is based on net sales less identifiable operating expenses and allocations and includes profits recorded on sales to other segments of the Company.  The Company has retrospectively revised segment results in prior periods' to conform with current period presentations.  There is no impact on the Company's previously reported consolidated financial position, results of operations, or cash flows.

[0000038725-18-000152:notes:85]
Financial information by reportable business segment is included in the following summary:

[0000038725-18-000152:notes:86]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions) | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 93.8 |  |  | $ | 87.4 |  |  | $ | 174.6 |  |  | $ | 159.1 |  |
| Latin America | 29.0 |  |  | 31.0 |  |  | 58.1 |  |  | 64.0 |  |
| Europe, Middle East & Africa | 48.5 |  |  | 45.1 |  |  | 97.8 |  |  | 86.5 |  |
| Asia Pacific | 19.1 |  |  | 21.7 |  |  | 39.9 |  |  | 43.2 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 20.0 |  |  | 13.1 |  |  | 31.8 |  |  | 13.1 |  |
| Total sales | 210.4 |  |  | 198.3 |  |  | 402.2 |  |  | 365.9 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |  |  |  |  |
| United States & Canada | 79.5 |  |  | 59.1 |  |  | 135.7 |  |  | 59.1 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 79.5 |  |  | 59.1 |  |  | 135.7 |  |  | 59.1 |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |  |  |  |  |
| United States & Canada | 38.5 |  |  | 36.1 |  |  | 71.3 |  |  | 65.6 |  |
| All other | 35.6 |  |  | 24.9 |  |  | 62.2 |  |  | 48.1 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 74.1 |  |  | 61.0 |  |  | 133.5 |  |  | 113.7 |  |
| Intersegment Eliminations/Other | (20.0 | ) |  | (13.1 | ) |  | (31.8 | ) |  | (13.1 | ) |
| Consolidated | $ | 344.0 |  |  | $ | 305.3 |  |  | $ | 639.6 |  |  | $ | 525.6 |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
|  | Operating income/(loss) |
| Water Systems | $ | 32.3 |  |  | $ | 32.8 |  |  | $ | 57.5 |  |  | $ | 54.2 |  |
| Distribution | 4.0 |  |  | 3.7 |  |  | 3.2 |  |  | 3.7 |  |
| Fueling Systems | 18.9 |  |  | 14.9 |  |  | 32.5 |  |  | 25.9 |  |
| Intersegment Eliminations/Other | (14.7 | ) |  | (17.1 | ) |  | (30.0 | ) |  | (31.0 | ) |
| Consolidated | $ | 40.5 |  |  | $ | 34.3 |  |  | $ | 63.2 |  |  | $ | 52.8 |  |

[0000038725-18-000152:notes:87]
|  | June 30, 2018 |  | December 31, 2017 |
|  | Total assets |
| Water Systems | $ | 685.6 |  |  | $ | 695.4 |  |
| Distribution | 185.7 |  |  | 153.1 |  |
| Fueling Systems | 282.8 |  |  | 265.7 |  |
| Other | 61.6 |  |  | 71.2 |  |
| Consolidated | $ | 1,215.7 |  |  | $ | 1,185.4 |  |

[0000038725-18-000152:notes:88]
[same as prior period, unchanged from 0000038725-18-000096:notes:128]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-18-000152:notes:89]
COMMITMENTS AND CONTINGENCIES
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-18-000152:notes:90]
At June 30, 2018, the Company had $5.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-18-000152:notes:91]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-18-000152:notes:92]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2018, are as follows:

[0000038725-18-000152:notes:93]
| (In millions) |  |  |
| Balance as of December 31, 2017 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 5.0 |  |
| Additions related to acquisitions |  | 0.1 |  |
| Reductions for payments made |  | (5.2 | ) |
| Balance as of June 30, 2018 |  | $ | 9.4 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-18-000152:notes:94]
SHARE-BASED COMPENSATION
The Franklin Electric Co., Inc. 2017 Stock Plan (the "2017 Stock Plan") is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, stock unit awards, and stock appreciation rights ("SARs") to key employees and non-employee directors.  The number of shares that may be issued under the Plan is 1,400,000.  Stock options and SARs reduce the number of available shares by one share for each share subject to the option or SAR, and stock awards and stock unit awards settled in shares reduce the number of available shares by 1.5 shares for every one share delivered.

[0000038725-18-000152:notes:95]
[same as prior period, unchanged from 0000038725-18-000096:notes:47]

[0000038725-18-000152:notes:96]
[same as prior period, unchanged from 0000038725-18-000096:notes:48]

[0000038725-18-000152:notes:97]
[same as prior period, unchanged from 0000038725-18-000096:notes:49]

[0000038725-18-000152:notes:98]
[same as prior period, unchanged from 0000038725-18-000096:notes:50]

[0000038725-18-000152:notes:99]
[same as prior period, unchanged from 0000038725-18-000096:notes:51]

[0000038725-18-000152:notes:100]
[same as prior period, unchanged from 0000038725-18-000096:notes:52]

[0000038725-18-000152:notes:101]
[same as prior period, unchanged from 0000038725-18-000096:notes:53]

[0000038725-18-000152:notes:102]
[same as prior period, unchanged from 0000038725-18-000096:notes:54]

[0000038725-18-000152:notes:103]
[same as prior period, unchanged from 0000038725-18-000096:notes:55]

[0000038725-18-000152:notes:104]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the six months ended June 30, 2018 and June 30, 2017 are as follows:

[0000038725-18-000152:notes:105]
|  |  | June 30, 2018 |  | June 30, 2017 |
| Risk-free interest rate |  | 2.69 | % |  | 1.89 | % |
| Dividend yield |  | 1.05 | % |  | 0.94 | % |
| Volatility factor |  | 28.71 | % |  | 31.19 | % |
| Expected term |  | 5.6 years |  |  | 5.5 years |  |

[0000038725-18-000152:notes:106]
A summary of the Company’s outstanding stock option activity and related information for the six months ended June 30, 2018 is as follows:

[0000038725-18-000152:notes:107]
| (Shares in thousands) |  | June 30, 2018 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,388 |  |  | $ | 28.79 |  |
| Granted |  | 251 |  |  | 40.26 |  |
| Exercised |  | (86 | ) |  | 20.88 |  |
| Forfeited |  | (3 | ) |  | 37.21 |  |
| Outstanding at end of period |  | 1,550 |  |  | $ | 27.26 |  |
| Expected to vest after applying forfeiture rate |  | 1,522 |  |  | $ | 30.92 |  |
| Vested and exercisable at end of period |  | 1,009 |  |  | $ | 27.26 |  |

[0000038725-18-000152:notes:108]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of June 30, 2018 is as follows:

[0000038725-18-000152:notes:109]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.84 years |  | $ | 21,753 |  |
| Expected to vest after applying forfeiture rate |  | 5.78 years |  | $ | 21,588 |  |
| Vested and exercisable at end of period |  | 4.28 years |  | $ | 17,999 |  |

[0000038725-18-000152:notes:110]
The total intrinsic value of options exercised during the six months ended June 30, 2018 and June 30, 2017 was $2.0 million and $1.6 million, respectively.

[0000038725-18-000152:notes:111]
As of June 30, 2018, there was $2.3 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.81 years.

[0000038725-18-000152:notes:112]
[same as prior period, unchanged from 0000038725-18-000096:notes:64]

[0000038725-18-000152:notes:113]
A summary of the Company’s restricted stock/stock unit award activity and related information for the sixth months ended June 30, 2018 is as follows:

[0000038725-18-000152:notes:114]
| (Shares in thousands) |  | June 30, 2018 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 463 |  |  | $ | 36.71 |  |
| Awarded |  | 164 |  |  | 40.48 |  |
| Vested |  | (82 | ) |  | 40.97 |  |
| Forfeited |  | (30 | ) |  | 36.35 |  |
| Non-vested at end of period |  | 515 |  |  | $ | 37.25 |  |

[0000038725-18-000152:notes:115]
As of June 30, 2018, there was $12.1 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.53 years.


## us-gaap:SubsequentEventsTextBlock

[0000038725-18-000152:notes:116]
SUBSEQUENT EVENT

[0000038725-18-000152:notes:117]
On July 30, 2018, the Company entered into the Second Amendment (the “Second Amendment”) to the New York Life Agreement.  The Second Amendment to the New York Life Agreement reinstates the credit facility with an expiration date of July 30, 2021 and increases the maximum aggregate principal borrowing capacity from $150.0 million to $200.0 million.  In addition, on July 30, 2018, the Company entered into Amendment No. 2 (“Amendment No. 2”) to the Prudential Agreement, which extended the term of the facility through July 30, 2021 and increased the total undrawn facility from $100.0 million to $150.0 million.

[0000038725-18-000152:notes:118]
The material terms of the New York Life Agreement and Prudential Agreement are more fully described in Note 9 of this Quarterly Report on Form 10-Q and the foregoing description is qualified in its entirety by reference to the New York Life Agreement and the Prudential Agreement, copies of which are filed as [Exhibits 10.2 - 10.3] hereof and are incorporated herein by reference.
