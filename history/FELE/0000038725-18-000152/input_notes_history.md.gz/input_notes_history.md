# FELE note change history — 0000038725-18-000096 → 0000038725-18-000152


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-07-31):
[0000038725-18-000152:note_history:1]
COMMITMENTS AND CONTINGENCIES
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.
  (was, 2018-05-08, similarity 0.9621):
[0000038725-18-000096:note_history:1]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

- changed (2018-07-31):
[0000038725-18-000152:note_history:2]
At June 30, 2018, the Company had $5.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2018-05-08, similarity 0.9689):
[0000038725-18-000096:note_history:2]
At March 31, 2018, the Company had $6.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2018-07-31):
[0000038725-18-000152:note_history:3]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.
  (was, 2018-05-08, similarity 0.935):
[0000038725-18-000096:note_history:3]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two to five years from date of manufacture or one to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

- changed (2018-07-31):
[0000038725-18-000152:note_history:4]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2018, are as follows:
  (was, 2018-05-08, similarity 0.9118):
[0000038725-18-000096:note_history:4]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2018, are as follows:

- changed (2018-07-31):
[0000038725-18-000152:note_history:5]
| (In millions) |  |  |
| Balance as of December 31, 2017 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 5.0 |  |
| Additions related to acquisitions |  | 0.1 |  |
| Reductions for payments made |  | (5.2 | ) |
| Balance as of June 30, 2018 |  | $ | 9.4 |  |
  (was, 2018-05-08, similarity 0.9816):
[0000038725-18-000096:note_history:5]
| (In millions) |  |  |
| Balance as of December 31, 2017 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 2.0 |  |
| Additions related to acquisitions |  | 0.1 |  |
| Reductions for payments made |  | (2.9 | ) |
| Balance as of March 31, 2018 |  | $ | 8.7 |  |

- removed (2018-07-31):
[0000038725-18-000096:note_history:6]
COMMITMENTS AND CONTINGENCIES


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-07-31):
[0000038725-18-000152:note_history:7]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2017, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2018, and for the second quarters and six months ended June 30, 2018 and June 30, 2017 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the second quarter and six months ended June 30, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2018.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2017.
  (was, 2018-05-08, similarity 0.9268):
[0000038725-18-000096:note_history:7]
The accompanying condensed consolidated balance sheet as of December 31, 2017, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2018, and for the first quarters ended March 31, 2018 and March 31, 2017 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended March 31, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2018.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2017.

- removed (2018-07-31):
[0000038725-18-000096:note_history:8]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-07-31):
[0000038725-18-000152:note_history:9]
DEBT
Debt consisted of the following:
  (was, 2018-05-08, similarity 0.9275):
[0000038725-18-000096:note_history:9]
Debt consisted of the following:

- changed (2018-07-31):
[0000038725-18-000152:note_history:10]
| (In millions) |  | June 30, 2018 |  | December 31, 2017 |
| Prudential Agreement |  | $ | 30.0 |  |  | $ | 60.0 |  |
| Tax increment financing debt |  | 20.3 |  |  | 20.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 133.8 |  |  | 67.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.8 |  |  | 3.5 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 262.7 |  |  | $ | 226.1 |  |
| Less: current maturities |  | (167.8 | ) |  | (100.5 | ) |
| Long-term debt |  | $ | 94.9 |  |  | $ | 125.6 |  |
  (was, 2018-05-08, similarity 0.9907):
[0000038725-18-000096:note_history:10]
| (In millions) |  | March 31, 2018 |  | December 31, 2017 |
| Prudential Agreement |  | $ | 60.0 |  |  | $ | 60.0 |  |
| Tax increment financing debt |  | 20.3 |  |  | 20.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 118.8 |  |  | 67.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.1 |  |  | 3.5 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 278.0 |  |  | $ | 226.1 |  |
| Less: current maturities |  | (152.9 | ) |  | (100.5 | ) |
| Long-term debt |  | $ | 125.1 |  |  | $ | 125.6 |  |

- changed (2018-07-31):
[0000038725-18-000152:note_history:11]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2018 matures as follows:
  (was, 2018-05-08, similarity 0.9514):
[0000038725-18-000096:note_history:11]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2018 matures as follows:

- changed (2018-07-31):
[0000038725-18-000152:note_history:12]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of June 30, 2018, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.
  (was, 2018-05-08, similarity 0.9925):
[0000038725-18-000096:note_history:12]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of March 31, 2018, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.

- changed (2018-07-31):
[0000038725-18-000152:note_history:13]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (2.10 percent as of June 30, 2018) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of June 30, 2018, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.
  (was, 2018-05-08, similarity 0.9851):
[0000038725-18-000096:note_history:13]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (1.88 percent as of March 31, 2018) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of March 31, 2018, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

- changed (2018-07-31):
[0000038725-18-000152:note_history:14]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable
  (was, 2018-05-08, similarity 0.8253):
[0000038725-18-000096:note_history:14]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

- added (2018-07-31):
[0000038725-18-000152:note_history:15]
quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

- changed (2018-07-31):
[0000038725-18-000152:note_history:16]
As of June 30, 2018, the Company had $133.8 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $5.6 million in letters of credit outstanding, and $160.6 million of available capacity under the Credit Agreement.
  (was, 2018-05-08, similarity 0.9817):
[0000038725-18-000096:note_history:16]
As of March 31, 2018, the Company had $118.8 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $5.3 million in letters of credit outstanding, and $175.9 million of available capacity under the Credit Agreement.

- changed (2018-07-31):
[0000038725-18-000152:note_history:17]
Covenants
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2018.
  (was, 2018-05-08, similarity 0.992):
[0000038725-18-000096:note_history:17]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2018.

- removed (2018-07-31):
[0000038725-18-000096:note_history:18]
DEBT

- removed (2018-07-31):
[0000038725-18-000096:note_history:19]
Covenants


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-07-31):
[0000038725-18-000152:note_history:20]
| (In millions) |  | June 30, 2018 |  | December 31, 2017 |
| Prudential Agreement |  | $ | 30.0 |  |  | $ | 60.0 |  |
| Tax increment financing debt |  | 20.3 |  |  | 20.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 133.8 |  |  | 67.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.8 |  |  | 3.5 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 262.7 |  |  | $ | 226.1 |  |
| Less: current maturities |  | (167.8 | ) |  | (100.5 | ) |
| Long-term debt |  | $ | 94.9 |  |  | $ | 125.6 |  |
  (was, 2018-05-08, similarity 0.9907):
[0000038725-18-000096:note_history:20]
| (In millions) |  | March 31, 2018 |  | December 31, 2017 |
| Prudential Agreement |  | $ | 60.0 |  |  | $ | 60.0 |  |
| Tax increment financing debt |  | 20.3 |  |  | 20.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 118.8 |  |  | 67.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.1 |  |  | 3.5 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 278.0 |  |  | $ | 226.1 |  |
| Less: current maturities |  | (152.9 | ) |  | (100.5 | ) |
| Long-term debt |  | $ | 125.1 |  |  | $ | 125.6 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-07-31):
[0000038725-18-000152:note_history:21]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2018 matures as follows:
  (was, 2018-05-08, similarity 0.9514):
[0000038725-18-000096:note_history:21]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2018 matures as follows:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2018-07-31):
[0000038725-18-000152:note_history:22]
SUBSEQUENT EVENT

- added (2018-07-31):
[0000038725-18-000152:note_history:23]
On July 30, 2018, the Company entered into the Second Amendment (the “Second Amendment”) to the New York Life Agreement.  The Second Amendment to the New York Life Agreement reinstates the credit facility with an expiration date of July 30, 2021 and increases the maximum aggregate principal borrowing capacity from $150.0 million to $200.0 million.  In addition, on July 30, 2018, the Company entered into Amendment No. 2 (“Amendment No. 2”) to the Prudential Agreement, which extended the term of the facility through July 30, 2021 and increased the total undrawn facility from $100.0 million to $150.0 million.

- added (2018-07-31):
[0000038725-18-000152:note_history:24]
The material terms of the New York Life Agreement and Prudential Agreement are more fully described in Note 9 of this Quarterly Report on Form 10-Q and the foregoing description is qualified in its entirety by reference to the New York Life Agreement and the Prudential Agreement, copies of which are filed as [Exhibits 10.2 - 10.3] hereof and are incorporated herein by reference.
