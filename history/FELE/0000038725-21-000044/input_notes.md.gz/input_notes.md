# FELE notes — 0000038725-21-000044


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000038725-21-000044:notes:1]
A portion of the Proxy Statement for the Annual Meeting of Shareholders to be held on May 7, 2021 (Part III).


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000038725-21-000044:notes:2]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Company--“Franklin Electric” or the “Company” shall refer to Franklin Electric Co., Inc. and its consolidated subsidiaries.

[0000038725-21-000044:notes:3]
Fiscal Year--The financial statements and accompanying notes are as of and for the years ended December 31, 2020, December 31, 2019, and December 31, 2018, and referred to as 2020, 2019, and 2018, respectively.

[0000038725-21-000044:notes:4]
Principles of Consolidation--The consolidated financial statements include the accounts of Franklin Electric Co., Inc. and its consolidated subsidiaries. All intercompany transactions have been eliminated.

[0000038725-21-000044:notes:5]
Business Combinations--The Company allocates the purchase price of its acquisitions to the assets acquired, liabilities assumed, and noncontrolling interests based upon their respective fair values at the acquisition date. The Company utilizes management estimates and inputs from an independent third-party valuation firm to assist in determining these fair values. The excess of the acquisition price over estimated fair values is recorded as goodwill. Goodwill is adjusted for any changes to acquisition date fair value amounts made within the measurement period. Any estimated fair values in excess of the acquisition price represents a bargain purchase gain and is recorded in accrued expenses and other current liabilities on the consolidated balance sheet until the determination of fair values is completed. Acquisition-related transaction costs are recognized separately from the business combination and expensed as incurred.

[0000038725-21-000044:notes:6]
Revenue Recognition--Revenue is recognized when promised goods or services are transferred to customers in an amount that reflects the consideration to which the entity expects to be entitled to in exchange for those goods or services. The promise in a contract to transfer goods or services to a customer represents a performance obligation. The Company typically sells its products to customers by purchase order and does not have any additional performance obligations included in contracts to customers other than the shipment of the products. Therefore, the Company allocates the transaction price based on a single performance obligation. The Company typically ships products FOB shipping at which point control of the products passes to the customers. The Company considers the performance obligation satisfied and recognizes revenue at a point in time, the time of shipment.

[0000038725-21-000044:notes:7]
The Company’s products may include routine assurance-type warranties which do not qualify as separate performance obligations. In the event that significant post-shipment obligations were to exist for the Company’s products, revenue recognition would be deferred until the performance obligations were satisfied.

[0000038725-21-000044:notes:8]
The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience.

[0000038725-21-000044:notes:9]
Shipping and Handling Costs--Shipping and handling costs are considered activities required to fulfill the Company’s promise to transfer goods, and do not qualify as a separate performance obligation. Shipping and handling costs are recorded as a component of cost of sales.

[0000038725-21-000044:notes:10]
Research and Development Expense--The Company’s research and development activities are charged to expense in the period incurred. The Company incurred expenses of approximately $21.7 million in 2020, $20.8 million in 2019, and $22.1 million in 2018 related to research and development.

[0000038725-21-000044:notes:11]
Cash and Cash Equivalents--The Company considers cash on hand, demand deposits, and highly liquid investments with an original maturity date of three months or less to be cash and cash equivalents.

[0000038725-21-000044:notes:12]
Fair Value of Financial Instruments--Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value. The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-21-000044:notes:13]
Level 1 – Quoted prices for identical assets and liabilities in active markets;

[0000038725-21-000044:notes:14]
Level 2 – Quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets; and

[0000038725-21-000044:notes:15]
Level 3 – Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable.

[0000038725-21-000044:notes:16]
Accounts Receivable, Earned Discounts, and Allowance for Uncollectible Accounts--Accounts receivable are stated at estimated net realizable value. Accounts receivable are comprised of balances due from customers, net of earned discounts and estimated allowances for uncollectible accounts. Earned discounts are based on specific customer agreement terms. In determining allowances for uncollectible accounts, historical collection experience, current trends, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are reviewed.

[0000038725-21-000044:notes:17]
Inventories--Inventories are stated at the lower of cost or market. The majority of the cost of domestic and foreign inventories is determined using the FIFO method with a portion of inventory costs determined using the average cost method. The Company reviews its inventories for excess or obsolete products or components based on an analysis of historical usage and management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts.

[0000038725-21-000044:notes:18]
Property, Plant, and Equipment--Property, plant, and equipment are stated at historical cost. The Company capitalizes certain computer software and software development costs incurred in connection with developing or obtaining computer software for internal use, which are included in property, plant, and equipment. Depreciation of plant and equipment is calculated on a straight line basis over the following estimated useful lives:

[0000038725-21-000044:notes:19]
| Land improvement and buildings | 10 - 40 years |
| Machinery and equipment | 5 - 10 years |
| Software | 3 - 7 years |
| Furniture and fixtures | 3 - 7 years |

[0000038725-21-000044:notes:20]
Maintenance, repairs, and renewals of a minor nature are expensed as incurred. Betterments and major renewals which extend the useful lives or add to the productive capacity of buildings, improvements, and equipment are capitalized. The Company reviews its property, plant, and equipment for impairment at the asset group level whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. If an indicator is present, the Company compares carrying values to undiscounted future cash flows; if the undiscounted future cash flows are less than the carrying value, an impairment would be recognized for the difference between the fair value and the carrying value.

[0000038725-21-000044:notes:21]
The Company’s depreciation expense was $27.1 million, $27.6 million, and $29.7 million in 2020, 2019, and 2018, respectively.

[0000038725-21-000044:notes:22]
Leases--The Company determines if an arrangement is a lease, or contains a lease, at the inception of the arrangement and determines whether it is an operating or financing lease. Operating and financing leases result in the Company recording a right-of-use (ROU) asset, current lease liability, and long term lease liability on its balance sheet. The Company has elected to not present leases with an initial term of 12 months or less on the balance sheet. The ROU assets and liabilities are initially recognized based on the present value of lease payments over the lease term. Initial direct costs and lease incentives are not material when measuring the ROU asset present value. Lease expense for operating lease payments is recognized on a straight-line basis over the lease term.

[0000038725-21-000044:notes:23]
In determining the present value, the Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the Company’s borrowing information available at inception. A portion of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised. In addition, the Company has elected not to separate non-lease components from lease components.

[0000038725-21-000044:notes:24]
Goodwill and Other Intangible Assets--Goodwill is tested at the reporting unit level, which the Company has determined to be the Global Water Systems, Fueling Systems, and Distribution units.

[0000038725-21-000044:notes:25]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the income and market valuation approaches. The income approach estimates fair value based upon future revenue, expenses, and cash flows discounted to present value. The market valuation approach estimates fair value using market multipliers of various financial measures compared to a set of comparable public companies. The fair value calculated for each reporting unit is considered a Level 3 measurement within the fair value hierarchy. An indication of impairment exists if the carrying value of the reporting unit is higher than its fair value, as determined by the above approach. The Company will test goodwill for impairment more frequently if warranted by triggering events that indicate potential impairment. The Company completed its annual goodwill impairment test during the fourth quarter, using balances as of October 1.

[0000038725-21-000044:notes:26]
The Company also tests indefinite lived intangible assets, primarily trade names, for impairment on an annual basis during the fourth quarter of each year, using balances as of October 1, or more frequently as warranted by triggering events that indicate potential impairment. In assessing the recoverability of the trade names, the Company determines the fair value using an income approach. The income approach estimates fair value based upon future revenue and estimated royalty rates. The fair value calculated for indefinite lived intangible assets is considered a Level 3 measurement within the fair value hierarchy. An indication of impairment exists if the carrying value of the trade names is higher than the fair value. The Company would record an impairment charge for the difference.

[0000038725-21-000044:notes:27]
Amortization is recorded and calculated for other definite lived intangible assets on a basis that reflects cash flows over the estimated useful lives. The weighted average number of years over which each intangible class is amortized is as follows:

[0000038725-21-000044:notes:28]
| Patents | 17 years |
| Technology | 15 years |
| Customer relationships | 13 - 20 years |
| Other | 5 - 8 years |

[0000038725-21-000044:notes:29]
Warranty Obligations--The Company provides warranties on most of its products. The warranty terms vary but are generally 2 years to 5 years from date of manufacture or 1 year to 5 years from date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims. The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-21-000044:notes:30]
Income Taxes--Income taxes are accounted for in accordance with FASB ASC Topic 740, Income Taxes. Under this guidance, deferred tax assets and liabilities are determined based on the difference between the financial statement and tax basis of assets and liabilities and net operating loss and credit carry forwards using enacted tax rates in effect for the year in which the differences are expected to reverse. Valuation allowances are established when necessary to reduce deferred tax assets to the amounts expected to be realized. The Company records a liability for uncertain tax positions by establishing a recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return.

[0000038725-21-000044:notes:31]
Defined Benefit Plans--The Company makes its determination for pension, post retirement, and post employment benefit plans liabilities based on management estimates and consultation with actuaries. The Company incorporates estimates and assumptions of future plan service costs, future interest costs on projected benefit obligations, rates of compensation increases, employee turnover rates, anticipated mortality rates, expected investment returns on plan assets, asset allocation assumptions of plan assets, and other factors.

[0000038725-21-000044:notes:32]
Earnings Per Common Share--Basic and diluted earnings per share are computed and disclosed in accordance with FASB ASC Topic 260, Earnings Per Share. The Company utilizes the two-class method to compute earnings available to common shareholders. Under the two-class method, earnings are adjusted by accretion amounts to redeemable noncontrolling interests recorded at redemption value. The adjustments represent dividend distributions, in substance, to the noncontrolling interest holder as the holders have contractual rights to receive an amount upon redemption other than the fair value of the applicable shares. As a result, earnings are adjusted to reflect this in substance distribution that is different from other common shareholders. In addition, the Company allocates net earnings to each class of common stock and participating security as if all of the net earnings for the period had been distributed. The Company’s participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders. Basic earnings per common share excludes dilution and is calculated by dividing net

[0000038725-21-000044:notes:33]
earnings allocated to common shares by the weighted-average number of common shares outstanding for the period. Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-21-000044:notes:34]
Translation of Foreign Currency Financial Statements--All assets and liabilities of foreign subsidiaries in functional currency other than the U.S. dollar are translated at year end exchange rates with the exception of the non-monetary assets and liabilities in countries with highly inflationary economies, which are translated at historical exchange rates. All revenue and expense accounts are translated at average rates in effect during the respective period with the exception of expenses related to the non-monetary assets and liabilities, which are translated at historical exchange rates. Adjustments for translating longer term foreign currency assets and liabilities in U.S. dollars are included as a component of other comprehensive income except for hyperinflation accounting adjustments. Transaction gains and losses that arise from shorter term exchange rate fluctuations and hyperinflation accounting adjustments are included in the “Foreign exchange income/(expense)” line within the Company’s consolidated statements of income, as incurred.

[0000038725-21-000044:notes:35]
Significant Estimates--The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make significant estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of expenses during the reporting periods. Significant estimates and assumptions by management affect inventory valuation, warranty, trade names and goodwill, income taxes, and pension and employee benefit obligations.

[0000038725-21-000044:notes:36]
Although the Company regularly assesses these estimates, actual results could materially differ. The Company bases its estimates on historical experience and various other assumptions that it believes to be reasonable under the circumstances.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-21-000044:notes:37]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-21-000044:notes:38]
In August 2018, the FASB issued Accounting Standards Update ("ASU") 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which modifies the disclosure requirements for employers that sponsor defined benefit pension or other postretirement plans. The amendments remove disclosures that no longer are considered cost beneficial, including the estimated amounts in accumulated other comprehensive income expected to be recognized as components of net periodic expense over the next fiscal year. The amendments clarify the specific requirements of disclosures, and add disclosure requirements identified as relevant, including the reasons for significant gains and losses related to change in the benefit obligation for the period. The ASU should be applied retrospectively and is effective for interim and annual periods beginning after December 15, 2020. The Company adopted the standard in the fourth quarter of 2020, and it did not have a material impact on the consolidated financial position, results of operation, and cash flows.

[0000038725-21-000044:notes:39]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value. The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted. The Company adopted the standard effective January 1, 2020. The standard did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-21-000044:notes:40]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which modifies the measurement of expected credit losses on certain financial instruments, including trade receivables. ASU 2016-13 is effective for interim and annual periods beginning after December 15, 2019 with early adoption permitted. Amendments should be applied using a modified retrospective approach except for debt securities, which require a prospective transitions approach. The Company adopted the standard effective January 1, 2020. The standard did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-21-000044:notes:41]
Accounting Standards Issued But Not Yet Adopted

[0000038725-21-000044:notes:42]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is expected to reduce cost and complexity related to accounting for income taxes. ASU 2019-12 eliminates the need for the Company to analyze whether certain exceptions apply and improves financial statement preparers' application of income tax-related guidance. ASU 2019-12 is effective for interim and annual periods beginning after December 15, 2020 with early adoption permitted. Amendments related to franchise taxes that are partially based on income should be applied on either a retrospective or modified retrospective basis. All other amendments should be applied on a prospective basis. The Company will adopt this standard effective January 1, 2021. Adoption is not expected to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.
In August 2020, the FASB issued ASU 2020-06, Debt – Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging – Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity. ASU 2020-06 reduces the number of accounting models for various convertible instruments and reduces form-over-substance-based accounting conclusions for the derivatives scope exception for contracts in an entity’s own equity. The FASB also updated Earnings Per Share (“EPS”) guidance under Topic 260 by requiring an entity to consider the potential effect of share settlement in the diluted EPS calculation for instruments that may be settled in cash or shares as well as other amendments. ASU 2020-06 is effective for interim and annual periods beginning after December 15, 2021 with early adoption permitted but no earlier than fiscal years beginning after December 15, 2020. The guidance should be adopted at the beginning of a fiscal year. ASU 2020-06 should be applied on either a retrospective or modified retrospective basis. The Company is still determining the date of adoption, but does not expect the ASU to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-21-000044:notes:43]
ACQUISITIONS
During the fourth quarter ended December 31, 2020, the Company acquired 100 percent of the ownership interests of Gicon Pumps & Equipment, Inc., a professional groundwater distributor operating seven locations in the state of Texas for a purchase price of $28.1 million after working capital adjustments. The Company's preliminary estimate of fair values exceeds the acquisition price by $5.3 million, representing a bargain purchase gain due to favorable market conditions. The Company has recorded the gain within accrued expenses and other current liabilities in the consolidated balance sheets. Once the determination of fair values is complete in 2021, the Company will recognize the bargain purchase gain in the consolidated statements of income. In a separate transaction during the fourth quarter ended December 31, 2020, the Company acquired 100 percent of the ownership interests in Waterite Inc. and its affiliate Waterite America Inc., headquartered in Winnipeg, Manitoba, Canada, for a purchase price of $22.0 million after working capital adjustments. The fair value of the assets acquired and liabilities assumed for both acquisitions are preliminary as of December 31, 2020 and is classified as Level 3 within the valuation hierarchy. In addition, the Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for both acquisitions is immaterial.

[0000038725-21-000044:notes:44]
During the first quarter ended March 31, 2020, the Company acquired all of the assets of a company that manufactures line shaft turbines and other adjacent product lines for a purchase price of $5.9 million after working capital adjustments. The fair value of the assets acquired and liabilities assumed are preliminary as of December 31, 2020 and is classified as Level 3 within the valuation hierarchy. In addition, the Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for this acquisition is immaterial.

[0000038725-21-000044:notes:45]
The identifiable intangible assets recognized in the separate transactions in 2020 were $14.8 million, and consist primarily of customer relationships, which will be amortized utilizing the straight-line method over 15 - 20 years.

[0000038725-21-000044:notes:46]
The goodwill of $10.3 million resulting from the separate acquisitions in 2020 consists primarily of the benefits of complementary product offerings and expanded geographical presence. Goodwill was recorded in the Water segment (see Note 6 - Goodwill and Other Intangible Assets), and only a portion ($1.4 million) is expected to be deductible for tax purposes.

[0000038725-21-000044:notes:47]
During the third quarter ended September 30, 2019, the Company acquired 100 percent of the ownership interests of First Sales, LLC, an Indiana manufacturer of water treatment and filtration equipment for the residential and commercial markets, which are sold through some of the same channels as other Company products in the Water Systems segment, for a purchase price of approximately $15.5 million after working capital adjustments. Goodwill resulting from the acquisition consists primarily of complementary product offerings. The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2019, as the results of operations for this acquisition is immaterial. The fair value of the assets acquired and liabilities assumed were considered final as of September 30, 2020.

[0000038725-21-000044:notes:48]
During the second quarter ended June 30, 2019, the Company acquired the remaining interest in Pluga Pumps and Motors Private Limited, India, increasing the Company's ownership to 100 percent. The redemption of this interest was immaterial.

[0000038725-21-000044:notes:49]
During the first quarter ended March 31, 2019, the Company acquired 100 percent of the ownership interests of Mt. Pleasant, Michigan-based Milan Supply Company ("Milan Supply"), for a purchase price of approximately $6.1 million after working capital adjustments. Milan Supply is a professional groundwater distributor operating six locations in the State of Michigan. Milan Supply is part of the Company’s Distribution Segment, which is a collection of professional groundwater equipment distributors. The Company has not presented separate results of operations since closing or combined pro forma financial

[0000038725-21-000044:notes:50]
information of the Company and the acquired interest since the beginning of 2019, as the results of operations for this acquisition is immaterial. The fair value of the assets acquired and the liabilities assumed for the acquisition were considered final as of March 31, 2020.

[0000038725-21-000044:notes:51]
During the third quarter ended September 30, 2018, the Company acquired, in separate transactions, substantially all of the assets of the Stationary Power Division (“SPD”) of Midtronics, Inc., and 100 percent of the ownership interest in Industrias Rotor Pump S.A. (“Industrias Rotor Pump”), located in the United States and Argentina, respectively. Neither of the acquisitions were material individually or in the aggregate, and the final combined purchase price was $37.0 million. SPD offers a variety of products to users in the electrical substation monitoring, data center and mobile telecommunications markets. Industrias Rotor Pump is the leading provider of water pumping equipment in Argentina.

[0000038725-21-000044:notes:52]
Prior to the acquisition of the Argentina entity the economy in Argentina was classified as highly inflationary. Beginning from the date of acquisition, the Company will apply the requisite accounting for highly inflationary economies, and the functional currency of the entity will be the U.S. dollar. Monetary assets and liabilities will be remeasured into U.S. dollars using exchange rates as of the latest balance sheet date while non-monetary assets and liabilities will be remeasured using historical exchange rates. Remeasurement adjustments will be included in foreign exchange gain / (loss) on the consolidated statements of income.

[0000038725-21-000044:notes:53]
During the first quarter ended March 31, 2018, the Company acquired 100 percent of the ownership interests of Lansing, Michigan-based Valley Farms Supply, Inc. ("Valley Farms"). The fair value of assets acquired and liabilities assumed were considered final in the first quarter of 2019, and the final purchase price was $9.5 million after working capital adjustments. Valley Farms is a professional groundwater distributor operating four locations in the State of Michigan and one in the State of Indiana. Valley Farms was acquired to serve customers in this region of the United States as part of the Company’s Distribution Segment, which is a collection of professional groundwater equipment distributors. The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2018, as the results of operations for this acquisition is immaterial.

[0000038725-21-000044:notes:54]
Transaction costs for all acquisition related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations. Transaction costs are included in selling, general, and administrative expense in the Company’s consolidated statements of income were $0.0 million, $0.2 million, and $0.4 million for the years ended 2020, 2019, and 2018, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-21-000044:notes:55]
FAIR VALUE MEASUREMENTS
As of December 31, 2020 and December 31, 2019, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-21-000044:notes:56]
| (In millions) |  | December 31, 2020 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 20.2 |  |  | $ | 20.2 |  |  | $ | — |  |  | $ | — |  |  |
|  |  | December 31, 2019 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |  |

[0000038725-21-000044:notes:57]
The Company’s Level 1 assets consist of cash equivalents which are generally comprised of foreign bank guaranteed certificates of deposit.

[0000038725-21-000044:notes:58]
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3 excluding the recurring fair value measurements in the Company's pension and other retirement plans as discussed in Note 7 - Employee Benefit Plans.

[0000038725-21-000044:notes:59]
Total debt, including current maturities, have carrying amounts of $94.6 million at December 31, 2020 and $115.0 million at December 31, 2019. The estimated fair value of all debt was $107.3 million and $121.0 million at December 31, 2020 and December 31, 2019, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a 
current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-21-000044:notes:60]
FINANCIAL INSTRUMENTSThe Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (“the swap”) to mitigate the Company’s exposure to these fluctuations in the Company’s stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party. As of December 31, 2020, the swap has a notional value based on 280,000 shares. For the years ended December 31, 2020, December 31, 2019, and December 31, 2018, the swap resulted in a gain of $3.2 million, a gain of $3.4 million, and a loss of $1.0 million, respectively. Gains and losses resulting from the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company’s consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-21-000044:notes:61]
GOODWILL AND OTHER INTANGIBLE ASSETS
The carrying amounts of the Company’s intangible assets are as follows:

[0000038725-21-000044:notes:62]
| (In millions) |  | 2020 |  | 2019 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (7.3) |  |  | $ | 7.4 |  |  | $ | (7.0) |  |
| Technology |  | 7.5 |  |  | (7.2) |  |  | 7.5 |  |  | (6.8) |  |
| Customer relationships |  | 165.1 |  |  | (78.5) |  |  | 155.4 |  |  | (71.4) |  |
| Other |  | 6.3 |  |  | (3.0) |  |  | 3.8 |  |  | (2.8) |  |
| Total |  | $ | 186.4 |  |  | $ | (96.0) |  |  | $ | 174.1 |  |  | $ | (88.0) |  |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 43.4 |  |  | — |  |  | 45.0 |  |  | — |  |
| Total intangibles |  | $ | 229.8 |  |  | $ | (96.0) |  |  | $ | 219.1 |  |  | $ | (88.0) |  |

[0000038725-21-000044:notes:63]
Amortization expense related to intangible assets for fiscal years 2020, 2019, and 2018, was $9.4 million, $9.4 million, and $8.9 million, respectively.

[0000038725-21-000044:notes:64]
Amortization expense for each of the five succeeding years is projected as follows:

[0000038725-21-000044:notes:65]
| (In millions) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |
|  |  | $ | 9.9 |  |  | $ | 9.7 |  |  | $ | 9.6 |  |  | $ | 9.4 |  |  | $ | 8.5 |  |

[0000038725-21-000044:notes:66]
The change in the carrying amount of goodwill by reportable segment for 2020 and 2019, is as follows:

[0000038725-21-000044:notes:67]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2018 |  | $ | 145.5 |  |  | $ | 67.5 |  |  | $ | 35.7 |  |  | $ | 248.7 |  |
| Acquisitions |  | 6.4 |  |  | — |  |  | 1.8 |  |  | 8.2 |  |
| Foreign currency translation |  | (0.9) |  |  | 0.1 |  |  | — |  |  | (0.8) |  |
| Balance as of December 31, 2019 |  | $ | 151.0 |  |  | $ | 67.6 |  |  | $ | 37.5 |  |  | $ | 256.1 |  |
| Acquisitions |  | 10.3 |  |  | — |  |  | — |  |  | 10.3 |  |
| Foreign currency translation |  | 0.2 |  |  | 0.1 |  |  | — |  |  | 0.3 |  |
| Balance as of December 31, 2020 |  | $ | 161.5 |  |  | $ | 67.7 |  |  | 37.5 |  |  | $ | 266.7 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-21-000044:notes:68]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of December 31, 2020, the Company maintained two domestic pension plans and three German pension plans. The Company used a December 31, 2020 measurement date for these plans. One of the Company’s domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011). The two domestic and three German plans collectively comprise the ‘Pension Benefits’ disclosure caption.

[0000038725-21-000044:notes:69]
Other Benefits - The Company’s other post-retirement benefit plan provides health and life insurance to domestic employees hired prior to 1992. The Company effectively capped its cost for those benefits through plan amendments made in 1992, freezing Company contributions for insurance benefits at 1991 levels for current and future beneficiaries with actuarially reduced benefits for employees who retire before age 65. The disclosures surrounding this plan are reflected in the “Other Benefits” caption.

[0000038725-21-000044:notes:70]
The following table sets forth aggregated information related to the Company’s pension benefits and other postretirement benefits, including changes in the benefit obligations, changes in plan assets, funded status, amounts recognized in the balance sheet, amounts recognized in accumulated other comprehensive income, and actuarial assumptions that the Company considered in its determination of benefit obligations and plan costs. Benefit obligation balances presented below reflect the projected benefit obligation (PBO) for the Company’s pension plans, and accumulated postretirement benefit obligations (APBO) for the Company’s other benefit plans.

[0000038725-21-000044:notes:71]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Accumulated benefit obligation, end of year |  | $ | 185.4 |  |  | $ | 176.5 |  |  | $ | 8.5 |  |  | $ | 8.3 |  |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |
| Benefit obligation, beginning of year |  | $ | 180.9 |  |  | $ | 168.9 |  |  | $ | 8.3 |  |  | $ | 9.1 |  |
| Service cost |  | 0.7 |  |  | 0.7 |  |  | — |  |  | — |  |
| Interest cost |  | 4.3 |  |  | 5.8 |  |  | 0.2 |  |  | 0.3 |  |
| Actuarial (gain)/loss |  | 12.8 |  |  | 17.0 |  |  | 0.8 |  |  | (0.2) |  |
| Settlements paid |  | (0.6) |  |  | (0.7) |  |  | — |  |  | — |  |
| Benefits paid |  | (11.4) |  |  | (10.3) |  |  | (0.8) |  |  | (0.9) |  |
| Foreign currency exchange |  | 2.2 |  |  | (0.5) |  |  | — |  |  | — |  |
| Benefit obligation, end of year |  | $ | 188.9 |  |  | $ | 180.9 |  |  | $ | 8.5 |  |  | $ | 8.3 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of assets, beginning of year |  | $ | 151.2 |  |  | $ | 140.1 |  |  | $ | — |  |  | $ | — |  |
| Actual return on plan assets |  | 13.0 |  |  | 20.0 |  |  | — |  |  | — |  |
| Company contributions |  | 0.5 |  |  | 2.0 |  |  | 0.8 |  |  | 0.9 |  |
| Settlements paid |  | (0.4) |  |  | (0.5) |  |  | — |  |  | — |  |
| Benefits paid |  | (11.4) |  |  | (10.3) |  |  | (0.8) |  |  | (0.9) |  |
| Foreign currency exchange |  | 0.4 |  |  | (0.1) |  |  | — |  |  | — |  |
| Plan assets, end of year |  | $ | 153.3 |  |  | $ | 151.2 |  |  | $ | — |  |  | $ | — |  |
| Funded status |  | $ | (35.6) |  |  | $ | (29.7) |  |  | $ | (8.5) |  |  | $ | (8.3) |  |
| Amounts recognized in balance sheet: |  |  |  |  |  |  |  |  |
| Current liabilities |  | $ | (0.5) |  |  | $ | (0.5) |  |  | $ | (0.8) |  |  | $ | (0.8) |  |
| Noncurrent liabilities |  | (35.1) |  |  | (29.2) |  |  | (7.7) |  |  | (7.5) |  |
| Net liability, end of year |  | $ | (35.6) |  |  | $ | (29.7) |  |  | $ | (8.5) |  |  | $ | (8.3) |  |
| Amount recognized in accumulated other comprehensive income/(loss): |  |  |  |  |  |  |  |  |
| Prior service cost |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net actuarial loss |  | 50.9 |  |  | 49.0 |  |  | 0.9 |  |  | 0.4 |  |
| Settlement |  | 0.8 |  |  | 0.6 |  |  | — |  |  | — |  |
| Total recognized in accumulated other comprehensive income/(loss) |  | $ | 51.7 |  |  | $ | 49.6 |  |  | $ | 0.9 |  |  | $ | 0.4 |  |

[0000038725-21-000044:notes:72]
The following table sets forth other changes in plan assets and benefit obligation recognized in other comprehensive income for 2020 and 2019:

[0000038725-21-000044:notes:73]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net actuarial (gain)/loss |  | $ | 6.6 |  |  | $ | 5.2 |  |  | $ | 0.8 |  |  | $ | (0.2) |  |
| Amortization of: |  |  |  |  |  |  |  |  |
| Net actuarial gain |  | (3.1) |  |  | (2.2) |  |  | (0.1) |  |  | (0.1) |  |
| Prior service credit |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement recognition |  | (0.8) |  |  | (0.6) |  |  | — |  |  | — |  |
| Deferred tax asset |  | (0.9) |  |  | (0.6) |  |  | (0.1) |  |  | 0.1 |  |
| Foreign currency exchange |  | 0.2 |  |  | (0.1) |  |  | — |  |  | — |  |
| Total recognized in other comprehensive income |  | $ | 2.0 |  |  | $ | 1.7 |  |  | $ | 0.6 |  |  | $ | (0.2) |  |

[0000038725-21-000044:notes:74]
Weighted-average assumptions used to determine domestic benefit obligations:

[0000038725-21-000044:notes:75]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Discount rate |  | 2.31 | % |  | 3.12 | % |  | 2.12 | % |  | 2.98 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | 2.00 - 9.00%(Graded) |  | 3.00 - 8.00%(Graded) |

[0000038725-21-000044:notes:76]
*No rate of increases in future compensation were used in the assumptions for 2020 and 2019, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation. The weighted-average interest crediting rate of the cash balance component of the domestic Pension Plan was 4.5% for 2020, 2019, and 2018 and is based on the approximate 30-year Treasury rate as of November of the prior year with a minimum of 4.5%.

[0000038725-21-000044:notes:77]
Assumptions used to determine domestic periodic benefit cost:

[0000038725-21-000044:notes:78]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| Discount rate |  | 3.17 | % |  | 4.31 | % |  | 3.64 | % |  | 2.99 | % |  | 4.18 | % |  | 3.51 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | — | % | * | 2.00 - 9.00%(Graded) |  | 3.00 - 8.00%(Graded) |  | 3.00 - 8.00%(Graded) |
| Expected long-term rate of return on plan assets |  | 4.90 | % |  | 5.75 | % |  | 5.90 | % |  | — | % |  | — | % |  | — | % |

[0000038725-21-000044:notes:79]
*No rate of increases in future compensation were used in the assumptions for 2020, 2019, and 2018, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation..

[0000038725-21-000044:notes:80]
For the fiscal year ended December 31, 2020, the Company used the PRI-2012 aggregate mortality table, and then projected forward from 2012 using Scale MP-2019 released by the Society of Actuaries during 2019 to estimate future mortality rates based upon current data. For the fiscal year ended December 31, 2019, the Company used the RP-2014 aggregate table adjusted to back out estimated mortality improvements from 2006 to the measurement date using Scale MP-2014, and then projected forward using Scale MP-2018 released by the Society of Actuaries during 2018 to estimate future mortality rates.

[0000038725-21-000044:notes:81]
The following table sets forth the aggregated net periodic benefit cost for all defined benefit plans for 2020, 2019, and 2018:

[0000038725-21-000044:notes:82]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| Service cost | $ | 0.7 |  |  | $ | 0.7 |  |  | $ | 0.6 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 4.3 |  |  | 5.8 |  |  | 5.4 |  |  | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Expected return on assets | (6.8) |  |  | (8.1) |  |  | (8.5) |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Transition obligation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Actuarial loss | 3.7 |  |  | 2.6 |  |  | 2.9 |  |  | 0.1 |  |  | 0.1 |  |  | 0.2 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 1.9 |  |  | $ | 1.0 |  |  | $ | 0.4 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.6 |  |

[0000038725-21-000044:notes:83]
The largest contributor to the net actuarial losses affecting the benefit obligation for the defined benefit pension plans is due to a decrease in the discount rate.

[0000038725-21-000044:notes:84]
The Company consults with a third party investment manager for the assets of the funded domestic defined benefit plan. The plan assets are currently invested primarily in pooled funds, where each fund in turn is composed of mutual funds that have at least daily net asset valuations. Thus, the Company’s funded domestic defined benefit plan assets are invested in a “fund of funds” approach.

[0000038725-21-000044:notes:85]
The Company’s Board has delegated oversight and guidance to an appointed Employee Benefits Committee. The Committee has the tasks of reviewing plan performance and asset allocation, ensuring plan compliance with applicable laws, establishing plan policies, procedures, and controls, monitoring expenses, and other related activities.

[0000038725-21-000044:notes:86]
The plan’s investment policies and strategies focus on the ability to fund benefit obligations as they come due. Considerations include the plan’s current funded level, plan design, benefit payment assumptions, funding regulations, impact of potentially volatile business results on the Company’s ability to make certain levels of contributions, and interest rate and asset return volatility among other considerations. The Company currently attempts to maintain plan funded status at approximately 80 percent or greater pursuant to the Pension Protection Act of 2007. Given the plan’s current funded status, the Company’s cash on hand, cash historically generated from business operations, and cash available under committed credit facilities, the Company sees ample liquidity to achieve this goal.

[0000038725-21-000044:notes:87]
Risk management and continuous monitoring requirements are met through monthly investment portfolio reports, quarterly Employee Benefits Committee meetings, annual valuations, asset/liability studies, and the annual assumption process focusing primarily on the return on asset assumption and the discount rate assumption. As of December 31, 2020 and December 31, 2019, funds were invested in equity, fixed income, and other investments as follows:

[0000038725-21-000044:notes:88]
|  |  | Target Percentage |  | Plan Asset Allocation at Year-End |
| Asset Category |  | at Year-End 2020 |  | 2020 |  | 2019 |
| Equity securities |  | 17 | % |  | 17 | % |  | 19 | % |
| Fixed income securities |  | 79 | % |  | 79 | % |  | 77 | % |
| Other |  | 4 | % |  | 4 | % |  | 4 | % |
| Total |  | 100 | % |  | 100 | % |  | 100 | % |

[0000038725-21-000044:notes:89]
The Company does not see any particular concentration of risk within the plans, nor any plan assets that pose difficulties for fair value assessment. The Company currently has no allocation to potentially illiquid or potentially difficult to value assets such as hedge funds, venture capital, private equity, and real estate.

[0000038725-21-000044:notes:90]
The Company works with actuaries and consultants in making its determination of the asset rate of return assumption and also the discount rate assumption.

[0000038725-21-000044:notes:91]
Asset class assumptions are set using a combination of empirical and forward-looking analysis for long-term rate of return on plan assets. A variety of models are applied for filtering historical data and isolating the fundamental characteristics of asset classes. These models provide empirical return estimates for each asset class, which are then reviewed and combined with a qualitative assessment of long-term relationships between asset classes before a return estimate is finalized. This provides an additional means for correcting for the effect of unrealistic or unsustainable short-term valuations or trends, opting instead for return levels and behavior that are more likely to prevail over long periods. With that, the Company has assumed an expected long-term rate of return on plan assets of 4.00 percent for the 2021 net periodic benefit cost, down from 4.90 percent in the prior year. This decrease in the assumed long-term rate of return is primarily due to a higher percentage of assets in fixed income securities.

[0000038725-21-000044:notes:92]
The Company uses the Aon Hewitt AA Above Median curve to determine the discount rate. All cash flow obligations under the plan are matched to bonds in the Aon Hewitt universe of liquid, high-quality, non-callable / non-putable corporate bonds with outliers removed. From that matching exercise, a discount rate is determined.

[0000038725-21-000044:notes:93]
The Company’s German pension plans are funded by insurance contract policies whereby the insurance company guarantees a fixed minimum return. Due to tax legislation, individual pension benefits can only be financed using direct insurance policies up to certain maximums. These maximum amounts in respect of each member are paid into such an arrangement on a yearly basis.

[0000038725-21-000044:notes:94]
The Company designated all equity and most domestic fixed income plan assets as Level 1, as they are mutual funds with prices that are readily available. The U.S. Treasury securities and German plan assets are designated as Level 2 inputs. The fair value of the German plan assets are measured by the reserve that is supervised by the German Federal Financial Supervisory Authority. The U.S. Treasury securities are administered by the United States government.

[0000038725-21-000044:notes:95]
The fair values of the Company’s pension plan assets for 2020 and 2019 by asset category are as follows:

[0000038725-21-000044:notes:96]
| (In millions) |  | 2020 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| International equity mutual funds |  | $ | 26.1 |  |  | $ | 26.1 |  |  | $ | — |  |  | $ | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 16.8 |  |  | — |  |  | 16.8 |  |  | — |  |
| Fixed income mutual funds |  | 104.8 |  |  | 104.8 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.8 |  |  | — |  |  | 4.8 |  |  | — |  |
| Cash and equivalents |  | 0.8 |  |  | 0.8 |  |  | — |  |  | — |  |
| Total |  | $ | 153.3 |  |  | $ | 131.7 |  |  | $ | 21.6 |  |  | $ | — |  |

[0000038725-21-000044:notes:97]
| (In millions) |  | 2019 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| International equity mutual funds |  | $ | 29.1 |  |  | $ | 29.1 |  |  | $ | — |  |  | $ | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 17.5 |  |  | — |  |  | 17.5 |  |  | — |  |
| Fixed income mutual funds |  | 99.3 |  |  | 99.3 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.5 |  |  | — |  |  | 4.5 |  |  | — |  |
| Cash and equivalents |  | 0.8 |  |  | 0.8 |  |  | — |  |  | — |  |
| Total |  | $ | 151.2 |  |  | $ | 129.2 |  |  | $ | 22.0 |  |  | $ | — |  |

[0000038725-21-000044:notes:98]
The Company estimates total contributions to the plans of about $1 million in 2021.

[0000038725-21-000044:notes:99]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid in accordance with the following schedule:

[0000038725-21-000044:notes:100]
| (In millions) |  | Pension Benefits |  | Other Benefits |
| 2021 |  | $ | 11.1 |  |  | $ | 0.8 |  |
| 2022 |  | $ | 10.8 |  |  | $ | 0.7 |  |
| 2023 |  | $ | 10.5 |  |  | $ | 0.7 |  |
| 2024 |  | $ | 16.2 |  |  | $ | 0.7 |  |
| 2025 |  | $ | 13.0 |  |  | $ | 0.6 |  |
| Years 2026 through 2030 |  | $ | 47.6 |  |  | $ | 2.6 |  |

[0000038725-21-000044:notes:101]
Defined Contribution Plans - The Company maintained two defined contribution plans during 2020, 2019, and 2018. The Company’s cash contributions are allocated to participant’s accounts based on investment elections.

[0000038725-21-000044:notes:102]
The following table sets forth Company contributions to the defined contribution plans:

[0000038725-21-000044:notes:103]
| (In millions) |  | 2020 |  | 2019 |  | 2018 |
| Company contributions to the plans |  | $ | 7.3 |  |  | $ | 7.4 |  |  | $ | 6.8 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000038725-21-000044:notes:104]
ACCRUED EXPENSES AND OTHER CURRENT LIABILITIES
Accrued expenses and other current liabilities consist of:

[0000038725-21-000044:notes:105]
| (In millions) |  | 2020 |  | 2019 |
| Salaries, wages, and commissions |  | $ | 36.4 |  |  | $ | 28.6 |  |
| Product warranty costs |  | 9.7 |  |  | 9.1 |  |
| Insurance |  | 2.4 |  |  | 2.6 |  |
| Employee benefits |  | 9.8 |  |  | 9.9 |  |
| Other |  | 30.7 |  |  | 18.2 |  |
|  |  | $ | 89.0 |  |  | $ | 68.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-21-000044:notes:106]
INCOME TAXES
Income before income taxes consisted of the following:

[0000038725-21-000044:notes:107]
| (In millions) |  | 2020 |  | 2019 |  | 2018 |
| Domestic |  | $ | 74.1 |  |  | $ | 55.5 |  |  | $ | 54.7 |  |
| Foreign |  | 49.6 |  |  | 61.3 |  |  | 65.7 |  |
|  |  | $ | 123.7 |  |  | $ | 116.8 |  |  | $ | 120.4 |  |

[0000038725-21-000044:notes:108]
The income tax provision/(benefit) from continuing operations consisted of the following:

[0000038725-21-000044:notes:109]
| (In millions) |  | 2020 |  | 2019 |  | 2018 |
| Current: |  |  |  |  |  |  |
| Federal |  | $ | 11.9 |  |  | $ | 6.9 |  |  | $ | 4.6 |  |
| Foreign |  | 12.3 |  |  | 15.1 |  |  | 14.3 |  |
| State |  | 2.6 |  |  | 1.4 |  |  | 1.2 |  |
| Total current |  | 26.8 |  |  | 23.4 |  |  | 20.1 |  |
| Deferred: |  |  |  |  |  |  |
| Federal |  | (0.2) |  |  | (0.6) |  |  | 3.6 |  |
| Foreign |  | (4.0) |  |  | (2.5) |  |  | (2.6) |  |
| State |  | (0.1) |  |  | 0.5 |  |  | (6.2) |  |
| Total deferred |  | $ | (4.3) |  |  | $ | (2.6) |  |  | $ | (5.2) |  |
|  |  | $ | 22.5 |  |  | $ | 20.8 |  |  | $ | 14.9 |  |

[0000038725-21-000044:notes:110]
A reconciliation of the tax provision for continuing operations at the U.S. statutory rate to the effective income tax expense rate as reported is as follows:

[0000038725-21-000044:notes:111]
|  |  | 2020 |  | 2019 |  | 2018 |
| U.S. Federal statutory rate |  | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income taxes, net of federal benefit |  | 1.5 |  |  | 1.1 |  |  | 1.1 |  |
| Foreign operations |  | 0.3 |  |  | (1.0) |  |  | (3.5) |  |
| R&D tax credits |  | (0.7) |  |  | (0.8) |  |  | (0.7) |  |
| Uncertain tax position adjustments |  | 0.1 |  |  | (0.6) |  |  | (0.5) |  |
| Valuation allowance on state and foreign deferred tax |  | 1.7 |  |  | 0.4 |  |  | (2.4) |  |
| Share-based compensation |  | (0.8) |  |  | (0.8) |  |  | (1.3) |  |
| Realized foreign currency loss |  | (4.0) |  |  | (0.4) |  |  | (0.1) |  |
| Other items |  | 1.7 |  |  | 0.9 |  |  | 0.9 |  |
| Impact of the U.S. Tax Cuts and Jobs Act |  |  |  |  |  |  |
| Transition tax |  | — |  |  | — |  |  | 0.5 |  |
| Deferred tax effects |  | — |  |  | — |  |  | (0.3) |  |
| Foreign Derived Intangible Income |  | (2.6) |  |  | (2.0) |  |  | (2.3) |  |
| Effective tax rate |  | 18.2 | % |  | 17.8 | % |  | 12.4 | % |

[0000038725-21-000044:notes:112]
The effective tax rate continues to be lower than the statutory rate of 21 percent primarily due to the recognition of the U.S. foreign-derived intangible income (FDII) provisions, the impact of foreign tax rates, and certain incentives and discrete events.

[0000038725-21-000044:notes:113]
During the twelve-month period ended December 31, 2020, the Company realized a foreign currency translation loss on the second quarter settlement of a discrete intercompany loan that was long-term-investment in nature resulting in a tax benefit of $5.0 million.

[0000038725-21-000044:notes:114]
The Company recorded discrete excess tax benefits from share-based compensation of $1.2 million in the twelve-month period ended December 31, 2020 pursuant to ASU 2016-09. ASU 2016-09 can add variability to the Company’s provision for income taxes, mainly due to the timing of stock option exercises, vesting of restricted stock, and the stock price.

[0000038725-21-000044:notes:115]
The Company also recorded net $0.9 million of expense for valuation allowances on deferred tax assets in foreign jurisdictions to recognize only the portion of the deferred tax assets that are more likely than not to be realized. During the twelve-month period ended December 31, 2018, the Company recorded a net discrete benefit related to the release of valuation allowances on deferred taxes of $4.2 million in domestic and foreign jurisdictions.

[0000038725-21-000044:notes:116]
Significant components of the Company’s deferred tax assets and liabilities were as follows:

[0000038725-21-000044:notes:117]
| (In millions) |  | 2020 |  | 2019 |
| Deferred tax assets: |  |  |  |  |
| Accrued expenses and reserves |  | $ | 13.0 |  |  | $ | 10.1 |  |
| Compensation and employee benefits |  | 19.8 |  |  | 17.7 |  |
| Net operating losses, tax credit carryforwards, and other |  | 20.7 |  |  | 18.8 |  |
| Lease liability |  | 8.0 |  |  | 7.0 |  |
| Valuation allowance on state and foreign deferred tax |  | (8.3) |  |  | (6.4) |  |
| Total deferred tax assets |  | 53.2 |  |  | 47.2 |  |
| Deferred tax liabilities: |  |  |  |  |
| Accelerated depreciation on fixed assets |  | 12.1 |  |  | 11.9 |  |
| Amortization of intangibles |  | 49.4 |  |  | 46.5 |  |
| Right-of-Use asset, net |  | 8.0 |  |  | 7.0 |  |
| Other items |  | 0.5 |  |  | 0.2 |  |
| Total deferred tax liabilities |  | 70.0 |  |  | 65.6 |  |
| Net deferred tax liabilities |  | $ | (16.8) |  |  | $ | (18.4) |  |

[0000038725-21-000044:notes:118]
The Company assesses the available positive and negative evidence to estimate whether sufficient future taxable income will be generated to permit use of the existing deferred tax assets. A significant piece of objective negative evidence evaluated was the cumulative loss for certain state and foreign income tax purposes incurred over the 3-year period ended December 31, 2020. Such objective evidence limits the ability to consider other subjective evidence, such as our projections for future growth.

[0000038725-21-000044:notes:119]
On the basis of this evaluation, as of December 31, 2020, a valuation allowance of $8.3 million has been recorded to recognize only the portion of the deferred tax assets that are more likely than not to be realized. The Company has foreign income tax net operating loss (“NOL”) and credit carryforwards of $14.1 million and state income tax NOL and credit carryforwards of $6.6 million, which will expire on various dates as follows:

[0000038725-21-000044:notes:120]
| (In millions) |  |
| 2021-2024 | $ | 2.1 |  |
| 2025-2029 | 4.4 |  |
| 2030-2034 | 2.2 |  |
| 2035-2039 | 0.6 |  |
| Unlimited | 11.4 |  |
|  | $ | 20.7 |  |

[0000038725-21-000044:notes:121]
The Company believes that it is more likely than not that the benefit from certain foreign NOL carryforwards as well as certain state credit carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance of $6.5 million on the deferred tax assets related to these foreign NOL carryforwards and a valuation allowance of $1.8 million on the deferred tax assets related to these state credit carryforwards.

[0000038725-21-000044:notes:122]
As of December 31, 2020, the Company has accumulated undistributed earnings generated by our foreign subsidiaries of approximately $506.7 million. Any taxes due with respect to such earnings or the excess of the amount for financial reporting

[0000038725-21-000044:notes:123]
over the tax basis of our foreign investments would generally be limited to foreign and state taxes. The Company intends, however, to indefinitely reinvest these earnings and expects future U.S. cash generation to be sufficient to meet future U.S. cash needs. The Company, therefore, has not recorded a deferred tax liability of $6.4 million.

[0000038725-21-000044:notes:124]
As of the beginning of fiscal year 2020, the Company had gross unrecognized tax benefits of $0.4 million, excluding accrued interest and penalties. The unrecognized tax benefits increased due to uncertain tax positions identified in the current year based on evaluations made during 2020. The Company had gross unrecognized tax benefits, excluding accrued interest and penalties, of $0.6 million as of December 31, 2020.

[0000038725-21-000044:notes:125]
A reconciliation of the beginning and ending amount of gross unrecognized tax benefits for 2020, 2019, and 2018 (excluding interest and penalties) is as follows:

[0000038725-21-000044:notes:126]
| (In millions) |  | 2020 |  | 2019 |  | 2018 |
| Beginning balance |  | $ | 0.4 |  |  | $ | 1.1 |  |  | $ | 1.3 |  |
| Additions for tax positions of the current year |  | 0.6 |  |  | — |  |  | — |  |
| Additions for tax positions of prior years |  | — |  |  | — |  |  | 0.3 |  |
| Reductions for tax positions of prior years |  | — |  |  | (0.4) |  |  | — |  |
| Statute expirations |  | (0.4) |  |  | (0.3) |  |  | (0.5) |  |
| Settlements |  | — |  |  | — |  |  | — |  |
| Ending balance |  | $ | 0.6 |  |  | $ | 0.4 |  |  | $ | 1.1 |  |

[0000038725-21-000044:notes:127]
If recognized, each annual effective tax rate would be affected by the net unrecognized tax benefits of $0.6 million, $0.4 million, and $1.0 million as of year-end 2020, 2019, and 2018, respectively.

[0000038725-21-000044:notes:128]
The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense. The Company has accrued interest and penalties as of December 31, 2020, December 31, 2019, and December 31, 2018 of approximately $0.1 million, $0.1 million, and $0.3 million, respectively.

[0000038725-21-000044:notes:129]
The Company is subject to taxation in the United States and various state and foreign jurisdictions. With few exceptions, as of December 31, 2020, the Company is no longer subject to U.S. federal income tax examinations by tax authorities for years before 2017 and is no longer subject to foreign or state income tax examinations by tax authorities for years before 2015.
It is reasonably possible that the amounts of unrecognized tax benefits could change in the next twelve months as a result of an audit or due to the expiration of a statute of limitation. Based on the current audits in process and pending statute expirations, the payment of taxes as a result would not be significant.


## us-gaap:DebtDisclosureTextBlock

[0000038725-21-000044:notes:130]
DEBT
Debt consisted of the following:

[0000038725-21-000044:notes:131]
| (In millions) |  | 2020 |  | 2019 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | — |  |  | 19.0 |  |
| Tax increment financing debt |  | 17.6 |  |  | 18.7 |  |
| Financing leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.8 |  |  | 2.3 |  |
| Other |  | 0.2 |  |  | — |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | 94.6 |  |  | 115.0 |  |
| Less current maturities |  | (2.6) |  |  | (21.9) |  |
| Long-term debt |  | $ | 92.0 |  |  | $ | 93.1 |  |

[0000038725-21-000044:notes:132]
Debt outstanding at December 31, 2020, excluding unamortized debt issuance costs, matures as follows:

[0000038725-21-000044:notes:133]
| (In millions) |  | Total |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |
| Debt |  | $ | 94.6 |  |  | $ | 2.5 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 76.4 |  |  | $ | 11.7 |  |
| Financing leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 94.7 |  |  | $ | 2.6 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 76.4 |  |  | $ | 11.7 |  |

[0000038725-21-000044:notes:134]
New York Life Agreement

[0000038725-21-000044:notes:135]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the “New York Life Agreement”) for $150.0 million maximum aggregate principal borrowing capacity. On October 28, 2016, the Company entered into the First Amendment to the Note Purchase and Private Shelf Agreement. The Amendment was intended to make the covenants within the New York Life Agreement consistent with the covenants that were modified in the Third Amended and Restated Credit Agreement (the “Credit Agreement”). On September 26, 2018 the Company entered into the Second Amendment to the Note Purchase and Private Shelf Agreement which increased the aggregate borrowing capacity to $200.0 million and authorized the issuance of $75.0 million of fixed rate senior noted due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable rate indebtedness with New York Life. As of December 31, 2020, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-21-000044:notes:136]
Project Bonds

[0000038725-21-000044:notes:137]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).” The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (“Tax increment financing debt”) bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033. The use of the proceeds from the Project Notes was limited to assist the financing of the new Global Corporate Headquarters and Engineering Center. On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement. This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-21-000044:notes:138]
Prudential Agreement

[0000038725-21-000044:notes:139]
On April 9, 2007, the Company entered into the Amended and Restated Note Purchase and Private Shelf Agreement (the “Prudential Agreement”) in the amount of $175.0 million. Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”). The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had at issuance an average life of 10 years with a final maturity in 2019. On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million. On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Agreement. On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015. On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement. This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees. On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million. On October 28, 2016, the Company entered into Amendment No. 1 to the Third Amended and Restated Note Purchase and Private Shelf Agreement. This amendment was intended to make the covenants within the Prudential Agreement consistent with the covenants that were modified in the Credit Agreement (below). The Prudential Agreement expires on July 30, 2021. As of December 31, 2020, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-21-000044:notes:140]
Credit Agreement

[0000038725-21-000044:notes:141]
On October 28, 2016, the Company entered into the Third Amended and Restated Credit Agreement (the “Credit Agreement”). The Credit Agreement extended the maturity date of the Company’s previous credit agreement to October 28, 2021 and increased the commitment amount from $150.0 million to $300.0 million. The Credit Agreement provides that the Borrowers

[0000038725-21-000044:notes:142]
may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million) subject to the conditions contained therein. All of the Company’s present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers’ obligations under and in connection with the Credit Agreement. Additionally, the Company unconditionally guaranties all of the obligations of Franklin Electric B.V. under the Credit Agreement. Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company’s leverage ratio) of the aggregate commitment, payable quarterly in arrears. Borrowings may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company’s leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-21-000044:notes:143]
As of December 31, 2020, the Company had no outstanding borrowings, $4.1 million in letters of credit outstanding, and $295.9 million of available capacity under the Credit Agreement. As of December 31, 2019, the Company had $19.0 million outstanding borrowings, $4.5 million in letters of credit outstanding, and $276.5 million of available capacity under the Credit Agreement.

[0000038725-21-000044:notes:144]
Covenants
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Credit Agreement, the Prudential Agreement, the Project Bonds, and the New York Life Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of December 31, 2020.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-21-000044:notes:145]
SHAREHOLDERS’ EQUITY
Authorized Shares

[0000038725-21-000044:notes:146]
The Company has the authority to issue 65,000,000, $.10 par value shares.

[0000038725-21-000044:notes:147]
Share Repurchases

[0000038725-21-000044:notes:148]
During 2020, 2019, and 2018, pursuant to a stock repurchase program authorized by the Company’s Board of Directors, the Company repurchased and retired the following amounts and number of shares:

[0000038725-21-000044:notes:149]
| (In millions, except share amounts) |  | 2020 |  | 2019 |  | 2018 |
| Repurchases |  | $ | 15.2 |  |  | $ | 6.6 |  |  | $ | 31.4 |  |
| Shares |  | 322,147 |  |  | 150,778 |  |  | 749,614 |  |

[0000038725-21-000044:notes:150]
The Company retired shares in the amount of 79,663, 82,601, and 62,908 in 2020, 2019, and 2018, respectively, that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards. The Company also retired shares in the amount of 22,438, 5,345, and 8,775, in 2020, 2019, and 2018, respectively that had been previously granted as stock awards to employees but were forfeited upon not meeting the required restriction criteria or termination.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-21-000044:notes:151]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS) 
Changes in accumulated other comprehensive income/(loss), net of tax, by component are summarized below:

[0000038725-21-000044:notes:152]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance, December 31, 2017 | $ | (99.7) |  |  | $ | (49.3) |  |  | $ | (149.0) |  |
| Other comprehensive income/(loss) before reclassifications | (34.8) |  |  | — |  |  | (34.8) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.8 |  |  | 0.8 |  |
| Net other comprehensive income/(loss) | (34.8) |  |  | 0.8 |  |  | (34.0) |  |
| Balance, December 31, 2018 | $ | (134.5) |  |  | $ | (48.5) |  |  | $ | (183.0) |  |
| Other comprehensive income/(loss) before reclassifications | (5.7) |  |  | — |  |  | (5.7) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | (1.5) |  |  | (1.5) |  |
| Net other comprehensive income/(loss) | (5.7) |  |  | (1.5) |  |  | (7.2) |  |
| Balance, December 31, 2019 | $ | (140.2) |  |  | $ | (50.0) |  |  | $ | (190.2) |  |
| Other comprehensive income/(loss) before reclassifications | (12.0) |  |  | — |  |  | (12.0) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | (2.6) |  |  | (2.6) |  |
| Net other comprehensive income/(loss) | (12.0) |  |  | (2.6) |  |  | (14.6) |  |
| Balance, December 31, 2020 | $ | (152.2) |  |  | $ | (52.6) |  |  | $ | (204.8) |  |

[0000038725-21-000044:notes:153]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 7 - Employee Benefit Plans for additional details) and is included in the “Selling, general, and administrative expenses” line of the Company’s consolidated statements of income.

[0000038725-21-000044:notes:154]
(2) Net of tax (benefit)/expense of $(1.1) million, $(0.6) million and $0.3 million for 2020, 2019, and 2018, respectively.
Amounts related to noncontrolling interests were not material.


## us-gaap:EarningsPerShareTextBlock

[0000038725-21-000044:notes:155]
EARNINGS PER SHARE
The Company calculates basic and diluted earnings per common share using the two-class method. Under the two-class method, net earnings are allocated to each class of common stock and participating security as if all of the net earnings for the period had been distributed. The Company’s participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.

[0000038725-21-000044:notes:156]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period. Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-21-000044:notes:157]
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-21-000044:notes:158]
| (In millions, except per share amounts) |  | 2020 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. |  | $ | 100.5 |  |  | $ | 95.5 |  |  | $ | 105.9 |  |
| Less: Earnings allocated to participating securities |  | 0.7 |  |  | 0.7 |  |  | 0.8 |  |
| Net income available to common shareholders |  | $ | 99.8 |  |  | $ | 94.8 |  |  | $ | 105.1 |  |
| Denominator: |  |  |  |  |  |  |
| Basic weighted average common shares outstanding |  | 46.2 |  |  | 46.4 |  |  | 46.6 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards |  | 0.5 |  |  | 0.4 |  |  | 0.4 |  |
| Diluted weighted average common shares outstanding |  | 46.7 |  |  | 46.8 |  |  | 47.0 |  |
| Basic earnings per share |  | $ | 2.16 |  |  | $ | 2.04 |  |  | $ | 2.25 |  |
| Diluted earnings per share |  | $ | 2.14 |  |  | $ | 2.03 |  |  | $ | 2.23 |  |

[0000038725-21-000044:notes:159]
There were 0.2 million, 0.2 million, and 0.1 million stock options outstanding as of 2020, 2019, and 2018, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-21-000044:notes:160]
SHARE-BASED COMPENSATION
The Franklin Electric Co., Inc. 2017 Stock Plan (the “2017 Stock Plan”) is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, stock unit awards, and stock appreciation rights (“SARs”) to key employees and non-employee directors. The number of shares that may be issued under the Plan is 1,400,000. Stock options and SARs reduce the number of available shares by one share for each share subject to the option or SAR, and stock awards and stock unit awards settled in shares reduce the number of available shares by 1.5 shares for every one share delivered.

[0000038725-21-000044:notes:161]
The Company also maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the “2012 Stock Plan”), which is a share-based compensation plan that provides for discretionary grants of stock options, stock awards and stock unit awards to key employees and non-employee directors.

[0000038725-21-000044:notes:162]
The 2012 Stock Plan authorized 2,400,000 shares for issuance as follows:

[0000038725-21-000044:notes:163]
| 2012 Stock Plan |  | Authorized Shares |
| Stock Options |  | 1,680,000 |
| Stock/Stock Unit Awards |  | 720,000 |

[0000038725-21-000044:notes:164]
The Company also maintains the Amended and Restated Franklin Electric Co., Inc. Stock Plan (the “2009 Stock Plan”) which, as amended in 2009, provided for discretionary grants of stock options and stock awards. The 2009 Stock Plan authorized 4,400,000 shares for issuance as follows:

[0000038725-21-000044:notes:165]
| 2009 Stock Plan | Authorized Shares |
| Stock Options | 3,200,000 |
| Stock Awards | 1,200,000 |

[0000038725-21-000044:notes:166]
All options in the 2009 Stock Plan have been awarded and no additional awards are granted out of the plan.

[0000038725-21-000044:notes:167]
The Company currently issues new shares from its common stock balance to satisfy option exercises and the settlement of stock awards and stock unit awards made under the outstanding stock plans.

[0000038725-21-000044:notes:168]
The total share-based compensation expense recognized in 2020, 2019, and 2018 was $10.1 million, $8.9 million, and $8.4 million, respectively.

[0000038725-21-000044:notes:169]
Stock Options:

[0000038725-21-000044:notes:170]
Under the above plans, the exercise price of each option equals the market price of the Company’s common stock on the date of grant, and the options expire 10 years after the date of the grant. Options granted to employees in 2019 and after vest at 33 percent a year and become fully vested and fully exercisable after 3 years. Options granted prior to 2019 vest at 25 percent a year and become fully vested and fully exercisable after 4 years. Vesting is accelerated upon death or disability. Subject to the terms of the plans, in general, the aggregate option exercise price and any applicable tax withholding may be satisfied in cash or its equivalent, by the plan participant’s delivery of shares of the Company’s common stock having a fair market value at the time of exercise equal to the aggregate option exercise price and/or the applicable tax withholding or by having shares otherwise subject to the award withheld by the Company or via cashless exercise through a broker-dealer.

[0000038725-21-000044:notes:171]
The fair value of each option award is estimated on the date of grant using the Black-Scholes option valuation model with a single approach and amortized using a straight-line attribution method over the option’s vesting period. Options granted to retirement eligible employees are immediately expensed. The Company uses historical data to estimate the expected volatility of its stock, the weighted average expected life, the period of time options granted are expected to be outstanding, and its dividend yield. The risk-free rates for periods within the contractual life of the option are based on the U.S. Treasury yield curve in effect at the time of the grant.

[0000038725-21-000044:notes:172]
The table below provides the weighted average grant-date fair values and key assumptions used for the Black-Scholes model to determine the fair value of options granted during 2020, 2019, and 2018:

[0000038725-21-000044:notes:173]
|  |  | 2020 |  | 2019 |  | 2018 |
| Risk-free interest rate |  | 1.39 | % |  | 2.53 | % |  | 2.69 | % |
| Dividend yield |  | 1.04 | % |  | 1.05 | % |  | 1.05 | % |
| Volatility factor |  | 29.45 | % |  | 29.38 | % |  | 28.71 | % |
| Expected term |  | 5.5 years |  | 5.5 years |  | 5.6 years |
| Weighted average grant-date fair value of options |  | $ | 15.63 |  |  | $ | 15.61 |  |  | $ | 11.40 |  |

[0000038725-21-000044:notes:174]
A summary of the Company’s outstanding stock option activity and related information is as follows:

[0000038725-21-000044:notes:175]
| (Shares in thousands) |  |  |  |  |  |  |  |  |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | AggregateIntrinsic Value (000’s) |
| Outstanding at beginning of 2020 |  | 1,262 |  |  | $ | 37.99 |  |  |  |  |  |
| Granted |  | 214 |  |  | 59.71 |  |  |  |  |  |
| Exercised |  | (121) |  |  | 30.64 |  |  |  |  |  |
| Forfeited |  | (24) |  |  | 52.58 |  |  |  |  |  |
| Outstanding at end of 2020 |  | 1,331 |  |  | $ | 41.90 |  |  | 5.51 years |  | $ | 36,360 |  |
| Expected to vest after applying forfeiture rate |  | 1,330 |  |  | $ | 41.88 |  |  | 5.50 years |  | $ | 36,342 |  |
| Vested and exercisable at end of period |  | 884 |  |  | $ | 36.41 |  |  | 4.15 years |  | $ | 28,987 |  |

[0000038725-21-000044:notes:176]
| (In millions) |  | 2020 |  | 2019 |  | 2018 |
| Intrinsic value of options exercised |  | $ | 3.3 |  |  | $ | 4.6 |  |  | $ | 10.2 |  |
| Cash received from the exercise of options |  | 3.7 |  |  | 3.2 |  |  | 9.0 |  |
| Fair value of shares vested |  | 2.9 |  |  | 2.6 |  |  | 2.2 |  |
| Tax benefit of options exercised |  | 0.8 |  |  | 1.1 |  |  | 2.6 |  |

[0000038725-21-000044:notes:177]
As of December 31, 2020, there was $0.9 million of total unrecognized compensation cost related to non-vested stock options granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.53 years.

[0000038725-21-000044:notes:178]
Stock/Stock Unit Awards:

[0000038725-21-000044:notes:179]
Under the 2009 Stock Plan, non-employee directors and employees may be granted stock awards. Under the 2012 Stock Plan and the 2017 Stock Plan, non-employee directors and employees may be granted stock awards and stock units.

[0000038725-21-000044:notes:180]
Stock awards to non-employee directors are generally fully vested when made. Stock/stock unit awards to employees cliff vest over 3 or 4 years (subject to accelerated vesting of a pro rata portion in the case of retirement, death or disability) and may be contingent on the attainment of certain performance goals. Dividends are paid to the recipient prior to vesting, except that dividends on performance-based stock awards under the 2012 Stock Plan and the 2017 Stock Plan will be paid only to the extent the performance goals are met.

[0000038725-21-000044:notes:181]
Stock/stock unit awards granted to retirement eligible employees are expensed over the vesting period. Compensation cost for the performance stock/stock unit awards is accrued based on the probable outcome of specified performance conditions.

[0000038725-21-000044:notes:182]
A summary of the Company’s restricted stock/stock unit award activity and related information is as follows:

[0000038725-21-000044:notes:183]
| (Shares in thousands) |  |  |  |  |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of 2020 |  | 463 |  |  | $ | 42.36 |  |
| Awarded |  | 118 |  |  | 59.28 |  |
| Vested |  | (140) |  |  | 34.63 |  |
| Forfeited |  | (38) |  |  | 49.62 |  |
| Non-vested at end of 2020 |  | 403 |  |  | $ | 49.34 |  |

[0000038725-21-000044:notes:184]
The weighted-average grant date fair value of restricted stock/stock unit awards granted in 2020, 2019, and 2018, is $59.28, $51.47, and $40.48, respectively.

[0000038725-21-000044:notes:185]
As of December 31, 2020, there was $7.4 million of total unrecognized compensation cost related to non-vested stock/stock unit awards granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.25 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-21-000044:notes:186]
SEGMENT AND GEOGRAPHIC INFORMATION
The Company’s business consists of the Water Systems, Distribution, and Fueling Systems reportable segments, based on the principal end market served. The Company includes unallocated corporate expenses and intercompany eliminations in an “Intersegment Eliminations/Other” segment that together with the Water Systems, Distribution, and Fueling Systems segments, represent the Company.

[0000038725-21-000044:notes:187]
The Water Systems segment designs, manufactures and sells motors, pumps, electronic controls and related parts and equipment primarily for use in submersible water and other fluid system applications. The Fueling Systems segment designs, manufactures and sells pumps, electronic controls and related parts and equipment primarily for use in submersible fueling system applications. The Fueling Systems segment integrates and sells motors and electronic controls produced by the Water Systems segment. The Company reports these product transfers between Water and Fueling as inventory transfers since a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes. The Distribution segment sells to and provides presale support and specifications to the installing contractors. The Distribution segment sells products produced by the Water Systems segment. The Company reports intersegment transfers from Water Systems to Distribution as intersegment revenue at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water System and Distribution segments.

[0000038725-21-000044:notes:188]
Segment operating income is a key financial performance measure. Operating income by segment is based on net sales less identifiable operating expenses and allocations and includes profits recorded on sales to other segments of the Company.

[0000038725-21-000044:notes:189]
The accounting policies of the Company’s reportable segments are the same as those described in Note 1 - Summary of Significant Accounting Policies. Performance is evaluated based on the sales and operating income of the segments and a variety of ratios to measure performance. These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented.

[0000038725-21-000044:notes:190]
Financial information by reportable business segment is included in the following summary:

[0000038725-21-000044:notes:191]
| Net Sales |
| (In millions) | 2020 |  | 2019 |  | 2018 |
| Water Systems |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | $ | 327.6 |  |  | $ | 367.6 |  |  | $ | 372.0 |  |
| Latin America | 118.5 |  |  | 124.2 |  |  | 120.2 |  |
| Europe, Middle East & Africa | 156.8 |  |  | 155.6 |  |  | 170.9 |  |
| Asia Pacific | 70.9 |  |  | 81.8 |  |  | 80.8 |  |
| Intersegment sales |  |  |  |  |  |
| United States & Canada | 60.9 |  |  | 52.3 |  |  | 56.2 |  |
| Total sales | 734.7 |  |  | 781.5 |  |  | 800.1 |  |
| Distribution |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 328.4 |  |  | 291.8 |  |  | 269.6 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |
| Total sales | 328.4 |  |  | 291.8 |  |  | 269.6 |  |
| Fueling Systems |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 158.2 |  |  | 173.5 |  |  | 156.9 |  |
| All other | 86.9 |  |  | 120.1 |  |  | 127.7 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |
| Total Sales | 245.1 |  |  | 293.6 |  |  | 284.6 |  |
| Intersegment Eliminations/Other | (60.9) |  |  | (52.3) |  |  | (56.2) |  |
| Consolidated | $ | 1,247.3 |  |  | $ | 1,314.6 |  |  | $ | 1,298.1 |  |
| Operating income (loss) |
|  | 2020 |  | 2019 |  | 2018 |
| Water Systems | $ | 114.4 |  |  | $ | 103.0 |  |  | $ | 112.7 |  |
| Distribution | 11.5 |  |  | 3.6 |  |  | 3.4 |  |
| Fueling Systems | 63.4 |  |  | 75.8 |  |  | 70.6 |  |
| Intersegment Eliminations/Other | (58.8) |  |  | (55.3) |  |  | (54.7) |  |
| Consolidated | $ | 130.5 |  |  | $ | 127.1 |  |  | $ | 132.0 |  |

[0000038725-21-000044:notes:192]
|  | Total assets |  | Depreciation |
|  | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| Water Systems | $ | 645.9 |  |  | $ | 658.3 |  |  | $ | 679.7 |  |  | $ | 18.7 |  |  | $ | 19.0 |  |  | $ | 20.4 |  |
| Distribution | 249.0 |  |  | 180.2 |  |  | 165.1 |  |  | 2.6 |  |  | 2.8 |  |  | 2.2 |  |
| Fueling Systems | 268.9 |  |  | 283.8 |  |  | 275.7 |  |  | 2.1 |  |  | 2.1 |  |  | 2.2 |  |
| Other | 108.5 |  |  | 72.4 |  |  | 61.9 |  |  | 3.7 |  |  | 3.7 |  |  | 4.9 |  |
| Consolidated | $ | 1,272.3 |  |  | $ | 1,194.7 |  |  | $ | 1,182.4 |  |  | $ | 27.1 |  |  | $ | 27.6 |  |  | $ | 29.7 |  |
|  | Amortization |  | Capital expenditures |
|  | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| Water Systems | $ | 6.9 |  |  | $ | 6.9 |  |  | $ | 6.5 |  |  | $ | 16.9 |  |  | $ | 15.1 |  |  | $ | 18.2 |  |
| Distribution | 0.6 |  |  | 0.5 |  |  | 0.5 |  |  | 3.5 |  |  | 3.9 |  |  | 2.0 |  |
| Fueling Systems | 1.8 |  |  | 1.9 |  |  | 1.8 |  |  | 2.0 |  |  | 1.9 |  |  | 2.2 |  |
| Other | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.5 |  |  | 1.2 |  |  | 1.0 |  |
| Consolidated | $ | 9.4 |  |  | $ | 9.4 |  |  | $ | 8.9 |  |  | $ | 22.9 |  |  | $ | 22.1 |  |  | $ | 23.4 |  |

[0000038725-21-000044:notes:193]
Cash and property, plant and equipment are the major asset groups in “Other” of total assets for the fiscal years ended December 31, 2020 and December 31, 2019. Property, plant and equipment is the major asset group in "Other" of total assets for the fiscal year ended December 31, 2018.

[0000038725-21-000044:notes:194]
Financial information by geographic region is as follows:

[0000038725-21-000044:notes:195]
|  | Net sales |  | Long-lived assets |
| (In millions) | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| United States | $ | 760.6 |  |  | $ | 776.6 |  |  | $ | 752.5 |  |  | $ | 405.9 |  |  | $ | 394.7 |  |  | $ | 372.6 |  |
| Foreign | 486.7 |  |  | 538.0 |  |  | 545.6 |  |  | 238.3 |  |  | 223.4 |  |  | 221.2 |  |
| Consolidated | $ | 1,247.3 |  |  | $ | 1,314.6 |  |  | $ | 1,298.1 |  |  | $ | 644.2 |  |  | $ | 618.1 |  |  | $ | 593.8 |  |

[0000038725-21-000044:notes:196]
Net sales are attributed to geographic regions based upon the ship to location of the customer. Long-lived assets are attributed to geographic regions based upon the country of domicile.

[0000038725-21-000044:notes:197]
The Company offers a large array of products and systems to multiple markets and customers. Product sales information is tracked regionally and products are categorized differently between regions based on local needs and reporting requirements. However, net sales by segment are representative of the Company’s sales by major product category. The Company sells its products through various distribution channels including wholesale and retail distributors, specialty distributors, industrial and petroleum equipment distributors, as well as major oil and utility companies and original equipment manufacturers.

[0000038725-21-000044:notes:198]
No single customer accounted for more than 10 percent of the Company’s consolidated sales in 2020, 2019, or 2018. No single customer accounted for more than 10 percent of the Company’s gross accounts receivable in 2020 or 2019.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-21-000044:notes:199]
COMMITMENTS AND CONTINGENCIESIn 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. The subject-matter expert has issued their preliminary report, which indicates that total damages incurred by Esso amounted to approximately 12 million euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company has retained experts to demonstrate that its products did not cause the damage, and in January 2021, submitted its response to the expert’s preliminary report for each station. The expert's response to the Company's report is due to the Court in June 2021. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s results of operations.
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-21-000044:notes:200]
At December 31, 2020, the Company had $9.1 million of commitments primarily for capital expenditures and the purchase of raw materials to be used in production.

[0000038725-21-000044:notes:201]
The changes in the carrying amount of the warranty accrual, as recorded in the “Accrued expenses and other current liabilities” line of the Company’s consolidated balance sheets for 2020 and 2019, are as follows:

[0000038725-21-000044:notes:202]
| (In millions) |  | 2020 |  | 2019 |
| Beginning balance |  | $ | 9.1 |  |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 9.4 |  |  | 10.7 |  |
| Additions related to acquisitions |  | 0.6 |  |  | 0.1 |  |
| Reductions for payments made |  | (9.4) |  |  | (10.7) |  |
| Ending balance |  | $ | 9.7 |  |  | $ | 9.1 |  |

[0000038725-21-000044:notes:203]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. However, these financing leases are immaterial to the Company.

[0000038725-21-000044:notes:204]
The components of the Company's operating lease portfolio as of December 31, 2020 are as follows:

[0000038725-21-000044:notes:205]
| Lease Cost (In millions): |  |  |
| Operating lease cost |  | $ | 11.4 |  |
| Short-term lease cost |  | 0.4 |  |
| Other Information: |  |  |
| Weighted-average remaining lease term |  | 3.9 years |
| Weighted-average discount rate |  | 3.7 | % |

[0000038725-21-000044:notes:206]
Total rent expense charged to operations for operating leases including contingent rentals was $17.4 million in 2018 under Topic 840.

[0000038725-21-000044:notes:207]
The future minimum rental payments for non-cancellable operating leases as of December 31, 2020, are as follows:

[0000038725-21-000044:notes:208]
| (In millions) | Total |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |
| Undiscounted future minimum rental payments | $ | 34.4 |  |  | $ | 11.9 |  |  | $ | 8.0 |  |  | $ | 5.9 |  |  | $ | 3.1 |  |  | $ | 2.0 |  |  | $ | 3.5 |  |
| Less: Imputed Interest | $ | 2.4 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | $ | 32.0 |  |  |  |  |  |  |  |  |  |  |  |  |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000038725-21-000044:notes:209]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000038725-21-000044:notes:210]
| (In millions) |  | Balance at Beginning of Period |  | Additions Charged to Costs and Expenses |  | Deductions (a) |  | Other (b) |  | Balance at End of Period |
| 2020 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.7 |  |  | $ | 0.2 |  |  | $ | 1.0 |  |  | $ | 1.1 |  |  | $ | 4.0 |  |
| Allowance for deferred taxes |  | 6.4 |  |  | 1.9 |  |  | — |  |  | — |  |  | 8.3 |  |
| 2019 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4.4 |  |  | $ | 0.1 |  |  | $ | 0.9 |  |  | $ | 0.1 |  |  | $ | 3.7 |  |
| Allowance for deferred taxes |  | 6.8 |  |  | — |  |  | 0.4 |  |  | — |  |  | 6.4 |  |
| 2018 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4.4 |  |  | $ | (0.1) |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | 4.4 |  |
| Allowance for deferred taxes |  | 9.8 |  |  | 2.3 |  |  | 5.3 |  |  | — |  |  | 6.8 |  |

[0000038725-21-000044:notes:211]
(a) Charges for which allowances were created.

[0000038725-21-000044:notes:212]
(b) Primarily related to acquisitions
