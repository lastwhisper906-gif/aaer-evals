# FELE 8-K — 0000038725-21-000010 filed 2021-02-16

## item codes, every 8-K on or before 2021-02-24

- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2021-02-24

- none on or before 2021-02-24

## item 2.02 — earnings release, exhibit 99.1

[0000038725-21-000010:8k_2_02:1]
EX-99.1
2
a202102168-kexhibit991.htm
EX-99.1

[0000038725-21-000010:8k_2_02:2]
Document

[0000038725-21-000010:8k_2_02:3]
Exhibit 99.1

[0000038725-21-000010:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-21-000010:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS FULL YEAR 2020 RESULTS AND RECORD FOURTH QUARTER 2020 RESULTS

[0000038725-21-000010:8k_2_02:6]
Fourth Quarter 2020 Highlights

[0000038725-21-000010:8k_2_02:7]
•Record sales of $321.1 million

[0000038725-21-000010:8k_2_02:8]
•Organic sales growth for Distribution (21%) and Water Systems (4%)

[0000038725-21-000010:8k_2_02:9]
•Gross profit margin as a percent of sales increased 300 basis points

[0000038725-21-000010:8k_2_02:10]
•Record GAAP operating income of $34.4 million, increasing 20% from the prior year

[0000038725-21-000010:8k_2_02:11]
•Successful completion of the Gicon Pumps and Equipment acquisition; expected to drive meaningful growth for Distribution

[0000038725-21-000010:8k_2_02:12]
Full Year 2020 Highlights

[0000038725-21-000010:8k_2_02:13]
•Full year 2020 Sales were $1,247.3 million.

[0000038725-21-000010:8k_2_02:14]
•GAAP earnings per share of $2.14, a 5% increase from the prior year

[0000038725-21-000010:8k_2_02:15]
•Full year 2020 cash flow from operating activities was a record of $212 million and free cash flow conversion of net income was 187%

[0000038725-21-000010:8k_2_02:16]
Fort Wayne, IN – February 16, 2021 – Franklin Electric Co. Inc. today announced fourth quarter and full year financial results for fiscal year 2020.

[0000038725-21-000010:8k_2_02:17]
Fourth quarter 2020 sales were $321.1 million, compared to fourth quarter 2019 sales of $320.1 million.  Fourth quarter 2020 operating income was $34.4 million, compared to fourth quarter operating income in 2019 of $28.6 million.

[0000038725-21-000010:8k_2_02:18]
Fourth quarter 2020 GAAP fully diluted earnings per share (EPS) was $0.57, versus GAAP fully diluted EPS in the fourth quarter 2019 of $0.42. Fourth quarter 2020 EPS before the impact of restructuring expenses was $0.57 compared to fourth quarter 2019 EPS before restructuring of $0.43 (see table below for a reconciliation of GAAP EPS to EPS before restructuring).

[0000038725-21-000010:8k_2_02:19]
Full year 2020 sales were $1,247.3 million, compared to full year 2019 sales of $1,314.6 million.  Full year 2020 operating income was $130.5 million, compared to full year 2019 operating income of $127.1 million.

[0000038725-21-000010:8k_2_02:20]
Full year 2020 GAAP fully diluted earnings per share (EPS) was $2.14, versus a GAAP fully diluted EPS in 2019 of $2.03.  Full year 2020 EPS before the impact of restructuring expenses was $2.18 compared to 2019 EPS before restructuring of $2.07 (see table below for a reconciliation of GAAP EPS to EPS before restructuring).

[0000038725-21-000010:8k_2_02:21]
“We ended 2020 strong, delivering record fourth quarter 2020 sales and earnings. Our Water Systems business continued to rebound from the slowdown driven by the pandemic earlier in the year to post 4 percent organic sales growth in the fourth quarter, alongside record operating income and operating income margin. Further, our Distribution business achieved profitability in the fourth quarter for the first time in its history supported by organic sales growth of 21 percent.  We also continued to advance our acquisition strategy with the completion of two strategic acquisitions in the fourth quarter, one in the Water Treatment space in Canada and another with a critical groundwater distribution entity in central

[0000038725-21-000010:8k_2_02:22]
Texas. We are confident that each offers a great new growth platform for 2021,” commented Gregg Sengstack, Franklin Electric’s Chairperson and Chief Executive Officer.

[0000038725-21-000010:8k_2_02:23]
“Given the incredible challenges we faced in 2020, I am extremely proud of the dedication and execution of our global team. We gained momentum towards the end of 2020 and are poised to capitalize on the strong tailwinds that have materialized in the Water end markets we serve. Our strategy to grow as a global provider of water and fuel systems, through geographic expansion and product line extensions, leveraging our global platform and competency in system design, is working. We see many growth opportunities ahead of us and look forward to continuing to drive strong performance in the years ahead,” concluded Sengstack.

[0000038725-21-000010:8k_2_02:24]
Segment Summaries

[0000038725-21-000010:8k_2_02:25]
Water Systems sales were $189.3 million in the fourth quarter 2020, an increase of $1.1 million versus the fourth quarter 2019. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 4 percent compared to the fourth quarter 2019.  Sales of groundwater pumping equipment and sales of surface pumping equipment increased due to strong end market demand. These increases were partially offset by lower sales of dewatering equipment, which were down by about 24 percent, due to lower sales in the rental channel.  In 2020, Water Systems operating income was a record for any fourth quarter at $30.4 million driven by price realization, product sales mix and cost management.  Fourth quarter 2019 Water Systems operating income was $24.5 million.

[0000038725-21-000010:8k_2_02:26]
Fueling Systems sales were $65.5 million in the fourth quarter 2020, a decrease of $11.8 million versus the fourth quarter 2019. Fueling Systems sales in the U.S. and Canada decreased by about 13 percent compared to the fourth quarter 2019. The decrease was due to declining demand for new filling stations. Outside the U.S. and Canada, Fueling Systems revenues declined by about 21 percent, driven primarily by lower sales in China. Fueling Systems operating income was $18.8 million in the fourth quarter of 2020, compared to $20.2 million in the fourth quarter of 2019 driven almost entirely by lower revenues.

[0000038725-21-000010:8k_2_02:27]
Distribution sales were a record at $77.9 million in the fourth quarter 2020.  The Distribution segment organic sales increased 21 percent compared to the fourth quarter of 2019.  Favorable weather conditions versus last year contributed to the revenue growth. The Distribution segment operating income was a record at $0.5 million in the fourth quarter of 2020.

[0000038725-21-000010:8k_2_02:28]
Cash Flow

[0000038725-21-000010:8k_2_02:29]
Full Year 2020 Free Cash Flow from Operations was $189 million and 187 percent of Net Income versus $157 million and 163 percent of net income in 2019.  Free cash flow increased primarily due to a 200-basis point improvement in working capital as a percent of trailing twelve-month sales. Free Cash Flow is Net Cash Flows from Operating Activities, less net additions to property, plant, and equipment.

[0000038725-21-000010:8k_2_02:30]
2021 Guidance

[0000038725-21-000010:8k_2_02:31]
The Company expects its full year 2021 sales to be in the range of $1.365 billion to $1.395 billion and full year 2021 earnings per share before restructuring expenses to be in the range from $2.50 to $2.75.  The Company expects full year 2021 free cash flow conversion to exceed 115 percent of net income.

[0000038725-21-000010:8k_2_02:32]
Earnings Conference Call

[0000038725-21-000010:8k_2_02:33]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The fourth quarter and fiscal year 2020 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-21-000010:8k_2_02:34]
https://edge.media-server.com/mmc/p/dn9qs2nn

[0000038725-21-000010:8k_2_02:35]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls. The conference ID is: 2573897.

[0000038725-21-000010:8k_2_02:36]
A replay of the conference call will be available Tuesday, February 16, 2021 at 12:00 noon ET through noon ET on Tuesday, February 23, 2021, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls. The replay passcode is: 2573897.

[0000038725-21-000010:8k_2_02:37]
Forward Looking Statements

[0000038725-21-000010:8k_2_02:38]
About Franklin Electric

[0000038725-21-000010:8k_2_02:39]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-21-000010:8k_2_02:40]
Franklin Electric Contact:

[0000038725-21-000010:8k_2_02:41]
John J. Haines

[0000038725-21-000010:8k_2_02:42]
Franklin Electric Co., Inc.

[0000038725-21-000010:8k_2_02:43]
260-824-2900

[0000038725-21-000010:8k_2_02:44]
Email: jhaines@fele.com

[0000038725-21-000010:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |  |
|  | Fourth Quarter Ended |  |  | Fiscal Year End |
|  | December 31, 2020 |  | December 31, 2019 |  |  | December 31, 2020 |  | December 31, 2019 |
| Net sales | $ | 321,106 |  |  | $ | 320,107 |  |  |  | $ | 1,247,331 |  |  | $ | 1,314,578 |  |
| Cost of sales | 209,703 |  |  | 218,851 |  |  |  | 814,192 |  |  | 886,475 |  |
| Gross profit | 111,403 |  |  | 101,256 |  |  |  | 433,139 |  |  | 428,103 |  |
| Selling, general, and administrative expenses | 76,713 |  |  | 71,870 |  |  |  | 300,122 |  |  | 298,451 |  |
| Restructuring expense | 317 |  |  | 784 |  |  |  | 2,506 |  |  | 2,519 |  |
| Operating income | 34,373 |  |  | 28,602 |  |  |  | 130,511 |  |  | 127,133 |  |
| Interest expense | (1,131) |  |  | (1,571) |  |  |  | (4,627) |  |  | (8,245) |  |
| Other income/(expense), net | 267 |  |  | (109) |  |  |  | (795) |  |  | (412) |  |
| Foreign exchange income/(expense) | (1,308) |  |  | (3,807) |  |  |  | (1,392) |  |  | (1,641) |  |
| Income before income taxes | 32,201 |  |  | 23,115 |  |  |  | 123,697 |  |  | 116,835 |  |
| Income tax (benefit)/ expense | 5,213 |  |  | 3,130 |  |  |  | 22,540 |  |  | 20,836 |  |
| Net income | $ | 26,988 |  |  | $ | 19,985 |  |  |  | $ | 101,157 |  |  | $ | 95,999 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (194) |  |  | (210) |  |  |  | (697) |  |  | (516) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 26,794 |  |  | $ | 19,775 |  |  |  | $ | 100,460 |  |  | $ | 95,483 |  |
| Income per share: |  |  |  |  |  |  |  |  |
| Basic | $ | 0.58 |  |  | $ | 0.42 |  |  |  | $ | 2.16 |  |  | $ | 2.04 |  |
| Diluted | $ | 0.57 |  |  | $ | 0.42 |  |  |  | $ | 2.14 |  |  | $ | 2.03 |  |

[0000038725-21-000010:8k_2_02:46]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | December 31, 2020 |  | December 31, 2019 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 130,787 |  |  | $ | 64,405 |  |
| Receivables (net) | 159,827 |  |  | 173,327 |  |
| Inventories | 300,932 |  |  | 300,246 |  |
| Other current assets | 27,708 |  |  | 29,466 |  |
| Total current assets | 619,254 |  |  | 567,444 |  |
| Property, plant, and equipment, net | 209,021 |  |  | 201,328 |  |
| Right-of-use asset, net | 31,954 |  |  | 27,621 |  |
| Goodwill and other assets | 412,078 |  |  | 398,350 |  |
| Total assets | $ | 1,272,307 |  |  | $ | 1,194,743 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 95,903 |  |  | $ | 82,593 |  |
| Accrued expenses and other current liabilities | 94,160 |  |  | 71,454 |  |
| Current lease liability | 11,090 |  |  | 9,838 |  |
| Current maturities of long-term debt and short-term borrowings | 2,551 |  |  | 21,879 |  |
| Total current liabilities | 203,704 |  |  | 185,764 |  |
| Long-term debt | 91,966 |  |  | 93,141 |  |
| Long-term lease liability | 20,866 |  |  | 17,785 |  |
| Income taxes payable non-current | 11,965 |  |  | 11,965 |  |
| Deferred income taxes | 25,671 |  |  | 27,598 |  |
| Employee benefit plans | 44,443 |  |  | 38,288 |  |
| Other long-term liabilities | 23,988 |  |  | 21,769 |  |
| Redeemable noncontrolling interest | (245) |  |  | (236) |  |
| Total equity | 849,949 |  |  | 798,669 |  |
| Total liabilities and equity | $ | 1,272,307 |  |  | $ | 1,194,743 |  |

[0000038725-21-000010:8k_2_02:47]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Twelve Months Ended |
| (In thousands) |  |  |  |
|  | December 31, 2020 |  | December 31, 2019 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 101,157 |  |  | $ | 95,999 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 36,488 |  |  | 36,977 |  |
| Non-cash lease expense | 11,699 |  |  | 11,699 |  |
| Share-based compensation | 10,066 |  |  | 8,957 |  |
| Other | (1,635) |  |  | (34) |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | 22,053 |  |  | 1,076 |  |
| Inventory | 13,144 |  |  | 17,228 |  |
| Accounts payable and accrued expenses | 20,519 |  |  | 6,770 |  |
| Operating leases | (11,698) |  |  | (11,698) |  |
| Other | 10,061 |  |  | 10,702 |  |
| Net cash flows from operating activities | 211,854 |  |  | 177,676 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (22,856) |  |  | (21,855) |  |
| Proceeds from sale of property, plant, and equipment | 34 |  |  | 866 |  |
| Acquisitions and investments | (55,915) |  |  | (20,827) |  |
| Other investing activities | (74) |  |  | 10 |  |
| Net cash flows from investing activities | (78,811) |  |  | (41,806) |  |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (21,073) |  |  | (90,943) |  |
| Proceeds from issuance of common stock | 3,721 |  |  | 3,194 |  |
| Purchases of common stock | (19,553) |  |  | (10,741) |  |
| Dividends paid | (29,675) |  |  | (27,671) |  |
| Purchase of redeemable non-controlling shares | — |  |  | (487) |  |
| Net cash flows from financing activities | (66,580) |  |  | (126,648) |  |
| Effect of exchange rate changes on cash | (81) |  |  | (3,990) |  |
| Net change in cash and equivalents | 66,382 |  |  | 5,232 |  |
| Cash and equivalents at beginning of period | 64,405 |  |  | 59,173 |  |
| Cash and equivalents at end of period | $ | 130,787 |  |  | $ | 64,405 |  |

[0000038725-21-000010:8k_2_02:48]
Key Performance Indicators: Earnings Per Share Calculations

[0000038725-21-000010:8k_2_02:49]
| Earnings Before and After Restructuring |  | For the Fourth Quarter |  | For the Full Year of |
| (in millions) |  | 2020 | 2019 | Change |  | 2020 | 2019 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 26.8 |  | $ | 19.8 |  | 35 | % |  | $ | 100.5 |  | $ | 95.5 |  | 5 | % |
| Allocated Earnings |  | $ | (0.2) |  | $ | (0.2) |  |  |  | $ | (0.7) |  | $ | (0.7) |  |  |
| Earnings for EPS Calculations |  | $ | 26.6 |  | $ | 19.6 |  | 36 | % |  | $ | 99.8 |  | $ | 94.8 |  | 5 | % |
| Restructuring (before tax): |  | $ | 0.3 |  | $ | 0.8 |  |  |  | $ | 2.5 |  | $ | 2.5 |  |  |
| Restructuring, net of tax: |  | $ | 0.2 |  | $ | 0.6 |  |  |  | $ | 2.0 |  | $ | 2.0 |  |  |
| Earnings Before Restructuring |  | $ | 26.8 |  | $ | 20.2 |  | 33 | % |  | $ | 101.8 |  | $ | 96.8 |  | 5 | % |
| Earnings Per Share |  | For the Fourth Quarter |  | For the Full Year of |
| Before and After Restructuring |  | 2020 | 2019 | Change |  | 2020 | 2019 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.8 |  | 46.8 |  | — | % |  | 46.7 |  | 46.8 |  | — | % |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.57 |  | $ | 0.42 |  | 36 | % |  | $ | 2.14 |  | $ | 2.03 |  | 5 | % |
| Restructuring Per Share, net of tax |  | $ | — |  | $ | 0.01 |  |  |  | $ | 0.04 |  | $ | 0.04 |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.57 |  | $ | 0.43 |  | 33 | % |  | $ | 2.18 |  | $ | 2.07 |  | 5 | % |

[0000038725-21-000010:8k_2_02:50]
Key Performance Indicators: Sales Summary

[0000038725-21-000010:8k_2_02:51]
|  | Net Sales For the Fourth Quarter |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q4 2019 | $ | 92.5 |  | $ | 33.7 |  | $ | 38.1 |  | $ | 23.9 |  | $ | 188.2 |  | $ | 77.3 |  | $ | 64.4 |  | $ | (9.8) |  | $ | 320.1 |  |
| Q4 2020 | $ | 94.1 |  | $ | 36.0 |  | $ | 41.3 |  | $ | 17.9 |  | $ | 189.3 |  | $ | 65.5 |  | $ | 77.9 |  | $ | (11.6) |  | $ | 321.1 |  |
| Change | $ | 1.6 |  | $ | 2.3 |  | $ | 3.2 |  | $ | (6.0) |  | $ | 1.1 |  | $ | (11.8) |  | $ | 13.5 |  | $ | (1.8) |  | $ | 1.0 |  |
| % Change | 2 | % | 7 | % | 8 | % | (25) | % | 1 | % | (15) | % | 21 | % |  | — | % |
| Foreign currency translation | $ | 0.1 |  | $ | (8.0) |  | $ | (2.5) |  | $ | 0.6 |  | $ | (9.8) |  | $ | 0.9 |  | $ | — |  |  |  |
| % Change | — | % | (24) | % | (7) | % | 3 | % | (5) | % | 1 | % | — | % |  |  |
| Acquisitions | $ | 4.1 |  | $ | — |  | $ | — |  | $ | — |  | $ | 4.1 |  | $ | — |  | $ | — |  |  |  |
| Volume/Price | $ | (2.6) |  | $ | 10.3 |  | $ | 5.7 |  | $ | (6.6) |  | $ | 6.8 |  | $ | (12.7) |  | $ | 13.5 |  |  |  |
| % Change | (3) | % | 31 | % | 15 | % | (28) | % | 4 | % | (16) | % | 21 | % |  |  |
|  | Net Sales For the Full Year |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| FY 2019 | $ | 419.9 |  | $ | 124.2 |  | $ | 155.6 |  | $ | 81.8 |  | $ | 781.5 |  | $ | 293.6 |  | $ | 291.8 |  | $ | (52.3) |  | $ | 1,314.6 |  |
| FY 2020 | $ | 388.5 |  | $ | 118.5 |  | $ | 156.8 |  | $ | 70.9 |  | $ | 734.7 |  | $ | 245.1 |  | $ | 328.4 |  | $ | (60.9) |  | $ | 1,247.3 |  |
| Change | $ | (31.4) |  | $ | (5.7) |  | $ | 1.2 |  | $ | (10.9) |  | $ | (46.8) |  | $ | (48.5) |  | $ | 36.6 |  | $ | (8.6) |  | $ | (67.3) |  |
| % Change | (7) | % | (5) | % | 1 | % | (13) | % | (6) | % | (17) | % | 13 | % |  | (5) | % |
| Foreign currency translation | $ | (0.7) |  | $ | (28.3) |  | $ | (10.8) |  | $ | (0.2) |  | $ | (40) |  | $ | 0.4 |  | $ | — |  |  |  |
| % Change | — | % | (23) | % | (7) | % | — | % | (5) | % | — | % | — | % |  |  |
| Acquisitions | $ | 12.8 |  | $ | — |  | $ | — |  | $ | — |  | $ | 12.8 |  | $ | — |  | $ | — |  |  |  |
| Volume/Price | $ | (43.5) |  | $ | 22.6 |  | $ | 12.0 |  | $ | (10.7) |  | $ | (19.6) |  | $ | (48.9) |  | $ | 36.6 |  |  |  |
| % Change | (10) | % | 18 | % | 8 | % | (13) | % | (3) | % | (17) | % | 13 | % |  |  |

[0000038725-21-000010:8k_2_02:52]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-21-000010:8k_2_02:53]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2020 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 30.4 |  | $ | 18.8 |  | $ | 0.5 |  | $ | (15.3) |  | $ | 34.4 |  |
| % Operating Income To Net Sales | 16.1 | % | 28.7 | % | 0.6 | % |  | 10.7 | % |
| Restructuring | $ | 0.3 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.3 |  |
| Operating Income/(Loss) Before Restructuring | $ | 30.7 |  | $ | 18.8 |  | $ | 0.5 |  | $ | (15.3) |  | $ | 34.7 |  |
| % Operating Income to Net Sales Before Restructuring | 16.2 | % | 28.7 | % | 0.6 | % |  | 10.8 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2019 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 24.5 |  | $ | 20.2 |  | $ | (2.5) |  | $ | (13.6) |  | $ | 28.6 |  |
| % Operating Income To Net Sales | 13.0 | % | 26.1 | % | (3.9) | % |  | 8.9 | % |
| Restructuring | $ | 0.8 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.8 |  |
| Operating Income/(Loss) Before Restructuring | $ | 25.3 |  | $ | 20.2 |  | $ | (2.5) |  | $ | (13.6) |  | $ | 29.4 |  |
| % Operating Income to Net Sales Before Restructuring | 13.4 | % | 26.1 | % | (3.9) | % |  | 9.2 | % |

[0000038725-21-000010:8k_2_02:54]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year of 2020 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 114.4 |  | $ | 63.4 |  | $ | 11.5 |  | $ | (58.8) |  | $ | 130.5 |  |
| % Operating Income To Net Sales | 15.6 | % | 25.9 | % | 3.5 | % |  | 10.5 | % |
| Restructuring | $ | 2.3 |  | $ | 0.1 |  | $ | 0.1 |  | $ | — |  | $ | 2.5 |  |
| Operating Income/(Loss) Before Restructuring | $ | 116.7 |  | $ | 63.5 |  | $ | 11.6 |  | $ | (58.8) |  | $ | 133.0 |  |
| % Operating Income to Net Sales Before Restructuring | 15.9 | % | 25.9 | % | 3.5 | % |  | 10.7 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year of 2019 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 103.0 |  | $ | 75.8 |  | $ | 3.6 |  | $ | (55.3) |  | $ | 127.1 |  |
| % Operating Income To Net Sales | 13.2 | % | 25.8 | % | 1.2 | % |  | 9.7 | % |
| Restructuring | $ | 1.7 |  | $ | — |  | $ | 0.8 |  | $ | — |  | $ | 2.5 |  |
| Operating Income/(Loss) Before Restructuring | $ | 104.7 |  | $ | 75.8 |  | $ | 4.4 |  | $ | (55.3) |  | $ | 129.6 |  |
| % Operating Income to Net Sales Before Restructuring | 13.4 | % | 25.8 | % | 1.5 | % |  | 9.9 | % |
