# FELE MD&A — 0000038725-21-000044


## mdna

[0000038725-21-000044:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-21-000044:mdna:2]
Discussion of the year-over-year comparison of changes in the Company's financial condition and results of operation as of and for the fiscal years ended December 31, 2019 and December 31, 2018 can be found in Part II, Item 7. "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our Annual Report on Form 10-K for the fiscal year ended December 31, 2019.

[0000038725-21-000044:mdna:3]
2020 vs. 2019

[0000038725-21-000044:mdna:4]
OVERVIEW

[0000038725-21-000044:mdna:5]
Sales in 2020 were down from the prior year. The sales decrease was primarily from lower volumes, in part created by uncertainty and general disruptions around the global pandemic relating to the transmission of COVID-19 and governmental and societal reactions thereto in the second quarter. The impact of foreign currency translation decreased sales by about 3 percent. The Company's consolidated gross profit was $433.1 million for 2020, an increase of $5.0 million or about 1 percent from 2019. The gross profit as a percent of net sales increased 210 basis points to 34.7 percent in 2020 from 32.6 percent in 2019. For 2020, diluted earnings per share were $2.14, up from 2019 diluted earnings per share of $2.03.

[0000038725-21-000044:mdna:6]
EFFECTS OF THE GLOBAL PANDEMIC

[0000038725-21-000044:mdna:7]
The top priority of the Company is the health and welfare of its employees and partners around the world. In response to the health risks posed by the Global Pandemic, the Company implemented and has been following the recommended hygiene and social distancing practices promulgated by the United States Centers for Disease Control and the World Health Organization.

[0000038725-21-000044:mdna:8]
The Company’s products and services are generally viewed as essential in most jurisdictions in which the Company operates. All the Company’s global manufacturing and distribution operations are operating with limited disruption.

[0000038725-21-000044:mdna:9]
The primary impacts of the Global Pandemic on the Company’s end markets remain consistent with prior disclosures. Large dewatering equipment sales in the Water Systems segment continue to be depressed and the deferral or cancellation of the construction of new filling stations in the Fueling Systems segment continues. The Company’s financial results are also impacted negatively by continuing government mandated closures and related customer behaviors.

[0000038725-21-000044:mdna:10]
RESULTS OF OPERATIONS

[0000038725-21-000044:mdna:11]
Net Sales

[0000038725-21-000044:mdna:12]
Net sales in 2020 were $1,247.3 million, a decrease of $67.3 million or about 5 percent compared to 2019 sales of $1,314.6 million. The incremental impact of sales from acquired businesses was $12.8 million. Sales revenue decreased by $39.6 million or 3 percent in 2020 due to foreign currency translation. The sales change in 2020, excluding acquisitions and foreign currency translation, was a decrease of about 3 percent.

[0000038725-21-000044:mdna:13]
|  | Net Sales |
| (In millions) | 2020 |  | 2019 |  | 2020 v 2019 |
| Water Systems | $ | 734.7 |  |  | $ | 781.5 |  |  | $ | (46.8) |  |
| Fueling Systems | 245.1 |  |  | 293.6 |  |  | (48.5) |  |
| Distribution | 328.4 |  |  | 291.8 |  |  | 36.6 |  |
| Eliminations/Other | (60.9) |  |  | (52.3) |  |  | (8.6) |  |
| Consolidated | $ | 1,247.3 |  |  | $ | 1,314.6 |  |  | $ | (67.3) |  |

[0000038725-21-000044:mdna:14]
Net Sales-Water Systems

[0000038725-21-000044:mdna:15]
Water Systems sales were $734.7 million in 2020, a decrease of $46.8 million or about 6 percent versus 2019. The incremental impact of sales from acquired businesses was $12.8 million. Foreign currency translation changes decreased sales $40.0 million, or about 5 percent, compared to sales in 2019. The Water Systems sales change in 2020, excluding acquisitions and foreign currency translation, was a decrease of $19.6 million or about 3 percent.

[0000038725-21-000044:mdna:16]
Water Systems sales in the U.S. and Canada decreased by about 7 percent compared to 2019. The incremental impact of sales from acquired businesses was $12.8 million. Sales revenue decreased by $0.7 million in 2020 due to foreign currency translation. In 2020, sales of dewatering equipment decreased by about 54 percent due to lower sales in rental channels and

[0000038725-21-000044:mdna:17]
substantial uncertainty in oil production end markets. Sales of groundwater pumping equipment increased by 12 percent versus 2019. Sales of other surface pumping equipment decreased by about 3 percent.

[0000038725-21-000044:mdna:18]
Water Systems sales in markets outside the U.S. and Canada decreased by about 4 percent compared to 2019. Sales revenue decreased by $39.3 million or about 11 percent in 2020 due to foreign currency translation. Sales change in 2020, excluding foreign currency translation, was an increase of about 7 percent. Sales growth in Latin America and EMENA were partially offset by lower sales in the Asia Pacific markets.

[0000038725-21-000044:mdna:19]
Net Sales-Fueling Systems

[0000038725-21-000044:mdna:20]
Fueling Systems sales were $245.1 million in 2020, a decrease of $48.5 million or about 17 percent from 2019. Foreign currency translation changes increased sales $0.4 million or less than 1 percent compared to sales in 2019. The Fueling Systems sales change in 2020, excluding foreign currency translation, was a decrease of $48.9 million or about 17 percent.

[0000038725-21-000044:mdna:21]
Fueling Systems sales in the U.S. and Canada declined by about 9 percent during 2020. The decrease was in all product lines and due to declining demand for new filling stations. Internationally, Fueling Systems revenues declined by about 28 percent, driven by lower sales in Asia Pacific, primarily China and India. China sales were about $18 million in 2020 compared to 2019 Fueling Systems China sales of about $45 million.

[0000038725-21-000044:mdna:22]
Net Sales-Distribution

[0000038725-21-000044:mdna:23]
Distribution sales were $328.4 million in 2020, versus 2019 sales of $291.8 million. Distribution segment organic sales increased about 13 percent compared to 2019. More favorable weather conditions in most of the United States versus the prior year contributed to the revenue growth.

[0000038725-21-000044:mdna:24]
Cost of Sales

[0000038725-21-000044:mdna:25]
Cost of sales as a percent of net sales for 2020 and 2019 was 65.3 percent and 67.4 percent, respectively. Correspondingly, the gross profit margin was 34.7 percent and 32.6 percent, respectively. The Company's consolidated gross profit was $433.1 million for 2020, up $5.0 million from the gross profit of $428.1 million in 2019. The increase in gross profit and gross profit margin was primarily driven by price realization, product sales mix and cost management.

[0000038725-21-000044:mdna:26]
Selling, General and Administrative (“SG&A”)

[0000038725-21-000044:mdna:27]
Selling, general, and administrative expenses were $300.1 million in 2020 and increased by $1.6 million or less than one percent overall compared to $298.5 million last year. SG&A expenses from acquired businesses was $2.2 million and excluding the acquired entities, the Company’s SG&A expenses in 2020 were $297.9 million, a decrease from the prior year. SG&A expenses were lower versus the prior year due to companywide efforts to lower spending in response to the impacts of the Global Pandemic and in part because of foreign currency translation.

[0000038725-21-000044:mdna:28]
Restructuring Expenses

[0000038725-21-000044:mdna:29]
Restructuring expenses for 2020 were $2.5 million. Restructuring expenses were $2.3 million in the Water segment and $0.1 million in each of the Fueling and Distribution segments. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution segment. Restructuring expenses for 2019 were $2.5 million. Restructuring expenses were $1.7 million in the Water segment and $0.8 million in the Distribution segment. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution segment.

[0000038725-21-000044:mdna:30]
Operating Income

[0000038725-21-000044:mdna:31]
Operating income was $130.5 million in 2020, up $3.4 million or 3 percent from $127.1 million in 2019.

[0000038725-21-000044:mdna:32]
|  |  | Operating income (loss) |
| (In millions) |  | 2020 |  | 2019 |  | 2020 v 2019 |
| Water Systems |  | $ | 114.4 |  |  | $ | 103.0 |  |  | $ | 11.4 |  |
| Fueling Systems |  | 63.4 |  |  | 75.8 |  |  | (12.4) |  |
| Distribution |  | 11.5 |  |  | 3.6 |  |  | 7.9 |  |
| Eliminations/Other |  | (58.8) |  |  | (55.3) |  |  | (3.5) |  |
| Consolidated |  | $ | 130.5 |  |  | $ | 127.1 |  |  | $ | 3.4 |  |

[0000038725-21-000044:mdna:33]
Operating Income-Water Systems

[0000038725-21-000044:mdna:34]
Water Systems operating income was $114.4 million in 2020 compared to $103.0 million in 2019, an increase of 11 percent. The operating income margin was 15.6 percent compared to the 2019 operating income margin of 13.2 percent. Operating income margin increased in Water Systems primarily driven by price realization, product sales mix and cost management.

[0000038725-21-000044:mdna:35]
Operating Income-Fueling Systems

[0000038725-21-000044:mdna:36]
Fueling Systems operating income was $63.4 million in 2020 compared to $75.8 million in 2019. The operating income margin was 25.9 percent compared to 25.8 percent of net sales in 2019. Operating income decreased in Fueling Systems primarily due to lower sales volumes. The increase in margin was primarily driven by cost management.

[0000038725-21-000044:mdna:37]
Operating Income-Distribution

[0000038725-21-000044:mdna:38]
Distribution operating income was $11.5 million in 2020 and operating income margin was 3.5 percent. Distribution operating income was $3.6 million in 2019 and operating income margin was 1.2 percent. Operating income and operating income margin increased in Distribution due to higher sales volumes.

[0000038725-21-000044:mdna:39]
Operating Income-Eliminations/Other

[0000038725-21-000044:mdna:40]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses. The inter-segment profit elimination impact in 2020 increased operating loss about $0.2 million. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its third-party customer. Unallocated general and administrative expenses were higher by $3.3 million or about 6 percent to last year, primarily due to higher variable performance-based compensation expenses.

[0000038725-21-000044:mdna:41]
Interest Expense

[0000038725-21-000044:mdna:42]
Interest expense for 2020 and 2019 was $4.6 million and $8.2 million, respectively, and decreased primarily as a result of lower debt levels.

[0000038725-21-000044:mdna:43]
Other Income or Expense

[0000038725-21-000044:mdna:44]
Other income or expense was a loss of $0.8 million and $0.4 million, respectively in 2020 and 2019.

[0000038725-21-000044:mdna:45]
Foreign Exchange

[0000038725-21-000044:mdna:46]
Foreign currency–based transactions produced a loss for 2020 of $1.4 million, primarily due to changes in the value of the Argentinian Peso relative to the U.S. dollar. Foreign currency–based transactions produced a loss for 2019 of $1.6 million, primarily due to changes in the value of the Argentinian Peso relative to the U.S. dollar.

[0000038725-21-000044:mdna:47]
Income Taxes

[0000038725-21-000044:mdna:48]
The provision for income taxes in 2020 and 2019 was $22.5 million and $20.8 million, respectively. The effective tax rate for 2020 was about 18 percent and before the impact of discrete events was about 21 percent. The effective tax rate for 2019 was about 18 percent and before the impact of discrete events was about 20 percent. The tax rate was lower than the statutory rate of 21 percent primarily due to foreign earnings taxed at lower statutory rates, as well as recognition of the U.S. deduction for Foreign Derived Intangible Income, and certain incentives and discrete events. Discrete events in 2020 include a benefit related to a realized foreign currency translation loss on the settlement of an intercompany loan.

[0000038725-21-000044:mdna:49]
Net Income

[0000038725-21-000044:mdna:50]
Net income for 2020 was $101.2 million compared to 2019 net income of $96.0 million. Net income attributable to Franklin Electric Co., Inc. for 2020 was $100.5 million, or $2.14 per diluted share, compared to 2019 net income attributable to Franklin Electric Co., Inc. of $95.5 million or $2.03 per diluted share.

[0000038725-21-000044:mdna:51]
CAPITAL RESOURCES AND LIQUIDITY

[0000038725-21-000044:mdna:52]
Sources of Liquidity

[0000038725-21-000044:mdna:53]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at December 31, 2020 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-21-000044:mdna:54]
As of December 31, 2020, the Company had a $300.0 million revolving credit facility. The facility is scheduled to mature on October 28, 2021. As of December 31, 2020, the Company had $295.9 million borrowing capacity under the Credit Agreement as $4.1 million in letters of commercial and standby letters of credit were outstanding and undrawn. No revolver borrowings were outstanding as of the end of the year.

[0000038725-21-000044:mdna:55]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of $125.0 million as of December 31, 2020. The New York Life Agreement matures on September 26, 2025. The Company also has other long-term debt borrowings outstanding as of December 31, 2020. See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-21-000044:mdna:56]
At December 31, 2020, the Company had $75 million of cash and cash equivalents held in foreign jurisdictions, which the Company intends to use to fund foreign operations. There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-21-000044:mdna:57]
Cash Flows

[0000038725-21-000044:mdna:58]
The following table summarizes significant sources and uses of cash and cash equivalents:

[0000038725-21-000044:mdna:59]
| (in thousands) | 2020 |  | 2019 |  | 2018 |
| Cash flows from operating activities | $ | 211.9 |  |  | $ | 177.7 |  |  | $ | 128.4 |  |
| Cash flows from investing activities | $ | (78.8) |  |  | $ | (41.8) |  |  | $ | (66.3) |  |
| Cash flows from financing activities | $ | (66.6) |  |  | $ | (126.7) |  |  | $ | (66.8) |  |
| Impact of exchange rates on cash and cash equivalents | $ | (0.1) |  |  | $ | (4.0) |  |  | $ | (3.4) |  |
| Change in cash and cash equivalents | $ | 66.4 |  |  | $ | 5.2 |  |  | $ | (8.1) |  |

[0000038725-21-000044:mdna:60]
Cash Flows from Operating Activities

[0000038725-21-000044:mdna:61]
2020 vs 2019

[0000038725-21-000044:mdna:62]
Net cash provided by operating activities was $211.9 million for 2020 compared to $177.7 million for 2019. The increase in cash provided by operating activities was primarily due to increased earnings and a decrease of $30.6 million in working capital requirements related to improved customer collections and inventory management and more favorable payment terms with vendors.

[0000038725-21-000044:mdna:63]
Cash Flows from Investing Activities

[0000038725-21-000044:mdna:64]
2020 vs. 2019

[0000038725-21-000044:mdna:65]
Net cash used in investing activities was $78.8 million in 2020 compared to $41.8 million in 2019. The increase was primarily attributable to increased acquisition activity.

[0000038725-21-000044:mdna:66]
Cash Flows from Financing Activities

[0000038725-21-000044:mdna:67]
2020 vs. 2019

[0000038725-21-000044:mdna:68]
Net cash used in financing activities was $66.6 million in 2020 compared to $126.7 million in 2019. The decrease in cash used in financing activities was primarily attributable to a decrease in net debt repayments, down approximately $70 million in the current year. Other uses of cash in financing activities include an increase in dividend payments of $2.0 million and an increase in common stock repurchases of $8.8 million.

[0000038725-21-000044:mdna:69]
AGGREGATE CONTRACTUAL OBLIGATIONS

[0000038725-21-000044:mdna:70]
The majority of the Company’s contractual obligations to third parties relate to debt obligations. In addition, the Company has certain contractual obligations for future lease payments and purchase obligations. The payment schedule for these contractual obligations is as follows:

[0000038725-21-000044:mdna:71]
| (In millions) |  |  |  |  |  |  |  |  | More than |
|  | Total |  | 2021 |  | 2022-2023 |  | 2024-2025 |  | 5 years |
| Debt | $ | 94.6 |  |  | $ | 2.5 |  |  | $ | 2.6 |  |  | $ | 77.8 |  |  | $ | 11.7 |  |
| Debt interest | 19.7 |  |  | 3.8 |  |  | 7.2 |  |  | 7.0 |  |  | 1.7 |  |
| Operating leases | 34.4 |  |  | 11.9 |  |  | 13.9 |  |  | 5.1 |  |  | 3.5 |  |
| Purchase obligations | 9.1 |  |  | 9.1 |  |  | — |  |  | — |  |  | — |  |
| Income Taxes-U.S. Tax Cuts and Jobs Act transition tax | $ | 14.7 |  |  | $ | 1.5 |  |  | $ | 4.5 |  |  | $ | 8.7 |  |  | $ | — |  |
|  | $ | 172.5 |  |  | $ | 28.8 |  |  | $ | 28.2 |  |  | $ | 98.6 |  |  | $ | 16.9 |  |

[0000038725-21-000044:mdna:72]
The Company has pension and other post-retirement benefit obligations not included in the table above which will result in estimated future payments of approximately $1 million in 2021. The Company also has unrecognized tax benefits, none of which are included in the table above. The unrecognized tax benefits of approximately $0.6 million have been recorded as liabilities and the Company is uncertain as to if or when such amounts may be settled. Related to the unrecognized tax benefits, the Company has also recorded a liability for potential penalties and interest of $0.1 million.

[0000038725-21-000044:mdna:73]
ACCOUNTING PRONOUNCEMENTS

[0000038725-21-000044:mdna:74]
For information regarding recent accounting pronouncements, refer to Note 2 - Accounting Pronouncements, in the Notes to Consolidated Financial Statements in the sections entitled ""Adoption of New Accounting Standards" and "Accounting Standards Issued But Not Yet Adopted", included in Part II, Item 8, "Financial Statements and Supplementary Data" of this Annual Report on Form 10-K.

[0000038725-21-000044:mdna:75]
CRITICAL ACCOUNTING ESTIMATES

[0000038725-21-000044:mdna:76]
Management’s discussion and analysis of its financial condition and results of operations are based upon the Company’s consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires management to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and the related disclosure of contingent assets and liabilities. Management evaluates estimates on an ongoing basis. Estimates are based on historical experience and on other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. There were no material changes to estimates or methodologies used to develop those estimates in 2020.

[0000038725-21-000044:mdna:77]
The Company’s critical accounting estimates are identified below:

[0000038725-21-000044:mdna:78]
Inventory Valuation

[0000038725-21-000044:mdna:79]
The Company uses certain estimates and judgments to value inventory. Inventory is recorded at the lower of cost or market. The Company reviews its inventories for excess or obsolete products or components. Based on an analysis of historical usage, management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts, carrying values are adjusted. The carrying value is reduced regularly to reflect the age and current anticipated product demand. If actual demand differs from the estimates, additional reductions would be necessary in the period such determination is made. Excess and obsolete inventory is periodically disposed of through sale to third parties, scrapping, or other means.

[0000038725-21-000044:mdna:80]
Business Combinations

[0000038725-21-000044:mdna:81]
The Company follows the guidance under FASB Accounting Standards Codification (“ASC”) Topic 805, Business Combinations. The acquisition purchase price is allocated to the assets acquired and liabilities assumed based upon their respective fair values. The Company shall report in its financial statements provisional amounts for the items for which accounting is incomplete. Goodwill is adjusted for any changes to provisional amounts made within the measurement period. The Company utilizes management estimates and an independent third-party valuation firm to assist in determining the fair values of assets acquired and liabilities assumed. Such estimates and valuations require the Company to make significant assumptions, including projections of future events and operating performance. The Company has not made any material changes to the method of valuing fair values of assets acquired and liabilities assumed during the last three years.

[0000038725-21-000044:mdna:82]
Trade Names and Goodwill

[0000038725-21-000044:mdna:83]
According to FASB ASC Topic 350, Intangibles - Goodwill and Other, intangible assets with indefinite lives must be tested for impairment at least annually or more frequently as warranted by triggering events that indicate potential impairment. The Company uses a variety of methodologies in conducting impairment assessments including income and market approaches. For indefinite-lived assets apart from goodwill, primarily trade names for the Company, if the fair value is less than the carrying amount, an impairment charge is recognized in an amount equal to that excess. The Company has not made any material changes to the method of evaluating impairments during the last three years.

[0000038725-21-000044:mdna:84]
In compliance with FASB ASC Topic 350, goodwill is not amortized. Goodwill is tested at the reporting unit level for impairment annually or more frequently as warranted by triggering events that indicate potential impairment. Reporting units are operating segments or one level below, known as components, which can be aggregated for testing purposes. The Company’s goodwill is allocated to the Global Water Systems, Fueling Systems and Distribution units. As the Company’s business model evolves, management will continue to evaluate its reporting units and review the aggregation criteria.

[0000038725-21-000044:mdna:85]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the market value and income approaches. The market value approach compares the reporting units’ current and projected financial results to entities of similar size and industry to determine the market value of the reporting unit. The income approach utilizes assumptions regarding estimated future cash flows and other factors to determine the fair value of the respective assets. These cash flows consider factors regarding expected future operating income and historical trends, as well as the effects of demand and competition. The Company may be required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units is below their associated carrying values. Goodwill included on the balance sheet as of the fiscal year ended 2020 was $266.7 million.

[0000038725-21-000044:mdna:86]
During the fourth quarter of 2020, the Company completed its annual impairment test of goodwill and trade names and determined the fair value of all intangibles were substantially in excess of the respective carrying values. Significant judgment is required to determine if an indication of impairment has taken place. Factors to be considered include the following: adverse changes in operating results, decline in strategic business plans, significantly lower future cash flows, and sustainable declines in market data such as market capitalization. A 10 percent decrease in the fair value estimates used in the impairment test would not have changed this determination. The sensitivity analysis required the use of numerous subjective assumptions, which, if actual experience varies, could result in material differences in the requirements for impairment charges. Further, an extended downturn in the economy may impact certain components of the operating segments more significantly and could result in changes to the aggregation assumptions and impairment determination.

[0000038725-21-000044:mdna:87]
Income Taxes

[0000038725-21-000044:mdna:88]
Under the requirements of FASB ASC Topic 740, Income Taxes, the Company records deferred tax assets and liabilities for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company analyzes the deferred tax assets and liabilities for their future realization based on the estimated existence of sufficient taxable income. This analysis considers the following sources of taxable income: prior year taxable income, future reversals of existing taxable temporary differences, future taxable income exclusive of reversing temporary differences and tax planning strategies that would generate taxable income in the relevant period. If sufficient taxable income is not projected then the Company will record a valuation allowance against the relevant deferred tax assets.

[0000038725-21-000044:mdna:89]
The Company’s operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions. These jurisdictions have different tax rates, and the Company determines the allocation of income to each of these jurisdictions based upon various estimates and assumptions. In the normal course of business, the Company will undergo tax audits by various tax jurisdictions. Such audits often require an extended period of time to complete and may result in income tax adjustments if changes to the allocation are required between jurisdictions with different tax rates. The final taxes paid are dependent upon many factors, including negotiations with taxing authorities in the various jurisdictions and resolution of disputes arising from federal, state, and international tax audits. Although the Company has recorded all income tax uncertainties in accordance with FASB ASC Topic 740, these accruals represent estimates that are subject to the inherent uncertainties associated with the tax audit process, and therefore include uncertainties. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, which, if actual experience varies, could result in material adjustments to tax expense and/or deferred tax assets and liabilities.

[0000038725-21-000044:mdna:90]
Pension and Employee Benefit Obligations

[0000038725-21-000044:mdna:91]
The Company consults with its actuaries to assist with the calculation of discount rates used in its pension and post retirement plans. The discount rates used to determine domestic pension and post-retirement plan liabilities are calculated using a full yield curve approach. Market conditions have caused the weighted-average discount rate to move from 3.12 percent last year to 2.31 percent this year for the domestic pension plans and from 2.98 percent last year to 2.12 percent this year for the postretirement health and life insurance plan. A change in the discount rate selected by the Company of 25 basis points would result in a change of about $0.1 million to employee benefit expense and a change of about $4.2 million of liability.

[0000038725-21-000044:mdna:92]
The Company consults with actuaries and investment advisors in making its determination of the expected long-term rate of return on plan assets. Using input from these consultations such as long-term investment sector expected returns, the correlations and standard deviations thereof, and the plan asset allocation, the Company has assumed an expected long-term rate of return on plan assets of 4.00 percent as of the fiscal year ended 2020. Market conditions have caused the expected long-term rate of return to decrease from 4.90 percent as of the fiscal year ended 2019. A change in the long-term rate of return selected by the Company of 25 basis points would result in a change of about $0.4 million of employee benefit expense.

[0000038725-21-000044:mdna:93]
FACTORS THAT MAY AFFECT FUTURE RESULTS
