# FELE notes — 0000038725-17-000042


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000038725-17-000042:notes:1]
ACCRUED EXPENSES AND OTHER CURRENT LIABILITIES

[0000038725-17-000042:notes:2]
Accrued expenses and other current liabilities consist of:

[0000038725-17-000042:notes:3]
| (In millions) |  | 2016 |  | 2015 |
| Salaries, wages, and commissions |  | $ | 28.4 |  |  | $ | 20.5 |  |
| Product warranty costs |  | 8.2 |  |  | 9.3 |  |
| Insurance |  | 2.0 |  |  | 2.7 |  |
| Employee benefits |  | 7.9 |  |  | 11.0 |  |
| Other |  | 10.3 |  |  | 8.6 |  |
|  |  | $ | 56.8 |  |  | $ | 52.1 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-17-000042:notes:4]
ACQUISITIONS

[0000038725-17-000042:notes:5]
In 2012, the Company acquired a controlling interest in Pioneer Pump Holdings, Inc. ("PPH").  Pursuant to the terms of the 2012 stock purchase agreement, the remaining 29.5 percent noncontrolling interest was recorded at $22.9 million and accounted for as a share purchase liability.  During the first quarter of 2015, the Company purchased the remaining 29.5 percent of outstanding shares of PPH for $20.2 million, increasing the Company's ownership in PPH to 100 percent.  The purchase was considered the settlement of a financing obligation, and the resulting $2.7 million gain was recorded in the Company's consolidated statements of income in the "Other income, net" line during the first quarter of 2015.

[0000038725-17-000042:notes:6]
During the third quarter of 2014, the Company acquired controlling interests in two entities in India in separate unrelated transactions.  Neither of the acquisitions was individually material, and the combined purchase price paid was approximately $6.6 million.  The results of the two businesses from their respective dates of acquisition through January 3, 2015 were not material.

[0000038725-17-000042:notes:7]
In an agreement dated June 6, 2014, between the Company and Bombas Leao S.A. ("Bombas Leao"), the Company acquired rights to 100 percent of the outstanding shares of Bombas Leao for a cash purchase price of approximately BRL 69.6 million, $31.0 million at the then current exchange rate, subject to certain terms and conditions. The Company also acquired debt and certain liabilities of Bombas Leao. The Company funded the acquisition with cash on hand and short-term borrowings from the Company's revolving credit agreement.

[0000038725-17-000042:notes:8]
Bombas Leao, based in Monte Azul Paulista, State of Sao Paulo, Brazil, designs, manufactures, and distributes submersible groundwater pumping equipment through manufacturing and distribution facilities.

[0000038725-17-000042:notes:9]
The Bombas Leao intangible assets of $23.5 million consist primarily of customer relationships, which will be amortized utilizing the straight line method over 20 years, and trade names, which are classified as indefinite lived assets and will not be amortized.

[0000038725-17-000042:notes:10]
The goodwill amount of $3.4 million resulting from the Bombas Leao acquisition consists primarily of broadened product offerings and expanded customer base. All of the goodwill was recorded as part of the Water Systems segment and is not expected to be deductible for tax purposes.

[0000038725-17-000042:notes:11]
Preliminary goodwill increased by $0.3 million and current assets decreased by $0.3 million during 2015 due to working capital adjustments.  In addition, the Company paid an additional $0.3 million to the sellers of Bombas Leao during 2015 to satisfy amounts previously accrued per the original purchase agreement.

[0000038725-17-000042:notes:12]
The final purchase price assigned to the major identifiable assets and liabilities for the Bombas Leao acquisition is as follows:

[0000038725-17-000042:notes:13]
| (In millions) |  |
| Assets: |  |
| Cash acquired | $ | 1.1 |  |
| Current assets | 13.4 |  |
| Property, plant, and equipment | 6.5 |  |
| Intangible assets | 23.5 |  |
| Goodwill | 3.4 |  |
| Other assets | 3.1 |  |
| Total assets | 51.0 |  |
| Liabilities | (20.0 | ) |
| Total consideration paid | $ | 31.0 |  |

[0000038725-17-000042:notes:14]
The fair values of the identifiable assets, property, plant, and equipment, and liabilities were final as of the second quarter of 2015.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation.

[0000038725-17-000042:notes:15]
The results of operations of Bombas Leao were included in the Company's consolidated statements of income from the acquisition date through the year ended January 3, 2015.  The difference between actual sales for the Company and proforma sales including Bombas Leao as if it was acquired at the beginning of the year was not material as a component of the Company's consolidated sales for the year ended January 3, 2015.  Due to the immaterial nature of the acquisition, the Company has not included full year proforma statements of income for the acquisition year.

[0000038725-17-000042:notes:16]
Transaction costs for all acquisition related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations.  Transaction costs included in selling, general, and administrative expense in the Company’s consolidated statements of income were $0.1 million, $0.2 million, and $2.4 million for the fiscal years ended 2016, 2015, and 2014, respectively.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000038725-17-000042:notes:17]
Cash and Cash Equivalents--The Company considers cash on hand, demand deposits, and highly liquid investments with an original maturity date of three months or less to be cash and cash equivalents.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-17-000042:notes:18]
COMMITMENTS AND CONTINGENCIES

[0000038725-17-000042:notes:19]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-17-000042:notes:20]
Total rent expense charged to operations for operating leases including contingent rentals was $11.7 million, $11.9 million, and $12.6 million in 2016, 2015, and 2014, respectively.

[0000038725-17-000042:notes:21]
The future minimum rental payments for non-cancelable operating leases as of December 31, 2016, are as follows:

[0000038725-17-000042:notes:22]
| (In millions) | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Future minimum rental payments | $ | 7.4 |  |  | $ | 5.2 |  |  | $ | 4.0 |  |  | $ | 2.4 |  |  | $ | 1.7 |  |  | $ | 0.7 |  |

[0000038725-17-000042:notes:23]
At December 31, 2016, the Company had $10.8 million of commitments primarily for capital expenditures and the purchase of raw materials to be used in production.

[0000038725-17-000042:notes:24]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's consolidated balance sheets for 2016 and 2015, are as follows:

[0000038725-17-000042:notes:25]
| (In millions) |  | 2016 |  | 2015 |
| Beginning balance |  | $ | 9.3 |  |  | $ | 9.4 |  |
| Accruals related to product warranties |  | 5.9 |  |  | 7.6 |  |
| Reductions for payments made |  | (7.0 | ) |  | (7.7 | ) |
| Ending balance |  | $ | 8.2 |  |  | $ | 9.3 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-17-000042:notes:26]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)

[0000038725-17-000042:notes:27]
Changes in accumulated other comprehensive income/(loss), net of tax, by component are summarized below:

[0000038725-17-000042:notes:28]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance, December 28, 2013 | $ | (16.0 | ) |  | $ | (38.7 | ) |  | $ | (54.7 | ) |
| Other comprehensive income/(loss) before reclassifications | (35.8 | ) |  | — |  |  | (35.8 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | (17.4 | ) |  | (17.4 | ) |
| Net other comprehensive income/(loss) | (35.8 | ) |  | (17.4 | ) |  | (53.2 | ) |
| Balance, January 3, 2015 | $ | (51.8 | ) |  | $ | (56.1 | ) |  | $ | (107.9 | ) |
| Other comprehensive income/(loss) before reclassifications | (58.3 | ) |  | — |  |  | (58.3 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 4.6 |  |  | 4.6 |  |
| Net other comprehensive income/(loss) | (58.3 | ) |  | 4.6 |  |  | (53.7 | ) |
| Balance, January 2, 2016 | $ | (110.1 | ) |  | $ | (51.5 | ) |  | $ | (161.6 | ) |
| Other comprehensive income/(loss) before reclassifications | (8.3 | ) |  | — |  |  | (8.3 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | — |  |  | — |  |
| Net other comprehensive income/(loss) | (8.3 | ) |  | — |  |  | (8.3 | ) |
| Balance, December 31, 2016 | $ | (118.4 | ) |  | $ | (51.5 | ) |  | $ | (169.9 | ) |

[0000038725-17-000042:notes:29]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 8 for additional details) and is included in the "Selling, general, and administrative expenses" line of the Company's consolidated statements of income.

[0000038725-17-000042:notes:30]
(2) Net of tax (benefit)/expense of $0.5 million, $2.5 million and $(8.6) million for 2016, 2015, and 2014, respectively.

[0000038725-17-000042:notes:31]
Amounts related to noncontrolling interests were not material.


## us-gaap:ConsolidationPolicyTextBlock

[0000038725-17-000042:notes:32]
Principles of Consolidation--The consolidated financial statements include the accounts of Franklin Electric Co., Inc. and its consolidated subsidiaries.  All intercompany transactions have been eliminated.


## us-gaap:DebtDisclosureTextBlock

[0000038725-17-000042:notes:33]
DEBT

[0000038725-17-000042:notes:34]
Debt consisted of the following:

[0000038725-17-000042:notes:35]
| (In millions) |  | 2016 |  | 2015 |
| New York Life |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Prudential Agreement |  | 90.0 |  |  | 120.0 |  |
| Tax increment financing debt |  | 21.8 |  |  | 22.8 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.6 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | 190.2 |  |  | 220.7 |  |
| Less current maturities |  | (33.7 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 156.5 |  |  | $ | 187.8 |  |

[0000038725-17-000042:notes:36]
Debt outstanding at December 31, 2016, excluding unamortized debt issuance costs, matures as follows:

[0000038725-17-000042:notes:37]
| (In millions) |  | Total |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |
| Debt |  | $ | 190.4 |  |  | $ | 33.7 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 91.8 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 190.5 |  |  | $ | 33.7 |  |  | $ | 31.3 |  |  | $ | 31.3 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 91.8 |  |

[0000038725-17-000042:notes:38]
New York Life

[0000038725-17-000042:notes:39]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025.  These senior notes have a floating interest rate of one-month USD LIBOR (0.76 percent as of December 31, 2016) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  On October 28, 2016, the Company entered into the First Amendment to Note Purchase and Private Shelf Agreement.  The Amendment was intended to make the covenants within the New York Life Agreement consistent with the covenants that were modified in the Third Amended and Restated Credit Agreement (the "Credit Agreement").  As of December 31, 2016, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-17-000042:notes:40]
Project Bonds

[0000038725-17-000042:notes:41]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement.  Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)."  The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million.  The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum.  Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.  The use of the proceeds from the Project Notes was limited to assist the financing of the new Global Corporate Headquarters and Engineering Center.  On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-17-000042:notes:42]
Prudential Agreement

[0000038725-17-000042:notes:43]
On April 9, 2007, the Company entered into the Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") in the amount of $175.0 million.  Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”).  The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had at issuance an average life of 10 years with a final maturity in 2019.  On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million.  On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Agreement.  On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015.  On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement.   This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million.  On October 28, 2016, the Company entered into Amendment No. 1 to the Third Amended and Restated Note Purchase and Private Shelf Agreement.  This amendment was intended to make the covenants within the Prudential Agreement consistent with the covenants that were modified in the Credit Agreement (below).  As of December 31, 2016, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.

[0000038725-17-000042:notes:44]
Credit Agreement

[0000038725-17-000042:notes:45]
On October 28, 2016, the Company entered into the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement extended the maturity date of the Company’s previous credit agreement to October 28, 2021 and increased the commitment amount from $150.0 million to $300.0 million.  The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million) subject to the conditions contained therein. All of the Company's present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers' obligations under and in connection with the Credit Agreement. Additionally, the Company unconditionally guaranties all of the obligations of Franklin B.V. under the Credit Agreement.  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-17-000042:notes:46]
As of December 31, 2016, the Company had no outstanding borrowings, $5.9 million in letters of credit outstanding, and $294.1 million of available capacity under the Credit Agreement.  As of January 2, 2016, the Company had no outstanding borrowings, $5.2 million in letters of credit outstanding, and $144.8 million of available capacity under the Credit Agreement.

[0000038725-17-000042:notes:47]
Covenants

[0000038725-17-000042:notes:48]
The New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 (using net debt in the measure of leverage ratio, whereas the previous credit agreement used gross debt) and a minimum interest coverage ratio of 3.00 to 1.00 (using EBITDA in the measure, whereas the previous credit agreement used EBIT). Cross default is applicable with the Credit Agreement, the Prudential Agreement, the Project Bonds, and the New York Life Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million.  The Company was in compliance with all financial covenants as of December 31, 2016.


## us-gaap:DefinedContributionPlanDisclosuresTableTextBlock

[0000038725-17-000042:notes:49]
The following table sets forth Company contributions to the defined contribution plans:

[0000038725-17-000042:notes:50]
| (In millions) |  | 2016 |  | 2015 |  | 2014 |
| Company contributions to the plans |  | $ | 5.9 |  |  | $ | 5.9 |  |  | $ | 5.6 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-17-000042:notes:51]
FINANCIAL INSTRUMENTS

[0000038725-17-000042:notes:52]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements ("the swap") to mitigate the Company’s exposure to these fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  As of December 31, 2016, the swap has a notional value based on 205,000 shares.  For the years ended December 31, 2016, January 2, 2016, and January 3, 2015, the swap resulted in a gain of $2.2 million, and losses of $2.0 million and $0.8 million, respectively.  Gains/losses resulting from the swap were primarily offset by losses/gains on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-17-000042:notes:53]
SHARE-BASED COMPENSATION

[0000038725-17-000042:notes:54]
The Company maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the "2012 Stock Plan"), which is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards and stock unit awards to key employees and non-employee directors.

[0000038725-17-000042:notes:55]
The 2012 Stock Plan authorizes 2,400,000 shares for issuance as follows:

[0000038725-17-000042:notes:56]
| 2012 Stock Plan |  | Authorized Shares |
| Stock Options |  | 1,680,000 |
| Stock/Stock Unit Awards |  | 720,000 |

[0000038725-17-000042:notes:57]
The Company also maintains the Amended and Restated Franklin Electric Co., Inc. Stock Plan (the "2009 Stock Plan") which, as amended in 2009, provided for discretionary grants of stock options and stock awards.  The 2009 Stock Plan authorized 4,400,000 shares for issuance as follows:

[0000038725-17-000042:notes:58]
| 2009 Stock Plan | Authorized Shares |
| Stock Options | 3,200,000 |
| Stock Awards | 1,200,000 |

[0000038725-17-000042:notes:59]
All options in the 2009 Stock Plan have been awarded.

[0000038725-17-000042:notes:60]
The Company currently issues new shares from its common stock balance to satisfy option exercises and the settlement of stock awards and stock unit awards made under the 2009 Stock Plan and/or the 2012 Stock Plan.

[0000038725-17-000042:notes:61]
The total share-based compensation expense recognized in 2016, 2015, and 2014 was $6.9 million, $5.6 million, and $7.5 million, respectively.

[0000038725-17-000042:notes:62]
Stock Options:

[0000038725-17-000042:notes:63]
Under the above plans, the exercise price of each option equals the market price of the Company’s common stock on the date of grant, and the options expire 10 years after the date of the grant.  Options granted to employees vest at 25 percent a year and become fully vested and fully exercisable after 4 years (vesting is accelerated upon retirement, death, or disability).  Subject to the terms of the plans, in general, the aggregate option exercise price and any applicable tax withholdings may be satisfied in cash or its equivalent, by the plan participant’s delivery of shares of the Company’s common stock having a fair market value at the time of exercise equal to the aggregate option exercise price and/or the applicable tax withholdings or by having shares otherwise subject to the award withheld by the Company or via cashless exercise through a broker-dealer.

[0000038725-17-000042:notes:64]
The fair value of each option award is estimated on the date of grant using the Black-Scholes option valuation model with a single approach and amortized using a straight-line attribution method over the option’s vesting period.  Options granted to retirement eligible employees are immediately expensed.  The Company uses historical data to estimate the expected volatility of its stock, the weighted average expected life, the period of time options granted are expected to be outstanding, and its dividend yield.  The risk-free rates for periods within the contractual life of the option are based on the U.S. Treasury yield curve in effect at the time of the grant.

[0000038725-17-000042:notes:65]
The table below provides the weighted average grant-date fair values and key assumptions used for the Black-Scholes model to determine the fair value of options granted during 2016, 2015, and 2014:

[0000038725-17-000042:notes:66]
|  |  | 2016 |  | 2015 |  | 2014 |
| Risk-free interest rate |  | 1.21 | % |  | 1.59 | % |  | 1.68 | % |
| Dividend yield |  | 1.32 | % |  | 0.95 | % |  | 0.70 | % |
| Volatility factor |  | 37.70 | % |  | 37.90 | % |  | 38.70 | % |
| Expected term |  | 5.5 years |  |  | 5.5 years |  |  | 5.6 years |  |
| Weighted average grant-date fair value of options |  | $ | 9.18 |  |  | $ | 12.34 |  |  | $ | 15.09 |  |

[0000038725-17-000042:notes:67]
A summary of the Company’s outstanding stock option activity and related information is as follows:

[0000038725-17-000042:notes:68]
| (Shares in thousands) |  |  |  |  |  |  |  |  |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | AggregateIntrinsic Value (000’s) |
| Outstanding at beginning of 2016 |  | 1,472 |  |  | $ | 23.26 |  |  |  |  |  |
| Granted |  | 265 |  |  | 29.08 |  |  |  |  |  |
| Exercised |  | (273 | ) |  | 19.18 |  |  |  |  |  |
| Forfeited |  | (8 | ) |  | 33.68 |  |  |  |  |  |
| Expired |  | (1 | ) |  | 43.27 |  |  |  |  |  |
| Outstanding at end of 2016 |  | 1,455 |  |  | $ | 25.02 |  |  | 5.50 years |  | $ | 20,592 |  |
| Expected to vest after applying forfeiture rate |  | 1,433 |  |  | $ | 24.92 |  |  | 5.45 years |  | $ | 20,433 |  |
| Vested and exercisable at end of period |  | 977 |  |  | $ | 21.15 |  |  | 4.05 years |  | $ | 17,548 |  |

[0000038725-17-000042:notes:69]
| (In millions) |  | 2016 |  | 2015 |  | 2014 |
| Intrinsic value of options exercised |  | $ | 5.2 |  |  | $ | 1.7 |  |  | $ | 3.8 |  |
| Cash received from the exercise of options |  | 5.2 |  |  | 2.0 |  |  | 2.9 |  |
| Fair value of shares vested |  | 1.7 |  |  | 1.4 |  |  | 2.8 |  |
| Tax benefit of options exercised |  | 1.9 |  |  | 0.7 |  |  | 1.5 |  |

[0000038725-17-000042:notes:70]
As of December 31, 2016, there was $1.7 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.15 years.

[0000038725-17-000042:notes:71]
Stock/Stock Unit Awards:

[0000038725-17-000042:notes:72]
Under the 2009 Stock Plan, non-employee directors and employees may be granted stock awards.  Under the 2012 Stock Plan, non-employee directors and employees may be granted stock awards and stock units.

[0000038725-17-000042:notes:73]
Stock awards to non-employee directors are generally fully vested when made.  Stock/stock unit awards to employees cliff vest over 3 or 4 years (subject to accelerated vesting of a pro rata portion in the case of retirement, death or disability) and may be contingent on the attainment of certain performance goals.  Dividends are paid to the recipient prior to vesting, except that dividends on performance-based stock awards under the 2012 Stock Plan will be paid only to the extent the performance goals are met.

[0000038725-17-000042:notes:74]
Stock/stock unit awards granted to retirement eligible employees are expensed over the vesting period.  Compensation cost for the performance stock/stock unit awards is accrued based on the probable outcome of specified performance conditions.

[0000038725-17-000042:notes:75]
A summary of the Company’s restricted stock/stock unit award activity and related information is as follows:

[0000038725-17-000042:notes:76]
| (Shares in thousands) |  |  |  |  |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of 2016 |  | 510 |  |  | $ | 34.43 |  |
| Awarded |  | 172 |  |  | 29.45 |  |
| Vested |  | (175 | ) |  | 28.35 |  |
| Forfeited |  | (34 | ) |  | 34.16 |  |
| Non-vested at end of 2016 |  | 473 |  |  | $ | 34.89 |  |

[0000038725-17-000042:notes:77]
The weighted-average grant date fair value of restricted stock/stock unit awards granted in 2016, 2015, and 2014, is $29.45, $36.27, and $42.39, respectively.

[0000038725-17-000042:notes:78]
As of December 31, 2016, there was $8.1 million of total unrecognized compensation cost related to non-vested stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.21 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000038725-17-000042:notes:79]
Earnings Per Common Share--Basic and diluted earnings per share are computed and disclosed in accordance with FASB ASC Topic 260, Earnings Per Share.  The Company utilizes the two-class method to compute earnings available to common shareholders.  Under the two-class method, earnings are adjusted by accretion amounts to redeemable noncontrolling interests recorded at redemption value.  The adjustments represent dividend distributions, in substance, to the noncontrolling interest holder as the holders have contractual rights to receive an amount upon redemption other than the fair value of the applicable shares.  As a result, earnings are adjusted to reflect this in substance distribution that is different from other common shareholders.  In addition, the Company allocates net earnings to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company's participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.  Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.


## us-gaap:EarningsPerShareTextBlock

[0000038725-17-000042:notes:80]
EARNINGS PER SHARE

[0000038725-17-000042:notes:81]
The Company calculates basic and diluted earnings per common share using the two-class method.  Under the two-class method, net earnings are allocated to each class of common stock and participating security as if all of the net earnings for the period had been distributed.  The Company's participating securities consist of share-based payment awards that contain a nonforfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.

[0000038725-17-000042:notes:82]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-17-000042:notes:83]
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-17-000042:notes:84]
| (In millions, except per share amounts) |  | 2016 |  | 2015 |  | 2014 |
| Numerator: |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. |  | $ | 78.7 |  |  | $ | 72.9 |  |  | $ | 69.8 |  |
| Less: Undistributed earnings allocated to participating securities |  | 0.7 |  |  | 0.7 |  |  | 0.7 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest |  | 1.0 |  |  | 0.8 |  |  | 0.9 |  |
| Net income available to common shareholders |  | $ | 77.0 |  |  | $ | 71.4 |  |  | $ | 68.2 |  |
| Denominator: |  |  |  |  |  |  |
| Basic weighted average common shares outstanding |  | 46.2 |  |  | 47.1 |  |  | 47.7 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Diluted weighted average common shares outstanding |  | 46.7 |  |  | 47.6 |  |  | 48.2 |  |
| Basic earnings per share |  | $ | 1.67 |  |  | $ | 1.52 |  |  | $ | 1.43 |  |
| Diluted earnings per share |  | $ | 1.65 |  |  | $ | 1.50 |  |  | $ | 1.41 |  |

[0000038725-17-000042:notes:85]
There were 0.4 million, 0.3 million, and 0.1 million stock options outstanding as of 2016, 2015, and 2014, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000038725-17-000042:notes:86]
OTHER ASSETS

[0000038725-17-000042:notes:87]
The Company has equity interests in various companies for strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s consolidated balance sheet.  The carrying amount of the investments is adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income, net" line of the Company's consolidated statements of income, were immaterial for the years ended December 31, 2016, January 2, 2016, and January 3, 2015.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-17-000042:notes:88]
As of December 31, 2016 and January 2, 2016, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-17-000042:notes:89]
| (In millions) |  | December 31, 2016 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 3.6 |  |  | $ | 3.6 |  |  | $ | — |  |  | $ | — |  |  |
|  |  | January 2, 2016 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 3.9 |  |  | $ | 3.9 |  |  | $ | — |  |  | $ | — |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-17-000042:notes:90]
FAIR VALUE MEASUREMENTS

[0000038725-17-000042:notes:91]
The Company's Level 1 assets consist of cash equivalents which are generally comprised of foreign bank guaranteed certificates of deposit.

[0000038725-17-000042:notes:92]
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3.

[0000038725-17-000042:notes:93]
Total debt, including current maturities, have carrying amounts of $190.2 million at December 31, 2016 and $220.7 million at January 2, 2016.  The estimated fair value of all debt was $195 million and $225 million at December 31, 2016 and January 2, 2016, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.

[0000038725-17-000042:notes:94]
As of December 31, 2016, the Company had no assets held for sale.  As of January 2, 2016, $1.6 million of assets were held for sale, recorded at carrying value in the Water Systems segment relating to an idle facility in Brazil.  The sale of the facility in Brazil was completed during 2016.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000038725-17-000042:notes:95]
Translation of Foreign Currency Financial Statements--All assets and liabilities of foreign subsidiaries in functional currency other than the U.S. dollar are translated at year end exchange rates.  All revenue and expense accounts are translated at average rates in effect during the respective period.  Adjustments for translating longer term foreign currency assets and liabilities in U.S. dollars are included as a component of other comprehensive income.  Transaction gains and losses that arise from shorter term exchange rate fluctuations are included in the “Foreign exchange income/(expense)" line within the Company's consolidated statements of income, as incurred.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-17-000042:notes:96]
GOODWILL AND OTHER INTANGIBLE ASSETS

[0000038725-17-000042:notes:97]
The carrying amounts of the Company’s intangible assets are as follows:

[0000038725-17-000042:notes:98]
| (In millions) |  | 2016 |  | 2015 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.4 |  |  | $ | (6.4 | ) |  | $ | 7.4 |  |  | $ | (6.2 | ) |
| Technology |  | 7.5 |  |  | (5.3 | ) |  | 7.5 |  |  | (4.8 | ) |
| Customer relationships |  | 133.4 |  |  | (49.6 | ) |  | 132.6 |  |  | (42.3 | ) |
| Other |  | 2.7 |  |  | (2.1 | ) |  | 3.5 |  |  | (2.7 | ) |
| Total |  | $ | 151.0 |  |  | $ | (63.4 | ) |  | $ | 151.0 |  |  | $ | (56.0 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 47.1 |  |  | — |  |  | 46.4 |  |  | — |  |
| Total intangibles |  | $ | 198.1 |  |  | $ | (63.4 | ) |  | $ | 197.4 |  |  | $ | (56.0 | ) |

[0000038725-17-000042:notes:99]
Amortization expense related to intangible assets for fiscal years 2016, 2015, and 2014, was $8.4 million, $8.6 million, and $9.1 million, respectively.

[0000038725-17-000042:notes:100]
Amortization expense for each of the five succeeding years is projected as follows:

[0000038725-17-000042:notes:101]
| (In millions) |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 |
|  |  | $ | 8.4 |  |  | $ | 8.3 |  |  | $ | 8.2 |  |  | $ | 8.1 |  |  | $ | 7.7 |  |

[0000038725-17-000042:notes:102]
The change in the carrying amount of goodwill by reporting segment for 2016 and 2015, is as follows:

[0000038725-17-000042:notes:103]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of January 3, 2015 |  | $ | 145.3 |  |  | $ | 63.5 |  |  | $ | 208.8 |  |
| Adjustments to prior year acquisitions |  | (0.9 | ) |  | (0.2 | ) |  | (1.1 | ) |
| Foreign currency translation |  | (7.6 | ) |  | (0.3 | ) |  | (7.9 | ) |
| Balance as of January 2, 2016 |  | $ | 136.8 |  |  | $ | 63.0 |  |  | $ | 199.8 |  |
| Acquisitions |  | — |  |  | 0.8 |  |  | 0.8 |  |
| Foreign currency translation |  | (0.5 | ) |  | (0.5 | ) |  | (1.0 | ) |
| Balance as of December 31, 2016 |  | $ | 136.3 |  |  | $ | 63.3 |  |  | $ | 199.6 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000038725-17-000042:notes:104]
Goodwill and Other Intangible Assets--Goodwill is tested at the reporting unit level, which the Company has determined to be the North America Water Systems, International Water, and Fueling Systems units.  In compliance with FASB ASC Topic 350, Intangibles - Goodwill and Other, the Company has evaluated the aggregation criteria and determined that the individual components within the North America Water Systems and International Water reporting units, respectively, can be aggregated in 2016.

[0000038725-17-000042:notes:105]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the income and market valuation approaches.  The income approach estimates fair value based upon future revenue, expenses, and cash flows discounted to present value.  The market valuation approach estimates fair value using market multipliers of various financial measures compared to a set of comparable public companies.  The fair value calculated for each reporting unit is considered a Level 3 measurement within the fair value hierarchy.

[0000038725-17-000042:notes:106]
An indication of impairment exists if the carrying value of the reporting unit is higher than its fair value, as determined by the above approach.  The second step of testing as outlined in FASB ASC Topic 350 must be performed to measure the amount of impairment loss.  The amount of impairment is determined by comparing the implied fair value of the reporting unit's goodwill to its carrying value in the same manner as if the reporting units were being acquired in a business combination.  The Company would allocate the fair value to all of the reporting unit's assets and liabilities, including any unrecognized intangible assets, in a hypothetical analysis that would calculate the implied fair value of goodwill.  The Company would record an impairment charge for the difference between the implied fair value of goodwill and the recorded goodwill.

[0000038725-17-000042:notes:107]
The Company currently tests goodwill for impairment on an annual basis using balances as of period 8, or more frequently as warranted by triggering events that indicate potential impairment.  Beginning in 2017, the Company will complete its annual goodwill impairment test during the fourth quarter, using balances as of October 1.  The change in goodwill impairment testing date is deemed a change in accounting principle which management determined to be preferable.  The change was made to better align with the timing of the Company's annual and long-term planning processes, which are significant elements of the testing.

[0000038725-17-000042:notes:108]
In connection with the change in date of the annual goodwill impairment test, the Company performed a qualitative assessment of goodwill as of October 1, 2016 to ensure that a period of greater than 12 months did not elapse between test dates.  The Company did not recognize a goodwill impairment as a result of the qualitative assessment.  The change in annual goodwill impairment testing dates did not delay, accelerate, or avoid a goodwill impairment charge.

[0000038725-17-000042:notes:109]
The Company also tests indefinite lived intangible assets, primarily trade names, for impairment on an annual basis during the fourth quarter of each year, or more frequently as warranted by triggering events that indicate potential impairment.  In assessing the recoverability of the trade names, the Company determines the fair value using an income approach.  The income approach estimates fair value based upon future revenue and estimated royalty rates.  The fair value calculated for indefinite lived intangible assets is considered a Level 3 measurement within the fair value hierarchy.  An indication of impairment exists if the carrying value of the trade names is higher than the fair value.  The Company would record an impairment charge for the difference.

[0000038725-17-000042:notes:110]
Amortization is recorded and calculated for other definite lived intangible assets on a basis that reflects cash flows over the estimated useful lives.  The weighted average number of years over which each intangible class is amortized is as follows:

[0000038725-17-000042:notes:111]
| Patents | 17 years |
| Technology | 15 years |
| Customer relationships | 13-20 years |
| Other | 5-8 years |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-17-000042:notes:112]
INCOME TAXES

[0000038725-17-000042:notes:113]
Income before income taxes consisted of the following:

[0000038725-17-000042:notes:114]
| (In millions) |  | 2016 |  | 2015 |  | 2014 |
| Domestic |  | $ | 45.4 |  |  | $ | 23.6 |  |  | $ | 42.2 |  |
| Foreign |  | 58.7 |  |  | 62.7 |  |  | 47.5 |  |
|  |  | $ | 104.1 |  |  | $ | 86.3 |  |  | $ | 89.7 |  |

[0000038725-17-000042:notes:115]
The income tax provision/(benefit) from continuing operations consisted of the following:

[0000038725-17-000042:notes:116]
| (In millions) |  | 2016 |  | 2015 |  | 2014 |
| Current: |  |  |  |  |  |  |
| Federal |  | $ | 9.6 |  |  | $ | 1.2 |  |  | $ | 7.4 |  |
| Foreign |  | 11.4 |  |  | 17.4 |  |  | 12.2 |  |
| State |  | 0.8 |  |  | 0.8 |  |  | 1.7 |  |
| Total current |  | 21.8 |  |  | 19.4 |  |  | 21.3 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Federal |  | 2.9 |  |  | (1.8 | ) |  | 3.3 |  |
| Foreign |  | (1.0 | ) |  | (4.0 | ) |  | (3.8 | ) |
| State |  | 1.1 |  |  | (1.0 | ) |  | (1.9 | ) |
| Total deferred |  | $ | 3.0 |  |  | $ | (6.8 | ) |  | $ | (2.4 | ) |
|  |  | $ | 24.8 |  |  | $ | 12.6 |  |  | $ | 18.9 |  |

[0000038725-17-000042:notes:117]
A reconciliation of the tax provision for continuing operations at the U.S. statutory rate to the effective income tax expense rate as reported is as follows:

[0000038725-17-000042:notes:118]
|  |  | 2016 |  | 2015 |  | 2014 |
| U.S. Federal statutory rate |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State income taxes, net of federal benefit |  | (0.3 | ) |  | (0.3 | ) |  | 1.0 |  |
| Foreign operations |  | (8.4 | ) |  | (13.1 | ) |  | (9.2 | ) |
| R&D tax credits |  | (0.6 | ) |  | (1.0 | ) |  | (0.6 | ) |
| Uncertain tax position adjustments |  | (2.5 | ) |  | (1.5 | ) |  | (1.6 | ) |
| Deferred tax adjustments - restructuring and rate adjustments |  | 0.3 |  |  | 1.1 |  |  | (3.9 | ) |
| Valuation allowance on state and foreign deferred tax |  | 2.4 |  |  | 4.1 |  |  | (0.3 | ) |
| Purchase of noncontrolling interest |  | — |  |  | (9.4 | ) |  | — |  |
| Share-based compensation |  | (1.1 | ) |  | — |  |  | — |  |
| Other items |  | (1.0 | ) |  | (0.3 | ) |  | 0.6 |  |
| Effective tax rate |  | 23.8 | % |  | 14.6 | % |  | 21.0 | % |

[0000038725-17-000042:notes:119]
Significant components of the Company's deferred tax assets and liabilities were as follows:

[0000038725-17-000042:notes:120]
| (In millions) |  | 2016 |  | 2015 |
| Deferred tax assets: |  |  |  |  |
| Accrued expenses and reserves |  | $ | 10.0 |  |  | $ | 12.8 |  |
| Compensation and employee benefits |  | 24.2 |  |  | 25.7 |  |
| Other items |  | 10.9 |  |  | 9.6 |  |
| Valuation allowance on state and foreign deferred tax |  | (9.8 | ) |  | (7.2 | ) |
| Total deferred tax assets |  | 35.3 |  |  | 40.9 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Accelerated depreciation on fixed assets |  | 13.8 |  |  | 14.0 |  |
| Amortization of intangibles |  | 56.5 |  |  | 56.6 |  |
| Other items |  | 0.9 |  |  | 0.2 |  |
| Total deferred tax liabilities |  | 71.2 |  |  | 70.8 |  |
| Net deferred tax liabilities |  | $ | (35.9 | ) |  | $ | (29.9 | ) |

[0000038725-17-000042:notes:121]
The effective tax rate continues to be lower than the statutory rate primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate as well as recognition of foreign tax credits.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations as well as cash on hand and available credit.

[0000038725-17-000042:notes:122]
In March 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-09, Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.  This standard simplifies several aspects of the accounting for employee share-based payment transactions including the recognition of excess tax benefits and deficiencies, the classification of those excess tax benefits on the statement of cash flows, an accounting policy election for forfeitures, the amount an employer can withhold to cover income taxes and still qualify for equity classification, and the classification of those taxes paid on the statement of cash flows. This ASU is effective for annual and interim periods beginning after December 15, 2016 with early adoption permitted.  The Company early adopted ASU 2016-09 during the second quarter ended July 2, 2016.

[0000038725-17-000042:notes:123]
The Company settled the liability for the noncontrolling interest of a subsidiary during the first quarter of 2015. This transaction created additional accretive benefits for the Company from the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer. The Company also realized a gain on the mandatorily redeemable noncontrolling interest liability during the first quarter of 2015.

[0000038725-17-000042:notes:124]
In November 2015, the FASB issued ASU 2015-17, Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes. This ASU requires an entity to classify deferred tax assets and liabilities as noncurrent within a classified balance sheet. The ASU is effective for interim and annual periods beginning after December 15, 2016, and early adoption is permitted. Entities can elect either prospective or retrospective adoption of the standard. The Company adopted the new standard on a prospective basis as of the fiscal year-ended January 2, 2016. Accordingly, classification of prior period deferred tax amounts were not retrospectively adjusted.

[0000038725-17-000042:notes:125]
The Company assesses the available positive and negative evidence to estimate whether sufficient future taxable income will be generated to permit use of the existing deferred tax assets. A significant piece of objective negative evidence evaluated was the cumulative loss for certain state and foreign income tax purposes incurred over the three-year period ended December 31, 2016. Such objective evidence limits the ability to consider other subjective evidence, such as our projections for future growth.

[0000038725-17-000042:notes:126]
On the basis of this evaluation, as of December 31, 2016, a valuation allowance of $9.8 million has been recorded to recognize only the portion of the deferred tax assets that are more likely than not to be realized.  The Company has foreign income tax net operating loss ("NOL") carryforwards of $4.7 million and state income tax NOL and credit carryforwards of $6.1 million, which will expire on various dates as follows:

[0000038725-17-000042:notes:127]
| (In millions) |  |
| 2017-2019 | $ | 0.7 |  |
| 2020-2024 | 2.4 |  |
| 2025-2029 | 0.6 |  |
| 2030-2034 | 2.1 |  |
| 2035-2039 | 0.7 |  |
| Unlimited | 4.3 |  |
|  | $ | 10.8 |  |

[0000038725-17-000042:notes:128]
The Company believes that it is more likely than not that the benefit from certain foreign NOL carryforwards as well as certain state NOL and state credit carryforwards will not be realized.  In recognition of this risk, the Company has provided a valuation allowance of $3.8 million on the deferred tax assets related to these foreign NOL carryforwards and a valuation allowance of $6.0 million on the deferred tax assets related to these state NOL and credit carryforwards.

[0000038725-17-000042:notes:129]
The Company considers undistributed earnings from its foreign subsidiaries to be indefinitely reinvested with respect to the U.S. It is the Company’s policy to reinvest earnings as needed for operations, capital and acquisition spending. The Company does not provide for deferred taxes on the excess of the financial reporting over the tax basis in our investments in foreign subsidiaries that are essentially permanent in duration. That excess totaled approximately $440.0 million as of December 31, 2016.  The determination of the additional deferred taxes that have not been provided is not practicable.

[0000038725-17-000042:notes:130]
As of the beginning of fiscal year 2016, the Company had gross unrecognized tax benefits of $2.4 million, excluding accrued interest and penalties.  The unrecognized tax benefits decreased $1.1 million for federal tax liabilities and remained the same for state income tax liabilities based on evaluations made during 2016 primarily due to statute expirations and offset by uncertain tax positions identified in the current year.  The Company had gross unrecognized tax benefits, excluding accrued interest and penalties, of $1.3 million as of December 31, 2016.

[0000038725-17-000042:notes:131]
A reconciliation of the beginning and ending amount of gross unrecognized tax benefits for 2016, 2015, and 2014 (excluding interest and penalties) is as follows:

[0000038725-17-000042:notes:132]
| (In millions) |  | 2016 |  | 2015 |  | 2014 |
| Beginning balance |  | $ | 2.4 |  |  | $ | 4.4 |  |  | $ | 5.1 |  |
| Additions for tax positions of the current year |  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |
| Additions for tax positions of prior years |  | 0.1 |  |  | 0.2 |  |  | 1.7 |  |
| Reductions for tax positions of prior years |  | (0.2 | ) |  | (0.8 | ) |  | (1.1 | ) |
| Statute expirations |  | (1.1 | ) |  | (1.6 | ) |  | (1.4 | ) |
| Settlements |  | — |  |  | — |  |  | — |  |
| Ending balance |  | $ | 1.3 |  |  | $ | 2.4 |  |  | $ | 4.4 |  |

[0000038725-17-000042:notes:133]
If recognized, each annual effective tax rate would be affected by the net unrecognized tax benefits of $1.3 million, $2.3 million, and $4.3 million as of year-end 2016, 2015, and 2014, respectively.

[0000038725-17-000042:notes:134]
The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.  In 2016, interest and penalties decreased $1.2 million, for prior year tax positions.  The Company has accrued interest and penalties as of December 31, 2016, January 2, 2016, and January 3, 2015 of approximately $1.1 million, $2.3 million, and $2.5 million, respectively.

[0000038725-17-000042:notes:135]
The Company is subject to taxation in the United States and various state and foreign jurisdictions.  With few exceptions, as of December 31, 2016, the Company is no longer subject to U.S. federal income tax examinations by tax authorities for years before 2013 and is no longer subject to foreign or state income tax examinations by tax authorities for years before 2011.

[0000038725-17-000042:notes:136]
It is reasonably possible that the amounts of unrecognized tax benefits could change in the next twelve months as a result of an audit or due to the expiration of a statute of limitation.  Based on the current audits in process and pending statute expirations, the payment of taxes as a result could be up to $0.9 million.


## us-gaap:IncomeTaxPolicyTextBlock

[0000038725-17-000042:notes:137]
Income Taxes--Income taxes are accounted for in accordance with FASB ASC Topic 740, Income Taxes.  Under this guidance, deferred tax assets and liabilities are determined based on the difference between the financial statement and tax basis of assets and liabilities and net operating loss and credit carry forwards using enacted tax rates in effect for the year in which the differences are expected to reverse.  Valuation allowances are established when necessary to reduce deferred tax assets to the amounts expected to be realized.  The Company records a liability for uncertain tax positions by establishing a recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return.


## us-gaap:InventoryPolicyTextBlock

[0000038725-17-000042:notes:138]
Inventories--  Inventories are stated at the lower of cost or market.  The majority of the cost of domestic and foreign inventories is determined using the FIFO method with a portion of inventory costs determined using the average cost method.  The Company reviews its inventories for excess or obsolete products or components based on an analysis of historical usage and management's evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-17-000042:notes:139]
ACCOUNTING PRONOUNCEMENTS

[0000038725-17-000042:notes:140]
Adoption of New Accounting Standards

[0000038725-17-000042:notes:141]
In March 2016, the FASB issued ASU 2016-09, Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.  This standard simplifies several aspects of the accounting for employee share-based payment transactions including the recognition of excess tax benefits and deficiencies, the classification of those excess tax benefits on the statement of cash flows, an accounting policy election for forfeitures, the amount an employer can withhold to cover income taxes and still qualify for equity classification, and the classification of those taxes paid on the statement of cash flows. This ASU is effective for annual and interim periods beginning after December 15, 2016 with early adoption permitted.

[0000038725-17-000042:notes:142]
The Company early adopted ASU 2016-09 during the second quarter ended July 2, 2016.  The primary impact of adoption was the recognition of excess tax benefits or deficiencies in the provision for income taxes rather than paid-in capital for all periods in fiscal year 2016.  Early adoption of the standard required adjustments as of January 3, 2016, the beginning of the annual period that includes the interim period of adoption.

[0000038725-17-000042:notes:143]
The Company has elected to continue its current policy of estimating forfeitures rather than recognizing forfeitures when they occur.

[0000038725-17-000042:notes:144]
Under ASU 2016-09, excess income tax benefits from stock-based compensation arrangements are classified as cash flows from operations, rather than as cash flows from financing activities.  The Company elected to apply the cash flow presentation requirements prospectively.

[0000038725-17-000042:notes:145]
The standard also clarifies that cash flows related to employee taxes paid by withheld shares should be classified as a financing activity.  This provision had no impact to the Company, because these cash flows have historically been presented as financing activities.

[0000038725-17-000042:notes:146]
In April 2015, the FASB issued ASU 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs, which requires debt issuance costs to be presented in the balance sheet as a direct deduction from the associated debt liability instead of a deferred asset.  The standard does not change the amortization of debt issuance costs, which will continue to follow the existing accounting guidance.  The Company adopted ASU 2015-03 during the first quarter ended April 2, 2016.  The retrospective adoption of this ASU required a total of approximately $0.3 million of unamortized debt issuance costs as of year-end 2015 to be reclassified from "Other assets" and "Other current assets" to a direct deduction from "Long-term debt" in the Company's consolidated balance sheet as of January 2, 2016.  In addition, there were no impacts to the Company's results of operations, retained earnings, or cash flows in the current or previous interim and annual reporting periods.

[0000038725-17-000042:notes:147]
Accounting Standards Issued But Not Yet Adopted

[0000038725-17-000042:notes:148]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in ASC Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company has begun the evaluation process for the adoption of the ASU, and anticipates that the majority of the Company’s outstanding operating leases would be recognized as right-of-use assets and lease liabilities upon adoption, resulting in a significant impact to the Company’s consolidated balance sheets. The impact of this ASU is non-cash in nature and will not affect the Company’s cash position.  The impact to the Company’s results of operations is still being evaluated.

[0000038725-17-000042:notes:149]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606).  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  In March 2016, the FASB issued ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net).  ASU 2016-08 clarifies the implementation guidance on principal versus agent considerations.  In April 2016, the FASB issued ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing.  ASU 2016-10 clarifies the implementation guidance on identifying performance obligations.  These ASUs are effective for interim and annual reporting periods beginning after December 15, 2017.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt these standards.  The Company will adopt ASU 2014-09 beginning in the first quarter of 2018 using the modified retrospective approach.  The Company does not expect the adoption of this ASU to have a material impact on the Company’s consolidated financial position, results of operations, or cash flows.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-17-000042:notes:150]
EMPLOYEE BENEFIT PLANS

[0000038725-17-000042:notes:151]
Defined Benefit Plans - As of December 31, 2016, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2016 measurement date for these plans.  One of the Company’s domestic pension plans covers two management employees (one active employee and one former employee), while the other domestic plan covers all other eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the ‘Pension Benefits’ disclosure caption.

[0000038725-17-000042:notes:152]
Other Benefits - The Company also maintains a postretirement benefit plan to provide health and life insurance benefits to employees hired prior to 1992.  The Company effectively capped its cost for those benefits through plan amendments made in 1992, freezing Company contributions for insurance benefits at 1991 levels for current and future beneficiaries with actuarially reduced benefits for employees who retire before age 65.  The disclosures surrounding this plan are reflected in the "Other Benefits" caption.

[0000038725-17-000042:notes:153]
The following table sets forth aggregated information related to the Company’s pension benefits and other postretirement benefits, including changes in the benefit obligations, changes in plan assets, funded status, amounts recognized in the balance sheet, amounts recognized in accumulated other comprehensive income, and actuarial assumptions that the Company considered in its determination of benefit obligations and plan costs.  Benefit obligation balances presented below reflect the projected benefit obligation (PBO) for the Company's pension plans, and accumulated postretirement benefit obligations (APBO) for the Company's other benefit plans.

[0000038725-17-000042:notes:154]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Accumulated benefit obligation, end of year |  | $ | 177.0 |  |  | $ | 182.8 |  |  | $ | 10.5 |  |  | $ | 11.3 |  |
| Change in benefit obligation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Benefit obligation, beginning of year |  | $ | 186.9 |  |  | $ | 209.5 |  |  | $ | 11.3 |  |  | $ | 13.0 |  |
| Service cost |  | 0.9 |  |  | 1.4 |  |  | 0.1 |  |  | 0.1 |  |
| Interest cost |  | 6.0 |  |  | 7.5 |  |  | 0.3 |  |  | 0.5 |  |
| Actuarial (gain)/loss |  | 4.1 |  |  | (12.3 | ) |  | — |  |  | (1.0 | ) |
| Settlements paid |  | (0.6 | ) |  | (0.4 | ) |  | — |  |  | — |  |
| Benefits paid |  | (15.7 | ) |  | (14.4 | ) |  | (1.2 | ) |  | (1.3 | ) |
| Curtailment |  | — |  |  | (1.9 | ) |  | — |  |  | — |  |
| Foreign currency exchange |  | (0.5 | ) |  | (2.5 | ) |  | — |  |  | — |  |
| Benefit obligation, end of year |  | $ | 181.1 |  |  | $ | 186.9 |  |  | $ | 10.5 |  |  | $ | 11.3 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of assets, beginning of year |  | $ | 147.4 |  |  | $ | 160.0 |  |  | $ | — |  |  | $ | — |  |
| Actual return on plan assets |  | 9.5 |  |  | (4.0 | ) |  | — |  |  | — |  |
| Company contributions |  | 5.5 |  |  | 6.9 |  |  | 1.2 |  |  | 1.3 |  |
| Settlements paid |  | (0.5 | ) |  | (0.4 | ) |  | — |  |  | — |  |
| Benefits paid |  | (15.7 | ) |  | (14.4 | ) |  | (1.2 | ) |  | (1.3 | ) |
| Foreign currency exchange |  | (0.1 | ) |  | (0.7 | ) |  | — |  |  | — |  |
| Plan assets, end of year |  | $ | 146.1 |  |  | $ | 147.4 |  |  | $ | — |  |  | $ | — |  |
| Funded status |  | $ | (35.0 | ) |  | $ | (39.5 | ) |  | $ | (10.5 | ) |  | $ | (11.3 | ) |
| Amounts recognized in balance sheet: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities |  | $ | (0.3 | ) |  | $ | (3.4 | ) |  | $ | (1.1 | ) |  | $ | (1.2 | ) |
| Noncurrent liabilities |  | (34.7 | ) |  | (36.0 | ) |  | (9.4 | ) |  | (10.1 | ) |
| Net liability, end of year |  | $ | (35.0 | ) |  | $ | (39.4 | ) |  | $ | (10.5 | ) |  | $ | (11.3 | ) |
| Amount recognized in accumulated other comprehensive income/(loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior service cost |  | $ | — |  |  | $ | — |  |  | $ | 0.2 |  |  | $ | 0.5 |  |
| Net actuarial loss |  | 48.9 |  |  | 48.0 |  |  | 0.9 |  |  | 0.9 |  |
| Settlement |  | 1.5 |  |  | 2.1 |  |  | — |  |  | — |  |
| Total recognized in accumulated other comprehensive income/(loss) |  | $ | 50.4 |  |  | $ | 50.1 |  |  | $ | 1.1 |  |  | $ | 1.4 |  |

[0000038725-17-000042:notes:155]
The following table sets forth other changes in plan assets and benefit obligation recognized in other comprehensive income for 2016 and 2015:

[0000038725-17-000042:notes:156]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net actuarial (gain)/loss |  | $ | 3.8 |  |  | $ | (0.3 | ) |  | $ | — |  |  | $ | (1.0 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net actuarial gain |  | (2.3 | ) |  | (2.8 | ) |  | (0.1 | ) |  | (0.2 | ) |
| Prior service credit |  | — |  |  | — |  |  | (0.4 | ) |  | (0.4 | ) |
| Settlement recognition |  | (1.4 | ) |  | (2.1 | ) |  | — |  |  | — |  |
| Deferred tax asset |  | 0.3 |  |  | 1.9 |  |  | 0.2 |  |  | 0.6 |  |
| Foreign currency exchange |  | (0.1 | ) |  | (0.3 | ) |  | — |  |  | — |  |
| Total recognized in other comprehensive income |  | $ | 0.3 |  |  | $ | (3.6 | ) |  | $ | (0.3 | ) |  | $ | (1.0 | ) |

[0000038725-17-000042:notes:157]
Weighted-average assumptions used to determine domestic benefit obligations:

[0000038725-17-000042:notes:158]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Discount rate |  | 4.13 | % |  | 4.37 | % |  | 3.89 | % |  | 4.09 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | 3.00 - 8.00%(Graded) |  |  | 3.00 - 8.00%(Graded) |  |

[0000038725-17-000042:notes:159]
*No rate of increases in future compensation used within assumptions for 2016 and 2015, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation.

[0000038725-17-000042:notes:160]
Assumptions used to determine domestic periodic benefit cost:

[0000038725-17-000042:notes:161]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Discount rate |  | 4.40 | % |  | 4.00 | % |  | 4.75 | % |  | 4.09 | % |  | 3.75 | % |  | 4.50 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | — | % | * | 3.00 - 8.00%(Graded) |  |  | 3.00 - 8.00%(Graded) |  |  | 3.00 - 12.00%(Graded) |  |
| Expected long-term rate of return on plan assets |  | 6.50 | % |  | 7.00 | % |  | 7.70 | % |  | — | % |  | — | % |  | — | % |

[0000038725-17-000042:notes:162]
*No rate of increases in future compensation used within assumptions for 2016, 2015, and 2014, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation.

[0000038725-17-000042:notes:163]
For the fiscal year ended December 31, 2016, the Company used the RP-2014 aggregate table adjusted to back out estimated mortality improvements from 2006 to the measurement date using Scale MP-2014, and then projected forward using Scale MP-2016 released by the Society of Actuaries during 2016 to estimate future mortality rates based upon current data.   For the fiscal year ended January 2, 2016, the Company used the RP-2014 aggregate table adjusted to back out estimated mortality improvements from 2006 to the measurement date using Scale MP-2014, and then projected forward using Scale MP-2015 released by the Society of Actuaries during 2015 to estimate future mortality rates.

[0000038725-17-000042:notes:164]
The following table sets forth the aggregated net periodic benefit cost for all defined benefit plans for 2016, 2015, and 2014:

[0000038725-17-000042:notes:165]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Service cost | $ | 0.9 |  |  | $ | 1.4 |  |  | $ | 1.2 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |
| Interest cost | 6.0 |  |  | 7.5 |  |  | 8.2 |  |  | 0.3 |  |  | 0.5 |  |  | 0.5 |  |
| Expected return on assets | (9.2 | ) |  | (9.9 | ) |  | (10.6 | ) |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Transition obligation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | 0.3 |  |  | 0.4 |  |  | 0.4 |  |
| Actuarial loss | 2.5 |  |  | 3.4 |  |  | 2.5 |  |  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |
| Settlement cost | 1.2 |  |  | 1.2 |  |  | 1.0 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 1.5 |  |  | $ | 3.6 |  |  | $ | 2.3 |  |  | $ | 0.8 |  |  | $ | 1.2 |  |  | $ | 1.1 |  |

[0000038725-17-000042:notes:166]
The estimated net actuarial (gain)/loss and prior service cost/(credit) that will be amortized from accumulated other comprehensive income into net periodic benefit cost during the 2017 fiscal year are $2.6 million and $0.0 million, respectively, for the pension plans and $0.1 million and $0.3 million, respectively, for all other benefits.

[0000038725-17-000042:notes:167]
The Company consults with a third party investment manager for the assets of the funded domestic defined benefit plan.  The plan assets are currently invested primarily in pooled funds, where each fund in turn is composed of mutual funds that have at least daily net asset valuations.  Thus, the Company’s funded domestic defined benefit plan assets are invested in a “fund of funds” approach.

[0000038725-17-000042:notes:168]
The Company’s Board has delegated oversight and guidance to an appointed Employee Benefits Committee.  The Committee has the tasks of reviewing plan performance and asset allocation, ensuring plan compliance with applicable laws, establishing plan policies, procedures, and controls, monitoring expenses, and other related activities.

[0000038725-17-000042:notes:169]
The plan's investment policies and strategies focus on the ability to fund benefit obligations as they come due.  Considerations include the plan's current funded level, plan design, benefit payment assumptions, funding regulations, impact of potentially volatile business results on the Company’s ability to make certain levels of contributions, and interest rate and asset return volatility among other considerations.  The Company currently attempts to maintain plan funded status at approximately 80 percent or greater pursuant to the Pension Protection Act of 2007.  Given the plan’s current funded status, the Company’s cash on hand, cash historically generated from business operations, and cash available under committed credit facilities, the Company sees ample liquidity to achieve this goal.

[0000038725-17-000042:notes:170]
Risk management and continuous monitoring requirements are met through monthly investment portfolio reports, quarterly Employee Benefits Committee meetings, annual valuations, asset/liability studies, and the annual assumption process focusing primarily on the return on asset assumption and the discount rate assumption.  As of December 31, 2016 and January 2, 2016, funds were invested in equity, fixed income, and other investments as follows:

[0000038725-17-000042:notes:171]
|  |  | Target Percentage |  | Plan Asset Allocation at Year-End |
| Asset Category |  | at Year-End 2016 |  | 2016 |  | 2015 |
| Equity securities |  | 31 | % |  | 31 | % |  | 34 | % |
| Fixed income securities |  | 65 | % |  | 65 | % |  | 62 | % |
| Other |  | 4 | % |  | 4 | % |  | 4 | % |
| Total |  | 100 | % |  | 100 | % |  | 100 | % |

[0000038725-17-000042:notes:172]
The Company does not see any particular concentration of risk within the plans, nor any plan assets that pose difficulties for fair value assessment.  The Company currently has no allocation to potentially illiquid or potentially difficult to value assets such as hedge funds, venture capital, private equity, and real estate.

[0000038725-17-000042:notes:173]
The Company works with actuaries and consultants in making its determination of the asset rate of return assumption and also the discount rate assumption.

[0000038725-17-000042:notes:174]
Asset class assumptions are set using a combination of empirical and forward-looking analysis for long-term rate of return on plan assets.  A variety of models are applied for filtering historical data and isolating the fundamental characteristics of asset classes.  These models provide empirical return estimates for each asset class, which are then reviewed and combined with a qualitative assessment of long-term relationships between asset classes before a return estimate is finalized.  This provides an additional means for correcting for the effect of unrealistic or unsustainable short-term valuations or trends, opting instead for return levels and behavior that are more likely to prevail over long periods.  With that, the Company has assumed an expected long-term rate of return on plan assets of 6.25 percent for the 2017 net periodic benefit cost, down from 6.50 percent in the prior year.  This decrease in the assumed long-term rate of return is primarily due to a higher percentage of assets in fixed income securities.

[0000038725-17-000042:notes:175]
The Company uses the Aon Hewitt AA Above Median curve to determine the discount rate.  All cash flow obligations under the plan are matched to bonds in the Aon Hewitt universe of liquid, high-quality, non-callable / non-putable corporate bonds with outliers removed.  From that matching exercise, a discount rate is determined.

[0000038725-17-000042:notes:176]
At January 2, 2016, the Company changed the method used to calculate the service and interest components of net periodic benefit cost for the domestic pension plans and other postretirement benefit plan.  This change compared to the previous method resulted in different service and interest components of net periodic benefit cost in the 2016 fiscal year.  Historically, the Company estimated these service and interest cost components utilizing a single weighted-average discount rate derived from the yield curve used to measure the benefit obligation at the beginning of the period.  The Company elected to utilize a full yield curve approach in the estimation of these components by applying the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows.  The Company made this change to provide a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot yield curve rates.  This change does not affect the measurement of the Company's domestic pension and postretirement benefit obligations and is accounted for as a change in accounting estimate applied prospectively.

[0000038725-17-000042:notes:177]
The Company’s German pension plans are funded by insurance contract policies whereby the insurance company guarantees a fixed minimum return.  Due to tax legislation, individual pension benefits can only be financed using direct insurance policies up to certain maximums.  These maximum amounts in respect of each member are paid into such an arrangement on a yearly basis.

[0000038725-17-000042:notes:178]
The Company designated all equity and most domestic fixed income plan assets as Level 1, as they are mutual funds with prices that are readily available.  The U.S. Treasury securities and German plan assets are designated as Level 2 inputs.  The fair value of the German plan assets are measured by the reserve that is supervised by the German Federal Financial Supervisory Authority.  The U.S. Treasury securities are administered by the United States government.

[0000038725-17-000042:notes:179]
The fair values of the Company’s pension plan assets for 2016 and 2015 by asset category are as follows:

[0000038725-17-000042:notes:180]
| (In millions) |  | 2016 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| Domestic equity mutual funds |  | $ | 27.8 |  |  | $ | 27.8 |  |  | $ | — |  |  | $ | — |  |
| International equity mutual funds |  | 17.5 |  |  | 17.5 |  |  | — |  |  | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 16.4 |  |  | — |  |  | 16.4 |  |  | — |  |
| Fixed income mutual funds |  | 79.1 |  |  | 79.1 |  | — |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.5 |  |  | — |  |  | 4.5 |  |  | — |  |
| Cash and equivalents |  | 0.8 |  |  | 0.8 |  |  | — |  |  | — |  |
| Total |  | $ | 146.1 |  |  | $ | 125.2 |  |  | $ | 20.9 |  |  | $ | — |  |

[0000038725-17-000042:notes:181]
| (In millions) |  | 2015 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| Domestic equity mutual funds |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | — |  |  | $ | — |  |
| International equity mutual funds |  | 19.6 |  |  | 19.6 |  |  | — |  |  | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 15.8 |  |  | — |  |  | 15.8 |  | — |  | — |  |
| Fixed income mutual funds |  | 75.3 |  |  | 75.3 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.9 |  |  | — |  |  | 4.9 |  |  | — |  |
| Cash and equivalents |  | 0.8 |  |  | 0.8 |  |  | — |  |  | — |  |
| Total |  | $ | 147.4 |  |  | $ | 126.7 |  |  | $ | 20.7 |  |  | $ | — |  |

[0000038725-17-000042:notes:182]
The Company estimates total contributions to the plans of $6 million in 2017.

[0000038725-17-000042:notes:183]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid in accordance with the following schedule:

[0000038725-17-000042:notes:184]
| (In millions) |  | Pension Benefits |  | Other Benefits |
| 2017 |  | $ | 11.6 |  |  | $ | 1.1 |  |
| 2018 |  | 11.7 |  |  | 1.0 |  |
| 2019 |  | 11.3 |  |  | 1.0 |  |
| 2020 |  | 11.3 |  |  | 0.9 |  |
| 2021 |  | 11.2 |  |  | 0.8 |  |
| Years 2022 through 2026 |  | 59.3 |  |  | 3.5 |  |

[0000038725-17-000042:notes:185]
Defined Contribution Plans - The Company maintained two defined contribution plans during 2016, 2015, and 2014.  The Company's cash contributions are allocated to participant's accounts based on investment elections.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000038725-17-000042:notes:186]
Property, Plant, and Equipment--Property, plant, and equipment are stated at historical cost.  The Company capitalizes certain computer software and software development costs incurred in connection with developing or obtaining computer software for internal use, which are included in property, plant, and equipment.  Depreciation of plant and equipment is calculated on a straight line basis over the following estimated useful lives:

[0000038725-17-000042:notes:187]
| Land improvement and buildings | 10-40 years |
| Machinery and equipment | 5-10 years |
| Software | 3-7 years |
| Furniture and fixtures | 3-7 years |

[0000038725-17-000042:notes:188]
Maintenance, repairs, and renewals of a minor nature are expensed as incurred.  Betterments and major renewals which extend the useful lives or add to the productive capacity of buildings, improvements, and equipment are capitalized.  The Company reviews its property, plant, and equipment for impairment at the asset group level whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable.  If an indicator is present, the Company compares carrying values to undiscounted future cash flows; if the undiscounted future cash flows are less than the carrying value, an impairment would be recognized for the difference between the fair value and the carrying value.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000038725-17-000042:notes:189]
SELECTED QUARTERLY FINANCIAL DATA (UNAUDITED)

[0000038725-17-000042:notes:190]
Unaudited quarterly financial information for 2016 and 2015, is as follows:

[0000038725-17-000042:notes:191]
| (In millions, except per share amounts) |  |  |  |  |  |  |  |  |  |  |
|  | Net Sales |  | Gross Profit |  | Net Income |  | Net Income Attributable to Franklin Electric Co., Inc. |  | Basic Earnings Per Share |  | Diluted Earnings Per Share |
| 2016 |  |  |  |  |  |  |  |  |  |  |  |
| 1st quarter | $ | 218.4 |  |  | $ | 74.2 |  |  | $ | 13.6 |  |  | $ | 13.5 |  |  | $ | 0.28 |  |  | $ | 0.28 |  |
| 2nd quarter | 252.1 |  |  | 90.7 |  |  | 24.2 |  |  | 24.0 |  |  | 0.51 |  |  | 0.50 |  |
| 3rd quarter | 239.8 |  |  | 85.5 |  |  | 23.7 |  |  | 23.7 |  |  | 0.51 |  |  | 0.50 |  |
| 4th quarter | 239.6 |  |  | 81.0 |  |  | 17.8 |  |  | 17.5 |  |  | 0.37 |  |  | 0.37 |  |
|  | $ | 949.9 |  |  | $ | 331.4 |  |  | $ | 79.3 |  |  | $ | 78.7 |  |  | $ | 1.67 |  |  | $ | 1.65 |  |
| 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| 1st quarter | $ | 225.7 |  |  | $ | 71.5 |  |  | $ | 20.0 |  |  | $ | 19.8 |  |  | $ | 0.41 |  |  | $ | 0.41 |  |
| 2nd quarter | 247.4 |  |  | 80.2 |  |  | 16.4 |  |  | 16.1 |  |  | 0.33 |  |  | 0.33 |  |
| 3rd quarter | 232.5 |  |  | 76.8 |  |  | 21.0 |  |  | 20.8 |  |  | 0.44 |  |  | 0.43 |  |
| 4th quarter | 219.3 |  |  | 69.1 |  |  | 16.3 |  |  | 16.2 |  |  | 0.34 |  |  | 0.33 |  |
|  | $ | 924.9 |  |  | $ | 297.6 |  |  | $ | 73.7 |  |  | $ | 72.9 |  |  | $ | 1.52 |  |  | $ | 1.50 |  |

[0000038725-17-000042:notes:192]
Basic and diluted earnings per share amounts are computed independently for each of the quarters presented.  As a result, the sum of the quarterly earnings per share amounts may not equal the annual earnings per share amount.


## us-gaap:ReceivablesPolicyTextBlock

[0000038725-17-000042:notes:193]
Accounts Receivable, Earned Discounts, and Allowance for Uncollectible Accounts--Accounts receivable are stated at estimated net realizable value.  Accounts receivable are comprised of balances due from customers, net of earned discounts and estimated allowances for uncollectible accounts.  Earned discounts are based on specific customer agreement terms.  In determining allowances for uncollectible accounts, historical collection experience, current trends, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are reviewed.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-17-000042:notes:194]
RESTRUCTURING

[0000038725-17-000042:notes:195]
On July 1, 2014, the Company announced a plan to close its Wittlich, Germany manufacturing facility and to complete other European based business units and facilities realignments. The realignments as of the end of 2016 are considered to be substantially completed. In total, the Company had previously estimated the cost for these European realignments to be approximately $19.4 million.  The Company actually incurred expenses of $17.5 million.  Charges for the realignment included severance expenses, professional service fees, asset write-offs and manufacturing equipment relocation costs.

[0000038725-17-000042:notes:196]
Costs incurred in the twelve months ended December 31, 2016, included in the “Restructuring (income)/expense” line of the Company's consolidated statements of income, are as follows:

[0000038725-17-000042:notes:197]
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.2 |  |
| Equipment relocation |  | — |  |  | 0.2 |  |  | — |  |  | 0.2 |  |
| Asset write-off, net of gain on disposal |  | (2.0 | ) |  | 0.4 |  |  | — |  |  | (1.6 | ) |
| Other |  | 0.6 |  |  | — |  |  | — |  |  | 0.6 |  |
| Total |  | $ | (1.2 | ) |  | $ | 0.6 |  |  | $ | — |  |  | $ | (0.6 | ) |

[0000038725-17-000042:notes:198]
Restructuring expenses of $3.0 million and $16.6 million were incurred in 2015 and 2014, respectively, primarily for the Water Systems realignment.

[0000038725-17-000042:notes:199]
As of December 31, 2016 and January 2, 2016, there were no material restructuring reserves.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000038725-17-000042:notes:200]
Revenue Recognition--Revenue is recognized when pervasive evidence of an arrangement exists, collectability is reasonably assured, the price is fixed or determinable, and shipment or delivery has occurred.  For product sales, the Company recognizes revenue once the transfer of ownership and risk of loss pass to the customer, which is generally when the products are shipped.

[0000038725-17-000042:notes:201]
Generally, the only post-shipment obligation on the Company’s products include routine warranty obligations.  In the event that significant post-shipment obligations were to exist for the Company’s products, revenue recognition would be deferred until substantially all obligations were satisfied.

[0000038725-17-000042:notes:202]
The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0000038725-17-000042:notes:203]
The weighted average number of years over which each intangible class is amortized is as follows:


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000038725-17-000042:notes:204]
Financial information by geographic region is as follows:

[0000038725-17-000042:notes:205]
|  | Net sales |  | Long-lived assets |
| (In millions) | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| United States | $ | 446.9 |  |  | $ | 418.5 |  |  | $ | 485.5 |  |  | $ | 349.2 |  |  | $ | 404.1 |  |  | $ | 418.0 |  |
| Foreign | 503.0 |  |  | 506.4 |  |  | 562.3 |  |  | 202.3 |  |  | 150.7 |  |  | 184.4 |  |
| Consolidated | $ | 949.9 |  |  | $ | 924.9 |  |  | $ | 1,047.8 |  |  | $ | 551.5 |  |  | $ | 554.8 |  |  | $ | 602.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-17-000042:notes:206]
Financial information by reportable business segment is included in the following summary:

[0000038725-17-000042:notes:207]
|  | Net sales to external customers |  | Operating income (loss) |
| (In millions) | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Water Systems | $ | 723.2 |  |  | $ | 707.6 |  |  | $ | 824.6 |  |  | $ | 108.2 |  |  | $ | 86.7 |  |  | $ | 103.9 |  |
| Fueling Systems | 226.7 |  |  | 217.3 |  |  | 223.2 |  |  | 56.3 |  |  | 51.5 |  |  | 49.7 |  |
| Other | — |  |  | — |  |  | — |  |  | (53.7 | ) |  | (47.8 | ) |  | (53.5 | ) |
| Consolidated | $ | 949.9 |  |  | $ | 924.9 |  |  | $ | 1,047.8 |  |  | $ | 110.8 |  |  | $ | 90.4 |  |  | $ | 100.1 |  |
|  | Total assets |  | Depreciation |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Water Systems | $ | 671.5 |  |  | $ | 677.6 |  |  | $ | 757.5 |  |  | $ | 19.5 |  |  | $ | 19.5 |  |  | $ | 19.9 |  |
| Fueling Systems | 251.1 |  |  | 248.5 |  |  | 252.7 |  |  | 2.3 |  |  | 2.5 |  |  | 2.4 |  |
| Other | 117.3 |  |  | 70.0 |  |  | 65.6 |  |  | 5.3 |  |  | 4.8 |  |  | 5.8 |  |
| Consolidated | $ | 1,039.9 |  |  | $ | 996.1 |  |  | $ | 1,075.8 |  |  | $ | 27.1 |  |  | $ | 26.8 |  |  | $ | 28.1 |  |
|  | Amortization |  | Capital expenditures |
|  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Water Systems | $ | 6.4 |  |  | $ | 6.6 |  |  | $ | 7.1 |  |  | $ | 31.8 |  |  | $ | 19.5 |  |  | $ | 33.8 |  |
| Fueling Systems | 1.9 |  |  | 1.9 |  |  | 1.8 |  |  | 2.1 |  |  | 1.4 |  |  | 3.9 |  |
| Other | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 3.7 |  |  | 5.0 |  |  | 4.7 |  |
| Consolidated | $ | 8.4 |  |  | $ | 8.6 |  |  | $ | 9.1 |  |  | $ | 37.6 |  |  | $ | 25.9 |  |  | $ | 42.4 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-17-000042:notes:208]
During 2016, 2015, and 2014, pursuant to a stock repurchase program authorized by the Company’s Board of Directors, the Company repurchased and retired the following amounts and number of shares:

[0000038725-17-000042:notes:209]
| (In millions, except share amounts) |  | 2016 |  | 2015 |  | 2014 |
| Repurchases |  | $ | 3.8 |  |  | $ | 46.3 |  |  | $ | 9.0 |  |
| Shares |  | 144,600 |  |  | 1,568,731 |  |  | 243,020 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000038725-17-000042:notes:210]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000038725-17-000042:notes:211]
| (In millions) |  | Balance at Beginning of Period |  | Additions Charged to Costs and Expenses |  | Deductions (a) |  | Other |  | Balance at End of Period |
| 2016 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.8 |  |  | $ | 0.1 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | 3.6 |  |
| Allowance for deferred taxes |  | 7.2 |  |  | 2.9 |  |  | 0.3 |  |  | — |  |  | 9.8 |  |
| 2015 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.2 |  |  | $ | 1.1 |  |  | $ | 0.5 |  |  | $ | — |  |  | $ | 3.8 |  |
| Allowance for deferred taxes |  | 3.9 |  |  | 3.5 |  |  | 0.2 |  |  | — |  |  | 7.2 |  |
| 2014 |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 3.0 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 3.2 |  |
| Allowance for deferred taxes |  | 3.5 |  |  | 1.3 |  |  | 0.9 |  |  | — |  |  | 3.9 |  |

[0000038725-17-000042:notes:212]
(a) Charges for which allowances were created.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-17-000042:notes:213]
SEGMENT AND GEOGRAPHIC INFORMATION

[0000038725-17-000042:notes:214]
The Company’s business consists of the Water Systems and Fueling Systems reportable segments, based on the principal end market served.  Within the Water Systems segment, North America Water Systems and International Water Systems have been identified as operating segments.  For reporting segment purposes, the Company aggregates North America Water Systems and International Water Systems into the Water Systems segment, as they meet the aggregation criteria in FASB ASC 280. The Company includes unallocated corporate expenses and inter-company eliminations in an “Other” segment that together with the Water Systems and Fueling Systems segments, represent the Company.

[0000038725-17-000042:notes:215]
The Water Systems segment designs, manufactures and sells motors, pumps, electronic controls and related parts and equipment primarily for use in submersible water and other fluid system applications.  The Fueling Systems segment designs, manufactures and sells pumps, electronic controls and related parts and equipment primarily for use in submersible fueling system applications.  The Fueling Systems segment integrates and sells motors and electronic controls produced by the Water Systems segment.

[0000038725-17-000042:notes:216]
The accounting policies of the Company's reportable segments are the same as those described in Note 1 (Summary of Significant Accounting Policies).  Performance is evaluated based on the sales and operating income of the segments and a variety of ratios to measure performance.  These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented.

[0000038725-17-000042:notes:217]
Cash is the major asset group in "Other" of total assets at December 31, 2016.  Property, plant and equipment is the major asset group in "Other" of total assets at January 2, 2016.

[0000038725-17-000042:notes:218]
Net sales are attributed to geographic regions based upon the ship to location of the customer.  Long-lived assets are attributed to geographic regions based upon the country of domicile.

[0000038725-17-000042:notes:219]
The Company offers a large array of products and systems to multiple markets and customers.  Product sales information is tracked regionally and products are categorized differently between regions based on local needs and reporting requirements. However, net sales by segment are representative of the Company's sales by major product category. The Company sells its products through various distribution channels including wholesale and retail distributors, specialty distributors, industrial and petroleum equipment distributors, as well as major oil and utility companies and original equipment manufacturers.

[0000038725-17-000042:notes:220]
No single customer accounted for more than 10 percent of the Company’s consolidated sales in 2016, 2015, or 2014.  No single customer accounted for more than 10 percent of the Company's gross accounts receivable in 2016 or 2015.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0000038725-17-000042:notes:221]
Shipping and Handling Costs--Shipping and handling costs are recorded as a component of cost of sales.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000038725-17-000042:notes:222]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0000038725-17-000042:notes:223]
Company--“Franklin Electric” or the “Company” shall refer to Franklin Electric Co., Inc. and its consolidated subsidiaries.

[0000038725-17-000042:notes:224]
Fiscal Year--In December 2016, the Company's Board of Directors approved a change in reporting periods from fiscal periods to a calendar year.  This change is effective beginning January 1, 2017.  For fiscal years 2016 and prior, the Company's fiscal year ends on the Saturday nearest December 31.  The financial statements and accompanying notes are as of and for the years ended December 31, 2016 (52 weeks), January 2, 2016 (52 weeks), and January 3, 2015 (53 weeks), and referred to as 2016, 2015, and 2014, respectively.

[0000038725-17-000042:notes:225]
Business Combinations--The Company allocates the purchase price of its acquisitions to the assets acquired, liabilities assumed, and noncontrolling interests acquired based upon their respective fair values at the acquisition date.  The Company utilizes management estimates and inputs from an independent third-party valuation firm to assist in determining these fair values.  The excess of the acquisition price over these estimated fair values is recorded as goodwill.  Goodwill is adjusted for any changes to acquisition date fair value amounts made within the measurement period.  Acquisition-related transaction costs are recognized separately from the business combination and expensed as incurred.

[0000038725-17-000042:notes:226]
Research and Development Expense--The Company’s research and development activities are charged to expense in the period incurred.  The Company incurred expenses of approximately $21.5 million in 2016, $18.4 million in 2015, and $19.3 million in 2014 related to research and development.

[0000038725-17-000042:notes:227]
Fair Value of Financial Instruments--Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy.  Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date.  The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value.  The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-17-000042:notes:228]
Level 1 – Quoted prices for identical assets and liabilities in active markets;

[0000038725-17-000042:notes:229]
Level 2 – Quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets; and

[0000038725-17-000042:notes:230]
Level 3 – Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable.

[0000038725-17-000042:notes:231]
The Company’s depreciation expense was $27.1 million, $26.8 million, and $28.1 million in 2016, 2015, and 2014, respectively.

[0000038725-17-000042:notes:232]
Warranty Obligations--The Company provides warranties on most of its products. The warranty terms vary but are generally two to five years from date of manufacture or one to five years from date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims. The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-17-000042:notes:233]
Defined Benefit Plans--The Company makes its determination for pension, post retirement, and post employment benefit plans liabilities based on management estimates and consultation with actuaries, incorporating estimates and assumptions of future plan service costs, future interest costs on projected benefit obligations, rates of compensation increases, employee turnover rates, anticipated mortality rates, expected investment returns on plan assets, asset allocation assumptions of plan assets, and other factors.

[0000038725-17-000042:notes:234]
Significant Estimates--The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make significant estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of expenses during the reporting periods.  Significant estimates and assumptions by management affect inventory valuation, warranty, trade names and goodwill, income taxes, and pension and employee benefit obligations.

[0000038725-17-000042:notes:235]
Although the Company regularly assesses these estimates, actual results could materially differ.  The Company bases its estimates on historical experience and various other assumptions that it believes to be reasonable under the circumstances.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-17-000042:notes:236]
SHAREHOLDERS' EQUITY

[0000038725-17-000042:notes:237]
Authorized Shares

[0000038725-17-000042:notes:238]
The Company has the authority to issue 65,000,000, $.10 par value shares.

[0000038725-17-000042:notes:239]
Share Repurchases

[0000038725-17-000042:notes:240]
In 2016, the Company retired 96,929 shares that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards.  The Company also retired 16,391 shares that had been previously granted as stock awards to employees, but were forfeited upon not meeting the required restriction criteria or termination.  In 2015, the Company retired 65,209 shares that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards.  The Company also retired 958 shares that had been previously granted as a stock award to employees, but were forfeited upon not meeting the required restriction criteria or termination.  In 2014, the Company retired 40,679 shares that were received from employees as payment for the exercise price of their stock options and taxes owned upon the exercise of their stock options and release of their restricted awards.  The Company also retired 68,675 shares that had been previously granted as stock awards to employees, but were forfeited upon not meeting the required restriction criteria or termination.

[0000038725-17-000042:notes:241]
In 2015 and 2014, the Company recorded $1.4 million and $2.3 million, respectively, as a reduction in tax liability and an increase to shareholders' equity as a result of stock option exercises and award vests.  In 2016, the Company early adopted ASU 2016-09 (refer to Note 2 for additional information); therefore, no amounts were recorded to equity as a result of stock option exercises and award vests.
