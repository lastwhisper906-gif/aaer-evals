# FELE MD&A — 0000038725-17-000042


## mdna

[0000038725-17-000042:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-17-000042:mdna:2]
2016 vs. 2015

[0000038725-17-000042:mdna:3]
OVERVIEW

[0000038725-17-000042:mdna:4]
Sales in 2016 increased from the prior year.  Net sales in 2016 were $949.9 million, an increase of about 3 percent compared to 2015 sales of $924.9 million. The sales increase was attributable to both volume and price increases partially offset by the impact of foreign currency translation as the US dollar strengthened against certain foreign currencies. The Company's consolidated gross profit was $331.4 million for 2016, an increase of $33.8 million or about 11 percent from 2015. The gross profit as a percent of net sales increased 270 basis points to 34.9 percent in 2016 from 32.2 percent in 2015. The gross profit margin change was due primarily to favorable pricing, lower direct material costs and lower fixed cost on higher sales. For 2016, diluted earnings per share were $1.65, an increase of 10 percent compared to 2015 diluted earnings per share of $1.50. Adjusted earnings per share were $1.66, an increase of 13 percent versus the $1.47 adjusted earnings per share in 2015 (see the table below for a reconciliation of the GAAP EPS to the adjusted EPS).

[0000038725-17-000042:mdna:5]
RESULTS OF OPERATIONS

[0000038725-17-000042:mdna:6]
Net Sales

[0000038725-17-000042:mdna:7]
Net sales in 2016 were $949.9 million, an increase of $25.0 million or about 3 percent compared to 2015 sales of $924.9 million.  The incremental impact of sales from acquired businesses was $0.7 million.  Sales revenue decreased by $23.2 million or about 2 percent in 2016 due to foreign currency translation. The sales change in 2016, excluding acquisitions and foreign currency translation, was an increase of $47.5 million or about 5 percent.

[0000038725-17-000042:mdna:8]
|  | Net Sales |
| (In millions) | 2016 |  | 2015 |  | 2016 v 2015 |
| Water Systems | $ | 723.2 |  |  | $ | 707.6 |  |  | $ | 15.6 |  |
| Fueling Systems | 226.7 |  |  | 217.3 |  |  | 9.4 |  |
| Consolidated | $ | 949.9 |  |  | $ | 924.9 |  |  | $ | 25.0 |  |

[0000038725-17-000042:mdna:9]
Net Sales-Water Systems

[0000038725-17-000042:mdna:10]
Water Systems sales were $723.2 million in 2016, an increase of $15.6 million or 2 percent versus 2015. The incremental impact of sales from acquired businesses was $0.7 million.  Foreign currency translation rate changes decreased sales $21.4 million, or about 3 percent, compared to sales in 2015. The sales change in 2016, excluding acquisitions and foreign currency translation, was an increase of $36.3 million or about 5 percent.

[0000038725-17-000042:mdna:11]
Water Systems sales in the U.S. and Canada were 36 percent of consolidated sales and increased by about 5 percent in 2016 compared to the prior year. Sales revenue decreased by $2.1 million or less than 1 percent in 2016 due to foreign currency translation. The sales change in 2016, excluding acquisitions and foreign currency translation, was an increase of $16.4 million or about 5 percent.  In 2016, sales of groundwater pumping equipment increased by about 9 percent. The growth in groundwater equipment sales was led by a 12 percent increase in sales of products for both residential and agricultural applications.  Sales of Pioneer branded mobile dewatering equipment declined by about 12 percent. The decline in mobile dewatering equipment is primarily attributed to reduced demand in the oil and gas end markets.

[0000038725-17-000042:mdna:12]
Water Systems sales in Europe, Middle East and Africa were about 17 percent of consolidated sales and declined by about 4 percent compared to 2015. Water Systems in Europe, the Middle East and Africa were reduced by $10.5 million or about 6 percent due to foreign currency translation. Excluding the impact of foreign currency translation, sales were up in 2016 by about 2 percent compared to 2015. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-17-000042:mdna:13]
In local currency sales in Turkey grew; however, this growth was offset by sales declines in other parts of the region due to political and economic turmoil and the lower price of oil which reduced investment by the public sector, particularly in Saudi Arabia.

[0000038725-17-000042:mdna:14]
Water Systems sales in Latin America were about 14 percent of consolidated sales for 2016 and declined by about 1 percent compared to 2015.  Sales revenue decreased by $8.5 million or about 7 percent in 2016 due to foreign currency translation. The sales change in 2016, excluding foreign currency translation, was an increase of $7.4 million or about 6 percent. The growth in sales was led by increased sales in Mexico and Brazil, in local currency. This sales growth is a result of increasing demand for

[0000038725-17-000042:mdna:15]
Franklin submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions.

[0000038725-17-000042:mdna:16]
Water Systems sales in the Asia Pacific region were 9 percent of consolidated sales and grew by about 12 percent compared to the prior year. Foreign currency translation rate changes decreased sales in 2016 in the Asia Pacific region by less than a percent. The Asia Pacific region experienced strong year over year growth in Southeast Asia and Australia.

[0000038725-17-000042:mdna:17]
Net Sales-Fueling Systems

[0000038725-17-000042:mdna:18]
Fueling Systems sales which represented 24 percent of consolidated sales were $226.7 million in 2016, an increase of $9.4 million or about 4 percent versus 2015. Foreign currency translation rate changes decreased sales $1.8 million or about 1 percent compared to sales in 2015. The sales change in 2016, excluding acquisitions and foreign currency translation, was an increase of $11.2 million or about 5 percent.

[0000038725-17-000042:mdna:19]
Fueling Systems sales in the U.S. and Canada grew by about 8 percent in 2016 compared to the prior year with sales growth coming from most product lines, most significantly our pumping and fuel management systems. Fueling Systems sales in the rest of the world were down about 2 percent year over year.  In 2016, Fueling Systems revenues increased in the Asia Pacific regions by about 14 percent, driven by higher sales in India. This growth in Asia was more than offset by a sales decline in Europe principally due to a 42 percent decline in the sale of storage tanks that support North Sea oil production.

[0000038725-17-000042:mdna:20]
Cost of Sales

[0000038725-17-000042:mdna:21]
Cost of sales as a percent of net sales for 2016 and 2015 was 65.1 percent and 67.8 percent, respectively. Correspondingly, the gross profit margin increased to 34.9 percent from 32.2 percent, a 270 basis point improvement. The gross profit margin increase was primarily due to lower raw material costs and lower fixed costs.  Direct materials as a percentage of sales was 44.8 percent down 210 basis points compared to 46.9 percent last year.  This decrease in direct materials was primarily due to favorable pricing and lower direct material costs.  The Company's consolidated gross profit was $331.4 million for 2016, up $33.8 million or 11 percent from 2015.

[0000038725-17-000042:mdna:22]
Selling, General and Administrative (“SG&A”)

[0000038725-17-000042:mdna:23]
Selling, general, and administrative (SG&A) expenses were $221.2 million in 2016 and increased by $16.9 million or about 8 percent in 2016 compared to last year. In 2016, increases in SG&A attributable to higher variable compensation expenses were about $12 million or about 6 percent. Additional year over year changes in SG&A costs were primarily in Marketing and Selling related expenses which increased about $2.5 million to support sales growth and, also, Research, Development & Engineering expense which increased by $2.3 million in the year.

[0000038725-17-000042:mdna:24]
Restructuring (Income)/Expense

[0000038725-17-000042:mdna:25]
Restructuring expenses for 2016 netted to a gain of $(0.6) million and increased diluted earnings per share about $0.01.  Restructuring expenses for 2016 included a gain of $(2.0) million from the sale of land and building in Brazil and $1.4 million in expenses related to severance and pension costs, equipment relocation expenses, asset write-downs and other costs related to the transfer of production activities and other restructuring costs from continued manufacturing realignments.

[0000038725-17-000042:mdna:26]
Restructuring expenses for 2015 were $3.0 million and decreased diluted earnings per share about $0.04.  Restructuring expenses in 2015 included severance and pension costs, equipment relocation expenses, and asset write-downs primarily related to the closure of the Wittlich, Germany facility and other manufacturing realignment activities in Europe and Brazil.

[0000038725-17-000042:mdna:27]
Operating Income

[0000038725-17-000042:mdna:28]
Operating income was $110.8 million in 2016, up $20.4 million from $90.4 million in 2015.

[0000038725-17-000042:mdna:29]
|  |  | Operating income (loss) |
| (In millions) |  | 2016 |  | 2015 |  | 2016 v 2015 |
| Water Systems |  | $ | 108.2 |  |  | $ | 86.7 |  |  | $ | 21.5 |  |
| Fueling Systems |  | 56.3 |  |  | 51.5 |  |  | 4.8 |  |
| Other |  | (53.7 | ) |  | (47.8 | ) |  | (5.9 | ) |
| Consolidated |  | $ | 110.8 |  |  | $ | 90.4 |  |  | $ | 20.4 |  |

[0000038725-17-000042:mdna:30]
There were specific items in 2016 and 2015 that impacted operating income.

[0000038725-17-000042:mdna:31]
In 2016 they were as follows:

[0000038725-17-000042:mdna:32]
| • | $(0.6) million of net restructuring charges. Restructuring (income)/expenses in 2016 included a gain of $(2.0) million from the sale of land and building in Brazil, $0.4 million in asset write-offs, $0.2 million in severance and pension cost, $0.2 million expenses related to equipment transfers and freight costs and $0.6 million in other relocation costs primarily related to other manufacturing realignment activities. |

[0000038725-17-000042:mdna:33]
| • | $1.2 million related to executive transition. |

[0000038725-17-000042:mdna:34]
| • | $0.1 million in other miscellaneous costs related to closed acquisitions. |

[0000038725-17-000042:mdna:35]
In 2015 they were as follows:

[0000038725-17-000042:mdna:36]
| • | There were $3.0 million of restructuring charges. Restructuring expenses in 2015 were $0.6 million in severance cost, $0.6 million in pension cost, $0.6 million expenses related to equipment transfers and freight costs, $0.1 million in asset write-offs and $1.1 million in other relocation costs primarily related to the closure of the Wittlich, Germany facility and other manufacturing realignment activities in Europe and Brazil. |

[0000038725-17-000042:mdna:37]
| • | $1.2 million related to executive transition. |

[0000038725-17-000042:mdna:38]
| • | $0.7 million related to business realignment cost, primarily severance, in targeted fixed cost reduction actions. |

[0000038725-17-000042:mdna:39]
| • | $0.2 million in other miscellaneous costs related to closed acquisitions. |

[0000038725-17-000042:mdna:40]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments to net sales (operating income margin after non-GAAP adjustments).  The Company believes this information helps investors and management understand underlying trends in the Company's business more easily and by presenting these matters in this way, gives our investors and management a more accurate picture of the actual operational performance of the Company. The non-GAAP adjustments are for restructuring expenses, reported separately on the income statement, as well as certain legal matters and acquisition related items which are included in SG&A on the income statement.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-17-000042:mdna:41]
18

[0000038725-17-000042:mdna:42]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Full Year of 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 108.2 |  | $ | 56.3 |  | $ | (53.7 | ) | $ | 110.8 |  |
| % Operating Income To Net Sales | 15.0 | % | 24.8 | % |  | 11.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | (1.2 | ) | $ | 0.6 |  | $ | — |  | $ | (0.6 | ) |
| Non-GAAP | $ | 0.1 |  | $ | — |  | $ | 1.2 |  | $ | 1.3 |  |
| Operating Income/(Loss) after Non-GAAP Adjustments | $ | 107.1 |  | $ | 56.9 |  | $ | (52.5 | ) | $ | 111.5 |  |
| % Operating Income to Net Sales after Non-GAAP adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.8 | % | 25.1 | % |  | 11.7 | % |
|  | For the Full Year of 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 86.7 |  | $ | 51.5 |  | $ | (47.8 | ) | $ | 90.4 |  |
| % Operating Income To Net Sales | 12.3 | % | 23.7 | % |  | 9.8 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 2.7 |  | $ | 0.3 |  | $ | — |  | $ | 3.0 |  |
| Non-GAAP | $ | 0.7 |  | $ | 0.2 |  | $ | 1.2 |  | $ | 2.1 |  |
| Operating Income/(Loss) after Non-GAAP Adjustments | $ | 90.1 |  | $ | 52.0 |  | $ | (46.6 | ) | $ | 95.5 |  |
| % Operating Income to Net Sales after Non-GAAP adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.7 | % | 23.9 | % |  | 10.3 | % |

[0000038725-17-000042:mdna:43]
Operating Income-Water Systems

[0000038725-17-000042:mdna:44]
Water Systems operating income was $108.2 million in 2016, up $21.5 million or 25 percent versus the 2015 as reported and up $17.0 million or 19 percent versus the 2015 after non-GAAP adjustments. The 2016 operating income margin was 15.0 percent, up 270 basis points from 12.3 percent in 2015. The 2016 operating income margin after non-GAAP adjustments was 14.8 percent, an increase of 210 basis points from the 12.7 percent of net sales in 2015 after non-GAAP adjustments. The increase in basis points was primarily due to improved margins from lower variable costs.

[0000038725-17-000042:mdna:45]
Operating Income-Fueling Systems

[0000038725-17-000042:mdna:46]
Fueling Systems operating income was $56.3 million in 2016, up $4.8 million or about 9 percent compared to $51.5 million in 2015 as reported, and up $4.9 million or 9 percent compared to $52.0 million after non-GAAP adjustments in 2015. The 2016 operating income margin was 24.8 percent, an increase of 110 basis points from the as reported 23.7 percent of net sales in 2015. The 2016 operating income margin after non-GAAP adjustments was 25.1 percent, an increase of 120 basis points from the 23.9 percent of net sales in 2015 after non-GAAP adjustments. The increase in basis points was primarily due to improved margins from lower variable costs.

[0000038725-17-000042:mdna:47]
Operating Income-Other

[0000038725-17-000042:mdna:48]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses after non-GAAP adjustments were higher by about 13 percent, primarily due to higher variable compensation expenses.

[0000038725-17-000042:mdna:49]
Interest Expense

[0000038725-17-000042:mdna:50]
Interest expense for 2016 and 2015 was $8.7 million and $10.0 million, respectively.

[0000038725-17-000042:mdna:51]
Other Income or Expense

[0000038725-17-000042:mdna:52]
Other income or expense was a gain of $1.0 million in 2016. Included in other income or expense in 2016 was minority income of $1.7 million and interest income of $1.0 million, primarily derived from the investment of cash balances in short-term securities. In 2016, other expenses also included the reversal of an indemnification receivable related to a contingent tax liability for $1.9 million recorded at the time of a foreign acquisition.  The contingent tax liability was for the same amount and

[0000038725-17-000042:mdna:53]
was also reversed in 2016 and the benefit was recorded in the income tax provision.  Other income or expense was income of $6.9 million in 2015. Included in other income or expense in 2016 was minority income of $2.8 million and interest income of $1.3 million, primarily derived from the investment of cash balances in short-term securities. The Company also realized a gain on the settlement of the redeemable non-controlling interest liability in the first quarter of 2015 of about $2.7 million.

[0000038725-17-000042:mdna:54]
Foreign Exchange

[0000038725-17-000042:mdna:55]
Foreign currency-based transactions produced a gain for 2016 of $1.1 million, primarily due to the Turkish lira relative to the U.S. dollar and euro.  Foreign currency-based transactions produced a loss for 2015 of $0.9 million, primarily due to the South African rand, Colombian peso and Australian dollar relative to the U.S. dollar, none of which individually were significant.

[0000038725-17-000042:mdna:56]
Income Taxes

[0000038725-17-000042:mdna:57]
The provision for income taxes in 2016 and 2015 was $24.8 million and $12.6 million, respectively. The tax rate for 2016 was 23.8 percent and 2015 was 14.6 percent. Discrete adjustments in 2016 were primarily due to the favorable impact from equity compensation share based payments and the reversal of a contingent tax liability offset by adjustments to the Company’s valuation allowance against certain state deferred tax assets that are not likely to be realized. Discrete adjustments during 2015 were the reversal of a deferred tax liability of about $4.8 million created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer.  This purchase transaction also resulted in other tax benefits of about $3.5 million. The tax rate before discrete adjustments for 2016 was about 26 percent and 2015 was about 27 percent. The tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-17-000042:mdna:58]
Net Income

[0000038725-17-000042:mdna:59]
Net income for 2016 was $79.3 million compared to 2015 net income of $73.7 million.  Net income attributable to Franklin Electric Co., Inc. for 2016 was $78.7 million, or $1.65 per diluted share, compared to 2015 net income attributable to Franklin Electric Co., Inc. of $72.9 million or $1.50 per diluted share. Net income attributable to Franklin Electric Co., Inc. after Non-GAAP adjustments for 2016 was $77.4 million, or $1.66 per diluted share, compared to 2015 net income attributable to Franklin Electric Co., Inc. after Non-GAAP adjustments of $69.7 million or $1.47 per diluted share.

[0000038725-17-000042:mdna:60]
There were specific items in 2016 and 2015 that impacted net income attributable to Franklin Electric Co., Inc.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of net income attributable to Franklin Electric Co., Inc. and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-17-000042:mdna:61]
| Earnings Before and After Non-GAAP Adjustments | For the Full Year |
| (in millions) | 2016 | 2015 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 78.7 |  | $ | 72.9 |  | 8 | % |
| Allocated Undistributed Earnings | $ | (1.7 | ) | $ | (1.5 | ) |  |
| Earnings for EPS Calculations | $ | 77.0 |  | $ | 71.4 |  | 8 | % |
| Non-GAAP adjustments (before tax): |  |  |  |
| Restructuring | $ | (0.6 | ) | $ | 3.0 |  |  |
| Non-GAAP items | $ | 1.3 |  | $ | 2.1 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | (4.8 | ) |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | (0.4 | ) | $ | 1.8 |  |  |
| Non-GAAP items | $ | 0.8 |  | $ | 1.3 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | (4.8 | ) |  |
| Earnings after Non-GAAP Adjustments | $ | 77.4 |  | $ | 69.7 |  | 11 | % |

[0000038725-17-000042:mdna:62]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the Full Year |
| (in millions except per-share data) | 2016 |  | 2015 |  | Change |
| Average Fully Diluted Shares Outstanding | $ | 46.7 |  |  | $ | 47.6 |  |  | (2 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 1.65 |  |  | $ | 1.50 |  |  | 10 | % |
| Restructuring Per Share, net of tax | $ | (0.01 | ) |  | $ | 0.04 |  |  |  |
| Non-GAAP items, net of tax | $ | 0.02 |  |  | $ | 0.03 |  |  |  |
| Pioneer tax benefits on equity gain | $ | — |  |  | $ | (0.10 | ) |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 1.66 |  |  | $ | 1.47 |  |  | 13 | % |

[0000038725-17-000042:mdna:63]
2015 vs. 2014

[0000038725-17-000042:mdna:64]
OVERVIEW

[0000038725-17-000042:mdna:65]
Sales in 2015 decreased from the prior year.  Net sales in 2015 were $924.9 million, a decrease of about 12 percent compared to 2014 sales of $1,047.8 million. The sales decrease was primarily the impact of foreign currency translation as the US dollar strengthened against certain foreign currencies and lower sales volume, partially offset by sales price increases, as well as the Company's acquisitions. The Company's consolidated gross profit was $297.6 million for 2015, a decrease of $46.8 million or about 14 percent from 2014. The gross profit as a percent of net sales decreased 70 basis points to 32.2 percent in 2015 from 32.9 percent in 2014. The gross profit margin change was due primarily to lost leverage on fixed cost due to lower sales. For 2015, diluted earnings per share were $1.50, an increase of 6 percent compared to 2014 diluted earnings per share of $1.41. Adjusted earnings per share were $1.47, a decrease of 16 percent versus the $1.76 adjusted earnings per share in 2014 (see the table below for a reconciliation of the GAAP EPS to the adjusted EPS).

[0000038725-17-000042:mdna:66]
RESULTS OF OPERATIONS

[0000038725-17-000042:mdna:67]
Net Sales

[0000038725-17-000042:mdna:68]
Net sales in 2015 were $924.9 million, a decrease of $122.9 million or about 12 percent compared to 2014 sales of $1,047.8 million.  The incremental impact of sales from acquired businesses was $21.3 million or about 2 percent.  Sales revenue decreased by $89.3 million or about 9 percent in 2015 due to foreign currency translation. The sales change in 2015, excluding acquisitions and foreign currency translation, was a decrease of $54.9 million or about 5 percent.

[0000038725-17-000042:mdna:69]
|  |  | Net Sales |
| (In millions) |  | 2015 |  | 2014 |  | 2015 v 2014 |
| Water Systems |  | $ | 707.6 |  |  | $ | 824.6 |  |  | $ | (117.0 | ) |
| Fueling Systems |  | 217.3 |  |  | 223.2 |  |  | (5.9 | ) |
| Consolidated |  | $ | 924.9 |  |  | $ | 1,047.8 |  |  | $ | (122.9 | ) |

[0000038725-17-000042:mdna:70]
Net Sales-Water Systems

[0000038725-17-000042:mdna:71]
Water Systems sales were $707.6 million in 2015, a decrease of $117.0 million or 14 percent versus 2014. The incremental impact of sales from acquired businesses was $20.8 million or about 2 percent.  Foreign currency translation rate changes decreased sales $78.3 million, or about 9 percent, compared to sales in 2014. The sales change in 2015, excluding acquisitions and foreign currency translation, was a decrease of $59.5 million or about 7 percent.

[0000038725-17-000042:mdna:72]
Water Systems sales in the U.S. and Canada were 36 percent of consolidated sales and declined by about 20 percent in 2015 compared to the prior year. Sales revenue decreased by $5.9 million or about 1 percent in 2015 due to foreign currency translation. In 2015, U.S. and Canada sales of Pioneer branded mobile dewatering equipment declined by about 55 percent. The decline in mobile dewatering equipment is primarily attributed to reduced demand in the oil and gas end markets. Sales of

[0000038725-17-000042:mdna:73]
groundwater pumping equipment declined by about 14 percent, and sales of surface water pumping equipment declined by about 6 percent versus 2014. The decline in groundwater equipment sales is attributable primarily to weaker demand in the agriculture sector as a result of less favorable weather and to a lesser extent, distributor changes the Company made in its primary groundwater distribution channel.  Sales of surface water pumping equipment also declined due to lower condensate pump sales as cooler temperatures delayed the start to the HVAC season.

[0000038725-17-000042:mdna:74]
Water Systems sales in Latin America were about 14 percent of consolidated sales for 2015 and declined by about 9 percent compared to the prior year. Acquisition related sales during 2015 were $10.4 million or about 7 percent. Foreign currency translation rate changes decreased sales $34.7 million, or about 24 percent, compared to sales in 2014. Excluding acquisition and foreign currency translation, sales in Latin America grew by about 8 percent during 2015. The growth in sales was led by increased sales in Mexico and Brazil, in local currency. This sales growth is a result of increasing demand for Franklin submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions.

[0000038725-17-000042:mdna:75]
Water Systems sales in the Middle East and Africa were about 11 percent of consolidated sales and decreased by about 10 percent compared to 2014. Water Systems sales in the Middle East and Africa were reduced by $16.5 million or about 14 percent in the year due to foreign currency translation. Excluding the impact of foreign currency translation, sales were up about 4 percent compared to 2014. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-17-000042:mdna:76]
Water Systems sales in the Asia Pacific region were 8 percent of consolidated sales and grew by about 7 percent compared to the prior year. Acquisition related sales during 2015 increased sales by about 9 percent in Asia Pacific. Foreign currency translation rate changes decreased sales in 2015 in the Asia Pacific region by about 5 percent. Excluding acquisitions and foreign currency translation sales grew by about 3 percent during 2015. The Asia Pacific region experienced strong year over year growth in Southeast Asia and Korea. These sales increases were partially offset by smaller declines in sales in Australia, Japan and China.

[0000038725-17-000042:mdna:77]
Water Systems sales in Europe were about 7 percent of consolidated sales and decreased by about 20 percent compared to the prior year. Foreign currency translation rate changes decreased sales by about 21 percent compared to sales in 2014. Excluding foreign currency translation, European sales grew by about 1 percent during 2015.

[0000038725-17-000042:mdna:78]
Net Sales-Fueling Systems

[0000038725-17-000042:mdna:79]
Fueling Systems sales which represented 23 percent of consolidated sales were $217.3 million in 2015, a decrease of $5.9 million or about 3 percent versus 2014. The incremental impact of sales from acquired businesses was $0.5 million.  Foreign currency translation rate changes decreased sales $11.0 million or about 5 percent compared to sales in 2014. The sales change in 2015, excluding acquisitions and foreign currency translation, was an increase of $4.6 million or about 2 percent.

[0000038725-17-000042:mdna:80]
Fueling Systems sales in the U.S. and Canada grew by about 6 percent in 2015 compared to the prior year with sales growth coming from most product lines, especially in piping. Fueling Systems revenues declined in India and China due to the timing of tender awards made in India and the ongoing reduction in State owned oil company procurements in China. Sales also declined in Europe principally due to a 42 percent decline in the sale of storage tanks that support North Sea oil production.

[0000038725-17-000042:mdna:81]
Cost of Sales

[0000038725-17-000042:mdna:82]
Cost of sales as a percent of net sales for 2015 and 2014 was 67.8 percent and 67.1 percent, respectively. Correspondingly, the gross profit margin decreased to 32.2 percent from 32.9 percent, a 70 basis point decline. The gross profit margin decrease was primarily due to fixed costs deleverage on lower sales and higher raw material costs.  Direct materials as a percentage of sales was 46.9 percent up 50 basis points compared to 46.4 percent last year.  This increase in direct materials was partially offset by lower labor and burden costs.  The Company's consolidated gross profit was $297.6 million for 2015, down $46.8 million or 14 percent from 2014.

[0000038725-17-000042:mdna:83]
Selling, General and Administrative (“SG&A”)

[0000038725-17-000042:mdna:84]
Selling, general, and administrative (SG&A) expenses were $204.3 million in 2015 and decreased by $23.4 million or about 10 percent in 2015 compared to last year. In 2015, increases in SG&A attributable to acquisitions were about $6 million or about 3 percent. Additional year over year changes in SG&A costs were decreases in the year primarily due to lower marketing and selling related expenses, as well as lower costs for incentive compensation. Approximately half of the lower SG&A expenses was related to foreign exchange.

[0000038725-17-000042:mdna:85]
Restructuring Expenses

[0000038725-17-000042:mdna:86]
Restructuring expenses for 2015 were $3.0 million and reduced diluted earnings per share by approximately $0.04. Restructuring expenses in 2015 included severance and pension costs, equipment relocation expenses, asset write-downs and primarily related to the closure of the Wittlich, Germany facility and other manufacturing realignment activities in Europe and Brazil. There were $16.6 million of restructuring expenses in 2014 and reduced diluted earnings per share by approximately $0.24. Restructuring expenses in 2014 included severance costs, equipment relocation expenses, and asset write-downs primarily related to the closure of the Wittlich, Germany facility and other European manufacturing realignment activities.

[0000038725-17-000042:mdna:87]
Operating Income

[0000038725-17-000042:mdna:88]
Operating income was $90.4 million in 2015, down $9.7 million from $100.1 million in 2014.

[0000038725-17-000042:mdna:89]
|  |  | Operating income (loss) |
| (In millions) |  | 2015 |  | 2014 |  | 2015 v 2014 |
| Water Systems |  | $ | 86.7 |  |  | $ | 103.9 |  |  | $ | (17.2 | ) |
| Fueling Systems |  | 51.5 |  |  | 49.7 |  |  | 1.8 |  |
| Other |  | (47.8 | ) |  | (53.5 | ) |  | 5.7 |  |
| Consolidated |  | $ | 90.4 |  |  | $ | 100.1 |  |  | $ | (9.7 | ) |

[0000038725-17-000042:mdna:90]
There were specific items in 2015 and 2014 that impacted operating income.

[0000038725-17-000042:mdna:91]
In 2015 they were as follows:

[0000038725-17-000042:mdna:92]
| • | There were $3.0 million of restructuring charges. Restructuring expenses in 2015 were $0.6 million in severance cost, $0.6 million in pension cost, $0.6 million expenses related to equipment transfers and freight costs, $0.1 million in asset write-offs and $1.1 million in other relocation costs primarily related to the closure of the Wittlich, Germany facility and other manufacturing realignment activities in Europe and Brazil. |

[0000038725-17-000042:mdna:93]
| • | $1.2 million related to executive transition. |

[0000038725-17-000042:mdna:94]
| • | $0.7 million related to business realignment cost, primarily severance, in targeted fixed cost reduction actions. |

[0000038725-17-000042:mdna:95]
| • | $0.2 million in other miscellaneous costs related to closed acquisitions. |

[0000038725-17-000042:mdna:96]
In 2014 they were as follows:

[0000038725-17-000042:mdna:97]
| • | There were $16.6 million of restructuring charges. Restructuring expenses in 2014 were $14.7 million in severance cost, $1.7 million expenses related to equipment transfers, freight and other relocation costs and $0.2 million in asset write-offs primarily related to the transfer of production activities from Germany to the Czech Republic and other continued manufacturing realignments. |

[0000038725-17-000042:mdna:98]
| • | $3.2 million in other miscellaneous costs related to closed and pending acquisitions and $0.2 million in legal fees incurred by Franklin Fueling Systems. |

[0000038725-17-000042:mdna:99]
| • | $2.5 million related to executive transition. |

[0000038725-17-000042:mdna:100]
| • | $1.8 million of software write-offs. |

[0000038725-17-000042:mdna:101]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments to net sales (operating income margin after non-GAAP adjustments).  The Company believes this information helps investors and management understand underlying trends in the Company's business more easily and by presenting these matters in this way, gives our investors and management a more accurate picture of the actual operational performance of the Company. The non-GAAP adjustments are for restructuring expenses, reported separately on the income statement, as well as certain legal matters and acquisition related items which are included in SG&A on the income statement.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-17-000042:mdna:102]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Full Year of 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 86.7 |  | $ | 51.5 |  | $ | (47.8 | ) | $ | 90.4 |  |
| % Operating Income To Net Sales | 12.3 | % | 23.7 | % |  | 9.8 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 2.7 |  | $ | 0.3 |  | $ | — |  | $ | 3.0 |  |
| Non-GAAP | $ | 0.7 |  | $ | 0.2 |  | $ | 1.2 |  | $ | 2.1 |  |
| Operating Income after Non-GAAP Adjustments | $ | 90.1 |  | $ | 52.0 |  | $ | (46.6 | ) | $ | 95.5 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.7 | % | 23.9 | % |  | 10.3 | % |
|  | For the Full Year of 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 103.9 |  | $ | 49.7 |  | $ | (53.5 | ) | $ | 100.1 |  |
| % Operating Income To Net Sales | 12.6 | % | 22.3 | % |  | 9.6 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 16.1 |  | $ | 0.5 |  | $ | — |  | $ | 16.6 |  |
| Non-GAAP | $ | 3.7 |  | $ | 1.5 |  | $ | 2.5 |  | $ | 7.7 |  |
| Operating Income after Non-GAAP Adjustments | $ | 123.7 |  | $ | 51.7 |  | $ | (51.0 | ) | $ | 124.4 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.0 | % | 23.2 | % |  | 11.9 | % |

[0000038725-17-000042:mdna:103]
Operating Income-Water Systems

[0000038725-17-000042:mdna:104]
Water Systems operating income, after non-GAAP adjustments, was $90.1 million in 2015, a decrease of 27 percent versus 2014. The 2015 operating income margin after non-GAAP adjustments was 12.7 percent and decreased by 230 basis points compared to the 15.0 percent of net sales in 2014. Operating income margin after non-GAAP adjustments decreased in Water Systems primarily due to loss of operating leverage.

[0000038725-17-000042:mdna:105]
Operating Income-Fueling Systems

[0000038725-17-000042:mdna:106]
Fueling Systems operating income after non-GAAP adjustments was $52.0 million in 2015 compared to $51.7 million after non-GAAP adjustments in 2014. The 2015 operating income margin after non-GAAP adjustments was 23.9 percent and increased by 70 basis points compared to the 23.2 percent of net sales in 2014. This increased profitability was primarily due to lower fixed costs.

[0000038725-17-000042:mdna:107]
Operating Income-Other

[0000038725-17-000042:mdna:108]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses after non-GAAP adjustments were down about 9 percent compared to last year primarily due to lower incentive compensation due to lower overall operating results.

[0000038725-17-000042:mdna:109]
Interest Expense

[0000038725-17-000042:mdna:110]
Interest expense for 2015 and 2014 was $10.0 million and $10.7 million, respectively.

[0000038725-17-000042:mdna:111]
Other Income or Expense

[0000038725-17-000042:mdna:112]
Other income or expense was a gain of $6.9 million in 2015. Included in other income or expense in 2015 was minority income of $2.8 million and interest income of $1.3 million, primarily derived from the investment of cash balances in short-term securities. The Company also realized a gain on the settlement of the redeemable non-controlling interest liability in the first quarter of this year of about $2.7 million. Other income or expense was a gain of $1.3 million in 2014 and included in other

[0000038725-17-000042:mdna:113]
income or expense in 2014 was interest income of $2.0 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-17-000042:mdna:114]
Foreign Exchange

[0000038725-17-000042:mdna:115]
Foreign currency-based transactions produced a loss for 2015 of $0.9 million, primarily due to the South African rand, Colombian Peso and Australian dollar relative to the U.S. dollar, none of which individually were significant.  Foreign currency-based transactions produced a loss for 2014 of $1.0 million, primarily due to the Canadian dollar, Australian dollar, Turkish lira, and South African rand relative to the U.S. dollar, none of which individually were significant.

[0000038725-17-000042:mdna:116]
Income Taxes

[0000038725-17-000042:mdna:117]
The provision for income taxes in 2015 and 2014 was $12.6 million and $18.9 million, respectively. The tax rate for 2015 was 14.6 percent and 2014 was 21.0 percent. Discrete adjustments during 2015 were the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer. This tax benefit of about $4.8 million was treated as a non-GAAP adjustment. Because in 2012, the gain was treated as a non-GAAP adjustment, the Company is now consistently treating the reversal of the tax liability related to that gain as a non-GAAP adjustment and reducing reported Earnings per Share in 2015 by $0.10 cents. The Company also realized a gain on the redeemable non-controlling interest liability in the year of about $2.7 million which is included in ‘Other income’. This purchase transaction also resulted in other tax benefits of about $2.5 million, which were expensed through the Company’s earnings in prior years as well as a benefit of about $1.0 million related to the 2015 gain. The tax rate before discrete adjustments for 2015 was about 27 percent and 2014 was about 26 percent. The tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-17-000042:mdna:118]
Net Income

[0000038725-17-000042:mdna:119]
Net income for 2015 was $73.7 million compared to 2014 net income of $70.9 million.  Net income attributable to Franklin Electric Co., Inc. for 2015 was $72.9 million, or $1.50 per diluted share, compared to 2014 net income attributable to Franklin Electric Co., Inc. of $69.8 million or $1.41 per diluted share. Net income attributable to Franklin Electric Co., Inc. after Non-GAAP adjustments for 2015 was $69.7 million, or $1.47 per diluted share, compared to 2014 net income attributable to Franklin Electric Co., Inc. after Non-GAAP adjustments of $84.3 million or $1.76 per diluted share.

[0000038725-17-000042:mdna:120]
There were specific items in 2015 and 2014 that impacted net income attributable to Franklin Electric Co., Inc. The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of net income attributable to Franklin Electric Co., Inc. and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-17-000042:mdna:121]
| Earnings Before and After Non-GAAP Adjustments | For the Full Year |
| (in millions) | 2015 |  | 2014 |  | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 72.9 |  |  | $ | 69.8 |  |  | 4 | % |
| Allocated Undistributed Earnings | $ | (1.5 | ) |  | $ | (1.6 | ) |  |  |
| Earnings for EPS Calculations | $ | 71.4 |  |  | $ | 68.2 |  |  | 5 | % |
| Non-GAAP adjustments (before tax): |  |  |  |  |  |
| Restructuring | $ | 3.0 |  |  | $ | 16.6 |  |  |  |
| Non-GAAP items | $ | 2.1 |  |  | $ | 7.7 |  |  |  |
| Pioneer tax benefits on equity gain | $ | (4.8 | ) |  | $ | — |  |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |  |
| Restructuring | $ | 1.8 |  |  | $ | 11.4 |  |  |  |
| Non-GAAP items | $ | 1.3 |  |  | $ | 4.7 |  |  |  |
| Pioneer tax benefits on equity gain | $ | (4.8 | ) |  | $ | — |  |  |  |
| Earnings after Non-GAAP Adjustments | $ | 69.7 |  |  | $ | 84.3 |  |  | (17 | )% |

[0000038725-17-000042:mdna:122]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the Full Year |
| (in millions except per-share data) | 2015 |  | 2014 |  | Change |
| Average Fully Diluted Shares Outstanding | $ | 47.6 |  |  | $ | 48.2 |  |  | (1 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 1.50 |  |  | $ | 1.41 |  |  | 6 | % |
| Restructuring Per Share, net of tax | $ | 0.04 |  |  | $ | 0.24 |  |  |  |
| Non-GAAP items, net of tax | $ | 0.03 |  |  | $ | 0.11 |  |  |  |
| Pioneer tax benefits on equity gain | $ | (0.10 | ) |  | $ | — |  |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 1.47 |  |  | $ | 1.76 |  |  | (16 | )% |

[0000038725-17-000042:mdna:123]
CAPITAL RESOURCES AND LIQUIDITY

[0000038725-17-000042:mdna:124]
Sources of Liquidity

[0000038725-17-000042:mdna:125]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at December 31, 2016 is adequate to meet projected needs.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-17-000042:mdna:126]
As of December 31, 2016, the Company had a $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of December 31, 2016, the Company had $294.1 million borrowing capacity under the Credit Agreement as $5.9 million in letters of commercial and standby letters of credit were outstanding and undrawn and no revolver borrowing was drawn and outstanding as of the end of the quarter.

[0000038725-17-000042:mdna:127]
The Company also has other long-term debt borrowings outstanding as of December 31, 2016.  See Footnote 11 for additional specifics regarding these obligations and future maturities.

[0000038725-17-000042:mdna:128]
26

[0000038725-17-000042:mdna:129]
At December 31, 2016, the Company had $74.5 million of cash and cash equivalents held in foreign jurisdictions, which will be used to fund foreign operations.  There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.  If the Company chose to repatriate historical earnings held in foreign jurisdictions, the intention to do so would only be in a tax-efficient manner.

[0000038725-17-000042:mdna:130]
Cash Flows

[0000038725-17-000042:mdna:131]
The following table summarizes significant sources and uses of cash and cash equivalents:

[0000038725-17-000042:mdna:132]
| (in thousands) | 2016 |  | 2015 |  | 2014 |
| Net cash provided by operating activities | $ | 115.4 |  |  | $ | 99.6 |  |  | $ | 47.3 |  |
| Net cash used in investing activities | (33.8 | ) |  | (29.6 | ) |  | (77.7 | ) |
| Net cash used in financing activities | (51.7 | ) |  | (41.1 | ) |  | (44.3 | ) |
| Impact of exchange rates on cash and cash equivalents | (7.1 | ) |  | (6.5 | ) |  | (0.7 | ) |
| Change in cash and cash equivalents | $ | 22.8 |  |  | $ | 22.4 |  |  | $ | (75.4 | ) |

[0000038725-17-000042:mdna:133]
Cash Flows Provided by Operating Activities

[0000038725-17-000042:mdna:134]
2016 vs. 2015

[0000038725-17-000042:mdna:135]
Net cash provided by operating activities was $115.4 million for 2016 compared to $99.6 million for 2015.  An increase in cash provided by operations in 2016 was partially attributable to large cash outflows in 2015 related to restructuring costs previously accrued at year-end 2014.  The increase in cash provided was partially offset by increased cash used during 2016 for higher receivables and inventory balances compared to year-end 2015, driven by higher sales volumes in 2016.  Finally, during 2015 the mandatory share purchase liability of $22.9 million for Pioneer was settled, resulting in a non-cash gain and reversal of certain deferred tax liabilities, also non-cash, both of which were adjustments to net income.

[0000038725-17-000042:mdna:136]
2015 vs. 2014

[0000038725-17-000042:mdna:137]
Net cash provided by operating activities was $99.6 million for 2015 compared to $47.3 million for 2014. The increase in cash provided from operations in 2015 compared to 2014 was primarily due to lower uses of cash for trade receivables and inventory in conjunction with reduced sales in 2015. This increase in cash provided from operations was partially offset by a reduction in outstanding accounts payable balances at year-end 2015 compared to 2014. This reduction was also primarily due to lower year-end inventory levels.

[0000038725-17-000042:mdna:138]
Cash Flows Used in Investing Activities

[0000038725-17-000042:mdna:139]
2016 vs. 2015

[0000038725-17-000042:mdna:140]
Net cash used in investing activities was $33.8 million in 2016 compared to $29.6 million in 2015. During 2016, the Company had increased capital expenditures compared to 2015, primarily attributable to the purchase of a building in the first quarter.  Cash expended on this purchase was partially offset with proceeds realized from the sale of an idle building in Brazil which completed during the third quarter of 2016.

[0000038725-17-000042:mdna:141]
2015 vs. 2014

[0000038725-17-000042:mdna:142]
Net cash used in investing activities was $29.6 million in 2015 compared to $77.7 million in 2014. During 2015, the Company used less cash for acquisitions and equity investment purchases compared to 2014. In addition, cash used for capital expenditures during 2015 was less than the previous year as 2014 saw the completion of a new manufacturing facility in Brazil.  During 2014, the Company completed the acquisitions of Bombas Leao S.A. (“Bombas Leao”), with cash on hand and short-term borrowings repaid within the year, and two entities in India, with cash on hand.

[0000038725-17-000042:mdna:143]
Cash Flows Used in Financing Activities

[0000038725-17-000042:mdna:144]
2016 vs. 2015

[0000038725-17-000042:mdna:145]
Net cash flows from financing activities were uses of cash of $51.7 million in 2016 compared to $41.1 million in 2015.  During 2016, the Company had net repayments of debt of about $30.4 million compared to net borrowings during 2015 of about $43.6 million, resulting in a greater use of cash.  The Company paid dividends of $19.1 million in 2016, which was up slightly from $18.9 million in 2015.  In addition, in 2015 the Company made a payment of $20.2 million for the Pioneer mandatory share purchase liability and repurchased a significant amount of the Company's common stock, which were both large uses of cash that did not repeat in 2016.

[0000038725-17-000042:mdna:146]
2015 vs. 2014

[0000038725-17-000042:mdna:147]
Net cash flows from financing activities were uses of cash of $41.1 million in 2015 compared to $44.3 million in 2014. During 2015, the Company made a payment of $20.2 million for the Pioneer mandatory share purchase liability. In addition, the Company used cash of $46.3 million to complete the repurchase of about 1.6 million shares of the Company’s common stock pursuant to the Company’s stock repurchase program. Dividends in the amount of $18.9 million were paid to shareholders. The Company also had increased debt borrowings and repayments during 2015 primarily due to the issuance of $75.0 million of debt under the New York Life Agreement, first scheduled Prudential Agreement payment of $30.0 million, and increased Revolver borrowing and repayments.

[0000038725-17-000042:mdna:148]
AGGREGATE CONTRACTUAL OBLIGATIONS

[0000038725-17-000042:mdna:149]
The majority of the Company’s contractual obligations to third parties relate to debt obligations.  In addition, the Company has certain contractual obligations for future lease payments and purchase obligations.  The payment schedule for these contractual obligations is as follows:

[0000038725-17-000042:mdna:150]
| (In millions) |  |  |  |  |  |  |  |  | More than |
|  | Total |  | 2017 |  | 2018-2019 |  | 2020-2021 |  | 5 years |
| Debt | $ | 190.4 |  |  | $ | 33.7 |  |  | $ | 62.5 |  |  | $ | 2.4 |  |  | $ | 91.8 |  |
| Debt interest | 29.3 |  |  | 7.5 |  |  | 8.1 |  |  | 4.5 |  |  | 9.2 |  |
| Capital leases | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |
| Operating leases | 21.4 |  |  | 7.4 |  |  | 9.2 |  |  | 4.1 |  |  | 0.7 |  |
| Purchase obligations | 10.8 |  |  | 10.8 |  |  | — |  |  | — |  |  | — |  |
|  | $ | 252.0 |  |  | $ | 59.4 |  |  | $ | 79.9 |  |  | $ | 11.0 |  |  | $ | 101.7 |  |

[0000038725-17-000042:mdna:151]
The Company has pension and other post-retirement benefit obligations not included in the table above which will result in estimated future payments of approximately $6 million in 2017.  The Company also has unrecognized tax benefits, none of which are included in the table above.  The unrecognized tax benefits of approximately $1.3 million have been recorded as liabilities and the Company is uncertain as to if or when such amounts may be settled.  Related to the unrecognized tax benefits, the Company has also recorded a liability for potential penalties and interest of $1.1 million.

[0000038725-17-000042:mdna:152]
ACCOUNTING PRONOUNCEMENTS

[0000038725-17-000042:mdna:153]
Accounting Standards Issued But Not Yet Adopted

[0000038725-17-000042:mdna:154]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification ("ASC") Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company has begun the evaluation process for the adoption of the ASU, and anticipates that the majority of the Company’s outstanding operating leases would be recognized as right-of-use assets and lease liabilities upon adoption, resulting in a significant impact to the Company’s Consolidated Balance Sheets. The impact of this ASU is non-cash in nature and will not affect the Company’s cash position.  The impact to the Company’s results of operations is still being evaluated.

[0000038725-17-000042:mdna:155]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606).  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  In March 2016, the FASB issued ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net).  ASU 2016-08 clarifies the implementation guidance on principal versus agent considerations.  In April 2016, the FASB issued ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing.  ASU 2016-10 clarifies the implementation guidance on identifying performance obligations.  These ASUs are effective for interim and annual reporting periods beginning after December 15, 2017.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt these standards.  The Company will adopt ASU 2014-09 beginning in the first quarter of 2018 using the modified retrospective approach.  The Company does not expect the adoption of this ASU to have a material impact on the Company’s consolidated financial position, results of operations, or cash flows.

[0000038725-17-000042:mdna:156]
CRITICAL ACCOUNTING ESTIMATES

[0000038725-17-000042:mdna:157]
Management’s discussion and analysis of its financial condition and results of operations are based upon the Company’s consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires management to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and the related disclosure of contingent assets and liabilities.  Management evaluates its estimates on an ongoing basis.  Estimates are based on historical experience and on other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions.  There were no material changes to estimates or methodologies used to develop those estimates in 2016.

[0000038725-17-000042:mdna:158]
The Company’s critical accounting estimates are identified below:

[0000038725-17-000042:mdna:159]
Inventory Valuation

[0000038725-17-000042:mdna:160]
The Company uses certain estimates and judgments to value inventory. Inventory is recorded at the lower of cost or market. The Company reviews its inventories for excess or obsolete products or components. Based on an analysis of historical usage, management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts, carrying values are adjusted.  The carrying value is reduced regularly to reflect the age and current anticipated product demand. If actual demand differs from the estimates, additional reductions would be necessary in the period such determination is made.  Excess and obsolete inventory is periodically disposed of through sale to third parties, scrapping, or other means.

[0000038725-17-000042:mdna:161]
Trade Names and Goodwill

[0000038725-17-000042:mdna:162]
According to FASB ASC Topic 350, Intangibles - Goodwill and Other, intangible assets with indefinite lives must be tested for impairment at least annually or more frequently as warranted by triggering events that indicate potential impairment.  The Company uses a variety of methodologies in conducting impairment assessments including income and market approaches.  For indefinite-lived assets apart from goodwill, primarily trade names for the Company, if the fair value is less than the carrying amount, an impairment charge is recognized in an amount equal to that excess.  The Company has not made any material changes to the method of evaluating impairments during the last three years.

[0000038725-17-000042:mdna:163]
In compliance with FASB ASC Topic 350, goodwill is not amortized. Goodwill is tested at the reporting unit level for impairment annually or more frequently as warranted by triggering events that indicate potential impairment.  Reporting units are operating segments or one level below, known as components, which can be aggregated for testing purposes.  The Company’s goodwill is allocated to the North America Water Systems, International Water, and Fueling Systems units, as components within the North America Water Systems and International Water reporting units can be aggregated.  As the Company’s business model evolves, management will continue to evaluate its reporting units and review the aggregation criteria.

[0000038725-17-000042:mdna:164]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the market value and income approaches. The market value approach compares the reporting units' current and projected financial results to entities of similar size and industry to determine the market value of the reporting unit. The income approach utilizes assumptions regarding estimated future cash flows and other factors to determine the fair value of the respective assets. These cash flows consider factors regarding expected future operating income and historical trends, as well as the effects of demand and competition. The Company may be required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units is below their associated carrying values. Goodwill included on the balance sheet as of the fiscal year ended 2016 was $199.6 million.

[0000038725-17-000042:mdna:165]
During the fourth quarter of 2016, the Company completed its annual impairment test of goodwill and tradenames and determined the fair value of all intangibles were substantially in excess of the respective carrying values.  Significant judgment is required to determine if an indication of impairment has taken place.  Factors to be considered include the following: adverse changes in operating results, decline in strategic business plans, significantly lower future cash flows, and sustainable declines in market data such as market capitalization.  A 10 percent decrease in the fair value estimates used in the impairment test would not have changed this determination.  The sensitivity analysis required the use of numerous subjective assumptions, which, if actual experience varies, could result in material differences in the requirements for impairment charges.  Further, an extended downturn in the economy may impact certain components of the operating segments more significantly and could result in changes to the aggregation assumptions and impairment determination.

[0000038725-17-000042:mdna:166]
Income Taxes

[0000038725-17-000042:mdna:167]
Under the requirements of FASB ASC Topic 740, Income Taxes, the Company records deferred tax assets and liabilities for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and

[0000038725-17-000042:mdna:168]
liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company analyzes the deferred tax assets and liabilities for their future realization based on the estimated existence of sufficient taxable income.  This analysis considers the following sources of taxable income: prior year taxable income, future reversals of existing taxable temporary differences, future taxable income exclusive of reversing temporary differences and tax planning strategies that would generate taxable income in the relevant period.  If sufficient taxable income is not projected then the Company will record a valuation allowance against the relevant deferred tax assets.

[0000038725-17-000042:mdna:169]
The Company's operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions.  These jurisdictions have different tax rates, and the Company determines the allocation of income to each of these jurisdictions based upon various estimates and assumptions. In the normal course of business, the Company will undergo tax audits by various tax jurisdictions. Such audits often require an extended period of time to complete and may result in income tax adjustments if changes to the allocation are required between jurisdictions with different tax rates.  The final taxes paid are dependent upon many factors, including negotiations with taxing authorities in the various jurisdictions and resolution of disputes arising from federal, state, and international tax audits.  Although the Company has recorded all income tax uncertainties in accordance with FASB ASC Topic 740, these accruals represent estimates that are subject to the inherent uncertainties associated with the tax audit process, and therefore include uncertainties.  Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, which, if actual experience varies, could result in material adjustments to tax expense and/or deferred tax assets and liabilities.

[0000038725-17-000042:mdna:170]
Pension and Employee Benefit Obligations

[0000038725-17-000042:mdna:171]
The Company consults with its actuaries to assist with the calculation of discount rates used in its pension and post retirement plans.  Beginning in 2016, the discount rates used to determine domestic pension and post-retirement plan liabilities are calculated using a full yield curve approach.  The change compared to the previous method resulted in different service and interest components of net periodic benefit cost in the 2016 fiscal year.  Historically, the Company estimated these service and interest cost components utilizing a single weighted-average discount rate derived from the yield curve used to measure the benefit obligation at the beginning of the period.  The Company made this change to provide a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot yield curve rates. Market conditions have caused the weighted-average discount rate to move from 4.37 percent last year to 4.13 percent this year for the domestic pension plans and from 4.09 percent last year to 3.89 percent this year for the postretirement health and life insurance plan. A change in the discount rate selected by the Company of 25 basis points would result in a change of about $0.1 million to employee benefit expense and a change of about $4.1 million of liability.

[0000038725-17-000042:mdna:172]
The Company consults with actuaries and investment advisors in making its determination of the expected long-term rate of return on plan assets. Using input from these consultations such as long-term investment sector expected returns, the correlations and standard deviations thereof, and the plan asset allocation, the Company has assumed an expected long-term rate of return on plan assets of 6.25 percent as of the fiscal year ended 2016.  A change in the long-term rate of return selected by the Company of 25 basis points would result in a change of about $0.4 million of employee benefit expense.

[0000038725-17-000042:mdna:173]
According to FASB ASC 715, Compensation - Retirement Benefits, settlement accounting is triggered when lump sum payouts from a defined benefit plan exceed the sum of service cost and interest cost for the year. During 2016, one of the Company’s domestic pension plans required settlement accounting as a payout to a participant exceeded these criteria.

[0000038725-17-000042:mdna:174]
FACTORS THAT MAY AFFECT FUTURE RESULTS

[0000038725-17-000042:mdna:175]
presently available.  The Company does not assume any obligation to update any forward-looking information, except as required by law.
