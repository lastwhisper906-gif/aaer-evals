# FELE 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000038725-17-000042:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0000038725-17-000042:item_9a:2]
As of the end of the period covered by this report (the “Evaluation Date”), the Company carried out an evaluation, under the supervision and with the participation of the Company’s management, including the Company’s Chief Executive Officer and the Company’s Chief Financial Officer, of the effectiveness of the design and operation of the Company’s disclosure controls and procedures pursuant to Exchange Act Rules 13a-15.  Based upon that evaluation, the Company’s Chief Executive Officer and the Company’s Chief Financial Officer concluded that, as of the Evaluation Date, the Company’s disclosure controls and procedures were effective.

[0000038725-17-000042:item_9a:3]
In the third quarter of 2016, the Company began the process of a multi-year implementation of a global enterprise resource planning (“ERP”) system.  The new ERP system was designed to better support the Company's business needs in response to the changing operating environment.  The implementation of a worldwide ERP system will likely affect the processes that constitute the Company's internal control over financial reporting and will require testing for effectiveness as the implementation progresses. The Company expects that the new ERP system will enhance the overall system of internal controls over financial reporting through further automation and integration of business processes, although it is not being implemented in response to any identified deficiency in the Company’s internal controls over financial reporting.

[0000038725-17-000042:item_9a:4]
Other than the ERP implementation, there have been no changes in the Company's internal control over financial reporting identified in connection with the evaluation required by Rules 13a-15 under the Exchange Act during the last fiscal quarter that have materially affected, or are reasonably likely to materially affect the Company's internal control over financial reporting.

[0000038725-17-000042:item_9a:5]
MANAGEMENT’S REPORT ON INTERNAL CONTROL OVER FINANCIAL REPORTING

[0000038725-17-000042:item_9a:6]
Management is responsible for establishing and maintaining an adequate system of internal control over financial reporting of the Company.  This system is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with accounting principles generally accepted in the United States of America.

[0000038725-17-000042:item_9a:7]
The Company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the financial statements.

[0000038725-17-000042:item_9a:8]
Because of its inherent limitations, internal control over financial reporting can provide only reasonable assurance with respect to financial statement preparation and may not prevent or detect misstatements.  Further, because of changes in conditions, effectiveness of internal controls over financial reporting may vary over time.

[0000038725-17-000042:item_9a:9]
Management conducted an evaluation of the effectiveness of the system of internal control over financial reporting based on the framework in the Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.  Based on its evaluation, management concluded that the Company’s system of internal control over financial reporting was effective as of December 31, 2016.

[0000038725-17-000042:item_9a:10]
Our independent registered public accounting firm has issued an audit report on the effectiveness of the Company’s internal control over financial reporting as of December 31, 2016.  This report appears on page 68.

[0000038725-17-000042:item_9a:11]
67

[0000038725-17-000042:item_9a:12]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000038725-17-000042:item_9a:13]
To the Board of Directors and Shareholders of Franklin Electric Co., Inc.

[0000038725-17-000042:item_9a:14]
Fort Wayne, Indiana

[0000038725-17-000042:item_9a:15]
We have audited the internal control over financial reporting of Franklin Electric Co., Inc. and subsidiaries (the "Company") as of December 31, 2016, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. The Company's management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company's internal control over financial reporting based on our audit.

[0000038725-17-000042:item_9a:16]
We conducted our audit in accordance with the standards of the Public Company Accounting Oversight Board (United States). Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000038725-17-000042:item_9a:17]
A company's internal control over financial reporting is a process designed by, or under the supervision of, the company's principal executive and principal financial officers, or persons performing similar functions, and effected by the company's board of directors, management, and other personnel to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company's internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company's assets that could have a material effect on the financial statements.

[0000038725-17-000042:item_9a:18]
Because of the inherent limitations of internal control over financial reporting, including the possibility of collusion or improper management override of controls, material misstatements due to error or fraud may not be prevented or detected on a timely basis. Also, projections of any evaluation of the effectiveness of the internal control over financial reporting to future periods are subject to the risk that the controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000038725-17-000042:item_9a:19]
In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2016, based on the criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0000038725-17-000042:item_9a:20]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States), the consolidated financial statements and financial statement schedule as of and for the three years ended December 31, 2016 of the Company and our report dated March 1, 2017 expressed an unqualified opinion on those financial statements and financial statement schedule.

[0000038725-17-000042:item_9a:21]
/s/DELOITTE & TOUCHE LLP

[0000038725-17-000042:item_9a:22]
Chicago, Illinois

[0000038725-17-000042:item_9a:23]
March 1, 2017

[0000038725-17-000042:item_9a:24]
68
