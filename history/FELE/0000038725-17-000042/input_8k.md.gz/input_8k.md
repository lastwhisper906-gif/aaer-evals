# FELE 8-K — 0000038725-17-000019 filed 2017-02-21

## item codes, every 8-K on or before 2017-03-01

- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2017-03-01

- none on or before 2017-03-01

## item 2.02 — earnings release, exhibit 99.1

[0000038725-17-000019:8k_2_02:1]
EX-99.1
2
a201702218-kexhibit991.htm
EXHIBIT 99.1

[0000038725-17-000019:8k_2_02:2]
Exhibit

[0000038725-17-000019:8k_2_02:3]
Exhibit 99.1

[0000038725-17-000019:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000038725-17-000019:8k_2_02:5]
Contact:    John J. Haines

[0000038725-17-000019:8k_2_02:6]
Franklin Electric Co., Inc.

[0000038725-17-000019:8k_2_02:7]
260.824.2900

[0000038725-17-000019:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS FOURTH QUARTER

[0000038725-17-000019:8k_2_02:9]
2016 SALES AND EARNINGS

[0000038725-17-000019:8k_2_02:10]
Fort Wayne, IN - February 21, 2017 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported fourth quarter 2016 GAAP fully diluted earnings per share (EPS) of $0.37, versus a GAAP fully diluted EPS in the fourth quarter 2015 of $0.33, an increase of 12 percent.  In the fourth quarter of 2016, the Company’s adjusted EPS was $0.38 compared to 2015 fourth quarter adjusted EPS of $0.35, a 9 percent increase (see table below for a reconciliation of GAAP EPS to the adjusted EPS).

[0000038725-17-000019:8k_2_02:11]
Fourth quarter 2016 sales were $239.6 million, an increase of 9 percent compared to 2015 fourth quarter sales of $219.3 million.  The Company’s organic sales growth was 10 percent. The impact of foreign currency translation was a reduction in sales of about 1 percent.

[0000038725-17-000019:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-17-000019:8k_2_02:13]
“Overall, we’re pleased with the Company’s results in the fourth quarter, particularly the performance of our Water Systems segment.  Strong sales performance in the U.S and Canada led the way with overall Water segment organic sales growth of 9 percent.  Our Water Systems adjusted operating income margin was 30 basis points higher in the fourth quarter than the same quarter of 2015.  Our Fueling Systems segment recorded record sales in the fourth quarter with an organic sales growth of 11 percent after excluding the impact of foreign currency translation.”

[0000038725-17-000019:8k_2_02:14]
Key Performance Indicators:

[0000038725-17-000019:8k_2_02:15]
| Earnings Before and After Non-GAAP Adjustments |  | For the Fourth Quarter |  | For the Full Year |
| (in millions) |  | 2016 | 2015 | Change |  | 2016 | 2015 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 17.6 |  | $ | 16.2 |  | 9 | % |  | $ | 78.7 |  | $ | 72.9 |  | 8 | % |
| Allocated Undistributed Earnings |  | $ | (0.3 | ) | $ | (0.5 | ) |  |  | $ | (1.7 | ) | $ | (1.5 | ) |  |
| Earnings for EPS Calculations |  | $ | 17.3 |  | $ | 15.7 |  | 10 | % |  | $ | 77.0 |  | $ | 71.4 |  | 8 | % |
| Non-GAAP adjustments (before tax): |  |  |  |  |  |  |  |  |
| Restructuring |  | $ | 0.3 |  | $ | 0.5 |  |  |  | $ | (0.6 | ) | $ | 3.0 |  |  |
| Non-GAAP items |  | $ | 0.4 |  | $ | 0.4 |  |  |  | $ | 1.3 |  | $ | 2.1 |  |  |
| Pioneer tax benefits on equity gain |  | $ | — |  | $ | — |  |  |  | $ | — |  | $ | (4.8 | ) |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |  |  |  |  |
| Restructuring |  | $ | 0.2 |  | $ | 0.3 |  |  |  | $ | (0.4 | ) | $ | 1.8 |  |  |
| Non-GAAP items |  | $ | 0.2 |  | $ | 0.2 |  |  |  | $ | 0.8 |  | $ | 1.3 |  |  |
| Pioneer tax benefits on equity gain |  | $ | — |  | $ | — |  |  |  | $ | — |  | $ | (4.8 | ) |  |
| Earnings after Non-GAAP Adjustments |  | $ | 17.7 |  | $ | 16.2 |  | 9 | % |  | $ | 77.4 |  | $ | 69.7 |  | 11 | % |
| Earnings Per Share |  | For the Fourth Quarter |  | For the Full Year |
| Before and After Non-GAAP Adjustments |  | 2016 | 2015 | Change |  | 2016 | 2015 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.9 |  | 46.7 |  | — | % |  | 46.7 |  | 47.6 |  | (2 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.37 |  | $ | 0.33 |  | 12 | % |  | $ | 1.65 |  | $ | 1.50 |  | 10 | % |
| Restructuring Per Share, net of tax |  | $ | — |  | $ | 0.01 |  |  |  | $ | (0.01 | ) | $ | 0.04 |  |  |
| Non-GAAP items, net of tax |  | $ | 0.01 |  | $ | 0.01 |  |  |  | $ | 0.02 |  | $ | 0.03 |  |  |
| Pioneer tax benefits on equity gain |  | $ | — |  | $ | — |  |  |  | $ | — |  | $ | (0.10 | ) |  |
| Fully Diluted EPS after Non-GAAP Adjustments(Adjusted EPS) |  | $ | 0.38 |  | $ | 0.35 |  | 9 | % |  | $ | 1.66 |  | $ | 1.47 |  | 13 | % |

[0000038725-17-000019:8k_2_02:16]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Consolidated |
| Q4 2015 | $ | 72.6 |  | $ | 31.3 |  | $ | 39.7 |  | $ | 19.6 |  | $ | 163.2 |  | $ | 56.1 |  | $ | 219.3 |  |
| Q4 2016 | $ | 82.2 |  | $ | 34.5 |  | $ | 40.8 |  | $ | 20.3 |  | $ | 177.8 |  | $ | 61.8 |  | $ | 239.6 |  |
| Change | $ | 9.6 |  | $ | 3.2 |  | $ | 1.1 |  | $ | 0.7 |  | $ | 14.6 |  | $ | 5.7 |  | $ | 20.3 |  |
| % Change | 13 | % | 10 | % | 3 | % | 4 | % | 9 | % | 10 | % | 9 | % |
| Foreign currency translation | $ | (0.2 | ) | $ | 1.6 |  | $ | (2.3 | ) | $ | 0.2 |  | $ | (0.7 | ) | $ | (0.7 | ) | $ | (1.4 | ) |
| % Change | — | % | 5 | % | (6 | )% | 1 | % | — | % | (1 | )% | (1 | )% |
| Volume/Price | $ | 9.8 |  | $ | 1.6 |  | $ | 3.4 |  | $ | 0.5 |  | $ | 15.3 |  | $ | 6.4 |  | $ | 21.7 |  |
| % Change | 13 | % | 5 | % | 9 | % | 3 | % | 9 | % | 11 | % | 10 | % |

[0000038725-17-000019:8k_2_02:17]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Fourth Quarter 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 22.6 |  | $ | 15.4 |  | $ | (12.8 | ) | $ | 25.2 |  |
| % Operating Income To Net Sales | 12.7 | % | 24.9 | % |  | 10.5 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.2 |  | $ | 0.1 |  | $ | — |  | $ | 0.3 |  |
| Non-GAAP | $ | 0.1 |  | $ | — |  | $ | 0.3 |  | $ | 0.4 |  |
| Operating Income/(Loss) after Non-GAAP Adjustments | $ | 22.9 |  | $ | 15.5 |  | $ | (12.5 | ) | $ | 25.9 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.9 | % | 25.1 | % |  | 10.8 | % |
|  | For the Fourth Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 20.0 |  | $ | 14.1 |  | $ | (10.5 | ) | $ | 23.6 |  |
| % Operating Income To Net Sales | 12.3 | % | 25.1 | % |  | 10.8 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.5 |  | $ | — |  | $ | — |  | $ | 0.5 |  |
| Non-GAAP | $ | 0.1 |  | $ | — |  | $ | 0.3 |  | $ | 0.4 |  |
| Operating Income/(Loss) after Non-GAAP Adjustments | $ | 20.6 |  | $ | 14.1 |  | $ | (10.2 | ) | $ | 24.5 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.6 | % | 25.1 | % |  | 11.2 | % |

[0000038725-17-000019:8k_2_02:18]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Full Year of 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 108.2 |  | $ | 56.3 |  | $ | (53.7 | ) | $ | 110.8 |  |
| % Operating Income To Net Sales | 15.0 | % | 24.8 | % |  | 11.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | (1.2 | ) | $ | 0.6 |  | $ | — |  | $ | (0.6 | ) |
| Non-GAAP | $ | 0.1 |  | $ | — |  | $ | 1.2 |  | $ | 1.3 |  |
| Operating Income/(Loss) after Non-GAAP Adjustments | $ | 107.1 |  | $ | 56.9 |  | $ | (52.5 | ) | $ | 111.5 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.8 | % | 25.1 | % |  | 11.7 | % |
|  | For the Full Year of 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 86.7 |  | $ | 51.5 |  | $ | (47.8 | ) | $ | 90.4 |  |
| % Operating Income To Net Sales | 12.3 | % | 23.7 | % |  | 9.8 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 2.7 |  | $ | 0.3 |  | $ | — |  | $ | 3.0 |  |
| Non-GAAP | $ | 0.7 |  | $ | 0.2 |  | $ | 1.2 |  | $ | 2.1 |  |
| Operating Income/(Loss) after Non-GAAP Adjustments | $ | 90.1 |  | $ | 52.0 |  | $ | (46.6 | ) | $ | 95.5 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.7 | % | 23.9 | % |  | 10.3 | % |

[0000038725-17-000019:8k_2_02:19]
Water Systems

[0000038725-17-000019:8k_2_02:20]
Water Systems sales were $177.8 million in the fourth quarter 2016, an increase of $14.6 million or about 9 percent versus the fourth quarter 2015 sales of $163.2 million.    Water Systems organic sales growth was also about 9 percent compared to the fourth quarter 2015. The impact of foreign currency translation was not significant.

[0000038725-17-000019:8k_2_02:21]
Water Systems sales in the U.S. and Canada were up about 13 percent compared to the prior year fourth quarter. In the fourth quarter 2016, sales of groundwater pumping equipment grew by about 18 percent, with significant increase in sales of products for both residential and agricultural applications.  Water Systems sales in markets outside the U.S. and Canada experienced overall growth of about 7 percent, after excluding the impact of foreign currency translation.  International Water Systems sales growth was led by improved groundwater product sales in Europe, the Middle East and Africa regions which experienced organic sales growth of 9 percent, after excluding the impact of foreign currency translation. Sales in the Asia Pacific and Latin America markets also grew in the quarter compared to last year.

[0000038725-17-000019:8k_2_02:22]
Water Systems operating income was $22.6 million in the fourth quarter 2016, up $2.6 million or 13 percent versus the fourth quarter 2015 as reported and up $2.3 million or 11 percent versus the fourth quarter 2015 after non-GAAP adjustments. The fourth quarter operating income margin was 12.7 percent, up 40 basis points from 12.3 percent in the fourth quarter of 2015. The fourth quarter operating income

[0000038725-17-000019:8k_2_02:23]
margin after non-GAAP adjustments was 12.9 percent, an increase of 30 basis points from the 12.6 percent of net sales in the fourth quarter of 2015 after non-GAAP adjustments.

[0000038725-17-000019:8k_2_02:24]
Fueling Systems

[0000038725-17-000019:8k_2_02:25]
Fueling Systems sales were $61.8 million in the fourth quarter 2016, an increase of $5.7 million or about 10 percent versus the fourth quarter 2015 sales of $56.1 million.  Fueling Systems sales decreased by $0.7 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems sales increased about 11 percent, after excluding foreign currency translation.

[0000038725-17-000019:8k_2_02:26]
Fueling Systems sales in the U.S. and Canada grew by about 13 percent during the quarter.  The increase was broad based and included pumping, pipe and containment and fuel management systems.  Internationally, Fueling Systems revenues were up overall, led by stronger sales in Asia Pacific.  This growth was partially offset by a sales decline in Europe.

[0000038725-17-000019:8k_2_02:27]
Fueling Systems operating income was $15.4 million in the fourth quarter of 2016, up $1.3 million or about 9 percent compared to $14.1 million in the fourth quarter of 2015 as reported, and up $1.4 million or 10 percent compared to $14.1 million after non-GAAP adjustments in the fourth quarter of 2015. The fourth quarter operating income margin was 24.9 percent, a decrease of 20 basis points from the as reported 25.1 percent of net sales in the fourth quarter of 2015. The fourth quarter operating income margin after non-GAAP adjustments was 25.1 percent, flat from the 25.1 percent of net sales in the fourth quarter of 2015 after non-GAAP adjustments.

[0000038725-17-000019:8k_2_02:28]
Overall

[0000038725-17-000019:8k_2_02:29]
The Company’s consolidated gross profit was $81.0 million for the fourth quarter of 2016, an increase of $11.9 million, or about 17 percent, from the fourth quarter of 2015 gross profit of $69.1 million. The gross profit as a percent of net sales was 33.8 percent in the fourth quarter of 2016 and increased about 230 basis points versus 31.5 percent during the fourth quarter 2015.  The gross profit margin increase was primarily due to favorable pricing, lower direct material costs and fixed cost leverage from higher sales.

[0000038725-17-000019:8k_2_02:30]
Selling, general, and administrative (SG&A) expenses were $55.5 million in the fourth quarter of 2016 compared to $45.1 million in the fourth quarter of the prior year, an increase of $10.4 million or about 23 percent.  Roughly half of the Company’s SG&A expense increase in the quarter, or about $5.0 million, was due to higher variable compensation expenses. Marketing and Selling related expenses increased about $4.5 million to support sales growth and Research Development & Engineering expense increased by $1.1 million in the quarter.

[0000038725-17-000019:8k_2_02:31]
The Company ended the fourth quarter of 2016 with a cash balance of about $104 million, which was about 28 percent higher than at the end of 2015.  The cash balance increased primarily due to higher earnings.

[0000038725-17-000019:8k_2_02:32]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-17-000019:8k_2_02:33]
“Despite a meaningful amount of global uncertainty due to the current political and economic climate, we believe we are entering 2017 with momentum in the key end markets we serve and our outlook for 2017 is positive.  We currently see the Company’s total Net Sales increasing in the 3 to 5 percent range overall

[0000038725-17-000019:8k_2_02:34]
despite our current assumption of about a 2 percent currency translation headwind due to the strengthening U.S. dollar versus many key international currencies most notably the Euro and Turkish Lira.  We expect our organic growth after considering foreign exchange impacts to be in the range of 5 to 7 percent.

[0000038725-17-000019:8k_2_02:35]
"We expect our 2017 Adjusted Earnings Per Share to be between $1.77 and $1.87 after considering foreign currency translation will impact our adjusted earnings per share by about 4 cents compared to 2016.”

[0000038725-17-000019:8k_2_02:36]
A conference call to review earnings and other developments in the business will commence at 9:00 am EST.  The fourth quarter 2016 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-17-000019:8k_2_02:37]
http://edge.media-server.com/m/p/vo3qqk5d

[0000038725-17-000019:8k_2_02:38]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 66653279.

[0000038725-17-000019:8k_2_02:39]
A replay of the conference call will be available Tuesday, February 21, 2017 at 12:00 noon EST through midnight EST on Tuesday, February 28, 2017, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 66653279.

[0000038725-17-000019:8k_2_02:40]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-17-000019:8k_2_02:41]
The Company presents the non-GAAP financial measures of earnings after non-GAAP adjustments, fully diluted earnings per share after non-GAAP adjustments (or adjusted EPS), operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments (or operating income margin after non-GAAP adjustments) because the Company believes the information helps investors understand underlying trends in the Company's business more easily. The differences between these measures and the most comparable GAAP measures are reconciled in the tables above.

[0000038725-17-000019:8k_2_02:42]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Fourth Quarter Ended |  | Fiscal Year End |
|  | December 31, 2016 |  | January 2, 2016 |  | December 31, 2016 |  | January 2, 2016 |
| Net sales | $ | 239,590 |  |  | $ | 219,283 |  |  | $ | 949,856 |  |  | $ | 924,923 |  |
| Cost of sales | 158,567 |  |  | 150,165 |  |  | 618,450 |  |  | 627,315 |  |
| Gross profit | 81,023 |  |  | 69,118 |  |  | 331,406 |  |  | 297,608 |  |
| Selling, general, and administrative expenses | 55,537 |  |  | 45,090 |  |  | 221,209 |  |  | 204,250 |  |
| Restructuring (income)/expense | 252 |  |  | 472 |  |  | (598 | ) |  | 2,997 |  |
| Operating income | 25,234 |  |  | 23,556 |  |  | 110,795 |  |  | 90,361 |  |
| Interest expense | (2,101 | ) |  | (2,322 | ) |  | (8,732 | ) |  | (10,039 | ) |
| Other income/(expense), net | (1,794 | ) |  | 838 |  |  | 993 |  |  | 6,863 |  |
| Foreign exchange income/(expense) | 420 |  |  | (830 | ) |  | 1,057 |  |  | (869 | ) |
| Income before income taxes | 21,759 |  |  | 21,242 |  |  | 104,113 |  |  | 86,316 |  |
| Income tax expense | 3,958 |  |  | 4,991 |  |  | 24,798 |  |  | 12,625 |  |
| Net income | $ | 17,801 |  |  | $ | 16,251 |  |  | $ | 79,315 |  |  | $ | 73,691 |  |
| Less: Net income attributable to noncontrolling interests | (159 | ) |  | (90 | ) |  | (570 | ) |  | (746 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 17,642 |  |  | $ | 16,161 |  |  | $ | 78,745 |  |  | $ | 72,945 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.37 |  |  | $ | 0.34 |  |  | $ | 1.67 |  |  | $ | 1.52 |  |
| Diluted | $ | 0.37 |  |  | $ | 0.33 |  |  | $ | 1.65 |  |  | $ | 1.50 |  |

[0000038725-17-000019:8k_2_02:43]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | December 31, 2016 |  | January 2, 2016 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 104,331 |  |  | $ | 81,561 |  |
| Receivables | 145,999 |  |  | 127,251 |  |
| Inventories | 203,471 |  |  | 194,594 |  |
| Other current assets | 30,018 |  |  | 34,715 |  |
| Total current assets | 483,819 |  |  | 438,121 |  |
| Property, plant, and equipment, net | 196,137 |  |  | 190,039 |  |
| Goodwill and other assets | 359,949 |  |  | 367,951 |  |
| Total assets | $ | 1,039,905 |  |  | $ | 996,111 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 63,927 |  |  | $ | 57,822 |  |
| Accrued expenses and other current liabilities | 60,119 |  |  | 53,903 |  |
| Current maturities of long-term debt and short-term borrowings | 33,715 |  |  | 32,946 |  |
| Total current liabilities | 157,761 |  |  | 144,671 |  |
| Long-term debt | 156,544 |  |  | 187,806 |  |
| Deferred income taxes | 40,460 |  |  | 33,404 |  |
| Employee benefit plans | 45,307 |  |  | 47,398 |  |
| Other long-term liabilities | 17,093 |  |  | 16,511 |  |
| Redeemable noncontrolling interest | 7,652 |  |  | 6,856 |  |
| Total equity | 615,088 |  |  | 559,465 |  |
| Total liabilities and equity | $ | 1,039,905 |  |  | $ | 996,111 |  |

[0000038725-17-000019:8k_2_02:44]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
| (In thousands) | 2016 |  | 2015 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 79,315 |  |  | $ | 73,691 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 35,534 |  |  | 35,476 |  |
| Share-based compensation | 6,889 |  |  | 5,626 |  |
| Realized gain on share purchase liability | — |  |  | (2,723 | ) |
| Other | 2,672 |  |  | (5,323 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (21,334 | ) |  | 3,444 |  |
| Inventory | (7,636 | ) |  | 9,350 |  |
| Accounts payable and accrued expenses | 11,782 |  |  | (19,744 | ) |
| Other | 8,152 |  |  | (194 | ) |
| Net cash flows from operating activities | 115,374 |  |  | 99,603 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (39,136 | ) |  | (26,171 | ) |
| Proceeds from sale of property, plant, and equipment | 6,028 |  |  | 202 |  |
| Acquisitions and investments | (1,007 | ) |  | (3,888 | ) |
| Other investing activities | 346 |  |  | 274 |  |
| Net cash flows from investing activities | (33,769 | ) |  | (29,583 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (30,385 | ) |  | 43,576 |  |
| Proceeds from issuance of common stock | 5,243 |  |  | 2,050 |  |
| Excess tax from share-based payment arrangements | — |  |  | 932 |  |
| Purchases of common stock | (7,422 | ) |  | (48,579 | ) |
| Dividends paid | (19,137 | ) |  | (18,926 | ) |
| Share purchase liability payment | — |  |  | (20,200 | ) |
| Net cash flows from financing activities | (51,701 | ) |  | (41,147 | ) |
| Effect of exchange rate changes on cash | (7,134 | ) |  | (6,453 | ) |
| Net change in cash and equivalents | 22,770 |  |  | 22,420 |  |
| Cash and equivalents at beginning of period | 81,561 |  |  | 59,141 |  |
| Cash and equivalents at end of period | $ | 104,331 |  |  | $ | 81,561 |  |
