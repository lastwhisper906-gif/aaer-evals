# FELE notes — 0000038725-14-000108


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-14-000108:notes:1]
[same as prior period, unchanged from 0000038725-13-000228:notes:1]

[0000038725-14-000108:notes:2]
Transaction costs were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations.  Transaction costs included in selling, general, and administrative expenses in the Company’s condensed consolidated statement of income for the first quarter ended March 29, 2014, was $0.1 million.  No transaction costs were included in selling, general, and administrative expenses for the first quarter ended March 30, 2013.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000038725-14-000108:notes:3]
CONTINGENCIES AND COMMITMENTS

[0000038725-14-000108:notes:4]
In August 2010, the California Air Resources Board (“CARB”) and South Coast Air Quality Management District (“SCAQMD”) filed civil complaints in the Los Angeles Superior Court against the Company and Franklin Fueling Systems, Inc.  The complaints related to a third-party-supplied component part of the Company's Healy 900 Series nozzle, which is part of the Company's Enhanced Vapor Recovery (“EVR”) Systems installed in California gasoline filling stations.  This part, a diaphragm, was the subject of a retrofit during the first half of 2008.  As the Company previously reported, in October 2008 CARB issued a Notice of Violation to the Company alleging that the circumstances leading to the retrofit program violated California statutes and regulations.

[0000038725-14-000108:notes:5]
The claims in the complaints mirrored those that CARB presented to the Company in the Notice of Violation, and included claims that the Company negligently and intentionally sold nozzles with a modified diaphragm without required CARB certification. Those complaints were consolidated into one case in the Superior Court of California, County of Los Angeles (People of the State of California vs. Franklin Fueling Systems, Inc. et al.)  which was tried in the later part of December 2012 and early part of January 2013 (“CARB Case”).

[0000038725-14-000108:notes:6]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014.  CARB has filed a notice of appeal.

[0000038725-14-000108:notes:7]
Neither of these suits has had any effect on CARB's certification of the Company's EVR System or any other products of the Company or its subsidiaries, and did not interfere with continuing sales.  CARB has never decertified the Company's EVR System and has never proposed to do so.

[0000038725-14-000108:notes:8]
The Company is defending various other claims and legal actions, including environmental matters, which have arisen in the

[0000038725-14-000108:notes:9]
ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with

[0000038725-14-000108:notes:10]
counsel, these claims and legal actions can be successfully defended or resolved without a material adverse effect on the

[0000038725-14-000108:notes:11]
Company’s financial position, results of operations, and net cash flows.

[0000038725-14-000108:notes:12]
At March 29, 2014, the Company had $18.5 million of commitments primarily for the purchase of machinery and equipment as well as conditional agreements related to building expansions.

[0000038725-14-000108:notes:13]
The company provides warranties on most of its products.  The warranty terms vary but are generally two years from date of manufacture or one year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to five years from date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-14-000108:notes:14]
The changes in the carrying amount of the warranty accrual, as recorded in "Accrued expenses" in the Company's consolidated balance sheet for the three months ended March 29, 2014, are as follows:

[0000038725-14-000108:notes:15]
| (In millions) |  |  |
| Balance as of December 28, 2013 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 1.4 |  |
| Reductions for payments made |  | (2.0 | ) |
| Balance as of March 29, 2014 |  | $ | 8.9 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-14-000108:notes:16]
[same as prior period, unchanged from 0000038725-13-000228:notes:20]

[0000038725-14-000108:notes:17]
Changes in accumulated other comprehensive income (loss) by component for the three months ended March 29, 2014 and March 30, 2013, are summarized below:

[0000038725-14-000108:notes:18]
| (In millions) |  |  |  |  |  |
| For the three months ended March 29, 2014: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance as of December 28, 2013 | $ | (16.0 | ) |  | $ | (38.7 | ) |  | $ | (54.7 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | 2.1 |  |  | — |  |  | 2.1 |  |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | 2.1 |  |  | — |  |  | 2.1 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 0.7 |  | (1) | 0.7 |  |
| Income tax expense | — |  |  | (0.3 | ) |  | (0.3 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 0.4 |  |  | 0.4 |  |
| Net current period other comprehensive income/(loss), net of income taxes | 2.1 |  |  | 0.4 |  |  | 2.5 |  |
| Other comprehensive (income)/loss attributable to noncontrolling interest | 0.3 |  |  | — |  |  | 0.3 |  |
| Balance as of March 29, 2014 | $ | (13.6 | ) |  | $ | (38.3 | ) |  | $ | (51.9 | ) |
| For the three months ended March 30, 2013: |  |  |  |  |  |
| Balance as of December 29, 2012 | $ | (0.2 | ) |  | $ | (56.9 | ) |  | $ | (57.1 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (5.8 | ) |  | — |  |  | (5.8 | ) |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (5.8 | ) |  | — |  |  | (5.8 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 1.0 |  | (1) | 1.0 |  |
| Income tax expense | — |  |  | (0.4 | ) |  | (0.4 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 0.6 |  |  | 0.6 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (5.8 | ) |  | 0.6 |  |  | (5.2 | ) |
| Other comprehensive (income)/loss attributable to noncontrolling interest | 0.4 |  |  | — |  |  | 0.4 |  |
| Balance as of March 30, 2013 | $ | (5.6 | ) |  | $ | (56.3 | ) |  | $ | (61.9 | ) |

[0000038725-14-000108:notes:19]
(1) This accumulated other comprehensive income (loss) component is included in the computation of net periodic pension cost (refer to Note 9 for additional details) and is included in the "Selling, general, and administrative expenses" line of the consolidated statements of income.


## us-gaap:DebtDisclosureTextBlock

[0000038725-14-000108:notes:20]
DEBT

[0000038725-14-000108:notes:21]
Debt consisted of the following:

[0000038725-14-000108:notes:22]
| (In millions) |  | March 29, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.1 |  |  | 24.6 |  |
| Revolver |  | 15.0 |  |  | — |  |
| Capital leases |  | 0.7 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 14.5 |  |  | 14.2 |  |
|  |  | 204.3 |  |  | 189.6 |  |
| Less current maturities |  | (30.6 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 173.7 |  |  | $ | 174.2 |  |

[0000038725-14-000108:notes:23]
Foreign subsidiary debt denoted in the table above is predominately comprised of debt at Impo.

[0000038725-14-000108:notes:24]
The total estimated fair value of debt was $218.3 million and $203.7 million at March 29, 2014 and December 28, 2013, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its long term debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as a Level 2 within the valuations hierarchy.

[0000038725-14-000108:notes:25]
The following debt payments are expected to be paid in accordance with the following schedule:

[0000038725-14-000108:notes:26]
| (In millions) |  | Total |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | More than 5 years |
| Debt |  | $ | 203.6 |  |  | $ | 30.4 |  |  | $ | 30.9 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 49.3 |  |
| Capital leases |  | 0.7 |  |  | 0.2 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 204.3 |  |  | $ | 30.6 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 49.3 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-14-000108:notes:27]
FINANCIAL INSTRUMENTS

[0000038725-14-000108:notes:28]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  During February 2014, the Company entered into a share swap transaction agreement (the "swap") to mitigate the Company’s exposure to these fluctuations in the Company's stock price.  The swap was not designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  The swap has a notional value of 134,000 shares.  As of March 29, 2014, the swap transaction resulted in a loss of $0.2 million.  All gains or losses and expenses related to the total return swap are recorded in the Company's consolidated statement of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-14-000108:notes:29]
[same as prior period, unchanged from 0000038725-13-000228:notes:34]

[0000038725-14-000108:notes:30]
The Company maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the "2012 Stock Plan"), which is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, stock unit awards, and performance awards to key employees and non-employee directors.  Shares and per share data below have been adjusted for all periods presented to reflect the two-for-one stock split effective March 18, 2013.

[0000038725-14-000108:notes:31]
The 2012 Stock Plan authorized 2,400,000 shares for issuance as follows:

[0000038725-14-000108:notes:32]
[same as prior period, unchanged from 0000038725-13-000228:notes:37]

[0000038725-14-000108:notes:33]
The Company also maintains the Amended and Restated Franklin Electric Co., Inc. Stock Plan (the "2009 Stock Plan") which, as amended in 2009, provided for discretionary grants of stock options and stock awards.  The 2009 Stock Plan authorized 4,400,000 shares for issuance as follows:

[0000038725-14-000108:notes:34]
| 2009 Stock Plan | Authorized Shares |
| Stock Options | 3,200,000 |
| Stock Awards | 1,200,000 |

[0000038725-14-000108:notes:35]
[same as prior period, unchanged from 0000038725-13-000228:notes:40]

[0000038725-14-000108:notes:36]
[same as prior period, unchanged from 0000038725-13-000228:notes:41]

[0000038725-14-000108:notes:37]
[same as prior period, unchanged from 0000038725-13-000228:notes:42]

[0000038725-14-000108:notes:38]
[same as prior period, unchanged from 0000038725-13-000228:notes:43]

[0000038725-14-000108:notes:39]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the first quarter ended March 29, 2014, are as follows:

[0000038725-14-000108:notes:40]
|  |  | March 29, 2014 |  |  | March 30, 2013 |  |
| Risk-free interest rate |  | 1.68 | % |  | 1.03 | % |
| Dividend yield |  | 0.70 | % |  | 0.89 | % |
| Volatility factor |  | 0.387 |  |  | 0.394 |  |
| Expected term |  | 5.6 years |  |  | 6.0 years |  |
| Forfeiture rate |  | 3.81 | % |  | 4.52 | % |

[0000038725-14-000108:notes:41]
There were 92,946 and 176,168 stock options granted during the first quarters ended March 29, 2014 and March 30, 2013, respectively.

[0000038725-14-000108:notes:42]
A summary of the Company’s outstanding stock option activity and related information for the first quarters ended March 29, 2014 and March 30, 2013 is as follows:

[0000038725-14-000108:notes:43]
| (Shares in thousands) |  | March 29, 2014 |  | March 30, 2013 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,476 |  |  | $ | 19.01 |  |  | 2,184 |  |  | 16.69 |  |
| Granted |  | 93 |  |  | 43.27 |  |  | 176 |  |  | 32.53 |  |
| Exercised |  | (34 | ) |  | 18.57 |  |  | (307 | ) |  | 13.43 |  |
| Forfeited |  | (2 | ) |  | 26.95 |  |  | — |  |  | — |  |
| Outstanding at end of period |  | 1,533 |  |  | $ | 20.48 |  |  | 2,053 |  |  | 18.54 |  |
| Expected to vest after applying forfeiture rate |  | 1,511 |  |  | $ | 20.31 |  |  | 2,022 |  |  | $ | 18.39 |  |
| Vested and exercisable at end of period |  | 1,070 |  |  | $ | 16.34 |  |  | 1,457 |  |  | $ | 15.82 |  |

[0000038725-14-000108:notes:44]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value for the first quarter ended March 29, 2014 is as follows:

[0000038725-14-000108:notes:45]
| (In millions) |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.81 years |  | $ | 32,598 |  |
| Expected to vest after applying forfeiture rate |  | 5.76 years |  | 32,426 |  |
| Vested and exercisable at end of period |  | 4.61 years |  | 27,068 |  |

[0000038725-14-000108:notes:46]
The total intrinsic value of options exercised during the first quarters ended March 29, 2014 and March 30, 2013, was $0.8 million and $4.8 million, respectively.

[0000038725-14-000108:notes:47]
As of March 29, 2014, there was $2.2 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements related to stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.81 years.

[0000038725-14-000108:notes:48]
[same as prior period, unchanged from 0000038725-13-000228:notes:53]

[0000038725-14-000108:notes:49]
A summary of the Company’s restricted stock/stock unit award activity and related information for the first quarters ended March 29, 2014 and March 30, 2013 is as follows:

[0000038725-14-000108:notes:50]
| (Shares in thousands) |  | March 29, 2014 |  | March 30, 2013 |
| Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 551 |  |  | $ | 24.75 |  |  | $ | 458 |  |  | $ | 20.90 |  |
| Awarded |  | 172 |  |  | 43.37 |  |  | 141 |  |  | 32.53 |  |
| Vested |  | (110 | ) |  | 15.75 |  |  | (35 | ) |  | 17.21 |  |
| Forfeited |  | (56 | ) |  | 27.81 |  |  | (1 | ) |  | 18.89 |  |
| Non-vested at end of period |  | 557 |  |  | $ | 31.96 |  |  | $ | 563 |  |  | $ | 24.04 |  |

[0000038725-14-000108:notes:51]
As of March 29, 2014, there was $12.8 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements related to stock awards granted under the 2012 Stock Plan and the 2009 Stock Plan..  That cost is expected to be recognized over a weighted-average period of 2.91 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-14-000108:notes:52]
[same as prior period, unchanged from 0000038725-13-000228:notes:57]

[0000038725-14-000108:notes:53]
[same as prior period, unchanged from 0000038725-13-000228:notes:58]

[0000038725-14-000108:notes:54]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period.  Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares as of the balance sheet date, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-14-000108:notes:55]
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-14-000108:notes:56]
| (In millions, except per share amounts) | March 29, 2014 |  | March 30, 2013 |
| Numerator: |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 17.0 |  |  | $ | 15.5 |  |
| Less: Undistributed earnings allocable to participating securities | 0.3 |  |  | 0.2 |  |
|  | $ | 16.7 |  |  | $ | 15.3 |  |
| Denominator: |  |  |  |  |  |
| Basic |  |  |  |  |  |
| Weighted average common shares | 47.7 |  |  | 47.3 |  |
| Diluted |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Non-participating employee and director incentive stock options and performance awards | 0.6 |  |  | 0.7 |  |
| Adjusted weighted average common shares | 48.3 |  |  | 48.0 |  |
| Basic earnings per share | $ | 0.35 |  |  | $ | 0.32 |  |
| Diluted earnings per share | $ | 0.35 |  |  | $ | 0.32 |  |
| Anti-dilutive stock options | — |  |  | — |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-14-000108:notes:57]
As of March 29, 2014 and December 28, 2013, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below.

[0000038725-14-000108:notes:58]
| (In millions) | March 29, 2014 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) | Recognized Loss |
| Cash equivalents | $ | 8.2 |  | $ | 8.2 |  | $ | — |  | $ | — |  | $ | — |  |
|  | December 28, 2013 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) | Recognized Loss |
| Cash equivalents | $ | 6.6 |  | $ | 6.6 |  | $ | — |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-14-000108:notes:59]
[same as prior period, unchanged from 0000038725-13-000228:notes:64]

[0000038725-14-000108:notes:60]
[same as prior period, unchanged from 0000038725-13-000228:notes:65]

[0000038725-14-000108:notes:61]
[same as prior period, unchanged from 0000038725-13-000228:notes:66]

[0000038725-14-000108:notes:62]
[same as prior period, unchanged from 0000038725-13-000228:notes:67]

[0000038725-14-000108:notes:63]
[same as prior period, unchanged from 0000038725-13-000228:notes:68]

[0000038725-14-000108:notes:64]
[same as prior period, unchanged from 0000038725-13-000228:notes:69]

[0000038725-14-000108:notes:65]
The Company has no assets or liabilities classified as Level 2 or Level 3.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-14-000108:notes:66]
GOODWILL AND OTHER INTANGIBLE ASSETS

[0000038725-14-000108:notes:67]
[same as prior period, unchanged from 0000038725-13-000228:notes:73]

[0000038725-14-000108:notes:68]
| (In millions) |  | March 29, 2014 |  | December 28, 2013 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.8 |  |  | $ | (6.0 | ) |  | $ | 7.8 |  |  | $ | (5.9 | ) |
| Supply agreements |  | 4.4 |  |  | (4.4 | ) |  | 4.4 |  |  | (4.4 | ) |
| Technology |  | 7.5 |  |  | (3.9 | ) |  | 7.5 |  |  | (3.8 | ) |
| Customer relationships |  | 125.3 |  |  | (31.6 | ) |  | 125.1 |  |  | (29.7 | ) |
| Software |  | 2.1 |  |  | (0.4 | ) |  | 2.1 |  |  | (0.4 | ) |
| Other |  | 1.3 |  |  | (1.3 | ) |  | 1.3 |  |  | (1.2 | ) |
| Total |  | $ | 148.4 |  |  | $ | (47.6 | ) |  | $ | 148.2 |  |  | $ | (45.4 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 46.1 |  |  | — |  |  | 45.9 |  |  | — |  |
| Total intangibles |  | $ | 194.5 |  |  | $ | (47.6 | ) |  | $ | 194.1 |  |  | $ | (45.4 | ) |

[0000038725-14-000108:notes:69]
Amortization expense related to intangible assets for first quarters ended March 29, 2014 and March 30, 2013 was $2.0 million and $2.0 million, respectively.

[0000038725-14-000108:notes:70]
[same as prior period, unchanged from 0000038725-13-000228:notes:76]

[0000038725-14-000108:notes:71]
| (In millions) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |
|  |  | $ | 8.1 |  |  | $ | 8.1 |  |  | $ | 8.1 |  |  | $ | 7.8 |  |  | $ | 7.7 |  |

[0000038725-14-000108:notes:72]
The change in the carrying amount of goodwill by reporting segment for the first quarter ended March 29, 2014, is as follows:

[0000038725-14-000108:notes:73]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of December 28, 2013 |  | $ | 144.1 |  |  | $ | 63.1 |  |  | $ | 207.2 |  |
| Foreign currency translation |  | 0.4 |  |  | 0.1 |  |  | 0.5 |  |
| Balance as of March 29, 2014 |  | $ | 144.5 |  |  | $ | 63.2 |  |  | $ | 207.7 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-14-000108:notes:74]
[same as prior period, unchanged from 0000038725-13-000228:notes:80]

[0000038725-14-000108:notes:75]
The effective tax rate continues to be lower than the U.S. statutory rate of 35.0 percent primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate as well as recognition of U.S. tax credits.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations as well as cash on hand and available credit.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000038725-14-000108:notes:76]
[same as prior period, unchanged from 0000038725-13-000228:notes:82]

[0000038725-14-000108:notes:77]
[same as prior period, unchanged from 0000038725-13-000228:notes:83]

[0000038725-14-000108:notes:78]
The noncontrolling interest in Impo is redeemable at other than fair value as the redemption value is determined based on a specified formula.  The noncontrolling interest becomes redeemable after the passage of time, and therefore the Company records the carrying amount of the noncontrolling interest at the greater of (1) the initial carrying amount, increased or decreased for each noncontrolling interest's share of net income or loss and its share of other comprehensive income or loss and dividends (“carrying amount”) or (2) the redemption value which is determined based on the greater of the redemption floor value or the then-current specified earnings multiple.  As of March 29, 2014, the Impo redeemable noncontrolling interest was recorded at the carrying amount.

[0000038725-14-000108:notes:79]
According to FASB ASC Topic 810, Consolidation and Emerging Issues Task Force ("EITF") Topic No. D-98, Classification and Measurement of Redeemable Securities, redeemable noncontrolling interests issued in the form of common securities, to the extent that the noncontrolling interest holder has a contractual right to receive an amount upon share redemption that is other than the fair value of such shares, then the noncontrolling interest holder has, in substance, received a dividend distribution that is different from other common shareholders.  Therefore, adjustments to the noncontrolling interest to reflect the redemption amount should be reflected in the computation of earnings per share using the two-class method.  Under the two-class method, the Company has elected to treat as a dividend only the portion of the periodic redemption value adjustment (if any) that reflects a redemption value in excess of carrying value.  No adjustments were necessary for the first quarters ended March 29, 2014 or March 30, 2013.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-14-000108:notes:80]
ACCOUNTING PRONOUNCEMENTS

[0000038725-14-000108:notes:81]
In April 2014, FASB issued ASU 2014-08 Presentation of Financial Statements and Property, Plant and Equipment: Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity.  ASU No. 2014-08 raises the threshold for a disposal to qualify as a discontinued operation and requires new disclosures of both discontinued operations and certain other disposals that do not meet the definition of a discontinued operation. ASU No. 2014-08 is effective for annual periods beginning after December 15, 2014, and interim periods within annual periods beginning on or after December 15, 2015, with early adoption permitted.  The Company has adopted this standard with no impact on the Company’s consolidated financial position, results of operations, or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-14-000108:notes:82]
1. CONDENSED CONSOLIDATED FINANCIAL STATEMENTS

[0000038725-14-000108:notes:83]
The accompanying condensed consolidated balance sheet as of December 28, 2013, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 29, 2014, and for the first quarters ended March 29, 2014 and March 30, 2013, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended March 29, 2014, are not necessarily indicative of the results that may be expected for the fiscal year ending January 3, 2015.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K/A for the year ended December 28, 2013.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000038725-14-000108:notes:84]
[same as prior period, unchanged from 0000038725-13-000228:notes:90]

[0000038725-14-000108:notes:85]
The Company has equity interests in various companies for various strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s consolidated balance sheet.  The carrying amount of the investment is adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income/(expense)" line of the Company's consolidated statements of income, were immaterial for the quarter ended March 29, 2014.

[0000038725-14-000108:notes:86]
The Company has a loan agreement with the parent company of a customer.  The current maturity is included in "Receivables" and the long-term portion is included in "Other assets" on the Company's consolidated balance sheet.  The agreement provides for interest on the loan at a variable market interest rate with the customer to repay the loan plus interest in semi-annual installments.  The Company has a long-term relationship with the customer and considers the loan fully collectible.   The loan is not considered material to the Company’s financial position.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-14-000108:notes:87]
[same as prior period, unchanged from 0000038725-13-000228:notes:93]

[0000038725-14-000108:notes:88]
Defined Benefit Plans - As of March 29, 2014, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31 measurement date for these plans.

[0000038725-14-000108:notes:89]
[same as prior period, unchanged from 0000038725-13-000228:notes:95]

[0000038725-14-000108:notes:90]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the first quarters ended March 29, 2014 and March 30, 2013, respectively:

[0000038725-14-000108:notes:91]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | First Quarter Ended |  | First Quarter Ended |
|  | March 29, 2014 |  |  | March 30, 2013 |  |  | March 29, 2014 |  |  | March 30, 2013 |  |
| Service cost | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 2.0 |  |  | 1.9 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | (2.6 | ) |  | (2.5 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Amortization of loss | 0.6 |  |  | 0.9 |  |  | — |  |  | 0.1 |  |
| Net periodic benefit cost | $ | 0.3 |  |  | $ | 0.7 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |
| Settlement cost | 0.2 |  |  | — |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 0.5 |  |  | $ | 0.7 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |

[0000038725-14-000108:notes:92]
In the first quarter ended March 29, 2014, the Company made contributions to the funded plans of $2.8 million.  The amount of contributions to be made to the plans during the calendar year 2014 will be finalized by September 15, 2014, based upon the plan's year-end valuation at December 28, 2013, and the funding level required for the plan year ended December 28, 2013.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-14-000108:notes:93]
[same as prior period, unchanged from 0000038725-13-000228:notes:99]

[0000038725-14-000108:notes:94]
Costs incurred in the first quarter ended March 29, 2014, included in the “Restructuring (income)/expense” line of the Company's consolidated statement of income, are as follows:

[0000038725-14-000108:notes:95]
|  |  | March 29, 2014 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |

[0000038725-14-000108:notes:96]
Restructuring expenses, relating primarily to severance for the first quarter ended March 30, 2013, were approximately $0.7 million.

[0000038725-14-000108:notes:97]
As of March 29, 2014 and March 30, 2013, there were $0.0 million and $0.6 million in restructuring reserves, respectively.  The restructuring reserves were primarily for severance.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-14-000108:notes:98]
Financial information by reportable segment is as follows:

[0000038725-14-000108:notes:99]
|  | First Quarter Ended |  | First Quarter Ended |
|  | Net sales to external customers |  | Operating income (loss) |
| (In millions) | March 29, 2014 |  | March 30, 2013 |  | March 29, 2014 |  | March 30, 2013 |
| Water Systems | $ | 184.6 |  |  | $ | 176.4 |  |  | $ | 29.2 |  |  | $ | 28.7 |  |
| Fueling Systems | 46.8 |  |  | 46.1 |  |  | 9.1 |  |  | 6.2 |  |
| Other | — |  |  | — |  |  | (12.3 | ) |  | (11.7 | ) |
| Consolidated | $ | 231.4 |  |  | $ | 222.5 |  |  | $ | 26.0 |  |  | $ | 23.2 |  |
|  | Total assets |  |  |
|  | March 29, 2014 |  | December 28, 2013 |  |  |  |  |
| Water Systems | $ | 772.3 |  |  | $ | 714.7 |  |  |  |  |  |
| Fueling Systems | 252.8 |  |  | 247.9 |  |  |  |  |  |
| Other | 64.6 |  |  | 89.3 |  |  |  |  |  |
| Consolidated | $ | 1,089.7 |  |  | $ | 1,051.9 |  |  |  |  |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-14-000108:notes:100]
The schedule below sets forth equity changes in the three months ended March 29, 2014:

[0000038725-14-000108:notes:101]
| (In thousands) | Common Stock | Additional Paid in Capital | Retained Earnings | Minimum Pension Liability | Cumulative Translation Adjustment | Noncontrolling Interest | Total Equity | Redeemable Noncontrolling Interest |
| Balance as of December 28, 2013 | $ | 4,771 |  | $ | 194,810 |  | $ | 450,855 |  | $ | (38,707 | ) | $ | (16,022 | ) | $ | 2,509 |  | $ | 598,216 |  | $ | 5,171 |  |
| Net income |  |  | 16,957 |  |  |  | 199 |  | 17,156 |  | 265 |  |
| Dividends on common stock |  |  | (3,709 | ) |  |  |  | (3,709 | ) |  |
| Common stock issued | 3 |  | 632 |  |  |  |  |  | 635 |  |  |
| Common stock repurchased or received for stock options exercised | (4 | ) |  | (1,577 | ) |  |  |  | (1,581 | ) |  |
| Share-based compensation | (1 | ) | 1,393 |  |  |  |  |  | 1,392 |  |  |
| Tax benefit of stock options exercised |  | 1,254 |  |  |  |  |  | 1,254 |  |  |
| Currency translation adjustment |  |  |  |  | 2,316 |  | 10 |  | 2,326 |  | (148 | ) |
| Pension liability, net of tax |  |  |  | 488 |  |  |  | 488 |  |  |
| Other |  |  |  | (150 | ) | 150 |  |  |  |  |
| Balance as of March 29, 2014 | $ | 4,769 |  | $ | 198,089 |  | $ | 462,526 |  | $ | (38,369 | ) | $ | (13,556 | ) | $ | 2,718 |  | $ | 616,177 |  | $ | 5,288 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-14-000108:notes:102]
[same as prior period, unchanged from 0000038725-13-000228:notes:109]

[0000038725-14-000108:notes:103]
The Company’s business consists of the Water Systems and Fueling Systems reportable segments, based on the principal end market served.  The Company includes unallocated corporate expenses and inter-company eliminations in an “Other” segment that, together with the Water Systems and Fueling Systems segments, represent the Company.

[0000038725-14-000108:notes:104]
The Water Systems segment designs, manufactures and sells motors, pumps, electronic controls, and related parts and equipment primarily for use in submersible water and other fluid system applications.  The Fueling Systems segment designs, manufactures, and sells pumps, electronic controls and related parts and equipment primarily for use in submersible fueling system applications.  The Fueling Systems segment integrates and sells motors and electronic controls produced by the Water Systems segment.

[0000038725-14-000108:notes:105]
The accounting policies of the Company's reportable segments are the same as those described in Note 1 (Summary of Significant Accounting Policies).  Performance is evaluated based on the sales and operating income of the segments and a variety of ratios to measure performance.  These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented.

[0000038725-14-000108:notes:106]
Cash is the major asset group in “Other” of total assets.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-14-000108:notes:107]
[same as prior period, unchanged from 0000038725-13-000228:notes:111]
