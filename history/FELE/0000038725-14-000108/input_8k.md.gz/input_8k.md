# FELE 8-K — 0000038725-14-000080 filed 2014-04-29

## item codes, every 8-K on or before 2014-05-08

- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2014-05-08

- none on or before 2014-05-08

## item 2.02 — earnings release, exhibit 99.1

[0000038725-14-000080:8k_2_02:1]
EX-99.1
2
a2014exhibit991.htm
EXHIBIT

[0000038725-14-000080:8k_2_02:2]
2014 Exhibit 99.1

[0000038725-14-000080:8k_2_02:3]
Exhibit 99.1

[0000038725-14-000080:8k_2_02:4]
For Immediate Release

[0000038725-14-000080:8k_2_02:5]
For Further Information

[0000038725-14-000080:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-14-000080:8k_2_02:7]
260-824-2900

[0000038725-14-000080:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS RECORD FIRST QUARTER 2014 SALES AND EARNINGS

[0000038725-14-000080:8k_2_02:9]
Fort Wayne, Indiana - April 29, 2014 - Franklin Electric Co., Inc. (NASDAQ:FELE) reported first quarter 2014 adjusted earnings per share (EPS) of $0.35 compared to 2013 first quarter adjusted EPS of $0.33, a 6 percent increase (see table below for a reconciliation of GAAP EPS to the adjusted EPS).  In the first quarter of 2014, the Company’s GAAP fully diluted EPS was $0.35 which was up 9 percent to the GAAP fully diluted EPS from the first quarter of 2013.

[0000038725-14-000080:8k_2_02:10]
First quarter 2014 sales were $231.4 million, an increase of 4 percent compared to 2013 first quarter sales of $222.5 million.  The Company’s organic sales growth was 7 percent excluding acquisitions and the impact of foreign currency translation.

[0000038725-14-000080:8k_2_02:11]
Scott Trumbull, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-14-000080:8k_2_02:12]
“We are pleased to report that our sales and adjusted net income for the first quarter of 2014 were again records for any first quarter in the Company’s history.  During the first quarter 2014, our consolidated operating income after non-GAAP adjustments grew by 8 percent compared to the first quarter prior year driven by a 19 percent organic increase in Water Systems sales in developing regions and a 35 percent increase in Fueling Systems operating income resulting from a combination of productivity, favorable pricing, mix, and synergies from the Flex-ing acquisition.    These positive factors were partially offset during the quarter by lower earnings for our Water Systems business in the U.S. and Canada driven by an unfavorable mix shift and reduced sales growth due to severe weather during January and February.  Consolidated adjusted operating income margin improved in the first quarter by 40 basis points.”

[0000038725-14-000080:8k_2_02:13]
Key Performance Indicators:

[0000038725-14-000080:8k_2_02:14]
| Earnings Before and After Non-GAAP Adjustments |  | For the First Quarter |
| (in millions) |  | 2014 | 2013 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 17.0 |  | $ | 15.5 |  | 10 | % |
| Allocated Undistributed Earnings |  | $ | (0.3 | ) | $ | (0.2 | ) |  |
| Adjusted Earnings for EPS Calculations |  | $ | 16.7 |  | $ | 15.3 |  | 9 | % |
| Non-GAAP adjustments (before tax): |  |  |  |  |
| Restructuring |  | $ | 0.1 |  | $ | 0.7 |  |  |
| Legal matters |  | $ | — |  | $ | 0.4 |  |  |
| Acquisition related items |  | $ | 0.1 |  | $ | — |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |
| Restructuring |  | $ | 0.1 |  | $ | 0.4 |  |  |
| Legal matters |  | $ | — |  | $ | 0.2 |  |  |
| Acquisition related items |  | $ | 0.1 |  | $ | — |  |  |
| Earnings after Non-GAAP Adjustments |  | $ | 16.9 |  | $ | 15.9 |  | 6 | % |
| Earnings Per Share |  | For the First Quarter |
| Before and After Non-GAAP Adjustments |  | 2014 | 2013 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 48.3 |  | 48.0 |  | 1 | % |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.35 |  | $ | 0.32 |  | 9 | % |
| Restructuring Per Share, net of tax |  | $ | — |  | $ | 0.01 |  |  |
| Legal matters Per Share, net of tax |  | $ | — |  | $ | — |  |  |
| Acquisition related items Per Share, net of tax |  | $ | — |  | $ | — |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments(Adjusted EPS) |  | $ | 0.35 |  | $ | 0.33 |  | 6 | % |

[0000038725-14-000080:8k_2_02:15]
| Net Sales | For the First Quarter |
| (in millions) | Water | Fueling | Consolidated |
| Sales for 2013 | $ | 176.4 |  | $ | 46.1 |  | $ | 222.5 |  |
| Acquisitions | $ | 0.8 |  | $ | — |  | $ | 0.8 |  |
| Foreign Exchange | $ | (8.6 | ) | $ | 0.6 |  | $ | (8.0 | ) |
| Volume/Price Change | $ | 16.0 |  | $ | 0.1 |  | $ | 16.1 |  |
| Sales for 2014 | $ | 184.6 |  | $ | 46.8 |  | $ | 231.4 |  |

[0000038725-14-000080:8k_2_02:16]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the First Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 29.2 |  | $ | 9.1 |  | $ | (12.3 | ) | $ | 26.0 |  |
| % Operating Income To Net Sales | 15.8 | % | 19.4 | % |  | 11.2 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.1 |  | $ | — |  | $ | — |  | $ | 0.1 |  |
| Legal matters | $ | — |  | $ | — |  | $ | — |  | $ | — |  |
| Acquisition related items | $ | — |  | $ | 0.1 |  | $ | — |  | $ | 0.1 |  |
| Operating Income after Non-GAAP Adjustments | $ | 29.3 |  | $ | 9.2 |  | $ | (12.3 | ) | $ | 26.2 |  |
| % Operating Income to Net Sales After non-GAAP adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.9 | % | 19.7 | % |  | 11.3 | % |
|  | For the First Quarter 2013 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 28.7 |  | $ | 6.2 |  | $ | (11.7 | ) | $ | 23.2 |  |
| % Operating Income To Net Sales | 16.3 | % | 13.4 | % |  | 10.4 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.5 |  | $ | 0.2 |  | $ | — |  | $ | 0.7 |  |
| Legal matters | $ | — |  | $ | 0.4 |  | $ | — |  | $ | 0.4 |  |
| Acquisition related items | $ | — |  | $ | — |  | $ | — |  | $ | — |  |
| Operating Income after Non-GAAP Adjustments | $ | 29.2 |  | $ | 6.8 |  | $ | (11.7 | ) | $ | 24.3 |  |
| % Operating Income to Net Sales After non-GAAP adjustments (Operating Income Margin after Non-GAAP Adjustments) | 16.6 | % | 14.8 | % |  | 10.9 | % |

[0000038725-14-000080:8k_2_02:17]
Water Systems

[0000038725-14-000080:8k_2_02:18]
Water Systems sales were $184.6 million in the first quarter 2014, an increase of $8.2 million or about 5 percent versus the first quarter 2013 sales of $176.4 million.  Sales from businesses acquired since the first quarter of 2013 were $0.8 million or less than 1 percent.  Water Systems sales were reduced by $8.6 million or about 5 percent in the quarter due to foreign currency translation.  Water Systems sales growth, excluding acquisitions and foreign currency translation, was about 9 percent.

[0000038725-14-000080:8k_2_02:19]
Water Systems sales in the U.S. and Canada represented 38 percent of consolidated sales and increased by about 2 percent compared to the prior year. Sales of mobile pumping equipment sold to the pump rental channel grew, however this growth was partially offset by declining sales to the groundwater and wastewater distribution channels.  U.S. and Canada sales in the gr

[0000038725-14-000080:8k_2_02:20]
oundwater and wastewater channels declined by about 6.5 percent in the quarter driven by more significant declines during the severe weather months of January and February, but sales in these channels grew in the month of March as the weather moderated.

[0000038725-14-000080:8k_2_02:21]
During the first quarter, the Company’s second largest customer, National Pump and Compressor, was acquired by United Rental, which is one of the largest rental companies in the world.  United has announced plans to use the National Pump acquisition as a platform for significant pump rental growth.  The Company believes that over time this will have a positive impact on the Pioneer product line.

[0000038725-14-000080:8k_2_02:22]
Water Systems sales in Latin America were about 13 percent of consolidated sales for the first quarter and declined by about 2 percent compared to the first quarter of the prior year.  Excluding the impact of foreign currency translation, Latin American sales increased by about 9 percent compared to the first quarter 2013.  Most of the sales growth in Latin America occurred in Brazil, where demand was strong across virtually all regions and all product lines. In the second quarter, the new factory being built in Brazil is expected to open.  The new facility will add capacity and support additional growth and enable the Company to further improve its operational efficiency.

[0000038725-14-000080:8k_2_02:23]
Water Systems sales in the Middle East and Africa were about 13 percent of consolidated sales and grew by about 25 percent compared to the first quarter 2013.  Excluding the impact of foreign currency translation, sales increased by about 43 percent compared to the first quarter 2013. The growth was driven by strong sales of groundwater pumping equipment sold under both the Impo and Franklin brand names in Turkey and North Africa.

[0000038725-14-000080:8k_2_02:24]
Water Systems sales in the Asia Pacific region were 8 percent of consolidated sales and were flat compared to the first quarter prior year.  Excluding the impact of foreign currency translation, Asia Pacific sales increased by about 5 percent compared to the first quarter 2013.  The Asia Pacific region experienced strong sales of groundwater pumping equipment in Japan and Korea, offset by a slowdown of sales in Indonesia and Australia.

[0000038725-14-000080:8k_2_02:25]
Water Systems sales in Europe were about 8 percent of consolidated sales and grew by about 6 percent compared to the first quarter 2013.  Acquisition related sales were about 3 percent.  The impact of foreign currency translation increased sales by about 3 percent compared to the first quarter 2013.  Excluding acquisition and the impact of foreign currency translation, European sales were flat to the first quarter 2013.

[0000038725-14-000080:8k_2_02:26]
Water Systems operating income, after non-GAAP adjustments, was $29.3 million in the first quarter 2014, flat versus the first quarter 2013. The first quarter operating income margin after non-GAAP adjustments was 15.9 percent, down 70 basis points from 16.6 percent in the first quarter of 2013.  Operating income margin after non-GAAP adjustments decreased in Water Systems primarily due to sales and mix in the U.S and Canada.

[0000038725-14-000080:8k_2_02:27]
Fueling Systems

[0000038725-14-000080:8k_2_02:28]
Fueling Systems sales represented 20 percent of consolidated sales and were $46.8 million in the first quarter 2014, an increase of $0.7 million or about 2 percent versus the first quarter 2013 sales of $46.1 million.  Fueling Systems sales increased by $0.6 million or about 1 percent in the quarter due to foreign currency translation.  Fueling Systems sales were flat, excluding acquisitions and foreign currency translation.

[0000038725-14-000080:8k_2_02:29]
During the first quarter last year, Fueling Systems shipped about $4.7 million of equipment to India to fill a large tender order.   This year the Company’s Indian tender shipments, which will be about the same size as last year, are planned for later in the year.  Excluding the impact of the Indian tender sales during the first quarter of 2013, Fueling Systems sales grew by about 12 percent.  Sales of pressure pumping systems outside of India grew by 25 percent during the quarter as demand for the Franklin pressure pumping systems is increasing in virtually all developing regions of the world.  The Company also experienced solid growth during the first quarter for fueling dispenser nozzles and related equipment in China.

[0000038725-14-000080:8k_2_02:30]
Fueling Systems operating income after non-GAAP adjustments was $9.2 million in the first quarter of 2014 compared to $6.8 million after non-GAAP adjustments in the first quarter of 2013, an increase of about 35 percent. The first quarter operating income margin after non-GAAP adjustments was 19.7 percent, an increase of 490 basis points from the 14.8 percent of net sales in the first quarter of 2013.  The increase was driven by a positive product sales mix and a combination of productivity, favorable pricing, and synergies from the Flex-ing acquisition.

[0000038725-14-000080:8k_2_02:31]
Overall

[0000038725-14-000080:8k_2_02:32]
The Company’s consolidated gross profit was $78.1 million for the first quarter of 2014, an increase of $4.2 million, or about 6 percent, from the first quarter of 2013 gross profit of $73.9 million. The gross profit as a percent of net sales was 33.8 percent

[0000038725-14-000080:8k_2_02:33]
in the first quarter of 2014 up about 60 basis points versus 33.2 percent during the first quarter 2013.  The gross profit margin increase was due to lower fixed cost, leverage on fixed cost from higher sales, productivity improvements which lowered direct labor and variable costs, partially offset by higher raw material costs.

[0000038725-14-000080:8k_2_02:34]
Selling, general, and administrative (SG&A) expenses were $52.0 million in the first quarter of 2014 compared to $50.1 million in the first quarter of prior year, an increase of $1.9 million or about 4 percent.  SG&A expenses as a percentage of sales were 22.5 percent in the first quarter of 2014, flat to the first quarter of 2013.

[0000038725-14-000080:8k_2_02:35]
The Company ended the first quarter of 2014 with a cash balance of $102.1 million, which was $32.5 million lower than at the end of 2013.  The cash balance decrease is primarily attributable to the seasonality of the business including lower sales in the first quarter and annual incentive compensation payments.  The cash balance at the end of the first quarter 2014 increased by 37 percent versus the $74.7 million balance at the end of the first quarter 2013.

[0000038725-14-000080:8k_2_02:36]
Commenting on the outlook for the second quarter of 2014, Mr. Trumbull said:

[0000038725-14-000080:8k_2_02:37]
“Our short term outlook is being influenced by a decision that we have made to restructure our groundwater distribution channel in the United States.  In mid-February we notified certain distribution outlets that after July 15 of this year we will discontinue supplying them and they will be replaced with other distribution outlets that we believe will represent our products more effectively.  In total, the affected annual revenue of these distribution outlets represents less than four percent of our consolidated sales.  We anticipate that during the transition, second quarter U.S. groundwater sales may decline modestly due to inventory adjustments made by both our discontinued and new distributors.  We are confident that when this activity is complete, we will have stronger overall U.S. distribution relationships and our sales will benefit.  As a result, we are projecting that our second quarter 2014 global Water Systems sales and adjusted operating income will grow 2 to 4 percent.

[0000038725-14-000080:8k_2_02:38]
“We estimate that our Fueling Systems sales and adjusted operating earnings will grow in the second quarter of 2014 by 9 to 11 percent.

[0000038725-14-000080:8k_2_02:39]
“Finally, due to some favorable tax items in the second quarter 2013, we believe our effective tax rate will be about 300 basis points higher than last year so our consolidated adjusted earnings per share growth will be in the 3 to 5 percent range.”

[0000038725-14-000080:8k_2_02:40]
A conference call to review earnings and other developments in the business will commence at 5:00pm EDT.  The first quarter 2014 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-14-000080:8k_2_02:41]
http://www.media-server.com/m/p/abvef5ji

[0000038725-14-000080:8k_2_02:42]
If you intend to ask questions during the call, please dial in using 877-643-7158 for domestic calls and 914-495-8565 for international calls.

[0000038725-14-000080:8k_2_02:43]
A replay of the conference call will be available Tuesday, April 29, 2014 at 8pm EDT through midnight EDT on Monday, May 5, 2014, by dialing 855-859-2056 for domestic calls and 404-537-3406 for international calls. The replay passcode is 31384171.

[0000038725-14-000080:8k_2_02:44]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and automotive fuels. Recognized as a technical leader in its specialties, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-14-000080:8k_2_02:45]
The Company presents the non-GAAP financial measures of earnings after non-GAAP adjustments, fully diluted earnings per share after non-GAAP adjustments (or adjusted EPS), operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments (or operating income margin after non-GAAP adjustments) because the Company believes the information helps investors understand underlying trends in the Company's business more easily.  The differences between these measures and the most comparable GAAP measures are reconciled in the tables above.

[0000038725-14-000080:8k_2_02:46]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |
|  | First Quarter Ended |
|  | March 29, 2014 |  | March 30, 2013 |
| Net sales | $ | 231,421 |  |  | $ | 222,524 |  |
| Cost of sales | 153,310 |  |  | 148,583 |  |
| Gross profit | 78,111 |  |  | 73,941 |  |
| Selling, general, and administrative expenses | 52,015 |  |  | 50,065 |  |
| Restructuring (income)/expense | 136 |  |  | 710 |  |
| Operating income | 25,960 |  |  | 23,166 |  |
| Interest expense | (2,784 | ) |  | (2,590 | ) |
| Other income/(expense) | 325 |  |  | 447 |  |
| Foreign exchange income/(expense) | (420 | ) |  | (171 | ) |
| Income before income taxes | 23,081 |  |  | 20,852 |  |
| Income taxes | 5,660 |  |  | 5,237 |  |
| Net income | $ | 17,421 |  |  | $ | 15,615 |  |
| Less: Net income attributable to noncontrolling interests | (464 | ) |  | (159 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 16,957 |  |  | $ | 15,456 |  |
| Income per share: |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.32 |  |
| Diluted | $ | 0.35 |  |  | $ | 0.32 |  |

[0000038725-14-000080:8k_2_02:47]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | March 29, 2014 |  | December 28, 2013 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 102,137 |  |  | $ | 134,553 |  |
| Receivables | 147,101 |  |  | 115,127 |  |
| Inventories | 223,133 |  |  | 191,561 |  |
| Other current assets | 36,933 |  |  | 31,113 |  |
| Total current assets | 509,304 |  |  | 472,354 |  |
| Property, plant, and equipment, net | 210,330 |  |  | 208,596 |  |
| Goodwill and other assets | 370,106 |  |  | 370,923 |  |
| Total assets | $ | 1,089,740 |  |  | $ | 1,051,873 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 81,133 |  |  | $ | 57,755 |  |
| Accrued expenses | 50,542 |  |  | 65,356 |  |
| Current maturities of long-term debt and short-term borrowings | 30,607 |  |  | 15,363 |  |
| Total current liabilities | 162,282 |  |  | 138,474 |  |
| Long-term debt | 173,654 |  |  | 174,166 |  |
| Deferred income taxes | 54,347 |  |  | 54,618 |  |
| Employee benefit plans | 38,457 |  |  | 41,685 |  |
| Other long-term liabilities | 39,535 |  |  | 39,543 |  |
| Redeemable noncontrolling interest | 5,288 |  |  | 5,171 |  |
| Total equity | 616,177 |  |  | 598,216 |  |
| Total liabilities and equity | $ | 1,089,740 |  |  | $ | 1,051,873 |  |

[0000038725-14-000080:8k_2_02:48]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Three Months Ended |
| (In thousands) | March 29, 2014 |  | March 30, 2013 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 17,421 |  |  | $ | 15,615 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 8,847 |  |  | 7,367 |  |
| Share-based compensation | 1,392 |  |  | 2,158 |  |
| Other | (1,237 | ) |  | (4,516 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (31,451 | ) |  | (28,686 | ) |
| Inventory | (31,408 | ) |  | (17,038 | ) |
| Accounts payable and accrued expenses | 8,408 |  |  | (8,441 | ) |
| Other | (7,352 | ) |  | 2,762 |  |
| Net cash flows from operating activities | (35,380 | ) |  | (30,779 | ) |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (8,172 | ) |  | (16,515 | ) |
| Proceeds from sale of property, plant, and equipment | 1,592 |  |  | 55 |  |
| Additions to intangibles | — |  |  | 48 |  |
| Acquisitions and investments | (2,449 | ) |  | — |  |
| Net cash flows from investing activities | (9,029 | ) |  | (16,412 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 14,641 |  |  | 25,016 |  |
| Proceeds from issuance of common stock | 635 |  |  | 4,128 |  |
| Excess tax from share-based payment arrangements | 1,448 |  |  | 2,063 |  |
| Purchases of common stock | (1,581 | ) |  | (2,504 | ) |
| Dividends paid | (3,709 | ) |  | (3,417 | ) |
| Payment of contingent consideration liability | — |  |  | (5,555 | ) |
| Net cash flows from financing activities | 11,434 |  |  | 19,731 |  |
| Effect of exchange rate changes on cash | 559 |  |  | (1,212 | ) |
| Net change in cash and equivalents | (32,416 | ) |  | (28,672 | ) |
| Cash and equivalents at beginning of period | 134,553 |  |  | 103,338 |  |
| Cash and equivalents at end of period | $ | 102,137 |  |  | $ | 74,666 |  |
