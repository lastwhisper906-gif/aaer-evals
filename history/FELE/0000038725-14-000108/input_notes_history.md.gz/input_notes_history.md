# FELE note change history — 0000038725-13-000228 → 0000038725-14-000108


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-08):
[0000038725-14-000108:note_history:1]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014.  CARB has filed a notice of appeal.
  (was, 2013-11-07, similarity 0.6851):
[0000038725-13-000228:note_history:1]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.

- changed (2014-05-08):
[0000038725-14-000108:note_history:2]
Neither of these suits has had any effect on CARB's certification of the Company's EVR System or any other products of the Company or its subsidiaries, and did not interfere with continuing sales.  CARB has never decertified the Company's EVR System and has never proposed to do so.
  (was, 2013-11-07, similarity 0.9143):
[0000038725-13-000228:note_history:2]
None of these suits have had any effect on CARB's certification of the Company's EVR System or any other products of the Company or its subsidiaries, and did not interfere with continuing sales.  CARB has never decertified the Company's EVR System and has never proposed to do so.

- added (2014-05-08):
[0000038725-14-000108:note_history:3]
The Company is defending various other claims and legal actions, including environmental matters, which have arisen in the

- added (2014-05-08):
[0000038725-14-000108:note_history:4]
ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with

- added (2014-05-08):
[0000038725-14-000108:note_history:5]
counsel, these claims and legal actions can be successfully defended or resolved without a material adverse effect on the

- added (2014-05-08):
[0000038725-14-000108:note_history:6]
Company’s financial position, results of operations, and net cash flows.

- changed (2014-05-08):
[0000038725-14-000108:note_history:7]
At March 29, 2014, the Company had $18.5 million of commitments primarily for the purchase of machinery and equipment as well as conditional agreements related to building expansions.
  (was, 2013-11-07, similarity 0.6957):
[0000038725-13-000228:note_history:7]
At September 28, 2013, the Company had $15.7 million of commitments primarily for conditional agreements related to building expansions and the purchase of machinery and equipment.

- changed (2014-05-08):
[0000038725-14-000108:note_history:8]
The company provides warranties on most of its products.  The warranty terms vary but are generally two years from date of manufacture or one year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to five years from date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.
  (was, 2013-11-07, similarity 0.9973):
[0000038725-13-000228:note_history:8]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two years from date of manufacture or one year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to five years from the date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes action to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

- changed (2014-05-08):
[0000038725-14-000108:note_history:9]
The changes in the carrying amount of the warranty accrual, as recorded in "Accrued expenses" in the Company's consolidated balance sheet for the three months ended March 29, 2014, are as follows:
  (was, 2013-11-07, similarity 0.8448):
[0000038725-13-000228:note_history:9]
The changes in the carrying amount of the warranty accrual, as recorded in "Accrued expenses" in the Company's condensed consolidated balance sheet for the nine months ended September 28, 2013, are as follows:

- added (2014-05-08):
[0000038725-14-000108:note_history:10]
| (In millions) |  |  |
| Balance as of December 28, 2013 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 1.4 |  |
| Reductions for payments made |  | (2.0 | ) |
| Balance as of March 29, 2014 |  | $ | 8.9 |  |

- removed (2014-05-08):
[0000038725-13-000228:note_history:11]
CARB and SCAQMD will have 60 days from service of the Notice of Entry of Judgment (which has not yet been entered by the Court in the CARB Case) in which to file a notice of appeal.

- removed (2014-05-08):
[0000038725-13-000228:note_history:12]
In addition, as the Company has previously reported, the Sacramento Metropolitan Air Quality Management District (“SMAQMD”) issued a Notice of Violation to the Company concerning the diaphragm matter in March 2008.  In November 2010, SMAQMD filed a civil complaint in the Sacramento Superior Court, mirroring the claims brought in the CARB Case.  In May 2013, the Company and SMAQMD entered into a settlement agreement whereby the Company and SMAQMD agreed to dismiss the suit with prejudice and the Company agreed to pay SCAQMD a percent of any award made in the CARB Case.  Because the CARB Case has thus far resulted in a complete defense verdict, no payments are due under the settlement with SMAQMD.

- removed (2014-05-08):
[0000038725-13-000228:note_history:13]
The Company is defending various other claims and legal actions, including environmental matters, which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be successfully defended or resolved without a material adverse effect on the Company’s financial position, results of operations, and net cash flows.

- removed (2014-05-08):
[0000038725-13-000228:note_history:14]
| (In millions) |  |  |
| Beginning balance, December 29, 2012 |  | $ | 9.7 |  |
| Accruals related to product warranties |  | 6.7 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (6.7 | ) |
| Ending balance, September 28, 2013 |  | $ | 9.7 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-08):
[0000038725-14-000108:note_history:15]
1. CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
  (was, 2013-11-07, similarity 0.9773):
[0000038725-13-000228:note_history:15]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS

- changed (2014-05-08):
[0000038725-14-000108:note_history:16]
The accompanying condensed consolidated balance sheet as of December 28, 2013, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 29, 2014, and for the first quarters ended March 29, 2014 and March 30, 2013, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended March 29, 2014, are not necessarily indicative of the results that may be expected for the fiscal year ending January 3, 2015.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K/A for the year ended December 28, 2013.
  (was, 2013-11-07, similarity 0.8706):
[0000038725-13-000228:note_history:16]
The accompanying condensed consolidated balance sheet as of December 29, 2012, which has been derived from audited financial statements and the unaudited interim condensed consolidated financial statements as of September 28, 2013, and for the third quarters and nine months ended September 28, 2013 and September 29, 2012, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the third quarters and nine months ended September 28, 2013, are not necessarily indicative of the results that may be expected for the fiscal year ending December 28, 2013.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K for the year ended December 29, 2012.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-08):
[0000038725-14-000108:note_history:17]
| (In millions) |  | March 29, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.1 |  |  | 24.6 |  |
| Revolver |  | 15.0 |  |  | — |  |
| Capital leases |  | 0.7 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 14.5 |  |  | 14.2 |  |
|  |  | 204.3 |  |  | 189.6 |  |
| Less current maturities |  | (30.6 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 173.7 |  |  | $ | 174.2 |  |
  (was, 2013-11-07, similarity 0.8704):
[0000038725-13-000228:note_history:17]
| (In millions) |  | September 28, 2013 |  | December 29, 2012 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.6 |  |  | — |  |
| Capital leases |  | 0.8 |  |  | 1.0 |  |
| Foreign subsidiary debt |  | 15.2 |  |  | 14.9 |  |
|  |  | 190.6 |  |  | 165.9 |  |
| Less current maturities |  | (16.4 | ) |  | (15.2 | ) |
| Long-term debt |  | $ | 174.2 |  |  | $ | 150.7 |  |

- changed (2014-05-08):
[0000038725-14-000108:note_history:18]
Foreign subsidiary debt denoted in the table above is predominately comprised of debt at Impo.
  (was, 2013-11-07, similarity 0.7181):
[0000038725-13-000228:note_history:18]
Foreign subsidiary debt denoted in the table above is predominately comprised of debt at Impo, which was refinanced in September 2013 with maturity dates in September 2014.

- changed (2014-05-08):
[0000038725-14-000108:note_history:19]
The total estimated fair value of debt was $218.3 million and $203.7 million at March 29, 2014 and December 28, 2013, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its long term debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as a Level 2 within the valuations hierarchy.
  (was, 2013-11-07, similarity 0.9885):
[0000038725-13-000228:note_history:19]
The total estimated fair value of debt was $205.0 million and $179.8 million at September 28, 2013 and December 29, 2012, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its long-term debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as a Level 2 within the valuations hierarchy.

- changed (2014-05-08):
[0000038725-14-000108:note_history:20]
| (In millions) |  | Total |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | More than 5 years |
| Debt |  | $ | 203.6 |  |  | $ | 30.4 |  |  | $ | 30.9 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 49.3 |  |
| Capital leases |  | 0.7 |  |  | 0.2 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 204.3 |  |  | $ | 30.6 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 49.3 |  |
  (was, 2013-11-07, similarity 0.8978):
[0000038725-13-000228:note_history:20]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More than 5 years |
| Debt |  | $ | 189.8 |  |  | $ | 16.1 |  |  | $ | 0.9 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 79.8 |  |
| Capital leases |  | 0.8 |  |  | 0.3 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 190.6 |  |  | $ | 16.4 |  |  | $ | 1.1 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 79.8 |  |

- removed (2014-05-08):
[0000038725-13-000228:note_history:21]
On December 31, 2012, the Company, Allen County, Indiana, and certain institutional investors entered into a Bond Purchase and Loan Agreement.  Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).”  The aggregate principal amount of the Project Bonds that was issued, authenticated, and is now outstanding thereunder was limited to $25.0 million.  The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation, and equipping of the new Global Corporate Headquarters and Engineering Center of Excellence. These Project Notes (tax increment financing debt) bear interest at 3.6 percent per annum.  Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.  The use of the proceeds from the Project Notes is limited to assist the financing of the new Global Corporate Headquarters and Engineering Center of Excellence.

- removed (2014-05-08):
[0000038725-13-000228:note_history:22]
The agreement contains customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws, and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales, and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio and a minimum interest coverage ratio. The agreement also contains a cross default provision in the event the Company defaults on any obligation exceeding $10.0 million.

- removed (2014-05-08):
[0000038725-13-000228:note_history:23]
Also, on December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-08):
[0000038725-14-000108:note_history:24]
| (In millions) |  | March 29, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.1 |  |  | 24.6 |  |
| Revolver |  | 15.0 |  |  | — |  |
| Capital leases |  | 0.7 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 14.5 |  |  | 14.2 |  |
|  |  | 204.3 |  |  | 189.6 |  |
| Less current maturities |  | (30.6 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 173.7 |  |  | $ | 174.2 |  |
  (was, 2013-11-07, similarity 0.8704):
[0000038725-13-000228:note_history:24]
| (In millions) |  | September 28, 2013 |  | December 29, 2012 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.6 |  |  | — |  |
| Capital leases |  | 0.8 |  |  | 1.0 |  |
| Foreign subsidiary debt |  | 15.2 |  |  | 14.9 |  |
|  |  | 190.6 |  |  | 165.9 |  |
| Less current maturities |  | (16.4 | ) |  | (15.2 | ) |
| Long-term debt |  | $ | 174.2 |  |  | $ | 150.7 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-08):
[0000038725-14-000108:note_history:25]
| (In millions) |  | Total |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | More than 5 years |
| Debt |  | $ | 203.6 |  |  | $ | 30.4 |  |  | $ | 30.9 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 49.3 |  |
| Capital leases |  | 0.7 |  |  | 0.2 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 204.3 |  |  | $ | 30.6 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 49.3 |  |
  (was, 2013-11-07, similarity 0.8978):
[0000038725-13-000228:note_history:25]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More than 5 years |
| Debt |  | $ | 189.8 |  |  | $ | 16.1 |  |  | $ | 0.9 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 31.0 |  |  | $ | 79.8 |  |
| Capital leases |  | 0.8 |  |  | 0.3 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 190.6 |  |  | $ | 16.4 |  |  | $ | 1.1 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 79.8 |  |
