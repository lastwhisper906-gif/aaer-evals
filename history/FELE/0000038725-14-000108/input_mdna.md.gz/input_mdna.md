# FELE MD&A — 0000038725-14-000108


## mdna

[0000038725-14-000108:mdna:1]
ITEM 2.  MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-14-000108:mdna:2]
First Quarter 2014 vs. First Quarter 2013

[0000038725-14-000108:mdna:3]
[same as prior period, unchanged from 0000038725-13-000228:mdna:3]

[0000038725-14-000108:mdna:4]
Sales and earnings in the first quarter of 2014 increased from the first quarter last year.  The sales increase was primarily due to volume increases which were partially offset by the negative impact of foreign currency translation. The Company's consolidated gross profit was $78.1 million for the first quarter of 2014, an increase of $4.2 million or about 6 percent from the prior year’s first quarter. The gross profit as a percent of net sales increased 60 basis points to 33.8 percent in 2014 from 33.2 percent in first quarter of 2013. The gross profit margin increase was due to lower fixed cost, leverage on fixed cost from higher sales, and productivity improvements which lowered direct labor and variable costs, partially offset by higher raw material costs.

[0000038725-14-000108:mdna:5]
[same as prior period, unchanged from 0000038725-13-000228:mdna:5]

[0000038725-14-000108:mdna:6]
[same as prior period, unchanged from 0000038725-13-000228:mdna:6]

[0000038725-14-000108:mdna:7]
Net sales in the first quarter of 2014 were $231.4 million, an increase of $8.9 million or about 4 percent compared to 2013 first quarter sales of $222.5 million.  The incremental impact of sales from acquired businesses was $0.8 million or less than 1 percent.  Sales revenue decreased by $8.0 million or about 4 percent in the first quarter of 2014 due to foreign currency translation. The sales change in the first quarter of 2014, excluding acquisitions and foreign currency translation, was an increase of $16.1 million or about 7 percent.

[0000038725-14-000108:mdna:8]
|  | Net Sales |
| (In millions) | Q1 2014 |  | Q1 2013 |  | 2014 v 2013 |
| Water Systems | $ | 184.6 |  |  | $ | 176.4 |  |  | $ | 8.2 |  |
| Fueling Systems | 46.8 |  |  | 46.1 |  |  | 0.7 |  |
| Consolidated | $ | 231.4 |  |  | $ | 222.5 |  |  | $ | 8.9 |  |

[0000038725-14-000108:mdna:9]
[same as prior period, unchanged from 0000038725-13-000228:mdna:9]

[0000038725-14-000108:mdna:10]
Water Systems revenues were $184.6 million in the first quarter 2014, an increase of $8.2 million or about 5 percent versus the first quarter 2013 sales of $176.4 million.  Sales from businesses acquired since the first quarter of 2013 were $0.8 million or less than 1 percent.  Water Systems sales were reduced by $8.6 million or about 5 percent in the quarter due to foreign currency translation.  Water Systems sales growth, excluding acquisitions and foreign currency translation, was about 9 percent.

[0000038725-14-000108:mdna:11]
Water Systems sales in the U.S. and Canada represented 38 percent of consolidated sales and increased by about 2 percent compared to the prior year. Sales of mobile pumping equipment sold to the pump rental channel grew, however this growth was partially offset by declining sales to the groundwater and wastewater distribution channels.  U.S. and Canada sales in the groundwater and wastewater channels declined by about 6.5 percent in the quarter driven by more significant declines during the severe weather months of January and February, but sales in these channels grew in the month of March as the weather moderated.

[0000038725-14-000108:mdna:12]
During the first quarter, the Company’s second largest customer, National Pump and Compressor, was acquired by United Rental.  United is one of the largest rental companies in the world and has announced plans to use the National Pump acquisition as a platform for significant pump rental growth.  The Company believes that over time this will have a positive impact on the Pioneer product line.

[0000038725-14-000108:mdna:13]
Water Systems sales in Latin America were about 13 percent of consolidated sales for the first quarter and declined by about 2 percent compared to the first quarter of the prior year.  Excluding the impact of foreign currency translation, Latin American sales increased by about 9 percent compared to the first quarter 2013.  Most of the sales growth in Latin America occurred in Brazil, where demand was strong across virtually all regions and all product lines. In the second quarter, the new factory being built in Brazil will open.  The new facility will add capacity, support additional growth, and enable the Company to further improve its operational efficiency.

[0000038725-14-000108:mdna:14]
Water Systems sales in the Middle East and Africa were about 13 percent of consolidated sales and grew by about 25 percent compared to the first quarter 2013.  Excluding the impact of foreign currency translation, sales increased by about 43 percent

[0000038725-14-000108:mdna:15]
compared to the first quarter 2013. The growth was driven by strong sales of groundwater pumping equipment sold under both the Impo and Franklin brand names in Turkey and North Africa.

[0000038725-14-000108:mdna:16]
Water Systems sales in the Asia Pacific region were 8 percent of consolidated sales and were flat compared to the first quarter prior year.  Excluding the impact of foreign currency translation, Asia Pacific sales increased by about 5 percent compared to the first quarter 2013.  The Asia Pacific region experienced strong sales of groundwater pumping equipment in Japan and Korea, offset by a slowdown of sales in Indonesia and Australia.

[0000038725-14-000108:mdna:17]
Water Systems sales in Europe were about 8 percent of consolidated sales and grew by about 6 percent compared to the first quarter 2013.  Acquisition related sales were about 3 percent.  The impact of foreign currency translation increased sales by about 3 percent compared to the first quarter of 2013.  Excluding acquisition and the impact of foreign currency translation, European sales were flat to the first quarter of 2013

[0000038725-14-000108:mdna:18]
[same as prior period, unchanged from 0000038725-13-000228:mdna:16]

[0000038725-14-000108:mdna:19]
Fueling Systems sales were $46.8 million in the first quarter 2014, an increase of $0.7 million or about 2 percent versus the first quarter 2013 sales of $46.1 million.   Fueling Systems sales were increased by $0.6 million or 1 percent in the quarter due to foreign currency translation.  Fueling Systems sales growth, excluding acquisitions and foreign currency translation, was less than 1 percent.

[0000038725-14-000108:mdna:20]
During the first quarter last year, Fueling Systems shipped about $4.7 million of equipment to India to fill a large tender order.   This year the company’s Indian tender shipments, which will be about the same size as last year, are planned for later in the year.  Excluding the impact of the Indian tender sales during the first quarter of 2013, Fueling systems sales grew by about 12 percent.  Sales of pressure pumping systems outside of India grew by 25 percent during the quarter as demand for the Franklin pressure pumping system is increasing in virtually all developing regions of the world.  The Company also experienced solid growth during the first quarter for fueling dispenser nozzles and related equipment in China.

[0000038725-14-000108:mdna:21]
[same as prior period, unchanged from 0000038725-13-000228:mdna:19]

[0000038725-14-000108:mdna:22]
Cost of sales as a percentage of net sales for the first quarters of 2014 and 2013 was 66.2 percent and 66.8 percent, respectively. Correspondingly, the gross profit margin increased to 33.8 percent from 33.2 percent, a 60 basis point improvement. The Company’s consolidated gross profit was $78.1 million for the first quarter of 2014, an increase of $4.2 million, or about 6 percent, from the first quarter of 2013 gross profit of $73.9 million. The gross profit margin increase was due to lower fixed cost, leverage on fixed cost from higher sales, and productivity improvements which lowered direct labor and variable costs, partially offset by higher raw material costs.

[0000038725-14-000108:mdna:23]
[same as prior period, unchanged from 0000038725-13-000228:mdna:21]

[0000038725-14-000108:mdna:24]
Selling, general, and administrative (SG&A) expenses were $52.0 million in the first quarter of 2014 compared to $50.1 million from the first quarter of prior year, an increase of $1.9 million or about 4 percent.  SG&A expenses as a percentage of sales were 22.5 percent in the first quarter of 2014, flat to the first quarter of 2013.

[0000038725-14-000108:mdna:25]
[same as prior period, unchanged from 0000038725-13-000228:mdna:23]

[0000038725-14-000108:mdna:26]
Restructuring expenses for the first quarter of 2014 were $0.1 million and had no impact on diluted earnings per share. Restructuring expenses were primarily severance expenses and other miscellaneous manufacturing realignment activities. Restructuring expenses last year were $0.7 million and had a $0.01 impact on diluted earnings per share. Restructuring expenses in the first quarter of 2013 were primarily severance expenses, as well as Flex-ing acquisition integration activities, and other miscellaneous manufacturing realignment activities.

[0000038725-14-000108:mdna:27]
[same as prior period, unchanged from 0000038725-13-000228:mdna:25]

[0000038725-14-000108:mdna:28]
Operating income was $26.0 million in the first quarter of 2014, up $2.8 million or about 12 percent from $23.2 million in the first quarter of 2013.

[0000038725-14-000108:mdna:29]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2014 |  | Q1 2013 |  | 2014 v 2013 |
| Water Systems |  | $ | 29.2 |  |  | $ | 28.7 |  |  | $ | 0.5 |  |
| Fueling Systems |  | 9.1 |  |  | 6.2 |  |  | 2.9 |  |
| Other |  | (12.3 | ) |  | (11.7 | ) |  | (0.6 | ) |
| Consolidated |  | $ | 26.0 |  |  | $ | 23.2 |  |  | $ | 2.8 |  |

[0000038725-14-000108:mdna:30]
There were specific items in the first quarters of 2014 and 2013 that impacted operating income that were not operational in nature.  In the first quarter of 2014, there were two such items: $0.1 million of restructuring charges and $0.1 million for acquisition related activities.  In the first quarter of 2013, there were two such items: $0.7 million of restructuring charges and $0.4 million for certain legal matters.

[0000038725-14-000108:mdna:31]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments to net sales (operating income margin after non-GAAP adjustments).  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-14-000108:mdna:32]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (In millions) | For the First Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 29.2 |  | $ | 9.1 |  | $ | (12.3 | ) | $ | 26.0 |  |
| % Operating Income To Net Sales | 15.8 | % | 19.4 | % |  | 11.2 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.1 |  | $ | — |  | $ | — |  | $ | 0.1 |  |
| Legal matters | $ | — |  | $ | — |  | $ | — |  | $ | — |  |
| Acquisition related items | $ | — |  | $ | 0.1 |  | $ | — |  | $ | 0.1 |  |
| Operating Income after Non-GAAP Adjustments | $ | 29.3 |  | $ | 9.2 |  | $ | (12.3 | ) | $ | 26.2 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.9 | % | 19.7 | % |  | 11.3 | % |
|  | For the First Quarter 2013 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 28.7 |  | $ | 6.2 |  | $ | (11.7 | ) | $ | 23.2 |  |
| % Operating Income To Net Sales | 16.3 | % | 13.4 | % |  | 10.4 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.5 |  | $ | 0.2 |  | $ | — |  | $ | 0.7 |  |
| Legal matters | $ | — |  | $ | 0.4 |  | $ | — |  | $ | 0.4 |  |
| Acquisition related items | $ | — |  | $ | — |  | $ | — |  | $ | — |  |
| Operating Income after Non-GAAP Adjustments | $ | 29.2 |  | $ | 6.8 |  | $ | (11.7 | ) | $ | 24.3 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 16.6 | % | 14.8 | % |  | 10.9 | % |

[0000038725-14-000108:mdna:33]
[same as prior period, unchanged from 0000038725-13-000228:mdna:38]

[0000038725-14-000108:mdna:34]
Water Systems operating income, after non-GAAP adjustments, was $29.3 million in the first quarter 2014, flat versus the first quarter 2013. The first quarter operating income margin after non-GAAP adjustments was 15.9 percent, down 70 basis points from 16.6 percent in the first quarter of 2013.  Operating income margin after non-GAAP adjustments decreased in Water Systems primarily due to sales mix in the U.S. and Canada.

[0000038725-14-000108:mdna:35]
[same as prior period, unchanged from 0000038725-13-000228:mdna:40]

[0000038725-14-000108:mdna:36]
Fueling Systems operating income after non-GAAP adjustments was $9.2 million in the first quarter of 2014 compared to $6.8 million after non-GAAP adjustments in the first quarter of 2013, an increase of about 35 percent. The first quarter operating income margin after non-GAAP adjustments was 19.7 percent, an increase of 490 basis points from the 14.8 percent of net sales in the first quarter of 2013.  The increase was driven by a positive product sales mix and a combination of productivity, favorable pricing, and synergies from the Flex-ing acquisition.

[0000038725-14-000108:mdna:37]
22

[0000038725-14-000108:mdna:38]
[same as prior period, unchanged from 0000038725-13-000228:mdna:42]

[0000038725-14-000108:mdna:39]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses were higher primarily due to depreciation expense and increases in other Information Technologies expenses related to the new Headquarters and Engineering facility in Fort Wayne, Indiana.

[0000038725-14-000108:mdna:40]
[same as prior period, unchanged from 0000038725-13-000228:mdna:44]

[0000038725-14-000108:mdna:41]
Interest expense for the first quarters of 2014 and 2013 was $2.8 million and $2.6 million, respectively.

[0000038725-14-000108:mdna:42]
[same as prior period, unchanged from 0000038725-13-000228:mdna:46]

[0000038725-14-000108:mdna:43]
Other income or expense was income of $0.3 million in the first quarter of 2014 and income of $0.4 million in the first quarter of 2013.  Included in other income in the first quarter of 2014 was interest income of $0.4 million, primarily derived from the investment of cash balances in short-term securities. Included in other income in the first quarter of 2013 was interest income of $0.4 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-14-000108:mdna:44]
[same as prior period, unchanged from 0000038725-13-000228:mdna:49]

[0000038725-14-000108:mdna:45]
Foreign currency-based transactions produced a loss of $0.4 million for the first quarter of 2014, primarily due to the Canadian dollar.  Foreign currency-based transactions produced a loss of $0.2 million for the first quarter of 2013, primarily due to the South African rand.

[0000038725-14-000108:mdna:46]
[same as prior period, unchanged from 0000038725-13-000228:mdna:51]

[0000038725-14-000108:mdna:47]
The provision for income taxes in the first quarters of 2014 and 2013 was $5.7 million and $5.2 million, respectively. The effective tax rate for the first quarter of 2014 was about 25 percent and, before the impact of discrete events, was 28 percent.  Discrete adjustments during the first quarter were primarily for foreign tax rate changes and the impact of those changes on net deferred tax liabilities in those jurisdictions.  The tax rate as a percentage of pre-tax earnings for the second quarter of 2014 is projected to be about 28 percent, nearly 300 basis point increase compared to the second quarter of 2013.  The tax rate as a percentage of pre-tax earnings for the second quarter of 2013 was about 25 percent primarily due the completion of income tax audits and the favorable resolution of matters previously under review.  The average effective tax rate after discrete events for the second half of 2014 is projected to be 25 percent, an improvement of over 150 basis points from the back half of 2013.  The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand, and available credit.

[0000038725-14-000108:mdna:48]
[same as prior period, unchanged from 0000038725-13-000228:mdna:53]

[0000038725-14-000108:mdna:49]
Net income for the first quarter of 2014 was $17.4 million compared to the prior year first quarter net income of $15.6 million.  Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2014 was $17.0 million, or $0.35 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $15.5 million or $0.32 per diluted share. Earnings after non-GAAP adjustments for the first quarter of 2014 were $16.9 million, or $0.35 per diluted share, compared to the prior year first quarter earnings after non-GAAP adjustments of $15.9 million or $0.33 per diluted share.

[0000038725-14-000108:mdna:50]
There were specific items in the first quarters of 2014 and 2013 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-14-000108:mdna:51]
| Earnings Before and After Non-GAAP Adjustments | For the First Quarter Ended |
| (In millions) | 2014 | 2013 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 17.0 |  | $ | 15.5 |  | 10 | % |
| Allocated Undistributed Earnings | $ | (0.3 | ) | $ | (0.2 | ) |  |
| Adjusted Earnings for EPS Calculations | $ | 16.7 |  | $ | 15.3 |  | 9 | % |
| Non-GAAP adjustments, before tax: |  |  |  |
| Restructuring | $ | 0.1 |  | $ | 0.7 |  |  |
| Legal matters | $ | — |  | $ | 0.4 |  |  |
| Acquisition related items | $ | 0.1 |  | $ | — |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 0.1 |  | $ | 0.4 |  |  |
| Legal matters | $ | — |  | $ | 0.2 |  |  |
| Acquisition related items | $ | 0.1 |  | $ | — |  |  |
| Net Income attributable to Franklin Electric Co., Inc. after Non-GAAP Adjustments (Adjusted Net Income) | $ | 16.9 |  | $ | 15.9 |  | 6 | % |

[0000038725-14-000108:mdna:52]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the First Quarter Ended |
| (In millions, except per share data) | 2014 | 2013 | Change |
| Average Fully Diluted Shares Outstanding | 48.3 |  | $ | 48.0 |  | 1 | % |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.35 |  | $ | 0.32 |  | 9 | % |
| Restructuring per Share, net of tax | $ | — |  | $ | 0.01 |  |  |
| Legal matters per Share, net of tax | $ | — |  | $ | — |  |  |
| Acquisition related items Per Share, net of tax | $ | — |  | $ | — |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.35 |  | $ | 0.33 |  | 6 | % |

[0000038725-14-000108:mdna:53]
[same as prior period, unchanged from 0000038725-13-000228:mdna:117]

[0000038725-14-000108:mdna:54]
The Company's primary sources of liquidity are cash on hand, cash from operations, revolving credit agreement, and long-term debt funds available.

[0000038725-14-000108:mdna:55]
The Company has a committed, unsecured, revolving credit agreement maturing on December 14, 2016 (the “Agreement”) in the amount of $150.0 million. As of March 29, 2014, the Company had $130.7 million borrowing capacity under the Agreement as $4.3 million in letters of credit were outstanding and undrawn and $15.0 million of revolver borrowing had been drawn and were outstanding at the end of the quarter.

[0000038725-14-000108:mdna:56]
The Company also has an amended and restated uncommitted note purchase and private shelf agreement (the “Prudential Agreement”) in the amount of $200.0 million, with $150.0 million of notes issued thereunder beginning to mature in 2015. The Company has no scheduled principal payments under the Prudential Agreement until 2015 at which time it amortizes for 5 years at an amount of $30.0 million per year. As of March 29, 2014, the Company had $50.0 million borrowing capacity under the Prudential Agreement.

[0000038725-14-000108:mdna:57]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).” The aggregate principal amount of the Project Bonds

[0000038725-14-000108:mdna:58]
24

[0000038725-14-000108:mdna:59]
that were issued, authenticated, and outstanding thereunder was limited to $25.0 million. The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation, and equipping of the new Global Corporate Headquarters and Engineering Center of Excellence. The Project Notes (tax increment financing debt) bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033. The use of the proceeds from the Project Notes was limited to assist in the financing of the new Global Corporate Headquarters and Engineering Center of Excellence.

[0000038725-14-000108:mdna:60]
The Agreement, the Prudential Agreement, and the tax increment financing debt contain customary affirmative and negative covenants. The affirmative covenants include financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans or advances, investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Agreement, the Prudential Agreement, and the tax increment financing debt, but only if the Company is defaulting on an obligation exceeding $10.0 million. As of March 29, 2014, the Company was in compliance with all covenants.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-14-000108:mdna:61]
At March 29, 2014, the Company had $102.1 million of cash and equivalents at various locations worldwide. Approximately 24 percent of the cash and equivalents was in the U.S. and readily accessible.  Approximately 21 percent was in various European subsidiaries, and 27 percent was in Mexico and Brazil. On a regular basis the Company reviews international cash balances and, if appropriate based on forecasted expenditures and considerations for the post-tax economic efficiency, will reposition cash among its global entities. Cash investments worldwide are invested according to a written policy and are generally in bank demand accounts and bank time deposits with the preservation of principal as the highest priority. Also, historically the Company has generally sourced inputs and sold outputs both in the local currency of operations on a country by country basis, thereby insulating local cash balances from currency volatility.

[0000038725-14-000108:mdna:62]
Net use of cash from operating activities was $35.4 million for the first quarter ended March 29, 2014 compared to

[0000038725-14-000108:mdna:63]
$30.8 million for the first quarter ended March 30, 2013.  Inventory balances and related payables were up in first quarter 2014 due to the seasonal inventory build.  The increase in cash used for receivables in first quarter 2014 followed the increase in sales in first quarter 2014 over first quarter 2013 as well as extended terms to customers.

[0000038725-14-000108:mdna:64]
Net cash used in investing activities was $9.0 million for the first quarter ended March 29, 2014, compared to $16.4 million for the first quarter ended March 30, 2013.  Additions to property, plant and equipment were significantly lower in the first quarter 2014 compared to first quarter 2013 due to the Global Corporate Headquarters and Engineering Center of Excellence project spending in 2013. In evaluating potential future acquisitions that impact cash from investing, the Company reviews opportunities with an emphasis on increasing global distribution and also with an emphasis on adding complementary product lines that can be effectively marketed through existing global distribution.

[0000038725-14-000108:mdna:65]
Net cash provided by financing activities was $11.4 million for the first quarter ended March 29, 2014, compared to $19.7 million for the first quarter ended March 30, 2013. The primary decrease in cash provided by financing activities in first quarter 2014 is attributed to the TIF debt proceeds received in the first quarter of 2013 of $25 million and the debt repayments of $6.6 million in the first quarter of 2014.  Stock option exercises were significantly lower in first quarter 2014 compared to first quarter 2013.   The Company made a contingent consideration payment in the first quarter of 2013 of $5.6 million.
