# EVLV notes — 0001628280-24-022282


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-24-022282:notes:1]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to live, work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to better address the chronic epidemic of escalating gun violence, mass shootings, and terrorist attacks in a cost-effective manner while improving safety and the visitor experience. The Company is headquartered in Waltham, Massachusetts.

[0001628280-24-022282:notes:2]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly-owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).

[0001628280-24-022282:notes:3]
[same as prior period, unchanged from 0001628280-23-038311:notes:3]

[0001628280-24-022282:notes:4]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001628280-24-022282:notes:5]
[same as prior period, unchanged from 0001628280-23-038311:notes:5]

[0001628280-24-022282:notes:6]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2024, and for the three months ended March 31, 2024 and 2023 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2023 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2024 and the results of its operations for the three months ended March 31, 2024 and 2023 and cash flows for the three months ended March 31, 2024 and 2023. The results for the three months ended March 31, 2024 are not necessarily indicative of results to be expected for the year ending December 31, 2024, any other interim periods, or any future year or period.

[0001628280-24-022282:notes:7]
Reclassifications

[0001628280-24-022282:notes:8]
During the year ended December 31, 2023, the Company began classifying revenue from professional services, which includes installation, training, and event support, as well as other one-time revenue, within license fee and other revenue on the consolidated statements of operations and comprehensive loss, whereas the revenue for these services has previously been included in service revenue. Correspondingly, the Company began classifying costs associated with professional services within cost of license fee and other revenue, whereas these costs were previously included in cost of service revenue. These reclassifications were made to align the presentation of professional services with the Company's internal reporting and analysis. The reclassifications did not impact total revenue or total cost of revenue for any period. Prior year amounts included in this Quarterly Report on Form 10-Q have been reclassified to conform to the current presentation.

[0001628280-24-022282:notes:9]
For the three months ended March 31, 2023, the reclassifications resulted in an increase in license fee and other revenue of $0.6 million and a corresponding decrease in service revenue, as well as in increase in cost of license fee and other revenue of $0.3 million and a corresponding decrease in cost of service revenue.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-24-022282:notes:10]
[same as prior period, unchanged from 0001628280-23-038311:notes:8]

[0001628280-24-022282:notes:11]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2023, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2023. There have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2024.

[0001628280-24-022282:notes:12]
Recently Issued Accounting Pronouncements

[0001628280-24-022282:notes:13]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures.” The updated accounting guidance requires enhanced reportable segment disclosures, primarily related to significant segment expenses which are regularly provided to the chief operating decision maker. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Retrospective application is required and early adoption is permitted. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

[0001628280-24-022282:notes:14]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity should apply the amendments in ASU 2023-09 prospectively to all annual periods beginning after December 15, 2024. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-24-022282:notes:15]
Marketable Securities
Marketable securities as of March 31, 2024 and December 31, 2023 consisted of the following:

[0001628280-24-022282:notes:16]
|  | March 31, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 36,415 |  |  | $ | — |  |  | $ | 36,415 |  |
| Total marketable securities | $ | 36,415 |  |  | $ | — |  |  | $ | 36,415 |  |

[0001628280-24-022282:notes:17]
|  | December 31, 2023 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |
| Total marketable securities | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |

[0001628280-24-022282:notes:18]
Marketable securities at March 31, 2024 and December 31, 2023 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. The Company did not record any unrealized gains or losses on available-for-sale securities for each of the three months ended March 31, 2024 and 2023 as unrealized gains or losses were not material. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive income.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-24-022282:notes:19]
[same as prior period, unchanged from 0001628280-23-038311:notes:20]

[0001628280-24-022282:notes:20]
|  | Fair Value Measurements at March 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 23,771 |  |  | $ | — |  |  | $ | — |  |  | $ | 23,771 |  |
| Treasury bills | — |  |  | 41,378 |  |  | — |  |  | 41,378 |  |
|  | $ | 23,771 |  |  | $ | 41,378 |  |  | $ | — |  |  | $ | 65,149 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 22,220 |  |  | $ | 22,220 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 6,003 |  |  | 6,003 |  |
| Public Warrant liability | 8,738 |  |  | — |  |  | — |  |  | 8,738 |  |
|  | $ | 8,738 |  |  | $ | — |  |  | $ | 28,223 |  |  | $ | 36,961 |  |

[0001628280-24-022282:notes:21]
|  | Fair Value Measurements as of December 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 57,829 |  |  | $ | — |  |  | $ | — |  |  | $ | 57,829 |  |
| Treasury bills | — |  |  | 51,289 |  |  | — |  |  | 51,289 |  |
|  | $ | 57,829 |  |  | $ | 51,289 |  |  | $ | — |  |  | $ | 109,118 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 29,119 |  |  | $ | 29,119 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 6,530 |  |  | 6,530 |  |
| Public Warrant liability | 10,889 |  |  | — |  |  | — |  |  | 10,889 |  |
|  | $ | 10,889 |  |  | $ | — |  |  | $ | 35,649 |  |  | $ | 46,538 |  |

[0001628280-24-022282:notes:22]
Money market funds are included in cash and cash equivalents on the condensed consolidated balance sheets. As of March 31, 2024, U.S. treasury bills with maturities less than 3 months, which totaled $5.0 million, are included in cash and cash equivalents, while treasury bills with maturities greater than 3 months, which totaled $36.4 million, are reflected as marketable securities. As of December 31, 2023, all outstanding treasury bills, which totaled $51.3 million, had maturities greater than 3 months and are reflected as marketable securities. The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources.

[0001628280-24-022282:notes:23]
[same as prior period, unchanged from 0001628280-23-038311:notes:24]

[0001628280-24-022282:notes:24]
The carrying amounts of cash and cash equivalents, accounts receivable, restricted cash, accounts payable, accrued liabilities, and other accrued expenses approximate fair value because of their short maturity.

[0001628280-24-022282:notes:25]
During each of the three months ended March 31, 2024 and 2023, there were no transfers between Level 1, Level 2 and Level 3.

[0001628280-24-022282:notes:26]
[same as prior period, unchanged from 0001628280-23-038311:notes:26]

[0001628280-24-022282:notes:27]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2023. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of March 31, 2024, no milestones have been achieved.

[0001628280-24-022282:notes:28]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of March 31, 2024 were as follows: 85% expected stock price volatility, a risk-free rate of return of 4.6%, a 25% likelihood of change in control and a remaining term of 1.9 years.

[0001628280-24-022282:notes:29]
[same as prior period, unchanged from 0001628280-23-038311:notes:29]

[0001628280-24-022282:notes:30]
| Balance at December 31, 2023 | $ | 29,119 |  |
| Change in fair value | (6,899) |  |
| Balance at March 31, 2024 | $ | 22,220 |  |

[0001628280-24-022282:notes:31]
[same as prior period, unchanged from 0001628280-23-038311:notes:31]

[0001628280-24-022282:notes:32]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock which were converted into shares of the Company's stock in connection with the Merger (the “Founder Shares”). Of these shares, 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 outstanding shares will vest upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2023. The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of March 31, 2024, no milestones have been achieved.

[0001628280-24-022282:notes:33]
The fair value of the contingently issued common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of March 31, 2024 were as follows: 95% expected stock price volatility, a risk-free rate of return of 4.5%, a 25% likelihood of change in control and a remaining term of 2.3 years.

[0001628280-24-022282:notes:34]
[same as prior period, unchanged from 0001628280-23-038311:notes:34]

[0001628280-24-022282:notes:35]
| Balance at December 31, 2023 | $ | 6,530 |  |
| Change in fair value | (527) |  |
| Balance at March 31, 2024 | $ | 6,003 |  |

[0001628280-24-022282:notes:36]
[same as prior period, unchanged from 0001628280-23-038311:notes:36]

[0001628280-24-022282:notes:37]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. As of March 31, 2024, 14,324,893 Public Warrants are outstanding.

[0001628280-24-022282:notes:38]
[same as prior period, unchanged from 0001628280-23-038311:notes:38]

[0001628280-24-022282:notes:39]
| Balance at December 31, 2023 | $ | 10,889 |  |
| Change in fair value | (2,151) |  |
| Balance at March 31, 2024 | $ | 8,738 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-24-022282:notes:40]
[same as prior period, unchanged from 0001628280-23-038311:notes:40]

[0001628280-24-022282:notes:41]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001628280-24-022282:notes:42]
Distribution and License Agreement

[0001628280-24-022282:notes:43]
In March 2023, the Company entered into a distributor licensing agreement (the “Distribution and License Agreement”) with Columbia Electrical Contractors, Inc. (“Columbia Tech”). Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, which serves as the Company's primary contract manufacturer. Under this arrangement, the Company has granted a license of its intellectual property to Columbia Tech, which contracts directly with certain of the Company's resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment as opposed to lease the equipment. Columbia Tech pays the Company a hardware license fee for each system it manufactures and sells under the agreement. In these instances, the Company still contracts directly with the reseller to provide a multi-year SaaS and maintenance subscription to the end-users.

[0001628280-24-022282:notes:44]
The Company has assessed whether it operates as the principal or as an agent in relation to the sale of product made by Columbia Tech to the Company's resellers pursuant to the Distribution and License Agreement. The Company considered various factors, including but not limited to, inventory risk, discretion in establishing pricing, and which entity is primarily responsible for fulfillment. Based on an evaluation of the facts and circumstances, the Company concluded that Columbia Tech is the principal in the arrangement. The Company therefore does not recognize revenue in relation to sales of product pursuant to the Distribution and License Agreement, but does recognize revenue in relation to license fees received from Columbia Tech and the SaaS and maintenance subscription contracts.

[0001628280-24-022282:notes:45]
[same as prior period, unchanged from 0001628280-23-038311:notes:42]

[0001628280-24-022282:notes:46]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2024.

[0001628280-24-022282:notes:47]
|  | Less than 1 year |  | 1 - 2 years |  | More than 2 years |  | Total |
| Product revenue | $ | 998 |  |  | $ | — |  |  | $ | — |  |  | $ | 998 |  |
| Subscription revenue | 63,890 |  |  | 56,850 |  |  | 65,829 |  |  | 186,569 |  |
| Service revenue | 22,261 |  |  | 21,691 |  |  | 22,112 |  |  | 66,064 |  |
| License fee and other revenue | 436 |  |  | 1 |  |  | 2 |  |  | 439 |  |
| Total revenue | $ | 87,585 |  |  | $ | 78,542 |  |  | $ | 87,943 |  |  | $ | 254,070 |  |

[0001628280-24-022282:notes:48]
The amount of minimum future leases is based on expected income recognition. As of March 31, 2024, future minimum payments on noncancelable leases are as follows (in thousands):

[0001628280-24-022282:notes:49]
| Year Ending December 31: |  |
| 2024 (nine months remaining) | $ | 48,486 |  |
| 2025 | 58,972 |  |
| 2026 | 47,647 |  |
| 2027 | 27,312 |  |
| 2028 | 4,033 |  |
| Thereafter | 119 |  |
|  | $ | 186,569 |  |

[0001628280-24-022282:notes:50]
[same as prior period, unchanged from 0001628280-23-038311:notes:47]

[0001628280-24-022282:notes:51]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of March 31, 2024 and December 31, 2023, the Company had $2.5 million and $3.7 million in current portion of contract assets and $0.3 million and $0.5 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001628280-24-022282:notes:52]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $17.3 million during the three months ended March 31, 2024 that was included in the December 31, 2023 deferred revenue balance. The Company recognized revenue of $6.9 million during the three months ended March 31, 2023 that was included in the December 31, 2022 deferred revenue balance.

[0001628280-24-022282:notes:53]
[same as prior period, unchanged from 0001628280-23-038311:notes:50]

[0001628280-24-022282:notes:54]
| Balance at December 31, 2023 | $ | 71,490 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (17,323) |  |
| Revenue deferred | 17,554 |  |
| Balance at March 31, 2024 | $ | 71,721 |  |

[0001628280-24-022282:notes:55]
[same as prior period, unchanged from 0001628280-23-038311:notes:52]

[0001628280-24-022282:notes:56]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Interest income on lease receivables | 42 |  |  | 53 |  |  |  |  |  |
| Lease income - operating leases | 14,503 |  |  | 6,466 |  |  |  |  |  |
| Total lease revenue | $ | 14,545 |  |  | $ | 6,519 |  |  |  |  |  |

[0001628280-24-022282:notes:57]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.3 million and $0.2 million during the three months ended March 31, 2024 and 2023, respectively.

[0001628280-24-022282:notes:58]
[same as prior period, unchanged from 0001628280-23-038311:notes:55]

[0001628280-24-022282:notes:59]
The following table presents the Company’s revenue by revenue stream (in thousands). Certain prior period amounts have been reclassified to conform to current period presentation:

[0001628280-24-022282:notes:60]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Product revenue | $ | 603 |  |  | $ | 8,754 |  |  |  |  |  |
| Subscription revenue | 14,503 |  |  | 6,466 |  |  |  |  |  |
| Service revenue | 5,384 |  |  | 2,786 |  |  |  |  |  |
| License fees | 724 |  |  | — |  |  |  |  |  |
| Professional services and other revenue | 454 |  |  | 575 |  |  |  |  |  |
| Total revenue | $ | 21,668 |  |  | $ | 18,581 |  |  |  |  |  |

[0001628280-24-022282:notes:61]
Commissions
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $11.5 million and $11.4 million as of March 31, 2024 and December 31, 2023, respectively. During the three months ended March 31, 2024 and 2023, the Company recognized commission expense of $1.4 million and $1.6 million, respectively.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001628280-24-022282:notes:62]
[same as prior period, unchanged from 0001628280-23-038311:notes:59]

[0001628280-24-022282:notes:63]
[same as prior period, unchanged from 0001628280-23-038311:notes:60]

[0001628280-24-022282:notes:64]
|  | Allowance for Doubtful Accounts |
| Balance at December 31, 2023 | $ | (582) |  |
| Provisions | 264 |  |
| Write-offs, net of recoveries | 3 |  |
| Balance at March 31, 2024 | $ | (315) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001628280-24-022282:notes:65]
[same as prior period, unchanged from 0001628280-23-038311:notes:62]

[0001628280-24-022282:notes:66]
|  | March 31,2024 |  | December 31,2023 |
| Raw materials | $ | 2,048 |  |  | $ | 1,869 |  |
| Finished goods | 8,959 |  |  | 7,638 |  |
| Total | $ | 11,007 |  |  | $ | 9,507 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-24-022282:notes:67]
[same as prior period, unchanged from 0001628280-23-038311:notes:64]

[0001628280-24-022282:notes:68]
|  | March 31,2024 |  | December 31,2023 |
| Computers and telecom equipment | $ | 1,481 |  |  | $ | 1,331 |  |
| Lab equipment | 1,588 |  |  | 1,171 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 566 |  |  | 566 |  |
| Leased equipment | 90,200 |  |  | 80,206 |  |
| Capitalized software | 10,520 |  |  | 8,629 |  |
| Sales demo equipment | 2,853 |  |  | 2,758 |  |
| Equipment held for lease1 | 39,163 |  |  | 32,910 |  |
| Construction in progress | 3,094 |  |  | 2,493 |  |
|  | 149,576 |  |  | 130,175 |  |
| Less: Accumulated depreciation and amortization | (20,234) |  |  | (17,254) |  |
|  | $ | 129,342 |  |  | $ | 112,921 |  |

[0001628280-24-022282:notes:69]
[same as prior period, unchanged from 0001628280-23-038311:notes:66]

[0001628280-24-022282:notes:70]
As of March 31, 2024 and December 31, 2023, the net book value of capitalized software was $8.6 million and $7.0 million, respectively. These amounts include $0.9 million and $0.7 million of capitalized stock compensation costs, respectively. Depreciation and amortization expense related to property and equipment was $3.5 million and $1.8 million for the three months ended March 31, 2024 and 2023, respectively, which included amortization expense of capitalized software of $0.3 million and $0.2 million for the three months ended March 31, 2024 and 2023, respectively.

[0001628280-24-022282:notes:71]
[same as prior period, unchanged from 0001628280-23-038311:notes:68]

[0001628280-24-022282:notes:72]
|  | March 31,2024 |  | December 31,2023 |
| Leased equipment | $ | 90,200 |  |  | $ | 80,206 |  |
| Accumulated depreciation | (15,661) |  |  | (13,283) |  |
| Leased equipment, net | $ | 74,539 |  |  | $ | 66,923 |  |

[0001628280-24-022282:notes:73]
Depreciation expense related to leased units was $2.9 million and $1.4 million during the three months ended March 31, 2024 and 2023, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.
The Company did not record any loss from impairment of property and equipment during the three months ended March 31, 2024 and recorded $0.1 million of loss from impairment of property and equipment during the three months ended March 31, 2023. This primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in an impairment of the remaining economic value of such units.


## us-gaap:DebtDisclosureTextBlock

[0001628280-24-022282:notes:74]
Long-term Debt
In December 2022, the Company entered into a loan and security agreement (the “2022 SVB Credit Agreement”) with Silicon Valley Bank (“SVB”) in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. In light of the foregoing, on March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. During the three months ended March 31, 2023, the Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs. The Company had no long-term debt as of March 31, 2024 and December 31, 2023.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-24-022282:notes:75]
[same as prior period, unchanged from 0001628280-23-038311:notes:77]

[0001628280-24-022282:notes:76]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the three months ended March 31, 2024 and 2023:

[0001628280-24-022282:notes:77]
|  | Three Months Ended March 31, |
|  | 2024 |  | 2023 |
| Risk-free interest rate | 4.1 | % |  | 4.2 | % |
| Expected term (in years) | 6.1 |  | 6.1 |
| Expected volatility | 90.0 | % |  | 87.5 | % |
| Expected dividend yield | 0.0 | % |  | 0.0 | % |

[0001628280-24-022282:notes:78]
The following table summarizes the Company’s stock option activity since December 31, 2023 (in thousands, except for share and per share data):

[0001628280-24-022282:notes:79]
|  | Number ofShares |  | WeightedAverageExercise Price |
| Outstanding as of December 31, 2023 | 20,324,528 |  | $ | 1.04 |  |
| Granted | 2,725,625 |  | 3.63 |  |
| Exercised | (519,089) |  | 0.58 |  |
| Forfeited | (9,059) |  |  | 0.42 |  |
| Outstanding as of March 31, 2024 | 22,522,005 |  | 1.37 |  |

[0001628280-24-022282:notes:80]
[same as prior period, unchanged from 0001628280-23-038311:notes:82]

[0001628280-24-022282:notes:81]
The following table summarizes the Company's restricted stock units activity since December 31, 2023:

[0001628280-24-022282:notes:82]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2023 | 13,046,679 |  |  | $ | 3.49 |  |
| Granted | 6,850,765 |  |  | 3.70 |  |
| Vested | (3,147,778) |  |  | 3.35 |  |
| Forfeited | (289,631) |  |  | 3.58 |  |
| Outstanding as of March 31, 2024 | 16,460,035 |  |  | $ | 3.60 |  |

[0001628280-24-022282:notes:83]
[same as prior period, unchanged from 0001628280-23-038311:notes:85]

[0001628280-24-022282:notes:84]
The following table summarizes the Company's performance stock units activity since December 31, 2023:

[0001628280-24-022282:notes:85]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2023 | 380,000 |  |  | $ | 2.64 |  |
| Granted | — |  |  | — |  |
| Vested | (380,000) |  |  | 2.64 |  |
| Forfeited | — |  |  | — |  |
| Outstanding as of March 31, 2024 | — |  |  | $ | — |  |

[0001628280-24-022282:notes:86]
[same as prior period, unchanged from 0001628280-23-038311:notes:88]

[0001628280-24-022282:notes:87]
In January 2021, the Company granted warrants (the “Finback Common Stock Warrants”) to purchase 2,552,913 shares of the Company's Class A common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC (“Finback”), a consulting group affiliated with one of the Company's stockholders. The Finback Common Stock Warrants vest upon meeting certain sales criteria as defined in a business development agreement (the “Finback BDA”), which had a term of 3 years. The Finback BDA expired on January 1, 2023 but included a 1-year “tail period” expiring on January 1, 2024. During the tail period, the Finback Common Stock Warrants continued to vest related to any sale consummated by the Company for which it was determined Finback provided services prior to January 1, 2023 in furtherance of the sale.

[0001628280-24-022282:notes:88]
The Finback Common Stock Warrants expire in January 2031. The Finback Common Stock Warrants are accounted for under ASC 718 Compensation – Stock Compensation as the warrants vest upon certain performance conditions being met.

[0001628280-24-022282:notes:89]
As of March 31, 2024, 117,423 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $0.5 million, and there were no Finback Common Stock Warrants that are unvested, given the expiration of the 1-year tail period on January 1, 2024. The Company recognizes compensation expense for the Finback Common Stock Warrants when the warrants vest based on meeting the specified sales criteria. During the three months ended March 31, 2024, there was no stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants. During the three months ended March 31, 2023, the Company recorded $0.6 million of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants.

[0001628280-24-022282:notes:90]
[same as prior period, unchanged from 0001628280-23-038311:notes:91]

[0001628280-24-022282:notes:91]
[same as prior period, unchanged from 0001628280-23-038311:notes:92]

[0001628280-24-022282:notes:92]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Cost of revenue | $ | 138 |  | $ | 145 |  |  |  |  |
| Research and development | 882 |  | 837 |  |  |  |  |
| Sales and marketing | 2,959 |  | 1,998 |  |  |  |  |
| General and administrative | 2,431 |  | 2,063 |  |  |  |  |
| Total stock-based compensation expense | $ | 6,410 |  | $ | 5,043 |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-24-022282:notes:93]
Income Taxes
There is no provision for income taxes for the three months ended March 31, 2024 and 2023 because the Company has historically incurred net operating losses and maintains a full valuation allowance against its deferred tax assets.

[0001628280-24-022282:notes:94]
[same as prior period, unchanged from 0001628280-23-038311:notes:95]


## us-gaap:EarningsPerShareTextBlock

[0001628280-24-022282:notes:95]
Net Loss per Share
Basic and diluted net loss per share attributable to common stockholders are calculated as follows (in thousands, except share and per share amounts):

[0001628280-24-022282:notes:96]
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net loss attributable to common stockholders – basic and diluted | $ | (11,644) |  | $ | (28,609) |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 153,076,719 |  |  | 146,433,378 |  |  |  |  |  |
| Net loss per share attributable to common stockholders – basic and diluted | $ | (0.08) |  |  | $ | (0.20) |  |  |  |  |  |

[0001628280-24-022282:notes:97]
[same as prior period, unchanged from 0001628280-23-038311:notes:98]

[0001628280-24-022282:notes:98]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Options issued and outstanding | 22,522,005 |  |  | 23,136,658 |  |  |  |  |  |
| Public Warrants to purchase common stock | 14,324,893 |  |  | 14,324,994 |  |  |  |  |  |
| Warrants to purchase common stock (Finback) | 117,423 |  |  | 1,590,984 |  |  |  |  |  |
| Unvested restricted stock units | 16,460,035 |  |  | 12,395,533 |  |  |  |  |  |
| Unvested performance stock units | — |  |  | 414,500 |  |  |  |  |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |  |  |  |  |
| Contingently issuable common stock* | 1,897,500 |  |  | 1,897,500 |  |  |  |  |  |
|  | 70,321,856 |  |  | 68,760,169 |  |  |  |  |  |

[0001628280-24-022282:notes:99]
*Issuance of Earn-out shares and Contingently issuable common stock is contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-24-022282:notes:100]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola

[0001628280-24-022282:notes:101]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended March 31, 2024 and 2023, revenue from Motorola's distributor services was $1.9 million and $3.2 million, respectively. As of March 31, 2024 and December 31, 2023, accounts receivable related to Motorola’s distributor services was $2.1 million and $1.2 million, respectively.

[0001628280-24-022282:notes:102]
Reseller Agreement with Stanley Black & Decker
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB (“Securitas”) in 2023. Securitas, directly or through its affiliates, resells the Company's products. Effective in the first fiscal quarter of 2024, while the reseller agreement is still in effect, Securitas is no longer considered a related party. During the three months ended March 31, 2023, revenue from Securitas' reseller services was $0.4 million. As of December 31, 2023, accounts receivable related to Securitas' reseller services was $0.6 million.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-24-022282:notes:103]
Commitments and Contingencies
Indemnification Agreements

[0001628280-24-022282:notes:104]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is

[0001628280-24-022282:notes:105]
not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of March 31, 2024 or December 31, 2023.

[0001628280-24-022282:notes:106]
Legal Proceedings

[0001628280-24-022282:notes:107]
We are from time to time subject to various claims, lawsuits, and other legal and administrative proceedings arising in the ordinary course of business.

[0001628280-24-022282:notes:108]
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.

[0001628280-24-022282:notes:109]
The Company has identified certain claims as a result of which a loss may be incurred, but in the aggregate any loss is expected to be immaterial. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. Based upon information presently known to management, the Company has not accrued a loss for these matters, including the matter described below, as a loss is not probable and reasonably estimable. While it is reasonably possible a loss may be incurred, the Company is unable to estimate a loss or range of loss in these matters. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

[0001628280-24-022282:notes:110]
In March 2024, an Evolv shareholder filed in the U.S. District Court for the District of Massachusetts a putative class action lawsuit, captioned Raby v. Evolv Technologies Holdings, Inc., et al. case number 1:24-cv-10761, alleging that Evolv and certain of its current and former executives and other individuals violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 based on alleged misstatements concerning the Company’s products. This litigation is in the preliminary stages, and the outcome of any complex legal proceeding is inherently unpredictable and subject to significant uncertainties.

[0001628280-24-022282:notes:111]
Regulatory and Governmental Matters

[0001628280-24-022282:notes:112]
In the ordinary course of business, the Company is subject to regulatory and governmental examinations, information gathering requests, inquiries, and investigations. The U.S. Federal Trade Commission (“FTC”) has requested information about certain aspects of the Company's marketing practices. The Company is cooperating with the investigation and has provided documentation and information responsive to the FTC inquiry. Further, in February 2024, we received a subpoena from the SEC, Division of Enforcement, requesting that we produce certain documents and information. We are cooperating and intend to continue to cooperate with the SEC's investigation.

[0001628280-24-022282:notes:113]
Any resolution or litigation with the FTC, the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on us and/or require us to make changes to our business practices. These costs and requirements may be material both individually and in the aggregate.

[0001628280-24-022282:notes:114]
We can offer no assurances as to the outcome of these investigations or their potential effect, if any, on us or our results of operations. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-24-022282:notes:115]
On March 14, 2024, Merline Saintil, a member of our Board of Directors, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the sale of 30% of the net shares of the Company’s common stock underlying 25,846 restricted stock units. The trading arrangement is scheduled to expire on the earlier of July 31, 2024 or the date that all transactions under the trading arrangement are completed.
