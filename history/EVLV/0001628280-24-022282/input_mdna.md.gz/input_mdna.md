# EVLV MD&A — 0001628280-24-022282


## mdna

[0001628280-24-022282:mdna:1]
[same as prior period, unchanged from 0001628280-23-038311:mdna:1]

[0001628280-24-022282:mdna:2]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of our business combination (the "Merger") and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001628280-24-022282:mdna:3]
[same as prior period, unchanged from 0001628280-23-038311:mdna:4]

[0001628280-24-022282:mdna:4]
[same as prior period, unchanged from 0001628280-23-038311:mdna:5]

[0001628280-24-022282:mdna:5]
Our products have screened over 1.3 billion visitors worldwide since our inception. We believe that we have screened more people through advanced systems than any organization other than the United States Transportation Security Administration (“TSA”). Our customers include many iconic venues across a wide variety of industries, including major sports stadiums and arenas, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, hospitals, large industrial workplaces, schools, and prominent houses of worship. We offer our products for lease or purchase and primarily under a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue, and creates expansion and upsell opportunities.

[0001628280-24-022282:mdna:6]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $21.7 million and $18.6 million for the three months ended March 31, 2024 and 2023, respectively. We generated a net loss of $11.6 million and $28.6 million for the three months ended March 31, 2024 and 2023, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-24-022282:mdna:7]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations, and if necessary, debt financings. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources.” Additionally, as discussed in Note 14 (Commitments and Contingencies) to our condensed consolidated financial statements for the three months ended March 31, 2024, certain legal proceedings, including government investigations, have been initiated involving us. Given the uncertainty and the preliminary stage of such matters, no assurance can be given regarding the outcome of such matters and we are unable at this time to give an estimate of the amount or range of potential loss, if any, which might result to the Company if the outcome in such matters was unfavorable.

[0001628280-24-022282:mdna:8]
[same as prior period, unchanged from 0001628280-23-038311:mdna:9]

[0001628280-24-022282:mdna:9]
[same as prior period, unchanged from 0001628280-23-038311:mdna:11]

[0001628280-24-022282:mdna:10]
We believe that our performance and future success depend on many factors that present significant opportunities for us but also pose risks and challenges, including those discussed below and in the “Risk Factors” section of our 2023 Form 10-K.

[0001628280-24-022282:mdna:11]
[same as prior period, unchanged from 0001628280-23-038311:mdna:13]

[0001628280-24-022282:mdna:12]
We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of rising inflation and interest rates on business spending; supply chain issues and the impacts on our manufacturing capabilities; public health emergencies; geopolitical conflicts and war, including the conflicts in Europe and the Middle East; and recessionary trends. See the risk factor titled “Downturns in general economic and market conditions and reductions in spending may reduce demand for our products and services and may impact third parties on which we rely, which could harm our revenue, results of operations, and cash flows, and could make it difficult to predict revenue for a particular period” in Item 1A of our 2023 Form 10-K. While these factors continue to evolve, we plan to remain flexible and to optimize our business as appropriate and allocate resources, as necessary.

[0001628280-24-022282:mdna:13]
[same as prior period, unchanged from 0001628280-23-038311:mdna:15]

[0001628280-24-022282:mdna:14]
We believe the world will continue to focus on the safety and security of people in the places where they gather. Many of these locations, such as professional sports venues, educational institutions, and healthcare facilities, are moving toward a more frictionless security screening experience. We are well-positioned to take advantage of this opportunity due to our proprietary technologies and distribution capabilities. Our products are designed to empower venues and facilities to realize the full benefits of touchless security screening, including a rapid visitor throughput and minimal security staff to screened visitor physical contact. We expect that our results of operations, including revenue, will fluctuate for the foreseeable future as venues and facilities continue to shift away from conventional security screening processes towards touchless security screening or consider security screening processes for the first time. The degree to which potential and current customers recognize these benefits and invest in our products will affect our financial results.

[0001628280-24-022282:mdna:15]
[same as prior period, unchanged from 0001628280-23-038311:mdna:17]

[0001628280-24-022282:mdna:16]
We sell our solutions under two primary sales models. We offer a “pure subscription” model, where the customer leases hardware from us and we provide a multi-year security-as-a-service subscription. For end-user customers that prefer to purchase our hardware outright, we offer our “distributor licensing” model based on the Distribution and License Agreement we entered into with Columbia Electrical Contractors, Inc. (“Columbia Tech”) in March of 2023. Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, currently serves as our primary contract manufacturer. Under this arrangement, we have granted a license of our intellectual property to Columbia Tech, which contracts directly with certain of our resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment. Columbia Tech pays us a hardware license fee for each system it manufactures and sells under this agreement. In these instances, we still contract directly with the reseller to provide a multi-year security-as-a-service subscription to the end-users.

[0001628280-24-022282:mdna:17]
We also have historically sold our systems under a purchase subscription model, where customers purchase the hardware from us, and we provide a multi-year security-as-a-service subscription. However, we do not plan to offer this sales model in future periods to our existing or new customers, except in limited circumstances.

[0001628280-24-022282:mdna:18]
Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions, primarily within the United States. Pricing may vary by region or vertical market due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales, bookings, and business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products to our customers.

[0001628280-24-022282:mdna:19]
[same as prior period, unchanged from 0001628280-23-038311:mdna:21]

[0001628280-24-022282:mdna:20]
We are a leader in AI-based weapons detection for security screening, offering transformative technologies that enable higher throughput, a more frictionless visitor experience, and substantial cost savings through our product innovations. Our performance is significantly dependent on the investment we make in our research and development

[0001628280-24-022282:mdna:21]
efforts and on our ability to be at the forefront of the security screening industry. It is essential that we continually identify and respond to rapidly evolving customer requirements, develop, and introduce innovative new products, enhance existing products and generate customer demand for our products. We believe that investment in our security screening products will contribute to long-term revenue growth, however the incurrence of research and development costs will impact our near-term profitability.

[0001628280-24-022282:mdna:22]
[same as prior period, unchanged from 0001628280-23-038311:mdna:23]

[0001628280-24-022282:mdna:23]
[same as prior period, unchanged from 0001628280-23-038311:mdna:24]

[0001628280-24-022282:mdna:24]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement, (4) license fees related to the Distribution and License Agreement, and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax.

[0001628280-24-022282:mdna:25]
[same as prior period, unchanged from 0001628280-23-038311:mdna:26]

[0001628280-24-022282:mdna:26]
We derive a portion of our revenue from the sale of our Evolv Express equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We expect product revenue to continue declining as a percentage of our overall revenue as we continue focusing our go-to-market strategy on our pure subscription and distributor licensing sales models.

[0001628280-24-022282:mdna:27]
[same as prior period, unchanged from 0001628280-23-038311:mdna:28]

[0001628280-24-022282:mdna:28]
Subscription revenue consists of revenue derived from leasing Evolv Express units to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001628280-24-022282:mdna:29]
Lease arrangements generally include both lease and non-lease components. The non-lease components relate to (1) distinct services, including professional services, SaaS, and maintenance, and (2) any add-on accessories. Professional services are included in license fees and other revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive loss.

[0001628280-24-022282:mdna:30]
[same as prior period, unchanged from 0001628280-23-038311:mdna:85]

[0001628280-24-022282:mdna:31]
Service revenue consists of subscription-based SaaS and maintenance revenue related to Evolv Express units sold to customers. Customers generally pay either a quarterly or annual fixed payment for SaaS and maintenance. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically four years.

[0001628280-24-022282:mdna:32]
License Fee and Other Revenue

[0001628280-24-022282:mdna:33]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from Columbia Tech to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration. Revenue for professional services and other one-time revenue, which had previously been included in service revenue, has been reclassified for prior periods to License fee and other revenue on the consolidated statements of operations and comprehensive loss.

[0001628280-24-022282:mdna:34]
[same as prior period, unchanged from 0001628280-23-038311:mdna:33]

[0001628280-24-022282:mdna:35]
[same as prior period, unchanged from 0001628280-23-038311:mdna:34]

[0001628280-24-022282:mdna:36]
3

[0001628280-24-022282:mdna:37]
[same as prior period, unchanged from 0001628280-23-038311:mdna:35]

[0001628280-24-022282:mdna:38]
Cost of product revenue consists primarily of costs paid to our third-party manufacturer and other suppliers, labor costs (including stock-based compensation), and shipping costs.

[0001628280-24-022282:mdna:39]
[same as prior period, unchanged from 0001628280-23-038311:mdna:37]

[0001628280-24-022282:mdna:40]
[same as prior period, unchanged from 0001628280-23-038311:mdna:38]

[0001628280-24-022282:mdna:41]
Cost of Service Revenue

[0001628280-24-022282:mdna:42]
Cost of services revenue consists of maintenance costs related to units purchased by customers and an allocated portion of internal-use software amortization expense. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, field service repair costs, equipment, and supplies.

[0001628280-24-022282:mdna:43]
Cost of License Fee and Other Revenue

[0001628280-24-022282:mdna:44]
Cost of license fees and other revenue consists primarily of internal and third-party costs related to professional services, such as installation, training, and event support.

[0001628280-24-022282:mdna:45]
[same as prior period, unchanged from 0001628280-23-038311:mdna:41]

[0001628280-24-022282:mdna:46]
[same as prior period, unchanged from 0001628280-23-038311:mdna:42]

[0001628280-24-022282:mdna:47]
[same as prior period, unchanged from 0001628280-23-038311:mdna:43]

[0001628280-24-022282:mdna:48]
[same as prior period, unchanged from 0001628280-23-038311:mdna:44]

[0001628280-24-022282:mdna:49]
•Mix of sales between our pure subscription, purchase subscription, and distributor licensing sales models;

[0001628280-24-022282:mdna:50]
[same as prior period, unchanged from 0001628280-23-038311:mdna:46]

[0001628280-24-022282:mdna:51]
•Our ability to maintain our costs on the components that go into the manufacture of our products; and

[0001628280-24-022282:mdna:52]
[same as prior period, unchanged from 0001628280-23-038311:mdna:48]

[0001628280-24-022282:mdna:53]
[same as prior period, unchanged from 0001628280-23-038311:mdna:49]

[0001628280-24-022282:mdna:54]
[same as prior period, unchanged from 0001628280-23-038311:mdna:50]

[0001628280-24-022282:mdna:55]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, stock-based compensation, prototypes, design expenses, and consulting and contractor costs. We expect research and development costs will increase for the year ending December 31, 2024 compared to the year ended December 31, 2023 primarily due to incremental investments in headcount and programs we are making to support our new product development efforts.

[0001628280-24-022282:mdna:56]
[same as prior period, unchanged from 0001628280-23-038311:mdna:52]

[0001628280-24-022282:mdna:57]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success, business development, and strategy functions, as well as costs related to trade shows and

[0001628280-24-022282:mdna:58]
4

[0001628280-24-022282:mdna:59]
events, and stock-based compensation. We expect our sales and marketing costs will increase for the year ending December 31, 2024 compared to the year ended December 31, 2023 primarily due to an expected increase in customer facing headcount to support higher sales volume.

[0001628280-24-022282:mdna:60]
[same as prior period, unchanged from 0001628280-23-038311:mdna:54]

[0001628280-24-022282:mdna:61]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and insurance. We expect our general and administrative expenses will remain relatively consistent for the year ending December 31, 2024 compared to the year ended December 31, 2023 as we look to leverage previous investments made in people and processes. Our general and administrative expenses may be impacted by regulatory compliance costs related to the ongoing FTC and SEC matters.

[0001628280-24-022282:mdna:62]
[same as prior period, unchanged from 0001628280-23-038311:mdna:56]

[0001628280-24-022282:mdna:63]
Loss from impairment of property and equipment relates to (i) leased Evolv Edge units and Evolv Express prototype units that are removed from service and retired as we transition our domestic customers to our most current Evolv Express units and (ii) damaged or destroyed leased units.

[0001628280-24-022282:mdna:64]
[same as prior period, unchanged from 0001628280-23-038311:mdna:58]

[0001628280-24-022282:mdna:65]
[same as prior period, unchanged from 0001628280-23-038311:mdna:59]

[0001628280-24-022282:mdna:66]
[same as prior period, unchanged from 0001628280-23-038311:mdna:60]

[0001628280-24-022282:mdna:67]
Interest income relates to interest earned on money market funds and treasury bills, and interest earned on our lease receivables for our Evolv Express units recognized as sales-type leases.

[0001628280-24-022282:mdna:68]
Loss on Extinguishment of Debt

[0001628280-24-022282:mdna:69]
In December 2022, the Company entered into a loan and security agreement (the “2022 SVB Credit Agreement”) with Silicon Valley Bank (“SVB”) in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. In light of the foregoing, the Company terminated the 2022 SVB Credit Agreement on March 31, 2023. As a result of the termination of the SVB Credit Agreement, the Company incurred a loss on extinguishment of debt.

[0001628280-24-022282:mdna:70]
[same as prior period, unchanged from 0001628280-23-038311:mdna:62]

[0001628280-24-022282:mdna:71]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders are entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001628280-24-022282:mdna:72]
[same as prior period, unchanged from 0001628280-23-038311:mdna:64]

[0001628280-24-022282:mdna:73]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock, referred to as Founder Shares. Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 1,897,500 Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones, and 517,500 Founder Shares were contributed to Give Evolv LLC. The 1,897,500 outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001628280-24-022282:mdna:74]
[same as prior period, unchanged from 0001628280-23-038311:mdna:66]

[0001628280-24-022282:mdna:75]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are currently exercisable and expire in July 2026. We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss with the offset to additional paid-in capital.

[0001628280-24-022282:mdna:76]
[same as prior period, unchanged from 0001628280-23-038311:mdna:68]

[0001628280-24-022282:mdna:77]
Our income tax provision consists of an estimate for federal, state, and foreign income taxes based on enacted rates in the jurisdictions in which we operate, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. We have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets.

[0001628280-24-022282:mdna:78]
Reclassification

[0001628280-24-022282:mdna:79]
During the year ended December 31, 2023, the Company began classifying revenue from professional services, which includes installation, training, and event support, as well as one-time revenue within license fee and other revenue on the consolidated statements of operations and comprehensive loss, whereas the revenue for these services has previously been included in service revenue. Correspondingly, the Company began classifying costs associated with professional services within cost of license fee and other revenue, whereas these costs were previously included in cost of service revenue. These reclassifications were made to align the presentation of professional services with the Company's internal reporting and analysis.

[0001628280-24-022282:mdna:80]
[same as prior period, unchanged from 0001628280-23-038311:mdna:70]

[0001628280-24-022282:mdna:81]
Comparison of the Three Months Ended March 31, 2024 and 2023

[0001628280-24-022282:mdna:82]
The following table summarizes our results of operations for the three months ended March 31, 2024 and 2023 (in thousands):

[0001628280-24-022282:mdna:83]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 603 |  |  | $ | 8,754 |  |  | $ | (8,151) |  |  | (93) | % |
| Subscription revenue | 14,503 |  |  | 6,466 |  |  | 8,037 |  |  | 124 |  |
| Service revenue | 5,384 |  |  | 2,786 |  |  | 2,598 |  |  | 93 |  |
| License fee and other revenue | 1,178 |  |  | 575 |  |  | 603 |  |  | 105 |  |
| Total revenue | 21,668 |  |  | 18,581 |  |  | 3,087 |  |  | 17 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 2,777 |  |  | 10,578 |  |  | (7,801) |  |  | (74) |  |
| Cost of subscription revenue | 5,779 |  |  | 2,351 |  |  | 3,428 |  |  | 146 |  |
| Cost of service revenue | 1,211 |  |  | 583 |  |  | 628 |  |  | 108 |  |
| Cost of license fee and other revenue | 129 |  |  | 304 |  |  | (175) |  |  | (58) |  |
| Total cost of revenue | 9,896 |  |  | 13,816 |  |  | (3,920) |  |  | (28) |  |
| Gross profit | 11,772 |  |  | 4,765 |  |  | 7,007 |  |  | 147 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,205 |  |  | 5,389 |  |  | 816 |  |  | 15 |  |
| Sales and marketing | 16,005 |  |  | 12,804 |  |  | 3,201 |  |  | 25 |  |
| General and administrative | 11,840 |  |  | 8,926 |  |  | 2,914 |  |  | 33 |  |
| Loss from impairment of property and equipment | — |  |  | 137 |  |  | (137) |  |  | (100) |  |
| Total operating expenses | 34,050 |  |  | 27,256 |  |  | 6,794 |  |  | 25 |  |
| Loss from operations | (22,278) |  |  | (22,491) |  |  | 213 |  |  | 1 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (654) |  |  | 654 |  |  | 100 |  |
| Interest income | 1,085 |  |  | 953 |  |  | 132 |  |  | 14 |  |
| Other income (expense), net | (28) |  |  | 19 |  |  | (47) |  |  | (247) |  |
| Loss on extinguishment of debt | — |  |  | (626) |  |  | 626 |  |  | 100 |  |
| Change in fair value of contingent earn-out liability | 6,899 |  |  | (3,318) |  |  | 10,217 |  |  | 308 |  |
| Change in fair value of contingently issuable common stock liability | 527 |  |  | (742) |  |  | 1,269 |  |  | 171 |  |
| Change in fair value of public warrant liability | 2,151 |  |  | (1,750) |  |  | 3,901 |  |  | 223 |  |
| Total other income (expense), net | 10,634 |  |  | (6,118) |  |  | 16,752 |  |  | 274 |  |
| Net loss | $ | (11,644) |  |  | $ | (28,609) |  |  | $ | 16,965 |  |  | 59 | % |

[0001628280-24-022282:mdna:84]
[same as prior period, unchanged from 0001628280-23-038311:mdna:83]

[0001628280-24-022282:mdna:85]
[same as prior period, unchanged from 0001628280-23-038311:mdna:75]

[0001628280-24-022282:mdna:86]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 53 new customers during the three months ended March 31, 2024 and 61 new customers during the three months ended March 31, 2023, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-24-022282:mdna:87]
Our average sales cycle increased to five months during the first fiscal quarter of 2024 compared to three months during the first fiscal quarter of 2023, an increase of approximately 40%. We believe the FTC and SEC investigations have been the primary reason for the lengthening of the sales cycle as customers work to satisfy incremental due diligence requirements. Our sales cycle may continue to be extended until the investigations are resolved. However, the investigations do not appear to be impacting our win rate, which has increased year over year.

[0001628280-24-022282:mdna:88]
[same as prior period, unchanged from 0001628280-23-038311:mdna:77]

[0001628280-24-022282:mdna:89]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Product revenue | $ | 603 |  |  | $ | 8,754 |  |  | $ | (8,151) |  |  | (93) | % |
| Cost of product revenue | $ | 2,777 |  |  | $ | 10,578 |  |  | $ | (7,801) |  |  | (74) | % |
| Gross profit - Product revenue | $ | (2,174) |  |  | $ | (1,824) |  |  | $ | (350) |  |  | (19) | % |
| Gross profit margin - Product revenue | (361) | % |  | (21) | % |  | N/A |  | (340) | % |

[0001628280-24-022282:mdna:90]
The decreases in product revenue and cost of product revenue are primarily due to a continued transition to pure subscription sales and sales under our distributor model during the preceding twelve months. The decrease in product gross profit margin for the three months ended March 31, 2024 compared to the prior year period is primarily attributable to $0.7 million of expense related to an increase to our inventory reserve and $1.2 million of expense associated with adverse non-cancellable inventory purchase commitments, both of which relate primarily to the ongoing transition of our manufacturing operations to the next generation of Evolv Express systems and the determination that certain components within our legacy systems will not be used in the next generation systems.

[0001628280-24-022282:mdna:91]
[same as prior period, unchanged from 0001628280-23-038311:mdna:80]

[0001628280-24-022282:mdna:92]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Subscription revenue | $ | 14,503 |  |  | $ | 6,466 |  |  | $ | 8,037 |  |  | 124 | % |
| Cost of subscription revenue | $ | 5,779 |  |  | $ | 2,351 |  |  | $ | 3,428 |  |  | 146 | % |
| Gross profit - Subscription revenue | $ | 8,724 |  |  | $ | 4,115 |  |  | $ | 4,609 |  |  | 112 | % |
| Gross profit margin - Subscription revenue | 60 | % |  | 64 | % |  | N/A |  | (3) | % |

[0001628280-24-022282:mdna:93]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base for the three months ended March 31, 2024 compared to the prior year period, which was

[0001628280-24-022282:mdna:94]
due to a transition to our pure subscription model and a higher number of active Evolv Express units deployed under our pure subscription contract model.

[0001628280-24-022282:mdna:95]
[same as prior period, unchanged from 0001628280-23-038311:mdna:125]

[0001628280-24-022282:mdna:96]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Service revenue | $ | 5,384 |  |  | $ | 2,786 |  |  | $ | 2,598 |  |  | 93 | % |
| Cost of service revenue | $ | 1,211 |  |  | $ | 583 |  |  | $ | 628 |  |  | 108 | % |
| Gross profit - Service revenue | $ | 4,173 |  |  | $ | 2,203 |  |  | $ | 1,970 |  |  | 89 | % |
| Gross profit margin - Service revenue | 78 | % |  | 79 | % |  | N/A |  | (2) | % |

[0001628280-24-022282:mdna:97]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech, for the three months ended March 31, 2024 compared to the prior year period.

[0001628280-24-022282:mdna:98]
[same as prior period, unchanged from 0001628280-23-038311:mdna:88]

[0001628280-24-022282:mdna:99]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| License fee and other revenue | $ | 1,178 |  |  | $ | 575 |  |  | $ | 603 |  |  | 105 | % |
| Cost of license fee and other revenue | $ | 129 |  |  | $ | 304 |  |  | $ | (175) |  |  | (58) | % |
| Gross profit - License fee and other revenue | $ | 1,049 |  |  | $ | 271 |  |  | $ | 778 |  |  | 287 | % |
| Gross profit margin - License fee and other revenue | 89 | % |  | 47 | % |  | N/A |  | 42 | % |

[0001628280-24-022282:mdna:100]
The increase in license fee and other revenue, gross profit, and gross profit margin was primarily driven by $0.7 million of license fees earned during the three months ended March 31, 2024 compared to no license fees earned during the prior year period under the Distribution and License Agreement which was executed in March 2023. Revenue from install, training, and professional services was $0.5 million for the three months ended March 31, 2024 compared to $0.6 million for the prior year period.

[0001628280-24-022282:mdna:101]
[same as prior period, unchanged from 0001628280-23-038311:mdna:90]

[0001628280-24-022282:mdna:102]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 3,987 |  |  | $ | 3,847 |  |  | $ | 140 |  |  | 4 | % |
| Materials and prototypes | 839 |  |  | 358 |  |  | 481 |  |  | 134 | % |
| Professional fees | 917 |  |  | 999 |  |  | (82) |  |  | (8) | % |
| Other | 462 |  |  | 185 |  |  | 277 |  |  | 150 | % |
|  | $ | 6,205 |  |  | $ | 5,389 |  |  | $ | 816 |  |  | 15 | % |

[0001628280-24-022282:mdna:103]
The increase in personnel related expenses is due to an increase in payroll costs primarily resulting from new hires in our research and development function during the past twelve months, offset by a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased. Stock compensation expense included in research and development expenses was $0.9 million for the three months ended March 31, 2024 compared to $0.8 million for the three months ended March 31, 2023. The increase in materials and prototypes expense is due to increased design and engineering costs related to the development of the next generation of our Evolv Express system. The decrease in professional fees primarily relates to higher amount of costs capitalized related to internal-use software and software embedded in products to be sold or leased, offset by consulting costs incurred for product development and engineering. The increase in other expense primarily relates to an increase in IT and software subscription costs.

[0001628280-24-022282:mdna:104]
[same as prior period, unchanged from 0001628280-23-038311:mdna:93]

[0001628280-24-022282:mdna:105]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 11,992 |  |  | $ | 9,449 |  |  | $ | 2,543 |  |  | 27 | % |
| Advertising and direct marketing | 810 |  |  | 1,215 |  |  | (405) |  |  | (33) | % |
| Travel and entertainment | 1,270 |  |  | 890 |  |  | 380 |  |  | 43 | % |
| Professional fees | 959 |  |  | 525 |  |  | 434 |  |  | 83 | % |
| Other | 974 |  |  | 725 |  |  | 249 |  |  | 34 | % |
|  | $ | 16,005 |  |  | $ | 12,804 |  |  | $ | 3,201 |  |  | 25 | % |

[0001628280-24-022282:mdna:106]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increased sales volume. Stock compensation expense included in sales and marketing expenses was $3.0 million for the three months ended March 31, 2024 compared to $2.0 million for the three months ended March 31, 2023. The decrease in advertising and direct marketing expense is primarily due to a decrease in expense related to trade shows and events. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings. Professional fees increased due primarily to an increase in marketing consulting costs. Other expense increased primarily due to increases in IT and software subscription costs and shipping costs related to demo units.

[0001628280-24-022282:mdna:107]
[same as prior period, unchanged from 0001628280-23-038311:mdna:96]

[0001628280-24-022282:mdna:108]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 6,238 |  |  | $ | 5,060 |  |  | $ | 1,178 |  |  | 23 | % |
| Professional fees | 2,546 |  |  | 1,405 |  |  | 1,141 |  |  | 81 | % |
| Insurance costs | 742 |  |  | 973 |  |  | (231) |  |  | (24) | % |
| Other | 2,314 |  |  | 1,488 |  |  | 826 |  |  | 56 | % |
|  | $ | 11,840 |  |  | $ | 8,926 |  |  | $ | 2,914 |  |  | 33 | % |

[0001628280-24-022282:mdna:109]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $2.4 million for the three months ended March 31, 2024 compared to $2.1 million for the three months ended March 31, 2023. The increase in professional fees was primarily related to an increase in outsourced accounting consultancy and audit fees. The decrease in insurance costs was primarily related to a decrease in director and officer insurance premiums. Other expense increased primarily due to $0.5 million of certain one-time expenses incurred during the three months ended March 31, 2024, as well as increases in rent, IT and software subscription costs, and property taxes.

[0001628280-24-022282:mdna:110]
[same as prior period, unchanged from 0001628280-23-038311:mdna:99]

[0001628280-24-022282:mdna:111]
No loss from impairment of property and equipment was recognized for the three months ended March 31, 2024, compared to $0.1 million for the three months ended March 31, 2023, primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in impairment of the remaining economic value of such units.

[0001628280-24-022282:mdna:112]
[same as prior period, unchanged from 0001628280-23-038311:mdna:101]

[0001628280-24-022282:mdna:113]
No interest expense was recognized for the three months ended March 31, 2024, compared to $0.7 million for the three months ended March 31, 2023. During March 2023, the Company fully repaid all borrowings and accrued interest under its term loans with Silicon Valley Bank (“SVB”) pursuant to a loan and security agreement entered into in December 2022 (the “2022 SVB Credit Agreement”).

[0001628280-24-022282:mdna:114]
[same as prior period, unchanged from 0001628280-23-038311:mdna:104]

[0001628280-24-022282:mdna:115]
Interest income of $1.1 million for the three months ended March 31, 2024 and $1.0 million for the three months ended March 31, 2023 related primarily to interest earned on money market funds, and for the three months ended March 31, 2024, accretion of discounts on treasury bills.

[0001628280-24-022282:mdna:116]
[same as prior period, unchanged from 0001628280-23-038311:mdna:106]

[0001628280-24-022282:mdna:117]
Change in the fair value of the contingent earn-out liability resulted in a $6.9 million gain and $3.3 million loss for the three months ended March 31, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-24-022282:mdna:118]
[same as prior period, unchanged from 0001628280-23-038311:mdna:108]

[0001628280-24-022282:mdna:119]
Change in the fair value of the contingently issuable common stock liability resulted in a $0.5 million gain and $0.7 million loss for the three months ended March 31, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-24-022282:mdna:120]
[same as prior period, unchanged from 0001628280-23-038311:mdna:110]

[0001628280-24-022282:mdna:121]
Change in the fair value of the public warrant liability resulted in a $2.2 million gain and a $1.8 million loss for the three months ended March 31, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-24-022282:mdna:122]
[same as prior period, unchanged from 0001628280-23-038311:mdna:154]

[0001628280-24-022282:mdna:123]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. As of March 31, 2024, we had $81.0 million in cash, cash equivalents, and marketable securities. We incurred a net loss of $11.6 million and $28.6 million for the three months ended March 31, 2024 and 2023, respectively. We incurred cash outflows from operating activities of $16.1 million and $3.4 million during the three months ended March 31, 2024 and 2023, respectively.

[0001628280-24-022282:mdna:124]
We maintain substantially all of our cash, cash equivalents, and marketable securities in accounts with U.S. and multi-national financial institutions and our cash deposits at these institutions exceed Federal Deposit Insurance Corporation insured limits. The Company does not believe it is exposed to any unusual credit risk or deposit concentration risk beyond the ordinary credit risk associated with commercial banking relationships.

[0001628280-24-022282:mdna:125]
We expect our cash, cash equivalents, and marketable securities, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our sales and marketing team. We may require additional capital to respond to the expected growth in the demand for equipment purchases to support our “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances and in either the short-term or long-term may determine to engage in debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001628280-24-022282:mdna:126]
[same as prior period, unchanged from 0001628280-23-038311:mdna:158]

[0001628280-24-022282:mdna:127]
During March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. The Company has no debt outstanding as of March 31, 2024.

[0001628280-24-022282:mdna:128]
[same as prior period, unchanged from 0001628280-23-038311:mdna:160]

[0001628280-24-022282:mdna:129]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of March 31, 2024. We anticipate fulfilling such commitments with our existing cash, cash equivalents, and marketable securities, as well as cash and cash equivalents obtained through operations and, if necessary, proceeds from long-term debt. Cash, cash equivalents, and marketable securities amounted to $81.0 million as of March 31, 2024.

[0001628280-24-022282:mdna:130]
We are party to a lease agreement for office space at our headquarters in Waltham, MA. During the three months ended March 31, 2024, we amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. We are required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space which is classified as restricted cash, non-current on the condensed consolidated balance sheet as of March 31, 2024. Total future minimum lease payments under this noncancelable operating lease amount to $2.9 million as of March 31, 2024.

[0001628280-24-022282:mdna:131]
[same as prior period, unchanged from 0001628280-23-038311:mdna:163]

[0001628280-24-022282:mdna:132]
[same as prior period, unchanged from 0001628280-23-038311:mdna:164]

[0001628280-24-022282:mdna:133]
|  | Three Months EndedMarch 31, |
|  | 2024 |  | 2023 |
| Net cash used in operating activities | $ | (16,083) |  |  | $ | (3,434) |  |
| Net cash used in investing activities | (6,788) |  |  | (14,038) |  |
| Net cash provided by (used in) financing activities | 302 |  |  | (30,299) |  |
| Effect of exchange rate changes on cash and cash equivalents | 3 |  |  | (16) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (22,566) |  |  | $ | (47,787) |  |

[0001628280-24-022282:mdna:134]
[same as prior period, unchanged from 0001628280-23-038311:mdna:166]

[0001628280-24-022282:mdna:135]
|  | Three Months EndedMarch 31, |
|  | 2024 |  | 2023 |
| Net loss | $ | (11,644) |  |  | $ | (28,609) |  |
| Non-cash expense | 1,653 |  |  | 14,005 |  |
| Changes in operating assets and liabilities | (6,092) |  |  | 11,170 |  |
| Net cash used in operating activities | $ | (16,083) |  |  | $ | (3,434) |  |

[0001628280-24-022282:mdna:136]
Net loss decreased from $28.6 million for the three months ended March 31, 2023 to $11.6 million for the three months ended March 31, 2024 primarily due to changes in the fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability. See "Results of Operations" above for further discussion.

[0001628280-24-022282:mdna:137]
Non-cash expense for the three months ended March 31, 2024 is primarily attributable to $6.4 million of stock-based compensation expense, $3.5 million of depreciation and amortization, and $9.6 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability. Non-cash expense for the three months ended March 31, 2023 is primarily attributable to $5.0 million of stock-based compensation expense, $1.8 million of depreciation and amortization, $0.6 million of loss from extinguishment of debt, and $5.8 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability.

[0001628280-24-022282:mdna:138]
Changes in operating assets and liabilities for the three months ended March 31, 2024 are primarily related to the following:

[0001628280-24-022282:mdna:139]
•$2.1 million increase in inventory primarily due to increased production of units to meet customer demand, offset by a higher proportion of finished goods recorded as property and equipment based on our expectations of the future mix of Evolv Express units to be leased to customers versus sold to customers;

[0001628280-24-022282:mdna:140]
•$3.7 million increase in prepaid expenses and other current assets primarily due to prepaid deposits related to orders placed for Evolv Express units;

[0001628280-24-022282:mdna:141]
•$1.6 million decrease in accrued expenses and other current liabilities primarily due to the payment of 2023 bonuses and commissions during the three months ended March 31, 2024; offset by

[0001628280-24-022282:mdna:142]
•$1.3 million decrease in contract assets related to the timing of billings.

[0001628280-24-022282:mdna:143]
Changes in operating assets and liabilities for the three months ended March 31, 2023 are primarily related to the following:

[0001628280-24-022282:mdna:144]
•$8.6 million decrease in accounts receivable primarily due to increased collections and timing of billings to customers;

[0001628280-24-022282:mdna:145]
•$1.4 million decrease in inventory primarily due to a higher proportion of finished goods recorded as property and equipment based on our expectations of the future mix of Evolv Express units to be leased to customers versus sold to customers;

[0001628280-24-022282:mdna:146]
•$8.8 million increase in deferred revenue due to a higher volume of sales; offset by

[0001628280-24-022282:mdna:147]
•$2.2 million decrease in accounts payable (excluding the non-cash change in capital expenditures incurred but not yet paid from December 31, 2022 to March 31, 2023) primarily due to a decrease in inventory; and

[0001628280-24-022282:mdna:148]
•$4.6 million decrease in accrued expenses and other current liabilities primarily due to the payment of 2022 compensation, bonuses, and commissions during the three months ended March 31, 2023.

[0001628280-24-022282:mdna:149]
[same as prior period, unchanged from 0001628280-23-038311:mdna:180]

[0001628280-24-022282:mdna:150]
During the three months ended March 31, 2024, cash used in investing activities was $6.8 million, consisting of $19.7 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers and $1.8 million for the development of internal-use software and software embedded in products to be sold or leased, offset by a net $14.7 million inflow related to purchases and redemptions of marketable securities.

[0001628280-24-022282:mdna:151]
During the three months ended March 31, 2023, cash used in investing activities was $14.0 million, consisting primarily of $13.4 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers, and $0.7 million for the development of internal-use software.

[0001628280-24-022282:mdna:152]
[same as prior period, unchanged from 0001628280-23-038311:mdna:183]

[0001628280-24-022282:mdna:153]
During the three months ended March 31, 2024, cash used in financing activities was $0.3 million, consisting of $0.3 million of proceeds from the exercise of stock options.

[0001628280-24-022282:mdna:154]
During the three months ended March 31, 2023, cash used in financing activities was $30.3 million, consisting of $1.9 million of proceeds under the 2022 SVB Credit Agreement, offset by $31.9 million related to the full repayment of amounts owed under the 2022 SVB Credit Agreement and $0.3 million payment of debt issuance costs and a prepayment penalty.

[0001628280-24-022282:mdna:155]
[same as prior period, unchanged from 0001628280-23-038311:mdna:186]

[0001628280-24-022282:mdna:156]
There were no new accounting pronouncements that were issued or became effective since the issuance of the 2023 Form 10-K that had, or are expected to have, a material impact on its consolidated financial position, results of operations or cash flows.

[0001628280-24-022282:mdna:157]
[same as prior period, unchanged from 0001628280-23-038311:mdna:188]

[0001628280-24-022282:mdna:158]
Our critical accounting policies and estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” of the 2023 Form 10-K. There have been no material changes to our critical accounting policies and estimates during the three months ended March 31, 2024.
