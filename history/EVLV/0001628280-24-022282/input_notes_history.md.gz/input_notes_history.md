# EVLV note change history — 0001628280-23-038311 → 0001628280-24-022282


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-09):
[0001628280-24-022282:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is
  (was, 2023-11-09, similarity 0.9042):
[0001628280-23-038311:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of September 30, 2023 or December 31, 2022.

- added (2024-05-09):
[0001628280-24-022282:note_history:2]
not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of March 31, 2024 or December 31, 2023.

- changed (2024-05-09):
[0001628280-24-022282:note_history:3]
Legal Proceedings
  (was, 2023-11-09, similarity 0.6538):
[0001628280-23-038311:note_history:3]
Legal Proceedings and Other Matters

- added (2024-05-09):
[0001628280-24-022282:note_history:4]
We are from time to time subject to various claims, lawsuits, and other legal and administrative proceedings arising in the ordinary course of business.

- changed (2024-05-09):
[0001628280-24-022282:note_history:5]
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.
  (was, 2023-11-09, similarity 0.813):
[0001628280-23-038311:note_history:5]
The Company is not a party to any litigation of a material nature and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.

- added (2024-05-09):
[0001628280-24-022282:note_history:6]
The Company has identified certain claims as a result of which a loss may be incurred, but in the aggregate any loss is expected to be immaterial. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. Based upon information presently known to management, the Company has not accrued a loss for these matters, including the matter described below, as a loss is not probable and reasonably estimable. While it is reasonably possible a loss may be incurred, the Company is unable to estimate a loss or range of loss in these matters. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

- added (2024-05-09):
[0001628280-24-022282:note_history:7]
In March 2024, an Evolv shareholder filed in the U.S. District Court for the District of Massachusetts a putative class action lawsuit, captioned Raby v. Evolv Technologies Holdings, Inc., et al. case number 1:24-cv-10761, alleging that Evolv and certain of its current and former executives and other individuals violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 based on alleged misstatements concerning the Company’s products. This litigation is in the preliminary stages, and the outcome of any complex legal proceeding is inherently unpredictable and subject to significant uncertainties.

- added (2024-05-09):
[0001628280-24-022282:note_history:8]
Regulatory and Governmental Matters

- added (2024-05-09):
[0001628280-24-022282:note_history:9]
In the ordinary course of business, the Company is subject to regulatory and governmental examinations, information gathering requests, inquiries, and investigations. The U.S. Federal Trade Commission (“FTC”) has requested information about certain aspects of the Company's marketing practices. The Company is cooperating with the investigation and has provided documentation and information responsive to the FTC inquiry. Further, in February 2024, we received a subpoena from the SEC, Division of Enforcement, requesting that we produce certain documents and information. We are cooperating and intend to continue to cooperate with the SEC's investigation.

- added (2024-05-09):
[0001628280-24-022282:note_history:10]
Any resolution or litigation with the FTC, the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on us and/or require us to make changes to our business practices. These costs and requirements may be material both individually and in the aggregate.

- added (2024-05-09):
[0001628280-24-022282:note_history:11]
We can offer no assurances as to the outcome of these investigations or their potential effect, if any, on us or our results of operations. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.

- removed (2024-05-09):
[0001628280-23-038311:note_history:12]
In the ordinary course of business, the Company is subject to regulatory and governmental examinations, information gathering requests, inquiries and investigations. For example, the U.S. Federal Trade Commission ("FTC") has previously requested information about certain aspects of the Company's marketing practices. The Company has provided, and continues to provide, documentation and information responsive to the FTC inquiry. We currently do not expect such examinations, requests, inquiries or investigations to have a material effect on our results of operations, financial condition or liquidity, either individually or in the aggregate.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-09):
[0001628280-24-022282:note_history:13]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to live, work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to better address the chronic epidemic of escalating gun violence, mass shootings, and terrorist attacks in a cost-effective manner while improving safety and the visitor experience. The Company is headquartered in Waltham, Massachusetts.
  (was, 2023-11-09, similarity 0.9992):
[0001628280-23-038311:note_history:13]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to live, work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to better address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks in a cost-effective manner while improving safety and the visitor experience. The Company is headquartered in Waltham, Massachusetts.

- added (2024-05-09):
[0001628280-24-022282:note_history:14]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly-owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).

- changed (2024-05-09):
[0001628280-24-022282:note_history:15]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2024, and for the three months ended March 31, 2024 and 2023 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2023 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2024 and the results of its operations for the three months ended March 31, 2024 and 2023 and cash flows for the three months ended March 31, 2024 and 2023. The results for the three months ended March 31, 2024 are not necessarily indicative of results to be expected for the year ending December 31, 2024, any other interim periods, or any future year or period.
  (was, 2023-11-09, similarity 0.7157):
[0001628280-23-038311:note_history:15]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2023, and for the three and nine months ended September 30, 2023 and 2022 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2022 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2023 and the results of its operations for the three and nine months ended September 30, 2023 and 2022 and cash flows for the nine months ended September 30, 2023 and 2022. The results for the three and nine months ended September 30, 2023 are not necessarily indicative of results to be expected for the year ending December 31, 2023, any other interim periods, or any future year or period.

- added (2024-05-09):
[0001628280-24-022282:note_history:16]
Reclassifications

- added (2024-05-09):
[0001628280-24-022282:note_history:17]
During the year ended December 31, 2023, the Company began classifying revenue from professional services, which includes installation, training, and event support, as well as other one-time revenue, within license fee and other revenue on the consolidated statements of operations and comprehensive loss, whereas the revenue for these services has previously been included in service revenue. Correspondingly, the Company began classifying costs associated with professional services within cost of license fee and other revenue, whereas these costs were previously included in cost of service revenue. These reclassifications were made to align the presentation of professional services with the Company's internal reporting and analysis. The reclassifications did not impact total revenue or total cost of revenue for any period. Prior year amounts included in this Quarterly Report on Form 10-Q have been reclassified to conform to the current presentation.

- added (2024-05-09):
[0001628280-24-022282:note_history:18]
For the three months ended March 31, 2023, the reclassifications resulted in an increase in license fee and other revenue of $0.6 million and a corresponding decrease in service revenue, as well as in increase in cost of license fee and other revenue of $0.3 million and a corresponding decrease in cost of service revenue.

- removed (2024-05-09):
[0001628280-23-038311:note_history:19]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly-owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC.

- removed (2024-05-09):
[0001628280-23-038311:note_history:20]
Merger
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the Merger as a wholly-owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-09):
[0001628280-24-022282:note_history:21]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2023, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2023. There have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2024.
  (was, 2023-11-09, similarity 0.7597):
[0001628280-23-038311:note_history:21]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2022, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2022. Other than the addition of the accounting policy related to marketable securities as described in Note

- changed (2024-05-09):
[0001628280-24-022282:note_history:22]
Recently Issued Accounting Pronouncements
  (was, 2023-11-09, similarity 0.8916):
[0001628280-23-038311:note_history:22]
Recently Adopted Accounting Pronouncements

- added (2024-05-09):
[0001628280-24-022282:note_history:23]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures.” The updated accounting guidance requires enhanced reportable segment disclosures, primarily related to significant segment expenses which are regularly provided to the chief operating decision maker. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Retrospective application is required and early adoption is permitted. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

- added (2024-05-09):
[0001628280-24-022282:note_history:24]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity should apply the amendments in ASU 2023-09 prospectively to all annual periods beginning after December 15, 2024. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

- removed (2024-05-09):
[0001628280-23-038311:note_history:25]
3. Marketable Securities, there have been no material changes to the Company’s significant accounting policies during the nine months ended September 30, 2023.

- removed (2024-05-09):
[0001628280-23-038311:note_history:26]
The Company qualifies as an “emerging growth company” as defined in the Jumpstart Our Business Startups Act of 2012 and has elected not to “opt out” to the extended transition related to complying with new or revised accounting standards, which means that when a standard is issued or revised and it has different application dates for public and nonpublic companies, the Company will adopt the new or revised standard at the time nonpublic companies adopt the new or revised standard and will do so until such time that the Company either (1) irrevocably elects to “opt out” of such extended transition period or (2) no longer qualifies as an emerging growth company. The Company may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for nonpublic companies. Based on our public float as of June 30, 2023, we expect to become a large accelerated filer and lose emerging growth company status as of December 31, 2023. As of December 31, 2023, we will be required to adopt new or revised accounting standards when they are applicable to public companies that are not emerging growth companies. Based on our public float as of June 30, 2023, we also expect to transition out of smaller reporting company status as of December 31, 2023 and will no longer be able to rely on the scaled disclosure requirements allowed for smaller reporting companies.

- removed (2024-05-09):
[0001628280-23-038311:note_history:27]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have a material impact on its consolidated financial statements and related disclosures.

- removed (2024-05-09):
[0001628280-23-038311:note_history:28]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years, and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have an impact on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-05-09):
[0001628280-24-022282:note_history:29]
Long-term Debt
In December 2022, the Company entered into a loan and security agreement (the “2022 SVB Credit Agreement”) with Silicon Valley Bank (“SVB”) in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. In light of the foregoing, on March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. During the three months ended March 31, 2023, the Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs. The Company had no long-term debt as of March 31, 2024 and December 31, 2023.

- removed (2024-05-09):
[0001628280-23-038311:note_history:30]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):

- removed (2024-05-09):
[0001628280-23-038311:note_history:31]
|  | September 30,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |

- removed (2024-05-09):
[0001628280-23-038311:note_history:32]
Silicon Valley Bank Term Loan Agreement

- removed (2024-05-09):
[0001628280-23-038311:note_history:33]
In December 2022, the Company entered into a loan and security agreement (the "2022 SVB Credit Agreement") with Silicon Valley Bank ("SVB") in order to finance purchases of hardware to be leased to customers. The 2022 SVB Credit Agreement provided for an initial term loan advance of $30.0 million, which was approximately equivalent to the value of all hardware purchases made to support leasing transactions with the Company's customers through December 21, 2022 (the "SVB Closing Date"), with the opportunity to obtain, within 18 months after the SVB Closing Date, additional term loan advances, subject to the satisfaction of certain conditions, in an aggregate principal amount equal to $20.0 million (subject to an increase of an additional $25.0 million upon the satisfaction of certain conditions and approval from SVB). The interest rate applicable to the SVB Term Loans was the greater of (a) the Wall Street Journal Prime Rate plus 1.0% or (b) 7.25% per annum. Interest and principal under the SVB Credit Agreement was payable monthly.

- removed (2024-05-09):
[0001628280-23-038311:note_history:34]
On March 10, 2023, SVB was closed by the California Department of Financial Protection and Innovation, which appointed the Federal Deposit Corporation ("FDIC") as receiver. The FDIC created a successor bridge bank, Silicon Valley Bridge Bank, N.A. ("SVBB"), and all deposits of SVB were transferred to SVBB under a systemic risk exception approved by the Federal Reserve, the U.S. Treasury Department, and the FDIC. On March 12, 2023, the Federal Reserve, the U.S. Treasury Department, and the FDIC announced in a joint statement that all SVB deposits, including both insured and uninsured amounts, would be available in full to account holders. SVB was acquired by First Citizens Bank on March 27, 2023.

- removed (2024-05-09):
[0001628280-23-038311:note_history:35]
In light of the foregoing, on March 28, 2023, upon the recommendation of the Company’s newly-formed Investment Committee of the Board of Directors, the Company (i) gave notice of its desire and intent to terminate the commitments under the 2022 SVB Credit Agreement and (ii) transferred its excess cash out of First Citizens Bank (the “Transfer”). The Transfer resulted in an event of default under the 2022 SVB Credit Agreement. Upon the occurrence of such event of default, First Citizens Bank could have, but was not required to, declare all obligations under the 2022 SVB Credit Agreement immediately due and payable. First Citizens Bank did not make such declaration following such event of default. 
On March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-09):
[0001628280-24-022282:note_history:36]
Marketable Securities
Marketable securities as of March 31, 2024 and December 31, 2023 consisted of the following:
  (was, 2023-11-09, similarity 0.9026):
[0001628280-23-038311:note_history:36]
Marketable Securities
Marketable securities as of September 30, 2023 consisted of the following:

- changed (2024-05-09):
[0001628280-24-022282:note_history:37]
|  | March 31, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 36,415 |  |  | $ | — |  |  | $ | 36,415 |  |
| Total marketable securities | $ | 36,415 |  |  | $ | — |  |  | $ | 36,415 |  |
  (was, 2023-11-09, similarity 0.9706):
[0001628280-23-038311:note_history:37]
|  | September 30, 2023 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 39,487 |  |  | $ | — |  |  | $ | 39,487 |  |
| Total marketable securities | $ | 39,487 |  |  | $ | — |  |  | $ | 39,487 |  |

- added (2024-05-09):
[0001628280-24-022282:note_history:38]
|  | December 31, 2023 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |
| Total marketable securities | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |

- added (2024-05-09):
[0001628280-24-022282:note_history:39]
Marketable securities at March 31, 2024 and December 31, 2023 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. The Company did not record any unrealized gains or losses on available-for-sale securities for each of the three months ended March 31, 2024 and 2023 as unrealized gains or losses were not material. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive income.

- removed (2024-05-09):
[0001628280-23-038311:note_history:40]
Marketable securities are reported at fair value and, at September 30, 2023, are comprised solely of zero coupon U.S. treasury bills with maturities of less than one year that are classified as available-for-sale debt securities. The Company did not record any unrealized gains or losses on available-for-sale securities for the three or nine months ended September 30, 2023. The accretion of discounts on marketable securities is included in interest income on the condensed

- removed (2024-05-09):
[0001628280-23-038311:note_history:41]
consolidated statements of operations and comprehensive income. The Company did not have any marketable securities as of December 31, 2022.

- removed (2024-05-09):
[0001628280-23-038311:note_history:42]
The Company considers an available-for-sale debt security to be impaired if the fair value of the investment is less than its amortized cost basis. The entire difference between the amortized cost basis and the fair value of the Company’s available-for-sale debt securities is recognized on the condensed consolidated statements of operations as an impairment if, (i) the fair value of the security is below its amortized cost and (ii) the Company intends to sell or is more likely than not required to sell the security before recovery of its amortized cost basis. If neither criterion is met, the Company evaluates whether the decline in fair value is due to credit losses or other factors. In making this assessment, the Company considers the changes to the rating of the security by third-party rating agencies, and adverse conditions specific to the security, among other factors. If the Company’s assessment indicates that a credit loss exists, the credit loss is measured based on the Company’s best estimate of the cash flows expected to be collected. When developing its estimate of cash flows expected to be collected, the Company considers all available information relevant to the collectability of the security, including past events, current conditions, and reasonable and supportable forecasts.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2024-05-09):
[0001628280-23-038311:note_history:43]
The components of the Company’s long-term debt consisted of the following (in thousands):

- removed (2024-05-09):
[0001628280-23-038311:note_history:44]
|  | September 30,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-05-09):
[0001628280-24-022282:note_history:45]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola
  (was, 2023-11-09, similarity 0.8323):
[0001628280-23-038311:note_history:45]
Original Equipment Manufacturer Partnership Agreement with Motorola

- changed (2024-05-09):
[0001628280-24-022282:note_history:46]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended March 31, 2024 and 2023, revenue from Motorola's distributor services was $1.9 million and $3.2 million, respectively. As of March 31, 2024 and December 31, 2023, accounts receivable related to Motorola’s distributor services was $2.1 million and $1.2 million, respectively.
  (was, 2023-11-09, similarity 0.8027):
[0001628280-23-038311:note_history:46]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended September 30, 2023 and 2022, revenue from Motorola's distributor services was $1.7 million and $2.3 million, respectively. During the nine months ended September 30, 2023 and 2022, revenue from Motorola's distributor services was $7.9 million and $5.0 million, respectively. As of September 30, 2023 and December 31, 2022, accounts receivable related to Motorola’s distributor services was $2.0 million and $12.5 million, respectively.

- added (2024-05-09):
[0001628280-24-022282:note_history:47]
Reseller Agreement with Stanley Black & Decker
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB (“Securitas”) in 2023. Securitas, directly or through its affiliates, resells the Company's products. Effective in the first fiscal quarter of 2024, while the reseller agreement is still in effect, Securitas is no longer considered a related party. During the three months ended March 31, 2023, revenue from Securitas' reseller services was $0.4 million. As of December 31, 2023, accounts receivable related to Securitas' reseller services was $0.6 million.

- removed (2024-05-09):
[0001628280-23-038311:note_history:48]
Related Party Transactions
Business Development Agreement with Finback

- removed (2024-05-09):
[0001628280-23-038311:note_history:49]
In January 2021, the Company granted the Finback Common Stock Warrants subject to the terms of the Finback BDA, as discussed in Note 10.

- removed (2024-05-09):
[0001628280-23-038311:note_history:50]
In connection with the Merger and pursuant to the Merger Agreement, in addition to earn-out shares allocated to Finback based on its common stock ownership percentage as of the Merger date, Finback is entitled to receive a proportional share of earn-out shares based upon its remaining unvested warrants as of the Merger Date.

- removed (2024-05-09):
[0001628280-23-038311:note_history:51]
Reseller Agreement with Stanley Black & Decker

- removed (2024-05-09):
[0001628280-23-038311:note_history:52]
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB ("Securitas") in 2023. Securitas, directly or through its affiliates, resells the Company's products. During the three months ended September 30, 2023 and 2022, revenue from Securitas' reseller services was $0.4 million and $0.5 million, respectively. During the nine months ended September 30, 2023 and 2022, revenue from Securitas' reseller services was $1.3 million and $0.8 million, respectively. As of September 30, 2023 and December 31, 2022, accounts receivable related to Securitas' reseller services was $0.4 million and $2.2 million, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-09):
[0001628280-24-022282:note_history:53]
The following table presents the Company’s revenue by revenue stream (in thousands). Certain prior period amounts have been reclassified to conform to current period presentation:
  (was, 2023-11-09, similarity 0.6388):
[0001628280-23-038311:note_history:53]
The following table presents the Company’s revenue by revenue stream (in thousands):

- added (2024-05-09):
[0001628280-24-022282:note_history:54]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Product revenue | $ | 603 |  |  | $ | 8,754 |  |  |  |  |  |
| Subscription revenue | 14,503 |  |  | 6,466 |  |  |  |  |  |
| Service revenue | 5,384 |  |  | 2,786 |  |  |  |  |  |
| License fees | 724 |  |  | — |  |  |  |  |  |
| Professional services and other revenue | 454 |  |  | 575 |  |  |  |  |  |
| Total revenue | $ | 21,668 |  |  | $ | 18,581 |  |  |  |  |  |

- removed (2024-05-09):
[0001628280-23-038311:note_history:55]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Product revenue | $ | 3,191 |  |  | $ | 9,839 |  |  | $ | 19,188 |  |  | $ | 19,179 |  |
| Leased equipment | 10,231 |  |  | 5,198 |  |  | 24,661 |  |  | 12,208 |  |
| SaaS, maintenance, and other revenue | 4,397 |  |  | 1,180 |  |  | 11,296 |  |  | 2,277 |  |
| Professional services | 360 |  |  | 313 |  |  | 1,440 |  |  | 646 |  |
| License fee and other revenue | 2,012 |  |  | — |  |  | 2,012 |  |  | — |  |
| Total revenue | $ | 20,191 |  |  | $ | 16,530 |  |  | $ | 58,597 |  |  | $ | 34,310 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-05-09):
[0001628280-24-022282:note_history:56]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

- added (2024-05-09):
[0001628280-24-022282:note_history:57]
Distribution and License Agreement

- added (2024-05-09):
[0001628280-24-022282:note_history:58]
In March 2023, the Company entered into a distributor licensing agreement (the “Distribution and License Agreement”) with Columbia Electrical Contractors, Inc. (“Columbia Tech”). Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, which serves as the Company's primary contract manufacturer. Under this arrangement, the Company has granted a license of its intellectual property to Columbia Tech, which contracts directly with certain of the Company's resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment as opposed to lease the equipment. Columbia Tech pays the Company a hardware license fee for each system it manufactures and sells under the agreement. In these instances, the Company still contracts directly with the reseller to provide a multi-year SaaS and maintenance subscription to the end-users.

- added (2024-05-09):
[0001628280-24-022282:note_history:59]
The Company has assessed whether it operates as the principal or as an agent in relation to the sale of product made by Columbia Tech to the Company's resellers pursuant to the Distribution and License Agreement. The Company considered various factors, including but not limited to, inventory risk, discretion in establishing pricing, and which entity is primarily responsible for fulfillment. Based on an evaluation of the facts and circumstances, the Company concluded that Columbia Tech is the principal in the arrangement. The Company therefore does not recognize revenue in relation to sales of product pursuant to the Distribution and License Agreement, but does recognize revenue in relation to license fees received from Columbia Tech and the SaaS and maintenance subscription contracts.

- changed (2024-05-09):
[0001628280-24-022282:note_history:60]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2024.
  (was, 2023-11-09, similarity 0.9731):
[0001628280-23-038311:note_history:60]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2023.

- changed (2024-05-09):
[0001628280-24-022282:note_history:61]
|  | Less than 1 year |  | 1 - 2 years |  | More than 2 years |  | Total |
| Product revenue | $ | 998 |  |  | $ | — |  |  | $ | — |  |  | $ | 998 |  |
| Subscription revenue | 63,890 |  |  | 56,850 |  |  | 65,829 |  |  | 186,569 |  |
| Service revenue | 22,261 |  |  | 21,691 |  |  | 22,112 |  |  | 66,064 |  |
| License fee and other revenue | 436 |  |  | 1 |  |  | 2 |  |  | 439 |  |
| Total revenue | $ | 87,585 |  |  | $ | 78,542 |  |  | $ | 87,943 |  |  | $ | 254,070 |  |
  (was, 2023-11-09, similarity 0.6161):
[0001628280-23-038311:note_history:61]
|  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue | $ | 2,469 |  |  | $ | — |  |  | $ | 2,469 |  |
| Subscription revenue | 51,258 |  |  | 108,942 |  |  | 160,200 |  |
| Service revenue | 18,173 |  |  | 40,284 |  |  | 58,457 |  |
| Total revenue | $ | 71,900 |  |  | $ | 149,226 |  |  | $ | 221,126 |  |

- changed (2024-05-09):
[0001628280-24-022282:note_history:62]
The amount of minimum future leases is based on expected income recognition. As of March 31, 2024, future minimum payments on noncancelable leases are as follows (in thousands):
  (was, 2023-11-09, similarity 0.8342):
[0001628280-23-038311:note_history:62]
The amount of minimum future leases included in subscription revenue in the table above is based on expected income recognition. As of September 30, 2023, future minimum payments on noncancelable leases are as follows (in thousands):

- changed (2024-05-09):
[0001628280-24-022282:note_history:63]
| Year Ending December 31: |  |
| 2024 (nine months remaining) | $ | 48,486 |  |
| 2025 | 58,972 |  |
| 2026 | 47,647 |  |
| 2027 | 27,312 |  |
| 2028 | 4,033 |  |
| Thereafter | 119 |  |
|  | $ | 186,569 |  |
  (was, 2023-11-09, similarity 0.9014):
[0001628280-23-038311:note_history:63]
| Year Ending December 31: |  |
| 2023 (three months remaining) | $ | 12,988 |  |
| 2024 | 50,800 |  |
| 2025 | 46,632 |  |
| 2026 | 35,489 |  |
| 2027 | 14,291 |  |
|  | $ | 160,200 |  |

- changed (2024-05-09):
[0001628280-24-022282:note_history:64]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of March 31, 2024 and December 31, 2023, the Company had $2.5 million and $3.7 million in current portion of contract assets and $0.3 million and $0.5 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2023-11-09, similarity 0.9849):
[0001628280-23-038311:note_history:64]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2023 and December 31, 2022, the Company had $3.7 million and $2.9 million in current portion of contract assets and $0.5 million and $1.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2024-05-09):
[0001628280-24-022282:note_history:65]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $17.3 million during the three months ended March 31, 2024 that was included in the December 31, 2023 deferred revenue balance. The Company recognized revenue of $6.9 million during the three months ended March 31, 2023 that was included in the December 31, 2022 deferred revenue balance.
  (was, 2023-11-09, similarity 0.9317):
[0001628280-23-038311:note_history:65]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $4.4 million and $16.5 million during the three and nine months ended September 30, 2023 that was included in the December 31, 2022 deferred revenue balance. The Company recognized revenue of $1.3 million and $6.0 million during the three and nine months ended September 30, 2022 that was included in the December 31, 2021 deferred revenue balance.

- changed (2024-05-09):
[0001628280-24-022282:note_history:66]
| Balance at December 31, 2023 | $ | 71,490 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (17,323) |  |
| Revenue deferred | 17,554 |  |
| Balance at March 31, 2024 | $ | 71,721 |  |
  (was, 2023-11-09, similarity 0.97):
[0001628280-23-038311:note_history:66]
| Balance at December 31, 2022 | $ | 35,968 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (16,507) |  |
| Revenue deferred | 53,058 |  |
| Balance at September 30, 2023 | $ | 72,519 |  |

- added (2024-05-09):
[0001628280-24-022282:note_history:67]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Interest income on lease receivables | 42 |  |  | 53 |  |  |  |  |  |
| Lease income - operating leases | 14,503 |  |  | 6,466 |  |  |  |  |  |
| Total lease revenue | $ | 14,545 |  |  | $ | 6,519 |  |  |  |  |  |

- changed (2024-05-09):
[0001628280-24-022282:note_history:68]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.3 million and $0.2 million during the three months ended March 31, 2024 and 2023, respectively.
  (was, 2023-11-09, similarity 0.8812):
[0001628280-23-038311:note_history:68]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.3 million and $0.5 million during the three and nine months ended September 30, 2023, respectively. Revenue related to leases entered into with related parties were $0.2 million and $0.4 million during the three and nine months ended September 30, 2022, respectively.

- changed (2024-05-09):
[0001628280-24-022282:note_history:69]
The following table presents the Company’s revenue by revenue stream (in thousands). Certain prior period amounts have been reclassified to conform to current period presentation:
  (was, 2023-11-09, similarity 0.6388):
[0001628280-23-038311:note_history:69]
The following table presents the Company’s revenue by revenue stream (in thousands):

- added (2024-05-09):
[0001628280-24-022282:note_history:70]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Product revenue | $ | 603 |  |  | $ | 8,754 |  |  |  |  |  |
| Subscription revenue | 14,503 |  |  | 6,466 |  |  |  |  |  |
| Service revenue | 5,384 |  |  | 2,786 |  |  |  |  |  |
| License fees | 724 |  |  | — |  |  |  |  |  |
| Professional services and other revenue | 454 |  |  | 575 |  |  |  |  |  |
| Total revenue | $ | 21,668 |  |  | $ | 18,581 |  |  |  |  |  |

- changed (2024-05-09):
[0001628280-24-022282:note_history:71]
Commissions
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $11.5 million and $11.4 million as of March 31, 2024 and December 31, 2023, respectively. During the three months ended March 31, 2024 and 2023, the Company recognized commission expense of $1.4 million and $1.6 million, respectively.
  (was, 2023-11-09, similarity 0.7476):
[0001628280-23-038311:note_history:71]
CommissionsThe Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $10.8 million and $9.0 million as of September 30, 2023 and December 31, 2022, respectively. During the three months ended September 30, 2023 and 2022, the Company recognized commission expense of $1.3 million and $1.2 million, respectively. During the nine months ended September 30, 2023 and 2022, the Company recognized commission expense of $4.4 million and $2.4 million, respectively.

- removed (2024-05-09):
[0001628280-23-038311:note_history:72]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases under ASC 842 and (2) from the sale of products, inclusive of SaaS and maintenance, (3) professional services, and (4) license fees related to a distribution and license agreement with the Company's primary contract manufacturer. The Company’s arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax.

- removed (2024-05-09):
[0001628280-23-038311:note_history:73]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue from sales-type leases | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 1,135 |  |
| Interest income on lease receivables | 49 |  |  | 60 |  |  | 153 |  |  | 170 |  |
| Lease income - operating leases | 10,231 |  |  | 5,198 |  |  | 24,661 |  |  | 12,208 |  |
| Total lease revenue | $ | 10,280 |  |  | $ | 5,287 |  |  | $ | 24,814 |  |  | $ | 13,513 |  |

- removed (2024-05-09):
[0001628280-23-038311:note_history:74]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Product revenue | $ | 3,191 |  |  | $ | 9,839 |  |  | $ | 19,188 |  |  | $ | 19,179 |  |
| Leased equipment | 10,231 |  |  | 5,198 |  |  | 24,661 |  |  | 12,208 |  |
| SaaS, maintenance, and other revenue | 4,397 |  |  | 1,180 |  |  | 11,296 |  |  | 2,277 |  |
| Professional services | 360 |  |  | 313 |  |  | 1,440 |  |  | 646 |  |
| License fee and other revenue | 2,012 |  |  | — |  |  | 2,012 |  |  | — |  |
| Total revenue | $ | 20,191 |  |  | $ | 16,530 |  |  | $ | 58,597 |  |  | $ | 34,310 |  |
