# EVLV 8-K — 0001628280-24-022265 filed 2024-05-09

## item codes, every 8-K on or before 2024-05-09

- 2024-05-09 0001628280-24-022265 — 2.02, 9.01
- 2024-02-29 0001628280-24-007980 — 2.02, 9.01
- 2024-02-20 0001104659-24-025077 — 7.01, 9.01
- 2024-01-31 0001628280-24-002618 — 5.03, 9.01
- 2023-11-09 0001628280-23-038267 — 2.02, 9.01
- 2023-11-06 0001104659-23-114499 — 5.02
- 2023-10-25 0001628280-23-035145 — 4.02
- 2023-10-12 0001104659-23-108693 — 2.02, 7.01, 9.01
- 2023-08-10 0001628280-23-028861 — 2.02, 9.01
- 2023-06-02 0001628280-23-020680 — 5.07
- 2023-05-10 0001628280-23-017243 — 2.02, 9.01
- 2023-04-03 0001628280-23-010402 — 1.02, 2.04, 8.01, 9.01
- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2024-05-09

- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-24-022265:8k_2_02:1]
EX-99.1
2
evlv-20240509exx991.htm
EX-99.1

[0001628280-24-022265:8k_2_02:2]
Document

[0001628280-24-022265:8k_2_02:3]
Exhibit 99.1

[0001628280-24-022265:8k_2_02:4]
Investor Relations:

[0001628280-24-022265:8k_2_02:5]
Brian Norris

[0001628280-24-022265:8k_2_02:6]
Senior Vice President of Finance and Investor Relations

[0001628280-24-022265:8k_2_02:7]
bnorris@evolvtechnology.com

[0001628280-24-022265:8k_2_02:8]
Evolv Technology Reports First Quarter Financial Results

[0001628280-24-022265:8k_2_02:9]
•Q1 Revenue of $21.7 million, up 17% year-over-year

[0001628280-24-022265:8k_2_02:10]
•Q1 Ending ARR1 of $82.5 million, up 96% year-over-year

[0001628280-24-022265:8k_2_02:11]
•Q1 Ending RPO2 of $254.1 million, up 57% year-over-year

[0001628280-24-022265:8k_2_02:12]
•Q1 Ending Evolv Express® subscriptions of 4,882, up 75% year-over-year

[0001628280-24-022265:8k_2_02:13]
Waltham, Massachusetts – May 9, 2024 – Evolv Technology (NASDAQ: EVLV), the leading security technology company pioneering AI-based screening to create safer experiences, today announced financial results for the quarter ended March 31, 2024.

[0001628280-24-022265:8k_2_02:14]
Results for the First Quarter of 2024

[0001628280-24-022265:8k_2_02:15]
Total revenue for the first quarter of 2024 was $21.7 million, an increase of 17% compared to $18.6 million for the first quarter of 2023. Annual Recurring Revenue (“ARR”)1 was $82.5 million at the end of first quarter of 2024, an increase of 96% compared to $42.0 million at the end of the first quarter of 2023. Net loss for the first quarter of 2024 was $(11.6) million, or $(0.08) per basic and diluted share, compared to $(28.6) million, or $(0.20) per basic and diluted share, in the first quarter of 2023. Adjusted earnings (loss)3 for the first quarter of 2024 was $(13.1) million, or $(0.09) per diluted share, compared to adjusted earnings (loss)3 of $(16.9) million, or $(0.12) per diluted share, for the first quarter of 2023. Adjusted EBITDA3 for the first quarter of 2024 was $(10.7) million compared to $(15.4) million in the first quarter of 2023. As of March 31, 2024, the Company had cash, cash equivalents, marketable securities, and restricted cash of $81.3 million and no debt.

[0001628280-24-022265:8k_2_02:16]
The following table summarizes the breakdown of recurring and non-recurring revenue4 for each period presented:

[0001628280-24-022265:8k_2_02:17]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  | % Change |  |  |  |  |  |  |
| Recurring revenue | $ | 19,381 |  |  | $ | 9,075 |  |  | 114 | % |  |  |  |  |  |  |
| Non-recurring revenue | 2,287 |  |  | 9,506 |  |  | (76) | % |  |  |  |  |  |  |
| Total revenue | $ | 21,668 |  |  | $ | 18,581 |  |  | 17 | % |  |  |  |  |  |  |

[0001628280-24-022265:8k_2_02:18]
The following table summarizes operating cash flows for each period presented:

[0001628280-24-022265:8k_2_02:19]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Net loss | $ | (11,644) |  |  | $ | (28,609) |  |  |  |  |  |
| Non-cash expense | 1,653 |  |  | 14,005 |  |  |  |  |  |
| Changes in operating assets and liabilities | (6,092) |  |  | 11,170 |  |  |  |  |  |
| Net cash used in operating activities | $ | (16,083) |  |  | $ | (3,434) |  |  |  |  |  |

[0001628280-24-022265:8k_2_02:20]
Company Comments on Outlook for 2024

[0001628280-24-022265:8k_2_02:21]
The Company today commented on its business outlook for 2024. The Company's outlook is based on the current indications for its business, which may change at any time.

[0001628280-24-022265:8k_2_02:22]
| Estimate ($ in millions) |  | Issued February 29, 2024 |  | Issued May 9, 2024 |
| Total Revenue |  | ~$115 |  | ~$100 |
| ARR1 (ARR) at 12/31/24 |  | $108-$112 |  | ~$100 |
| Adjusted Gross Margin3 |  | ~60% |  | Reaffirmed |
| Adjusted EBITDA3 |  | Improve by 40%+ |  | Reaffirmed |

[0001628280-24-022265:8k_2_02:23]
Company to Host Live Conference Call and Webcast

[0001628280-24-022265:8k_2_02:24]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business and other matters.  The conference call may be accessed in the United States by dialing +1.877.692.8955 and using access code 825879.  The conference call may be accessed outside of the United States by dialing +1.234.720.6979 and using the same access code. The conference call will be simultaneously webcast on the Company’s investor relations website, which can be accessed at http://ir.evolvtechnology.com.  The press release with the financial results will be available on the Company’s website prior to the conference call. A replay of the conference call will be available for a period of 30 days by dialing +1.866.207.1041 or +1.402.970.0847 and using access code 2732005 or by accessing the webcast replay on the Company’s investor relations website at http://ir.evolvtechnology.com.

[0001628280-24-022265:8k_2_02:25]
About Evolv Technology

[0001628280-24-022265:8k_2_02:26]
Evolv Technology (NASDAQ: EVLV) is transforming human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered weapons detection and analytics. Its mission is to transform security to create a safer world to work, learn, and play. Evolv has digitally transformed the gateways in places where people gather by enabling seamless integration combined with powerful analytics and insights. Evolv’s advanced systems have scanned more than 1 billion people, second only to the Department of Homeland Security’s Transportation Security Administration (TSA) in the United States. Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category. Evolv Technology®, Evolv Express®, Evolv Insights®, Evolv Cortex AI®, and Evolv Extend™ are registered trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit https://evolvtechnology.com.

[0001628280-24-022265:8k_2_02:27]
1 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001628280-24-022265:8k_2_02:28]
2 We define Remaining Performance Obligation, or RPO, as estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied or partially satisfied as of the end of the quarter.

[0001628280-24-022265:8k_2_02:29]
3 Non-GAAP Financial Measures In this press release, the Company’s adjusted gross profit (loss), adjusted gross margin, adjusted operating expenses, adjusted operating income (loss), adjusted EBITDA, adjusted earnings (loss), and adjusted earnings per diluted share are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit and adjusted gross margin exclude one-time expenses, stock-based compensation expense, and amortization of capitalized stock-based compensation which management believes provides a more meaningful representation of contribution margin. Adjusted operating expenses is defined as operating expenses less one-time items, stock-based compensation expense, amortization of capitalized stock-based compensation, and loss on impairment of lease equipment which management believes provides a more meaningful representation of on-going operating expense levels. Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, share-based compensation, interest expense (income), loss on extinguishment of debt, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, and certain other one-time expenses. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, amortization of capitalized stock-based compensation, loss on extinguishment of debt, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of lease equipment, and certain other one-time expenses. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operating performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release. The Company is unable to provide a reconciliation of Adjusted Gross Margin to GAAP Gross Margin and Adjusted EBITDA to Net Income (Loss), each measure's most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact these GAAP financial measures are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of derivative liabilities, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001628280-24-022265:8k_2_02:30]
4 Recurring revenue includes the recurring portion of revenue associated with pure subscription contracts and hardware purchase subscription contracts. Non-recurring revenue includes revenue that is one-time in nature, such as product revenue, shipping revenue, and revenue from installation, training, and professional services.

[0001628280-24-022265:8k_2_02:31]
Forward-Looking Statements

[0001628280-24-022265:8k_2_02:32]
could result in injury or loss of life, which could harm our brand, reputation, and results of operations; the loss of designation of our Evolv Express® system as a Qualified Anti-Terrorism Technology under the Homeland Security SAFETY Act; risks related to our business model, which is predicated, in part, on building a customer base that will generate a recurring stream of revenues through the sale of our subscription contracts; the ability for the Company to obtain, maintain, protect and enforce the Company’s intellectual property rights and use of “open source” software; the concentration of the Company’s revenues on a single solution; the Company’s ability to timely design, produce and launch its solutions, the Company’s ability to invest in growth initiatives and pursue acquisition opportunities; the limited liquidity and trading of the Company’s securities; risks related to existing and changing tax laws; geopolitical risk and changes in applicable laws or regulations; the possibility that the Company may be adversely affected by other economic, business, and/or competitive factors; operational risk; risks related to material weaknesses in our internal control over financial reporting and our remediation plans; risks related to increasing attention to and evolving expectations for, environmental, social, and governance initiatives; the impact of fluctuating general economic and market conditions and reductions in spending; the need for additional capital to support business growth, which might not be available on acceptable terms, if at all; and litigation and regulatory enforcement risks, including the diversion of management time and attention and the additional costs and demands on resources. These and other important factors discussed under the caption “Risk Factors” in our Annual Report on Form 10-K for the year ended December 31, 2023 filed with the Securities and Exchange Commission ("SEC") on February 29, 2024, as any such factors may be updated from time to time in our other filings with the SEC, including the Quarterly Report on Form 10-Q for the quarter ended March 31, 2024. The forward-looking statements in this press release and related presentation materials are based upon information available to us as of the date hereof, and while we believe such information forms a reasonable basis for such statements, it may be limited or incomplete, and our statements should not be read to indicate that we have conducted an exhaustive inquiry into, or review of, all potentially available relevant information. These statements are inherently uncertain and investors are cautioned not to unduly rely upon these statements.

[0001628280-24-022265:8k_2_02:33]
You should review this press release and the documents that we reference in this press release and related presentation materials with the understanding that our actual future results, levels of activity, performance and achievements may be materially different from what we expect. We qualify all of our forward-looking statements by these cautionary statements. Except as required by applicable law, we do not plan to publicly update or revise any forward-looking statements contained in this press release and related presentation materials, whether as a result of any new information, future events or otherwise.

[0001628280-24-022265:8k_2_02:34]
EVOLV TECHNOLOGY

[0001628280-24-022265:8k_2_02:35]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001628280-24-022265:8k_2_02:36]
(In thousands, except share and per share data)

[0001628280-24-022265:8k_2_02:37]
(Unaudited)

[0001628280-24-022265:8k_2_02:38]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 603 |  |  | $ | 8,754 |  |  |  |  |  |
| Subscription revenue | 14,503 |  |  | 6,466 |  |  |  |  |  |
| Service revenue | 5,384 |  |  | 2,786 |  |  |  |  |  |
| License fee and other revenue | 1,178 |  |  | 575 |  |  |  |  |  |
| Total revenue | 21,668 |  |  | 18,581 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 2,777 |  |  | 10,578 |  |  |  |  |  |
| Cost of subscription revenue | 5,779 |  |  | 2,351 |  |  |  |  |  |
| Cost of service revenue | 1,211 |  |  | 583 |  |  |  |  |  |
| Cost of license fee and other revenue | 129 |  |  | 304 |  |  |  |  |  |
| Total cost of revenue | 9,896 |  |  | 13,816 |  |  |  |  |  |
| Gross profit | 11,772 |  |  | 4,765 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,205 |  |  | 5,389 |  |  |  |  |  |
| Sales and marketing | 16,005 |  |  | 12,804 |  |  |  |  |  |
| General and administrative | 11,840 |  |  | 8,926 |  |  |  |  |  |
| Loss from impairment of property and equipment | — |  |  | 137 |  |  |  |  |  |
| Total operating expenses | 34,050 |  |  | 27,256 |  |  |  |  |  |
| Loss from operations | (22,278) |  |  | (22,491) |  |  |  |  |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (654) |  |  |  |  |  |
| Interest income | 1,085 |  |  | 953 |  |  |  |  |  |
| Other income (expense), net | (28) |  |  | 19 |  |  |  |  |  |
| Loss on extinguishment of debt | — |  |  | (626) |  |  |  |  |  |
| Change in fair value of contingent earn-out liability | 6,899 |  |  | (3,318) |  |  |  |  |  |
| Change in fair value of contingently issuable common stock liability | 527 |  |  | (742) |  |  |  |  |  |
| Change in fair value of public warrant liability | 2,151 |  |  | (1,750) |  |  |  |  |  |
| Total other income (expense), net | 10,634 |  |  | (6,118) |  |  |  |  |  |
| Net loss | $ | (11,644) |  |  | $ | (28,609) |  |  |  |  |  |
| Weighted average common shares outstanding – basic and diluted | 153,076,719 |  |  | 146,433,378 |  |  |  |  |  |
| Net loss per share - basic and diluted | $ | (0.08) |  |  | $ | (0.20) |  |  |  |  |  |
| Net loss | $ | (11,644) |  |  | $ | (28,609) |  |  |  |  |  |
| Other comprehensive income (loss) |  |  |  |  |  |  |  |
| Cumulative translation adjustment | 3 |  |  | (16) |  |  |  |  |  |
| Total other comprehensive income (loss) | 3 |  |  | (16) |  |  |  |  |  |
| Total comprehensive loss | $ | (11,641) |  |  | $ | (28,625) |  |  |  |  |  |

[0001628280-24-022265:8k_2_02:39]
EVOLV TECHNOLOGY

[0001628280-24-022265:8k_2_02:40]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-24-022265:8k_2_02:41]
(In thousands, except share and per share data)

[0001628280-24-022265:8k_2_02:42]
(Unaudited)

[0001628280-24-022265:8k_2_02:43]
|  | March 31, 2024 |  | December 31, 2023 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 44,596 |  |  | $ | 67,162 |  |
| Restricted cash | — |  |  | 275 |  |
| Marketable securities | 36,415 |  |  | 51,289 |  |
| Accounts receivable, net | 22,030 |  |  | 22,611 |  |
| Inventory | 11,007 |  |  | 9,507 |  |
| Current portion of contract assets | 2,538 |  |  | 3,707 |  |
| Current portion of commission asset | 4,516 |  |  | 4,339 |  |
| Prepaid expenses and other current assets | 20,700 |  |  | 16,954 |  |
| Total current assets | 141,802 |  |  | 175,844 |  |
| Restricted cash, noncurrent | 275 |  |  | — |  |
| Contract assets, noncurrent | 307 |  |  | 451 |  |
| Commission asset, noncurrent | 7,000 |  |  | 7,107 |  |
| Property and equipment, net | 129,342 |  |  | 112,921 |  |
| Operating lease right-of-use assets | 2,535 |  |  | 1,195 |  |
| Other assets | 999 |  |  | 1,202 |  |
| Total assets | $ | 282,260 |  |  | $ | 298,720 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 15,584 |  |  | $ | 17,400 |  |
| Accrued expenses and other current liabilities | 13,712 |  |  | 15,578 |  |
| Current portion of deferred revenue | 48,913 |  |  | 47,677 |  |
| Current portion of operating lease liabilities | 1,713 |  |  | 1,391 |  |
| Total current liabilities | 79,922 |  |  | 82,046 |  |
| Deferred revenue, noncurrent | 22,808 |  |  | 23,813 |  |
| Operating lease liabilities, noncurrent | 980 |  |  | — |  |
| Contingent earn-out liability | 22,220 |  |  | 29,119 |  |
| Contingently issuable common stock liability | 6,003 |  |  | 6,530 |  |
| Public warrant liability | 8,738 |  |  | 10,889 |  |
| Total liabilities | 140,671 |  |  | 152,397 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at March 31, 2024 and December 31, 2023; no shares issued and outstanding at March 31, 2024 and December 31, 2023 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at March 31, 2024 and December 31, 2023; 155,356,947 and 151,310,080 shares issued and outstanding at March 31, 2024 and December 31, 2023, respectively | 16 |  |  | 15 |  |
| Additional paid-in capital | 451,731 |  |  | 444,825 |  |
| Accumulated other comprehensive loss | (50) |  |  | (53) |  |
| Accumulated deficit | (310,108) |  |  | (298,464) |  |
| Stockholders’ equity | 141,589 |  |  | 146,323 |  |
| Total liabilities and stockholders’ equity | $ | 282,260 |  |  | $ | 298,720 |  |

[0001628280-24-022265:8k_2_02:44]
EVOLV TECHNOLOGY

[0001628280-24-022265:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-24-022265:8k_2_02:46]
(In thousands)

[0001628280-24-022265:8k_2_02:47]
(Unaudited)

[0001628280-24-022265:8k_2_02:48]
|  | Three Months EndedMarch 31, |
|  | 2024 |  | 2023 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (11,644) |  |  | $ | (28,609) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 3,474 |  |  | 1,815 |  |
| Write-off of inventory and change in inventory reserve | 1,059 |  |  | 214 |  |
| Loss from impairment of property and equipment | — |  |  | 137 |  |
| Stock-based compensation | 6,410 |  |  | 5,043 |  |
| Non-cash interest expense | — |  |  | 22 |  |
| Accretion of discount on marketable securities, net of change in accrued interest | 200 |  |  | — |  |
| Non-cash lease expense | 354 |  |  | 214 |  |
| Change in allowance for expected credit losses | (267) |  |  | 124 |  |
| Loss on extinguishment of debt | — |  |  | 626 |  |
| Change in fair value of earn-out liability | (6,899) |  |  | 3,318 |  |
| Change in fair value of contingently issuable common stock | (527) |  |  | 742 |  |
| Change in fair value of public warrant liability | (2,151) |  |  | 1,750 |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | 848 |  |  | 8,640 |  |
| Inventory | (2,091) |  |  | 1,418 |  |
| Commission assets | (70) |  |  | (644) |  |
| Contract assets | 1,313 |  |  | 258 |  |
| Other assets | 203 |  |  | (130) |  |
| Prepaid expenses and other current assets | (3,746) |  |  | (25) |  |
| Accounts payable | (760) |  |  | (2,213) |  |
| Deferred revenue | 231 |  |  | 8,757 |  |
| Accrued expenses and other current liabilities | (1,628) |  |  | (4,637) |  |
| Operating lease liability | (392) |  |  | (254) |  |
| Net cash used in operating activities | (16,083) |  |  | (3,434) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (1,797) |  |  | (733) |  |
| Purchases of property and equipment | (19,665) |  |  | (13,365) |  |
| Proceeds from sale of property and equipment | — |  |  | 60 |  |
| Purchases of marketable securities | (14,567) |  |  | — |  |
| Proceeds from maturities of marketable securities | 29,241 |  |  | — |  |
| Net cash used in investing activities | (6,788) |  |  | (14,038) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 302 |  |  | 33 |  |
| Proceeds from long-term debt | — |  |  | 1,876 |  |
| Repayment of principal on long-term debt | — |  |  | (31,876) |  |
| Payment of debt issuance costs and prepayment penalty | — |  |  | (332) |  |
| Net cash provided by (used in) financing activities | 302 |  |  | (30,299) |  |
| Effect of exchange rate changes on cash and cash equivalents | 3 |  |  | (16) |  |
| Net decrease in cash, cash equivalents and restricted cash | (22,566) |  |  | (47,787) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 67,437 |  |  | 230,058 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 44,871 |  |  | $ | 182,271 |  |

[0001628280-24-022265:8k_2_02:49]
EVOLV TECHNOLOGY

[0001628280-24-022265:8k_2_02:50]
SUMMARY OF KEY OPERATING STATISTICS

[0001628280-24-022265:8k_2_02:51]
(Unaudited)

[0001628280-24-022265:8k_2_02:52]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2023 |  | June 30,2023 |  | September 30,2023 |  | December 31,2023 |  | March 31,2024 |  |  |  |  |  |  |
| New customers |  | 61 |  |  | 74 |  |  | 70 |  |  | 75 |  |  | 53 |  |  |  |  |  |  |  |
| Annual recurring revenue |  | $ | 42,021 |  |  | $ | 54,339 |  |  | $ | 65,774 |  |  | $ | 74,989 |  |  | $ | 82,511 |  |  |  |  |  |  |  |
| Recurring revenue |  | $ | 9,075 |  |  | $ | 11,689 |  |  | $ | 14,377 |  |  | $ | 17,350 |  |  | $ | 19,381 |  |  |  |  |  |  |  |
| Remaining performance obligation |  | $ | 161,813 |  |  | $ | 198,296 |  |  | $ | 221,126 |  |  | $ | 240,513 |  |  | $ | 254,070 |  |  |  |  |  |  |  |
| Net additions |  | 520 |  |  | 599 |  |  | 628 |  |  | 491 |  |  | 377 |  |  |  |  |  |  |  |
| Ending deployed units |  | 2,787 |  |  | 3,386 |  |  | 4,014 |  |  | 4,505 |  |  | 4,882 |  |  |  |  |  |  |  |

[0001628280-24-022265:8k_2_02:53]
EVOLV TECHNOLOGY

[0001628280-24-022265:8k_2_02:54]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001628280-24-022265:8k_2_02:55]
(In thousands)

[0001628280-24-022265:8k_2_02:56]
(Unaudited)

[0001628280-24-022265:8k_2_02:57]
|  | Three Months Ended, |
|  |  | March 31,2023 |  | June 30,2023 |  | September 30,2023 |  | December 31,2023 |  | March 31,2024 |  |  |  |  |  |  |
| Operating expenses, GAAP |  | $ | 27,256 |  |  | $ | 31,039 |  |  | $ | 31,629 |  |  | $ | 32,167 |  |  | $ | 34,050 |  |  |  |  |  |  |  |
| Stock-based compensation |  | (4,898) |  |  | (6,505) |  |  | (5,454) |  |  | (6,711) |  |  | (6,272) |  |  |  |  |  |  |  |
| Loss on impairment of lease equipment |  | (137) |  |  | (157) |  |  | (28) |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Other one-time expenses |  | (53) |  |  | (683) |  |  | (945) |  |  | (535) |  |  | (476) |  |  |  |  |  |  |  |
| Adjusted operating expenses |  | $ | 22,168 |  |  | $ | 23,694 |  |  | $ | 25,202 |  |  | $ | 24,921 |  |  | $ | 27,302 |  |  |  |  |  |  |  |

[0001628280-24-022265:8k_2_02:58]
EVOLV TECHNOLOGY

[0001628280-24-022265:8k_2_02:59]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT, GAAP GROSS MARGIN TO ADJUSTED GROSS MARGIN AND GAAP OPERATING INCOME (LOSS) TO ADJUSTED OPERATING INCOME (LOSS)

[0001628280-24-022265:8k_2_02:60]
(In thousands)

[0001628280-24-022265:8k_2_02:61]
(Unaudited)

[0001628280-24-022265:8k_2_02:62]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Revenue | $ | 21,668 |  |  | $ | 18,581 |  |  |  |  |  |
| Cost of revenue | 9,896 |  |  | 13,816 |  |  |  |  |  |
| Gross profit, GAAP | 11,772 |  |  | 4,765 |  |  |  |  |  |
| Stock-based compensation | 138 |  |  | 145 |  |  |  |  |  |
| Amortization of capitalized stock-based compensation | 14 |  |  | 10 |  |  |  |  |  |
| Other one-time expenses | 1,204 |  |  | — |  |  |  |  |  |
| Adjusted gross profit | $ | 13,128 |  |  | $ | 4,920 |  |  |  |  |  |
| Gross margin % | 54.3 | % |  | 25.6 | % |  |  |  |  |
| Adjusted gross margin % | 60.6 | % |  | 26.5 | % |  |  |  |  |

[0001628280-24-022265:8k_2_02:63]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Operating loss, GAAP | $ | (22,278) |  |  | $ | (22,491) |  |  |  |  |  |
| Stock-based compensation | 6,410 |  |  | 5,043 |  |  |  |  |  |
| Amortization of capitalized stock-based compensation | 14 |  |  | 10 |  |  |  |  |  |
| Loss on impairment of lease equipment | — |  |  | 137 |  |  |  |  |  |
| Other one-time expenses | 1,680 |  |  | 53 |  |  |  |  |  |
| Adjusted operating loss | $ | (14,174) |  |  | $ | (17,248) |  |  |  |  |  |

[0001628280-24-022265:8k_2_02:64]
EVOLV TECHNOLOGY

[0001628280-24-022265:8k_2_02:65]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-24-022265:8k_2_02:66]
(In thousands)

[0001628280-24-022265:8k_2_02:67]
(Unaudited)

[0001628280-24-022265:8k_2_02:68]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Net loss | $ | (11,644) |  |  | $ | (28,609) |  |  |  |  |  |
| Depreciation & amortization | 3,474 |  |  | 1,815 |  |  |  |  |  |
| Stock-based compensation | 6,410 |  |  | 5,043 |  |  |  |  |  |
| Interest expense (income) | (1,085) |  |  | (299) |  |  |  |  |  |
| Loss on extinguishment of debt | — |  |  | 626 |  |  |  |  |  |
| Change in fair value of contingent earn-out liability | (6,899) |  |  | 3,318 |  |  |  |  |  |
| Change in fair value of contingently issuable common stock liability | (527) |  |  | 742 |  |  |  |  |  |
| Change in fair value of public warrant liability | (2,151) |  |  | 1,750 |  |  |  |  |  |
| Loss on impairment of lease equipment | — |  |  | 137 |  |  |  |  |  |
| Other one-time expenses | 1,680 |  |  | 53 |  |  |  |  |  |
| Adjusted EBITDA | $ | (10,742) |  |  | $ | (15,424) |  |  |  |  |  |

[0001628280-24-022265:8k_2_02:69]
EVOLV TECHNOLOGY

[0001628280-24-022265:8k_2_02:70]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001628280-24-022265:8k_2_02:71]
(In thousands, except share and per share data)

[0001628280-24-022265:8k_2_02:72]
(Unaudited)

[0001628280-24-022265:8k_2_02:73]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Net loss | $ | (11,644) |  |  | $ | (28,609) |  |  |  |  |  |
| Stock-based compensation | 6,410 |  |  | 5,043 |  |  |  |  |  |
| Amortization of capitalized stock-based compensation | 14 |  |  | 10 |  |  |  |  |  |
| Loss on extinguishment of debt | — |  |  | 626 |  |  |  |  |  |
| Change in fair value of contingent earn-out liability | (6,899) |  |  | 3,318 |  |  |  |  |  |
| Change in fair value of contingently issuable common stock liability | (527) |  |  | 742 |  |  |  |  |  |
| Change in fair value of public warrant liability | (2,151) |  |  | 1,750 |  |  |  |  |  |
| Loss on impairment of lease equipment | — |  |  | 137 |  |  |  |  |  |
| Other one-time expenses | 1,680 |  |  | 53 |  |  |  |  |  |
| Adjusted loss | $ | (13,117) |  |  | $ | (16,930) |  |  |  |  |  |
| Weighted average common shares outstanding – diluted | 153,076,719 |  |  | 146,433,378 |  |  |  |  |  |
| Adjusted loss per share – diluted | $ | (0.09) |  |  | $ | (0.12) |  |  |  |  |  |
