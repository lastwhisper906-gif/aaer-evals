# EVLV notes — 0001628280-24-008053


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-24-008053:notes:1]
Certain portions of the information required to be furnished pursuant to Part III of this Annual Report on Form 10-K will be set forth in, and incorporated by reference from, the registrant’s definitive proxy statement for the annual meeting of stockholders which will be filed with the Securities and Exchange Commission no later than 120 days after the end of the fiscal year ended December 31, 2023.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-24-008053:notes:2]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a global leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks in a cost-effective manner while improving the visitor experience. The Company is headquartered in Waltham, Massachusetts.

[0001628280-24-008053:notes:3]
As used in this Annual Report on Form 10-K, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC.

[0001628280-24-008053:notes:4]
Risks and uncertainties

[0001628280-24-008053:notes:5]
There is significant uncertainty in the current macroeconomic environment due to inflationary pressures globally, conflicts in Europe and the Middle East, and foreign currency volatility and their impacts on the Company’s business. If economic conditions were to worsen, the Company’s results of operations, financial condition, and cash flows from operations may be materially and adversely impacted.

[0001628280-24-008053:notes:6]
Basis of presentation

[0001628280-24-008053:notes:7]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001628280-24-008053:notes:8]
Merger

[0001628280-24-008053:notes:9]
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the Merger as a wholly-owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001628280-24-008053:notes:10]
Reclassifications

[0001628280-24-008053:notes:11]
During the year ended December 31, 2023, the Company began classifying revenue from professional services, which includes installation, training, and event support, as well as other one-time revenue, within license fee and other revenue on the consolidated statements of operations and comprehensive loss, whereas the revenue for these services has previously been included in service revenue. Correspondingly, the Company began classifying costs associated with professional services within cost of license fee and other revenue, whereas these costs were previously included in cost of service revenue. These reclassifications were made to align the presentation of professional services with the Company's internal reporting and analysis. The reclassifications did not impact total revenue or total cost of revenue for any period. Prior year amounts included in this Annual Report on Form 10-K have been reclassified to conform to the current presentation.

[0001628280-24-008053:notes:12]
For the year ended December 31, 2022, the reclassifications resulted in an increase in license fee and other revenue of $1.3 million and a corresponding decrease in service revenue, as well as in increase in cost of license fee and other revenue of $2.2 million and a corresponding decrease in cost of service revenue.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-24-008053:notes:13]
Summary of Significant Accounting Policies
Use of Estimates

[0001628280-24-008053:notes:14]
The preparation of the Company’s consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the reporting periods. Significant estimates and assumptions reflected in these consolidated financial statements include but are not limited to calculating the standalone selling price for revenue recognition, the valuation of inventory, the expensing and capitalization of costs associated with internal-use software, stock-based awards, the valuation of the contingent earn-out liability, the valuation of the contingently issuable common stock, and the valuation of the public warrant liability. The Company bases its estimates on historical experience, known trends and other market-specific or other relevant factors that it believes to be reasonable under the circumstances. On an ongoing basis, management evaluates its estimates when there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results could differ from those estimates.

[0001628280-24-008053:notes:15]
Risk of Concentrations of Credit, Significant Customers and Significant Suppliers

[0001628280-24-008053:notes:16]
Financial instruments that potentially expose the Company to concentrations of credit risk consist primarily of cash equivalents, restricted cash, marketable securities, and accounts receivable, net. We maintain substantially all of our cash and cash equivalents with U.S. and multi-national financial institutions, and our deposits are generally in excess of federally insured limits. The Company maintains its cash, cash equivalents, restricted cash, and marketable securities with financial institutions that management believes to be of high credit quality. The Company has not experienced any losses on such accounts and does not believe it is exposed to any unusual credit risk beyond the normal credit risk associated with commercial banking relationships.

[0001628280-24-008053:notes:17]
Significant customers are those which represent more than 10% of the Company’s total revenue or accounts receivable, net balance at each respective balance sheet date. The following table presents customers that represent 10% or more of the Company’s total revenue for the years ended December 31, 2023 and December 31, 2022. Each customer shown is a reseller partner of the Company.

[0001628280-24-008053:notes:18]
|  | Year Ended December 31, 2023 |  | Year Ended December 31, 2022 |
| Motorola Solutions, Inc. | 12.0 | % |  | 20.9 | % |
| Customer A | * |  | 10.1 | % |
| Customer B | 10.4 | % |  | * |
|  | 22.4 | % |  | 31.0 | % |

[0001628280-24-008053:notes:19]
* Less than 10%

[0001628280-24-008053:notes:20]
The following table presents customers that represent 10% or more of the Company’s accounts receivable, net. Each customer shown is a reseller partner of the Company.

[0001628280-24-008053:notes:21]
|  | December 31, |
|  | 2023 |  | 2022 |
| Motorola Solutions, Inc. | * |  | 39.0 | % |
| Customer B | * |  | 16.0 | % |
|  |  |  | 55.0 | % |

[0001628280-24-008053:notes:22]
The Company relies on one primary third-party contract manufacturer, Columbia Tech, for the production of our touchless security screening systems. Columbia Tech provides a variety of services including sourcing off-the-shelf components, manufacturing custom components/assemblies, final product assembly and integration, end of line testing and quality assurance per our specifications, material and finished goods inventory, and direct shipping to our customers. We also use a different third-party manufacturer as a second source for the production of a key sensor component used in our systems. In instances where these parties fail to perform their obligations, the Company may be unable to find alternative suppliers to satisfactorily deliver its products to its customers on time, if at all, which could have a material adverse effect on the Company’s operating results, financial condition and cash flows and damage its customer relationships.

[0001628280-24-008053:notes:23]
Cash, Cash Equivalents, and Restricted Cash

[0001628280-24-008053:notes:24]
The Company considers all short-term, highly liquid investments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents. Restricted cash relates to a letter of credit on the Company’s office lease in Waltham, Massachusetts, all of which is included in restricted cash, current on the consolidated balance sheet as of December 31, 2023. As the letter of credit is reduced, restricted cash is reclassified to cash and cash equivalents.

[0001628280-24-008053:notes:25]
Marketable Securities

[0001628280-24-008053:notes:26]
Marketable securities are reported at fair value and, at December 31, 2023, are comprised solely of zero coupon U.S. treasury bills with maturities of less than one year that are classified as available-for-sale debt securities. The Company considers an available-for-sale debt security to be impaired if the fair value of the investment is less than its amortized cost basis. The entire difference between the amortized cost basis and the fair value of the Company’s available-for-sale debt securities is recognized on the consolidated statements of operations as an impairment if, (i) the fair value of the security is below its amortized cost and (ii) the Company intends to sell or is more likely than not required to sell the security before recovery of its amortized cost basis. If neither criterion is met, the Company evaluates whether the decline in fair value is due to credit losses or other factors. In making this assessment, the Company considers the changes to the rating of the security by third-party rating agencies, and adverse conditions specific to the security, among other factors. If the Company’s assessment indicates that a credit loss exists, the credit loss is measured based on the Company’s best estimate of the cash flows expected to be collected. When developing its estimate of cash flows expected to be collected, the Company considers all available information relevant to the collectability of the security, including past events, current conditions, and reasonable and supportable forecasts.

[0001628280-24-008053:notes:27]
Unrealized gains and losses, net of tax, on marketable securities, if any, are recognized in accumulated other comprehensive income (loss) in the accompanying consolidated balance sheets. Realized net gains and losses on marketable securities, if any, are reflected in interest income in the accompanying consolidated statements of operations and comprehensive loss.

[0001628280-24-008053:notes:28]
Fair Value Measurements of Financial Instruments

[0001628280-24-008053:notes:29]
Certain assets and liabilities of the Company are carried at fair value under GAAP. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement

[0001628280-24-008053:notes:30]
date. Valuation techniques used to measure fair value must maximize the use of observable inputs and minimize the use of unobservable inputs. Financial assets and liabilities carried at fair value are to be classified and disclosed in one of the following three levels of the fair value hierarchy, of which the first two are considered observable and the last is considered unobservable:

[0001628280-24-008053:notes:31]
•Level 1 — Quoted prices in active markets for identical assets or liabilities.

[0001628280-24-008053:notes:32]
•Level 2 — Observable inputs (other than Level 1 quoted prices), such as quoted prices in active markets for similar assets or liabilities, quoted prices in markets that are not active for identical or similar assets or liabilities, or other inputs that are observable or can be corroborated by observable market data.

[0001628280-24-008053:notes:33]
•Level 3 — Unobservable inputs that are supported by little or no market activity that are significant to determining the fair value of the assets or liabilities, including pricing models, discounted cash flow methodologies and similar techniques.

[0001628280-24-008053:notes:34]
The Company’s cash equivalents, restricted cash, marketable securities, derivative liability, contingent earn-out liability, contingently issuable common stock liability and its common stock warrant liability are carried at fair value, determined according to the fair value hierarchy described above (see Note 4). The carrying values of the Company’s accounts receivable, net, accounts payable and accrued expenses approximate their fair values due to the short-term nature of these assets and liabilities. The carrying value of the Company’s long-term debt approximates its fair value (a Level 2 measurement) at each balance sheet date due to its variable interest rate, which approximates a market interest rate.

[0001628280-24-008053:notes:35]
Assets that are measured at fair value on a nonrecurring basis primarily relate to property and equipment. We do not periodically adjust carrying value to fair value for property and equipment. Rather, the carrying value of the asset is reduced to its fair value when we determine that impairment has occurred.

[0001628280-24-008053:notes:36]
Contingent Earn-out

[0001628280-24-008053:notes:37]
In connection with the Merger and pursuant to the Merger Agreement, certain of the Legacy Evolv’s shareholders and Legacy Evolv Service Providers are entitled to receive additional shares of the Company’s common stock (the “Earn-Out Shares”) upon the Company achieving certain milestones:

[0001628280-24-008053:notes:38]
•Triggering Event I – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock is greater than $12.50 per share for any 20 trading days within any 30 trading day period.

[0001628280-24-008053:notes:39]
•Triggering Event II – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock is greater than $15.00 per share for any 20 trading days within any 30 trading day period.

[0001628280-24-008053:notes:40]
•Triggering Event III – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock is greater than $17.50 per share for any 20 trading days within any 30 trading day period.

[0001628280-24-008053:notes:41]
In accordance with ASC 815 – Derivatives and Hedging, the earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a change in fair value of contingent earn-out liability in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Triggering Events have been achieved and the Earn-Out Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001628280-24-008053:notes:42]
The estimated fair value of the contingent earn-out shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, drift rate, percentage of change in control and expected term.

[0001628280-24-008053:notes:43]
The contingent earn-out liability is categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingent earn-out payments involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001628280-24-008053:notes:44]
The Earn-Out Shares issued to employees, officers, directors, and non-employees are based on achievement of certain target share price contingencies and for the employees and officers, subject to continued employment, (the “Earn-Out Service Providers”) represents share-based compensation and is included in additional paid-in capital on the Company’s balance sheet. Corresponding stock-based compensation expense is recorded in the consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. As a condition to being issued Earn-Out Shares, the Earn-Out Service Providers must still be providing services to the Company on the date of the issuance of the shares. If the relationship with the service provider is terminated prior to the issuance of the Earn-Out Shares, the shares will be redistributed to the remaining participants in the Earn-Out Shares.

[0001628280-24-008053:notes:45]
Contingently Issuable Common Stock

[0001628280-24-008053:notes:46]
Prior to the Merger, NewHold Industrial Technology Holdings, LLC, the sponsor of the NHIC special purpose acquisition company owned 4,312,500 shares of NHIC Class B common stock (the “Founder Shares). Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company’s common stock. The Founder Shares outstanding were subject to certain share-performance-based vesting provisions as follows:

[0001628280-24-008053:notes:47]
•Vesting Provision I – 1,897,500 shares of the Company’s common stock shall vest and no longer be subject to forfeiture as of the Merger;

[0001628280-24-008053:notes:48]
•Vesting Provision II – if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $12.50 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30 trading day period, then 948,750 shares of the Company’s common stock shall vest and no longer be subject to forfeiture and

[0001628280-24-008053:notes:49]
•Vesting Provision III – if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $15.00 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30-trading day period, then 948,750 shares of the Company’s common stock) shall vest and no longer be subject to forfeiture.

[0001628280-24-008053:notes:50]
The remaining 517,500 Founder Shares were contributed to Give Evolv LLC.

[0001628280-24-008053:notes:51]
If Vesting Provision II and/or Vesting Provision III are not satisfied, the corresponding number of shares specified shall be forfeited and no longer issued and outstanding. If there is a Change of Control event prior to Vesting Provision II and/or Vesting Provision III are satisfied, the Founder shares are no longer subject to forfeiture and shall vest immediately upon the occurrence of a Change of Control event.

[0001628280-24-008053:notes:52]
In accordance with ASC 815 – Derivatives and Hedging, the contingently issuable common stock is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as change in fair value of contingently issuable common stock liability in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Vesting Provisions have been achieved and the contingently issuable common shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001628280-24-008053:notes:53]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, likelihood of change in control, and remaining term.

[0001628280-24-008053:notes:54]
The contingently issuable common shares are categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingently issuable shares involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001628280-24-008053:notes:55]
Public Warrant Liability

[0001628280-24-008053:notes:56]
In connection with the closing of the Merger, the Company assumed warrants for the purchase of 14,325,000 shares of common stock at an exercise price of $11.50 (the “Public Warrants”). The Public Warrants are classified as a liability pursuant to ASC 815 – Derivatives and Hedging as the equity derivative scope exception was not met and are measured at fair value, with the changes in fair value reported in earnings as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss with the offset to additional paid in capital.

[0001628280-24-008053:notes:57]
Leases as a Lessee

[0001628280-24-008053:notes:58]
The Company accounts for leases in accordance with ASC 842, Leases. At contract inception, the Company determines if an arrangement is or contains a lease. A lease conveys the right to control the use of an identified asset for a period of time in exchange for consideration. If determined to be or contain a lease, the lease is assessed for classification as either an operating or finance lease at the lease commencement date, defined as the date on which the leased asset is made available for use by the Company (when the Company is the lessee). Where the Company is the lessee, for each lease with a term greater than twelve months, the Company records a right-of-use asset and lease liability.

[0001628280-24-008053:notes:59]
A right-of-use asset represents the economic benefit conveyed to the Company by the right to use the underlying asset over the lease term. A lease liability represents the obligation to make lease payments arising from the use of the asset over the lease term. Lease liabilities are measured at lease commencement and calculated as the present value of the future lease payments in the contract using the rate implicit in the contract, when available. If an implicit rate is not readily determinable, the Company uses an incremental borrowing rate measured as the rate at which the Company could borrow, on a fully collateralized basis, a commensurate loan in the same currency over a period consistent with the lease term at the commencement date. Right-of-use assets are measured as the amount of the initial lease liability plus initial direct costs and prepaid lease payments, less lease incentives granted by the lessor. The lease term is measured as the noncancelable period in the contract, adjusted for any options to extend or terminate when it is reasonably certain the Company will extend the lease term via such options based on an assessment of economic factors present as of the lease commencement date. The Company elected the practical expedient to not recognize leases with a lease term of twelve months or less.

[0001628280-24-008053:notes:60]
Components of a lease are split into three categories: lease components, non-lease components, and non-components. The fixed and in-substance fixed contract consideration (including any consideration related to non-components) are allocated, based on the respective relative fair values, to the lease components and non-lease components. The Company has elected the practical expedient to account for lease and non-lease components together as a single lease component for all underlying assets and allocate all of the contract consideration to the lease component only.

[0001628280-24-008053:notes:61]
The Company’s operating leases are presented in the consolidated balance sheet as operating lease right-of-use assets, classified as noncurrent assets, and operating lease liabilities, classified as current and noncurrent liabilities. Operating lease expense is recognized on a straight-line basis over the lease term. Variable costs associated with a lease, such as maintenance and utilities, are not included in the measurement of the lease liabilities and right-of-use assets but rather are expensed when the events determining the amount of variable consideration to be paid have occurred.

[0001628280-24-008053:notes:62]
Inventory

[0001628280-24-008053:notes:63]
Inventory is stated at the lower of cost or net realizable value with cost being determined using the weighted average method. The Company regularly reviews inventory quantities on-hand for excess and obsolete inventory and, when circumstances indicate, records charges to write down inventories to their estimated net realizable value, after evaluating historical sales, future demand, market conditions and expected product life cycles. Such charges are classified as product cost of revenues in the consolidated statement of operations and comprehensive loss. Any write-down of inventory to net realizable value creates a new cost basis. The Company recorded $1.6 million and $1.6 million in inventory write-offs and change in inventory reserves during the years ended December 31, 2023 and 2022, respectively. Inventory write-offs primarily relate to Edge units and prior generation Express units, as the Company is no longer selling these products, as well as other inventory that was determined to be obsolete or unsellable.

[0001628280-24-008053:notes:64]
Property and Equipment

[0001628280-24-008053:notes:65]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization expense are recognized using the straight-line method over the estimated useful life of each asset, as follows:

[0001628280-24-008053:notes:66]
|  | Estimated Useful Life |
| Computers and telecommunications equipment | 3 years |
| Lab equipment | 5 years |
| Software | 4 years |
| Furniture and fixtures | 5 years |
| Leasehold improvements | Shorter of useful life of 7 years or remaining lease term |
| Leased equipment | 4-7 years |
| Internal-use software | 4 years |

[0001628280-24-008053:notes:67]
Estimated useful lives are periodically assessed to determine if changes are appropriate. Leasehold improvements are depreciated using the straight-line method over the lesser of the lease term or its estimated economic useful life. Lease terms are used based upon the initial lease agreement and do not consider potential renewals or extensions until such time that the renewals or extensions are contracted. Maintenance and repairs are charged to expense as incurred. When assets are retired or otherwise disposed of, the cost of these assets and related accumulated depreciation are eliminated from the consolidated balance sheet and any resulting gains or losses are included in the consolidated statements of operations and comprehensive loss in the period of disposal. Costs for capital assets not yet placed into service are capitalized as construction-in-progress and depreciated once placed into service.

[0001628280-24-008053:notes:68]
The Company’s leases for leased equipment generally are 48 months. The Company’s subscription contracts are generally classified as operating leases because title does not transfer and they do not meet any of the other criteria per Accounting Standards Codification 842 – Leases (“ASC 842”).

[0001628280-24-008053:notes:69]
The Company evaluates property and equipment for obsolescence and impairment whenever events or changes in business circumstances indicate that the carrying amount of the assets may not be fully recoverable. Factors that the Company considers in deciding when to perform an impairment review include significant underperformance of the business in relation to expectations, significant negative industry or economic trends and significant changes or planned changes in the use of the assets. If an impairment review is performed to evaluate a long-lived asset group for recoverability, the Company compares forecasts of undiscounted cash flows expected to result from the use and eventual disposition of the long-lived asset group to its carrying value. An impairment loss would be recognized in loss from operations and comprehensive loss when estimated undiscounted future cash flows expected to result from the use of an asset group are less than its carrying amount. The impairment loss is based on the excess of the carrying value of the impaired asset group over its fair value, determined based on discounted cash flows. The Company recorded impairment losses of $0.3 million and $1.2 million during the years ended December 31, 2023 and 2022, respectively. These impairment losses related primarily to Edge and Express prototype units that were taken out of service and retired.

[0001628280-24-008053:notes:70]
The Company capitalizes certain software development costs, including consulting costs and compensation expenses for employees who devote time to the development projects, beginning upon completion of the preliminary project stage (in relation to internal-use software) or upon establishment of technological feasibility (in relation to software embedded in products to be sold or leased), and through the date the software is ready for its intended use. The Company records software development costs in property and equipment, net. Costs incurred in the preliminary stages of development activities and post implementation are expensed in the period incurred and are recorded in research and development expense in the consolidated statements of operations and comprehensive loss. The Company also capitalizes

[0001628280-24-008053:notes:71]
costs related to specific upgrades and enhancements when it is probable the expenditures will result in additional functionality.

[0001628280-24-008053:notes:72]
Once the project is available for general release, capitalization ceases, and the asset can begin amortization. Capitalized software costs are amortized on a straight-line basis over their estimated useful life, which is generally four years, and are recorded in cost of subscription revenue and cost of service revenue in the consolidated statements of operations and comprehensive loss.

[0001628280-24-008053:notes:73]
Debt Issuance Costs

[0001628280-24-008053:notes:74]
The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated debt on the consolidated balance sheet and amortized as interest expense on the consolidated statement of operations and comprehensive loss using the effective interest method.

[0001628280-24-008053:notes:75]
Segment Information

[0001628280-24-008053:notes:76]
The Company determined that it has one operating segment after considering the Company’s organizational structure and the information regularly reviewed and evaluated by the Company’s chief operating decision maker (“CODM”) in deciding how to allocate resources and assess performance. The Company has determined that its CODM is its President and Chief Executive Officer. The CODM reviews the financial information on a consolidated basis for purposes of evaluating financial performance and allocating resources. On the basis of these factors, the Company determined that it operates and manages its business as one operating segment, that develops, manufactures, markets and sells security screening products and specific services, and accordingly has one reportable segment for financial reporting purposes.

[0001628280-24-008053:notes:77]
Revenue Recognition

[0001628280-24-008053:notes:78]
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

[0001628280-24-008053:notes:79]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001628280-24-008053:notes:80]
Distribution and License Agreement

[0001628280-24-008053:notes:81]
In March 2023, the Company entered into a distributor licensing agreement (the "Distribution and License Agreement") with Columbia Electrical Contractors, Inc. ("Columbia Tech"). Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, which serves as the Company's primary contract manufacturer. Under this arrangement, the Company has granted a license of its intellectual property to Columbia Tech, which contracts directly with certain of the Company's resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment as opposed to lease the equipment. Columbia Tech pays the Company a hardware license fee for each system it manufactures and sells under the agreement. In these instances, the Company still contracts directly with the reseller to provide a multi-year SaaS and maintenance subscription to the end-users.

[0001628280-24-008053:notes:82]
The Company has assessed whether it operates as the principal or as an agent in relation to the sale of product  made by Columbia Tech to the Company's resellers pursuant to the Distribution and License Agreement. The Company considered various factors, including but not limited to, inventory risk, discretion in establishing pricing, and which entity is primarily responsible for fulfillment. Based on an evaluation of the facts and circumstances, the Company concluded that Columbia Tech is the principal in the arrangement. The Company therefore does not recognize revenue in relation to sales of product pursuant to the Distribution and License Agreement, but does recognize revenue in relation to license fees received from Columbia Tech and the SaaS and maintenance subscription contracts, each as further described below.

[0001628280-24-008053:notes:83]
Product Revenue

[0001628280-24-008053:notes:84]
The Company derives revenue from the sale of its Evolv Express equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer. Transfer of control occurs when the Company has transferred title and risk of loss and has a present right to payment for the equipment, which follows the terms of each customer contract. Products are predominantly sold with distinct services, which are described in the services section below.

[0001628280-24-008053:notes:85]
Subscription Revenue - Leases as Lessor

[0001628280-24-008053:notes:86]
In addition to selling our products directly to customers, we also derive revenue from leasing our equipment, which we classify as subscription revenue. Lease terms are typically four years, generally do not include unilateral options by either the Company or our customer to extend, terminate or to purchase the underlying asset, and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. There are no variable lease payments as a part of these arrangements.

[0001628280-24-008053:notes:87]
The accounting provisions we use to classify transactions as sales-type are: (i) whether the lease transfers ownership of the equipment by the end of the lease term, (ii) whether the lease grants the customer an option to purchase the equipment and the customer is reasonably certain to do so, (iii) whether the lease term is for the major part of the economic life of the underlying equipment, (iv) whether the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (v) whether the equipment is specific to the customer and of such a specialized nature that it is expected to have no alternative use to the Company at the end of the lease term. Leasing arrangements meeting any of these conditions are accounted for as sales-type leases and revenue attributable to the lease component is recognized in a manner consistent with product revenue and the related equipment is derecognized with the associated expense presented as a cost of revenue. Leasing arrangements that do not meet the criteria for classification as a sales-type lease will be accounted for as a direct-financing lease if the following two conditions are met: (i) the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments and any other third party unrelated to the Company, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (ii) it is probable that the Company will collect the lease payments and amounts necessary to satisfy a residual value guarantee. Leasing arrangements that do not meet any of the sales-type lease or direct-financing lease classification criteria are accounted for as operating leases and revenue is recognized straight-line over the term of the lease. Historically, nearly all of the Company's equipment leases have been classified as operating leases.

[0001628280-24-008053:notes:88]
The Company considers the economic life of most of our products to be seven years. The Company believes seven years is representative of the period during which the equipment is expected to be economically usable by one or more users, with normal service, for the purpose for which it is intended. The unguaranteed residual value is estimated to be the value at the end of the lease term based on the anticipated fair market value of the units. The Company mitigates residual value risk of our leased equipment by performing regular management and maintenance, as necessary.

[0001628280-24-008053:notes:89]
Generally, lease arrangements include both lease and non-lease components. The lease component relates to the customer’s right-to-use the equipment over the lease term. The non-lease components relate to (1) distinct services, such as SaaS and maintenance, (2) any add-on accessories, and (3) professional services, including installation, training, and event. Professional services are included in license fees and other revenue, as described below, and add-on accessories are included in product revenue. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the Company elected the practical expedient to aggregate non-lease components with the associated lease component and account for the combined component as an

[0001628280-24-008053:notes:90]
operating lease for all underlying asset classes. In the evaluation of whether the lease component (equipment) or the non-lease components associated with the lease component (SaaS and maintenance) is the predominant component, the Company determined that the lease component is predominant as we believe the customer would ascribe more value to the use of the security equipment than that of the SaaS and maintenance services. Therefore, the Company accounts for the combined lease component under ASC 842. The equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations and comprehensive loss. The professional services represent distinct services provided to customers. These activities are considered separate performance obligations to the customer and therefore are considered non-lease components. As professional services are generally performed prior to lease commencement, the timing and pattern of transfer for these services differ from that of the lease component and are not eligible to be combined.

[0001628280-24-008053:notes:91]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party.

[0001628280-24-008053:notes:92]
Professional services are generally billed to the lessee as part of the lease contract billing, according to various contractual terms. Professional services costs incurred by the Company are accounted for as a fulfillment cost and are included in the cost of license fees and other revenue in the consolidated statements of operations and comprehensive loss.

[0001628280-24-008053:notes:93]
Service Revenue

[0001628280-24-008053:notes:94]
Service revenue consists of subscription-based SaaS and maintenance revenue related to products sold to a customer by either the Company or by Columbia Tech pursuant to the Distribution and License Agreement. Customers generally pay either a quarterly or annual fixed payment for SaaS and maintenance. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically 4 years.

[0001628280-24-008053:notes:95]
License Fee and Other Revenue

[0001628280-24-008053:notes:96]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from our third-party manufacturer to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration.

[0001628280-24-008053:notes:97]
Revenue from Reseller Partners

[0001628280-24-008053:notes:98]
A portion of the Company’s revenue is also generated by sales to its reseller partners. When the Company transacts with a reseller partner, its contractual arrangement is with the reseller partner and not with the end-use customer. In these transactions, the reseller partner is considered the customer; the Company has discretion over the pricing to the reseller partner and maintains overall control of the inventory and sales process to the reseller partner. Right of return does not generally exist. Whether the Company transacts with a reseller partner and receives the order from a reseller partner or directly from an end-use customer, its revenue recognition policy and resulting pattern of revenue recognition is the same.

[0001628280-24-008053:notes:99]
Transaction Price

[0001628280-24-008053:notes:100]
The transaction price is the amount of consideration that the Company expects to be entitled for providing goods and services under a contract, which includes fixed amounts, and on rare occasions, variable consideration. The Company may also provide discounts to customers which reduce the transaction price. On infrequent occasions, the Company may offer customers the option to purchase additional goods and services at a fixed price. In these circumstances, the Company assesses whether these offers constitute a material right, and if so, the Company would account for the material right as a separate performance obligation. The Company does not normally provide for rights of returns to customers on product sales and, therefore, does not record a provision for returns. Amounts paid or payable to customers, including those related to sponsorship arrangements, are recognized as a reduction of the transaction price, and therefore, of revenue unless the payment is in exchange for a distinct good or service.

[0001628280-24-008053:notes:101]
Performance Obligations

[0001628280-24-008053:notes:102]
A performance obligation is a promise in a contract to transfer a distinct product or service to a customer that is both capable of being distinct, whereby the customer can benefit from the product or service either on its own or together with other resources that are readily available, and is distinct in the context of the contract, whereby the transfer of the product or service is separately identifiable from other promises in the contract.

[0001628280-24-008053:notes:103]
Equipment is sold or leased with embedded software, which is considered a single performance obligation. Maintenance, which includes preventative maintenance, future updates, security threat updates, and minor bug fixes on a when-and-if available basis, is considered a single performance obligation. SaaS, which includes data-driven security information and analytics insights, is also considered a performance obligation. Professional services, including installation, training, and event support, are considered separate performance obligations and are included within license fee and other revenue. Any add-on accessories are also considered separate performance obligations and are included in product revenue.

[0001628280-24-008053:notes:104]
Payment terms

[0001628280-24-008053:notes:105]
Payment terms for customer orders are typically 30 days after the shipment or installation of the product. Generally, the Company’s contracts do not contain a significant financing component.

[0001628280-24-008053:notes:106]
Multiple Performance Obligations within an Arrangement

[0001628280-24-008053:notes:107]
The Company’s contracts may include multiple performance obligations when customers purchase a combination of products and services. When the Company’s customer arrangements have multiple performance obligations that contain an equipment lease for the customer’s use as well as distinct services that are delivered simultaneously, the Company allocates the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, the Company allocates the contract’s transaction price to each performance obligation on a relative SSP basis. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company estimates the SSP taking into account available information such as market conditions, internally approved pricing guidelines, and observable pricing data such as standard cost metrics related to the performance obligation.

[0001628280-24-008053:notes:108]
Stock-Based Compensation

[0001628280-24-008053:notes:109]
The Company measures all stock-based awards granted to employees, officers, directors and non-employees based on their fair value on the date of the grant and recognizes compensation expense for those awards over the requisite service period, which is generally the vesting period of the respective award. The vesting period for stock options is generally four years and the vesting period for restricted stock units is generally three years. The Company classifies stock-based compensation expense in its consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. The Company issues stock-based awards with service-based vesting conditions and records the expense for these awards using the straight-line method. Forfeitures are accounted for as they occur.

[0001628280-24-008053:notes:110]
In January 2021, the Company granted warrants (the "Finback Common Stock Warrants") exercisable for 2,552,913 shares of common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC ("Finback"), a consulting group affiliated with one of the Company's shareholders. The Finback Common Stock Warrants vest upon meeting certain sales criteria as defined in a business development agreement (the "Finback BDA") which has a term of   three years. The Finback Common Stock Warrants expire in January 2031. The Finback Common Stock Warrants are accounted for under ASC 718 Compensation - Stock Compensation as the warrants vest upon certain performance conditions being met.

[0001628280-24-008053:notes:111]
Prior to the closing of the Merger, there was not a public market for the shares of the Company’s common stock. The Company’s determination of the fair value of stock options on the date of grant utilized the Black-Scholes option-pricing model and was impacted by its common stock price, as determined by the Board of Directors with input from the Company’s management, as well as changes in assumptions regarding a number of subjective variables. These variables

[0001628280-24-008053:notes:112]
included, but were not limited to, the expected term that options remained outstanding, the expected common stock price volatility over the term of the option awards, risk-free interest rates, and expected dividends. The Company valued its common stock taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the Company determines the fair value of each share of common stock underlying stock-based awards based on the closing price of the Company’s common stock as reported by Nasdaq on the date of grant.

[0001628280-24-008053:notes:113]
Pursuant to the Merger Agreement, the Company will issue 15,000,000 earn-out shares of the Company’s common stock to Legacy Evolv shareholders and Legacy Evolv Service Providers including employees, officers, directors, and non-employees based on the achievement of certain target share price contingencies and subject to continued employment. The company classifies the share-based compensation arrangement with Legacy Evolv Service Providers as equity on its balance sheet and corresponding stock-based compensation expense in its consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. As of December 31, 2023, of the total 15,000,000 earn-out shares of the Company’s common stock, 2,115,304 earn-out shares can be earned by the Legacy Evolv Service Providers and are subject to the stock-based compensation guidance. As a condition for Earn-Out Shares being issued to Earn-Out Service Providers, the service provider must be providing services to the Company on the date of the issuance of the shares. If the relationship with the service provider is terminated prior to the issuance of the Earn-Out Shares, the shares will be redistributed to the remaining participants in the Earn-Out Shares.

[0001628280-24-008053:notes:114]
Income Taxes

[0001628280-24-008053:notes:115]
The Company accounts for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in the consolidated financial statements or in the Company’s tax returns. Deferred tax assets and liabilities are determined on the basis of the differences between the consolidated financial statements and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. Changes in deferred tax assets and liabilities are recorded in the provision for income taxes.

[0001628280-24-008053:notes:116]
The Company assesses the likelihood that its deferred tax assets will be recovered from future sources of income and, to the extent it believes, based upon the weight of available evidence, that it is more likely than not that all or a portion of the deferred tax assets will not be realized, a valuation allowance is established through a charge to income tax expense. The potential for recovery of deferred tax assets is evaluated by analyzing past operating results, estimating the future taxable profits expected and considering prudent and feasible tax planning strategies.

[0001628280-24-008053:notes:117]
The Company accounts for uncertainty in income taxes recognized in the consolidated financial statements by applying a two-step process to determine the amount of tax benefit to be recognized. First, the tax position must be evaluated to determine the likelihood that it will be sustained upon external examination by the taxing authorities. If the tax position is deemed more-likely-than-not to be sustained, the tax position is then assessed to determine the amount of benefit to recognize in the consolidated financial statements. The amount of the benefit that may be recognized is the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. The provision for income taxes includes the effects of any resulting tax reserves, or unrecognized tax benefits, that are considered appropriate as well as the related net interest and penalties.

[0001628280-24-008053:notes:118]
The Company evaluates at the end of each reporting period whether some or all the undistributed earnings of its foreign subsidiaries are permanently reinvested. The Company would recognize deferred income tax liabilities to the extent that management asserts that undistributed earnings of its foreign subsidiaries are not permanently reinvested and will not be permanently reinvested in the future. For the year ended December 31, 2023, the Company had less than $0.1 million in foreign earnings. For the year ended December 31, 2022, the Company had no foreign earnings in any foreign jurisdictions. The Company will continue to evaluate its position in the future based on its future strategy and cash needs.

[0001628280-24-008053:notes:119]
Net Loss per Share Attributable to Common Stockholders

[0001628280-24-008053:notes:120]
Basic net loss per share attributable to common stockholders is computed by dividing the net loss attributable to common stockholders by the weighted average number of common shares outstanding for the period. Diluted net loss attributable to common stockholders is computed by adjusting net loss attributable to common stockholders for the impact

[0001628280-24-008053:notes:121]
to the extent a denominator adjustment is required. Diluted net loss per share attributable to common stockholders is computed by dividing the diluted net loss attributable to common stockholders by the weighted average number of common shares outstanding for the period, including the dilutive effect of potential dilutive common shares as determined under the treasury stock method. For purposes of this calculation, outstanding stock options, convertible preferred stock, convertible notes, warrants to purchase common stock, and warrants to purchase preferred stock are considered potential dilutive common shares.

[0001628280-24-008053:notes:122]
In periods in which the Company reported a net loss attributable to common stockholders, diluted net loss per share attributable to common stockholders is the same as basic net loss per share attributable to common stockholders, since dilutive common shares are not assumed to have been issued if their effect is anti-dilutive. The Company reported a net loss attributable to common stockholders for the years ended December 31, 2023 and 2022.

[0001628280-24-008053:notes:123]
Recently Adopted Accounting Pronouncements

[0001628280-24-008053:notes:124]
Becoming a Large Accelerated Filer

[0001628280-24-008053:notes:125]
Prior to December 31, 2023, the Company qualified as an "emerging growth company", as defined in the Jumpstart our Business Startups Act of 2012, and elected not to “opt out” of the extended transition related to complying with new or revised accounting standards.

[0001628280-24-008053:notes:126]
The Company became a large accelerated filer and ceased to qualify as an emerging growth company as of December 31, 2023. The adoption dates discussed below for recently adopted accounting pronouncements reflect the updated transition periods required as a result of becoming a "large accelerated filer" (as defined under Rule 12b-2 of the Exchange Act) as of December 31, 2023. The Company will be required to adopt all future new or revised accounting pronouncements in accordance with applicable public company timelines specified in those accounting pronouncements.

[0001628280-24-008053:notes:127]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have a material impact on its consolidated financial statements and related disclosures.

[0001628280-24-008053:notes:128]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years, and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have an impact on its consolidated financial statements and related disclosures.

[0001628280-24-008053:notes:129]
Recently Issued Accounting Pronouncements

[0001628280-24-008053:notes:130]
In July 2023, the FASB issued Accounting Standards Update ASU 2023-03, “Presentation of Financial Statement (Topic 205), Income Statement - Reporting Comprehensive Income (Topic 220), Distinguishing Liabilities from Equity (Topic 480), Equity (Topic 505), and Compensation - Stock Compensation (Topic 718),” to amend various U.S. Securities Exchange Commission ("SEC") paragraphs in the Accounting Standards Codification to reflect the issuance of SEC Staff Accounting Bulletin No. 120, among other things. The ASU does not provide any new guidance so there is no transition or

[0001628280-24-008053:notes:131]
effective date associated with it. The Company is currently assessing the impact of adopting ASU 2023-03 on the consolidated financial statements and related disclosures.

[0001628280-24-008053:notes:132]
In October 2023, the FASB issued ASU 2023-06, “Disclosure Improvements – Codification Amendments in Response to the SEC’s Disclosure Update and Simplification Initiative,” related to disclosure or presentation requirements for various subtopics in the FASB’s Accounting Standards Codification (“Codification”). The amendments in the update are intended to align the requirements in the Codification with the SEC regulations and facilitate the application of GAAP for all entities. The effective date for each amendment is the date on which the SEC removal of the related disclosure requirement from Regulation S-X or Regulation S-K becomes effective, or if the SEC has not removed the requirements by June 30, 2027, this amendment will be removed from the Codification and will not become effective for any entity. Early adoption is prohibited. The Company does not expect this update to have a material impact on the consolidated financial statements and related disclosures.

[0001628280-24-008053:notes:133]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures.” The updated accounting guidance requires enhanced reportable segment disclosures, primarily related to significant segment expenses which are regularly provided to the chief operating decision maker. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Retrospective application is required and early adoption is permitted. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

[0001628280-24-008053:notes:134]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures." ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity should apply the amendments in ASU 2023-09 prospectively to all annual periods beginning after December 15, 2024. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-24-008053:notes:135]
Marketable Securities
Marketable securities as of December 31, 2023 consisted of the following:

[0001628280-24-008053:notes:136]
|  | December 31, 2023 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |
| Total marketable securities | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |

[0001628280-24-008053:notes:137]
Marketable securities at December 31, 2023 are comprised solely of zero coupon U.S. treasury bills with maturities of less than one year that are classified as available-for-sale debt securities. The Company did not record any unrealized gains or losses on available-for-sale securities for the year ended December 31, 2023. The accretion of discounts on marketable securities is included in interest income on the consolidated statements of operations and comprehensive income. The Company did not have any marketable securities as of December 31, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-24-008053:notes:138]
Fair Value Measurements
The following tables present information about the Company’s financial assets and liabilities measured at fair value on a recurring basis and indicate the level of the fair value hierarchy used to determine such fair values (in thousands):

[0001628280-24-008053:notes:139]
|  | Fair Value Measurements at December 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 57,829 |  |  | $ | — |  |  | $ | — |  |  | $ | 57,829 |  |
| Treasury bills | — |  |  | 51,289 |  |  | — |  |  | 51,289 |  |
|  | $ | 57,829 |  |  | $ | 51,289 |  |  | $ | — |  |  | $ | 109,118 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 29,119 |  |  | $ | 29,119 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 6,530 |  |  | 6,530 |  |
| Public Warrant liability | 10,889 |  |  | — |  |  | — |  |  | 10,889 |  |
|  | $ | 10,889 |  |  | $ | — |  |  | $ | 35,649 |  |  | $ | 46,538 |  |

[0001628280-24-008053:notes:140]
|  | Fair Value Measurements at December 31, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 149,971 |  |  | $ | — |  |  | $ | — |  |  | $ | 149,971 |  |
|  | $ | 149,971 |  |  | $ | — |  |  | $ | — |  |  | $ | 149,971 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Long-term debt including current portion | $ | — |  |  | $ | 29,683 |  |  | $ | — |  |  | $ | 29,683 |  |
| Contingent earn-out liability | — |  |  | — |  |  | 14,218 |  |  | 14,218 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 3,392 |  |  | 3,392 |  |
| Public Warrant liability | 6,124 |  |  | — |  |  | — |  |  | 6,124 |  |
|  | $ | 6,124 |  |  | $ | 29,683 |  |  | $ | 17,610 |  |  | $ | 53,417 |  |

[0001628280-24-008053:notes:141]
Money market funds are included in cash and cash equivalents on the consolidated balance sheets. As of December 31, 2023, all outstanding treasury bills, which totaled $51.3 million, had maturities greater than 3 months and are reflected as marketable securities. The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources.

[0001628280-24-008053:notes:142]
The Company may also value its non-financial assets and liabilities, including items such as inventories and property and equipment, at fair value on a non-recurring basis if it is determined that impairment has occurred. Such fair value measurements use significant unobservable inputs and are classified as Level 3.

[0001628280-24-008053:notes:143]
The carrying amounts of cash and cash equivalents, accounts receivable, restricted cash, accounts payable, accrued liabilities, and other accrued expenses approximate fair value because of their short maturity.

[0001628280-24-008053:notes:144]
During each of the years ended December 31, 2023 and 2022, there were no transfers between Level 1, Level 2, and Level 3.

[0001628280-24-008053:notes:145]
Valuation of Contingent Earn-out

[0001628280-24-008053:notes:146]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the

[0001628280-24-008053:notes:147]
closing of the Merger and are remeasured at each reporting period. As of December 31, 2023, no milestones have been achieved.

[0001628280-24-008053:notes:148]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of December 31, 2023 were as follows: 90% expected stock price volatility, a risk-free rate of return of 4.2%, a 25% likelihood of change in control, and a remaining term of 2.2 years.

[0001628280-24-008053:notes:149]
The following table provides a rollforward of the contingent earn-out liability (in thousands):

[0001628280-24-008053:notes:150]
| Balance at December 31, 2021 | $ | 21,206 |  |
| Change in fair value | (6,988) |  |
| Balance at December 31, 2022 | $ | 14,218 |  |
| Change in fair value | 14,901 |  |
| Balance at December 31, 2023 | $ | 29,119 |  |

[0001628280-24-008053:notes:151]
Valuation of Contingently Issuable Common Stock

[0001628280-24-008053:notes:152]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 Founder Shares. Of these shares, 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC and the remaining 1,897,500 outstanding shares will vest upon the Company achieving certain milestones (see Note 2). The Company’s contingently issuable common stock was recorded at fair value as contingent shares on the closing of the Merger and will be remeasured at each reporting period. As of December 31, 2023, no milestones have been achieved.

[0001628280-24-008053:notes:153]
The fair value of the contingently issued common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of December 31, 2023 were as follows: 90% expected stock price volatility, a risk-free rate of return of 4.1%, a 25% likelihood of change in control, and a remaining term of 2.5 years.

[0001628280-24-008053:notes:154]
The following table provides a rollforward of the contingently issuable common shares (in thousands):

[0001628280-24-008053:notes:155]
| Balance at December 31, 2021 | $ | 5,264 |  |
| Change in fair value | (1,872) |  |
| Balance at December 31, 2022 | $ | 3,392 |  |
| Change in fair value | 3,138 |  |
| Balance at December 31, 2023 | $ | 6,530 |  |

[0001628280-24-008053:notes:156]
Valuation of Public Warrant Liability

[0001628280-24-008053:notes:157]
Upon the closing of the Merger, the Company assumed the Public Warrants to purchase shares of the Company’s common stock. The Public Warrants are publicly traded and the initial fair value of the public warrants were based on the closing price as reported by Nasdaq on the date of the Merger and remeasured at each reporting period.

[0001628280-24-008053:notes:158]
The following table provides a rollforward of the public warrant liability (in thousands):

[0001628280-24-008053:notes:159]
| Balance at December 31, 2021 | $ | 11,030 |  |
| Change in fair value | (4,906) |  |
| Balance at December 31, 2022 | $ | 6,124 |  |
| Change in fair value | 4,765 |  |
| Balance at December 31, 2023 | $ | 10,889 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-24-008053:notes:160]
Revenue Recognition
Remaining Performance Obligations

[0001628280-24-008053:notes:161]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of December 31, 2023.

[0001628280-24-008053:notes:162]
|  | Less than 1 year |  | 1 - 2 years |  | More than 2 years |  | Total |
| Product revenue | $ | 997 |  |  | $ | — |  |  | $ | — |  |  | $ | 997 |  |
| Subscription revenue | 56,819 |  |  | 52,188 |  |  | 63,265 |  |  | 172,272 |  |
| Service revenue | 21,255 |  |  | 20,948 |  |  | 24,898 |  |  | 67,101 |  |
| License fee and other revenue | 143 |  |  | — |  |  | — |  |  | 143 |  |
| Total revenue | $ | 79,214 |  |  | $ | 73,136 |  |  | $ | 88,163 |  |  | $ | 240,513 |  |

[0001628280-24-008053:notes:163]
The amount of minimum future leases is based on expected income recognition. As of December 31, 2023, future minimum payments on noncancelable leases are as follows (in thousands):

[0001628280-24-008053:notes:164]
| Year Ending December 31: |  |
| 2024 | $ | 56,819 |  |
| 2025 | 52,188 |  |
| 2026 | 41,088 |  |
| 2027 | 21,118 |  |
| Thereafter | 1,059 |  |
|  | $ | 172,272 |  |

[0001628280-24-008053:notes:165]
Contract Balances from Contracts with Customers

[0001628280-24-008053:notes:166]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of December 31, 2023 and December 31, 2022, the Company had $3.7 million and $2.9 million in current portion of contract assets and $0.5 million and $1.4 million in contract assets, noncurrent on the consolidated balance sheets, respectively.

[0001628280-24-008053:notes:167]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $19.1 million during the year ended December 31, 2023 that was included in the 2022 deferred revenue balance. The Company recognized revenue of $6.6 million during the year ended December 31, 2022 that was included in the 2021 deferred revenue balance.

[0001628280-24-008053:notes:168]
The following table provides a rollforward of deferred revenue (in thousands):

[0001628280-24-008053:notes:169]
| Balance at December 31, 2021 | $ | 9,074 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (6,632) |  |
| Revenue deferred | 33,526 |  |
| Balance at December 31, 2022 | $ | 35,968 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (19,104) |  |
| Revenue deferred | 54,626 |  |
| Balance at December 31, 2023 | $ | 71,490 |  |

[0001628280-24-008053:notes:170]
The following table presents the Company’s components of lease revenue (in thousands):

[0001628280-24-008053:notes:171]
|  | Twelve Months EndedDecember 31, |
|  | 2023 |  | 2022 |
| Revenue from sales-type leases | $ | — |  |  | $ | 1,123 |  |
| Interest income on lease receivables | 197 |  |  | 224 |  |
| Lease income - operating leases | 37,247 |  |  | 17,569 |  |
| Total lease revenue | $ | 37,444 |  |  | $ | 18,916 |  |

[0001628280-24-008053:notes:172]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified under interest income in the consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.9 million and $0.6 million during the years ended December 31, 2023 and 2022, respectively.

[0001628280-24-008053:notes:173]
Disaggregated Revenue

[0001628280-24-008053:notes:174]
The following table presents the Company’s revenue by revenue stream (in thousands). Certain prior period amounts have been reclassified to conform to current period presentation:

[0001628280-24-008053:notes:175]
|  | Twelve Months EndedDecember 31, |
|  | 2023 |  | 2022 |
| Product revenue | $ | 21,977 |  |  | $ | 31,985 |  |
| Leased equipment | 37,247 |  |  | 17,569 |  |
| Service revenue | 16,141 |  |  | 4,331 |  |
| License fees | 2,963 |  |  | — |  |
| Professional services and other revenue | 2,090 |  |  | 1,310 |  |
| Total revenue | $ | 80,418 |  |  | $ | 55,195 |  |

[0001628280-24-008053:notes:176]
The following table presents the Company's revenue by geographical region based on customer location (in thousands):

[0001628280-24-008053:notes:177]
|  | Twelve Months EndedDecember 31, |
|  | 2023 |  | 2022 |
| United States | $ | 78,556 |  |  | $ | 53,815 |  |
| Foreign | 1,862 |  |  | 1,380 |  |
| Total revenue | $ | 80,418 |  |  | $ | 55,195 |  |

[0001628280-24-008053:notes:178]
Commissions

[0001628280-24-008053:notes:179]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $11.4 million and $9.0 million as of December 31, 2023 and December 31, 2022, respectively. During the years ended December 31, 2023 and 2022, the Company recognized commission expense of $5.6 million and $4.1 million, respectively.

[0001628280-24-008053:notes:180]
Give Evolv LLC

[0001628280-24-008053:notes:181]
Upon the closing of the Merger, the NHIC Founders transferred 517,500 shares of its common stock to Evolv NewHold Benefit LLC (“ENHB”), which represented the initial contribution to be used to pay for the donation of Evolv’s Express units to public venues and institutions, primarily schools in locations that might not otherwise be able to afford weapon detection security screening systems and related products and services. In September 2021, ENHB was renamed to Give Evolv LLC (“Give Evolv”). Give Evolv is deemed an entity under common control and a consolidating entity as it is under the same management as the Company. As such, the shares held by Give Evolv are not considered outstanding or issued.

[0001628280-24-008053:notes:182]
For such arrangements, Give Evolv generally purchases the related products and services from Evolv through an intercompany transaction using the available donated proceeds from the transfer of common stock upon the closing of the Merger. Evolv will be responsible for the delivery of the units, in addition to providing related services, such as installation, training, and maintenance. Consideration transferred to Evolv for the related products and services may be in the form of common stock or cash. Shares of common stock may be sold to generate funds for the purposes of paying for the donated goods and services. The sales transactions between Evolv and Give Evolv eliminate in consolidation.

[0001628280-24-008053:notes:183]
During the year ended December 31, 2023, the Company donated five Evolv Express units to schools resulting in $0.2 million in general and administrative expenses in the Company's consolidated statements of operations and comprehensive loss. During the year ended December 31, 2022, the Company donated six Evolv Express units to schools, resulting in $0.2 million in general and administrative expenses in the Company's consolidated statements of operations and comprehensive loss.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-24-008053:notes:184]
Leases
Company Headquarters (Waltham, MA)

[0001628280-24-008053:notes:185]
In April 2021, the Company entered into a sublease agreement for office and storage space for its corporate headquarters located at 500 Totten Pond Road in Waltham, MA. The Company entered into an amendment to the sublease agreement in August 2023 in order to lease additional space within the building. The sublease expires on October 31, 2024. The Company is required to maintain a minimum cash balance of $0.3 million as a security deposit on the space which is classified as restricted cash, current on the consolidated balance sheets. The Company pays for its proportionate share of building operating expenses and taxes that are treated as variable costs and excluded from the measurement of the lease. The sublease grants the Company an option to extend the term for an additional three years at the fair market rent by giving

[0001628280-24-008053:notes:186]
the landlord nine months written notice. The Company was not reasonably certain to exercise the option to extend the lease and therefore the extension term was excluded from the measurement of the lease.

[0001628280-24-008053:notes:187]
Storage Facilities

[0001628280-24-008053:notes:188]
The Company additionally leases three storage spaces on a month-to-month basis that are classified as short-term leases.

[0001628280-24-008053:notes:189]
Operating lease cost recognized during the years ended December 31, 2023 and December 31, 2022 was $1.2 million and $1.0 million, respectively. Cash paid for amounts included in the measurement of lease liabilities for the years ended December 31, 2023 and December 31, 2022 was $1.4 million and $1.1 million, respectively.

[0001628280-24-008053:notes:190]
The weighted-average remaining lease term and discount rate were as follows:

[0001628280-24-008053:notes:191]
|  | December 31, |
|  | 2023 |  | 2022 |
| Weighted average remaining lease term | 0.8 years |  | 1.8 years |
| Weighted average discount rate | 7.75 | % |  | 6.95 | % |

[0001628280-24-008053:notes:192]
Future annual lease payments under non-cancelable operating leases as of December 31, 2023 were as follows (in thousands):

[0001628280-24-008053:notes:193]
| Year Ended December 31: |  |
| 2024 | $ | 1,432 |  |
| 2025 | — |  |
| Total future lease payments | 1,432 |  |
| Less: imputed interest | (41) |  |
| Present value of operating lease liability | $ | 1,391 |  |


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001628280-24-008053:notes:194]
Accounts Receivable
Allowance for Expected Credit Losses

[0001628280-24-008053:notes:195]
Changes in the allowance for expected credit losses were as follows (in thousands):

[0001628280-24-008053:notes:196]
|  | Allowance for Expected Credit Losses |
| December 31, 2021 | $ | (50) |  |
| Provisions | (150) |  |
| Write-offs, net of recoveries | — |
| December 31, 2022 | $ | (200) |  |
| Provisions | (410) |  |
| Write-offs, net of recoveries | 28 |
| December 31, 2023 | $ | (582) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001628280-24-008053:notes:197]
Inventory
Inventory consisted of the following (in thousands):

[0001628280-24-008053:notes:198]
|  | December 31, |
|  | 2023 |  | 2022 |
| Raw materials | $ | 1,869 |  |  | $ | 2,334 |  |
| Finished goods | 7,638 |  |  | 7,923 |  |
| Total | $ | 9,507 |  |  | $ | 10,257 |  |


## nhic:PrepaidExpenseAndOtherAssetsCurrentTextBlock

[0001628280-24-008053:notes:199]
Prepaid expenses and other current assets
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001628280-24-008053:notes:200]
|  | December 31, |
|  | 2023 |  | 2022 |
| Prepaid deposits | $ | 12,177 |  |  | $ | 9,666 |  |
| Prepaid subscriptions | 1,868 |  |  | 897 |  |
| Current portion of net investment in sales-type leases | 367 |  |  | 337 |  |
| Prepaid insurance | 1,208 |  |  | 2,374 |  |
| Other | 1,334 |  |  | 1,114 |  |
| Total | $ | 16,954 |  |  | $ | 14,388 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-24-008053:notes:201]
Property and Equipment, Net
Property and equipment, net consisted of the following (in thousands):

[0001628280-24-008053:notes:202]
|  | December 31, |
|  | 2023 |  | 2022 |
| Computers and telecom equipment | $ | 1,331 |  |  | $ | 599 |  |
| Lab equipment | 1,171 |  |  | 871 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 566 |  |  | 542 |  |
| Leased equipment | 80,206 |  |  | 35,983 |  |
| Capitalized software | 8,629 |  |  | 4,150 |  |
| Sales demo equipment | 2,758 |  |  | 2,340 |  |
| Equipment held for lease1 | 32,910 |  |  | 7,826 |  |
| Construction in progress | 2,493 |  |  | 71 |  |
|  | 130,175 |  |  | 52,493 |  |
| Less: Accumulated depreciation and amortization | (17,254) |  |  | (7,786) |  |
|  | $ | 112,921 |  |  | $ | 44,707 |  |

[0001628280-24-008053:notes:203]
(1) Represents equipment that has not yet been deployed to a customer and, accordingly, is not being depreciated.

[0001628280-24-008053:notes:204]
As of December 31, 2023 and 2022, the net book value of capitalized software was $7.0 million and $3.5 million, respectively. These amounts include $0.7 million and approximately $0.2 million of capitalized stock compensation costs, respectively. Depreciation expense and amortization expense related to property and equipment was $9.9 million and $5.5

[0001628280-24-008053:notes:205]
million for the years ended December 31, 2023 and 2022, respectively, which included amortization expense of capitalized software of $1.0 million and $0.6 million for the years ended December 31, 2023 and 2022, respectively.

[0001628280-24-008053:notes:206]
Leased equipment and the related accumulated depreciation were as follows:

[0001628280-24-008053:notes:207]
|  | December 31, |
|  | 2023 |  | 2022 |
| Leased equipment | $ | 80,206 |  |  | $ | 35,983 |  |
| Accumulated depreciation | (13,283) |  |  | (5,802) |  |
| Leased equipment, net | $ | 66,923 |  |  | $ | 30,181 |  |

[0001628280-24-008053:notes:208]
Depreciation expense related to leased units was $8.0 million and $4.3 million during the years ended December 31, 2023 and 2022, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.
Loss from impairment of property and equipment was $0.3 million and $1.2 million during the years ended December 31, 2023 and 2022, respectively. This primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in an impairment of the remaining economic value of such units.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001628280-24-008053:notes:209]
Accrued Expenses and Other Current Liabilities
Accrued expenses and other current liabilities consisted of the following (in thousands):

[0001628280-24-008053:notes:210]
|  | December 31, |
|  | 2023 |  | 2022 |
| Accrued employee compensation and benefits expense | $ | 7,780 |  |  | $ | 7,225 |  |
| Accrued professional services and consulting | 1,579 |  |  | 722 |  |
| Accrued sales tax | 1,643 |  |  | 1,680 |  |
| Purchase order cancellation fees | 1,188 |  |  | — |  |
| Other | 3,388 |  |  | 1,918 |  |
|  | $ | 15,578 |  |  | $ | 11,545 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-24-008053:notes:211]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001628280-24-008053:notes:212]
|  | December 31, |
|  | 2023 |  | 2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | (10,000) |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |

[0001628280-24-008053:notes:213]
Silicon Valley Bank Term Loan Agreement

[0001628280-24-008053:notes:214]
In December 2022, the Company entered into a loan and security agreement (the "2022 SVB Credit Agreement") with Silicon Valley Bank ("SVB") in order to finance purchases of hardware to be leased to customers. The 2022 SVB Credit Agreement provided for an initial term loan advance of $30.0 million, which was approximately equivalent to the value of all hardware purchases made to support leasing transactions with the Company's customers through December 21,

[0001628280-24-008053:notes:215]
2022 (the "SVB Closing Date"), with the opportunity to obtain, within 18 months after the SVB Closing Date, additional term loan advances, subject to the satisfaction of certain conditions, in an aggregate principal amount equal to $20.0 million (subject to an increase of an additional $25.0 million upon the satisfaction of certain conditions and approval from SVB). The interest rate applicable to the SVB term loans was the greater of (a) the Wall Street Journal Prime Rate plus 1.0% or (b) 7.25% per annum. Interest and principal under the 2022 SVB Credit Agreement was payable monthly.

[0001628280-24-008053:notes:216]
On March 10, 2023, SVB was closed by the California Department of Financial Protection and Innovation, which appointed the Federal Deposit Corporation ("FDIC") as receiver. The FDIC created a successor bridge bank, Silicon Valley Bridge Bank, N.A. ("SVBB"), and all deposits of SVB were transferred to SVBB under a systemic risk exception approved by the Federal Reserve Board, the U.S. Treasury Department, and the FDIC. On March 12, 2023, the Federal Reserve Board, the U.S. Treasury Department, and the FDIC announced in a joint statement that all SVB deposits, including both insured and uninsured amounts, would be available in full to account holders. SVB was acquired by First Citizens Bank on March 27, 2023.

[0001628280-24-008053:notes:217]
In light of the foregoing, on March 28, 2023, upon the recommendation of the Company’s newly-formed Investment Committee of the Board of Directors, the Company (i) gave notice of its desire and intent to terminate the commitments under the 2022 SVB Credit Agreement and (ii) transferred its excess cash out of First Citizens Bank (the “Transfer”). The Transfer resulted in an event of default under the 2022 SVB Credit Agreement. Upon the occurrence of such event of default, First Citizens Bank could have, but was not required to, declare all obligations under the 2022 SVB Credit Agreement immediately due and payable. First Citizens Bank did not make such declaration following such event of default. 
On March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs.


## nhic:WarrantsAndRightsNoteDisclosureTextBlock

[0001628280-24-008053:notes:218]
Warrants
As of December 31, 2023 and 2022, warrants to purchase the following classes of common stock outstanding consisted of the following:

[0001628280-24-008053:notes:219]
| December 31, 2023 |
| Warrant Description |  | Issuance Date |  | ContractualTerm(in years) |  | Underlying EquityInstrument |  | Balance SheetClassification |  | Shares IssuableUpon Exerciseof Warrant |  | WeightedAverageExercise Price |
| Finback Common Stock Warrants (see Note 15) |  | January 13, 2021 |  | 10 |  | Common stock |  | Equity |  | 1,317,327 |  |  | $ | 0.42 |  |
| Public Warrants (see Note 2) |  | July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,893 |  |  | $ | 11.50 |  |
|  |  |  |  |  |  |  |  |  |  | 15,642,220 |  |  |  |

[0001628280-24-008053:notes:220]
| December 31, 2022 |
| Warrant Description |  | Issuance Date |  | ContractualTerm(in years) |  | Underlying EquityInstrument |  | Balance SheetClassification |  | Shares IssuableUpon Exerciseof Warrant |  | WeightedAverageExercise Price |
| Finback Common Stock Warrants (see Note 15) |  | January 13, 2021 |  | 10 |  | Common stock |  | Equity |  | 2,421,200 |  |  | $ | 0.42 |  |
| Public Warrants (see Note 2) |  | July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,994 |  |  | $ | 11.50 |  |
|  |  |  |  |  |  |  |  |  |  | 16,746,194 |  |  |  |


## nhic:CommonStockDisclosureTextBlock

[0001628280-24-008053:notes:221]
Common Stock
Each share of common stock entitles the holder to one vote on all matters submitted to a vote of the Company’s stockholders. Common stockholders are entitled to receive dividends, as may be declared by the board of directors, subject to the preferential dividend rights of Preferred Stock. As of December 31, 2023 and 2022, no cash dividends had been declared or paid.
As of December 31, 2023 and 2022, the Company had reserved 80,298,297 and 79,795,376 shares, respectively, of common stock for the exercise of outstanding stock options, vesting of outstanding restricted stock units and performance stock units, vesting of contingent earn-out shares, vesting of contingently issuable common stock, granting of awards under the Company’s 2021 Equity Incentive Plan (see Note 15), and the exercise of outstanding warrants (see Note 13). In addition, as of December 31, 2023 and 2022, the Company had 6,315,248 and 4,863,198 shares, respectively, of common stock available to be issued under the 2021 Employee Stock Purchase Plan (see Note 15).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-24-008053:notes:222]
Stock-Based Compensation
2021 Equity Incentive Plan

[0001628280-24-008053:notes:223]
The Company’s 2021 Equity Incentive Plan (the “2021 Plan”) provides for the Company to grant incentive stock options or nonqualified stock options, restricted stock awards, restricted stock units, performance stock units, and other stock-based awards to employees, officers, directors, and non-employees of the Company. A total of 21,177,295 shares of common stock were initially authorized under the 2021 Plan, subject to annual evergreen increases of up to 5% of total common shares outstanding as of the end of the prior year. As of December 31, 2023, 14,007,370 shares were available for future grant under the 2021 Plan. Shares, units, and options that are expired, forfeited, canceled, or otherwise terminated without having been fully exercised will be available for future grant under the 2021 Plan. In addition, shares of common stock that are tendered to the Company by a participant to exercise an award are added to the number of shares of common stock available for future grants.

[0001628280-24-008053:notes:224]
The 2021 Plan is administered by the Board of Directors or, at the discretion of the Board of Directors, by a committee of the Board of Directors. The exercise prices, vesting, and other restrictions are determined at the discretion of the Board of Directors, or its committee if so delegated, except that the exercise price per share of stock options may not be less than 100% of the fair market value of a share of common stock on the date of grant and the term of the stock option may not be greater than ten years. Stock options granted to employees, officers, members of the Board of Directors and non-employees vesting terms are determined on an individual basis on the date of grant. Prior to the closing of the Merger, the Company’s Board of Directors valued the Company’s common stock, taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors which may have changed since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the fair value of each share of common stock underlying stock-based awards is based on the closing price of our common stock as reported by Nasdaq on the date of grant.

[0001628280-24-008053:notes:225]
Stock Options

[0001628280-24-008053:notes:226]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the years ended December 31, 2023 and 2022:

[0001628280-24-008053:notes:227]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |
| Risk-free interest rate | 4.2 | % |  | 1.6 | % |
| Expected term (in years) | 6.1 |  | 6.1 |
| Expected volatility | 87.5 | % |  | 75.0 | % |
| Expected dividend yield | 0.0 | % |  | 0.0 | % |

[0001628280-24-008053:notes:228]
The following tables summarize the Company’s stock option activity under the 2021 Equity Incentive Plan (in thousands, except for share and per share data):

[0001628280-24-008053:notes:229]
|  | Number ofShares |  | WeightedAverageExercise Price |  | WeightedAverageRemainingContractual Term (in years) |  | AggregateIntrinsic Value |
| Outstanding as of December 31, 2021 | 20,769,130 |  | $ | 0.39 |  |  |  |  |  |
| Granted | 2,262,925 |  | 3.49 |  |  |  |  |  |
| Exercised | (1,896,975) |  | 0.43 |  |  |  |  |  |
| Forfeited | (710,707) |  | 0.42 |  |  |  |  |  |
| Expired | (27,549) |  | 0.42 |  |  |  |  |  |
| Outstanding as of December 31, 2022 | 20,396,824 |  | $ | 0.73 |  |  |  |  |  |
| Granted | 2,840,421 |  | 3.12 |  |  |  |  |  |
| Exercised | (1,735,978) |  | 0.38 |  |  |  |  |  |
| Forfeited | (1,164,932) |  | 1.72 |  |  |  |  |  |
| Expired | (11,807) |  | 0.42 |  |  |  |  |  |
| Outstanding as of December 31, 2023 | 20,324,528 |  | $ | 1.04 |  |  | 6.0 |  | $ | 74,768 |  |
| Vested and expected to vest as of December 31, 2023 | 20,324,528 |  | $ | 1.04 |  |  | 6.0 |  | $ | 74,768 |  |
| Options exercisable as of December 31, 2023 | 16,114,401 |  | $ | 0.67 |  |  | 5.4 |  | $ | 65,339 |  |

[0001628280-24-008053:notes:230]
The aggregate intrinsic value of options is calculated as the difference between the exercise price of the stock options and the fair value of the Company’s common stock for those options that had exercise prices lower than the fair value of the Company’s common stock.

[0001628280-24-008053:notes:231]
The weighted average grant date fair value of stock options granted was $2.35 and $2.32 during the years ended December 31, 2023 and 2022, respectively. The aggregate intrinsic value of the stock options exercised was $8.7 million and $4.4 million during the years ended December 31, 2023 and 2022, respectively.

[0001628280-24-008053:notes:232]
Restricted Stock Units

[0001628280-24-008053:notes:233]
The following table summarizes the Company’s restricted stock units activity under its existing restricted stock unit plan:

[0001628280-24-008053:notes:234]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2021 | 1,951,924 |  | $ | 6.76 |  |
| Granted | 7,613,472 |  | 3.26 |  |
| Vested | (565,774) |  | 6.72 |  |
| Forfeited | (1,497,677) |  | 5.15 |  |
| Outstanding as of December 31, 2022 | 7,501,945 |  | $ | 3.54 |  |
| Granted | 9,477,014 |  | 3.48 |  |
| Vested | (2,833,155) |  | 3.55 |  |
| Forfeited | (1,099,125) |  | 3.54 |  |
| Outstanding as of December 31, 2023 | 13,046,679 |  | $ | 3.49 |  |

[0001628280-24-008053:notes:235]
During the years ended December 31, 2023 and 2022, the aggregate grant-date fair value of restricted stock units issued under the 2021 Plan was $33.0 million and $24.9 million, respectively. RSUs generally vest ratably over a three year period subject to the grantee's continued service through the applicable vesting date. During the year ended December 31, 2023 and 2022, the total fair value of shares vested was $10.1 million and $3.8 million, respectively.

[0001628280-24-008053:notes:236]
Performance Stock Units

[0001628280-24-008053:notes:237]
The following table summarizes the Company's performance stock units activity under its existing performance stock units plan:

[0001628280-24-008053:notes:238]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2021 | — |  |  | $ | — |  |
| Granted | 947,000 |  |  | 2.65 |  |
| Vested | — |  |  | — |  |
| Forfeited | (83,000) |  |  | 2.65 |  |
| Outstanding as of December 31, 2022 | 864,000 |  |  | $ | 2.65 |  |
| Granted | — |  |  | — |  |
| Vested | (432,000) |  |  | 2.65 |  |
| Forfeited | (52,000) |  |  | 2.67 |  |
| Outstanding as of December 31, 2023 | 380,000 |  |  | $ | 2.64 |  |

[0001628280-24-008053:notes:239]
Based upon the terms of the award agreements and achievement of the performance goal, 50% of the applicable performance stock units vested on January 1, 2023 and 50% on January 1, 2024, subject to the grantee’s continued service through the applicable vesting date.

[0001628280-24-008053:notes:240]
2021 Employee Stock Purchase Plan

[0001628280-24-008053:notes:241]
In July 2021, the Company’s Board of Directors adopted the 2021 Employee Stock Purchase Plan (“2021 ESPP”), which was subsequently approved by the Company’s stockholders and became effective on July 16, 2021. The 2021 ESPP authorizes the initial issuance of up to 3,435,748 shares of the Company’s common stock to eligible employees of the Company or, as designated by the Company’s Board of Directors, employees of a related company. The 2021 ESPP provides that the number of shares reserved and available for issuance under the 2021 ESPP will automatically increase each January 1, beginning on January 1, 2022 and ending on (and including) January 1, 2032, by an amount equal to the lesser of (i) 1% of the outstanding number of shares of common stock on the immediately preceding December 31 and (ii) such smaller number of shares as determined by the Company’s Board of Directors. As of December 31, 2023, 6,315,248 shares of the Company’s common stock were available for future issuance. The Company’s Board of Directors may from time to time grant or provide for the grant to eligible employees of options to purchase common stock under the 2021 ESPP during a specific offering period. As of December 31, 2023, no offerings have been approved.

[0001628280-24-008053:notes:242]
Finback Common Stock Warrants

[0001628280-24-008053:notes:243]
The Company utilized a Black-Scholes pricing model to determine the grant-date fair value of the Finback Common Stock Warrants. The assumptions used are presented in the following table:

[0001628280-24-008053:notes:244]
| Warrants - Black Scholes |  |
| Risk-free interest rate | 0.4 | % |
| Expected term (in years) | 3.0 |
| Expected volatility | 23.9 | % |
| Expected dividend yield | — | % |

[0001628280-24-008053:notes:245]
In January 2021, the Company granted warrants (the "Finback Common Stock Warrants") to purchase 2,552,913 shares of the Company's Class A common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC ("Finback"), a consulting group affiliated with one of the Company's stockholders. The Finback Common Stock Warrants vest upon meeting certain sales criteria as defined in a business development agreement (the "Finback BDA"), which has a term of 3 years. The Finback BDA expired on January 1, 2023, subject to a 1-year "tail period" expiring on January 1, 2024. During the tail period, the Finback Common Stock Warrants will continue to vest related to any sale consummated by the Company for which it is determined Finback provided services prior to January 1, 2023 in furtherance of the sale. The Finback Common Stock Warrants expire in January 2031. The Finback Common Stock Warrants are accounted for under ASC 718 Compensation – Stock Compensation as the warrants vest upon certain performance conditions being met. On the date of issuance, the Finback Common Stock Warrants were valued at $19.5 million.

[0001628280-24-008053:notes:246]
Upon the closing of the Merger, vested Finback Common Stock Warrants automatically converted into 131,713 shares of the Company’s common stock. As of December 31, 2023, 117,423 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $0.5 million. The remaining 1,199,904 Finback Common Stock Warrants are unvested and have a total unrecognized grant date fair value of $9.1 million. As of December 31, 2023, 1,103,873 of the Finback common stock warrants were exercised. The Company recognizes compensation expense for the Finback Common Stock Warrants when the warrants become vested based on meeting the specified sales criteria. During the years ended December 31, 2023 and 2022, the Company recorded $3.1 million and $4.5 million, respectively, of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants.

[0001628280-24-008053:notes:247]
Stock-based compensation expense was classified in the consolidated statements of operations and comprehensive loss as follows (in thousands):

[0001628280-24-008053:notes:248]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |
| Cost of revenue | $ | 583 |  | $ | 829 |
| Research and development | 4,284 |  | 4,009 |
| Sales and marketing | 9,387 |  | 10,038 |
| General and administrative | 9,897 |  | 7,622 |
| Total stock-based compensation expense | $ | 24,151 |  | $ | 22,498 |

[0001628280-24-008053:notes:249]
Stock-based compensation expense by award type recognized in the consolidated statements of operations and comprehensive loss was as follows (in thousands):

[0001628280-24-008053:notes:250]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |
| Stock options | $ | 2,925 |  | $ | 1,594 |
| Earn-out shares | 2,073 |  | 6,499 |
| Warrants | 3,147 |  | 4,523 |
| RSUs and PSUs | 16,006 |  | 9,882 |
| Total stock-based compensation expense | $ | 24,151 |  | $ | 22,498 |

[0001628280-24-008053:notes:251]
Total unrecognized compensation expense related to stock options and restricted stock units as of December 31, 2023, was $40.8 million, which is expected to be recognized over a weighted average period of 2.1 years. Total unrecognized compensation expense related to earn-out shares associated with the share-based compensation arrangement as of December 31, 2023, was $0.2 million, which is expected to be recognized over a weighted average period of 0.5 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-24-008053:notes:252]
Income Taxes
The components of the Company’s loss before income tax expense are as follows (in thousands):

[0001628280-24-008053:notes:253]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |
| United States | $ | (106,261) |  |  | $ | (85,760) |  |
| Foreign | 58 |  |  | (646) |  |
| Loss before income tax provision | $ | (106,203) |  |  | $ | (86,406) |  |

[0001628280-24-008053:notes:254]
Income tax expense is comprised of the following (in thousands):

[0001628280-24-008053:notes:255]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |
| Current: |  |  |  |
| Federal | $ | — |  | $ | — |
| State | 27 |  | — |
| Foreign | 24 |  | — |
| Total current income tax expense | $ | 51 |  | $ | — |
| Deferred: |  |  |  |
| Federal | $ | — |  | $ | — |
| State | — |  | — |
| Foreign | — |  | — |
| Total deferred income tax expense | $ | — |  | $ | — |
| Total income tax expense | $ | 51 |  | $ | — |

[0001628280-24-008053:notes:256]
The effective tax rate differs from the U.S. federal statutory rate primarily due to the full valuation allowance maintained on the Company’s net deferred tax assets and non-deductible fair value adjustments for the years ended December 31, 2023 and 2022. A reconciliation of the U.S. federal statutory income tax rate to the Company’s effective income tax rate is as follows:

[0001628280-24-008053:notes:257]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |
| Federal statutory income tax rate | 21.0 % |  | 21.0 % |
| State income taxes, net of federal benefit | 3.4 |  |  | 3.5 |  |
| Federal and state research and development tax credits | — |  |  | (1.2) |  |
| Change in fair value of contingent earn-out liability and contingently issuable common stock liability | (4.5) |  |  | 3.4 |  |
| Change in valuation allowance | (16.9) |  |  | (23.6) |  |
| Change in uncertain tax positions | (0.4) |  |  | — |  |
| Change in tax rate | 0.8 |  |  | (0.1) |  |
| Stock-based compensation | (0.6) |  |  | (0.2) |  |
| Non-deductible compensation | (2.4) |  |  | (2.6) |  |
| Permanent differences | (0.1) |  |  | (0.2) |  |
| Other | (0.3) |  |  | — |  |
| Effective income tax rate | 0.0 | % |  | 0.0 | % |

[0001628280-24-008053:notes:258]
Net deferred tax assets consisted of the following (in thousands):

[0001628280-24-008053:notes:259]
|  | December 31, |
|  | 2023 |  | 2022 |
| Deferred tax assets: |  |  |  |
| Net operating loss carryforwards | $ | 41,541 |  | $ | 36,518 |
| Research and development tax credit carryforwards | 3,802 |  | 3,836 |
| Capitalized research and development costs | 13,043 |  | 9,965 |
| Accrued expenses | 7,230 |  | 6,660 |
| Deferred revenue | 18,206 |  | 8,884 |
| Lease liability | 351 |  | 490 |
| Other | 1,305 |  | 106 |
| Total deferred tax assets | 85,478 |  | 66,459 |
| Valuation allowance | (82,558) |  |  | (64,570) |  |
| Total deferred tax assets, net of valuation allowance | 2,920 |  | 1,889 |
| Deferred tax liabilities: |  |  |  |
| Depreciation and amortization | (2,601) |  |  | (1,464) |  |
| Right of use lease asset | (302) |  | (409) |
| Other | (17) |  | (16) |
| Total deferred tax liabilities | (2,920) |  | (1,889) |
| Net deferred tax assets | $ | — |  | $ | — |

[0001628280-24-008053:notes:260]
As of December 31, 2023 and December 31, 2022, the Company had gross federal net operating losses of $20.1 million and $20.1 million that are subject to expire at various dates beginning in 2033, and federal net operating losses of $142.4 million and $124.3 million, which have no expiration date and can be used to offset up to 80% of future taxable income in any one tax period, respectively. The Company also had gross state net operating loss carryforwards of $142.4

[0001628280-24-008053:notes:261]
million and $103.8 million for the years ended December 31, 2023 and 2022, respectively, which may be available to offset future state taxable income and which begin to expire in 2033. Additionally, the Company had no UK net operating loss carryforwards as of December 31, 2023 and gross UK net operating loss carryforwards of approximately $2.3 million that will not expire as of December 31, 2022. As of December 31, 2023, the Company had gross U.S. federal and state research and development and other tax credit carryforwards of $2.5 million and $1.6 million, respectively, which may be available to offset future tax liabilities and the majority of which begin to expire in 2033 and 2030, respectively. As of December 31, 2022, the Company had gross U.S. federal and state research and development and other tax credit carryforwards of $2.5 million and $1.6 million, respectively, which may be available to offset future tax liabilities and the majority of which begin to expire in 2033 and 2029, respectively.

[0001628280-24-008053:notes:262]
Utilization of the U.S. federal and state net operating loss carryforwards and research and development tax credit carryforwards may be subject to a substantial annual limitation under Sections 382 and 383 of the Internal Revenue Code of 1986, and corresponding provisions of state law, due to ownership changes that have occurred previously or that could occur in the future. These ownership changes may limit the amount of carryforwards that can be utilized annually to offset future taxable income or tax liabilities. In general, an ownership change, as defined by Section 382, results from transactions increasing the ownership of certain stockholders or public groups in the stock of a corporation by more than 50% over a three-year period. The Company has not conducted a study to assess whether a change of control has occurred or whether there have been multiple changes of control since inception due to the significant complexity and cost associated with such a study. If the Company has experienced a change of control, as defined by Section 382, at any time since inception, utilization of the net operating loss carryforwards or research and development tax credit carryforwards would be subject to an annual limitation under Section 382, which is determined by first multiplying the value of the Company’s stock at the time of the ownership change by the applicable long-term tax-exempt rate, and then could be subject to additional adjustments, as required. Any limitation may result in expiration of a portion of the net operating loss carryforwards or research and development tax credit carryforwards before utilization.

[0001628280-24-008053:notes:263]
The Company considered the significant negative evidence of its history of cumulative net operating losses incurred since inception, as well as other positive and negative evidence bearing upon its ability to realize the deferred tax assets, and has concluded that it is more likely than not that the Company will not realize the benefits of the deferred tax assets. Accordingly, a full valuation allowance has been established against the net deferred tax assets as of December 31, 2023 and 2022. If or when recognized, the tax benefits related to any reversal of the valuation allowance on deferred tax assets as of December 31, 2023, will be accounted for as follows: approximately $80.0 million will be recognized as a reduction of income tax expense and $2.5 million will be recorded as an increase in equity. The Company reevaluates the positive and negative evidence at each reporting period.

[0001628280-24-008053:notes:264]
Changes in the valuation allowance for deferred tax assets related primarily to the increase in net operating loss carryforwards and capitalized R&D costs and were as follows (in thousands):

[0001628280-24-008053:notes:265]
|  | December 31, |
|  | 2023 |  | 2022 |
| Valuation allowance as of beginning of year | $ | 64,570 |  | $ | 43,966 |
| Additions charged to provision for income taxes | 17,988 |  | 20,320 |
| Additions charged to equity | — |  | 332 |
| Currency translation and other | — |  | (48) |
| Valuation allowance as of end of year | $ | 82,558 |  | $ | 64,570 |

[0001628280-24-008053:notes:266]
The Company accounts for income tax uncertainties in accordance with ASC 740 Income Taxes, which prescribes a recognition threshold and measurement criteria for the financial statement recognition and measurement of a tax position taken or expected to be taken in a tax return. Benefits from tax positions should be recognized in the financial statements only when it is more likely than not that the tax position will be sustained upon examination by the appropriate taxing authority that would have full knowledge of all relevant information. A tax position that meets the more likely than not recognition threshold is measured at the largest amount of benefit that is greater than fifty percent likely of being realized upon ultimate settlement. Tax positions that previously failed to meet the more likely than not recognition threshold should be recognized in the first subsequent financial reporting period in which that threshold is met. Previously recognized tax positions that no longer meet the more likely than not recognition threshold should be derecognized in the first subsequent

[0001628280-24-008053:notes:267]
financial reporting period in which that threshold is no longer met. ASC 740 also provides guidance on the accounting for and disclosure of liabilities for uncertain tax positions, interest and penalties. The Company’s policy is to record interest and penalties related to income taxes as part of its income tax provision.

[0001628280-24-008053:notes:268]
The following table summarizes the activity related to the Company’s uncertain tax positions (excluding interest and penalties and related tax attributes) (in thousands):

[0001628280-24-008053:notes:269]
|  | December 31, |
|  | 2023 |  | 2022 |
| Balance at beginning of fiscal year | $ | — |  | $ | — |
| Gross increases related to prior year tax positions | 407 |  | — |
| Foreign exchange and others | 21 |  | — |
| Balance at end of fiscal year | $ | 428 |  | $ | — |

[0001628280-24-008053:notes:270]
The Company’s liability for uncertain tax positions as of December 31, 2023, includes $0.4 million related to amounts that, if recognized, would affect the effective tax rate (excluding related interest and penalties).

[0001628280-24-008053:notes:271]
The Company files income tax returns as prescribed by the tax laws of the jurisdictions in which it operates. In the normal course of business, the Company is subject to examination by federal, state, and non-US jurisdictions, where applicable. The Company is open to future tax examinations in the US under statute from 2020 to the present; however, carryforward attributes that were generated prior to 2020 may still be adjusted upon examination by federal, state, or local tax authorities if they either have been or will be used in a future period. The Company is also open for future tax examinations under statute from 2021 to the present in the UK. The Company has not received notice of examination in any jurisdictions for any tax year open under statute.


## us-gaap:EarningsPerShareTextBlock

[0001628280-24-008053:notes:272]
Net Loss per Share
Basic and diluted net loss per share attributable to common stockholders was calculated as follows (in thousands, except share and per share amounts):

[0001628280-24-008053:notes:273]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |
| Numerator: |  |  |  |
| Net income (loss) attributable to common stockholders – basic and diluted | $ | (106,254) |  |  | $ | (86,406) |  |
| Denominator: |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 149,168,105 |  | 143,858,668 |
| Net loss per share attributable to common stockholders – basic and diluted | $ | (0.71) |  |  | $ | (0.60) |  |

[0001628280-24-008053:notes:274]
The following potentially dilutive outstanding securities were excluded from the computation of diluted net loss per share attributable to common stockholders because their effect would have been anti-dilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the period:

[0001628280-24-008053:notes:275]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |
| Options issued and outstanding | 20,324,528 |  |  | 20,396,824 |  |
| Public Warrants to purchase common stock | 14,324,893 |  |  | 14,324,994 |  |
| Warrants to purchase common stock (Finback)** | 1,317,327 |  |  | 2,421,200 |  |
| Unvested restricted stock units | 13,046,679 |  |  | 7,501,945 |  |
| Unvested performance stock units | 380,000 |  |  | 864,000 |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |
| Contingently issuable common stock* | 1,897,500 |  |  | 1,897,500 |  |
|  | 66,290,927 |  |  | 62,406,463 |  |

[0001628280-24-008053:notes:276]
*Issuance of Earn-out shares and Contingently issuable common stock is contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period.

[0001628280-24-008053:notes:277]
**Includes 117,423 vested warrants and 1,199,904 unvested warrants as of December 31, 2023.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-24-008053:notes:278]
Related Party Transactions
Business Development Agreement with Finback

[0001628280-24-008053:notes:279]
In January 2021, the Company granted the Finback Common Stock Warrants subject to the terms of the Finback BDA, as discussed in Note 15.

[0001628280-24-008053:notes:280]
In connection with the Merger and pursuant to the Merger Agreement, in addition to earn-out shares allocated to Finback based on its common stock ownership percentage as of the Merger date, Finback is entitled to receive a proportional share of earn-out shares based upon its remaining unvested warrants as of the Merger Date.

[0001628280-24-008053:notes:281]
Original Equipment Manufacturer Partnership Agreement with Motorola Solutions, Inc.

[0001628280-24-008053:notes:282]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the years ended December 31, 2023 and 2022, revenue from Motorola’s distributor services was $9.6 million and $11.6 million, respectively. As of December 31, 2023 and 2022, accounts receivable related to Motorola’s distributor services were $1.2 million and $12.5 million, respectively.

[0001628280-24-008053:notes:283]
Reseller Agreement with Stanley Black & Decker

[0001628280-24-008053:notes:284]
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB ("Securitas") in 2023. Securitas, directly or through its affiliates, resells the Company's products. During the years ended December 31, 2023 and 2022, revenue from Stanley Black & Decker’s reseller services was $1.7 million and $1.9 million, respectively. As of December 31, 2023 and 2022, accounts receivable related to Stanley Black & Decker’s reseller services were $0.6 million and $2.2 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-24-008053:notes:285]
Commitments and Contingencies
Indemnification Agreements

[0001628280-24-008053:notes:286]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its consolidated financial statements as of December 31, 2023 or 2022.

[0001628280-24-008053:notes:287]
Legal Proceedings

[0001628280-24-008053:notes:288]
The Company is not a party to any litigation of a material nature and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.

[0001628280-24-008053:notes:289]
In the ordinary course of business, the Company is subject to regulatory and governmental examinations, information gathering requests, inquiries, and investigations. The FTC has previously requested information about certain aspects of the Company's marketing practices. The Company is cooperating with the investigation and has provided documentation and information responsive to the FTC inquiry. We currently do not expect this investigation to have a material effect on our results of operations, financial condition or liquidity, either individually or in the aggregate.

[0001628280-24-008053:notes:290]
Further, in February 2024, we received a subpoena from the SEC, Division of Enforcement, requesting that we produce certain documents and information, much of which is similar to the documents and information previously requested by the FTC. We are cooperating and intend to continue to cooperate with the SEC's investigation.

[0001628280-24-008053:notes:291]
We can offer no assurances as to the outcome of these investigations or their potential effect, if any, on us or our results of operations. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001628280-24-008053:notes:292]
Benefit Plans
The Company established a defined contribution savings plan under Section 401(k) of the Code. This plan covers all employees who meet minimum age and service requirements and allows participants to defer a portion of their annual compensation on a pre-tax basis. The Company made $0.3 million matching contributions to the plan during the year ended December 31, 2023. The Company did not make any matching contributions to the plan during the year ended December 31, 2022.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-24-008053:notes:293]
On December 15, 2023, Anil Chitkara, Chief Growth Officer and Founder, adopted a Rule 10b5-1 trading plan that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the sale of up to 200,000 shares of the Company’s common stock until September 6, 2024.
