# EVLV 8-K — 0001628280-24-007980 filed 2024-02-29

## item codes, every 8-K on or before 2024-02-29

- 2024-02-29 0001628280-24-007980 — 2.02, 9.01
- 2024-02-20 0001104659-24-025077 — 7.01, 9.01
- 2024-01-31 0001628280-24-002618 — 5.03, 9.01
- 2023-11-09 0001628280-23-038267 — 2.02, 9.01
- 2023-11-06 0001104659-23-114499 — 5.02
- 2023-10-25 0001628280-23-035145 — 4.02
- 2023-10-12 0001104659-23-108693 — 2.02, 7.01, 9.01
- 2023-08-10 0001628280-23-028861 — 2.02, 9.01
- 2023-06-02 0001628280-23-020680 — 5.07
- 2023-05-10 0001628280-23-017243 — 2.02, 9.01
- 2023-04-03 0001628280-23-010402 — 1.02, 2.04, 8.01, 9.01
- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2024-02-29

- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-24-007980:8k_2_02:1]
EX-99.1
2
evlv-20240229exx991.htm
EX-99.1

[0001628280-24-007980:8k_2_02:2]
Document

[0001628280-24-007980:8k_2_02:3]
Exhibit 99.1

[0001628280-24-007980:8k_2_02:4]
Investor Relations:

[0001628280-24-007980:8k_2_02:5]
Brian Norris

[0001628280-24-007980:8k_2_02:6]
Senior Vice President of Finance and Investor Relations

[0001628280-24-007980:8k_2_02:7]
bnorris@evolvtechnology.com

[0001628280-24-007980:8k_2_02:8]
Evolv Technology Reports Record Fourth Quarter and Full Year Financial Results

[0001628280-24-007980:8k_2_02:9]
•Q4 Revenue of $21.8 million, up 4% year-over-year

[0001628280-24-007980:8k_2_02:10]
•Q4 Ending ARR1 of $75.0 million, up 120% year-over-year

[0001628280-24-007980:8k_2_02:11]
•Q4 Ending RPO2 of $240.5 million, up 66% year-over-year

[0001628280-24-007980:8k_2_02:12]
•Q4 Ending Evolv Express® subscriptions of 4,505, up 99% year-over-year

[0001628280-24-007980:8k_2_02:13]
Waltham, Massachusetts – February 29, 2024 – Evolv Technology (NASDAQ: EVLV), the leading security technology company pioneering AI-based weapons detection to create safer experiences, today announced financial results for the quarter and year ended December 31, 20233 and issued its outlook for 2024.

[0001628280-24-007980:8k_2_02:14]
Results for the Fourth Quarter of 2023

[0001628280-24-007980:8k_2_02:15]
Total revenue for the fourth quarter of 2023 was $21.8 million, an increase of 4% compared to $20.9 million for the fourth quarter of 2022. Annual Recurring Revenue (“ARR”)1 was $75.0 million at the end of fourth quarter of 2023, an increase of 120% compared to $34.1 million at the end of fourth quarter of 2022. Net loss for the fourth quarter of 2023 was $(16.9) million, or $(0.11) per basic and diluted share, compared to net loss of $(28.3) million or $(0.20) per basic and diluted share in the fourth quarter of 2022. Adjusted net loss3 for the fourth quarter of 2023 was $(11.0) million, or $(0.07) per diluted share, compared to adjusted loss3 of $(18.3) million, or $(0.13) per diluted share, for the fourth quarter of 2022. Adjusted EBITDA3 for the fourth quarter of 2023 was $(9.5) million compared to $(18.0) million in the fourth quarter of 2022. As of December 31, 2023, the Company had cash, cash equivalents, marketable securities, and restricted cash of $118.7 million and no debt.

[0001628280-24-007980:8k_2_02:16]
Results for 2023

[0001628280-24-007980:8k_2_02:17]
Total revenue in 2023 was $80.4 million, an increase of 46% compared to $55.2 million in 2022. Net loss in 2023 was $(106.3) million, or $(0.71) per basic and diluted share, compared to net loss of $(86.4) million, or $(0.60) per basic and diluted share, in 2022. Adjusted net loss3 in 2023 was $(54.2) million, or $(0.36) per diluted share, compared to $(72.7) million, or $(0.51) per diluted share, in 2022. Adjusted EBITDA3 in 2023 was $(49.8) million, compared to $(69.7) million in 2022.

[0001628280-24-007980:8k_2_02:18]
The following table summarizes the breakdown of recurring and non-recurring revenue4 during each year:

[0001628280-24-007980:8k_2_02:19]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2023 |  | 2022 |  | % Change |  | 2023 |  | 2022 |  | % Change |
| Recurring revenue | $ | 17,350 |  |  | $ | 7,388 |  |  | 135 | % |  | $ | 52,491 |  |  | $ | 21,372 |  |  | 146 | % |
| Non-recurring revenue | 4,471 |  |  | 13,497 |  |  | (67) | % |  | 27,927 |  |  | 33,823 |  |  | (17) | % |
| Total revenue | $ | 21,821 |  |  | $ | 20,885 |  |  | 4 | % |  | $ | 80,418 |  |  | $ | 55,195 |  |  | 46 | % |

[0001628280-24-007980:8k_2_02:20]
The following table summarizes operating cash flows during each year:

[0001628280-24-007980:8k_2_02:21]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net loss | $ | (16,890) |  |  | $ | (28,304) |  |  | $ | (106,254) |  |  | $ | (86,406) |  |
| Non-cash expense | 7,970 |  |  | 12,928 |  |  | 59,754 |  |  | 17,331 |  |
| Changes in operating assets and liabilities | 5,777 |  |  | 10,069 |  |  | 36,699 |  |  | (5,653) |  |
| Net cash used in operating activities | $ | (3,143) |  |  | $ | (5,307) |  |  | $ | (9,801) |  |  | $ | (74,728) |  |

[0001628280-24-007980:8k_2_02:22]
Company Reaffirms Outlook for 2024

[0001628280-24-007980:8k_2_02:23]
The Company today commented on its business outlook for 2024. The Company's outlook is based on the current indications for its business, which may change at any time.

[0001628280-24-007980:8k_2_02:24]
|  |  | 2024 Business Outlook |
| Estimate (In millions) |  | Issued November 9, 2023 |  | Issued February 29, 2024 |
| Total Revenue |  | ~$115 |  | Reaffirmed |
| ARR1 (ARR) at 12/31/24 |  | $108-$112 |  | Reaffirmed |
| Adjusted Gross Margin3 |  | ~60% |  | Reaffirmed |
| Adjusted EBITDA3 |  | Improve by 40%+ |  | Reaffirmed |

[0001628280-24-007980:8k_2_02:25]
Company to Host Live Conference Call and Webcast

[0001628280-24-007980:8k_2_02:26]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business and other matters.  The conference call may be accessed in the United States by dialing +1.877.692.8955 and using access code 825879.  The conference call may be accessed outside of the United States by dialing +1.234.720.6979 and using the same access code. The conference call will be simultaneously webcast on the Company’s investor relations website, which can be accessed at http://ir.evolvtechnology.com.  The press release with the financial results as well as the accompanying investor presentation materials will be accessible from the Company’s website prior to the conference call.  A replay of the conference call will be available for a period of 30 days by dialing +1.866.207.1041 or +1.402.970.0847 and using access code 4005393 or by accessing the webcast replay on the Company’s investor relations website at http://ir.evolvtechnology.com

[0001628280-24-007980:8k_2_02:27]
About Evolv Technology

[0001628280-24-007980:8k_2_02:28]
Evolv Technology (NASDAQ: EVLV) is transforming human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered weapons detection and analytics. Its mission is to transform security to create a safer world to work, learn, and play. Evolv has digitally transformed the gateways in places where people gather by enabling seamless integration combined with powerful analytics and insights. Evolv’s advanced systems have scanned more than a billion people since 2019. Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category. Evolv Technology®, Evolv Express®, Evolv Insights®, Evolv Cortex AI®, and Evolv Visual Gun Detection™ are registered trademarks or trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit https://evolvtechnology.com.

[0001628280-24-007980:8k_2_02:29]
1 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001628280-24-007980:8k_2_02:30]
2 We define Remaining Performance Obligation, or RPO, as estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied or partially satisfied as of the end of the quarter.

[0001628280-24-007980:8k_2_02:31]
3 Non-GAAP Financial Measures In this press release, the Company’s adjusted gross profit (loss), adjusted gross margin, adjusted operating expenses, adjusted operating income (loss), adjusted EBITDA, adjusted earnings (loss), and adjusted earnings per basic and diluted share are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit and adjusted gross margin exclude one-time items and stock-based compensation expense which management believes provides a more meaningful representation of contribution margin. Adjusted operating expenses is defined as operating expenses less one-time items, stock-based compensation expense, restructuring expenses, and loss on impairment of lease equipment which management believes provides a more meaningful representation of on-going operating expense levels. Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, share-based compensation, and certain other one-time expenses. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, change in fair value of derivative liability, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, change in fair value of common stock warrant liability, restructuring expenses, loss on impairment of lease equipment, and certain other one-time expenses. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operating performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release. The Company is unable to provide a reconciliation of Adjusted Gross Margin to GAAP Gross Margin and non-GAAP Adjusted EBITDA to Net Income (Loss), each measure's most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact these GAAP financial measures are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of derivative liabilities, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001628280-24-007980:8k_2_02:32]
4 Recurring revenue includes the recurring portion of revenue associated with pure subscription contracts and hardware purchase subscription contracts. Non-recurring revenue includes revenue that is one-time in nature, such as product revenue, shipping revenue, and revenue from installation, training, and professional services.

[0001628280-24-007980:8k_2_02:33]
Forward-Looking Statements

[0001628280-24-007980:8k_2_02:34]
These statements reflect management’s current expectations regarding future events and operating performance and speak only as of the date of this press release. You should not put undue reliance on any forward-looking statements. Although we believe that the expectations reflected in the forward-looking statements are reasonable, we cannot guarantee that future results, levels of activity, performance and events and circumstances reflected in the forward-looking statements will be achieved or will occur. Except as required

[0001628280-24-007980:8k_2_02:35]
EVOLV TECHNOLOGY

[0001628280-24-007980:8k_2_02:36]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001628280-24-007980:8k_2_02:37]
(In thousands, except share and per share data)

[0001628280-24-007980:8k_2_02:38]
(Unaudited)

[0001628280-24-007980:8k_2_02:39]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 2,789 |  |  | $ | 12,806 |  |  | $ | 21,977 |  |  | $ | 31,985 |  |
| Subscription revenue | 12,586 |  |  | 5,361 |  |  | 37,247 |  |  | 17,569 |  |
| Service revenue | 5,015 |  |  | 2,094 |  |  | 16,141 |  |  | 4,331 |  |
| License fee and other revenue | 1,431 |  |  | 624 |  |  | 5,053 |  |  | 1,310 |  |
| Total revenue | 21,821 |  |  | 20,885 |  |  | 80,418 |  |  | 55,195 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 5,214 |  |  | 18,062 |  |  | 26,667 |  |  | 41,575 |  |
| Cost of subscription revenue | 5,003 |  |  | 1,739 |  |  | 14,991 |  |  | 7,469 |  |
| Cost of service revenue | 1,166 |  |  | 548 |  |  | 3,982 |  |  | 2,200 |  |
| Cost of license fee and other revenue | 177 |  |  | 482 |  |  | 949 |  |  | 2,222 |  |
| Total cost of revenue | 11,560 |  |  | 20,831 |  |  | 46,589 |  |  | 53,466 |  |
| Gross profit | 10,261 |  |  | 54 |  |  | 33,829 |  |  | 1,729 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,262 |  |  | 4,824 |  |  | 24,455 |  |  | 18,771 |  |
| Sales and marketing | 14,887 |  |  | 13,470 |  |  | 55,223 |  |  | 46,639 |  |
| General and administrative | 11,018 |  |  | 8,451 |  |  | 42,091 |  |  | 37,719 |  |
| Loss from impairment of property and equipment | — |  |  | 123 |  |  | 322 |  |  | 1,161 |  |
| Total operating expenses | 32,167 |  |  | 26,868 |  |  | 122,091 |  |  | 104,290 |  |
| Loss from operations | (21,906) |  |  | (26,814) |  |  | (88,262) |  |  | (102,561) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (223) |  |  | (654) |  |  | (712) |  |
| Interest income | 1,630 |  |  | 1,554 |  |  | 6,227 |  |  | 3,165 |  |
| Other expense, net | (17) |  |  | (7) |  |  | (84) |  |  | (64) |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | (626) |  |  | — |  |
| Change in fair value of contingent earn-out liability | 2,452 |  |  | (2,766) |  |  | (14,901) |  |  | 6,988 |  |
| Change in fair value of contingently issuable common stock liability | 422 |  |  | (657) |  |  | (3,138) |  |  | 1,872 |  |
| Change in fair value of public warrant liability | 580 |  |  | 609 |  |  | (4,765) |  |  | 4,906 |  |
| Total other income (expense), net | $ | 5,067 |  |  | $ | (1,490) |  |  | $ | (17,941) |  |  | $ | 16,155 |  |
| Loss before income taxes | (16,839) |  |  | (28,304) |  |  | (106,203) |  |  | (86,406) |  |
| Provision for income taxes | (51) |  |  | — |  |  | (51) |  |  | — |  |
| Net loss | $ | (16,890) |  |  | $ | (28,304) |  |  | $ | (106,254) |  |  | $ | (86,406) |  |
| Weighted average common shares outstanding – basic and diluted | 151,087,430 |  | 144,856,047 |  | 149,168,105 |  | 143,858,668 |
| Net loss per share - basic and diluted | $ | (0.11) |  |  | $ | (0.20) |  |  | $ | (0.71) |  |  | $ | (0.60) |  |
| Net loss | $ | (16,890) |  |  | $ | (28,304) |  |  | $ | (106,254) |  |  | $ | (86,406) |  |
| Other comprehensive loss |  |  |  |  |  |  |  |
| Cumulative translation adjustment | (44) |  |  | (45) |  |  | (43) |  |  | (10) |  |
| Total other comprehensive loss | (44) |  |  | (45) |  |  | (43) |  |  | (10) |  |
| Total comprehensive loss | $ | (16,934) |  |  | $ | (28,349) |  |  | $ | (106,297) |  |  | $ | (86,416) |  |

[0001628280-24-007980:8k_2_02:40]
EVOLV TECHNOLOGY

[0001628280-24-007980:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-24-007980:8k_2_02:42]
(In thousands, except share and per share data)

[0001628280-24-007980:8k_2_02:43]
(Unaudited)

[0001628280-24-007980:8k_2_02:44]
|  | December 31, 2023 |  | December 31, 2022 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 67,162 |  |  | $ | 229,783 |  |
| Restricted cash | 275 |  |  | — |  |
| Marketable securities | 51,289 |  |  | — |  |
| Accounts receivable, net | 22,611 |  |  | 31,920 |  |
| Inventory | 9,507 |  |  | 10,257 |  |
| Current portion of contract assets | 3,707 |  |  | 2,852 |  |
| Current portion of commission asset | 4,339 |  |  | 3,384 |  |
| Prepaid expenses and other current assets | 16,954 |  |  | 14,388 |  |
| Total current assets | 175,844 |  |  | 292,584 |  |
| Restricted cash, noncurrent | — |  |  | 275 |  |
| Contract assets, noncurrent | 451 |  |  | 1,386 |  |
| Commission asset, noncurrent | 7,107 |  |  | 5,655 |  |
| Property and equipment, net | 112,921 |  |  | 44,707 |  |
| Operating lease right-of-use assets | 1,195 |  |  | 1,673 |  |
| Other assets | 1,202 |  |  | 1,835 |  |
| Total assets | $ | 298,720 |  |  | $ | 348,115 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 17,400 |  |  | $ | 18,194 |  |
| Accrued expenses and other current liabilities | 15,578 |  |  | 11,545 |  |
| Current portion of deferred revenue | 47,677 |  |  | 18,273 |  |
| Current portion of long-term debt | — |  |  | 10,000 |  |
| Current portion of operating lease liabilities | 1,391 |  |  | 1,114 |  |
| Total current liabilities | 82,046 |  |  | 59,126 |  |
| Deferred revenue, noncurrent | 23,813 |  |  | 17,695 |  |
| Long-term debt, noncurrent | — |  |  | 19,683 |  |
| Operating lease liabilities, noncurrent | — |  |  | 892 |  |
| Contingent earn-out liability | 29,119 |  |  | 14,218 |  |
| Contingently issuable common stock liability | 6,530 |  |  | 3,392 |  |
| Public warrant liability | 10,889 |  |  | 6,124 |  |
| Total liabilities | 152,397 |  |  | 121,130 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at December 31, 2023 and December 31, 2022; no shares issued and outstanding at December 31, 2023 and December 31, 2022 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at December 31, 2023 and December 31, 2022, 151,310,080 and 145,204,974 shares issued and outstanding at December 31, 2023 and December 31, 2022, respectively | 15 |  |  | 15 |  |
| Additional paid-in capital | 444,825 |  |  | 419,190 |  |
| Accumulated other comprehensive loss | (53) |  |  | (10) |  |
| Accumulated deficit | (298,464) |  |  | (192,210) |  |
| Stockholders’ equity | 146,323 |  |  | 226,985 |  |
| Total liabilities and stockholders’ equity | $ | 298,720 |  |  | $ | 348,115 |  |

[0001628280-24-007980:8k_2_02:45]
EVOLV TECHNOLOGY

[0001628280-24-007980:8k_2_02:46]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-24-007980:8k_2_02:47]
(In thousands)

[0001628280-24-007980:8k_2_02:48]
(Unaudited)

[0001628280-24-007980:8k_2_02:49]
|  | Twelve Months EndedDecember 31, |
|  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (106,254) |  |  | $ | (86,406) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 9,932 |  |  | 5,465 |  |
| Write-off of inventory and change in inventory reserve | 1,612 |  |  | 1,582 |  |
| Adjustment to property and equipment for sales type leases | — |  |  | (625) |  |
| Loss from impairment of property and equipment | 322 |  |  | 1,161 |  |
| Stock-based compensation | 24,151 |  |  | 22,498 |  |
| Non-cash interest expense | 22 |  |  | 55 |  |
| Accretion of discount on marketable securities | (575) |  |  | — |  |
| Non-cash lease expense | 478 |  |  | 811 |  |
| Change in allowance for expected credit losses | 382 |  |  | 150 |  |
| Loss on extinguishment of debt | 626 |  |  | — |  |
| Change in fair value of earn-out liability | 14,901 |  |  | (6,988) |  |
| Change in fair value of contingently issuable common stock | 3,138 |  |  | (1,872) |  |
| Change in fair value of public warrant liability | 4,765 |  |  | (4,906) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | 8,927 |  |  | (25,593) |  |
| Inventory | (644) |  |  | (8,495) |  |
| Commission assets | (2,407) |  |  | (3,675) |  |
| Contract assets | 80 |  |  | 639 |  |
| Other assets | 633 |  |  | (419) |  |
| Prepaid expenses and other current assets | (2,566) |  |  | (3,174) |  |
| Accounts payable | (5,963) |  |  | 7,661 |  |
| Deferred revenue | 35,522 |  |  | 26,887 |  |
| Accrued expenses and other current liabilities | 3,732 |  |  | 1,462 |  |
| Operating lease liability | (615) |  |  | (946) |  |
| Net cash used in operating activities | (9,801) |  |  | (74,728) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (3,535) |  |  | (2,720) |  |
| Purchases of property and equipment | (69,134) |  |  | (21,473) |  |
| Proceeds from sale of property and equipment | 270 |  |  | 312 |  |
| Purchases of marketable securities | (89,898) |  |  | — |  |
| Proceeds from maturities of marketable securities | 39,184 |  |  | — |  |
| Net cash used in investing activities | (123,113) |  |  | (23,881) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 668 |  |  | 827 |  |
| Proceeds from long-term debt | 1,876 |  |  | 29,683 |  |
| Repayment of principal on long-term debt | (31,876) |  |  | (10,000) |  |
| Payment of debt issuance costs and prepayment penalty | (332) |  |  | — |  |
| Net cash provided by (used in) financing activities | (29,664) |  |  | 20,510 |  |
| Effect of exchange rate changes on cash and cash equivalents | (43) |  |  | (10) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (162,621) |  |  | (78,109) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 230,058 |  |  | 308,167 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 67,437 |  |  | $ | 230,058 |  |

[0001628280-24-007980:8k_2_02:50]
EVOLV TECHNOLOGY

[0001628280-24-007980:8k_2_02:51]
SUMMARY OF KEY OPERATING STATISTICS

[0001628280-24-007980:8k_2_02:52]
(Unaudited)

[0001628280-24-007980:8k_2_02:53]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |  | December 31,2022 |  | March 31,2023 |  | June 30,2023 |  | September 30,2023 |  | December 31,2023 |
| New customers |  | 44 |  |  | 53 |  |  | 92 |  |  | 106 |  |  | 61 |  |  | 74 |  |  | 70 |  |  | 75 |  |
| Annual recurring revenue |  | $ | 16,641 |  |  | $ | 20,865 |  |  | $ | 28,741 |  |  | $ | 34,120 |  |  | $ | 42,021 |  |  | $ | 54,339 |  |  | $ | 65,774 |  |  | $ | 74,989 |  |
| Recurring revenue |  | $ | 3,159 |  |  | $ | 4,604 |  |  | $ | 6,221 |  |  | $ | 7,388 |  |  | $ | 9,075 |  |  | $ | 11,689 |  |  | $ | 14,377 |  |  | $ | 17,350 |  |
| Remaining performance obligation |  | $ | 63,750 |  |  | $ | 80,978 |  |  | $ | 109,407 |  |  | $ | 144,561 |  |  | $ | 161,813 |  |  | $ | 198,296 |  |  | $ | 221,126 |  |  | $ | 240,513 |  |
| Net additions |  | 207 |  |  | 237 |  |  | 545 |  |  | 575 |  |  | 520 |  |  | 599 |  |  | 628 |  |  | 491 |  |
| Ending deployed units |  | 910 |  |  | 1,147 |  |  | 1,692 |  |  | 2,267 |  |  | 2,787 |  |  | 3,386 |  |  | 4,014 |  |  | 4,505 |  |

[0001628280-24-007980:8k_2_02:54]
EVOLV TECHNOLOGY

[0001628280-24-007980:8k_2_02:55]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001628280-24-007980:8k_2_02:56]
(In thousands)

[0001628280-24-007980:8k_2_02:57]
(Unaudited)

[0001628280-24-007980:8k_2_02:58]
|  | Three Months Ended, |
|  |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |  | December 31,2022 |  | March 31,2023 |  | June 30,2023 |  | September 30,2023 |  | December 31,2023 |
| Operating expenses, GAAP |  | $ | 24,760 |  |  | $ | 25,835 |  |  | $ | 26,827 |  |  | $ | 26,868 |  |  | $ | 27,256 |  |  | $ | 31,039 |  |  | $ | 31,629 |  |  | $ | 32,167 |  |
| Stock-based compensation |  | (3,819) |  |  | (4,781) |  |  | (6,298) |  |  | (6,771) |  |  | (4,898) |  |  | (6,505) |  |  | (5,454) |  |  | (6,711) |  |
| Restructuring expenses |  | (324) |  |  | 13 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Loss on impairment of lease equipment |  | (96) |  |  | (316) |  |  | (626) |  |  | (123) |  |  | (137) |  |  | (157) |  |  | (28) |  |  | — |  |
| Other one-time expenses |  | (1,107) |  |  | (2,298) |  |  | (69) |  |  | (41) |  |  | (53) |  |  | (683) |  |  | (945) |  |  | (535) |  |
| Adjusted operating expenses |  | $ | 19,414 |  |  | $ | 18,453 |  |  | $ | 19,834 |  |  | $ | 19,933 |  |  | $ | 22,168 |  |  | $ | 23,694 |  |  | $ | 25,202 |  |  | $ | 24,921 |  |

[0001628280-24-007980:8k_2_02:59]
EVOLV TECHNOLOGY

[0001628280-24-007980:8k_2_02:60]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT, GAAP GROSS MARGIN TO ADJUSTED GROSS MARGIN AND GAAP OPERATING INCOME (LOSS) TO ADJUSTED OPERATING INCOME (LOSS)

[0001628280-24-007980:8k_2_02:61]
(In thousands)

[0001628280-24-007980:8k_2_02:62]
(Unaudited)

[0001628280-24-007980:8k_2_02:63]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue | $ | 21,821 |  |  | $ | 20,885 |  |  | $ | 80,418 |  |  | $ | 55,195 |  |
| Cost of revenue | 11,560 |  |  | 20,831 |  |  | 46,589 |  |  | 53,466 |  |
| Gross profit, GAAP | 10,261 |  |  | 54 |  |  | 33,829 |  |  | 1,729 |  |
| Stock-based compensation | 137 |  |  | 214 |  |  | 583 |  |  | 829 |  |
| Amortization of capitalized stock-based compensation | 14 |  |  | 9 |  |  | 47 |  |  | 24 |  |
| Other one-time expenses | 1,925 |  |  | — |  |  | 1,925 |  |  | — |  |
| Adjusted gross profit | $ | 12,337 |  |  | $ | 277 |  |  | $ | 36,384 |  |  | $ | 2,582 |  |
| Gross margin % | 47.0 | % |  | 0.3 | % |  | 42.1 | % |  | 3.1 | % |
| Adjusted gross margin % | 56.5 | % |  | 1.3 | % |  | 45.2 | % |  | 4.7 | % |

[0001628280-24-007980:8k_2_02:64]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Operating loss, GAAP | $ | (21,906) |  |  | $ | (26,814) |  |  | $ | (88,262) |  |  | $ | (102,561) |  |
| Stock-based compensation | 6,848 |  |  | 6,985 |  |  | 24,151 |  |  | 22,498 |  |
| Amortization of capitalized stock-based compensation | 14 |  |  | 9 |  |  | 47 |  |  | 24 |  |
| Restructuring expenses | — |  |  | — |  |  | — |  |  | 311 |  |
| Loss on impairment of lease equipment | — |  |  | 123 |  |  | 322 |  |  | 1,161 |  |
| Other one-time expenses | 2,460 |  |  | 41 |  |  | 4,141 |  |  | 3,515 |  |
| Adjusted operating loss | $ | (12,584) |  |  | $ | (19,656) |  |  | $ | (59,601) |  |  | $ | (75,052) |  |

[0001628280-24-007980:8k_2_02:65]
EVOLV TECHNOLOGY

[0001628280-24-007980:8k_2_02:66]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-24-007980:8k_2_02:67]
(In thousands)

[0001628280-24-007980:8k_2_02:68]
(Unaudited)

[0001628280-24-007980:8k_2_02:69]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net loss | $ | (16,890) |  |  | $ | (28,304) |  |  | $ | (106,254) |  |  | $ | (86,406) |  |
| Depreciation & amortization | 3,151 |  |  | 1,683 |  |  | 9,932 |  |  | 5,465 |  |
| Stock-based compensation | 6,848 |  |  | 6,985 |  |  | 24,151 |  |  | 22,498 |  |
| Interest expense (income) | (1,630) |  |  | (1,331) |  |  | (5,573) |  |  | (2,453) |  |
| Provision for income taxes | 51 |  |  | — |  |  | 51 |  |  | — |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | 626 |  |  | — |  |
| Change in fair value of contingent earn-out liability | (2,452) |  |  | 2,766 |  |  | 14,901 |  |  | (6,988) |  |
| Change in fair value of contingently issuable common stock liability | (422) |  |  | 657 |  |  | 3,138 |  |  | (1,872) |  |
| Change in fair value of public warrant liability | (580) |  |  | (609) |  |  | 4,765 |  |  | (4,906) |  |
| Restructuring expenses | — |  |  | — |  |  | — |  |  | 311 |  |
| Loss on impairment of lease equipment | — |  |  | 123 |  |  | 322 |  |  | 1,161 |  |
| Other one-time expenses | 2,460 |  |  | 41 |  |  | 4,141 |  |  | 3,515 |  |
| Adjusted EBITDA | $ | (9,464) |  |  | $ | (17,989) |  |  | $ | (49,800) |  |  | $ | (69,675) |  |

[0001628280-24-007980:8k_2_02:70]
EVOLV TECHNOLOGY

[0001628280-24-007980:8k_2_02:71]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001628280-24-007980:8k_2_02:72]
(In thousands, except share and per share data)

[0001628280-24-007980:8k_2_02:73]
(Unaudited)

[0001628280-24-007980:8k_2_02:74]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net loss | $ | (16,890) |  |  | $ | (28,304) |  |  | $ | (106,254) |  |  | $ | (86,406) |  |
| Stock-based compensation | 6,848 |  |  | 6,985 |  |  | 24,151 |  |  | 22,498 |  |
| Amortization of capitalized stock-based compensation | 14 |  |  | 9 |  |  | 47 |  |  | 24 |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | 626 |  |  | — |  |
| Change in fair value of contingent earn-out liability | (2,452) |  |  | 2,766 |  |  | 14,901 |  |  | (6,988) |  |
| Change in fair value of contingently issuable common stock liability | (422) |  |  | 657 |  |  | 3,138 |  |  | (1,872) |  |
| Change in fair value of public warrant liability | (580) |  |  | (609) |  |  | 4,765 |  |  | (4,906) |  |
| Restructuring expenses | — |  |  | — |  |  | — |  |  | 311 |  |
| Loss on impairment of lease equipment | — |  |  | 123 |  |  | 322 |  |  | 1,161 |  |
| Other one-time expenses | 2,460 |  |  | 41 |  |  | 4,141 |  |  | 3,515 |  |
| Adjusted loss | $ | (11,022) |  |  | $ | (18,332) |  |  | $ | (54,163) |  |  | $ | (72,663) |  |
| Weighted average common shares outstanding – diluted | 151,087,430 |  |  | 144,856,047 |  |  | 149,168,105 |  |  | 143,858,668 |  |
| Adjusted loss per share – diluted | $ | (0.07) |  |  | $ | (0.13) |  |  | $ | (0.36) |  |  | $ | (0.51) |  |
