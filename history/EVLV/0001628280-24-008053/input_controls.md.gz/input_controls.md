# EVLV 10-K controls and the auditor's report


## auditors_report

[0001628280-24-008053:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001628280-24-008053:auditors_report:2]
To the Board of Directors and Stockholders of Evolv Technologies Holdings, Inc.

[0001628280-24-008053:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001628280-24-008053:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Evolv Technologies Holdings, Inc. and its subsidiaries (the “Company”) as of December 31, 2023 and 2022, and the related consolidated statements of operations and comprehensive loss, of stockholders' equity (deficit) and of cash flows for the years then ended, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of December 31, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001628280-24-008053:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2023 and 2022, and the results of its operations and its cash flows for the years then ended December 31, 2023 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company did not maintain, in all material respects, effective internal control over financial reporting as of December 31, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO because material weaknesses in internal control over financial reporting existed as of that date related the Company not designing and maintaining (i) an effective control environment commensurate with its financial reporting requirements, (ii) effective controls in response to the risks of material misstatement to financial reporting, (iii) effective controls over the period-end financial reporting process, (iv) effective controls to analyze, account for and disclose non-routine, unusual or complex transactions, (v) formal accounting policies, procedures and controls to achieve complete, accurate and timely financial accounting, reporting and disclosures, including segregation of duties and controls over the preparation and review of account reconciliations and journal entries, and (vi) effective controls over information technology general controls for information systems that are relevant to the preparation of the consolidated financial statements, including program change management, user access, computer operations, and program development.

[0001628280-24-008053:auditors_report:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. The material weaknesses referred to above are described in Management’s Annual Report on Internal Control Over Financial Reporting appearing under Item 9A. We considered these material weaknesses in determining the nature, timing, and extent of audit tests applied in our audit of the 2023 consolidated financial statements, and our opinion regarding the effectiveness of the Company’s internal control over financial reporting does not affect our opinion on those consolidated financial statements.

[0001628280-24-008053:auditors_report:7]
Basis for Opinions

[0001628280-24-008053:auditors_report:8]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting included in management's report referred to above. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001628280-24-008053:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001628280-24-008053:auditors_report:10]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001628280-24-008053:auditors_report:11]
68

[0001628280-24-008053:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0001628280-24-008053:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001628280-24-008053:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001628280-24-008053:auditors_report:15]
Critical Audit Matters

[0001628280-24-008053:auditors_report:16]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001628280-24-008053:auditors_report:17]
Consolidated Financial Statements - Impact of Control Environment, Risk Assessment, and Control Activities Related to Financial Reporting

[0001628280-24-008053:auditors_report:18]
The completeness and accuracy of the consolidated financial statements, including the financial condition, results of operations and cash flows, is dependent on, in part, (i) maintaining a sufficient complement of personnel with an appropriate level of internal controls and accounting knowledge, training and experience commensurate with the Company’s financial reporting requirements, (ii) designing and maintaining controls in response to the risks of material misstatement to financial reporting, (iii) designing and maintaining effective controls over the period-end financial reporting process, (iv) designing and maintaining controls to analyze, account for and disclose non-routine, unusual or complex transactions, (v) designing and maintaining formal accounting policies, procedures, and controls to achieve complete, accurate, and timely financial accounting, reporting and disclosures, including segregation of duties and controls over the preparation and review of account reconciliations and journal entries, and (vi) designing and maintaining effective controls over information technology general controls for information systems that are relevant to the preparation of the consolidated financial statements, including program change management, user access, computer operations, and program development.

[0001628280-24-008053:auditors_report:19]
The principal considerations for our determination that performing procedures relating to the consolidated financial statements – impact of control environment, risk assessment, and control activities related to financial reporting is a critical audit matter are a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating audit evidence related to business processes that affect substantially all financial statement account balances and disclosures. As described in the “Opinions on the Financial Statements and Internal Control over Financial Reporting” section, material weaknesses were identified related to this matter.

[0001628280-24-008053:auditors_report:20]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included, among others, evaluating and determining the nature and extent of audit procedures performed and evidence obtained that are responsive to the material weaknesses identified. These procedures also included (i) evaluating whether segregation of duties was maintained over the preparation and review of account reconciliations and recording of journal entries, (ii) testing the completeness and accuracy of period-end financial reporting, including the classification and presentation of accounts and disclosures; (iii) testing the accounting and disclosures for non-routine, unusual or complex transactions; and (iv) manually testing the completeness and accuracy of system reports or other information generated by the Company’s information systems.

[0001628280-24-008053:auditors_report:21]
69

[0001628280-24-008053:auditors_report:22]
/s/ PricewaterhouseCoopers LLP

[0001628280-24-008053:auditors_report:23]
Boston, Massachusetts

[0001628280-24-008053:auditors_report:24]
February 29, 2024

[0001628280-24-008053:auditors_report:25]
We have served as the Company’s auditor since 2015.

[0001628280-24-008053:auditors_report:26]
70

[0001628280-24-008053:auditors_report:27]
EVOLV TECHNOLOGIES HOLDINGS, INC.


## item_9a

[0001628280-24-008053:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0001628280-24-008053:item_9a:2]
Limitations on effectiveness of controls and procedures

[0001628280-24-008053:item_9a:3]
We maintain disclosure controls and procedures (as that term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) that are designed to ensure that information required to be disclosed in the reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms, and that such information is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate, to allow timely decisions regarding required disclosures. In designing and evaluating our disclosure controls and procedures, management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply judgment in evaluating the benefits of our controls and procedures relative to their costs.

[0001628280-24-008053:item_9a:4]
Evaluation of disclosure controls and procedures

[0001628280-24-008053:item_9a:5]
Our management, with the participation of our principal executive officer and principal financial officer, evaluated, as of the end of the period covered by this Annual Report on Form 10-K, the effectiveness of our disclosure controls and procedures (as that term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act). Based on that evaluation, our principal executive officer and principal financial officer concluded that our disclosure controls and procedures were not effective as of December 31, 2023 due to the material weaknesses in our internal control over financial reporting as described below.

[0001628280-24-008053:item_9a:6]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001628280-24-008053:item_9a:7]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as that term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our management, including our principal executive officer and principal financial officer, conducted an assessment as of December 31, 2023 of the effectiveness of our internal control over financial reporting based on the criteria set forth in Internal Control–Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this assessment, management concluded that, as of December 31, 2023, our internal control over financial reporting was not effective due to the material weaknesses described below.

[0001628280-24-008053:item_9a:8]
We identified material weaknesses in our internal control over financial reporting. A material weakness is a deficiency, or combination of deficiencies, in internal control over financial reporting, such that there is reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis.

[0001628280-24-008053:item_9a:9]
We did not design and maintain an effective control environment commensurate with our financial reporting requirements. Specifically, we lacked a sufficient complement of personnel with an appropriate level of internal controls and accounting knowledge, training and experience commensurate with our financial reporting requirements. Additionally, the limited personnel resulted in our inability to consistently establish appropriate authorities and responsibilities in pursuit of our financial reporting objectives, as demonstrated by, among other things, insufficient segregation of duties in our finance and accounting functions. In addition, we did not design and maintain effective controls in response to the risks of material misstatement as changes to existing controls or the implementation of new controls were not sufficient to respond to changes to the risks of material misstatement to financial reporting. These material weaknesses contributed to the following additional material weaknesses:

[0001628280-24-008053:item_9a:10]
•We did not design and maintain effective controls over the period-end financial reporting process to achieve complete, accurate, and timely financial accounting, reporting and disclosures, including the classification of various accounts in the financial statements and the presentation and disclosure of items in the consolidated statements of cash flows.

[0001628280-24-008053:item_9a:11]
•We did not design and maintain processes and controls to analyze, account for and disclose non-routine, unusual or complex transactions. Specifically, we did not design and maintain controls to timely analyze and account for debt modifications and extinguishments, convertible notes, warrant instruments, non-routine complex revenue transactions including the leasing of products and transfer of inventory for leased assets into property plant and equipment, merger transactions, and the accounting and valuation of earn out liabilities.

[0001628280-24-008053:item_9a:12]
•We did not design and maintain formal accounting policies, procedures, and controls to achieve complete, accurate, and timely financial accounting, reporting and disclosures, including segregation of duties, controls to validate reliability of system-generated information used in the controls, controls over the preparation and review of account reconciliations and journal entries, and controls over recording of revenue, receivables, and deferred revenue transactions, completeness and accuracy of accounts payable and accrued liabilities, commissions, equity and share-based compensation, fixed assets, inventory, payroll, income taxes, and cash and investments.

[0001628280-24-008053:item_9a:13]
These material weaknesses resulted in audit adjustments and certain immaterial misstatements in the Evolv financial statements to prepaid and other current assets, accounts payable and accrued liabilities, long-term and short-term debt, convertible notes, contingent earn-out liabilities, change in fair value of contingent earn-out liability, equity, commission assets, contract assets, revenue, deferred revenue, accounts receivable, inventory, property plant and equipment, cost of sales and various expense line items and related financial statement disclosures as of and for the years ended December 31, 2019, 2020 and 2021. The material weaknesses related to accounting for warrant instruments, the classification of various accounts in the consolidated financial statements and the presentation and disclosure of items in the consolidated statements of cash flows also resulted in the revision of the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022, as well as the restatement of the Company’s financial statements as of and for the three and six months ended June 30, 2023. Additionally, these material weaknesses could result in a misstatement of substantially all of our accounts or disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0001628280-24-008053:item_9a:14]
•In addition to the foregoing, we did not design and maintain effective controls over information technology (“IT”) general controls for information systems that are relevant to the preparation of our consolidated financial statements, specifically, with respect to: (i) program change management controls for financial systems to ensure that IT program and data changes affecting financial IT applications and underlying accounting records are identified, tested, authorized, and implemented appropriately; (ii) user access controls to ensure appropriate segregation of duties and that adequately restrict user and privileged access to financial applications, programs, and data to appropriate company personnel; (iii) computer operations controls to ensure that critical batch jobs are monitored and data backups are authorized and monitored, and (iv) testing and approval controls for program development to ensure that new software development is aligned with business and IT requirements. These IT deficiencies did not result in a misstatement to the consolidated financial statements, however, the deficiencies, when aggregated, could impact maintaining effective segregation of duties, as well as the effectiveness of IT-dependent controls (such as automated controls that address the risk of material misstatement to one or more assertions, along with the IT controls and underlying data that support the effectiveness of system-generated data and reports) that could result in misstatements potentially impacting all financial statement accounts and disclosures that would not be prevented or detected. Accordingly, management has determined these deficiencies in the aggregate constitute a material weakness.

[0001628280-24-008053:item_9a:15]
Our independent registered public accounting firm, PricewaterhouseCoopers LLP, has issued an audit report with respect to the effectiveness of our internal control over financial reporting as of December 31, 2023, which appears in Part II, Item 8 of this Annual Report on Form 10-K.

[0001628280-24-008053:item_9a:16]
Remediation Plan for the Material Weaknesses

[0001628280-24-008053:item_9a:17]
We continue to be focused on designing and implementing effective internal controls to improve our internal control over financial reporting and remediate the material weaknesses. Our efforts include a number of actions:

[0001628280-24-008053:item_9a:18]
•We have hired additional accounting, internal audit, and IT personnel to bolster our reporting, technical accounting, internal control, and IT capabilities. Additionally, we are in the process of designing and implementing controls to formalize roles and review responsibilities to align with our team’s skills and experience and designing and implementing controls over segregation of duties.

[0001628280-24-008053:item_9a:19]
•We added, and continue to add, finance personnel to the organization, including in fiscal 2022 a new Chief Financial Officer and a Chief Accounting Officer, to strengthen our internal accounting team, to provide oversight, structure and reporting lines, and to provide additional review over our accounting and financial reporting.

[0001628280-24-008053:item_9a:20]
•We have performed, and will continue to perform, a financial statement risk assessment in order to identify material financial statement line items for which key controls are needed in order to ensure complete and accurate financial reporting. Additionally, we have engaged outside consultants to assist with the design and implementation of control activities resulting from the aforementioned risk assessment.

[0001628280-24-008053:item_9a:21]
•We have designed and implemented additional review and training procedures within Evolv's accounting and finance functions to enhance knowledge and understanding of internal control over financial reporting.

[0001628280-24-008053:item_9a:22]
•During each of the three months ended June 30, 2023, September 30, 2023, and December 31, 2023, we implemented controls related to, among other items, (i) the period-end financial reporting process and classification of various accounts in our consolidated financial statements, including the presentation and disclosure of items in the consolidated statements of cash flows, (ii) timely identification and accounting for non-routine, unusual and complex transactions, including controls over the preparation and review of accounting memoranda addressing these matters, (iii) revenue recognition, including non-routine complex revenue transactions that may also include the leasing of products and the recording of revenue transactions in the appropriate period, (iv) completeness and accuracy of accounts payable and accrued liabilities, and (v) completeness, accuracy, valuation, and classification of cash equivalents and marketable securities.

[0001628280-24-008053:item_9a:23]
Additionally, we are in the process of designing and implementing controls related to:

[0001628280-24-008053:item_9a:24]
•the preparation and review of journal entries and account reconciliations to ensure proper segregation of duties;

[0001628280-24-008053:item_9a:25]
•formal accounting policies, procedures and controls to achieve complete, accurate and timely financial accounting, reporting and disclosures; and

[0001628280-24-008053:item_9a:26]
•information technology general controls, including controls over program change management, the review and update of user access rights and privileges, controls over batch jobs and data backups, and program development approvals and testing. To this end, we implemented a new Enterprise Resource Planning ("ERP") system in April 2022 and have implemented, and continue to implement, IT general controls related to the new system.

[0001628280-24-008053:item_9a:27]
The process of designing and maintaining effective internal control over financial reporting is a continuous effort that requires management to anticipate and react to changes in our business, economic, and regulatory environments and to expend significant resources. As we continue to evaluate our internal control over financial reporting, we may take additional actions to remediate the material weaknesses or modify the remediation actions described above.

[0001628280-24-008053:item_9a:28]
While we continue to devote significant time and attention to these remediation efforts, the material weaknesses will not be considered remediated until management completes the design and implementation of the actions described above and the controls operate for a sufficient period of time, and management has concluded, through testing, that these controls are effective.

[0001628280-24-008053:item_9a:29]
Changes in Internal Control over Financial Reporting

[0001628280-24-008053:item_9a:30]
Other than with respect to the remediation efforts described in the Remediation Plan for the Material Weaknesses section above, there were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended December 31, 2023 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
