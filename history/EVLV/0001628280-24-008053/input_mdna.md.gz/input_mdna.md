# EVLV MD&A — 0001628280-24-008053


## mdna

[0001628280-24-008053:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001628280-24-008053:mdna:2]
As used in this Annual Report on Form 10-K, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of the Merger and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001628280-24-008053:mdna:3]
Business Overview

[0001628280-24-008053:mdna:4]
We are a leader in AI-based weapons detection for security screening. Unlike conventional walk-through metal detectors, our products use advanced sensors, artificial intelligence software, and cloud services to reliably detect guns, improvised explosives, and large knives while ignoring harmless items like phones and keys. This not only enhances security at venues and facilities but also improves the visitor experience by making screening up to ten times faster than alternatives at up to 70% lower total cost.

[0001628280-24-008053:mdna:5]
Our products have screened over one billion visitors worldwide since our inception. We believe that we have screened more people through advanced systems than any organization other than the TSA. Our customers include many iconic venues across a wide variety of industries including major sports stadiums and arenas, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, hospitals, large industrial workplaces, schools, and prominent houses of worship. We offer our products for purchase and primarily under a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue, and creates expansion and upsell opportunities.

[0001628280-24-008053:mdna:6]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $80.4 million and $55.2 million for the years ended December 31, 2023 and 2022, respectively. We generated a net loss of $106.3 million and $86.4 million for the years ended December 31, 2023 and 2022, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-24-008053:mdna:7]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations, and if necessary, debt financings. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources.”

[0001628280-24-008053:mdna:8]
Key Factors Affecting Our Operating Results

[0001628280-24-008053:mdna:9]
We believe that our performance and future success depend on many factors that present significant opportunities for us but also pose risks and challenges, including those discussed below and in the "Risk Factors" section of this Annual Report on Form 10-K.

[0001628280-24-008053:mdna:10]
General Economic and Market Conditions

[0001628280-24-008053:mdna:11]
We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of rising inflation and interest rates on business spending; supply chain issues and the impacts on our manufacturing capabilities; public health emergencies; geopolitical conflicts and war, including the conflicts in Europe and the Middle East; and recessionary trends. See the risk factor titled “Downturns in general economic and market conditions and reductions in spending may reduce demand for our products and services and may impact third parties on which we rely, which could harm our revenue, results of operations, and cash flows, and could make it difficult to predict revenue for a particular period” in Item 1A. Risk Factors of this Annual Report on Form 10-K. While these factors continue to evolve, we plan to remain flexible and optimize our business as appropriate and allocate resources, as necessary.

[0001628280-24-008053:mdna:12]
Adoption of our Security Screening Products

[0001628280-24-008053:mdna:13]
We believe the world will continue to focus on the safety and security of people in the places where they gather. Many of these locations, such as professional sports venues, educational institutions, and healthcare facilities, are moving toward a more frictionless security screening experience. We are well-positioned to take advantage of this opportunity due to our proprietary technologies and distribution capabilities. Our products are designed to empower venues and facilities to realize the full benefits of touchless security screening, including a rapid visitor throughput and minimal security staff to screened visitor physical contact. We expect that our results of operations, including revenue, will fluctuate for the foreseeable future as venues and facilities continue to shift away from conventional security screening processes towards touchless security screening or consider security screening processes for the first time. The degree to which potential and current customers recognize these benefits and invest in our products will affect our financial results.

[0001628280-24-008053:mdna:14]
Sales Mix, Pricing, Product Cost and Margins

[0001628280-24-008053:mdna:15]
Historically, we offered our products under either a "pure subscription" sales model, where the customer leases our hardware, or a purchase subscription model, where the customer purchases the hardware from us. In both models, we provide a multi-year security-as-a-service subscription. During 2023, we gradually transitioned away from the purchase subscription model. Accordingly, product revenue as a percentage of total revenue decreased sequentially in each quarter of 2023. Going forward, we only plan to offer the purchase subscription model under limited circumstances. We introduced a new sales model in March 2023, when we entered into the Distribution and License Agreement. Under this arrangement, we have granted a limited, non-exclusive license under our intellectual property rights to Columbia Tech, and Columbia Tech manufactures hardware systems and contracts directly with certain of our resellers to fulfill sales demand where the end-user customer requires the contract to be in form of a hardware purchase. Columbia Tech pays us a hardware license fee for each system manufactured and sold under this agreement. In these instances, we still contract directly with the reseller to provide a multi-year security-as-a-service subscription to the end-users. We expect substantially all of our sales in future periods to be made under either the pure subscription model or the distributor licensing model, which would result in an increase in the percentage of revenue recognized over time and a decrease in the percentage of revenue recognized at a point in time.

[0001628280-24-008053:mdna:16]
Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions, primarily within the United States. Pricing may vary by region or vertical market due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales, bookings, and business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products to our customers.

[0001628280-24-008053:mdna:17]
Continued Investment and Innovation

[0001628280-24-008053:mdna:18]
We are a leader in AI-based weapons detection for security screening, offering transformative technologies that enable higher throughput, a more frictionless visitor experience, and substantial cost savings through our product innovations. Our performance is significantly dependent on the investment we make in our research and development efforts and on our ability to be at the forefront of the security screening industry. It is essential that we continually identify and respond to rapidly evolving customer requirements, develop, and introduce innovative new products, enhance existing products and generate customer demand for our products. We believe that investment in our security screening products will contribute to long-term revenue growth, but it may adversely affect our near-term profitability.

[0001628280-24-008053:mdna:19]
Components of Results of Operations

[0001628280-24-008053:mdna:20]
Revenue

[0001628280-24-008053:mdna:21]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement, (4) license fees related to the Distribution and License Agreement, and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax.

[0001628280-24-008053:mdna:22]
Product Revenue

[0001628280-24-008053:mdna:23]
We derive a portion of our revenue from the sale of our Evolv Express equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We expect product revenue to continue declining as a percentage of our overall revenue as we continue focusing our go-to-market strategy on pure subscription contracts and contracts under our distributor licensing model.

[0001628280-24-008053:mdna:24]
Subscription Revenue

[0001628280-24-008053:mdna:25]
Subscription revenue consists of revenue derived from leasing Evolv Express and Evolv Edge units to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001628280-24-008053:mdna:26]
Lease arrangements generally include both lease and non-lease components. The non-lease components relate to (1) distinct services, including professional services, SaaS, and maintenance, and (2) any add-on accessories. Professional services are included in license fees and other revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive loss.

[0001628280-24-008053:mdna:27]
Service Revenue

[0001628280-24-008053:mdna:28]
Service revenue consists of subscription-based SaaS and maintenance revenue related to products sold to customers. Customers generally pay either a quarterly or annual fixed payment for SaaS and maintenance. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically four years.

[0001628280-24-008053:mdna:29]
License Fee and Other Revenue

[0001628280-24-008053:mdna:30]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from our primary third-party manufacturer to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration. Revenue for professional services and other one-time revenue, which had previously been included in service revenue, has been reclassified for prior periods to License fee and other revenue on the consolidated statements of operations and comprehensive loss.

[0001628280-24-008053:mdna:31]
Cost of Revenue

[0001628280-24-008053:mdna:32]
We recognize cost of revenue in the same manner that the related revenue is recognized.

[0001628280-24-008053:mdna:33]
Cost of Product Revenue

[0001628280-24-008053:mdna:34]
Cost of product revenue consists primarily of costs paid to our third-party manufacturer and other suppliers, labor costs (including stock-based compensation), and shipping costs.

[0001628280-24-008053:mdna:35]
51

[0001628280-24-008053:mdna:36]
Cost of Subscription Revenue

[0001628280-24-008053:mdna:37]
Cost of subscription revenue consists primarily of depreciation expense related to leased units, an allocated portion of internal-use software amortization expense, shipping costs, and maintenance costs related to leased units. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001628280-24-008053:mdna:38]
Cost of Service Revenue

[0001628280-24-008053:mdna:39]
Cost of services revenue consists of maintenance costs related to units purchased by customers and an allocated portion of internal-use software amortization expense. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001628280-24-008053:mdna:40]
Cost of License Fee and Other Revenue

[0001628280-24-008053:mdna:41]
Cost of license fees and other revenue consists primarily of internal and third-party costs related to professional services, such as installation, training, and event support.

[0001628280-24-008053:mdna:42]
Gross Profit and Gross Margin

[0001628280-24-008053:mdna:43]
Our gross profit is calculated based on the difference between our revenues and cost of revenues. Gross margin is the percentage obtained by dividing gross profit by our revenue. Our gross profit and gross margin are, or may be, influenced by a number of factors, including:

[0001628280-24-008053:mdna:44]
•Market conditions that may impact our pricing;

[0001628280-24-008053:mdna:45]
•Product mix changes between established products and new products;

[0001628280-24-008053:mdna:46]
•Mix of sales between our pure subscription, purchase subscription, and distributor licensing sales models;

[0001628280-24-008053:mdna:47]
•Our cost structure for manufacturing operations, including contract manufacturers, relative to volume, and our product support obligations;

[0001628280-24-008053:mdna:48]
•Our ability to maintain our costs on the components that go into the manufacture of our products; and

[0001628280-24-008053:mdna:49]
•Write-offs of inventory.

[0001628280-24-008053:mdna:50]
We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001628280-24-008053:mdna:51]
Research and Development

[0001628280-24-008053:mdna:52]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, stock-based compensation, prototypes, design expenses, and consulting and contractor costs. We expect research and development costs will increase for the year ending December 31, 2024 compared to the year ended December 31, 2023 primarily due to incremental investments in headcount and programs we are making to support our new product development efforts.

[0001628280-24-008053:mdna:53]
Sales and Marketing

[0001628280-24-008053:mdna:54]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will increase for the year ending December 31, 2024 compared to the year ended December 31, 2023 primarily due to an expected increase in customer facing headcount to support higher sales volume.

[0001628280-24-008053:mdna:55]
General and Administrative

[0001628280-24-008053:mdna:56]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and sales tax contingencies. We expect our general and administrative expenses will remain relatively consistent for the year ending December 31, 2024 compared to the year ended December 31, 2023 as we look to leverage previous investments made in people and processes.

[0001628280-24-008053:mdna:57]
Loss From Impairment of Property and Equipment

[0001628280-24-008053:mdna:58]
Loss from impairment of property and equipment relates to (i) leased Evolv Edge units and Evolv Express prototype units that are removed from service and retired as we transition our domestic customers to our most current Evolv Express units and (ii) damaged or destroyed leased units.

[0001628280-24-008053:mdna:59]
Interest Expense

[0001628280-24-008053:mdna:60]
Interest expense includes cash interest paid on long-term debt and amortization of deferred financing fees and costs.

[0001628280-24-008053:mdna:61]
Interest Income

[0001628280-24-008053:mdna:62]
Interest income relates to interest earned on money market funds and treasury bills, and interest earned on our lease receivables for our Evolv Express units recognized as sales-type leases.

[0001628280-24-008053:mdna:63]
Loss on Extinguishment of Debt

[0001628280-24-008053:mdna:64]
In December 2022, the Company entered into a loan and security agreement (the "2022 SVB Credit Agreement") with Silicon Valley Bank ("SVB") in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. In light of the foregoing, the Company terminated the 2022 SVB Credit Agreement on March 31, 2023. As a result of the termination of the SVB Credit Agreement, the Company incurred a loss on extinguishment of debt.

[0001628280-24-008053:mdna:65]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-24-008053:mdna:66]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders are entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001628280-24-008053:mdna:67]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-24-008053:mdna:68]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock, referred to as Founder Shares. Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 1,897,500 Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones, and 517,500 Founder Shares were contributed to Give Evolv LLC. The 1,897,500 outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001628280-24-008053:mdna:69]
Change in Fair Value of Public Warrant Liability

[0001628280-24-008053:mdna:70]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are currently exercisable and expire in July 2026. We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss with the offset to additional paid-in capital.

[0001628280-24-008053:mdna:71]
Income Taxes

[0001628280-24-008053:mdna:72]
Our income tax provision consists of an estimate for federal, state, and foreign income taxes based on enacted rates in the jurisdictions in which we operate, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. We have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets.

[0001628280-24-008053:mdna:73]
Reclassification

[0001628280-24-008053:mdna:74]
During the year ended December 31, 2023, the Company began classifying revenue from professional services, which includes installation, training, and event support, as well as one-time revenue within license fee and other revenue on the consolidated statements of operations and comprehensive loss, whereas the revenue for these services has previously been included in service revenue. Correspondingly, the Company began classifying costs associated with professional services within cost of license fee and other revenue, whereas these costs were previously included in cost of service revenue. These reclassifications were made to align the presentation of professional services with the Company's internal reporting and analysis.

[0001628280-24-008053:mdna:75]
54

[0001628280-24-008053:mdna:76]
Results of Operations

[0001628280-24-008053:mdna:77]
Comparison of the Years Ended December 31, 2023 and 2022

[0001628280-24-008053:mdna:78]
The following table summarizes our results of operations for the years ended December 31, 2023 and 2022 (in thousands):

[0001628280-24-008053:mdna:79]
|  | Year Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 21,977 |  |  | $ | 31,985 |  |  | $ | (10,008) |  |  | (31) | % |
| Subscription revenue | 37,247 |  |  | 17,569 |  |  | 19,678 |  |  | 112 |  |
| Service revenue | 16,141 |  |  | 4,331 |  |  | 11,810 |  |  | 273 |  |
| License fee and other revenue | 5,053 |  |  | 1,310 |  |  | 3,743 |  |  | 286 |  |
| Total revenue | 80,418 |  |  | 55,195 |  |  | 25,223 |  |  | 46 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 26,667 |  |  | 41,575 |  |  | (14,908) |  |  | (36) |  |
| Cost of subscription revenue | 14,991 |  |  | 7,469 |  |  | 7,522 |  |  | 101 |  |
| Cost of service revenue | 3,982 |  |  | 2,200 |  |  | 1,782 |  |  | 81 |  |
| Cost of license fee and other revenue | 949 |  |  | 2,222 |  |  | (1,273) |  |  | (57) |  |
| Total cost of revenue | 46,589 |  |  | 53,466 |  |  | (6,877) |  |  | (13) |  |
| Gross profit | 33,829 |  |  | 1,729 |  |  | 32,100 |  |  | 1,857 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 24,455 |  |  | 18,771 |  |  | 5,684 |  |  | 30 |  |
| Sales and marketing | 55,223 |  |  | 46,639 |  |  | 8,584 |  |  | 18 |  |
| General and administrative | 42,091 |  |  | 37,719 |  |  | 4,372 |  |  | 12 |  |
| Loss from impairment of property and equipment | 322 |  |  | 1,161 |  |  | (839) |  |  | (72) |  |
| Total operating expenses | 122,091 |  |  | 104,290 |  |  | 17,801 |  |  | 17 |  |
| Loss from operations | (88,262) |  |  | (102,561) |  |  | 14,299 |  |  | 14 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (654) |  |  | (712) |  |  | 58 |  |  | 8 |  |
| Interest income | 6,227 |  |  | 3,165 |  |  | 3,062 |  |  | 97 |  |
| Other expense, net | (84) |  |  | (64) |  |  | (20) |  |  | (31) |  |
| Loss on extinguishment of debt | (626) |  |  | — |  |  | (626) |  |  | * |
| Change in fair value of contingent earn-out liability | (14,901) |  |  | 6,988 |  |  | (21,889) |  |  | (313) |  |
| Change in fair value of contingently issuable common stock liability | (3,138) |  |  | 1,872 |  |  | (5,010) |  |  | (268) |  |
| Change in fair value of public warrant liability | (4,765) |  |  | 4,906 |  |  | (9,671) |  |  | (197) |  |
| Total other income (expense), net | (17,941) |  |  | 16,155 |  |  | (34,096) |  |  | (211) |  |
| Loss before income taxes | (106,203) |  |  | (86,406) |  |  | (19,797) |  |  | (23) | % |
| Provision for income taxes | (51) |  |  | — |  |  | (51) |  |  | * |
| Net loss | $ | (106,254) |  |  | $ | (86,406) |  |  | $ | (19,848) |  |  | (23) | % |

[0001628280-24-008053:mdna:80]
*N/A – Not meaningful

[0001628280-24-008053:mdna:81]
Revenue, Cost of Revenue and Gross Profit

[0001628280-24-008053:mdna:82]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 280 new customers during the year ended December 31, 2023 and 295 new customers during the year ended December 31, 2022, compared to 84 new customer during the year ended December 31, 2021, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our reseller partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-24-008053:mdna:83]
Product Revenue

[0001628280-24-008053:mdna:84]
|  | Year Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Product revenue | $ | 21,977 |  | $ | 31,985 |  | $ | (10,008) |  | (31) % |
| Cost of product revenue | $ | 26,667 |  | $ | 41,575 |  | $ | (14,908) |  | (36) % |
| Gross profit - Product revenue | $ | (4,690) |  | $ | (9,590) |  | $ | 4,900 |  | 51 % |
| Gross profit margin - Product revenue | (21) % |  | (30) % |  | N/A |  | 9 % |

[0001628280-24-008053:mdna:85]
The decreases in product revenue and cost of product revenue and the increase in gross profit for the year ended December 31, 2023 compared to the year ended December 31, 2022 are primarily due to a gradual transition to pure subscription sales and sales under our distributor licensing model. Cost of product revenue for the year ended December 31, 2023 includes $1.9 million of costs, primarily cancellation fees associated with firm inventory purchase commitments, related to the planned transition of our manufacturing operations to the next generation of the Evolv Express system in 2024.

[0001628280-24-008053:mdna:86]
Subscription Revenue

[0001628280-24-008053:mdna:87]
|  | Year Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Subscription revenue | $ | 37,247 |  | $ | 17,569 |  | $ | 19,678 |  | 112 % |
| Cost of subscription revenue | $ | 14,991 |  | $ | 7,469 |  | $ | 7,522 |  | 101 % |
| Gross profit - Subscription revenue | $ | 22,256 |  | $ | 10,100 |  | $ | 12,156 |  | 120 % |
| Gross profit margin - Subscription revenue | 60 % |  | 57 % |  | N/A |  | 2 % |

[0001628280-24-008053:mdna:88]
The increases in subscription revenue, cost of subscription revenue and subscription gross profit are primarily due to growth in our customer base for the year ended December 31, 2023, compared to the year ended December 31, 2022, which was due to a gradual transition to our pure subscription contract model and a higher number of active Evolv Express units deployed under our pure subscription model. Subscription gross profit margin increased slightly as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-24-008053:mdna:89]
Service Revenue

[0001628280-24-008053:mdna:90]
|  | Year Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Service revenue | $ | 16,141 |  | $ | 4,331 |  | $ | 11,810 |  | 273 % |
| Cost of service revenue | $ | 3,982 |  | $ | 2,200 |  | $ | 1,782 |  | 81 % |
| Gross profit - Service revenue | $ | 12,159 |  | $ | 2,131 |  | $ | 10,028 |  | 471 % |
| Gross profit margin - Service revenue | 75 % |  | 49 % |  | N/A |  | 26 % |

[0001628280-24-008053:mdna:91]
The increase in service revenue and gross profit is primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from

[0001628280-24-008053:mdna:92]
Columbia Tech, for the year ended December 31, 2023 compared to the year ended December 31, 2022. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-24-008053:mdna:93]
License fee and other revenue

[0001628280-24-008053:mdna:94]
|  | Year Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| License fee and other revenue | $ | 5,053 |  | $ | 1,310 |  | $ | 3,743 |  | 286 % |
| Cost of license fee and other revenue | $ | 949 |  | $ | 2,222 |  | $ | (1,273) |  | (57) % |
| Gross profit - License fee and other revenue | $ | 4,104 |  | $ | (912) |  | $ | 5,016 |  | 550 % |
| Gross profit margin - License fee and other revenue | 81 % |  | (70) % |  | N/A |  | 151 % |

[0001628280-24-008053:mdna:95]
The increase in license fee and other revenue, gross profit, and gross profit margin was primarily driven by $3.0 million of license fees earned during the year ended December 31, 2023 under the Distribution and License Agreement which was executed in March 2023, compared to no license fees earned during the year ended December 31, 2022. Professional services, consisting primarily of installation, training, and event support, increased to $1.9 million for the year ended December 31, 2023 compared to $1.0 million for the year ended December 31, 2022, primarily as the result of a higher number of new Express systems deployed during the year ended December 31, 2023 compared to the prior year.

[0001628280-24-008053:mdna:96]
Research and Development Expenses

[0001628280-24-008053:mdna:97]
|  | Year Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 16,692 |  | $ | 14,568 |  | $ | 2,124 |  | 15 | % |
| Materials and prototypes | 2,432 |  | 652 |  | 1,780 |  |  | 273 |  |
| Professional fees | 3,996 |  | 2,806 |  | 1,190 |  |  | 42 |  |
| Other | 1,335 |  | 745 |  | 590 |  |  | 79 |  |
|  | $ | 24,455 |  | $ | 18,771 |  | $ | 5,684 |  |  | 30 | % |

[0001628280-24-008053:mdna:98]
The increase in personnel related expenses for the year ended December 31, 2023 compared to the year ended December 31, 2022 was due to higher payroll and stock-based compensation expense, which was primarily attributable to increased headcount in connection with new hires in our research and development function. Stock compensation expense was $4.3 million for the year ended December 31, 2023, compared to $4.0 million for the year ended December 31, 2022. Additionally, we experienced an increase in materials and prototype costs due to an increase in design and engineering costs in connection with the development of the next generation of our Evolv Express system. The year-over-year increase in professional fees was primarily due to consulting costs incurred for product development and engineering. The increase in other expense was primarily due to an increase in IT and software subscription costs.

[0001628280-24-008053:mdna:99]
57

[0001628280-24-008053:mdna:100]
Sales and Marketing Expenses

[0001628280-24-008053:mdna:101]
|  | Year Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 40,592 |  |  | $ | 31,591 |  |  | $ | 9,001 |  |  | 28 | % |
| Advertising and direct marketing | 3,575 |  |  | 5,457 |  |  | -1,882 |  | (34) |  |
| Travel and entertainment | 5,015 |  |  | 3,327 |  |  | 1,688 |  | 51 |  |
| Professional fees | 2,231 |  |  | 1,446 |  |  | 785 |  | 54 |  |
| Other | 3,810 |  |  | 4,818 |  |  | -1,008 |  | (21) |  |
|  | $ | 55,223 |  |  | $ | 46,639 |  |  | $ | 8,584 |  |  | 18 | % |

[0001628280-24-008053:mdna:102]
The increase in personnel related expenses for the year ended December 31, 2023 compared to the year ended December 31, 2022 was due to an increase in payroll costs and commissions resulting primarily from new hires in our sales and marketing functions during the year ended December 31, 2023 to support increased sales volume. Stock compensation expense was $9.4 million for the year ended December 31, 2023, compared to $10.0 million for the year ended December 31, 2022. The decrease in advertising and direct marketing expense was primarily attributable to lower spending at trade shows. The increase in travel and entertainment expense was due to an increase in travel costs for in-person sales personnel meetings and events. Professional fees increased primarily due to an increase in marketing consulting costs. Other expense decreased primarily due to $1.0 million of certain-one-time expenses incurred during the year ended December 31, 2022, including a $0.4 million one-time payment to former employees.

[0001628280-24-008053:mdna:103]
General and Administrative Expenses

[0001628280-24-008053:mdna:104]
|  | Year Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 23,145 |  |  | $ | 17,369 |  |  | $ | 5,776 |  |  | 33 | % |
| Professional fees | 6,712 |  |  | 8,715 |  |  | (2,003) |  |  | (23) |  |
| Insurance costs | 3,424 |  |  | 4,514 |  |  | (1,090) |  |  | (24) |  |
| Other | 8,810 |  |  | 7,121 |  |  | 1,689 |  |  | 24 |  |
|  | $ | 42,091 |  |  | $ | 37,719 |  |  | $ | 4,372 |  |  | 12 | % |

[0001628280-24-008053:mdna:105]
The increase in personnel related expenses was due to an increase in payroll costs and stock-based compensation as a result of expanding our administrative team during the year ended December 31, 2023. Stock compensation expense was $9.9 million for the year ended December 31, 2023, compared to $7.6 million for the year ended December 31, 2022. The decrease in professional fees was primarily related to a decrease in outsourced accounting consultancy and audit fees. The decrease in insurance costs was primarily related to a decrease in director and officer insurance premiums. The increase in other expenses was primarily attributable to a $1.0 million increase in IT and software subscription costs, a $0.4 million increase in property taxes, and a $0.3 million increase in the change in the allowance of expected credit losses.

[0001628280-24-008053:mdna:106]
Loss From Impairment of Property and Equipment

[0001628280-24-008053:mdna:107]
Loss from impairment of property and equipment was $0.3 million for the year ended December 31, 2023, compared to $1.2 million for the year ended December 31, 2022, primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in an impairment of the remaining economic value of such units.

[0001628280-24-008053:mdna:108]
Interest Expense and Loss on Extinguishment of Debt

[0001628280-24-008053:mdna:109]
Interest expense remained flat on a year-over-year basis at $0.7 million for the years ended December 31, 2023 and 2022. In March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of

[0001628280-24-008053:mdna:110]
58

[0001628280-24-008053:mdna:111]
repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write off of $0.3 million of unamortized debt issuance costs.

[0001628280-24-008053:mdna:112]
Interest Income

[0001628280-24-008053:mdna:113]
Interest income of $6.2 million and $3.2 million for the years ended December 31, 2023 and December 31, 2022, respectively, related primarily to interest earned on money market funds, and for the year ended December 31, 2023, accretion of discounts on treasury bills.

[0001628280-24-008053:mdna:114]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-24-008053:mdna:115]
The change in fair value of the contingent earn-out liability was $(14.9) million and $7.0 million for the years ended December 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments.

[0001628280-24-008053:mdna:116]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-24-008053:mdna:117]
The change in the fair value of the contingently issuable common stock liability was $(3.1) million and $1.9 million for the years ended December 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments.

[0001628280-24-008053:mdna:118]
Change in Fair Value of Public Warrant Liability

[0001628280-24-008053:mdna:119]
The change in the fair value of the public warrant liability was $(4.8) million and $4.9 million for the years ended December 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments.

[0001628280-24-008053:mdna:120]
Income Taxes

[0001628280-24-008053:mdna:121]
Our effective tax rate (“ETR”) on income before taxes for each of the years ended December 31, 2023 and  December 31, 2022 was 0%. For December 31, 2023, the ETR was primarily impacted by the full valuation allowance maintained on the Company’s net deferred tax assets and non-deductible fair value adjustments.  For the year ended December 31, 2022, the ETR was primarily impacted by the full valuation allowance maintained on the Company’s net deferred tax assets and non-taxable fair value adjustments. We have provided a valuation allowance for all of our net deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001628280-24-008053:mdna:122]
Liquidity and Capital Resources

[0001628280-24-008053:mdna:123]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures, and general corporate needs. We expect these needs to continue as we develop and grow our business. As of December 31, 2023, we had $118.5 million in cash, cash equivalents, and marketable securities. We incurred a net loss of $106.3 million and $86.4 million for the years ended December 31, 2023 and 2022, respectively. We incurred cash outflows from operating activities of $9.8 million and $74.7 million during the years ended December 31, 2023 and 2022, respectively.

[0001628280-24-008053:mdna:124]
We maintain substantially all of our cash, cash equivalents, and marketable securities in accounts with U.S. and multi-national financial institutions and our cash deposits at these institutions exceed Federal Deposit Insurance Corporation insured limits. The Company does not believe it is exposed to any unusual credit risk or deposit concentration risk beyond the ordinary credit risk associated with commercial banking relationships.

[0001628280-24-008053:mdna:125]
We expect our cash, cash equivalents, and marketable securities, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Annual Report on Form 10-K. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our sales and marketing team. We may require additional capital to respond to the expected growth in the demand for equipment purchases to support our "leased equipment" offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances and in either the short-term or long-term may determine to engage in debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, including the COVID-19 pandemic and its variants, international political turmoil, including in Europe and the Middle East, and related international sanctions, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001628280-24-008053:mdna:126]
Financing Arrangements

[0001628280-24-008053:mdna:127]
In December 2020, we entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024, and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022. Under the terms of the JPM Credit Agreement, we received proceeds of $10.0 million. We fully repaid all borrowings under the JPM Credit Agreement and terminated the JPM Credit Agreement in November 2022.

[0001628280-24-008053:mdna:128]
In December 2022, we entered into the 2022 SVB Credit Agreement in order to finance purchases of hardware to be leased to customers. The 2022 SVB Credit Agreement provided for an initial term loan advance of $30.0 million, which was approximately equivalent to the value of all hardware purchases made to support leasing transactions with our customers through December 21, 2022 (the "SVB Closing Date"), with the opportunity to obtain, within 18 months after the SVB Closing Date, additional term loan advances, subject to the satisfaction of certain conditions, in an aggregate principal amount equal to $20.0 million, (subject to an increase of an additional $25.0 million upon the satisfaction of certain conditions and approval from SVB). The interest rate applicable to the SVB Term Loans was the greater of (a) the Wall Street Journal Prime Rate plus 1.0% or (b) 7.25% per annum. Interest and principal under the SVB Credit Agreement was payable monthly.

[0001628280-24-008053:mdna:129]
On March 31, 2023, following the collapse of SVB, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. The Company has no debt outstanding as of December 31, 2023.

[0001628280-24-008053:mdna:130]
Material Cash Requirements for Known Contractual and Other Obligations

[0001628280-24-008053:mdna:131]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of December 31, 2023. We anticipate fulfilling such commitments with our existing cash and cash equivalents, as well as cash and cash equivalents obtained through operations and, if necessary, proceeds from long-term debt. Cash, cash equivalents, and marketable securities amounted to $118.5 million as of December 31, 2023.

[0001628280-24-008053:mdna:132]
We are party to a lease agreement for office space for the period from May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. During the year ended December 31, 2023, we amended the lease agreement to add additional square footage within the same building. The amendment did not impact the term of the lease. We are required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space which is classified as restricted cash, current on the consolidated balance sheet as of December 31, 2023. Total future minimum lease payments under this noncancelable operating lease amount to $1.4 million. See Note 6 to our consolidated financial statements for the year ended December 31, 2023.

[0001628280-24-008053:mdna:133]
Cash Flows

[0001628280-24-008053:mdna:134]
The following table sets forth a summary of cash flows for the periods presented:

[0001628280-24-008053:mdna:135]
|  | Year EndedDecember 31, |
|  | 2023 |  | 2022 |
| Net cash used in operating activities | $ | (9,801) |  |  | $ | (74,728) |  |
| Net cash used in investing activities | (123,113) |  |  | (23,881) |  |
| Net cash provided by (used in) financing activities | (29,664) |  |  | 20,510 |  |
| Effect of exchange rate changes on cash and cash equivalents | (43) |  |  | (10) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (162,621) |  |  | $ | (78,109) |  |

[0001628280-24-008053:mdna:136]
Operating Activities

[0001628280-24-008053:mdna:137]
|  | Year EndedDecember 31, |
|  | 2023 |  | 2022 |
| Net loss | $ | (106,254) |  |  | $ | (86,406) |  |
| Non-cash expense | 59,754 |  |  | 17,331 |  |
| Changes in operating assets and liabilities | 36,699 |  |  | (5,653) |  |
| Net cash used in operating activities | $ | (9,801) |  |  | $ | (74,728) |  |

[0001628280-24-008053:mdna:138]
Net loss increased to $106.3 million for the year ended December 31, 2023 from $86.4 million for the year ended December 31, 2022 as a result of the factors described in "Results of Operations" above.

[0001628280-24-008053:mdna:139]
Non-cash expenses for the year ended December 31, 2023 were primarily attributable to $24.2 million of stock-based compensation expense, $9.9 million of depreciation and amortization, $1.6 million of write-off of inventory, and $22.8 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability. Non-cash expenses for the year ended December 31, 2022 were primarily attributable to $22.5 million of stock-based compensation expense, $5.5 million of depreciation and amortization, $1.6 million of write-off of inventory, and $1.2 million of loss from impairment of property and equipment, offset by $13.8 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability.

[0001628280-24-008053:mdna:140]
Changes in operating assets and liabilities for the year ended December 31, 2023 are primarily related to the following:

[0001628280-24-008053:mdna:141]
•$35.5 million increase in deferred revenue to a higher volume of sales;

[0001628280-24-008053:mdna:142]
•$8.9 million decrease in accounts receivable primarily due to the Company's transition away from the purchase model, under which upfront billings to customers are generally higher; and

[0001628280-24-008053:mdna:143]
•$3.7 million increase in accrued expenses and other current liabilities, related to accrued consulting and professional fees and an accrual for purchase order cancellation fees, offset by

[0001628280-24-008053:mdna:144]
•$6.0 million decrease in accounts payable (excluding the non-cash portion related to capital expenditures incurred but not yet paid) due primarily to the timing of vendor payments;

[0001628280-24-008053:mdna:145]
•$2.6 million increase in prepaid expense and other current assets due to an increase in vendor deposits; and

[0001628280-24-008053:mdna:146]
•$2.4 million increase in commission assets due to a higher volume of sales.

[0001628280-24-008053:mdna:147]
Changes in operating assets and liabilities for the year ended December 31, 2022 are primarily related to the following:

[0001628280-24-008053:mdna:148]
•$26.9 million increase in deferred revenue due to a higher volume of sales;

[0001628280-24-008053:mdna:149]
•$7.7 million increase in accounts payable primarily due to amounts payable to the Company's contract manufacturer; offset by

[0001628280-24-008053:mdna:150]
•$25.6 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001628280-24-008053:mdna:151]
•$8.5 million increase in inventory primarily due to increased production of units to meet customer demand;

[0001628280-24-008053:mdna:152]
•$3.7 million increase in commission assets due to a higher volume of sales; and

[0001628280-24-008053:mdna:153]
•$3.2 million increase in prepaid expenses and other current assets primarily due to deposits paid to the Company's contract manufacturer.

[0001628280-24-008053:mdna:154]
Investing Activities

[0001628280-24-008053:mdna:155]
During the year ended December 31, 2023, cash used in investing activities was $123.1 million, consisting of $69.1 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers, $3.5 million for the development of internal-use software and software embedded in products to be sold or leased, and a net $50.7 million outflow related to purchases and redemptions of marketable securities.

[0001628280-24-008053:mdna:156]
During the year ended December 31, 2022, cash used in investing activities was $23.9 million, consisting of $21.5 million for the purchase of property and equipment, primarily related to the purchase of Express units to be leased to customers, and $2.7 million for the development of internal-use software, offset by $0.3 million of proceeds from the sale of property and equipment.

[0001628280-24-008053:mdna:157]
Financing Activities

[0001628280-24-008053:mdna:158]
During the year ended December 31, 2023, cash used in financing activities was $29.7 million, consisting of $1.9 million of proceeds under the 2022 SVB Credit Agreement and $0.7 million of proceeds from the exercise of stock options, offset by $31.9 million related to the full repayment of amounts owed under the 2022 SVB Credit Agreement and a $0.3 million payment of debt issuance costs and a prepayment penalty.

[0001628280-24-008053:mdna:159]
During the year ended December 31, 2022, cash provided by financing activities was $20.5 million, consisting of $29.7 million of proceeds from long-term debt, net of issuance costs, and $0.8 million of proceeds from the exercise of stock options, offset by $10.0 million of debt repayments.

[0001628280-24-008053:mdna:160]
Recent Accounting Pronouncements

[0001628280-24-008053:mdna:161]
A description of recently issued accounting pronouncements that may potentially impact our financial position, results of operations or cash flows is disclosed in Note 2 to our consolidated financial statements included elsewhere in this Annual Report on Form 10-K.

[0001628280-24-008053:mdna:162]
Emerging Growth Company Status

[0001628280-24-008053:mdna:163]
Upon the completion of the Merger, we qualified as an "emerging growth company" as defined in the JOBS Act. Effective December 31, 2023, we exited our EGC status and became a "large accelerated filer" as defined in Rule 12b-2 of the Exchange Act. As a result, we may no longer take advantage of the extended transition period provided in Section 7(a)(2)(B) of the Securities Act for complying with new or revised accounting standards available to EGCs, and we must comply with all financial reporting and compliance requirements applicable to a "large accelerated filer". The effect of the loss of EGC status and the impact of the adoption of new accounting pronouncements is discussed further in Note 2 to our consolidated financial statements in this Annual Report on Form 10-K.

[0001628280-24-008053:mdna:164]
Critical Accounting Policies and Estimates

[0001628280-24-008053:mdna:165]
Our consolidated financial statements are prepared in accordance with generally accepted accounting principles in the United States. The preparation of our consolidated financial statements and related disclosures requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, costs and expenses, and the disclosure of contingent assets and liabilities in our consolidated financial statements. We base our estimates on historical experience, known trends and events and various other factors that we believe are reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. We evaluate our estimates and assumptions on an ongoing basis. Our actual results may differ from these estimates under different assumptions or conditions.

[0001628280-24-008053:mdna:166]
While our significant accounting policies are described in more detail in Note 2 to our consolidated financial statements, we believe that the following accounting policies are those most critical to the judgments and estimates used in the preparation of our consolidated financial statements.

[0001628280-24-008053:mdna:167]
Marketable Securities

[0001628280-24-008053:mdna:168]
Marketable securities are reported at fair value and, at December 31, 2023, are comprised solely of zero coupon U.S. treasury bills with maturities of less than one year that are classified as available-for-sale debt securities. The Company considers an available-for-sale debt security to be impaired if the fair value of the investment is less than its amortized cost basis. The entire difference between the amortized cost basis and the fair value of the Company’s available-for-sale debt securities is recognized on the consolidated statements of operations as an impairment if, (i) the fair value of the security is below its amortized cost and (ii) the Company intends to sell or is more likely than not required to sell the security before recovery of its amortized cost basis. If neither criterion is met, the Company evaluates whether the decline in fair value is due to credit losses or other factors. In making this assessment, the Company considers the changes to the rating of the security by third-party rating agencies, and adverse conditions specific to the security, among other factors. If the Company’s assessment indicates that a credit loss exists, the credit loss is measured based on the Company’s best estimate of the cash flows expected to be collected. When developing its estimate of cash flows expected to be collected, the Company considers all available information relevant to the collectability of the security, including past events, current conditions, and reasonable and supportable forecasts.

[0001628280-24-008053:mdna:169]
Revenue Recognition

[0001628280-24-008053:mdna:170]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement, (4) license fees under the Distribution and License Agreement, and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001628280-24-008053:mdna:171]
Product Revenue

[0001628280-24-008053:mdna:172]
We derive a portion of our revenue from the sale of our Evolv Express equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract.

[0001628280-24-008053:mdna:173]
Subscription Revenue

[0001628280-24-008053:mdna:174]
Subscription revenue is comprised of revenue derived from leasing Evolv Express and Evolv Edge units to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001628280-24-008053:mdna:175]
Lease arrangements generally include both lease and non-lease components. The non-lease components relate to (1) distinct services, including professional services, SaaS, and maintenance, and (2) any add-on accessories. Professional services are included in license fees and other revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive loss.

[0001628280-24-008053:mdna:176]
Service Revenue

[0001628280-24-008053:mdna:177]
Service revenue consists of subscription-based SaaS and maintenance revenue related to products sold to a customer. Customers generally pay either a quarterly or annual fixed payment for SaaS and maintenance. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically four years.

[0001628280-24-008053:mdna:178]
License Fee and Other Revenue

[0001628280-24-008053:mdna:179]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product

[0001628280-24-008053:mdna:180]
from our third-party manufacturer to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration.

[0001628280-24-008053:mdna:181]
Revenue from Reseller Partners

[0001628280-24-008053:mdna:182]
A portion of our revenue is generated by sales in conjunction with our reseller partners. When we transact with a reseller partner, our contractual arrangement is with the reseller partner and not with the end-use customer. Whether we transact with a reseller partner and receive the order from a reseller partner or directly from an end-use customer, our revenue recognition policy and resulting pattern of revenue recognition is the same.

[0001628280-24-008053:mdna:183]
Standalone Selling Price

[0001628280-24-008053:mdna:184]
We allocate the transaction price to each distinct performance obligation based on the standalone selling price (“SSP”) of each product or service. Our contracts may include multiple performance obligations when customers purchase a combination of products and services. When our customer arrangements have multiple performance obligations that contain a lease as well as distinct services that are delivered simultaneously, we allocate the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, we allocate the contract’s transaction price to each performance obligation on a relative SSP basis.

[0001628280-24-008053:mdna:185]
Stock-Based Compensation

[0001628280-24-008053:mdna:186]
We measure stock-based option awards granted to employees, consultants and directors based on their fair value on the date of grant using the Black-Scholes option-pricing model. Compensation expense for those awards is recognized, net of estimated forfeitures, over the requisite service period, which is generally the vesting period of the respective award.

[0001628280-24-008053:mdna:187]
Prior to the closing of the Merger, the fair value of each stock option grant was estimated on the date of grant using the Black-Scholes option-pricing model, which uses the following inputs: (1) the fair value per share of the common stock issuable upon exercise of the option, (2) the expected term of the option, (3) expected volatility of the price of the common stock, (4) the risk-free interest rate, and (5) the expected dividend yield.

[0001628280-24-008053:mdna:188]
After the closing of the Merger, we determine the fair value of each share of common stock underlying stock-based awards based on the closing price of our common stock as reported by Nasdaq on the date of grant.

[0001628280-24-008053:mdna:189]
The Black-Scholes option-pricing model uses as inputs the fair value of our common shares and assumptions we make for the volatility of our common shares, the expected term of our stock options, the risk-free interest rate for a period that approximates the expected term of our stock options, and our expected dividend yield. As a result of being a private company prior to the Merger, the Company currently lacks sufficient company-specific historical and implied volatility information to solely utilize its own data for purposes of establishing the volatility assumption for use in the Black-Scholes model. Therefore, we estimate our expected share volatility based on a mix of company-specific historical volatility and historical volatility of a publicly traded set of peer companies. We expect to continue to do so until such time as we have adequate historical data regarding the volatility of our own traded share price.

[0001628280-24-008053:mdna:190]
Valuation of Contingent Earn-out Liability

[0001628280-24-008053:mdna:191]
The estimated fair value of the contingent earn-out shares is determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including volatility, risk-free rate of return, likelihood of a change in control, and expected remaining term. For potential common stock issuances related to a stock price milestones, the fair value was determined based on our expectations of achieving such a milestone and the simulated estimated stock price on the expected date of achievement.

[0001628280-24-008053:mdna:192]
We believe our assumptions are reasonable based on available information, our experience, knowledge, and judgments. These estimates can be affected by factors that are difficult to predict including future (1) EVLV closing price per share on the Nasdaq, (2) estimated stock price volatility over the earn-out period, and (3) risk free rates. Changes in assumptions and estimates used in our analysis, or future results that vary from assumptions used in the analysis, could affect the fair value of the contingent earn-out and could result in material changes in future periods.

[0001628280-24-008053:mdna:193]
Valuation of Contingently Issuable Common Stock Liability

[0001628280-24-008053:mdna:194]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the vesting period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including volatility, risk-free rate of return, likelihood of a change in control, and expected remaining term.

[0001628280-24-008053:mdna:195]
We believe our assumptions are reasonable based on available information, our experience, knowledge, and judgments. These estimates can be affected by factors that are difficult to predict including future (1) EVLV closing price per share on the Nasdaq, (2) estimated stock price volatility over the contingently issuable common shares period, and (3) risk free rates. Changes in assumptions and estimates used in our analysis, or future results that vary from assumptions used in the analysis, could affect the fair value of the contingently issuable common stock and could result in material changes in future periods.

[0001628280-24-008053:mdna:196]
Valuation of Public Warrant Liability

[0001628280-24-008053:mdna:197]
In connection with the closing of the Merger, we assumed the Public Warrants to purchase shares of common stock, which were classified as a liability, as the Public Warrants do not meet the criteria to be indexed to our common stock. Accordingly, we recorded the Public Warrants at fair value upon the closing of the Merger with a corresponding adjustment to additional paid-in capital. After the initial measurement, the fair value of the Public Warrants is subsequently remeasured quarterly based on the listed market price on the Nasdaq of such Public Warrants.

[0001628280-24-008053:mdna:198]
Valuation of Inventory

[0001628280-24-008053:mdna:199]
Inventory is valued at the lower of cost or net realizable value. Cost is computed using the weighted average method. We regularly review inventory quantities on-hand for excess and obsolete inventory and, when circumstances indicate, record charges to write down inventories to their estimated net realizable value, after evaluating historical sales, future demand, our estimates of forecasted net revenue, market conditions and expected product life cycles. A significant change in the timing or level of demand for our products as compared to forecasted amounts may result in recording additional write-offs. Such charges are classified as cost of product revenue in the statements of operations and comprehensive loss. Any write-down of inventory to net realizable value creates a new cost basis.

[0001628280-24-008053:mdna:200]
Capitalized Software

[0001628280-24-008053:mdna:201]
Software development costs consist of certain consulting costs and compensation expenses for employees who devote time to the development of our internal-use software and software embedded in products to be sold or leased, as well as certain upgrades and enhancements that are expected to result in enhanced functionality. We amortize these development costs over the estimated useful life of four years. We determined that a four year life is appropriate for our capitalized software based on our best estimate of the useful life of the software after considering factors such as continuous developments in the technology, obsolescence, and anticipated life of the service offering before significant upgrades. Management evaluates the useful lives of these assets on a quarterly basis and tests for impairment whenever events or changes in circumstances occur that could impact the recoverability of these assets.

[0001628280-24-008053:mdna:202]
We determine the amount of software costs to be capitalized based on the amount of time spent by our developers and consultants on projects in the application stage of development. There is judgment in estimating the time allocated to a particular project in the application stage. A significant change in the time spent on each project could have a material impact on the amount capitalized and related amortization expense in subsequent periods.

[0001628280-24-008053:mdna:203]
Leases

[0001628280-24-008053:mdna:204]
To determine the residual value estimates and useful life of equipment that we lease to our customers, we are required to make judgments about future events that are subject to risks and uncertainties outside of their control, such as inventory levels of new equipment, changing consumer preferences, new technology and mandatory regulations. We have disciplines related to the management and maintenance of our leased equipment designed to manage the risk associated with the residual values of our revenue generating equipment. We periodically review and adjust, as appropriate, the estimated residual values and useful lives of existing revenue generating equipment for the purposes of classifying transactions as operating or sales-type leases and recording depreciation expense. Based on the results of our analysis, we

[0001628280-24-008053:mdna:205]
may adjust the estimated residual values and useful lives of individual assets of our revenue generating equipment each year.
