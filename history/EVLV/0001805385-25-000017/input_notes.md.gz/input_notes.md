# EVLV notes — 0001805385-25-000017


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001805385-25-000017:notes:1]
[same as prior period, unchanged from 0001805385-25-000009:notes:1]

[0001805385-25-000017:notes:2]
The Company offers two major products, Evolv Express® and Evolv eXpedite™, which are designed to efficiently screen high volumes of people and bags for concealed threats. These products and their associated services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

[0001805385-25-000017:notes:3]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. (“Evolv UK”) and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”). References to the “Investigation” refer to the investigation commenced in September 2024 by an ad hoc committee of independent directors of the Company's Board of Directors into its sales practices, as previously disclosed in our Annual Report on Form 10-K for the year ended December 31, 2024.

[0001805385-25-000017:notes:4]
[same as prior period, unchanged from 0001805385-25-000009:notes:4]

[0001805385-25-000017:notes:5]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001805385-25-000017:notes:6]
[same as prior period, unchanged from 0001805385-25-000009:notes:6]

[0001805385-25-000017:notes:7]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures, debt obligations, and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of September 30, 2025, the Company had $56.2 million in cash, cash equivalents, and marketable securities, with outstanding debt of $28.5 million and available additional debt of up to $45.0 million, as detailed below. We incurred a net loss of $44.0 million and $38.3 million for the nine months ended September 30, 2025 and 2024, respectively, and operating activities resulted in cash inflow of $3.1 million and cash outflow of $34.1 million during the nine months ended September 30, 2025 and 2024, respectively. We expect to continue to generate losses for the foreseeable future.

[0001805385-25-000017:notes:8]
[same as prior period, unchanged from 0001805385-25-000009:notes:8]

[0001805385-25-000017:notes:9]
On July 29, 2025 (the “Closing Date”), the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's

[0001805385-25-000017:notes:10]
subscription sales model. The MidCap Credit Agreement provided an initial $30.0 million term loan facility (the “Initial Term Loan”), a $30.0 million delayed draw facility (the “Delayed Draw Term Loan”) (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit (the “Revolving Credit Facility”), each with a maturity date of July 1, 2030 (collectively, the “Senior Secured Credit Facilities”). On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs paid at closing. As of September 30, 2025, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available. See Note 9, Long-term Debt for additional information.

[0001805385-25-000017:notes:11]
The Company expects its cash, cash equivalents, and marketable securities of $56.2 million as of September 30, 2025, together with cash it expects to generate from future operations and borrowing availability under the Senior Secured Credit Facilities, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth.

[0001805385-25-000017:notes:12]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that begins at $106.0 million on December 31, 2025 and increases quarterly thereafter. The minimum required ARR on December 31, 2026 is $111.3 million. As of September 30, 2025, the Company’s ARR was $117.2 million, which is sufficient to satisfy the minimum required ARR through December 31, 2027; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. As of September 30, 2025, the minimum liquidity required is $15.0 million, and liquidity, as defined in the agreement, was $71.1 million. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum EBITDA covenant that takes effect on June 30, 2027. As of September 30, 2025, the Company is in full compliance with all applicable covenant requirements, and expects to remain in compliance for a period of at least twelve months from November 13, 2025.

[0001805385-25-000017:notes:13]
[same as prior period, unchanged from 0001805385-25-000009:notes:12]

[0001805385-25-000017:notes:14]
[same as prior period, unchanged from 0001805385-25-000009:notes:13]

[0001805385-25-000017:notes:15]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2025, and for the three and nine months ended September 30, 2025 and 2024 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2024 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2025, the results of its operations for the three and nine months ended September 30, 2025 and 2024 and cash flows for the nine months ended September 30, 2025 and 2024. The results for the three and nine months ended September 30, 2025 are not necessarily indicative of results to be expected for the year ending December 31, 2025, any other interim periods, or any future year or period. These interim unaudited condensed consolidated financial statements should be read in conjunction with the financial statements included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024.

[0001805385-25-000017:notes:16]
[same as prior period, unchanged from 0001805385-25-000009:notes:15]

[0001805385-25-000017:notes:17]
During the three months ended March 31, 2025, the Company began classifying restructuring charges, which includes termination charges arising from severance obligations, incremental non-cash expense, and other customary employee benefit payments in connection with a reduction in force, within restructuring costs on the condensed consolidated statements of operations and comprehensive loss, whereas the restructuring costs for these services had previously been included in cost of service revenue, research and development expenses, sales and marketing expenses,

[0001805385-25-000017:notes:18]
and general and administrative expenses. These reclassifications were made to align the presentation of restructuring charges with the Company's internal reporting and analysis. There were no reclassifications for the three months ended September 30, 2024. The reclassifications increased gross profit by $0.2 million for the nine months ended September 30, 2024 and did not impact total loss from operations or total net loss for any period. Prior year amounts included in this Quarterly Report on Form 10-Q have been reclassified to conform to the current presentation.

[0001805385-25-000017:notes:19]
For the nine months ended September 30, 2024, the reclassifications resulted in an increase in restructuring costs of $0.9 million, and a corresponding decrease in cost of service revenue, sales and marketing expenses, and general and administrative expenses of $0.2 million, $0.7 million, and less than $0.1 million, respectively.

[0001805385-25-000017:notes:20]
During the three months ended September 30, 2025, the Company recorded an out-of-period correction to decrease other income (expense) by $0.9 million, decrease contingently issuable common stock liability by $2.3 million, increase other assets by $2.0 million and increase additional paid in capital by $3.4 million. The out-of-period adjustment was recorded to correct the accounting for the fair value of the contingently issuable common shares and the contingently returnable common stock, as described in more detail in Note 4, Fair Value Measurements. Management evaluated the accounting impacts on prior periods based on the historical dates of transfers, concluding that such impacts were not material to the historical financial statements.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001805385-25-000017:notes:21]
[same as prior period, unchanged from 0001805385-25-000009:notes:80]

[0001805385-25-000017:notes:22]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2024, and the notes thereto, which are included in our 2024 Form 10-K. Except for the partner rebate program, debt and debt issuance costs, and the estimates used to determine the grant date valuation for certain market-based stock units (“MSUs”), as described below, there have been no material changes to the Company’s significant accounting policies during the nine months ended September 30, 2025.

[0001805385-25-000017:notes:23]
[same as prior period, unchanged from 0001805385-25-000009:notes:82]

[0001805385-25-000017:notes:24]
[same as prior period, unchanged from 0001805385-25-000009:notes:83]

[0001805385-25-000017:notes:25]
[same as prior period, unchanged from 0001805385-25-000009:notes:84]

[0001805385-25-000017:notes:26]
[same as prior period, unchanged from 0001805385-25-000009:notes:85]

[0001805385-25-000017:notes:27]
The estimated grant date fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.

[0001805385-25-000017:notes:28]
Debt and Debt issuance costs

[0001805385-25-000017:notes:29]
Debt is initially recognized at the amount of proceeds received, net of directly attributable issuance costs. The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated

[0001805385-25-000017:notes:30]
debt on the condensed consolidated balance sheet and amortized as interest expense on the condensed consolidated statement of operations and comprehensive loss using the effective interest method.

[0001805385-25-000017:notes:31]
For undrawn delayed draw and revolving line of credit facilities, commitment fees and related costs are costs incurred in exchange for access to capital. These fees are paid regardless of whether the funds are drawn down. Such costs associated with delayed draw facility are capitalized as prepaid expenses and other current assets and other assets in our condensed consolidated balance sheets, and such costs associated with revolving line of credit are capitalized as other assets in our condensed consolidated balance sheets. The capitalized costs are amortized as interest expense on a straight-line basis over the access period. If drawdown of the delayed draw facility becomes probable, the remaining unamortized costs are reclassified as contra-debt and amortized using the effective interest method. If it becomes probable that the delayed draw facility will not be drawn during the access period, the remaining unamortized cost will be recognized as expense in the period that determination was made.

[0001805385-25-000017:notes:32]
Recently Issued Accounting Pronouncements

[0001805385-25-000017:notes:33]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity may apply the amendments in ASU 2023-09 either prospectively to all annual periods beginning after December 15, 2024, or retrospectively to prior periods. The Company determined that ASU 2023-09 is applicable and will be adopted in our Annual Report on Form 10-K for the year ended December 31, 2025. As ASU 2023-09 addresses disclosures only, the Company expects it will not have any material effects on its financial condition, results of operations, or cash flows.

[0001805385-25-000017:notes:34]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses.”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

[0001805385-25-000017:notes:35]
In July 2025, the FASB issued ASU 2025-05, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets.” The amendment in ASU 2025-05 provides entities with a practical expedient to simplify the estimation of expected credit losses by assuming that the current conditions as of the balance sheet date will not change for the remaining life of the asset. Early adoption is permitted, and this amendment is applied prospectively. ASU 2025-05 is effective for all annual periods beginning after December 15, 2025 and interim periods within those annual periods. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

[0001805385-25-000017:notes:36]
In September 2025, the FASB issued ASU 2025-06, “Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software.” which amends guidance on capitalization of software development costs and introduces a probable-to-complete recognition threshold, along with factors to consider for evaluating significant development uncertainty. The amendments are effective for annual reporting periods beginning after December 15, 2027, including interim periods within those annual periods. Early adoption is permitted and this amendment is applied prospectively. The Company is currently evaluating the impact of this ASU on its accounting policies and disclosures within the consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001805385-25-000017:notes:37]
Marketable Securities
Marketable securities as of September 30, 2025 and December 31, 2024 consisted of the following:

[0001805385-25-000017:notes:38]
|  | September 30, 2025 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 24,723 |  |  | $ | — |  |  | $ | 24,723 |  |
| Total marketable securities | $ | 24,723 |  |  | $ | — |  |  | $ | 24,723 |  |

[0001805385-25-000017:notes:39]
|  | December 31, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 14,927 |  |  | $ | — |  |  | $ | 14,927 |  |
| Total marketable securities | $ | 14,927 |  |  | $ | — |  |  | $ | 14,927 |  |

[0001805385-25-000017:notes:40]
Marketable securities at September 30, 2025 and December 31, 2024 were comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and nine months ended September 30, 2025 and 2024. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive loss.


## us-gaap:FairValueDisclosuresTextBlock

[0001805385-25-000017:notes:41]
[same as prior period, unchanged from 0001805385-25-000009:notes:95]

[0001805385-25-000017:notes:42]
|  | Fair Value Measurements at September 30, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 9,017 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,017 |  |
| Treasury bills | — |  |  | 29,714 |  |  | — |  |  | 29,714 |  |
| Contingently returnable common stock asset | — |  |  | — |  |  | 3,239 |  |  | 3,239 |  |
|  | $ | 9,017 |  |  | $ | 29,714 |  |  | $ | 3,239 |  |  | $ | 41,970 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 10,512 |  |  | $ | 10,512 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 3,638 |  |  | 3,638 |  |
| Public Warrant liability | 10,457 |  |  | — |  |  | — |  |  | 10,457 |  |
|  | $ | 10,457 |  |  | $ | — |  |  | $ | 14,150 |  |  | $ | 24,607 |  |

[0001805385-25-000017:notes:43]
[same as prior period, unchanged from 0001805385-25-000009:notes:97]

[0001805385-25-000017:notes:44]
Money market funds are included in cash and cash equivalents on the condensed consolidated balance sheets. As of September 30, 2025, U.S. treasury bills with maturities less than 3 months, which totaled $5.0 million, are included in cash and cash equivalents, while treasury bills with maturities greater than 3 months, which totaled $24.7 million, are reflected as marketable securities. As of December 31, 2024, U.S. treasury bills with maturities less than 3 months, which totaled $12.5 million, are included in cash and cash equivalents, while treasury bills with maturities greater than 3 months, which totaled $14.9 million, are reflected as marketable securities. The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources.

[0001805385-25-000017:notes:45]
[same as prior period, unchanged from 0001805385-25-000009:notes:99]

[0001805385-25-000017:notes:46]
[same as prior period, unchanged from 0001805385-25-000009:notes:100]

[0001805385-25-000017:notes:47]
The carrying value of the Company’s long-term debt approximates its fair value (a Level 2 measurement) at each balance sheet date due to its variable interest rate, which approximates a market interest rate.

[0001805385-25-000017:notes:48]
During each of the nine months ended September 30, 2025 and 2024, there were no transfers between Level 1, Level 2 and Level 3.

[0001805385-25-000017:notes:49]
[same as prior period, unchanged from 0001805385-25-000009:notes:102]

[0001805385-25-000017:notes:50]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 3 of our consolidated financial statements of our 2024 Form 10-K. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of September 30, 2025, no milestones have been achieved.

[0001805385-25-000017:notes:51]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of September 30, 2025 were as follows: 70% expected stock price volatility, a risk-free rate of return of 3.9%, a 5% likelihood of change in control and a remaining term of 0.4 years. The assumed likelihood of change in control was reduced to 5% as of September 30, 2025 from 15% as of June 30, 2025, reflecting the shortened remaining term of less than one year.

[0001805385-25-000017:notes:52]
[same as prior period, unchanged from 0001805385-25-000009:notes:105]

[0001805385-25-000017:notes:53]
| Balance at December 31, 2024 | $ | 12,809 |  |
| Change in fair value | (2,297) |  |
| Balance at September 30, 2025 | $ | 10,512 |  |

[0001805385-25-000017:notes:54]
The decrease in fair value of the contingent earn-out liability is primarily due to the shortened remaining term of less than one year as well as the reduced likelihood of a change in control.

[0001805385-25-000017:notes:55]
Valuation of Contingently Issuable Common Stock and Contingently Returnable Common Stock Asset

[0001805385-25-000017:notes:56]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock which were converted into shares of the Company's stock in connection with the Merger (the “Founder Shares”). Of these shares, 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 unvested shares will vest upon the Company achieving certain milestones as described in Note 3 of our consolidated financial statements of our 2024 Form 10-K ("Vesting Conditions"). The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of September 30, 2025, no milestones have been achieved.

[0001805385-25-000017:notes:57]
Under the Founder Shares arrangement, Founder Shares may be transferred to third parties, subject to certain conditions. The unvested shares must be returned to the Company if the specified Vesting Conditions are not met. As of September 30, 2025, a total of 729,570 unvested shares had been transferred to individual stockholders' brokerage accounts. As of September 30, 2025, the fair value of the unvested shares recorded as additional paid in capital was $3.7 million. The contractual obligation of the holders to return unvested shares upon failure to meet Vesting Conditions is accounted for as a freestanding financial asset in accordance with ASC 815. This asset is initially recognized at fair value and remeasured at each reporting period. As of September 30, 2025, the Company recognized a $3.2 million contingently returnable common stock asset, which is included in other assets in our condensed consolidated balance sheets. Management evaluated the accounting impacts on prior periods based on the historical dates of transfers between July 2022 and June 2025, concluding that such impacts were not material to the historical financial statements, as further described in Note 1, Nature of the Business.

[0001805385-25-000017:notes:58]
The fair value of the contingently issuable common shares and the contingently returnable common stock asset is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of September 30, 2025 were as follows: 70% expected stock price volatility, a risk-free rate of return of 3.7%, a 15% likelihood of change in control and a remaining term of 0.8 years. The assumed likelihood of change in control was reduced to 15% as of September 30, 2025 from 25% as of June 30, 2025, reflecting the shortened remaining term of less than one year.

[0001805385-25-000017:notes:59]
[same as prior period, unchanged from 0001805385-25-000009:notes:111]

[0001805385-25-000017:notes:60]
| Balance at December 31, 2024 | $ | 4,001 |  |
| Change in fair value | 1,906 |  |
| Common shares issuance | (2,269) |  |
| Balance at September 30, 2025 | $ | 3,638 |  |

[0001805385-25-000017:notes:61]
The following table provides a rollforward of the contingently returnable common stock asset (in thousands):

[0001805385-25-000017:notes:62]
| Balance at December 31, 2024 | $ | — |  |
| Fair value of the contingently returnable common stock asset | 3,239 |  |
| Balance at September 30, 2025 | $ | 3,239 |  |

[0001805385-25-000017:notes:63]
[same as prior period, unchanged from 0001805385-25-000009:notes:113]

[0001805385-25-000017:notes:64]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. As of September 30, 2025, 14,324,893 Public Warrants are outstanding.

[0001805385-25-000017:notes:65]
[same as prior period, unchanged from 0001805385-25-000009:notes:116]

[0001805385-25-000017:notes:66]
| Balance at December 31, 2024 | $ | 4,297 |  |
| Change in fair value | 6,160 |  |
| Balance at September 30, 2025 | $ | 10,457 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001805385-25-000017:notes:67]
[same as prior period, unchanged from 0001805385-25-000009:notes:118]

[0001805385-25-000017:notes:68]
[same as prior period, unchanged from 0001805385-25-000009:notes:119]

[0001805385-25-000017:notes:69]
[same as prior period, unchanged from 0001805385-25-000009:notes:120]

[0001805385-25-000017:notes:70]
In March 2023, the Company entered into a distributor licensing agreement (the “Distribution and License Agreement”) with Columbia Electrical Contractors, Inc. (“Columbia Tech”). Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, which serves as the Company's primary contract manufacturer. Under this arrangement, the Company has granted a license of its intellectual property to Columbia Tech, which contracts directly with certain of the Company's resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment as opposed to lease the equipment. Columbia Tech pays the Company a hardware license fee for each system it manufactures and sells under the agreement. In these instances, the Company still contracts directly with the reseller to provide a multi-year SaaS and maintenance subscription to the end-users. During the three months ended September 30, 2025, the Company discontinued quoting on this basis, and while any outstanding quotes will be honored, all new quotes for end-user customers wishing to purchase the hardware equipment will be fulfilled through the Company's purchase subscription model going forward.

[0001805385-25-000017:notes:71]
[same as prior period, unchanged from 0001805385-25-000009:notes:122]

[0001805385-25-000017:notes:72]
[same as prior period, unchanged from 0001805385-25-000009:notes:123]

[0001805385-25-000017:notes:73]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2025:

[0001805385-25-000017:notes:74]
|  | Less than 1 year |  | 1 - 2 years |  | More than 2 years |  | Total |
| Product revenue | $ | 7,346 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,346 |  |
| Subscription revenue | 87,330 |  |  | 68,552 |  |  | 62,643 |  |  | 218,525 |  |
| Service revenue | 31,045 |  |  | 20,772 |  |  | 19,841 |  |  | 71,658 |  |
| License fee and other revenue | 938 |  |  | 32 |  |  | 61 |  |  | 1,031 |  |
| Total revenue | $ | 126,659 |  |  | $ | 89,356 |  |  | $ | 82,545 |  |  | $ | 298,560 |  |

[0001805385-25-000017:notes:75]
[same as prior period, unchanged from 0001805385-25-000009:notes:126]

[0001805385-25-000017:notes:76]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time.  As of September 30, 2025 and December 31, 2024, the Company had $1.2 million and $0.8 million in current portion of contract assets and $0.4 million and $0.7 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001805385-25-000017:notes:77]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $13.9 million and $58.0 million during the three and nine months ended September 30, 2025, respectively, that was included in the December 31, 2024 deferred revenue balance. The Company recognized revenue of $10.1 million and $40.8 million during the three and nine months ended September 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance.

[0001805385-25-000017:notes:78]
[same as prior period, unchanged from 0001805385-25-000009:notes:129]

[0001805385-25-000017:notes:79]
| Balance at December 31, 2024 | $ | 84,772 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (57,966) |  |
| Revenue deferred | 69,562 |  |
| Balance at September 30, 2025 | $ | 96,368 |  |

[0001805385-25-000017:notes:80]
[same as prior period, unchanged from 0001805385-25-000009:notes:131]

[0001805385-25-000017:notes:81]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest income on lease receivables | $ | 24 |  |  | $ | 40 |  |  | $ | 80 |  |  | $ | 123 |  |
| Lease income - operating leases | 22,685 |  |  | 17,909 |  |  | 62,122 |  |  | 47,783 |  |
| Total lease revenue | $ | 22,709 |  |  | $ | 17,949 |  |  | $ | 62,202 |  |  | $ | 47,906 |  |

[0001805385-25-000017:notes:82]
[same as prior period, unchanged from 0001805385-25-000009:notes:133]

[0001805385-25-000017:notes:83]
under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties was $0.5 million and $1.1 million during the three and nine months ended September 30, 2024, respectively. There was no revenue related to leases entered into with related parties during the three and nine months ended September 30, 2025.

[0001805385-25-000017:notes:84]
[same as prior period, unchanged from 0001805385-25-000009:notes:135]

[0001805385-25-000017:notes:85]
[same as prior period, unchanged from 0001805385-25-000009:notes:136]

[0001805385-25-000017:notes:86]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Product revenue | $ | 9,242 |  |  | $ | 1,344 |  |  | $ | 14,092 |  |  | $ | 4,789 |  |
| Subscription revenue | 22,685 |  |  | 17,909 |  |  | 62,122 |  |  | 47,783 |  |
| Service revenue | 7,808 |  |  | 6,085 |  |  | 21,224 |  |  | 16,903 |  |
| License fees | 2,280 |  |  | 1,606 |  |  | 7,774 |  |  | 4,047 |  |
| Professional services and other revenue | 835 |  |  | 416 |  |  | 2,189 |  |  | 1,243 |  |
| Total revenue | $ | 42,850 |  |  | $ | 27,360 |  |  | $ | 107,401 |  |  | $ | 74,765 |  |

[0001805385-25-000017:notes:87]
As discussed in Note 2, Summary of Significant Accounting Policies, the Company implemented a new Rebate Program for eligible resellers. As of September 30, 2025, the Company has accrued $1.1 million related to the Rebate Program, which is included in accrued expenses and other current liabilities in our condensed consolidated balance sheets. As a substantial amount of the Company's revenue with eligible resellers is recognized over-time, the Company recognized $0.2 million and $0.6 million of current portion of contract asset and contract asset, noncurrent in our condensed consolidated balance sheets, respectively, as of September 30, 2025 and recognized $0.2 million and $0.4 million as reduction of revenue for the three and nine months ended September 30, 2025, respectively.

[0001805385-25-000017:notes:88]
[same as prior period, unchanged from 0001805385-25-000009:notes:139]

[0001805385-25-000017:notes:89]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and professional services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $13.0 million as of both September 30, 2025 and December 31, 2024. During the three months ended September 30, 2025 and 2024, the Company recognized commission expense of $2.1 million and $1.4 million, respectively. During the nine months ended September 30, 2025 and 2024, the Company recognized commission expense of $5.4 million and $4.3 million, respectively.

[0001805385-25-000017:notes:90]
[same as prior period, unchanged from 0001805385-25-000009:notes:141]

[0001805385-25-000017:notes:91]
As of September 30, 2025, future minimum noncancelable payments related to leases of the Company's equipment are as follows (in thousands):

[0001805385-25-000017:notes:92]
| Year Ending December 31: |  |
| 2025 (three months remaining) | $ | 23,132 |  |
| 2026 | 83,429 |  |
| 2027 | 61,724 |  |
| 2028 | 35,868 |  |
| 2029 | 13,693 |  |
| Thereafter | 679 |  |
|  | $ | 218,525 |  |


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001805385-25-000017:notes:93]
[same as prior period, unchanged from 0001805385-25-000009:notes:144]

[0001805385-25-000017:notes:94]
[same as prior period, unchanged from 0001805385-25-000009:notes:145]

[0001805385-25-000017:notes:95]
|  | Allowance for Expected Credit Losses |
| Balance at December 31, 2024 | $ | (734) |  |
| Provisions | (131) |  |
| Write-offs, net of recoveries | 65 |  |
| Balance at September 30, 2025 | $ | (800) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001805385-25-000017:notes:96]
[same as prior period, unchanged from 0001805385-25-000009:notes:147]

[0001805385-25-000017:notes:97]
|  | September 30,2025 |  | December 31,2024 |
| Raw materials | $ | 3,717 |  |  | $ | 4,362 |  |
| Finished goods |  |  |  |
| Finished goods inventory | 4,966 |  |  | 12,153 |  |
| Uninstalled inventory | 87 |  |  | 448 |  |
| Total | $ | 8,770 |  |  | $ | 16,963 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001805385-25-000017:notes:98]
[same as prior period, unchanged from 0001805385-25-000009:notes:150]

[0001805385-25-000017:notes:99]
|  | September 30,2025 |  | December 31,2024 |
| Computers and telecom equipment | $ | 2,152 |  |  | $ | 2,064 |  |
| Lab equipment | 6,244 |  |  | 5,564 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 607 |  |  | 607 |  |
| Leased equipment | 134,050 |  |  | 112,078 |  |
| Capitalized software | 19,324 |  |  | 14,555 |  |
| Sales demo equipment | 3,015 |  |  | 3,649 |  |
| Vehicles | 604 |  |  | 604 |  |
| Equipment held for lease1 | 12,193 |  |  | 17,347 |  |
| Construction in progress | 35 |  |  | 477 |  |
|  | 178,335 |  |  | 157,056 |  |
| Less: Accumulated depreciation and amortization | (51,416) |  |  | (33,395) |  |
|  | $ | 126,919 |  |  | $ | 123,661 |  |

[0001805385-25-000017:notes:100]
[same as prior period, unchanged from 0001805385-25-000009:notes:152]

[0001805385-25-000017:notes:101]
As of September 30, 2025 and December 31, 2024, the net book value of capitalized software was $13.1 million and $11.1 million, respectively. These amounts include $2.4 million and $1.7 million of capitalized stock-based compensation costs, respectively. Depreciation and amortization expense related to property and equipment was $6.5 million and $4.6 million for the three months ended September 30, 2025 and 2024, respectively, which included amortization expense of capitalized software of $1.0 million and $0.4 million for the three months ended September 30, 2025 and 2024, respectively. Depreciation and amortization expense related to property and equipment was $17.9 million and $11.9 million for the nine months ended September 30, 2025 and 2024, respectively, which included amortization expense of capitalized software of $2.8 million and $1.0 million for the nine months ended September 30, 2025 and 2024, respectively.

[0001805385-25-000017:notes:102]
[same as prior period, unchanged from 0001805385-25-000009:notes:154]

[0001805385-25-000017:notes:103]
|  | September 30,2025 |  | December 31,2024 |
| Leased equipment | $ | 134,050 |  |  | $ | 112,078 |  |
| Accumulated depreciation | (39,771) |  |  | (25,726) |  |
| Leased equipment, net | $ | 94,279 |  |  | $ | 86,352 |  |

[0001805385-25-000017:notes:104]
Depreciation expense related to leased equipment was $5.0 million and $3.7 million during the three months ended September 30, 2025 and 2024, respectively. Depreciation expense related to leased equipment was $13.4 million and $9.7 million during the nine months ended September 30, 2025 and 2024, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.

[0001805385-25-000017:notes:105]
The Company recorded losses of $1.9 million and $3.5 million from disposals of property and equipment during the three and nine months ended September 30, 2025, respectively, primarily related to the disposal of previously leased Evolv Express systems in connection with customer upgrades to the second generation of Express systems, which were recorded in cost of subscription revenue. The Company did not record any loss from disposal of property and equipment during the three and nine months ended September 30, 2024.
The Company recorded $0.2 million loss from impairment of property and equipment during each of the three and nine months ended September 30, 2024. This primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in an impairment of the remaining economic value of such units. The Company did not record any impairment of property and equipment during the three and nine months ended September 30, 2025.


## us-gaap:DebtDisclosureTextBlock

[0001805385-25-000017:notes:106]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001805385-25-000017:notes:107]
|  | September 30,2025 |  |  |
| Term loans payable | $ | 30,000 |  |  |  |
| Less: Unamortized discount | (1,472) |  |  |  |
|  | 28,528 |  |  |  |
| Less: Current portion of long-term debt | — |  |  |  |
| Long-term debt, net of discount | $ | 28,528 |  |  |  |

[0001805385-25-000017:notes:108]
As described in Note 1, on July 29, 2025, the Company entered into the $75.0 million MidCap Credit Agreement, which provided for the Senior Secured Credit Facilities, which include a $30.0 million Initial Term Loan, a $30.0 million Delayed Draw Term Loan (available for drawdown during the two-year period following the Closing Date), and a $15.0 million Revolving Credit Facility, each with a maturity date of July 1, 2030. As of September 30, 2025, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available.

[0001805385-25-000017:notes:109]
On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs funded at closing. The total debt issuance costs of $3.7 million, which included $0.3 million of additional issuance costs paid by the Company, have been allocated to each component of the facility in accordance with ASC 835. The Senior Secured Credit Facilities are guaranteed by the Company, and in the future, may be guaranteed by certain material subsidiaries. The Senior Secured Credit Facilities are secured by a first lien on substantially all of the assets of the Company.

[0001805385-25-000017:notes:110]
The Senior Secured Credit Facilities bear interest at a fluctuating rate per annum equal to Term Secured Overnight Financing Rate (“Term SOFR”) and an applicable margin calculated based on earnings before interest, taxes, depreciation, and amortization (“EBITDA”). At closing, the applicable margin on Term SOFR loans was 5.25%. If the event described under the MidCap Credit Agreement related to Term SOFR occurs, a base rate is determined by reference to the higher of (1) the prime rate of Wells Fargo and (2) 2.00%. Interest and principal are payable monthly. Monthly interest payments are due in arrears on the first day of each month.

[0001805385-25-000017:notes:111]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that begins at $106.0 million on December 31, 2025 and increases quarterly thereafter. The minimum required ARR on December 31, 2026 is $111.3 million. As of September 30, 2025,  the Company’s ARR was $117.2 million, which is sufficient to satisfy the minimum required ARR through December 31, 2027; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. As of September 30, 2025, the minimum liquidity required is $15.0 million, and liquidity, as defined in the agreement, was $71.1 million. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum EBITDA covenant that takes effect on June 30, 2027. As of September 30, 2025, the Company is in full compliance with all applicable covenant requirements, and expects to remain in compliance for a period of at least twelve months from November 13, 2025.

[0001805385-25-000017:notes:112]
Initial Term Loan

[0001805385-25-000017:notes:113]
The borrowing under the $30.0 million Initial Term Loan is subject to principal repayments beginning in August 2029, following a 48-month interest-only period, and will be repaid in equal installments over the final 12 months of the loan term.

[0001805385-25-000017:notes:114]
As of September 30, 2025, the unamortized debt issuance costs totaled $1.5 million, and are presented as a direct deduction from the carrying amount of the Initial Term Loan on the consolidated balance sheet and are amortized as interest expense using the effective interest method in accordance with ASC 835. Interest expense related to the Initial Term Loan totaled $0.6 million for the three and nine months ended September 30, 2025. The interest rate in effect as of September 30, 2025 was approximately 9.60%, which includes Term SOFR of 4.35% and an applicable margin of 5.25%. Interest expense related to the amortization of debt issuance costs totaled less than $0.1 million for the three and nine months ended September 30, 2025.

[0001805385-25-000017:notes:115]
As of September 30, 2025, future principal payments on long-term debt are as follows (in thousands):

[0001805385-25-000017:notes:116]
| December 31, |  |
| 2025 (remaining three months) | $ | — |  |
| 2026 | — |  |
| 2027 | — |  |
| 2028 | — |  |
| 2029 | 12,500 |  |
| Thereafter | 17,500 |  |
|  | $ | 30,000 |  |

[0001805385-25-000017:notes:117]
Delayed Draw Term Loan and Revolving Credit Facility

[0001805385-25-000017:notes:118]
As of September 30, 2025, no amounts had been drawn under the Delayed Draw Term Loan or Revolving Credit Facility. Unused commitments amounted to $30.0 million and $15.0 million under the Delayed Draw Term Loan and Revolving Credit Facility, respectively, as of September 30, 2025. Debt issuance costs allocated to these facilities are paid regardless of whether the funds are drawn down. Such costs are capitalized as prepaid assets and amortized as interest expense on a straight-line basis over their respective access periods, which end on August 1, 2027 and July 1, 2030 for Delayed Draw Term Loan and Revolving Credit Facility, respectively. As of September 30, 2025, the Company recorded $0.7 million in prepaid expenses and other current assets and $1.3 million in other assets in the condensed consolidated balance sheets for costs associated with Delayed Draw Term Loan and Revolving Credit Facility. Capitalized debt issuance cost is amortized as interest expense on a straight-line basis over the period each facility is available to be drawn. Interest expense related to the amortization of debt issuance costs totaled $0.2 million for the three and nine months ended September 30, 2025.

[0001805385-25-000017:notes:119]
The Revolving Credit Facility provides for an unused commitment fee of 0.25% on the undrawn portion of the facility. Interest expense related to the unused commitment fees totaled less than $0.1 million for the three and nine months ended September 30, 2025.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001805385-25-000017:notes:120]
[same as prior period, unchanged from 0001805385-25-000009:notes:158]

[0001805385-25-000017:notes:121]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the nine months ended September 30, 2024. No option grants were issued during the nine months ended  September 30, 2025.

[0001805385-25-000017:notes:122]
|  |  |  | Nine Months Ended September 30, |
|  |  |  | 2024 |
| Risk-free interest rate |  |  | 4.1% |
| Expected term (in years) |  |  | 6.1 |
| Expected volatility |  |  | 90.0% |
| Expected dividend yield |  |  | 0.0% |

[0001805385-25-000017:notes:123]
[same as prior period, unchanged from 0001805385-25-000009:notes:161]

[0001805385-25-000017:notes:124]
|  | Number ofShares |  | WeightedAverageExercise Price |
| Outstanding as of December 31, 2024 | 18,125,937 |  | $ | 1.18 |  |
| Granted | — |  |  | — |  |
| Exercised | (8,079,161) |  | 1.06 |  |
| Forfeited | (525,981) |  |  | 3.61 |  |
| Expired | (20,306) |  |  | 3.63 |  |
| Outstanding as of September 30, 2025 | 9,500,489 |  | $ | 1.15 |  |

[0001805385-25-000017:notes:125]
[same as prior period, unchanged from 0001805385-25-000009:notes:163]

[0001805385-25-000017:notes:126]
[same as prior period, unchanged from 0001805385-25-000009:notes:164]

[0001805385-25-000017:notes:127]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2024 | 12,115,657 |  |  | $ | 3.50 |  |
| Granted | 8,145,704 |  |  | 3.89 |  |
| Vested | (5,313,544) |  |  | 3.33 |  |
| Forfeited | (3,929,323) |  |  | 3.73 |  |
| Nonvested as of September 30, 2025 | 11,018,494 |  |  | $ | 3.79 |  |

[0001805385-25-000017:notes:128]
During the nine months ended September 30, 2025, the Company granted market-based stock units ("MSUs") for which the vesting conditions consist of market-based vesting conditions, determined by the Company's level of achievement of pre-established parameters relating to the performance of the Company's stock price as set by the Board as well as service-based vesting conditions. Vesting may range from 0% to 200% of the target MSUs granted, based on the

[0001805385-25-000017:notes:129]
achievement of specified market conditions. The awards will be measured at each anniversary of the grant date and will vest following the completion of a performance period, which is generally three years unless shortened in the event of a change in control.

[0001805385-25-000017:notes:130]
[same as prior period, unchanged from 0001805385-25-000009:notes:167]

[0001805385-25-000017:notes:131]
|  | Nine Months Ended September 30, |
|  | 2025 |  |  |
| Risk-free interest rate | 3.9% |  |  |
| Expected term (in years) | 3.0 |  |  |
| Expected volatility | 90.5% |  |  |
| Expected dividend yield | 0.0% |  |  |

[0001805385-25-000017:notes:132]
[same as prior period, unchanged from 0001805385-25-000009:notes:169]

[0001805385-25-000017:notes:133]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2024 | — |  |  | $ | — |  |
| Granted | 1,755,370 |  |  | 5.14 |  |
| Vested | — |  |  | — |  |
| Forfeited | (85,227) |  |  | 4.40 |  |
| Nonvested as of September 30, 2025 | 1,670,143 |  |  | $ | 5.17 |  |

[0001805385-25-000017:notes:134]
[same as prior period, unchanged from 0001805385-25-000009:notes:171]

[0001805385-25-000017:notes:135]
[same as prior period, unchanged from 0001805385-25-000009:notes:172]

[0001805385-25-000017:notes:136]
As of September 30, 2025, all 1,221,296 of the Finback Common Stock Warrants were fully exercised. Consequently, there were no remaining Finback Common Stock Warrants that were exercisable or unvested, given the expiration of the 1-year tail period on January 1, 2024. The Company recognized compensation expense for the Finback Common Stock Warrants when the warrants vested based on meeting the specified sales criteria. During the three and nine

[0001805385-25-000017:notes:137]
months ended September 30, 2025 and 2024, there was no stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants.

[0001805385-25-000017:notes:138]
[same as prior period, unchanged from 0001805385-25-000009:notes:175]

[0001805385-25-000017:notes:139]
[same as prior period, unchanged from 0001805385-25-000009:notes:176]

[0001805385-25-000017:notes:140]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cost of revenue | $ | 269 |  | $ | 244 |  | $ | 770 |  | $ | 555 |
| Research and development | 1,227 |  | 1,243 |  | 3,496 |  | 3,367 |
| Sales and marketing | 1,480 |  | 2,516 |  | 4,238 |  | 8,199 |
| General and administrative | 2,414 |  | 3,504 |  | 6,787 |  | 9,243 |
| Restructuring costs | $ | — |  | $ | — |  | $ | 525 |  | $ | — |
| Total stock-based compensation expense | $ | 5,390 |  | $ | 7,507 |  | $ | 15,816 |  | $ | 21,364 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001805385-25-000017:notes:141]
[same as prior period, unchanged from 0001805385-25-000009:notes:178]

[0001805385-25-000017:notes:142]
The Company’s tax provision and resulting effective tax rate for interim periods are determined using the estimated annual effective tax rate (“AETR”), which is updated each quarter and adjusted for discrete items recognized in the period. For the three and nine months ended September 30, 2025, the AETR reflects expected taxable income of Evolv UK, consistent with its intercompany transfer pricing policy. The forecast is consistent with year-to-date actual results through September 30, 2025, and excludes any mark-to-market adjustments. While the overall tax provision remains immaterial due to the Company's full valuation allowance, a portion of the prior-year net operating losses of Evolv UK expected to be utilized is subject to uncertainty. As a result, a corresponding unrecognized tax benefit has been included within the AETR.

[0001805385-25-000017:notes:143]
[same as prior period, unchanged from 0001805385-25-000009:notes:180]

[0001805385-25-000017:notes:144]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was signed into law in the United States. The OBBBA introduces various corporate and international tax law changes with staggered effective dates through 2027. Key provisions include immediate R&D expensing, permanent bonus depreciation, modifications to interest expense limitations, and changes to certain international tax rules. The enacted legislation did not have a material impact on the Company’s financial position, results of operations, or effective tax rate for the nine months ended September 30, 2025, primarily due to its full valuation allowance position on U.S. deferred tax assets, immaterial current tax liabilities, and insignificant foreign earnings from Evolv UK. The Company will continue to monitor and evaluate all applicable provisions of the OBBBA and any potential future impact on its consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001805385-25-000017:notes:145]
Net Loss per Share
Basic and diluted net loss per share attributable to common stockholders are calculated as follows (in thousands, except share and per share amounts):

[0001805385-25-000017:notes:146]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net loss attributable to common stockholders – basic and diluted | $ | (1,796) |  | $ | (30,443) |  | $ | (44,020) |  | $ | (38,297) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 172,790,098 |  |  | 157,709,229 |  |  | 166,327,570 |  |  | 155,760,149 |  |
| Net loss per share attributable to common stockholders – basic and diluted | $ | (0.01) |  |  | $ | (0.19) |  |  | $ | (0.26) |  |  | $ | (0.25) |  |

[0001805385-25-000017:notes:147]
The following potentially dilutive outstanding securities were excluded from the computation of diluted net loss income per share attributable to common stockholders because their effect would have been anti-dilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the period:

[0001805385-25-000017:notes:148]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Options issued and outstanding | 9,500,489 |  |  | 20,963,754 |  |  | 9,500,489 |  | 20,963,754 |  |
| Public Warrants to purchase common stock | 14,324,893 |  |  | 14,324,893 |  |  | 14,324,893 |  |  | 14,324,893 |  |
| Warrants to purchase common stock (Finback) | — |  |  | 117,423 |  |  | — |  |  | 117,423 |  |
| Unvested restricted stock units | 11,018,494 |  |  | 15,473,291 |  |  | 11,018,494 |  |  | 15,473,291 |  |
| Unvested market-based stock units* | 1,670,143 |  |  | — |  |  | 1,670,143 |  |  | — |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |
| Contingently issuable common stock* | 1,167,930 |  |  | 1,897,500 |  |  | 1,167,930 |  |  | 1,897,500 |  |
|  | 52,681,949 |  |  | 67,776,861 |  |  | 52,681,949 |  |  | 67,776,861 |  |

[0001805385-25-000017:notes:149]
[same as prior period, unchanged from 0001805385-25-000009:notes:186]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001805385-25-000017:notes:150]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. While the partnership agreement is still in effect, effective in the fourth quarter of 2024, Motorola is no longer considered a related party. During the three and nine months ended September 30, 2024, revenue from Motorola's distributor services was $2.2 million and $6.1 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001805385-25-000017:notes:151]
Commitments and Contingencies
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for

[0001805385-25-000017:notes:152]
contingencies. The Company expenses the costs related to such legal proceedings as incurred. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. Below is a summary of the various types of matters subject to this guidance.

[0001805385-25-000017:notes:153]
Indemnification Agreements

[0001805385-25-000017:notes:154]
In the ordinary course of business, the Company provides indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. Based on historical experience and evaluation of the agreements, we do not believe that any payments related to our indemnities will have a material impact on our financial condition or results of operations.

[0001805385-25-000017:notes:155]
Legal Proceedings

[0001805385-25-000017:notes:156]
We are from time to time subject to various claims, lawsuits, government and regulatory examinations, inquiries, information requests and investigations, and other legal and administrative proceedings arising in the ordinary course of business. The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

[0001805385-25-000017:notes:157]
General Litigation

[0001805385-25-000017:notes:158]
Class Action Lawsuits

[0001805385-25-000017:notes:159]
On March 25, 2024 and November 1, 2024, putative class action lawsuits were filed against the Company in the United States District Court for the District of Massachusetts. On December 13, 2024, the Court consolidated the two lawsuits into one action (the “Class Action”), pursuant to which a consolidated amended complaint was filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees. The Company filed its motion to dismiss the Class Action on March 28, 2025, and the Class Action Plaintiffs filed their opposition to the motion to dismiss on June 24, 2025. On June 30, 2025, the Court issued an order staying the Class Action, including disposition on the motion to dismiss, pending settlement negotiations. On August 5, 2025, the parties to the Class Action engaged in mediation and reached a settlement in principle in the amount of $15.0 million, which is subject to negotiation of definitive documentation and court approval, of which the Company estimated that $14.0 million would be funded by the Company's Directors and Officers insurance coverage. On August 19, 2025, the Court issued an order continuing the stay and ordering Class Action Plaintiffs to file a motion for preliminary approval of the settlement by December 15, 2025.

[0001805385-25-000017:notes:160]
As of September 30, 2025, the Company has recognized a settlement accrual of $15.0 million and an estimated insurance recovery of $14.0 million, which are included in accrued expenses and other current liabilities and prepaid and other current assets in the condensed consolidated balance sheets, respectively, representing management's best estimate of the outcome. For the three and nine months ended September 30, 2025, the Company recognized $0 and $1.0 million,

[0001805385-25-000017:notes:161]
respectively, for the estimated net loss in general and administrative expense in the condensed consolidated statements of operations and comprehensive loss.

[0001805385-25-000017:notes:162]
Derivative Lawsuits

[0001805385-25-000017:notes:163]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.

[0001805385-25-000017:notes:164]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “First Delaware Derivative Action”). The First Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. The First Delaware Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.

[0001805385-25-000017:notes:165]
On October 2, 2025, another shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Second Delaware Derivative Action”). The Second Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers and directors, NHIC directors and officers, and nominally against the Company. Plaintiff Robert Patrick, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duties, unjust enrichment, abuse of control, gross mismanagement, and waste of corporate assets, seeking various forms of relief, including equitable relief directing reform of corporate governance and internal controls, monetary damages including restitution and other fees, and a declaration that the individual defendants breached or aided and abetted breaches of fiduciary duties. On November 7, 2025, the Delaware Court of Chancery entered an order staying the Second Delaware Derivative Action pending the outcome of renewed motions to dismiss or final disposition of the Class Action.

[0001805385-25-000017:notes:166]
The Company expects to incur legal and professional services expenses associated with this litigation in future periods. The Company will recognize these expenses as services are received. We cannot reasonably estimate a range of possible losses at this time for the derivative lawsuits, as the proceedings remain in the early stages, alleged damages have not been specified, and the derivative actions are stayed. For these reasons, the Company has not recorded a loss contingency liability for the derivative lawsuits as of September 30, 2025.

[0001805385-25-000017:notes:167]
Regulatory and Governmental Matters

[0001805385-25-000017:notes:168]
As previously disclosed, on October 12, 2023, the Company announced that the U.S. Federal Trade Commission (the “FTC”) had requested information about certain aspects of its marketing practices. The Company reached a settlement with the FTC and on December 5, 2024, a Stipulated Order for Permanent Injunction and Other Relief (the “Order”) was entered in the United States District Court for the District of Massachusetts Eastern Division. The Order (i) required that the Company permit a limited cohort of school customers to cancel their contracts, (ii) required that the Company take certain compliance actions and meet record keeping obligations, and (iii) enjoined the Company from making misleading or unsubstantiated marketing claims. The Order did not include any monetary relief. The period during which eligible customers may cancel closed on March 30, 2025. Any inability to adequately comply with the terms of the Order could result in enforcement actions or penalties imposed by the FTC.

[0001805385-25-000017:notes:169]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered

[0001805385-25-000017:notes:170]
the cancellation period, and of these, 5 customers representing 24 Evolv Express systems elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the year ended December 31, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and nine months ended September 30, 2025, as revenue continued to be recognized on these deals through the cancellation dates of each contract, all of which were in June 2025, and all systems have been removed from our subscription base as of September 30, 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of the effective date of the Order were impacted by the cancellations, which has been excluded from the remaining performance obligations disclosed in Note 5 Revenue Recognition.

[0001805385-25-000017:notes:171]
As previously disclosed, in February 2024, the Company received a subpoena from the Division of Enforcement of the Securities and Exchange Commission (the “SEC”), requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation.

[0001805385-25-000017:notes:172]
As previously reported, the Company self-reported the Investigation to the Division of Enforcement of the SEC. The Company has since received requests for documents and information from the SEC relating to this matter. The Company is cooperating with this investigation. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("DOJ") relating to these same issues, and has since received additional requests for documents and information relating to this matter. By letter dated August 7, 2025, the DOJ informed the Company that the Company is no longer the subject of a DOJ investigation.

[0001805385-25-000017:notes:173]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of such matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.

[0001805385-25-000017:notes:174]
Any resolution or litigation with the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to the SEC matter. In addition to the expected insurance recovery discussed above related to the Class Action litigation, the Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matter, including certain expenses that have previously been paid, are also expected to be reimbursed. As of September 30, 2025, the Company recognized an estimated loss recovery related to insurance coverage for these matters of $1.2 million and $6.8 million for the three and nine months ended September 30, 2025, respectively, which was recorded as a reduction of general and administrative expense in the condensed consolidated statements of operations and comprehensive loss. As of September 30, 2025, $5.6 million of these recoveries have been paid out by the Company's insurance provider. The $1.2 million remaining estimated recovery is included in prepaid and other current assets in the condensed consolidated balance sheets as of September 30, 2025. This amount reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company has determined are probable of recovery. $1.0 million of recoveries were paid out in the fourth quarter to date. As it relates to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated

[0001805385-25-000017:notes:175]
insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.

[0001805385-25-000017:notes:176]
Contract manufacturers

[0001805385-25-000017:notes:177]
The Company generally contracts with its contract manufacturer, Columbia Tech, on a cancellable purchase-order basis to provide manufacturing services for the Company's equipment sold or leased to customers. While these contracts are cancellable by the Company upon prior notice, payments due upon cancellation may consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. Additionally, the recently executed agreement with the Company's new contract manufacturer, Plexus, includes provisions for which order volumes that fall short of our forecasts may result in purchase commitments. These payments are not determinable, but could result in a material purchase commitment if the Company were to cancel their open purchase orders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001805385-25-000017:notes:178]
[same as prior period, unchanged from 0001805385-25-000009:notes:209]

[0001805385-25-000017:notes:179]
[same as prior period, unchanged from 0001805385-25-000009:notes:210]

[0001805385-25-000017:notes:180]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Segment revenue | $ | 42,850 |  |  | $ | 27,360 |  |  | $ | 107,401 |  |  | $ | 74,765 |  |
| Less: |  |  |  |  |  |  |  |
| Employee expense | 18,217 |  |  | 16,222 |  |  | 50,325 |  |  | 51,882 |  |
| Travel and expense | 1,110 |  |  | 1,704 |  |  | 3,002 |  |  | 4,892 |  |
| Capitalized R&D expense | (1,165) |  |  | (1,656) |  |  | (4,015) |  |  | (4,678) |  |
| Stock-based compensation expense1 | 5,390 |  |  | 7,507 |  |  | 15,291 |  |  | 21,364 |  |
| Other non-recurring expenses2 | (30) |  |  | 3,810 |  |  | 10,343 |  |  | 7,745 |  |
| Consulting and contract staffing | 2,216 |  |  | 2,825 |  |  | 8,539 |  |  | 9,261 |  |
| Software subscriptions | 1,635 |  |  | 1,847 |  |  | 4,739 |  |  | 4,942 |  |
| Depreciation and amortization | 6,540 |  |  | 4,575 |  |  | 17,859 |  |  | 11,933 |  |
| Restructuring costs | — |  |  | — |  |  | 2,662 |  |  | 860 |  |
| Disposal of property and equipment | 1,870 |  |  | — |  |  | 3,503 |  |  | — |  |
| Other cost of revenue | 10,606 |  |  | 3,862 |  |  | 22,620 |  |  | 13,136 |  |
| Other operating expenses | 5,057 |  |  | 5,816 |  |  | 13,011 |  |  | 16,857 |  |
| Other segment items3 | (6,800) |  |  | 11,291 |  |  | 3,542 |  |  | (25,132) |  |
| Segment net (loss) income | $ | (1,796) |  |  | $ | (30,443) |  |  | $ | (44,020) |  |  | $ | (38,297) |  |

[0001805385-25-000017:notes:181]
[same as prior period, unchanged from 0001805385-25-000009:notes:212]

[0001805385-25-000017:notes:182]
2 For the three and nine months ended September 30, 2025, includes consulting and legal fees related to the Investigation and related matters, additional audit fees incurred in connection with the restatement of prior period financial statements, net of estimated insurance recoveries, as well as estimated net losses related to ongoing legal matters. For the three and nine months ended September 30, 2024, includes costs associated with adverse non-cancellable inventory purchase commitments, inventory reserve associated with the transition of our manufacturing operations to the next generation of Evolv Express systems and the determination that certain components within our legacy systems will not be used in the next generation systems, and severance expense.

[0001805385-25-000017:notes:183]
3 Refer to Total other income (expense), net and provision for income taxes in the condensed consolidated statements of operations and comprehensive loss.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001805385-25-000017:notes:184]
[same as prior period, unchanged from 0001805385-25-000009:notes:215]

[0001805385-25-000017:notes:185]
[same as prior period, unchanged from 0001805385-25-000009:notes:216]

[0001805385-25-000017:notes:186]
[same as prior period, unchanged from 0001805385-25-000009:notes:217]

[0001805385-25-000017:notes:187]
To align the presentation of restructuring charges, the Company reclassified the comparative financial statements for the nine months ended September 30, 2024. There were no reclassifications for the three months ended September 30, 2024. For the nine months ended September 30, 2024, the reclassifications resulted in an increase in restructuring costs of $0.9 million, and a corresponding decrease in cost of service revenue, sales and marketing expenses, and general and administrative expenses of $0.2 million, $0.7 million, and less than $0.1 million, respectively. The prior year activity was limited in scope, and the reclassifications did not impact total loss from operations or total net income (loss). All actions related to the prior year reduction in force were completed by September 30, 2024.

[0001805385-25-000017:notes:188]
[same as prior period, unchanged from 0001805385-25-000009:notes:219]

[0001805385-25-000017:notes:189]
| Balance at December 31, 2023 | $ | — |  |
| Charges incurred | 860 |  |
| Cash payments | (860) |  |
| Balance at December 31, 2024 | — |  |
| Charges incurred | 2,137 |  |
| Cash payments | (2,069) |  |
| Balance at September 30, 2025 | $ | 68 |  |
