# EVLV 10-Q controls and the auditor's report


## item_4_controls

[0001805385-25-000017:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001805385-25-000017:item_4_controls:2]
Limitations on effectiveness of controls and procedures

[0001805385-25-000017:item_4_controls:3]
We maintain disclosure controls and procedures (as that term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) that are designed to provide reasonable assurance that information required to be disclosed in the reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms, and that such information is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate, to allow timely decisions regarding required disclosures. In designing and evaluating our disclosure controls and procedures, management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply judgment in evaluating the benefits of our controls and procedures relative to their costs.

[0001805385-25-000017:item_4_controls:4]
Evaluation of disclosure controls and procedures

[0001805385-25-000017:item_4_controls:5]
Our management, with the participation of our principal executive officer and principal financial officer, evaluated, as of the end of the period covered by this Quarterly Report on Form 10-Q, the effectiveness of our disclosure controls and procedures (as that term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act). Based on that evaluation, our principal executive officer and principal financial officer concluded that our disclosure controls and

[0001805385-25-000017:item_4_controls:6]
procedures were not effective as of September 30, 2025, due to the material weaknesses in our internal control over financial reporting as described below.

[0001805385-25-000017:item_4_controls:7]
Material weaknesses in internal control over financial reporting

[0001805385-25-000017:item_4_controls:8]
We identified material weaknesses in our internal control over financial reporting. A material weakness is a deficiency, or combination of deficiencies, in internal control over financial reporting, such that there is reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. The material weaknesses are as follows:

[0001805385-25-000017:item_4_controls:9]
•We did not design and maintain an effective control environment as we did not demonstrate a commitment to maintaining integrity and ethical values. Specifically, we did not sufficiently promote, monitor or enforce appropriate accounting policies and procedures, thereby resulting in inappropriate recognition of revenue due to the failure to consider the impact of certain extra-contractual terms and conditions in sales agreements on the amount and timing of revenue to be recognized;

[0001805385-25-000017:item_4_controls:10]
•Additionally, we lacked a sufficient complement of personnel with an appropriate level of internal controls and accounting knowledge, training and experience commensurate with our financial reporting requirements. The limited personnel resulted in our inability to consistently establish appropriate authorities and responsibilities in pursuit of our financial reporting objectives, as demonstrated by, among other things, insufficient segregation of duties in our finance and accounting functions;

[0001805385-25-000017:item_4_controls:11]
•We did not design and maintain effective controls in response to the risks of material misstatement as changes to existing controls or the implementation of new controls were not sufficient to respond to changes to the risks of material misstatement to financial reporting;

[0001805385-25-000017:item_4_controls:12]
•We did not design and maintain effective controls for communicating and sharing information between the sales, accounting and finance departments. Specifically, the accounting and finance departments were not consistently provided the complete and adequate support, documentation, and information including the nature of relationships with certain customers to record revenue transactions within the financial statements timely, completely and accurately. Additionally, there have been instances in which indications of extra-contractual terms and conditions in sales arrangements were not disclosed to the Audit Committee of the Board and the external auditors;

[0001805385-25-000017:item_4_controls:13]
•We did not design and maintain effective controls over the period-end financial reporting process to achieve complete, accurate, and timely financial accounting, reporting and disclosures, including the classification of various accounts in the financial statements and the presentation and disclosure of items in the consolidated statements of cash flows;

[0001805385-25-000017:item_4_controls:14]
•We did not design and maintain effective controls to analyze, account for and disclose non-routine, unusual or complex transactions. Specifically, we did not design and maintain controls to timely analyze and account for debt modifications and extinguishments, convertible notes, warrant instruments, non-routine complex revenue transactions including the leasing of products and transfer of inventory for leased assets into property plant and equipment, merger transactions, and the accounting and valuation of earn out liabilities; and

[0001805385-25-000017:item_4_controls:15]
•We did not design and maintain formal accounting policies, procedures, and controls to achieve complete, accurate, and timely financial accounting, reporting and disclosures, including controls over the preparation and review of account reconciliations and journal entries, and control activities related to all significant accounts and disclosures.

[0001805385-25-000017:item_4_controls:16]
The material weaknesses in the control environment, including the lack of a sufficient complement of personnel, risk assessment, and information and communication components of internal control, as well as the material weakness related to revenue control activities resulted in the restatement of the consolidated financial statements for the annual periods ended December 31, 2022 and 2023, and the quarterly periods included in such fiscal years beginning with the second quarter of 2022, and for the quarterly periods as of and for the periods ended March 31, 2024 and June 30, 2024; as well as adjustments to the consolidated annual financial statements for the year ended December 31, 2024, and the consolidated financial statements for the quarterly period ended September 30, 2024, that were recorded prior to the issuance of those financial statements.

[0001805385-25-000017:item_4_controls:17]
The material weaknesses related to the lack of sufficient complement of personnel with an appropriate level of internal controls and accounting knowledge, training and experience, risk assessment, lack of effective controls over the period-end financial reporting process, lack of effective controls related to non-routine, unusual or complex transactions, and the lack of effective control activities related to all significant accounts and disclosures resulted in:

[0001805385-25-000017:item_4_controls:18]
•the restatement of the Company’s financial statements as of and for the three and six months ended June 30, 2023;

[0001805385-25-000017:item_4_controls:19]
•the revision of the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022; and

[0001805385-25-000017:item_4_controls:20]
•adjustments and certain immaterial misstatements in the consolidated financial statements to prepaid and other current assets, accounts payable and accrued liabilities, long-term and short-term debt, convertible notes, contingent earn-out liabilities, change in fair value of contingent earn-out liability, equity, commission assets, contract assets, revenue, deferred revenue, accounts receivable, inventory, property plant and equipment, cost of sales, and various expense line items and related financial statement disclosures as of and for the years ended December 31, 2019, 2020, 2021, 2022, 2023, and 2024; as well as certain quarterly periods within those years and the three and nine months ended September 30, 2024.

[0001805385-25-000017:item_4_controls:21]
Additionally, the material weaknesses could result in a misstatement of the consolidated financial statements and disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0001805385-25-000017:item_4_controls:22]
•In addition to the foregoing, we did not design and maintain effective controls over information technology (“IT”) general controls for information systems that are relevant to the preparation of our consolidated financial statements, specifically, with respect to: (i) program change management controls for financial systems to ensure that IT program and data changes affecting financial IT applications and underlying accounting records are identified, tested, authorized, and implemented appropriately; (ii) user access controls to ensure appropriate segregation of duties and that adequately restrict user and privileged access to financial applications, programs, and data to appropriate company personnel; (iii) computer operations controls to ensure that critical batch jobs are monitored and data backups are authorized and monitored; and (iv) testing and approval controls for program development to ensure that new software development is aligned with business and IT requirements. These IT deficiencies did not result in a misstatement to the consolidated financial statements; however, the deficiencies, when aggregated, could impact maintaining effective segregation of duties, as well as the effectiveness of IT-dependent controls (such as automated controls that address the risk of material misstatement to one or more assertions, along with the IT controls and underlying data that support the effectiveness of system-generated data and reports) that could result in misstatements potentially impacting all financial statement accounts and disclosures that would not be prevented or detected. Accordingly, management has determined these deficiencies in the aggregate constitute a material weakness.

[0001805385-25-000017:item_4_controls:23]
Remediation Plan for the Material Weaknesses

[0001805385-25-000017:item_4_controls:24]
We continue to be focused on designing and implementing effective internal controls to improve our internal control over financial reporting and remediate the material weaknesses. Actions taken to date include:

[0001805385-25-000017:item_4_controls:25]
•We have implemented a new channel partner program intended to strengthen compliance with contractual terms and conditions, as well as to enhance controls over related communication and sharing of information with the accounting and finance departments;

[0001805385-25-000017:item_4_controls:26]
•We have reviewed and updated our Audit Committee and Compliance Committee Charters to ensure enhanced risk oversight and adherence to our ethical values;

[0001805385-25-000017:item_4_controls:27]
•We have hired additional accounting personnel to bolster our reporting, technical accounting, and internal control capabilities, and will continue to monitor and evaluate our personnel requirements based on future company growth and our ability to successfully achieve our objectives. Additionally, we are in the process of designing and implementing controls to formalize roles and review responsibilities to align with our team’s skills and experience and designing and implementing controls over segregation of duties;

[0001805385-25-000017:item_4_controls:28]
•We have enhanced the competencies of our accounting function including the hiring of a new Chief Accounting Officer (“CAO”) in January 2025. Our CAO has extensive public company experience and will strengthen our internal accounting team by providing technical accounting oversight over our financial reporting and disclosure processes and controls. Additionally, we hired a new Chief Revenue Officer in February 2025 to provide leadership and accountability over our sales agreement and revenue recognition accounting processes;

[0001805385-25-000017:item_4_controls:29]
•We have launched additional trainings to the Finance and Sales teams around the responsibility of preventing financial misconduct and commitment to maintaining integrity and ethical values. We also launched a company-wide communication campaign and training regarding our Speak Up policy. We launched a new Code of Business Conduct and Ethics with additional company-wide trainings related to the same to promote an ethical culture, further educate employees on Company policies and align with public company standards;

[0001805385-25-000017:item_4_controls:30]
•We have designed and implemented additional review and training procedures within Evolv's accounting and finance functions to enhance knowledge and understanding of internal control over financial reporting;

[0001805385-25-000017:item_4_controls:31]
•We have performed, and will continue to perform, a financial statement risk assessment in order to identify material financial statement line items for which key controls are needed in order to ensure complete and accurate financial reporting.

[0001805385-25-000017:item_4_controls:32]
•In January 2025, we engaged a large national advisory firm to assist in the design and implementation of control activities and to strengthen the skills of personnel involved in the business processes supporting the Company’s significant accounts and disclosures. As of September 2025, walkthroughs and operating effectiveness testing have commenced for all processes within IT and Finance walkthroughs are underway as well.

[0001805385-25-000017:item_4_controls:33]
In addition to the remedial actions taken to date, our ongoing efforts include:

[0001805385-25-000017:item_4_controls:34]
•Our new leadership team, together with other senior executives, is committed to achieving and maintaining a strong control environment, high ethical standards, and financial reporting integrity. This commitment has been and will continue to be communicated to and reinforced with Evolv employees and external stakeholders;

[0001805385-25-000017:item_4_controls:35]
•The development and communication of a framework that will serve as a set of guiding principles emphasizing our commitment to accounting and financial reporting integrity as well as transparency and robust and complete communications with, and disclosures to, the Board of Directors and external auditors;

[0001805385-25-000017:item_4_controls:36]
•We continue to reinforce the importance of communication between the sales, accounting and finance departments regarding key terms of, and changes or modifications to, sales transactions, including by establishing controls requiring finance department approval of certain non-standard terms;

[0001805385-25-000017:item_4_controls:37]
•We are designing a new deal review policy and process, including enhanced certification by the Sales team of terms and conditions, to ensure proper communication to the accounting and finance departments to allow for an effective review of the accounting for the transactions;

[0001805385-25-000017:item_4_controls:38]
•Over the past year, we implemented controls related to, among other items, (i) the period-end financial reporting process and classification of various accounts in our consolidated financial statements, including the presentation and disclosure of items in the consolidated statements of cash flows, (ii) timely identification and accounting for non-routine, unusual and complex transactions, including controls over the preparation and review of accounting memoranda addressing these matters, (iii) revenue recognition, including non-routine complex revenue transactions that may also include the leasing of products and the recording of revenue transactions in the appropriate period, (iv) completeness and accuracy of accounts payable and accrued liabilities, and (v) completeness, accuracy, valuation, and classification of cash equivalents and marketable securities. We are in the process of designing and implementing controls over the preparation and review of journal entries and account reconciliations to ensure proper segregation of duties;

[0001805385-25-000017:item_4_controls:39]
•We are in the process of creating and maintaining formal accounting policies, procedures and controls to achieve complete, accurate and timely financial accounting, reporting and disclosures;

[0001805385-25-000017:item_4_controls:40]
•We are in the process of designing and implementing information technology general controls for all relevant information systems, including controls over program change management, the review, approval and update of user access rights and privileges, controls over batch jobs and data backups, and program development approvals and testing for new systems. During the quarter ended September 30, 2025, we have enhanced the control design and began testing operating effectiveness. The management evaluation of operating effectiveness is ongoing;

[0001805385-25-000017:item_4_controls:41]
•We have, and continue to make investments in our technology platforms including enhancing our financial and human resources systems to further automate processes and reduce the risk of manual errors; and

[0001805385-25-000017:item_4_controls:42]
•We are continuing to assess the need for new systems for which IT general controls will be designed and implemented.

[0001805385-25-000017:item_4_controls:43]
The process of designing and maintaining effective internal control over financial reporting is a continuous effort that requires management to anticipate and react to changes in our business, economic, and regulatory environments and to expend significant resources. As we continue to evaluate our internal control over financial reporting, we may take additional actions to remediate the material weaknesses or modify the remediation actions described above.

[0001805385-25-000017:item_4_controls:44]
While we continue to devote significant time and attention to these remediation efforts, the material weaknesses will not be considered remediated until management completes the design and implementation of the actions described above and the controls operate for a sufficient period of time, and management has concluded, through testing, that these controls are effective.

[0001805385-25-000017:item_4_controls:45]
Changes in Internal Control over Financial Reporting

[0001805385-25-000017:item_4_controls:46]
Other than the remediation measures with respect to the material weaknesses described above, there were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended September 30, 2025 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
