# EVLV MD&A — 0001805385-25-000017


## mdna

[0001805385-25-000017:mdna:1]
[same as prior period, unchanged from 0001805385-25-000009:mdna:1]

[0001805385-25-000017:mdna:2]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of our business combination (the “Merger”) and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. References to “Investigations” refer to the investigation commenced in September 2024 by an ad hoc committee of independent directors of our Board of Directors into our sales practices, as previously disclosed in prior filings.

[0001805385-25-000017:mdna:3]
[same as prior period, unchanged from 0001805385-25-000009:mdna:5]

[0001805385-25-000017:mdna:4]
[same as prior period, unchanged from 0001805385-25-000009:mdna:6]

[0001805385-25-000017:mdna:5]
Our solutions combine proprietary software and hardware, delivered as a long-term Security-as-a-Service (“SaaS”) subscription model, and are designed to enhance security and improve the visitor experience. Evolv provides a cloud-connected, AI-driven approach to security that goes beyond just hardware, supporting the end-to-end screening experience. Our focus is weapons detection, and we offer two core solutions: Evolv Express® and Evolv eXpedite™, designed to efficiently screen high volumes of people and bags for concealed threats.

[0001805385-25-000017:mdna:6]
[same as prior period, unchanged from 0001805385-25-000009:mdna:8]

[0001805385-25-000017:mdna:7]
Our innovative technology is designed to enhance security and provide an efficient, positive visitor and customer security experience. In addition to screening capabilities, our solution includes Evolv Insights®, a powerful software analytics dashboard that allows customers to comprehensively review, analyze, and gather insights from the Evolv Express screening systems at their various venues or facility locations.  Available data includes visitor arrival patterns, throughput volumes, system detection performance, alarm statistics, weapons detected and detection settings.  Our customers can leverage this data to inform their security operations, while providing end-users with an approachable security experience. Our products, which are offered to our customers primarily under a multi-year subscription model, provide predictable revenue streams for us in addition to value for our customers.

[0001805385-25-000017:mdna:8]
[same as prior period, unchanged from 0001805385-25-000009:mdna:12]

[0001805385-25-000017:mdna:9]
[same as prior period, unchanged from 0001805385-25-000009:mdna:10]

[0001805385-25-000017:mdna:10]
[same as prior period, unchanged from 0001805385-25-000009:mdna:13]

[0001805385-25-000017:mdna:11]
[same as prior period, unchanged from 0001805385-25-000009:mdna:14]

[0001805385-25-000017:mdna:12]
Supply Chain Strategy

[0001805385-25-000017:mdna:13]
On November 5, 2025, we entered into a non-exclusive contract manufacturing agreement with Plexus Corp. (“Plexus”). This shift is part of a broader supply chain strategy aimed at enhancing scalability, geographic diversification, creating long-term cost-saving opportunities, and operational resiliency. As Plexus is brought onboard, we believe we maintain ample inventory and committed production capacity to meet our growth targets with our existing contract manufacturer, ensuring uninterrupted service and consistent delivery to customers.

[0001805385-25-000017:mdna:14]
We regularly evaluate our supply chain structure to mitigate risks, including dependencies, lead times, and cost fluctuations. While no material disruptions are anticipated during the onboarding of Plexus, we continue to monitor potential risks associated with onboarding, logistics, and supplier performance. These factors may influence cost of revenue, inventory levels, and working capital in future periods.

[0001805385-25-000017:mdna:15]
[same as prior period, unchanged from 0001805385-25-000009:mdna:15]

[0001805385-25-000017:mdna:16]
[same as prior period, unchanged from 0001805385-25-000009:mdna:16]

[0001805385-25-000017:mdna:17]
[same as prior period, unchanged from 0001805385-25-000009:mdna:17]

[0001805385-25-000017:mdna:18]
[same as prior period, unchanged from 0001805385-25-000009:mdna:18]

[0001805385-25-000017:mdna:19]
[same as prior period, unchanged from 0001805385-25-000009:mdna:19]

[0001805385-25-000017:mdna:20]
We sell our solutions under two primary sales models. We offer a “pure subscription” model, where the customer leases hardware from us and we provide a multi-year security-as-a-service subscription. For end-user customers that prefer to purchase our hardware outright, we offer customers the option of purchasing our hardware outright directly from us through our “purchase subscription” model. In addition to our two primary sales models, we have historically offered our “distributor licensing” model based on the Distribution and License Agreement we entered into with Columbia Tech in March of 2023. Under this arrangement, we have granted a license of our intellectual property to Columbia Tech, which contracts directly with certain of our resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment. Columbia Tech pays us a hardware license fee for each system it manufactures and sells under this agreement. In these instances, we still contract directly with the reseller to provide a multi-year security-as-a-service subscription to the end-users. During the three months ended September 30, 2025, we discontinued quoting on this basis, and while any outstanding quotes will be honored, all new quotes for end-user customers wishing to purchase the hardware equipment will be fulfilled through our purchase subscription model going forward. Thus, license revenue from this agreement is expected to reduce to zero over time, replaced by increased product revenue, which will in turn provide an increase in gross profit and a decrease in gross margin percentage. We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our

[0001805385-25-000017:mdna:21]
revenue, gross profit, gross margin, and overall profitability in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments.

[0001805385-25-000017:mdna:22]
[same as prior period, unchanged from 0001805385-25-000009:mdna:21]

[0001805385-25-000017:mdna:23]
[same as prior period, unchanged from 0001805385-25-000009:mdna:22]

[0001805385-25-000017:mdna:24]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $107.4 million and $74.8 million for the nine months ended September 30, 2025 and 2024, respectively. We generated a net loss of $44.0 million and $38.3 million for the nine months ended September 30, 2025 and 2024, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001805385-25-000017:mdna:25]
[same as prior period, unchanged from 0001805385-25-000009:mdna:24]

[0001805385-25-000017:mdna:26]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations and our Senior Secured Credit Facilities. See “Liquidity and Capital Resources” as well as “Risks Related to Our Financial Condition and Liquidity” for more information. Additionally, as discussed in Note 14, Commitments and Contingencies, to our condensed consolidated financial statements for the three and nine months ended September 30, 2025, we are involved in certain legal proceedings, including a government investigation. Given the uncertainty of such matters, no assurance can be given regarding the final outcome of such matters. However, the ultimate amount or range of potential loss, which might result to the Company, may differ materially from our current estimates.

[0001805385-25-000017:mdna:27]
As described under Supply Chain Strategy section, we entered into a non-exclusive contract manufacturing agreement with Plexus, which is expected to enhance manufacturing scalability and operational efficiency. While the onboarding may temporarily affect working capital due to dual production activities and other onboarding costs, the Company does not anticipate a material impact on overall liquidity in the near term. Once fully operational, we expect improved inventory efficiency and commercial terms. The Company continues to monitor cash flows and capital requirements associated with the transition to ensure sufficient resources are available to support ongoing operations and strategic initiatives.

[0001805385-25-000017:mdna:28]
[same as prior period, unchanged from 0001805385-25-000009:mdna:26]

[0001805385-25-000017:mdna:29]
[same as prior period, unchanged from 0001805385-25-000009:mdna:27]

[0001805385-25-000017:mdna:30]
[same as prior period, unchanged from 0001805385-25-000009:mdna:28]

[0001805385-25-000017:mdna:31]
[same as prior period, unchanged from 0001805385-25-000009:mdna:29]

[0001805385-25-000017:mdna:32]
We derive a portion of our revenue from the sale of our Evolv Express and eXpedite equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We anticipate future growth in product revenue as more customers purchase systems through our purchase subscription model.

[0001805385-25-000017:mdna:33]
[same as prior period, unchanged from 0001805385-25-000009:mdna:31]

[0001805385-25-000017:mdna:34]
Subscription revenue consists of revenue derived from leasing Evolv Express and eXpedite systems to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001805385-25-000017:mdna:35]
[same as prior period, unchanged from 0001805385-25-000009:mdna:35]

[0001805385-25-000017:mdna:36]
[same as prior period, unchanged from 0001805385-25-000009:mdna:36]

[0001805385-25-000017:mdna:37]
[same as prior period, unchanged from 0001805385-25-000009:mdna:37]

[0001805385-25-000017:mdna:38]
[same as prior period, unchanged from 0001805385-25-000009:mdna:38]

[0001805385-25-000017:mdna:39]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from Columbia Tech to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration. Revenue for professional services and other one-time revenue, which had previously been included in service revenue, has been reclassified for prior periods to License fee and other revenue on the condensed consolidated statements of operations and comprehensive loss. During the three months ended September 30, 2025, we discontinued quoting under the Distribution and License Agreement, and while any outstanding quotes will be honored, all new quotes for end-user customers wishing to purchase the hardware equipment will be fulfilled through our purchase subscription model going forward. Thus, license revenue from this agreement is expected to reduce to zero over time, replaced by increased product revenue.

[0001805385-25-000017:mdna:40]
[same as prior period, unchanged from 0001805385-25-000009:mdna:40]

[0001805385-25-000017:mdna:41]
[same as prior period, unchanged from 0001805385-25-000009:mdna:41]

[0001805385-25-000017:mdna:42]
[same as prior period, unchanged from 0001805385-25-000009:mdna:42]

[0001805385-25-000017:mdna:43]
[same as prior period, unchanged from 0001805385-25-000009:mdna:43]

[0001805385-25-000017:mdna:44]
[same as prior period, unchanged from 0001805385-25-000009:mdna:44]

[0001805385-25-000017:mdna:45]
[same as prior period, unchanged from 0001805385-25-000009:mdna:45]

[0001805385-25-000017:mdna:46]
4

[0001805385-25-000017:mdna:47]
[same as prior period, unchanged from 0001805385-25-000009:mdna:46]

[0001805385-25-000017:mdna:48]
[same as prior period, unchanged from 0001805385-25-000009:mdna:47]

[0001805385-25-000017:mdna:49]
[same as prior period, unchanged from 0001805385-25-000009:mdna:48]

[0001805385-25-000017:mdna:50]
[same as prior period, unchanged from 0001805385-25-000009:mdna:49]

[0001805385-25-000017:mdna:51]
[same as prior period, unchanged from 0001805385-25-000009:mdna:50]

[0001805385-25-000017:mdna:52]
[same as prior period, unchanged from 0001805385-25-000009:mdna:51]

[0001805385-25-000017:mdna:53]
[same as prior period, unchanged from 0001805385-25-000009:mdna:52]

[0001805385-25-000017:mdna:54]
[same as prior period, unchanged from 0001805385-25-000009:mdna:53]

[0001805385-25-000017:mdna:55]
[same as prior period, unchanged from 0001805385-25-000009:mdna:54]

[0001805385-25-000017:mdna:56]
[same as prior period, unchanged from 0001805385-25-000009:mdna:55]

[0001805385-25-000017:mdna:57]
[same as prior period, unchanged from 0001805385-25-000009:mdna:56]

[0001805385-25-000017:mdna:58]
[same as prior period, unchanged from 0001805385-25-000009:mdna:57]

[0001805385-25-000017:mdna:59]
[same as prior period, unchanged from 0001805385-25-000009:mdna:58]

[0001805385-25-000017:mdna:60]
We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our gross profit and gross margin in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments.

[0001805385-25-000017:mdna:61]
[same as prior period, unchanged from 0001805385-25-000009:mdna:60]

[0001805385-25-000017:mdna:62]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, stock-based compensation, prototypes, design expenses, and consulting and contractor costs. We expect our research and development costs to decrease for the year ending December 31, 2025 compared to the year ended December 31, 2024 as a result of certain cost cutting measures we have taken, including the reduction in force implemented in January 2025, as well as decrease in consulting costs related to the second generation of our Evolv Express systems that were launched in prior year.

[0001805385-25-000017:mdna:63]
[same as prior period, unchanged from 0001805385-25-000009:mdna:62]

[0001805385-25-000017:mdna:64]
[same as prior period, unchanged from 0001805385-25-000009:mdna:63]

[0001805385-25-000017:mdna:65]
[same as prior period, unchanged from 0001805385-25-000009:mdna:66]

[0001805385-25-000017:mdna:66]
[same as prior period, unchanged from 0001805385-25-000009:mdna:64]

[0001805385-25-000017:mdna:67]
General and administrative expenses consist primarily of personnel related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and insurance, net of any probable and reasonably estimable insurance recoveries or received insurance recoveries. During the year ended 2024, we experienced a significant increase in general and administrative expenses, primarily for legal fees and consulting expenses, as a result of the Investigation and related actions. This increased level of expenses continued through the second quarter of 2025 and has reduced in the third quarter of 2025. We expect our general and administrative expenses to remain at this lower level in the fourth quarter of 2025.

[0001805385-25-000017:mdna:68]
[same as prior period, unchanged from 0001805385-25-000009:mdna:67]

[0001805385-25-000017:mdna:69]
[same as prior period, unchanged from 0001805385-25-000009:mdna:68]

[0001805385-25-000017:mdna:70]
[same as prior period, unchanged from 0001805385-25-000009:mdna:69]

[0001805385-25-000017:mdna:71]
[same as prior period, unchanged from 0001805385-25-000009:mdna:70]

[0001805385-25-000017:mdna:72]
[same as prior period, unchanged from 0001805385-25-000009:mdna:71]

[0001805385-25-000017:mdna:73]
[same as prior period, unchanged from 0001805385-25-000009:mdna:72]

[0001805385-25-000017:mdna:74]
[same as prior period, unchanged from 0001805385-25-000009:mdna:73]

[0001805385-25-000017:mdna:75]
[same as prior period, unchanged from 0001805385-25-000009:mdna:74]

[0001805385-25-000017:mdna:76]
[same as prior period, unchanged from 0001805385-25-000009:mdna:75]

[0001805385-25-000017:mdna:77]
Change in Fair Value of Contingently Issuable Common Stock Liability and Contingently Returnable Common Stock Asset

[0001805385-25-000017:mdna:78]
[same as prior period, unchanged from 0001805385-25-000009:mdna:77]

[0001805385-25-000017:mdna:79]
Under the Founder Shares arrangement, Founder Shares may be transferred to third parties, subject to certain conditions. The unvested shares must be returned to the Company if the specified vesting conditions are not met. As of September 30, 2025, a total of 729,570 unvested shares had been transferred to individual brokerage accounts, resulting in a reduction to the contingently issuable common stock liability and recognition of the value of the shares as outstanding equity. The contractual obligation of the holders to return the transferred shares upon failure to meet vesting conditions is accounted for as a freestanding financial asset. This asset is initially recognized at fair value and remeasured at each

[0001805385-25-000017:mdna:80]
6

[0001805385-25-000017:mdna:81]
reporting date with changes in fair value recorded as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss.

[0001805385-25-000017:mdna:82]
[same as prior period, unchanged from 0001805385-25-000009:mdna:78]

[0001805385-25-000017:mdna:83]
[same as prior period, unchanged from 0001805385-25-000009:mdna:79]

[0001805385-25-000017:mdna:84]
[same as prior period, unchanged from 0001805385-25-000009:mdna:80]

[0001805385-25-000017:mdna:85]
[same as prior period, unchanged from 0001805385-25-000009:mdna:81]

[0001805385-25-000017:mdna:86]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was signed into law in the United States. The OBBBA introduces various corporate and international tax law changes with staggered effective dates through 2027. Key provisions include immediate R&D expensing, permanent bonus depreciation, modifications to interest expense limitations, and changes to certain international tax rules. The enacted legislation did not have a material impact on our financial position, results of operations, or effective tax rate for the nine months ended September 30, 2025, primarily due to our full valuation allowance position on U.S. deferred tax assets, immaterial current tax liabilities, and insignificant foreign earnings from Evolv UK. We will continue to monitor and evaluate all applicable provisions of the OBBBA and any potential future impact on our consolidated financial statements.

[0001805385-25-000017:mdna:87]
[same as prior period, unchanged from 0001805385-25-000009:mdna:84]

[0001805385-25-000017:mdna:88]
[same as prior period, unchanged from 0001805385-25-000009:mdna:85]

[0001805385-25-000017:mdna:89]
[same as prior period, unchanged from 0001805385-25-000009:mdna:87]

[0001805385-25-000017:mdna:90]
Comparison of the Three Months Ended September 30, 2025 and 2024

[0001805385-25-000017:mdna:91]
The following table summarizes our results of operations for the three months ended September 30, 2025 and 2024 (in thousands):

[0001805385-25-000017:mdna:92]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 9,242 |  |  | $ | 1,344 |  |  | $ | 7,898 |  |  | 588 | % |
| Subscription revenue | 22,685 |  |  | 17,909 |  |  | 4,776 |  |  | 27 |  |
| Service revenue | 7,808 |  |  | 6,085 |  |  | 1,723 |  |  | 28 |  |
| License fee and other revenue | 3,115 |  |  | 2,022 |  |  | 1,093 |  |  | 54 |  |
| Total revenue | 42,850 |  |  | 27,360 |  |  | 15,490 |  |  | 57 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 7,960 |  |  | 2,616 |  |  | 5,344 |  |  | 204 |  |
| Cost of subscription revenue | 10,923 |  |  | 7,348 |  |  | 3,575 |  |  | 49 |  |
| Cost of service revenue | 2,338 |  |  | 1,404 |  |  | 934 |  |  | 67 |  |
| Cost of license fee and other revenue | 323 |  |  | 183 |  |  | 140 |  |  | 77 |  |
| Total cost of revenue | 21,544 |  |  | 11,551 |  |  | 9,993 |  |  | 87 |  |
| Gross profit | 21,306 |  |  | 15,809 |  |  | 5,497 |  |  | 35 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,608 |  |  | 5,810 |  |  | (202) |  |  | (3) |  |
| Sales and marketing | 11,715 |  |  | 14,966 |  |  | (3,251) |  |  | (22) |  |
| General and administrative | 12,579 |  |  | 13,976 |  |  | (1,397) |  |  | (10) |  |
| Loss from impairment of property and equipment | — |  |  | 209 |  |  | (209) |  |  | (100) |  |
| Total operating expenses | 29,902 |  |  | 34,961 |  |  | (5,059) |  |  | (14) |  |
| Loss from operations | (8,596) |  |  | (19,152) |  |  | 10,556 |  |  | 55 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (713) |  |  | — |  |  | (713) |  |  | * |
| Interest income | 436 |  |  | 628 |  |  | (192) |  |  | (31) |  |
| Other (expense) income, net | (44) |  |  | 34 |  |  | (78) |  |  | (229) |  |
| Change in fair value of contingent earn-out liability | 7,521 |  |  | (8,321) |  |  | 15,842 |  |  | 190 |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | 2,178 |  |  | (2,056) |  |  | 4,234 |  |  | 206 |  |
| Change in fair value of public warrant liability | (2,578) |  |  | (1,576) |  |  | (1,002) |  |  | (64) |  |
| Total other income (expense), net | 6,800 |  |  | (11,291) |  |  | 18,091 |  |  | 160 |  |
| Net loss | $ | (1,796) |  |  | $ | (30,443) |  |  | $ | 28,647 |  |  | 94 | % |

[0001805385-25-000017:mdna:93]
8

[0001805385-25-000017:mdna:94]
[same as prior period, unchanged from 0001805385-25-000009:mdna:91]

[0001805385-25-000017:mdna:95]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 62 new customers during the three months ended September 30, 2025, and (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations as well as expanding their fleet with our Evolv eXpedite offering.

[0001805385-25-000017:mdna:96]
[same as prior period, unchanged from 0001805385-25-000009:mdna:93]

[0001805385-25-000017:mdna:97]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Product revenue | $ | 9,242 |  |  | $ | 1,344 |  |  | $ | 7,898 |  |  | 588 | % |
| Cost of product revenue | $ | 7,960 |  |  | $ | 2,616 |  |  | $ | 5,344 |  |  | 204 | % |
| Gross profit (loss) - Product revenue | $ | 1,282 |  |  | $ | (1,272) |  |  | $ | 2,554 |  |  | 201 | % |
| Gross profit margin - Product revenue | 14 | % |  | (95) | % |  | N/A |  | 109 | % |

[0001805385-25-000017:mdna:98]
The increases in product revenue and cost of product revenue for the three months ended September 30, 2025 compared to the prior year period are primarily due to an increased utilization of our purchase subscription model, in which customers purchase Evolv Express and Evolv eXpedite systems directly from us instead of through our distributor licensing model. The increase in product gross profit margin was due to an expense related to our inventory reserve of $1.5 million recognized in the three months ended September 30, 2024, which related primarily to the transition of our manufacturing operations to the next generation of Evolv Express systems and the determination that certain components within our legacy systems will not be used in the next generation systems, partially offset by the initial deployments of our Evolv eXpedite systems, which as a new product offering reflect a higher initial cost to produce that we expect to gradually decline in the future.

[0001805385-25-000017:mdna:99]
[same as prior period, unchanged from 0001805385-25-000009:mdna:96]

[0001805385-25-000017:mdna:100]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Subscription revenue | $ | 22,685 |  |  | $ | 17,909 |  |  | $ | 4,776 |  |  | 27 | % |
| Cost of subscription revenue | $ | 10,923 |  |  | $ | 7,348 |  |  | $ | 3,575 |  |  | 49 | % |
| Gross profit - Subscription revenue | $ | 11,762 |  |  | $ | 10,561 |  |  | $ | 1,201 |  |  | 11 | % |
| Gross profit margin - Subscription revenue | 52 | % |  | 59 | % |  | N/A |  | (7) | % |

[0001805385-25-000017:mdna:101]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to continued growth in our customer base as of September 30, 2025 compared to the prior year, with a higher number of active Evolv Express systems deployed under our pure subscription model and an increase in short term rental subscription revenue during the three months ended September 30, 2025. The decrease in subscription gross profit margin was due to a $1.9 million loss on disposal of leased equipment and a $0.6 million estimated field services cost related to the replacement of certain Express system parts.

[0001805385-25-000017:mdna:102]
[same as prior period, unchanged from 0001805385-25-000009:mdna:100]

[0001805385-25-000017:mdna:103]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Service revenue | $ | 7,808 |  |  | $ | 6,085 |  |  | $ | 1,723 |  |  | 28 | % |
| Cost of service revenue | $ | 2,338 |  |  | $ | 1,404 |  |  | $ | 934 |  |  | 67 | % |
| Gross profit - Service revenue | $ | 5,470 |  |  | $ | 4,681 |  |  | $ | 789 |  |  | 17 | % |
| Gross profit margin - Service revenue | 70 | % |  | 77 | % |  | N/A |  | (7) | % |

[0001805385-25-000017:mdna:104]
The increases in service revenue, cost of service revenue, and service gross profit are primarily due to increased maintenance revenue associated with growth in number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech under our distributor licensing model, for the three months ended September 30, 2025 compared to the prior year period. The decrease in gross profit margin is primarily due to a $0.5 million estimated field services cost related to the replacement of certain Express system parts and a $0.2 million increase in amortization of capitalized software costs during the three months ended September 30, 2025 due to the release of Evolv eXpedite and our second generation of Evolv Express systems.

[0001805385-25-000017:mdna:105]
[same as prior period, unchanged from 0001805385-25-000009:mdna:103]

[0001805385-25-000017:mdna:106]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| License fee and other revenue | $ | 3,115 |  |  | $ | 2,022 |  |  | $ | 1,093 |  |  | 54 | % |
| Cost of license fee and other revenue | $ | 323 |  |  | $ | 183 |  |  | $ | 140 |  |  | 77 | % |
| Gross profit - License fee and other revenue | $ | 2,792 |  |  | $ | 1,839 |  |  | $ | 953 |  |  | 52 | % |
| Gross profit margin - License fee and other revenue | 90 | % |  | 91 | % |  | N/A |  | (1) | % |

[0001805385-25-000017:mdna:107]
The increases in license fee and other revenue and gross profit are primarily driven by $2.3 million of license fee revenue earned during the three months ended September 30, 2025 compared to $1.6 million earned during the prior year period under the distributor licensing model, as well as a $0.2 million increase in installation and training service fees. Although the unit sales through our distributor licensing model declined, the license fee and other revenue increased due to an increase in per-unit license fees for our second generation of Evolv Express systems.

[0001805385-25-000017:mdna:108]
[same as prior period, unchanged from 0001805385-25-000009:mdna:106]

[0001805385-25-000017:mdna:109]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 4,239 |  |  | $ | 4,075 |  |  | $ | 164 |  |  | 4 | % |
| Materials and prototypes | 233 |  |  | 614 |  |  | (381) |  |  | (62) | % |
| Professional fees | 703 |  |  | 713 |  |  | (10) |  |  | (1) | % |
| Other | 433 |  |  | 408 |  |  | 25 |  |  | 6 | % |
|  | $ | 5,608 |  |  | $ | 5,810 |  |  | $ | (202) |  |  | (3) | % |

[0001805385-25-000017:mdna:110]
The increase in personnel related expenses is primarily due to a decrease in payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $0.2 million. The decrease in materials and prototypes expense is primarily due to a decrease of $0.3 million in design and engineering costs reflecting the timing of certain product releases in the prior year.

[0001805385-25-000017:mdna:111]
[same as prior period, unchanged from 0001805385-25-000009:mdna:111]

[0001805385-25-000017:mdna:112]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 9,135 |  |  | $ | 10,346 |  |  | $ | (1,211) |  |  | (12) | % |
| Advertising and direct marketing | 446 |  |  | 1,316 |  |  | (870) |  |  | (66) | % |
| Travel and entertainment | 707 |  |  | 1,305 |  |  | (598) |  |  | (46) | % |
| Professional fees | 477 |  |  | 915 |  |  | (438) |  |  | (48) | % |
| Other | 950 |  |  | 1,084 |  |  | (134) |  |  | (12) | % |
|  | $ | 11,715 |  |  | $ | 14,966 |  |  | $ | (3,251) |  |  | (22) | % |

[0001805385-25-000017:mdna:113]
The decrease in personnel related expenses is due to a decrease in payroll costs and stock-based compensation of $1.1 million, which resulted primarily from the reduction in force in January 2025. Stock-based compensation expense included in sales and marketing expenses was $1.5 million for the three months ended September 30, 2025 compared to $2.5 million for the three months ended September 30, 2024. The decrease in advertising and direct marketing expense is primarily due to a decrease in expenses related to trade shows and events of $0.5 million and decrease in sponsorship fees of $0.2 million. The decrease in travel and entertainment expense is due to a decrease in travel costs for in-person sales meetings as a result of our reductions in force. Professional fees decreased primarily due to a decrease in marketing consulting costs.

[0001805385-25-000017:mdna:114]
[same as prior period, unchanged from 0001805385-25-000009:mdna:114]

[0001805385-25-000017:mdna:115]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 7,138 |  |  | $ | 6,789 |  |  | $ | 349 |  |  | 5 | % |
| Professional fees | 2,193 |  |  | 1,441 |  |  | 752 |  |  | 52 | % |
| Insurance costs | 941 |  |  | 830 |  |  | 111 |  |  | 13 | % |
| Non-recurring professional fees and other expenses | 2,307 |  |  | 4,916 |  |  | (2,609) |  |  | (53) | % |
|  | $ | 12,579 |  |  | $ | 13,976 |  |  | $ | (1,397) |  |  | (10) | % |

[0001805385-25-000017:mdna:116]
Personnel related expenses increased due to a $1.5 million increase in payroll costs, primarily from an increase in accrued bonuses, offset by a decrease in stock-based compensation of $1.1 million, which resulted primarily from the termination of certain executives as well as the reduction in force in January 2025. Stock-based compensation expense included in general and administrative expenses was $2.4 million for the three months ended September 30, 2025 compared to $3.5 million for the three months ended September 30, 2024. Professional fees increased primarily due to an increase in legal fees of $0.4 million and an increase in audit and tax fees of $0.2 million. Non-recurring professional fees and other expenses decreased primarily due to a $1.2 million decrease in consulting and legal fees and audit fees incurred in connection with the previous restatement of prior period financial statements, additional insurance recoveries of $1.2 million, and a decrease in IT and software subscription costs of $0.3 million, partially offset by an increase in rent of $0.2 million for additional leased space.

[0001805385-25-000017:mdna:117]
[same as prior period, unchanged from 0001805385-25-000009:mdna:117]

[0001805385-25-000017:mdna:118]
No restructuring cost was recognized for the three months ended September 30, 2025 and 2024.

[0001805385-25-000017:mdna:119]
Interest Expense

[0001805385-25-000017:mdna:120]
Interest expense of $0.7 million for the three months ended September 30, 2025 related to cash interest paid on long-term debt and amortization of deferred financing fees and costs. No interest expense was recognized for the three months ended September 30, 2024, as there was no debt outstanding during the period.

[0001805385-25-000017:mdna:121]
[same as prior period, unchanged from 0001805385-25-000009:mdna:119]

[0001805385-25-000017:mdna:122]
[same as prior period, unchanged from 0001805385-25-000009:mdna:120]

[0001805385-25-000017:mdna:123]
Interest income of $0.4 million for the three months ended September 30, 2025 and $0.6 million for the three months ended September 30, 2024 related primarily to interest earned on money market funds and the accretion of discounts on treasury bills. The interest earned decreased primarily due to lower average balances in interest-bearing accounts during the three months ended September 30, 2025 compared to during the three months ended September 30, 2024.

[0001805385-25-000017:mdna:124]
[same as prior period, unchanged from 0001805385-25-000009:mdna:122]

[0001805385-25-000017:mdna:125]
Change in the fair value of the contingent earn-out liability resulted in a $7.5 million gain and $8.3 million loss for the three months ended September 30, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments.

[0001805385-25-000017:mdna:126]
Change in Fair Value of Contingently Issuable/Returnable Common Stock Liability/Asset

[0001805385-25-000017:mdna:127]
Change in the fair value of the contingently issuable common stock liability resulted in a $2.2 million gain for the three months ended September 30, 2025, resulting from quarterly mark-to-market adjustments and common shares issuance, and a $2.1 million loss for the three months ended September 30, 2024, resulting from quarterly mark-to-market adjustments.

[0001805385-25-000017:mdna:128]
[same as prior period, unchanged from 0001805385-25-000009:mdna:126]

[0001805385-25-000017:mdna:129]
Change in the fair value of the public warrant liability resulted in losses of $2.6 million and $1.6 million for the three months ended September 30, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments.

[0001805385-25-000017:mdna:130]
12

[0001805385-25-000017:mdna:131]
Comparison of the Nine Months Ended September 30, 2025 and 2024

[0001805385-25-000017:mdna:132]
The following table summarizes our results of operations for the nine months ended September 30, 2025 and 2024 (in thousands):

[0001805385-25-000017:mdna:133]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 14,092 |  |  | $ | 4,789 |  |  | $ | 9,303 |  |  | 194 | % |
| Subscription revenue | 62,122 |  |  | 47,783 |  |  | 14,339 |  |  | 30 |  |
| Service revenue | 21,224 |  |  | 16,903 |  |  | 4,321 |  |  | 26 |  |
| License fee and other revenue | 9,963 |  |  | 5,290 |  |  | 4,673 |  |  | 88 |  |
| Total revenue | 107,401 |  |  | 74,765 |  |  | 32,636 |  |  | 44 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 16,495 |  |  | 8,569 |  |  | 7,926 |  |  | 92 |  |
| Cost of subscription revenue | 27,713 |  |  | 19,242 |  |  | 8,471 |  |  | 44 |  |
| Cost of service revenue | 5,753 |  |  | 3,749 |  |  | 2,004 |  |  | 53 |  |
| Cost of license fee and other revenue | 766 |  |  | 484 |  |  | 282 |  |  | 58 |  |
| Total cost of revenue | 50,727 |  |  | 32,044 |  |  | 18,683 |  |  | 58 |  |
| Gross profit | 56,674 |  |  | 42,721 |  |  | 13,953 |  |  | 33 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 15,207 |  |  | 18,056 |  |  | (2,849) |  |  | (16) |  |
| Sales and marketing | 34,494 |  |  | 47,182 |  |  | (12,688) |  |  | (27) |  |
| General and administrative | 44,789 |  |  | 39,843 |  |  | 4,946 |  |  | 12 |  |
| Restructuring costs | 2,662 |  |  | 860 |  |  | 1,802 |  |  | 210 |  |
| Loss from impairment of property and equipment | — |  |  | 209 |  |  | (209) |  |  | (100) |  |
| Total operating expenses | 97,152 |  |  | 106,150 |  |  | (8,998) |  |  | (8) |  |
| Loss from operations | (40,478) |  |  | (63,429) |  |  | 22,951 |  |  | 36 |  |
| Other (expense) income, net: |  |  |  |  |  |  |  |
| Interest expense | (714) |  |  | — |  |  | (714) |  |  | * |
| Interest income | 1,049 |  |  | 2,394 |  |  | (1,345) |  |  | (56) |  |
| Other income (expense), net | 117 |  |  | (33) |  |  | 150 |  |  | 455 |  |
| Change in fair value of contingent earn-out liability | 2,297 |  |  | 15,092 |  |  | (12,795) |  |  | (85) |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | (69) |  |  | 2,218 |  |  | (2,287) |  |  | (103) |  |
| Change in fair value of public warrant liability | (6,160) |  |  | 5,461 |  |  | (11,621) |  |  | (213) |  |
| Total other (expense) income, net | (3,480) |  |  | 25,132 |  |  | (28,612) |  |  | (114) |  |
| Loss before income taxes | $ | (43,958) |  |  | $ | (38,297) |  |  | $ | (5,661) |  |  | (15) | % |
| Provision for income taxes | $ | 62 |  |  | $ | — |  |  | $ | 62 |  |  | * |
| Net loss | $ | (44,020) |  |  | $ | (38,297) |  |  | $ | (5,723) |  |  | (15) | % |

[0001805385-25-000017:mdna:134]
[same as prior period, unchanged from 0001805385-25-000009:mdna:131]

[0001805385-25-000017:mdna:135]
[same as prior period, unchanged from 0001805385-25-000009:mdna:132]

[0001805385-25-000017:mdna:136]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 179 new customers during the nine months ended September 30, 2025, and (iii) the expansion of our existing customers’ initial Evolv Express deployments to other venues and locations as well as expanding their fleet with our Evolv eXpedite offering.

[0001805385-25-000017:mdna:137]
[same as prior period, unchanged from 0001805385-25-000009:mdna:134]

[0001805385-25-000017:mdna:138]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Product revenue | $ | 14,092 |  |  | $ | 4,789 |  |  | $ | 9,303 |  |  | 194 | % |
| Cost of product revenue | $ | 16,495 |  |  | $ | 8,569 |  |  | $ | 7,926 |  |  | 92 | % |
| Gross loss - Product revenue | $ | (2,403) |  |  | $ | (3,780) |  |  | $ | 1,377 |  |  | 36 | % |
| Gross profit margin - Product revenue | (17) | % |  | (79) | % |  | N/A |  | 62 | % |

[0001805385-25-000017:mdna:139]
The increases in product revenue and cost of product revenue for the nine months ended September 30, 2025 compared to the prior year period are primarily due to an increased utilization of our purchase subscription model, in which the customers purchase Evolv Express and Evolv eXpedite systems directly from us. The increase in product gross profit margin for the nine months ended September 30, 2025 compared to the nine months ended September 30, 2024 is primarily due to expense recognized during the nine months ended September 30, 2024 of a $1.1 million related to non-cancellable inventory purchase commitments, a $0.6 million decrease in charges for inventory reserves during the nine months ended September 30, 2025 as compared to the same period in the prior year, and a $0.7 million decrease in manufacturing expense during the nine months ended September 30, 2025, primarily related to the deployments of second generation of Evolv Express systems, which provide improved gross margins as compared to the first generation products, all partially offset by the initial deployments of Evolv eXpedite systems, which, as a new product offering, reflect a higher initial cost to produce that we expect to gradually decline in the future.

[0001805385-25-000017:mdna:140]
[same as prior period, unchanged from 0001805385-25-000009:mdna:137]

[0001805385-25-000017:mdna:141]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Subscription revenue | $ | 62,122 |  |  | $ | 47,783 |  |  | $ | 14,339 |  |  | 30 | % |
| Cost of subscription revenue | $ | 27,713 |  |  | $ | 19,242 |  |  | $ | 8,471 |  |  | 44 | % |
| Gross profit - Subscription revenue | $ | 34,409 |  |  | $ | 28,541 |  |  | $ | 5,868 |  |  | 21 | % |
| Gross profit margin - Subscription revenue | 55 | % |  | 60 | % |  | N/A |  | (5) | % |

[0001805385-25-000017:mdna:142]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to continued growth in our customer base as of September 30, 2025 compared to the prior year, with a higher number of active Evolv Express systems deployed under our pure subscription model and an increase in short term rental subscription revenue during the nine months ended September 30, 2025. Gross profit margin decreased primarily due to a $3.1 million loss on disposals of certain first generation Evolv Express systems and a $0.6 million estimated field services costs related to the replacement of certain Express system parts during the nine months ended September 30, 2025.

[0001805385-25-000017:mdna:143]
14

[0001805385-25-000017:mdna:144]
[same as prior period, unchanged from 0001805385-25-000009:mdna:140]

[0001805385-25-000017:mdna:145]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Service revenue | $ | 21,224 |  |  | $ | 16,903 |  |  | $ | 4,321 |  |  | 26 | % |
| Cost of service revenue | $ | 5,753 |  |  | $ | 3,749 |  |  | $ | 2,004 |  |  | 53 | % |
| Gross profit - Service revenue | $ | 15,471 |  |  | $ | 13,154 |  |  | $ | 2,317 |  |  | 18 | % |
| Gross profit margin - Service revenue | 73 | % |  | 78 | % |  | N/A |  | (5) | % |

[0001805385-25-000017:mdna:146]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to increased maintenance revenue associated with growth in number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers, for the nine months ended September 30, 2025 compared to the nine months ended September 30, 2024. The decrease in gross profit margin is primarily due to an accrual of $0.5 million estimated field services costs related to the replacement of certain Express system parts and increased amortization of capitalized software costs during the nine months ended September 30, 2025 by $0.7 million due to the release of Evolv eXpedite and our second generation of Evolv Express systems.

[0001805385-25-000017:mdna:147]
[same as prior period, unchanged from 0001805385-25-000009:mdna:143]

[0001805385-25-000017:mdna:148]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| License fee and other revenue | $ | 9,963 |  |  | $ | 5,290 |  |  | $ | 4,673 |  |  | 88 | % |
| Cost of license fee and other revenue | $ | 766 |  |  | $ | 484 |  |  | $ | 282 |  |  | 58 | % |
| Gross profit - License fee and other revenue | $ | 9,197 |  |  | $ | 4,806 |  |  | $ | 4,391 |  |  | 91 | % |
| Gross profit margin - License fee and other revenue | 92 | % |  | 91 | % |  | N/A |  | 1 | % |

[0001805385-25-000017:mdna:149]
The increase in license fee and other revenue and gross profit was primarily driven by $7.8 million of license fees earned during the nine months ended September 30, 2025 compared to $4.0 million earned during the nine months ended September 30, 2024 under the distributor licensing model, as well as a $0.4 million increase in installation and training service fees. In addition to the increase in the unit sales through our distributor licensing model, per-unit license fees also increased for our second generation of Evolv Express systems.

[0001805385-25-000017:mdna:150]
[same as prior period, unchanged from 0001805385-25-000009:mdna:146]

[0001805385-25-000017:mdna:151]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 11,633 |  |  | $ | 12,324 |  |  | $ | (691) |  |  | (6) | % |
| Materials and prototypes | 473 |  |  | 1,957 |  |  | (1,484) |  |  | (76) | % |
| Professional fees | 2,033 |  |  | 2,559 |  |  | (526) |  |  | (21) | % |
| Other | 1,068 |  |  | 1,216 |  |  | (148) |  |  | (12) | % |
|  | $ | 15,207 |  |  | $ | 18,056 |  |  | $ | (2,849) |  |  | (16) | % |

[0001805385-25-000017:mdna:152]
The decrease in personnel related expenses is primarily due to the January 2025 reduction in force, which resulted in a decrease in payroll costs of $0.9 million, partially offset by a $0.1 million increase in stock-based compensation and a decrease in payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $0.1 million. The decrease in materials and prototypes expense is primarily due to a decrease of $1.0 million in design and engineering costs and $0.4 million inventory reserve on unused components recognized in the prior year, both of which relate primarily to the development of the next generation of our Evolv Express system and new product offerings. The decrease in professional fees primarily relates to a decrease in consulting costs incurred for product development and engineering of $0.5 million.

[0001805385-25-000017:mdna:153]
[same as prior period, unchanged from 0001805385-25-000009:mdna:150]

[0001805385-25-000017:mdna:154]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 26,773 |  |  | $ | 34,171 |  |  | $ | (7,398) |  |  | (22) | % |
| Advertising and direct marketing | 1,722 |  |  | 3,170 |  |  | (1,448) |  |  | (46) | % |
| Travel and entertainment | 1,907 |  |  | 3,963 |  |  | (2,056) |  |  | (52) | % |
| Professional fees | 1,706 |  |  | 2,754 |  |  | (1,048) |  |  | (38) | % |
| Other | 2,386 |  |  | 3,124 |  |  | (738) |  |  | (24) | % |
|  | $ | 34,494 |  |  | $ | 47,182 |  |  | $ | (12,688) |  |  | (27) | % |

[0001805385-25-000017:mdna:155]
The decrease in personnel related expenses is due to a decrease in payroll costs and stock-based compensation of $7.2 million, which resulted primarily from the reductions in force in May 2024 and January 2025. Stock-based compensation expense included in sales and marketing expenses was $4.2 million for the nine months ended September 30, 2025 compared to $8.2 million for the nine months ended September 30, 2024. The decrease in advertising and direct marketing expense is primarily due to a decrease in expenses related to trade shows and events of $0.6 million and a decrease in sponsorship fees of $0.5 million. The decrease in travel and entertainment expense is due to a decrease in travel costs for in-person sales meetings of $2.1 million as a result of our reductions in force. Professional fees decreased due to a decrease in marketing consulting costs of $1.0 million. Other expense decreased primarily due to reduction in shipping costs related to demonstration units of $0.4 million and supplies costs of $0.3 million.

[0001805385-25-000017:mdna:156]
[same as prior period, unchanged from 0001805385-25-000009:mdna:153]

[0001805385-25-000017:mdna:157]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 18,648 |  |  | $ | 19,912 |  |  | $ | (1,264) |  |  | (6) | % |
| Professional fees | 7,042 |  |  | 5,653 |  |  | 1,389 |  |  | 25 | % |
| Insurance costs | 2,447 |  |  | 2,338 |  |  | 109 |  |  | 5 | % |
| Non-recurring professional fees and other expenses | 16,652 |  |  | 11,940 |  |  | 4,712 |  |  | 39 | % |
|  | $ | 44,789 |  |  | $ | 39,843 |  |  | $ | 4,946 |  |  | 12 | % |

[0001805385-25-000017:mdna:158]
The decrease in personnel related expenses is due to a decrease in stock-based compensation of $2.5 million, which resulted primarily from the termination of certain executives and the reduction in force in January 2025, partially offset by a $1.4 million increase in payroll costs, which resulted primarily from an increase in accrued bonuses. Stock-based compensation expense included in general and administrative expenses was $6.8 million for the nine months ended September 30, 2025 compared to $9.2 million for the nine months ended September 30, 2024. Professional fees increased primarily due to an increase in outsourced accounting consultancy of $1.5 million and an increase in legal fees of $0.3 million, partially offset by a decrease in audit and tax fees of $0.4 million. Non-recurring professional fees and other expenses increased primarily due to a $10.3 million increase in consulting and legal fees related to the Investigation and related matters and audit fees incurred in connection with the restatement of prior period financial statements, $1.0 million of estimated net losses related to class action lawsuits, and an increase in rent of $0.9 million for additional leased space, partially offset by insurance recoveries of $6.8 million and a decrease in IT and software subscription costs of $0.3 million.

[0001805385-25-000017:mdna:159]
[same as prior period, unchanged from 0001805385-25-000009:mdna:156]

[0001805385-25-000017:mdna:160]
Restructuring costs of $2.7 million for the nine months ended September 30, 2025 resulted from the reduction in force in January 2025. Stock-based compensation expense included in restructuring costs was $0.5 million for the nine months ended September 30, 2025. Smaller restructuring costs of $0.9 million for the nine months ended September 30, 2024 resulted from the reduction in force in May 2024.

[0001805385-25-000017:mdna:161]
Interest Expense

[0001805385-25-000017:mdna:162]
Interest expense of $0.7 million for the nine months ended September 30, 2025 related to cash interest paid on long-term debt and amortization of deferred financing fees and costs. No interest expense was recognized for the nine months ended September 30, 2024, as there was no debt outstanding during the period.

[0001805385-25-000017:mdna:163]
[same as prior period, unchanged from 0001805385-25-000009:mdna:159]

[0001805385-25-000017:mdna:164]
Interest income of $1.0 million and $2.4 million for the nine months ended September 30, 2025 and 2024, respectively, related primarily to interest earned on money market funds and the accretion of discounts on treasury bills. The interest earned decreased primarily due to lower average balances in interest-bearing accounts during the nine months ended September 30, 2025 compared to during the nine months ended September 30, 2024.

[0001805385-25-000017:mdna:165]
[same as prior period, unchanged from 0001805385-25-000009:mdna:161]

[0001805385-25-000017:mdna:166]
Change in the fair value of the contingent earn-out liability resulted in gains of $2.3 million and $15.1 million for the nine months ended September 30, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments.

[0001805385-25-000017:mdna:167]
Change in Fair Value of Contingently Issuable/Returnable Common Stock Liability/Asset

[0001805385-25-000017:mdna:168]
Change in the fair value of the contingently issuable common stock liability resulted in a $0.1 million loss for the nine months ended September 30, 2025, resulting from quarterly mark-to-market adjustments and common shares issuance, and $2.2 million gain for the nine months ended September 30, 2024, resulting from quarterly mark-to-market adjustments.

[0001805385-25-000017:mdna:169]
[same as prior period, unchanged from 0001805385-25-000009:mdna:165]

[0001805385-25-000017:mdna:170]
Change in the fair value of the public warrant liability resulted in a $6.2 million loss and a $5.5 million gain for the nine months ended September 30, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments.

[0001805385-25-000017:mdna:171]
[same as prior period, unchanged from 0001805385-25-000009:mdna:167]

[0001805385-25-000017:mdna:172]
Our financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures, debt obligations, and general corporate needs. We expect these needs to continue as we develop and grow our business. As of September 30, 2025, we had $56.2 million in cash, cash equivalents, and marketable securities, with outstanding debt of $28.5 million and available additional debt of up to $45.0 million, as detailed below. We incurred a net loss of $1.8 million and $30.4 million for the three months ended September 30, 2025 and 2024, respectively, and incurred a net loss of $44.0 million and $38.3 million for the nine months ended September 30, 2025 and 2024, respectively. Operating activities resulted in cash inflow of $3.1 million and cash outflow of $34.1 million during the nine months ended September 30, 2025 and 2024, respectively. We expect to continue to generate net losses for the foreseeable future.

[0001805385-25-000017:mdna:173]
[same as prior period, unchanged from 0001805385-25-000009:mdna:169]

[0001805385-25-000017:mdna:174]
As described below, on July 29, 2025 (the "Closing Date"), Evolv Technologies, Inc. entered into the $75.0 million MidCap Credit Agreement, the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's subscription sales model. The MidCap Credit Agreement provided for an initial $30.0 million term loan facility, a $30.0 million delayed draw facility (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit. On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs. As of September 30, 2025, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available.

[0001805385-25-000017:mdna:175]
We expect our cash, cash equivalents, and marketable securities of $56.2 million as of September 30, 2025, together with cash we expect to generate from future operations and our borrowing availability under our Senior Secured

[0001805385-25-000017:mdna:176]
17

[0001805385-25-000017:mdna:177]
Credit Facilities, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months and thereafter from the date of this Quarterly Report on Form 10-Q. As we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to strategically and carefully invest in various areas of the business to support that growth.

[0001805385-25-000017:mdna:178]
Under the MidCap Credit Agreement, we are also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that begins at $106.0 million on December 31, 2025 and increases quarterly thereafter. The minimum required ARR on December 31, 2026 is $111.3 million. As of September 30, 2025, our ARR was $117.2 million, which is sufficient to satisfy the minimum required ARR through December 31, 2027; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. As of September 30, 2025, the minimum liquidity required is $15.0 million, and liquidity, as defined in the agreement, was $71.1 million. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum EBITDA covenant that takes effect on June 30, 2027. As of September 30, 2025, we are in full compliance with all applicable covenant requirements, and expects to remain in compliance for a period of at least twelve months from November 13, 2025.

[0001805385-25-000017:mdna:179]
Additionally, there continues to be significant uncertainty regarding recent changes and potential future developments related to increased trade restrictions, tariffs or taxes on imports or exports relating to countries where we source or sell materials or products. The exact magnitude of any potential impact remains uncertain, as there may be further changes to tariffs and policies and, consequently, potential increased tension between the U.S. and targeted countries, and our financial condition and results of operations could be adversely affected.

[0001805385-25-000017:mdna:180]
[same as prior period, unchanged from 0001805385-25-000009:mdna:173]

[0001805385-25-000017:mdna:181]
On July 29, 2025, the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's subscription sales model. The MidCap Credit Agreement provides for an initial $30.0 million term loan facility (the “Initial Term Loan”), a $30.0 million delayed draw facility (the “Delayed Draw Term Loan”) (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit (the "Revolving Credit Facility”), each with a maturity date of July 1, 2030 (collectively, the “Senior Secured Credit Facilities”).

[0001805385-25-000017:mdna:182]
The Senior Secured Credit Facilities are guaranteed by the Company, and in the future, may be guaranteed by certain material subsidiaries. The Senior Secured Credit Facilities are secured by a first lien on substantially all of the assets of the Company. The borrowings under the Senior Secured Credit Facilities bear interest at a fluctuating rate per annum equal to Term Secured Overnight Financing Rate (“Term SOFR”) and an applicable margin calculated depending on earnings before interest, taxes, depreciation, and amortization (“EBITDA”). At closing, the applicable margin on Term SOFR loans was 5.25%. If the event described under the MidCap Credit Agreement related to Term SOFR occurs, a base rate is determined by reference to the higher of (1) the prime rate of Wells Fargo and (2) 2.00%. Interest and principal are payable monthly. Monthly interest payments are due in arrears on the first day of each month. Principal repayments for the Initial Term Loan begin in August 2029, following a 48-month interest-only period, and will be repaid in equal installments over the final 12 months of the loan term. The Revolving Credit Facility provides for an unused commitment fee of 0.25% on the undrawn portion of the facility.

[0001805385-25-000017:mdna:183]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary affirmative and negative covenants, including a minimum annual recurring revenue covenant, a minimum EBITDA covenant that takes effect on June 30, 2027, and a minimum liquidity covenant that would cease to apply following the resolution of certain litigation and regulatory matters, in addition to customary reporting requirements of periodic financial results. As of September 30, 2025, we were in full compliance with all covenant requirements. See Note 9, Long-term Debt for additional information related to the Senior Secured Credit Facilities.

[0001805385-25-000017:mdna:184]
[same as prior period, unchanged from 0001805385-25-000009:mdna:177]

[0001805385-25-000017:mdna:185]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of September 30, 2025. We anticipate fulfilling such commitments with our existing cash, cash equivalents, and marketable securities, as well as cash and cash equivalents obtained through operations and the proceeds from our Senior Secured Credit Facilities. Cash, cash equivalents, and marketable securities amounted to $56.2 million as of September 30, 2025.

[0001805385-25-000017:mdna:186]
[same as prior period, unchanged from 0001805385-25-000009:mdna:181]

[0001805385-25-000017:mdna:187]
We are party to a lease agreement for office space at our headquarters in Waltham, MA. During the three months ended March 31, 2024, we amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. Additionally, in August 2024, we amended the lease agreement again to expand our footprint in our headquarters and extend the term of the lease through May 2031. Per the second lease amendment, we are no longer required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space. This amount was previously classified as restricted cash, non-current, as shown in the condensed consolidated statement of cash flows as of March 31, 2024. Total future minimum lease payments under this noncancelable operating lease amount to $17.9 million as of September 30, 2025.

[0001805385-25-000017:mdna:188]
We generally contract with our contract manufacturer, Columbia Tech, on a cancellable purchase-order basis to provide manufacturing services for our equipment sold or leased to customers. While these contracts are cancellable by us upon prior notice, payments due upon cancellation may consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. Additionally, the recently executed agreement with the Company's new contract manufacturer, Plexus, includes provisions for which order volumes that fall short of our forecasts may result in purchase commitments. These payments are not determinable, but could result in a material purchase commitment if we were to cancel our open purchase orders.

[0001805385-25-000017:mdna:189]
[same as prior period, unchanged from 0001805385-25-000009:mdna:182]

[0001805385-25-000017:mdna:190]
[same as prior period, unchanged from 0001805385-25-000009:mdna:183]

[0001805385-25-000017:mdna:191]
|  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |
| Net cash provided by (used in) operating activities | $ | 3,098 |  |  | $ | (34,057) |  |
| Net cash (used in) provided by investing activities | (43,226) |  |  | 11,852 |  |
| Net cash provided by financing activities | 34,722 |  |  | 1,151 |  |
| Effect of exchange rate changes on cash and cash equivalents | (105) |  |  | (75) |  |
| Net decrease in cash, cash equivalents and restricted cash | $ | (5,511) |  |  | $ | (21,129) |  |

[0001805385-25-000017:mdna:192]
[same as prior period, unchanged from 0001805385-25-000009:mdna:185]

[0001805385-25-000017:mdna:193]
|  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |
| Net loss | $ | (44,020) |  |  | $ | (38,297) |  |
| Adjustments to reconcile net loss to net cash provided by (used in) operating activities | 44,660 |  |  | 15,634 |  |
| Changes in operating assets and liabilities | 2,458 |  |  | (11,394) |  |
| Net cash provided by (used in) operating activities | $ | 3,098 |  |  | $ | (34,057) |  |

[0001805385-25-000017:mdna:194]
Net loss increased from $38.3 million for the nine months ended September 30, 2024 to $44.0 million for the nine months ended September 30, 2025, as discussed in “Results of Operations” above.

[0001805385-25-000017:mdna:195]
Adjustments to reconcile net loss to net cash used in operating activities for the nine months ended September 30, 2025 include $3.9 million of an aggregate change in fair value of the earn-out liability, contingently issuable/returnable common stock warrant liability/asset, and public warrant liability, $15.8 million of stock-based compensation expense, and $17.9 million of depreciation and amortization. For the nine months ended September 30, 2024, such adjustments included $21.4 million of stock-based compensation expense and $11.9 million of depreciation and amortization, offset by $22.8 million of an aggregate change in fair value of the earn-out liability, contingently issuable/returnable common stock liability/asset, and public warrant liability.

[0001805385-25-000017:mdna:196]
Changes in operating assets and liabilities for the nine months ended September 30, 2025 are primarily related to the following:

[0001805385-25-000017:mdna:197]
•$16.9 million increase in accrued expenses and other current liabilities primarily due to a legal settlement offer accrual and bonus accrual, partially offset by decrease in accrued vendor payables;

[0001805385-25-000017:mdna:198]
•$11.6 million increase in deferred revenue due to a higher volume of sales;

[0001805385-25-000017:mdna:199]
•$11.1 million decrease in inventory primarily due to an increased focus on efficient inventory management, partially offset by a decrease in products expected to be leased to customers; and

[0001805385-25-000017:mdna:200]
•$1.8 million increase in accounts payable (excluding the non-cash portion related to capital expenditures incurred but not yet paid from December 31, 2024 to September 30, 2025) due primarily to the timing of vendor payments; partially offset by

[0001805385-25-000017:mdna:201]
•$20.6 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001805385-25-000017:mdna:202]
•$17.3 million increase in prepaid expenses and other current assets primarily due to estimated outstanding insurance recoveries and capitalization of costs associated with Delayed Draw Term Loan and Revolving Credit Facility, partially offset by decrease in vendor deposits;

[0001805385-25-000017:mdna:203]
•$1.8 million decrease in accounts payable (excluding the non-cash portion related to capital expenditures incurred but not yet paid from December 31, 2024 to September 30, 2025) due primarily to the timing of vendor payments; and

[0001805385-25-000017:mdna:204]
•$0.7 million increase in commission assets due to a higher volume of sales.

[0001805385-25-000017:mdna:205]
Changes in operating assets and liabilities for the nine months ended September 30, 2024 are primarily related to the following:

[0001805385-25-000017:mdna:206]
•$13.7 million increase in accounts receivable primarily due to higher sales and the timing of customer billings;

[0001805385-25-000017:mdna:207]
•$8.3 million increase in inventory primarily due to increased purchases to satisfy future expected demand for the first generation of Evolv Express systems and for the ongoing transition to the next generation of Evolv Express systems;

[0001805385-25-000017:mdna:208]
•$4.1 million increase in prepaid expenses and other current assets primarily due to prepaid deposits related to orders placed for Evolv Express systems; partially offset by

[0001805385-25-000017:mdna:209]
•$13.6 million increase in deferred revenue due to a higher volume of sales;

[0001805385-25-000017:mdna:210]
•$1.7 million increase in accrued expenses due to the timing of certain payments; and

[0001805385-25-000017:mdna:211]
•$1.0 million decrease in contract assets related to the timing of revenue recognition.

[0001805385-25-000017:mdna:212]
[same as prior period, unchanged from 0001805385-25-000009:mdna:202]

[0001805385-25-000017:mdna:213]
During the nine months ended September 30, 2025, cash used in investing activities was $43.2 million, consisting of $29.1 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express systems to be leased to customers and $4.3 million for the development of internal-use software and software embedded in products to be sold or leased, offset by $9.8 million of net cash provided by purchases and redemptions of marketable securities.

[0001805385-25-000017:mdna:214]
During the nine months ended September 30, 2024, cash provided by investing activities was $11.9 million, consisting primarily of a net $41.1 million inflow related to purchases and redemptions of marketable securities, offset by $24.4 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express systems to be leased to customers, and $4.8 million for the development of internal-use software and software embedded in products to be sold or leased.

[0001805385-25-000017:mdna:215]
[same as prior period, unchanged from 0001805385-25-000009:mdna:205]

[0001805385-25-000017:mdna:216]
During the nine months ended September 30, 2025, cash provided by financing activities was $34.7 million. The increase was primarily driven by $30.0 million in proceeds from debt issuance under the drawn Initial Term Loan, partially offset by total debt issuance costs of $3.7 million. Additional sources of financing cash flows included proceeds from the exercise of stock.

[0001805385-25-000017:mdna:217]
During the nine months ended September 30, 2024, cash provided by financing activities was $1.2 million, consisting primarily of proceeds from the exercise of stock options.

[0001805385-25-000017:mdna:218]
[same as prior period, unchanged from 0001805385-25-000009:mdna:207]

[0001805385-25-000017:mdna:219]
As further discussed in Note 2, Summary of Significant Accounting Policies, there have been two new accounting pronouncements issued since the issuance of the 2024 Form 10-K that may have a material impact on our consolidated financial position, results of operations or cash flows. We are currently evaluating the potential impacts of ASU 2025-05 and 2025-06. There were no accounting pronouncements that became effective since the issuance of the 2024 Form 10-K that had a material impact on our consolidated financial position, results of operations or cash flows.

[0001805385-25-000017:mdna:220]
[same as prior period, unchanged from 0001805385-25-000009:mdna:209]

[0001805385-25-000017:mdna:221]
Our critical accounting estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” of our 2024 Form 10-K. Other than disclosures related to estimating the fair value of market-based stock units and for estimating rebate liabilities, as discussed below, there have been no material changes to our critical accounting estimates during the nine months ended September 30, 2025.

[0001805385-25-000017:mdna:222]
[same as prior period, unchanged from 0001805385-25-000009:mdna:211]

[0001805385-25-000017:mdna:223]
[same as prior period, unchanged from 0001805385-25-000009:mdna:212]

[0001805385-25-000017:mdna:224]
[same as prior period, unchanged from 0001805385-25-000009:mdna:213]

[0001805385-25-000017:mdna:225]
For the fiscal year 2025, the Company implemented a channel partner rebate program (the “Rebate Program”) for eligible resellers. Under the Rebate Program, eligible resellers that attain at least 25% of their current fiscal year total contract value (“TCV”) target (“Annual Target”) in a given quarter are eligible for a rebate based upon a percentage of their TCV for that quarter. In addition, resellers that meet their Annual Target are eligible for a one-time rebate based upon a percentage of their total fiscal year TCV, applied as a credit in the subsequent fiscal year. All rebates are issued as credits against future purchases, and no cash rebates are paid. Unused rebate credits are forfeited in the event of a reseller agreement termination.
