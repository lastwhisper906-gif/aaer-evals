# EVLV 8-K — 0001805385-25-000016 filed 2025-11-13

## item codes, every 8-K on or before 2025-11-13

- 2025-11-13 0001805385-25-000016 — 2.02, 9.01
- 2025-08-14 0001805385-25-000008 — 2.02, 5.02, 9.01
- 2025-07-30 0001104659-25-071952 — 1.01, 9.01
- 2025-07-01 0001104659-25-064786 — 7.01
- 2025-06-23 0001628280-25-032646 — 5.07
- 2025-05-20 0001628280-25-026833 — 2.02, 9.01
- 2025-04-28 0001628280-25-020351 — 2.02, 9.01
- 2025-04-23 0001104659-25-037732 — 5.02, 7.01, 9.01
- 2025-04-22 0001104659-25-037530 — 3.01, 7.01, 9.01
- 2025-02-04 0001104659-25-008892 — 5.02, 7.01, 9.01
- 2025-01-24 0001104659-25-005796 — 5.02, 7.01, 8.01, 9.01
- 2025-01-23 0001628280-25-002293 — 2.02, 2.05, 7.01, 9.01
- 2024-12-23 0001104659-24-131278 — 5.02
- 2024-12-12 0001104659-24-128006 — 5.02
- 2024-12-09 0001104659-24-126542 — 5.02, 7.01, 9.01
- 2024-11-22 0001104659-24-122102 — 3.01, 7.01, 9.01
- 2024-11-21 0001104659-24-121349 — 5.02, 7.01, 8.01, 9.01
- 2024-10-31 0001104659-24-112868 — 5.02, 7.01, 9.01
- 2024-10-25 0001104659-24-111310 — 4.02, 7.01, 9.01
- 2024-08-08 0001628280-24-036115 — 2.02, 9.01
- 2024-06-04 0001628280-24-026572 — 5.07
- 2024-05-09 0001628280-24-022265 — 2.02, 9.01
- 2024-02-29 0001628280-24-007980 — 2.02, 9.01
- 2024-02-20 0001104659-24-025077 — 7.01, 9.01
- 2024-01-31 0001628280-24-002618 — 5.03, 9.01
- 2023-11-09 0001628280-23-038267 — 2.02, 9.01
- 2023-11-06 0001104659-23-114499 — 5.02
- 2023-10-25 0001628280-23-035145 — 4.02
- 2023-10-12 0001104659-23-108693 — 2.02, 7.01, 9.01
- 2023-08-10 0001628280-23-028861 — 2.02, 9.01
- 2023-06-02 0001628280-23-020680 — 5.07
- 2023-05-10 0001628280-23-017243 — 2.02, 9.01
- 2023-04-03 0001628280-23-010402 — 1.02, 2.04, 8.01, 9.01
- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2025-11-13

- 2025-05-15 0001104659-25-049608 — NT 10-Q, for the period ended 2025-03-31
- 2025-03-31 0001104659-25-029637 — NT 10-K, for the period ended 2024-12-31
- 2024-11-13 0001104659-24-117677 — NT 10-Q, for the period ended 2024-09-30
- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001805385-25-000016:8k_2_02:1]
EX-99.1
2
evlv-20251113exx991.htm
EX-99.1

[0001805385-25-000016:8k_2_02:2]
Document

[0001805385-25-000016:8k_2_02:3]
Exhibit 99.1

[0001805385-25-000016:8k_2_02:4]
Evolv Technology Reports Third Quarter Financial Results

[0001805385-25-000016:8k_2_02:5]
—  Company Raises Revenue Outlook for 2025 to $142-$145 Million, up 37%-40% Year-Over-Year —

[0001805385-25-000016:8k_2_02:6]
•Q3'25 Revenue of $42.9 million, up 57% year-over-year

[0001805385-25-000016:8k_2_02:7]
•Q3'25 Ending ARR1 of $117.2 million, up 25% year-over-year

[0001805385-25-000016:8k_2_02:8]
•Q3'25 Net Loss of $(1.8) million, with Net Profit Margin of (4)%

[0001805385-25-000016:8k_2_02:9]
•Q3'25 Adjusted EBITDA2 of $5.1 million, with Adjusted EBITDA Margin2 of 12%

[0001805385-25-000016:8k_2_02:10]
Waltham, Massachusetts – November 13, 2025 – Evolv Technologies Holdings, Inc (NASDAQ: EVLV), a leading security technology company pioneering AI-based solutions designed to help create safer experiences, today announced financial results for the quarter ended September 30, 2025.

[0001805385-25-000016:8k_2_02:11]
“We made meaningful progress across many key measures of the business in the third quarter—including subscribers, revenue, and annual recurring revenue, as well as important indicators of profitability and liquidity,” said John Kedzierski, President and Chief Executive Officer of Evolv Technology. “Through strong new customer acquisition and expanding deployments with existing customers, we continue to deliver real-world impact at scale—screening millions of visitors every day across over 1,000 customers. Looking ahead, we’re encouraged by the growing demand for our solutions and are confident in our ability to close the year with momentum as we advance on our goal of building a high-growth, profitable, and cash-generative business.”

[0001805385-25-000016:8k_2_02:12]
Results for the Third Quarter of 2025

[0001805385-25-000016:8k_2_02:13]
Total revenue for the third quarter of 2025 was $42.9 million, an increase of 57% compared to $27.4 million for the third quarter of 2024. Revenue for the third quarter of 2025 was primarily driven by strong new customer additions and continued expansion of deployments across the existing customer base. Revenue for the period also reflected certain notable items that contributed approximately $7.5 million from the following: (i) approximately $3.0 million of revenue (primarily product revenue) associated with the largest customer order in the Company’s history; (ii) approximately $3.0 million attributable to IP license fees and other revenue associated with the Company’s distribution fulfillment model which is being phased out; and (iii) approximately $1.5 million from short-term rental agreements that concluded in the period. Annual Recurring Revenue (“ARR”)1 was $117.2 million at the end of third quarter of 2025, an increase of 25% compared to $93.7 million at the end of the third quarter of 2024. Net loss for the third quarter of 2025 was $(1.8) million, or $(0.01) per basic and diluted share, compared to $(30.4) million, or $(0.19) per basic and diluted share, in the third quarter of 2024. Adjusted earnings (loss)2 for the third quarter of 2025 was $(3.4) million, or $(0.02) per diluted share, compared to adjusted earnings (loss)2 of $(6.9) million, or $(0.04) per diluted share (as restated), for the third quarter of 2024. Adjusted EBITDA2 for the third quarter of 2025 was $5.1 million compared to $(3.0) million in the third quarter of 2024. As of September 30, 2025, the Company had cash, cash equivalents and marketable securities of $56.2 million.

[0001805385-25-000016:8k_2_02:14]
Results for the First Nine Months of 2025

[0001805385-25-000016:8k_2_02:15]
Total revenue for the nine months ended September 30, 2025 was $107.4 million, an increase of 44% compared to $74.8 million for the nine months ended September 30, 2024. Net loss for the nine months ended September 30, 2025 was $(44.0) million, or $(0.26) per basic and diluted share, compared to $(38.3) million, or $(0.25) per basic and diluted share, in the nine months ended September 30, 2024. Adjusted earnings (loss)2 for the nine months ended September 30, 2025 was $(11.5) million, or $(0.07) per diluted share, compared to adjusted earnings (loss)2 of $(30.8) million, or $(0.20) per diluted share, for the nine months ended September 30, 2024. Adjusted EBITDA2 for the nine months ended September 30, 2025 was $9.3 million compared to $(21.3) million in the nine months ended September 30, 2024.

[0001805385-25-000016:8k_2_02:16]
The following table summarizes the breakdown of recurring and non-recurring revenue3 for each period presented:

[0001805385-25-000016:8k_2_02:17]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | % Change |  | 2025 |  | 2024 |  | % Change |
| Recurring revenue | $ | 30,120 |  |  | $ | 23,764 |  |  | 27 | % |  | $ | 82,551 |  |  | $ | 63,741 |  |  | 30 | % |
| Non-recurring revenue | 12,730 |  |  | 3,596 |  |  | 254 | % |  | 24,850 |  |  | 11,024 |  |  | 125 | % |
| Total revenue | $ | 42,850 |  |  | $ | 27,360 |  |  | 57 | % |  | $ | 107,401 |  |  | $ | 74,765 |  |  | 44 | % |

[0001805385-25-000016:8k_2_02:18]
The following table summarizes operating cash flows for each period presented:

[0001805385-25-000016:8k_2_02:19]
|  |  |  | Nine Months EndedSeptember 30, |
|  |  |  |  |  | 2025 |  | 2024 |
| Net loss |  |  |  |  | $ | (44,020) |  |  | $ | (38,297) |  |
| Adjustments to reconcile net loss to net cash provided by (used in) operating activities |  |  |  |  | 44,660 |  |  | 15,634 |  |
| Changes in operating assets and liabilities |  |  |  |  | 2,458 |  |  | (11,394) |  |
| Net cash provided by (used in) operating activities |  |  |  |  | $ | 3,098 |  |  | $ | (34,057) |  |

[0001805385-25-000016:8k_2_02:20]
Company Comments on Outlook for 2025

[0001805385-25-000016:8k_2_02:21]
The Company today commented on its business outlook for 2025. The Company's outlook is based on the current indications for its business, which may change at any time.  The Company expects total revenues in 2025 to be between $142 to $145 million, reflecting growth of 37% to 40% compared to 2024.  The Company believes that this revenue growth, coupled with a focus on operational efficiency, will drive improved profitability and cash flow.  The Company expects to deliver positive full year Adjusted EBITDA1 in 2025 with Adjusted EBITDA1 margins in the high single digits.  The Company expects to be cash flow positive in the fourth quarter of 2025.

[0001805385-25-000016:8k_2_02:22]
| Estimate |  | Issued August 14, 2025 |  | Issued November 13, 2025 |
| Total Revenue (Millions) |  | $132-$135 |  | $142-$145 |
| Total Revenue Growth Rate |  | 27%-30% |  | 37%-40% |
| Adjusted EBITDA Margin2 |  | Mid-Single Digits |  | High Single Digits |

[0001805385-25-000016:8k_2_02:23]
Company to Host Live Conference Call and Webcast

[0001805385-25-000016:8k_2_02:24]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business for both 2025 and 2026.  The conference call will be webcast live at http://ir.evolvtechnology.com.

[0001805385-25-000016:8k_2_02:25]
About Evolv Technology

[0001805385-25-000016:8k_2_02:26]
Evolv Technologies Holdings, Inc (NASDAQ: EVLV) is designed to transform human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics. Its mission is to transform security to create a safer world to live, work, learn, and play. Evolv has digitally transformed the gateways in many places where people gather by enabling seamless integration combined with powerful analytics and insights. Evolv’s advanced systems have scanned more than three billion people since 2019. Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) 2024 New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category, as well as Sport Business Journal’s (SBJ) 2024 awards for “Best In Fan Experience Technology” and “Best In Sports Technology”. Evolv®, Evolv Express®, Evolv Insights®, Evolv Visual Gun Detection™, Evolv eXpedite™, and Evolv Eva™ are registered trademarks or trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit evolv.com.

[0001805385-25-000016:8k_2_02:27]
1 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001805385-25-000016:8k_2_02:28]
2 Non-GAAP Financial Measures In this press release, the Company’s adjusted gross profit (loss), adjusted gross margin, adjusted operating expenses, adjusted operating income (loss), adjusted EBITDA, adjusted EBITDA margin, adjusted earnings (loss), and adjusted earnings per diluted share are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit and adjusted gross margin exclude stock-based compensation expense, amortization of capitalized stock-based compensation, non-recurring employee restructuring and other separation costs, and non-recurring inventory charges, which management believes provides a more meaningful representation of contribution margin. Adjusted operating expenses is defined as operating expenses less stock-based compensation expense, loss on impairment of lease equipment, non-recurring employee restructuring and other separation costs, and other non-recurring legal and regulatory costs, which management believes provides a more meaningful representation of on-going operating expense levels. Other non-recurring legal and regulatory costs include non-recurring legal, accounting and professional fees related to the internal investigation, subsequent restatement, certain non-recurring regulatory, litigation and legal matters, as well as fees related to the resolution of the U.S. Federal Trade Commission investigation, net of estimated insurance recoveries. Adjusted operating income (loss), is defined as loss from operations, excluding stock-based compensation expense, amortization of capitalized stock-based compensation, loss on impairment of leased equipment, non-recurring employee restructuring and other separation costs, non-recurring inventory charges, and other non-recurring legal and regulatory costs, which management believes provides a more meaningful representation of operating results. Adjusted EBITDA and Adjusted EBITDA margin is defined as net income (loss) plus depreciation and amortization, stock-based compensation, interest expense (income), provision for income taxes, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of leased equipment, loss on disposal of leased equipment, non-recurring employee restructuring and other separation costs, non-recurring inventory charges, and other non-recurring legal and regulatory costs. Adjusted earnings (loss) and Adjusted earnings (loss) per diluted share are defined as net income (loss) plus stock-based compensation, amortization of capitalized stock-based compensation, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of leased equipment, non-recurring employee restructuring and other separation costs, non-recurring inventory charges, and other non-recurring legal and regulatory costs. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operating performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures

[0001805385-25-000016:8k_2_02:29]
included in this press release. The Company is unable to provide a reconciliation of Adjusted EBITDA to Net Income (Loss) and Adjusted EBITDA Margin to Net Profit Margin, each measure's most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact these GAAP financial measures are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001805385-25-000016:8k_2_02:30]
3 Recurring revenue includes the recurring portion of revenue associated with pure subscription contracts and hardware purchase subscription contracts. Non-recurring revenue includes revenue that is non-recurring in nature, such as product revenue, shipping revenue, and revenue from installation, training, and professional services.

[0001805385-25-000016:8k_2_02:31]
Forward-Looking Statements

[0001805385-25-000016:8k_2_02:32]
You should review this press release and the documents that we reference in this press release and related presentation materials with the understanding that our actual future results, levels of activity, performance and achievements may be materially different from what we expect. We qualify all of our forward-looking statements by these cautionary statements. Except as required by applicable law, we do not plan to publicly update or revise any forward-looking statements contained in this press release and related presentation materials, whether as a result of any new information, future events or otherwise.

[0001805385-25-000016:8k_2_02:33]
Investor Relations:

[0001805385-25-000016:8k_2_02:34]
Brian Norris

[0001805385-25-000016:8k_2_02:35]
Senior Vice President of Finance and Investor Relations

[0001805385-25-000016:8k_2_02:36]
bnorris@evolvtechnology.com

[0001805385-25-000016:8k_2_02:37]
EVOLV TECHNOLOGY

[0001805385-25-000016:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001805385-25-000016:8k_2_02:39]
(In thousands, except share and per share data)

[0001805385-25-000016:8k_2_02:40]
(Unaudited)

[0001805385-25-000016:8k_2_02:41]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 9,242 |  |  | $ | 1,344 |  |  | $ | 14,092 |  |  | $ | 4,789 |  |
| Subscription revenue | 22,685 |  |  | 17,909 |  |  | 62,122 |  |  | 47,783 |  |
| Service revenue | 7,808 |  |  | 6,085 |  |  | 21,224 |  |  | 16,903 |  |
| License fee and other revenue | 3,115 |  |  | 2,022 |  |  | 9,963 |  |  | 5,290 |  |
| Total revenue | 42,850 |  |  | 27,360 |  |  | 107,401 |  |  | 74,765 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 7,960 |  |  | 2,616 |  |  | 16,495 |  |  | 8,569 |  |
| Cost of subscription revenue | 10,923 |  |  | 7,348 |  |  | 27,713 |  |  | 19,242 |  |
| Cost of service revenue | 2,338 |  |  | 1,404 |  |  | 5,753 |  |  | 3,749 |  |
| Cost of license fee and other revenue | 323 |  |  | 183 |  |  | 766 |  |  | 484 |  |
| Total cost of revenue | 21,544 |  |  | 11,551 |  |  | 50,727 |  |  | 32,044 |  |
| Gross profit | 21,306 |  |  | 15,809 |  |  | 56,674 |  |  | 42,721 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,608 |  |  | 5,810 |  |  | 15,207 |  |  | 18,056 |  |
| Sales and marketing | 11,715 |  |  | 14,966 |  |  | 34,494 |  |  | 47,182 |  |
| General and administrative | 12,579 |  |  | 13,976 |  |  | 44,789 |  |  | 39,843 |  |
| Restructuring costs | — |  |  | — |  |  | 2,662 |  |  | 860 |  |
| Loss from impairment of property and equipment | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Total operating expenses | 29,902 |  |  | 34,961 |  |  | 97,152 |  |  | 106,150 |  |
| Loss from operations | (8,596) |  |  | (19,152) |  |  | (40,478) |  |  | (63,429) |  |
| Other (expense) income, net: |  |  |  |  |  |  |  |
| Interest expense | (713) |  |  | — |  |  | (714) |  |  | — |  |
| Interest income | 436 |  |  | 628 |  |  | 1,049 |  |  | 2,394 |  |
| Other income (expense), net | (44) |  |  | 34 |  |  | 117 |  |  | (33) |  |
| Change in fair value of contingent earn-out liability | 7,521 |  |  | (8,321) |  |  | 2,297 |  |  | 15,092 |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | 2,178 |  |  | (2,056) |  |  | (69) |  |  | 2,218 |  |
| Change in fair value of public warrant liability | (2,578) |  |  | (1,576) |  |  | (6,160) |  |  | 5,461 |  |
| Total other income (expense), net | 6,800 |  |  | (11,291) |  |  | (3,480) |  |  | 25,132 |  |
| Loss before income taxes | (1,796) |  |  | (30,443) |  |  | (43,958) |  |  | (38,297) |  |
| Provision for income taxes | — |  |  | — |  |  | $ | 62 |  |  | $ | — |  |
| Net loss | $ | (1,796) |  |  | $ | (30,443) |  |  | $ | (44,020) |  |  | $ | (38,297) |  |
| Net (loss) income attributable to common stockholders – basic and diluted | $ | (1,796) |  |  | $ | (30,443) |  |  | $ | (44,020) |  |  | $ | (38,297) |  |
| Weighted average common shares outstanding – basic and diluted | 172,790,098 |  |  | 157,709,229 |  |  | 166,327,570 |  |  | 155,760,149 |  |
| Net loss per share - basic and diluted | $ | (0.01) |  |  | $ | (0.19) |  |  | $ | (0.26) |  |  | $ | (0.25) |  |
| Net loss | $ | (1,796) |  |  | $ | (30,443) |  |  | $ | (44,020) |  |  | $ | (38,297) |  |
| Other comprehensive income (loss) |  |  |  |  |  |  |  |
| Cumulative translation adjustment | 26 |  |  | (86) |  |  | (105) |  |  | (75) |  |
| Total other comprehensive income (loss) | 26 |  |  | (86) |  |  | (105) |  |  | (75) |  |
| Total comprehensive loss | $ | (1,770) |  |  | $ | (30,529) |  |  | $ | (44,125) |  |  | $ | (38,372) |  |

[0001805385-25-000016:8k_2_02:42]
EVOLV TECHNOLOGY

[0001805385-25-000016:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001805385-25-000016:8k_2_02:44]
(In thousands, except share and per share data)

[0001805385-25-000016:8k_2_02:45]
(Unaudited)

[0001805385-25-000016:8k_2_02:46]
|  | September 30, 2025 |  | December 31, 2024 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 31,504 |  |  | $ | 37,015 |  |
| Marketable securities | 24,723 |  |  | 14,927 |  |
| Accounts receivable, net | 48,883 |  |  | 28,392 |  |
| Inventory | 8,770 |  |  | 16,963 |  |
| Current portion of contract assets | 1,212 |  |  | 799 |  |
| Current portion of commission asset | 5,956 |  |  | 5,429 |  |
| Prepaid expenses and other current assets | 30,593 |  |  | 17,921 |  |
| Total current assets | 151,641 |  |  | 121,446 |  |
| Contract assets, noncurrent | 381 |  |  | 657 |  |
| Commission asset, noncurrent | 7,759 |  |  | 7,567 |  |
| Property and equipment, net | 126,919 |  |  | 123,661 |  |
| Operating lease right-of-use assets | 12,730 |  |  | 13,993 |  |
| Other assets | 4,859 |  |  | 735 |  |
| Total assets | $ | 304,289 |  |  | $ | 268,059 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 4,724 |  |  | $ | 10,492 |  |
| Accrued expenses and other current liabilities | 33,954 |  |  | 19,508 |  |
| Current portion of deferred revenue | 77,904 |  |  | 64,506 |  |
| Current portion of operating lease liabilities | 2,765 |  |  | 2,203 |  |
| Total current liabilities | 119,347 |  |  | 96,709 |  |
| Deferred revenue, noncurrent | 18,464 |  |  | 20,266 |  |
| Long-term debt, noncurrent | 28,528 |  |  | — |  |
| Operating lease liabilities, noncurrent | 11,107 |  |  | 12,326 |  |
| Contingent earn-out liability, noncurrent | 10,512 |  |  | 12,809 |  |
| Contingently issuable common stock liability, noncurrent | 3,638 |  |  | 4,001 |  |
| Public warrant liability, noncurrent | 10,457 |  |  | 4,297 |  |
| Total liabilities | 202,053 |  |  | 150,408 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at September 30, 2025 and December 31, 2024; no shares issued and outstanding at September 30, 2025 and December 31, 2024 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at September 30, 2025 and December 31, 2024; 173,803,265 and 159,602,069 shares issued and outstanding at September 30, 2025 and December 31, 2024, respectively | 17 |  |  | 16 |  |
| Additional paid-in capital | 501,040 |  |  | 472,331 |  |
| Accumulated other comprehensive loss | (137) |  |  | (32) |  |
| Accumulated deficit | (398,684) |  |  | (354,664) |  |
| Stockholders’ equity | 102,236 |  |  | 117,651 |  |
| Total liabilities and stockholders’ equity | $ | 304,289 |  |  | $ | 268,059 |  |

[0001805385-25-000016:8k_2_02:47]
EVOLV TECHNOLOGY

[0001805385-25-000016:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001805385-25-000016:8k_2_02:49]
(In thousands)

[0001805385-25-000016:8k_2_02:50]
(Unaudited)

[0001805385-25-000016:8k_2_02:51]
|  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (44,020) |  |  | $ | (38,297) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 17,859 |  |  | 11,933 |  |
| Write-off of inventory and change in inventory reserve | 2,016 |  |  | 3,151 |  |
| Loss from impairment of property and equipment | — |  |  | 209 |  |
| Loss on disposal of property and equipment | 3,503 |  |  | — |  |
| Stock-based compensation | 15,816 |  |  | 21,364 |  |
| Non-cash interest expense | 195 |  |  | — |  |
| Amortization of premium on marketable securities, net of change in accrued interest | 10 |  |  | 261 |  |
| Non-cash lease expense | 1,263 |  |  | 1,116 |  |
| Change in allowance for expected credit losses | 66 |  |  | 371 |  |
| Change in fair value of earn-out liability | (2,297) |  |  | (15,092) |  |
| Change in fair value of contingently issuable common stock | 69 |  |  | (2,218) |  |
| Change in fair value of public warrant liability | 6,160 |  |  | (5,461) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (20,557) |  |  | (13,679) |  |
| Inventory | 11,079 |  |  | (8,327) |  |
| Commission assets | (719) |  |  | (1,005) |  |
| Contract assets | (137) |  |  | 993 |  |
| Other assets | 437 |  |  | 333 |  |
| Prepaid expenses and other current assets | (17,331) |  |  | (4,093) |  |
| Accounts payable | 1,845 |  |  | 216 |  |
| Deferred revenue | 11,596 |  |  | 13,559 |  |
| Accrued expenses and other current liabilities | 16,902 |  |  | 1,655 |  |
| Operating lease liability | (657) |  |  | (1,046) |  |
| Net cash provided by (used in) operating activities | 3,098 |  |  | (34,057) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (4,311) |  |  | (4,773) |  |
| Purchases of property and equipment | (29,109) |  |  | (24,443) |  |
| Purchases of marketable securities | (34,481) |  |  | (14,567) |  |
| Proceeds from maturities of marketable securities | 24,675 |  |  | 55,635 |  |
| Net cash (used in) provided by investing activities | (43,226) |  |  | 11,852 |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 8,406 |  |  | 1,151 |  |
| Proceeds from long-term debt | 26,316 |  |  | — |  |
| Net cash provided by financing activities | 34,722 |  |  | 1,151 |  |
| Effect of exchange rate changes on cash and cash equivalents | (105) |  |  | (75) |  |
| Net decrease in cash, cash equivalents and restricted cash | (5,511) |  |  | (21,129) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 37,015 |  |  | 67,437 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 31,504 |  |  | $ | 46,308 |  |

[0001805385-25-000016:8k_2_02:52]
EVOLV TECHNOLOGY

[0001805385-25-000016:8k_2_02:53]
SUMMARY OF KEY OPERATING STATISTICS

[0001805385-25-000016:8k_2_02:54]
(Unaudited)

[0001805385-25-000016:8k_2_02:55]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  | June 30,2025 |  | September 30,2025 |  |  |
| New customers |  | 53 |  |  | 84 |  |  | 52 |  |  | 60 |  |  | 54 |  |  | 63 |  |  | 62 |  |  |  |
| Annual recurring revenue |  | $ | 79,192 |  |  | $ | 87,011 |  |  | $ | 93,676 |  |  | $ | 99,351 |  |  | $ | 105,990 |  |  | $ | 110,516 |  |  | $ | 117,200 |  |  |  |
| Recurring revenue |  | $ | 18,961 |  |  | $ | 21,016 |  |  | $ | 23,764 |  |  | $ | 23,678 |  |  | $ | 25,753 |  |  | $ | 26,678 |  |  | $ | 30,120 |  |  |  |

[0001805385-25-000016:8k_2_02:56]
.

[0001805385-25-000016:8k_2_02:57]
EVOLV TECHNOLOGY

[0001805385-25-000016:8k_2_02:58]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001805385-25-000016:8k_2_02:59]
(In thousands)

[0001805385-25-000016:8k_2_02:60]
(Unaudited)

[0001805385-25-000016:8k_2_02:61]
|  | Three Months Ended, |
|  |  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  | June 30,2025 |  | September 30,2025 |  |  |
|  |  | (Restated) |  | (Restated) |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses, GAAP |  | $ | 34,061 |  |  | $ | 37,128 |  |  | $ | 34,961 |  |  | $ | 35,619 |  |  | $ | 33,539 |  |  | $ | 33,711 |  |  | $ | 29,902 |  |  |  |
| Stock-based compensation |  | (6,292) |  |  | (7,254) |  |  | (7,263) |  |  | (3,159) |  |  | (4,660) |  |  | (5,265) |  |  | (5,121) |  |  |  |
| Loss on impairment of leased equipment |  | — |  |  | — |  |  | (209) |  |  | (15) |  |  | — |  |  | — |  |  | — |  |  |  |
| Non-recurring employee restructuring and other separation costs |  | — |  |  | (1,000) |  |  | — |  |  | (2,060) |  |  | (2,137) |  |  | (827) |  |  | (6) |  |  |  |
| Other non-recurring legal and regulatory costs |  | (476) |  |  | (2,185) |  |  | (2,339) |  |  | (7,284) |  |  | (3,561) |  |  | (5,979) |  |  | 36 |  |  |  |
| Adjusted operating expenses |  | $ | 27,293 |  |  | $ | 26,689 |  |  | $ | 25,150 |  |  | $ | 23,101 |  |  | $ | 23,181 |  |  | $ | 21,640 |  |  | $ | 24,811 |  |  |  |

[0001805385-25-000016:8k_2_02:62]
EVOLV TECHNOLOGY

[0001805385-25-000016:8k_2_02:63]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT, GAAP GROSS MARGIN TO ADJUSTED GROSS MARGIN AND GAAP INCOME (LOSS) FROM OPERATIONS TO ADJUSTED OPERATING INCOME (LOSS)

[0001805385-25-000016:8k_2_02:64]
(In thousands)

[0001805385-25-000016:8k_2_02:65]
(Unaudited)

[0001805385-25-000016:8k_2_02:66]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue | $ | 42,850 |  |  | $ | 27,360 |  |  | $ | 107,401 |  |  | $ | 74,765 |  |
| Cost of revenue | 21,544 |  |  | 11,551 |  |  | 50,727 |  |  | 32,044 |  |
| Gross profit, GAAP | 21,306 |  |  | 15,809 |  |  | 56,674 |  |  | 42,721 |  |
| Stock-based compensation | 269 |  |  | 244 |  |  | 770 |  |  | 555 |  |
| Amortization of capitalized stock-based compensation | 114 |  |  | 23 |  |  | 324 |  |  | 52 |  |
| Non-recurring employee restructuring and other separation costs | — |  |  | — |  |  | 6 |  |  | — |  |
| Non-recurring inventory charges | — |  |  | 1,471 |  |  | — |  |  | 2,607 |  |
| Adjusted gross profit* | $ | 21,689 |  |  | $ | 17,547 |  |  | $ | 57,774 |  |  | $ | 45,935 |  |
| Gross margin % | 49.7 | % |  | 57.8 | % |  | 52.8 | % |  | 57.1 | % |
| Adjusted gross margin % | 50.6 | % |  | 64.1 | % |  | 53.8 | % |  | 61.4 | % |

[0001805385-25-000016:8k_2_02:67]
*Beginning in the three month period ended September 30, 2025, and on a go-forward basis, management has determined that the loss on disposal of leased equipment should no longer be considered a non-recurring expense, and accordingly, loss on disposal of leased equipment is now reflected within non-GAAP gross margins and adjusted loss from operations.

[0001805385-25-000016:8k_2_02:68]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Loss from operations, GAAP | $ | (8,596) |  |  | $ | (19,152) |  |  | $ | (40,478) |  |  | $ | (63,429) |  |
| Stock-based compensation | 5,390 |  |  | 7,507 |  |  | 15,816 |  |  | 21,364 |  |
| Amortization of capitalized stock-based compensation | 114 |  |  | 23 |  |  | 324 |  |  | 52 |  |
| Loss on impairment of lease equipment | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Non-recurring employee restructuring and other separation costs | 6 |  |  | — |  |  | 2,976 |  |  | 1,000 |  |
| Non-recurring inventory charges | — |  |  | 1,471 |  |  | — |  |  | 2,607 |  |
| Other non-recurring legal and regulatory costs | (36) |  |  | 2,339 |  |  | 9,504 |  |  | 5,000 |  |
| Adjusted loss from operations* | $ | (3,122) |  |  | $ | (7,603) |  |  | $ | (11,858) |  |  | $ | (33,197) |  |

[0001805385-25-000016:8k_2_02:69]
*Beginning this quarter, and on a go-forward basis, management has determined that the loss on disposal of leased equipment should no longer be considered a non-recurring expense, and accordingly, loss on disposal of leased equipment is now reflected within non-GAAP gross margins and adjusted loss from operations.

[0001805385-25-000016:8k_2_02:70]
EVOLV TECHNOLOGY

[0001805385-25-000016:8k_2_02:71]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA AND NET PROFIT MARGIN TO ADJUSTED EBITDA MARGIN

[0001805385-25-000016:8k_2_02:72]
(In thousands)

[0001805385-25-000016:8k_2_02:73]
(Unaudited)

[0001805385-25-000016:8k_2_02:74]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net loss | $ | (1,796) |  |  | $ | (30,443) |  |  | $ | (44,020) |  |  | $ | (38,297) |  |
| Depreciation & amortization | 6,541 |  |  | 4,575 |  |  | 17,859 |  |  | 11,933 |  |
| Stock-based compensation | 5,390 |  |  | 7,507 |  |  | 15,816 |  |  | 21,364 |  |
| Interest expense (income) | 277 |  |  | (628) |  |  | (335) |  |  | (2,394) |  |
| Provision for income taxes | — |  |  | — |  |  | 62 |  |  | — |  |
| Change in fair value of contingent earn-out liability | (7,521) |  |  | 8,321 |  |  | (2,297) |  |  | (15,092) |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | (2,178) |  |  | 2,056 |  |  | 69 |  |  | (2,218) |  |
| Change in fair value of public warrant liability | 2,578 |  |  | 1,576 |  |  | 6,160 |  |  | (5,461) |  |
| Loss on impairment of leased equipment | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Loss on disposal of leased equipment | 1,870 |  |  | — |  |  | 3,503 |  |  | — |  |
| Non-recurring employee restructuring and other separation costs | 6 |  |  | — |  |  | 2,976 |  |  | 1,000 |  |
| Non-recurring inventory charges | — |  |  | 1,471 |  |  | — |  |  | 2,607 |  |
| Other non-recurring legal and regulatory costs | (36) |  |  | 2,339 |  |  | 9,504 |  |  | 5,000 |  |
| Adjusted EBITDA | $ | 5,131 |  |  | $ | (3,017) |  |  | $ | 9,297 |  |  | $ | (21,349) |  |
| Net profit margin % | (4.2) | % |  | (111.3) | % |  | (41.0) | % |  | (51.2) | % |
| Impact of adjustments from Net loss to Adjusted EBITDA | 16.2 | % |  | 100.3 | % |  | 49.6 | % |  | 22.6 | % |
| Adjusted EBITDA margin % | 12.0 | % |  | (11.0) | % |  | 8.7 | % |  | (28.6) | % |

[0001805385-25-000016:8k_2_02:75]
EVOLV TECHNOLOGY

[0001805385-25-000016:8k_2_02:76]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001805385-25-000016:8k_2_02:77]
(In thousands, except share and per share data)

[0001805385-25-000016:8k_2_02:78]
(Unaudited)

[0001805385-25-000016:8k_2_02:79]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net loss | $ | (1,796) |  |  | $ | (30,443) |  |  | $ | (44,020) |  |  | $ | (38,297) |  |
| Stock-based compensation | 5,390 |  |  | 7,507 |  |  | 15,816 |  |  | 21,364 |  |
| Amortization of capitalized stock-based compensation | 114 |  |  | 23 |  |  | 324 |  |  | 52 |  |
| Change in fair value of contingent earn-out liability | (7,521) |  |  | 8,321 |  |  | (2,297) |  |  | (15,092) |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | (2,178) |  |  | 2,056 |  |  | 69 |  |  | (2,218) |  |
| Change in fair value of public warrant liability | 2,578 |  |  | 1,576 |  |  | 6,160 |  |  | (5,461) |  |
| Loss on impairment of lease equipment | — |  |  | 209 |  |  | — |  |  | 209 |  |
| Non-recurring employee restructuring and other separation costs | 6 |  |  | — |  |  | 2,976 |  |  | 1,000 |  |
| Non-recurring inventory charges | — |  |  | 1,471 |  |  | — |  |  | 2,607 |  |
| Other non-recurring legal and regulatory costs | (36) |  |  | 2,339 |  |  | 9,504 |  |  | 5,000 |  |
| Adjusted loss | $ | (3,443) |  |  | $ | (6,941) |  |  | $ | (11,468) |  |  | $ | (30,836) |  |
| Weighted average common shares outstanding – diluted | 172,790,098 |  |  | 157,709,229 |  |  | 166,327,570 |  |  | 155,760,149 |  |
| Adjusted loss per share – diluted | $ | (0.02) |  |  | $ | (0.04) |  |  | $ | (0.07) |  |  | $ | (0.20) |  |

[0001805385-25-000016:8k_2_02:80]
*Stock-based compensation, amortization of capitalized stock-based compensation, and non-recurring restructuring and other employee separation costs were recorded in the condensed consolidated statements of operations and comprehensive loss (income) as follows. Prior period amounts are being shown for comparative purposes:

[0001805385-25-000016:8k_2_02:81]
|  | Three Months Ended, |
|  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  | June 30,2025 |  | September 30,2025 |  |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | $ | — |  |  | $ | 5 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |  | $ | 17 |  |  | $ | 32 |  |  |  |
| Cost of subscription revenue | 91 |  |  | 110 |  |  | 169 |  |  | 154 |  |  | 137 |  |  | 167 |  |  | 146 |  |  |  |
| Cost of service revenue | 44 |  |  | 51 |  |  | 63 |  |  | 61 |  |  | 67 |  |  | 74 |  |  | 72 |  |  |  |
| Cost of license fee and other revenue | 3 |  |  | 7 |  |  | 8 |  |  | 10 |  |  | 7 |  |  | 24 |  |  | 19 |  |  |  |
| Research and development | 902 |  |  | 1,222 |  |  | 1,243 |  |  | 1,153 |  |  | 1,115 |  |  | 1,154 |  |  | 1,227 |  |  |  |
| Sales and marketing | 2,959 |  |  | 2,724 |  |  | 2,516 |  |  | 2,747 |  |  | 1,048 |  |  | 1,710 |  |  | 1,480 |  |  |  |
| General and administrative | 2,431 |  |  | 3,308 |  |  | 3,504 |  |  | (741) |  |  | 1,972 |  |  | 2,401 |  |  | 2,414 |  |  |  |
| Restructuring costs | — |  |  | — |  |  | — |  |  | — |  |  | 525 |  |  | — |  |  | — |  |  |  |
| Total stock-based compensation | $ | 6,430 |  |  | $ | 7,427 |  |  | $ | 7,507 |  |  | $ | 3,392 |  |  | $ | 4,879 |  |  | $ | 5,547 |  |  | $ | 5,390 |  |  |  |
| Amortization of capitalized stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of subscription revenue | $ | 8 |  |  | $ | 8 |  |  | $ | 13 |  |  | $ | 47 |  |  | $ | 59 |  |  | $ | 60 |  |  | $ | 63 |  |  |  |
| Cost of service revenue | 6 |  |  | 7 |  |  | 10 |  |  | 38 |  |  | 44 |  |  | 47 |  |  | 51 |  |  |  |
| Total amortization of capitalized stock-based compensation | $ | 14 |  |  | $ | 15 |  |  | $ | 23 |  |  | $ | 85 |  |  | $ | 103 |  |  | $ | 107 |  |  | $ | 114 |  |  |  |
| Non-recurring employee restructuring and other separation costs: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of service revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |  | — |  |  |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 31 |  |  | — |  |  |  |
| Sales and marketing | — |  |  | 140 |  |  | — |  |  | 63 |  |  | — |  |  | 613 |  |  | $ | 6 |  |  |  |
| General and administrative | — |  |  | — |  |  | — |  |  | 1,997 |  |  | — |  |  | 183 |  |  | — |  |  |  |
| Restructuring costs | — |  |  | 860 |  |  | — |  |  | — |  |  | 2,137 |  |  | — |  |  | — |  |  |  |
| Total non-recurring employee restructuring and other separation costs | $ | — |  |  | $ | 1,000 |  |  | $ | — |  |  | $ | 2,060 |  |  | $ | 2,137 |  |  | $ | 833 |  |  | $ | 6 |  |  |  |
