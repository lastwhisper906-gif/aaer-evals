# EVLV 10-K controls and the auditor's report


## auditors_report

[0001805385-26-000012:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001805385-26-000012:auditors_report:2]
To the Board of Directors and Stockholders of Evolv Technologies Holdings, Inc.

[0001805385-26-000012:auditors_report:3]
Opinion on the Financial Statements

[0001805385-26-000012:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Evolv Technologies Holdings, Inc. and its subsidiaries (the “Company”) as of December 31, 2025 and 2024, and the related consolidated statements of operations and comprehensive loss, of stockholders' equity (deficit) and of cash flows for the years then ended, including the related notes (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of December 31, 2025 and 2024, and the results of its operations and its cash flows for the years then ended in conformity with accounting principles generally accepted in the United States of America.

[0001805385-26-000012:auditors_report:5]
Basis for Opinion

[0001805385-26-000012:auditors_report:6]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s consolidated financial statements based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001805385-26-000012:auditors_report:7]
We conducted our audits of these consolidated financial statements in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud. The Company is not required to have, nor were we engaged to perform, an audit of its internal control over financial reporting. As part of our audits we are required to obtain an understanding of internal control over financial reporting but not for the purpose of expressing an opinion on the effectiveness of the Company's internal control over financial reporting. Accordingly, we express no such opinion.

[0001805385-26-000012:auditors_report:8]
Our audits included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001805385-26-000012:auditors_report:9]
Critical Audit Matters

[0001805385-26-000012:auditors_report:10]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001805385-26-000012:auditors_report:11]
Revenue Recognition - Products, Subscription, Service, and License Fees Revenues

[0001805385-26-000012:auditors_report:12]
As described in Notes 2 and 5 to the consolidated financial statements, the Company derives its revenue primarily from (1) subscription arrangements generally accounted for as operating leases, including security-as-a-service (SaaS) and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers, and (4) license fees. Management recognizes revenue when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the Company expects to receive in exchange for those goods or services. The Company’s contracts may include multiple performance obligations when customers purchase a combination of products and services. For multiple performance obligation arrangements, management allocates the contract’s transaction price to each performance obligation on a relative standalone selling price basis. Revenue related to products, subscription, service, and license fees for the year ended December 31, 2025 totaled $142.9 million.

[0001805385-26-000012:auditors_report:13]
The principal considerations for our determination that performing procedures relating to revenue recognition for products, subscription, service, and license fees revenues is a critical audit matter are a high degree of auditor subjectivity and effort in performing procedures and evaluating audit evidence related to revenue recognition. As disclosed by management, material weaknesses were identified related to this matter.

[0001805385-26-000012:auditors_report:14]
67

[0001805385-26-000012:auditors_report:15]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included, among others (i) evaluating and determining the nature and extent of audit procedures performed and evidence obtained that are responsive to the material weaknesses identified; (ii) obtaining an understanding of management’s process for identifying and evaluating terms and conditions in contracts, including evaluating management’s determination of the impact of those terms and conditions on revenue recognition; (iii) for a sample of revenue transactions, (a) confirming terms and conditions of sales arrangements directly with customers, including performing alternative procedures when responses were not received, (b) testing the completeness and accuracy of management’s identification and evaluation of terms and conditions by  inspecting contracts, (c) testing revenue recognized by obtaining and inspecting source documents, such as contracts, purchase orders, invoices, proof of delivery, and subsequent cash receipts, (d) testing the timing of recognition of revenue transactions, and (e) testing the determination of the standalone selling price for contracts that include multiple performance obligations and testing the completeness and accuracy of the underlying data used by management in determining the standalone selling price allocated to each performance obligation.

[0001805385-26-000012:auditors_report:16]
/s/ PricewaterhouseCoopers LLP

[0001805385-26-000012:auditors_report:17]
Boston, Massachusetts

[0001805385-26-000012:auditors_report:18]
March 10, 2026

[0001805385-26-000012:auditors_report:19]
We have served as the Company’s auditor since 2015.

[0001805385-26-000012:auditors_report:20]
68

[0001805385-26-000012:auditors_report:21]
EVOLV TECHNOLOGIES HOLDINGS, INC.


## item_9a

[0001805385-26-000012:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0001805385-26-000012:item_9a:2]
Limitations on effectiveness of controls and procedures

[0001805385-26-000012:item_9a:3]
We maintain disclosure controls and procedures that are designed to ensure that information required to be disclosed in the reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms, and that such information is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate, to allow timely decisions regarding required disclosures. In designing and evaluating our disclosure controls and procedures, management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply judgment in evaluating the benefits of our controls and procedures relative to their costs.

[0001805385-26-000012:item_9a:4]
Evaluation of disclosure controls and procedures

[0001805385-26-000012:item_9a:5]
Our management, with the participation of our principal executive officer and principal financial officer, evaluated, as of the end of the period covered by this Annual Report on Form 10-K, the effectiveness of our disclosure controls and procedures (as that term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act). Based on that evaluation, our principal executive officer and principal financial officer concluded that our disclosure controls and procedures were not effective as of December 31, 2025, due to the material weaknesses in our internal control over financial reporting as described below.

[0001805385-26-000012:item_9a:6]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001805385-26-000012:item_9a:7]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as that term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our management, including our principal executive officer and principal financial officer, conducted an assessment as of December 31, 2025 of the effectiveness of our internal control over financial reporting based on the criteria set forth in Internal Control–Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this assessment, management concluded that, as of December 31, 2025, our internal control over financial reporting was not effective due to the material weaknesses described below.

[0001805385-26-000012:item_9a:8]
A material weakness is a deficiency, or combination of deficiencies, in internal control over financial reporting, such that there is reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. The material weaknesses are as follows:

[0001805385-26-000012:item_9a:9]
•We did not design and maintain an effective control environment commensurate with our financial reporting requirements. Specifically, we lacked a sufficient complement of personnel with an appropriate level of internal controls and accounting knowledge, training and experience commensurate with our financial reporting requirements. The limited personnel resulted in our inability to consistently establish appropriate authorities and responsibilities in pursuit of our financial reporting objectives, as demonstrated by, among other things, insufficient segregation of duties in our finance and accounting functions;

[0001805385-26-000012:item_9a:10]
•We did not design and maintain effective controls in response to the risks of material misstatement as changes to existing controls or the implementation of new controls were not sufficient to respond to changes to the risks of material misstatement to financial reporting;

[0001805385-26-000012:item_9a:11]
•We did not design and maintain effective controls over the period-end financial reporting process to achieve complete, accurate, and timely financial accounting, reporting and disclosures, including the classification of various accounts in the financial statements and the presentation and disclosure of items in the consolidated statements of cash flows;

[0001805385-26-000012:item_9a:12]
•We did not design and maintain effective controls to analyze, account for and disclose non-routine, unusual or complex transactions. Specifically, we did not design and maintain controls to timely analyze and account for debt modifications and extinguishments, convertible notes, warrant instruments, non-routine complex revenue transactions including the leasing of products and transfer of inventory for leased assets into property plant and equipment, merger transactions, and the accounting and valuation of earn out liabilities; and

[0001805385-26-000012:item_9a:13]
•We did not design and maintain formal accounting policies, procedures, and controls to achieve complete, accurate, and timely financial accounting, reporting and disclosures, including controls over the preparation and review of account reconciliations and journal entries, and control activities related to all significant accounts and disclosures.

[0001805385-26-000012:item_9a:14]
The material weaknesses in the control environment and risk assessment resulted in the restatement of the consolidated financial statements for the annual periods ended December 31, 2022 and 2023, and the quarterly periods included in such fiscal years beginning with the second quarter of 2022, and for the quarterly periods as of and for the periods ended March 31, 2024 and June 30, 2024; as well as adjustments to the consolidated annual financial statements for the year ended December 31, 2024, and the consolidated financial statements for the quarterly period ended September 30, 2024, that were recorded prior to the issuance of those financial statements.

[0001805385-26-000012:item_9a:15]
The material weaknesses related to the control environment, risk assessment, lack of effective controls over the period-end financial reporting process, lack of effective controls related to non-routine, unusual or complex transactions, and the lack of effective control activities related to all significant accounts and disclosures resulted in:

[0001805385-26-000012:item_9a:16]
•the restatement of the Company’s financial statements as of and for the three and six months ended June 30, 2023;

[0001805385-26-000012:item_9a:17]
•the revision of the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022; and

[0001805385-26-000012:item_9a:18]
•adjustments and certain immaterial misstatements in the consolidated financial statements to prepaid and other current assets, accounts payable and accrued liabilities, long-term and short-term debt, convertible notes, contingent earn-out liabilities, change in fair value of contingent earn-out liability, equity, commission assets, contract assets, to-be-leased assets, revenue, deferred revenue, accounts receivable, inventory, property plant and equipment, cost of sales, founders shares and various expense line items and related financial statement disclosures as of and for the years ended December 31, 2019, 2020, 2021, 2022, 2023, 2024 and 2025; as well as certain quarterly periods within those years.

[0001805385-26-000012:item_9a:19]
Additionally, the material weaknesses could result in a misstatement of the consolidated financial statements and disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0001805385-26-000012:item_9a:20]
In addition to the foregoing, we did not design and maintain effective controls over information technology (“IT”) general controls for information systems that are relevant to the preparation of our consolidated financial statements, specifically, with respect to: (i) program change management controls for financial systems to ensure that IT program and data changes affecting financial IT applications and underlying accounting records are identified, tested, authorized, and implemented appropriately; (ii) user access controls to ensure appropriate segregation of duties and that adequately restrict user and privileged access to financial applications, programs, and data to appropriate company personnel; (iii) computer operations controls to ensure that critical batch jobs are monitored and data backups are authorized and monitored; and (iv) testing and approval controls for program development to ensure that new software development is aligned with business and IT requirements. These IT deficiencies did not result in a misstatement to the consolidated financial statements; however, the deficiencies, when aggregated, could impact maintaining effective segregation of duties, as well as the effectiveness of IT-dependent controls (such as automated controls that address the risk of material misstatement to one or more assertions, along with the IT controls and underlying data that support the effectiveness of system-generated data and reports) that could result in misstatements potentially impacting all financial statement accounts and disclosures that would not be prevented or detected. Accordingly, management has determined these deficiencies in the aggregate constitute a material weakness.

[0001805385-26-000012:item_9a:21]
This Annual Report on Form 10-K does not include an attestation report of our independent registered public accounting firm on management’s assessment regarding internal control over financial reporting due to an exemption established by the SEC for non-accelerated filers.

[0001805385-26-000012:item_9a:22]
Remediation Plan for the Remaining Material Weaknesses

[0001805385-26-000012:item_9a:23]
We continue to be focused on designing and implementing effective internal controls to improve our internal control over financial reporting and remediate the material weaknesses. Actions taken to date include:

[0001805385-26-000012:item_9a:24]
•We have hired additional accounting personnel to bolster our reporting, technical accounting, and internal control capabilities during 2025, and will continue to monitor and evaluate our personnel requirements based on future company growth and our ability to successfully achieve our objectives. Additionally, we designed and implemented new controls as well as re-designed existing controls to formalize roles and review responsibilities to align with our team’s skills and experience and enhanced controls over segregation of duties;

[0001805385-26-000012:item_9a:25]
•We have enhanced the competencies of our accounting function including the hiring of a new Chief Accounting Officer (“CAO”) in January 2025. Our CAO has extensive public company experience and has strengthened our internal accounting team by providing technical accounting oversight over our financial reporting and disclosure processes and controls. Additionally, we hired a new Chief Revenue Officer in February 2025 to provide leadership and accountability over our sales agreement and revenue recognition accounting processes;

[0001805385-26-000012:item_9a:26]
•We have designed and implemented additional review and training procedures within Evolv's accounting and finance functions to enhance knowledge and understanding of internal control over financial reporting;

[0001805385-26-000012:item_9a:27]
•We have performed, and will continue to perform, a financial statement risk assessment in order to identify material financial statement line items for which key controls are needed in order to ensure complete and accurate financial reporting and have incorporated this risk assessment into our ongoing internal control evaluation process.

[0001805385-26-000012:item_9a:28]
•In January 2025, we engaged a large national advisory firm to assist in the design and implementation of control activities and to strengthen the skills of personnel involved in the business processes supporting the Company’s significant accounts and disclosures.

[0001805385-26-000012:item_9a:29]
•Over the past year, we continued to design and implement controls related to, among other items, (i) the period-end financial reporting process and classification of various accounts in our consolidated financial statements, including the presentation and disclosure of items in the consolidated statements of cash flows, (ii) timely identification and accounting for non-routine, unusual and complex transactions, including controls over the preparation and review of accounting memoranda addressing these matters, (iii) revenue recognition, including non-routine complex revenue transactions that may also include the leasing of products and the recording of revenue transactions in the appropriate period, (iv) completeness and accuracy of accounts payable and accrued liabilities, and (v) the preparation and review of journal entries and account reconciliations to ensure proper segregation of duties.

[0001805385-26-000012:item_9a:30]
In addition to the remedial actions taken to date, our ongoing efforts include:

[0001805385-26-000012:item_9a:31]
•We are in process of designing and implementing formal accounting policies, procedures and controls to achieve complete, accurate and timely financial accounting, reporting and disclosures.

[0001805385-26-000012:item_9a:32]
•We are in process of designing and implementing information technology general controls for all relevant information systems, including controls over program change management, the review, approval and update of user access rights and privileges, controls over batch jobs and data backups, and program development approvals and testing for new systems; and

[0001805385-26-000012:item_9a:33]
•During 2025 we made significant investments in our technology platforms including a commitment to implement new systems related to quoting, commissions and order processing in 2026 as well as plan to

[0001805385-26-000012:item_9a:34]
implement a new instance of our financial Enterprise Resource Planning Tool (“ERP”) during 2027 to further automate processes and reduce the risk of manual errors.

[0001805385-26-000012:item_9a:35]
The process of designing and maintaining effective internal control over financial reporting is a continuous effort that requires management to anticipate and react to changes in our business, economic, and regulatory environments and to expend significant resources. As we continue to evaluate our internal control over financial reporting, we may take additional actions to remediate the material weaknesses or modify the remediation actions described above.

[0001805385-26-000012:item_9a:36]
While we continue to devote significant time and attention to these remediation efforts, the material weaknesses will not be considered remediated until management completes the design and implementation of the actions described above and the controls operate for a sufficient period of time, and management has concluded, through testing, that these controls are effective.

[0001805385-26-000012:item_9a:37]
Remediation of Previously Disclosed Material Weaknesses

[0001805385-26-000012:item_9a:38]
As previously reported in Item 9A of our Annual Report on Form 10-K for the fiscal year ended December 31, 2024, management identified the following material weaknesses in our internal control over financial reporting, which were remediated as of December 31, 2025:

[0001805385-26-000012:item_9a:39]
•We did not design and maintain an effective control environment as we did not demonstrate a commitment to maintaining integrity and ethical values. Specifically, we did not sufficiently promote, monitor or enforce appropriate accounting policies and procedures, thereby resulting in inappropriate recognition of revenue due to the failure to consider the impact of certain extracontractual terms and conditions in sales agreements on the amount and timing of revenue to be recognized.

[0001805385-26-000012:item_9a:40]
•We did not design and maintain effective controls for communicating and sharing information between the sales, accounting and finance departments. Specifically, the accounting and finance departments were not consistently provided the complete and adequate support, documentation, and information including the nature of relationships with certain customers to record revenue transactions within the financial statements timely, completely and accurately. Additionally, there have been instances in which indications of extra-contractual terms and conditions in sales arrangements were not disclosed to the Audit Committee of the Board and external auditors.

[0001805385-26-000012:item_9a:41]
Management conducted a comprehensive, multi‑phase remediation effort throughout 2025, and has concluded that the material weaknesses listed above were remediated as of December 31, 2025. A summary of the key remediation actions is provided below.

[0001805385-26-000012:item_9a:42]
1. Commitment to Maintaining Integrity and Ethical Values

[0001805385-26-000012:item_9a:43]
To address the lack of an effective control environment due to not demonstrating a commitment to integrity and ethical values, management implemented a broad set of enhancements:

[0001805385-26-000012:item_9a:44]
•We reset our leadership and governance by installing new executives, enhancing Audit Committee oversight, and strengthening processes to ensure transparent, timely communication of revenue and contractual matters to leadership, and the Audit Committee.

[0001805385-26-000012:item_9a:45]
•We strengthened our ethics and compliance program by reinforcing values and leadership messaging, rolling out an updated Code of Conduct with mandatory training, expanding and empowering the compliance function, and implementing a new employee hotline.

[0001805385-26-000012:item_9a:46]
•We reinforced culture and compliance by delivering targeted ethics and fraud training while redesigning sales compensation to discourage inappropriate practices and promote compliant behavior.

[0001805385-26-000012:item_9a:47]
•We implemented monitoring controls to ensure required training courses were completed and recurring training cycles are completed going forward.

[0001805385-26-000012:item_9a:48]
2. Communicating and Sharing Information Between the Sales, Accounting and Finance Departments

[0001805385-26-000012:item_9a:49]
To address deficiencies in communication between sales, accounting, and finance, which led to incomplete, inaccurate, or delayed information relevant to revenue recognition, management executed the following:

[0001805385-26-000012:item_9a:50]
•Formalized communication protocols

[0001805385-26-000012:item_9a:51]
•Implemented a new Deal Desk policy and controls including enhanced sales certifications and contract attestations, ensuring all financially significant terms are identified, documented, and communicated to accounting and finance before contract execution.

[0001805385-26-000012:item_9a:52]
•Standardized reseller and channel partner agreements to reduce variability in key terms impacting revenue recognition.

[0001805385-26-000012:item_9a:53]
•Augmented the cross‑functional Disclosure Committee with additional contract‑terms review procedures

[0001805385-26-000012:item_9a:54]
•Designed and implemented Deal Desk review and sales certification controls with expanded documentation requirements

[0001805385-26-000012:item_9a:55]
•Implemented quarterly reporting to the Audit Committee on ethics hotline activity, investigations, and culture indicators.

[0001805385-26-000012:item_9a:56]
•Established guiding principles emphasizing transparency and completeness of communication with the Board.

[0001805385-26-000012:item_9a:57]
Management has evaluated the design, implementation, and operating effectiveness of the re-designed and enhanced controls and concluded that the controls are appropriately designed and are operating effectively as of December 31, 2025.   Therefore, the material weaknesses have been remediated as of December 31, 2025.

[0001805385-26-000012:item_9a:58]
Changes in Internal Control over Financial Reporting

[0001805385-26-000012:item_9a:59]
There were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended December 31, 2025 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
