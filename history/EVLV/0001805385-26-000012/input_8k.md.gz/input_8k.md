# EVLV 8-K — 0001805385-26-000011 filed 2026-03-10

## item codes, every 8-K on or before 2026-03-10

- 2026-03-10 0001805385-26-000011 — 2.02, 9.01
- 2026-02-12 0001805385-26-000003 — 5.02, 7.01, 9.01
- 2025-11-13 0001805385-25-000016 — 2.02, 9.01
- 2025-08-14 0001805385-25-000008 — 2.02, 5.02, 9.01
- 2025-07-30 0001104659-25-071952 — 1.01, 9.01
- 2025-07-01 0001104659-25-064786 — 7.01
- 2025-06-23 0001628280-25-032646 — 5.07
- 2025-05-20 0001628280-25-026833 — 2.02, 9.01
- 2025-04-28 0001628280-25-020351 — 2.02, 9.01
- 2025-04-23 0001104659-25-037732 — 5.02, 7.01, 9.01
- 2025-04-22 0001104659-25-037530 — 3.01, 7.01, 9.01
- 2025-02-04 0001104659-25-008892 — 5.02, 7.01, 9.01
- 2025-01-24 0001104659-25-005796 — 5.02, 7.01, 8.01, 9.01
- 2025-01-23 0001628280-25-002293 — 2.02, 2.05, 7.01, 9.01
- 2024-12-23 0001104659-24-131278 — 5.02
- 2024-12-12 0001104659-24-128006 — 5.02
- 2024-12-09 0001104659-24-126542 — 5.02, 7.01, 9.01
- 2024-11-22 0001104659-24-122102 — 3.01, 7.01, 9.01
- 2024-11-21 0001104659-24-121349 — 5.02, 7.01, 8.01, 9.01
- 2024-10-31 0001104659-24-112868 — 5.02, 7.01, 9.01
- 2024-10-25 0001104659-24-111310 — 4.02, 7.01, 9.01
- 2024-08-08 0001628280-24-036115 — 2.02, 9.01
- 2024-06-04 0001628280-24-026572 — 5.07
- 2024-05-09 0001628280-24-022265 — 2.02, 9.01
- 2024-02-29 0001628280-24-007980 — 2.02, 9.01
- 2024-02-20 0001104659-24-025077 — 7.01, 9.01
- 2024-01-31 0001628280-24-002618 — 5.03, 9.01
- 2023-11-09 0001628280-23-038267 — 2.02, 9.01
- 2023-11-06 0001104659-23-114499 — 5.02
- 2023-10-25 0001628280-23-035145 — 4.02
- 2023-10-12 0001104659-23-108693 — 2.02, 7.01, 9.01
- 2023-08-10 0001628280-23-028861 — 2.02, 9.01
- 2023-06-02 0001628280-23-020680 — 5.07
- 2023-05-10 0001628280-23-017243 — 2.02, 9.01
- 2023-04-03 0001628280-23-010402 — 1.02, 2.04, 8.01, 9.01
- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2026-03-10

- 2025-05-15 0001104659-25-049608 — NT 10-Q, for the period ended 2025-03-31
- 2025-03-31 0001104659-25-029637 — NT 10-K, for the period ended 2024-12-31
- 2024-11-13 0001104659-24-117677 — NT 10-Q, for the period ended 2024-09-30
- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001805385-26-000011:8k_2_02:1]
EX-99.1
2
evlv-20260310exx991.htm
EX-99.1

[0001805385-26-000011:8k_2_02:2]
Document

[0001805385-26-000011:8k_2_02:3]
Exhibit 99.1

[0001805385-26-000011:8k_2_02:4]
Evolv Technology Reports Fourth Quarter Financial Results

[0001805385-26-000011:8k_2_02:5]
—  Company Raises Outlook for 2026 —

[0001805385-26-000011:8k_2_02:6]
•Q4'25 Revenue of $38.5 million, up 32% year-over-year

[0001805385-26-000011:8k_2_02:7]
•Q4'25 Ending ARR1 of $120.5 million, up 21% year-over-year

[0001805385-26-000011:8k_2_02:8]
•Q4'25 Net Income of $10.9 million, with Net Profit Margin of 28%

[0001805385-26-000011:8k_2_02:9]
•Q4'25 Adjusted EBITDA2 of $1.8 million, with Adjusted EBITDA Margin2 of 5%

[0001805385-26-000011:8k_2_02:10]
•Q4'25 Ending Cash, Cash Equivalents and Marketable Securities of $69.0 million, up $12.8 million sequentially

[0001805385-26-000011:8k_2_02:11]
Waltham, Massachusetts – March 10, 2026 – Evolv Technologies Holdings, Inc (NASDAQ: EVLV), a leading security technology company pioneering AI-based solutions designed to help create safer experiences, today announced financial results for the year ended December 31, 2025.

[0001805385-26-000011:8k_2_02:12]
“We are pleased to be reporting solid fourth quarter results, which capped a year of significant improvement across the Company,” said John Kedzierski, President and Chief Executive Officer of Evolv Technology. ”We continue to deliver advanced weapons screening capabilities at scale for more than 1,200 customers worldwide through a tightly integrated platform that combines proprietary hardware, real‑world visitor data sets, and AI‑driven software, delivered via long‑term subscriptions that foster durable customer relationships and high‑quality recurring revenue. Looking ahead, we believe AI‑based weapons screening will continue to become increasingly prevalent, and we look forward to capitalizing on this still‑nascent market opportunity to help make the world a safer place to live, work, learn, and play."

[0001805385-26-000011:8k_2_02:13]
Results for the Fourth Quarter of 2025

[0001805385-26-000011:8k_2_02:14]
Total revenue for the fourth quarter of 2025 was $38.5 million, an increase of 32% compared to $29.1 million for the fourth quarter of 2024. Revenue for the fourth quarter of 2025 was primarily driven by strong new customer additions and continued expansion of deployments across the existing customer base. Annual Recurring Revenue (“ARR”)1 was $120.5 million at the end of fourth quarter of 2025, an increase of 21% compared to $99.4 million at the end of the fourth quarter of 2024. Net income for the fourth quarter of 2025 was $10.9 million, or $0.06 per basic share and $0.06 per diluted share, compared to net loss of $(15.7) million, or $(0.10) per basic and diluted share, in the fourth quarter of 2024. Adjusted earnings (loss)2 for the fourth quarter of 2025 was $(5.3) million, or $(0.03) per diluted share, compared to adjusted earnings (loss)2 of $(4.4) million, or $(0.03) per diluted share, for the fourth quarter of 2024. Adjusted EBITDA2 for the fourth quarter of 2025 was $1.8 million compared to $0.4 million in the fourth quarter of 2024. As of December 31, 2025, the Company had cash, cash equivalents and marketable securities of $69.0 million.

[0001805385-26-000011:8k_2_02:15]
Results for 2025

[0001805385-26-000011:8k_2_02:16]
Total revenue for the twelve months ended December 31, 2025 was $145.9 million, an increase of 40% compared to $103.9 million for the twelve months ended December 31, 2024. Net loss for the twelve months ended December 31, 2025 was $(33.1) million, or $(0.20) per basic and diluted share, compared to $(54.0) million, or $(0.34) per basic and diluted share, in the twelve months ended December 31, 2024. Adjusted earnings (loss)2 for the twelve months ended

[0001805385-26-000011:8k_2_02:17]
December 31, 2025 was $(16.8) million, or $(0.10) per diluted share, compared to adjusted earnings (loss)2 of $(35.3) million, or $(0.23) per diluted share, for the twelve months ended December 31, 2024. Adjusted EBITDA2 for the twelve months ended December 31, 2025 was $11.1 million compared to $(21.0) million in the twelve months ended December 31, 2024.

[0001805385-26-000011:8k_2_02:18]
The following table summarizes the breakdown of recurring and non-recurring revenue3 for each period presented:

[0001805385-26-000011:8k_2_02:19]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2025 |  | 2024 |  | % Change |  | 2025 |  | 2024 |  | % Change |
| Recurring revenue | $ | 29,547 |  |  | $ | 23,678 |  |  | 25 | % |  | $ | 112,098 |  |  | $ | 87,419 |  |  | 28 | % |
| Non-recurring revenue | 8,957 |  |  | 5,422 |  |  | 65 | % |  | 33,807 |  |  | 16,446 |  |  | 106 | % |
| Total revenue | $ | 38,504 |  |  | $ | 29,100 |  |  | 32 | % |  | $ | 145,905 |  |  | $ | 103,865 |  |  | 40 | % |

[0001805385-26-000011:8k_2_02:20]
The following table summarizes operating cash flows for each period presented:

[0001805385-26-000011:8k_2_02:21]
|  |  |  | Twelve Months EndedDecember 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Net loss |  |  |  |  | $ | (33,138) |  |  | $ | (54,017) |  |
| Adjustments to reconcile net loss to net cash provided by operating activities |  |  |  |  | 38,542 |  |  | 22,504 |  |
| Changes in operating assets and liabilities |  |  |  |  | 13,265 |  |  | 660 |  |
| Net cash provided by (used in) operating activities |  |  |  |  | $ | 18,669 |  |  | $ | (30,853) |  |

[0001805385-26-000011:8k_2_02:22]
Company Comments on Outlook for 2026

[0001805385-26-000011:8k_2_02:23]
The Company today commented on its business outlook for 2026. The Company's outlook is based on the current indications for its business, which may change at any time.  The Company expects total revenues in 2026 to be between $172 to $178 million, reflecting growth of approximately 18% to 22% year-over-year.  The Company expects ending ARR at December 31, 2026 to increase to approximately $145 to $150 million, reflecting growth of approximately 20% to 25% year-over-year.  The Company continues to expect ARR growth to exceed total revenue growth as previously disclosed changes to the Company's selling model and pricing continue to reshape contractual revenue recognition toward a higher mix of recurring revenue and reduced one‑time revenue. The Company currently expects approximately 50% of the Company’s new unit deployments in 2026 to be delivered under the Company’s pure subscription model, with the remaining 50% deployed through the Company’s purchase‑subscription model.  The Company expects to deliver positive full year Adjusted EBITDA1 in 2026 with Adjusted EBITDA1 margins in the high single digits.

[0001805385-26-000011:8k_2_02:24]
| Estimate |  | Issued November 13, 2025 |  | Issued March 10, 2026 |
| Total Revenue (Millions) |  | $160-$165 |  | $172-$178 |
| Ending ARR at 12/31/26 (Millions) |  | n/a |  | $145-$150 |
| Adjusted EBITDA Margin2 |  | n/a |  | High Single Digits |

[0001805385-26-000011:8k_2_02:25]
Company to Host Live Conference Call and Webcast

[0001805385-26-000011:8k_2_02:26]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business.  The conference call will be webcast live at http://ir.evolvtechnology.com.

[0001805385-26-000011:8k_2_02:27]
About Evolv Technology

[0001805385-26-000011:8k_2_02:28]
Evolv Technologies Holdings, Inc (NASDAQ: EVLV) is designed to transform human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics. Its mission is to transform security to create a safer world to live, work, learn, and play. Evolv has digitally transformed the gateways in many places where people gather by enabling seamless integration combined with powerful analytics and insights. Evolv’s advanced systems have scanned more than four billion people since 2019. Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) 2024 New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category, as well as Sport Business Journal’s (SBJ) 2024 awards for “Best In Fan Experience Technology” and “Best In Sports Technology”. Evolv®, Evolv Express®, Evolv Insights®, Evolv Visual Gun Detection™, Evolv eXpedite™, and Evolv Eva™ are registered trademarks or trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit evolv.com.

[0001805385-26-000011:8k_2_02:29]
1 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001805385-26-000011:8k_2_02:30]
2 Non-GAAP Financial Measures In this press release, the Company’s adjusted gross profit (loss), adjusted gross margin, adjusted operating expenses, adjusted operating income (loss), adjusted EBITDA, adjusted EBITDA margin, adjusted earnings (loss), and adjusted earnings (loss) per diluted share are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit and adjusted gross margin exclude stock-based compensation expense, amortization of capitalized stock-based compensation, loss on impairment of intangible asset, non-recurring employee restructuring and other separation costs, and non-recurring inventory charges, which management believes provides a more meaningful representation of contribution margin. Adjusted operating expenses is defined as operating expenses less stock-based compensation expense, loss on impairment of leased equipment, non-recurring employee restructuring and other separation costs, and other non-recurring legal and regulatory costs, which management believes provides a more meaningful representation of on-going operating expense levels. Other non-recurring legal and regulatory costs include non-recurring legal, accounting and professional fees related to the internal investigation, subsequent restatement, certain non-recurring regulatory, litigation and legal matters, as well as fees related to the resolution of the Securities and Exchange Commission investigation, net of estimated insurance recoveries. Adjusted operating income (loss) is defined as loss from operations, excluding stock-based compensation expense, amortization of capitalized stock-based compensation, loss on impairment of leased equipment, loss on impairment of intangible asset, non-recurring employee restructuring and other separation costs, non-recurring inventory charges, and other non-recurring legal and regulatory costs, which management believes provides a more meaningful representation of operating results. Adjusted EBITDA and Adjusted EBITDA margin is defined as net income (loss) plus depreciation and amortization, stock-based compensation, interest expense (income), provision for income taxes, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of leased equipment, loss on impairment of intangible asset, loss on disposal of leased equipment, non-recurring employee restructuring and other separation costs, non-recurring inventory charges, and other non-recurring legal and regulatory costs, which management believes provides a more meaningful representation of operating results. Adjusted earnings (loss) and Adjusted earnings (loss) per diluted share are defined as net income (loss) plus stock-based compensation, amortization of capitalized stock-based compensation, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of leased equipment, loss on impairment of intangible asset, non-recurring employee restructuring and other separation costs, non-recurring inventory charges, and other non-recurring legal and regulatory costs, which management believes provides a more meaningful representation of operating results. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operating performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release. The Company is unable to provide a

[0001805385-26-000011:8k_2_02:31]
reconciliation of Adjusted EBITDA to Net Income (Loss) and Adjusted EBITDA Margin to Net Profit Margin, each measure's most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact these GAAP financial measures are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001805385-26-000011:8k_2_02:32]
3 Recurring revenue includes the recurring portion of revenue associated with pure subscription contracts and hardware purchase subscription contracts. Non-recurring revenue includes revenue that is non-recurring in nature, such as product revenue, shipping revenue, and revenue from installation, training, and professional services.

[0001805385-26-000011:8k_2_02:33]
Forward-Looking Statements

[0001805385-26-000011:8k_2_02:34]
You should review this press release and the documents that we reference in this press release and related presentation materials with the understanding that our actual future results, levels of activity, performance and achievements may be materially different from what we expect. We qualify all of our forward-looking statements by these cautionary statements. Except as required by applicable law, we do not plan to publicly update or revise any forward-looking statements contained in this press release and related presentation materials, whether as a result of any new information, future events or otherwise.

[0001805385-26-000011:8k_2_02:35]
Investor Relations:

[0001805385-26-000011:8k_2_02:36]
Brian Norris

[0001805385-26-000011:8k_2_02:37]
Senior Vice President of Finance and Investor Relations

[0001805385-26-000011:8k_2_02:38]
bnorris@evolvtechnology.com

[0001805385-26-000011:8k_2_02:39]
EVOLV TECHNOLOGY

[0001805385-26-000011:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (LOSS)

[0001805385-26-000011:8k_2_02:41]
(In thousands, except share and per share data)

[0001805385-26-000011:8k_2_02:42]
(Unaudited)

[0001805385-26-000011:8k_2_02:43]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 7,545 |  |  | $ | 1,675 |  |  | $ | 21,637 |  |  | $ | 6,464 |  |
| Subscription revenue | 21,717 |  |  | 17,263 |  |  | 83,839 |  |  | 65,046 |  |
| Service revenue | 8,151 |  |  | 6,564 |  |  | 29,375 |  |  | 23,467 |  |
| License fee and other revenue | 1,091 |  |  | 3,598 |  |  | 11,054 |  |  | 8,888 |  |
| Total revenue | 38,504 |  |  | 29,100 |  |  | 145,905 |  |  | 103,865 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 7,825 |  |  | 2,166 |  |  | 24,320 |  |  | 10,735 |  |
| Cost of subscription revenue | 8,971 |  |  | 8,604 |  |  | 36,684 |  |  | 27,846 |  |
| Cost of service revenue | 2,657 |  |  | 1,476 |  |  | 8,410 |  |  | 5,225 |  |
| Cost of license fee and other revenue | 423 |  |  | 113 |  |  | 1,189 |  |  | 597 |  |
| Total cost of revenue | 19,876 |  |  | 12,359 |  |  | 70,603 |  |  | 44,403 |  |
| Gross profit | 18,628 |  |  | 16,741 |  |  | 75,302 |  |  | 59,462 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,412 |  |  | 5,390 |  |  | 20,619 |  |  | 23,446 |  |
| Sales and marketing | 11,132 |  |  | 13,455 |  |  | 45,626 |  |  | 60,637 |  |
| General and administrative | 10,069 |  |  | 16,759 |  |  | 54,858 |  |  | 56,602 |  |
| Restructuring costs | — |  |  | — |  |  | 2,662 |  |  | 860 |  |
| Loss on impairment of property and equipment | — |  |  | 15 |  |  | — |  |  | 224 |  |
| Total operating expenses | 26,613 |  |  | 35,619 |  |  | 123,765 |  |  | 141,769 |  |
| Loss from operations | (7,985) |  |  | (18,878) |  |  | (48,463) |  |  | (82,307) |  |
| Other income, net: |  |  |  |  |  |  |  |
| Interest expense | (1,018) |  |  | — |  |  | (1,732) |  |  | — |  |
| Interest income | 487 |  |  | 548 |  |  | 1,536 |  |  | 2,942 |  |
| Other income (expense), net | (18) |  |  | (50) |  |  | 99 |  |  | (83) |  |
| Change in fair value of contingent earn-out liability | 10,138 |  |  | 1,218 |  |  | 12,435 |  |  | 16,310 |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | 2,683 |  |  | 311 |  |  | 2,614 |  |  | 2,529 |  |
| Change in fair value of public warrant liability | 6,595 |  |  | 1,131 |  |  | 435 |  |  | 6,592 |  |
| Total other income, net | 18,867 |  |  | 3,158 |  |  | 15,387 |  |  | 28,290 |  |
| Loss before income taxes | 10,882 |  |  | (15,720) |  |  | (33,076) |  |  | (54,017) |  |
| Provision for income taxes | — |  |  | — |  |  | $ | 62 |  |  | $ | — |  |
| Net income (loss) | $ | 10,882 |  |  | $ | (15,720) |  |  | $ | (33,138) |  |  | $ | (54,017) |  |
| Net income (loss) income attributable to common stockholders – basic and diluted | $ | 10,810 |  |  | $ | (15,720) |  |  | $ | (33,138) |  |  | $ | (54,017) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |
| Basic | 174,625,931 |  | 158,997,410 |  | 168,419,211 |  | 156,573,886 |
| Diluted | 189,125,126 |  | 158,997,410 |  | 168,419,211 |  | 156,573,886 |
| Net income (loss) per share |  |  |  |  |  |  |  |
| Basic | $ | 0.06 |  |  | $ | (0.10) |  |  | $ | (0.20) |  |  | $ | (0.34) |  |
| Diluted | $ | 0.06 |  |  | $ | (0.10) |  |  | $ | (0.20) |  |  | $ | (0.34) |  |
| Net income (loss) | $ | 10,882 |  |  | $ | (15,720) |  |  | $ | (33,138) |  |  | $ | (54,017) |  |
| Other comprehensive (loss) income |  |  |  |  |  |  |  |
| Cumulative translation adjustment | (4) |  |  | 96 |  |  | (109) |  |  | 21 |  |
| Total other comprehensive (loss) income | (4) |  |  | 96 |  |  | (109) |  |  | 21 |  |
| Total comprehensive income (loss) | $ | 10,878 |  |  | $ | (15,624) |  |  | $ | (33,247) |  |  | $ | (53,996) |  |

[0001805385-26-000011:8k_2_02:44]
EVOLV TECHNOLOGY

[0001805385-26-000011:8k_2_02:45]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001805385-26-000011:8k_2_02:46]
(In thousands, except share and per share data)

[0001805385-26-000011:8k_2_02:47]
(Unaudited)

[0001805385-26-000011:8k_2_02:48]
|  | December 31, 2025 |  | December 31, 2024 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 49,150 |  |  | $ | 37,015 |  |
| Marketable securities | 19,885 |  |  | 14,927 |  |
| Accounts receivable, net | 30,841 |  |  | 28,392 |  |
| Inventory | 9,317 |  |  | 16,963 |  |
| Current portion of contract assets | 878 |  |  | 799 |  |
| Current portion of commission asset | 6,062 |  |  | 5,429 |  |
| Prepaid expenses and other current assets | 35,169 |  |  | 17,921 |  |
| Total current assets | 151,302 |  |  | 121,446 |  |
| Contract assets, noncurrent | 15 |  |  | 657 |  |
| Commission asset, noncurrent | 7,867 |  |  | 7,567 |  |
| Property and equipment, net | 127,522 |  |  | 123,661 |  |
| Operating lease right-of-use assets | 12,303 |  |  | 13,993 |  |
| Other assets | 5,400 |  |  | 735 |  |
| Total assets | $ | 304,409 |  |  | $ | 268,059 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 9,770 |  |  | $ | 10,492 |  |
| Accrued expenses and other current liabilities | 35,293 |  |  | 19,508 |  |
| Current portion of deferred revenue | 74,924 |  |  | 64,506 |  |
| Current portion of operating lease liabilities | 2,989 |  |  | 2,203 |  |
| Total current liabilities | 122,976 |  |  | 96,709 |  |
| Deferred revenue, noncurrent | 16,716 |  |  | 20,266 |  |
| Long-term debt | 28,596 |  |  | — |  |
| Operating lease liabilities, noncurrent | 10,654 |  |  | 12,326 |  |
| Contingent earn-out liability, noncurrent | 374 |  |  | 12,809 |  |
| Contingently issuable common stock liability, noncurrent | 1,809 |  |  | 4,001 |  |
| Public warrant liability, noncurrent | 3,862 |  |  | 4,297 |  |
| Total liabilities | 184,987 |  |  | 150,408 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at December 31, 2025 and December 31, 2024; no shares issued and outstanding at December 31, 2025 and December 31, 2024 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at December 31, 2025 and December 31, 2024; 175,399,488 and 159,602,069 shares issued and outstanding at December 31, 2025 and December 31, 2024, respectively | 18 |  |  | 16 |  |
| Additional paid-in capital | 507,347 |  |  | 472,331 |  |
| Accumulated other comprehensive loss | (141) |  |  | (32) |  |
| Accumulated deficit | (387,802) |  |  | (354,664) |  |
| Stockholders’ equity | 119,422 |  |  | 117,651 |  |
| Total liabilities and stockholders’ equity | $ | 304,409 |  |  | $ | 268,059 |  |

[0001805385-26-000011:8k_2_02:49]
EVOLV TECHNOLOGY

[0001805385-26-000011:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001805385-26-000011:8k_2_02:51]
(In thousands)

[0001805385-26-000011:8k_2_02:52]
(Unaudited)

[0001805385-26-000011:8k_2_02:53]
|  | Twelve Months EndedDecember 31, |
|  | 2025 |  | 2024 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (33,138) |  |  | $ | (54,017) |  |
| Adjustments to reconcile net loss to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation and amortization | 24,340 |  |  | 17,375 |  |
| Write-off of inventory and change in inventory reserve | 2,891 |  |  | 2,578 |  |
| Loss on impairment of property and equipment | — |  |  | 224 |  |
| Loss on impairment of intangible asset | — |  |  | 983 |  |
| Loss on disposal of property and equipment | 3,787 |  |  | — |  |
| Stock-based compensation | 21,096 |  |  | 24,756 |  |
| Non-cash interest expense | 482 |  |  | — |  |
| (Accretion) amortization of (discount) premium on marketable securities, net of change in accrued interest | (126) |  |  | 447 |  |
| Non-cash lease expense | 1,690 |  |  | 1,420 |  |
| Change in allowance for expected credit losses | (134) |  |  | 152 |  |
| Change in fair value of earn-out liability | (12,435) |  |  | (16,310) |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | (2,614) |  |  | (2,529) |  |
| Change in fair value of public warrant liability | (435) |  |  | (6,592) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (2,315) |  |  | (6,997) |  |
| Inventory | 9,118 |  |  | (7,852) |  |
| Commission assets | (933) |  |  | (1,360) |  |
| Contract assets | 563 |  |  | 905 |  |
| Other assets | 750 |  |  | 467 |  |
| Prepaid expenses and other current assets | (22,577) |  |  | (964) |  |
| Accounts payable | 3,775 |  |  | 192 |  |
| Deferred revenue | 6,868 |  |  | 12,815 |  |
| Accrued expenses and other current liabilities | 18,902 |  |  | 4,534 |  |
| Operating lease liability | (886) |  |  | (1,080) |  |
| Net cash provided by (used in) operating activities | 18,669 |  |  | (30,853) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (5,627) |  |  | (6,125) |  |
| Purchases of property and equipment | (31,367) |  |  | (31,189) |  |
| Purchases of marketable securities | (39,388) |  |  | (29,367) |  |
| Proceeds from maturities of marketable securities | 34,556 |  |  | 65,282 |  |
| Net cash used in investing activities | (41,826) |  |  | (1,399) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 9,085 |  |  | 1,809 |  |
| Proceeds from long-term debt | 26,316 |  |  | — |  |
| Net cash provided by financing activities | 35,401 |  |  | 1,809 |  |
| Effect of exchange rate changes on cash and cash equivalents | (109) |  |  | 21 |  |
| Net increase (decrease) in cash and cash equivalents | 12,135 |  |  | (30,422) |  |
| Cash and cash equivalents |  |  |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 37,015 |  |  | 67,437 |  |
| Cash and cash equivalents at end of period | $ | 49,150 |  |  | $ | 37,015 |  |

[0001805385-26-000011:8k_2_02:54]
EVOLV TECHNOLOGY

[0001805385-26-000011:8k_2_02:55]
SUMMARY OF KEY OPERATING STATISTICS

[0001805385-26-000011:8k_2_02:56]
(Unaudited)

[0001805385-26-000011:8k_2_02:57]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  | June 30,2025 |  | September 30,2025 |  | December 31,2025 |
| New customers |  | 53 |  |  | 84 |  |  | 52 |  |  | 60 |  |  | 54 |  |  | 63 |  |  | 62 |  |  | 64 |  |
| Annual recurring revenue |  | $ | 79,192 |  |  | $ | 87,011 |  |  | $ | 93,676 |  |  | $ | 99,351 |  |  | $ | 105,990 |  |  | $ | 110,516 |  |  | $ | 117,200 |  |  | $ | 120,467 |  |
| Recurring revenue |  | $ | 18,961 |  |  | $ | 21,016 |  |  | $ | 23,764 |  |  | $ | 23,678 |  |  | $ | 25,753 |  |  | $ | 26,678 |  |  | $ | 30,120 |  |  | $ | 29,547 |  |

[0001805385-26-000011:8k_2_02:58]
The following table includes the Company's remaining performance obligations for the fiscal quarters from December 31, 2024 through September 30, 2025, which have been updated to reflect immaterial adjustments made as part of the Company’s 2025 year‑end financial reporting process. These changes had no impact on the Company’s statements of operations and comprehensive income (loss), balance sheets, or statements of cash flows for any periods presented.

[0001805385-26-000011:8k_2_02:59]
|  | As of |
| ($ in thousands) |  | December 31,2024 |  | March 31,2025 |  | June 30,2025 |  | September 30,2025 |  | December 31,2025 |
| Remaining performance obligation (as reported) |  | $ | 266,704 |  |  | $ | 261,233 |  |  | $ | 275,451 |  |  | $ | 298,560 |  |  | $ | 293,589 |  |
| Adjustment |  | (7,592) |  |  | (8,444) |  |  | (8,415) |  |  | (8,829) |  |  | — |  |
| Remaining performance obligation (as adjusted) |  | $ | 259,112 |  |  | $ | 252,789 |  |  | $ | 267,036 |  |  | $ | 289,731 |  |  | $ | 293,589 |  |

[0001805385-26-000011:8k_2_02:60]
EVOLV TECHNOLOGY

[0001805385-26-000011:8k_2_02:61]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001805385-26-000011:8k_2_02:62]
(In thousands)

[0001805385-26-000011:8k_2_02:63]
(Unaudited)

[0001805385-26-000011:8k_2_02:64]
|  | Three Months Ended, |
|  |  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  | June 30,2025 |  | September 30,2025 |  | December 31,2025 |
|  |  | (Restated) |  | (Restated) |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses, GAAP |  | $ | 34,061 |  |  | $ | 37,128 |  |  | $ | 34,961 |  |  | $ | 35,619 |  |  | $ | 33,539 |  |  | $ | 33,711 |  |  | $ | 29,902 |  |  | $ | 26,613 |  |
| Stock-based compensation |  | (6,292) |  |  | (7,254) |  |  | (7,263) |  |  | (3,159) |  |  | (4,660) |  |  | (5,265) |  |  | (5,121) |  |  | (5,006) |  |
| Loss on impairment of leased equipment |  | — |  |  | — |  |  | (209) |  |  | (15) |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Non-recurring employee restructuring and other separation costs |  | — |  |  | (1,000) |  |  | — |  |  | (2,060) |  |  | (2,137) |  |  | (827) |  |  | (6) |  |  | — |  |
| Other non-recurring legal and regulatory costs |  | (476) |  |  | (2,185) |  |  | (2,339) |  |  | (7,284) |  |  | (3,561) |  |  | (5,979) |  |  | 36 |  |  | 2,225 |  |
| Adjusted operating expenses |  | $ | 27,293 |  |  | $ | 26,689 |  |  | $ | 25,150 |  |  | $ | 23,101 |  |  | $ | 23,181 |  |  | $ | 21,640 |  |  | $ | 24,811 |  |  | $ | 23,832 |  |

[0001805385-26-000011:8k_2_02:65]
EVOLV TECHNOLOGY

[0001805385-26-000011:8k_2_02:66]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT, GAAP GROSS MARGIN TO ADJUSTED GROSS MARGIN AND GAAP INCOME (LOSS) FROM OPERATIONS TO ADJUSTED OPERATING INCOME (LOSS)

[0001805385-26-000011:8k_2_02:67]
(In thousands)

[0001805385-26-000011:8k_2_02:68]
(Unaudited)

[0001805385-26-000011:8k_2_02:69]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue | $ | 38,504 |  |  | $ | 29,100 |  |  | $ | 145,905 |  |  | $ | 103,865 |  |
| Cost of revenue | 19,876 |  |  | 12,359 |  |  | 70,603 |  |  | 44,403 |  |
| Gross profit, GAAP | 18,628 |  |  | 16,741 |  |  | 75,302 |  |  | 59,462 |  |
| Stock-based compensation | 274 |  |  | 233 |  |  | 1,044 |  |  | 788 |  |
| Amortization of capitalized stock-based compensation | 150 |  |  | 85 |  |  | 474 |  |  | 137 |  |
| Loss on impairment of intangible asset | — |  |  | 983 |  |  | — |  |  | 983 |  |
| Non-recurring employee restructuring and other separation costs | — |  |  | — |  |  | 6 |  |  | — |  |
| Non-recurring inventory charges | — |  |  | 123 |  |  | — |  |  | 2,730 |  |
| Adjusted gross profit* | $ | 19,052 |  |  | $ | 18,165 |  |  | $ | 76,826 |  |  | $ | 64,100 |  |
| Gross margin % | 48.4 | % |  | 57.5 | % |  | 51.6 | % |  | 57.2 | % |
| Adjusted gross margin % | 49.5 | % |  | 62.4 | % |  | 52.7 | % |  | 61.7 | % |

[0001805385-26-000011:8k_2_02:70]
*Beginning in the three month period ended September 30, 2025, and on a go-forward basis, management has determined that the loss on disposal of leased equipment should no longer be considered a non-recurring expense, and accordingly, loss on disposal of leased equipment is now reflected within non-GAAP gross margins and adjusted loss from operations.

[0001805385-26-000011:8k_2_02:71]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Loss from operations, GAAP | $ | (7,985) |  |  | $ | (18,878) |  |  | $ | (48,463) |  |  | $ | (82,307) |  |
| Stock-based compensation | 5,280 |  |  | 3,392 |  |  | 21,096 |  |  | 24,756 |  |
| Amortization of capitalized stock-based compensation | 150 |  |  | 85 |  |  | 474 |  |  | 137 |  |
| Loss on impairment of leased equipment | — |  |  | 15 |  |  | — |  |  | 224 |  |
| Loss on impairment of intangible asset | — |  |  | 983 |  |  | — |  |  | 983 |  |
| Non-recurring employee restructuring and other separation costs | — |  |  | 2,060 |  |  | 2,976 |  |  | 3,060 |  |
| Non-recurring inventory charges | — |  |  | 123 |  |  | — |  |  | 2,730 |  |
| Other non-recurring legal and regulatory costs | (2,225) |  |  | 7,284 |  |  | 7,279 |  |  | 12,284 |  |
| Adjusted loss from operations* | $ | (4,780) |  |  | $ | (4,936) |  |  | $ | (16,638) |  |  | $ | (38,133) |  |

[0001805385-26-000011:8k_2_02:72]
*Beginning in the three month period ended September 30, 2025, and on a go-forward basis, management has determined that the loss on disposal of leased equipment should no longer be considered a non-recurring expense, and accordingly, loss on disposal of leased equipment is now reflected within non-GAAP gross margins and adjusted loss from operations.

[0001805385-26-000011:8k_2_02:73]
EVOLV TECHNOLOGY

[0001805385-26-000011:8k_2_02:74]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA AND NET PROFIT MARGIN TO ADJUSTED EBITDA MARGIN

[0001805385-26-000011:8k_2_02:75]
(In thousands)

[0001805385-26-000011:8k_2_02:76]
(Unaudited)

[0001805385-26-000011:8k_2_02:77]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net income (loss) | $ | 10,882 |  |  | $ | (15,720) |  |  | $ | (33,138) |  |  | $ | (54,017) |  |
| Depreciation and amortization | 6,481 |  |  | 5,442 |  |  | 24,340 |  |  | 17,375 |  |
| Stock-based compensation | 5,280 |  |  | 3,392 |  |  | 21,096 |  |  | 24,756 |  |
| Interest expense (income) | 531 |  |  | (548) |  |  | 196 |  |  | (2,942) |  |
| Provision for income taxes | — |  |  | — |  |  | 62 |  |  | — |  |
| Change in fair value of contingent earn-out liability | (10,138) |  |  | (1,218) |  |  | (12,435) |  |  | (16,310) |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | (2,683) |  |  | (311) |  |  | (2,614) |  |  | (2,529) |  |
| Change in fair value of public warrant liability | (6,595) |  |  | (1,131) |  |  | (435) |  |  | (6,592) |  |
| Loss on impairment of leased equipment | — |  |  | 15 |  |  | — |  |  | 224 |  |
| Loss on impairment of intangible asset | — |  |  | 983 |  |  | — |  |  | 983 |  |
| Loss on disposal of leased equipment | 284 |  |  | — |  |  | 3,787 |  |  | — |  |
| Non-recurring employee restructuring and other separation costs | — |  |  | 2,060 |  |  | 2,976 |  |  | 3,060 |  |
| Non-recurring inventory charges | — |  |  | 123 |  |  | — |  |  | 2,730 |  |
| Other non-recurring legal and regulatory costs | (2,225) |  |  | 7,284 |  |  | 7,279 |  |  | 12,284 |  |
| Adjusted EBITDA | $ | 1,817 |  |  | $ | 371 |  |  | $ | 11,114 |  |  | $ | (20,978) |  |
| Net profit margin % | 28.3 | % |  | (54.0) | % |  | (22.7) | % |  | (52.0) | % |
| Impact of adjustments from Net income (loss) to Adjusted EBITDA | (23.6) | % |  | 55.3 | % |  | 30.3 | % |  | 31.8 | % |
| Adjusted EBITDA margin % | 4.7 | % |  | 1.3 | % |  | 7.6 | % |  | (20.2) | % |

[0001805385-26-000011:8k_2_02:78]
EVOLV TECHNOLOGY

[0001805385-26-000011:8k_2_02:79]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001805385-26-000011:8k_2_02:80]
(In thousands, except share and per share data)

[0001805385-26-000011:8k_2_02:81]
(Unaudited)

[0001805385-26-000011:8k_2_02:82]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net income (loss) | $ | 10,882 |  |  | $ | (15,720) |  |  | $ | (33,138) |  |  | $ | (54,017) |  |
| Stock-based compensation | 5,280 |  |  | 3,392 |  |  | 21,096 |  |  | 24,756 |  |
| Amortization of capitalized stock-based compensation | 150 |  |  | 85 |  |  | 474 |  |  | 137 |  |
| Change in fair value of contingent earn-out liability | (10,138) |  |  | (1,218) |  |  | (12,435) |  |  | (16,310) |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | (2,683) |  |  | (311) |  |  | (2,614) |  |  | (2,529) |  |
| Change in fair value of public warrant liability | (6,595) |  |  | (1,131) |  |  | (435) |  |  | (6,592) |  |
| Loss on impairment of leased equipment | — |  |  | 15 |  |  | — |  |  | 224 |  |
| Loss on impairment of intangible asset | — |  |  | 983 |  |  | — |  |  | 983 |  |
| Non-recurring employee restructuring and other separation costs | — |  |  | 2,060 |  |  | 2,976 |  |  | 3,060 |  |
| Non-recurring inventory charges | — |  |  | 123 |  |  | — |  |  | 2,730 |  |
| Other non-recurring legal and regulatory costs | (2,225) |  |  | 7,284 |  |  | 7,279 |  |  | 12,284 |  |
| Adjusted loss | $ | (5,329) |  |  | $ | (4,438) |  |  | $ | (16,797) |  |  | $ | (35,274) |  |
| Weighted average common shares outstanding – diluted | 174,625,931 |  |  | 158,997,410 |  |  | 168,419,211 |  |  | 156,573,886 |  |
| Adjusted loss per share – diluted | $ | (0.03) |  |  | $ | (0.03) |  |  | $ | (0.10) |  |  | $ | (0.23) |  |

[0001805385-26-000011:8k_2_02:83]
*Stock-based compensation, amortization of capitalized stock-based compensation, and non-recurring restructuring and other employee separation costs were recorded in the condensed consolidated statements of operations and comprehensive loss (income) as follows. Prior period amounts are being shown for comparative purposes:

[0001805385-26-000011:8k_2_02:84]
|  | Three Months Ended, |
|  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  | June 30,2025 |  | September 30,2025 |  | December 31,2025 |
| Stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | $ | — |  |  | $ | 5 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |  | $ | 17 |  |  | $ | 32 |  |  | $ | 39 |  |
| Cost of subscription revenue | 91 |  |  | 110 |  |  | 169 |  |  | 154 |  |  | 137 |  |  | 167 |  |  | 146 |  |  | 135 |  |
| Cost of service revenue | 44 |  |  | 51 |  |  | 63 |  |  | 61 |  |  | 67 |  |  | 74 |  |  | 72 |  |  | 80 |  |
| Cost of license fee and other revenue | 3 |  |  | 7 |  |  | 8 |  |  | 10 |  |  | 7 |  |  | 24 |  |  | 19 |  |  | 20 |  |
| Research and development | 902 |  |  | 1,222 |  |  | 1,243 |  |  | 1,153 |  |  | 1,115 |  |  | 1,154 |  |  | 1,227 |  |  | 1,252 |  |
| Sales and marketing | 2,959 |  |  | 2,724 |  |  | 2,516 |  |  | 2,747 |  |  | 1,048 |  |  | 1,710 |  |  | 1,480 |  |  | 1,330 |  |
| General and administrative | 2,431 |  |  | 3,308 |  |  | 3,504 |  |  | (741) |  |  | 1,972 |  |  | 2,401 |  |  | 2,414 |  |  | 2,424 |  |
| Restructuring costs | — |  |  | — |  |  | — |  |  | — |  |  | 525 |  |  | — |  |  | — |  |  | — |  |
| Total stock-based compensation | $ | 6,430 |  |  | $ | 7,427 |  |  | $ | 7,507 |  |  | $ | 3,392 |  |  | $ | 4,879 |  |  | $ | 5,547 |  |  | $ | 5,390 |  |  | $ | 5,280 |  |
| Amortization of capitalized stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of subscription revenue | $ | 8 |  |  | $ | 8 |  |  | $ | 13 |  |  | $ | 47 |  |  | $ | 59 |  |  | $ | 60 |  |  | $ | 63 |  |  | $ | 82 |  |
| Cost of service revenue | 6 |  |  | 7 |  |  | 10 |  |  | 38 |  |  | 44 |  |  | 47 |  |  | 51 |  |  | 68 |  |
| Total amortization of capitalized stock-based compensation | $ | 14 |  |  | $ | 15 |  |  | $ | 23 |  |  | $ | 85 |  |  | $ | 103 |  |  | $ | 107 |  |  | $ | 114 |  |  | $ | 150 |  |
| Non-recurring employee restructuring and other separation costs: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of service revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |  | $ | — |  |  | $ | — |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 31 |  |  | — |  |  | — |  |
| Sales and marketing | — |  |  | 140 |  |  | — |  |  | 63 |  |  | — |  |  | 613 |  |  | 6 |  |  | — |  |
| General and administrative | — |  |  | — |  |  | — |  |  | 1,997 |  |  | — |  |  | 183 |  |  | — |  |  | — |  |
| Restructuring costs | — |  |  | 860 |  |  | — |  |  | — |  |  | 2,137 |  |  | — |  |  | — |  |  | — |  |
| Total non-recurring employee restructuring and other separation costs | $ | — |  |  | $ | 1,000 |  |  | $ | — |  |  | $ | 2,060 |  |  | $ | 2,137 |  |  | $ | 833 |  |  | $ | 6 |  |  | $ | — |  |
