# EVLV MD&A — 0001805385-26-000012


## mdna

[0001805385-26-000012:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001805385-26-000012:mdna:2]
As used in this Annual Report on Form 10-K, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. (“Evolv UK”) and Give Evolv LLC. References to “NHIC” refer to the company prior to the consummation of our business combination (the “Merger”) and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001805385-26-000012:mdna:3]
Business Overview

[0001805385-26-000012:mdna:4]
Evolv is a leading security technology company pioneering Artificial Intelligence (“AI”)-powered screening solutions designed to help create safer environments while maintaining efficient visitor flow and a positive visitor experience. We serve customers across a range of end markets, including education, healthcare, sports, live entertainment, tourist attractions, houses of worship, and industrial workplaces. Our mission is to make the world a safer and more enjoyable place to live, work, learn, and play. Our goal is to help facility operators address escalating gun violence, mass shootings and terrorist attacks while maintaining a positive visitor experience.

[0001805385-26-000012:mdna:5]
Our solutions are delivered through a Security-as-a-Service model that integrates our proprietary sensor platform and AI-powered software, cloud connectivity, and ongoing services. We deliver our solutions through two sales models: a pure subscription model and a purchase subscription model, each of which requires both hardware and an active, connected software subscription, as further described in “Sales Mix, Pricing, Product Cost and Margins”. We believe this integrated approach reflects the full scope of our offering and aligns our long-term interests with those of our customers.

[0001805385-26-000012:mdna:6]
Our hardware platforms are uniquely designed and purpose engineered for real world, high throughput security environments and are the foundational component of our solutions. Evolv Express® and Evolv eXpedite™ operate exclusively with Evolv’s proprietary software and cloud services. When deployed together, the two products are designed to support improved operational efficiency through better threat identification and alarm performance. We believe our ability to deliver continuous improvement through software upgrades differentiates our platform from many legacy hardware only offerings.

[0001805385-26-000012:mdna:7]
Our platform was designed from inception around AI operating in physical environments. Our AI powered software and services are central to the performance and long-term value of our platform. Through continuous operation across a large and growing installed base, our systems generate substantial volumes of anonymized screening data related to the movement of people and bags through physical spaces. We train our models on a proprietary data set and can improve the system performance through new and updated algorithms, which customers receive from us through software updates.

[0001805385-26-000012:mdna:8]
We focus on weapons detection and offer two core solutions that can be deployed independently or together and are supported by data and visual dashboards that provide actionable analytics and automated reports designed to help security teams make evidence-based decisions to strengthen security. Evolv Express is designed to screen high volumes of people for concealed threats, while Evolv eXpedite is designed to screen high volumes of bags automatically, without requiring a trained X-Ray operator. When deployed together, these solutions provide a layered security approach that allows customers to operate at heightened sensitivity levels while seeking to maintain efficient throughput and a positive visitor experience.

[0001805385-26-000012:mdna:9]
In addition to screening capabilities, our subscription includes Evolv Insights®, our cloud-based analytics solution that provides customers with operational visibility into system performance across their venues or facilities. Available data includes throughput volumes, alarm statistics, detection settings, and system performance metrics, which customers can use to inform security operations, staffing decisions, and checkpoint configuration.

[0001805385-26-000012:mdna:10]
Our offering is bundled together by the services included in our subscription. We recognize that the primary mission of our customers is typically not security. Our customers’ mission might be educating children, restoring patients to good health, or entertaining fans in their seats. Our subscription includes full onsite support and repair services for the full term, so that our customers can focus on what they do best while we make sure their equipment is operating as designed.  We are security as a service, from the hardware to the software to the data to the support.

[0001805385-26-000012:mdna:11]
Our platform incorporates both hardware and software components that are deployed across a large number of operating venues. Each deployed unit functions not only as a detection device but also as a data collection mechanism, generating ongoing real‑world operational data, including both threat and non‑threat events. Some of this data is used to support the continued development and refinement of our algorithms. We believe the integration of our hardware and software creates operational interdependencies that are integral to our platform. As a result, the hardware and software components of our system are designed to operate together and are not intended to function as standalone offerings, which distinguishes our approach from cloud‑only software solutions.

[0001805385-26-000012:mdna:12]
We believe our hardware-enabled, long term subscription model differentiates our business from purely software-as-a-service offerings. We believe our platform is well positioned to benefit from ongoing advances in artificial intelligence, driving durable customer value and supporting predictable, recurring subscription revenue.

[0001805385-26-000012:mdna:13]
We are focused on delivering value in the spaces in and around the physical threshold of venues and facilities while offering the ability for connected layers of security. We believe that digitally transforming the visitor experience at the entry point to venues and facilities will be a critically important innovation in physical security. We believe that our solutions will not only help make venues and facilities safer and more enjoyable, but also more efficient, and more informed about their visitors’ and security team needs.

[0001805385-26-000012:mdna:14]
Key indicators of our performance of market acceptance and customer adoption include Annual Recurring Revenue (“ARR”), a measure of annualized recurring subscription and related service revenue, and Remaining Performance Obligation (“RPO”), a measure of expected future revenue from active customer contracts. We believe these indicators reflect the scale, durability, and growth of our Security‑as‑a‑Service model.

[0001805385-26-000012:mdna:15]
Key Factors Affecting Our Operating Results

[0001805385-26-000012:mdna:16]
We believe that our performance and future success depend on many factors that present significant opportunities for us but also pose risks and challenges, including those discussed below and in the "Risk Factors" section of this Annual Report on Form 10-K.

[0001805385-26-000012:mdna:17]
Supply Chain Strategy

[0001805385-26-000012:mdna:18]
On November 5, 2025, we entered into a non-exclusive contract manufacturing agreement with Plexus Corp. (“Plexus”). This shift is part of a broader supply chain strategy aimed at enhancing scalability, geographic diversification, creating long-term cost-saving opportunities, and operational resiliency. As Plexus is brought onboard, we believe we maintain ample inventory and committed production capacity to meet our growth targets with our existing contract manufacturer, ensuring uninterrupted service and consistent delivery to customers.

[0001805385-26-000012:mdna:19]
We regularly evaluate our supply chain structure to mitigate risks, including supplier concentration and dependencies, global chipset and semiconductor supply constraints, including memory and compute components used in AI‑enabled products, long and variable lead times, cost volatility, and supplier allocation practices. While no material disruptions are anticipated during the onboarding of Plexus, manufacturing capacity for certain components is limited to a small number of qualified suppliers, and extended or unforeseen disruptions, capacity limitations, or changes in allocation practices could impact our supply. We continue to monitor risks associated with onboarding, logistics, and supplier performance. These factors may influence cost of revenue, inventory levels, working capital, and our ability to meet customer demand in future periods.

[0001805385-26-000012:mdna:20]
General Economic and Market Conditions

[0001805385-26-000012:mdna:21]
We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of rising inflation and interest rates on business spending; supply chain constraints, operational challenges, and the impacts on our manufacturing capabilities; public health emergencies; geopolitical conflicts and war, including the conflicts in Europe and the Middle East; and recessionary trends. See the risk

[0001805385-26-000012:mdna:22]
factor titled “Our operating results may fluctuate for a variety of reasons, including our failure to close large volume opportunity customer sales” in Item 1A. Risk Factors of this Annual Report on Form 10-K. While these factors continue to evolve, we plan to remain flexible and optimize our business as appropriate and allocate resources, as necessary.

[0001805385-26-000012:mdna:23]
Adoption of our Security Screening Products

[0001805385-26-000012:mdna:24]
We believe the world will continue to focus on the safety and security of people in the places where they gather. Many of these locations, such as professional sports venues, educational institutions, and healthcare facilities, are moving toward a more frictionless security screening experience. We are well-positioned to take advantage of this opportunity due to our proprietary technologies and distribution capabilities. Our products are designed to empower venues and facilities to realize the full benefits of touchless security screening, including a rapid visitor throughput and minimal security staff to screened visitor physical contact. We expect that our results of operations, including revenue, will fluctuate for the foreseeable future as venues and facilities continue to shift away from conventional security screening processes towards touchless security screening or consider security screening processes for the first time. The degree to which potential and current customers recognize these benefits and invest in our products will affect our financial results.

[0001805385-26-000012:mdna:25]
Sales Mix, Pricing, Product Cost and Margins

[0001805385-26-000012:mdna:26]
We sell our solutions under two primary sales models. We offer a “pure subscription” model, where the customer leases hardware from us and we provide a multi-year security-as-a-service subscription. For end-user customers that prefer to purchase our hardware outright, we offer customers the option of purchasing our hardware outright directly from us through our “purchase subscription” model that also includes a multi-year security and software-as-a-service subscription. In addition to our two primary sales models, we have historically offered our “distributor licensing” model based on the Distribution and License Agreement we entered into with Columbia Tech in March of 2023. Under this arrangement, we have granted a license of our intellectual property to Columbia Tech, which contracts directly with certain of our resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment. Columbia Tech pays us a hardware license fee for each system it manufactures and sells under this agreement. In these instances, we still contract directly with the reseller to provide a multi-year security-as-a-service subscription to the end-users. During the three months ended September 30, 2025, we discontinued quoting on this basis, and the agreement with Columbia Tech expired on December 31, 2025. While any outstanding quotes will be honored, all new quotes for end-user customers wishing to purchase the hardware equipment will be fulfilled through our purchase subscription model going forward. Thus, license revenue from this agreement is expected to reduce to zero over time, replaced by increased product revenue, which will in turn provide an increase in gross profit over the duration of the contract. We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our revenue, gross profit, gross margin, and overall profitability in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments.

[0001805385-26-000012:mdna:27]
Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions. While adoption of our products has primarily been within the United States to date, we expect increased adoption of our products in foreign markets in the near future as we explore expansion into international markets. Pricing may vary by region or vertical market due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales and business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce AI-powered security screening solutions to our customers.

[0001805385-26-000012:mdna:28]
Development and Commercialization of our Products

[0001805385-26-000012:mdna:29]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $145.9 million and $103.9 million for the years ended December 31, 2025 and 2024, respectively. We generated a net loss of $33.1 million and $54.0 million for the years ended December 31, 2025 and 2024, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling the use of third-party contract manufacturers, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001805385-26-000012:mdna:30]
Certain Key Metrics and Non-GAAP Financial Measures

[0001805385-26-000012:mdna:31]
ARR. We believe annual recurring revenue (“ARR”) is a useful metric for investors because it provides visibility into the scale and sustainability of our recurring revenue base. ARR reflects the annualized value of active subscription arrangements at a point in time and helps investors evaluate trends in customer and unit acquisition, retention, and expansion. As our business continues to shift toward pure subscription and purchase subscription sales models (and away from our legacy distribution subscription model), we believe ARR more accurately captures the recurring nature of our revenue compared to period based revenue measures alone. Management also uses ARR to assess operating performance, inform strategic decisions, and plan for future growth, because it is impacted by multiple dimensions of our business, including new customer and unit acquisition, customer pricing, renewal history, and renewal pricing.

[0001805385-26-000012:mdna:32]
We define ARR as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001805385-26-000012:mdna:33]
As of December 31, 2025, ARR was $120.5 million, compared to $99.4 million as of December 31, 2024, representing year over year growth of 21%. This increase was driven by the addition of nearly 250 customers during 2025, expanded deployments by existing customers and increased demand for our pure subscription and purchase subscription sales models which generate a higher proportion of recurring revenue compared to our legacy distribution subscription sales model (see "Sales Models”).

[0001805385-26-000012:mdna:34]
RPO. We believe Remaining Performance Obligation ("RPO"), a measure of expected future revenue from active customers, to be a key indicator of our performance. As disclosed in Note 5 to our financial statements, RPO at December 31, 2025 was $293.6 million, an increase of approximately 13% from December 31, 2024, driven by continued market demand.

[0001805385-26-000012:mdna:35]
Adjusted EBITDA. We believe Adjusted Earnings Before Interest, Taxes, Depreciation and Amortization (“Adjusted EBITDA”) is a useful metric for investors because it provides insight into the underlying operating performance of our business by excluding items that are not indicative of our core operating results or that may vary significantly from period to period. Adjusted EBITDA facilitates period-to-period comparisons of our operating performance and enhances investors’ ability to evaluate trends in profitability and operating leverage. In addition, Adjusted EBITDA helps investors better understand the impact of our cost structure and operating efficiency as we scale our business, independent of non‑cash expenses, financing decisions, tax structure, and certain non‑recurring or non‑operational items. While Adjusted EBITDA should be considered in conjunction with our GAAP financial results, we believe it provides supplemental information that enhances investors’ understanding of the performance of our business.

[0001805385-26-000012:mdna:36]
Management uses Adjusted EBITDA internally to assess operating performance, monitor cost discipline, and evaluate the efficiency of our business as we scale. Adjusted EBITDA is a key metric used by management to measure the profitability of our core operations and to assess the impact of operating decisions across the organization. Management reviews Adjusted EBITDA trends to inform strategic decisions related to expense management, investment prioritization, and resource allocation. Because Adjusted EBITDA excludes certain non‑cash and non‑recurring items, it allows management to better evaluate underlying operating performance and comparability across reporting periods. By monitoring Adjusted EBITDA over time, management is able to assess progress toward profitability objectives and make informed decisions regarding long-term operational and financial planning.

[0001805385-26-000012:mdna:37]
Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, stock based compensation, interest expense (income), provision for income taxes, change in fair value of contingent earn out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of leased equipment, loss on impairment of intangible asset, loss on disposal of leased equipment, non-recurring employee restructuring and other separation costs, non-recurring inventory charges, and other non-recurring legal and regulatory costs, which management believes provides a more meaningful representation of operating results.

[0001805385-26-000012:mdna:38]
The following table presents a reconciliation of net income, the most directly comparable GAAP financial measure, to Adjusted EBITDA for each of the periods indicated:

[0001805385-26-000012:mdna:39]
|  |  |  | December 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Net loss |  |  |  |  | $ | (33,138) |  |  | $ | (54,017) |  |
| Depreciation and amortization |  |  |  |  | 24,340 |  |  | 17,375 |  |
| Stock-based compensation |  |  |  |  | 21,096 |  |  | 24,756 |  |
| Interest expense (income) |  |  |  |  | 196 |  |  | (2,942) |  |
| Provision for income taxes |  |  |  |  | 62 |  |  | — |  |
| Change in fair value of contingent earn-out liability |  |  |  |  | (12,435) |  |  | (16,310) |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset |  |  |  |  | (2,614) |  |  | (2,529) |  |
| Change in fair value of public warrant liability |  |  |  |  | (435) |  |  | (6,592) |  |
| Loss on impairment of leased equipment |  |  |  |  | — |  |  | 224 |  |
| Loss on impairment of intangible asset |  |  |  |  | — |  |  | 983 |  |
| Loss on disposal of leased equipment |  |  |  |  | 3,787 |  |  | — |  |
| Non-recurring employee restructuring and other separation costs |  |  |  |  | 2,976 |  |  | 3,060 |  |
| Non-recurring inventory charges |  |  |  |  | — |  |  | 2,730 |  |
| Other non-recurring legal and regulatory costs |  |  |  |  | 7,279 |  |  | 12,284 |  |
| Adjusted EBITDA |  |  |  |  | $ | 11,114 |  |  | $ | (20,978) |  |

[0001805385-26-000012:mdna:40]
For the year ended December 31, 2025, Adjusted EBITDA was $11.1 million, compared to negative Adjusted EBITDA of $(21.0) million for the year ended December 31, 2024, representing an improvement of $32.1 million year-over‑year. This improvement was primarily driven by revenue growth, increased operating leverage, and continued discipline in managing operating expenses, partially offset by higher investments to support growth initiatives and customer deployments.

[0001805385-26-000012:mdna:41]
Liquidity and Capital Resources

[0001805385-26-000012:mdna:42]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations and our Senior Secured Credit Facilities. See “Liquidity and Capital Resources” as well as “Risks Related to Our Financial Condition and Liquidity” for more information. Additionally, as discussed in Note 19, Commitments and Contingencies, to our consolidated financial statements for the year ended December 31, 2025, we are involved in certain legal proceedings, including a government investigation. Given the uncertainty of such matters, no assurance can be given regarding the final outcome of such matters. However, the ultimate amount or range of potential loss, which might result to the Company, may differ materially from our current estimates.

[0001805385-26-000012:mdna:43]
As described under Supply Chain Strategy section, we entered into a non-exclusive contract manufacturing agreement with Plexus, which is expected to enhance manufacturing scalability and operational efficiency. While the onboarding may temporarily affect working capital due to dual production activities and other onboarding costs, the Company does not anticipate a material impact on overall liquidity in the near term. Once fully operational, we expect improved inventory efficiency and commercial terms. The Company continues to monitor cash flows and capital requirements associated with the transition to ensure sufficient resources are available to support ongoing operations and strategic initiatives.

[0001805385-26-000012:mdna:44]
Components of Results of Operations

[0001805385-26-000012:mdna:45]
Revenue

[0001805385-26-000012:mdna:46]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement, (4) license fees related to the Distribution and

[0001805385-26-000012:mdna:47]
License Agreement, and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax. To the extent that we see an increase in demand for our pure subscription model, we would expect to see a reduction in upfront revenue recognition in favor of more recurring revenue.

[0001805385-26-000012:mdna:48]
Product Revenue

[0001805385-26-000012:mdna:49]
We derive a portion of our revenue from the sale of our Evolv Express and eXpedite equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We anticipate future growth in product revenue as more customers purchase systems through our purchase subscription model instead of through the now cancelled Distribution and License agreement with Columbia Tech.

[0001805385-26-000012:mdna:50]
Subscription Revenue

[0001805385-26-000012:mdna:51]
Subscription revenue consists of revenue derived from leasing Evolv Express and eXpedite systems to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001805385-26-000012:mdna:52]
Lease arrangements generally include both lease and non-lease components. The non-lease components relate to (1) distinct services, including professional services, SaaS, and maintenance, and (2) any add-on accessories. Professional services are included in license fees and other revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive loss.

[0001805385-26-000012:mdna:53]
Service Revenue

[0001805385-26-000012:mdna:54]
Service revenue consists of subscription-based SaaS and maintenance revenue related to Evolv Express and eXpedite systems sold to customers. Customers generally pay either a quarterly or annual fixed payment for SaaS and maintenance. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically four years.

[0001805385-26-000012:mdna:55]
License Fee and Other Revenue

[0001805385-26-000012:mdna:56]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from Columbia Tech to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration. Revenue for professional services and other one-time revenue, which had previously been included in service revenue, has been reclassified for prior periods to License fee and other revenue on the consolidated statements of operations and comprehensive loss. During the three months ended September 30, 2025, we discontinued quoting under this basis, and the agreement with Columbia Tech expired on December 31, 2025. While any outstanding quotes will be honored, all new quotes for end-user customers wishing to purchase the hardware equipment will be fulfilled through our purchase subscription model going forward. Thus, license revenue from this agreement is expected to reduce to zero over time, replaced by increased product revenue, which will in turn provide an increase in gross profit over the duration of the contract.

[0001805385-26-000012:mdna:57]
Cost of Revenue

[0001805385-26-000012:mdna:58]
We recognize cost of revenue in the same manner that the related revenue is recognized.

[0001805385-26-000012:mdna:59]
Cost of Product Revenue

[0001805385-26-000012:mdna:60]
Cost of product revenue consists primarily of costs paid to our third-party manufacturer and other suppliers, labor costs (including stock-based compensation), and shipping costs.

[0001805385-26-000012:mdna:61]
Cost of Subscription Revenue

[0001805385-26-000012:mdna:62]
Cost of subscription revenue consists primarily of depreciation expense related to leased units, an allocated portion of internal-use software amortization expense, shipping costs, and maintenance costs related to leased units. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies. Service-related costs reflected in cost of subscription revenue include, in part, the Company’s decision to in-source certain technical and field services support functions that were previously outsourced to a third-party service provider.

[0001805385-26-000012:mdna:63]
Cost of Service Revenue

[0001805385-26-000012:mdna:64]
Cost of service revenue consists of maintenance costs related to units purchased by customers and an allocated portion of internal-use software amortization expense. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies. Service-related costs reflected in cost of service revenue include, in part, the Company’s decision to in-source certain technical and field services support functions that were previously outsourced to a third-party service provider.

[0001805385-26-000012:mdna:65]
Cost of License Fee and Other Revenue

[0001805385-26-000012:mdna:66]
Cost of license fee and other revenue consists primarily of internal and third-party costs related to professional services, such as installation, training, and event support. License fee revenue earned under our Distribution and License Agreement with Columbia Tech has no associated cost of revenue.

[0001805385-26-000012:mdna:67]
Gross Profit and Gross Profit Margin

[0001805385-26-000012:mdna:68]
Our gross profit is calculated based on the difference between our revenues and cost of revenues. Gross profit margin is the percentage obtained by dividing gross profit by our revenue.

[0001805385-26-000012:mdna:69]
We expect our gross margins to fluctuate over time based on the following factors:

[0001805385-26-000012:mdna:70]
•Mix of sales between our pure subscription and purchase subscription models;

[0001805385-26-000012:mdna:71]
•Market conditions that may impact our pricing;

[0001805385-26-000012:mdna:72]
•Product mix changes between established products and new products;

[0001805385-26-000012:mdna:73]
•Our cost structure for manufacturing operations, including contract manufacturers, relative to volume, and our product support obligations;

[0001805385-26-000012:mdna:74]
•Our ability to maintain our costs on the components that go into the manufacture of our products; and

[0001805385-26-000012:mdna:75]
•Write-offs of inventory.

[0001805385-26-000012:mdna:76]
We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our gross profit and gross profit margin in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments.

[0001805385-26-000012:mdna:77]
Research and Development

[0001805385-26-000012:mdna:78]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and

[0001805385-26-000012:mdna:79]
bonuses, employee benefits, stock-based compensation, prototypes, design expenses, and consulting and contractor costs. We expect our research and development costs to increase for the year ending December 31, 2026 compared to the year ended December 31, 2025 as we continue to invest in product innovation.

[0001805385-26-000012:mdna:80]
Sales and Marketing

[0001805385-26-000012:mdna:81]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will increase modestly for the year ending December 31, 2026 compared to the year ended December 31, 2025 as we expand our go to market efforts through both direct and channel investments.

[0001805385-26-000012:mdna:82]
General and Administrative

[0001805385-26-000012:mdna:83]
General and administrative expenses consist primarily of personnel related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and insurance, net of any probable and reasonably estimable insurance recoveries or received insurance recoveries. During the first and second quarter of the year ended 2025, we experienced a significant increase in general and administrative expenses, primarily for legal fees and consulting expenses in connection with a previously disclosed investigation and restatement of prior period financial statements. This has declined in the second half of 2025 as certain of our legal and consulting expenses normalized. We expect our general and administrative expenses to decrease for the year ending December 31, 2026, as expenses incurred in 2025 related to a previously disclosed investigation and restatement of prior period financial statements are believed to be substantially non-recurring.

[0001805385-26-000012:mdna:84]
Restructuring Costs

[0001805385-26-000012:mdna:85]
Restructuring costs consist of termination charges arising from severance obligations, incremental non-cash expenses related to extended eligibility for the vesting of certain equity awards, and other customary employee benefit payments in connection with a reduction in force. See Note 22, Restructuring Charges for additional information.

[0001805385-26-000012:mdna:86]
The restructuring charges, which had previously been included in cost of service revenue, research and development expenses, sales and marketing expenses, and general and administrative expenses, has been reclassified for prior periods to restructuring costs on the consolidated statements of operations and comprehensive loss. See “Reclassifications” below and Note 1 for additional information.

[0001805385-26-000012:mdna:87]
Loss On Impairment of Property and Equipment

[0001805385-26-000012:mdna:88]
Loss on impairment of property and equipment relates to (i) Evolv Express prototype systems that are removed from service and retired as we transition our domestic customers to our most current Evolv Express systems, (ii) damaged or destroyed leased units, and (iii) IT equipment that is removed from service.

[0001805385-26-000012:mdna:89]
Interest Expense

[0001805385-26-000012:mdna:90]
Interest expense includes interest on our long-term debt, amortization of debt issuance costs, and unused commitment fees.

[0001805385-26-000012:mdna:91]
Interest Income

[0001805385-26-000012:mdna:92]
Interest income relates primarily to interest earned on our money market funds and treasury bills.

[0001805385-26-000012:mdna:93]
Change in Fair Value of Contingent Earn-out Liability

[0001805385-26-000012:mdna:94]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders are entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated

[0001805385-26-000012:mdna:95]
statements of operations and comprehensive (loss) income. The earn-out shares under this arrangement expired on March 8, 2026 as the required milestones were not met.

[0001805385-26-000012:mdna:96]
Change in Fair Value of Contingently Issuable/Returnable Common Stock Liability/Asset

[0001805385-26-000012:mdna:97]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock, referred to as Founder Shares. Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 1,897,500 Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones, subject to expiration in July 2026, and 517,500 Founder Shares were contributed to Give Evolv LLC. The 1,897,500 outstanding contingently issuable common shares are accounted for either as a liability, if still held at the Company's transfer agent, or as an asset as described below, and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income, net in the consolidated statements of operations and comprehensive loss.

[0001805385-26-000012:mdna:98]
Under the Founder Shares arrangement, Founder Shares may be transferred to third parties, subject to certain conditions. The unvested shares must be returned to the Company if the specified vesting conditions are not met. As of December 31, 2025, a total of 729,570 unvested shares had been transferred to individual brokerage accounts, resulting in a reduction to the contingently issuable common stock liability and recognition of the value of the shares as outstanding equity. The contractual obligation of the holders to return the transferred shares upon failure to meet vesting conditions is accounted for as a freestanding financial asset. This asset was initially recognized at fair value and is remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001805385-26-000012:mdna:99]
Change in Fair Value of Public Warrant Liability

[0001805385-26-000012:mdna:100]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are currently exercisable and expire in July 2026. We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger as a component of other income (expense), net in the consolidated statements of operations and comprehensive (loss) income with the offset to additional paid-in capital. The liability is subsequently remeasured at each reporting with changes in fair value.

[0001805385-26-000012:mdna:101]
Income Taxes

[0001805385-26-000012:mdna:102]
Our income tax provision consists of an estimate for federal, state, and foreign income taxes based on enacted rates in the jurisdictions in which we operate, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. We have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets.

[0001805385-26-000012:mdna:103]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was signed into law in the United States. The OBBBA introduces various corporate and international tax law changes with staggered effective dates through 2027. Key provisions include immediate R&D expensing, permanent bonus depreciation, modifications to interest expense limitations, and changes to certain international tax rules. The enacted legislation did not have a material impact on our financial position, results of operations, or effective tax rate for the year ended December 31, 2025, primarily due to our full valuation allowance position on U.S. deferred tax assets, immaterial current tax liabilities, and insignificant foreign earnings from Evolv UK. We will continue to monitor and evaluate all applicable provisions of the OBBBA and any potential future impact on our consolidated financial statements.

[0001805385-26-000012:mdna:104]
Reclassifications

[0001805385-26-000012:mdna:105]
During the three months ended March 31, 2025, the Company began classifying restructuring charges, which includes termination charges arising from severance obligations, incremental non-cash expense, and other customary employee benefit payments in connection with a reduction in force, within restructuring costs on the consolidated statements of operations and comprehensive loss, whereas the restructuring costs for these services has previously been included in cost of service revenue, research and development expenses, sales and marketing expenses, and general and administrative expenses. These reclassifications were made to align the presentation of restructuring charges with the Company's internal reporting and analysis. See Note 1, Nature of the Business and Basis of Presentation for additional information.

[0001805385-26-000012:mdna:106]
Results of Operations

[0001805385-26-000012:mdna:107]
Comparison of the Years Ended December 31, 2025 and 2024

[0001805385-26-000012:mdna:108]
The following table summarizes our results of operations for the years ended December 31, 2025 and 2024 (in thousands):

[0001805385-26-000012:mdna:109]
|  | Year Ended December 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 21,637 |  |  | $ | 6,464 |  |  | $ | 15,173 |  |  | 235 | % |
| Subscription revenue | 83,839 |  |  | 65,046 |  |  | 18,793 |  |  | 29 |  |
| Service revenue | 29,375 |  |  | 23,467 |  |  | 5,908 |  |  | 25 |  |
| License fee and other revenue | 11,054 |  |  | 8,888 |  |  | 2,166 |  |  | 24 |  |
| Total revenue | 145,905 |  |  | 103,865 |  |  | 42,040 |  |  | 40 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 24,320 |  |  | 10,735 |  |  | 13,585 |  |  | 127 |  |
| Cost of subscription revenue | 36,684 |  |  | 27,846 |  |  | 8,838 |  |  | 32 |  |
| Cost of service revenue | 8,410 |  |  | 5,225 |  |  | 3,185 |  |  | 61 |  |
| Cost of license fee and other revenue | 1,189 |  |  | 597 |  |  | 592 |  |  | 99 |  |
| Total cost of revenue | 70,603 |  |  | 44,403 |  |  | 26,200 |  |  | 59 |  |
| Gross profit | 75,302 |  |  | 59,462 |  |  | 15,840 |  |  | 27 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 20,619 |  |  | 23,446 |  |  | (2,827) |  |  | (12) |  |
| Sales and marketing | 45,626 |  |  | 60,637 |  |  | (15,011) |  |  | (25) |  |
| General and administrative | 54,858 |  |  | 56,602 |  |  | (1,744) |  |  | (3) |  |
| Restructuring costs | 2,662 |  |  | 860 |  |  | 1,802 |  |  | 210 |  |
| Loss on impairment of property and equipment | — |  |  | 224 |  |  | (224) |  |  | (100) |  |
| Total operating expenses | 123,765 |  |  | 141,769 |  |  | (18,004) |  |  | (13) |  |
| Loss from operations | (48,463) |  |  | (82,307) |  |  | 33,844 |  |  | 41 |  |
| Other income, net: |  |  |  |  |  |  |  |
| Interest expense | (1,732) |  |  | — |  |  | (1,732) |  |  | * |
| Interest income | 1,536 |  |  | 2,942 |  |  | (1,406) |  |  | (48) |  |
| Other income (expense), net | 99 |  |  | (83) |  |  | 182 |  |  | 219 |  |
| Change in fair value of contingent earn-out liability | 12,435 |  |  | 16,310 |  |  | (3,875) |  |  | (24) |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | 2,614 |  |  | 2,529 |  |  | 85 |  |  | 3 |  |
| Change in fair value of public warrant liability | 435 |  |  | 6,592 |  |  | (6,157) |  |  | (93) |  |
| Total other income, net | 15,387 |  |  | 28,290 |  |  | (12,903) |  |  | (46) |  |
| Loss before income taxes | (33,076) |  |  | (54,017) |  |  | 20,941 |  |  | 39 | % |
| Provision for income taxes | 62 |  |  | — |  |  | 62 |  |  | * |
| Net loss | $ | (33,138) |  |  | $ | (54,017) |  |  | $ | 20,879 |  |  | 39 | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (12) % |  | (66) % |  | N/A |  | 54 % |
| Subscription revenue | 56 % |  | 57 % |  | N/A |  | (1) % |
| Service revenue | 71 % |  | 78 % |  | N/A |  | (7) % |
| License fee and other revenue | 89 % |  | 93 % |  | N/A |  | (4) % |

[0001805385-26-000012:mdna:110]
54

[0001805385-26-000012:mdna:111]
*N/A – Not meaningful

[0001805385-26-000012:mdna:112]
Revenue, Cost of Revenue and Gross Profit

[0001805385-26-000012:mdna:113]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 243 new end-users during the year ended December 31, 2025, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001805385-26-000012:mdna:114]
Product Revenue

[0001805385-26-000012:mdna:115]
|  | Year Ended December 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Product revenue | $ | 21,637 |  |  | $ | 6,464 |  |  | $ | 15,173 |  |  | 235 | % |
| Cost of product revenue | $ | 24,320 |  |  | $ | 10,735 |  |  | $ | 13,585 |  |  | 127 | % |
| Gross loss - Product revenue | $ | (2,683) |  |  | $ | (4,271) |  |  | $ | 1,588 |  |  | 37 | % |
| Gross profit margin - Product revenue | (12) | % |  | (66) | % |  | N/A |  | 54 | % |

[0001805385-26-000012:mdna:116]
The increases in product revenue and cost of product revenue for the year ended December 31, 2025 compared to the prior year are primarily due to an increased utilization of our purchase subscription model, in which the customers purchase Evolv Express and Evolv eXpedite systems directly from us. In 2025, we were awarded a large customer contract with a U.S.-based education customer in Georgia, which contributed approximately $3.8 million to product revenue in 2025. The increase in product gross profit margin for the year ended December 31, 2025 compared to the year ended December 31, 2024 is primarily due to lower costs of second generation of Evolv Express systems compared to the first generation which was primarily shipping in 2024, a $0.6 million decrease in non-cancellable inventory purchase commitments, and a $0.9 million decrease in manufacturing expense during the year ended December 31, 2025, primarily related to the deployments of second generation of Evolv Express systems. These gross profit improvements were partially offset by the initial deployments of Evolv eXpedite systems, which, as a new product offering, reflect a higher initial cost to produce that we expect to gradually decline in the future and a $0.3 million in expense related to disposals of certain first generation Evolv Express systems during the year ended December 31, 2025 as compared to the same period in the prior year.

[0001805385-26-000012:mdna:117]
Subscription Revenue

[0001805385-26-000012:mdna:118]
|  | Year Ended December 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Subscription revenue | $ | 83,839 |  |  | $ | 65,046 |  |  | $ | 18,793 |  |  | 29 | % |
| Cost of subscription revenue | $ | 36,684 |  |  | $ | 27,846 |  |  | $ | 8,838 |  |  | 32 | % |
| Gross profit - Subscription revenue | $ | 47,155 |  |  | $ | 37,200 |  |  | $ | 9,955 |  |  | 27 | % |
| Gross profit margin - Subscription revenue | 56 | % |  | 57 | % |  | N/A |  | (1) | % |

[0001805385-26-000012:mdna:119]
The increases in subscription revenue, cost of subscription revenue, and gross profit are primarily due to continued growth in our customer base as of December 31, 2025 compared to the prior year, with a higher number of active Evolv Express and Evolv eXpedite systems deployed under our pure subscription model and an increase in short term rental subscription revenue during the year ended December 31, 2025. The gross profit margin remained consistent with the prior year primarily due to $3.3 million in expense related to disposals of certain first generation Evolv Express systems and an accrual of $1.2 million estimated field services costs related to the replacement of certain Express system parts during year ended December 31, 2025, offset by a $1.0 million impairment charge recorded during the year ended December 31, 2024, which related to certain of our software development projects that had previously been capitalized, and our ability to leverage our fixed costs over a higher revenue base and lower costs related to our second generation of Evolv Express systems.

[0001805385-26-000012:mdna:120]
Service Revenue

[0001805385-26-000012:mdna:121]
|  | Year Ended December 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Service revenue | $ | 29,375 |  |  | $ | 23,467 |  |  | $ | 5,908 |  |  | 25 | % |
| Cost of service revenue | $ | 8,410 |  |  | $ | 5,225 |  |  | $ | 3,185 |  |  | 61 | % |
| Gross profit - Service revenue | $ | 20,965 |  |  | $ | 18,242 |  |  | $ | 2,723 |  |  | 15 | % |
| Gross profit margin - Service revenue | 71 | % |  | 78 | % |  | N/A |  | (7) | % |

[0001805385-26-000012:mdna:122]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to the growth in the number of active revenue-generating purchase subscription units added through December 31, 2024, as well as active revenue-generating units purchased by customers in 2025, compared to the year ended December 31, 2024. The decrease in gross profit margin is primarily due to an accrual of $1.0 million estimated field services costs related to the replacement of certain Express system parts and increased amortization of capitalized software costs during year ended December 31, 2025 of $0.8 million due to the release of Evolv eXpedite and our second generation of Evolv Express systems.

[0001805385-26-000012:mdna:123]
License fee and other revenue

[0001805385-26-000012:mdna:124]
|  | Year Ended December 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| License fee and other revenue | $ | 11,054 |  |  | $ | 8,888 |  |  | $ | 2,166 |  |  | 24 | % |
| Cost of license fee and other revenue | $ | 1,189 |  |  | $ | 597 |  |  | $ | 592 |  |  | 99 | % |
| Gross profit - License fee and other revenue | $ | 9,865 |  |  | $ | 8,291 |  |  | $ | 1,574 |  |  | 19 | % |
| Gross profit margin - License fee and other revenue | 89 | % |  | 93 | % |  | N/A |  | (4) | % |

[0001805385-26-000012:mdna:125]
The increase in license fee and other revenue and gross profit was primarily driven by $8.1 million of license fees earned during the year ended December 31, 2025 compared to $7.2 million earned during the year ended December 31, 2024 under the Distribution and License Agreement, as well as a $0.6 million increase in installation and training service fees and $0.5 million revenue from the sale of demonstration systems. Although the unit sales through our distributor licensing model declined, the license fee and other revenue increased due to an increase in per-unit license fees for our second generation of Evolv Express systems. The decrease in gross profit margin is primarily due to an increase in personnel and overhead costs of $0.6 million during the year ended December 31, 2025.

[0001805385-26-000012:mdna:126]
Research and Development Expenses

[0001805385-26-000012:mdna:127]
56

[0001805385-26-000012:mdna:128]
|  | Year Ended December 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 15,796 |  |  | $ | 16,352 |  |  | $ | (556) |  |  | (3) | % |
| Materials and prototypes | 611 |  |  | 2,050 |  |  | (1,439) |  |  | (70) | % |
| Professional fees | 2,704 |  |  | 3,296 |  |  | (592) |  |  | (18) | % |
| Other | 1,508 |  |  | 1,748 |  |  | (240) |  |  | (14) | % |
|  | $ | 20,619 |  |  | $ | 23,446 |  |  | $ | (2,827) |  |  | (12) | % |

[0001805385-26-000012:mdna:129]
The decrease in personnel related expenses is primarily due to a $0.8 million decrease in payroll costs, which resulted primarily from the January 2025 reduction in force partially offset by an increase in short term incentive compensation, and a $0.2 million increase in stock-based compensation. The decrease in materials and prototypes expense is primarily due to a decrease of $0.9 million in design and engineering costs and $0.4 million write-off on unused prototype components recognized in the prior year, both of which relate primarily to the development of the next generation of our Evolv Express system and new product offerings. The decrease in professional fees primarily relates to a decrease in consulting costs incurred for product development and engineering of $0.6 million. Other expense decreased primarily due to reduction in supplies costs.

[0001805385-26-000012:mdna:130]
Sales and Marketing Expenses

[0001805385-26-000012:mdna:131]
|  | Year Ended December 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 35,361 |  |  | $ | 44,439 |  |  | $ | (9,078) |  |  | (20) | % |
| Advertising and direct marketing | 2,187 |  |  | 3,573 |  |  | (1,386) |  |  | (39) | % |
| Travel and entertainment | 2,646 |  |  | 4,777 |  |  | (2,131) |  |  | (45) | % |
| Professional fees | 2,226 |  |  | 3,576 |  |  | (1,350) |  |  | (38) | % |
| Other | 3,206 |  |  | 4,272 |  |  | (1,066) |  |  | (25) | % |
|  | $ | 45,626 |  |  | $ | 60,637 |  |  | $ | (15,011) |  |  | (25) | % |

[0001805385-26-000012:mdna:132]
The decrease in personnel related expenses is primarily due to a $3.5 million decrease in payroll costs, which resulted primarily from reductions in force in May 2024 and January 2025 partially offset by an increase in commission expense and short term incentive compensation, and a $5.4 million decrease in stock-based compensation, which also resulted primarily from the reductions in force. Stock-based compensation expense included in sales and marketing expenses was $5.6 million for the year ended December 31, 2025 compared to $10.9 million for the year ended December 31, 2024. The decrease in advertising and direct marketing expense is primarily due to a decrease in expenses related to trade shows and events of $1.1 million. The decrease in travel and entertainment expense is due to a decrease in travel costs for in-person sales meetings of $2.1 million as a result of our reductions in force. Professional fees decreased due to a decrease in marketing consulting costs of $1.4 million. Other expense decreased primarily due to a reduction in shipping costs related to demonstration units of $0.5 million and supplies costs of $0.4 million.

[0001805385-26-000012:mdna:133]
General and Administrative Expenses

[0001805385-26-000012:mdna:134]
|  | Year Ended December 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 25,408 |  |  | $ | 23,749 |  |  | $ | 1,659 |  |  | 7 | % |
| Professional fees | 9,879 |  |  | 8,266 |  |  | 1,613 |  |  | 20 | % |
| Insurance costs | 2,985 |  |  | 3,145 |  |  | (160) |  |  | (5) | % |
| Non-recurring professional fees and other expenses | 16,586 |  |  | 21,442 |  |  | (4,856) |  |  | (23) | % |
|  | $ | 54,858 |  |  | $ | 56,602 |  |  | $ | (1,744) |  |  | (3) | % |

[0001805385-26-000012:mdna:135]
57

[0001805385-26-000012:mdna:136]
The increase in personnel related expenses is due to a $0.9 million increase in payroll costs, which resulted primarily from an increase in short term incentive compensation partially offset by a decrease in severance expense, and a $0.7 million increase in stock-based compensation, mainly driven by the impact of forfeited stock-based awards during the year ended December 31, 2024 following the termination of certain executives. Professional fees increased primarily due to an increase in outsourced accounting consultancy of $2.0 million, partially offset by a decrease in audit and tax fees of $0.5 million. Non-recurring professional fees and other expenses decreased primarily due to insurance recoveries of $10.1 million and a decrease in information technology and software subscription costs of $0.4 million, partially offset by a $4.1 million increase in consulting and legal fees and audit fees incurred in connection with a previously disclosed investigation and restatement of prior period financial statements, $1.0 million of estimated net losses related to class action lawsuits, and an increase in rent of $0.9 million for additional leased space.

[0001805385-26-000012:mdna:137]
Loss On Impairment of Property and Equipment

[0001805385-26-000012:mdna:138]
Loss on impairment of property and equipment of $0.2 million for the year ended December 31, 2024 primarily related to the removal of certain Evolv Express systems and IT equipment from service, resulting in impairment of the remaining economic value of such systems. No loss on impairment of property and equipment was recognized for the year ended December 31, 2025.

[0001805385-26-000012:mdna:139]
Restructuring Costs

[0001805385-26-000012:mdna:140]
Restructuring costs of $2.7 million for the year ended December 31, 2025 resulted from the reduction in force in January 2025. Stock-based compensation expense included in restructuring costs was $0.5 million for the year ended December 31, 2025. Restructuring costs of $0.9 million for the year ended December 31, 2024 resulted from the reduction in force in May 2024.

[0001805385-26-000012:mdna:141]
Interest Expense

[0001805385-26-000012:mdna:142]
Interest expense of $1.7 million for the year ended December 31, 2025 related to interest on long-term debt, amortization of debt issuance costs, and unused commitment fees. No interest expense was recognized for the year ended December 31, 2024, as there was no debt outstanding during the period.

[0001805385-26-000012:mdna:143]
Interest Income

[0001805385-26-000012:mdna:144]
Interest income of $1.5 million and $2.9 million for the years ended December 31, 2025 and 2024, respectively, related primarily to interest earned on money market funds and the accretion of discounts on treasury bills. The interest earned decreased primarily due to lower average balances in interest-bearing accounts during the year ended December 31, 2025 compared to during the year ended December 31, 2024.

[0001805385-26-000012:mdna:145]
Change in Fair Value of Contingent Earn-out Liability

[0001805385-26-000012:mdna:146]
Change in the fair value of the contingent earn-out liability resulted in gains of $12.4 million and $16.3 million for the years ended December 31, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments.

[0001805385-26-000012:mdna:147]
Change in Fair Value of Contingently Issuable/Returnable Common Stock Liability/Asset

[0001805385-26-000012:mdna:148]
Change in the fair value of the contingently issuable/returnable common stock liability/asset resulted in gains of $2.6 million and $2.5 million gain for the years ended December 31, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments.

[0001805385-26-000012:mdna:149]
Change in Fair Value of Public Warrant Liability

[0001805385-26-000012:mdna:150]
Change in the fair value of the public warrant liability resulted in gains of $0.4 million and $6.6 million for the years ended December 31, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments.

[0001805385-26-000012:mdna:151]
Income Taxes

[0001805385-26-000012:mdna:152]
Our effective tax rate (“ETR”) on income before taxes for each of the years ended December 31, 2025 and December 31, 2024 was 0%. For the years ended December 31, 2025 and 2024, the ETR was primarily impacted by the full valuation allowance maintained on the Company’s net deferred tax assets and non-deductible fair value adjustments. We have provided a valuation allowance for all of our net deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001805385-26-000012:mdna:153]
Liquidity and Capital Resources

[0001805385-26-000012:mdna:154]
In accordance with Accounting Standards Update (“ASU”) No. 2014-15, Disclosures of Uncertainties about an Entity’s Ability to Continue as a Going Concern (Subtopic 205-40), management must evaluate whether there are conditions or events, considered in the aggregate, that raise substantial doubt about our ability to continue as a going concern within one year after the date that the financial statements are issued.

[0001805385-26-000012:mdna:155]
Our financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures, debt obligations, and general corporate needs. We expect these needs to continue as we develop and grow our business. As of December 31, 2025, we had $69.0 million in cash, cash equivalents, and marketable securities, with outstanding debt of $30.0 million and available additional debt of up to $45.0 million, as detailed below. We incurred a net loss of $33.1 million and $54.0 million for the years ended December 31, 2025 and 2024, respectively. Operating activities resulted in cash inflow of $18.7 million and cash outflow of $30.9 million during the years ended December 31, 2025 and 2024, respectively. We expect to continue to generate losses for the foreseeable future.

[0001805385-26-000012:mdna:156]
We maintain substantially all of our cash, cash equivalents, and marketable securities in accounts with U.S. and multi-national financial institutions and our cash deposits at these institutions exceed Federal Deposit Insurance Corporation insured limits. We do not believe we are exposed to any unusual credit risk or deposit concentration risk beyond the ordinary credit risk associated with commercial banking relationships.

[0001805385-26-000012:mdna:157]
As described below, on July 29, 2025 (the "Closing Date"), Evolv Technologies, Inc. entered into the $75.0 million MidCap Credit Agreement, the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's pure subscription sales model. The MidCap Credit Agreement provided for an initial $30.0 million term loan facility, a $30.0 million delayed draw facility (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit. On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs. As of December 31, 2025, $30.0 million under the initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available.

[0001805385-26-000012:mdna:158]
We expect our cash, cash equivalents, and marketable securities of $69.0 million as of December 31, 2025, together with cash we expect to generate from future operations and our borrowing availability under our Senior Secured Credit Facilities, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Annual Report on Form 10-K. As we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to strategically and carefully invest in various areas of the business to support that growth.

[0001805385-26-000012:mdna:159]
Under the MidCap Credit Agreement, we are also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that begins at $106.0 million on December 31, 2025 and increases quarterly thereafter; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum earnings before interest, taxes, depreciation, and amortization (“EBITDA”) covenant that takes effect on June 30, 2027. As of December 31, 2025, we are in full compliance with all applicable covenant requirements and expect to remain in compliance for a period of at least twelve months from March 10, 2026.

[0001805385-26-000012:mdna:160]
59

[0001805385-26-000012:mdna:161]
Financing Arrangements

[0001805385-26-000012:mdna:162]
On July 29, 2025, the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's pure subscription sales model. The MidCap Credit Agreement provides for an initial $30.0 million term loan facility (the “Initial Term Loan”), a $30.0 million delayed draw facility (the “Delayed Draw Term Loan”) (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit (the "Revolving Credit Facility”), each with a maturity date of July 1, 2030 (collectively, the “Senior Secured Credit Facilities”).

[0001805385-26-000012:mdna:163]
The Senior Secured Credit Facilities are guaranteed by the Company, and in the future, may be guaranteed by certain material subsidiaries. The Senior Secured Credit Facilities are secured by a first lien on substantially all of the assets of the Company. The borrowings under the Senior Secured Credit Facilities bear interest at a fluctuating rate per annum equal to the Term Secured Overnight Financing Rate (“Term SOFR”) and an applicable margin calculated depending on EBITDA. At closing, the applicable margin on Term SOFR loans was 5.25%. If the event described under the MidCap Credit Agreement related to Term SOFR occurs, a base rate is determined by reference to the higher of (1) the prime rate of Wells Fargo and (2) 2.00%. Monthly interest payments are due in arrears on the first day of each month. Principal repayments for the Initial Term Loan begin in August 2029, following a 48-month interest-only period, and will be repaid in equal monthly installments over the final 12 months of the loan term. The Revolving Credit Facility provides for an unused commitment fee of 0.25% on the undrawn portion of the facility.

[0001805385-26-000012:mdna:164]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary affirmative and negative covenants, including a minimum annual recurring revenue covenant, a minimum EBITDA covenant that takes effect on June 30, 2027, and a minimum liquidity covenant that would cease to apply following the resolution of certain litigation and regulatory matters, in addition to customary reporting requirements of periodic financial results. As of December 31, 2025, we were in full compliance with all covenant requirements. See Note 12, Long-term Debt for additional information related to the Senior Secured Credit Facilities.

[0001805385-26-000012:mdna:165]
Material Cash Requirements for Known Contractual and Other Obligations

[0001805385-26-000012:mdna:166]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of December 31, 2025. We anticipate fulfilling such commitments with our existing cash, cash equivalents, and marketable securities, as well as cash and cash equivalents obtained through operations and the proceeds from our Senior Secured Credit Facilities. Cash, cash equivalents, and marketable securities amounted to $69.0 million as of December 31, 2025.

[0001805385-26-000012:mdna:167]
We are party to a lease agreement for office space at our headquarters in Waltham, MA. During the three months ended March 31, 2024, we amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. Additionally, in August 2024, we amended the lease agreement again to expand our footprint in our headquarters and extend the term of the lease through May 2031. Per the second lease amendment, we are no longer required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space. Total future minimum lease payments under this noncancelable operating lease amount to $17.4 million as of December 31, 2025.

[0001805385-26-000012:mdna:168]
We generally contract with Columbia Tech, one of our contract manufacturers, on a cancellable purchase-order basis to provide manufacturing services for our equipment sold or leased to customers. While these contracts are cancellable by us upon prior notice, payments due upon cancellation may consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. Additionally, the recently executed agreement with the Company's new contract manufacturer, Plexus, includes provisions for which order volumes that fall short of our forecasts may result in purchase commitments. These payments are not determinable but could result in a material purchase commitment if we were to cancel our open purchase orders.

[0001805385-26-000012:mdna:169]
On March 25, 2024 and November 1, 2024, putative class action lawsuits were filed against the Company in the United States District Court for the District of Massachusetts. As of December 31, 2025, the Company has recognized a settlement accrual of $15.0 million and an estimated insurance recovery of $14.0 million. See Note 19, Commitments and Contingencies for additional information.

[0001805385-26-000012:mdna:170]
Cash Flows

[0001805385-26-000012:mdna:171]
The following table sets forth a summary of cash flows for the periods presented:

[0001805385-26-000012:mdna:172]
|  | Year EndedDecember 31, |
|  | 2025 |  | 2024 |  |  |
| Net cash provided by (used in) operating activities | $ | 18,669 |  |  | $ | (30,853) |  |  |  |
| Net cash used in investing activities | (41,826) |  |  | (1,399) |  |  |  |
| Net cash provided by financing activities | 35,401 |  |  | 1,809 |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | (109) |  |  | 21 |  |  |  |
| Net increase (decrease) in cash and cash equivalents | $ | 12,135 |  |  | $ | (30,422) |  |  |  |

[0001805385-26-000012:mdna:173]
Operating Activities

[0001805385-26-000012:mdna:174]
|  | Year EndedDecember 31, |
|  | 2025 |  | 2024 |  |  |
| Net loss | $ | (33,138) |  |  | $ | (54,017) |  |  |  |
| Adjustments to reconcile net loss to net cash provided by operating activities | 38,542 |  |  | 22,504 |  |  |  |
| Changes in operating assets and liabilities | 13,265 |  |  | 660 |  |  |  |
| Net cash provided by (used in) operating activities | $ | 18,669 |  |  | $ | (30,853) |  |  |  |

[0001805385-26-000012:mdna:175]
Net loss decreased from $54.0 million for the year ended December 31, 2024 to $33.1 million for the year ended December 31, 2025, as discussed in "Results of Operations" above.

[0001805385-26-000012:mdna:176]
Adjustments to reconcile net loss to net cash used in operating activities for the year ended December 31, 2025 include $21.1 million of stock-based compensation expense, $24.3 million of depreciation and amortization, and $3.8 million of loss on disposal of property and equipment, offset by $15.5 million of an aggregate change in fair value of the contingent earn-out liability, contingently issuable/returnable common stock liability/asset, and public warrant liability. For the year ended December 31, 2024, such adjustments included $24.8 million of stock-based compensation expense and $17.4 million of depreciation and amortization, offset by $25.4 million of an aggregate change in fair value of the earn-out liability, contingently issuable/returnable common stock liability/asset, and public warrant liability.

[0001805385-26-000012:mdna:177]
Changes in operating assets and liabilities for the year ended December 31, 2025 are primarily related to the following:

[0001805385-26-000012:mdna:178]
•$18.9 million increase in accrued expenses and other current liabilities primarily due to a legal settlement offer accrual and an increase in bonus accrual, partially offset by a decrease in accrued vendor payables;

[0001805385-26-000012:mdna:179]
•$9.1 million decrease in inventory primarily due to an increased focus on efficient inventory management, partially offset by a decrease in products expected to be leased to customers;

[0001805385-26-000012:mdna:180]
•$6.9 million increase in deferred revenue due to a higher volume of sales, including upgrades by existing customers to the second generation of Evolv Express; and

[0001805385-26-000012:mdna:181]
•$3.8 million increase in accounts payable (excluding the non-cash portion related to capital expenditures incurred but not yet paid from December 31, 2024 to December 31, 2025) due primarily to the timing of vendor payments; partially offset by

[0001805385-26-000012:mdna:182]
•$22.6 million increase in prepaid expenses and other current assets primarily due to estimated outstanding insurance recoveries and an increase in advance payments to vendors; and

[0001805385-26-000012:mdna:183]
•$2.3 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers.

[0001805385-26-000012:mdna:184]
Changes in operating assets and liabilities for the year ended December 31, 2024 are primarily related to the following:

[0001805385-26-000012:mdna:185]
61

[0001805385-26-000012:mdna:186]
•$7.0 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001805385-26-000012:mdna:187]
•$7.9 million increase in inventory primarily due to raw material purchase increase for the next generation of Evolv Express systems and Evolv eXpedite, partially offset by inventory decrease of first generation of Evolv Express systems for the ongoing transition to the next generation of Evolv Express systems;

[0001805385-26-000012:mdna:188]
•$1.1 million decrease in operating lease liability due to amortization;

[0001805385-26-000012:mdna:189]
•$1.4 million increase in commission assets due to a higher volume of sales; partially offset by

[0001805385-26-000012:mdna:190]
•$12.8 million increase in deferred revenue to a higher volume of sales; and

[0001805385-26-000012:mdna:191]
•$4.5 million increase in accrued expenses and other current liabilities due to the timing of certain payments.

[0001805385-26-000012:mdna:192]
Investing Activities

[0001805385-26-000012:mdna:193]
For the year ended December 31, 2025, cash used in investing activities was $41.8 million, consisting of $31.4 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express systems to be leased to customers and $5.6 million for the development of internal-use software and software embedded in products to be sold or leased, offset by a $4.8 million of net cash used in purchases and redemptions of marketable securities.

[0001805385-26-000012:mdna:194]
For the year ended December 31, 2024, cash provided by investing activities was $1.4 million, consisting of $31.2 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express systems to be leased to customers and $6.1 million for the development of internal-use software and software embedded in products to be sold or leased, offset by a net $35.9 million inflow related to purchases and redemptions of marketable securities.

[0001805385-26-000012:mdna:195]
Financing Activities

[0001805385-26-000012:mdna:196]
For the year ended December 31, 2025, net cash provided by financing activities was $35.4 million, consisting of $26.3 million in net proceeds from debt issuance under the drawn Initial Term Loan and $9.1 million of proceeds from the exercise of stock options.

[0001805385-26-000012:mdna:197]
For the year ended December 31, 2024, cash provided by financing activities was $1.8 million, consisting of proceeds from the exercise of stock options.

[0001805385-26-000012:mdna:198]
Critical Accounting Estimates

[0001805385-26-000012:mdna:199]
Our consolidated financial statements are prepared in accordance with generally accepted accounting principles in the United States. The preparation of our consolidated financial statements and related disclosures requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, costs and expenses, and the disclosure of contingent assets and liabilities in our consolidated financial statements. We base our estimates on historical experience, known trends and events and various other factors that we believe are reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. We evaluate our estimates and assumptions on an ongoing basis. Our actual results may differ from these estimates under different assumptions or conditions.

[0001805385-26-000012:mdna:200]
While our significant accounting policies are described in more detail in Note 2 to our consolidated financial statements, we believe that the following accounting policies are those most critical to the judgments and estimates used in the preparation of our consolidated financial statements.

[0001805385-26-000012:mdna:201]
Revenue Recognition

[0001805385-26-000012:mdna:202]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement, (4) license fees under the Distribution and License Agreement, and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001805385-26-000012:mdna:203]
Product Revenue

[0001805385-26-000012:mdna:204]
62

[0001805385-26-000012:mdna:205]
We derive a portion of our revenue from the sale of our Evolv Express and Evolv eXpedite equipment and related add-on accessories to customers. Customers are billed and pay for the product at the time of sale which is generally at the beginning of the associated subscription term (see “Service Revenue” below). Revenue is recognized pursuant to the guidelines detailed under "Standalone Selling Price" below when control of the product has transferred to the customer, which follows the terms of each contract.

[0001805385-26-000012:mdna:206]
Subscription Revenue

[0001805385-26-000012:mdna:207]
Subscription revenue is comprised of revenue derived from leasing Evolv Express and Evolv eXpedite systems to our customers. Lease terms are typically four years and customers generally pay an annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001805385-26-000012:mdna:208]
Lease arrangements generally include both lease and non-lease components. The non-lease components relate to (1) distinct services, including professional services, SaaS, and maintenance, and (2) any add-on accessories. Professional services are included in license fees and other revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive loss.

[0001805385-26-000012:mdna:209]
Service Revenue

[0001805385-26-000012:mdna:210]
Service revenue consists of subscription-based SaaS and maintenance revenue related to products sold to a customer. Customers generally pay an annual fixed payment for SaaS and maintenance. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically four years.

[0001805385-26-000012:mdna:211]
License Fee and Other Revenue

[0001805385-26-000012:mdna:212]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from our third-party manufacturer to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration.

[0001805385-26-000012:mdna:213]
Revenue from Reseller Partners

[0001805385-26-000012:mdna:214]
A majority of our revenue is generated by sales in conjunction with our reseller partners. When we transact with a reseller partner, our contractual arrangement is with the reseller partner and not with the end-use customer. Whether we transact with a reseller partner and receive the order from a reseller partner or directly from an end-use customer, our revenue recognition policy and resulting pattern of revenue recognition is the same.

[0001805385-26-000012:mdna:215]
Standalone Selling Price

[0001805385-26-000012:mdna:216]
We allocate the transaction price to each distinct performance obligation based on the standalone selling price (“SSP”) of each product or service. Our contracts may include multiple performance obligations when customers purchase a combination of products and services. When our customer arrangements have multiple performance obligations that contain a lease as well as distinct services that are delivered simultaneously, we allocate the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, we allocate the contract’s transaction price to each performance obligation on a relative SSP basis.

[0001805385-26-000012:mdna:217]
Stock-Based Compensation

[0001805385-26-000012:mdna:218]
We measure stock-based option awards granted to employees, consultants and directors based on their fair value on the date of grant using the Black-Scholes option-pricing model. Compensation expense for those awards is recognized, net of forfeitures, over the requisite service period, which is generally the vesting period of the respective award.

[0001805385-26-000012:mdna:219]
Prior to the closing of the Merger, the fair value of each stock option grant was estimated on the date of grant using the Black-Scholes option-pricing model, which uses the following inputs: (1) the fair value per share of the common stock issuable upon exercise of the option, (2) the expected term of the option, (3) expected volatility of the price of the common stock, (4) the risk-free interest rate, and (5) the expected dividend yield.

[0001805385-26-000012:mdna:220]
After the closing of the Merger, we determine the fair value of each share of common stock underlying stock-based awards based on the closing price of our common stock as reported by Nasdaq on the date of grant.

[0001805385-26-000012:mdna:221]
The Black-Scholes option-pricing model uses as inputs the fair value of our common shares and assumptions we make for the volatility of our common shares, the expected term of our stock options, the risk-free interest rate for a period that approximates the expected term of our stock options, and our expected dividend yield. As a result of being a private company prior to the Merger, we lacked sufficient company-specific historical and implied volatility information to solely utilize its own data for purposes of establishing the volatility assumption for use in the Black-Scholes model. Therefore, we estimated our expected share volatility based on a mix of company-specific historical volatility and historical volatility of a publicly traded set of peer companies. Once we had sufficient company-specific historical and implied volatility information, we estimated our expected share volatility based on the average of company-specific historical and implied volatility.

[0001805385-26-000012:mdna:222]
Additionally, beginning in 2025, we began granting Market-based Stock Units (“MSUs”) to certain of our employees. These MSUs are subject to certain vesting conditions based on the appreciation of our stock price as well as continued service over a specified term. The estimated fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of our stock price throughout the performance period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.

[0001805385-26-000012:mdna:223]
Valuation of Inventory

[0001805385-26-000012:mdna:224]
Inventory is valued at the lower of cost or net realizable value. Cost is computed using the weighted average method. We regularly review inventory quantities on-hand for excess and obsolete inventory and, when circumstances indicate, record charges to write down inventories to their estimated net realizable value, after evaluating historical sales, future demand, our estimates of forecasted net revenue, market conditions and expected product life cycles. A significant change in the timing or level of demand for our products as compared to forecasted amounts may result in recording additional write-offs. Such charges are classified as cost of product revenue in the statements of operations and comprehensive loss. Any write-down of inventory to net realizable value creates a new cost basis.

[0001805385-26-000012:mdna:225]
Capitalized Software

[0001805385-26-000012:mdna:226]
Software development costs consist of certain consulting costs and compensation expenses for employees who devote time to the development of our internal-use software and software embedded in products to be sold or leased, as well as certain upgrades and enhancements that are expected to result in enhanced functionality. We amortize these development costs over the estimated useful life of four years. We determined that a four-year life is appropriate for our capitalized software based on our best estimate of the useful life of the software after considering factors such as continuous developments in the technology, obsolescence, and anticipated life of the service offering before significant upgrades. Management evaluates the useful lives of these assets on a quarterly basis and tests for impairment whenever events or changes in circumstances occur that could impact the recoverability of these assets.

[0001805385-26-000012:mdna:227]
We determine the amount of software costs to be capitalized based on the amount of time spent by our developers and consultants on projects in the application stage of development. There is judgment in estimating the time allocated to a particular project in the application stage. A significant change in the time spent on each project could have a material impact on the amount capitalized and related amortization expense in subsequent periods.

[0001805385-26-000012:mdna:228]
Leases

[0001805385-26-000012:mdna:229]
To determine the residual value estimates and useful life of equipment that we lease to our customers, we are required to make judgments about future events that are subject to risks and uncertainties outside of their control, such as inventory levels of new equipment, changing consumer preferences, new technology and mandatory regulations. We have disciplines related to the management and maintenance of our leased equipment designed to manage the risk associated with the residual values of our revenue generating equipment. We periodically review and adjust, as appropriate, the

[0001805385-26-000012:mdna:230]
estimated residual values and useful lives of existing revenue generating equipment for the purposes of classifying transactions as operating or sales-type leases and recording depreciation expense. Based on the results of our analysis, we may adjust the estimated residual values and useful lives of individual assets of our revenue generating equipment each year.

[0001805385-26-000012:mdna:231]
Partner Rebate Program

[0001805385-26-000012:mdna:232]
For the fiscal year 2025, the Company implemented a channel partner rebate program (the “Rebate Program”) for eligible resellers. Under the Rebate Program, eligible resellers that attain at least 25% of their current fiscal year total contract value (“TCV”) target (“Annual Target”) in a given quarter are eligible for a rebate based upon a percentage of their TCV for that quarter. In addition, resellers that meet their Annual Target are eligible for a one-time rebate based upon a percentage of their total fiscal year TCV, applied as a credit in the subsequent fiscal year. All rebates are issued as credits against future purchases, and no cash rebates are paid. Unused rebate credits are forfeited in the event of a reseller agreement termination.
