# EVLV note change history — 0001805385-25-000009 → 0001805385-25-000017


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-11-13):
[0001805385-25-000017:note_history:1]
Commitments and Contingencies
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for
  (was, 2025-08-14, similarity 0.6381):
[0001805385-25-000009:note_history:1]
Commitments and Contingencies
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. Below is a summary of the various types of matters subject to this guidance.

- added (2025-11-13):
[0001805385-25-000017:note_history:2]
contingencies. The Company expenses the costs related to such legal proceedings as incurred. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. Below is a summary of the various types of matters subject to this guidance.

- added (2025-11-13):
[0001805385-25-000017:note_history:3]
Class Action Lawsuits

- changed (2025-11-13):
[0001805385-25-000017:note_history:4]
On March 25, 2024 and November 1, 2024, putative class action lawsuits were filed against the Company in the United States District Court for the District of Massachusetts. On December 13, 2024, the Court consolidated the two lawsuits into one action (the “Class Action”), pursuant to which a consolidated amended complaint was filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees. The Company filed its motion to dismiss the Class Action on March 28, 2025, and the Class Action Plaintiffs filed their opposition to the motion to dismiss on June 24, 2025. On June 30, 2025, the Court issued an order staying the Class Action, including disposition on the motion to dismiss, pending settlement negotiations. On August 5, 2025, the parties to the Class Action engaged in mediation and reached a settlement in principle in the amount of $15.0 million, which is subject to negotiation of definitive documentation and court approval, of which the Company estimated that $14.0 million would be funded by the Company's Directors and Officers insurance coverage. On August 19, 2025, the Court issued an order continuing the stay and ordering Class Action Plaintiffs to file a motion for preliminary approval of the settlement by December 15, 2025.
  (was, 2025-08-14, similarity 0.6933):
[0001805385-25-000009:note_history:4]
On March 25, 2024 and November 1, 2024, putative class action lawsuits were filed against the Company in the United States District Court for the District of Massachusetts. On December 13, 2024, the Court consolidated the two lawsuits into one action (the “Class Action”), pursuant to which a consolidated amended complaint was filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees. The

- added (2025-11-13):
[0001805385-25-000017:note_history:5]
As of September 30, 2025, the Company has recognized a settlement accrual of $15.0 million and an estimated insurance recovery of $14.0 million, which are included in accrued expenses and other current liabilities and prepaid and other current assets in the condensed consolidated balance sheets, respectively, representing management's best estimate of the outcome. For the three and nine months ended September 30, 2025, the Company recognized $0 and $1.0 million,

- added (2025-11-13):
[0001805385-25-000017:note_history:6]
respectively, for the estimated net loss in general and administrative expense in the condensed consolidated statements of operations and comprehensive loss.

- added (2025-11-13):
[0001805385-25-000017:note_history:7]
Derivative Lawsuits

- changed (2025-11-13):
[0001805385-25-000017:note_history:8]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “First Delaware Derivative Action”). The First Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. The First Delaware Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.
  (was, 2025-08-14, similarity 0.9884):
[0001805385-25-000009:note_history:8]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Delaware Derivative Action”). The Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. The Delaware Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.

- added (2025-11-13):
[0001805385-25-000017:note_history:9]
On October 2, 2025, another shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Second Delaware Derivative Action”). The Second Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers and directors, NHIC directors and officers, and nominally against the Company. Plaintiff Robert Patrick, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duties, unjust enrichment, abuse of control, gross mismanagement, and waste of corporate assets, seeking various forms of relief, including equitable relief directing reform of corporate governance and internal controls, monetary damages including restitution and other fees, and a declaration that the individual defendants breached or aided and abetted breaches of fiduciary duties. On November 7, 2025, the Delaware Court of Chancery entered an order staying the Second Delaware Derivative Action pending the outcome of renewed motions to dismiss or final disposition of the Class Action.

- added (2025-11-13):
[0001805385-25-000017:note_history:10]
The Company expects to incur legal and professional services expenses associated with this litigation in future periods. The Company will recognize these expenses as services are received. We cannot reasonably estimate a range of possible losses at this time for the derivative lawsuits, as the proceedings remain in the early stages, alleged damages have not been specified, and the derivative actions are stayed. For these reasons, the Company has not recorded a loss contingency liability for the derivative lawsuits as of September 30, 2025.

- added (2025-11-13):
[0001805385-25-000017:note_history:11]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered

- added (2025-11-13):
[0001805385-25-000017:note_history:12]
the cancellation period, and of these, 5 customers representing 24 Evolv Express systems elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the year ended December 31, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and nine months ended September 30, 2025, as revenue continued to be recognized on these deals through the cancellation dates of each contract, all of which were in June 2025, and all systems have been removed from our subscription base as of September 30, 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of the effective date of the Order were impacted by the cancellations, which has been excluded from the remaining performance obligations disclosed in Note 5 Revenue Recognition.

- changed (2025-11-13):
[0001805385-25-000017:note_history:13]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of such matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.
  (was, 2025-08-14, similarity 0.9899):
[0001805385-25-000009:note_history:13]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of legal and regulatory matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.

- changed (2025-11-13):
[0001805385-25-000017:note_history:14]
Any resolution or litigation with the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to the SEC matter. In addition to the expected insurance recovery discussed above related to the Class Action litigation, the Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matter, including certain expenses that have previously been paid, are also expected to be reimbursed. As of September 30, 2025, the Company recognized an estimated loss recovery related to insurance coverage for these matters of $1.2 million and $6.8 million for the three and nine months ended September 30, 2025, respectively, which was recorded as a reduction of general and administrative expense in the condensed consolidated statements of operations and comprehensive loss. As of September 30, 2025, $5.6 million of these recoveries have been paid out by the Company's insurance provider. The $1.2 million remaining estimated recovery is included in prepaid and other current assets in the condensed consolidated balance sheets as of September 30, 2025. This amount reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company has determined are probable of recovery. $1.0 million of recoveries were paid out in the fourth quarter to date. As it relates to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated
  (was, 2025-08-14, similarity 0.6145):
[0001805385-25-000009:note_history:14]
Any resolution or litigation with the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to SEC matter. In addition to the expected insurance recovery discussed above related to the Class Action litigation, the Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matter, including certain expenses that have previously been paid, are also expected to be reimbursed. As of June 30, 2025, the Company recognized an estimated loss recovery related to insurance coverage for these matters of $1.7 million and $5.6 million for the three and six months ended June 30, 2025, respectively, which was recorded as a reduction of general and administrative expense in the condensed consolidated statements of operations and comprehensive loss. As of June 30, 2025, $0.9 million of these recoveries have been paid out by the Company's insurance provider. The $4.7 million remaining estimated recovery is included in prepaid and other current assets in the condensed consolidated balance sheets as of June 30, 2025. This amount reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company has determined are probable of recovery. $4.1 million of recoveries were paid out in July 2025. As it relates to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.

- added (2025-11-13):
[0001805385-25-000017:note_history:15]
insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.

- changed (2025-11-13):
[0001805385-25-000017:note_history:16]
The Company generally contracts with its contract manufacturer, Columbia Tech, on a cancellable purchase-order basis to provide manufacturing services for the Company's equipment sold or leased to customers. While these contracts are cancellable by the Company upon prior notice, payments due upon cancellation may consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. Additionally, the recently executed agreement with the Company's new contract manufacturer, Plexus, includes provisions for which order volumes that fall short of our forecasts may result in purchase commitments. These payments are not determinable, but could result in a material purchase commitment if the Company were to cancel their open purchase orders.
  (was, 2025-08-14, similarity 0.6225):
[0001805385-25-000009:note_history:16]
The Company generally contracts with its contract manufacturer, Columbia Tech, on a cancellable, purchase-order basis. The Company has a contract in the normal course of business with Columbia Tech to provide manufacturing services for the Company's equipment sold or leased to customers. While these contracts are cancellable by the Company upon prior notice, payments due upon cancellation consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. These payments are not determinable, but could result in a material purchase commitment if the Company were to cancel their open purchase orders.

- removed (2025-11-13):
[0001805385-25-000009:note_history:17]
Company filed its motion to dismiss the Class Action on March 28, 2025, and the Class Action Plaintiffs filed their opposition to the motion to dismiss on June 24, 2025. On June 30, 2025, the Court issued an order staying the Class Action, including disposition on the motion to dismiss, pending settlement negotiations.

- removed (2025-11-13):
[0001805385-25-000009:note_history:18]
The Company expects to incur legal and professional services expenses associated with this litigation in future periods. The Company will recognize these expenses as services are received. We cannot reasonably estimate a range of possible losses at this time for the derivative lawsuits, as the proceedings remain in the early stages, alleged damages have not been specified, and the derivative actions are stayed. For these reasons, the Company has not recorded a loss contingency liability for the derivative lawsuits as of June 30, 2025. On August 5, 2025, the parties to the Class Action engaged in mediation and reached a settlement in principle in the amount of $15.0 million, which is subject to negotiation of definitive documentation and court approval, of which the Company estimated that $14.0 million would be funded by D&O insurance. As of June 30, 2025, the Company recognized a settlement accrual of $15.0 million and an estimated insurance recovery of $14.0 million, which are included in accrued expenses and other current liabilities and prepaid and other current assets in the condensed consolidated balance sheets, respectively. The Company recognized the net $1.0 million as an estimated loss in general and administrative expense in the condensed consolidated statements of operations and comprehensive loss for both the three and six months ended June 30, 2025.

- removed (2025-11-13):
[0001805385-25-000009:note_history:19]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, 5 customers representing 24 Evolv Express systems elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the year ended December 31, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and six months ended June 30, 2025, as revenue continued to be

- removed (2025-11-13):
[0001805385-25-000009:note_history:20]
recognized on these deals through the cancellation dates of each contract, all of which were in June 2025, and all systems have been removed from our subscription base as of June 30, 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of the effective date of the Order were impacted by the cancellations, which has been excluded from the remaining performance obligations disclosed in Note 6 Revenue Recognition.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-11-13):
[0001805385-25-000017:note_history:21]
The Company offers two major products, Evolv Express® and Evolv eXpedite™, which are designed to efficiently screen high volumes of people and bags for concealed threats. These products and their associated services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

- changed (2025-11-13):
[0001805385-25-000017:note_history:22]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. (“Evolv UK”) and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”). References to the “Investigation” refer to the investigation commenced in September 2024 by an ad hoc committee of independent directors of the Company's Board of Directors into its sales practices, as previously disclosed in our Annual Report on Form 10-K for the year ended December 31, 2024.
  (was, 2025-08-14, similarity 0.868):
[0001805385-25-000009:note_history:22]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. (“Evolv UK”) and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).

- added (2025-11-13):
[0001805385-25-000017:note_history:23]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures, debt obligations, and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of September 30, 2025, the Company had $56.2 million in cash, cash equivalents, and marketable securities, with outstanding debt of $28.5 million and available additional debt of up to $45.0 million, as detailed below. We incurred a net loss of $44.0 million and $38.3 million for the nine months ended September 30, 2025 and 2024, respectively, and operating activities resulted in cash inflow of $3.1 million and cash outflow of $34.1 million during the nine months ended September 30, 2025 and 2024, respectively. We expect to continue to generate losses for the foreseeable future.

- added (2025-11-13):
[0001805385-25-000017:note_history:24]
On July 29, 2025 (the “Closing Date”), the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's

- added (2025-11-13):
[0001805385-25-000017:note_history:25]
subscription sales model. The MidCap Credit Agreement provided an initial $30.0 million term loan facility (the “Initial Term Loan”), a $30.0 million delayed draw facility (the “Delayed Draw Term Loan”) (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit (the “Revolving Credit Facility”), each with a maturity date of July 1, 2030 (collectively, the “Senior Secured Credit Facilities”). On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs paid at closing. As of September 30, 2025, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available. See Note 9, Long-term Debt for additional information.

- changed (2025-11-13):
[0001805385-25-000017:note_history:26]
The Company expects its cash, cash equivalents, and marketable securities of $56.2 million as of September 30, 2025, together with cash it expects to generate from future operations and borrowing availability under the Senior Secured Credit Facilities, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth.
  (was, 2025-08-14, similarity 0.99):
[0001805385-25-000009:note_history:26]
The Company expects its cash, cash equivalents, and marketable securities of $36.9 million as of June 30, 2025, together with cash it expects to generate from future operations and borrowing availability under the Senior Secured Credit Facilities, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth.

- added (2025-11-13):
[0001805385-25-000017:note_history:27]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that begins at $106.0 million on December 31, 2025 and increases quarterly thereafter. The minimum required ARR on December 31, 2026 is $111.3 million. As of September 30, 2025, the Company’s ARR was $117.2 million, which is sufficient to satisfy the minimum required ARR through December 31, 2027; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. As of September 30, 2025, the minimum liquidity required is $15.0 million, and liquidity, as defined in the agreement, was $71.1 million. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum EBITDA covenant that takes effect on June 30, 2027. As of September 30, 2025, the Company is in full compliance with all applicable covenant requirements, and expects to remain in compliance for a period of at least twelve months from November 13, 2025.

- changed (2025-11-13):
[0001805385-25-000017:note_history:28]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2025, and for the three and nine months ended September 30, 2025 and 2024 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2024 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2025, the results of its operations for the three and nine months ended September 30, 2025 and 2024 and cash flows for the nine months ended September 30, 2025 and 2024. The results for the three and nine months ended September 30, 2025 are not necessarily indicative of results to be expected for the year ending December 31, 2025, any other interim periods, or any future year or period. These interim unaudited condensed consolidated financial statements should be read in conjunction with the financial statements included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024.
  (was, 2025-08-14, similarity 0.6617):
[0001805385-25-000009:note_history:28]
The accompanying unaudited condensed consolidated financial statements as of June 30, 2025, and for the three and six months ended June 30, 2025 and 2024 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2024 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of June 30, 2025, the results of its operations for the three and six months ended June 30, 2025 and 2024 and cash flows for the six months ended June 30, 2025 and 2024. The results for the three and six months ended June 30, 2025 are not necessarily indicative of results to be expected for the year ending December 31, 2025, any other interim periods, or any future year or period. These interim unaudited condensed consolidated financial statements should be read in conjunction with the financial statements included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024.

- changed (2025-11-13):
[0001805385-25-000017:note_history:29]
During the three months ended March 31, 2025, the Company began classifying restructuring charges, which includes termination charges arising from severance obligations, incremental non-cash expense, and other customary employee benefit payments in connection with a reduction in force, within restructuring costs on the condensed consolidated statements of operations and comprehensive loss, whereas the restructuring costs for these services had previously been included in cost of service revenue, research and development expenses, sales and marketing expenses,
  (was, 2025-08-14, similarity 0.6935):
[0001805385-25-000009:note_history:29]
During the three months ended March 31, 2025, the Company began classifying restructuring charges, which includes termination charges arising from severance obligations, incremental non-cash expense, and other customary employee benefit payments in connection with a reduction in force, within restructuring costs on the condensed consolidated statements of operations and comprehensive loss, whereas the restructuring costs for these services had previously been included in cost of service revenue, research and development expenses, sales and marketing expenses, and general and administrative expenses. These reclassifications were made to align the presentation of restructuring charges with the Company's internal reporting and analysis. The reclassifications increased gross profit by $0.2 million for both the three and six months ended June 30, 2024 and did not impact total loss from operations or total net loss for any period. Prior year amounts included in this Quarterly Report on Form 10-Q have been reclassified to conform to the current presentation.

- added (2025-11-13):
[0001805385-25-000017:note_history:30]
and general and administrative expenses. These reclassifications were made to align the presentation of restructuring charges with the Company's internal reporting and analysis. There were no reclassifications for the three months ended September 30, 2024. The reclassifications increased gross profit by $0.2 million for the nine months ended September 30, 2024 and did not impact total loss from operations or total net loss for any period. Prior year amounts included in this Quarterly Report on Form 10-Q have been reclassified to conform to the current presentation.

- changed (2025-11-13):
[0001805385-25-000017:note_history:31]
For the nine months ended September 30, 2024, the reclassifications resulted in an increase in restructuring costs of $0.9 million, and a corresponding decrease in cost of service revenue, sales and marketing expenses, and general and administrative expenses of $0.2 million, $0.7 million, and less than $0.1 million, respectively.
  (was, 2025-08-14, similarity 0.8927):
[0001805385-25-000009:note_history:31]
For both the three and six months ended June 30, 2024, the reclassifications resulted in an increase in restructuring costs of $0.9 million, and a corresponding decrease in cost of service revenue, sales and marketing expenses, and general and administrative expenses of $0.2 million, $0.7 million, and less than $0.1 million, respectively.

- added (2025-11-13):
[0001805385-25-000017:note_history:32]
During the three months ended September 30, 2025, the Company recorded an out-of-period correction to decrease other income (expense) by $0.9 million, decrease contingently issuable common stock liability by $2.3 million, increase other assets by $2.0 million and increase additional paid in capital by $3.4 million. The out-of-period adjustment was recorded to correct the accounting for the fair value of the contingently issuable common shares and the contingently returnable common stock, as described in more detail in Note 4, Fair Value Measurements. Management evaluated the accounting impacts on prior periods based on the historical dates of transfers, concluding that such impacts were not material to the historical financial statements.

- removed (2025-11-13):
[0001805385-25-000009:note_history:33]
The Company recently launched a new product offering, Evolv eXpedite™, an autonomous AI-based weapons detection system for bags. This new offering, as well as existing products such as Evolv Express®, are designed to be integrated layers for detection as part of a unified Evolv Safer Experience System™. These products and their associated services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

- removed (2025-11-13):
[0001805385-25-000009:note_history:34]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of June 30, 2025, the Company had $36.9 million in cash, cash equivalents, and marketable securities. The Company incurred a net loss of $42.2 million and $7.9 million for the six months ended June 30, 2025 and 2024, respectively. The Company incurred cash outflows from operating activities of $0.4 million and $37.7 million during the six months ended June 30, 2025 and 2024, respectively. The Company expects to continue to generate losses for the foreseeable future.

- removed (2025-11-13):
[0001805385-25-000009:note_history:35]
On July 29, 2025, the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's subscription sales model. The MidCap Credit Agreement provides for an initial $30.0 million term loan facility, a $30.0 million delayed draw facility (available for drawdown during the two-year period following the closing date), and a $15.0 million revolving line

- removed (2025-11-13):
[0001805385-25-000009:note_history:36]
of credit, each with a term of five years (collectively, the "Senior Secured Credit Facilities"). At closing, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs incurred in connection with the closing of MidCap Credit Agreement. See Note 17, Subsequent Events for additional information.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-11-13):
[0001805385-25-000017:note_history:37]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2024, and the notes thereto, which are included in our 2024 Form 10-K. Except for the partner rebate program, debt and debt issuance costs, and the estimates used to determine the grant date valuation for certain market-based stock units (“MSUs”), as described below, there have been no material changes to the Company’s significant accounting policies during the nine months ended September 30, 2025.
  (was, 2025-08-14, similarity 0.9355):
[0001805385-25-000009:note_history:37]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2024, and the notes thereto, which are included in our 2024 Form 10-K. Except for the partner rebate program and the estimates used to determine the grant date valuation for certain market-based stock units (“MSUs”), as described below, there have been no material changes to the Company’s significant accounting policies during the six months ended June 30, 2025.

- changed (2025-11-13):
[0001805385-25-000017:note_history:38]
The estimated grant date fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.
  (was, 2025-08-14, similarity 0.6863):
[0001805385-25-000009:note_history:38]
The estimated grant date fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The

- added (2025-11-13):
[0001805385-25-000017:note_history:39]
Debt and Debt issuance costs

- added (2025-11-13):
[0001805385-25-000017:note_history:40]
Debt is initially recognized at the amount of proceeds received, net of directly attributable issuance costs. The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated

- added (2025-11-13):
[0001805385-25-000017:note_history:41]
debt on the condensed consolidated balance sheet and amortized as interest expense on the condensed consolidated statement of operations and comprehensive loss using the effective interest method.

- added (2025-11-13):
[0001805385-25-000017:note_history:42]
For undrawn delayed draw and revolving line of credit facilities, commitment fees and related costs are costs incurred in exchange for access to capital. These fees are paid regardless of whether the funds are drawn down. Such costs associated with delayed draw facility are capitalized as prepaid expenses and other current assets and other assets in our condensed consolidated balance sheets, and such costs associated with revolving line of credit are capitalized as other assets in our condensed consolidated balance sheets. The capitalized costs are amortized as interest expense on a straight-line basis over the access period. If drawdown of the delayed draw facility becomes probable, the remaining unamortized costs are reclassified as contra-debt and amortized using the effective interest method. If it becomes probable that the delayed draw facility will not be drawn during the access period, the remaining unamortized cost will be recognized as expense in the period that determination was made.

- changed (2025-11-13):
[0001805385-25-000017:note_history:43]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity may apply the amendments in ASU 2023-09 either prospectively to all annual periods beginning after December 15, 2024, or retrospectively to prior periods. The Company determined that ASU 2023-09 is applicable and will be adopted in our Annual Report on Form 10-K for the year ended December 31, 2025. As ASU 2023-09 addresses disclosures only, the Company expects it will not have any material effects on its financial condition, results of operations, or cash flows.
  (was, 2025-08-14, similarity 0.993):
[0001805385-25-000009:note_history:43]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity may apply the amendments in ASU 2023-09 either prospectively to all annual periods beginning after December 15, 2024, or retrospectively to prior periods. The Company determined that ASU 2023-09 is applicable and will be adopted in our Annual Report on Form 10-K for the year ended December 31, 2025. It addresses disclosures only, the Company expects it will not have any material effects on its financial condition, results of operations, or cash flows.

- added (2025-11-13):
[0001805385-25-000017:note_history:44]
In September 2025, the FASB issued ASU 2025-06, “Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software.” which amends guidance on capitalization of software development costs and introduces a probable-to-complete recognition threshold, along with factors to consider for evaluating significant development uncertainty. The amendments are effective for annual reporting periods beginning after December 15, 2027, including interim periods within those annual periods. Early adoption is permitted and this amendment is applied prospectively. The Company is currently evaluating the impact of this ASU on its accounting policies and disclosures within the consolidated financial statements.

- removed (2025-11-13):
[0001805385-25-000009:note_history:45]
assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-11-13):
[0001805385-25-000017:note_history:46]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):

- added (2025-11-13):
[0001805385-25-000017:note_history:47]
|  | September 30,2025 |  |  |
| Term loans payable | $ | 30,000 |  |  |  |
| Less: Unamortized discount | (1,472) |  |  |  |
|  | 28,528 |  |  |  |
| Less: Current portion of long-term debt | — |  |  |  |
| Long-term debt, net of discount | $ | 28,528 |  |  |  |

- added (2025-11-13):
[0001805385-25-000017:note_history:48]
As described in Note 1, on July 29, 2025, the Company entered into the $75.0 million MidCap Credit Agreement, which provided for the Senior Secured Credit Facilities, which include a $30.0 million Initial Term Loan, a $30.0 million Delayed Draw Term Loan (available for drawdown during the two-year period following the Closing Date), and a $15.0 million Revolving Credit Facility, each with a maturity date of July 1, 2030. As of September 30, 2025, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available.

- added (2025-11-13):
[0001805385-25-000017:note_history:49]
On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs funded at closing. The total debt issuance costs of $3.7 million, which included $0.3 million of additional issuance costs paid by the Company, have been allocated to each component of the facility in accordance with ASC 835. The Senior Secured Credit Facilities are guaranteed by the Company, and in the future, may be guaranteed by certain material subsidiaries. The Senior Secured Credit Facilities are secured by a first lien on substantially all of the assets of the Company.

- added (2025-11-13):
[0001805385-25-000017:note_history:50]
The Senior Secured Credit Facilities bear interest at a fluctuating rate per annum equal to Term Secured Overnight Financing Rate (“Term SOFR”) and an applicable margin calculated based on earnings before interest, taxes, depreciation, and amortization (“EBITDA”). At closing, the applicable margin on Term SOFR loans was 5.25%. If the event described under the MidCap Credit Agreement related to Term SOFR occurs, a base rate is determined by reference to the higher of (1) the prime rate of Wells Fargo and (2) 2.00%. Interest and principal are payable monthly. Monthly interest payments are due in arrears on the first day of each month.

- added (2025-11-13):
[0001805385-25-000017:note_history:51]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that begins at $106.0 million on December 31, 2025 and increases quarterly thereafter. The minimum required ARR on December 31, 2026 is $111.3 million. As of September 30, 2025,  the Company’s ARR was $117.2 million, which is sufficient to satisfy the minimum required ARR through December 31, 2027; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. As of September 30, 2025, the minimum liquidity required is $15.0 million, and liquidity, as defined in the agreement, was $71.1 million. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum EBITDA covenant that takes effect on June 30, 2027. As of September 30, 2025, the Company is in full compliance with all applicable covenant requirements, and expects to remain in compliance for a period of at least twelve months from November 13, 2025.

- added (2025-11-13):
[0001805385-25-000017:note_history:52]
Initial Term Loan

- added (2025-11-13):
[0001805385-25-000017:note_history:53]
The borrowing under the $30.0 million Initial Term Loan is subject to principal repayments beginning in August 2029, following a 48-month interest-only period, and will be repaid in equal installments over the final 12 months of the loan term.

- added (2025-11-13):
[0001805385-25-000017:note_history:54]
As of September 30, 2025, the unamortized debt issuance costs totaled $1.5 million, and are presented as a direct deduction from the carrying amount of the Initial Term Loan on the consolidated balance sheet and are amortized as interest expense using the effective interest method in accordance with ASC 835. Interest expense related to the Initial Term Loan totaled $0.6 million for the three and nine months ended September 30, 2025. The interest rate in effect as of September 30, 2025 was approximately 9.60%, which includes Term SOFR of 4.35% and an applicable margin of 5.25%. Interest expense related to the amortization of debt issuance costs totaled less than $0.1 million for the three and nine months ended September 30, 2025.

- added (2025-11-13):
[0001805385-25-000017:note_history:55]
As of September 30, 2025, future principal payments on long-term debt are as follows (in thousands):

- added (2025-11-13):
[0001805385-25-000017:note_history:56]
| December 31, |  |
| 2025 (remaining three months) | $ | — |  |
| 2026 | — |  |
| 2027 | — |  |
| 2028 | — |  |
| 2029 | 12,500 |  |
| Thereafter | 17,500 |  |
|  | $ | 30,000 |  |

- added (2025-11-13):
[0001805385-25-000017:note_history:57]
Delayed Draw Term Loan and Revolving Credit Facility

- added (2025-11-13):
[0001805385-25-000017:note_history:58]
As of September 30, 2025, no amounts had been drawn under the Delayed Draw Term Loan or Revolving Credit Facility. Unused commitments amounted to $30.0 million and $15.0 million under the Delayed Draw Term Loan and Revolving Credit Facility, respectively, as of September 30, 2025. Debt issuance costs allocated to these facilities are paid regardless of whether the funds are drawn down. Such costs are capitalized as prepaid assets and amortized as interest expense on a straight-line basis over their respective access periods, which end on August 1, 2027 and July 1, 2030 for Delayed Draw Term Loan and Revolving Credit Facility, respectively. As of September 30, 2025, the Company recorded $0.7 million in prepaid expenses and other current assets and $1.3 million in other assets in the condensed consolidated balance sheets for costs associated with Delayed Draw Term Loan and Revolving Credit Facility. Capitalized debt issuance cost is amortized as interest expense on a straight-line basis over the period each facility is available to be drawn. Interest expense related to the amortization of debt issuance costs totaled $0.2 million for the three and nine months ended September 30, 2025.

- added (2025-11-13):
[0001805385-25-000017:note_history:59]
The Revolving Credit Facility provides for an unused commitment fee of 0.25% on the undrawn portion of the facility. Interest expense related to the unused commitment fees totaled less than $0.1 million for the three and nine months ended September 30, 2025.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-11-13):
[0001805385-25-000017:note_history:60]
Debt and Debt issuance costs

- added (2025-11-13):
[0001805385-25-000017:note_history:61]
Debt is initially recognized at the amount of proceeds received, net of directly attributable issuance costs. The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated

- added (2025-11-13):
[0001805385-25-000017:note_history:62]
debt on the condensed consolidated balance sheet and amortized as interest expense on the condensed consolidated statement of operations and comprehensive loss using the effective interest method.

- added (2025-11-13):
[0001805385-25-000017:note_history:63]
For undrawn delayed draw and revolving line of credit facilities, commitment fees and related costs are costs incurred in exchange for access to capital. These fees are paid regardless of whether the funds are drawn down. Such costs associated with delayed draw facility are capitalized as prepaid expenses and other current assets and other assets in our condensed consolidated balance sheets, and such costs associated with revolving line of credit are capitalized as other assets in our condensed consolidated balance sheets. The capitalized costs are amortized as interest expense on a straight-line basis over the access period. If drawdown of the delayed draw facility becomes probable, the remaining unamortized costs are reclassified as contra-debt and amortized using the effective interest method. If it becomes probable that the delayed draw facility will not be drawn during the access period, the remaining unamortized cost will be recognized as expense in the period that determination was made.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-13):
[0001805385-25-000017:note_history:64]
Marketable Securities
Marketable securities as of September 30, 2025 and December 31, 2024 consisted of the following:
  (was, 2025-08-14, similarity 0.7115):
[0001805385-25-000009:note_history:64]
Marketable Securities
All marketable securities fully matured as of June 30, 2025. Marketable securities as of December 31, 2024 consisted of the following:

- added (2025-11-13):
[0001805385-25-000017:note_history:65]
|  | September 30, 2025 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 24,723 |  |  | $ | — |  |  | $ | 24,723 |  |
| Total marketable securities | $ | 24,723 |  |  | $ | — |  |  | $ | 24,723 |  |

- added (2025-11-13):
[0001805385-25-000017:note_history:66]
Marketable securities at September 30, 2025 and December 31, 2024 were comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and nine months ended September 30, 2025 and 2024. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive loss.

- removed (2025-11-13):
[0001805385-25-000009:note_history:67]
Marketable securities at December 31, 2024 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and six months ended June 30, 2025 and 2024. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive loss.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-11-13):
[0001805385-25-000017:note_history:68]
The components of the Company’s long-term debt consisted of the following (in thousands):

- added (2025-11-13):
[0001805385-25-000017:note_history:69]
|  | September 30,2025 |  |  |
| Term loans payable | $ | 30,000 |  |  |  |
| Less: Unamortized discount | (1,472) |  |  |  |
|  | 28,528 |  |  |  |
| Less: Current portion of long-term debt | — |  |  |  |
| Long-term debt, net of discount | $ | 28,528 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-11-13):
[0001805385-25-000017:note_history:70]
As of September 30, 2025, future principal payments on long-term debt are as follows (in thousands):

- added (2025-11-13):
[0001805385-25-000017:note_history:71]
| December 31, |  |
| 2025 (remaining three months) | $ | — |  |
| 2026 | — |  |
| 2027 | — |  |
| 2028 | — |  |
| 2029 | 12,500 |  |
| Thereafter | 17,500 |  |
|  | $ | 30,000 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-11-13):
[0001805385-25-000017:note_history:72]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. While the partnership agreement is still in effect, effective in the fourth quarter of 2024, Motorola is no longer considered a related party. During the three and nine months ended September 30, 2024, revenue from Motorola's distributor services was $2.2 million and $6.1 million, respectively.
  (was, 2025-08-14, similarity 0.9553):
[0001805385-25-000009:note_history:72]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. While the partnership agreement is still in effect, effective in the fourth quarter of 2024, Motorola is no longer considered a related party. During the three and six months ended June 30, 2024, revenue from Motorola's distributor services was $1.9 million (as restated) and $3.9 million (as restated), respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-13):
[0001805385-25-000017:note_history:73]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Product revenue | $ | 9,242 |  |  | $ | 1,344 |  |  | $ | 14,092 |  |  | $ | 4,789 |  |
| Subscription revenue | 22,685 |  |  | 17,909 |  |  | 62,122 |  |  | 47,783 |  |
| Service revenue | 7,808 |  |  | 6,085 |  |  | 21,224 |  |  | 16,903 |  |
| License fees | 2,280 |  |  | 1,606 |  |  | 7,774 |  |  | 4,047 |  |
| Professional services and other revenue | 835 |  |  | 416 |  |  | 2,189 |  |  | 1,243 |  |
| Total revenue | $ | 42,850 |  |  | $ | 27,360 |  |  | $ | 107,401 |  |  | $ | 74,765 |  |
  (was, 2025-08-14, similarity 0.8439):
[0001805385-25-000009:note_history:73]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Product revenue | $ | 2,528 |  |  | $ | 1,954 |  |  | $ | 4,850 |  |  | $ | 3,445 |  |
| Subscription revenue | 20,200 |  |  | 15,655 |  |  | 39,437 |  |  | 29,874 |  |
| Service revenue | 6,686 |  |  | 5,566 |  |  | 13,416 |  |  | 10,818 |  |
| License fees | 2,291 |  |  | 1,717 |  |  | 5,494 |  |  | 2,441 |  |
| Professional services and other revenue | 839 |  |  | 332 |  |  | 1,354 |  |  | 827 |  |
| Total revenue | $ | 32,544 |  |  | $ | 25,224 |  |  | $ | 64,551 |  |  | $ | 47,405 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-13):
[0001805385-25-000017:note_history:74]
In March 2023, the Company entered into a distributor licensing agreement (the “Distribution and License Agreement”) with Columbia Electrical Contractors, Inc. (“Columbia Tech”). Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, which serves as the Company's primary contract manufacturer. Under this arrangement, the Company has granted a license of its intellectual property to Columbia Tech, which contracts directly with certain of the Company's resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment as opposed to lease the equipment. Columbia Tech pays the Company a hardware license fee for each system it manufactures and sells under the agreement. In these instances, the Company still contracts directly with the reseller to provide a multi-year SaaS and maintenance subscription to the end-users. During the three months ended September 30, 2025, the Company discontinued quoting on this basis, and while any outstanding quotes will be honored, all new quotes for end-user customers wishing to purchase the hardware equipment will be fulfilled through the Company's purchase subscription model going forward.
  (was, 2025-08-14, similarity 0.8499):
[0001805385-25-000009:note_history:74]
In March 2023, the Company entered into a distributor licensing agreement (the “Distribution and License Agreement”) with Columbia Electrical Contractors, Inc. (“Columbia Tech”). Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, which serves as the Company's primary contract manufacturer. Under this arrangement, the Company has granted a license of its intellectual property to Columbia Tech, which contracts directly with certain of the Company's resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment as opposed to lease the equipment. Columbia Tech pays the Company a hardware license fee for each system it manufactures and sells under the agreement. In these instances, the Company still contracts directly with the reseller to provide a multi-year SaaS and maintenance subscription to the end-users.

- changed (2025-11-13):
[0001805385-25-000017:note_history:75]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2025:
  (was, 2025-08-14, similarity 0.9705):
[0001805385-25-000009:note_history:75]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of June 30, 2025:

- changed (2025-11-13):
[0001805385-25-000017:note_history:76]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time.  As of September 30, 2025 and December 31, 2024, the Company had $1.2 million and $0.8 million in current portion of contract assets and $0.4 million and $0.7 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2025-08-14, similarity 0.986):
[0001805385-25-000009:note_history:76]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time.  As of June 30, 2025 and December 31, 2024, the Company had $0.8 million and $0.8 million in current portion of contract assets and $0.8 million and $0.7 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2025-11-13):
[0001805385-25-000017:note_history:77]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $13.9 million and $58.0 million during the three and nine months ended September 30, 2025, respectively, that was included in the December 31, 2024 deferred revenue balance. The Company recognized revenue of $10.1 million and $40.8 million during the three and nine months ended September 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance.
  (was, 2025-08-14, similarity 0.9381):
[0001805385-25-000009:note_history:77]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $19.4 million and $44.1 million during the three and six months ended June 30, 2025, respectively, that was included in the December 31, 2024 deferred revenue balance. The Company recognized revenue of $13.8 million (as restated) and $30.7 million (as restated) during the three and six months ended June 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance.

- changed (2025-11-13):
[0001805385-25-000017:note_history:78]
| Balance at December 31, 2024 | $ | 84,772 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (57,966) |  |
| Revenue deferred | 69,562 |  |
| Balance at September 30, 2025 | $ | 96,368 |  |
  (was, 2025-08-14, similarity 0.9724):
[0001805385-25-000009:note_history:78]
| Balance at December 31, 2024 | $ | 84,772 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (44,110) |  |
| Revenue deferred | 50,710 |  |
| Balance at June 30, 2025 | $ | 91,372 |  |

- added (2025-11-13):
[0001805385-25-000017:note_history:79]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest income on lease receivables | $ | 24 |  |  | $ | 40 |  |  | $ | 80 |  |  | $ | 123 |  |
| Lease income - operating leases | 22,685 |  |  | 17,909 |  |  | 62,122 |  |  | 47,783 |  |
| Total lease revenue | $ | 22,709 |  |  | $ | 17,949 |  |  | $ | 62,202 |  |  | $ | 47,906 |  |

- changed (2025-11-13):
[0001805385-25-000017:note_history:80]
under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties was $0.5 million and $1.1 million during the three and nine months ended September 30, 2024, respectively. There was no revenue related to leases entered into with related parties during the three and nine months ended September 30, 2025.
  (was, 2025-08-14, similarity 0.8788):
[0001805385-25-000009:note_history:80]
under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties was $0.3 million and $0.6 million during the three and six months ended June 30, 2024, respectively. There was no revenue related to leases entered into with related parties during the three and six months ended June 30, 2025.

- changed (2025-11-13):
[0001805385-25-000017:note_history:81]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Product revenue | $ | 9,242 |  |  | $ | 1,344 |  |  | $ | 14,092 |  |  | $ | 4,789 |  |
| Subscription revenue | 22,685 |  |  | 17,909 |  |  | 62,122 |  |  | 47,783 |  |
| Service revenue | 7,808 |  |  | 6,085 |  |  | 21,224 |  |  | 16,903 |  |
| License fees | 2,280 |  |  | 1,606 |  |  | 7,774 |  |  | 4,047 |  |
| Professional services and other revenue | 835 |  |  | 416 |  |  | 2,189 |  |  | 1,243 |  |
| Total revenue | $ | 42,850 |  |  | $ | 27,360 |  |  | $ | 107,401 |  |  | $ | 74,765 |  |
  (was, 2025-08-14, similarity 0.8439):
[0001805385-25-000009:note_history:81]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Product revenue | $ | 2,528 |  |  | $ | 1,954 |  |  | $ | 4,850 |  |  | $ | 3,445 |  |
| Subscription revenue | 20,200 |  |  | 15,655 |  |  | 39,437 |  |  | 29,874 |  |
| Service revenue | 6,686 |  |  | 5,566 |  |  | 13,416 |  |  | 10,818 |  |
| License fees | 2,291 |  |  | 1,717 |  |  | 5,494 |  |  | 2,441 |  |
| Professional services and other revenue | 839 |  |  | 332 |  |  | 1,354 |  |  | 827 |  |
| Total revenue | $ | 32,544 |  |  | $ | 25,224 |  |  | $ | 64,551 |  |  | $ | 47,405 |  |

- changed (2025-11-13):
[0001805385-25-000017:note_history:82]
As discussed in Note 2, Summary of Significant Accounting Policies, the Company implemented a new Rebate Program for eligible resellers. As of September 30, 2025, the Company has accrued $1.1 million related to the Rebate Program, which is included in accrued expenses and other current liabilities in our condensed consolidated balance sheets. As a substantial amount of the Company's revenue with eligible resellers is recognized over-time, the Company recognized $0.2 million and $0.6 million of current portion of contract asset and contract asset, noncurrent in our condensed consolidated balance sheets, respectively, as of September 30, 2025 and recognized $0.2 million and $0.4 million as reduction of revenue for the three and nine months ended September 30, 2025, respectively.
  (was, 2025-08-14, similarity 0.9444):
[0001805385-25-000009:note_history:82]
As discussed in Note 3, Summary of Significant Accounting Policies, the Company implemented a new Rebate Program for eligible resellers. As of June 30, 2025, the Company has accrued $0.4 million related to the Rebate Program, which is included in accrued expenses and other current liabilities in our condensed consolidated balance sheets. As a substantial amount of the Company's revenue with eligible resellers is recognized over-time, the Company recognized less than $0.1 million and $0.2 million of current portion of contract asset and contract asset, noncurrent in our condensed consolidated balance sheets, respectively, as of June 30, 2025 and recognized $0.1 million and $0.2 million as reduction of revenue for the three and six months ended June 30, 2025, respectively.

- added (2025-11-13):
[0001805385-25-000017:note_history:83]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and professional services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $13.0 million as of both September 30, 2025 and December 31, 2024. During the three months ended September 30, 2025 and 2024, the Company recognized commission expense of $2.1 million and $1.4 million, respectively. During the nine months ended September 30, 2025 and 2024, the Company recognized commission expense of $5.4 million and $4.3 million, respectively.

- changed (2025-11-13):
[0001805385-25-000017:note_history:84]
As of September 30, 2025, future minimum noncancelable payments related to leases of the Company's equipment are as follows (in thousands):
  (was, 2025-08-14, similarity 0.9579):
[0001805385-25-000009:note_history:84]
As of June 30, 2025, future minimum noncancelable payments related to leases of the Company's equipment are as follows (in thousands):

- changed (2025-11-13):
[0001805385-25-000017:note_history:85]
| Year Ending December 31: |  |
| 2025 (three months remaining) | $ | 23,132 |  |
| 2026 | 83,429 |  |
| 2027 | 61,724 |  |
| 2028 | 35,868 |  |
| 2029 | 13,693 |  |
| Thereafter | 679 |  |
|  | $ | 218,525 |  |
  (was, 2025-08-14, similarity 0.9737):
[0001805385-25-000009:note_history:85]
| Year Ending December 31: |  |
| 2025 (six months remaining) | $ | 41,984 |  |
| 2026 | 74,372 |  |
| 2027 | 53,103 |  |
| 2028 | 26,720 |  |
| 2029 | 5,872 |  |
| Thereafter | 260 |  |
|  | $ | 202,311 |  |

- removed (2025-11-13):
[0001805385-25-000009:note_history:86]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Interest income on lease receivables | $ | 27 |  |  | $ | 41 |  |  | $ | 56 |  |  | $ | 83 |  |
| Lease income - operating leases | 20,200 |  |  | 15,655 |  |  | 39,437 |  |  | 29,874 |  |
| Total lease revenue | $ | 20,227 |  |  | $ | 15,696 |  |  | $ | 39,493 |  |  | $ | 29,957 |  |

- removed (2025-11-13):
[0001805385-25-000009:note_history:87]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $12.9 million and $13.0 million as of June 30, 2025 and December 31, 2024, respectively. During the three months ended June 30, 2025 and 2024, the Company recognized commission expense of $1.8 million and $1.6 million (as restated), respectively. During the six months ended June 30, 2025 and 2024, the Company recognized commission expense of $3.3 million and $2.9 million (as restated), respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-11-13):
[0001805385-25-000009:note_history:88]
Subsequent Events
Senior Secured Credit Facilities

- removed (2025-11-13):
[0001805385-25-000009:note_history:89]
As described in Note 2, on July 29, 2025, the Company entered into the $75.0 million MidCap Credit Agreement, the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the

- removed (2025-11-13):
[0001805385-25-000009:note_history:90]
Company's subscription sales model. The MidCap Credit Agreement provides for the Senior Secured Credit Facilities, which include an initial $30.0 million term loan facility, a $30.0 million delayed draw facility (available for drawdown during the two-year period following the closing date), and a $15.0 million revolving line of credit, each with a term of five years. At closing, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs incurred in connection with the closing of MidCap Credit Agreement.

- removed (2025-11-13):
[0001805385-25-000009:note_history:91]
The Senior Secured Credit Facilities are guaranteed by the Company, and in the future, may be guaranteed by certain material subsidiaries. The Senior Secured Credit Facilities are secured by a first lien on substantially all of the assets of the Company. The borrowings under the Senior Secured Credit Facilities bear interest at a fluctuating rate per annum equal to (x) a base rate determined by reference to the higher of (1) the prime rate of Wells Fargo and (2) 2.00% or (y) Term Secured Overnight Financing Rate (“Term SOFR”), in each case, plus an applicable margin calculated based on earnings before interest, taxes, depreciation, and amortization (“EBITDA”). At closing, the applicable margin on Term SOFR loans was 5.25%. Interest and principal are payable monthly. The term loan facilities require interest-only payments during the initial 48-month period, with principal repayment amortized on a straight-line basis over the remaining 12 months of the term.

- removed (2025-11-13):
[0001805385-25-000009:note_history:92]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary affirmative and negative covenants, including a minimum annual recurring revenue covenant, a minimum EBITDA covenant that takes effect on the second anniversary of the closing date, and a minimum liquidity covenant that would cease to apply following the resolution of certain litigation and regulatory matters, in addition to customary reporting requirements of periodic financial results.

- removed (2025-11-13):
[0001805385-25-000009:note_history:93]
Departure of Officer

- removed (2025-11-13):
[0001805385-25-000009:note_history:94]
On August 13, 2025, Mr. Michael Ellenbogen, Chief Innovation Officer and a member of the Board of Directors (the “Board”) of the Company, informed the Company that he would be resigning as Chief Innovation Officer, effective as of September 5, 2025, citing new time commitments. Mr. Ellenbogen’s decision to resign is not due any disagreements with the Company. Mr. Ellenbogen will continue to serve as a member of the Board and will be eligible to receive compensation as a non-employee director pursuant to the Company's Director Compensation Policy.
