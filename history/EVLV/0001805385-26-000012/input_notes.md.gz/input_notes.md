# EVLV notes — 0001805385-26-000012


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001805385-26-000012:notes:1]
Certain portions of the information required to be furnished pursuant to Part III of this Annual Report on Form 10-K will be set forth in, and incorporated by reference from, the registrant’s definitive proxy statement for the annual meeting of stockholders which will be filed with the Securities and Exchange Commission no later than 120 days after the end of the fiscal year ended December 31, 2025 (the "Proxy Statement").


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001805385-26-000012:notes:2]
Cybersecurity Risk Management and Strategy

[0001805385-26-000012:notes:3]
We have developed and implemented a cybersecurity risk management program intended to protect the confidentiality, integrity, and availability of our critical systems and information.

[0001805385-26-000012:notes:4]
We design and assess our program based on the National Institute of Standards and Technology Cybersecurity Framework ("NIST CSF") and SOC 2 trust principles on security. This does not imply that we meet any particular technical standards, specifications, or requirements, but only that we use these frameworks as a guide to help us identify, assess, and manage cybersecurity risks relevant to our business.

[0001805385-26-000012:notes:5]
Our cybersecurity risk management program is integrated into our overall enterprise risk management program, and shares common methodologies, reporting channels and governance processes that apply across the enterprise risk management program to other legal, compliance, strategic, operational, and financial risk areas.

[0001805385-26-000012:notes:6]
Key elements of our cybersecurity risk management program include:

[0001805385-26-000012:notes:7]
•risk assessments designed to help identify material cybersecurity risks to our critical systems, information, products, services, and our broader enterprise IT environment;

[0001805385-26-000012:notes:8]
•a security team principally responsible for managing (1) our cybersecurity risk assessment processes, (2) our security controls, and (3) our response to cybersecurity incidents;

[0001805385-26-000012:notes:9]
•the use of external service providers, where appropriate, to assess, test or otherwise assist with aspects of our security controls;

[0001805385-26-000012:notes:10]
•cybersecurity awareness training of our employees, incident response personnel, and senior management;

[0001805385-26-000012:notes:11]
•a cybersecurity incident response plan that includes procedures for responding to cybersecurity incidents; and

[0001805385-26-000012:notes:12]
•a third-party risk management process for service providers that includes a diligence and contracting process depending on our assessment of each provider's respective criticality and risk profile.

[0001805385-26-000012:notes:13]
We have not identified risks from known cybersecurity threats, including as a result of any prior cybersecurity incidents, that have materially affected us, including our operations, business strategy, results of operations, or financial condition. We face certain ongoing risks from cybersecurity threats that, if realized, are reasonably likely to materially affect us, including our operations, business strategy, results of operations, or financial condition. See “Risk Factors – Our products collect and store personal data about individuals, including our customers, their visitors, and our employees, as well as other proprietary business and confidential information.”


## cyd:CybersecurityRiskBoardCommitteeOrSubcommitteeResponsibleForOversightTextBlock

[0001805385-26-000012:notes:14]
Our Board considers cybersecurity risk as part of its risk oversight function and has delegated to the Audit Committee ("Audit Committee") oversight of cybersecurity and other IT risks. The Audit Committee oversees management’s implementation of our cybersecurity risk management program.

[0001805385-26-000012:notes:15]
The Audit Committee receives periodic reports from our Vice President of Cybersecurity and Information Technology on our cybersecurity risks, updates, as necessary, regarding any cybersecurity incidents, as well as any incidents with lesser impact potential. 
The Audit Committee reports to the full Board regarding its activities, including those related to cybersecurity.


## cyd:CybersecurityRiskManagementPositionsOrCommitteesResponsibleTextBlock

[0001805385-26-000012:notes:16]
Our Vice President of Cybersecurity and Information Technology is responsible for assessing and managing our material risks from cybersecurity threats and has primary responsibility for our overall cybersecurity risk management program and supervises both our internal cybersecurity personnel and our retained external cybersecurity consultants. Our Vice President of Cybersecurity and Information Technology has served in that position since 2022, and has extensive experience assessing and managing cybersecurity programs and technology risk. Prior to joining Evolv, our Vice President of Cybersecurity and Information Technology was the Leader of Global Information Security for New Balance.

[0001805385-26-000012:notes:17]
Our Vice President of Cybersecurity and Information Technology supervises efforts to prevent, detect, mitigate, and remediate cybersecurity risks and incidents through various means, which may include briefings from internal security personnel; threat intelligence and other information obtained from governmental, public or private sources, including external consultants engaged by us; and alerts and reports produced by security tools deployed in the IT environment.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001805385-26-000012:notes:18]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company pioneering Artificial Intelligence (“AI”)-powered screening solutions designed to help create safer environments while maintaining efficient visitor flow and a positive visitor experience. The Company serves customers across a range of end markets, including education, healthcare, sports, live entertainment, tourist attractions, houses of worship, and industrial workplaces.

[0001805385-26-000012:notes:19]
The Company offers two major products, Evolv Express® and Evolv eXpedite™, which are designed to efficiently screen high volumes of people and bags for concealed threats. These products and their associated services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

[0001805385-26-000012:notes:20]
As used in this Annual Report on Form 10-K, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. (“Evolv UK”) and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).

[0001805385-26-000012:notes:21]
Liquidity and capital resources

[0001805385-26-000012:notes:22]
In accordance with Accounting Standards Update (“ASU”) No. 2014-15, Disclosures of Uncertainties about an Entity’s Ability to Continue as a Going Concern (Subtopic 205-40), management must evaluate whether there are conditions or events, considered in the aggregate, that raise substantial doubt about the company’s ability to continue as a going concern within one year after the date that the financial statements are issued.

[0001805385-26-000012:notes:23]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures, debt obligations, and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of December 31, 2025, the Company had $69.0 million in cash, cash equivalents, and marketable securities, with outstanding debt of $30.0 million and available additional debt of up to $45.0 million, as detailed below. The Company incurred a net loss of $33.1 million and $54.0 million for the years ended December 31, 2025 and 2024, respectively. Operating activities resulted in cash inflow of $18.7 million and cash outflow of $30.9 million during the years ended December 31, 2025 and 2024, respectively. The Company expects to continue to generate losses for the foreseeable future.

[0001805385-26-000012:notes:24]
The Company maintains substantially all of its cash, cash equivalents, and marketable securities in accounts with U.S. and multi-national financial institutions and its cash deposits at these institutions exceed Federal Deposit Insurance Corporation insured limits. The Company does not believe it is exposed to any unusual credit risk or deposit concentration risk beyond the ordinary credit risk associated with commercial banking relationships.

[0001805385-26-000012:notes:25]
On July 29, 2025 (the “Closing Date”), the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's pure subscription sales model. The MidCap Credit Agreement provided an initial $30.0 million term loan facility (the “Initial Term Loan”), a $30.0 million delayed draw facility (the “Delayed Draw Term Loan”) (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit (the “Revolving Credit Facility”), each with a maturity date of July 1, 2030 (collectively, the “Senior Secured Credit Facilities”). On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs paid at

[0001805385-26-000012:notes:26]
closing. As of December 31, 2025, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available. See Note 12, Long-term Debt for additional information.

[0001805385-26-000012:notes:27]
The Company expects its cash, cash equivalents, and marketable securities of $69.0 million as of December 31, 2025, together with cash it expects to generate from future operations and borrowing availability under the Senior Secured Credit Facilities, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Annual Report on Form 10-K. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth.

[0001805385-26-000012:notes:28]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that begins at $106.0 million on December 31, 2025 and increases quarterly thereafter; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum EBITDA covenant that takes effect on June 30, 2027. As of December 31, 2025, the Company is in full compliance with all applicable covenant requirements, and expects to remain in compliance for a period of at least twelve months from March 10, 2026.

[0001805385-26-000012:notes:29]
Risks and uncertainties

[0001805385-26-000012:notes:30]
There is significant uncertainty in the current geopolitical and macroeconomic environment due to various factors, including but not limited to inflationary pressures globally, conflicts in Europe and the Middle East, and foreign currency volatility and their impacts on the Company’s business. If economic conditions were to worsen, the Company’s results of operations, financial condition, and cash flows from operations may be materially and adversely impacted.

[0001805385-26-000012:notes:31]
Additionally, there continues to be significant uncertainty regarding recent changes and potential future developments related to increased trade restrictions, tariffs or taxes on imports or exports relating to countries where we source or sell materials or products. The exact magnitude of any potential impact remains uncertain, as there may be further changes to tariffs and policies and, consequently, potential increased tension between the U.S. and targeted countries, and the Company's financial condition and results of operations could be adversely affected.

[0001805385-26-000012:notes:32]
Basis of presentation

[0001805385-26-000012:notes:33]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001805385-26-000012:notes:34]
Reclassifications

[0001805385-26-000012:notes:35]
During the three months ended March 31, 2025, the Company began classifying restructuring charges, which includes termination charges arising from severance obligations, incremental non-cash expense, and other customary employee benefit payments in connection with a reduction in force, within restructuring costs on the consolidated statements of operations and comprehensive loss, whereas the restructuring costs for these services had previously been included in cost of service revenue, research and development expenses, sales and marketing expenses, and general and administrative expenses. These reclassifications were made to align the presentation of restructuring charges with the Company's internal reporting and analysis. The reclassifications increased gross profit by $0.2 million for the year ended December 31, 2024 and did not impact total loss from operations or total net loss for any period. Prior year amounts included in this Annual Report on Form 10-K have been reclassified to conform to the current presentation.

[0001805385-26-000012:notes:36]
For the year ended December 31, 2024, the reclassifications resulted in an increase in restructuring costs of $0.9 million, and a corresponding decrease in cost of service revenue, sales and marketing expenses, and general and administrative expenses of $0.2 million, $0.7 million, and less than $0.1 million, respectively.

[0001805385-26-000012:notes:37]
During the three months ended September 30, 2025, the Company recorded an out-of-period correction to decrease other income (expense) by $0.9 million, decrease contingently issuable common stock liability by $2.3 million, increase other assets by $2.0 million and increase additional paid in capital by $3.4 million. The out-of-period adjustment was recorded to correct the accounting for the fair value of the contingently issuable common shares and the contingently returnable common stock, as described in more detail in Note 4, Fair Value Measurements. Management evaluated the accounting impacts on prior periods based on the historical dates of transfers, concluding that such impacts were not material to the historical financial statements.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001805385-26-000012:notes:38]
Summary of Significant Accounting Policies
Use of Estimates

[0001805385-26-000012:notes:39]
The preparation of the Company’s consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the reporting periods. Significant estimates and assumptions reflected in these consolidated financial statements include but are not limited to calculating the standalone selling price for revenue recognition, the valuation of inventory, the expensing and capitalization of costs associated with internal-use software, stock-based awards, the valuation of the contingent earn-out liability, the valuation of the contingently issuable common stock, and the valuation of the public warrant liability. The Company bases its estimates on historical experience, known trends and other market-specific or other relevant factors that it believes to be reasonable under the circumstances. On an ongoing basis, management evaluates its estimates when there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results could differ from those estimates.

[0001805385-26-000012:notes:40]
Risk of Concentrations of Credit, Significant Customers and Significant Suppliers

[0001805385-26-000012:notes:41]
Financial instruments that potentially expose the Company to concentrations of credit risk consist primarily of cash equivalents, marketable securities, and accounts receivable, net. We maintain substantially all of our cash and cash equivalents with U.S. and multi-national financial institutions, and our deposits are generally in excess of federally insured limits. The Company maintains its cash, cash equivalents, and marketable securities with financial institutions that management believes to be of high credit quality. The Company has not experienced any losses on such accounts and does not believe it is exposed to any unusual credit risk beyond the normal credit risk associated with commercial banking relationships.

[0001805385-26-000012:notes:42]
Significant customers are those which represent more than 10% of the Company’s total revenue or accounts receivable, net balance at each respective balance sheet date. The following table presents a customer that represents 10% or more of the Company’s total revenue for the years ended December 31, 2025 and 2024. The customer shown is a reseller partner of the Company.

[0001805385-26-000012:notes:43]
|  | Year Ended December 31, 2025 |  | Year Ended December 31, 2024 |  |  |
| Customer B | 15.3 | % |  | 12.6 | % |  |  |
|  | 15.3 | % |  | 12.6 | % |  |  |

[0001805385-26-000012:notes:44]
The following table presents customers that represent 10% or more of the Company’s accounts receivable, net.

[0001805385-26-000012:notes:45]
|  | December 31, |
|  | 2025 |  | 2024 |
| Columbia Tech | * |  | 11.0 | % |
| Customer A | * |  | 11.3 | % |
| Customer B | 15.1 | % |  | * |
|  | 15.1 | % |  | 22.3 | % |

[0001805385-26-000012:notes:46]
* Less than 10%

[0001805385-26-000012:notes:47]
The Company depends on its primary third-party contract manufacturer for the production of its security screening systems. While there are several potential contract manufacturers for most of these products, all systems are currently manufactured, assembled, tested, and packaged by Columbia Tech. On November 5, 2025, the Company entered into a non-exclusive contract manufacturing agreement with Plexus Corp. In most cases, the Company relies on these manufacturers to procure components and, in some cases, provide manufacturing engineering work. In instances where these parties fail to perform their obligations, the Company may be unable to find alternative suppliers to satisfactorily deliver its products to its customers on time, if at all, which could have a material adverse effect on the Company’s operating results, financial condition, and cash flows and damage its customer relationships.

[0001805385-26-000012:notes:48]
Cash and Cash Equivalents

[0001805385-26-000012:notes:49]
The Company considers all short-term, highly liquid investments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents.

[0001805385-26-000012:notes:50]
Marketable Securities

[0001805385-26-000012:notes:51]
Marketable securities are reported at fair value and, at December 31, 2025, are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. The Company considers an available-for-sale debt security to be impaired if the fair value of the investment is less than its amortized cost basis. The entire difference between the amortized cost basis and the fair value of the Company’s available-for-sale debt securities is recognized on the consolidated statements of operations as an impairment if, (i) the fair value of the security is below its amortized cost and (ii) the Company intends to sell or is more likely than not required to sell the security before recovery of its amortized cost basis. If neither criterion is met, the Company evaluates whether the decline in fair value is due to credit losses or other factors. In making this assessment, the Company considers the changes to the rating of the security by third-party rating agencies, and adverse conditions specific to the security, among other factors. If the Company’s assessment indicates that a credit loss exists, the credit loss is measured based on the Company’s best estimate of the cash flows expected to be collected. When developing its estimate of cash flows expected to be collected, the Company considers all available information relevant to the collectability of the security, including past events, current conditions, and reasonable and supportable forecasts.

[0001805385-26-000012:notes:52]
Unrealized gains and losses, net of tax, on marketable securities, if any, are recognized in accumulated other comprehensive income (loss) in the accompanying consolidated balance sheets. Realized net gains and losses on marketable securities, if any, are reflected in interest income in the accompanying consolidated statements of operations and comprehensive loss.

[0001805385-26-000012:notes:53]
Fair Value Measurements of Financial Instruments

[0001805385-26-000012:notes:54]
Certain assets and liabilities of the Company are carried at fair value under GAAP. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. Valuation techniques used to measure fair value must maximize the use of observable inputs and minimize the use of unobservable inputs. Financial assets and liabilities carried at fair value are to be classified and disclosed in one of the

[0001805385-26-000012:notes:55]
following three levels of the fair value hierarchy, of which the first two are considered observable and the last is considered unobservable:

[0001805385-26-000012:notes:56]
•Level 1 — Quoted prices in active markets for identical assets or liabilities.

[0001805385-26-000012:notes:57]
•Level 2 — Observable inputs (other than Level 1 quoted prices), such as quoted prices in active markets for similar assets or liabilities, quoted prices in markets that are not active for identical or similar assets or liabilities, or other inputs that are observable or can be corroborated by observable market data.

[0001805385-26-000012:notes:58]
•Level 3 — Unobservable inputs that are supported by little or no market activity that are significant to determining the fair value of the assets or liabilities, including pricing models, discounted cash flow methodologies and similar techniques.

[0001805385-26-000012:notes:59]
The Company’s cash equivalents, marketable securities, contingent earn-out liability, contingently issuable/returnable common stock liability/asset, and public warrant liability are carried at fair value, determined according to the fair value hierarchy described above (see Note 4). The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources. The carrying amounts of the Company’s cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and other accrued expenses approximate fair values due to their short-term nature of these assets and liabilities. The carrying value of the Company’s long-term debt approximates its fair value (a Level 2 measurement) at each balance sheet date due to its variable interest rate, which approximates a market interest rate.

[0001805385-26-000012:notes:60]
Assets that are measured at fair value on a non-recurring basis primarily relate to inventories and property and equipment. We do not periodically adjust carrying value to fair value for inventories and property and equipment. Rather, the carrying value of the asset is reduced to its fair value when we determine that impairment has occurred.

[0001805385-26-000012:notes:61]
Contingent Earn-out

[0001805385-26-000012:notes:62]
In connection with the Merger and pursuant to the Merger Agreement, certain of the Legacy Evolv’s shareholders and Legacy Evolv Service Providers were entitled to receive additional shares of the Company’s common stock (the “Earn-Out Shares”) upon the Company achieving certain milestones. On March 8, 2026, the earn‑out period expired and no triggering events were achieved. Accordingly, all Earn‑Out Shares expired and were not issued. As of December 31, 2025, the Company recorded a liability for the contingent earn‑out arrangement in accordance with ASC 815, with changes in fair value recognized in other income (expense).

[0001805385-26-000012:notes:63]
The milestones for the Earn-Out Shares were as follows:

[0001805385-26-000012:notes:64]
•Triggering Event I – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock was greater than $12.50 per share for any 20 trading days within any 30 trading day period.

[0001805385-26-000012:notes:65]
•Triggering Event II – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock was greater than $15.00 per share for any 20 trading days within any 30 trading day period.

[0001805385-26-000012:notes:66]
•Triggering Event III – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock was greater than $17.50 per share for any 20 trading days within any 30 trading day period.

[0001805385-26-000012:notes:67]
In accordance with ASC 815 – Derivatives and Hedging, the earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a change in fair value of contingent earn-out liability in other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001805385-26-000012:notes:68]
The estimated fair value of the contingent earn-out shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the

[0001805385-26-000012:notes:69]
calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, drift rate, percentage of change in control and expected term.

[0001805385-26-000012:notes:70]
The contingent earn-out liability is categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingent earn-out payments involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001805385-26-000012:notes:71]
The Earn-Out Shares issued to employees, officers, directors, and non-employees are based on achievement of certain target share price contingencies and for the employees and officers, subject to continued employment, (the “Earn-Out Service Providers”) represents share-based compensation and is included in additional paid-in capital on the Company’s balance sheet. Corresponding stock-based compensation expense is recorded in the consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. As a condition to being issued Earn-Out Shares, the Earn-Out Service Providers must still be providing services to the Company on the date of the issuance of the shares. If the relationship with the service provider is terminated prior to the issuance of the Earn-Out Shares, the shares will be redistributed to the remaining participants in the Earn-Out Shares.

[0001805385-26-000012:notes:72]
Contingently Issuable Common Stock and Contingently Returnable Common Stock Asset

[0001805385-26-000012:notes:73]
Prior to the Merger, NewHold Industrial Technology Holdings, LLC, the sponsor of the NHIC special purpose acquisition company owned 4,312,500 shares of NHIC Class B common stock (the “Founder Shares). Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company’s common stock. The Founder Shares outstanding were subject to certain share-performance-based vesting provisions as follows:

[0001805385-26-000012:notes:74]
•Vesting Provision I – 1,897,500 shares of the Company’s common stock shall vest and no longer be subject to forfeiture as of the Merger;

[0001805385-26-000012:notes:75]
•Vesting Provision II – if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $12.50 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30 trading day period, then 948,750 shares of the Company’s common stock shall vest and no longer be subject to forfeiture and

[0001805385-26-000012:notes:76]
•Vesting Provision III – if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $15.00 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30-trading day period, then 948,750 shares of the Company’s common stock) shall vest and no longer be subject to forfeiture.

[0001805385-26-000012:notes:77]
The remaining 517,500 Founder Shares were contributed to Give Evolv LLC.

[0001805385-26-000012:notes:78]
If Vesting Provision II and/or Vesting Provision III are not satisfied, the corresponding number of shares specified shall be forfeited and no longer issued and outstanding. If there is a Change of Control event prior to Vesting Provision II and/or Vesting Provision III are satisfied, the Founder shares are no longer subject to forfeiture and shall vest immediately upon the occurrence of a Change of Control event.

[0001805385-26-000012:notes:79]
In accordance with ASC 815 – Derivatives and Hedging, the contingently issuable common stock is accounted for either as a liability, if still held at the Company's transfer agent, or as an asset as described below, and subsequently remeasured at each reporting date with changes in fair value recorded as change in fair value of contingently issuable/returnable common stock liability/asset in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Vesting Provisions have been achieved and the contingently issuable common shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001805385-26-000012:notes:80]
Under the Founder Shares arrangement, Founder Shares may be transferred to third parties, subject to certain conditions. The unvested shares must be returned to the Company if the specified vesting conditions are not met. As of December 31, 2025, a total of 729,570 unvested shares had been transferred to individual brokerage accounts, resulting in a reduction to the contingently issuable common stock liability and recognition of the value of the shares as outstanding equity. The contractual obligation of the holders to return the transferred shares upon failure to meet vesting conditions is accounted for as a freestanding financial asset. This asset was initially recognized at fair value and is remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001805385-26-000012:notes:81]
The estimated fair value of the contingently issuable common shares and the contingently returnable common stock asset was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, likelihood of change in control, and remaining term.

[0001805385-26-000012:notes:82]
The contingently issuable common shares and the contingently returnable common stock asset are categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingently issuable shares and the contingently returnable common stock asset involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001805385-26-000012:notes:83]
Public Warrant Liability

[0001805385-26-000012:notes:84]
In connection with the closing of the Merger, the Company assumed warrants for the purchase of 14,325,000 shares of common stock at an exercise price of $11.50 (the “Public Warrants”). The Public Warrants are classified as a liability pursuant to ASC 815 – Derivatives and Hedging as the equity derivative scope exception was not met and are measured at fair value, with the changes in fair value reported in earnings as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss with the offset to additional paid in capital.

[0001805385-26-000012:notes:85]
Leases as a Lessee

[0001805385-26-000012:notes:86]
The Company accounts for leases in accordance with ASC 842, Leases. At contract inception, the Company determines if an arrangement is or contains a lease. A lease conveys the right to control the use of an identified asset for a period of time in exchange for consideration. If determined to be or contain a lease, the lease is assessed for classification as either an operating or finance lease at the lease commencement date, defined as the date on which the leased asset is made available for use by the Company (when the Company is the lessee). Where the Company is the lessee, for each lease with a term greater than twelve months, the Company records a right-of-use asset and lease liability.

[0001805385-26-000012:notes:87]
A right-of-use asset represents the economic benefit conveyed to the Company by the right to use the underlying asset over the lease term. A lease liability represents the obligation to make lease payments arising from the use of the asset over the lease term. Lease liabilities are measured at lease commencement and calculated as the present value of the future lease payments in the contract using the rate implicit in the contract, when available. If an implicit rate is not readily determinable, the Company uses an incremental borrowing rate measured as the rate at which the Company could borrow, on a fully collateralized basis, a commensurate loan in the same currency over a period consistent with the lease term at the commencement date. Right-of-use assets are measured as the amount of the initial lease liability plus initial direct costs and prepaid lease payments, less lease incentives granted by the lessor. The lease term is measured as the noncancelable period in the contract, adjusted for any options to extend or terminate when it is reasonably certain the Company will extend the lease term via such options based on an assessment of economic factors present as of the lease commencement date. The Company elected the practical expedient to not recognize leases with a lease term of twelve months or less.

[0001805385-26-000012:notes:88]
Components of a lease are split into three categories: lease components, non-lease components, and non-components. The fixed and in-substance fixed contract consideration (including any consideration related to non-components) are allocated, based on the respective relative fair values, to the lease components and non-lease components. The Company has elected the practical expedient to account for lease and non-lease components together as a single lease component for all underlying assets and allocate all of the contract consideration to the lease component only.

[0001805385-26-000012:notes:89]
The Company’s operating leases are presented in the consolidated balance sheet as operating lease right-of-use assets, classified as noncurrent assets, and operating lease liabilities, classified as current and noncurrent liabilities. Operating lease expense is recognized on a straight-line basis over the lease term. Variable costs associated with a lease, such as maintenance and utilities, are not included in the measurement of the lease liabilities and right-of-use assets but rather are expensed when the events determining the amount of variable consideration to be paid have occurred.

[0001805385-26-000012:notes:90]
Inventory

[0001805385-26-000012:notes:91]
Inventory is stated at the lower of cost or net realizable value with cost being determined using the weighted average method. The Company regularly reviews inventory quantities on-hand for excess and obsolete inventory and, when circumstances indicate, records charges to write down inventories to their estimated net realizable value, after evaluating historical sales, future demand, market conditions and expected product life cycles. Such charges are classified as product cost of revenues in the consolidated statement of operations and comprehensive loss. Any write-down of inventory to net realizable value creates a new cost basis. The Company recorded $2.9 million and $2.6 million in inventory write-offs and change in inventory reserves during the years ended December 31, 2025 and 2024, respectively. Inventory reserves and write-offs primarily related to Evolv Edge systems and prior generation Evolv Express systems and related components, as well as other inventory that was determined to be obsolete or unsellable.

[0001805385-26-000012:notes:92]
Property and Equipment

[0001805385-26-000012:notes:93]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization expense are recognized using the straight-line method over the estimated useful life of each asset, as follows:

[0001805385-26-000012:notes:94]
|  | Estimated Useful Life |
| Computers and telecommunications equipment | 3 years |
| Lab equipment | 5 years |
| Software | 4 years |
| Furniture and fixtures | 5 years |
| Leasehold improvements | Shorter of useful life of 7 years or remaining lease term |
| Leased equipment | 7 years |
| Internal-use software | 4 years |
| Sales demo equipment | 7 years |
| Vehicles | 5 years |

[0001805385-26-000012:notes:95]
Estimated useful lives are periodically assessed to determine if changes are appropriate. Leasehold improvements are depreciated using the straight-line method over the lesser of the lease term or its estimated economic useful life. Lease terms are used based upon the initial lease agreement and do not consider potential renewals or extensions until such time that the renewals or extensions are contracted. Maintenance and repairs are charged to expense as incurred. When assets are retired or otherwise disposed of, the cost of these assets and related accumulated depreciation are eliminated from the consolidated balance sheet and any resulting gains or losses are included in the consolidated statements of operations and comprehensive loss in the period of disposal. Costs for capital assets not yet placed into service are capitalized as construction-in-progress and depreciated once placed into service. The Company recorded $3.8 million of loss on disposal of property and equipment during the year ended December 31, 2025. There was no loss on disposal of property and equipment during the year ended December 31, 2024.

[0001805385-26-000012:notes:96]
The Company’s leases for leased equipment generally are 48 months. The Company’s subscription contracts are generally classified as operating leases because title does not transfer and they do not meet any of the other criteria to be recognized as a sales type lease per Accounting Standards Codification 842 – Leases (“ASC 842”).

[0001805385-26-000012:notes:97]
The Company evaluates property and equipment for obsolescence and impairment whenever events or changes in business circumstances indicate that the carrying amount of the assets may not be fully recoverable. Factors that the Company considers in deciding when to perform an impairment review include significant underperformance of the business in relation to expectations, significant negative industry or economic trends and significant changes or planned changes in the use of the assets. If an impairment review is performed to evaluate a long-lived asset group for recoverability, the Company compares forecasts of undiscounted cash flows expected to result from the use and eventual disposition of the long-lived asset group to its carrying value. An impairment loss would be recognized in loss from operations and comprehensive loss when estimated undiscounted future cash flows expected to result from the use of an asset group are less than its carrying amount. The impairment loss is based on the excess of the carrying value of the impaired asset group over its fair value, determined based on discounted cash flows. The Company recorded impairment losses of $0.2 million during the year ended December 31, 2024, which related primarily to Evolv Express systems and IT equipment that were taken out of service and retired. There was no impairment loss during the year ended December 31, 2025.

[0001805385-26-000012:notes:98]
The Company capitalizes certain software development costs, including consulting costs and compensation expenses for employees who devote time to the development projects, beginning upon completion of the preliminary project stage (in relation to internal-use software) or upon establishment of technological feasibility (in relation to software embedded in products to be sold or leased), and through the date the software is ready for its intended use. The Company records software development costs in property and equipment, net. Costs incurred in the preliminary stages of development activities and post implementation are expensed in the period incurred and are recorded in research and development expense in the consolidated statements of operations and comprehensive loss. The Company also capitalizes costs related to specific upgrades and enhancements when it is probable the expenditures will result in additional functionality.

[0001805385-26-000012:notes:99]
Once the project is available for general release, capitalization ceases, and the asset can begin amortization. Capitalized software costs are amortized on a straight-line basis over their estimated useful life, which is generally four years, and are recorded in cost of subscription revenue and cost of service revenue in the consolidated statements of operations and comprehensive loss.

[0001805385-26-000012:notes:100]
Debt and Debt Issuance Costs

[0001805385-26-000012:notes:101]
Debt is initially recognized at the amount of proceeds received, net of directly attributable issuance costs. The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated debt on the consolidated balance sheet and amortized as interest expense on the consolidated statement of operations and comprehensive loss using the effective interest method.

[0001805385-26-000012:notes:102]
For undrawn delayed draw and revolving line of credit facilities, commitment fees and related costs are costs incurred in exchange for access to capital. These fees are paid regardless of whether the funds are drawn down. Such costs associated with delayed draw facility are capitalized as prepaid expenses and other current assets and other assets in our consolidated balance sheets, and such costs associated with revolving line of credit are capitalized as other assets in our consolidated balance sheets. The capitalized costs are amortized as interest expense on a straight-line basis over the access period. If drawdown of the delayed draw facility becomes probable, the remaining unamortized costs are reclassified as contra-debt and amortized using the effective interest method. If it becomes probable that the delayed draw facility will not be drawn during the access period, the remaining unamortized cost will be recognized as expense in the period that determination was made.

[0001805385-26-000012:notes:103]
Segment Information

[0001805385-26-000012:notes:104]
The Company determined that it has one operating segment after considering the Company’s organizational structure and the information regularly reviewed and evaluated by the Company’s chief operating decision maker (“CODM”) in deciding how to allocate resources and assess performance. The Company has determined that its CODM is

[0001805385-26-000012:notes:105]
its President and Chief Executive Officer. The CODM reviews the financial information on a consolidated basis for purposes of evaluating financial performance and allocating resources. On the basis of these factors, the Company determined that it operates and manages its business as one operating segment, that develops, manufactures, markets and sells security screening products and specific services, and accordingly has one reportable segment for financial reporting purposes. Refer to Note 21, Segment Information, for more detail.

[0001805385-26-000012:notes:106]
Revenue Recognition

[0001805385-26-000012:notes:107]
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

[0001805385-26-000012:notes:108]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001805385-26-000012:notes:109]
Distribution and License Agreement

[0001805385-26-000012:notes:110]
In March 2023, the Company entered into a distributor licensing agreement (the "Distribution and License Agreement") with Columbia Electrical Contractors, Inc. ("Columbia Tech"). Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, serves as the Company's primary contract manufacturer. Under this arrangement, the Company has granted a license of its intellectual property to Columbia Tech, which contracts directly with certain of the Company's resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment as opposed to lease the equipment. Columbia Tech pays the Company a hardware license fee for each system it manufactures and sells under the agreement. In these instances, the Company still contracts directly with the reseller to provide a multi-year SaaS and maintenance subscription to the end-users. The Distribution and License Agreement expired on December 31, 2025, and the Company no longer offers the distributor license model.

[0001805385-26-000012:notes:111]
The Company has assessed whether it operates as the principal or as an agent in relation to the sale of product made by Columbia Tech to the Company's resellers pursuant to the Distribution and License Agreement. The Company considered various factors, including but not limited to, inventory risk, discretion in establishing pricing, and which entity is primarily responsible for fulfillment. Based on an evaluation of the facts and circumstances, the Company concluded that Columbia Tech is the principal in the arrangement. The Company therefore does not recognize revenue in relation to sales of product pursuant to the Distribution and License Agreement, but does recognize revenue in relation to license fees received from Columbia Tech and the SaaS and maintenance subscription contracts, each as further described below.

[0001805385-26-000012:notes:112]
Product Revenue

[0001805385-26-000012:notes:113]
The Company derives revenue from the sale of its Evolv Express and Evolv eXpedite equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. Products are predominantly sold with distinct services, which are described in the services section below.

[0001805385-26-000012:notes:114]
Subscription Revenue - Leases as Lessor

[0001805385-26-000012:notes:115]
Subscription revenue consists of revenue derived from leasing Evolv Express and Evolv eXpedite systems to customers. Lease terms are typically four years, generally do not include unilateral options by either the Company or our customer to extend, terminate or to purchase the underlying asset, and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. There are no variable lease payments as a part of these arrangements.

[0001805385-26-000012:notes:116]
The accounting provisions we use to classify transactions as sales-type are: (i) whether the lease transfers ownership of the equipment by the end of the lease term, (ii) whether the lease grants the customer an option to purchase the equipment and the customer is reasonably certain to do so, (iii) whether the lease term is for the major part of the economic life of the underlying equipment, (iv) whether the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (v) whether the equipment is specific to the customer and of such a specialized nature that it is expected to have no alternative use to the Company at the end of the lease term. Leasing arrangements meeting any of these conditions are accounted for as sales-type leases and revenue attributable to the lease component is recognized in a manner consistent with product revenue and the related equipment is derecognized with the associated expense presented as a cost of revenue. Leasing arrangements that do not meet the criteria for classification as a sales-type lease will be accounted for as a direct-financing lease if the following two conditions are met: (i) the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments and any other third party unrelated to the Company, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (ii) it is probable that the Company will collect the lease payments and amounts necessary to satisfy a residual value guarantee. Leasing arrangements that do not meet any of the sales-type lease or direct-financing lease classification criteria are accounted for as operating leases and revenue is recognized straight-line over the term of the lease. Historically, nearly all of the Company's equipment leases have been classified as operating leases.

[0001805385-26-000012:notes:117]
The Company considers the economic life of most of Evolv Express and Evolv eXpedite systems to be seven years. The Company believes seven years is representative of the period during which the equipment is expected to be economically usable by one or more users, with normal service, for the purpose for which it is intended. The unguaranteed residual value is estimated to be the value at the end of the lease term based on the anticipated fair market value of the units. The Company mitigates residual value risk of our leased equipment by performing regular management and maintenance, as necessary.

[0001805385-26-000012:notes:118]
Generally, lease arrangements include both lease and non-lease components. The lease component relates to the customer’s right-to-use the equipment over the lease term. The non-lease components relate to (1) distinct services, such as SaaS and maintenance, (2) any add-on accessories, and (3) professional services, including installation, training, and event. Professional services are included in license fees and other revenue, as described below, and add-on accessories are included in product revenue. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the Company elected the practical expedient to aggregate non-lease components with the associated lease component and account for the combined component as a as a service arrangement under ASC 606. The equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations and comprehensive loss. The professional services represent distinct services provided to customers. These activities are considered separate performance obligations to the customer and therefore are considered non-lease components. As professional services are generally performed prior to lease commencement, the timing and pattern of transfer for these services differ from that of the lease component and are not eligible to be combined.

[0001805385-26-000012:notes:119]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party when those payments represent lessor costs that do not transfer a good or service to the lessee (e.g., property taxes and insurance).

[0001805385-26-000012:notes:120]
Professional services are generally billed to the lessee as part of the lease contract billing, according to various contractual terms. Professional services costs incurred by the Company are accounted for as a fulfillment cost and are included in the cost of license fees and other revenue in the consolidated statements of operations and comprehensive loss.

[0001805385-26-000012:notes:121]
Service Revenue

[0001805385-26-000012:notes:122]
Service revenue consists of subscription-based SaaS and maintenance revenue related to Evolv Express and Evolv eXpedite systems sold to customers, either directly by us through our purchase subscription model or by our distributor through our distributor license model. We no longer offer the distributor license model for new unit sales. Customers generally pay an annual fixed payment for SaaS and maintenance. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically 4 years.

[0001805385-26-000012:notes:123]
License Fee and Other Revenue

[0001805385-26-000012:notes:124]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from our third-party manufacturer to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration. Revenue for professional services and other one-time revenue, which had previously been included in service revenue, has been reclassified for prior periods to License fee and other revenue on the consolidated statements of operations and comprehensive loss. During the three months ended September 30, 2025, we discontinued quoting under the Distribution and License Agreement, which expired on December 31, 2025. While any outstanding quotes under the expired agreement will be honored, all new quotes for end-user customers wishing to purchase the hardware equipment will be fulfilled through our purchase subscription model going forward.

[0001805385-26-000012:notes:125]
Revenue from Reseller Partners

[0001805385-26-000012:notes:126]
A portion of the Company’s revenue is also generated by sales to its reseller partners. When the Company transacts with a reseller partner, its contractual arrangement is with the reseller partner and not with the end-use customer. In these transactions, the reseller partner is considered the customer; the Company has discretion over the pricing to the reseller partner and maintains overall control of the inventory and sales process to the reseller partner. Right of return does not generally exist. Whether the Company transacts with a reseller partner and receives the order from a reseller partner or directly from an end-use customer, its revenue recognition policy and resulting pattern of revenue recognition is the same.

[0001805385-26-000012:notes:127]
Transaction Price

[0001805385-26-000012:notes:128]
The transaction price is the amount of consideration that the Company expects to be entitled for providing goods and services under a contract, which includes fixed amounts, and on rare occasions, variable consideration. The Company may also provide discounts to customers which reduce the transaction price. On infrequent occasions, the Company may offer customers the option to purchase additional goods and services at a fixed price. In these circumstances, the Company assesses whether these offers constitute a material right, and if so, the Company would account for the material right as a separate performance obligation. The Company does not normally provide for rights of returns to customers on product sales and, therefore, does not record a provision for returns. Amounts paid or payable to customers, including those related to sponsorship arrangements, are recognized as a reduction of the transaction price, and therefore, of revenue unless the payment is in exchange for a distinct good or service, which has typically not been the case to date.

[0001805385-26-000012:notes:129]
Performance Obligations

[0001805385-26-000012:notes:130]
A performance obligation is a promise in a contract to transfer a distinct product or service to a customer that is both capable of being distinct, whereby the customer can benefit from the product or service either on its own or together with other resources that are readily available, and is distinct in the context of the contract, whereby the transfer of the product or service is separately identifiable from other promises in the contract.

[0001805385-26-000012:notes:131]
Equipment is sold or leased with embedded software, which is considered a single performance obligation. Maintenance, which includes preventative maintenance, future updates, security threat updates, and minor bug fixes on a when-and-if available basis, is considered a single performance obligation. SaaS, which includes data-driven security information and analytics insights, is also considered a performance obligation. Professional services, including installation, training, and event support, are considered separate performance obligations and are included within license fee and other revenue. Any add-on accessories are also considered separate performance obligations and are included in product revenue.

[0001805385-26-000012:notes:132]
Payment terms

[0001805385-26-000012:notes:133]
Payment terms for customer orders are typically 30 days after the shipment of the product. Generally, the Company’s contracts do not contain a significant financing component.

[0001805385-26-000012:notes:134]
Multiple Performance Obligations within an Arrangement

[0001805385-26-000012:notes:135]
The Company’s contracts may include multiple performance obligations when customers purchase a combination of products and services. When the Company’s customer arrangements have multiple performance obligations that contain an equipment lease for the customer’s use as well as distinct services that are delivered simultaneously, the Company allocates the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, the Company allocates the contract’s transaction price to each performance obligation on a relative SSP basis. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company estimates the SSP taking into account available information such as market conditions, internally approved pricing guidelines, and observable pricing data such as standard cost metrics related to the performance obligation.

[0001805385-26-000012:notes:136]
Commissions

[0001805385-26-000012:notes:137]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract.

[0001805385-26-000012:notes:138]
Partner Rebate Program

[0001805385-26-000012:notes:139]
For the fiscal year 2025, the Company implemented a channel partner rebate program (the “Rebate Program”) for eligible resellers. Under the Rebate Program, eligible resellers that attain at least 25% of their current fiscal year total contract value (“TCV”) target (“Annual Target”) in a given quarter are eligible for a rebate based upon a percentage of their TCV for that quarter. In addition, resellers that meet their Annual Target are eligible for a one-time rebate based upon a percentage of their total fiscal year TCV, applied as a credit in the subsequent fiscal year. All rebates are issued as credits against future purchases, and no cash rebates are paid. Unused rebate credits are forfeited in the event of a reseller agreement termination.

[0001805385-26-000012:notes:140]
The Company recognizes an accrued liability related to the Rebate Program in accrued expenses and other current liabilities in our condensed consolidated balance sheets and recognizes the rebates as reduction of revenue.

[0001805385-26-000012:notes:141]
Stock-Based Compensation

[0001805385-26-000012:notes:142]
The Company measures all stock-based awards granted to employees, officers, directors and non-employees based on their fair value on the date of the grant and recognizes compensation expense for those awards over the requisite service period, which is generally the vesting period of the respective award. The vesting period for stock options is generally four years and the vesting period for restricted stock units is generally three years. The Company classifies stock-based compensation expense in its consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. The Company issues stock-based awards with service-based vesting conditions and records the expense for these awards using the straight-line method. Forfeitures are accounted for as they occur.

[0001805385-26-000012:notes:143]
In January 2021, the Company granted warrants (the "Finback Common Stock Warrants") exercisable for 2,552,913 shares of common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC ("Finback"), a consulting group affiliated with one of the Company's shareholders. The Finback Common Stock Warrants vested upon meeting certain sales criteria as defined in a business development agreement (the "Finback BDA") which has a term of three years and an expiration date of January 2031. As of December 31, 2025, all 1,221,296 of the Finback Common Stock Warrants were exercised. Consequently, there were no remaining Finback Common Stock Warrants that were exercisable or unvested, given the expiration of the 1-year tail period on January 1, 2024. The Finback Common Stock Warrants were

[0001805385-26-000012:notes:144]
accounted for under ASC 718 Compensation - Stock Compensation as the warrants vested upon certain performance conditions being met.

[0001805385-26-000012:notes:145]
Prior to the closing of the Merger, there was not a public market for the shares of the Company’s common stock. The Company’s determination of the fair value of stock options on the date of grant utilized the Black-Scholes option-pricing model and was impacted by its common stock price, as determined by the Board of Directors with input from the Company’s management, as well as changes in assumptions regarding a number of subjective variables. These variables included, but were not limited to, the expected term that options remained outstanding, the expected common stock price volatility over the term of the option awards, risk-free interest rates, and expected dividends. The Company valued its common stock taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the Company determines the fair value of each share of common stock underlying stock-based awards based on the closing price of the Company’s common stock as reported by Nasdaq on the date of grant.

[0001805385-26-000012:notes:146]
Pursuant to the Merger Agreement, the Company was to issue 15,000,000 earn-out shares of the Company’s common stock to Legacy Evolv shareholders and Legacy Evolv Service Providers including employees, officers, directors, and non-employees based on the achievement of certain target share price contingencies to be achieved by March 8, 2026 and subject to continued employment. The Company classifies the share-based compensation arrangement with Legacy Evolv Service Providers as equity on its balance sheet and corresponding stock-based compensation expense in its consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. As of December 31, 2025, of the total 15,000,000 earn-out shares of the Company’s common stock, 1,137,846 earn-out shares could be earned by the Legacy Evolv Service Providers and were subject to the stock-based compensation guidance. As a condition for earn-out shares being issued to Earn-Out Service Providers, the service provider must be providing services to the Company on the date of the issuance of the shares. If the relationship with the service provider were to be terminated prior to the issuance of the Earn-Out Shares, the shares would be redistributed to the remaining participants in the Earn-Out Shares. As of March 8, 2026, none of the targets required for issuance had been met, and thus no earn-out shares became issuable.

[0001805385-26-000012:notes:147]
Additionally, beginning in 2025, the Company began granting Market-based Stock Units (“MSUs”) to certain of its employees. These MSUs are subject to certain vesting conditions based on the appreciation of the Company’s stock price as well as continued service over a specified term. The estimated grant date fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.

[0001805385-26-000012:notes:148]
Income Taxes

[0001805385-26-000012:notes:149]
The Company accounts for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in the consolidated financial statements or in the Company’s tax returns. Deferred tax assets and liabilities are determined on the basis of the differences between the consolidated financial statements and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. Changes in deferred tax assets and liabilities are recorded in the provision for income taxes.

[0001805385-26-000012:notes:150]
The Company assesses the likelihood that its deferred tax assets will be recovered from future sources of income and, to the extent it believes, based upon the weight of available evidence, that it is more likely than not that all or a portion of the deferred tax assets will not be realized, a valuation allowance is established through a charge to income tax expense. The potential for recovery of deferred tax assets is evaluated by analyzing past operating results, estimating the future taxable profits expected and considering prudent and feasible tax planning strategies.

[0001805385-26-000012:notes:151]
The Company accounts for uncertainty in income taxes recognized in the consolidated financial statements by applying a two-step process to determine the amount of tax benefit to be recognized. First, the tax position must be evaluated to determine the likelihood that it will be sustained upon external examination by the taxing authorities. If the tax position is deemed more-likely-than-not to be sustained, the tax position is then assessed to determine the amount of benefit to recognize in the consolidated financial statements. The amount of the benefit that may be recognized is the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. The provision for income

[0001805385-26-000012:notes:152]
taxes includes the effects of any resulting tax reserves, or unrecognized tax benefits, that are considered appropriate as well as the related net interest and penalties.

[0001805385-26-000012:notes:153]
The Company evaluates at the end of each reporting period whether some or all the undistributed earnings of its foreign subsidiaries are permanently reinvested. The Company would recognize deferred income tax liabilities to the extent that management asserts that undistributed earnings of its foreign subsidiaries are not permanently reinvested and will not be permanently reinvested in the future. The Company will continue to evaluate its position in the future based on its future strategy and cash needs.

[0001805385-26-000012:notes:154]
Net Loss per Share Attributable to Common Stockholders

[0001805385-26-000012:notes:155]
Basic net loss per share attributable to common stockholders is computed by dividing the net loss attributable to common stockholders by the weighted average number of common shares outstanding for the period. Diluted net loss attributable to common stockholders is computed by adjusting net loss attributable to common stockholders for the impact to the extent a denominator adjustment is required. Diluted net loss per share attributable to common stockholders is computed by dividing the diluted net loss attributable to common stockholders by the weighted average number of common shares outstanding for the period, including the dilutive effect of potential dilutive common shares as determined under the treasury stock method. For purposes of this calculation, outstanding stock options, convertible preferred stock, convertible notes, warrants to purchase common stock, and warrants to purchase preferred stock are considered potential dilutive common shares.

[0001805385-26-000012:notes:156]
In periods in which the Company reported a net loss attributable to common stockholders, diluted net loss per share attributable to common stockholders is the same as basic net loss per share attributable to common stockholders, since dilutive common shares are not assumed to have been issued if their effect is anti-dilutive. The Company reported a net loss attributable to common stockholders for the years ended December 31, 2025 and 2024.

[0001805385-26-000012:notes:157]
Recently Adopted Accounting Pronouncements

[0001805385-26-000012:notes:158]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity may apply the amendments in ASU 2023-09 either prospectively to all annual periods beginning after December 15, 2024, or retrospectively to prior periods. The Company adopted this guidance prospectively effective December 31, 2025. This ASU addresses disclosures only, and as such the adoption of this guidance did not have any material effects on its financial condition, results of operations, or cash flows.

[0001805385-26-000012:notes:159]
Recently Issued Accounting Pronouncements

[0001805385-26-000012:notes:160]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses.”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Further, in January 2025, the FASB issued ASU 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Clarifying the Effective Date)" to clarify the effective date of ASU 2024-03. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 and ASU 2025-01 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

[0001805385-26-000012:notes:161]
In July 2025, the FASB issued ASU 2025-05, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets.” The amendment in ASU 2025-05 provides entities with a practical expedient to simplify the estimation of expected credit losses by assuming that the current conditions as of the balance sheet date will not change for the remaining life of the asset. Early adoption is permitted, and this amendment is

[0001805385-26-000012:notes:162]
applied prospectively. ASU 2025-05 is effective for all annual periods beginning after December 15, 2025 and interim periods within those annual periods. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

[0001805385-26-000012:notes:163]
In September 2025, the FASB issued ASU 2025-06, “Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software.”, which amends guidance on capitalization of software development costs and introduces a probable-to-complete recognition threshold, along with factors to consider for evaluating significant development uncertainty. The amendments are effective for annual reporting periods beginning after December 15, 2027, including interim periods within those annual periods. Early adoption is permitted and this amendment is applied prospectively. The Company is currently evaluating the impact of this ASU on its accounting policies and disclosures within the consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001805385-26-000012:notes:164]
Marketable Securities
Marketable securities as of December 31, 2025 consisted of the following:

[0001805385-26-000012:notes:165]
|  | December 31, 2025 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 19,885 |  |  | $ | — |  |  | $ | 19,885 |  |
| Total marketable securities | $ | 19,885 |  |  | $ | — |  |  | $ | 19,885 |  |

[0001805385-26-000012:notes:166]
|  | December 31, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 14,927 |  |  | $ | — |  |  | $ | 14,927 |  |
| Total marketable securities | $ | 14,927 |  |  | $ | — |  |  | $ | 14,927 |  |

[0001805385-26-000012:notes:167]
Marketable securities at December 31, 2025 and December 31, 2024 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the year ended December 31, 2025 and 2024. The accretion of discounts on marketable securities is included in interest income on the consolidated statements of operations and comprehensive income.


## us-gaap:FairValueDisclosuresTextBlock

[0001805385-26-000012:notes:168]
Fair Value Measurements
The following tables present information about the Company’s financial assets and liabilities measured at fair value on a recurring basis and indicate the level of the fair value hierarchy used to determine such fair values (in thousands):

[0001805385-26-000012:notes:169]
|  | Fair Value Measurements at December 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 39,406 |  |  | $ | — |  |  | $ | — |  |  | $ | 39,406 |  |
| Treasury bills | — |  |  | 19,885 |  |  | — |  |  | 19,885 |  |
| Contingently returnable common stock asset | $ | — |  |  | $ | — |  |  | $ | 4,094 |  |  | $ | 4,094 |  |
|  | $ | 39,406 |  |  | $ | 19,885 |  |  | $ | 4,094 |  |  | $ | 63,385 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 374 |  |  | $ | 374 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 1,809 |  |  | 1,809 |  |
| Public Warrant liability | 3,862 |  |  | — |  |  | — |  |  | 3,862 |  |
|  | $ | 3,862 |  |  | $ | — |  | $ | — |  | $ | 2,183 |  | $ | — |  | $ | 6,045 |  |

[0001805385-26-000012:notes:170]
|  | Fair Value Measurements at December 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 28,946 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,946 |  |
| Treasury bills | $ | — |  |  | $ | 27,417 |  |  | $ | — |  |  | $ | 27,417 |  |
|  | $ | 28,946 |  |  | $ | 27,417 |  |  | $ | — |  |  | $ | 56,363 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | — |  |  | — |  |  | 12,809 |  |  | 12,809 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 4,001 |  |  | 4,001 |  |
| Public Warrant liability | 4,297 |  |  | — |  |  | — |  |  | 4,297 |  |
|  | $ | 4,297 |  |  | $ | — |  |  | $ | 16,810 |  |  | $ | 21,107 |  |

[0001805385-26-000012:notes:171]
Money market funds are included in cash and cash equivalents on the consolidated balance sheets. As of December 31, 2025, U.S. treasury bills with maturities greater than 3 months, which totaled $19.9 million, are reflected as marketable securities. At December 31, 2024, U.S. treasury bills with maturities less than 3 months, which totaled $12.5 million, are included in cash and cash equivalents, while treasury bills with maturities greater than 3 months, which totaled $14.9 million, are reflected as marketable securities. The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources.

[0001805385-26-000012:notes:172]
The Company may also value its non-financial assets and liabilities, including items such as inventories and property and equipment, at fair value on a non-recurring basis if it is determined that impairment has occurred. Such fair value measurements use significant unobservable inputs and are classified as Level 3.

[0001805385-26-000012:notes:173]
The carrying amounts of cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and other accrued expenses approximate fair value because of their short maturity.

[0001805385-26-000012:notes:174]
The carrying value of the Company’s long-term debt approximates its fair value (a Level 2 measurement) at each balance sheet date due to its variable interest rate, which approximates a market interest rate.

[0001805385-26-000012:notes:175]
During each of the years ended December 31, 2025 and 2024, there were no transfers between Level 1, Level 2, and Level 3.

[0001805385-26-000012:notes:176]
Valuation of Contingent Earn-out

[0001805385-26-000012:notes:177]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of December 31, 2025, no milestones have been achieved, and as of March 8, 2026, all contingent earn-out shares expired.

[0001805385-26-000012:notes:178]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of December 31, 2025 were as follows: 70% expected stock price volatility, a risk-free rate of return of 3.7%, a 5% likelihood of change in control, and a remaining term of 0.2 years. The assumed likelihood of change in control was reduced to 5% as of December 31, 2025 from 25% as of December 31, 2024, reflecting the shortened remaining term of less than one year.

[0001805385-26-000012:notes:179]
The following table provides a rollforward of the contingent earn-out liability (in thousands):

[0001805385-26-000012:notes:180]
| Balance at December 31, 2023 | $ | 29,119 |  |
| Change in fair value | (16,310) |  |
| Balance at December 31, 2024 | $ | 12,809 |  |
| Change in fair value | (12,435) |  |
| Balance at December 31, 2025 | $ | 374 |  |

[0001805385-26-000012:notes:181]
The decrease in fair value of the contingent earn-out liability is primarily due to lowered probability to achieve the stock price milestones based on the Company's current stock price and a shorter remaining term.

[0001805385-26-000012:notes:182]
Valuation of Contingently Issuable Common Stock and Contingently Returnable Common Stock Asset

[0001805385-26-000012:notes:183]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 Founder Shares. Of these shares, 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 outstanding shares will vest upon the Company achieving certain milestones as described in Note 2 (“Vesting Conditions”). The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of December 31, 2025, no milestones have been achieved.

[0001805385-26-000012:notes:184]
Under the Founder Shares arrangement, Founder Shares may be transferred to third parties, subject to certain conditions. The unvested shares must be returned to the Company if the specified Vesting Conditions are not met. As of December 31, 2025, a total of 729,570 unvested shares had been transferred to individual stockholders' brokerage accounts. As of December 31, 2025, the fair value of the unvested shares recorded as additional paid in capital was $3.7 million. The contractual obligation of the holders to return unvested shares upon failure to meet Vesting Conditions is accounted for as a freestanding financial asset in accordance with ASC 815. This asset is initially recognized at fair value and remeasured at each reporting period. As of December 31, 2025, the Company recognized a $4.1 million contingently returnable common stock asset, which is included in other assets in our consolidated balance sheets. Management evaluated the accounting impacts on prior periods based on the historical dates of transfers between July 2022 and June 2025, concluding that such impacts were not material to the historical financial statements, as further described in Note 1, Nature of the Business.

[0001805385-26-000012:notes:185]
The fair value of the contingently issuable common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of December 31, 2025 were as follows: 65% expected stock price volatility, a risk-free rate of return of 3.6%, a 10% likelihood of change in control, and a remaining term of 0.5 years. The assumed likelihood of change in control was reduced to 10% as of December 31, 2025 from 25% as of December 31, 2024, reflecting the shortened remaining term of less than one year.

[0001805385-26-000012:notes:186]
The following table provides a rollforward of the contingently issuable common shares (in thousands):

[0001805385-26-000012:notes:187]
| Balance at December 31, 2023 | $ | 6,530 |  |
| Change in fair value | (2,529) |  |
| Balance at December 31, 2024 | $ | 4,001 |  |
| Change in fair value | 32 |  |
| Fair value adjustment for contingently returnable shares | (2,224) |  |
| Balance at December 31, 2025 | $ | 1,809 |  |

[0001805385-26-000012:notes:188]
The following table provides a rollforward of the contingently returnable common stock asset (in thousands):

[0001805385-26-000012:notes:189]
| Balance at December 31, 2024 | $ | — |  |
| Change in fair value | 2,646 |  |
| Fair value adjustment for contingently returnable shares | 1,448 |  |
| Balance at December 31, 2025 | $ | 4,094 |  |

[0001805385-26-000012:notes:190]
Valuation of Public Warrant Liability

[0001805385-26-000012:notes:191]
In connection with the closing of the Merger, the Company assumed the Public Warrants to purchase shares of the Company’s common stock. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. As of December 31, 2025, 14,324,893 Public Warrants are outstanding.

[0001805385-26-000012:notes:192]
The following table provides a rollforward of the public warrant liability (in thousands):

[0001805385-26-000012:notes:193]
| Balance at December 31, 2023 | $ | 10,889 |  |
| Change in fair value | (6,592) |  |
| Balance at December 31, 2024 | $ | 4,297 |  |
| Change in fair value | (435) |  |
| Balance at December 31, 2025 | $ | 3,862 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001805385-26-000012:notes:194]
Revenue Recognition
Remaining Performance Obligations

[0001805385-26-000012:notes:195]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of December 31, 2025.

[0001805385-26-000012:notes:196]
|  | Less than 1 year |  | 1 - 2 years |  | More than 2 years |  | Total |
| Product revenue | $ | 9,852 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,852 |  |
| Subscription revenue | 84,729 |  |  | 64,482 |  |  | 57,239 |  |  | 206,450 |  |
| Service revenue | 32,130 |  |  | 21,695 |  |  | 22,635 |  |  | 76,460 |  |
| License fee and other revenue | 418 |  |  | 138 |  |  | 271 |  |  | 827 |  |
| Total revenue* | $ | 127,129 |  |  | $ | 86,315 |  |  | $ | 80,145 |  |  | $ | 293,589 |  |

[0001805385-26-000012:notes:197]
*The Company identified an immaterial error in its 2024 RPO disclosure of $7.6 million. The Company has updated the RPO disclosure as of December 31, 2025 to appropriately exclude this amount.

[0001805385-26-000012:notes:198]
Contract Balances from Contracts with Customers

[0001805385-26-000012:notes:199]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is unconditional and only subject to the passage of time. As of December 31, 2025 and December 31, 2024, the Company had $0.9 million and $0.8 million in current portion of contract assets and less than $0.1 million and $0.7 million in contract assets, noncurrent on the consolidated balance sheets, respectively.

[0001805385-26-000012:notes:200]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $64.5 million during the year ended December 31, 2025 that was included in the December 31, 2024 deferred revenue balance. The Company recognized revenue of $46.4 million during the year ended December 31, 2024 that was included in the December 31, 2023 deferred revenue balance.

[0001805385-26-000012:notes:201]
The following table provides a rollforward of deferred revenue (in thousands):

[0001805385-26-000012:notes:202]
| Balance at December 31, 2023 | $ | 71,957 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (46,431) |  |
| Revenue deferred | 59,246 |  |
| Balance at December 31, 2024 | $ | 84,772 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (64,490) |  |
| Revenue deferred | 71,358 |  |
| Balance at December 31, 2025 | $ | 91,640 |  |

[0001805385-26-000012:notes:203]
The following table presents the Company’s components of lease revenue (in thousands):

[0001805385-26-000012:notes:204]
|  | Twelve Months EndedDecember 31, |
|  | 2025 |  | 2024 |  |  |
| Interest income on lease receivables | 97 |  |  | 154 |  |  |  |
| Lease income - operating leases | 83,839 |  |  | 65,046 |  |  |  |
| Total lease revenue | $ | 83,936 |  |  | $ | 65,200 |  |  |  |

[0001805385-26-000012:notes:205]
The interest income on lease receivables is classified under interest income in the consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the consolidated statements of operations and

[0001805385-26-000012:notes:206]
comprehensive loss. Revenue related to leases entered into with related parties was $1.1 million during the year ended December 31, 2024. There was no revenue related to leases entered into with related parties during the year ended December 31, 2025

[0001805385-26-000012:notes:207]
Disaggregated Revenue

[0001805385-26-000012:notes:208]
The following table presents the Company’s revenue by revenue stream (in thousands). Certain prior period amounts have been reclassified to conform to current period presentation:

[0001805385-26-000012:notes:209]
|  | Twelve Months EndedDecember 31, |
|  | 2025 |  | 2024 |  |  |
| Product revenue | $ | 21,637 |  |  | $ | 6,464 |  |  |  |
| Subscription revenue | 83,839 |  |  | 65,046 |  |  |  |
| Service revenue | 29,375 |  |  | 23,467 |  |  |  |
| License fees | 8,075 |  |  | 7,181 |  |  |  |
| Professional services and other revenue | 2,979 |  |  | 1,707 |  |  |  |
| Total revenue | $ | 145,905 |  |  | $ | 103,865 |  |  |  |

[0001805385-26-000012:notes:210]
The following table presents the Company's revenue by geographical region based on customer location (in thousands):

[0001805385-26-000012:notes:211]
|  | Twelve Months EndedDecember 31, |
|  | 2025 |  | 2024 |  |  |
| United States | $ | 140,652 |  |  | $ | 99,995 |  |  |  |
| Foreign | 5,253 |  |  | 3,870 |  |  |  |
| Total revenue | $ | 145,905 |  |  | $ | 103,865 |  |  |  |

[0001805385-26-000012:notes:212]
As discussed in Note 2, Summary of Significant Accounting Policies, the Company implemented a new Rebate Program for eligible resellers. As of December 31, 2025, the Company has accrued $1.2 million related to the Rebate Program, which is included in accrued expenses and other current liabilities in our consolidated balance sheets. As a substantial amount of the Company's revenue with eligible resellers is recognized over-time, the Company recognized $0.2 million and $0.6 million of current portion of contract asset and contract asset, noncurrent in our consolidated balance sheets, respectively, as of December 31, 2025 and recognized $0.4 million as a reduction of revenue for these payments to our customers for the year ended December 31, 2025.

[0001805385-26-000012:notes:213]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had total deferred assets related to commissions of $13.1 million and $13.0 million as of December 31, 2025 and December 31, 2024, respectively. During the years ended December 31, 2025 and 2024, the Company recognized commission expense of $7.4 million and $5.7 million, respectively.

[0001805385-26-000012:notes:214]
Leases

[0001805385-26-000012:notes:215]
The amount of minimum future leases is based on expected income recognition. As of December 31, 2025, future minimum payments on noncancelable leases are as follows (in thousands):

[0001805385-26-000012:notes:216]
| Year Ending December 31: |  |
| 2026 | $ | 84,729 |  |
| 2027 | 64,482 |  |
| 2028 | 38,735 |  |
| 2029 | 17,633 |  |
| Thereafter | 871 |  |
|  | $ | 206,450 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001805385-26-000012:notes:217]
Leases
Company Headquarters (Waltham, MA)

[0001805385-26-000012:notes:218]
In April 2021, the Company entered into a sublease agreement for office and storage space for its corporate headquarters located at 500 Totten Pond Road in Waltham, MA. The Company entered into an amendment to the sublease agreement during the three months ended September 30, 2023 in order to lease additional space within the building. During the three months ended March 31, 2024, the Company amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. During the three months ended September 30, 2024, the Company amended the lease agreement to expand our footprint in our headquarters and extend our lease until May 31, 2031. As a result of this amendment, no further option exists to extend the lease.

[0001805385-26-000012:notes:219]
Storage Facilities

[0001805385-26-000012:notes:220]
The Company additionally leases storage space on a month-to-month basis that is classified as short-term leases.

[0001805385-26-000012:notes:221]
Operating lease cost recognized during the years ended December 31, 2025 and December 31, 2024 was $3.0 million and $2.1 million, respectively. Cash paid for amounts included in the measurement of lease liabilities for the years ended December 31, 2025 and December 31, 2024 was $2.3 million and $1.8 million, respectively.

[0001805385-26-000012:notes:222]
The weighted-average remaining lease term and discount rate were as follows:

[0001805385-26-000012:notes:223]
|  | December 31, |
|  | 2025 |  | 2024 |
| Weighted average remaining lease term | 5.4 years |  | 6.4 years |
| Weighted average discount rate | 9.24 | % |  | 9.23 | % |

[0001805385-26-000012:notes:224]
Future annual lease payments under non-cancelable operating leases as of December 31, 2025 were as follows (in thousands):

[0001805385-26-000012:notes:225]
| Year Ended December 31: |  |
| 2026 | $ | 2,963 |  |
| 2027 | 3,105 |  |
| 2028 | 3,199 |  |
| 2029 | 3,292 |  |
| 2030 | 3,386 |  |
| 2031 | 1,445 |  |
| Total future lease payments | 17,390 |  |
| Less: imputed interest | (3,747) |  |
| Present value of operating lease liability | $ | 13,643 |  |


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001805385-26-000012:notes:226]
Accounts Receivable
Allowance for Expected Credit Losses

[0001805385-26-000012:notes:227]
Changes in the allowance for expected credit losses were as follows (in thousands):

[0001805385-26-000012:notes:228]
|  | Allowance for Expected Credit Losses |
| December 31, 2023 | $ | (582) |  |
| Provision for expected credit losses | (155) |  |
| Write-offs, net of recoveries | 3 |
| December 31, 2024 | $ | (734) |  |
| Provision for expected credit losses | 114 |  |
| Write-offs, net of recoveries | 20 |
| December 31, 2025 | $ | (600) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001805385-26-000012:notes:229]
Inventory
Inventory consisted of the following (in thousands):

[0001805385-26-000012:notes:230]
|  | December 31, |
|  | 2025 |  | 2024 |
| Raw materials | $ | 3,273 |  |  | $ | 4,362 |  |
| Finished goods |  |  |  |
| Finished goods inventory | 5,317 |  |  | 12,153 |  |
| Uninstalled inventory | $ | 727 |  |  | $ | 448 |  |
| Total | $ | 9,317 |  |  | $ | 16,963 |  |

[0001805385-26-000012:notes:231]
The cost of equipment that has been shipped to a customer, but for which revenue recognition has not started due to the timing of the transfer of control, is included in finished goods inventory until the point in time that the Company transferred control of the equipment to the customer, corresponding to the revenue recognition start date. These amounts are included in Uninstalled inventory in the table above.


## evlv:PrepaidExpenseAndOtherAssetsCurrentTextBlock

[0001805385-26-000012:notes:232]
Prepaid expenses and other current assets
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001805385-26-000012:notes:233]
|  | December 31, |
|  | 2025 |  | 2024 |
| Prepaid deposits | $ | 11,905 |  |  | $ | 12,582 |  |
| Prepaid subscriptions | 1,685 |  |  | 2,087 |  |
| Prepaid insurance | 1,915 |  |  | 1,167 |  |
| Insurance proceeds receivable | 15,341 |  |  | — |  |
| Other | 4,323 |  |  | 2,085 |  |
| Total | $ | 35,169 |  |  | $ | 17,921 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001805385-26-000012:notes:234]
Property and Equipment, Net
Property and equipment, net consisted of the following (in thousands):

[0001805385-26-000012:notes:235]
|  | December 31, |
|  | 2025 |  | 2024 |
| Computers and telecom equipment | $ | 2,350 |  |  | $ | 2,064 |  |
| Lab equipment | 6,274 |  |  | 5,564 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 607 |  |  | 607 |  |
| Leased equipment | 140,981 |  |  | 112,078 |  |
| Capitalized software | 20,889 |  |  | 14,555 |  |
| Sales demo equipment | 3,038 |  |  | 3,649 |  |
| Vehicles | 604 |  |  | 604 |  |
| Equipment held for lease1 | 10,628 |  |  | 17,347 |  |
| Construction in progress | 35 |  |  | 477 |  |
|  | 185,517 |  |  | 157,056 |  |
| Less: Accumulated depreciation and amortization | (57,995) |  |  | (33,395) |  |
|  | $ | 127,522 |  |  | $ | 123,661 |  |

[0001805385-26-000012:notes:236]
1 Represents equipment that has not yet been deployed to a customer and, accordingly, is not being depreciated.

[0001805385-26-000012:notes:237]
As of December 31, 2025 and 2024, the net book value of capitalized software was $13.6 million and $11.1 million, respectively. These amounts include $2.8 million and $1.7 million of capitalized stock compensation costs, respectively. Depreciation expense and amortization expense related to property and equipment was $24.3 million and $17.4 million for the years ended December 31, 2025 and 2024, respectively, which included amortization expense of capitalized software of $3.9 million and $1.8 million for the years ended December 31, 2025 and 2024, respectively.

[0001805385-26-000012:notes:238]
Leased equipment and the related accumulated depreciation were as follows:

[0001805385-26-000012:notes:239]
|  | December 31, |
|  | 2025 |  | 2024 |
| Leased equipment | $ | 140,981 |  |  | $ | 112,078 |  |
| Accumulated depreciation | (44,653) |  |  | (25,726) |  |
| Leased equipment, net | $ | 96,328 |  |  | $ | 86,352 |  |

[0001805385-26-000012:notes:240]
Depreciation expense related to leased units was $18.3 million and $13.6 million during the years ended December 31, 2025 and 2024, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.

[0001805385-26-000012:notes:241]
Loss on impairment of property and equipment was $0.2 million during the year ended December 31, 2024. This primarily related to the removal of Evolv Express systems and IT equipment from service, resulting in an impairment of the remaining economic value of such systems. No loss on impairment of property and equipment was recognized for the year ended December 31, 2025. During the year ended December 31, 2024, the Company recorded an impairment charge related to certain of its software development projects that had previously been capitalized. This resulted in an impairment charge of $1.0 million, and was recorded in cost of subscription revenue.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001805385-26-000012:notes:242]
Accrued Expenses and Other Current Liabilities
Accrued expenses and other current liabilities consisted of the following (in thousands):

[0001805385-26-000012:notes:243]
|  | December 31, |
|  | 2025 |  | 2024 |
| Accrued employee compensation and benefits expense | $ | 11,150 |  |  | $ | 5,332 |  |
| Accrued professional services and consulting | 2,690 |  |  | 5,674 |  |
| Accrued sales tax | 751 |  |  | 1,109 |  |
| Accrued legal settlement | 15,000 |  |  | — |  |
| Other | 5,702 |  |  | 7,393 |  |
|  | $ | 35,293 |  |  | $ | 19,508 |  |


## us-gaap:DebtDisclosureTextBlock

[0001805385-26-000012:notes:244]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001805385-26-000012:notes:245]
|  | December 31,2025 |  | December 31,2024 |
| Term loans payable | $ | 30,000 |  |  | $ | — |  |
| Less: Unamortized debt issuance cost | (1,404) |  |  | — |  |
|  | 28,596 |  |  | — |  |
| Less: Current portion of long-term debt | — |  |  | — |  |
| Long-term debt | $ | 28,596 |  |  | $ | — |  |

[0001805385-26-000012:notes:246]
As described in Note 1, on July 29, 2025, the Company entered into the $75.0 million MidCap Credit Agreement, which provided for the Senior Secured Credit Facilities (as defined below), which include a $30.0 million Initial Term Loan, a $30.0 million Delayed Draw Term Loan (available for drawdown during the two-year period following the Closing Date), and a $15.0 million Revolving Credit Facility, each with a maturity date of July 1, 2030. As of December 31, 2025,

[0001805385-26-000012:notes:247]
$30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available.

[0001805385-26-000012:notes:248]
On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs funded at closing. The total debt issuance costs of $3.7 million, which included $0.3 million of additional issuance costs paid by the Company, have been allocated to each component of the facility in accordance with ASC 835. The Senior Secured Credit Facilities are guaranteed by the Company, and in the future, may be guaranteed by certain material subsidiaries. The Senior Secured Credit Facilities are secured by a first lien on substantially all of the assets of the Company.

[0001805385-26-000012:notes:249]
The Senior Secured Credit Facilities bear interest at a fluctuating rate per annum equal to Term Secured Overnight Financing Rate (“Term SOFR”) and an applicable margin calculated based on earnings before interest, taxes, depreciation, and amortization (“EBITDA”). At closing, the applicable margin on Term SOFR loans was 5.25%. If the event described under the MidCap Credit Agreement related to Term SOFR occurs, a base rate is determined by reference to the higher of (1) the prime rate of Wells Fargo and (2) 2.00%. Interest and principal are payable monthly. Monthly interest payments are due in arrears on the first day of each month.

[0001805385-26-000012:notes:250]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that begins at $106.0 million on December 31, 2025 and increases quarterly thereafter; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum EBITDA covenant that takes effect on June 30, 2027. As of December 31, 2025, the Company is in full compliance with all applicable covenant requirements.

[0001805385-26-000012:notes:251]
Initial Term Loan

[0001805385-26-000012:notes:252]
The borrowing under the $30.0 million Initial Term Loan is subject to principal repayments beginning in August 2029, following a 48-month interest-only period, and will be repaid in equal installments over the final 12 months of the loan term.

[0001805385-26-000012:notes:253]
As of December 31, 2025, the unamortized debt issuance costs totaled $1.4 million, and are presented as a direct deduction from the carrying amount of the Initial Term Loan on the consolidated balance sheet and are amortized as interest expense using the effective interest method in accordance with ASC 835. Interest expense related to the Initial Term Loan totaled $1.3 million for the year ended December 31, 2025. The interest rate in effect as of December 31, 2025 was approximately 9.12%, which includes Term SOFR of 3.87% and an applicable margin of 5.25%. Interest expense related to the amortization of debt issuance costs totaled less than $0.1 million for the year ended December 31, 2025.

[0001805385-26-000012:notes:254]
As of December 31, 2025, future principal payments on long-term debt are as follows (in thousands):

[0001805385-26-000012:notes:255]
| December 31, |  |
| 2026 | — |  |
| 2027 | — |  |
| 2028 | — |  |
| 2029 | 12,500 |  |
| Thereafter | 17,500 |  |
|  | $ | 30,000 |  |

[0001805385-26-000012:notes:256]
Delayed Draw Term Loan and Revolving Credit Facility

[0001805385-26-000012:notes:257]
As of December 31, 2025, no amounts had been drawn under the Delayed Draw Term Loan or Revolving Credit Facility. Unused commitments amounted to $30.0 million and $15.0 million under the Delayed Draw Term Loan and Revolving Credit Facility, respectively, as of December 31, 2025. Debt issuance costs allocated to these facilities are paid

[0001805385-26-000012:notes:258]
regardless of whether the funds are drawn down. Such costs are capitalized as prepaid assets and amortized as interest expense on a straight-line basis over their respective access periods, which end on August 1, 2027 and July 1, 2030 for Delayed Draw Term Loan and Revolving Credit Facility, respectively. As of December 31, 2025, the Company recorded $0.7 million in prepaid expenses and other current assets and $1.1 million in other assets in the consolidated balance sheets for costs associated with Delayed Draw Term Loan and Revolving Credit Facility. Capitalized debt issuance cost is amortized as interest expense on a straight-line basis over the period each facility is available to be drawn. Interest expense related to the amortization of debt issuance costs totaled $0.4 million the year ended December 31, 2025.

[0001805385-26-000012:notes:259]
The Revolving Credit Facility provides for an unused commitment fee of 0.25% on the undrawn portion of the facility. Interest expense related to the unused commitment fees totaled less than $0.1 million for the year ended December 31, 2025.


## evlv:WarrantsAndRightsNoteDisclosureTextBlock

[0001805385-26-000012:notes:260]
Warrants
As of December 31, 2025 and 2024, warrants to purchase the following classes of common stock outstanding consisted of the following:

[0001805385-26-000012:notes:261]
| December 31, 2025 |
| Warrant Description |  | Issuance Date |  | ContractualTerm(in years) |  | Underlying EquityInstrument |  | Balance SheetClassification |  | Shares IssuableUpon Exerciseof Warrant |  | WeightedAverageExercise Price |
| Public Warrants (see Note 2) |  | July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,893 |  |  | $ | 11.50 |  |
|  |  |  |  |  |  |  |  |  |  | 14,324,893 |  |  |  |

[0001805385-26-000012:notes:262]
| December 31, 2024 |
| Warrant Description |  | Issuance Date |  | ContractualTerm(in years) |  | Underlying EquityInstrument |  | Balance SheetClassification |  | Shares IssuableUpon Exerciseof Warrant |  | WeightedAverageExercise Price |
| Finback Common Stock Warrants (see Note 15) |  | January 13, 2021 |  | 10 |  | Common stock |  | Equity |  | 117,423 |  |  | $ | 0.42 |  |
| Public Warrants (see Note 2) |  | July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,893 |  |  | $ | 11.50 |  |
|  |  |  |  |  |  |  |  |  |  | 14,442,316 |  |  |  |


## evlv:CommonStockDisclosureTextBlock

[0001805385-26-000012:notes:263]
Common Stock
Each share of common stock entitles the holder to one vote on all matters submitted to a vote of the Company’s stockholders. Common stockholders are entitled to receive dividends, as may be declared by the board of directors, subject to the preferential dividend rights of Preferred Stock. As of December 31, 2025 and 2024, no cash dividends had been declared or paid.
As of December 31, 2025 and 2024, the Company had reserved 70,394,153 and 78,252,044 shares, respectively, of common stock for the exercise of outstanding stock options, vesting of outstanding restricted stock units, vesting of outstanding MSUs, vesting of contingent earn-out shares, vesting of contingently issuable common stock, granting of awards under the Company’s 2021 Equity Incentive Plan (see Note 15), and the exercise of outstanding warrants (see Note 13). In addition, as of December 31, 2025 and 2024, the Company had 9,424,370 and 7,828,349 shares, respectively, of common stock available to be issued under the 2021 Employee Stock Purchase Plan (see Note 15).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001805385-26-000012:notes:264]
Stock-Based Compensation
2021 Equity Incentive Plan

[0001805385-26-000012:notes:265]
The Company’s 2021 Equity Incentive Plan (the “2021 Plan”) provides for the Company to grant incentive stock options or nonqualified stock options, restricted stock awards, restricted stock units, performance stock units, and other stock-based awards to employees, officers, directors, and non-employees of the Company. A total of 21,177,295 shares of common stock were initially authorized under the 2021 Plan, subject to annual evergreen increases of up to 5% of total common shares outstanding as of the end of the prior year. As of December 31, 2025, 19,387,020 shares were available for future grant under the 2021 Plan. Shares, units, and options that are expired, forfeited, canceled, or otherwise terminated without having been fully exercised will be available for future grant under the 2021 Plan. In addition, shares of common stock that are tendered to the Company by a participant to exercise an award are added to the number of shares of common stock available for future grants.

[0001805385-26-000012:notes:266]
The 2021 Plan is administered by the Board of Directors or, at the discretion of the Board of Directors, by a committee of the Board of Directors. The exercise prices, vesting, and other restrictions are determined at the discretion of the Board of Directors, or its committee if so delegated, except that the exercise price per share of stock options may not be less than 100% of the fair market value of a share of common stock on the date of grant and the term of the stock option may not be greater than ten years. Stock options granted to employees, officers, members of the Board of Directors and non-employees vesting terms are determined on an individual basis on the date of grant. Prior to the closing of the Merger, the Company’s Board of Directors valued the Company’s common stock, taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors which may have changed since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the fair value of each share of common stock underlying stock-based awards is based on the closing price of our common stock as reported by Nasdaq on the date of grant.

[0001805385-26-000012:notes:267]
Stock Options

[0001805385-26-000012:notes:268]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the year ended December 31, 2024. No option grants were issued during the year ended December 31, 2025.

[0001805385-26-000012:notes:269]
|  |  |  | Year Ended December 31, |
|  |  |  | 2024 |
| Risk-free interest rate |  |  | 4.1 | % |
| Expected term (in years) |  |  | 6.1 |
| Expected volatility |  |  | 90.0 | % |
| Expected dividend yield |  |  | 0.0 | % |

[0001805385-26-000012:notes:270]
The following tables summarize the Company’s stock option activity under the 2021 Equity Incentive Plan (in thousands, except for share and per share data):

[0001805385-26-000012:notes:271]
|  | Number ofShares |  | WeightedAverageExercise Price |  | WeightedAverageRemainingContractual Term (in years) |  | AggregateIntrinsic Value |
| Outstanding as of December 31, 2024 | 18,125,937 |  | $ | 1.18 |  |  |  |  |  |
| Granted | — |  | — |  |  |  |  |  |
| Exercised | (9,395,646) |  | 0.98 |  |  |  |  |  |
| Forfeited | (525,981) |  | 3.61 |  |  |  |  |  |
| Expired | (20,306) |  | 3.63 |  |  |  |  |  |
| Outstanding as of December 31, 2025 | 8,184,004 |  | $ | 1.25 |  |  | 4.4 |  | $ | 48,364 |  |
| Vested and expected to vest as of December 31, 2025 | 8,184,004 |  | $ | 1.25 |  |  | 4.4 |  | $ | 48,364 |  |
| Options exercisable as of December 31, 2025 | 7,397,552 |  | $ | 1.02 |  |  | 4.1 |  | $ | 45,433 |  |

[0001805385-26-000012:notes:272]
The aggregate intrinsic value of options is calculated as the difference between the exercise price of the stock options and the fair value of the Company’s common stock for those options that had exercise prices lower than the fair value of the Company’s common stock.

[0001805385-26-000012:notes:273]
The weighted average grant date fair value of stock options granted was $2.77 during the year ended December 31, 2024. The aggregate intrinsic value of the stock options exercised was $48.0 million and $7.3 million during the years ended December 31, 2025 and 2024, respectively.

[0001805385-26-000012:notes:274]
Restricted Stock Units

[0001805385-26-000012:notes:275]
The following table summarizes the Company’s restricted stock units activity under its existing restricted stock unit plan:

[0001805385-26-000012:notes:276]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2024 | 12,115,657 |  | $ | 3.50 |  |
| Granted | 8,272,397 |  | 3.95 |  |
| Vested | (5,593,282) |  | 3.33 |  |
| Forfeited | (4,134,609) |  | 3.71 |  |
| Nonvested as of December 31, 2025 | 10,660,163 |  | $ | 3.85 |  |

[0001805385-26-000012:notes:277]
During the years ended December 31, 2025 and 2024, the aggregate grant-date fair value of restricted stock units issued under the 2021 Plan was $32.6 million and $31.8 million, respectively. RSUs generally vest ratably over a three year period subject to the grantee's continued service through the applicable vesting date. During the year ended December 31, 2025 and 2024, the total fair value of shares vested was $18.6 million and $19.3 million, respectively.

[0001805385-26-000012:notes:278]
Market-based Stock Units

[0001805385-26-000012:notes:279]
During the year ended December 31, 2025, the Company granted market-based stock units ("MSUs") for which the vesting conditions consist of market-based vesting conditions, determined by the Company's level of achievement of pre-established parameters relating to the performance of the Company's stock price as set by the Board as well as service-

[0001805385-26-000012:notes:280]
based vesting conditions. Vesting may range from 0% to 200% of the target MSUs granted, based on the achievement of specified market conditions. The awards will be measured at each anniversary of the grant date and will vest following the completion of a performance period, which is generally three years unless shortened in the event of a change in control.

[0001805385-26-000012:notes:281]
Compensation expense for MSUs is based on the estimated value of the awards on the grant date, and is recognized over the period from the grant date through the expected vest date, regardless of level of achievement of the market conditions. The fair value of the awards were estimated based on a Monte Carlo simulation model applying the following key assumptions, on a weighted average basis:

[0001805385-26-000012:notes:282]
|  | Year Ended December 31, |
|  | 2025 |  |  |
| Risk-free interest rate | 3.9% |  |  |
| Expected term (in years) | 3.0 |  |  |
| Expected volatility | 90.5% |  |  |
| Expected dividend yield | 0.0% |  |  |

[0001805385-26-000012:notes:283]
The following table summarizes the Company's market-based stock units activity since December 31, 2024:

[0001805385-26-000012:notes:284]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2024 | — |  |  | $ | — |  |
| Granted | 1,755,370 |  |  | 5.14 |  |
| Vested | — |  |  | — |  |
| Forfeited | (85,227) |  |  | 4.40 |  |
| Nonvested as of December 31, 2025 | 1,670,143 |  |  | $ | 5.17 |  |

[0001805385-26-000012:notes:285]
2021 Employee Stock Purchase Plan

[0001805385-26-000012:notes:286]
In July 2021, the Company’s Board of Directors adopted the 2021 Employee Stock Purchase Plan (“2021 ESPP”), which was subsequently approved by the Company’s stockholders and became effective on July 16, 2021. The 2021 ESPP authorizes the initial issuance of up to 3,435,748 shares of the Company’s common stock to eligible employees of the Company or, as designated by the Company’s Board of Directors, employees of a related company. The 2021 ESPP provides that the number of shares reserved and available for issuance under the 2021 ESPP will automatically increase each January 1, beginning on January 1, 2022 and ending on (and including) January 1, 2032, by an amount equal to the lesser of (i) 1% of the outstanding number of shares of common stock on the immediately preceding December 31 and (ii) such smaller number of shares as determined by the Company’s Board of Directors. As of December 31, 2025, 9,424,370 shares of the Company’s common stock were available for future issuance. The Company’s Board of Directors may from time to time grant or provide for the grant to eligible employees of options to purchase common stock under the 2021 ESPP during a specific offering period. As of December 31, 2025, no offerings have been approved.

[0001805385-26-000012:notes:287]
Finback Common Stock Warrants

[0001805385-26-000012:notes:288]
In January 2021, the Company granted equity classified warrants (the "Finback Common Stock Warrants") to purchase 2,552,913 shares of the Company's Class A common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC ("Finback"), a consulting group affiliated with one of the Company's stockholders. The Finback Common Stock Warrants vested upon meeting certain sales criteria as defined in a business development agreement (the "Finback BDA"), which has a term of 3 years and an expiration date of January 2031. The Finback BDA expired on January 1, 2023, subject to a 1-year "tail period" expiring on January 1, 2024. During the tail period, the Finback Common Stock Warrants continued to vest related to any sale consummated by the Company for which it was determined Finback provided services prior to January 1, 2023 in furtherance of the sale. The Finback Common Stock Warrants are accounted

[0001805385-26-000012:notes:289]
for under ASC 718 Compensation – Stock Compensation as the warrants vested upon certain performance conditions being met. The Company utilized a Black-Scholes pricing model to determine the grant-date fair value of the Finback Common Stock Warrants.

[0001805385-26-000012:notes:290]
As of December 31, 2025, all 1,221,296 of the Finback Common Stock Warrants were exercised. Consequently, there were no remaining Finback Common Stock Warrants that were exercisable or unvested, given the expiration of the 1-year tail period on January 1, 2024. The Company recognized compensation expense for the Finback Common Stock Warrants when the warrants vested based on meeting the specified sales criteria. During the years ended December 31, 2025 and 2024, there was no stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants.

[0001805385-26-000012:notes:291]
Stock-based compensation expense was classified in the consolidated statements of operations and comprehensive loss as follows (in thousands):

[0001805385-26-000012:notes:292]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  |  |
| Cost of revenue | $ | 1,044 |  | $ | 788 |  |  |
| Research and development | 4,748 |  | 4,520 |  |  |
| Sales and marketing | 5,568 |  | 10,946 |  |  |
| General and administrative | 9,211 |  | 8,502 |  |  |
| Restructuring costs | 525 |  | — |  |  |
| Total stock-based compensation expense | $ | 21,096 |  | $ | 24,756 |  |  |

[0001805385-26-000012:notes:293]
Stock-based compensation expense by award type recognized in the consolidated statements of operations and comprehensive loss was as follows (in thousands):

[0001805385-26-000012:notes:294]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  |  |
| Stock options | $ | 1,566 |  | $ | 3,767 |  |  |
| Earn-out shares | 64 |  | 11 |  |  |
| RSUs | 16,972 |  | 20,978 |  |  |
| MSUs | 2,494 |  | — |  |  |
| Total stock-based compensation expense | $ | 21,096 |  | $ | 24,756 |  |  |

[0001805385-26-000012:notes:295]
Total unrecognized compensation expense related to stock options and restricted stock units as of December 31, 2025, was $35.7 million, which is expected to be recognized over a weighted average period of 2.7 years. Total unrecognized compensation expense related to earn-out shares associated with the share-based compensation arrangement as of December 31, 2025, was less than $0.1 million, which is expected to be recognized over a weighted average period of 14 days.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001805385-26-000012:notes:296]
Income Taxes
The components of the Company’s loss before income tax expense are as follows (in thousands):

[0001805385-26-000012:notes:297]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  |  |
| United States | $ | (33,192) |  |  | $ | (54,046) |  |  |  |
| Foreign | 116 |  |  | 29 |  |  |  |
| Loss before income tax provision | $ | (33,076) |  |  | $ | (54,017) |  |  |  |

[0001805385-26-000012:notes:298]
Income tax expense is comprised of the following (in thousands):

[0001805385-26-000012:notes:299]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  |  |
| Current: |  |  |  |  |  |
| Federal | $ | — |  | $ | — |  |  |
| State | 34 |  | — |  |  |
| Foreign | 28 |  | — |  |  |
| Total current income tax expense | $ | 62 |  | $ | — |  |  |
| Deferred: |  |  |  |  |  |
| Federal | $ | — |  | $ | — |  |  |
| State | — |  | — |  |  |
| Foreign | — |  | — |  |  |
| Total deferred income tax expense | $ | — |  | $ | — |  |  |
| Total income tax expense | $ | 62 |  | $ | — |  |  |

[0001805385-26-000012:notes:300]
The effective tax rate differs from the U.S. federal statutory rate primarily due to the full valuation allowance maintained on the Company’s net deferred tax assets and non-deductible fair value adjustments for the years ended December 31, 2025 and 2024. For the year ended December 31, 2025, the Company adopted ASU 2023-09 on a prospective basis. The following table is a reconciliation of the U.S. federal statutory rate of 21.0 % to the effective tax rate for the year ended December 31, 2025, in accordance with ASU 2023-09:

[0001805385-26-000012:notes:301]
|  | Year Ended December 31, 2025 |
|  | Amount(in thousands) |  | Percent |  |  |  |  |
| Federal statutory income tax rate | $ | (6,946) |  | 21.0 % |  |  |  |  |
| State and local income tax, net of federal income tax effect | — |  | — |  |  |  |  |  |
| Change in valuation allowance | 10,125 |  | (30.6) |  |  |  |  |  |
| Nontaxable or nondeductible items: |  |  |  |  |  |  |  |
| Change in fair value of contingent earn-out liability, public warrants, and contingently issuable common stock liability | (3,252) |  | 9.8 |  |  |  |  |  |
| Stock-based compensation | (6,934) |  | 20.9 |  |  |  |  |  |
| Non-deductible compensation | 6,976 |  | (21.0) |  |  |  |  |  |
| Permanent differences | 83 |  | (0.3) |  |  |  |  |  |
| Other | 10 |  | 0.2 |  |  |  |  |  |
| Effective income tax rate | $ | 62 |  |  | 0.0 | % |  |  |  |  |

[0001805385-26-000012:notes:302]
The following table is a reconciliation of the US federal statutory rate of 21.0 % to the effective tax rate prior to the adoption of ASU 2023-09:

[0001805385-26-000012:notes:303]
|  | Year Ended December 31, 2024 |
| Federal statutory income tax rate | 21.0 % |  |  |
| State income taxes, net of federal benefit | 7.7 |  |  |  |
| Federal and state research and development tax credits | (0.1) |  |  |  |
| Change in fair value of contingent earn-out liability and contingently issuable common stock liability | 9.9 |  |  |  |
| Change in valuation allowance | (42.9) |  |  |  |
| Change in uncertain tax positions | (0.1) |  |  |  |
| Change in tax rate | 3.3 |  |  |  |
| Stock-based compensation | 1.1 |  |  |  |
| Non-deductible compensation | 0.5 |  |  |  |
| Permanent differences | (0.2) |  |  |  |
| Other | (0.2) |  |  |  |
| Effective income tax rate | 0.0 | % |  |  |

[0001805385-26-000012:notes:304]
Net deferred tax assets consisted of the following (in thousands):

[0001805385-26-000012:notes:305]
|  | December 31, |
|  | 2025 |  | 2024 |  |  |
| Deferred tax assets: |  |  |  |  |  |
| Net operating loss carryforwards | $ | 69,652 |  | $ | 57,450 |  |  |
| Research and development tax credit carryforwards | 3,530 |  | 3,594 |  |  |
| Capitalized research and development costs | 14,252 |  | 15,868 |  |  |
| Accrued expenses | 12,021 |  | 9,991 |  |  |
| Deferred revenue | 24,154 |  | 22,531 |  |  |
| Lease liability | 3,596 |  | 3,848 |  |  |
| Other | 4,729 |  | 2,960 |  |  |
| Total deferred tax assets | 131,934 |  | 116,242 |  |  |
| Valuation allowance | (119,329) |  |  | (106,268) |  |  |  |
| Total deferred tax assets, net of valuation allowance | 12,605 |  | 9,974 |  |  |
| Deferred tax liabilities: |  |  |  |  |  |
| Depreciation and amortization | (9,345) |  |  | (6,250) |  |  |  |
| Right of use lease asset | (3,243) |  | (3,706) |  |  |
| Other | (17) |  | (18) |  |  |
| Total deferred tax liabilities | (12,605) |  | (9,974) |  |  |
| Net deferred tax assets | $ | — |  | $ | — |  |  |

[0001805385-26-000012:notes:306]
As of December 31, 2025, the Company had federal net operating loss carryforwards of $20.1 million, which begin to expire in 2033. These losses were generated before 2018 and are subject to a 20-year carryforward period under the tax rules in effect at that time. The Company also had federal net operating loss carryforwards of $248.0 million and $203.3 million as of December 31, 2025 and 2024, respectively, which do not expire but are generally limited to offsetting up to 80% of taxable income in any given year. These amounts were generated after 2017 and are subject to the provisions of the Tax Cuts and Jobs Act, which eliminated the expiration period but imposed a limitation on usage.

[0001805385-26-000012:notes:307]
The Company had state net operating loss carryforwards of $248.0 million and $201.1 million as of December 31, 2025 and 2024, respectively, which may be available to offset future state taxable income and which begin to expire in 2033, depending on jurisdiction-specific rules. Additionally, as of December 31, 2025 and 2024, the Company had United Kingdom net operating loss carryforwards of approximately $1.4 million and $1.7 million, respectively, which do not expire under current UK tax law.

[0001805385-26-000012:notes:308]
As of December 31, 2025, the Company had gross U.S. federal and state research and development and other tax credit carryforwards of $2.4 million and $1.4 million, respectively, which may be available to offset future tax liabilities and the majority of which begin to expire in 2035 and 2032, respectively. As of December 31, 2024, the Company had gross U.S. federal and state research and development and other tax credit carryforwards of $2.4 million and $1.5 million, respectively, which may be available to offset future tax liabilities and the majority of which begin to expire in 2033 and 2030, respectively.

[0001805385-26-000012:notes:309]
Utilization of the U.S. federal and state net operating loss carryforwards and research and development tax credit carryforwards may be subject to a substantial annual limitation under Sections 382 and 383 of the Internal Revenue Code of 1986, and corresponding provisions of state law, due to ownership changes that have occurred previously or that could occur in the future. These ownership changes may limit the amount of carryforwards that can be utilized annually to offset future taxable income or tax liabilities. In general, an ownership change, as defined by Section 382, results from transactions increasing the ownership of certain stockholders or public groups in the stock of a corporation by more than 50% over a three-year period. If the Company has experienced a change of control, as defined by Section 382, at any time since inception, utilization of the net operating loss carryforwards or research and development tax credit carryforwards would be subject to an annual limitation under Section 382, which is determined by first multiplying the value of the

[0001805385-26-000012:notes:310]
Company’s stock at the time of the ownership change by the applicable long-term tax-exempt rate, and then could be subject to additional adjustments. Any limitation may result in the expiration of a portion of the net operating loss carryforwards or research and development tax credit carryforwards before utilization.

[0001805385-26-000012:notes:311]
The Company believes that an ownership change within the meaning of Section 382 occurred on July 16, 2021, in connection with Merger. Based on the estimated annual limitation, the Company would have been able to fully utilize all of its Section 382-limited net operating losses and tax credit carryforwards in the 2022 tax year. The Company has not performed an analysis of ownership changes since the Merger, and does not anticipate utilization of net operating losses or credit carryforwards in the near term.

[0001805385-26-000012:notes:312]
The Company considered the evidence of its history of cumulative net operating losses incurred since inception, as well as other positive and negative evidence bearing upon its ability to realize deferred tax assets in respect of our net operating loss carryforwards, and has concluded that it is more likely than not that the Company will not realize the benefits of the deferred tax assets. Accordingly, a full valuation allowance has been established against the net deferred tax assets as of December 31, 2025 and 2024. If or when recognized, the tax benefits related to any reversal of the valuation allowance on deferred tax assets as of December 31, 2025, will be accounted for as follows: approximately $117.1 million will be recognized as a reduction of income tax expense and $2.2 million will be recorded as an increase in equity. The Company reevaluates the positive and negative evidence at each reporting period.

[0001805385-26-000012:notes:313]
Changes in the valuation allowance for deferred tax assets related primarily to the increase in net operating loss carryforwards and capitalized R&D costs and were as follows (in thousands):

[0001805385-26-000012:notes:314]
|  | December 31, |
|  | 2025 |  | 2024 |  |  |
| Valuation allowance as of beginning of year | $ | 106,268 |  | $ | 83,113 |  |  |
| Additions charged to provision for income taxes | 13,061 |  | 23,155 |  |  |
| Valuation allowance as of end of year | $ | 119,329 |  | $ | 106,268 |  |  |

[0001805385-26-000012:notes:315]
The Company accounts for income tax uncertainties in accordance with ASC 740 Income Taxes, which prescribes a recognition threshold and measurement criteria for the financial statement recognition and measurement of a tax position taken or expected to be taken in a tax return. Benefits from tax positions should be recognized in the financial statements only when it is more likely than not that the tax position will be sustained upon examination by the appropriate taxing authority that would have full knowledge of all relevant information. A tax position that meets the more likely than not recognition threshold is measured at the largest amount of benefit that is greater than fifty percent likely of being realized upon ultimate settlement. Tax positions that previously failed to meet the more likely than not recognition threshold should be recognized in the first subsequent financial reporting period in which that threshold is met. Previously recognized tax positions that no longer meet the more likely than not recognition threshold should be derecognized in the first subsequent financial reporting period in which that threshold is no longer met. ASC 740 also provides guidance on the accounting for and disclosure of liabilities for uncertain tax positions, interest and penalties. The Company’s policy is to record interest and penalties related to income taxes as part of its income tax provision.

[0001805385-26-000012:notes:316]
The following table summarizes the activity related to the Company’s uncertain tax positions (excluding interest and penalties and related tax attributes) (in thousands):

[0001805385-26-000012:notes:317]
|  | December 31, |
|  | 2025 |  | 2024 |  |  |
| Balance at beginning of fiscal year | $ | 447 |  | $ | 428 |  |  |
| Gross increases related to prior year tax positions | 18 |  | 20 |  |  |
| Foreign exchange and others | (76) |  | (1) |  |  |
| Balance at end of fiscal year | $ | 389 |  | $ | 447 |  |  |

[0001805385-26-000012:notes:318]
The Company’s liability for uncertain tax positions as of December 31, 2025 and 2024 includes $0.4 million related to amounts that, if recognized, would affect the effective tax rate (excluding related interest and penalties).

[0001805385-26-000012:notes:319]
The Company files income tax returns as prescribed by the tax laws of the jurisdictions in which it operates. In the normal course of business, the Company is subject to examination by federal, state and non-US jurisdictions, where applicable. The Company is open to future tax examinations in the US under statute from 2022 to the present; however, carryforward attributes that were generated prior to 2022 may still be adjusted upon examination by federal, state, or local tax authorities if they either have been or will be used in a future period.  The Company is also subject to future tax examinations under UK statute for the period from 2022 to the present, with a standard look-back period of 4 years, extendable to 6 years in cases of carelessness. The Company has not received notice of examination in any jurisdictions for any tax year open under statute.


## us-gaap:EarningsPerShareTextBlock

[0001805385-26-000012:notes:320]
Net Loss per Share
Basic and diluted net loss per share attributable to common stockholders was calculated as follows (in thousands, except share and per share amounts):

[0001805385-26-000012:notes:321]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  |  |
| Numerator: |  |  |  |  |  |
| Net loss attributable to common stockholders – basic and diluted | $ | (33,138) |  |  | $ | (54,017) |  |  |  |
| Denominator: |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 168,419,211 |  | 156,573,886 |  |  |
| Net loss per share attributable to common stockholders – basic and diluted | $ | (0.20) |  |  | $ | (0.34) |  |  |  |

[0001805385-26-000012:notes:322]
The following potentially dilutive outstanding securities were excluded from the computation of diluted net loss per share attributable to common stockholders because their effect would have been anti-dilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the period:

[0001805385-26-000012:notes:323]
|  | Year Ended December 31, |
|  | 2025 |  | 2024 |  |  |
| Options issued and outstanding | 8,184,004 |  |  | 18,125,937 |  |  |  |
| Public Warrants to purchase common stock | 14,324,893 |  |  | 14,324,893 |  |  |  |
| Warrants to purchase common stock (Finback) | — |  |  | 117,423 |  |  |  |
| Unvested restricted stock units | 10,660,163 |  |  | 12,115,657 |  |  |  |
| Unvested market-based stock units* | 1,670,143 |  |  | — |  |  |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |  |  |
| Contingently issuable common stock* | 1,167,930 |  |  | 1,897,500 |  |  |  |
|  | 51,007,133 |  |  | 61,581,410 |  |  |  |

[0001805385-26-000012:notes:324]
*Issuance of Market-based stock units, Earn-out shares, and Contingently issuable common stock is contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001805385-26-000012:notes:325]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola Solutions, Inc.

[0001805385-26-000012:notes:326]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. While the partnership agreement is still in effect, effective in the fourth quarter of 2024, Motorola is no longer considered a related party. During the years ended December 31, 2024, revenue from Motorola’s distributor services was $6.1 million.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001805385-26-000012:notes:327]
Commitments and Contingencies
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. Below is a summary of the various types of matters subject to this guidance.

[0001805385-26-000012:notes:328]
Indemnification Agreements

[0001805385-26-000012:notes:329]
In the ordinary course of business, the Company provides indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. Based on historical experience and evaluation of the agreements, we do not believe that any payments related to our indemnities will have a material impact on our financial condition or results of operations.

[0001805385-26-000012:notes:330]
Legal Proceedings

[0001805385-26-000012:notes:331]
We are from time to time subject to various claims, lawsuits, government and regulatory examinations, inquiries, information requests and investigations, and other legal and administrative proceedings arising in the ordinary course of business. The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

[0001805385-26-000012:notes:332]
General Litigation

[0001805385-26-000012:notes:333]
Class Action Lawsuits

[0001805385-26-000012:notes:334]
On March 25, 2024 and November 1, 2024, putative class action lawsuits were filed against the Company in the United States District Court for the District of Massachusetts. On December 13, 2024, the Court consolidated the two lawsuits into one action (the “Class Action”), pursuant to which a consolidated amended complaint was filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees. The

[0001805385-26-000012:notes:335]
Company filed its motion to dismiss the Class Action on March 28, 2025, and the Class Action Plaintiffs filed their opposition to the motion to dismiss on June 24, 2025. On June 30, 2025, the Court issued an order staying the Class Action, including disposition on the motion to dismiss, pending settlement negotiations. On August 5, 2025, the parties to the Class Action engaged in mediation and reached a settlement in principle in the amount of $15.0 million, which is subject to negotiation of definitive documentation and court approval, of which the Company estimated that $14.0 million would be funded by the Company's Directors and Officers insurance coverage. On August 19, 2025, after receiving notice of the anticipated settlement agreement, the Court denied the motion to dismiss with leave to renew if warranted. On December 15, 2025, the Court issued an order continuing the stay and ordering Class Action Plaintiffs to file a motion for preliminary approval of the settlement by March 16, 2026.

[0001805385-26-000012:notes:336]
As of December 31, 2025, the Company has recognized a settlement accrual of $15.0 million and an estimated insurance recovery of $14.0 million, which are included in accrued expenses and other current liabilities and prepaid and other current assets in the consolidated balance sheets, respectively, representing management's best estimate of the outcome. For the year ended December 31, 2025, the Company recognized $1.0 million for the estimated net loss in general and administrative expense in the consolidated statements of operations and comprehensive loss.

[0001805385-26-000012:notes:337]
Derivative Lawsuits

[0001805385-26-000012:notes:338]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.

[0001805385-26-000012:notes:339]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “First Delaware Derivative Action”). The First Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. The First Delaware Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.

[0001805385-26-000012:notes:340]
On October 2, 2025, another shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Second Delaware Derivative Action”). The Second Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers and directors, NHIC directors and officers, and nominally against the Company. Plaintiff Robert Patrick, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duties, unjust enrichment, abuse of control, gross mismanagement, and waste of corporate assets, seeking various forms of relief, including equitable relief directing reform of corporate governance and internal controls, monetary damages including restitution and other fees, and a declaration that the individual defendants breached or aided and abetted breaches of fiduciary duties. On November 7, 2025, the Delaware Court of Chancery entered an order staying the Second Delaware Derivative Action pending the outcome of renewed motions to dismiss or final disposition of the Class Action.

[0001805385-26-000012:notes:341]
The Company expects to incur legal and professional services expenses associated with this litigation in future periods. The Company will recognize these expenses as services are received. We cannot reasonably estimate a range of possible losses at this time for the derivative lawsuits, as the proceedings remain in the early stages, alleged damages have not been specified, and the derivative actions are stayed. For these reasons, the Company has not recorded a loss contingency liability for the derivative lawsuits as of December 31, 2025.

[0001805385-26-000012:notes:342]
Regulatory and Governmental Matters

[0001805385-26-000012:notes:343]
As previously disclosed, on October 12, 2023, the Company announced that the U.S. Federal Trade Commission (the “FTC”) had requested information about certain aspects of its marketing practices. The Company reached a settlement with the FTC and on December 5, 2024, a Stipulated Order for Permanent Injunction and Other Relief (the “Order”) was entered in the United States District Court for the District of Massachusetts Eastern Division. The Order (i) required that the Company permit a limited cohort of school customers to cancel their contracts, (ii) required that the Company take certain compliance actions and meet record keeping obligations, and (iii) enjoined the Company from making misleading or unsubstantiated marketing claims. The Order did not include any monetary relief. The period during which eligible customers may cancel closed on March 30, 2025. Any inability to adequately comply with the terms of the Order could result in enforcement actions or penalties imposed by the FTC.

[0001805385-26-000012:notes:344]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, 5 customers representing 24 Evolv Express systems elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled were required to be returned to the customer, but these amounts were immaterial for the year ended December 31, 2024 and therefore the Company did not book a liability in its consolidated financial statements. Revenue continued to be recognized on these deals through the cancellation dates of each contract, all of which were in June 2025, and all systems have been removed from our subscription base as of December 31, 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of the effective date of the Order were impacted by the cancellations, which has been excluded from the remaining performance obligations disclosed in Note 5, Revenue Recognition.

[0001805385-26-000012:notes:345]
In February 2024, the Company received a subpoena from the Division of Enforcement of the Securities and Exchange Commission (the “SEC”), requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("DOJ") relating to a previously disclosed investigation and related restatement of prior period financial statements, and has since received additional requests for documents and information relating to this matter. By letter dated August 7, 2025, the DOJ informed the Company that the Company is no longer the subject of a DOJ investigation.

[0001805385-26-000012:notes:346]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of such matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.

[0001805385-26-000012:notes:347]
Any resolution or litigation with the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to the SEC matter. In addition to the expected insurance recovery discussed above related to the Class Action litigation, the Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matters, including certain expenses that have previously been paid, are also expected to be reimbursed. As of December 31, 2025, the Company recognized an estimated loss recovery related to insurance coverage for these matters of $10.1 million for the year ended December 31, 2025, which was recorded as a reduction of general and administrative expense in the consolidated statements of operations and comprehensive loss. As of December 31, 2025, $8.7 million of these recoveries have been paid out by the Company's insurance provider. The $1.3 million remaining estimated recovery is included in prepaid and other current assets in the consolidated balance sheets as of December 31, 2025. This amount reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company has determined are probable of recovery. $1.1 million of recoveries were paid out in the first quarter of 2026. As it relates 
to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001805385-26-000012:notes:348]
Benefit Plans
The Company established a defined contribution savings plan under Section 401(k) of the Code. This plan covers all employees who meet minimum age and service requirements and allows participants to defer a portion of their annual compensation on a pre-tax basis. The Company made $0.8 million matching contributions to the plan during each of the years ended December 31, 2025 and December 31, 2024.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001805385-26-000012:notes:349]
Segment Information
The Company determined that it has one operating and reporting segment after considering the Company’s organizational structure and the information regularly reviewed and evaluated by the Company’s CODM in deciding how to allocate resources and assess performance. The Company has determined that its CODM is its President and Chief Executive Officer. The CODM evaluates the performance of our segment based upon consolidated net income and considers budget-to-actual or forecast-to-actual variances to assess performance and make decisions about allocating resources. The CODM evaluates segment assets based on total assets on the consolidated balance sheets. Asset information is not presented here because its presentation here would be duplicative of the consolidated balance sheets. On the basis of these factors, the Company determined that it operates and manages its business as one operating and reporting segment, that develops, manufactures, markets and sells security screening products and specific services, and accordingly has one reportable segment for financial reporting purposes.

[0001805385-26-000012:notes:350]
Information by reportable segment is as follows (in thousands):

[0001805385-26-000012:notes:351]
|  | Twelve Months EndedDecember 31, |
|  | 2025 |  | 2024 |  |  |
| Segment revenue | $ | 145,905 |  |  | $ | 103,865 |  |  |  |
| Less: |  |  |  |  |  |
| Employee expense | 67,735 |  |  | 66,847 |  |  |  |
| Travel and expense | 4,318 |  |  | 6,043 |  |  |  |
| Capitalized R&D expense | (5,217) |  |  | (6,027) |  |  |  |
| Stock-based compensation expense1 | 20,571 |  |  | 24,756 |  |  |  |
| Other non-recurring expenses2 | 8,119 |  |  | 17,212 |  |  |  |
| Consulting and contract staffing | 11,841 |  |  | 12,732 |  |  |  |
| Software subscriptions | 6,365 |  |  | 6,814 |  |  |  |
| Depreciation and amortization | 24,340 |  |  | 17,375 |  |  |  |
| Restructuring costs | 2,662 |  |  | 860 |  |  |  |
| Loss on disposal of property and equipment | 3,787 |  |  | — |  |  |  |
| Other cost of revenue | 32,974 |  |  | 18,320 |  |  |  |
| Other operating expenses | 16,873 |  |  | 21,240 |  |  |  |
| Other segment items3 | (15,325) |  |  | (28,290) |  |  |  |
| Segment net (loss) income | $ | (33,138) |  |  | $ | (54,017) |  |  |  |

[0001805385-26-000012:notes:352]
1 Excludes incremental expense related to modified awards included in the Restructuring costs line. See Note 22, Restructuring Charges for additional information.

[0001805385-26-000012:notes:353]
2 For the year ended December 31, 2025, includes consulting and legal fees and additional audit fees incurred in connection with a previously disclosed investigation and restatement of prior period financial statements, net of estimated insurance recoveries, as well as estimated net losses related to ongoing legal matters. For the year ended December 31, 2024, includes each of the costs described above, as well as costs associated with adverse non-cancellable inventory purchase commitments, inventory reserve associated with the transition of our manufacturing operations to the next generation of Evolv Express systems and the determination that certain components within our legacy systems will not be used in the next generation systems, and severance expense.

[0001805385-26-000012:notes:354]
3 Refer to Total other income (expense), net and provision for income taxes in the consolidated statements of operations and comprehensive loss.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001805385-26-000012:notes:355]
Restructuring Charges
In January 2025, the Company implemented a Board-approved reduction in force affecting 41 members of its workforce. This action is part of the Company’s initiative to increase its profitability and cash flow as the Company seeks further flexibility to pursue its investment strategy with certain growth opportunities.

[0001805385-26-000012:notes:356]
The Company incurred charges of $2.7 million for the reduction in force during the three months ended March 31, 2025. These charges consisted of termination charges arising from severance obligations of approximately $2.0 million, extended eligibility for the vesting of certain equity awards originally scheduled to vest on or before March 1, 2025, resulting in incremental non-cash expense of $0.5 million, and other customary employee benefit payments in connection with a reduction in force of $0.2 million. All of these restructuring costs are reported within restructuring costs in our consolidated statements of operations and comprehensive loss.

[0001805385-26-000012:notes:357]
All actions related to the reduction in force were completed by March 31, 2025, with the exception of certain severance obligations that are payable over various periods through November 2025 under the Company's Severance And Change In Control Plan.

[0001805385-26-000012:notes:358]
To align the presentation of restructuring charges, the Company reclassified the comparative financial statements for the year ended December 31, 2024. For the year ended December 31, 2024, the reclassifications resulted in an increase in restructuring costs of $0.9 million, and a corresponding decrease in cost of service revenue, sales and marketing expenses, and general and administrative expenses of $0.2 million, $0.7 million, and less than $0.1 million, respectively. The prior year activity was limited in scope, and the reclassifications did not impact total loss from operations or total net income (loss). All actions related to the prior year reduction in force were completed by December 31, 2024.

[0001805385-26-000012:notes:359]
The following table summarizes the liabilities recognized in relation to the cash obligations from reduction in force, which are included in accrued expenses and other current liabilities in our consolidated balance sheets (in thousands):

[0001805385-26-000012:notes:360]
| Balance at December 31, 2023 | $ | — |  |
| Charges incurred | 860 |  |
| Cash payments | (860) |  |
| Balance at December 31, 2024 | — |  |
| Charges incurred | 2,137 |  |
| Cash payments | (2,137) |  |
| Balance at December 31, 2025 | $ | — |  |
