# EVLV note change history — 0001805385-25-000017 → 0001805385-26-000028


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-12):
[0001805385-26-000028:note_history:1]
Commitments and Contingencies
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. Below is a summary of the various types of matters subject to this guidance.
  (was, 2025-11-13, similarity 0.6381):
[0001805385-25-000017:note_history:1]
Commitments and Contingencies
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for

- changed (2026-05-12):
[0001805385-26-000028:note_history:2]
On March 25, 2024 and November 1, 2024, putative class action lawsuits were filed against the Company in the United States District Court for the District of Massachusetts. On December 13, 2024, the Court consolidated the two lawsuits into one action (the “Class Action”), pursuant to which a consolidated amended complaint was filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees. The Company filed its motion to dismiss the Class Action on March 28, 2025, and the Class Action Plaintiffs filed their opposition to the motion to dismiss on June 24, 2025. On June 30, 2025, the Court issued an order staying the Class Action, including disposition on the motion to dismiss, pending settlement negotiations. On August 5, 2025, the parties to the Class Action engaged in mediation and reached a settlement in principle in the amount of $15.0 million, which is subject to negotiation of definitive documentation and court approval, of which the Company estimated that $14.0 million would be funded by the Company's Directors and Officers insurance coverage. On August 19, 2025, after receiving notice of the anticipated settlement agreement, the Court denied the motion to dismiss with leave to renew if warranted. On April 13, 2026, Class Action Plaintiffs filed a motion for preliminary approval of the settlement agreement. On April 16, 2026, the Court granted preliminary approval of the settlement agreement, stayed all proceedings in the Class Action other than to carry out and enforce the settlement agreement, and scheduled a final fairness hearing for September 24, 2026.
  (was, 2025-11-13, similarity 0.8367):
[0001805385-25-000017:note_history:2]
On March 25, 2024 and November 1, 2024, putative class action lawsuits were filed against the Company in the United States District Court for the District of Massachusetts. On December 13, 2024, the Court consolidated the two lawsuits into one action (the “Class Action”), pursuant to which a consolidated amended complaint was filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees. The Company filed its motion to dismiss the Class Action on March 28, 2025, and the Class Action Plaintiffs filed their opposition to the motion to dismiss on June 24, 2025. On June 30, 2025, the Court issued an order staying the Class Action, including disposition on the motion to dismiss, pending settlement negotiations. On August 5, 2025, the parties to the Class Action engaged in mediation and reached a settlement in principle in the amount of $15.0 million, which is subject to negotiation of definitive documentation and court approval, of which the Company estimated that $14.0 million would be funded by the Company's Directors and Officers insurance coverage. On August 19, 2025, the Court issued an order continuing the stay and ordering Class Action Plaintiffs to file a motion for preliminary approval of the settlement by December 15, 2025.

- added (2026-05-12):
[0001805385-26-000028:note_history:3]
The Company has previously recognized a settlement accrual of $15.0 million and an estimated insurance recovery of $14.0 million, which remain in accrued expenses and other current liabilities and prepaid and other current assets in the condensed consolidated balance sheets as of December 31, 2025, respectively, representing management's best estimate of the outcome. The Company was subsequently notified that an additional $0.3 million will be recovered and has adjusted the insurance recovery receivable to $14.3 million as of March 31, 2026. The related adjustment was recorded in general and administrative expense in the condensed consolidated statements of operations and comprehensive loss during the three months ended March 31, 2026.

- changed (2026-05-12):
[0001805385-26-000028:note_history:4]
On October 2, 2025, another shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Second Delaware Derivative Action”). The Second Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers and directors, NHIC directors and officers, and nominally against the Company. Plaintiff Robert Patrick, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duties, unjust enrichment, abuse of control, gross mismanagement, and waste of corporate
  (was, 2025-11-13, similarity 0.6974):
[0001805385-25-000017:note_history:4]
On October 2, 2025, another shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Second Delaware Derivative Action”). The Second Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers and directors, NHIC directors and officers, and nominally against the Company. Plaintiff Robert Patrick, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duties, unjust enrichment, abuse of control, gross mismanagement, and waste of corporate assets, seeking various forms of relief, including equitable relief directing reform of corporate governance and internal controls, monetary damages including restitution and other fees, and a declaration that the individual defendants breached or aided and abetted breaches of fiduciary duties. On November 7, 2025, the Delaware Court of Chancery entered an order staying the Second Delaware Derivative Action pending the outcome of renewed motions to dismiss or final disposition of the Class Action.

- added (2026-05-12):
[0001805385-26-000028:note_history:5]
assets, seeking various forms of relief, including equitable relief directing reform of corporate governance and internal controls, monetary damages including restitution and other fees, and a declaration that the individual defendants breached or aided and abetted breaches of fiduciary duties. On November 7, 2025, the Delaware Court of Chancery entered an order staying the Second Delaware Derivative Action pending the outcome of renewed motions to dismiss or final disposition of the Class Action.

- added (2026-05-12):
[0001805385-26-000028:note_history:6]
On May 4, 2026, the Company reached an agreement in principle to settle the Massachusetts Derivative Action, the First Delaware Derivative Action, and the Second Delaware Derivative Action. The proposed settlement is subject to the execution of definitive settlement documentation and court approval. The Company has agreed to implement certain corporate governance reforms and to cause the Company’s directors’ and officers’ liability insurance carriers to pay plaintiffs’ counsel a fee of $1.3 million. The Company does not expect the proposed settlement to have a material adverse effect on its condensed consolidated balance sheet, condensed consolidated statements of operations and comprehensive loss, and condensed consolidated statements of cash flows.

- added (2026-05-12):
[0001805385-26-000028:note_history:7]
In February 2024, the Company received a subpoena from the Division of Enforcement of the Securities and Exchange Commission (the “SEC”), requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York (the “DOJ”) relating to a previously disclosed investigation and related restatement of prior period financial statements, and has since received additional requests for documents and information relating to this matter. By letter dated August 7, 2025, the DOJ informed the Company that the Company is no longer the subject of a DOJ investigation.

- added (2026-05-12):
[0001805385-26-000028:note_history:8]
Any resolution or litigation with the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to the SEC matter. In addition to the expected insurance recovery discussed above related to the Class Action litigation, the Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matters, including certain expenses that have previously been paid, are also expected to be reimbursed. The Company recognized estimated loss recoveries related to insurance coverage for these matters of $1.1 million and $3.9 million for the three months ended March 31, 2026 and 2025, respectively, which were recorded as reductions of general and administrative expense in the condensed consolidated statements of operations and comprehensive loss. These amounts reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company has determined are probable of recovery. During the three months ended March 31, 2026, $1.2 million of these recoveries were paid out by the Company's insurance provider. No insurance recoveries were paid out during the three months ended March 31, 2025. As of March 31, 2026 and December 31, 2025, remaining estimated recoveries of $1.2 million and $1.3 million were included in prepaid and other current assets in the condensed consolidated balance sheets, respectively.

- added (2026-05-12):
[0001805385-26-000028:note_history:9]
As it relates to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or

- added (2026-05-12):
[0001805385-26-000028:note_history:10]
that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated recoveries.

- added (2026-05-12):
[0001805385-26-000028:note_history:11]
The Company generally contracts with its contract manufacturers on a cancellable, purchase-order basis. The Company has a contract in the normal course of business with its contract manufacturers to provide manufacturing services for the Company's equipment sold or leased to customers. While these contracts are cancellable by the Company upon prior notice, payments due upon cancellation consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. These payments are not determinable, but could result in a material purchase commitment if the Company were to cancel their open purchase orders.

- removed (2026-05-12):
[0001805385-25-000017:note_history:12]
contingencies. The Company expenses the costs related to such legal proceedings as incurred. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. Below is a summary of the various types of matters subject to this guidance.

- removed (2026-05-12):
[0001805385-25-000017:note_history:13]
As of September 30, 2025, the Company has recognized a settlement accrual of $15.0 million and an estimated insurance recovery of $14.0 million, which are included in accrued expenses and other current liabilities and prepaid and other current assets in the condensed consolidated balance sheets, respectively, representing management's best estimate of the outcome. For the three and nine months ended September 30, 2025, the Company recognized $0 and $1.0 million,

- removed (2026-05-12):
[0001805385-25-000017:note_history:14]
respectively, for the estimated net loss in general and administrative expense in the condensed consolidated statements of operations and comprehensive loss.

- removed (2026-05-12):
[0001805385-25-000017:note_history:15]
The Company expects to incur legal and professional services expenses associated with this litigation in future periods. The Company will recognize these expenses as services are received. We cannot reasonably estimate a range of possible losses at this time for the derivative lawsuits, as the proceedings remain in the early stages, alleged damages have not been specified, and the derivative actions are stayed. For these reasons, the Company has not recorded a loss contingency liability for the derivative lawsuits as of September 30, 2025.

- removed (2026-05-12):
[0001805385-25-000017:note_history:16]
As previously disclosed, on October 12, 2023, the Company announced that the U.S. Federal Trade Commission (the “FTC”) had requested information about certain aspects of its marketing practices. The Company reached a settlement with the FTC and on December 5, 2024, a Stipulated Order for Permanent Injunction and Other Relief (the “Order”) was entered in the United States District Court for the District of Massachusetts Eastern Division. The Order (i) required that the Company permit a limited cohort of school customers to cancel their contracts, (ii) required that the Company take certain compliance actions and meet record keeping obligations, and (iii) enjoined the Company from making misleading or unsubstantiated marketing claims. The Order did not include any monetary relief. The period during which eligible customers may cancel closed on March 30, 2025. Any inability to adequately comply with the terms of the Order could result in enforcement actions or penalties imposed by the FTC.

- removed (2026-05-12):
[0001805385-25-000017:note_history:17]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered

- removed (2026-05-12):
[0001805385-25-000017:note_history:18]
the cancellation period, and of these, 5 customers representing 24 Evolv Express systems elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the year ended December 31, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and nine months ended September 30, 2025, as revenue continued to be recognized on these deals through the cancellation dates of each contract, all of which were in June 2025, and all systems have been removed from our subscription base as of September 30, 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of the effective date of the Order were impacted by the cancellations, which has been excluded from the remaining performance obligations disclosed in Note 5 Revenue Recognition.

- removed (2026-05-12):
[0001805385-25-000017:note_history:19]
As previously disclosed, in February 2024, the Company received a subpoena from the Division of Enforcement of the Securities and Exchange Commission (the “SEC”), requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation.

- removed (2026-05-12):
[0001805385-25-000017:note_history:20]
As previously reported, the Company self-reported the Investigation to the Division of Enforcement of the SEC. The Company has since received requests for documents and information from the SEC relating to this matter. The Company is cooperating with this investigation. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("DOJ") relating to these same issues, and has since received additional requests for documents and information relating to this matter. By letter dated August 7, 2025, the DOJ informed the Company that the Company is no longer the subject of a DOJ investigation.

- removed (2026-05-12):
[0001805385-25-000017:note_history:21]
Any resolution or litigation with the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to the SEC matter. In addition to the expected insurance recovery discussed above related to the Class Action litigation, the Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matter, including certain expenses that have previously been paid, are also expected to be reimbursed. As of September 30, 2025, the Company recognized an estimated loss recovery related to insurance coverage for these matters of $1.2 million and $6.8 million for the three and nine months ended September 30, 2025, respectively, which was recorded as a reduction of general and administrative expense in the condensed consolidated statements of operations and comprehensive loss. As of September 30, 2025, $5.6 million of these recoveries have been paid out by the Company's insurance provider. The $1.2 million remaining estimated recovery is included in prepaid and other current assets in the condensed consolidated balance sheets as of September 30, 2025. This amount reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company has determined are probable of recovery. $1.0 million of recoveries were paid out in the fourth quarter to date. As it relates to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated

- removed (2026-05-12):
[0001805385-25-000017:note_history:22]
insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.

- removed (2026-05-12):
[0001805385-25-000017:note_history:23]
The Company generally contracts with its contract manufacturer, Columbia Tech, on a cancellable purchase-order basis to provide manufacturing services for the Company's equipment sold or leased to customers. While these contracts are cancellable by the Company upon prior notice, payments due upon cancellation may consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. Additionally, the recently executed agreement with the Company's new contract manufacturer, Plexus, includes provisions for which order volumes that fall short of our forecasts may result in purchase commitments. These payments are not determinable, but could result in a material purchase commitment if the Company were to cancel their open purchase orders.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2026-05-12):
[0001805385-26-000028:note_history:24]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company pioneering Artificial Intelligence (“AI”)-powered screening solutions designed to help create safer environments while maintaining efficient visitor flow and a positive visitor experience. The Company serves customers across a range of end markets, including education, healthcare, sports, live entertainment, tourist attractions, houses of worship, and industrial workplaces.

- changed (2026-05-12):
[0001805385-26-000028:note_history:25]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. (“Evolv UK”) and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).
  (was, 2025-11-13, similarity 0.868):
[0001805385-25-000017:note_history:25]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. (“Evolv UK”) and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”). References to the “Investigation” refer to the investigation commenced in September 2024 by an ad hoc committee of independent directors of the Company's Board of Directors into its sales practices, as previously disclosed in our Annual Report on Form 10-K for the year ended December 31, 2024.

- changed (2026-05-12):
[0001805385-26-000028:note_history:26]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures, debt obligations, and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of March 31, 2026, the Company had $61.1 million in cash, cash equivalents, and marketable securities, with outstanding debt of $30.0 million and available additional debt of up to $45.0 million, as detailed below. We incurred a net loss of $5.0 million and $1.7 million for the three months ended March 31, 2026 and 2025, respectively, and operating activities resulted in cash outflows of $3.2 million and $2.5 million during the three months ended March 31, 2026 and 2025, respectively. The Company expects to continue to generate losses for the foreseeable future.
  (was, 2025-11-13, similarity 0.9227):
[0001805385-25-000017:note_history:26]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures, debt obligations, and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of September 30, 2025, the Company had $56.2 million in cash, cash equivalents, and marketable securities, with outstanding debt of $28.5 million and available additional debt of up to $45.0 million, as detailed below. We incurred a net loss of $44.0 million and $38.3 million for the nine months ended September 30, 2025 and 2024, respectively, and operating activities resulted in cash inflow of $3.1 million and cash outflow of $34.1 million during the nine months ended September 30, 2025 and 2024, respectively. We expect to continue to generate losses for the foreseeable future.

- changed (2026-05-12):
[0001805385-26-000028:note_history:27]
On July 29, 2025 (the “Closing Date”), the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's pure subscription sales model. The MidCap Credit Agreement provided an initial $30.0 million term loan facility (the
  (was, 2025-11-13, similarity 0.8564):
[0001805385-25-000017:note_history:27]
On July 29, 2025 (the “Closing Date”), the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's

- changed (2026-05-12):
[0001805385-26-000028:note_history:28]
“Initial Term Loan”), a $30.0 million delayed draw facility (the “Delayed Draw Term Loan”) (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit (the “Revolving Credit Facility”), each with a maturity date of July 1, 2030 (collectively, the “Senior Secured Credit Facilities”). On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs paid at closing. As of March 31, 2026, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available. See Note 9, Long-term Debt for additional information.
  (was, 2025-11-13, similarity 0.9211):
[0001805385-25-000017:note_history:28]
subscription sales model. The MidCap Credit Agreement provided an initial $30.0 million term loan facility (the “Initial Term Loan”), a $30.0 million delayed draw facility (the “Delayed Draw Term Loan”) (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit (the “Revolving Credit Facility”), each with a maturity date of July 1, 2030 (collectively, the “Senior Secured Credit Facilities”). On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs paid at closing. As of September 30, 2025, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available. See Note 9, Long-term Debt for additional information.

- changed (2026-05-12):
[0001805385-26-000028:note_history:29]
The Company expects its cash, cash equivalents, and marketable securities of $61.1 million as of March 31, 2026, together with cash it expects to generate from future operations and borrowing availability under the Senior Secured Credit Facilities, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth.
  (was, 2025-11-13, similarity 0.9892):
[0001805385-25-000017:note_history:29]
The Company expects its cash, cash equivalents, and marketable securities of $56.2 million as of September 30, 2025, together with cash it expects to generate from future operations and borrowing availability under the Senior Secured Credit Facilities, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth.

- added (2026-05-12):
[0001805385-26-000028:note_history:30]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that began at $106.0 million on December 31, 2025 and increases quarterly thereafter; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum earnings before interest, taxes, depreciation, and amortization ("EBITDA") covenant that takes effect on June 30, 2027. As of March 31, 2026, the minimum required ARR is $107.3 million, and the Company is in full compliance with all applicable covenant requirements, and expects to remain in compliance for a period of at least twelve months from May 12, 2026.

- added (2026-05-12):
[0001805385-26-000028:note_history:31]
There is significant uncertainty in the current geopolitical and macroeconomic environment due to various factors, including but not limited to inflationary pressures globally, conflicts in Europe and the Middle East, and foreign currency volatility and their impacts on the Company’s business. If economic conditions were to worsen, the Company’s results of operations, financial condition, and cash flows from operations may be materially and adversely impacted.

- changed (2026-05-12):
[0001805385-26-000028:note_history:32]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2026, and for the three months ended March 31, 2026 and 2025 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2025 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2026, the results of its operations for the three months ended March 31, 2026 and 2025 and cash flows for the three months ended March 31, 2026 and 2025. The results for the three months ended March 31, 2026 are not necessarily indicative of results to be expected for the year ending December 31, 2026, any other interim periods, or any future year or period. These interim unaudited condensed consolidated financial statements should be read in conjunction with the financial statements included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2025.
  (was, 2025-11-13, similarity 0.7787):
[0001805385-25-000017:note_history:32]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2025, and for the three and nine months ended September 30, 2025 and 2024 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2024 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2025, the results of its operations for the three and nine months ended September 30, 2025 and 2024 and cash flows for the nine months ended September 30, 2025 and 2024. The results for the three and nine months ended September 30, 2025 are not necessarily indicative of results to be expected for the year ending December 31, 2025, any other interim periods, or any future year or period. These interim unaudited condensed consolidated financial statements should be read in conjunction with the financial statements included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024.

- removed (2026-05-12):
[0001805385-25-000017:note_history:33]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company with products designed to transform human security to make a safer, faster, and better experience for the world's most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics.

- removed (2026-05-12):
[0001805385-25-000017:note_history:34]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that begins at $106.0 million on December 31, 2025 and increases quarterly thereafter. The minimum required ARR on December 31, 2026 is $111.3 million. As of September 30, 2025, the Company’s ARR was $117.2 million, which is sufficient to satisfy the minimum required ARR through December 31, 2027; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. As of September 30, 2025, the minimum liquidity required is $15.0 million, and liquidity, as defined in the agreement, was $71.1 million. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum EBITDA covenant that takes effect on June 30, 2027. As of September 30, 2025, the Company is in full compliance with all applicable covenant requirements, and expects to remain in compliance for a period of at least twelve months from November 13, 2025.

- removed (2026-05-12):
[0001805385-25-000017:note_history:35]
Reclassifications

- removed (2026-05-12):
[0001805385-25-000017:note_history:36]
During the three months ended March 31, 2025, the Company began classifying restructuring charges, which includes termination charges arising from severance obligations, incremental non-cash expense, and other customary employee benefit payments in connection with a reduction in force, within restructuring costs on the condensed consolidated statements of operations and comprehensive loss, whereas the restructuring costs for these services had previously been included in cost of service revenue, research and development expenses, sales and marketing expenses,

- removed (2026-05-12):
[0001805385-25-000017:note_history:37]
and general and administrative expenses. These reclassifications were made to align the presentation of restructuring charges with the Company's internal reporting and analysis. There were no reclassifications for the three months ended September 30, 2024. The reclassifications increased gross profit by $0.2 million for the nine months ended September 30, 2024 and did not impact total loss from operations or total net loss for any period. Prior year amounts included in this Quarterly Report on Form 10-Q have been reclassified to conform to the current presentation.

- removed (2026-05-12):
[0001805385-25-000017:note_history:38]
For the nine months ended September 30, 2024, the reclassifications resulted in an increase in restructuring costs of $0.9 million, and a corresponding decrease in cost of service revenue, sales and marketing expenses, and general and administrative expenses of $0.2 million, $0.7 million, and less than $0.1 million, respectively.

- removed (2026-05-12):
[0001805385-25-000017:note_history:39]
During the three months ended September 30, 2025, the Company recorded an out-of-period correction to decrease other income (expense) by $0.9 million, decrease contingently issuable common stock liability by $2.3 million, increase other assets by $2.0 million and increase additional paid in capital by $3.4 million. The out-of-period adjustment was recorded to correct the accounting for the fair value of the contingently issuable common shares and the contingently returnable common stock, as described in more detail in Note 4, Fair Value Measurements. Management evaluated the accounting impacts on prior periods based on the historical dates of transfers, concluding that such impacts were not material to the historical financial statements.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-12):
[0001805385-26-000028:note_history:40]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2025, and the notes thereto, which are included in our 2025 Form 10-K. Except for the estimates used to
  (was, 2025-11-13, similarity 0.6639):
[0001805385-25-000017:note_history:40]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2024, and the notes thereto, which are included in our 2024 Form 10-K. Except for the partner rebate program, debt and debt issuance costs, and the estimates used to determine the grant date valuation for certain market-based stock units (“MSUs”), as described below, there have been no material changes to the Company’s significant accounting policies during the nine months ended September 30, 2025.

- added (2026-05-12):
[0001805385-26-000028:note_history:41]
determine the grant date valuation for certain performance stock units (“PSUs”), as described below, there have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2026.

- added (2026-05-12):
[0001805385-26-000028:note_history:42]
Recently Adopted Accounting Pronouncements

- added (2026-05-12):
[0001805385-26-000028:note_history:43]
In July 2025, the FASB issued ASU 2025-05, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets.”. ASU 2025-05 provides a practical expedient that allows entities to estimate expected credit losses by assuming that current conditions as of the balance sheet date will not change over the remaining life of the asset. The amendment is applied prospectively and is effective for annual periods beginning after December 15, 2025, and interim periods within those annual periods. The Company adopted ASU 2025-05 effective January 1, 2026 and elected to adopt the practical expedient that permits entities to assume that current conditions as of the balance sheet date do not change over the remaining life of the asset when estimating expected credit losses. The adoption did not have a material impact on the Company’s condensed consolidated financial statements or related disclosures.

- changed (2026-05-12):
[0001805385-26-000028:note_history:44]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses.”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Further, in January 2025, the FASB issued ASU 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Clarifying the Effective Date)" to clarify the effective date of ASU 2024-03. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 and ASU 2025-01 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the condensed consolidated financial statements.
  (was, 2025-11-13, similarity 0.6222):
[0001805385-25-000017:note_history:44]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses.”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

- changed (2026-05-12):
[0001805385-26-000028:note_history:45]
In September 2025, the FASB issued ASU 2025-06, “Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software.”, which amends guidance on capitalization of software development costs and introduces a probable-to-complete recognition threshold, along with factors to consider for evaluating significant development uncertainty. The amendments are effective for annual reporting periods beginning after December 15, 2027, including interim periods within those annual periods. Early adoption is permitted and this amendment is applied prospectively. The Company is currently evaluating the impact of this ASU on its accounting policies and disclosures within the condensed consolidated financial statements.
  (was, 2025-11-13, similarity 0.9927):
[0001805385-25-000017:note_history:45]
In September 2025, the FASB issued ASU 2025-06, “Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software.” which amends guidance on capitalization of software development costs and introduces a probable-to-complete recognition threshold, along with factors to consider for evaluating significant development uncertainty. The amendments are effective for annual reporting periods beginning after December 15, 2027, including interim periods within those annual periods. Early adoption is permitted and this amendment is applied prospectively. The Company is currently evaluating the impact of this ASU on its accounting policies and disclosures within the consolidated financial statements.

- removed (2026-05-12):
[0001805385-25-000017:note_history:46]
Partner Rebate Program

- removed (2026-05-12):
[0001805385-25-000017:note_history:47]
For the fiscal year 2025, the Company implemented a channel partner rebate program (the “Rebate Program”) for eligible resellers. Under the Rebate Program, eligible resellers that attain at least 25% of their current fiscal year total contract value (“TCV”) target (“Annual Target”) in a given quarter are eligible for a rebate based upon a percentage of their TCV for that quarter. In addition, resellers that meet their Annual Target are eligible for a one-time rebate based upon a percentage of their total fiscal year TCV, applied as a credit in the subsequent fiscal year. All rebates are issued as credits against future purchases, and no cash rebates are paid. Unused rebate credits are forfeited in the event of a reseller agreement termination.

- removed (2026-05-12):
[0001805385-25-000017:note_history:48]
The Company recognizes an accrued liability related to the Rebate Program in accrued expenses and other current liabilities in our condensed consolidated balance sheets and recognizes the rebates as reduction of revenue.

- removed (2026-05-12):
[0001805385-25-000017:note_history:49]
Market-based Stock Units

- removed (2026-05-12):
[0001805385-25-000017:note_history:50]
The estimated grant date fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.

- removed (2026-05-12):
[0001805385-25-000017:note_history:51]
Debt and Debt issuance costs

- removed (2026-05-12):
[0001805385-25-000017:note_history:52]
Debt is initially recognized at the amount of proceeds received, net of directly attributable issuance costs. The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated

- removed (2026-05-12):
[0001805385-25-000017:note_history:53]
debt on the condensed consolidated balance sheet and amortized as interest expense on the condensed consolidated statement of operations and comprehensive loss using the effective interest method.

- removed (2026-05-12):
[0001805385-25-000017:note_history:54]
For undrawn delayed draw and revolving line of credit facilities, commitment fees and related costs are costs incurred in exchange for access to capital. These fees are paid regardless of whether the funds are drawn down. Such costs associated with delayed draw facility are capitalized as prepaid expenses and other current assets and other assets in our condensed consolidated balance sheets, and such costs associated with revolving line of credit are capitalized as other assets in our condensed consolidated balance sheets. The capitalized costs are amortized as interest expense on a straight-line basis over the access period. If drawdown of the delayed draw facility becomes probable, the remaining unamortized costs are reclassified as contra-debt and amortized using the effective interest method. If it becomes probable that the delayed draw facility will not be drawn during the access period, the remaining unamortized cost will be recognized as expense in the period that determination was made.

- removed (2026-05-12):
[0001805385-25-000017:note_history:55]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity may apply the amendments in ASU 2023-09 either prospectively to all annual periods beginning after December 15, 2024, or retrospectively to prior periods. The Company determined that ASU 2023-09 is applicable and will be adopted in our Annual Report on Form 10-K for the year ended December 31, 2025. As ASU 2023-09 addresses disclosures only, the Company expects it will not have any material effects on its financial condition, results of operations, or cash flows.

- removed (2026-05-12):
[0001805385-25-000017:note_history:56]
In July 2025, the FASB issued ASU 2025-05, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets.” The amendment in ASU 2025-05 provides entities with a practical expedient to simplify the estimation of expected credit losses by assuming that the current conditions as of the balance sheet date will not change for the remaining life of the asset. Early adoption is permitted, and this amendment is applied prospectively. ASU 2025-05 is effective for all annual periods beginning after December 15, 2025 and interim periods within those annual periods. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-12):
[0001805385-26-000028:note_history:57]
|  | March 31,2026 |  | December 31,2025 |
| Term loans payable | $ | 30,000 |  |  | $ | 30,000 |  |
| Less: Unamortized debt issuance cost | (1,335) |  |  | (1,404) |  |
|  | 28,665 |  |  | 28,596 |  |
| Less: Current portion of long-term debt | — |  |  | — |  |
| Long-term debt | $ | 28,665 |  |  | $ | 28,596 |  |

- added (2026-05-12):
[0001805385-26-000028:note_history:58]
On July 29, 2025, the Company entered into the $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's pure subscription sales model. The MidCap Credit Agreement provided for an initial $30.0 million term loan facility (the “Initial Term Loan”), a $30.0 million delayed draw facility (the “Delayed Draw Term Loan”) (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit (the "Revolving Credit Facility”), each with a maturity date of July 1, 2030 (collectively, the “Senior Secured Credit Facilities”). As of March 31, 2026, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available.

- changed (2026-05-12):
[0001805385-26-000028:note_history:59]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that began at $106.0 million on December 31, 2025 and increases quarterly thereafter; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum EBITDA covenant that takes effect on June 30, 2027. As of March 31, 2026, the minimum required ARR is $107.3 million, and the Company is in full compliance with all applicable covenant requirements.
  (was, 2025-11-13, similarity 0.6732):
[0001805385-25-000017:note_history:59]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that begins at $106.0 million on December 31, 2025 and increases quarterly thereafter. The minimum required ARR on December 31, 2026 is $111.3 million. As of September 30, 2025,  the Company’s ARR was $117.2 million, which is sufficient to satisfy the minimum required ARR through December 31, 2027; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. As of September 30, 2025, the minimum liquidity required is $15.0 million, and liquidity, as defined in the agreement, was $71.1 million. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum EBITDA covenant that takes effect on June 30, 2027. As of September 30, 2025, the Company is in full compliance with all applicable covenant requirements, and expects to remain in compliance for a period of at least twelve months from November 13, 2025.

- changed (2026-05-12):
[0001805385-26-000028:note_history:60]
As of March 31, 2026, the unamortized debt issuance costs totaled $1.3 million, and are presented as a direct deduction from the carrying amount of the Initial Term Loan on the condensed consolidated balance sheet and are amortized as interest expense using the effective interest method in accordance with ASC 835. Interest expense related to
  (was, 2025-11-13, similarity 0.6161):
[0001805385-25-000017:note_history:60]
As of September 30, 2025, the unamortized debt issuance costs totaled $1.5 million, and are presented as a direct deduction from the carrying amount of the Initial Term Loan on the consolidated balance sheet and are amortized as interest expense using the effective interest method in accordance with ASC 835. Interest expense related to the Initial Term Loan totaled $0.6 million for the three and nine months ended September 30, 2025. The interest rate in effect as of September 30, 2025 was approximately 9.60%, which includes Term SOFR of 4.35% and an applicable margin of 5.25%. Interest expense related to the amortization of debt issuance costs totaled less than $0.1 million for the three and nine months ended September 30, 2025.

- added (2026-05-12):
[0001805385-26-000028:note_history:61]
the Initial Term Loan totaled less than $0.7 million for the three months ended March 31, 2026. The interest rate in effect as of March 31, 2026 was approximately 8.92%, which includes Term SOFR of 3.67% and an applicable margin of 5.25%. Interest expense related to the amortization of debt issuance costs totaled less than $0.1 million for the three months ended March 31, 2026. No interest expense was recognized for the three months ended March 31, 2025, as there was no debt outstanding during the period.

- changed (2026-05-12):
[0001805385-26-000028:note_history:62]
As of March 31, 2026, future principal payments on long-term debt are as follows (in thousands):
  (was, 2025-11-13, similarity 0.9457):
[0001805385-25-000017:note_history:62]
As of September 30, 2025, future principal payments on long-term debt are as follows (in thousands):

- changed (2026-05-12):
[0001805385-26-000028:note_history:63]
| Year Ending December 31: |  |
| 2026 (remaining nine months) | $ | — |  |
| 2027 | — |  |
| 2028 | — |  |
| 2029 | 12,500 |  |
| 2030 | 17,500 |  |
|  | $ | 30,000 |  |
  (was, 2025-11-13, similarity 0.8413):
[0001805385-25-000017:note_history:63]
| December 31, |  |
| 2025 (remaining three months) | $ | — |  |
| 2026 | — |  |
| 2027 | — |  |
| 2028 | — |  |
| 2029 | 12,500 |  |
| Thereafter | 17,500 |  |
|  | $ | 30,000 |  |

- changed (2026-05-12):
[0001805385-26-000028:note_history:64]
As of March 31, 2026, no amounts had been drawn under the Delayed Draw Term Loan or Revolving Credit Facility. Unused commitments amounted to $30.0 million and $15.0 million under the Delayed Draw Term Loan and Revolving Credit Facility, respectively, as of March 31, 2026. Debt issuance costs allocated to these facilities are paid regardless of whether the funds are drawn down. Such costs are capitalized as prepaid assets and amortized as interest expense on a straight-line basis over their respective access periods, which end on August 1, 2027 and July 1, 2030 for Delayed Draw Term Loan and Revolving Credit Facility, respectively. As of March 31, 2026, the Company recorded $0.7 million in prepaid expenses and other current assets and $0.9 million in other assets in the condensed consolidated balance sheets for costs associated with Delayed Draw Term Loan and Revolving Credit Facility. As of December 31, 2025, the Company recorded $0.7 million in prepaid expenses and other current assets and $1.1 million in other assets in the condensed consolidated balance sheets for costs associated with Delayed Draw Term Loan and Revolving Credit Facility. Capitalized debt issuance cost is amortized as interest expense on a straight-line basis over the period each facility is available to be drawn. Interest expense related to the amortization of debt issuance costs totaled $0.2 million for the three months ended March 31, 2026. No interest expense related to the amortization of debt issuance costs was recognized for the three months ended March 31, 2025, as there was no debt during the period.
  (was, 2025-11-13, similarity 0.638):
[0001805385-25-000017:note_history:64]
As of September 30, 2025, no amounts had been drawn under the Delayed Draw Term Loan or Revolving Credit Facility. Unused commitments amounted to $30.0 million and $15.0 million under the Delayed Draw Term Loan and Revolving Credit Facility, respectively, as of September 30, 2025. Debt issuance costs allocated to these facilities are paid regardless of whether the funds are drawn down. Such costs are capitalized as prepaid assets and amortized as interest expense on a straight-line basis over their respective access periods, which end on August 1, 2027 and July 1, 2030 for Delayed Draw Term Loan and Revolving Credit Facility, respectively. As of September 30, 2025, the Company recorded $0.7 million in prepaid expenses and other current assets and $1.3 million in other assets in the condensed consolidated balance sheets for costs associated with Delayed Draw Term Loan and Revolving Credit Facility. Capitalized debt issuance cost is amortized as interest expense on a straight-line basis over the period each facility is available to be drawn. Interest expense related to the amortization of debt issuance costs totaled $0.2 million for the three and nine months ended September 30, 2025.

- changed (2026-05-12):
[0001805385-26-000028:note_history:65]
The Revolving Credit Facility provides for an unused commitment fee of 0.25% on the undrawn portion of the facility. Interest expense related to the unused commitment fees totaled less than $0.1 million for the three months ended March 31, 2026. No interest expense related to the unused commitment fees was recognized for the three months ended March 31, 2025, as there was no debt during the period.
  (was, 2025-11-13, similarity 0.6751):
[0001805385-25-000017:note_history:65]
The Revolving Credit Facility provides for an unused commitment fee of 0.25% on the undrawn portion of the facility. Interest expense related to the unused commitment fees totaled less than $0.1 million for the three and nine months ended September 30, 2025.

- removed (2026-05-12):
[0001805385-25-000017:note_history:66]
|  | September 30,2025 |  |  |
| Term loans payable | $ | 30,000 |  |  |  |
| Less: Unamortized discount | (1,472) |  |  |  |
|  | 28,528 |  |  |  |
| Less: Current portion of long-term debt | — |  |  |  |
| Long-term debt, net of discount | $ | 28,528 |  |  |  |

- removed (2026-05-12):
[0001805385-25-000017:note_history:67]
As described in Note 1, on July 29, 2025, the Company entered into the $75.0 million MidCap Credit Agreement, which provided for the Senior Secured Credit Facilities, which include a $30.0 million Initial Term Loan, a $30.0 million Delayed Draw Term Loan (available for drawdown during the two-year period following the Closing Date), and a $15.0 million Revolving Credit Facility, each with a maturity date of July 1, 2030. As of September 30, 2025, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2026-05-12):
[0001805385-25-000017:note_history:68]
Debt and Debt issuance costs

- removed (2026-05-12):
[0001805385-25-000017:note_history:69]
Debt is initially recognized at the amount of proceeds received, net of directly attributable issuance costs. The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated

- removed (2026-05-12):
[0001805385-25-000017:note_history:70]
debt on the condensed consolidated balance sheet and amortized as interest expense on the condensed consolidated statement of operations and comprehensive loss using the effective interest method.

- removed (2026-05-12):
[0001805385-25-000017:note_history:71]
For undrawn delayed draw and revolving line of credit facilities, commitment fees and related costs are costs incurred in exchange for access to capital. These fees are paid regardless of whether the funds are drawn down. Such costs associated with delayed draw facility are capitalized as prepaid expenses and other current assets and other assets in our condensed consolidated balance sheets, and such costs associated with revolving line of credit are capitalized as other assets in our condensed consolidated balance sheets. The capitalized costs are amortized as interest expense on a straight-line basis over the access period. If drawdown of the delayed draw facility becomes probable, the remaining unamortized costs are reclassified as contra-debt and amortized using the effective interest method. If it becomes probable that the delayed draw facility will not be drawn during the access period, the remaining unamortized cost will be recognized as expense in the period that determination was made.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2026-05-12):
[0001805385-26-000028:note_history:72]
Marketable securities as of March 31, 2026 and December 31, 2025 consisted of the following:

- added (2026-05-12):
[0001805385-26-000028:note_history:73]
|  | March 31, 2026 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 4,992 |  |  | $ | — |  |  | $ | 4,992 |  |
| Total marketable securities | $ | 4,992 |  |  | $ | — |  |  | $ | 4,992 |  |

- added (2026-05-12):
[0001805385-26-000028:note_history:74]
|  | December 31, 2025 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 19,885 |  |  | $ | — |  |  | $ | 19,885 |  |
| Total marketable securities | $ | 19,885 |  |  | $ | — |  |  | $ | 19,885 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-12):
[0001805385-26-000028:note_history:75]
Marketable Securities
Marketable securities as of March 31, 2026 and December 31, 2025 consisted of the following:
  (was, 2025-11-13, similarity 0.9528):
[0001805385-25-000017:note_history:75]
Marketable Securities
Marketable securities as of September 30, 2025 and December 31, 2024 consisted of the following:

- changed (2026-05-12):
[0001805385-26-000028:note_history:76]
|  | March 31, 2026 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 4,992 |  |  | $ | — |  |  | $ | 4,992 |  |
| Total marketable securities | $ | 4,992 |  |  | $ | — |  |  | $ | 4,992 |  |
  (was, 2025-11-13, similarity 0.9706):
[0001805385-25-000017:note_history:76]
|  | September 30, 2025 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 24,723 |  |  | $ | — |  |  | $ | 24,723 |  |
| Total marketable securities | $ | 24,723 |  |  | $ | — |  |  | $ | 24,723 |  |

- changed (2026-05-12):
[0001805385-26-000028:note_history:77]
Marketable securities at March 31, 2026 and December 31, 2025 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three months ended March 31, 2026 and 2025. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive loss.
  (was, 2025-11-13, similarity 0.8782):
[0001805385-25-000017:note_history:77]
Marketable securities at September 30, 2025 and December 31, 2024 were comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and nine months ended September 30, 2025 and 2024. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive loss.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-12):
[0001805385-26-000028:note_history:78]
|  | March 31,2026 |  | December 31,2025 |
| Term loans payable | $ | 30,000 |  |  | $ | 30,000 |  |
| Less: Unamortized debt issuance cost | (1,335) |  |  | (1,404) |  |
|  | 28,665 |  |  | 28,596 |  |
| Less: Current portion of long-term debt | — |  |  | — |  |
| Long-term debt | $ | 28,665 |  |  | $ | 28,596 |  |

- removed (2026-05-12):
[0001805385-25-000017:note_history:79]
|  | September 30,2025 |  |  |
| Term loans payable | $ | 30,000 |  |  |  |
| Less: Unamortized discount | (1,472) |  |  |  |
|  | 28,528 |  |  |  |
| Less: Current portion of long-term debt | — |  |  |  |
| Long-term debt, net of discount | $ | 28,528 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-12):
[0001805385-26-000028:note_history:80]
As of March 31, 2026, future principal payments on long-term debt are as follows (in thousands):
  (was, 2025-11-13, similarity 0.9457):
[0001805385-25-000017:note_history:80]
As of September 30, 2025, future principal payments on long-term debt are as follows (in thousands):

- changed (2026-05-12):
[0001805385-26-000028:note_history:81]
| Year Ending December 31: |  |
| 2026 (remaining nine months) | $ | — |  |
| 2027 | — |  |
| 2028 | — |  |
| 2029 | 12,500 |  |
| 2030 | 17,500 |  |
|  | $ | 30,000 |  |
  (was, 2025-11-13, similarity 0.8413):
[0001805385-25-000017:note_history:81]
| December 31, |  |
| 2025 (remaining three months) | $ | — |  |
| 2026 | — |  |
| 2027 | — |  |
| 2028 | — |  |
| 2029 | 12,500 |  |
| Thereafter | 17,500 |  |
|  | $ | 30,000 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2026-05-12):
[0001805385-25-000017:note_history:82]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. While the partnership agreement is still in effect, effective in the fourth quarter of 2024, Motorola is no longer considered a related party. During the three and nine months ended September 30, 2024, revenue from Motorola's distributor services was $2.2 million and $6.1 million, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-05-12):
[0001805385-26-000028:note_history:83]
|  | Three Months EndedMarch 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Product revenue | $ | 13,421 |  |  | $ | 2,322 |  |  |  |  |  |
| Subscription revenue | 23,148 |  |  | 19,237 |  |  |  |  |  |
| Service revenue | 8,589 |  |  | 6,730 |  |  |  |  |  |
| License fees | 172 |  |  | 3,203 |  |  |  |  |  |
| Professional services and other revenue | 998 |  |  | 515 |  |  |  |  |  |
| Total revenue | $ | 46,328 |  |  | $ | 32,007 |  |  |  |  |  |

- removed (2026-05-12):
[0001805385-25-000017:note_history:84]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Product revenue | $ | 9,242 |  |  | $ | 1,344 |  |  | $ | 14,092 |  |  | $ | 4,789 |  |
| Subscription revenue | 22,685 |  |  | 17,909 |  |  | 62,122 |  |  | 47,783 |  |
| Service revenue | 7,808 |  |  | 6,085 |  |  | 21,224 |  |  | 16,903 |  |
| License fees | 2,280 |  |  | 1,606 |  |  | 7,774 |  |  | 4,047 |  |
| Professional services and other revenue | 835 |  |  | 416 |  |  | 2,189 |  |  | 1,243 |  |
| Total revenue | $ | 42,850 |  |  | $ | 27,360 |  |  | $ | 107,401 |  |  | $ | 74,765 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-12):
[0001805385-26-000028:note_history:85]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.
  (was, 2025-11-13, similarity 0.9897):
[0001805385-25-000017:note_history:85]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after control passes to the customer. Revenue is recognized net of sales tax.

- added (2026-05-12):
[0001805385-26-000028:note_history:86]
In March 2023, the Company entered into a distributor licensing agreement (the "Distribution and License Agreement") with Columbia Electrical Contractors, Inc. ("Columbia Tech"). Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, which had served as the Company's primary contract manufacturer. Under this arrangement, the Company granted a license of its intellectual property to Columbia Tech, which contracted directly with certain of the Company's resellers to fulfill sales demand where the end-user customer preferred to purchase the hardware equipment as

- added (2026-05-12):
[0001805385-26-000028:note_history:87]
opposed to lease the equipment. Columbia Tech paid the Company a hardware license fee for each system it manufactured and sold under the agreement. In these instances, the Company still contracted directly with the reseller to provide a multi-year SaaS and maintenance subscription to the end-users. The Distribution and License Agreement expired on December 31, 2025, and the Company no longer offers the distributor license model.

- changed (2026-05-12):
[0001805385-26-000028:note_history:88]
The Company previously assessed whether it operated as the principal or as an agent in relation to the sale of product made by Columbia Tech to the Company's resellers pursuant to the Distribution and License Agreement. The Company considered various factors, including but not limited to, inventory risk, discretion in establishing pricing, and which entity is primarily responsible for fulfillment. Based on an evaluation of the facts and circumstances, the Company concluded that Columbia Tech was the principal in the arrangement. The Company therefore did not recognize revenue in relation to sales of product pursuant to the Distribution and License Agreement, but did recognize revenue in relation to license fees received from Columbia Tech and the SaaS and maintenance subscription contracts, each as further described below.
  (was, 2025-11-13, similarity 0.9626):
[0001805385-25-000017:note_history:88]
The Company has assessed whether it operates as the principal or as an agent in relation to the sale of product made by Columbia Tech to the Company's resellers pursuant to the Distribution and License Agreement. The Company considered various factors, including but not limited to, inventory risk, discretion in establishing pricing, and which entity is primarily responsible for fulfillment. Based on an evaluation of the facts and circumstances, the Company concluded that Columbia Tech is the principal in the arrangement. The Company therefore does not recognize revenue in relation to sales of product pursuant to the Distribution and License Agreement, but does recognize revenue in relation to license fees received from Columbia Tech and the SaaS and maintenance subscription contracts.

- changed (2026-05-12):
[0001805385-26-000028:note_history:89]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2026:
  (was, 2025-11-13, similarity 0.9733):
[0001805385-25-000017:note_history:89]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2025:

- changed (2026-05-12):
[0001805385-26-000028:note_history:90]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is unconditional and only subject to the passage of time.  As of March 31, 2026 and December 31, 2025, the Company had $1.2 million and $0.9 million in current portion of contract assets and both less than $0.1 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2025-11-13, similarity 0.9159):
[0001805385-25-000017:note_history:90]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time.  As of September 30, 2025 and December 31, 2024, the Company had $1.2 million and $0.8 million in current portion of contract assets and $0.4 million and $0.7 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2026-05-12):
[0001805385-26-000028:note_history:91]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $31.0 million during the three months ended March 31, 2026 that was included in the December 31, 2025 deferred revenue balance. The Company recognized revenue of $24.7 million during the three months ended March 31, 2025 that was included in the December 31, 2024 deferred revenue balance.
  (was, 2025-11-13, similarity 0.9096):
[0001805385-25-000017:note_history:91]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $13.9 million and $58.0 million during the three and nine months ended September 30, 2025, respectively, that was included in the December 31, 2024 deferred revenue balance. The Company recognized revenue of $10.1 million and $40.8 million during the three and nine months ended September 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance.

- changed (2026-05-12):
[0001805385-26-000028:note_history:92]
| Balance at December 31, 2025 | $ | 91,640 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (31,024) |  |
| Revenue deferred | 31,734 |  |
| Balance at March 31, 2026 | $ | 92,350 |  |
  (was, 2025-11-13, similarity 0.97):
[0001805385-25-000017:note_history:92]
| Balance at December 31, 2024 | $ | 84,772 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (57,966) |  |
| Revenue deferred | 69,562 |  |
| Balance at September 30, 2025 | $ | 96,368 |  |

- added (2026-05-12):
[0001805385-26-000028:note_history:93]
|  | Three Months EndedMarch 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Interest income on lease receivables | $ | 15 |  |  | $ | 29 |  |  |  |  |  |
| Lease income - operating leases | 23,148 |  |  | 19,237 |  |  |  |  |  |
| Total lease revenue | $ | 23,163 |  |  | $ | 19,266 |  |  |  |  |  |

- changed (2026-05-12):
[0001805385-26-000028:note_history:94]
The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss.
  (was, 2025-11-13, similarity 0.7463):
[0001805385-25-000017:note_history:94]
The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment

- added (2026-05-12):
[0001805385-26-000028:note_history:95]
|  | Three Months EndedMarch 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Product revenue | $ | 13,421 |  |  | $ | 2,322 |  |  |  |  |  |
| Subscription revenue | 23,148 |  |  | 19,237 |  |  |  |  |  |
| Service revenue | 8,589 |  |  | 6,730 |  |  |  |  |  |
| License fees | 172 |  |  | 3,203 |  |  |  |  |  |
| Professional services and other revenue | 998 |  |  | 515 |  |  |  |  |  |
| Total revenue | $ | 46,328 |  |  | $ | 32,007 |  |  |  |  |  |

- added (2026-05-12):
[0001805385-26-000028:note_history:96]
In 2025, the Company implemented a channel partner rebate program (the “Rebate Program”) for eligible resellers. Under the Rebate Program, eligible resellers that attain at least 25% of their current fiscal year total contract value (“TCV”) target (“Annual Target”) in a given quarter are eligible for a rebate based upon a percentage of their TCV for that quarter. In addition, resellers that meet their Annual Target are eligible for a one-time rebate based upon a percentage of their total fiscal year TCV, applied as a credit in the subsequent fiscal year. All rebates are issued as credits against future purchases, and no cash rebates are paid. Unused rebate credits are forfeited in the event of a reseller agreement termination.

- added (2026-05-12):
[0001805385-26-000028:note_history:97]
As of March 31, 2026 and December 31, 2025, the Company has accrued $0.5 million and $1.2 million related to the Rebate Program, respectively, which is included in accrued expenses and other current liabilities in our condensed consolidated balance sheets. As a substantial amount of the Company's revenue from eligible resellers is recognized over-time, rebate liabilities are recognized as contract assets, amortized as reductions to revenue over time, consistent with the recognition of the underlying revenue. As of March 31, 2026, the Company's condensed balance sheet includes $0.2 million and $0.8 million in current portion of contract asset and contract asset, noncurrent, respectively. The Company

- added (2026-05-12):
[0001805385-26-000028:note_history:98]
recognized $0.2 million and $0.6 million of current portion of contract asset and contract asset, noncurrent in our condensed consolidated balance sheets, respectively, as of December 31, 2025. The Company recognized $0.1 million and less than $0.1 million as reduction of revenue for the three months ended March 31, 2026 and 2025, respectively.

- changed (2026-05-12):
[0001805385-26-000028:note_history:99]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $12.3 million and $13.1 million as of March 31, 2026 and December 31, 2025, respectively. During the three months ended March 31, 2026 and 2025, the Company recognized commission expense of $2.3 million and $1.5 million, respectively.
  (was, 2025-11-13, similarity 0.7074):
[0001805385-25-000017:note_history:99]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and professional services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $13.0 million as of both September 30, 2025 and December 31, 2024. During the three months ended September 30, 2025 and 2024, the Company recognized commission expense of $2.1 million and $1.4 million, respectively. During the nine months ended September 30, 2025 and 2024, the Company recognized commission expense of $5.4 million and $4.3 million, respectively.

- added (2026-05-12):
[0001805385-26-000028:note_history:100]
The amount of minimum future leases is based on expected income recognition. As of March 31, 2026, future minimum payments on noncancelable leases are as follows (in thousands):

- changed (2026-05-12):
[0001805385-26-000028:note_history:101]
| Year Ending December 31: |  |
| 2026 (nine months remaining) | $ | 69,191 |  |
| 2027 | 72,105 |  |
| 2028 | 46,042 |  |
| 2029 | 25,278 |  |
| 2030 | 5,249 |  |
| Thereafter | 230 |  |
|  | $ | 218,095 |  |
  (was, 2025-11-13, similarity 0.977):
[0001805385-25-000017:note_history:101]
| Year Ending December 31: |  |
| 2025 (three months remaining) | $ | 23,132 |  |
| 2026 | 83,429 |  |
| 2027 | 61,724 |  |
| 2028 | 35,868 |  |
| 2029 | 13,693 |  |
| Thereafter | 679 |  |
|  | $ | 218,525 |  |

- removed (2026-05-12):
[0001805385-25-000017:note_history:102]
In March 2023, the Company entered into a distributor licensing agreement (the “Distribution and License Agreement”) with Columbia Electrical Contractors, Inc. (“Columbia Tech”). Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, which serves as the Company's primary contract manufacturer. Under this arrangement, the Company has granted a license of its intellectual property to Columbia Tech, which contracts directly with certain of the Company's resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment as opposed to lease the equipment. Columbia Tech pays the Company a hardware license fee for each system it manufactures and sells under the agreement. In these instances, the Company still contracts directly with the reseller to provide a multi-year SaaS and maintenance subscription to the end-users. During the three months ended September 30, 2025, the Company discontinued quoting on this basis, and while any outstanding quotes will be honored, all new quotes for end-user customers wishing to purchase the hardware equipment will be fulfilled through the Company's purchase subscription model going forward.

- removed (2026-05-12):
[0001805385-25-000017:note_history:103]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest income on lease receivables | $ | 24 |  |  | $ | 40 |  |  | $ | 80 |  |  | $ | 123 |  |
| Lease income - operating leases | 22,685 |  |  | 17,909 |  |  | 62,122 |  |  | 47,783 |  |
| Total lease revenue | $ | 22,709 |  |  | $ | 17,949 |  |  | $ | 62,202 |  |  | $ | 47,906 |  |

- removed (2026-05-12):
[0001805385-25-000017:note_history:104]
under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties was $0.5 million and $1.1 million during the three and nine months ended September 30, 2024, respectively. There was no revenue related to leases entered into with related parties during the three and nine months ended September 30, 2025.

- removed (2026-05-12):
[0001805385-25-000017:note_history:105]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Product revenue | $ | 9,242 |  |  | $ | 1,344 |  |  | $ | 14,092 |  |  | $ | 4,789 |  |
| Subscription revenue | 22,685 |  |  | 17,909 |  |  | 62,122 |  |  | 47,783 |  |
| Service revenue | 7,808 |  |  | 6,085 |  |  | 21,224 |  |  | 16,903 |  |
| License fees | 2,280 |  |  | 1,606 |  |  | 7,774 |  |  | 4,047 |  |
| Professional services and other revenue | 835 |  |  | 416 |  |  | 2,189 |  |  | 1,243 |  |
| Total revenue | $ | 42,850 |  |  | $ | 27,360 |  |  | $ | 107,401 |  |  | $ | 74,765 |  |

- removed (2026-05-12):
[0001805385-25-000017:note_history:106]
As discussed in Note 2, Summary of Significant Accounting Policies, the Company implemented a new Rebate Program for eligible resellers. As of September 30, 2025, the Company has accrued $1.1 million related to the Rebate Program, which is included in accrued expenses and other current liabilities in our condensed consolidated balance sheets. As a substantial amount of the Company's revenue with eligible resellers is recognized over-time, the Company recognized $0.2 million and $0.6 million of current portion of contract asset and contract asset, noncurrent in our condensed consolidated balance sheets, respectively, as of September 30, 2025 and recognized $0.2 million and $0.4 million as reduction of revenue for the three and nine months ended September 30, 2025, respectively.

- removed (2026-05-12):
[0001805385-25-000017:note_history:107]
As of September 30, 2025, future minimum noncancelable payments related to leases of the Company's equipment are as follows (in thousands):
