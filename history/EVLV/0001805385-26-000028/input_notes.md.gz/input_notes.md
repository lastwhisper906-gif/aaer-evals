# EVLV notes — 0001805385-26-000028


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001805385-26-000028:notes:1]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company pioneering Artificial Intelligence (“AI”)-powered screening solutions designed to help create safer environments while maintaining efficient visitor flow and a positive visitor experience. The Company serves customers across a range of end markets, including education, healthcare, sports, live entertainment, tourist attractions, houses of worship, and industrial workplaces.

[0001805385-26-000028:notes:2]
[same as prior period, unchanged from 0001805385-25-000017:notes:2]

[0001805385-26-000028:notes:3]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. (“Evolv UK”) and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).

[0001805385-26-000028:notes:4]
[same as prior period, unchanged from 0001805385-25-000017:notes:4]

[0001805385-26-000028:notes:5]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001805385-26-000028:notes:6]
[same as prior period, unchanged from 0001805385-25-000017:notes:6]

[0001805385-26-000028:notes:7]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures, debt obligations, and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of March 31, 2026, the Company had $61.1 million in cash, cash equivalents, and marketable securities, with outstanding debt of $30.0 million and available additional debt of up to $45.0 million, as detailed below. We incurred a net loss of $5.0 million and $1.7 million for the three months ended March 31, 2026 and 2025, respectively, and operating activities resulted in cash outflows of $3.2 million and $2.5 million during the three months ended March 31, 2026 and 2025, respectively. The Company expects to continue to generate losses for the foreseeable future.

[0001805385-26-000028:notes:8]
[same as prior period, unchanged from 0001805385-25-000017:notes:8]

[0001805385-26-000028:notes:9]
On July 29, 2025 (the “Closing Date”), the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's pure subscription sales model. The MidCap Credit Agreement provided an initial $30.0 million term loan facility (the

[0001805385-26-000028:notes:10]
“Initial Term Loan”), a $30.0 million delayed draw facility (the “Delayed Draw Term Loan”) (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit (the “Revolving Credit Facility”), each with a maturity date of July 1, 2030 (collectively, the “Senior Secured Credit Facilities”). On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs paid at closing. As of March 31, 2026, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available. See Note 9, Long-term Debt for additional information.

[0001805385-26-000028:notes:11]
The Company expects its cash, cash equivalents, and marketable securities of $61.1 million as of March 31, 2026, together with cash it expects to generate from future operations and borrowing availability under the Senior Secured Credit Facilities, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth.

[0001805385-26-000028:notes:12]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that began at $106.0 million on December 31, 2025 and increases quarterly thereafter; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum earnings before interest, taxes, depreciation, and amortization ("EBITDA") covenant that takes effect on June 30, 2027. As of March 31, 2026, the minimum required ARR is $107.3 million, and the Company is in full compliance with all applicable covenant requirements, and expects to remain in compliance for a period of at least twelve months from May 12, 2026.

[0001805385-26-000028:notes:13]
There is significant uncertainty in the current geopolitical and macroeconomic environment due to various factors, including but not limited to inflationary pressures globally, conflicts in Europe and the Middle East, and foreign currency volatility and their impacts on the Company’s business. If economic conditions were to worsen, the Company’s results of operations, financial condition, and cash flows from operations may be materially and adversely impacted.

[0001805385-26-000028:notes:14]
[same as prior period, unchanged from 0001805385-25-000017:notes:13]

[0001805385-26-000028:notes:15]
[same as prior period, unchanged from 0001805385-25-000017:notes:14]

[0001805385-26-000028:notes:16]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2026, and for the three months ended March 31, 2026 and 2025 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2025 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2026, the results of its operations for the three months ended March 31, 2026 and 2025 and cash flows for the three months ended March 31, 2026 and 2025. The results for the three months ended March 31, 2026 are not necessarily indicative of results to be expected for the year ending December 31, 2026, any other interim periods, or any future year or period. These interim unaudited condensed consolidated financial statements should be read in conjunction with the financial statements included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2025.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001805385-26-000028:notes:17]
[same as prior period, unchanged from 0001805385-25-000017:notes:21]

[0001805385-26-000028:notes:18]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2025, and the notes thereto, which are included in our 2025 Form 10-K. Except for the estimates used to

[0001805385-26-000028:notes:19]
determine the grant date valuation for certain performance stock units (“PSUs”), as described below, there have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2026.

[0001805385-26-000028:notes:20]
Recently Adopted Accounting Pronouncements

[0001805385-26-000028:notes:21]
In July 2025, the FASB issued ASU 2025-05, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets.”. ASU 2025-05 provides a practical expedient that allows entities to estimate expected credit losses by assuming that current conditions as of the balance sheet date will not change over the remaining life of the asset. The amendment is applied prospectively and is effective for annual periods beginning after December 15, 2025, and interim periods within those annual periods. The Company adopted ASU 2025-05 effective January 1, 2026 and elected to adopt the practical expedient that permits entities to assume that current conditions as of the balance sheet date do not change over the remaining life of the asset when estimating expected credit losses. The adoption did not have a material impact on the Company’s condensed consolidated financial statements or related disclosures.

[0001805385-26-000028:notes:22]
Recently Issued Accounting Pronouncements

[0001805385-26-000028:notes:23]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses.”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Further, in January 2025, the FASB issued ASU 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Clarifying the Effective Date)" to clarify the effective date of ASU 2024-03. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 and ASU 2025-01 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the condensed consolidated financial statements.

[0001805385-26-000028:notes:24]
In September 2025, the FASB issued ASU 2025-06, “Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software.”, which amends guidance on capitalization of software development costs and introduces a probable-to-complete recognition threshold, along with factors to consider for evaluating significant development uncertainty. The amendments are effective for annual reporting periods beginning after December 15, 2027, including interim periods within those annual periods. Early adoption is permitted and this amendment is applied prospectively. The Company is currently evaluating the impact of this ASU on its accounting policies and disclosures within the condensed consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001805385-26-000028:notes:25]
Marketable Securities
Marketable securities as of March 31, 2026 and December 31, 2025 consisted of the following:

[0001805385-26-000028:notes:26]
|  | March 31, 2026 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 4,992 |  |  | $ | — |  |  | $ | 4,992 |  |
| Total marketable securities | $ | 4,992 |  |  | $ | — |  |  | $ | 4,992 |  |

[0001805385-26-000028:notes:27]
|  | December 31, 2025 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 19,885 |  |  | $ | — |  |  | $ | 19,885 |  |
| Total marketable securities | $ | 19,885 |  |  | $ | — |  |  | $ | 19,885 |  |

[0001805385-26-000028:notes:28]
Marketable securities at March 31, 2026 and December 31, 2025 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three months ended March 31, 2026 and 2025. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive loss.


## us-gaap:FairValueDisclosuresTextBlock

[0001805385-26-000028:notes:29]
[same as prior period, unchanged from 0001805385-25-000017:notes:41]

[0001805385-26-000028:notes:30]
|  | Fair Value Measurements at March 31, 2026 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 35,811 |  |  | $ | — |  |  | $ | — |  |  | $ | 35,811 |  |
| Treasury bills | — |  |  | 14,931 |  |  | — |  |  | 14,931 |  |
| Contingently returnable common stock asset | — |  |  | — |  |  | 4,169 |  |  | 4,169 |  |
|  | $ | 35,811 |  |  | $ | 14,931 |  |  | $ | 4,169 |  |  | $ | 54,911 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 392 |  |  | 392 |  |
| Public Warrant liability | 1,818 |  |  | — |  |  | — |  |  | 1,818 |  |
|  | $ | 1,818 |  |  | $ | — |  |  | $ | 392 |  |  | $ | 2,210 |  |

[0001805385-26-000028:notes:31]
|  | Fair Value Measurements at December 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 39,406 |  |  | $ | — |  |  | $ | — |  |  | $ | 39,406 |  |
| Treasury bills | — |  |  | 19,885 |  |  | — |  |  | 19,885 |  |
| Contingently returnable common stock asset | — |  |  | — |  |  | 4,094 |  |  | 4,094 |  |
|  | $ | 39,406 |  |  | $ | 19,885 |  |  | $ | 4,094 |  |  | $ | 63,385 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 374 |  |  | $ | 374 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 1,809 |  |  | 1,809 |  |
| Public Warrant liability | 3,862 |  |  | — |  |  | — |  |  | 3,862 |  |
|  | $ | 3,862 |  |  | $ | — |  |  | $ | 2,183 |  |  | $ | 6,045 |  |

[0001805385-26-000028:notes:32]
Money market funds are included in cash and cash equivalents on the condensed consolidated balance sheets. As of March 31, 2026, U.S. treasury bills with maturities less than 3 months, which totaled $9.9 million, are included in cash and cash equivalents, while treasury bills with maturities greater than 3 months, which totaled $5.0 million, are reflected as marketable securities. As of December 31, 2025, U.S. treasury bills with maturities greater than 3 months, which totaled $19.9 million, are reflected as marketable securities. The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources.

[0001805385-26-000028:notes:33]
[same as prior period, unchanged from 0001805385-25-000017:notes:45]

[0001805385-26-000028:notes:34]
[same as prior period, unchanged from 0001805385-25-000017:notes:46]

[0001805385-26-000028:notes:35]
[same as prior period, unchanged from 0001805385-25-000017:notes:47]

[0001805385-26-000028:notes:36]
During each of the three months ended March 31, 2026 and 2025, there were no transfers between Level 1, Level 2 and Level 3.

[0001805385-26-000028:notes:37]
[same as prior period, unchanged from 0001805385-25-000017:notes:49]

[0001805385-26-000028:notes:38]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our 2025 Form 10-K. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and were remeasured each reporting period through the expiration of the earn-out period. The earn-out period expired on March 8, 2026 without achievement of the required milestones. As a result, the Company has no remaining contingent earn-out liability as of March 31, 2026.

[0001805385-26-000028:notes:39]
The fair value of the contingent earn-out was calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period.

[0001805385-26-000028:notes:40]
[same as prior period, unchanged from 0001805385-25-000017:notes:52]

[0001805385-26-000028:notes:41]
| Balance at December 31, 2025 | $ | 374 |  |
| Change in fair value | (374) |  |
| Balance at March 31, 2026 | $ | — |  |

[0001805385-26-000028:notes:42]
[same as prior period, unchanged from 0001805385-25-000017:notes:55]

[0001805385-26-000028:notes:43]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock which were converted into shares of the Company's stock in connection with the Merger (the “Founder Shares”). Of these shares, 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 unvested shares will vest upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our 2025 Form 10-K ("Vesting Conditions"). The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of March 31, 2026, no milestones have been achieved.

[0001805385-26-000028:notes:44]
Under the Founder Shares arrangement, Founder Shares may be transferred to third parties, subject to certain conditions. The unvested shares must be returned to the Company if the specified Vesting Conditions are not met. As of March 31, 2026, a total of 729,570 unvested shares had been transferred to individual stockholders' brokerage accounts. As of March 31, 2026, the fair value of the unvested shares recorded as additional paid in capital was $3.7 million. The contractual obligation of the holders to return unvested shares upon failure to meet Vesting Conditions is accounted for as a freestanding financial asset in accordance with ASC 815. This asset was initially recognized at fair value and is remeasured at each reporting period. As of March 31, 2026, the Company recognized a $4.2 million contingently returnable common stock asset, which is included in other assets in our condensed consolidated balance sheets.

[0001805385-26-000028:notes:45]
The fair value of the contingently issuable common shares and the contingently returnable common stock asset is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of March 31, 2026 were as follows: 65% expected stock price volatility, a risk-free rate of return of 3.7%, a 5% likelihood of change in control and a remaining term of 0.3 years. The assumed likelihood of change in control was reduced to 5% as of March 31, 2026 from 10% as of December 31, 2025, reflecting the shortened remaining term.

[0001805385-26-000028:notes:46]
[same as prior period, unchanged from 0001805385-25-000017:notes:59]

[0001805385-26-000028:notes:47]
| Balance at December 31, 2025 | $ | 1,809 |  |
| Change in fair value | (1,417) |  |
| Balance at March 31, 2026 | $ | 392 |  |

[0001805385-26-000028:notes:48]
[same as prior period, unchanged from 0001805385-25-000017:notes:61]

[0001805385-26-000028:notes:49]
| Balance at December 31, 2025 | $ | 4,094 |  |
| Change in fair value | 75 |  |
| Balance at March 31, 2026 | $ | 4,169 |  |

[0001805385-26-000028:notes:50]
[same as prior period, unchanged from 0001805385-25-000017:notes:63]

[0001805385-26-000028:notes:51]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. As of March 31, 2026, 14,324,893 Public Warrants are outstanding.

[0001805385-26-000028:notes:52]
[same as prior period, unchanged from 0001805385-25-000017:notes:65]

[0001805385-26-000028:notes:53]
| Balance at December 31, 2025 | $ | 3,862 |  |
| Change in fair value | (2,044) |  |
| Balance at March 31, 2026 | $ | 1,818 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001805385-26-000028:notes:54]
[same as prior period, unchanged from 0001805385-25-000017:notes:67]

[0001805385-26-000028:notes:55]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001805385-26-000028:notes:56]
[same as prior period, unchanged from 0001805385-25-000017:notes:69]

[0001805385-26-000028:notes:57]
In March 2023, the Company entered into a distributor licensing agreement (the "Distribution and License Agreement") with Columbia Electrical Contractors, Inc. ("Columbia Tech"). Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, which had served as the Company's primary contract manufacturer. Under this arrangement, the Company granted a license of its intellectual property to Columbia Tech, which contracted directly with certain of the Company's resellers to fulfill sales demand where the end-user customer preferred to purchase the hardware equipment as

[0001805385-26-000028:notes:58]
opposed to lease the equipment. Columbia Tech paid the Company a hardware license fee for each system it manufactured and sold under the agreement. In these instances, the Company still contracted directly with the reseller to provide a multi-year SaaS and maintenance subscription to the end-users. The Distribution and License Agreement expired on December 31, 2025, and the Company no longer offers the distributor license model.

[0001805385-26-000028:notes:59]
The Company previously assessed whether it operated as the principal or as an agent in relation to the sale of product made by Columbia Tech to the Company's resellers pursuant to the Distribution and License Agreement. The Company considered various factors, including but not limited to, inventory risk, discretion in establishing pricing, and which entity is primarily responsible for fulfillment. Based on an evaluation of the facts and circumstances, the Company concluded that Columbia Tech was the principal in the arrangement. The Company therefore did not recognize revenue in relation to sales of product pursuant to the Distribution and License Agreement, but did recognize revenue in relation to license fees received from Columbia Tech and the SaaS and maintenance subscription contracts, each as further described below.

[0001805385-26-000028:notes:60]
[same as prior period, unchanged from 0001805385-25-000017:notes:72]

[0001805385-26-000028:notes:61]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2026:

[0001805385-26-000028:notes:62]
|  | Less than 1 year |  | 1 - 2 years |  | More than 2 years |  | Total |
| Product revenue | $ | 5,004 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,004 |  |
| Subscription revenue | 69,191 |  |  | 72,105 |  |  | 76,799 |  |  | 218,095 |  |
| Service revenue | 25,259 |  |  | 23,311 |  |  | 26,602 |  |  | 75,172 |  |
| License fee and other revenue | 575 |  |  | 38 |  |  | 78 |  |  | 691 |  |
| Total revenue | $ | 100,029 |  |  | $ | 95,454 |  |  | $ | 103,479 |  |  | $ | 298,962 |  |

[0001805385-26-000028:notes:63]
[same as prior period, unchanged from 0001805385-25-000017:notes:75]

[0001805385-26-000028:notes:64]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is unconditional and only subject to the passage of time.  As of March 31, 2026 and December 31, 2025, the Company had $1.2 million and $0.9 million in current portion of contract assets and both less than $0.1 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001805385-26-000028:notes:65]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $31.0 million during the three months ended March 31, 2026 that was included in the December 31, 2025 deferred revenue balance. The Company recognized revenue of $24.7 million during the three months ended March 31, 2025 that was included in the December 31, 2024 deferred revenue balance.

[0001805385-26-000028:notes:66]
[same as prior period, unchanged from 0001805385-25-000017:notes:78]

[0001805385-26-000028:notes:67]
| Balance at December 31, 2025 | $ | 91,640 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (31,024) |  |
| Revenue deferred | 31,734 |  |
| Balance at March 31, 2026 | $ | 92,350 |  |

[0001805385-26-000028:notes:68]
[same as prior period, unchanged from 0001805385-25-000017:notes:80]

[0001805385-26-000028:notes:69]
|  | Three Months EndedMarch 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Interest income on lease receivables | $ | 15 |  |  | $ | 29 |  |  |  |  |  |
| Lease income - operating leases | 23,148 |  |  | 19,237 |  |  |  |  |  |
| Total lease revenue | $ | 23,163 |  |  | $ | 19,266 |  |  |  |  |  |

[0001805385-26-000028:notes:70]
The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss.

[0001805385-26-000028:notes:71]
[same as prior period, unchanged from 0001805385-25-000017:notes:84]

[0001805385-26-000028:notes:72]
[same as prior period, unchanged from 0001805385-25-000017:notes:85]

[0001805385-26-000028:notes:73]
|  | Three Months EndedMarch 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Product revenue | $ | 13,421 |  |  | $ | 2,322 |  |  |  |  |  |
| Subscription revenue | 23,148 |  |  | 19,237 |  |  |  |  |  |
| Service revenue | 8,589 |  |  | 6,730 |  |  |  |  |  |
| License fees | 172 |  |  | 3,203 |  |  |  |  |  |
| Professional services and other revenue | 998 |  |  | 515 |  |  |  |  |  |
| Total revenue | $ | 46,328 |  |  | $ | 32,007 |  |  |  |  |  |

[0001805385-26-000028:notes:74]
Partner Rebate Program

[0001805385-26-000028:notes:75]
In 2025, the Company implemented a channel partner rebate program (the “Rebate Program”) for eligible resellers. Under the Rebate Program, eligible resellers that attain at least 25% of their current fiscal year total contract value (“TCV”) target (“Annual Target”) in a given quarter are eligible for a rebate based upon a percentage of their TCV for that quarter. In addition, resellers that meet their Annual Target are eligible for a one-time rebate based upon a percentage of their total fiscal year TCV, applied as a credit in the subsequent fiscal year. All rebates are issued as credits against future purchases, and no cash rebates are paid. Unused rebate credits are forfeited in the event of a reseller agreement termination.

[0001805385-26-000028:notes:76]
As of March 31, 2026 and December 31, 2025, the Company has accrued $0.5 million and $1.2 million related to the Rebate Program, respectively, which is included in accrued expenses and other current liabilities in our condensed consolidated balance sheets. As a substantial amount of the Company's revenue from eligible resellers is recognized over-time, rebate liabilities are recognized as contract assets, amortized as reductions to revenue over time, consistent with the recognition of the underlying revenue. As of March 31, 2026, the Company's condensed balance sheet includes $0.2 million and $0.8 million in current portion of contract asset and contract asset, noncurrent, respectively. The Company

[0001805385-26-000028:notes:77]
recognized $0.2 million and $0.6 million of current portion of contract asset and contract asset, noncurrent in our condensed consolidated balance sheets, respectively, as of December 31, 2025. The Company recognized $0.1 million and less than $0.1 million as reduction of revenue for the three months ended March 31, 2026 and 2025, respectively.

[0001805385-26-000028:notes:78]
[same as prior period, unchanged from 0001805385-25-000017:notes:88]

[0001805385-26-000028:notes:79]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $12.3 million and $13.1 million as of March 31, 2026 and December 31, 2025, respectively. During the three months ended March 31, 2026 and 2025, the Company recognized commission expense of $2.3 million and $1.5 million, respectively.

[0001805385-26-000028:notes:80]
[same as prior period, unchanged from 0001805385-25-000017:notes:90]

[0001805385-26-000028:notes:81]
The amount of minimum future leases is based on expected income recognition. As of March 31, 2026, future minimum payments on noncancelable leases are as follows (in thousands):

[0001805385-26-000028:notes:82]
| Year Ending December 31: |  |
| 2026 (nine months remaining) | $ | 69,191 |  |
| 2027 | 72,105 |  |
| 2028 | 46,042 |  |
| 2029 | 25,278 |  |
| 2030 | 5,249 |  |
| Thereafter | 230 |  |
|  | $ | 218,095 |  |


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001805385-26-000028:notes:83]
[same as prior period, unchanged from 0001805385-25-000017:notes:93]

[0001805385-26-000028:notes:84]
There were no changes in the allowance for expected credit losses during the three months ended March 31, 2026.


## us-gaap:InventoryDisclosureTextBlock

[0001805385-26-000028:notes:85]
[same as prior period, unchanged from 0001805385-25-000017:notes:96]

[0001805385-26-000028:notes:86]
|  | March 31,2026 |  | December 31,2025 |
| Raw materials | $ | 2,915 |  |  | $ | 3,273 |  |
| Finished goods |  |  |  |
| Finished goods inventory | 5,254 |  |  | 5,317 |  |
| Uninstalled inventory | 87 |  |  | 727 |  |
| Total | $ | 8,256 |  |  | $ | 9,317 |  |

[0001805385-26-000028:notes:87]
The cost of equipment that has been shipped to a customer, but for which revenue recognition has not started due to the timing of the transfer of control, is included in finished goods inventory until the point in time that the Company transferred control of the equipment to the customer, corresponding to the revenue recognition start date. These amounts are included in Uninstalled inventory in the table above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001805385-26-000028:notes:88]
[same as prior period, unchanged from 0001805385-25-000017:notes:98]

[0001805385-26-000028:notes:89]
|  | March 31,2026 |  | December 31,2025 |
| Computers and telecom equipment | $ | 2,251 |  |  | $ | 2,350 |  |
| Lab equipment | 6,274 |  |  | 6,274 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 590 |  |  | 607 |  |
| Leased equipment | 148,616 |  |  | 140,981 |  |
| Capitalized software | 22,676 |  |  | 20,889 |  |
| Sales demo equipment | 3,038 |  |  | 3,038 |  |
| Vehicles | 604 |  |  | 604 |  |
| Equipment held for lease1 | 8,125 |  |  | 10,628 |  |
| Construction in progress | 179 |  |  | 35 |  |
|  | 192,464 |  |  | 185,517 |  |
| Less: Accumulated depreciation and amortization | (64,625) |  |  | (57,995) |  |
|  | $ | 127,839 |  |  | $ | 127,522 |  |

[0001805385-26-000028:notes:90]
[same as prior period, unchanged from 0001805385-25-000017:notes:100]

[0001805385-26-000028:notes:91]
As of March 31, 2026 and December 31, 2025, the net book value of capitalized software was $14.1 million and $13.6 million, respectively. These amounts include $3.1 million and $2.8 million of cumulative capitalized stock-based compensation costs, respectively. Depreciation and amortization expense related to property and equipment was $6.8 million and $5.5 million for the three months ended March 31, 2026 and 2025, respectively, which included amortization expense of capitalized software of $1.2 million and $0.8 million for the three months ended March 31, 2026 and 2025, respectively.

[0001805385-26-000028:notes:92]
[same as prior period, unchanged from 0001805385-25-000017:notes:102]

[0001805385-26-000028:notes:93]
|  | March 31,2026 |  | December 31,2025 |
| Leased equipment | $ | 148,616 |  |  | $ | 140,981 |  |
| Accumulated depreciation | (49,681) |  |  | (44,653) |  |
| Leased equipment, net | $ | 98,935 |  |  | $ | 96,328 |  |

[0001805385-26-000028:notes:94]
Depreciation expense related to leased equipment was $5.0 million and $4.1 million during the three months ended March 31, 2026 and 2025, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.

[0001805385-26-000028:notes:95]
The Company recorded losses of $0.2 million from disposals of property and equipment during the three months ended March 31, 2026 related to the disposal of previously leased Evolv Express systems primarily in connection with customer upgrades to the second generation of Express systems, which were recorded in cost of subscription revenue. The Company recorded losses of $0.3 million from disposal of property and equipment during the three months ended March 31, 2025 primarily related to the disposal of leased Evolv Express systems, which were recorded in cost of product revenue.


## us-gaap:DebtDisclosureTextBlock

[0001805385-26-000028:notes:96]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001805385-26-000028:notes:97]
|  | March 31,2026 |  | December 31,2025 |
| Term loans payable | $ | 30,000 |  |  | $ | 30,000 |  |
| Less: Unamortized debt issuance cost | (1,335) |  |  | (1,404) |  |
|  | 28,665 |  |  | 28,596 |  |
| Less: Current portion of long-term debt | — |  |  | — |  |
| Long-term debt | $ | 28,665 |  |  | $ | 28,596 |  |

[0001805385-26-000028:notes:98]
On July 29, 2025, the Company entered into the $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's pure subscription sales model. The MidCap Credit Agreement provided for an initial $30.0 million term loan facility (the “Initial Term Loan”), a $30.0 million delayed draw facility (the “Delayed Draw Term Loan”) (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit (the "Revolving Credit Facility”), each with a maturity date of July 1, 2030 (collectively, the “Senior Secured Credit Facilities”). As of March 31, 2026, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available.

[0001805385-26-000028:notes:99]
On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs funded at closing. The total debt issuance costs of $3.7 million, which included $0.3 million of additional issuance costs paid by the Company, have been allocated to each component of the facility in accordance with ASC 835. The Senior Secured Credit Facilities are guaranteed by the Company, and in the future, may be guaranteed by certain material subsidiaries. The Senior Secured Credit Facilities are secured by a first lien on substantially all of the assets of the Company.

[0001805385-26-000028:notes:100]
The Senior Secured Credit Facilities bear interest at a fluctuating rate per annum equal to Term Secured Overnight Financing Rate (“Term SOFR”) and an applicable margin calculated based on earnings before interest, taxes, depreciation, and amortization (“EBITDA”). At closing, the applicable margin on Term SOFR loans was 5.25%. If the event described under the MidCap Credit Agreement related to Term SOFR occurs, a base rate is determined by reference to the higher of (1) the prime rate of Wells Fargo and (2) 2.00%. Interest and principal are payable monthly. Monthly interest payments are due in arrears on the first day of each month.

[0001805385-26-000028:notes:101]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that began at $106.0 million on December 31, 2025 and increases quarterly thereafter; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum EBITDA covenant that takes effect on June 30, 2027. As of March 31, 2026, the minimum required ARR is $107.3 million, and the Company is in full compliance with all applicable covenant requirements.

[0001805385-26-000028:notes:102]
Initial Term Loan

[0001805385-26-000028:notes:103]
The borrowing under the $30.0 million Initial Term Loan is subject to principal repayments beginning in August 2029, following a 48-month interest-only period, and will be repaid in equal installments over the final 12 months of the loan term.

[0001805385-26-000028:notes:104]
As of March 31, 2026, the unamortized debt issuance costs totaled $1.3 million, and are presented as a direct deduction from the carrying amount of the Initial Term Loan on the condensed consolidated balance sheet and are amortized as interest expense using the effective interest method in accordance with ASC 835. Interest expense related to

[0001805385-26-000028:notes:105]
the Initial Term Loan totaled less than $0.7 million for the three months ended March 31, 2026. The interest rate in effect as of March 31, 2026 was approximately 8.92%, which includes Term SOFR of 3.67% and an applicable margin of 5.25%. Interest expense related to the amortization of debt issuance costs totaled less than $0.1 million for the three months ended March 31, 2026. No interest expense was recognized for the three months ended March 31, 2025, as there was no debt outstanding during the period.

[0001805385-26-000028:notes:106]
As of March 31, 2026, future principal payments on long-term debt are as follows (in thousands):

[0001805385-26-000028:notes:107]
| Year Ending December 31: |  |
| 2026 (remaining nine months) | $ | — |  |
| 2027 | — |  |
| 2028 | — |  |
| 2029 | 12,500 |  |
| 2030 | 17,500 |  |
|  | $ | 30,000 |  |

[0001805385-26-000028:notes:108]
Delayed Draw Term Loan and Revolving Credit Facility

[0001805385-26-000028:notes:109]
As of March 31, 2026, no amounts had been drawn under the Delayed Draw Term Loan or Revolving Credit Facility. Unused commitments amounted to $30.0 million and $15.0 million under the Delayed Draw Term Loan and Revolving Credit Facility, respectively, as of March 31, 2026. Debt issuance costs allocated to these facilities are paid regardless of whether the funds are drawn down. Such costs are capitalized as prepaid assets and amortized as interest expense on a straight-line basis over their respective access periods, which end on August 1, 2027 and July 1, 2030 for Delayed Draw Term Loan and Revolving Credit Facility, respectively. As of March 31, 2026, the Company recorded $0.7 million in prepaid expenses and other current assets and $0.9 million in other assets in the condensed consolidated balance sheets for costs associated with Delayed Draw Term Loan and Revolving Credit Facility. As of December 31, 2025, the Company recorded $0.7 million in prepaid expenses and other current assets and $1.1 million in other assets in the condensed consolidated balance sheets for costs associated with Delayed Draw Term Loan and Revolving Credit Facility. Capitalized debt issuance cost is amortized as interest expense on a straight-line basis over the period each facility is available to be drawn. Interest expense related to the amortization of debt issuance costs totaled $0.2 million for the three months ended March 31, 2026. No interest expense related to the amortization of debt issuance costs was recognized for the three months ended March 31, 2025, as there was no debt during the period.

[0001805385-26-000028:notes:110]
The Revolving Credit Facility provides for an unused commitment fee of 0.25% on the undrawn portion of the facility. Interest expense related to the unused commitment fees totaled less than $0.1 million for the three months ended March 31, 2026. No interest expense related to the unused commitment fees was recognized for the three months ended March 31, 2025, as there was no debt during the period.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001805385-26-000028:notes:111]
[same as prior period, unchanged from 0001805385-25-000017:notes:120]

[0001805385-26-000028:notes:112]
The following table summarizes the Company’s stock option activity since December 31, 2025 (in thousands, except for share and per share data):

[0001805385-26-000028:notes:113]
|  | Number ofShares |  | WeightedAverageExercise Price |  | WeightedAverageRemainingContractual Term (in years) |  | AggregateIntrinsic Value |
| Outstanding as of December 31, 2025 | 8,184,004 |  | $ | 1.25 |  |  |  |  |  |
| Exercised | (482,435) |  |  | 0.67 |  |  |  |  |  |
| Outstanding as of March 31, 2026 | 7,701,569 |  | $ | 1.29 |  |  | 4.2 |  | $ | 36,684 |  |
| Vested and expected to vest as of March 31, 2026 | 7,701,569 |  | $ | 1.29 |  |  | 4.2 |  | $ | 36,684 |  |
| Options exercisable as of March 31, 2026 | 7,070,412 |  | $ | 1.09 |  |  | 3.9 |  | $ | 35,037 |  |

[0001805385-26-000028:notes:114]
The aggregate intrinsic value of options is calculated as the difference between the exercise price of the stock options and the fair value of the Company’s common stock for those options that had exercise prices lower than the fair value of the Company’s common stock.

[0001805385-26-000028:notes:115]
[same as prior period, unchanged from 0001805385-25-000017:notes:125]

[0001805385-26-000028:notes:116]
The following table summarizes the Company's restricted stock units activity since December 31, 2025:

[0001805385-26-000028:notes:117]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2025 | 10,660,163 |  |  | $ | 3.85 |  |
| Granted | 3,948,290 |  |  | 5.44 |  |
| Vested | (3,576,310) |  |  | 3.40 |  |
| Forfeited | (184,530) |  |  | 4.71 |  |
| Nonvested as of March 31, 2026 | 10,847,613 |  |  | $ | 4.57 |  |

[0001805385-26-000028:notes:118]
Market‑Condition Stock‑Based Awards

[0001805385-26-000028:notes:119]
Market-based Stock Units

[0001805385-26-000028:notes:120]
During the three months ended March 31, 2025, the Company granted market-based stock units ("MSUs") for which the vesting conditions consist of market-based vesting conditions, determined by the Company's level of achievement of pre-established parameters relating to the performance of the Company's stock price as set by the Board as well as service-based vesting conditions. No MSUs were granted during the three months ended March 31, 2026. Vesting may range from 0% to 200% of the target MSUs granted, based on the achievement of specified market conditions. The

[0001805385-26-000028:notes:121]
awards will be measured at each anniversary of the grant date and will vest following the completion of a performance period, which is generally three years unless shortened in the event of a change in control.

[0001805385-26-000028:notes:122]
Performance Stock Units

[0001805385-26-000028:notes:123]
During the three months ended March 31, 2026, the Company granted performance stock units ("PSUs") with market-based vesting conditions based on the Company's relative total shareholder return percentile ranking compared to the specified stock market index over the applicable performance period, subject to a continued service-based vesting requirement. No PSUs were granted during the three months ended March 31, 2025. The number of PSUs that may vest ranges from 0% to 250% of the target PSUs granted, based on the achievement of the specified market-based measures. The awards vest following the completion of a performance period, which is generally three years, subject to continued service-based vesting requirement, except that the awards may provide for prorated vesting upon a termination by the Company without cause or by the participant for good reason (as defined in the applicable award agreements). The Company may, at its discretion, settle vested PSUs in shares of common stock or in cash equal to the fair value of the shares. The PSUs are accounted for as equity-classified awards.

[0001805385-26-000028:notes:124]
Compensation expense for MSUs and PSUs is based on the estimated value of the awards on the grant date, and is recognized over the period from the grant date through the performance period, regardless of level of achievement of the market conditions. The fair value of the awards was estimated based on a Monte Carlo simulation model, on a weighted average basis:

[0001805385-26-000028:notes:125]
|  | Three Months Ended March 31, |
|  | 2026 |  | 2025 |
| Risk-free interest rate | 3.4% |  | 4.0% |
| Expected term (in years) | 3.0 |  | 3.0 |
| Expected volatility | 83.0% |  | 91.7% |
| Expected dividend yield | 0.0% |  | 0.0% |

[0001805385-26-000028:notes:126]
The following table summarizes the Company's market-condition stock-based awards activity since December 31, 2025:

[0001805385-26-000028:notes:127]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2025 | 1,670,143 |  |  | $ | 4.93 |  |
| Granted | 1,130,835 |  |  | 9.47 |  |
| Nonvested as of March 31, 2026 | 2,800,978 |  |  | $ | 6.77 |  |

[0001805385-26-000028:notes:128]
[same as prior period, unchanged from 0001805385-25-000017:notes:138]

[0001805385-26-000028:notes:129]
[same as prior period, unchanged from 0001805385-25-000017:notes:139]

[0001805385-26-000028:notes:130]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Cost of revenue | $ | 315 |  | $ | 219 |  |  |  |  |
| Research and development | 1,280 |  | 1,115 |  |  |  |  |
| Sales and marketing | 1,566 |  | 1,048 |  |  |  |  |
| General and administrative | 2,426 |  | 1,972 |  |  |  |  |
| Restructuring costs | $ | — |  | $ | 525 |  |  |  |  |
| Total stock-based compensation expense | $ | 5,587 |  | $ | 4,879 |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001805385-26-000028:notes:131]
[same as prior period, unchanged from 0001805385-25-000017:notes:141]

[0001805385-26-000028:notes:132]
The Company’s tax provision and resulting effective tax rate for interim periods are determined using the estimated annual effective tax rate (“AETR”), which is updated each quarter and adjusted for discrete items recognized in the period. For the three months ended March 31, 2026, the AETR reflects expected taxable income of Evolv UK, consistent with its intercompany transfer pricing policy. The forecast is consistent with year-to-date actual results through March 31, 2026, and excludes any mark-to-market adjustments. While the overall tax provision remains immaterial due to the Company's full valuation allowance, a portion of the prior-year net operating losses of Evolv UK expected to be utilized is subject to uncertainty. As a result, a corresponding unrecognized tax benefit has been included within the AETR.

[0001805385-26-000028:notes:133]
[same as prior period, unchanged from 0001805385-25-000017:notes:143]


## us-gaap:EarningsPerShareTextBlock

[0001805385-26-000028:notes:134]
[same as prior period, unchanged from 0001805385-25-000017:notes:145]

[0001805385-26-000028:notes:135]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net loss attributable to common stockholders – basic and diluted | $ | (5,009) |  | $ | (1,689) |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 177,057,656 |  |  | 160,808,391 |  |  |  |  |  |
| Net loss per share attributable to common stockholders – basic and diluted | $ | (0.03) |  |  | $ | (0.01) |  |  |  |  |  |

[0001805385-26-000028:notes:136]
The following potentially dilutive outstanding securities were excluded from the computation of diluted net loss per share attributable to common stockholders because their effect would have been anti-dilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the period:

[0001805385-26-000028:notes:137]
|  | Three Months EndedMarch 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Options issued and outstanding | 7,701,569 |  |  | 17,435,329 |  |  |  |  |  |
| Public Warrants to purchase common stock | 14,324,893 |  |  | 14,324,893 |  |  |  |  |  |
| Warrants to purchase common stock (Finback) | — |  |  | 117,423 |  |  |  |  |  |
| Unvested restricted stock units | 10,847,613 |  |  | 12,713,887 |  |  |  |  |  |
| Unvested market-based and performance stock units* | 2,800,978 |  |  | 1,456,225 |  |  |  |  |  |
| Earn-out shares* | — |  |  | 15,000,000 |  |  |  |  |  |
| Contingently issuable common stock* | 1,167,930 |  |  | 1,897,500 |  |  |  |  |  |
|  | 36,842,983 |  |  | 62,945,257 |  |  |  |  |  |

[0001805385-26-000028:notes:138]
*Issuance of MSUs, PSUs, Earn-out shares, and Contingently issuable common stock is contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001805385-26-000028:notes:139]
Commitments and Contingencies
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. Below is a summary of the various types of matters subject to this guidance.

[0001805385-26-000028:notes:140]
Indemnification Agreements

[0001805385-26-000028:notes:141]
In the ordinary course of business, the Company provides indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. Based on historical experience and evaluation of the agreements, we do not believe that any payments related to our indemnities will have a material impact on our financial condition or results of operations.

[0001805385-26-000028:notes:142]
Legal Proceedings

[0001805385-26-000028:notes:143]
We are from time to time subject to various claims, lawsuits, government and regulatory examinations, inquiries, information requests and investigations, and other legal and administrative proceedings arising in the ordinary course of business. The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

[0001805385-26-000028:notes:144]
General Litigation

[0001805385-26-000028:notes:145]
Class Action Lawsuits

[0001805385-26-000028:notes:146]
On March 25, 2024 and November 1, 2024, putative class action lawsuits were filed against the Company in the United States District Court for the District of Massachusetts. On December 13, 2024, the Court consolidated the two lawsuits into one action (the “Class Action”), pursuant to which a consolidated amended complaint was filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees. The Company filed its motion to dismiss the Class Action on March 28, 2025, and the Class Action Plaintiffs filed their opposition to the motion to dismiss on June 24, 2025. On June 30, 2025, the Court issued an order staying the Class Action, including disposition on the motion to dismiss, pending settlement negotiations. On August 5, 2025, the parties to the Class Action engaged in mediation and reached a settlement in principle in the amount of $15.0 million, which is subject to negotiation of definitive documentation and court approval, of which the Company estimated that $14.0 million would be funded by the Company's Directors and Officers insurance coverage. On August 19, 2025, after receiving notice of the anticipated settlement agreement, the Court denied the motion to dismiss with leave to renew if warranted. On April 13, 2026, Class Action Plaintiffs filed a motion for preliminary approval of the settlement agreement. On April 16, 2026, the Court granted preliminary approval of the settlement agreement, stayed all proceedings in the Class Action other than to carry out and enforce the settlement agreement, and scheduled a final fairness hearing for September 24, 2026.

[0001805385-26-000028:notes:147]
The Company has previously recognized a settlement accrual of $15.0 million and an estimated insurance recovery of $14.0 million, which remain in accrued expenses and other current liabilities and prepaid and other current assets in the condensed consolidated balance sheets as of December 31, 2025, respectively, representing management's best estimate of the outcome. The Company was subsequently notified that an additional $0.3 million will be recovered and has adjusted the insurance recovery receivable to $14.3 million as of March 31, 2026. The related adjustment was recorded in general and administrative expense in the condensed consolidated statements of operations and comprehensive loss during the three months ended March 31, 2026.

[0001805385-26-000028:notes:148]
Derivative Lawsuits

[0001805385-26-000028:notes:149]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.

[0001805385-26-000028:notes:150]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “First Delaware Derivative Action”). The First Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. The First Delaware Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.

[0001805385-26-000028:notes:151]
On October 2, 2025, another shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Second Delaware Derivative Action”). The Second Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers and directors, NHIC directors and officers, and nominally against the Company. Plaintiff Robert Patrick, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duties, unjust enrichment, abuse of control, gross mismanagement, and waste of corporate

[0001805385-26-000028:notes:152]
assets, seeking various forms of relief, including equitable relief directing reform of corporate governance and internal controls, monetary damages including restitution and other fees, and a declaration that the individual defendants breached or aided and abetted breaches of fiduciary duties. On November 7, 2025, the Delaware Court of Chancery entered an order staying the Second Delaware Derivative Action pending the outcome of renewed motions to dismiss or final disposition of the Class Action.

[0001805385-26-000028:notes:153]
On May 4, 2026, the Company reached an agreement in principle to settle the Massachusetts Derivative Action, the First Delaware Derivative Action, and the Second Delaware Derivative Action. The proposed settlement is subject to the execution of definitive settlement documentation and court approval. The Company has agreed to implement certain corporate governance reforms and to cause the Company’s directors’ and officers’ liability insurance carriers to pay plaintiffs’ counsel a fee of $1.3 million. The Company does not expect the proposed settlement to have a material adverse effect on its condensed consolidated balance sheet, condensed consolidated statements of operations and comprehensive loss, and condensed consolidated statements of cash flows.

[0001805385-26-000028:notes:154]
Regulatory and Governmental Matters

[0001805385-26-000028:notes:155]
In February 2024, the Company received a subpoena from the Division of Enforcement of the Securities and Exchange Commission (the “SEC”), requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York (the “DOJ”) relating to a previously disclosed investigation and related restatement of prior period financial statements, and has since received additional requests for documents and information relating to this matter. By letter dated August 7, 2025, the DOJ informed the Company that the Company is no longer the subject of a DOJ investigation.

[0001805385-26-000028:notes:156]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of such matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.

[0001805385-26-000028:notes:157]
Any resolution or litigation with the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to the SEC matter. In addition to the expected insurance recovery discussed above related to the Class Action litigation, the Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matters, including certain expenses that have previously been paid, are also expected to be reimbursed. The Company recognized estimated loss recoveries related to insurance coverage for these matters of $1.1 million and $3.9 million for the three months ended March 31, 2026 and 2025, respectively, which were recorded as reductions of general and administrative expense in the condensed consolidated statements of operations and comprehensive loss. These amounts reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company has determined are probable of recovery. During the three months ended March 31, 2026, $1.2 million of these recoveries were paid out by the Company's insurance provider. No insurance recoveries were paid out during the three months ended March 31, 2025. As of March 31, 2026 and December 31, 2025, remaining estimated recoveries of $1.2 million and $1.3 million were included in prepaid and other current assets in the condensed consolidated balance sheets, respectively.

[0001805385-26-000028:notes:158]
As it relates to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or

[0001805385-26-000028:notes:159]
that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated recoveries.

[0001805385-26-000028:notes:160]
Contract manufacturers

[0001805385-26-000028:notes:161]
The Company generally contracts with its contract manufacturers on a cancellable, purchase-order basis. The Company has a contract in the normal course of business with its contract manufacturers to provide manufacturing services for the Company's equipment sold or leased to customers. While these contracts are cancellable by the Company upon prior notice, payments due upon cancellation consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. These payments are not determinable, but could result in a material purchase commitment if the Company were to cancel their open purchase orders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001805385-26-000028:notes:162]
Segment Information
The Company determined that it has one operating and reporting segment after considering the Company’s organizational structure and the information regularly reviewed and evaluated by the Company’s Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources and assess performance. The Company has determined that its CODM is its President and Chief Executive Officer. The CODM evaluates the performance of our segment based upon consolidated net income and considers budget-to-actual or forecast-to-actual variances to assess performance and make decisions about allocating resources. The CODM evaluates segment assets based on total assets on the consolidated balance sheets. Asset information is not presented here because its presentation here would be duplicative of the consolidated balance sheets. On the basis of these factors, the Company determined that it operates and manages its business as one operating and reporting segment, that develops, manufactures, markets and sells security screening products and specific services, and accordingly has one reportable segment for financial reporting purposes.

[0001805385-26-000028:notes:163]
[same as prior period, unchanged from 0001805385-25-000017:notes:179]

[0001805385-26-000028:notes:164]
|  | Three Months EndedMarch 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Segment revenue | $ | 46,328 |  |  | $ | 32,007 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |
| Employee expense | 19,270 |  |  | 16,369 |  |  |  |  |  |
| Stock-based compensation expense1 | 5,587 |  |  | 4,354 |  |  |  |  |  |
| Other non-recurring expenses2 | (99) |  |  | 3,561 |  |  |  |  |  |
| Consulting and contract staffing | 3,094 |  |  | 3,277 |  |  |  |  |  |
| Depreciation and amortization | 6,801 |  |  | 5,529 |  |  |  |  |  |
| Restructuring costs | — |  |  | 2,662 |  |  |  |  |  |
| Other cost of revenue | 13,269 |  |  | 5,688 |  |  |  |  |  |
| Other operating expenses | 6,878 |  |  | 4,956 |  |  |  |  |  |
| Other segment items3 | (3,463) |  |  | (12,700) |  |  |  |  |  |
| Segment net loss4 | $ | (5,009) |  |  | $ | (1,689) |  |  |  |  |  |

[0001805385-26-000028:notes:165]
1 For the three months ended March 31, 2025, excludes incremental expense related to modified awards included in the Restructuring costs line. See Note 15, Restructuring Charges for additional information.

[0001805385-26-000028:notes:166]
2 For the three months ended March 31, 2026 and 2025, includes consulting and legal fees and additional audit fees incurred in connection with a previously disclosed investigation and restatement of prior period financial statements, net of estimated insurance recoveries.

[0001805385-26-000028:notes:167]
[same as prior period, unchanged from 0001805385-25-000017:notes:183]

[0001805385-26-000028:notes:168]
4 Certain prior year amounts have been reclassified to conform to the current year presentation. These reclassifications had no impact on previously reported total segment net loss.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001805385-26-000028:notes:169]
Restructuring Charges
In January 2025, the Company implemented a Board-approved reduction in force affecting 41 members of its workforce. This action was part of the Company’s initiative to increase its profitability and cash flow as the Company seeks further flexibility to pursue its investment strategy with certain growth opportunities.

[0001805385-26-000028:notes:170]
[same as prior period, unchanged from 0001805385-25-000017:notes:185]

[0001805385-26-000028:notes:171]
All actions related to the reduction in force were completed by March 31, 2025, with the exception of certain severance obligations that were payable over various periods through November 2025 under the Company's Severance And Change In Control Plan. All amounts were paid out prior to December 31, 2025.
