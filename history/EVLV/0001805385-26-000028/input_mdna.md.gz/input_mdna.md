# EVLV MD&A — 0001805385-26-000028


## mdna

[0001805385-26-000028:mdna:1]
[same as prior period, unchanged from 0001805385-25-000017:mdna:1]

[0001805385-26-000028:mdna:2]
[same as prior period, unchanged from 0001805385-25-000017:mdna:2]

[0001805385-26-000028:mdna:3]
[same as prior period, unchanged from 0001805385-25-000017:mdna:3]

[0001805385-26-000028:mdna:4]
Evolv, a Delaware corporation formed in 2021, is a leading security technology company pioneering Artificial Intelligence (“AI”)-powered screening solutions designed to help create safer environments while maintaining efficient visitor flow and a positive visitor experience. We serve customers across a range of end markets, including education, healthcare, sports, live entertainment, tourist attractions, houses of worship, and industrial workplaces. Our mission is to make the world a safer and more enjoyable place to live, work, learn, and play. Our goal is to help facility operators address escalating gun violence, mass shootings and terrorist attacks while maintaining a positive visitor experience.

[0001805385-26-000028:mdna:5]
Our solutions are delivered through a Security-as-a-Service model that integrates our proprietary sensor platform and AI-powered software, cloud connectivity, and ongoing services. We deliver our solutions through two sales models: a pure subscription model and a purchase subscription model, each of which requires both hardware and an active, connected software subscription. We believe this integrated approach reflects the full scope of our offering and aligns our long-term interests with those of our customers.

[0001805385-26-000028:mdna:6]
Our hardware platforms are uniquely designed and purpose engineered for real world, high throughput security environments and are the foundational component of our solutions. Evolv Express® and Evolv eXpedite™ operate exclusively with Evolv’s proprietary software and cloud services. When deployed together, the two products are designed to support improved operational efficiency through better threat identification and alarm performance. We believe our ability to deliver continuous improvement through software upgrades differentiates our platform from many legacy hardware only offerings.

[0001805385-26-000028:mdna:7]
Our platform was designed from inception around AI operating in physical environments. Our AI powered software and services are central to the performance and long-term value of our platform. Through continuous operation across a large and growing installed base, our systems generate substantial volumes of anonymized screening data related to the movement of people and bags through physical spaces. We train our models on a proprietary data set and can improve the system performance through new and updated algorithms, which customers receive from us through software updates.

[0001805385-26-000028:mdna:8]
We focus on weapons detection and offer two core solutions that can be deployed independently or together and are supported by data and visual dashboards that provide actionable analytics and automated reports designed to help security teams make evidence-based decisions to strengthen security. Evolv Express is designed to screen high volumes of people for concealed threats, while Evolv eXpedite is designed to screen high volumes of bags automatically, without requiring a trained X-Ray operator. When deployed together, these solutions provide a layered security approach that allows customers to operate at heightened sensitivity levels while seeking to maintain efficient throughput and a positive visitor experience.

[0001805385-26-000028:mdna:9]
[same as prior period, unchanged from 0001805385-25-000017:mdna:9]

[0001805385-26-000028:mdna:10]
In addition to screening capabilities, our subscription includes Evolv Insights®, our cloud-based analytics solution that provides customers with operational visibility into system performance across their venues or facilities. Available data includes throughput volumes, alarm statistics, detection settings, and system performance metrics, which customers can use to inform security operations, staffing decisions, and checkpoint configuration.

[0001805385-26-000028:mdna:11]
Our offering is bundled together by the services included in our subscription. We recognize that the primary mission of our customers is typically not security. Our customers’ mission might be educating children, restoring patients to good health, or entertaining fans in their seats. Our subscription includes full onsite support and repair services for the full term, so that our customers can focus on what they do best while we make sure their equipment is operating as designed.  We are security as a service, from the hardware to the software to the data to the support.

[0001805385-26-000028:mdna:12]
Our platform incorporates both hardware and software components that are deployed across a large number of operating venues. Each deployed unit functions not only as a detection device but also as a data collection mechanism, generating ongoing real‑world operational data, including both threat and non‑threat events. Some of this data is used to support the continued development and refinement of our algorithms. We believe the integration of our hardware and software creates operational interdependencies that are integral to our platform. As a result, the hardware and software components of our system are designed to operate together and are not intended to function as standalone offerings, which distinguishes our approach from cloud‑only software solutions.

[0001805385-26-000028:mdna:13]
We believe our hardware-enabled, long term subscription model differentiates our business from purely software-as-a-service offerings. We believe our platform is well positioned to benefit from ongoing advances in artificial intelligence, driving durable customer value and supporting predictable, recurring subscription revenue.

[0001805385-26-000028:mdna:14]
[same as prior period, unchanged from 0001805385-25-000017:mdna:8]

[0001805385-26-000028:mdna:15]
Our customers include many iconic venues across a wide variety of industries, including major sports stadiums and arenas, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, hospitals, large industrial workplaces, schools, and prominent houses of worship.

[0001805385-26-000028:mdna:16]
Key indicators of our performance of market acceptance and customer adoption include Annual Recurring Revenue (“ARR”), a measure of annualized recurring subscription and related service revenue, and Remaining Performance Obligation (“RPO”), a measure of expected future revenue from active customer contracts. We believe these indicators reflect the scale, durability, and growth of our Security‑as‑a‑Service model.

[0001805385-26-000028:mdna:17]
[same as prior period, unchanged from 0001805385-25-000017:mdna:10]

[0001805385-26-000028:mdna:18]
[same as prior period, unchanged from 0001805385-25-000017:mdna:11]

[0001805385-26-000028:mdna:19]
[same as prior period, unchanged from 0001805385-25-000017:mdna:12]

[0001805385-26-000028:mdna:20]
On November 5, 2025, we entered into a non-exclusive contract manufacturing agreement with Plexus Corp. (“Plexus”). This shift is part of a broader supply chain strategy aimed at enhancing scalability, geographic diversification, creating long-term cost-saving opportunities, and operational resiliency. As Plexus is brought onboard, we believe we maintain sufficient inventory and committed production capacity to meet our growth targets with our existing contract manufacturer, ensuring uninterrupted service and consistent delivery to customers.

[0001805385-26-000028:mdna:21]
We regularly evaluate our supply chain structure to mitigate risks, including supplier concentration and dependencies, global chipset and semiconductor supply constraints, including memory and compute components used in AI‑enabled products, long and variable lead times, cost volatility, and supplier allocation practices. While we are actively managing the effects of these global market conditions on the supply of certain components, there can be no assurance that supplier capacity constraints, inventory availability, or supply‑chain disruptions will not impact our ability to meet customer demand in future periods. We continue to monitor risks associated with supplier onboarding, logistics, and

[0001805385-26-000028:mdna:22]
supplier performance. These factors may influence cost of revenue, inventory levels, working capital, and our ability to meet customer demand in future periods.

[0001805385-26-000028:mdna:23]
[same as prior period, unchanged from 0001805385-25-000017:mdna:15]

[0001805385-26-000028:mdna:24]
We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of rising inflation and interest rates on business spending; supply chain constraints, operational challenges, and the impacts on our manufacturing capabilities; public health emergencies; geopolitical conflicts and war, including the conflicts in Europe and the Middle East; and recessionary trends. See the risk factor titled “Our operating results may fluctuate for a variety of reasons, including our failure to close large volume opportunity customer sales” in Item 1A. Risk Factors of this Quarterly Report on Form 10-Q. While these factors continue to evolve, we plan to remain flexible and optimize our business as appropriate and allocate resources, as necessary.

[0001805385-26-000028:mdna:25]
[same as prior period, unchanged from 0001805385-25-000017:mdna:17]

[0001805385-26-000028:mdna:26]
We believe the world will continue to focus on the safety and security of people in the places where they gather. Many of these locations, such as professional sports venues, educational institutions, and healthcare facilities, are moving toward a more frictionless security screening experience. We are well-positioned to take advantage of this opportunity due to our proprietary technologies and distribution capabilities. Our products are designed to empower venues and facilities to realize the full benefits of advanced security screening, including rapid visitor throughput and minimal security staff to screened visitor physical contact. We expect that our results of operations, including revenue, will fluctuate for the foreseeable future as venues and facilities continue to shift away from conventional security screening processes towards touchless security screening or consider security screening processes for the first time. The degree to which potential and current customers recognize these benefits and invest in our products will affect our financial results.

[0001805385-26-000028:mdna:27]
[same as prior period, unchanged from 0001805385-25-000017:mdna:19]

[0001805385-26-000028:mdna:28]
We sell our solutions under two primary sales models. We offer a “pure subscription” model, where the customer leases hardware from us and we provide a multi-year security-as-a-service subscription. For end-user customers that prefer to purchase our hardware outright, we offer customers the option of purchasing our hardware outright directly from us through our “purchase subscription” model that also includes a multi-year security and software-as-a-service subscription. In addition to our two primary sales models, we have historically offered our “distributor licensing” model based on the Distribution and License Agreement we entered into with Columbia Tech in March of 2023. Under this arrangement, we have granted a license of our intellectual property to Columbia Tech, which contracts directly with certain of our resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment. Columbia Tech pays us a hardware license fee for each system it manufactures and sells under this agreement. In these instances, we still contract directly with the reseller to provide a multi-year security-as-a-service subscription to the end-users. During the three months ended September 30, 2025, we discontinued quoting on this basis, and the agreement with Columbia Tech expired on December 31, 2025. All new quotes for end-user customers wishing to purchase the hardware equipment will be fulfilled through our purchase subscription model going forward. Thus, license revenue from this agreement is expected to reduce to zero over time, replaced by increased product revenue, which will in turn provide an increase in gross profit over the duration of the contract. We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our revenue, gross profit, gross margin, and overall profitability in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments.

[0001805385-26-000028:mdna:29]
Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions. While adoption of our products has primarily been within the United States to date, we expect increased adoption of our products in foreign markets in the near future as we explore expansion into international markets. Pricing may vary by region or vertical market due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales and business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce AI-powered security screening solutions to our customers.

[0001805385-26-000028:mdna:30]
[same as prior period, unchanged from 0001805385-25-000017:mdna:23]

[0001805385-26-000028:mdna:31]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $46.3 million and $32.0 million for the three months ended March 31, 2026 and 2025, respectively. We generated a net loss of $5.0 million and $1.7 million for the three months ended March 31, 2026 and 2025, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling the use of third-party contract manufacturers, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001805385-26-000028:mdna:32]
Certain Key Metrics and Non-GAAP Financial Measures

[0001805385-26-000028:mdna:33]
ARR. We believe annual recurring revenue (“ARR”) is a useful metric for investors because it provides visibility into the scale and sustainability of our recurring revenue base. ARR reflects the annualized value of active subscription arrangements at a point in time and helps investors evaluate trends in customer and unit acquisition, retention, and expansion. As our business continues to shift toward pure subscription and purchase subscription sales models (and away from our legacy distribution subscription model), we believe ARR more accurately captures the recurring nature of our revenue compared to period based revenue measures alone. Management also uses ARR to assess operating performance, inform strategic decisions, and plan for future growth, because it is impacted by multiple dimensions of our business, including new customer and unit acquisition, customer pricing, renewal history, and renewal pricing.

[0001805385-26-000028:mdna:34]
We define ARR as the sum of subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter all multiplied by twelve. The amount of revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly due to differences in our recurring and non-recurring revenue streams. To the extent that we are negotiating a renewal or upgrade with a customer after the expiration of the subscription and we are continuing to provide service to that customer, we may continue to include that associated revenue in ARR. If a customer notifies us that it is not renewing its subscription, we will continue to include associated revenue in ARR through the natural expiration of the subscription term. ARR should be viewed independently of, and not as a substitute for or forecast of, revenue or deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001805385-26-000028:mdna:35]
As of March 31, 2026, ARR was $127.3 million, compared to $106.0 million as of March 31, 2025, representing year over year growth of 20%. This increase was driven by the addition of nearly 250 customers during 2025, expanded deployments by existing customers and increased demand for our pure subscription and purchase subscription sales models which generate a higher proportion of recurring revenue compared to our legacy distribution subscription sales model (see "Sales Models”).

[0001805385-26-000028:mdna:36]
RPO. We believe Remaining Performance Obligation ("RPO"), a measure of expected future revenue from active customers, to be a key indicator of our performance. As disclosed in Note 5 to our financial statements, RPO at March 31, 2026 was $299.0 million, an increase of approximately 2% from December 31, 2025, driven by continued market demand.

[0001805385-26-000028:mdna:37]
Adjusted EBITDA. We believe Adjusted Earnings Before Interest, Taxes, Depreciation and Amortization (“Adjusted EBITDA”) is a useful metric for investors because it provides insight into the underlying operating performance of our business by excluding items that are not indicative of our core operating results or that may vary significantly from period to period. Adjusted EBITDA facilitates period-to-period comparisons of our operating performance and enhances investors’ ability to evaluate trends in profitability and operating leverage. In addition, Adjusted EBITDA helps investors better understand the impact of our cost structure and operating efficiency as we scale our business, independent of non‑cash expenses, financing decisions, tax structure, and certain non‑recurring or non‑operational items. While Adjusted EBITDA should be considered in conjunction with our GAAP financial results, we believe it provides supplemental information that enhances investors’ understanding of the performance of our business.

[0001805385-26-000028:mdna:38]
Management uses Adjusted EBITDA internally to assess operating performance, monitor cost discipline, and evaluate the efficiency of our business as we scale. Adjusted EBITDA is a key metric used by management to measure the profitability of our core operations and to assess the impact of operating decisions across the organization. Management reviews Adjusted EBITDA trends to inform strategic decisions related to expense management, investment prioritization, and resource allocation. Because Adjusted EBITDA excludes certain non‑cash and non‑recurring items, it allows management to better evaluate underlying operating performance and comparability across reporting periods. By

[0001805385-26-000028:mdna:39]
monitoring Adjusted EBITDA over time, management is able to assess progress toward profitability objectives and make informed decisions regarding long-term operational and financial planning.

[0001805385-26-000028:mdna:40]
Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, stock based compensation, interest expense (income), provision for income taxes, change in fair value of contingent earn out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of leased equipment, loss on impairment of intangible asset, loss on disposal of leased equipment, non-recurring employee restructuring and other separation costs, non-recurring inventory charges, and other non-recurring legal and regulatory costs, which management believes provides a more meaningful representation of operating results.

[0001805385-26-000028:mdna:41]
The following table presents a reconciliation of net income, the most directly comparable GAAP financial measure, to Adjusted EBITDA for each of the periods indicated:

[0001805385-26-000028:mdna:42]
|  | Three Months EndedMarch 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Net loss | $ | (5,009) |  |  | $ | (1,689) |  |  |  |  |  |
| Depreciation and amortization | 6,801 |  |  | 5,530 |  |  |  |  |  |
| Stock-based compensation | 5,587 |  |  | 4,879 |  |  |  |  |  |
| Interest expense (income) | 447 |  |  | (388) |  |  |  |  |  |
| Provision for income taxes | (37) |  |  | 63 |  |  |  |  |  |
| Change in fair value of contingent earn-out liability | (374) |  |  | (8,976) |  |  |  |  |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | (1,492) |  |  | (1,653) |  |  |  |  |  |
| Change in fair value of public warrant liability | (2,044) |  |  | (1,721) |  |  |  |  |  |
| Loss on disposal of leased equipment | 164 |  |  | 321 |  |  |  |  |  |
| Non-recurring employee restructuring and other separation costs | — |  |  | 2,137 |  |  |  |  |  |
| Other non-recurring legal and regulatory costs | (99) |  |  | 3,561 |  |  |  |  |  |
| Adjusted EBITDA | $ | 3,944 |  |  | $ | 2,064 |  |  |  |  |  |

[0001805385-26-000028:mdna:43]
For the three months ended March 31, 2026, Adjusted EBITDA was $3.9 million, compared to $2.1 million for the three months ended March 31, 2025, representing an improvement of $1.9 million year-over‑year. This improvement was primarily driven by revenue growth, increased operating leverage, and continued discipline in managing operating expenses, partially offset by higher investments to support growth initiatives and customer deployments.

[0001805385-26-000028:mdna:44]
[same as prior period, unchanged from 0001805385-25-000017:mdna:25]

[0001805385-26-000028:mdna:45]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations and our Senior Secured Credit Facilities. See “Liquidity and Capital Resources” as well as “Risks Related to Our Financial Condition and Liquidity” for more information. Additionally, as discussed in Note 13, Commitments and Contingencies, to our condensed consolidated financial statements for the three months ended March 31, 2026, we are involved in certain legal proceedings, including a government investigation. Given the uncertainty of such matters, no assurance can be given regarding the final outcome of such matters. However, the ultimate amount or range of potential loss, which might result to the Company, may differ materially from our current estimates.

[0001805385-26-000028:mdna:46]
[same as prior period, unchanged from 0001805385-25-000017:mdna:27]

[0001805385-26-000028:mdna:47]
[same as prior period, unchanged from 0001805385-25-000017:mdna:65]

[0001805385-26-000028:mdna:48]
[same as prior period, unchanged from 0001805385-25-000017:mdna:28]

[0001805385-26-000028:mdna:49]
[same as prior period, unchanged from 0001805385-25-000017:mdna:29]

[0001805385-26-000028:mdna:50]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement, (4) license fees related to the Distribution and License Agreement, and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax. To the extent that we see an increase in demand for our pure subscription model, we would expect to see a reduction in upfront revenue recognition in favor of more recurring revenue.

[0001805385-26-000028:mdna:51]
[same as prior period, unchanged from 0001805385-25-000017:mdna:31]

[0001805385-26-000028:mdna:52]
We derive a portion of our revenue from the sale of our Evolv Express and eXpedite equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We anticipate future growth in product revenue as more customers purchase systems through our purchase subscription model instead of through the now cancelled Distribution and License agreement with Columbia Tech.

[0001805385-26-000028:mdna:53]
[same as prior period, unchanged from 0001805385-25-000017:mdna:33]

[0001805385-26-000028:mdna:54]
Subscription revenue consists of revenue derived from leasing Evolv Express and eXpedite systems to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases and recognized ratably over the duration of the lease. There are no contingent lease payments as part of these arrangements.

[0001805385-26-000028:mdna:55]
[same as prior period, unchanged from 0001805385-25-000017:mdna:35]

[0001805385-26-000028:mdna:56]
[same as prior period, unchanged from 0001805385-25-000017:mdna:36]

[0001805385-26-000028:mdna:57]
[same as prior period, unchanged from 0001805385-25-000017:mdna:37]

[0001805385-26-000028:mdna:58]
[same as prior period, unchanged from 0001805385-25-000017:mdna:38]

[0001805385-26-000028:mdna:59]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from Columbia Tech to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration. Revenue for professional services and other one-time revenue, which had previously been included in service revenue, has been reclassified for prior periods to License fee and other revenue on the consolidated statements of operations and comprehensive loss. During the three months ended September 30, 2025, we discontinued quoting under this basis, and the agreement with Columbia Tech expired on December 31, 2025. All new quotes for end-user customers wishing to purchase the hardware equipment will be fulfilled through our purchase subscription model going forward. Thus, license revenue from this agreement is expected to be reduced to zero over time, replaced by increased product revenue, which will in turn provide an increase in gross profit over the duration of the contract.

[0001805385-26-000028:mdna:60]
[same as prior period, unchanged from 0001805385-25-000017:mdna:80]

[0001805385-26-000028:mdna:61]
[same as prior period, unchanged from 0001805385-25-000017:mdna:40]

[0001805385-26-000028:mdna:62]
[same as prior period, unchanged from 0001805385-25-000017:mdna:41]

[0001805385-26-000028:mdna:63]
[same as prior period, unchanged from 0001805385-25-000017:mdna:42]

[0001805385-26-000028:mdna:64]
[same as prior period, unchanged from 0001805385-25-000017:mdna:43]

[0001805385-26-000028:mdna:65]
[same as prior period, unchanged from 0001805385-25-000017:mdna:44]

[0001805385-26-000028:mdna:66]
Cost of subscription revenue consists primarily of depreciation expense related to leased units, an allocated portion of internal-use software amortization expense, shipping costs, and maintenance costs related to leased units. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies. Service-related costs reflected in cost of subscription revenue include, in part, the Company’s decision to in-source certain technical and field services support functions that were previously outsourced to a third-party service provider.

[0001805385-26-000028:mdna:67]
[same as prior period, unchanged from 0001805385-25-000017:mdna:47]

[0001805385-26-000028:mdna:68]
Cost of service revenue consists of maintenance costs related to units purchased by customers and an allocated portion of internal-use software amortization expense. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies. Service-related costs reflected in cost of service revenue include, in part, the Company’s decision to in-source certain technical and field services support functions that were previously outsourced to a third-party service provider.

[0001805385-26-000028:mdna:69]
[same as prior period, unchanged from 0001805385-25-000017:mdna:49]

[0001805385-26-000028:mdna:70]
Cost of license fee and other revenue consists primarily of internal and third-party costs related to professional services, such as installation, training, and event support. License fee revenue earned under our Distribution and License Agreement with Columbia Tech has no associated cost of revenue.

[0001805385-26-000028:mdna:71]
Gross Profit and Gross Profit Margin

[0001805385-26-000028:mdna:72]
Our gross profit is calculated based on the difference between our revenues and cost of revenues. Gross profit margin is the percentage obtained by dividing gross profit by our revenue.

[0001805385-26-000028:mdna:73]
[same as prior period, unchanged from 0001805385-25-000017:mdna:53]

[0001805385-26-000028:mdna:74]
•Mix of sales between our pure subscription and purchase subscription models;

[0001805385-26-000028:mdna:75]
[same as prior period, unchanged from 0001805385-25-000017:mdna:55]

[0001805385-26-000028:mdna:76]
[same as prior period, unchanged from 0001805385-25-000017:mdna:56]

[0001805385-26-000028:mdna:77]
[same as prior period, unchanged from 0001805385-25-000017:mdna:57]

[0001805385-26-000028:mdna:78]
[same as prior period, unchanged from 0001805385-25-000017:mdna:58]

[0001805385-26-000028:mdna:79]
[same as prior period, unchanged from 0001805385-25-000017:mdna:59]

[0001805385-26-000028:mdna:80]
We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our gross profit and gross profit margin in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments.

[0001805385-26-000028:mdna:81]
7

[0001805385-26-000028:mdna:82]
[same as prior period, unchanged from 0001805385-25-000017:mdna:61]

[0001805385-26-000028:mdna:83]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, stock-based compensation, prototypes, design expenses, and consulting and contractor costs. We expect our research and development costs to increase for the year ending December 31, 2026 compared to the year ended December 31, 2025 as we continue to invest in product innovation.

[0001805385-26-000028:mdna:84]
[same as prior period, unchanged from 0001805385-25-000017:mdna:63]

[0001805385-26-000028:mdna:85]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will increase modestly for the year ending December 31, 2026 compared to the year ended December 31, 2025 as we expand our go to market efforts through both direct and channel investments.

[0001805385-26-000028:mdna:86]
[same as prior period, unchanged from 0001805385-25-000017:mdna:66]

[0001805385-26-000028:mdna:87]
General and administrative expenses consist primarily of personnel related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and insurance, net of any probable and reasonably estimable insurance recoveries or received insurance recoveries. During the first and second quarter of the year ended 2025, we experienced a significant increase in general and administrative expenses, primarily for legal fees and consulting expenses in connection with a previously disclosed investigation and restatement of prior period financial statements. Such costs began to decline in the second half of 2025 as certain of our legal and consulting expenses normalized. We expect our general and administrative expenses to decrease for the year ending December 31, 2026, as expenses incurred in 2025 related to a previously disclosed investigation and restatement of prior period financial statements are believed to be substantially non-recurring.

[0001805385-26-000028:mdna:88]
[same as prior period, unchanged from 0001805385-25-000017:mdna:68]

[0001805385-26-000028:mdna:89]
Restructuring costs consists of termination charges arising from severance obligations, incremental non-cash expense related to extended eligibility for the vesting of certain equity awards, and other customary employee benefit payments in connection with a reduction in force. See Note 15, Restructuring Charges for additional information.

[0001805385-26-000028:mdna:90]
[same as prior period, unchanged from 0001805385-25-000017:mdna:71]

[0001805385-26-000028:mdna:91]
Interest expense includes interest on our long-term debt, amortization of debt issuance costs, and unused commitment fees.

[0001805385-26-000028:mdna:92]
[same as prior period, unchanged from 0001805385-25-000017:mdna:73]

[0001805385-26-000028:mdna:93]
Interest income relates primarily to interest earned on our money market funds and treasury bills.

[0001805385-26-000028:mdna:94]
[same as prior period, unchanged from 0001805385-25-000017:mdna:75]

[0001805385-26-000028:mdna:95]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders were entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv shareholders was accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive (loss) income. The earn-out period expired on March 8, 2026 without achievement of the required milestones.

[0001805385-26-000028:mdna:96]
[same as prior period, unchanged from 0001805385-25-000017:mdna:77]

[0001805385-26-000028:mdna:97]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock, referred to as Founder Shares. Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 1,897,500 Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones, subject to expiration in July 2026, and 517,500 Founder Shares were contributed to Give Evolv LLC. The 1,897,500 outstanding contingently issuable common shares are accounted for either as a liability, if still held at the Company's transfer agent, or as an asset as described below, and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income, net in the condensed consolidated statements of operations and comprehensive loss.

[0001805385-26-000028:mdna:98]
Under the Founder Shares arrangement, Founder Shares may be transferred to third parties, subject to certain conditions. The unvested shares must be returned to the Company if the specified vesting conditions are not met. As of March 31, 2026, a total of 729,570 unvested shares had been transferred to individual brokerage accounts, resulting in a reduction to the contingently issuable common stock liability and recognition of the value of the shares as outstanding equity. The contractual obligation of the holders to return the transferred shares upon failure to meet vesting conditions is accounted for as a freestanding financial asset. This asset is initially recognized at fair value and remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss.

[0001805385-26-000028:mdna:99]
[same as prior period, unchanged from 0001805385-25-000017:mdna:82]

[0001805385-26-000028:mdna:100]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are currently exercisable and expire in July 2026. We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss with the offset to additional paid-in capital. The liability is subsequently remeasured at each reporting with changes in fair value.

[0001805385-26-000028:mdna:101]
[same as prior period, unchanged from 0001805385-25-000017:mdna:84]

[0001805385-26-000028:mdna:102]
[same as prior period, unchanged from 0001805385-25-000017:mdna:85]

[0001805385-26-000028:mdna:103]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was signed into law in the United States. The OBBBA introduces various corporate and international tax law changes with staggered effective dates through 2027. Key provisions include immediate R&D expensing, permanent bonus depreciation, modifications to interest expense limitations, and changes to certain international tax rules. The enacted legislation did not have a material impact on our financial position, results of operations, or effective tax rate for the three months ended March 31, 2026, primarily due to our full valuation allowance position on U.S. deferred tax assets, immaterial current tax liabilities, and insignificant foreign earnings from Evolv UK. We will continue to monitor and evaluate all applicable provisions of the OBBBA and any potential future impact on our consolidated financial statements.

[0001805385-26-000028:mdna:104]
[same as prior period, unchanged from 0001805385-25-000017:mdna:89]

[0001805385-26-000028:mdna:105]
Comparison of the Three Months Ended March 31, 2026 and 2025

[0001805385-26-000028:mdna:106]
The following table summarizes our results of operations for the three months ended March 31, 2026 and 2025 (in thousands):

[0001805385-26-000028:mdna:107]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 13,421 |  |  | $ | 2,322 |  |  | $ | 11,099 |  |  | 478 | % |
| Subscription revenue | 23,148 |  |  | 19,237 |  |  | 3,911 |  |  | 20 |  |
| Service revenue | 8,589 |  |  | 6,730 |  |  | 1,859 |  |  | 28 |  |
| License fee and other revenue | 1,170 |  |  | 3,718 |  |  | (2,548) |  |  | (69) |  |
| Total revenue | 46,328 |  |  | 32,007 |  |  | 14,321 |  |  | 45 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 11,856 |  |  | 3,184 |  |  | 8,672 |  |  | 272 |  |
| Cost of subscription revenue | 8,367 |  |  | 7,896 |  |  | 471 |  |  | 6 |  |
| Cost of service revenue | 2,192 |  |  | 1,705 |  |  | 487 |  |  | 29 |  |
| Cost of license fee and other revenue | 314 |  |  | 72 |  |  | 242 |  |  | 336 |  |
| Total cost of revenue | 22,729 |  |  | 12,857 |  |  | 9,872 |  |  | 77 |  |
| Gross profit | 23,599 |  |  | 19,150 |  |  | 4,449 |  |  | 23 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,885 |  |  | 4,862 |  |  | 1,023 |  |  | 21 |  |
| Sales and marketing | 12,671 |  |  | 11,043 |  |  | 1,628 |  |  | 15 |  |
| General and administrative | 13,515 |  |  | 14,972 |  |  | (1,457) |  |  | (10) |  |
| Restructuring costs | — |  |  | 2,662 |  |  | (2,662) |  |  | (100) |  |
| Total operating expenses | 32,071 |  |  | 33,539 |  |  | (1,468) |  |  | (4) |  |
| Loss from operations | (8,472) |  |  | (14,389) |  |  | 5,917 |  |  | 41 |  |
| Other income, net |  |  |  |  |  |  |  |
| Interest expense | (962) |  |  | (1) |  |  | (961) |  |  | (96,100) |  |
| Interest income | 515 |  |  | 389 |  |  | 126 |  |  | 32 |  |
| Other (expense) income, net | (37) |  |  | 25 |  |  | (62) |  |  | (248) |  |
| Change in fair value of contingent earn-out liability | 374 |  |  | 8,976 |  |  | (8,602) |  |  | (96) |  |
| Change in fair value of contingently issuable/returnable common stock liability/asset | 1,492 |  |  | 1,653 |  |  | (161) |  |  | (10) |  |
| Change in fair value of public warrant liability | 2,044 |  |  | 1,721 |  |  | 323 |  |  | 19 |  |
| Total other income, net | 3,426 |  |  | 12,763 |  |  | (9,337) |  |  | (73) |  |
| Loss before income taxes | $ | (5,046) |  |  | $ | (1,626) |  |  | $ | (3,420) |  |  | (210) | % |
| (Benefit) provision for income taxes | $ | (37) |  |  | $ | 63 |  |  | $ | (100) |  |  | (159) | % |
| Net loss | $ | (5,009) |  |  | $ | (1,689) |  |  | $ | (3,320) |  |  | (197) | % |

[0001805385-26-000028:mdna:108]
10

[0001805385-26-000028:mdna:109]
[same as prior period, unchanged from 0001805385-25-000017:mdna:94]

[0001805385-26-000028:mdna:110]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 48 new end-users during the three months ended March 31, 2026, and (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001805385-26-000028:mdna:111]
[same as prior period, unchanged from 0001805385-25-000017:mdna:96]

[0001805385-26-000028:mdna:112]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | $ Change |  | % Change |
| Product revenue | $ | 13,421 |  |  | $ | 2,322 |  |  | $ | 11,099 |  |  | 478 | % |
| Cost of product revenue | $ | 11,856 |  |  | $ | 3,184 |  |  | $ | 8,672 |  |  | 272 | % |
| Gross profit (loss) - Product revenue | $ | 1,565 |  |  | $ | (862) |  |  | $ | 2,427 |  |  | 282 | % |
| Gross profit margin - Product revenue | 12 | % |  | (37) | % |  | N/A |  | 49 | % |

[0001805385-26-000028:mdna:113]
The increases in product revenue and cost of product revenue for the three months ended March 31, 2026 compared to the prior year period are primarily due to an increased utilization of our purchase subscription model, in which the customers purchase Evolv Express and Evolv eXpedite systems directly from us. During the three months ended March 31, 2026, we recognized product revenue related to a large customer order which contributed approximately $1.9 million to product revenue, which included certain non-recurring engineering deliverables at higher margins than our typical product sales. The increase in product gross profit margin for the three months ended March 31, 2026 compared to prior year period was also driven by our ability to leverage our fixed costs over a higher revenue base, partially offset by an increase in outbound shipping costs of $0.4 million due to higher shipping volume and increase in manufacturing expense of $0.3 million.

[0001805385-26-000028:mdna:114]
[same as prior period, unchanged from 0001805385-25-000017:mdna:99]

[0001805385-26-000028:mdna:115]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | $ Change |  | % Change |
| Subscription revenue | $ | 23,148 |  |  | $ | 19,237 |  |  | $ | 3,911 |  |  | 20 | % |
| Cost of subscription revenue | $ | 8,367 |  |  | $ | 7,896 |  |  | $ | 471 |  |  | 6 | % |
| Gross profit - Subscription revenue | $ | 14,781 |  |  | $ | 11,341 |  |  | $ | 3,440 |  |  | 30 | % |
| Gross profit margin - Subscription revenue | 64 | % |  | 59 | % |  | N/A |  | 5 | % |

[0001805385-26-000028:mdna:116]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to continued growth in our customer base as of March 31, 2026 compared to the prior year, with a higher number of active Evolv Express and Evolv eXpedite systems deployed under our pure subscription model during the three months ended March 31, 2026. The increase in subscription gross profit margin is also driven by a $1.2 million decrease in field services cost related to our subscription systems during the three months ended March 31, 2026.

[0001805385-26-000028:mdna:117]
[same as prior period, unchanged from 0001805385-25-000017:mdna:102]

[0001805385-26-000028:mdna:118]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | $ Change |  | % Change |
| Service revenue | $ | 8,589 |  |  | $ | 6,730 |  |  | $ | 1,859 |  |  | 28 | % |
| Cost of service revenue | $ | 2,192 |  |  | $ | 1,705 |  |  | $ | 487 |  |  | 29 | % |
| Gross profit - Service revenue | $ | 6,397 |  |  | $ | 5,025 |  |  | $ | 1,372 |  |  | 27 | % |
| Gross profit margin - Service revenue | 74 | % |  | 75 | % |  | N/A |  | (1) | % |

[0001805385-26-000028:mdna:119]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to the growth in the number of active revenue-generating purchase subscription systems in the field during the three months ended March 31, 2026, compared to the prior year period. The gross profit margin was consistent with the prior period.

[0001805385-26-000028:mdna:120]
[same as prior period, unchanged from 0001805385-25-000017:mdna:105]

[0001805385-26-000028:mdna:121]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | $ Change |  | % Change |
| License fee and other revenue | $ | 1,170 |  |  | $ | 3,718 |  |  | $ | (2,548) |  |  | (69) | % |
| Cost of license fee and other revenue | $ | 314 |  |  | $ | 72 |  |  | $ | 242 |  |  | 336 | % |
| Gross profit - License fee and other revenue | $ | 856 |  |  | $ | 3,646 |  |  | $ | (2,790) |  |  | (77) | % |
| Gross profit margin - License fee and other revenue | 73 | % |  | 98 | % |  | N/A |  | (25) | % |

[0001805385-26-000028:mdna:122]
The decreases in license fee and other revenue and gross profit are primarily driven by $0.2 million of license fee revenue earned during the three months ended March 31, 2026 compared to $3.2 million earned during the prior year period under the Distribution and License Agreement due to the expiration and non-renewal of the agreement effective December 31, 2025. The decrease in gross profit margin is primarily due to the reduction in license fee revenue, which has no associated cost of revenue.

[0001805385-26-000028:mdna:123]
[same as prior period, unchanged from 0001805385-25-000017:mdna:108]

[0001805385-26-000028:mdna:124]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 4,405 |  |  | $ | 3,850 |  |  | $ | 555 |  |  | 14 | % |
| Materials and prototypes | 280 |  |  | 67 |  |  | 213 |  |  | 318 | % |
| Professional fees | 673 |  |  | 672 |  |  | 1 |  |  | — | % |
| Other | 527 |  |  | 273 |  |  | 254 |  |  | 93 | % |
|  | $ | 5,885 |  |  | $ | 4,862 |  |  | $ | 1,023 |  |  | 21 | % |

[0001805385-26-000028:mdna:125]
The increase in personnel related expenses is primarily due to an increase in payroll costs and stock-based compensation of $0.5 million, which resulted primarily from new hires in our research and development functions to support continued product innovation. Other expense increased primarily due to an increase in software subscription costs of $0.2 million.

[0001805385-26-000028:mdna:126]
[same as prior period, unchanged from 0001805385-25-000017:mdna:130]

[0001805385-26-000028:mdna:127]
[same as prior period, unchanged from 0001805385-25-000017:mdna:111]

[0001805385-26-000028:mdna:128]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 9,670 |  |  | $ | 8,504 |  |  | $ | 1,166 |  |  | 14 | % |
| Advertising and direct marketing | 721 |  |  | 583 |  |  | 138 |  |  | 24 | % |
| Travel and entertainment | 905 |  |  | 544 |  |  | 361 |  |  | 66 | % |
| Professional fees | 491 |  |  | 645 |  |  | (154) |  |  | (24) | % |
| Other | 884 |  |  | 767 |  |  | 117 |  |  | 15 | % |
|  | $ | 12,671 |  |  | $ | 11,043 |  |  | $ | 1,628 |  |  | 15 | % |

[0001805385-26-000028:mdna:129]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation of $1.0 million, which resulted primarily from new hires in our sales and marketing functions to support increased sales volume. Stock-based compensation expense included in sales and marketing expenses was $1.6 million for the three months ended March 31, 2026 compared to $1.0 million for the three months ended March 31, 2025. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales meetings.

[0001805385-26-000028:mdna:130]
[same as prior period, unchanged from 0001805385-25-000017:mdna:114]

[0001805385-26-000028:mdna:131]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2026 |  | 2025 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 7,043 |  |  | $ | 5,304 |  |  | $ | 1,739 |  |  | 33 | % |
| Professional fees | 2,852 |  |  | 2,658 |  |  | 194 |  |  | 7 | % |
| Insurance costs | 769 |  |  | 731 |  |  | 38 |  |  | 5 | % |
| Non-recurring professional fees and other expenses | 2,851 |  |  | 6,279 |  |  | (3,428) |  |  | (55) | % |
|  | $ | 13,515 |  |  | $ | 14,972 |  |  | $ | (1,457) |  |  | (10) | % |

[0001805385-26-000028:mdna:132]
Personnel related expenses increased due to an increase in payroll costs and stock-based compensation of $1.7 million, resulting from expanding our general and administrative team during the past twelve months while reducing the use of outsourced contractors and consultants. Stock-based compensation expense included in general and administrative expenses was $2.4 million for the three months ended March 31, 2026 compared to $2.0 million for the three months ended March 31, 2025. Non-recurring professional fees and other expenses decreased primarily due to a $6.3 million decrease in consulting and legal fees and audit fees incurred in connection with a previously disclosed investigation and restatement of prior period financial statements and $0.3 million decrease in estimated net losses related to class action lawsuits, partially offset by a decrease in insurance recoveries of $2.9 million.

[0001805385-26-000028:mdna:133]
[same as prior period, unchanged from 0001805385-25-000017:mdna:117]

[0001805385-26-000028:mdna:134]
Restructuring costs of $2.7 million for three months ended March 31, 2025 resulted from the reduction in force in January 2025. Stock-based compensation expense included in restructuring costs was $0.5 million for the three months ended March 31, 2025. No restructuring cost was recognized for the three months ended March 31, 2026.

[0001805385-26-000028:mdna:135]
[same as prior period, unchanged from 0001805385-25-000017:mdna:119]

[0001805385-26-000028:mdna:136]
Interest expense of $1.0 million for the three months ended March 31, 2026 related to interest on long-term debt, amortization of debt issuance costs, and unused commitment fees. No interest expense was recognized for the three months ended March 31, 2025, as there was no debt outstanding during the period.

[0001805385-26-000028:mdna:137]
[same as prior period, unchanged from 0001805385-25-000017:mdna:122]

[0001805385-26-000028:mdna:138]
Interest income of $0.5 million for the three months ended March 31, 2026 and $0.4 million for the three months ended March 31, 2025 related primarily to interest earned on money market funds and the accretion of discounts on treasury bills. The interest earned increased primarily due to higher average balances in interest-bearing accounts during the three months ended March 31, 2026 compared to during the three months ended March 31, 2025.

[0001805385-26-000028:mdna:139]
[same as prior period, unchanged from 0001805385-25-000017:mdna:124]

[0001805385-26-000028:mdna:140]
Change in the fair value of the contingent earn-out liability resulted in a $0.4 million gain for the three months ended March 31, 2026, resulting from the expiration of the earn-out period. Change in the fair value of the contingent earn-out liability resulted in a $9.0 million gain for the three months ended March 31, 2025, respectively, resulting from quarterly mark-to-market adjustments.

[0001805385-26-000028:mdna:141]
[same as prior period, unchanged from 0001805385-25-000017:mdna:126]

[0001805385-26-000028:mdna:142]
Change in the fair value of the contingently issuable/returnable common stock liability/asset resulted in gains of $1.5 million and $1.7 million for the three months ended March 31, 2026 and 2025, respectively, resulting from quarterly mark-to-market adjustments.

[0001805385-26-000028:mdna:143]
[same as prior period, unchanged from 0001805385-25-000017:mdna:128]

[0001805385-26-000028:mdna:144]
Change in the fair value of the public warrant liability resulted in gains of $2.0 million and $1.7 million for the three months ended March 31, 2026 and 2025, respectively, resulting from quarterly mark-to-market adjustments.

[0001805385-26-000028:mdna:145]
Income Taxes

[0001805385-26-000028:mdna:146]
Our income tax provision consists of an estimate for federal, state, and foreign income taxes based on enacted rates in the jurisdictions in which we operate, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. We have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets.

[0001805385-26-000028:mdna:147]
[same as prior period, unchanged from 0001805385-25-000017:mdna:171]

[0001805385-26-000028:mdna:148]
Our financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures, debt obligations, and general corporate needs. We expect these needs to continue as we develop and grow our business. As of March 31, 2026, we had $61.1 million in cash, cash equivalents, and marketable securities, with outstanding debt of $30.0 million and available additional debt of up to $45.0 million, as detailed below. We incurred a net loss of $5.0 million and $1.7 million for the three months ended March 31, 2026 and 2025, respectively. Operating activities resulted in cash outflows of $3.2 million and $2.5 million during the three months ended March 31, 2026 and 2025, respectively. We expect to continue to generate net losses for the foreseeable future.

[0001805385-26-000028:mdna:149]
[same as prior period, unchanged from 0001805385-25-000017:mdna:173]

[0001805385-26-000028:mdna:150]
As described below, on July 29, 2025 (the "Closing Date"), Evolv Technologies, Inc. entered into the $75.0 million MidCap Credit Agreement, the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's pure subscription sales model. The MidCap Credit Agreement provided for an initial $30.0 million term loan facility, a $30.0 million delayed draw facility (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit. On the Closing Date, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs. As of March 31, 2026, $30.0 million under initial term loan was drawn and outstanding, while the $30.0 million delayed draw facility and $15.0 million revolving credit facility remained undrawn and available.

[0001805385-26-000028:mdna:151]
We expect our cash, cash equivalents, and marketable securities of $61.1 million as of March 31, 2026, together with cash we expect to generate from future operations and our borrowing availability under our Senior Secured Credit Facilities, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to strategically and carefully invest in various areas of the business to support that growth.

[0001805385-26-000028:mdna:152]
[same as prior period, unchanged from 0001805385-25-000017:mdna:143]

[0001805385-26-000028:mdna:153]
Under the MidCap Credit Agreement, we are also required to comply with certain customary reporting requirements of periodic financial results and affirmative and negative covenants, including; (1) a minimum ending balance for annual recurring revenue (“ARR”), as defined, that began at $106.0 million on December 31, 2025 and increases quarterly thereafter; (2) minimum liquidity, as defined, of 50% of outstanding borrowings. This covenant would cease to apply following the resolution of certain litigation and regulatory matters; and (3) a minimum earnings before interest, taxes, depreciation, and amortization (“EBITDA”) covenant that takes effect on June 30, 2027. As of March 31, 2026, the minimum required ARR is $107.3 million, and we are in full compliance with all applicable covenant requirements, and expects to remain in compliance for a period of at least twelve months from May 12, 2026.

[0001805385-26-000028:mdna:154]
[same as prior period, unchanged from 0001805385-25-000017:mdna:180]

[0001805385-26-000028:mdna:155]
On July 29, 2025, the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's pure subscription sales model. The MidCap Credit Agreement provides for an initial $30.0 million term loan facility (the “Initial Term Loan”), a $30.0 million delayed draw facility (the “Delayed Draw Term Loan”) (available for drawdown during the two-year period following the Closing Date), and a $15.0 million revolving line of credit (the "Revolving Credit Facility”), each with a maturity date of July 1, 2030 (collectively, the “Senior Secured Credit Facilities”).

[0001805385-26-000028:mdna:156]
The Senior Secured Credit Facilities are guaranteed by the Company, and in the future, may be guaranteed by certain material subsidiaries. The Senior Secured Credit Facilities are secured by a first lien on substantially all of the assets of the Company. The borrowings under the Senior Secured Credit Facilities bear interest at a fluctuating rate per annum equal to the Term Secured Overnight Financing Rate (“Term SOFR”) and an applicable margin calculated depending on EBITDA. At closing, the applicable margin on Term SOFR loans was 5.25%. If the event described under the MidCap Credit Agreement related to Term SOFR occurs, a base rate is determined by reference to the higher of (1) the prime rate of Wells Fargo and (2) 2.00%. Monthly interest payments are due in arrears on the first day of each month. Principal repayments for the Initial Term Loan begin in August 2029, following a 48-month interest-only period, and will be repaid in equal monthly installments over the final 12 months of the loan term. The Revolving Credit Facility provides for an unused commitment fee of 0.25% on the undrawn portion of the facility.

[0001805385-26-000028:mdna:157]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary affirmative and negative covenants, including a minimum annual recurring revenue covenant, a minimum EBITDA covenant that takes effect on June 30, 2027, and a minimum liquidity covenant that would cease to apply following the resolution of certain litigation and regulatory matters, in addition to customary reporting requirements of periodic financial results. As of March 31, 2026, we were in full compliance with all covenant requirements. See Note 9, Long-term Debt for additional information related to the Senior Secured Credit Facilities.

[0001805385-26-000028:mdna:158]
[same as prior period, unchanged from 0001805385-25-000017:mdna:184]

[0001805385-26-000028:mdna:159]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of March 31, 2026. We anticipate fulfilling such commitments with our existing cash, cash equivalents, and marketable securities, as well as cash and cash equivalents obtained through operations and the proceeds from our Senior Secured Credit Facilities. Cash, cash equivalents, and marketable securities amounted to $61.1 million as of March 31, 2026.

[0001805385-26-000028:mdna:160]
We are party to a lease agreement for office space at our headquarters in Waltham, MA. During the three months ended March 31, 2024, we amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. Additionally, in August 2024, we amended the lease agreement again to expand our footprint in our headquarters and extend the term of the lease through May 2031. Per the second lease amendment, we are no longer required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space. Total future minimum lease payments under this noncancelable operating lease amount to $16.7 million as of March 31, 2026.

[0001805385-26-000028:mdna:161]
We generally contract with Columbia Tech, one of our contract manufacturers, on a cancellable purchase-order basis to provide manufacturing services for our equipment sold or leased to customers. While these contracts are cancellable by us upon prior notice, payments due upon cancellation may consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. Additionally, the recently executed agreement with the Company's new contract manufacturer, Plexus, includes provisions

[0001805385-26-000028:mdna:162]
15

[0001805385-26-000028:mdna:163]
for which order volumes that fall short of our forecasts may result in purchase commitments. These payments are not determinable but could result in a material purchase commitment if we were to cancel our open purchase orders.

[0001805385-26-000028:mdna:164]
On March 25, 2024 and November 1, 2024, putative class action lawsuits were filed against the Company in the United States District Court for the District of Massachusetts. As of March 31, 2026, the Company has recognized a settlement accrual of $15.0 million and an estimated insurance recovery of $14.3 million. See Note 13, Commitments and Contingencies for additional information.

[0001805385-26-000028:mdna:165]
[same as prior period, unchanged from 0001805385-25-000017:mdna:189]

[0001805385-26-000028:mdna:166]
[same as prior period, unchanged from 0001805385-25-000017:mdna:190]

[0001805385-26-000028:mdna:167]
|  | Three Months EndedMarch 31, |
|  | 2026 |  | 2025 |
| Net cash used in operating activities | $ | (3,179) |  |  | $ | (2,539) |  |
| Net cash provided by (used in) investing activities | 9,760 |  |  | (9,361) |  |
| Net cash provided by financing activities | 322 |  |  | 20 |  |
| Effect of exchange rate changes on cash and cash equivalents | 28 |  |  | (46) |  |
| Net increase (decrease) in cash and cash equivalents | $ | 6,931 |  |  | $ | (11,926) |  |

[0001805385-26-000028:mdna:168]
[same as prior period, unchanged from 0001805385-25-000017:mdna:192]

[0001805385-26-000028:mdna:169]
|  | Three Months EndedMarch 31, |
|  | 2026 |  | 2025 |
| Net loss | $ | (5,009) |  |  | $ | (1,689) |  |
| Adjustments to reconcile net loss to net cash used in operating activities | 9,604 |  |  | (1,082) |  |
| Changes in operating assets and liabilities | (7,774) |  |  | 232 |  |
| Net cash used in operating activities | $ | (3,179) |  |  | $ | (2,539) |  |

[0001805385-26-000028:mdna:170]
Net loss increased from $1.7 million for the three months ended March 31, 2025 to $5.0 million for the three months ended March 31, 2026, as discussed in “Results of Operations” above.

[0001805385-26-000028:mdna:171]
Adjustments to reconcile net loss to net cash used in operating activities for the three months ended March 31, 2026 include $3.9 million of an aggregate change in fair value of the earn-out liability, contingently issuable/returnable common stock warrant liability/asset, and public warrant liability, $5.6 million of stock-based compensation expense, and $6.8 million of depreciation and amortization. For the three months ended March 31, 2025, such adjustments included $12.4 million of an aggregate change in fair value of the earn-out liability, contingently issuable/returnable common stock liability/asset, and public warrant liability, offset by $4.9 million of stock-based compensation expense and $5.5 million of depreciation and amortization.

[0001805385-26-000028:mdna:172]
Changes in operating assets and liabilities for the three months ended March 31, 2026 are primarily related to the following:

[0001805385-26-000028:mdna:173]
•$11.9 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001805385-26-000028:mdna:174]
•$4.2 million decrease in accrued expenses and other current liabilities primarily due to the payment of 2025 bonuses and commissions during the three months ended March 31, 2026, partially offset by a $1.3 million settlement accrual for the derivative matters; and

[0001805385-26-000028:mdna:175]
•$1.9 million increase in prepaid expenses and other current assets primarily due to increases in estimated insurance recoveries, partially offset by

[0001805385-26-000028:mdna:176]
•$7.6 million increase in accounts payable (excluding the non-cash portion related to capital expenditures incurred but not yet paid) due primarily to the timing of vendor payments;

[0001805385-26-000028:mdna:177]
•$1.7 million decrease in inventory primarily due to an increased focus on efficient inventory management, partially offset by a decrease in products expected to be leased to customers;

[0001805385-26-000028:mdna:178]
•$0.7 million increase in deferred revenue due to a higher volume of sales; and

[0001805385-26-000028:mdna:179]
•$0.6 million decrease in commission assets driven by amortization exceeding new commission capitalized during the period.

[0001805385-26-000028:mdna:180]
Changes in operating assets and liabilities for the three months ended March 31, 2025 are primarily related to the following:

[0001805385-26-000028:mdna:181]
•$7.2 million decrease in inventory primarily due to an increase in products expected to be leased to customers and an increased focus on efficient inventory management;

[0001805385-26-000028:mdna:182]
•$2.8 million increase in accounts payable (excluding the non-cash portion related to capital expenditures incurred but not yet paid) due primarily to the timing of vendor payments; and

[0001805385-26-000028:mdna:183]
•$0.5 million increase in deferred revenue due to a higher volume of sales; partially offset by

[0001805385-26-000028:mdna:184]
•$6.1 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001805385-26-000028:mdna:185]
•$3.9 million increase in prepaid expenses and other current assets primarily due to estimated insurance recoveries; and

[0001805385-26-000028:mdna:186]
•$0.3 million increase in contract assets due to higher volume of sales.

[0001805385-26-000028:mdna:187]
[same as prior period, unchanged from 0001805385-25-000017:mdna:212]

[0001805385-26-000028:mdna:188]
During the three months ended March 31, 2026, cash provided by investing activities was $9.8 million, consisting of $14.7 million of net cash provided by redemptions of marketable securities, offset by $3.7 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express systems to be leased to customers and $1.2 million for the development of internal-use software and software embedded in products to be sold or leased.

[0001805385-26-000028:mdna:189]
During the three months ended March 31, 2025, cash provided by investing activities was $9.4 million, consisting of $12.7 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express systems to be leased to customers, and $1.6 million for the development of internal-use software and software embedded in products to be sold or leased, offset by $4.9 million of net cash provided by purchases and redemptions of marketable securities.

[0001805385-26-000028:mdna:190]
[same as prior period, unchanged from 0001805385-25-000017:mdna:215]

[0001805385-26-000028:mdna:191]
During the three months ended March 31, 2026, cash provided by financing activities was $0.3 million, consisting of proceeds from the exercise of stock options.

[0001805385-26-000028:mdna:192]
During the three months ended March 31, 2025, cash provided by financing activities was less than $0.1 million, consisting of proceeds from the exercise of stock options.

[0001805385-26-000028:mdna:193]
[same as prior period, unchanged from 0001805385-25-000017:mdna:218]

[0001805385-26-000028:mdna:194]
As further discussed in Note 2, Summary of Significant Accounting Policies, there have been no new accounting pronouncements issued since the issuance of the 2025 Form 10-K that may have a material impact on our consolidated financial position, results of operations or cash flows. There has been one accounting pronouncements that became effective since the issuance of the 2025 Form 10-K.

[0001805385-26-000028:mdna:195]
[same as prior period, unchanged from 0001805385-25-000017:mdna:220]

[0001805385-26-000028:mdna:196]
Our critical accounting estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” of our 2025 Form 10-K. Other than disclosures related to estimating the fair value of performance stock units, as discussed below, there have been no material changes to our critical accounting estimates during the three months ended March 31, 2026.

[0001805385-26-000028:mdna:197]
Performance Stock Units

[0001805385-26-000028:mdna:198]
Beginning in 2026, the Company began granting PSUs to certain of its employees. These PSUs are subject to certain market-based vesting conditions based on the Company's relative total shareholder return percentile ranking compared to the specified stock market index over the applicable performance period, subject to a continued service-based vesting requirements. The estimated grant date fair value of PSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The assumptions utilized in the calculation are based on the achievement of certain performance measurement including expected stock price volatility, risk-free rate of return, and remaining term.
