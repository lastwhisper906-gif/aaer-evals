# EVLV notes — 0001104659-21-106340


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-21-106340:notes:1]
NEWHOLD INVESTMENT CORP AND SUBSIDIARY.

[0001104659-21-106340:notes:2]
Notes to Condensed Consolidated Financial Statements

[0001104659-21-106340:notes:3]
(unaudited)

[0001104659-21-106340:notes:4]
NOTE 1 – DESCRIPTION OF ORGANIZATION AND BUSINESS OPERATIONS

[0001104659-21-106340:notes:5]
Organization and General:

[0001104659-21-106340:notes:6]
NewHold Investment Corp. (the “Company”) was incorporated in Delaware on January 24, 2020 as NewHold Industrial Corp. and on February 14, 2020 changed its name to NewHold Investment Corp. The Company was formed for the purpose of effecting a merger, capital stock exchange, asset acquisition, stock purchase, reorganization or similar business combination with one or more businesses (a “Business Combination”). The Company is an “emerging growth company,” as defined in Section 2(a) of the Securities Act of 1933, as amended, or the “Securities Act,” as modified by the Jumpstart Our Business Startups Act of 2012 (the “JOBS Act”).  On July 16, 2021 in connection with the Company’s initial Business Combination (See Note 9), the Company changed its name to Evolv Technologies Holdings, Inc.

[0001104659-21-106340:notes:7]
At June 30, 2021, the Company had not commenced any operations.  All activity for the period from January 24, 2020 (date of inception) to June 30, 2021 relates to the Company’s formation and the initial public offering (“Public Offering”) described below, and subsequent to the Public Offering, searching for a potential business combination. The Company will not generate any operating revenues until after completion of its initial Business Combination, at the earliest. The Company expects to generate non-operating income in the form of interest income on the proceeds derived from the Public Offering.

[0001104659-21-106340:notes:8]
All dollar amounts are rounded to the nearest thousand dollars.

[0001104659-21-106340:notes:9]
Sponsor and Financing:

[0001104659-21-106340:notes:10]
The Company’s sponsor is NewHold Industrial Technology Holdings LLC, a Delaware limited liability company (the “Sponsor”).   The registration statement for the Public Offering (as described in Note 3) was declared effective by the United States Securities and Exchange Commission (the “SEC”) on July 30, 2020.  The Company intends to finance a Business Combination with proceeds from the $172,500,000 Public Offering (Note 3) and a $5,700,000 Private Placement (as defined in Note 4), net of expenses. Upon the closing of the Public Offering and the Private Placement, $172,500,000 was deposited in a trust account (the “Trust Account”).

[0001104659-21-106340:notes:11]
The Trust Account:

[0001104659-21-106340:notes:12]
The funds in the Trust Account can be invested only in U.S. government treasury bills with a maturity of one hundred and eighty five (185) days or less or in money market funds meeting certain conditions under Rule 2a-7 under the Investment Company Act of 1940 which invest only in direct U.S. government obligations. Funds will remain in the Trust Account until the earlier of (i) the consummation of its initial Business Combination or (ii) the distribution of the Trust Account as described below. The remaining funds outside the Trust Account may be used to pay for business, legal and accounting due diligence on prospective acquisition targets and continuing general and administrative expenses.

[0001104659-21-106340:notes:13]
The Company’s amended and restated certificate of incorporation provides that, other than the withdrawal of interest to pay tax obligations and up to $250,000 per year for working capital purposes, if any, (less up to $100,000 of interest to pay dissolution expenses), none of the funds held in the Trust Account will be released until the earliest of: (a) the completion of the initial Business Combination, (b) the redemption of any public shares properly submitted in connection with a stockholder vote to amend the Company’s amended and restated certificate of incorporation (i) to modify the substance or timing of the ability of holders of the public shares to seek redemption in connection with our initial business combination or the Company’s obligation to redeem 100% of the public shares if the Company does not complete the initial Business Combination within 24 months from the closing of the Public Offering, August 4, 2022, or (ii) with respect to any other provision relating to stockholders’ rights or pre-Business Combination activity, and (c) the redemption of the public shares if the Company is unable to complete the initial Business Combination within 24 months from the closing of the Public Offering, subject to applicable law. The proceeds deposited in the Trust Account could become subject to the claims of creditors, if any, which could have priority over the claims of the Company’s public stockholders.

[0001104659-21-106340:notes:14]
Business Combination:

[0001104659-21-106340:notes:15]
The Company’s management has broad discretion with respect to the specific application of the net proceeds of the Public Offering, although substantially all of the net proceeds of the Public Offering are intended to be generally applied toward consummating a Business Combination with a Target Business. As used herein, “Target Business” is one or more target businesses that together have a fair market value equal to at least 80% of the balance in the Trust Account (less deferred underwriting commissions and any taxes payable on interest earned) at the time of signing a definitive agreement in connection with the Company’s initial Business Combination.  See Note 9.

[0001104659-21-106340:notes:16]
The Company, after signing a definitive agreement for a Business Combination, will either (i) seek stockholder approval of the Business Combination at a meeting called for such purpose in connection with which stockholders may seek to redeem their shares, regardless of whether they vote for or against the Business Combination, for cash equal to their pro rata share of the aggregate amount then on deposit in the Trust Account as of two business days prior to the consummation of the initial Business Combination, including interest but less taxes payable and amounts released for working capital, or (ii) provide stockholders with the opportunity to have their shares redeemed by the Company by means of a tender offer (and thereby avoid the need for a stockholder vote) for an amount in cash equal to their pro rata share of the aggregate amount then on deposit in the Trust Account as of two business days prior to the consummation of the initial Business Combination, including interest but less taxes payable and amounts released to the Company for working capital. The decision as to whether the Company will seek stockholder approval of the Business Combination or will allow stockholders to sell their shares in a tender offer will be made by the Company, solely in its discretion, and will be based on a variety of factors such as the timing of the transaction and whether the terms of the transaction would otherwise require the Company to seek stockholder approval unless a vote is required by the rules of the Nasdaq Capital Market. If the Company seeks stockholder approval, it will complete its Business Combination only if a majority of the outstanding shares of Class A and Class B common stock voted are voted in favor of the Business Combination. However, in no event will the Company redeem its public shares in an amount that would cause its net tangible assets to be less than $5,000,001 upon consummation of a Business Combination. In such case, the Company would not proceed with the redemption of its public shares and the related Business Combination, and instead may search for an alternate Business Combination.

[0001104659-21-106340:notes:17]
If the Company holds a stockholder vote or there is a tender offer for shares in connection with a Business Combination, a public stockholder will have the right to redeem its shares for an amount in cash equal to its pro rata share of the aggregate amount then on deposit in the Trust Account as of two business days prior to the consummation of the initial Business Combination, including interest but less taxes payable and amounts released to the Company for working capital. As a result, such shares of Class A common stock will be recorded at redemption amount and classified as temporary equity upon the completion of the Public Offering, in accordance with Financial Accounting Standards Board (“FASB”) ASC 480, “Distinguishing Liabilities from Equity.”  In August 2020, the Company deposited an aggregate of $172,500,000 from the proceeds of the Public Offering, including the underwriters’ exercise of their overallotment option and the sale of $5,700,000 for the Private Placement Warrants, net of expenses.

[0001104659-21-106340:notes:18]
The Company will have 24 months (until August 4, 2022) from the closing date of the Public Offering to complete its initial Business Combination. If the Company does not complete a Business Combination within this period of time, it shall (i) cease all operations except for the purposes of winding up; (ii) as promptly as reasonably possible, but not more than ten business days thereafter subject to lawfully available funds therefor, redeem 100% of the public shares of Class A common stock for a per share pro rata portion of the Trust Account, including interest, but less taxes payable and amounts released for working capital (less up to $100,000 of such net interest to pay dissolution expenses) and (iii) as promptly as possible following such redemption, dissolve and liquidate the balance of the Company’s net assets to its creditors and remaining stockholders, as part of its plan of dissolution and liquidation. The initial stockholders have entered into letter agreements with us, pursuant to which they have waived their rights to participate in any redemption with respect to their initial shares; however, if the initial stockholders or any of the Company’s officers, directors or affiliates acquire shares of Class A common stock in or after the Public Offering, they will be entitled to a pro rata share of the Trust Account upon the Company’s redemption or liquidation in the event the Company does not complete a Business Combination within 24 months from the closing of the Public Offering.

[0001104659-21-106340:notes:19]
In the event of such distribution, it is possible that the per share value of the residual assets remaining available for distribution (including Trust Account assets) will be less than the price per Unit in the Public Offering.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001104659-21-106340:notes:20]
NOTE 2 – SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001104659-21-106340:notes:21]
Principles of Consolidation:

[0001104659-21-106340:notes:22]
The condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiary, NHIC Sub Inc., a wholly owned subsidiary of the Company, incorporated in Delaware, formed to facilitate the acquisition of Evolv (Note 9). All significant intercompany balances and transactions have been eliminated in consolidation.

[0001104659-21-106340:notes:23]
[same as prior period, unchanged from 0001213900-21-028682:notes:6]

[0001104659-21-106340:notes:24]
The accompanying unaudited condensed consolidated interim financial statements of the Company are presented in U.S. dollars and in conformity with accounting principles generally accepted in the United States of America (“GAAP”) pursuant to the rules and regulations of the SEC and reflect all adjustments, consisting only of normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the financial position as of June 30, 2021, and the results of operations and cash flows for the periods presented. Certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted pursuant to such rules and regulations. Interim results are not necessarily indicative of results for a full year or any later period.  Certain reclassifications have been made to the December 31, 2020 balance sheet to conform to the current presentation.

[0001104659-21-106340:notes:25]
The accompanying unaudited condensed consolidated interim financial statements should be read in conjunction with the Company’s audited financial statements and notes thereto included in the Company’s final prospectus dated July 28, 2020, as well as the Company’s Annual Report, Amendment #1 on Form 10-K/A filed with the SEC on May 14, 2021.

[0001104659-21-106340:notes:26]
At June 30, 2021, the Company has approximately $181,000 in cash, approximately $7,706,000 of current liabilities and approximately $7,380,000 in negative working capital.  The preponderance of the current liabilities (approximately $7,300,000) results from amounts accrued as payable to professional service firms who have agreed to deferred payment terms, or success fees, that are payable at the closing of a Business Combination.  Such accrued fees were paid upon the closing of the Business Combination on July 16, 2020.  Therefore, in connection with the Company’s assessment of going concern considerations in accordance with FASB Accounting Standards Update (“ASU”) 2014-15, “Disclosures of Uncertainties about an Entity’s Ability to Continue as a Going Concern,” as of June 30, 2021, management has determined that the Company’s current liquidity is sufficient to fund the working capital needs of the Company until the earlier of the consummation of the Business Combination or one year from the date of issuance of these financial statements.

[0001104659-21-106340:notes:27]
[same as prior period, unchanged from 0001213900-21-028682:notes:9]

[0001104659-21-106340:notes:28]
Section 102(b)(1) of the JOBS Act exempts emerging growth companies from being required to comply with new or revised financial accounting standards until private companies (that is, those that have not had a Securities Act registration statement declared effective or do not have a class of securities registered under the Exchange Act) are required to comply with the new or revised financial accounting standards. The JOBS Act provides that a company can elect to opt out of the extended transition period and comply with the requirements that apply to non-emerging growth companies but any such an election to opt out is irrevocable. The Company has elected not to opt out of such extended transition period which means that when an accounting standard is issued or revised and it has different application dates for public or private companies, the Company, as an emerging growth company, can adopt the new or revised standard at the time private companies adopt the new or revised standard.  This may make comparison of the Company’s financial statements with another public company which is neither an emerging growth company nor an emerging growth company which has opted out of using the extended transition period difficult or impossible because of the potential differences in accounting standards used.

[0001104659-21-106340:notes:29]
[same as prior period, unchanged from 0001213900-21-028682:notes:11]

[0001104659-21-106340:notes:30]
The Company considers all highly liquid instruments with original maturities of three months or less when acquired, to be cash equivalents.  The Company had no cash equivalents at June 30, 2021 and December 31, 2020.

[0001104659-21-106340:notes:31]
[same as prior period, unchanged from 0001213900-21-028682:notes:13]

[0001104659-21-106340:notes:32]
The Company complies with the requirements of the FASB ASC 340-10-S99-1 and SEC Staff Accounting Bulletin (SAB) Topic 5A — “Expenses of Offering.”  Costs incurred in connection with preparation for the Offering were approximately $9,986,000, including underwriters’ discount paid and deferred of approximately $9,488,000.  Such costs were allocated among the equity and warrant liability components based on the relative fair value of the warrants and approximately $9,596,000 has been charged to equity for the equity components and approximately $390,000 has been charged to other expense for the warrant liability components upon completion of the Public Offering.

[0001104659-21-106340:notes:33]
[same as prior period, unchanged from 0001213900-21-028682:notes:15]

[0001104659-21-106340:notes:34]
As discussed in Note 3, all of the 17,250,000 public shares sold as part of Units in the Public Offering contain a redemption feature which allows for the redemption of public shares if the Company holds a stockholder vote or there is a tender offer for shares in connection with a Business Combination. In accordance with FASB ASC 480, redemption provisions not solely within the control of the Company require the security to be classified outside of permanent equity. Ordinary liquidation events, which involve the redemption and liquidation of all of the entity’s equity instruments, are excluded from the provisions of FASB ASC 480. Although the Company did not specify a maximum redemption threshold, its charter provides that in no event will it redeem its public shares in an amount that would cause its net tangible assets (stockholders’ equity) to be less than $5,000,001 upon the closing of a Business Combination.

[0001104659-21-106340:notes:35]
The Company recognizes changes in redemption value immediately as they occur and adjusts the carrying value of the securities at the end of each reporting period. Increases or decreases in the carrying amount of redeemable common stock are affected by adjustments to additional paid-in capital. Accordingly, at June 30, 2021 and December 31, 2020, 12,906,585 and 14,077,350, respectively, of the 17,250,000 public shares were classified outside of permanent equity.

[0001104659-21-106340:notes:36]
[same as prior period, unchanged from 0001213900-21-028682:notes:18]

[0001104659-21-106340:notes:37]
Net income (loss) per common share is computed by dividing net income (loss) applicable to common stockholders by the weighted average number of shares of common stock outstanding for the period. The Company has not considered the effect of the warrants sold in the Public Offering and Private Placement to purchase an aggregate of 14,325,000 shares of Class A common stock in the calculation of diluted income (loss) per share, since their inclusion would be anti-dilutive under the treasury stock method. As a result, diluted income (loss) per common share is the same as basic loss per common share for the periods presented.

[0001104659-21-106340:notes:38]
The Company’s statement of operations includes a presentation of income (loss) per share for common stock subject to redemption in a manner similar to the two-class method of income (loss) per share. Net income (loss) per share, basic and diluted for Class A common stock is calculated by dividing the interest income earned on the funds in the Trust Account, net of income tax expense and franchise tax expense, by the weighted average number of shares of Class A common stock outstanding since their original issuance. Net income (loss) per common share, basic and diluted, for shares of Class B common stock is calculated by dividing the net income (loss), less income attributable to Class A common stock, by the weighted average number of shares of Class B common stock outstanding for the period. Net income (loss) available to each class of common stockholders is as follows for the

[0001104659-21-106340:notes:39]
three and six months ended June 30, 2021 and for the three months ended June 30, 2020 and for the period from January 24, 2020 (date of inception) to June 30, 2020:

[0001104659-21-106340:notes:40]
| ​ | ​ | ​ | ​ | For the Period | ​ | ​ | ​ | For the Period |
| ​ | ​ | ​ | ​ | From January | ​ | ​ | ​ | From January |
| ​ | ​ | Three months | ​ | 24, 2020 (date | ​ | Six months | ​ | 24, 2020 (date |
| ​ | ​ | Ended | ​ | of inception) to | ​ | Ended | ​ | of inception) to |
| ​ | ​ | June 30, | ​ | June 30, | ​ | June 30, | ​ | June 30, |
| ​ |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net income available to Class A common stockholders: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Interest income | ​ | $ | 9,000 | ​ | $ | — | ​ | $ | 29,000 | ​ | $ | — |
| Less: Income and franchise taxes | ​ |  | (9,000) | ​ |  | — | ​ |  | (29,000) | ​ |  | — |
| Net income attributable to Class A common stockholders | ​ | $ | — | ​ | $ | — | ​ | $ | — | ​ | $ | — |
| Net income available to Class B common stockholders: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Net loss | ​ | $ | (7,626,000) | ​ | $ | (2,000) | ​ | $ | (11,708,000) | ​ | $ | (2,000) |
| Less: amount attributable to Class A common stockholders | ​ |  | — | ​ |  | — | ​ |  | — | ​ |  | — |
| Net (loss) attributable to Class B common stockholders | ​ | $ | (7,626,000) | ​ | $ | (2,000) | ​ | $ | (11,708,000) | ​ | $ | (2,000) |

[0001104659-21-106340:notes:41]
[same as prior period, unchanged from 0001213900-21-028682:notes:22]

[0001104659-21-106340:notes:42]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash accounts in a financial institution, which at times, may exceed the Federal depository insurance coverage of $250,000. The Company has not experienced losses on these accounts and management believes the Company is not exposed to significant risks on such accounts.

[0001104659-21-106340:notes:43]
[same as prior period, unchanged from 0001213900-21-028682:notes:24]

[0001104659-21-106340:notes:44]
The fair value of the Company’s assets and liabilities, which qualify as financial instruments under FASB Accounting Standards Codification (“ASC 820”), “Fair Value Measurements and Disclosures,” approximates the carrying amounts represented in the financial statements.

[0001104659-21-106340:notes:45]
[same as prior period, unchanged from 0001213900-21-028682:notes:26]

[0001104659-21-106340:notes:46]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires the Company’s management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements. Making estimates requires management to exercise significant judgment. It is at least reasonably possible that the estimate of the effect of a condition, situation or set of circumstances that existed at the date of the financial statement, which management considered in formulating its estimate, could change in the near term due to one or more future confirming events.  One of the more significant accounting estimates included in these financial statements is the determination of the fair value of the warrant liability. Such estimates may be subject to change as more current information becomes available and accordingly the actual results could differ significantly from those estimates.

[0001104659-21-106340:notes:47]
[same as prior period, unchanged from 0001213900-21-028682:notes:28]

[0001104659-21-106340:notes:48]
The Company follows the asset and liability method of accounting for income taxes under FASB ASC, 740, “Income Taxes.” Deferred tax assets and liabilities are recognized for the estimated future tax consequences attributable to differences between the financial statements carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that included the enactment date. Valuation allowances are established, when necessary, to reduce deferred tax assets to the amount expected to be realized.

[0001104659-21-106340:notes:49]
The Company’s currently taxable income consists of interest income on the Trust Account net of taxes. The Company’s general and administrative costs are generally considered start-up costs and are not currently deductible. During the three and six months ended June 30, 2021 and the three months ended June 30, 2021 and the period from January 24, 2020 (date of inception) to June 30, 2021, the Company recorded income tax expense of approximately $-0-and $-0-, respectively, related to interest income earned on the Trust Account net of taxes. The Company’s effective tax rate for the three and six months ended June 30, 2021 and the three months ended June 30, 2021 and the period from January 24, 2020 (date of inception) to June 30, 2021  was approximately -0-% and -0-%, and -0-% and -0-%, respectively, which differs from the expected income tax rate due to the start-up costs (discussed above) which are not currently deductible as well as business combination and warrant liability charges or credits which may not be deductible, and the low level of interest income.  At June 30, 2021 and December 31, 2020, the Company has a deferred tax asset of approximately $575,000 and $200,000, respectively. The Company records a full allowance reducing such deferred tax assets to zero since they are not reasonably assured of realizabilty due to the Company’s lack of operations, losses and pending change of control.

[0001104659-21-106340:notes:50]
FASB ASC 740 prescribes a recognition threshold and a measurement attribute for the financial statement recognition and measurement of tax positions taken or expected to be taken in a tax return. For those benefits to be recognized, a tax position must be more-likely-than-not to be sustained upon examination by taxing authorities. There were no unrecognized tax benefits as of June 30, 2021. The Company recognizes accrued interest and penalties related to unrecognized tax benefits as income tax expense. No amounts were accrued for the payment of interest and penalties at June 30, 2021. The Company is currently not aware of any issues under review that could result in significant payments, accruals or material deviation from its position. The Company is subject to income tax examinations by major taxing authorities since inception.

[0001104659-21-106340:notes:51]
[same as prior period, unchanged from 0001213900-21-028682:notes:32]

[0001104659-21-106340:notes:52]
The Company accounts for warrants as either equity-classified or liability-classified instruments based on an assessment of the warrant’s specific terms and applicable authoritative guidance FASB ASC 480, Distinguishing Liabilities from Equity (“ASC 480”) and ASC 815, Derivatives and Hedging (“ASC 815”). The assessment considers whether the warrants are freestanding financial instruments pursuant to ASC 480, meet the definition of a liability pursuant to ASC 480, and whether the warrants meet all of the requirements for equity classification under ASC 815, including whether the warrants are indexed to the Company’s own shares, among other conditions for equity classification. This assessment, which requires the use of professional judgment, is conducted at the time of warrant issuance and as of each subsequent quarterly period end date while the warrants are outstanding.

[0001104659-21-106340:notes:53]
For issued or modified warrants that meet all of the criteria for equity classification, the warrants are required to be recorded as a component of additional paid-in capital at the time of issuance. For issued or modified warrants that do not meet all the criteria for equity classification, the warrants are required to be recorded as liabilities at their initial fair value on the date of issuance, and at fair value in each balance sheet date thereafter. Changes in the estimated fair value of the warrants are recognized as a non-cash gain or loss on the statements of operations. Costs associated with issuing the warrants accounted for as liabilities are charged to operations when the warrants are issued.  The fair value of the public warrants and the private placement warrants were initially estimated using a Monte Carlo simulation approach.  Following the separate trading of the Company’s common stock and public warrants, the private placement warrants fair values were estimated using a Black-Scholes-Merton approach.

[0001104659-21-106340:notes:54]
[same as prior period, unchanged from 0001213900-21-028682:notes:35]

[0001104659-21-106340:notes:55]
In August 2020, the FASB issued Accounting Standards Update (“ASU”) 2020-06, Debt — Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging — Contracts in Entity’s Own Equity (Subtopic 815-40) (“ASU 2020-06”) to simplify accounting for certain financial instruments. ASU 2020-06 eliminates the current models that require separation of beneficial conversion and cash conversion features from convertible instruments and simplifies the derivative scope exception guidance pertaining to equity classification of contracts in an entity’s own equity. The new standard also introduces additional disclosures for convertible debt and freestanding instruments that are indexed to and settled in an entity’s own equity. ASU 2020-06 amends the diluted earnings per share guidance, including the requirement to use the if-converted method for all convertible instruments. ASU 2020-06 is effective January 1, 2022 and should be applied on a full or modified retrospective basis, with early adoption permitted beginning on January 1, 2021. The Company is currently evaluating the impact that the pronouncement will have on the financial statements.

[0001104659-21-106340:notes:56]
Management does not believe that any other recently issued, but not yet effective, accounting pronouncements, if currently adopted, would have a material effect on the Company’s financial statements.

[0001104659-21-106340:notes:57]
Subsequent Events:

[0001104659-21-106340:notes:58]
Management has evaluated subsequent events to determine if events or transactions occurring after the date of the condensed consolidated balance sheet but before the condensed financial statements were available to be issued require potential adjustment to or disclosure in the condensed consolidated financial statements and has concluded that all such events that would require adjustment or disclosure have been recognized or disclosed, see Note 9.


## us-gaap:PublicUtilitiesDisclosureTextBlock

[0001104659-21-106340:notes:59]
NOTE 3 – PUBLIC OFFERING

[0001104659-21-106340:notes:60]
In August 2020, the Company closed on the Public Offering, including the full exercise of the underwriters’ overallotment option, of an aggregate 17,250,000 units at a price of $10.00 per unit (the “Units”).  Each Unit consists of one share of the Company’s Class A common stock, $0.0001 par value and one-half of one redeemable warrant (the “Warrants”). Each whole Warrant offered in the Public Offering is exercisable to purchase one share of our Class A common stock for $11.50 per share. Only whole Warrants may be exercised. Under the terms of the warrant agreement, the Company has agreed to use its best efforts to file a new registration statement under the Securities Act, following the completion of the Company’s initial Business Combination. No fractional shares will be issued upon exercise of the Warrants.  If, upon exercise of the Warrants, a holder would be entitled to receive a fractional interest in a share, the Company will, upon exercise, round down to the nearest whole number the number of shares of Class A common stock to be issued to the Warrant holder. Each Warrant will become exercisable on the later of 30 days after the completion of the Company’s initial Business Combination or 12 months from the closing of the Public Offering and will expire five years after the completion of the Company’s initial Business Combination or earlier upon redemption or liquidation. However, if the Company does not complete its initial Business Combination on or prior to the 24-month period allotted to complete the Business Combination, the Warrants will expire at the end of such period. If the Company is unable to deliver registered shares of Class A common stock to the holder upon exercise of a Warrant during the exercise period, there will be no net cash settlement of these Warrants and the Warrants will expire worthless, unless they may be exercised on a cashless basis in the circumstances described in the warrant agreement. Once the Warrants become exercisable, the Company may redeem the outstanding Warrants in whole and not in part at a price of $0.01 per Warrant upon a minimum of 30 days’ prior written notice of redemption, only in the event that the last sale price of the Company’s shares of Class A common stock equals or exceeds $18.00 per share for any 20 trading days within the 30-trading day period ending on the third trading day before the Company sends the notice of redemption to the Warrant holders.

[0001104659-21-106340:notes:61]
In addition, if the Company issues additional shares of Class A common stock or equity-linked securities for capital raising purposes in connection with the closing of its initial Business Combination at an issue price or effective issue price of less than $9.20 per share of Class A common stock (with such issue price or effective issue price to be determined in good faith by the Company’s board of directors and, in the case of any such issuance to the initial stockholders or their affiliates, without taking into account any Founder Shares held by them, as applicable, prior to such issuance) (the “newly issued price”), the exercise price of the Warrants and the Private Placement Warrants (as defined below) will be adjusted (to the nearest cent) to be equal to 115% of the newly issued price.

[0001104659-21-106340:notes:62]
The Company paid an underwriting discount of 2.0% of the per Unit price to the underwriters at the closing of the Public Offering (an aggregate fee of $3,450,000 including the exercise of the underwriter’s overallotment option).

[0001104659-21-106340:notes:63]
In addition, the Company expects to pay an underwriting commission of 3.5% of the per Unit price to the underwriters (an aggregate of approximately $6,038,000), which commission was deposited in the Trust Account at the closing of the Public Offering and will be released to the underwriters only upon and concurrently with completion of the Company’s initial Business Combination.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001104659-21-106340:notes:64]
NOTE 4 – RELATED PARTY TRANSACTIONS

[0001104659-21-106340:notes:65]
Founder Shares

[0001104659-21-106340:notes:66]
In February 2020, the Sponsor purchased 4,312,500 shares of Class B common stock (the “Founder Shares”) for $25,000, or approximately $0.006 per share. In July 2020, the Sponsor transferred an aggregate of 867,500 founder shares, including to the following persons: (1) 32,500 founder shares to each of Marc Saiontz and Suzy Taherian, two of the Company’s independent director nominees, (ii) 35,000 founder shares to each of Neil Glat and Brian Mathis, two of the Company’s independent director nominees, (iii) 40,000 founder shares to Kathleen Harris, one of the Company’s independent director nominees, (iv) 50,000 founder shares to Thomas Sullivan, one of the Company’s independent director nominees, (v) 67,500 founder shares to Adam Deutsch, the Company’s Chief Financial Officer, (vi) 100,000 founder shares to Charlie Baynes-Reid, the Company’s Chief Operating Officer, (vii) 135,000 founder shares to each of Kevin Charlton and Charles Goldman, the Company’s Chief Executive Officer and director, respectively, and (viii)

[0001104659-21-106340:notes:67]
200,000 founder shares to Nick Petruska, the Company’s special advisor; and (ii) the Sponsor forfeited 920,000 shares of Class B common stock and certain funds and accounts managed by Magnetar Financial LLC, UBS O’Connor LLC, and Mint Tower Capital Management B.V (collectively, the “Anchor Investor”) purchased 920,000 shares of Class B common stock from the Company for an aggregate purchase price of approximately $5,333, or approximately $0.006 per share resulting in the Company’s initial stockholders holding an aggregate of 4,312,500 Founder Shares. The Founder Shares are identical to the Class A common stock included in the Units being sold in the Public Offering except that the Founder Shares automatically convert into shares of Class A common stock at the time of the initial Business Combination and are subject to certain transfer restrictions, as described in more detail below.

[0001104659-21-106340:notes:68]
The Company’s initial stockholders and Anchor Investors have agreed not to transfer, assign or sell any of its Founder Shares until the earlier of (A) one year after the completion of the Company’s initial Business Combination, or (B), subsequent to the Company’s initial Business Combination, if (x) the last sale price of the Company’s Class A common stock equals or exceeds $12.00 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30-trading day period commencing at least 150 days after the Company’s initial Business Combination or (y) the date on which the Company completes a liquidation, merger, stock exchange or other similar transaction after the initial Business Combination that results in all of the Company’s stockholders having the right to exchange their shares of Class A common stock for cash, securities or other property.

[0001104659-21-106340:notes:69]
Private Placement Warrants

[0001104659-21-106340:notes:70]
The Sponsor and the Anchor Investors purchased from the Company an aggregate of 5,700,000 warrants at a price of $1.00 per warrant, a purchase price of $5,700,000 in a private placement that occurred simultaneously with the completion of the Public Offering (the “Private Placement Warrants”), including the underwriters’ full exercise of their overallotment option. Each Private Placement Warrant entitles the holder to purchase one share of Class A common stock at $11.50 per share. A portion of the purchase price of the Private Placement Warrants was added to the proceeds from the Public Offering held in the Trust Account pending completion of the Company’s initial Business Combination. The Private Placement Warrants (including the Class A common stock issuable upon exercise of the Private Placement Warrants) are not transferable, assignable or salable until 30 days after the completion of the initial Business Combination and they will be non-redeemable so long as they are held by the Sponsor or the Anchor Investors or their permitted transferees. If the Private Placement Warrants are held by someone other than the Sponsor or the Anchor Investors or their permitted transferees, the Private Placement Warrants will be redeemable by the Company and exercisable by such holders on the same basis as the warrants included in the Units being sold in the Public Offering. Otherwise, the Private Placement Warrants have terms and provisions that are identical to those of the Warrants being sold as part of the Units in the Public Offering and have no net cash settlement provisions.

[0001104659-21-106340:notes:71]
If the Company does not complete a Business Combination, then the proceeds from the sale of the Private Placement Warrants will be part of the liquidating distribution to the public stockholders and the Private Placement Warrants issued to the Sponsor will expire worthless.

[0001104659-21-106340:notes:72]
Registration Rights

[0001104659-21-106340:notes:73]
The Company’s initial stockholders and the holders of the Private Placement Warrants will be entitled to registration rights pursuant to a registration rights agreement to be signed on or before the date of the prospectus for the Public Offering. These holders will be entitled to make up to three demands, excluding short form registration demands, that the Company register such securities for sale under the Securities Act. In addition, these holders will have “piggy-back” registration rights to include their securities in other registration statements filed by the Company. The Company will bear the expenses incurred in connection with the filing of any such registration statements. There will be no penalties associated with delays in registering the securities under the proposed registration rights agreement.

[0001104659-21-106340:notes:74]
Related Party Loans

[0001104659-21-106340:notes:75]
In February 2020, the Sponsor agreed to loan the Company an aggregate of $300,000 by drawdowns of not less than $10,000 each against the issuance of an unsecured promissory note (the “Note”) to cover expenses related to the Public Offering. The Note was non-interest bearing and payable promptly after the earlier of the date on which the Company consummates the Public Offering and the date on which the Company determines not to conduct the Public Offering. The Company drew down a total of approximately $47,000 under the Note, including approximately $3,000 for costs paid directly by the Sponsor.  On August 4, 2020, the approximately $47,000 outstanding under the Note was fully repaid in connection with the closing of the IPO.

[0001104659-21-106340:notes:76]
Working Capital Loans

[0001104659-21-106340:notes:77]
In order to finance transaction costs in connection with a Business Combination, the Sponsor, an affiliate of the Sponsor, or certain of the Company’s officers and directors or their affiliates may, but are not obligated to, loan the Company funds as may be required (“Working Capital Loans”). If the Company completes a Business Combination, the Company would repay the Working Capital Loans out of the proceeds of the Trust Account released to the Company. Otherwise, the Working Capital Loans would be repaid only out of funds held outside the Trust Account. In the event that a Business Combination does not close, the Company may use a portion of proceeds held outside the Trust Account to repay the Working Capital Loans but no proceeds held in the Trust Account would be used to repay the Working Capital Loans. The Working Capital Loans would either be repaid upon consummation of a Business Combination, without interest, or, at the lender’s discretion, up to $1,500,000 of such Working Capital Loans may be convertible into warrants of the post Business Combination entity. The warrants would be identical to the Private Placement Warrants. Except for the foregoing, the terms of such Working Capital Loans, if any, have not been determined and no written agreements exist with respect to such loans. As of June 30, 2021 and December 31, 2020, no Working Capital Loans were outstanding.

[0001104659-21-106340:notes:78]
Administrative Support Agreement

[0001104659-21-106340:notes:79]
The Company has agreed to pay $15,000 a month for office space, utilities and secretarial and administrative support to an affiliate of the Sponsor. Services commenced on the date the securities were first listed on the Nasdaq Capital Market and will terminate upon the earlier of the consummation by the Company of an initial Business Combination or the liquidation of the Company.  During the three and six months ended June 30, 2021, approximately $45,000 and $90,000, respectively, was included in general and administrative expenses for the administrative support fee.


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-21-106340:notes:80]
NOTE 5 - TRUST ACCOUNT AND FAIR VALUE MEASUREMENT

[0001104659-21-106340:notes:81]
The Company complies with FASB ASC 820, Fair Value Measurements, for its financial assets and liabilities that are re-measured and reported at fair value at each reporting period, and non-financial assets and liabilities that are re-measured and reported at fair value at least annually.

[0001104659-21-106340:notes:82]
Upon the closing of the Public Offering and the Private Placement, a total of approximately $172,500,000 was deposited into the Trust Account.  The proceeds in the Trust Account must be invested in either U.S. government treasury bills with a maturity of 180 days or less or in money market funds meeting certain conditions under Rule 2a-7 under the Investment Company Act of 1940, as amended, and that invest solely in U.S. government treasury obligations.

[0001104659-21-106340:notes:83]
At June 30, 2021 the proceeds of the Trust Account were invested primarily in a money market fund that invests in U.S. government treasury bills complying with the requirements stated above.

[0001104659-21-106340:notes:84]
The following table presents information about the Company’s assets that are measured at fair value on a recurring basis as of June 30, 2021 and indicates the fair value hierarchy of the valuation techniques the Company utilized to determine such fair value.  Since all of the Company’s permitted investments at June 30, 2021 consisted of U.S. government treasury bills and money market

[0001104659-21-106340:notes:85]
funds that invest only in U.S. government treasury bills, fair values of its investments are determined by Level 1 inputs utilizing quoted prices (unadjusted) in active markets for identical assets or liabilities as follows:

[0001104659-21-106340:notes:86]
| ​ |  | ​ |  |  | ​ |  | Quoted Price |
| ​ | ​ | ​ | ​ | ​ | ​ | Prices in |
| ​ | ​ | Carrying value at | ​ | Gross Unrealized | ​ | Active Markets |
| Description | ​ | June 30, 2021 | ​ | Holding Gains | ​ | (Level 1) |
| Assets: |  | ​ |  |  | ​ |  |  | ​ |  |
| Cash and money market funds | ​ | $ | 172,608,000 | ​ | $ | — | ​ | $ | 172,608,000 |
| Total | ​ | $ | 172,608,000 | ​ | $ | — | ​ | $ | 172,608,000 |

[0001104659-21-106340:notes:87]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Quoted Price |
| ​ | ​ | ​ | ​ | ​ |  | ​ | ​ | Prices in |
| ​ | ​ | Carrying value at | ​ | Gross Unrealized | ​ | Active Markets |
| Description |  | December 31, 2020 |  | Holding Gains |  | (Level 1) |
| Assets: | ​ |  |  |  | ​ |  |  | ​ |  |
| U.S. government treasury bills | ​ | $ | 172,579,000 | ​ | $ | — | ​ | $ | 172,579,000 |
| Total | ​ | $ | 172,579,000 | ​ | $ | — | ​ | $ | 172,579,000 |

[0001104659-21-106340:notes:88]
In July 2021, in connection with the Business Combination discussed further in Note 9, holders of 8,755,987 shares of Class A common stock properly redeemed their shares for an aggregate of $87,564,196.77 was removed from Trust Assets to fund such redemptions.  The remaining balance in the Trust Account was used to fund the Business Combination.


## evlv:AccountForWarrantLiabilityTextBlock

[0001104659-21-106340:notes:89]
NOTE 6 — ACCOUNTING FOR WARRANT LIABILITY

[0001104659-21-106340:notes:90]
At June 30, 2021, there were 14,325,000 warrants outstanding including 8,625,000 Public Warrants and 5,700,000 Private Placement Warrants.

[0001104659-21-106340:notes:91]
The Company accounts for its warrants outstanding consistent with the “Staff Statement on Accounting and Reporting Considerations for Warrants Issued by Special Purpose Acquisition Companies (the “Staff Statement”) issued on April 12, 2021 by the staff (the “Staff”) of the Division of Corporation Finance of the SEC. The following table presents information about the Company’s warrant liabilities that are measured at fair value on a recurring basis at June 30, 2021 and indicates the fair value hierarchy of the valuation inputs the Company utilized to determine such fair value.

[0001104659-21-106340:notes:92]
| ​ |  | ​ |  | ​ |  | Significant |  | Significant |
| ​ | ​ | ​ | ​ | Quoted Prices | ​ | Other | ​ | Other |
| ​ | ​ | ​ | ​ | in Active | ​ | Observable | ​ | Unobservable |
| ​ | ​ | June 30, | ​ | Markets | ​ | Inputs | ​ | Inputs |
| Description | ​ | 2021 | ​ | (Level 1) | ​ | (Level 2) | ​ | (Level 3) |
| Warrant Liabilities: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Public Warrants | ​ | $ | 14,921,000 | ​ | $ | 14,921,000 | ​ | $ | — | ​ | $ | — |
| Private Placement Warrants | ​ | $ | 10,203,000 | ​ | $ | — | ​ | $ | — | ​ | $ | 10,203,000 |
| Warrant liability at June 30, 2021 | ​ | $ | 25,124,000 | ​ | $ | 14,921,000 | ​ | ​ | — | ​ | $ | 10,203,000 |

[0001104659-21-106340:notes:93]
December 31, 2020 — The following table presents information about the Company’s warrant liabilities that are measured at fair value on a recurring basis at December 31, 2020 and indicates the fair value hierarchy of the valuation inputs the Company utilized to determine such fair value.

[0001104659-21-106340:notes:94]
| ​ |  | ​ |  | ​ |  | Significant |  | Significant |
| ​ | ​ | ​ | ​ | Quoted Prices | ​ | Other | ​ | Other |
| ​ | ​ | ​ | ​ | in Active | ​ | Observable | ​ | Unobservable |
| ​ | ​ | December 31, | ​ | Markets | ​ | Inputs | ​ | Inputs |
| Description | ​ | 2020 | ​ | (Level 1) | ​ | (Level 2) | ​ | (Level 3) |
| Warrant Liabilities: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Public Warrants | ​ | $ | 12,851,000 | ​ | $ | — | ​ | $ | — | ​ | $ | 12,851,000 |
| Private Placement Warrants | ​ |  | 8,668,000 | ​ |  | — | ​ |  | — | ​ |  | 8,668,000 |
| Warrant liability at December 31, 2020 | ​ | $ | 21,519,000 | ​ | $ | — | ​ | $ | — | ​ | $ | 21,519,000 |

[0001104659-21-106340:notes:95]
The Company utilizes a third-party valuation consultant that uses a Black-Scholes-Merton approach to value the Private Placement Warrants for the reporting period ended June 30, 2021, with changes in fair value recognized in the statement of operations. The estimated fair value of the Private Placement Warrant liability is determined using Level 3 inputs. Inherent in a Black-Scholes-Merton option pricing model are assumptions related to expected share-price volatility, expected life, risk-free interest rate and dividend yield. The Company estimates the volatility of its ordinary shares based on historical volatility that matches the expected remaining life of the warrants. The risk-free interest rate is based on the U.S. Treasury zero-coupon yield curve on the grant date for a maturity similar to the expected remaining life of the warrants. The expected life of the warrants is assumed to be equivalent to their remaining contractual term. The dividend rate is based on the historical rate, which the Company anticipates to remain at zero.

[0001104659-21-106340:notes:96]
The warrant liabilities are not subject to qualified hedge accounting.

[0001104659-21-106340:notes:97]
There were no transfers between Levels 1, 2 or 3 during the period ended June 30, 2021.

[0001104659-21-106340:notes:98]
The following table provides quantitative information regarding Level 3 fair value measurements:

[0001104659-21-106340:notes:99]
| ​ |  | As of |  | As of | ​ |
| ​ | ​ | June 30, | ​ | December 31, | ​ |
| Private Warrants: | ​ | 2021) | ​ | 2020 | ​ |
| Term (in years) |  | ​ | 5.0 |  | ​ | 5.0 |  |
| Volatility – post announcement |  | ​ | 24.1 | % | ​ | 30 | % |
| Risk-free rate |  | ​ | 0.87 | % | ​ | 0.47 | % |
| Fair value of warrants | ​ | $ | 1.79 | ​ | $ | 1.52 | ​ |
| Public Warrants: | ​ |  |  | ​ | ​ | ​ |  |
| Simulated warrant value | ​ | $ | 1.73 | ​ | $ | 1.49 |  |
| Publicly-traded value | ​ | $ | 1.73 | ​ | $ | 1.49 |  |

[0001104659-21-106340:notes:100]
The following table presents the changes in the fair value of warrant liabilities:

[0001104659-21-106340:notes:101]
| ​ |  | ​ | ​ |  | Private |  | Warrant |
| ​ |  | Public |  | Placement |  | Liabilities |
| Fair value measurement on December 31, 2020 | ​ | $ | 12,851,000 | ​ | $ | 8,668,000 | ​ | $ | 21,519,000 |
| Change in valuation inputs or other assumptions | ​ |  | 2,070,000 | ​ |  | 1,535,000 | ​ |  | 3,605,000 |
| Fair value as of June 30, 2021 | ​ | $ | 14,921,000 | ​ | $ | 10,203,000 | ​ | $ | 25,124,000 |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-21-106340:notes:102]
NOTE 7 – STOCKHOLDERS’ EQUITY

[0001104659-21-106340:notes:103]
[same as prior period, unchanged from 0001213900-21-028682:notes:80]

[0001104659-21-106340:notes:104]
The authorized common stock of the Company is 50,000,000 shares, including 45,000,000 shares of Class A common stock, par value, $0.0001, and 5,000,000 shares of Class B common stock, par value, $0.0001. The Company may (depending on the terms of the Business Combination) be required to increase the authorized number of shares at the same time as its stockholders vote on the Business Combination to the extent the Company seeks stockholder approval in connection with its Business Combination. Holders of the Company’s Class A and Class B common stock vote together as a single class and are entitled to one vote for each share of Class A and Class B common stock they own.  At June 30, 2021 and December 31, 2020, there were 4,312,500 shares of Class B common stock issued and outstanding at both dates and there were 4,343,415 and 3,172,650 shares, respectively , of Class A common stock issued and outstanding (excluding 12,906,585 and 14,077,350 shares, respectively, subject to possible redemption).

[0001104659-21-106340:notes:105]
[same as prior period, unchanged from 0001213900-21-028682:notes:82]

[0001104659-21-106340:notes:106]
The Company is authorized to issue 1,000,000 shares of preferred stock, par value $0.0001, with such designations, voting and other rights and preferences as may be determined from time to time by the Company’s board of directors. At June 30, 2021 and December 31, 2020, there were no shares of preferred stock issued or outstanding.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001104659-21-106340:notes:107]
NOTE 8 – COMMITMENTS AND CONTINGENCIES

[0001104659-21-106340:notes:108]
Business Combination Costs

[0001104659-21-106340:notes:109]
In connection with identifying an initial Business Combination candidate and negotiating an initial Business Combination, the Company has entered into and expects to enter into additional engagement letters or agreements with various consultants, advisors, professionals and others. The services under these engagement letters and agreements are material in amount and in some instances include contingent or success fees. Contingent or success fees (but not deferred underwriting compensation) would be charged to operations in the quarter that an initial Business Combination is consummated. In most instances (except with respect to our independent registered public accounting firm), these engagement letters and agreements are expected to specifically provide that such counterparties waive their rights to seek repayment from the funds in the Trust Account.

[0001104659-21-106340:notes:110]
Risks and Uncertainties – COVID-19

[0001104659-21-106340:notes:111]
Management continues to evaluate the impact of the COVID-19 pandemic on the industry and has concluded that while it is reasonably possible that the virus could have a negative effect on the Company’s financial position, results of its operations and/or search for a target company and/or a target company’s financial position and results of its operations, the specific impact is not readily determinable as of the date of these financial statements.  The financial statements do not include any adjustments that might result from the outcome of this uncertainty.


## us-gaap:SubsequentEventsTextBlock

[0001104659-21-106340:notes:112]
NOTE 9 – SUBSEQUENT EVENT – MERGER

[0001104659-21-106340:notes:113]
On July 16, 2021, subsequent to the fiscal quarter ended June 30, 2021, the fiscal quarter to which this Quarterly Report on Form 10-Q relates, we consummated the business combination, or the Business Combination, contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of the Company a special purpose acquisition company, which is our predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among the Company, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the merger as a wholly owned subsidiary of the Company (the “Business Combination”). Upon the closing of the Business Combination, the Company changed its name to Evolv Technologies Holdings, Inc. and the officers of NewHold Investments Corp resigned and the officers of Evolv became the officers of the Company.  Evolv is engaged in the business of providing artificial intelligence touchless security screening.  Evolv is based in Waltham, Massachusetts.

[0001104659-21-106340:notes:114]
Holders of 8,755,987 shares of the Company Class A common stock sold in its initial public offering properly exercised their right to have such shares redeemed for a full pro rata portion of the trust account holding the proceeds from Comapny public offering, calculated as of two business days prior to the consummation of the Business Combination, which was approximately $10.00 per share, or $87,564,196.77 in the aggregate. As a result of the Business Combination, each share of Legacy Evolv preferred stock and common stock was converted into the right to receive approximately 0.378 shares of Evolv Technologies Holdings, Inc’s Class A common stock. Additionally, the 4,312,500 shares of Company Class B common stock held by NewHold Industrial Technology Holdings LLC, automatically converted to 4,312,500 shares of Evolv Technologies Holdings, Inc’s Class A common stock.

[0001104659-21-106340:notes:115]
Cash proceeds of the Business Combination were funded through a combination of Company cash held in trust, net of redemptions, and $300.0 million in aggregate gross proceeds to Evolv from the Private Investment in Public Equity (“PIPE”).
