# EVLV MD&A — 0001104659-21-106340


## mdna

[0001104659-21-106340:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001104659-21-106340:mdna:2]
The following discussion and analysis of the Company’s financial condition and results of operations should be read in conjunction with the condensed consolidated financial statements and the notes thereto contained elsewhere in this report.

[0001104659-21-106340:mdna:3]
[same as prior period, unchanged from 0001213900-21-028682:mdna:3]

[0001104659-21-106340:mdna:4]
[same as prior period, unchanged from 0001213900-21-028682:mdna:4]

[0001104659-21-106340:mdna:5]
As of June 30, 2021 we were a blank check company incorporated on January 24, 2020 as a Delaware corporation and formed for the purpose of effecting a merger, capital stock exchange, asset acquisition, stock purchase, reorganization or similar business combination with one or more businesses (the “Initial Business Combination”).  We completed our Initial Business Combination on July 16, 2021 (as further discussed below) using cash from the proceeds of our initial public offering that was completed in August 2020 (the “Public Offering”) and the sale of warrants in a private placement (the “Private Placement”) that occurred simultaneously with the completion of the Public Offering (the “Private Placement Warrants”), our capital stock, debt or a combination of cash, stock and debt.

[0001104659-21-106340:mdna:6]
The issuance of additional shares of our stock in an Initial Business Combination:

[0001104659-21-106340:mdna:7]
[same as prior period, unchanged from 0001213900-21-028682:mdna:7]

[0001104659-21-106340:mdna:8]
[same as prior period, unchanged from 0001213900-21-028682:mdna:8]

[0001104659-21-106340:mdna:9]
[same as prior period, unchanged from 0001213900-21-028682:mdna:9]

[0001104659-21-106340:mdna:10]
[same as prior period, unchanged from 0001213900-21-028682:mdna:10]

[0001104659-21-106340:mdna:11]
[same as prior period, unchanged from 0001213900-21-028682:mdna:11]

[0001104659-21-106340:mdna:12]
Similarly, if we issue debt securities or incur other indebtedness to finance our Initial Business Combination, it could result in:

[0001104659-21-106340:mdna:13]
[same as prior period, unchanged from 0001213900-21-028682:mdna:13]

[0001104659-21-106340:mdna:14]
|  | ● | acceleration of our obligations to repay the indebtedness even if we make all principal and interest payments when due if we breach certain covenants that require the maintenance of certain financial ratios or reserves without a waiver or renegotiation of that covenant; |

[0001104659-21-106340:mdna:15]
[same as prior period, unchanged from 0001213900-21-028682:mdna:15]

[0001104659-21-106340:mdna:16]
|  | ● | our inability to obtain necessary additional financing if the debt security or other indebtedness contains covenants restricting our ability to obtain such financing while the debt security or other indebtedness is outstanding; |

[0001104659-21-106340:mdna:17]
[same as prior period, unchanged from 0001213900-21-028682:mdna:17]

[0001104659-21-106340:mdna:18]
[same as prior period, unchanged from 0001213900-21-028682:mdna:18]

[0001104659-21-106340:mdna:19]
[same as prior period, unchanged from 0001213900-21-028682:mdna:19]

[0001104659-21-106340:mdna:20]
[same as prior period, unchanged from 0001213900-21-028682:mdna:20]

[0001104659-21-106340:mdna:21]
|  | ● | limitations on our ability to borrow additional amounts for expenses, capital expenditures, acquisitions, debt service requirements, execution of our strategy and other purposes and; |

[0001104659-21-106340:mdna:22]
[same as prior period, unchanged from 0001213900-21-028682:mdna:22]

[0001104659-21-106340:mdna:23]
At June 30, 2021, we had approximately $181,000 in cash outside of the Trust Account.  We expect to incur significant costs in the pursuit of an Initial Business Combination and we cannot assure you that our plans to complete an Initial Business Combination will be successful.

[0001104659-21-106340:mdna:24]
[same as prior period, unchanged from 0001213900-21-028682:mdna:26]

[0001104659-21-106340:mdna:25]
On July 16, 2021, subsequent to the fiscal quarter ended June 30, 2021, the fiscal quarter to which this Report relates, we consummated the business combination, or the Business Combination, contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the merger as a wholly-owned subsidiary of NHIC. Upon the closing of the Business Combination, NHIC changed its name to Evolv Technologies Holdings, Inc. with its Class A common stock continuing to be listed on Nasdaq under the ticker symbol “EVLV,” its warrants continuing to be listed on Nasdaq under the symbol “EVLVW” and its units continuing to be listed on Nasdaq under the symbol “EVLVU.”  Evolv Technologies Holding, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001104659-21-106340:mdna:26]
As used in this Report, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of the Business Combination and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Business Combination.

[0001104659-21-106340:mdna:27]
Upon the closing of the Business Combination, NHIC changed its name to Evolv Technologies Holdings, Inc. and the officers of NewHold Investments Corp resigned and the officers of Evolv became the officers of the Company.  Evolv is engaged in the business of providing artificial intelligence touchless security screening.  Evolv is based in Waltham, Massachusetts.

[0001104659-21-106340:mdna:28]
See the Prospectus, dated June 28, 2021 and our Form 8-K filed with the SEC on June 28, 2021 and July 22, 2021, respectively, for additional information about the Merger Agreement.

[0001104659-21-106340:mdna:29]
Except as otherwise expressly provided herein, the information in this Report does not reflect the consummation of the Business Combination, which, as discussed above, occurred subsequent to the period covered hereunder.

[0001104659-21-106340:mdna:30]
[same as prior period, unchanged from 0001213900-21-028682:mdna:24]

[0001104659-21-106340:mdna:31]
Management continues to evaluate the impact of the COVID-19 pandemic on the industry and has concluded that while it is reasonably possible that the virus could have a negative effect on the Company’s financial position, results of its operations and/or search for a target company and/or a target company’s financial position and results of its operations, the specific impact is not readily determinable as of the date of these financial statements.  The financial statements do not include any adjustments that might result from the outcome of this uncertainty.

[0001104659-21-106340:mdna:32]
Results of Operations and Known Trends or Future Events

[0001104659-21-106340:mdna:33]
For the period from January 24, 2020 (date of inception) to June 30, 2021 our activities consisted of formation and preparation for the Public Offering and, subsequent to the Public Offering, identifying and completing a suitable Initial Business Combination.  As such, we had no operations or significant operating expenses until August 2020.

[0001104659-21-106340:mdna:34]
Our normal operating costs include costs associated with our search for an Initial Business Combination, costs associated with our governance and public reporting and state franchise taxes expected to total approximately $17,000 per month (see below), a charge of $15,000 per month from our Sponsor (see Note 1 to condensed consolidated financial statements) for administrative services.  Our costs in the three and six months ended June 30, 2021 also include the costs of our public reporting, governance and related costs, subsequent to the Public Offering as well as professional and consulting fees and travel associated with evaluating various Initial Business Combination candidates.  Costs associated with our governance and public reporting have increased since the Public Offering and were approximately $129,000 and $178,000, respectively, for the three and six months ended June 30, 2021. Costs associated with professional, due diligence and consulting fees related to our review of business combination candidates were approximately $6,360,000 and $7,539,000, respectively, for the three and six months ended June 30, 2021.  As we identify Initial Business Combination candidates, our costs are expected to increase significantly in connection with negotiating and executing a definitive agreement and related agreements as well as additional professional, due diligence and consulting fees and travel costs that will be required in connection with an Initial Business Combination.   We expect our costs to increase significantly in connection with negotiating and executing a merger agreement and related agreements as well as additional professional, due diligence and consulting fees and travel costs that will be required in connection with an Initial Business Combination.  Costs to adjust our warrant liabilities to market value at each reporting period were approximately $959,000 and $3,605,000, respectively, for the three and six months ended June 30, 2021.

[0001104659-21-106340:mdna:35]
Since our operating costs are not expected to be deductible for federal income tax purposes, we are subject to federal income taxes on the income from the Trust Account less taxes.  However, we are permitted to withdraw interest earned from the Trust Account for the payment of taxes.

[0001104659-21-106340:mdna:36]
Our Public Offering and Private Placement closed in August 2020 as more fully described in “Liquidity and Capital Resources” below.  The proceeds in the Trust Account were initially invested in a money market fund that invests solely in direct U.S. government obligations meeting the applicable conditions of Rule 2a-7 of the Investment Company Act of 1940.  In August 2020, the money market fund was largely liquidated and the trust assets were invested in U.S. government treasury bills which matured in February 2021 and were replaced with U.S. government treasury bills maturing in May 2021.  In May 2021, the proceeds from the maturity of the U.S. government treasury bills were invested in a money market fund meeting the conditions previously described.  The Company’s U.S. treasury bills yield approximately 0.1% on a yearly basis.  Interest on the Trust Account was approximately $10,000 and $29,000, respectively, for the three and six months ended June 30, 2021.  At the interest rate earned on the current portfolio in the trust account, it is unlikely that the income on the trust assets will be sufficient to fund the tax and working capital payments that are permitted to be withdrawn from the trust.

[0001104659-21-106340:mdna:37]
As discussed further in Note 6 to the condensed consolidated financial statements, the Company accounts for its outstanding public and private warrants as components as derivative liabilities in the accompanying unaudited condensed consolidated financial statements. As a result, the Company is required to measure the fair value of the public and private warrants at the end of each reporting period and recognize changes in the fair value from the prior period in the Company’s operating results for each current period.

[0001104659-21-106340:mdna:38]
[same as prior period, unchanged from 0001213900-21-028682:mdna:36]

[0001104659-21-106340:mdna:39]
In August 2020, we consummated the Public Offering of an aggregate of 17,250,000 Units (including the full exercise of the underwriters’ overallotment option) at a price of $10.00 per unit generating gross proceeds of approximately $172,500,000 before underwriting discounts and expenses. Simultaneously with the consummation of the Public Offering, we consummated the Private Placement of 5,700,000 Private Placement Warrants, each exercisable to purchase one share of our Class A common stock at $11.50 per share, to the Sponsor and the Anchor Investor, at a price of $1.00 per Private Placement Warrant, generating gross proceeds, before expenses, of approximately $5,700,000.

[0001104659-21-106340:mdna:40]
The net proceeds from the Public Offering and Private Placement was approximately $174,256,000, net of the non-deferred portion of the underwriting commissions of $3,450,000 and offering costs and other expenses of approximately $494,000.  $172,500,000 of the proceeds of the Public Offering and the Private Placement have been deposited in the Trust Account and are not available to us for operations (except for withdrawal of interest amounts, if available, to pay taxes and $250,000 per year in working capital).  At June 30, 2021, we had approximately $181,000 of cash available outside of the Trust Account to fund our activities until we consummate an Initial Business Combination.   In addition, we are permitted to withdraw cash from interest earned on the trust account for payment of taxes and for up to $250,000 of working capital.

[0001104659-21-106340:mdna:41]
Until the consummation of the Public Offering, the Company’s only sources of liquidity were an initial purchase of shares of our common stock for approximately $30,000 by the Sponsor and the Anchor Investor, and a total of $47,000 loaned by the Sponsor against the issuance of an unsecured promissory note (the “Note”).  The Note was non-interest bearing and was paid in full on August 2020 in connection with the closing of the Public Offering.

[0001104659-21-106340:mdna:42]
For the six months ended June 30, 2021, cash used in operating activities was approximately $1,147,000. Net loss of approximately $11,708,000 was affected by other expense for the change in the fair value of the warrant liability of $3,605,000 as well as income earned on investments held in the Trust Account of approximately $29,000. Changes in operating assets and liabilities provided approximately $6,985,000 of cash for operating activities.  For the period from January 24, 2020 (inception) to June 30, 2020, the Company’s cash needs were funded primarily with $25,000 contributed by the initial shareholders in connection with their purchase of Class B common stock and $25,000 borrowed from the Sponsor under a note that was paid at the closing of the Company’s Public Offering in January 2021.

[0001104659-21-106340:mdna:43]
For the period from January 24, 2020 to June 30, 2020, our activities were funded primarily by (a) $25,000 investment in our Class B common stock by our initial shareholders and (b) $25,000 in loans from our Sponser.

[0001104659-21-106340:mdna:44]
The Company believes that it has sufficient working capital available to it at June 30, 2021 to fund its operations at least until it completes its Business Combination or for the next twelve months.

[0001104659-21-106340:mdna:45]
The Company has until August 4, 2022 to complete an Initial Business Combination.  If the Company does not complete an Initial Business Combination by August 4, 2022, the Company will (i) cease all operations except for the purposes of winding up; (ii) as promptly as reasonably possible, but not more than ten business days thereafter, redeem the public shares for a per share price equal to a pro rata portion of the Trust Account, including interest, but less taxes payable (and less up to $100,000 of interest to pay dissolution expenses) and (iii) as promptly as reasonably possible following such redemption, dissolve and liquidate the balance of the Company’s net assets to its creditors and remaining stockholders, as part of its plan of dissolution and liquidation. The initial stockholders have waived their redemption rights with respect to their founder shares; however, if the initial stockholders or any of their affiliates acquire shares of Class A common stock in or after the Public Offering, they will be entitled to a pro rata share of the Trust Account upon the Company’s redemption or liquidation in the event the Company does not complete an Initial Business Combination within the required time period.

[0001104659-21-106340:mdna:46]
In the event of such liquidation, it is possible that the per share value of the residual assets remaining available for distribution (including Trust Account assets) will be less than the price per unit in the Public Offering.  At the interest rate earned on the current portfolio in the trust account, it is unlikely that the income on the trust assets will be sufficient to fund the tax and working capital payments that are permitted from the trust.

[0001104659-21-106340:mdna:47]
As discussed in Recent Developments – Merger Agreement, on July 16, 2021 the Company’s Initial Business Combination was consummated.

[0001104659-21-106340:mdna:48]
[same as prior period, unchanged from 0001213900-21-028682:mdna:44]

[0001104659-21-106340:mdna:49]
We have no obligations, assets or liabilities which would be considered off-balance sheet arrangements. We do not participate in transactions that create relationships with unconsolidated entities or financial partnerships, often referred to as variable interest entities, which would have been established for the purpose of facilitating off-balance sheet arrangements.

[0001104659-21-106340:mdna:50]
We have not entered into any off-balance sheet financing arrangements, established any special purpose entities, guaranteed any debt or commitments of other entities, or entered into any agreements for non-financial assets.

[0001104659-21-106340:mdna:51]
As discussed in Recent Developments – Merger Agreement, on July 16, 2021 the Company’s Initial Business Combination was consummated.

[0001104659-21-106340:mdna:52]
[same as prior period, unchanged from 0001213900-21-028682:mdna:47]

[0001104659-21-106340:mdna:53]
At June 30, 2021, we did not have any long-term debt, capital lease obligations, operating lease obligations or long-term liabilities.  In connection with the Public Offering, we entered into an Administrative Support Agreement with an affiliate of our Sponsor, pursuant to which the Company pays that affiliate $15,000 per month for office space, utilities and secretarial and administrative support.

[0001104659-21-106340:mdna:54]
Upon completion of the Initial Business Combination or the Company’s liquidation, the Company will cease paying or accruing these monthly fees.

[0001104659-21-106340:mdna:55]
In connection with identifying an Initial Business Combination candidate, the Company expects to enter into engagement letters or agreements with various consultants, advisors, professionals and others in connection with an Initial Business Combination.  The services under these engagement letters and agreements are likely to be material in amount and in some instances include contingent or success fees.  Contingent or success fees (but not deferred underwriting compensation) would be charged to operations in the quarter that an Initial Business Combination is consummated.  In most instances (except with respect to our independent registered public accounting firm), these engagement letters and agreements are expected to specifically provide that such counterparties waive their rights to seek repayment from the funds in the Trust Account.

[0001104659-21-106340:mdna:56]
As discussed in Recent Developments – Merger Agreement, on July 16, 2021 the Company’s Initial Business Combination was consummated.

[0001104659-21-106340:mdna:57]
[same as prior period, unchanged from 0001213900-21-028682:mdna:51]

[0001104659-21-106340:mdna:58]
The preparation of financial statements and related disclosures in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities at the date of the financial statements, and income and expenses during the periods reported.  Actual results could materially differ from those estimates.  The Company has identified the following as its critical accounting policies:

[0001104659-21-106340:mdna:59]
[same as prior period, unchanged from 0001213900-21-028682:mdna:53]

[0001104659-21-106340:mdna:60]
Section 102(b)(1) of the JOBS Act exempts emerging growth companies from being required to comply with new or revised financial accounting standards until private companies (that is, those that have not had a Securities Act registration statement declared effective or do not have a class of securities registered under the Exchange Act) are required to comply with the new or revised financial accounting standards. The JOBS Act provides that a company can elect to opt out of the extended transition period and comply with the requirements that apply to non-emerging growth companies but any such an election to opt out is irrevocable. The Company has elected not to opt out of such extended transition period which means that when an accounting standard is issued or revised and it has different application dates for public or private companies, the Company, as an emerging growth company, can adopt the new or revised standard at the time private companies adopt the new or revised standard.  This may make comparison of the Company’s financial statements with another public company which is neither an emerging growth company nor an emerging growth company which has opted out of using the extended transition period difficult or impossible because of the potential differences in accounting standards used.

[0001104659-21-106340:mdna:61]
[same as prior period, unchanged from 0001213900-21-028682:mdna:55]

[0001104659-21-106340:mdna:62]
The Company complies with the requirements of the FASB ASC 340-10-S99-1 and SEC Staff Accounting Bulletin (SAB) Topic 5A — ”Expenses of Offering”. Costs incurred in connection with preparation for the Offering were approximately $9,981,000 including underwriters’ discount paid and deferred of $9,488,000.  Such costs were allocated among the equity and warrant liability components based on the relative fair value of the warrants and approximately $9,596,000 has been charged to equity for the equity components and approximately $390,000 has been charged to other expense for the warrant liability components upon completion of the Public Offering.

[0001104659-21-106340:mdna:63]
[same as prior period, unchanged from 0001213900-21-028682:mdna:57]

[0001104659-21-106340:mdna:64]
As discussed in Note 3, all of the 17,250,000 public shares sold as part of Units in the Public Offering contain a redemption feature which allows for the redemption of public shares if the Company holds a stockholder vote or there is a tender offer for shares in connection with a Business Combination. In accordance with FASB ASC 480, redemption provisions not solely within the control of the Company require the security to be classified outside of permanent equity. Ordinary liquidation events, which involve the redemption and liquidation of all of the entity’s equity instruments, are excluded from the provisions of FASB ASC 480. Although the Company did not specify a maximum redemption threshold, its charter provides that in no event will it redeem its public shares in an amount that would cause its net tangible assets (stockholders’ equity) to be less than $5,000,001 upon the closing of a Business Combination.

[0001104659-21-106340:mdna:65]
The Company recognizes changes in redemption value immediately as they occur and adjusts the carrying value of the securities at the end of each reporting period. Increases or decreases in the carrying amount of redeemable common stock are affected by adjustments to additional paid-in capital. Accordingly, at June 30, 2021 and December 31 2020, 12,906,585 and 14,077,350 shares, respectively, of the 17,250,000 public shares were classified outside of permanent equity.

[0001104659-21-106340:mdna:66]
[same as prior period, unchanged from 0001213900-21-028682:mdna:60]

[0001104659-21-106340:mdna:67]
Net income (loss) per common share is computed by dividing net income (loss) applicable to common stockholders by the weighted average number of shares of common stock outstanding for the period. The Company has not considered the effect of the warrants sold in the Public Offering and Private Placement to purchase an aggregate of 14,325,000 shares of Class A common stock in the calculation of diluted income (loss) per share, since their inclusion would be anti-dilutive under the treasury stock method. As a result, diluted income (loss) per common share is the same as basic loss per common share for the period.

[0001104659-21-106340:mdna:68]
The Company’s statement of operations includes a presentation of income (loss) per share for common stock subject to redemption in a manner similar to the two-class method of income (loss) per share. Net income (loss) per share, basic and diluted for Class A common stock is calculated by dividing the interest income earned on the funds in the Trust Account, net of income tax expense and franchise tax expense, by the weighted average number of shares of Class A common stock outstanding since their original issuance. Net income (loss) per common share, basic and diluted, for shares of Class B common stock is calculated by dividing the net income (loss), less income attributable to Class A common stock, by the weighted average number of shares of Class B common stock outstanding for the period. Net income (loss) available to each class of common stockholders is as follows for the three and six months ended June 30, 2021 and for the three months ended June 30, 2020 and for period from January 24, 2020 (date of inception) to June 30, 2020:

[0001104659-21-106340:mdna:69]
| ​ | ​ | ​ | ​ | ​ | For the Period | ​ | ​ | ​ | ​ | For the Period |
| ​ | ​ | ​ | ​ | ​ | From January | ​ | ​ | ​ | ​ | From January |
| ​ | ​ | Three months | ​ | 24, 2020 (date | ​ | Six months | ​ | 24, 2020 (date |
| ​ | ​ | Ended | ​ | of inception) to | ​ | Ended | ​ | of inception) to |
| ​ |  | June 30, |  | June 30, |  | June 30, |  | June 30, |
| ​ |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net income available to Class A common stockholders: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Interest income | ​ | $ | 9,000 | ​ | $ | — | ​ | $ | 28,000 | ​ | $ | — |
| Less: Income and franchise taxes | ​ |  | (9,000) | ​ |  | — | ​ |  | (28,000) | ​ |  | — |
| Net income attributable to Class A common stockholders | ​ | $ | — | ​ | $ | — | ​ | $ | — | ​ | $ | — |
| Net income available to Class B common stockholders: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net loss | ​ | $ | (7,626,000) | ​ | $ | (2,000) | ​ | $ | (11,708,000) | ​ | $ | (2,000) |
| Less: amount attributable to Class A common stockholders | ​ |  | — | ​ |  | — | ​ |  | — | ​ |  | — |
| Net (loss) attributable to Class B common stockholders | ​ | $ | (7,626,000) | ​ | $ | (2,000) | ​ | $ | (11,708,000) | ​ | $ | (2,000) |

[0001104659-21-106340:mdna:70]
[same as prior period, unchanged from 0001213900-21-028682:mdna:64]

[0001104659-21-106340:mdna:71]
The Company follows the asset and liability method of accounting for income taxes under FASB ASC, 740, “Income Taxes.” Deferred tax assets and liabilities are recognized for the estimated future tax consequences attributable to differences between the financial statements carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that included the enactment date. Valuation allowances are established, when necessary, to reduce deferred tax assets to the amount expected to be realized.

[0001104659-21-106340:mdna:72]
The Company’s currently taxable income consists of interest income on the Trust Account net of taxes. The Company’s general and administrative costs are generally considered start-up costs and are not currently deductible. During the three and six months ended June 30, 2021 and the three months ended June 30, 2021 and the period from January 24, 2020 (date of inception) to June 30, 2021, the Company recorded income tax expense of approximately $0 and $0, respectively, related to interest income earned on the Trust Account net of taxes. The Company’s effective tax rate for the three and six months ended June 30, 2021 and the three months ended June 30, 2021 and the period from January 24, 2020 (date of inception) to June 30, 2021  was approximately -0 -% and -0 -%, and -0-% and -0-%, respectively, which differs from the expected income tax rate due to the start-up costs (discussed above) which are not currently deductible as well as business combination and warrant liability charges or credits which may not be deductible, and the low level of interest income.  At June 30, 2021 and December 31, 2020, the Company has a deferred tax asset of approximately $575,000 and $200,000, respectively.

[0001104659-21-106340:mdna:73]
FASB ASC 740 prescribes a recognition threshold and a measurement attribute for the financial statement recognition and measurement of tax positions taken or expected to be taken in a tax return. For those benefits to be recognized, a tax position must be more-likely-than-not to be sustained upon examination by taxing authorities. There were no unrecognized tax benefits as of June 30, 2021. The Company recognizes accrued interest and penalties related to unrecognized tax benefits as income tax expense. No amounts were accrued for the payment of interest and penalties at June 30, 2021. The Company is currently not aware of any issues under review that could result in significant payments, accruals or material deviation from its position. The Company is subject to income tax examinations by major taxing authorities since inception.

[0001104659-21-106340:mdna:74]
24

[0001104659-21-106340:mdna:75]
[same as prior period, unchanged from 0001213900-21-028682:mdna:68]

[0001104659-21-106340:mdna:76]
The Company accounts for warrants as either equity-classified or liability-classified instruments based on an assessment of the warrant’s specific terms and applicable authoritative guidance FASB ASC 480, Distinguishing Liabilities from Equity (“ASC 480”) and ASC 815, Derivatives and Hedging (“ASC 815”). The assessment considers whether the warrants are freestanding financial instruments pursuant to ASC 480, meet the definition of a liability pursuant to ASC 480, and whether the warrants meet all of the requirements for equity classification under ASC 815, including whether the warrants are indexed to the Company’s own shares, among other conditions for equity classification. This assessment, which requires the use of professional judgment, is conducted at the time of warrant issuance and as of each subsequent quarterly period end date while the warrants are outstanding.

[0001104659-21-106340:mdna:77]
For issued or modified warrants that meet all of the criteria for equity classification, the warrants are required to be recorded as a component of additional paid-in capital at the time of issuance. For issued or modified warrants that do not meet all the criteria for equity classification, the warrants are required to be recorded as liabilities at their initial fair value on the date of issuance, and at fair value in each balance sheet date thereafter. Changes in the estimated fair value of the warrants are recognized as a non-cash gain or loss on the statements of operations. Costs associated with issuing the warrants accounted for as liabilities are charged to operations when the warrants are issued.  The fair value of the public warrants and the private placement warrants were initially estimated using a Monte Carlo simulation approach.  Following the separate trading of the Company’s common stock and public warrants, the private placement warrants fair values were estimated using a Black-Scholes-Merton approach.
