# EVLV 10-Q controls and the auditor's report


## item_4_controls

[0001104659-21-106340:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001104659-21-106340:item_4_controls:2]
Limitations on Effectiveness of Controls and Procedures

[0001104659-21-106340:item_4_controls:3]
In designing and evaluating our disclosure controls and procedures, management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply judgment in evaluating the benefits of possible controls and procedures relative to their costs.

[0001104659-21-106340:item_4_controls:4]
Evaluation of Disclosure Controls and Procedures

[0001104659-21-106340:item_4_controls:5]
Disclosure controls and procedures are controls and other procedures that are designed to ensure that information required to be disclosed in our reports filed or submitted under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms.  Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed in company reports filed or submitted under the Exchange Act is accumulated and communicated to management, including our Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosure.

[0001104659-21-106340:item_4_controls:6]
25

[0001104659-21-106340:item_4_controls:7]
On April 12, 2021, the SEC issued a Staff Statement on Accounting and Reporting Considerations for Warrants Issued by Special Purpose Acquisition Companies (“SPAC’s”), the “Statement.”  In the Statement, the SEC indicates its view that certain terms of the warrants issued in connection with a SPAC Initial Public Offering (“Public Warrants”) and private placement warrants typically issued by a SPAC (“Private Warrants”) call for such warrants to be accounted for as liabilities and not as equity.  The Company has recorded such warrants as equity.  This determination (liability vs. equity) has caused the Company to restate previously issued financial statements that showed the warrants as equity.  Therefore, our management concluded that we did not maintain effective internal control over financial reporting as of June 30, 2021, March 31, 2021, December 31, 2020 and September 30, 2020, due to a material weakness in our internal control over financial reporting related to a lack of an effectively designed control over the evaluation of settlement features used to determine the classification of warrant instruments. The need to restate financial statements in this instance constitutes a material weakness in internal control

[0001104659-21-106340:item_4_controls:8]
In light of this material weakness at June 30, 2021, March 31, 2021, December 31, 2020 and September 30, 2020, we modified our procedures to include employing consultants on valuation and specialized knowledge on warrant accounting and we performed additional analysis as deemed necessary to ensure that our financial statements at June 30, 2020 were prepared in accordance with U.S. generally accepted accounting principles. Accordingly, management believes that the financial statements included in this Report present fairly in all material respects our financial position, results of operations and cash flows for the period presented.

[0001104659-21-106340:item_4_controls:9]
As required by Rules 13a-15 and 15d-15 under the Exchange Act, our Chief Executive Officer and Chief Financial Officer carried out an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of June 30, 2021.  Based upon their evaluation, including the discussion in the previous paragraph, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) were not effective as of June 30, 2021 due to the material weakness in our internal control over financial reporting described above.

[0001104659-21-106340:item_4_controls:10]
Changes in Internal Control over Financial Reporting

[0001104659-21-106340:item_4_controls:11]
During the three months ended June 30, 2021, there has been no change in our internal control over financial reporting that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting except as described below.

[0001104659-21-106340:item_4_controls:12]
In light of the correction of the previously filed financial statements, we are enhancing our processes to identify and appropriately apply applicable accounting requirements to better evaluate and understand the nuances of the complex accounting standards that apply to our financial statements. Our plans at this time include retaining consultants with technical accounting expertise in derivatives accounting as well as valuation consultants with expertise in warrants and other derivative instruments. We believe our efforts will enhance our controls relating to warrant accounting, but we can offer no assurance that our controls will not require additional review and modification in the future as industry accounting practices based on the SEC Statement may evolve over time.

[0001104659-21-106340:item_4_controls:13]
26
