# EVLV 8-K — 0001104659-21-106326 filed 2021-08-16

## item codes, every 8-K on or before 2021-08-16

- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2021-08-16

- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-21-106326:8k_2_02:1]
EX-99.1
2
tm2124831d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-21-106326:8k_2_02:2]
Exhibit
99.1

[0001104659-21-106326:8k_2_02:3]
| Investor Relations: Brian Norris Vice President of Investor Relations bnorris@evolvtechnology.com | Public Relations: Fitz Barth Director of Communications fbarth@evolvtechnology.com |

[0001104659-21-106326:8k_2_02:4]
Evolv Technology Reports Strong Second Quarter
Financial Results

[0001104659-21-106326:8k_2_02:5]
– Company Issues Full Year Revenue
Outlook of 375% Growth in 2021 –

[0001104659-21-106326:8k_2_02:6]
|  | · | Q2 Revenue of $4.5 million, up 590% year-over-year |

[0001104659-21-106326:8k_2_02:7]
|  | · | Q2 Total Contract Value (TCV) of $10.9 million, up 361% year-over-year |

[0001104659-21-106326:8k_2_02:8]
|  | · | Begins Trading on NASDAQ following combination with NewHold Investment Corp. |

[0001104659-21-106326:8k_2_02:9]
Waltham, Massachusetts – August 16,
2021 – Evolv Technology (NASDAQ: EVLV), the global leader in weapons detection security screening, today announced financial
results for its second quarter ended June 30, 2021.

[0001104659-21-106326:8k_2_02:10]
“We’re delighted to be reporting strong
second quarter results which reflect the growing demand for our innovative approach to keeping venues safe,” said Peter George,
Chief Executive Officer of Evolv Technology. “Our growth continues to be fueled by visionary security experts that are deploying
Evolv Express in venues to improve their security posture and their visitors’ experience, while lowering their operating costs.
Looking ahead, we believe that we are well positioned to extend our leadership in the weapons detection security screening market.”

[0001104659-21-106326:8k_2_02:11]
Results for the Second Quarter of 2021

[0001104659-21-106326:8k_2_02:12]
Total revenue for the second quarter of 2021 was
$4.5 million, an increase of 590% compared to $0.6 million for the second quarter of 2020. Total Contract Value (“TCV”) of
orders booked for the second quarter of 2021 was $10.9 million, an increase of 361% compared to $2.6 million in the second quarter of
2020. GAAP net loss for the second quarter of 2021 was $22.4 million, or $0.71 per basic and diluted share, compared to a GAAP net loss
of $5.1 million, or $0.22 per basic and diluted share, for the second quarter of 2020. As of June 30, 2021, the Company had $10.0
million of cash and cash equivalents compared to $4.7 million at December 31, 2020. On July 16, 2021, the Company completed
its previously announced business combination with NewHold Investment Corp., which raised approximately $385 million of cash for the Company
which the Company intends to use for general working capital requirements and to fund the Company’s accelerating growth.

[0001104659-21-106326:8k_2_02:13]
Results for the First Six Months of 2021

[0001104659-21-106326:8k_2_02:14]
Total revenue for the first six months of
2021 was $8.5 million, an increase of 558% compared to $1.3 million for the first six months of 2020. TCV of orders booked for the
first six months of 2021 was $20.2 million, an increase of 226% compared to $6.0 million in the first six months of 2020. GAAP net
loss for the first six months of 2021 was $36.1 million, or $1.22 per basic and diluted share, compared to a GAAP net loss of $11.5
million, or $0.49 per basic and diluted share, for the first six months of 2020.

[0001104659-21-106326:8k_2_02:15]
Company Issues Outlook for 2021

[0001104659-21-106326:8k_2_02:16]
The Company today issued its full year outlook
for TCV of orders booked and total revenue. The Company’s outlook is based on the current indications for its business, which may
change at any time.

[0001104659-21-106326:8k_2_02:17]
|  | · | The Company expects the TCV of orders booked in 2021 to be in the range of $53 million to $55 million. |

[0001104659-21-106326:8k_2_02:18]
|  | · | The Company expects total revenue in 2021 to be in the range of $20 million to $21 million. |

[0001104659-21-106326:8k_2_02:19]
|  | · | The Company expects GAAP net loss per share to be in the range of $0.75 to $0.80 based on approximately 84 million weighted average diluted shares outstanding. |

[0001104659-21-106326:8k_2_02:20]
Company to Host Live Conference Call and Webcast

[0001104659-21-106326:8k_2_02:21]
The Company’s management team plans to
host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s
outlook for the business and other matters. The conference call may be accessed in the United States by dialing +1.844.867.6169 and using
access code “EVLV”. The conference call may be accessed outside of the United States by dialing +1.409.207.6975 and using
access code “EVLV”. The conference call will be simultaneously webcast on the Company’s investor relations website,
which can be accessed at http://ir.evolvtechnology.com. A replay of the conference call will be available approximately two hours
after the call for a period of two weeks by dialing 1.866.207.1041 or +1.402.970.0847 and using access code 5737477 or by accessing the
webcast replay on the Company’s investor relations website at http://ir.evolvtechnology.com. The Company has used, and intends
to continue to use, the investor relations portion of its website as a means of disclosing material non-public information and for complying
with disclosure obligations under Regulation FD.

[0001104659-21-106326:8k_2_02:22]
About Evolv Technology

[0001104659-21-106326:8k_2_02:23]
Evolv Technology (NASDAQ: EVLV) is the global
leader in weapons detection security screening. Our mission is enabling a better experience and better security for venues, creating
a safer world to work, learn, and play by transforming physical security to make everywhere safer. This enhances the visitor experience
and improves weapons detection. We give sports fans, theme park visitors, concertgoers, shoppers, employees, students, and others peace
of mind so that they can gather without fear of violence. Our security system, delivered as a SaaS-based offering, has scanned over 75 million people, second only to the Department of Homeland Security’s Transportation Security Administration in the United States,
and our technology combines powerful, advanced sensors with proven artificial intelligence (AI), security ecosystem integrations, and
comprehensive venue analytics to reliably detect threats 10 times faster than traditional metal detectors. Evolv Technology, Evolv Express®,
Evolv Insights™, and Evolv Cortex AI™ are registered trademarks or trademarks of Evolv Technologies, Inc. in the United
States and other jurisdictions. For more information, visit https://evolvtechnology.com.

[0001104659-21-106326:8k_2_02:24]
Forward-Looking Statements

[0001104659-21-106326:8k_2_02:25]
Evolv
Technology

[0001104659-21-106326:8k_2_02:26]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE
LOSS

[0001104659-21-106326:8k_2_02:27]
(In thousands, except share and per share data)

[0001104659-21-106326:8k_2_02:28]
(Unaudited)

[0001104659-21-106326:8k_2_02:29]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue |  | $ | 2,452 |  |  | $ | 17 |  |  | $ | 4,954 |  |  | $ | 73 |  |
| Subscription revenue |  |  | 1,513 |  |  |  | 490 |  |  |  | 2,813 |  |  |  | 949 |  |
| Service revenue |  |  | 515 |  |  |  | 142 |  |  |  | 712 |  |  |  | 267 |  |
| Total revenue |  |  | 4,480 |  |  |  | 649 |  |  |  | 8,479 |  |  |  | 1,289 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue |  |  | 2,075 |  |  |  | 37 |  |  |  | 4,304 |  |  |  | 198 |  |
| Subscription revenue |  |  | 861 |  |  |  | 364 |  |  |  | 1,456 |  |  |  | 702 |  |
| Service revenue |  |  | 413 |  |  |  | 85 |  |  |  | 540 |  |  |  | 207 |  |
| Total cost of revenue |  |  | 3,349 |  |  |  | 486 |  |  |  | 6,300 |  |  |  | 1,107 |  |
| Gross profit |  |  | 1,131 |  |  |  | 163 |  |  |  | 2,179 |  |  |  | 182 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 1,077 |  |  |  | 2,947 |  |  |  | 4,689 |  |  |  | 6,541 |  |
| Research and development |  |  | 5,090 |  |  |  | 1,371 |  |  |  | 8,774 |  |  |  | 3,553 |  |
| General and administrative |  |  | 1,280 |  |  |  | 869 |  |  |  | 4,179 |  |  |  | 1,499 |  |
| Total operating expenses |  |  | 7,447 |  |  |  | 5,187 |  |  |  | 17,642 |  |  |  | 11,593 |  |
| Loss from operations |  |  | (6,316 | ) |  |  | (5,024 | ) |  |  | (15,463 | ) |  |  | (11,411 | ) |
| Interest expense |  |  | 3,255 |  |  |  | 80 |  |  |  | 5,702 |  |  |  | 123 |  |
| Loss on extinguishment of debt |  |  | 11,820 |  |  |  | - |  |  |  | 11,820 |  |  |  | - |  |
| Change in fair value of derivative liability |  |  | 795 |  |  |  | - |  |  |  | 2,220 |  |  |  | - |  |
| Change in fair value of common stock warrant liability |  |  | 185 |  |  |  | - |  |  |  | 921 |  |  |  | - |  |
| Total other expense |  |  | 16,055 |  |  |  | 80 |  |  |  | 20,663 |  |  |  | 123 |  |
|  |  |  |  |  |  |  |  |  |  |  | 6 |  |  |  |  |  |
| Net loss and comprehensive loss attributable to common stockholders – basic and diluted |  | $ | (22,371 | ) |  | $ | (5,104 | ) |  | $ | (36,126 | ) |  | $ | (11,534 | ) |
| Net loss per share – basic and diluted |  | $ | (0.71 | ) |  | $ | (0.22 | ) |  | $ | (1.22 | ) |  | $ | (0.49 | ) |
| Weighted average ordinary shares outstanding – basic and diluted |  |  | 31,540,397 |  |  |  | 23,568,291 |  |  |  | 29,593,131 |  |  |  | 23,491,518 |  |

[0001104659-21-106326:8k_2_02:30]
Evolv
Technology

[0001104659-21-106326:8k_2_02:31]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-21-106326:8k_2_02:32]
(In thousands, except share and per share data)

[0001104659-21-106326:8k_2_02:33]
(Unaudited)

[0001104659-21-106326:8k_2_02:34]
|  |  | June 30, 2021 |  |  | December 31, 2020 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  |  | 9,963 |  |  |  | 4,704 |  |
| Restricted Cash |  |  | 400 |  |  |  | - |  |
| Accounts receivable, net |  |  | 2,799 |  |  |  | 1,401 |  |
| Inventory |  |  | 3,869 |  |  |  | 2,742 |  |
| Prepaid expenses and other current assets |  |  | 9,237 |  |  |  | 1,462 |  |
| Total current assets |  |  | 26,268 |  |  |  | 10,309 |  |
| Commission asset, noncurrent |  |  | 2,192 |  |  |  | 1,730 |  |
| Property and equipment, net |  |  | 17,552 |  |  |  | 9,316 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  |  | - |  |
| Other long-term assets |  |  | 239 |  |  |  | - |  |
| Total assets |  | $ | 46,526 |  |  | $ | 21,355 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 9,798 |  |  |  | 4,437 |  |
| Accrued expenses and other current liabilities |  |  | 5,493 |  |  |  | 3,727 |  |
| Current portion of deferred revenue |  |  | 3,769 |  |  |  | 3,717 |  |
| Current portion of long-term debt |  |  | 29,802 |  |  |  | - |  |
| Other current liabilities |  |  | 163 |  |  |  | 238 |  |
| Total current liabilities |  |  | 49,025 |  |  |  | 12,119 |  |
| Deferred revenue |  |  | 681 |  |  |  | 480 |  |
| Common stock warrant liability |  |  | 922 |  |  |  | 1 |  |
| Derivative liability |  |  | 20,206 |  |  |  | 1,000 |  |
| Financing obligation, noncurrent |  |  | - |  |  |  | 132 |  |
| Long-term debt, noncurrent |  |  | 18,352 |  |  |  | 16,432 |  |
| Total liabilities |  |  | 89,186 |  |  |  | 30,164 |  |
| Convertible preferred stock and shareholders’ equity |  |  |  |  |  |  |  |  |
| Convertible preferred stock |  |  | 75,877 |  |  |  | 75,877 |  |
| Common stock |  |  | 35 |  |  |  | 26 |  |
| Additional paid-in capital |  |  | 11,439 |  |  |  | 9,169 |  |
| Accumulated deficit |  |  | (130,007 | ) |  |  | (93,881 | ) |
| Total shareholders’ deficit |  |  | (118,537 | ) |  |  | (84,686 | ) |
| Total liabilities and shareholders’ equity |  |  | 46,526 |  |  |  | 21,355 |  |

[0001104659-21-106326:8k_2_02:35]
EVOlv
TECHNOLOGY

[0001104659-21-106326:8k_2_02:36]
Consolidated
Statements Of Cash Flows

[0001104659-21-106326:8k_2_02:37]
(In thousands)

[0001104659-21-106326:8k_2_02:38]
(Unaudited)

[0001104659-21-106326:8k_2_02:39]
|  |  | Six Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (36,126 | ) |  | $ | (11,534 | ) |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 1,102 |  |  |  | 394 |  |
| Stock-based compensation |  |  | 1,617 |  |  |  | 122 |  |
| Noncash interest expense |  |  | 5,455 |  |  |  | - |  |
| Provision recorded for allowance for doubtful accounts |  |  | (63 | ) |  |  | (16 | ) |
| Loss on extinguishment of debt |  |  | 11,820 |  |  |  | - |  |
| Change in fair value of derivative liability |  |  | 2,220 |  |  |  | - |  |
| Change in fair value of common stock warrant liability |  |  | 921 |  |  |  | - |  |
| Changes in operating assets and liabilities |  |  | (3,900 | ) |  |  | (2,075 | ) |
| Net cash provided by operating activities |  |  | (16,954 | ) |  |  | (13,109 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property and equipment |  |  | (9,292 | ) |  |  | (2,106 | ) |
| Net cash used in investing activities |  |  | (9,292 | ) |  |  | (2,106 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from issuance of Series B-1 convertible preferred stock, net of issuance costs |  |  | - |  |  |  | 2,994 |  |
| Proceeds from exercise of stock options |  |  | 657 |  |  |  | 70 |  |
| Repayment of financing obligations |  |  | (359 | ) |  |  | (161 | ) |
| Proceeds from long-term debt, net of issuance costs |  |  | 31,882 |  |  |  | 3,154 |  |
| Net cash provided by financing activities |  |  | 32,180 |  |  |  | 6,057 |  |
| Net increase (decrease) in cash |  |  | 5,934 |  |  |  | (9,158 | ) |
| Cash, beginning of period |  |  | 4,704 |  |  |  | 17,341 |  |
| Cash, end of period |  | $ | 10,638 |  |  | $ | 8,183 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 247 |  |  | $ | 80 |  |

## item 4.01 — body, verbatim

[0001104659-21-106326:8k_body:1]
Item 4.01

[0001104659-21-106326:8k_body:2]
Changes in Registrant’s Certifying Accountant.

[0001104659-21-106326:8k_body:3]
(b) On August 11, 2021, the audit committee of the Company’s
board of directors approved the engagement of PricewaterhouseCoopers LLP (“PwC”) as the Company’s independent registered
public accounting firm to perform independent audit services for the Company for the fiscal year ending December 31, 2021, beginning with
the Company’s fiscal quarter ending June 30, 2021, effective immediately. During the period from January 24, 2020 (inception) to
December 31, 2020, and the subsequent interim period through August 11, 2021, the Company did not consult with PwC with respect to (i)
the application of accounting principles to a specified transaction, either completed or proposed, the type of audit opinion that might
be rendered on the Company’s financial statements, and neither a written report nor oral advice was provided to the Company that
PwC concluded was an important factor considered by the Company in reaching a decision as to any accounting, auditing or financial reporting
issue, or (ii) any matter that was either the subject of a disagreement (as that term is defined in Item 304(a)(1)(iv) of Regulation S-K
and the related instructions to Item 304 of Regulation S-K) or a reportable event (as that term is defined in Item 304(a)(1)(v) of Regulation
S-K).
