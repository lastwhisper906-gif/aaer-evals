# EVLV note change history — 0001213900-21-028682 → 0001104659-21-106340


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-08-16):
[0001104659-21-106340:note_history:1]
The accompanying unaudited condensed consolidated interim financial statements of the Company are presented in U.S. dollars and in conformity with accounting principles generally accepted in the United States of America (“GAAP”) pursuant to the rules and regulations of the SEC and reflect all adjustments, consisting only of normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the financial position as of June 30, 2021, and the results of operations and cash flows for the periods presented. Certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted pursuant to such rules and regulations. Interim results are not necessarily indicative of results for a full year or any later period.  Certain reclassifications have been made to the December 31, 2020 balance sheet to conform to the current presentation.
  (was, 2021-05-24, similarity 0.9075):
[0001213900-21-028682:note_history:1]
The accompanying unaudited condensed interim financial
statements of the Company are presented in U.S. dollars and in conformity with accounting principles generally accepted in the United
States of America (“GAAP”) pursuant to the rules and regulations of the SEC and reflect all adjustments, consisting only of
normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the financial position as
of March 31, 2021, and the results of operations and cash flows for the periods presented. Certain information and disclosures normally
included in financial statements prepared in accordance with GAAP have been omitted pursuant to such rules and regulations. Interim results
are not necessarily indicative of results for a full year.

- changed (2021-08-16):
[0001104659-21-106340:note_history:2]
The accompanying unaudited condensed consolidated interim financial statements should be read in conjunction with the Company’s audited financial statements and notes thereto included in the Company’s final prospectus dated July 28, 2020, as well as the Company’s Annual Report, Amendment #1 on Form 10-K/A filed with the SEC on May 14, 2021.
  (was, 2021-05-24, similarity 0.9798):
[0001213900-21-028682:note_history:2]
The accompanying unaudited condensed interim financial
statements should be read in conjunction with the Company’s audited financial statements and notes thereto included in the Company’s final
prospectus dated July 28, 2020, as well as the Company’s Annual Report, Amendment #1 on Form 10-K/A filed with the SEC on May 14, 2021.

- added (2021-08-16):
[0001104659-21-106340:note_history:3]
At June 30, 2021, the Company has approximately $181,000 in cash, approximately $7,706,000 of current liabilities and approximately $7,380,000 in negative working capital.  The preponderance of the current liabilities (approximately $7,300,000) results from amounts accrued as payable to professional service firms who have agreed to deferred payment terms, or success fees, that are payable at the closing of a Business Combination.  Such accrued fees were paid upon the closing of the Business Combination on July 16, 2020.  Therefore, in connection with the Company’s assessment of going concern considerations in accordance with FASB Accounting Standards Update (“ASU”) 2014-15, “Disclosures of Uncertainties about an Entity’s Ability to Continue as a Going Concern,” as of June 30, 2021, management has determined that the Company’s current liquidity is sufficient to fund the working capital needs of the Company until the earlier of the consummation of the Business Combination or one year from the date of issuance of these financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2021-08-16):
[0001104659-21-106340:note_history:4]
NEWHOLD INVESTMENT CORP AND SUBSIDIARY.

- added (2021-08-16):
[0001104659-21-106340:note_history:5]
Notes to Condensed Consolidated Financial Statements

- added (2021-08-16):
[0001104659-21-106340:note_history:6]
(unaudited)

- added (2021-08-16):
[0001104659-21-106340:note_history:7]
NOTE 1 – DESCRIPTION OF ORGANIZATION AND BUSINESS OPERATIONS

- added (2021-08-16):
[0001104659-21-106340:note_history:8]
Organization and General:

- added (2021-08-16):
[0001104659-21-106340:note_history:9]
NewHold Investment Corp. (the “Company”) was incorporated in Delaware on January 24, 2020 as NewHold Industrial Corp. and on February 14, 2020 changed its name to NewHold Investment Corp. The Company was formed for the purpose of effecting a merger, capital stock exchange, asset acquisition, stock purchase, reorganization or similar business combination with one or more businesses (a “Business Combination”). The Company is an “emerging growth company,” as defined in Section 2(a) of the Securities Act of 1933, as amended, or the “Securities Act,” as modified by the Jumpstart Our Business Startups Act of 2012 (the “JOBS Act”).  On July 16, 2021 in connection with the Company’s initial Business Combination (See Note 9), the Company changed its name to Evolv Technologies Holdings, Inc.

- added (2021-08-16):
[0001104659-21-106340:note_history:10]
At June 30, 2021, the Company had not commenced any operations.  All activity for the period from January 24, 2020 (date of inception) to June 30, 2021 relates to the Company’s formation and the initial public offering (“Public Offering”) described below, and subsequent to the Public Offering, searching for a potential business combination. The Company will not generate any operating revenues until after completion of its initial Business Combination, at the earliest. The Company expects to generate non-operating income in the form of interest income on the proceeds derived from the Public Offering.

- added (2021-08-16):
[0001104659-21-106340:note_history:11]
All dollar amounts are rounded to the nearest thousand dollars.

- added (2021-08-16):
[0001104659-21-106340:note_history:12]
Sponsor and Financing:

- added (2021-08-16):
[0001104659-21-106340:note_history:13]
The Company’s sponsor is NewHold Industrial Technology Holdings LLC, a Delaware limited liability company (the “Sponsor”).   The registration statement for the Public Offering (as described in Note 3) was declared effective by the United States Securities and Exchange Commission (the “SEC”) on July 30, 2020.  The Company intends to finance a Business Combination with proceeds from the $172,500,000 Public Offering (Note 3) and a $5,700,000 Private Placement (as defined in Note 4), net of expenses. Upon the closing of the Public Offering and the Private Placement, $172,500,000 was deposited in a trust account (the “Trust Account”).

- added (2021-08-16):
[0001104659-21-106340:note_history:14]
The Trust Account:

- added (2021-08-16):
[0001104659-21-106340:note_history:15]
The funds in the Trust Account can be invested only in U.S. government treasury bills with a maturity of one hundred and eighty five (185) days or less or in money market funds meeting certain conditions under Rule 2a-7 under the Investment Company Act of 1940 which invest only in direct U.S. government obligations. Funds will remain in the Trust Account until the earlier of (i) the consummation of its initial Business Combination or (ii) the distribution of the Trust Account as described below. The remaining funds outside the Trust Account may be used to pay for business, legal and accounting due diligence on prospective acquisition targets and continuing general and administrative expenses.

- added (2021-08-16):
[0001104659-21-106340:note_history:16]
The Company’s amended and restated certificate of incorporation provides that, other than the withdrawal of interest to pay tax obligations and up to $250,000 per year for working capital purposes, if any, (less up to $100,000 of interest to pay dissolution expenses), none of the funds held in the Trust Account will be released until the earliest of: (a) the completion of the initial Business Combination, (b) the redemption of any public shares properly submitted in connection with a stockholder vote to amend the Company’s amended and restated certificate of incorporation (i) to modify the substance or timing of the ability of holders of the public shares to seek redemption in connection with our initial business combination or the Company’s obligation to redeem 100% of the public shares if the Company does not complete the initial Business Combination within 24 months from the closing of the Public Offering, August 4, 2022, or (ii) with respect to any other provision relating to stockholders’ rights or pre-Business Combination activity, and (c) the redemption of the public shares if the Company is unable to complete the initial Business Combination within 24 months from the closing of the Public Offering, subject to applicable law. The proceeds deposited in the Trust Account could become subject to the claims of creditors, if any, which could have priority over the claims of the Company’s public stockholders.

- added (2021-08-16):
[0001104659-21-106340:note_history:17]
Business Combination:

- added (2021-08-16):
[0001104659-21-106340:note_history:18]
The Company’s management has broad discretion with respect to the specific application of the net proceeds of the Public Offering, although substantially all of the net proceeds of the Public Offering are intended to be generally applied toward consummating a Business Combination with a Target Business. As used herein, “Target Business” is one or more target businesses that together have a fair market value equal to at least 80% of the balance in the Trust Account (less deferred underwriting commissions and any taxes payable on interest earned) at the time of signing a definitive agreement in connection with the Company’s initial Business Combination.  See Note 9.

- added (2021-08-16):
[0001104659-21-106340:note_history:19]
The Company, after signing a definitive agreement for a Business Combination, will either (i) seek stockholder approval of the Business Combination at a meeting called for such purpose in connection with which stockholders may seek to redeem their shares, regardless of whether they vote for or against the Business Combination, for cash equal to their pro rata share of the aggregate amount then on deposit in the Trust Account as of two business days prior to the consummation of the initial Business Combination, including interest but less taxes payable and amounts released for working capital, or (ii) provide stockholders with the opportunity to have their shares redeemed by the Company by means of a tender offer (and thereby avoid the need for a stockholder vote) for an amount in cash equal to their pro rata share of the aggregate amount then on deposit in the Trust Account as of two business days prior to the consummation of the initial Business Combination, including interest but less taxes payable and amounts released to the Company for working capital. The decision as to whether the Company will seek stockholder approval of the Business Combination or will allow stockholders to sell their shares in a tender offer will be made by the Company, solely in its discretion, and will be based on a variety of factors such as the timing of the transaction and whether the terms of the transaction would otherwise require the Company to seek stockholder approval unless a vote is required by the rules of the Nasdaq Capital Market. If the Company seeks stockholder approval, it will complete its Business Combination only if a majority of the outstanding shares of Class A and Class B common stock voted are voted in favor of the Business Combination. However, in no event will the Company redeem its public shares in an amount that would cause its net tangible assets to be less than $5,000,001 upon consummation of a Business Combination. In such case, the Company would not proceed with the redemption of its public shares and the related Business Combination, and instead may search for an alternate Business Combination.

- added (2021-08-16):
[0001104659-21-106340:note_history:20]
If the Company holds a stockholder vote or there is a tender offer for shares in connection with a Business Combination, a public stockholder will have the right to redeem its shares for an amount in cash equal to its pro rata share of the aggregate amount then on deposit in the Trust Account as of two business days prior to the consummation of the initial Business Combination, including interest but less taxes payable and amounts released to the Company for working capital. As a result, such shares of Class A common stock will be recorded at redemption amount and classified as temporary equity upon the completion of the Public Offering, in accordance with Financial Accounting Standards Board (“FASB”) ASC 480, “Distinguishing Liabilities from Equity.”  In August 2020, the Company deposited an aggregate of $172,500,000 from the proceeds of the Public Offering, including the underwriters’ exercise of their overallotment option and the sale of $5,700,000 for the Private Placement Warrants, net of expenses.

- added (2021-08-16):
[0001104659-21-106340:note_history:21]
The Company will have 24 months (until August 4, 2022) from the closing date of the Public Offering to complete its initial Business Combination. If the Company does not complete a Business Combination within this period of time, it shall (i) cease all operations except for the purposes of winding up; (ii) as promptly as reasonably possible, but not more than ten business days thereafter subject to lawfully available funds therefor, redeem 100% of the public shares of Class A common stock for a per share pro rata portion of the Trust Account, including interest, but less taxes payable and amounts released for working capital (less up to $100,000 of such net interest to pay dissolution expenses) and (iii) as promptly as possible following such redemption, dissolve and liquidate the balance of the Company’s net assets to its creditors and remaining stockholders, as part of its plan of dissolution and liquidation. The initial stockholders have entered into letter agreements with us, pursuant to which they have waived their rights to participate in any redemption with respect to their initial shares; however, if the initial stockholders or any of the Company’s officers, directors or affiliates acquire shares of Class A common stock in or after the Public Offering, they will be entitled to a pro rata share of the Trust Account upon the Company’s redemption or liquidation in the event the Company does not complete a Business Combination within 24 months from the closing of the Public Offering.

- added (2021-08-16):
[0001104659-21-106340:note_history:22]
In the event of such distribution, it is possible that the per share value of the residual assets remaining available for distribution (including Trust Account assets) will be less than the price per Unit in the Public Offering.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-08-16):
[0001104659-21-106340:note_history:23]
Principles of Consolidation:

- added (2021-08-16):
[0001104659-21-106340:note_history:24]
The condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiary, NHIC Sub Inc., a wholly owned subsidiary of the Company, incorporated in Delaware, formed to facilitate the acquisition of Evolv (Note 9). All significant intercompany balances and transactions have been eliminated in consolidation.

- changed (2021-08-16):
[0001104659-21-106340:note_history:25]
The accompanying unaudited condensed consolidated interim financial statements of the Company are presented in U.S. dollars and in conformity with accounting principles generally accepted in the United States of America (“GAAP”) pursuant to the rules and regulations of the SEC and reflect all adjustments, consisting only of normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the financial position as of June 30, 2021, and the results of operations and cash flows for the periods presented. Certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted pursuant to such rules and regulations. Interim results are not necessarily indicative of results for a full year or any later period.  Certain reclassifications have been made to the December 31, 2020 balance sheet to conform to the current presentation.
  (was, 2021-05-24, similarity 0.9075):
[0001213900-21-028682:note_history:25]
The accompanying unaudited condensed interim financial
statements of the Company are presented in U.S. dollars and in conformity with accounting principles generally accepted in the United
States of America (“GAAP”) pursuant to the rules and regulations of the SEC and reflect all adjustments, consisting only of
normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the financial position as
of March 31, 2021, and the results of operations and cash flows for the periods presented. Certain information and disclosures normally
included in financial statements prepared in accordance with GAAP have been omitted pursuant to such rules and regulations. Interim results
are not necessarily indicative of results for a full year.

- changed (2021-08-16):
[0001104659-21-106340:note_history:26]
The accompanying unaudited condensed consolidated interim financial statements should be read in conjunction with the Company’s audited financial statements and notes thereto included in the Company’s final prospectus dated July 28, 2020, as well as the Company’s Annual Report, Amendment #1 on Form 10-K/A filed with the SEC on May 14, 2021.
  (was, 2021-05-24, similarity 0.9798):
[0001213900-21-028682:note_history:26]
The accompanying unaudited condensed interim financial
statements should be read in conjunction with the Company’s audited financial statements and notes thereto included in the Company’s final
prospectus dated July 28, 2020, as well as the Company’s Annual Report, Amendment #1 on Form 10-K/A filed with the SEC on May 14, 2021.

- added (2021-08-16):
[0001104659-21-106340:note_history:27]
At June 30, 2021, the Company has approximately $181,000 in cash, approximately $7,706,000 of current liabilities and approximately $7,380,000 in negative working capital.  The preponderance of the current liabilities (approximately $7,300,000) results from amounts accrued as payable to professional service firms who have agreed to deferred payment terms, or success fees, that are payable at the closing of a Business Combination.  Such accrued fees were paid upon the closing of the Business Combination on July 16, 2020.  Therefore, in connection with the Company’s assessment of going concern considerations in accordance with FASB Accounting Standards Update (“ASU”) 2014-15, “Disclosures of Uncertainties about an Entity’s Ability to Continue as a Going Concern,” as of June 30, 2021, management has determined that the Company’s current liquidity is sufficient to fund the working capital needs of the Company until the earlier of the consummation of the Business Combination or one year from the date of issuance of these financial statements.

- changed (2021-08-16):
[0001104659-21-106340:note_history:28]
The Company considers all highly liquid instruments with original maturities of three months or less when acquired, to be cash equivalents.  The Company had no cash equivalents at June 30, 2021 and December 31, 2020.
  (was, 2021-05-24, similarity 0.9337):
[0001213900-21-028682:note_history:28]
The Company considers all
highly liquid instruments with original maturities of three months or less when acquired, to be cash equivalents.  The Company
had no cash equivalents at March 31, 2021.

- changed (2021-08-16):
[0001104659-21-106340:note_history:29]
The Company recognizes changes in redemption value immediately as they occur and adjusts the carrying value of the securities at the end of each reporting period. Increases or decreases in the carrying amount of redeemable common stock are affected by adjustments to additional paid-in capital. Accordingly, at June 30, 2021 and December 31, 2020, 12,906,585 and 14,077,350, respectively, of the 17,250,000 public shares were classified outside of permanent equity.
  (was, 2021-05-24, similarity 0.9894):
[0001213900-21-028682:note_history:29]
The Company recognizes changes in redemption value
immediately as they occur and adjusts the carrying value of the securities at the end of each reporting period. Increases or decreases
in the carrying amount of redeemable common stock are affected by adjustments to additional paid-in capital. Accordingly, at March 31,
2021 and December 31, 2020, 13,669,161 and 14,077,350, respectively, of the 17,250,000 public shares were classified outside of permanent
equity.

- changed (2021-08-16):
[0001104659-21-106340:note_history:30]
Net income (loss) per common share is computed by dividing net income (loss) applicable to common stockholders by the weighted average number of shares of common stock outstanding for the period. The Company has not considered the effect of the warrants sold in the Public Offering and Private Placement to purchase an aggregate of 14,325,000 shares of Class A common stock in the calculation of diluted income (loss) per share, since their inclusion would be anti-dilutive under the treasury stock method. As a result, diluted income (loss) per common share is the same as basic loss per common share for the periods presented.
  (was, 2021-05-24, similarity 0.991):
[0001213900-21-028682:note_history:30]
Net income (loss) per common share is computed
by dividing net income (loss) applicable to common stockholders by the weighted average number of shares of common stock outstanding for
the period. The Company has not considered the effect of the warrants sold in the Public Offering and Private Placement to purchase an
aggregate of 14,325,000 shares of Class A common stock in the calculation of diluted income (loss) per share, since their inclusion would
be anti-dilutive under the treasury stock method. As a result, diluted income (loss) per common share is the same as basic loss per common
share for the period.

- changed (2021-08-16):
[0001104659-21-106340:note_history:31]
The Company’s statement of operations includes a presentation of income (loss) per share for common stock subject to redemption in a manner similar to the two-class method of income (loss) per share. Net income (loss) per share, basic and diluted for Class A common stock is calculated by dividing the interest income earned on the funds in the Trust Account, net of income tax expense and franchise tax expense, by the weighted average number of shares of Class A common stock outstanding since their original issuance. Net income (loss) per common share, basic and diluted, for shares of Class B common stock is calculated by dividing the net income (loss), less income attributable to Class A common stock, by the weighted average number of shares of Class B common stock outstanding for the period. Net income (loss) available to each class of common stockholders is as follows for the
  (was, 2021-05-24, similarity 0.9473):
[0001213900-21-028682:note_history:31]
The Company’s statement of operations includes
a presentation of income (loss) per share for common stock subject to redemption in a manner similar to the two-class method of income
(loss) per share. Net income (loss) per share, basic and diluted for Class A common stock is calculated by dividing the interest income
earned on the funds in the Trust Account, net of income tax expense and franchise tax expense, by the weighted average number of shares
of Class A common stock outstanding since their original issuance. Net income (loss) per common share, basic and diluted, for shares of
Class B common stock is calculated by dividing the net income (loss), less income attributable to Class A common stock, by the weighted
average number of shares of Class B common stock outstanding for the period. Net income (loss) available to each class of common stockholders
is as follows for the three months ended March 31, 2021 and for the period from January 24, 2020 (date of inception) to March 31, 2020:

- added (2021-08-16):
[0001104659-21-106340:note_history:32]
three and six months ended June 30, 2021 and for the three months ended June 30, 2020 and for the period from January 24, 2020 (date of inception) to June 30, 2020:

- added (2021-08-16):
[0001104659-21-106340:note_history:33]
| ​ | ​ | ​ | ​ | For the Period | ​ | ​ | ​ | For the Period |
| ​ | ​ | ​ | ​ | From January | ​ | ​ | ​ | From January |
| ​ | ​ | Three months | ​ | 24, 2020 (date | ​ | Six months | ​ | 24, 2020 (date |
| ​ | ​ | Ended | ​ | of inception) to | ​ | Ended | ​ | of inception) to |
| ​ | ​ | June 30, | ​ | June 30, | ​ | June 30, | ​ | June 30, |
| ​ |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net income available to Class A common stockholders: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Interest income | ​ | $ | 9,000 | ​ | $ | — | ​ | $ | 29,000 | ​ | $ | — |
| Less: Income and franchise taxes | ​ |  | (9,000) | ​ |  | — | ​ |  | (29,000) | ​ |  | — |
| Net income attributable to Class A common stockholders | ​ | $ | — | ​ | $ | — | ​ | $ | — | ​ | $ | — |
| Net income available to Class B common stockholders: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Net loss | ​ | $ | (7,626,000) | ​ | $ | (2,000) | ​ | $ | (11,708,000) | ​ | $ | (2,000) |
| Less: amount attributable to Class A common stockholders | ​ |  | — | ​ |  | — | ​ |  | — | ​ |  | — |
| Net (loss) attributable to Class B common stockholders | ​ | $ | (7,626,000) | ​ | $ | (2,000) | ​ | $ | (11,708,000) | ​ | $ | (2,000) |

- changed (2021-08-16):
[0001104659-21-106340:note_history:34]
The fair value of the Company’s assets and liabilities, which qualify as financial instruments under FASB Accounting Standards Codification (“ASC 820”), “Fair Value Measurements and Disclosures,” approximates the carrying amounts represented in the financial statements.
  (was, 2021-05-24, similarity 0.922):
[0001213900-21-028682:note_history:34]
The fair value of the Company’s assets and
liabilities, which qualify as financial instruments under Financial Accounting Standards Board (“FASB”) Accounting Standards
Codification (“ASC 820”), “Fair Value Measurements and Disclosures,” approximates the carrying amounts represented
in the financial statements.

- added (2021-08-16):
[0001104659-21-106340:note_history:35]
The Company’s currently taxable income consists of interest income on the Trust Account net of taxes. The Company’s general and administrative costs are generally considered start-up costs and are not currently deductible. During the three and six months ended June 30, 2021 and the three months ended June 30, 2021 and the period from January 24, 2020 (date of inception) to June 30, 2021, the Company recorded income tax expense of approximately $-0-and $-0-, respectively, related to interest income earned on the Trust Account net of taxes. The Company’s effective tax rate for the three and six months ended June 30, 2021 and the three months ended June 30, 2021 and the period from January 24, 2020 (date of inception) to June 30, 2021  was approximately -0-% and -0-%, and -0-% and -0-%, respectively, which differs from the expected income tax rate due to the start-up costs (discussed above) which are not currently deductible as well as business combination and warrant liability charges or credits which may not be deductible, and the low level of interest income.  At June 30, 2021 and December 31, 2020, the Company has a deferred tax asset of approximately $575,000 and $200,000, respectively. The Company records a full allowance reducing such deferred tax assets to zero since they are not reasonably assured of realizabilty due to the Company’s lack of operations, losses and pending change of control.

- added (2021-08-16):
[0001104659-21-106340:note_history:36]
FASB ASC 740 prescribes a recognition threshold and a measurement attribute for the financial statement recognition and measurement of tax positions taken or expected to be taken in a tax return. For those benefits to be recognized, a tax position must be more-likely-than-not to be sustained upon examination by taxing authorities. There were no unrecognized tax benefits as of June 30, 2021. The Company recognizes accrued interest and penalties related to unrecognized tax benefits as income tax expense. No amounts were accrued for the payment of interest and penalties at June 30, 2021. The Company is currently not aware of any issues under review that could result in significant payments, accruals or material deviation from its position. The Company is subject to income tax examinations by major taxing authorities since inception.

- added (2021-08-16):
[0001104659-21-106340:note_history:37]
In August 2020, the FASB issued Accounting Standards Update (“ASU”) 2020-06, Debt — Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging — Contracts in Entity’s Own Equity (Subtopic 815-40) (“ASU 2020-06”) to simplify accounting for certain financial instruments. ASU 2020-06 eliminates the current models that require separation of beneficial conversion and cash conversion features from convertible instruments and simplifies the derivative scope exception guidance pertaining to equity classification of contracts in an entity’s own equity. The new standard also introduces additional disclosures for convertible debt and freestanding instruments that are indexed to and settled in an entity’s own equity. ASU 2020-06 amends the diluted earnings per share guidance, including the requirement to use the if-converted method for all convertible instruments. ASU 2020-06 is effective January 1, 2022 and should be applied on a full or modified retrospective basis, with early adoption permitted beginning on January 1, 2021. The Company is currently evaluating the impact that the pronouncement will have on the financial statements.

- added (2021-08-16):
[0001104659-21-106340:note_history:38]
Management does not believe that any other recently issued, but not yet effective, accounting pronouncements, if currently adopted, would have a material effect on the Company’s financial statements.

- changed (2021-08-16):
[0001104659-21-106340:note_history:39]
Management has evaluated subsequent events to determine if events or transactions occurring after the date of the condensed consolidated balance sheet but before the condensed financial statements were available to be issued require potential adjustment to or disclosure in the condensed consolidated financial statements and has concluded that all such events that would require adjustment or disclosure have been recognized or disclosed, see Note 9.
  (was, 2021-05-24, similarity 0.8429):
[0001213900-21-028682:note_history:39]
Management has evaluated subsequent events to determine
if events or transactions occurring after the date of the financial statements but before the financial statements were available to be
issued require potential adjustment to or disclosure in the financial statements and has concluded that all such events that would require
adjustment or disclosure have been recognized or disclosed.

- removed (2021-08-16):
[0001213900-21-028682:note_history:40]
|  |  | Three months Ended March 31, 2021 |  |  | For the Period From January 24, 2020 (date of inception) to March 31, 2020 |  |
| Net income available to Class A common stockholders: |  |  |  |  |  |  |
| Interest income |  | $ | 19,000 |  |  | $ | - |  |
| Less: Income and franchise taxes |  |  | (19,000 | ) |  |  | - |  |
| Net income attributable to Class A common stockholders |  | $ | - |  |  | $ | - |  |
| Net income available to Class B common stockholders: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (4,082,000 | ) |  | $ | (2,000 | ) |
| Less: amount attributable to Class A common stockholders |  |  | - |  |  |  | - |  |
| Net (loss) attributable to Class B common stockholders |  | $ | (4,082,000 | ) |  | $ | (2,000 | ) |

- removed (2021-08-16):
[0001213900-21-028682:note_history:41]
The Company’s currently taxable income consists
of interest income on the Trust Account net of taxes. The Company’s general and administrative costs are generally considered start-up
costs and are not currently deductible. During the three months ended March 31, 2021 and the period from January 24, 2020 (date of inception)
to March 31, 2020, the Company recorded income tax expense of approximately $-0- for both periods, respectively, related to interest income
earned on the Trust Account net of taxes. The Company’s effective tax rate for the three months ended March 31, 2021 and the period
from January 24, 2020 (date of inception) to March 31, 2020 was approximately -0 -%, for both periods which differs from the expected
income tax rate due to the start-up costs (discussed above) which are not currently deductible as well as business combination and warrant
liability charges or credits which may not be deductible, and the low level of interest income. At March 31, 2021 and December 31, 2020,
the Company has a deferred tax asset of approximately $550,000 and $200,000, respectively, primarily related to start-up and Business
Combination costs. Management has determined that a full valuation allowance of the deferred tax asset is appropriate at this time.

- removed (2021-08-16):
[0001213900-21-028682:note_history:42]
FASB ASC 740 prescribes a recognition threshold
and a measurement attribute for the financial statement recognition and measurement of tax positions taken or expected to be taken in
a tax return. For those benefits to be recognized, a tax position must be more-likely-than-not to be sustained upon examination by taxing
authorities. There were no unrecognized tax benefits as of March 31, 2021. The Company recognizes accrued interest and penalties related
to unrecognized tax benefits as income tax expense. No amounts were accrued for the payment of interest and penalties at March 31, 2021.
The Company is currently not aware of any issues under review that could result in significant payments, accruals or material deviation
from its position. The Company is subject to income tax examinations by major taxing authorities since inception.

- removed (2021-08-16):
[0001213900-21-028682:note_history:43]
In August 2020, the FASB issued Accounting Standards
Update (“ASU”) No. 2020-06, Debt --Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging
--Contracts in Entity’ Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’ Own Equity (“ASU
2020-06”), which simplifies accounting for convertible instruments by removing major separation models required under current GAAP.
The ASU also removes certain settlement conditions that are required for equity-linked contracts to qualify for the derivative scope exception,
and it simplifies the diluted earnings per share calculation in certain areas. The Company adopted ASU 2020-06 on January 1, 2021. Adoption
of the ASU did not impact the Company’s financial position, results of operations or cash flows.

- removed (2021-08-16):
[0001213900-21-028682:note_history:44]
The Company’s management does not believe that
any other recently issued, but not yet effective, accounting standards if currently adopted would have a material effect on the accompanying
financial statements.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-08-16):
[0001104659-21-106340:note_history:45]
In February 2020, the Sponsor purchased 4,312,500 shares of Class B common stock (the “Founder Shares”) for $25,000, or approximately $0.006 per share. In July 2020, the Sponsor transferred an aggregate of 867,500 founder shares, including to the following persons: (1) 32,500 founder shares to each of Marc Saiontz and Suzy Taherian, two of the Company’s independent director nominees, (ii) 35,000 founder shares to each of Neil Glat and Brian Mathis, two of the Company’s independent director nominees, (iii) 40,000 founder shares to Kathleen Harris, one of the Company’s independent director nominees, (iv) 50,000 founder shares to Thomas Sullivan, one of the Company’s independent director nominees, (v) 67,500 founder shares to Adam Deutsch, the Company’s Chief Financial Officer, (vi) 100,000 founder shares to Charlie Baynes-Reid, the Company’s Chief Operating Officer, (vii) 135,000 founder shares to each of Kevin Charlton and Charles Goldman, the Company’s Chief Executive Officer and director, respectively, and (viii)
  (was, 2021-05-24, similarity 0.6897):
[0001213900-21-028682:note_history:45]
In February 2020, the Sponsor purchased 4,312,500
shares of Class B common stock (the “Founder Shares”) for $25,000, or approximately $0.006 per share. In July 2020, the Sponsor
transferred an aggregate of 867,500 founder shares, including to the following persons: (i) 32,500 founder shares to each of Marc Saiontz
and Suzy Taherian, two of the Company’s independent director nominees, (ii) 35,000 founder shares to each of Neil Glat and Brian
Mathis, two of the Company’s independent director nominees, (iii) 40,000 founder shares to Kathleen Harris, one of the Company’s
independent director nominees, (iv) 50,000 founder shares to Thomas Sullivan, one of the Company’s independent director nominees,
(v) 67,500 founder shares to Adam Deutsch, the Company’s Chief Financial Officer, (vi) 100,000 founder shares to Charlie Baynes-Reid,
the Company’s Chief Operating Officer, (vii) 135,000 founder shares to each of Kevin Charlton and Charles Goldman, the Company’s
Chief Executive Officer and director, respectively, and (viii) 200,000 founder shares to Nick Petruska, the Company’s special advisor;
and (ii) the Sponsor forfeited 920,000 shares of Class B common stock and certain funds and accounts managed by Magnetar Financial LLC,
UBS O’Connor LLC, and Mint Tower Capital Management B.V (collectively, the “Anchor Investor”) purchased 920,000 shares
of Class B common stock from the Company for an aggregate purchase price of approximately $5,333, or approximately $0.006 per share resulting
in the Company’s initial stockholders holding an aggregate of 4,312,500 Founder Shares. The Founder Shares are identical to the
Class A common stock included in the Units being sold in the Public Offering except that the Founder Shares automatically convert into
shares of Class A common stock at the time of the initial Business Combination and are subject to certain transfer restrictions, as described
in more detail below.

- added (2021-08-16):
[0001104659-21-106340:note_history:46]
200,000 founder shares to Nick Petruska, the Company’s special advisor; and (ii) the Sponsor forfeited 920,000 shares of Class B common stock and certain funds and accounts managed by Magnetar Financial LLC, UBS O’Connor LLC, and Mint Tower Capital Management B.V (collectively, the “Anchor Investor”) purchased 920,000 shares of Class B common stock from the Company for an aggregate purchase price of approximately $5,333, or approximately $0.006 per share resulting in the Company’s initial stockholders holding an aggregate of 4,312,500 Founder Shares. The Founder Shares are identical to the Class A common stock included in the Units being sold in the Public Offering except that the Founder Shares automatically convert into shares of Class A common stock at the time of the initial Business Combination and are subject to certain transfer restrictions, as described in more detail below.

- changed (2021-08-16):
[0001104659-21-106340:note_history:47]
In order to finance transaction costs in connection with a Business Combination, the Sponsor, an affiliate of the Sponsor, or certain of the Company’s officers and directors or their affiliates may, but are not obligated to, loan the Company funds as may be required (“Working Capital Loans”). If the Company completes a Business Combination, the Company would repay the Working Capital Loans out of the proceeds of the Trust Account released to the Company. Otherwise, the Working Capital Loans would be repaid only out of funds held outside the Trust Account. In the event that a Business Combination does not close, the Company may use a portion of proceeds held outside the Trust Account to repay the Working Capital Loans but no proceeds held in the Trust Account would be used to repay the Working Capital Loans. The Working Capital Loans would either be repaid upon consummation of a Business Combination, without interest, or, at the lender’s discretion, up to $1,500,000 of such Working Capital Loans may be convertible into warrants of the post Business Combination entity. The warrants would be identical to the Private Placement Warrants. Except for the foregoing, the terms of such Working Capital Loans, if any, have not been determined and no written agreements exist with respect to such loans. As of June 30, 2021 and December 31, 2020, no Working Capital Loans were outstanding.
  (was, 2021-05-24, similarity 0.9967):
[0001213900-21-028682:note_history:47]
In order to finance transaction costs in
connection with a Business Combination, the Sponsor, an affiliate of the Sponsor, or certain of the Company’s officers and
directors or their affiliates may, but are not obligated to, loan the Company funds as may be required (“Working Capital
Loans”). If the Company completes a Business Combination, the Company would repay the Working Capital Loans out of the
proceeds of the Trust Account released to the Company. Otherwise, the Working Capital Loans would be repaid only out of funds held
outside the Trust Account. In the event that a Business Combination does not close, the Company may use a portion of proceeds held
outside the Trust Account to repay the Working Capital Loans but no proceeds held in the Trust Account would be used to repay the
Working Capital Loans. The Working Capital Loans would either be repaid upon consummation of a Business Combination, without
interest, or, at the lender’s discretion, up to $1,500,000 of such Working Capital Loans may be convertible into warrants of
the post Business Combination entity. The warrants would be identical to the Private Placement Warrants. Except for the foregoing,
the terms of such Working Capital Loans, if any, have not been determined and no written agreements exist with respect to such
loans. As of March 31, 2021 and December 31, 2020, no Working Capital Loans were outstanding.

- changed (2021-08-16):
[0001104659-21-106340:note_history:48]
The Company has agreed to pay $15,000 a month for office space, utilities and secretarial and administrative support to an affiliate of the Sponsor. Services commenced on the date the securities were first listed on the Nasdaq Capital Market and will terminate upon the earlier of the consummation by the Company of an initial Business Combination or the liquidation of the Company.  During the three and six months ended June 30, 2021, approximately $45,000 and $90,000, respectively, was included in general and administrative expenses for the administrative support fee.
  (was, 2021-05-24, similarity 0.8377):
[0001213900-21-028682:note_history:48]
The Company has agreed to pay $15,000 a month for
office space, utilities and secretarial and administrative support to an affiliate of the Sponsor. Services commenced on the date the
securities were first listed on the Nasdaq Capital Market and will terminate upon the earlier of the consummation by the Company of an
initial Business Combination or the liquidation of the Company. During the three months ended March 31, 2021, approximately $45,000 was
included in general and administrative expenses for the administrative support fee.


## us-gaap:SubsequentEventsPolicyPolicyTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-08-16):
[0001104659-21-106340:note_history:49]
Management has evaluated subsequent events to determine if events or transactions occurring after the date of the condensed consolidated balance sheet but before the condensed financial statements were available to be issued require potential adjustment to or disclosure in the condensed consolidated financial statements and has concluded that all such events that would require adjustment or disclosure have been recognized or disclosed, see Note 9.
  (was, 2021-05-24, similarity 0.8429):
[0001213900-21-028682:note_history:49]
Management has evaluated subsequent events to determine
if events or transactions occurring after the date of the financial statements but before the financial statements were available to be
issued require potential adjustment to or disclosure in the financial statements and has concluded that all such events that would require
adjustment or disclosure have been recognized or disclosed.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-08-16):
[0001104659-21-106340:note_history:50]
NOTE 9 – SUBSEQUENT EVENT – MERGER

- added (2021-08-16):
[0001104659-21-106340:note_history:51]
On July 16, 2021, subsequent to the fiscal quarter ended June 30, 2021, the fiscal quarter to which this Quarterly Report on Form 10-Q relates, we consummated the business combination, or the Business Combination, contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of the Company a special purpose acquisition company, which is our predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among the Company, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the merger as a wholly owned subsidiary of the Company (the “Business Combination”). Upon the closing of the Business Combination, the Company changed its name to Evolv Technologies Holdings, Inc. and the officers of NewHold Investments Corp resigned and the officers of Evolv became the officers of the Company.  Evolv is engaged in the business of providing artificial intelligence touchless security screening.  Evolv is based in Waltham, Massachusetts.

- added (2021-08-16):
[0001104659-21-106340:note_history:52]
Holders of 8,755,987 shares of the Company Class A common stock sold in its initial public offering properly exercised their right to have such shares redeemed for a full pro rata portion of the trust account holding the proceeds from Comapny public offering, calculated as of two business days prior to the consummation of the Business Combination, which was approximately $10.00 per share, or $87,564,196.77 in the aggregate. As a result of the Business Combination, each share of Legacy Evolv preferred stock and common stock was converted into the right to receive approximately 0.378 shares of Evolv Technologies Holdings, Inc’s Class A common stock. Additionally, the 4,312,500 shares of Company Class B common stock held by NewHold Industrial Technology Holdings LLC, automatically converted to 4,312,500 shares of Evolv Technologies Holdings, Inc’s Class A common stock.

- added (2021-08-16):
[0001104659-21-106340:note_history:53]
Cash proceeds of the Business Combination were funded through a combination of Company cash held in trust, net of redemptions, and $300.0 million in aggregate gross proceeds to Evolv from the Private Investment in Public Equity (“PIPE”).
