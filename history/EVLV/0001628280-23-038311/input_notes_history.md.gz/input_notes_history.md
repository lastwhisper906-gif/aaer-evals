# EVLV note change history — 0001628280-23-028865 → 0001628280-23-038311


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0001628280-23-038311:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of September 30, 2023 or December 31, 2022.
  (was, 2023-08-10, similarity 0.9943):
[0001628280-23-028865:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of June 30, 2023 or December 31, 2022.

- changed (2023-11-09):
[0001628280-23-038311:note_history:2]
The Company is not a party to any litigation of a material nature and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.
  (was, 2023-08-10, similarity 0.7183):
[0001628280-23-028865:note_history:2]
The Company is not a party to any litigation of a material nature and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.
In the ordinary course of business, the Company is subject to regulatory and governmental examinations, information gathering requests, inquiries and investigations. We do not expect such examinations, requests, inquiries or investigations to have a material effect on our results of operations, financial condition or liquidity, either individually or in the aggregate.

- added (2023-11-09):
[0001628280-23-038311:note_history:3]
In the ordinary course of business, the Company is subject to regulatory and governmental examinations, information gathering requests, inquiries and investigations. For example, the U.S. Federal Trade Commission ("FTC") has previously requested information about certain aspects of the Company's marketing practices. The Company has provided, and continues to provide, documentation and information responsive to the FTC inquiry. We currently do not expect such examinations, requests, inquiries or investigations to have a material effect on our results of operations, financial condition or liquidity, either individually or in the aggregate.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-11-09):
[0001628280-23-038311:note_history:4]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2023, and for the three and nine months ended September 30, 2023 and 2022 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2022 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2023 and the results of its operations for the three and nine months ended September 30, 2023 and 2022 and cash flows for the nine months ended September 30, 2023 and 2022. The results for the three and nine months ended September 30, 2023 are not necessarily indicative of results to be expected for the year ending December 31, 2023, any other interim periods, or any future year or period.

- removed (2023-11-09):
[0001628280-23-028865:note_history:5]
The accompanying unaudited condensed consolidated financial statements as of June 30, 2023, and for the three and six months ended June 30, 2023 and 2022 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2022 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of June 30, 2023 and the results of its operations for the three and six months ended June 30, 2023 and 2022 and cash flows for the six months ended June 30, 2023 and 2022. The results for the three and six months ended June 30, 2023 are not necessarily indicative of results to be expected for the year ending December 31, 2023, any other interim periods, or any future year or period.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0001628280-23-038311:note_history:6]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2022, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2022. Other than the addition of the accounting policy related to marketable securities as described in Note
  (was, 2023-08-10, similarity 0.8539):
[0001628280-23-028865:note_history:6]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2022, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended

- changed (2023-11-09):
[0001628280-23-038311:note_history:7]
3. Marketable Securities, there have been no material changes to the Company’s significant accounting policies during the nine months ended September 30, 2023.
  (was, 2023-08-10, similarity 0.8322):
[0001628280-23-028865:note_history:7]
December 31, 2022. There have been no material changes to the Company’s significant accounting policies during the six months ended June 30, 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0001628280-23-038311:note_history:8]
|  | September 30,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |
  (was, 2023-08-10, similarity 0.9746):
[0001628280-23-028865:note_history:8]
|  | June 30,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2023-11-09):
[0001628280-23-038311:note_history:9]
Marketable Securities
Marketable securities as of September 30, 2023 consisted of the following:

- added (2023-11-09):
[0001628280-23-038311:note_history:10]
|  | September 30, 2023 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 39,487 |  |  | $ | — |  |  | $ | 39,487 |  |
| Total marketable securities | $ | 39,487 |  |  | $ | — |  |  | $ | 39,487 |  |

- added (2023-11-09):
[0001628280-23-038311:note_history:11]
Marketable securities are reported at fair value and, at September 30, 2023, are comprised solely of zero coupon U.S. treasury bills with maturities of less than one year that are classified as available-for-sale debt securities. The Company did not record any unrealized gains or losses on available-for-sale securities for the three or nine months ended September 30, 2023. The accretion of discounts on marketable securities is included in interest income on the condensed

- added (2023-11-09):
[0001628280-23-038311:note_history:12]
consolidated statements of operations and comprehensive income. The Company did not have any marketable securities as of December 31, 2022.

- added (2023-11-09):
[0001628280-23-038311:note_history:13]
The Company considers an available-for-sale debt security to be impaired if the fair value of the investment is less than its amortized cost basis. The entire difference between the amortized cost basis and the fair value of the Company’s available-for-sale debt securities is recognized on the condensed consolidated statements of operations as an impairment if, (i) the fair value of the security is below its amortized cost and (ii) the Company intends to sell or is more likely than not required to sell the security before recovery of its amortized cost basis. If neither criterion is met, the Company evaluates whether the decline in fair value is due to credit losses or other factors. In making this assessment, the Company considers the changes to the rating of the security by third-party rating agencies, and adverse conditions specific to the security, among other factors. If the Company’s assessment indicates that a credit loss exists, the credit loss is measured based on the Company’s best estimate of the cash flows expected to be collected. When developing its estimate of cash flows expected to be collected, the Company considers all available information relevant to the collectability of the security, including past events, current conditions, and reasonable and supportable forecasts.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0001628280-23-038311:note_history:14]
|  | September 30,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |
  (was, 2023-08-10, similarity 0.9746):
[0001628280-23-028865:note_history:14]
|  | June 30,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0001628280-23-038311:note_history:15]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended September 30, 2023 and 2022, revenue from Motorola's distributor services was $1.7 million and $2.3 million, respectively. During the nine months ended September 30, 2023 and 2022, revenue from Motorola's distributor services was $7.9 million and $5.0 million, respectively. As of September 30, 2023 and December 31, 2022, accounts receivable related to Motorola’s distributor services was $2.0 million and $12.5 million, respectively.
  (was, 2023-08-10, similarity 0.9579):
[0001628280-23-028865:note_history:15]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended June 30, 2023 and 2022, revenue from Motorola's distributor services was $2.9 million and $1.9 million, respectively. During the six months ended June 30, 2023 and 2022, revenue from Motorola's distributor services was $6.2 million and $2.8 million, respectively. As of June 30, 2023 and December 31, 2022, accounts receivable related to Motorola’s distributor services was $3.0 million and $12.5 million, respectively.

- added (2023-11-09):
[0001628280-23-038311:note_history:16]
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB ("Securitas") in 2023. Securitas, directly or through its affiliates, resells the Company's products. During the three months ended September 30, 2023 and 2022, revenue from Securitas' reseller services was $0.4 million and $0.5 million, respectively. During the nine months ended September 30, 2023 and 2022, revenue from Securitas' reseller services was $1.3 million and $0.8 million, respectively. As of September 30, 2023 and December 31, 2022, accounts receivable related to Securitas' reseller services was $0.4 million and $2.2 million, respectively.

- removed (2023-11-09):
[0001628280-23-028865:note_history:17]
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB ("Securitas") in 2023. Securitas, directly or through its affiliates, resells the Company's products. During the three months ended June 30, 2023 and 2022, revenue from Securitas' reseller services was $0.5 million and $0.3 million, respectively. During the six months ended June 30, 2023 and 2022, revenue from Securitas' reseller services was $0.9 million and $0.3 million, respectively. As of June 30, 2023 and December 31, 2022, accounts receivable related to Securitas' reseller services was $0.9 million and $2.2 million, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0001628280-23-038311:note_history:18]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Product revenue | $ | 3,191 |  |  | $ | 9,839 |  |  | $ | 19,188 |  |  | $ | 19,179 |  |
| Leased equipment | 10,231 |  |  | 5,198 |  |  | 24,661 |  |  | 12,208 |  |
| SaaS, maintenance, and other revenue | 4,397 |  |  | 1,180 |  |  | 11,296 |  |  | 2,277 |  |
| Professional services | 360 |  |  | 313 |  |  | 1,440 |  |  | 646 |  |
| License fee and other revenue | 2,012 |  |  | — |  |  | 2,012 |  |  | — |  |
| Total revenue | $ | 20,191 |  |  | $ | 16,530 |  |  | $ | 58,597 |  |  | $ | 34,310 |  |
  (was, 2023-08-10, similarity 0.7538):
[0001628280-23-028865:note_history:18]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Product revenue | $ | 7,243 |  |  | $ | 4,146 |  |  | $ | 15,997 |  |  | $ | 9,340 |  |
| Leased equipment | 7,964 |  |  | 4,006 |  |  | 14,430 |  |  | 7,010 |  |
| SaaS, maintenance, and other revenue | 4,121 |  |  | 729 |  |  | 6,899 |  |  | 1,097 |  |
| Professional services | 497 |  |  | 189 |  |  | 1,080 |  |  | 333 |  |
| Total revenue | $ | 19,825 |  |  | $ | 9,070 |  |  | $ | 38,406 |  |  | $ | 17,780 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0001628280-23-038311:note_history:19]
Revenue Recognition
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.
  (was, 2023-08-10, similarity 0.9994):
[0001628280-23-028865:note_history:19]
Revenue RecognitionThe Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the 
contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

- changed (2023-11-09):
[0001628280-23-038311:note_history:20]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2023.
  (was, 2023-08-10, similarity 0.9704):
[0001628280-23-028865:note_history:20]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of June 30, 2023.

- changed (2023-11-09):
[0001628280-23-038311:note_history:21]
The amount of minimum future leases included in subscription revenue in the table above is based on expected income recognition. As of September 30, 2023, future minimum payments on noncancelable leases are as follows (in thousands):
  (was, 2023-08-10, similarity 0.8413):
[0001628280-23-028865:note_history:21]
The amount of minimum future leases is based on expected income recognition. As of June 30, 2023, future minimum payments on noncancelable leases are as follows (in thousands):

- changed (2023-11-09):
[0001628280-23-038311:note_history:22]
| Year Ending December 31: |  |
| 2023 (three months remaining) | $ | 12,988 |  |
| 2024 | 50,800 |  |
| 2025 | 46,632 |  |
| 2026 | 35,489 |  |
| 2027 | 14,291 |  |
|  | $ | 160,200 |  |
  (was, 2023-08-10, similarity 0.8975):
[0001628280-23-028865:note_history:22]
| Year Ending December 31: |  |
| 2023 (six months remaining) | $ | 21,253 |  |
| 2024 | 41,340 |  |
| 2025 | 37,364 |  |
| 2026 | 26,748 |  |
| 2027 | 7,511 |  |
| Thereafter | 23 |  |
|  | $ | 134,239 |  |

- changed (2023-11-09):
[0001628280-23-038311:note_history:23]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2023 and December 31, 2022, the Company had $3.7 million and $2.9 million in current portion of contract assets and $0.5 million and $1.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2023-08-10, similarity 0.986):
[0001628280-23-028865:note_history:23]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of June 30, 2023 and December 31, 2022, the Company had $4.7 million and $2.9 million in current portion of contract assets and $0.7 million and $1.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2023-11-09):
[0001628280-23-038311:note_history:24]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $4.4 million and $16.5 million during the three and nine months ended September 30, 2023 that was included in the December 31, 2022 deferred revenue balance. The Company recognized revenue of $1.3 million and $6.0 million during the three and nine months ended September 30, 2022 that was included in the December 31, 2021 deferred revenue balance.
  (was, 2023-08-10, similarity 0.7946):
[0001628280-23-028865:note_history:24]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $5.3 million and $12.1 million during the three and six months ended June 30, 2023 that was included in the December 31, 2022 deferred revenue balance. The Company recognized revenue of $2.2 million and $4.7 million during the three and six months ended June 30, 2022 that was included in the December 31, 2021 deferred revenue balance.

- changed (2023-11-09):
[0001628280-23-038311:note_history:25]
| Balance at December 31, 2022 | $ | 35,968 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (16,507) |  |
| Revenue deferred | 53,058 |  |
| Balance at September 30, 2023 | $ | 72,519 |  |
  (was, 2023-08-10, similarity 0.9724):
[0001628280-23-028865:note_history:25]
| Balance at December 31, 2022 | $ | 35,968 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (12,140) |  |
| Revenue deferred | 36,253 |  |
| Balance at June 30, 2023 | $ | 60,081 |  |

- changed (2023-11-09):
[0001628280-23-038311:note_history:26]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue from sales-type leases | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 1,135 |  |
| Interest income on lease receivables | 49 |  |  | 60 |  |  | 153 |  |  | 170 |  |
| Lease income - operating leases | 10,231 |  |  | 5,198 |  |  | 24,661 |  |  | 12,208 |  |
| Total lease revenue | $ | 10,280 |  |  | $ | 5,287 |  |  | $ | 24,814 |  |  | $ | 13,513 |  |
  (was, 2023-08-10, similarity 0.9057):
[0001628280-23-028865:note_history:26]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue from sales-type leases | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,106 |  |
| Interest income on lease receivables | 51 |  |  | 61 |  |  | 104 |  |  | 110 |  |
| Lease income - operating leases | 7,964 |  |  | 4,006 |  |  | 14,430 |  |  | 7,010 |  |
| Total lease revenue | $ | 8,015 |  |  | $ | 4,067 |  |  | $ | 14,534 |  |  | $ | 8,226 |  |

- changed (2023-11-09):
[0001628280-23-038311:note_history:27]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.3 million and $0.5 million during the three and nine months ended September 30, 2023, respectively. Revenue related to leases entered into with related parties were $0.2 million and $0.4 million during the three and nine months ended September 30, 2022, respectively.
  (was, 2023-08-10, similarity 0.9458):
[0001628280-23-028865:note_history:27]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were less than $0.1 million and $0.2 million during the three and six months ended June 30, 2023, respectively. Revenue related to leases entered into with related parties were $0.2 million and $0.3 million during the three and six months ended June 30, 2022, respectively.

- changed (2023-11-09):
[0001628280-23-038311:note_history:28]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Product revenue | $ | 3,191 |  |  | $ | 9,839 |  |  | $ | 19,188 |  |  | $ | 19,179 |  |
| Leased equipment | 10,231 |  |  | 5,198 |  |  | 24,661 |  |  | 12,208 |  |
| SaaS, maintenance, and other revenue | 4,397 |  |  | 1,180 |  |  | 11,296 |  |  | 2,277 |  |
| Professional services | 360 |  |  | 313 |  |  | 1,440 |  |  | 646 |  |
| License fee and other revenue | 2,012 |  |  | — |  |  | 2,012 |  |  | — |  |
| Total revenue | $ | 20,191 |  |  | $ | 16,530 |  |  | $ | 58,597 |  |  | $ | 34,310 |  |
  (was, 2023-08-10, similarity 0.7538):
[0001628280-23-028865:note_history:28]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Product revenue | $ | 7,243 |  |  | $ | 4,146 |  |  | $ | 15,997 |  |  | $ | 9,340 |  |
| Leased equipment | 7,964 |  |  | 4,006 |  |  | 14,430 |  |  | 7,010 |  |
| SaaS, maintenance, and other revenue | 4,121 |  |  | 729 |  |  | 6,899 |  |  | 1,097 |  |
| Professional services | 497 |  |  | 189 |  |  | 1,080 |  |  | 333 |  |
| Total revenue | $ | 19,825 |  |  | $ | 9,070 |  |  | $ | 38,406 |  |  | $ | 17,780 |  |

- changed (2023-11-09):
[0001628280-23-038311:note_history:29]
CommissionsThe Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $10.8 million and $9.0 million as of September 30, 2023 and December 31, 2022, respectively. During the three months ended September 30, 2023 and 2022, the Company recognized commission expense of $1.3 million and $1.2 million, respectively. During the nine months ended September 30, 2023 and 2022, the Company recognized commission expense of $4.4 million and $2.4 million, respectively.
  (was, 2023-08-10, similarity 0.9412):
[0001628280-23-028865:note_history:29]
Commissions
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $10.3 million and $9.0 million as of June 30, 2023 and December 31, 2022, respectively. During the three months ended June 30, 2023 and 2022, the Company recognized commission expense of $1.5 million and $0.9 million, respectively. During the six months ended June 30, 2023 and 2022, the Company recognized commission expense of $3.1 million and $1.2 million, respectively.
