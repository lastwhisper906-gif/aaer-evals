# EVLV 8-K — 0001628280-23-038267 filed 2023-11-09

## item codes, every 8-K on or before 2023-11-09

- 2023-11-09 0001628280-23-038267 — 2.02, 9.01
- 2023-11-06 0001104659-23-114499 — 5.02
- 2023-10-25 0001628280-23-035145 — 4.02
- 2023-10-12 0001104659-23-108693 — 2.02, 7.01, 9.01
- 2023-08-10 0001628280-23-028861 — 2.02, 9.01
- 2023-06-02 0001628280-23-020680 — 5.07
- 2023-05-10 0001628280-23-017243 — 2.02, 9.01
- 2023-04-03 0001628280-23-010402 — 1.02, 2.04, 8.01, 9.01
- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2023-11-09

- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-23-038267:8k_2_02:1]
EX-99.1
2
evlv-20231110exx991.htm
EX-99.1

[0001628280-23-038267:8k_2_02:2]
Document

[0001628280-23-038267:8k_2_02:3]
Exhibit 99.1

[0001628280-23-038267:8k_2_02:4]
Investor Relations:

[0001628280-23-038267:8k_2_02:5]
Brian Norris

[0001628280-23-038267:8k_2_02:6]
Senior Vice President of Finance and Investor Relations

[0001628280-23-038267:8k_2_02:7]
bnorris@evolvtechnology.com

[0001628280-23-038267:8k_2_02:8]
Evolv Technology Reports Record Third Quarter Financial Results

[0001628280-23-038267:8k_2_02:9]
– Company Reaffirms Previously Raised Outlook for 2023 and Issues Outlook for 2024 Above Street Consensus –

[0001628280-23-038267:8k_2_02:10]
•Q3 Revenue of $20.2 million, up 22% year-over-year

[0001628280-23-038267:8k_2_02:11]
•Q3 Ending ARR1 of $65.8 million, up 129% year-over-year

[0001628280-23-038267:8k_2_02:12]
•Q3 Ending RPO2 of $221.1 million, up 102% year-over-year

[0001628280-23-038267:8k_2_02:13]
•Q3 Ending Evolv Express® subscriptions of 4,014, up 137% year-over-year

[0001628280-23-038267:8k_2_02:14]
Waltham, Massachusetts – November 10, 2023 – Evolv Technology (NASDAQ: EVLV), the leader in AI-based weapons detection security screening, today announced financial results for the quarter ended September 30, 2023, reaffirmed its previously raised business outlook for 2023 and issued its preliminary outlook for 2024..

[0001628280-23-038267:8k_2_02:15]
Results for the Third Quarter of 2023

[0001628280-23-038267:8k_2_02:16]
Total revenue for the third quarter of 2023 was $20.2 million, an increase of 22% compared to $16.5 million for the third quarter of 2022. Annual Recurring Revenue (“ARR”)1 was $65.8 million at the end of third quarter of 2023, an increase of 129% compared to $28.7 million at the end of the third quarter of 2022. Net income for the third quarter of 2023 was $6.0 million, or $0.04 per basic share and $0.03 per diluted share, compared to net loss of $(18.6) million, or $(0.13) per basic and diluted share, in the third quarter of 2022. Adjusted earnings (loss)3 for the third quarter of 2023 was $(12.0) million, or $(0.08) per diluted share, compared to adjusted earnings (loss)3 of  $(18.6) million, or $(0.13) per diluted share, for the third quarter of 2022. Adjusted EBITDA3 for the third quarter of 2023 was $(11.1) million compared to $(18.0) million in the third quarter of 2022. As of September 30, 2023, the Company had cash, cash equivalents, marketable securities, and restricted cash of $140.4 million and no debt.

[0001628280-23-038267:8k_2_02:17]
Results for the First Nine Months of 2023

[0001628280-23-038267:8k_2_02:18]
Total revenue for the nine months ended September 30, 2023 was $58.6 million, an increase of 71% compared to $34.3 million for the nine months ended September 30, 2022. Net loss for the nine months ended September 30, 2023 was $(89.4) million, or $(0.60) per basic and diluted share, compared to net loss of $(58.1) million, or $(0.40) per basic and diluted share, in the nine months ended September 30, 2022. Adjusted earnings (loss)3 for the nine months ended September 30, 2023 was $(43.1) million, or $(0.29) per diluted share, compared to adjusted earnings (loss)3 of  $(54.3) million, or $(0.38) per diluted share, for the nine months ended September 30, 2022. Adjusted EBITDA3 for the nine months ended September 30, 2023 was $(40.3) million compared to $(51.7) million in the nine months ended September 30, 2022.

[0001628280-23-038267:8k_2_02:19]
The following table summarizes the breakdown of recurring and non-recurring revenue4 during each quarter:

[0001628280-23-038267:8k_2_02:20]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | % Change |  | 2023 |  | 2022 |  | % Change |
| Recurring revenue | $ | 14,377 |  |  | $ | 6,221 |  |  | 131 | % |  | $ | 35,141 |  |  | $ | 13,984 |  |  | 151 | % |
| Non-recurring revenue | 5,814 |  |  | 10,309 |  |  | (44) | % |  | 23,456 |  |  | 20,326 |  |  | 15 | % |
| Total revenue | $ | 20,191 |  |  | $ | 16,530 |  |  | 22 | % |  | $ | 58,597 |  |  | $ | 34,310 |  |  | 71 | % |

[0001628280-23-038267:8k_2_02:21]
The following table summarizes operating cash flows during each quarter:

[0001628280-23-038267:8k_2_02:22]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income (loss) | $ | 5,999 |  |  | $ | (18,615) |  |  | $ | (89,364) |  |  | $ | (58,102) |  |
| Non-cash (income) expense | (16,446) |  |  | 1,771 |  |  | 51,784 |  |  | 4,403 |  |
| Changes in operating assets and liabilities | 12,544 |  |  | (82) |  |  | 30,922 |  |  | (15,722) |  |
| Net cash provided by (used in) operating activities | $ | 2,097 |  |  | $ | (16,926) |  |  | $ | (6,658) |  |  | $ | (69,421) |  |

[0001628280-23-038267:8k_2_02:23]
Company Provides Preliminary Outlook for 2024

[0001628280-23-038267:8k_2_02:24]
The Company today reaffirmed its business outlook for 2023 as previously raised on October 12, 2023 and provided a preliminary outlook for 2024. The Company's outlook is based on the current indications for its business, which may change at any time.

[0001628280-23-038267:8k_2_02:25]
|  |  | 2023 Business Outlook |  | 2024 Business Outlook |
| Estimate ($ in millions) |  | Raised October 12, 2023 |  | Issued November 9, 2023 |  | Issued November 9, 2023 |
| Total Revenue |  | $75-$77 |  | Reaffirmed |  | ~$115 |
| ARR1 (ARR) at 12/31/23 |  | $73-$75 |  | Reaffirmed |  | $108-$112 |
| Adjusted Gross Margin3 |  | 43%-45% |  | Reaffirmed |  | ~60% |
| Adjusted EBITDA3 |  | ($50-$53) |  | Reaffirmed |  | Improve by 40%+ |

[0001628280-23-038267:8k_2_02:26]
Company to Host Live Conference Call and Webcast

[0001628280-23-038267:8k_2_02:27]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business and other matters.  The conference call may be accessed in the United States by dialing +1.877.692.8955 and using access code 825879.  The conference call may be accessed outside of the United States by dialing +1.234.720.6979 and using the same access code. The conference call will be simultaneously webcast on the Company’s investor relations website, which can be accessed at http://ir.evolvtechnology.com.  A replay of the conference call will be available for a period of 30 days by dialing +1.866.207.1041 or +1.402.970.0847 and using access code 4536095 or by accessing the webcast replay on the Company’s investor relations website at http://ir.evolvtechnology.com.

[0001628280-23-038267:8k_2_02:28]
About Evolv Technology

[0001628280-23-038267:8k_2_02:29]
Evolv Technology (NASDAQ: EVLV) is transforming human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered weapons detection and analytics. Its mission is to transform security to create a safer world to work, learn, and play. Evolv has digitally transformed the gateways in places where people gather by enabling seamless integration combined with powerful analytics and insights. Evolv’s advanced systems have scanned more than 1 billion people, second only to the Department of Homeland Security’s Transportation Security Administration (TSA) in the United States. Evolv has been awarded the U.S. Department of Homeland Security

[0001628280-23-038267:8k_2_02:30]
(DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category. Evolv Technology®, Evolv Express®, Evolv Insights®, Evolv Cortex AI®, and Evolv Extend™ are registered trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit https://evolvtechnology.com.

[0001628280-23-038267:8k_2_02:31]
1 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001628280-23-038267:8k_2_02:32]
2 We define Remaining Performance Obligation, or RPO, as estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied or partially satisfied as of the end of the quarter.

[0001628280-23-038267:8k_2_02:33]
3 Non-GAAP Financial Measures In this press release, the Company’s adjusted gross profit (loss), adjusted gross margin, adjusted operating expenses, adjusted operating income (loss), adjusted EBITDA, adjusted earnings (loss), and adjusted earnings per diluted share are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit and adjusted gross margin exclude one-time items and stock-based compensation expense which management believes provides a more meaningful representation of contribution margin. Adjusted operating expenses is defined as operating expenses less one-time items, stock-based compensation expense, restructuring expenses, and loss on impairment of lease equipment which management believes provides a more meaningful representation of on-going operating expense levels. Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, share-based compensation, and certain other one-time expenses. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, change in fair value of derivative liability, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, change in fair value of common stock warrant liability, restructuring expenses, loss on impairment of lease equipment, and certain other one-time expenses. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operating performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release. The Company is unable to provide a reconciliation of Adjusted Gross Margin to GAAP Gross Margin and non-GAAP Adjusted EBITDA to Net Income (Loss), each measure's most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact these GAAP financial measures are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of derivative liabilities, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001628280-23-038267:8k_2_02:34]
4 Recurring revenue includes the recurring portion of revenue associated with pure subscription contracts and hardware purchase subscription contracts. Non-recurring revenue includes revenue that is one-time in nature, such as product revenue, shipping revenue, and revenue from installation, training, and professional services.

[0001628280-23-038267:8k_2_02:35]
Forward-Looking Statements

[0001628280-23-038267:8k_2_02:36]
regulations; the possibility that the Company may be adversely affected by other economic, business, and/or competitive factors; operational risk; the impact of fluctuating general economic and market conditions; the need for additional capital to support business growth, which might not be available on acceptable terms, if at all; litigation and regulatory enforcement risks, including the diversion of management time and attention and the additional costs and demands on resources, and the Company’s ability to identify and implement digital advances in its technology. These and other important factors discussed under the caption “Risk Factors” in our Annual Report on Form 10-K for the year ended December 31, 2022 filed with the Securities and Exchange Commission ("SEC") on March 24, 2023, as may be updated from time to time in other filings we make with the SEC including our Quarterly Report on Form 10-Q for the quarter ended on June 30, 2023 that was filed with the SEC on August 10, 2023, could cause actual results to differ materially from those indicated by the forward-looking statements made in this press release.

[0001628280-23-038267:8k_2_02:37]
EVOLV TECHNOLOGY

[0001628280-23-038267:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001628280-23-038267:8k_2_02:39]
(In thousands, except share and per share data)

[0001628280-23-038267:8k_2_02:40]
(Unaudited)

[0001628280-23-038267:8k_2_02:41]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 3,191 |  |  | $ | 9,839 |  |  | $ | 19,188 |  |  | $ | 19,179 |  |
| Subscription revenue | 10,231 |  |  | 5,198 |  |  | 24,661 |  |  | 12,208 |  |
| Service revenue | 4,757 |  |  | 1,493 |  |  | 12,736 |  |  | 2,923 |  |
| License fee and other revenue | 2,012 |  |  | — |  |  | 2,012 |  |  | — |  |
| Total revenue | 20,191 |  |  | 16,530 |  |  | 58,597 |  |  | 34,310 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 3,153 |  |  | 12,960 |  |  | 21,453 |  |  | 23,513 |  |
| Cost of subscription revenue | 4,231 |  |  | 2,207 |  |  | 9,988 |  |  | 5,730 |  |
| Cost of service revenue | 1,417 |  |  | 1,138 |  |  | 3,588 |  |  | 3,392 |  |
| Total cost of revenue | 8,801 |  |  | 16,305 |  |  | 35,029 |  |  | 32,635 |  |
| Gross profit | 11,390 |  |  | 225 |  |  | 23,568 |  |  | 1,675 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,409 |  |  | 5,616 |  |  | 18,193 |  |  | 13,947 |  |
| Sales and marketing | 13,919 |  |  | 11,746 |  |  | 40,336 |  |  | 33,169 |  |
| General and administrative | 11,273 |  |  | 8,839 |  |  | 31,073 |  |  | 29,268 |  |
| Loss from impairment of property and equipment | 28 |  |  | 626 |  |  | 322 |  |  | 1,038 |  |
| Total operating expenses | 31,629 |  |  | 26,827 |  |  | 89,924 |  |  | 77,422 |  |
| Loss from operations | (20,239) |  |  | (26,602) |  |  | (66,356) |  |  | (75,747) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (188) |  |  | (654) |  |  | (489) |  |
| Interest income | 1,791 |  |  | 1,052 |  |  | 4,597 |  |  | 1,611 |  |
| Other expense, net | (64) |  |  | (57) |  |  | (67) |  |  | (57) |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | (626) |  |  | — |  |
| Change in fair value of contingent earn-out liability | 14,078 |  |  | 7,245 |  |  | (17,353) |  |  | 9,754 |  |
| Change in fair value of contingently issuable common stock liability | 2,277 |  |  | 1,081 |  |  | (3,560) |  |  | 2,529 |  |
| Change in fair value of public warrant liability | 8,156 |  |  | (1,146) |  |  | (5,345) |  |  | 4,297 |  |
| Total other income (expense), net | 26,238 |  |  | 7,987 |  |  | $ | (23,008) |  |  | $ | 17,645 |  |
| Net income (loss) | $ | 5,999 |  |  | $ | (18,615) |  |  | $ | (89,364) |  |  | $ | (58,102) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |
| Basic | 150,206,893 |  | 144,117,273 |  | 148,521,299 |  | 143,522,555 |
| Diluted | 173,976,375 |  | 144,117,273 |  | 148,521,299 |  | 143,522,555 |
| Net income (loss) per share |  |  |  |  |  |  |  |
| Basic | $ | 0.04 |  |  | $ | (0.13) |  |  | $ | (0.60) |  |  | $ | (0.40) |  |
| Diluted | $ | 0.03 |  |  | $ | (0.13) |  |  | $ | (0.60) |  |  | $ | (0.40) |  |
| Net income (loss) | $ | 5,999 |  |  | $ | (18,615) |  |  | $ | (89,364) |  |  | $ | (58,102) |  |
| Other comprehensive income (loss) |  |  |  |  |  |  |  |
| Cumulative translation adjustment | 34 |  |  | 45 |  |  | 1 |  |  | 35 |  |
| Total other comprehensive income | 34 |  |  | 45 |  |  | 1 |  |  | 35 |  |
| Total comprehensive income (loss) | $ | 6,033 |  |  | $ | (18,570) |  |  | $ | (89,363) |  |  | $ | (58,067) |  |

[0001628280-23-038267:8k_2_02:42]
EVOLV TECHNOLOGY

[0001628280-23-038267:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-23-038267:8k_2_02:44]
(In thousands, except share and per share data)

[0001628280-23-038267:8k_2_02:45]
(Unaudited)

[0001628280-23-038267:8k_2_02:46]
|  | September 30, 2023 |  | December 31, 2022 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 99,617 |  |  | $ | 229,783 |  |
| Restricted cash | 1,000 |  |  | — |  |
| Marketable securities | 39,487 |  |  | — |  |
| Accounts receivable, net | 29,786 |  |  | 31,920 |  |
| Inventory | 7,826 |  |  | 10,257 |  |
| Current portion of contract assets | 3,667 |  |  | 2,852 |  |
| Current portion of commission asset | 3,908 |  |  | 3,384 |  |
| Prepaid expenses and other current assets | 16,500 |  |  | 14,388 |  |
| Total current assets | 201,791 |  |  | 292,584 |  |
| Restricted cash, noncurrent | 275 |  |  | 275 |  |
| Contract assets, noncurrent | 496 |  |  | 1,386 |  |
| Commission asset, noncurrent | 6,888 |  |  | 5,655 |  |
| Property and equipment, net | 93,995 |  |  | 44,707 |  |
| Operating lease right-of-use assets | 1,537 |  |  | 1,673 |  |
| Other assets | 1,483 |  |  | 1,835 |  |
| Total assets | $ | 306,465 |  |  | $ | 348,115 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 13,887 |  |  | $ | 18,194 |  |
| Accrued expenses and other current liabilities | 12,164 |  |  | 11,545 |  |
| Current portion of deferred revenue | 53,041 |  |  | 18,273 |  |
| Current portion of long-term debt | — |  |  | 10,000 |  |
| Current portion of operating lease liabilities | 1,655 |  |  | 1,114 |  |
| Total current liabilities | 80,747 |  |  | 59,126 |  |
| Deferred revenue, noncurrent | 19,478 |  |  | 17,695 |  |
| Long-term debt, noncurrent | — |  |  | 19,683 |  |
| Operating lease liabilities, noncurrent | 133 |  |  | 892 |  |
| Contingent earn-out liability | 31,571 |  |  | 14,218 |  |
| Contingently issuable common stock liability | 6,952 |  |  | 3,392 |  |
| Public warrant liability | 11,469 |  |  | 6,124 |  |
| Total liabilities | 150,350 |  |  | 121,130 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at September 30, 2023 and December 31, 2022; no shares issued and outstanding at September 30, 2023 and December 31, 2022 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at September 30, 2023 and December 31, 2022; 150,661,124 and 145,204,974 shares issued and outstanding at September 30, 2023 and December 31, 2022, respectively | 15 |  |  | 15 |  |
| Additional paid-in capital | 437,683 |  |  | 419,190 |  |
| Accumulated other comprehensive loss | (9) |  |  | (10) |  |
| Accumulated deficit | (281,574) |  |  | (192,210) |  |
| Stockholders’ equity | 156,115 |  |  | 226,985 |  |
| Total liabilities and stockholders’ equity | $ | 306,465 |  |  | $ | 348,115 |  |

[0001628280-23-038267:8k_2_02:47]
EVOLV TECHNOLOGY

[0001628280-23-038267:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-23-038267:8k_2_02:49]
(In thousands)

[0001628280-23-038267:8k_2_02:50]
(Unaudited)

[0001628280-23-038267:8k_2_02:51]
|  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (89,364) |  |  | $ | (58,102) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 6,781 |  |  | 3,782 |  |
| Write-off of inventory and change in inventory reserve | 581 |  |  | 559 |  |
| Adjustment to property and equipment for sales type leases | — |  |  | (625) |  |
| Loss from impairment of property and equipment | 322 |  |  | 1,038 |  |
| Stock-based compensation | 17,303 |  |  | 15,513 |  |
| Non-cash interest expense | 22 |  |  | 14 |  |
| Accretion of discount on marketable securities | (482) |  |  | — |  |
| Non-cash lease expense | 136 |  |  | 602 |  |
| Change in allowance for expected credit losses | 237 |  |  | 100 |  |
| Loss on extinguishment of debt | 626 |  |  | — |  |
| Change in fair value of earn-out liability | 17,353 |  |  | (9,754) |  |
| Change in fair value of contingently issuable common stock | 3,560 |  |  | (2,529) |  |
| Change in fair value of public warrant liability | 5,345 |  |  | (4,297) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | 2,107 |  |  | (14,822) |  |
| Inventory | 2,041 |  |  | (4,401) |  |
| Commission assets | (1,757) |  |  | (1,656) |  |
| Contract assets | 75 |  |  | (1,938) |  |
| Other assets | 352 |  |  | (629) |  |
| Prepaid expenses and other current assets | (2,111) |  |  | (9,009) |  |
| Accounts payable | (6,396) |  |  | 2,177 |  |
| Deferred revenue | 36,551 |  |  | 16,005 |  |
| Accrued expenses and other current liabilities | 278 |  |  | (750) |  |
| Operating lease liability | (218) |  |  | (699) |  |
| Net cash used in operating activities | (6,658) |  |  | (69,421) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (2,202) |  |  | (1,936) |  |
| Purchases of property and equipment | (51,646) |  |  | (17,554) |  |
| Proceeds from sale of property and equipment | 60 |  |  | 312 |  |
| Purchases of marketable securities | (58,652) |  |  | — |  |
| Proceeds from maturities of marketable securities | 19,647 |  |  | — |  |
| Net cash used in investing activities | (92,793) |  |  | (19,178) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options and warrants | 616 |  |  | 571 |  |
| Proceeds from long-term debt | 1,876 |  |  | — |  |
| Repayment of principal on long-term debt | (31,876) |  |  | (1,000) |  |
| Payment of debt issuance costs and prepayment penalty | (332) |  |  | — |  |
| Net cash provided by (used in) financing activities | (29,716) |  |  | (429) |  |
| Effect of exchange rate changes on cash and cash equivalents | 1 |  |  | 35 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (129,166) |  |  | (88,993) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 230,058 |  |  | 308,167 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 100,892 |  |  | $ | 219,174 |  |

[0001628280-23-038267:8k_2_02:52]
EVOLV TECHNOLOGY

[0001628280-23-038267:8k_2_02:53]
SUMMARY OF KEY OPERATING STATISTICS

[0001628280-23-038267:8k_2_02:54]
(Unaudited)

[0001628280-23-038267:8k_2_02:55]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |  | December 31,2022 |  | March 31,2023 |  | June 30,2023 |  | September 30,2023 |  |  |
| New customers |  | 44 |  |  | 53 |  |  | 92 |  |  | 106 |  |  | 61 |  |  | 74 |  |  | 70 |  |  |  |
| Annual recurring revenue |  | $ | 16,641 |  |  | $ | 20,865 |  |  | $ | 28,741 |  |  | $ | 34,120 |  |  | $ | 42,021 |  |  | $ | 54,339 |  |  | $ | 65,774 |  |  |  |
| Recurring revenue |  | $ | 3,159 |  |  | $ | 4,604 |  |  | $ | 6,221 |  |  | $ | 7,388 |  |  | $ | 9,075 |  |  | $ | 11,689 |  |  | $ | 14,377 |  |  |  |
| Remaining performance obligation |  | $ | 63,750 |  |  | $ | 80,978 |  |  | $ | 109,407 |  |  | $ | 144,561 |  |  | $ | 161,813 |  |  | $ | 198,296 |  |  | $ | 221,126 |  |  |  |
| Net additions |  | 207 |  |  | 237 |  |  | 545 |  |  | 575 |  |  | 520 |  |  | 599 |  |  | 628 |  |  |  |
| Ending deployed units |  | 910 |  |  | 1,147 |  |  | 1,692 |  |  | 2,267 |  |  | 2,787 |  |  | 3,386 |  |  | 4,014 |  |  |  |

[0001628280-23-038267:8k_2_02:56]
EVOLV TECHNOLOGY

[0001628280-23-038267:8k_2_02:57]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001628280-23-038267:8k_2_02:58]
(In thousands)

[0001628280-23-038267:8k_2_02:59]
(Unaudited)

[0001628280-23-038267:8k_2_02:60]
|  | Three Months Ended, |
|  |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |  | December 31,2022 |  | March 31,2023 |  | June 30,2023 |  | September 30,2023 |  |  |
| Operating expenses, GAAP |  | $ | 24,760 |  |  | $ | 25,835 |  |  | $ | 26,827 |  |  | $ | 26,868 |  |  | $ | 27,256 |  |  | $ | 31,039 |  |  | $ | 31,629 |  |  |  |
| Stock-based compensation |  | (3,819) |  |  | (4,781) |  |  | (6,298) |  |  | (6,771) |  |  | (4,898) |  |  | (6,505) |  |  | (5,454) |  |  |  |
| Restructuring expenses |  | (324) |  |  | 13 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |
| Loss on impairment of lease equipment |  | (96) |  |  | (316) |  |  | (626) |  |  | (123) |  |  | (137) |  |  | (157) |  |  | (28) |  |  |  |
| Other one-time expenses |  | (1,107) |  |  | (2,298) |  |  | (69) |  |  | (41) |  |  | (53) |  |  | (683) |  |  | (945) |  |  |  |
| Adjusted Operating Expenses |  | $ | 19,414 |  |  | $ | 18,453 |  |  | $ | 19,834 |  |  | $ | 19,933 |  |  | $ | 22,168 |  |  | $ | 23,694 |  |  | $ | 25,202 |  |  |  |

[0001628280-23-038267:8k_2_02:61]
EVOLV TECHNOLOGY

[0001628280-23-038267:8k_2_02:62]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT, GAAP GROSS MARGIN TO ADJUSTED GROSS MARGIN AND GAAP OPERATING INCOME (LOSS) TO ADJUSTED OPERATING INCOME (LOSS)

[0001628280-23-038267:8k_2_02:63]
(In thousands)

[0001628280-23-038267:8k_2_02:64]
(Unaudited)

[0001628280-23-038267:8k_2_02:65]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue | $ | 20,191 |  |  | $ | 16,530 |  |  | $ | 58,597 |  |  | $ | 34,310 |  |
| Cost of Revenue | 8,801 |  |  | 16,305 |  |  | 35,029 |  |  | 32,635 |  |
| Gross Profit, GAAP | 11,390 |  |  | 225 |  |  | 23,568 |  |  | 1,675 |  |
| Stock-based compensation | 117 |  |  | 227 |  |  | 446 |  |  | 615 |  |
| Amortization of capitalized stock-based compensation | 12 |  |  | 6 |  |  | 33 |  |  | 15 |  |
| Adjusted Gross Profit | $ | 11,519 |  |  | $ | 458 |  |  | $ | 24,047 |  |  | $ | 2,305 |  |
| Gross Margin % | 56.4 | % |  | 1.4 | % |  | 40.2 | % |  | 4.9 | % |
| Adjusted Gross Margin % | 57.1 | % |  | 2.8 | % |  | 41.0 | % |  | 6.7 | % |

[0001628280-23-038267:8k_2_02:66]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Operating income (loss), GAAP | $ | (20,239) |  |  | $ | (26,602) |  |  | $ | (66,356) |  |  | $ | (75,747) |  |
| Stock-based compensation | 5,571 |  |  | 6,525 |  |  | 17,303 |  |  | 15,513 |  |
| Amortization of capitalized stock-based compensation | 12 |  |  | 6 |  |  | 33 |  |  | 15 |  |
| Restructuring expenses | — |  |  | — |  |  | — |  |  | 311 |  |
| Loss on impairment of lease equipment | 28 |  |  | 626 |  |  | 322 |  |  | 1,038 |  |
| Other one-time expenses | 945 |  |  | 69 |  |  | 1,681 |  |  | 3,474 |  |
| Adjusted Operating Income (Loss) | $ | (13,683) |  |  | $ | (19,376) |  |  | $ | (47,017) |  |  | $ | (55,396) |  |

[0001628280-23-038267:8k_2_02:67]
EVOLV TECHNOLOGY

[0001628280-23-038267:8k_2_02:68]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-23-038267:8k_2_02:69]
(In thousands)

[0001628280-23-038267:8k_2_02:70]
(Unaudited)

[0001628280-23-038267:8k_2_02:71]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income (loss) | $ | 5,999 |  |  | $ | (18,615) |  |  | $ | (89,364) |  |  | $ | (58,102) |  |
| Depreciation & amortization | 2,694 |  |  | 1,432 |  |  | 6,781 |  |  | 3,782 |  |
| Stock-based compensation | 5,571 |  |  | 6,525 |  |  | 17,303 |  |  | 15,513 |  |
| Interest expense (income) | (1,791) |  |  | (864) |  |  | (3,943) |  |  | (1,122) |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | 626 |  |  | — |  |
| Change in fair value of contingent earn-out liability | (14,078) |  |  | (7,245) |  |  | 17,353 |  |  | (9,754) |  |
| Change in fair value of contingently issuable common stock liability | (2,277) |  |  | (1,081) |  |  | 3,560 |  |  | (2,529) |  |
| Change in fair value of public warrant liability | (8,156) |  |  | 1,146 |  |  | 5,345 |  |  | (4,297) |  |
| Restructuring expenses | — |  |  | — |  |  | — |  |  | 311 |  |
| Loss on impairment of lease equipment | 28 |  |  | 626 |  |  | 322 |  |  | 1,038 |  |
| Other one-time expenses | 945 |  |  | 69 |  |  | 1,681 |  |  | 3,474 |  |
| Adjusted EBITDA | $ | (11,065) |  |  | $ | (18,007) |  |  | $ | (40,336) |  |  | $ | (51,686) |  |

[0001628280-23-038267:8k_2_02:72]
EVOLV TECHNOLOGY

[0001628280-23-038267:8k_2_02:73]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001628280-23-038267:8k_2_02:74]
(In thousands, except share and per share data)

[0001628280-23-038267:8k_2_02:75]
(Unaudited)

[0001628280-23-038267:8k_2_02:76]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income (loss) | $ | 5,999 |  |  | $ | (18,615) |  |  | $ | (89,364) |  |  | $ | (58,102) |  |
| Stock-based compensation | 5,571 |  |  | 6,525 |  |  | 17,303 |  |  | 15,513 |  |
| Amortization of capitalized stock-based compensation | 12 |  |  | 6 |  |  | 33 |  |  | 15 |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | 626 |  |  | — |  |
| Change in fair value of contingent earn-out liability | (14,078) |  |  | (7,245) |  |  | 17,353 |  |  | (9,754) |  |
| Change in fair value of contingently issuable common stock liability | (2,277) |  |  | (1,081) |  |  | 3,560 |  |  | (2,529) |  |
| Change in fair value of public warrant liability | (8,156) |  |  | 1,146 |  |  | 5,345 |  |  | (4,297) |  |
| Restructuring expenses | — |  |  | — |  |  | — |  |  | 311 |  |
| Loss on impairment of lease equipment | 28 |  |  | 626 |  |  | 322 |  |  | 1,038 |  |
| Other one-time expenses | 945 |  |  | 69 |  |  | 1,681 |  |  | 3,474 |  |
| Adjusted Earnings (Loss) | $ | (11,956) |  |  | $ | (18,569) |  |  | $ | (43,141) |  |  | $ | (54,331) |  |
| Weighted average common shares outstanding – diluted | 150,206,893 |  |  | 144,117,273 |  |  | 148,521,299 |  |  | 143,522,555 |  |
| Adjusted Earnings (Loss) Per Share – diluted | $ | (0.08) |  |  | $ | (0.13) |  |  | $ | (0.29) |  |  | $ | (0.38) |  |
