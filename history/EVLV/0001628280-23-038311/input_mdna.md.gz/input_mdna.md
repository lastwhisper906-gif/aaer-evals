# EVLV MD&A — 0001628280-23-038311


## mdna

[0001628280-23-038311:mdna:1]
[same as prior period, unchanged from 0001628280-23-028865:mdna:1]

[0001628280-23-038311:mdna:2]
[same as prior period, unchanged from 0001628280-23-028865:mdna:2]

[0001628280-23-038311:mdna:3]
[same as prior period, unchanged from 0001628280-23-028865:mdna:3]

[0001628280-23-038311:mdna:4]
[same as prior period, unchanged from 0001628280-23-028865:mdna:4]

[0001628280-23-038311:mdna:5]
[same as prior period, unchanged from 0001628280-23-028865:mdna:5]

[0001628280-23-038311:mdna:6]
Our products have screened over 1 billion visitors worldwide since our inception. We believe that we have screened more people through advanced systems than any organization other than the United States Transportation Security Administration (“TSA”). Our customers include many iconic venues across a wide variety of industries, including major sports stadiums and arenas, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, hospitals, large industrial workplaces, schools, and prominent houses of worship. We offer our products for lease or purchase and utilize a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue, and creates expansion and upsell opportunities.

[0001628280-23-038311:mdna:7]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $20.2 million and $16.5 million for the three months ended September 30, 2023 and 2022, respectively. We generated operating losses of $20.2 million and $26.6 million for the three months ended September 30, 2023 and 2022, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-23-038311:mdna:8]
[same as prior period, unchanged from 0001628280-23-028865:mdna:8]

[0001628280-23-038311:mdna:9]
1

[0001628280-23-038311:mdna:10]
[same as prior period, unchanged from 0001628280-23-028865:mdna:9]

[0001628280-23-038311:mdna:11]
[same as prior period, unchanged from 0001628280-23-028865:mdna:10]

[0001628280-23-038311:mdna:12]
[same as prior period, unchanged from 0001628280-23-028865:mdna:11]

[0001628280-23-038311:mdna:13]
[same as prior period, unchanged from 0001628280-23-028865:mdna:12]

[0001628280-23-038311:mdna:14]
We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of rising inflation and interest rates on business spending; supply chain issues and the impacts on our manufacturing capabilities; public health emergencies; geopolitical conflicts and war, including in Europe and the Middle East; and a possible prolonged economic recession. While these factors continue to evolve, we plan to remain flexible and to optimize our business as appropriate and allocate resources, as necessary.

[0001628280-23-038311:mdna:15]
[same as prior period, unchanged from 0001628280-23-028865:mdna:14]

[0001628280-23-038311:mdna:16]
[same as prior period, unchanged from 0001628280-23-028865:mdna:15]

[0001628280-23-038311:mdna:17]
[same as prior period, unchanged from 0001628280-23-028865:mdna:16]

[0001628280-23-038311:mdna:18]
We continue to transition our go-to-market strategy to focus on our "pure subscription" sales model, where the customer leases our hardware, as opposed to purchasing the hardware outright, and enters into a multi-year security-as-a-service subscription, as well as our distributor model, as discussed below. Accordingly, subscription revenue as a percentage of total revenue has increased from 31% for the three months ended September 30, 2022 to 51% for the three months ended September 30, 2023, while hardware license fees generated from our distributor model were $2.0 million for the three months ended September 30, 2023, which was the first quarter in which the Company recognized revenue from license fees.

[0001628280-23-038311:mdna:19]
We believe that the pure subscription model aligns more closely with the SaaS nature of our business and results in a more predictable and consistent recurring revenue stream as compared to the purchase subscription model. As part of this overall strategy, we entered into a distribution and license agreement in March 2023 (the "Distribution and License Agreement") with Columbia Electrical Contractors, Inc. ("Columbia Tech"), which currently serves as our primary contract manufacturer. Under this arrangement, we have granted a limited, non-exclusive license under our intellectual property rights to Columbia Tech, and Columbia Tech manufactures hardware systems and contracts directly with certain of our resellers to fulfill sales demand where the end-user customer requires the contract to be in form of a hardware purchase. Columbia Tech pays us a hardware license fee for each system sold under this agreement. In these instances, we still contract directly with the reseller to provide a multi-year security-as-a-service subscription to the end-users.

[0001628280-23-038311:mdna:20]
Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions, primarily within the United States. Pricing may vary by region due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales, bookings, and business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products to our customers.

[0001628280-23-038311:mdna:21]
[same as prior period, unchanged from 0001628280-23-028865:mdna:20]

[0001628280-23-038311:mdna:22]
[same as prior period, unchanged from 0001628280-23-028865:mdna:21]

[0001628280-23-038311:mdna:23]
[same as prior period, unchanged from 0001628280-23-028865:mdna:22]

[0001628280-23-038311:mdna:24]
[same as prior period, unchanged from 0001628280-23-028865:mdna:23]

[0001628280-23-038311:mdna:25]
[same as prior period, unchanged from 0001628280-23-028865:mdna:24]

[0001628280-23-038311:mdna:26]
[same as prior period, unchanged from 0001628280-23-028865:mdna:25]

[0001628280-23-038311:mdna:27]
[same as prior period, unchanged from 0001628280-23-028865:mdna:26]

[0001628280-23-038311:mdna:28]
[same as prior period, unchanged from 0001628280-23-028865:mdna:27]

[0001628280-23-038311:mdna:29]
[same as prior period, unchanged from 0001628280-23-028865:mdna:28]

[0001628280-23-038311:mdna:30]
[same as prior period, unchanged from 0001628280-23-028865:mdna:29]

[0001628280-23-038311:mdna:31]
[same as prior period, unchanged from 0001628280-23-028865:mdna:30]

[0001628280-23-038311:mdna:32]
[same as prior period, unchanged from 0001628280-23-028865:mdna:31]

[0001628280-23-038311:mdna:33]
[same as prior period, unchanged from 0001628280-23-028865:mdna:32]

[0001628280-23-038311:mdna:34]
[same as prior period, unchanged from 0001628280-23-028865:mdna:33]

[0001628280-23-038311:mdna:35]
[same as prior period, unchanged from 0001628280-23-028865:mdna:34]

[0001628280-23-038311:mdna:36]
[same as prior period, unchanged from 0001628280-23-028865:mdna:35]

[0001628280-23-038311:mdna:37]
[same as prior period, unchanged from 0001628280-23-028865:mdna:36]

[0001628280-23-038311:mdna:38]
[same as prior period, unchanged from 0001628280-23-028865:mdna:37]

[0001628280-23-038311:mdna:39]
[same as prior period, unchanged from 0001628280-23-028865:mdna:38]

[0001628280-23-038311:mdna:40]
[same as prior period, unchanged from 0001628280-23-028865:mdna:39]

[0001628280-23-038311:mdna:41]
[same as prior period, unchanged from 0001628280-23-028865:mdna:40]

[0001628280-23-038311:mdna:42]
[same as prior period, unchanged from 0001628280-23-028865:mdna:41]

[0001628280-23-038311:mdna:43]
[same as prior period, unchanged from 0001628280-23-028865:mdna:42]

[0001628280-23-038311:mdna:44]
[same as prior period, unchanged from 0001628280-23-028865:mdna:43]

[0001628280-23-038311:mdna:45]
[same as prior period, unchanged from 0001628280-23-028865:mdna:44]

[0001628280-23-038311:mdna:46]
[same as prior period, unchanged from 0001628280-23-028865:mdna:45]

[0001628280-23-038311:mdna:47]
[same as prior period, unchanged from 0001628280-23-028865:mdna:46]

[0001628280-23-038311:mdna:48]
[same as prior period, unchanged from 0001628280-23-028865:mdna:47]

[0001628280-23-038311:mdna:49]
[same as prior period, unchanged from 0001628280-23-028865:mdna:48]

[0001628280-23-038311:mdna:50]
[same as prior period, unchanged from 0001628280-23-028865:mdna:49]

[0001628280-23-038311:mdna:51]
[same as prior period, unchanged from 0001628280-23-028865:mdna:50]

[0001628280-23-038311:mdna:52]
[same as prior period, unchanged from 0001628280-23-028865:mdna:51]

[0001628280-23-038311:mdna:53]
[same as prior period, unchanged from 0001628280-23-028865:mdna:52]

[0001628280-23-038311:mdna:54]
[same as prior period, unchanged from 0001628280-23-028865:mdna:53]

[0001628280-23-038311:mdna:55]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and sales tax contingencies. We expect our general and administrative expenses will remain relatively consistent for the year ending December 31, 2023 compared to the year ended December 31, 2022 as we look to leverage previous investments made in people and processes.

[0001628280-23-038311:mdna:56]
[same as prior period, unchanged from 0001628280-23-028865:mdna:55]

[0001628280-23-038311:mdna:57]
[same as prior period, unchanged from 0001628280-23-028865:mdna:56]

[0001628280-23-038311:mdna:58]
[same as prior period, unchanged from 0001628280-23-028865:mdna:57]

[0001628280-23-038311:mdna:59]
[same as prior period, unchanged from 0001628280-23-028865:mdna:58]

[0001628280-23-038311:mdna:60]
[same as prior period, unchanged from 0001628280-23-028865:mdna:59]

[0001628280-23-038311:mdna:61]
Interest income relates to interest earned on money market funds and treasury bills, and interest earned on our lease receivables for our Evolv Express units recognized as sales type leases.

[0001628280-23-038311:mdna:62]
[same as prior period, unchanged from 0001628280-23-028865:mdna:61]

[0001628280-23-038311:mdna:63]
[same as prior period, unchanged from 0001628280-23-028865:mdna:62]

[0001628280-23-038311:mdna:64]
[same as prior period, unchanged from 0001628280-23-028865:mdna:63]

[0001628280-23-038311:mdna:65]
[same as prior period, unchanged from 0001628280-23-028865:mdna:64]

[0001628280-23-038311:mdna:66]
[same as prior period, unchanged from 0001628280-23-028865:mdna:65]

[0001628280-23-038311:mdna:67]
[same as prior period, unchanged from 0001628280-23-028865:mdna:66]

[0001628280-23-038311:mdna:68]
[same as prior period, unchanged from 0001628280-23-028865:mdna:67]

[0001628280-23-038311:mdna:69]
Our income tax provision consists of an estimate for U.S. federal and state income taxes based on enacted rates, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. There is no provision for income taxes for the three and nine months ended September 30, 2023 and 2022 because we have historically incurred net operating losses and maintain a full valuation allowance against its deferred tax assets.

[0001628280-23-038311:mdna:70]
[same as prior period, unchanged from 0001628280-23-028865:mdna:69]

[0001628280-23-038311:mdna:71]
Comparison of the Three Months Ended September 30, 2023 and 2022

[0001628280-23-038311:mdna:72]
The following table summarizes our results of operations for the three months ended September 30, 2023 and 2022 (in thousands):

[0001628280-23-038311:mdna:73]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 3,191 |  |  | $ | 9,839 |  |  | $ | (6,648) |  |  | (68) | % |
| Subscription revenue | 10,231 |  |  | 5,198 |  |  | 5,033 |  |  | 97 |  |
| Service revenue | 4,757 |  |  | 1,493 |  |  | 3,264 |  |  | 219 |  |
| License fee and other revenue | 2,012 |  |  | — |  |  | 2,012 |  |  | * |
| Total revenue | 20,191 |  |  | 16,530 |  |  | 3,661 |  |  | 22 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 3,153 |  |  | 12,960 |  |  | (9,807) |  |  | (76) |  |
| Cost of subscription revenue | 4,231 |  |  | 2,207 |  |  | 2,024 |  |  | 92 |  |
| Cost of service revenue | 1,417 |  |  | 1,138 |  |  | 279 |  |  | 25 |  |
| Total cost of revenue | 8,801 |  |  | 16,305 |  |  | (7,504) |  |  | (46) |  |
| Gross profit | 11,390 |  |  | 225 |  |  | 11,165 |  |  | 4,962 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,409 |  |  | 5,616 |  |  | 793 |  |  | 14 |  |
| Sales and marketing | 13,919 |  |  | 11,746 |  |  | 2,173 |  |  | 18 |  |
| General and administrative | 11,273 |  |  | 8,839 |  |  | 2,434 |  |  | 28 |  |
| Loss from impairment of property and equipment | 28 |  |  | 626 |  |  | (598) |  |  | (96) |  |
| Total operating expenses | 31,629 |  |  | 26,827 |  |  | 4,802 |  |  | 18 |  |
| Loss from operations | (20,239) |  |  | (26,602) |  |  | 6,363 |  |  | 24 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (188) |  |  | 188 |  |  | * |
| Interest income | 1,791 |  |  | 1,052 |  |  | 739 |  |  | 70 |  |
| Other expense, net | (64) |  |  | (57) |  |  | (7) |  |  | (12) |  |
| Change in fair value of contingent earn-out liability | 14,078 |  |  | 7,245 |  |  | 6,833 |  |  | 94 |  |
| Change in fair value of contingently issuable common stock liability | 2,277 |  |  | 1,081 |  |  | 1,196 |  |  | 111 |  |
| Change in fair value of public warrant liability | 8,156 |  |  | (1,146) |  |  | 9,302 |  |  | 812 |  |
| Total other income (expense), net | 26,238 |  |  | 7,987 |  |  | 18,251 |  |  | 229 |  |
| Net loss | $ | 5,999 |  |  | $ | (18,615) |  |  | $ | 24,614 |  |  | 132 | % |

[0001628280-23-038311:mdna:74]
[same as prior period, unchanged from 0001628280-23-028865:mdna:74]

[0001628280-23-038311:mdna:75]
[same as prior period, unchanged from 0001628280-23-028865:mdna:75]

[0001628280-23-038311:mdna:76]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 70 new customers during the three months ended September 30, 2023 and 92 new customers during the three months ended September 30, 2022, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-23-038311:mdna:77]
[same as prior period, unchanged from 0001628280-23-028865:mdna:76]

[0001628280-23-038311:mdna:78]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Product revenue | $ | 3,191 |  |  | $ | 9,839 |  |  | $ | (6,648) |  |  | (68) | % |
| Cost of product revenue | $ | 3,153 |  |  | $ | 12,960 |  |  | $ | (9,807) |  |  | (76) | % |
| Gross profit - Product revenue | $ | 38 |  |  | $ | (3,121) |  |  | $ | 3,159 |  |  | 101 | % |
| Gross profit margin - Product revenue | 1 | % |  | (32) | % |  | N/A |  | 33 | % |

[0001628280-23-038311:mdna:79]
The decreases in product revenue and cost of product revenue are primarily due to a continued transition to pure subscription sales and sales under our distributor model during the preceding twelve months. The increases in product gross profit and product gross profit margin during the three months ended September 30, 2023 compared to the prior year period reflects a higher average number of units sold per transaction across our target end markets, particularly in the professional sports vertical.

[0001628280-23-038311:mdna:80]
[same as prior period, unchanged from 0001628280-23-028865:mdna:81]

[0001628280-23-038311:mdna:81]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Subscription revenue | $ | 10,231 |  |  | $ | 5,198 |  |  | $ | 5,033 |  |  | 97 | % |
| Cost of subscription revenue | $ | 4,231 |  |  | $ | 2,207 |  |  | $ | 2,024 |  |  | 92 | % |
| Gross profit - Subscription revenue | $ | 6,000 |  |  | $ | 2,991 |  |  | $ | 3,009 |  |  | 101 | % |
| Gross profit margin - Subscription revenue | 59 | % |  | 58 | % |  | N/A |  | 1 | % |

[0001628280-23-038311:mdna:82]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base, a continued transition to our pure subscription model, and a higher number of active Evolv

[0001628280-23-038311:mdna:83]
[same as prior period, unchanged from 0001628280-23-028865:mdna:84]

[0001628280-23-038311:mdna:84]
Express units deployed under our pure subscription contract model. Subscription gross profit margin increased slightly as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-23-038311:mdna:85]
[same as prior period, unchanged from 0001628280-23-028865:mdna:86]

[0001628280-23-038311:mdna:86]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Service revenue | $ | 4,757 |  |  | $ | 1,493 |  |  | $ | 3,264 |  |  | 219 | % |
| Cost of service revenue | $ | 1,417 |  |  | $ | 1,138 |  |  | $ | 279 |  |  | 25 | % |
| Gross profit - Service revenue | $ | 3,340 |  |  | $ | 355 |  |  | $ | 2,985 |  |  | 841 | % |
| Gross profit margin - Service revenue | 70 | % |  | 24 | % |  | N/A |  | 46 | % |

[0001628280-23-038311:mdna:87]
The increases in service revenue and gross profit are primarily due to an increased number of active revenue-generating purchase subscription units and an increase in installation and training services. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-23-038311:mdna:88]
License fee and other revenue

[0001628280-23-038311:mdna:89]
License fee and other revenue for the three months ended September 30, 2023 consists of $2.0 million of license fees earned in connection to the Distribution and License Agreement. The Company did not earn any license fee revenue for periods prior to the three months ended September 30, 2023.

[0001628280-23-038311:mdna:90]
[same as prior period, unchanged from 0001628280-23-028865:mdna:89]

[0001628280-23-038311:mdna:91]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 4,550 |  |  | $ | 4,306 |  |  | $ | 244 |  |  | 6 | % |
| Materials and prototypes | 364 |  |  | 203 |  |  | 161 |  |  | 79 | % |
| Professional fees | 1,100 |  |  | 974 |  |  | 126 |  |  | 13 | % |
| Other | 395 |  |  | 133 |  |  | 262 |  |  | 197 | % |
|  | $ | 6,409 |  |  | $ | 5,616 |  |  | $ | 793 |  |  | 14 | % |

[0001628280-23-038311:mdna:92]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation primarily resulting from new hires in our research and development function during the past twelve months, offset by a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased. Stock-based compensation expense included in research and development expenses was $1.2 million for the three months ended September 30, 2023 compared to $1.6 million for the three months ended September 30, 2022. The increase in materials and prototypes expense is due to increased design and engineering costs related to the development of the next generation of our Evolv Express system. The increase in professional fees primarily relates to consulting costs incurred for product development and engineering. The increase in other expense primarily relates to software subscriptions.

[0001628280-23-038311:mdna:93]
[same as prior period, unchanged from 0001628280-23-028865:mdna:92]

[0001628280-23-038311:mdna:94]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 9,560 |  |  | $ | 7,820 |  |  | $ | 1,740 |  |  | 22 | % |
| Advertising and direct marketing | 980 |  |  | 1,613 |  |  | (633) |  |  | (39) | % |
| Travel and entertainment | 1,506 |  |  | 992 |  |  | 514 |  |  | 52 | % |
| Professional fees | 716 |  |  | 421 |  |  | 295 |  |  | 70 | % |
| Other | 1,157 |  |  | 900 |  |  | 257 |  |  | 29 | % |
|  | $ | 13,919 |  |  | $ | 11,746 |  |  | $ | 2,173 |  |  | 18 | % |

[0001628280-23-038311:mdna:95]
The increase in personnel related expenses is due to an increase in payroll costs and commissions resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increased sales volume. Stock compensation expense included in sales and marketing expenses was $1.8 million for the three months ended September 30, 2023 compared to $2.5 million for the three months ended September 30, 2022. The decrease in advertising and direct marketing expense is primarily due to a decrease in expense related to trade shows and events. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings and events. Professional fees increased due primarily to an increase in marketing consulting costs. Other expense increased primarily due to increases in software subscriptions and other miscellaneous expenses.

[0001628280-23-038311:mdna:96]
[same as prior period, unchanged from 0001628280-23-028865:mdna:97]

[0001628280-23-038311:mdna:97]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 6,033 |  |  | $ | 4,548 |  |  | $ | 1,485 |  |  | 33 | % |
| Professional fees | 1,764 |  |  | 1,896 |  |  | (132) |  |  | (7) | % |
| Director and officer insurance | 708 |  |  | 894 |  |  | (186) |  |  | (21) | % |
| Other | 2,768 |  |  | 1,501 |  |  | 1,267 |  |  | 84 | % |
|  | $ | 11,273 |  |  | $ | 8,839 |  |  | $ | 2,434 |  |  | 28 | % |

[0001628280-23-038311:mdna:98]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $2.5 million for the three months ended September 30, 2023 compared to $2.2 million for the three months ended September 30, 2022. Other expense increased primarily due to $0.7 million of certain one-time expenses incurred during the three months ended September 30, 2023, as well as increases in software subscriptions and other miscellaneous expenses.

[0001628280-23-038311:mdna:99]
[same as prior period, unchanged from 0001628280-23-028865:mdna:100]

[0001628280-23-038311:mdna:100]
Loss from impairment of property and equipment was less than $0.1 million and $0.6 million for the three months ended September 30, 2023 and 2022, respectively, primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in impairment of the remaining economic value of such units.

[0001628280-23-038311:mdna:101]
[same as prior period, unchanged from 0001628280-23-028865:mdna:102]

[0001628280-23-038311:mdna:102]
No interest expense was recognized for the three months ended September 30, 2023, compared to $0.2 million for the three months ended September 30, 2022. During March 2023, the Company fully repaid all borrowings and accrued interest under its term loans with Silicon Valley Bank ("SVB") pursuant to a loan and security agreement entered into in December 2022 (the "2022 SVB Credit Agreement").

[0001628280-23-038311:mdna:103]
9

[0001628280-23-038311:mdna:104]
[same as prior period, unchanged from 0001628280-23-028865:mdna:104]

[0001628280-23-038311:mdna:105]
Interest income of $1.8 million for the three months ended September 30, 2023 and $1.1 million for the three months ended September 30, 2022 related primarily to interest earned on money market funds, and for the three months ended September 30, 2023, accretion of discounts on treasury bills.

[0001628280-23-038311:mdna:106]
[same as prior period, unchanged from 0001628280-23-028865:mdna:106]

[0001628280-23-038311:mdna:107]
Change in the fair value of the contingent earn-out liability resulted in gains of $14.1 million and $7.2 million for the three months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-23-038311:mdna:108]
[same as prior period, unchanged from 0001628280-23-028865:mdna:108]

[0001628280-23-038311:mdna:109]
Change in the fair value of the contingently issuable common stock liability resulted in gains of $2.3 million and $1.1 million for the three months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-23-038311:mdna:110]
[same as prior period, unchanged from 0001628280-23-028865:mdna:110]

[0001628280-23-038311:mdna:111]
Change in the fair value of the public warrant liability resulted in a $8.2 million gain and a $1.1 million loss for the three months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-23-038311:mdna:112]
Comparison of the Nine Months Ended September 30, 2023 and 2022

[0001628280-23-038311:mdna:113]
The following table summarizes our results of operations for the nine months ended September 30, 2023 and 2022, (in thousands):

[0001628280-23-038311:mdna:114]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 19,188 |  |  | $ | 19,179 |  |  | $ | 9 |  |  | — | % |
| Subscription revenue | 24,661 |  |  | 12,208 |  |  | 12,453 |  |  | 102 |  |
| Service revenue | 12,736 |  |  | 2,923 |  |  | 9,813 |  |  | 336 |  |
| License fee and other revenue | 2,012 |  |  | — |  |  | 2,012 |  |  | * |
| Total revenue | 58,597 |  |  | 34,310 |  |  | 24,287 |  |  | 71 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 21,453 |  |  | 23,513 |  |  | (2,060) |  |  | (9) |  |
| Cost of subscription revenue | 9,988 |  |  | 5,730 |  |  | 4,258 |  |  | 74 |  |
| Cost of service revenue | 3,588 |  |  | 3,392 |  |  | 196 |  |  | 6 |  |
| Total cost of revenue | 35,029 |  |  | 32,635 |  |  | 2,394 |  |  | 7 |  |
| Gross profit | 23,568 |  |  | 1,675 |  |  | 21,893 |  |  | 1,307 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 18,193 |  |  | 13,947 |  |  | 4,246 |  |  | 30 |  |
| Sales and marketing | 40,336 |  |  | 33,169 |  |  | 7,167 |  |  | 22 |  |
| General and administrative | 31,073 |  |  | 29,268 |  |  | 1,805 |  |  | 6 |  |
| Loss from impairment of property and equipment | 322 |  |  | 1,038 |  |  | (716) |  |  | (69) |  |
| Total operating expenses | 89,924 |  |  | 77,422 |  |  | 12,502 |  |  | 16 |  |
| Loss from operations | (66,356) |  |  | (75,747) |  |  | 9,391 |  |  | 12 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (654) |  |  | (489) |  |  | (165) |  |  | (34) |  |
| Interest income | 4,597 |  |  | 1,611 |  |  | 2,986 |  |  | 185 |  |
| Other expense, net | (67) |  |  | (57) |  |  | (10) |  |  | (18) |  |
| Loss on extinguishment of debt | (626) |  |  | — |  |  | (626) |  |  | * |
| Change in fair value of contingent earn-out liability | (17,353) |  |  | 9,754 |  |  | (27,107) |  |  | (278) |  |
| Change in fair value of contingently issuable common stock liability | (3,560) |  |  | 2,529 |  |  | (6,089) |  |  | (241) |  |
| Change in fair value of public warrant liability | (5,345) |  |  | 4,297 |  |  | (9,642) |  |  | (224) |  |
| Total other income (expense), net | (23,008) |  |  | 17,645 |  |  | (40,653) |  |  | (230) |  |
| Net loss | $ | (89,364) |  |  | $ | (58,102) |  |  | $ | (31,262) |  |  | (54) | % |

[0001628280-23-038311:mdna:115]
[same as prior period, unchanged from 0001628280-23-028865:mdna:73]

[0001628280-23-038311:mdna:116]
11

[0001628280-23-038311:mdna:117]
[same as prior period, unchanged from 0001628280-23-028865:mdna:117]

[0001628280-23-038311:mdna:118]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 205 new customers during the nine months ended September 30, 2023 and 189 new customers during the nine months ended September 30, 2022, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-23-038311:mdna:119]
[same as prior period, unchanged from 0001628280-23-028865:mdna:118]

[0001628280-23-038311:mdna:120]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Product revenue | $ | 19,188 |  |  | $ | 19,179 |  |  | $ | 9 |  |  | — | % |
| Cost of product revenue | $ | 21,453 |  |  | $ | 23,513 |  |  | $ | (2,060) |  |  | (9) | % |
| Gross profit - Product revenue | $ | (2,265) |  |  | $ | (4,334) |  |  | $ | 2,069 |  |  | 48 | % |
| Gross profit margin - Product revenue | (12) | % |  | (23) | % |  | N/A |  | 11 | % |

[0001628280-23-038311:mdna:121]
The decreases in product revenue and cost of product revenue are primarily due to a continued transition to pure subscription sales and sales under our distributor model during the preceding twelve months. The increases in product gross profit and product gross profit margin during the nine months ended September 30, 2023 compared to the prior year period reflects a higher average number of units sold per transaction across our target end markets, particularly in the professional sports vertical.

[0001628280-23-038311:mdna:122]
[same as prior period, unchanged from 0001628280-23-028865:mdna:123]

[0001628280-23-038311:mdna:123]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Subscription revenue | $ | 24,661 |  |  | $ | 12,208 |  |  | $ | 12,453 |  |  | 102 | % |
| Cost of subscription revenue | $ | 9,988 |  |  | $ | 5,730 |  |  | $ | 4,258 |  |  | 74 | % |
| Gross profit - Subscription revenue | $ | 14,673 |  |  | $ | 6,478 |  |  | $ | 8,195 |  |  | 127 | % |
| Gross profit margin - Subscription revenue | 59 | % |  | 53 | % |  | N/A |  | 6 | % |

[0001628280-23-038311:mdna:124]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base, a continued transition to our pure subscription model, and a higher number of active Evolv Express units deployed under our pure subscription contract model. Subscription gross profit margin increased as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-23-038311:mdna:125]
[same as prior period, unchanged from 0001628280-23-028865:mdna:127]

[0001628280-23-038311:mdna:126]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Service revenue | $ | 12,736 |  |  | $ | 2,923 |  |  | $ | 9,813 |  |  | 336 | % |
| Cost of service revenue | $ | 3,588 |  |  | $ | 3,392 |  |  | $ | 196 |  |  | 6 | % |
| Gross profit - Service revenue | $ | 9,148 |  |  | $ | (469) |  |  | $ | 9,617 |  |  | 2051 | % |
| Gross profit margin - Service revenue | 72 | % |  | (16) | % |  | N/A |  | 88 | % |

[0001628280-23-038311:mdna:127]
The increase in service revenue and gross profit is primarily due to an increased number of active revenue-generating purchase subscription units and an increase in installation and training services. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-23-038311:mdna:128]
12

[0001628280-23-038311:mdna:129]
License fee and other revenue

[0001628280-23-038311:mdna:130]
License fee and other revenue for the nine months ended September 30, 2023 consists of $2.0 million of license fees earned in connection to the Distribution and License Agreement. The Company did not earn any license fee revenue for periods prior to the nine months ended September 30, 2023.

[0001628280-23-038311:mdna:131]
[same as prior period, unchanged from 0001628280-23-028865:mdna:130]

[0001628280-23-038311:mdna:132]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 12,710 |  |  | $ | 11,268 |  |  | $ | 1,442 |  |  | 13 | % |
| Materials and prototypes | 1,561 |  |  | 439 |  |  | 1,122 |  |  | 256 | % |
| Professional fees | 3,025 |  |  | 1,706 |  |  | 1,319 |  |  | 77 | % |
| Other | 897 |  |  | 534 |  |  | 363 |  |  | 68 | % |
|  | $ | 18,193 |  |  | $ | 13,947 |  |  | $ | 4,246 |  |  | 30 | % |

[0001628280-23-038311:mdna:133]
The increase in personnel related expenses is due to an increase in payroll costs primarily resulting from new hires in our research and development function during the past twelve months, offset by a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased. Stock compensation expense included in research and development expenses was $3.2 million for the nine months ended September 30, 2023 compared to $3.1 million for the nine months ended September 30, 2022. The increase in materials and prototypes is due to design and engineering costs related to the next generation of our Evolv Express system. The increase in professional fees primarily relates to consulting costs incurred for product development and engineering.

[0001628280-23-038311:mdna:134]
[same as prior period, unchanged from 0001628280-23-028865:mdna:133]

[0001628280-23-038311:mdna:135]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 29,267 |  |  | $ | 21,433 |  |  | $ | 7,834 |  |  | 37 | % |
| Advertising and direct marketing | 2,807 |  |  | 4,502 |  |  | (1,695) |  |  | (38) | % |
| Travel and entertainment | 3,648 |  |  | 2,530 |  |  | 1,118 |  |  | 44 | % |
| Professional fees | 1,810 |  |  | 973 |  |  | 837 |  |  | 86 | % |
| Other | 2,804 |  |  | 3,731 |  |  | (927) |  |  | (25) | % |
|  | $ | 40,336 |  |  | $ | 33,169 |  |  | $ | 7,167 |  |  | 22 | % |

[0001628280-23-038311:mdna:136]
The increase in personnel related expenses is due to an increase in payroll costs and commissions resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increased sales volume. Stock compensation expense included in sales and marketing expenses was $6.3 million for both the nine months ended September 30, 2023 and the nine months ended September 30, 2022. The decrease in advertising and direct marketing expense is primarily due to a decrease in expense related to trade shows and events. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings and events. Professional fees increased due primarily to an increase in marketing consulting costs. Other expense decreased due primarily to $1.0 million of certain one-time expenses incurred during the nine months ended September 30, 2023.

[0001628280-23-038311:mdna:137]
[same as prior period, unchanged from 0001628280-23-028865:mdna:150]

[0001628280-23-038311:mdna:138]
[same as prior period, unchanged from 0001628280-23-028865:mdna:137]

[0001628280-23-038311:mdna:139]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 17,206 |  |  | $ | 12,513 |  |  | $ | 4,693 |  |  | 38 | % |
| Professional fees | 4,673 |  |  | 7,235 |  |  | (2,562) |  |  | (35) | % |
| Insurance costs | 2,774 |  |  | 3,524 |  |  | (750) |  |  | (21) | % |
| Other | 6,420 |  |  | 5,996 |  |  | 424 |  |  | 7 | % |
|  | $ | 31,073 |  |  | $ | 29,268 |  |  | $ | 1,805 |  |  | 6 | % |

[0001628280-23-038311:mdna:140]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $7.3 million for the nine months ended September 30, 2023 compared to $5.4 million for the nine months ended September 30, 2022. The decrease in professional fees is primarily related to a decrease in outsourced accounting consultancy and audit fees. The decrease in insurance expense is primarily related to a decrease in director and officer insurance premiums.

[0001628280-23-038311:mdna:141]
[same as prior period, unchanged from 0001628280-23-028865:mdna:140]

[0001628280-23-038311:mdna:142]
Loss from impairment of property and equipment was $0.3 million and $1.0 million for the nine months ended September 30, 2023 and 2022, respectively, primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in impairment of the remaining economic value of such units.

[0001628280-23-038311:mdna:143]
[same as prior period, unchanged from 0001628280-23-028865:mdna:142]

[0001628280-23-038311:mdna:144]
Interest expense was $0.7 million for the nine months ended September 30, 2023, compared to $0.5 million for the nine months ended September 30, 2022. The increase was primarily due to interest expense incurred during the three months ended March 31, 2023 related to the Company's term loans with SVB pursuant to the 2022 SVB Credit Agreement. During March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write off of $0.3 million of unamortized debt issuance costs.

[0001628280-23-038311:mdna:145]
[same as prior period, unchanged from 0001628280-23-028865:mdna:144]

[0001628280-23-038311:mdna:146]
Interest income of $4.6 million for the nine months ended September 30, 2023 and $1.6 million for the nine months ended September 30, 2022 related primarily to interest earned on money market funds, and for the nine months ended September 30, 2023, accretion of discounts on treasury bills.

[0001628280-23-038311:mdna:147]
[same as prior period, unchanged from 0001628280-23-028865:mdna:146]

[0001628280-23-038311:mdna:148]
Change in the fair value of the contingent earn-out liability resulted in a $17.4 million loss and a $9.8 million gain for the nine months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-23-038311:mdna:149]
[same as prior period, unchanged from 0001628280-23-028865:mdna:148]

[0001628280-23-038311:mdna:150]
Change in the fair value of the contingently issuable common stock liability resulted in a $3.6 million loss and a $2.5 million gain for the nine months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-23-038311:mdna:151]
14

[0001628280-23-038311:mdna:152]
[same as prior period, unchanged from 0001628280-23-028865:mdna:151]

[0001628280-23-038311:mdna:153]
Change in the fair value of the public warrant liability resulted in a $5.3 million loss and a $4.3 million gain for the nine months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-23-038311:mdna:154]
[same as prior period, unchanged from 0001628280-23-028865:mdna:153]

[0001628280-23-038311:mdna:155]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. As of September 30, 2023, we had $139.1 million in cash, cash equivalents, and marketable securities. We incurred net income of $6.0 million and a net loss of $18.6 million for the three months ended September 30, 2023 and 2022, respectively, and a net loss of $89.4 million and $58.1 million for the nine months ended September 30, 2023 and 2022, respectively. We incurred cash outflows from operating activities of $6.7 million and $69.4 million during the nine months ended September 30, 2023 and 2022, respectively.

[0001628280-23-038311:mdna:156]
We maintain substantially all of our cash, cash equivalents, and marketable securities in accounts with a diverse set of U.S. and multi-national financial institutions and our cash deposits at these institutions exceed Federal Deposit Insurance Corporation insured limits. The Company does not believe it is exposed to any unusual credit risk or deposit concentration risk beyond the ordinary credit risk associated with commercial banking relationships.

[0001628280-23-038311:mdna:157]
We expect our cash, cash equivalents, and marketable securities, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our sales and marketing team. We may require additional capital to respond to the expected growth in the demand for equipment purchases to support our "leased equipment" offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances and in either the short-term or long-term may determine to engage in debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as the public health emergencies, including the COVID-19 pandemic and its variants, international political turmoil, including in Europe and the Middle East, and related international sanctions, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001628280-23-038311:mdna:158]
[same as prior period, unchanged from 0001628280-23-028865:mdna:157]

[0001628280-23-038311:mdna:159]
During March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. The Company has no debt outstanding as of September 30, 2023.

[0001628280-23-038311:mdna:160]
[same as prior period, unchanged from 0001628280-23-028865:mdna:159]

[0001628280-23-038311:mdna:161]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of September 30, 2023. We anticipate fulfilling such commitments with our existing cash, cash equivalents, and marketable securities, as well as cash and cash equivalents obtained through operations and, if necessary, proceeds from long-term debt. Cash, cash equivalents, and marketable securities amounted to $139.1 million as of September 30, 2023.

[0001628280-23-038311:mdna:162]
We are party to a lease agreement for office space for the period from May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. During the three months ended September 30, 2023, we amended the lease agreement to add additional square footage within the same building. The amendment did not impact the term of the lease. We are required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space which is classified as restricted cash, non-current on the condensed consolidated balance sheet as of September 30, 2023. Total future minimum lease payments under this noncancelable operating lease, including the amendment, amount to $1.9 million.

[0001628280-23-038311:mdna:163]
[same as prior period, unchanged from 0001628280-23-028865:mdna:162]

[0001628280-23-038311:mdna:164]
[same as prior period, unchanged from 0001628280-23-028865:mdna:163]

[0001628280-23-038311:mdna:165]
|  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |
| Net cash used in operating activities | $ | (6,658) |  |  | $ | (69,421) |  |
| Net cash used in investing activities | (92,793) |  |  | (19,178) |  |
| Net cash provided by (used in) financing activities | (29,716) |  |  | (429) |  |
| Effect of exchange rate changes on cash and cash equivalents | 1 |  |  | 35 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (129,166) |  |  | $ | (88,993) |  |

[0001628280-23-038311:mdna:166]
[same as prior period, unchanged from 0001628280-23-028865:mdna:165]

[0001628280-23-038311:mdna:167]
|  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |
| Net income (loss) | $ | (89,364) |  |  | $ | (58,102) |  |
| Non-cash (income) expense | 51,784 |  |  | 4,403 |  |
| Changes in operating assets and liabilities | 30,922 |  |  | (15,722) |  |
| Net cash provided by (used in) operating activities | $ | (6,658) |  |  | $ | (69,421) |  |

[0001628280-23-038311:mdna:168]
Net loss increased from $58.1 million for the nine months ended September 30, 2022 to $89.4 million for the nine months ended September 30, 2023 primarily due to changes in the fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability. See "Results of Operations" above for further discussion.

[0001628280-23-038311:mdna:169]
Non-cash expense for the nine months ended September 30, 2023 is primarily attributable to $17.3 million of stock-based compensation expense, $6.8 million of depreciation and amortization, and $26.3 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability. Non-cash expense for the nine months ended September 30, 2022 is primarily attributable to $15.5 million of stock-based compensation expense, $3.8 million of depreciation and amortization, and $1.0 million of loss from impairment of property and equipment, offset by $16.6 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability.

[0001628280-23-038311:mdna:170]
Changes in operating assets and liabilities for the nine months ended September 30, 2023 are primarily related to the following:

[0001628280-23-038311:mdna:171]
•$2.0 million decrease in inventory primarily due to a higher proportion of finished goods recorded as property and equipment based on our expectations of the future mix of Evolv Express units to be leased to customers versus sold to customers;

[0001628280-23-038311:mdna:172]
•$36.6 million increase in deferred revenue due to a higher volume of sales; offset by

[0001628280-23-038311:mdna:173]
•$6.4 million decrease in accounts payable (excluding the non-cash change in capital expenditures incurred but not yet paid from December 31, 2022 to September 30, 2023) primarily due to a decrease in inventory.

[0001628280-23-038311:mdna:174]
Changes in operating assets and liabilities for the nine months ended September 30, 2022 are primarily related to the following:

[0001628280-23-038311:mdna:175]
•$14.8 million increase in accounts receivable primarily due to higher sales driven by an increase in customers and the timing of billings to customers;

[0001628280-23-038311:mdna:176]
•$4.4 million increase in inventory primarily due to increased production of units to meet customer demand;

[0001628280-23-038311:mdna:177]
•$9.0 million increase in prepaid expense and other current assets primarily due to prepaid deposits related to orders placed for Evolv Express units; offset by

[0001628280-23-038311:mdna:178]
•$16.0 million increase in deferred revenue primarily due to an increase in billings associated with higher sales.

[0001628280-23-038311:mdna:179]
16

[0001628280-23-038311:mdna:180]
[same as prior period, unchanged from 0001628280-23-028865:mdna:179]

[0001628280-23-038311:mdna:181]
During the nine months ended September 30, 2023, cash used in investing activities was $92.8 million, consisting of $51.6 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers, $2.2 million for the development of internal-use software and software embedded in products to be sold or leased, and a net $39.0 million outflow related to purchases and redemptions of marketable securities.

[0001628280-23-038311:mdna:182]
During the nine months ended September 30, 2022, cash used in investing activities was $19.2 million, consisting of $17.6 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers, and $1.9 million for the development of internal-use software, offset by $0.3 million of proceeds from the sale of property and equipment.

[0001628280-23-038311:mdna:183]
[same as prior period, unchanged from 0001628280-23-028865:mdna:182]

[0001628280-23-038311:mdna:184]
During the nine months ended September 30, 2023, cash used in financing activities was $29.7 million, consisting of $1.9 million of proceeds under the 2022 SVB Credit Agreement and $0.6 million of proceeds from the exercise of stock options, offset by $31.9 million related to the full repayment of amounts owed under the 2022 SVB Credit Agreement and $0.3 million payment of debt issuance costs and a prepayment penalty.

[0001628280-23-038311:mdna:185]
During the nine months ended September 30, 2022, cash used in financing activities was $0.4 million, consisting of $1.0 million of debt repayments, offset by $0.6 million of proceeds from the exercise of stock options.

[0001628280-23-038311:mdna:186]
[same as prior period, unchanged from 0001628280-23-028865:mdna:185]

[0001628280-23-038311:mdna:187]
[same as prior period, unchanged from 0001628280-23-028865:mdna:186]

[0001628280-23-038311:mdna:188]
[same as prior period, unchanged from 0001628280-23-028865:mdna:187]

[0001628280-23-038311:mdna:189]
Our critical accounting policies and estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” of the 2022 Form 10-K. There have been no material changes to our critical accounting policies and estimates during the nine months ended September 30, 2023.

[0001628280-23-038311:mdna:190]
[same as prior period, unchanged from 0001628280-23-028865:mdna:189]

[0001628280-23-038311:mdna:191]
[same as prior period, unchanged from 0001628280-23-028865:mdna:190]

[0001628280-23-038311:mdna:192]
[same as prior period, unchanged from 0001628280-23-028865:mdna:191]
