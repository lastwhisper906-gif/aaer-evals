# EVLV notes — 0001628280-23-038311


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-23-038311:notes:1]
[same as prior period, unchanged from 0001628280-23-028865:notes:1]

[0001628280-23-038311:notes:2]
[same as prior period, unchanged from 0001628280-23-028865:notes:2]

[0001628280-23-038311:notes:3]
[same as prior period, unchanged from 0001628280-23-028865:notes:3]

[0001628280-23-038311:notes:4]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001628280-23-038311:notes:5]
[same as prior period, unchanged from 0001628280-23-028865:notes:5]

[0001628280-23-038311:notes:6]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2023, and for the three and nine months ended September 30, 2023 and 2022 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2022 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2023 and the results of its operations for the three and nine months ended September 30, 2023 and 2022 and cash flows for the nine months ended September 30, 2023 and 2022. The results for the three and nine months ended September 30, 2023 are not necessarily indicative of results to be expected for the year ending December 31, 2023, any other interim periods, or any future year or period.

[0001628280-23-038311:notes:7]
[same as prior period, unchanged from 0001628280-23-028865:notes:7]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-23-038311:notes:8]
[same as prior period, unchanged from 0001628280-23-028865:notes:8]

[0001628280-23-038311:notes:9]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2022, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2022. Other than the addition of the accounting policy related to marketable securities as described in Note

[0001628280-23-038311:notes:10]
3. Marketable Securities, there have been no material changes to the Company’s significant accounting policies during the nine months ended September 30, 2023.

[0001628280-23-038311:notes:11]
Recently Adopted Accounting Pronouncements

[0001628280-23-038311:notes:12]
[same as prior period, unchanged from 0001628280-23-028865:notes:12]

[0001628280-23-038311:notes:13]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have a material impact on its consolidated financial statements and related disclosures.

[0001628280-23-038311:notes:14]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years, and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have an impact on its consolidated financial statements and related disclosures.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-23-038311:notes:15]
Marketable Securities
Marketable securities as of September 30, 2023 consisted of the following:

[0001628280-23-038311:notes:16]
|  | September 30, 2023 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 39,487 |  |  | $ | — |  |  | $ | 39,487 |  |
| Total marketable securities | $ | 39,487 |  |  | $ | — |  |  | $ | 39,487 |  |

[0001628280-23-038311:notes:17]
Marketable securities are reported at fair value and, at September 30, 2023, are comprised solely of zero coupon U.S. treasury bills with maturities of less than one year that are classified as available-for-sale debt securities. The Company did not record any unrealized gains or losses on available-for-sale securities for the three or nine months ended September 30, 2023. The accretion of discounts on marketable securities is included in interest income on the condensed

[0001628280-23-038311:notes:18]
consolidated statements of operations and comprehensive income. The Company did not have any marketable securities as of December 31, 2022.

[0001628280-23-038311:notes:19]
The Company considers an available-for-sale debt security to be impaired if the fair value of the investment is less than its amortized cost basis. The entire difference between the amortized cost basis and the fair value of the Company’s available-for-sale debt securities is recognized on the condensed consolidated statements of operations as an impairment if, (i) the fair value of the security is below its amortized cost and (ii) the Company intends to sell or is more likely than not required to sell the security before recovery of its amortized cost basis. If neither criterion is met, the Company evaluates whether the decline in fair value is due to credit losses or other factors. In making this assessment, the Company considers the changes to the rating of the security by third-party rating agencies, and adverse conditions specific to the security, among other factors. If the Company’s assessment indicates that a credit loss exists, the credit loss is measured based on the Company’s best estimate of the cash flows expected to be collected. When developing its estimate of cash flows expected to be collected, the Company considers all available information relevant to the collectability of the security, including past events, current conditions, and reasonable and supportable forecasts.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-23-038311:notes:20]
[same as prior period, unchanged from 0001628280-23-028865:notes:15]

[0001628280-23-038311:notes:21]
|  | Fair Value Measurements at September 30, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 73,171 |  |  | $ | — |  |  | $ | — |  |  | $ | 73,171 |  |
| Treasury bills | — |  |  | 49,372 |  |  | — |  |  | 49,372 |  |
|  | $ | 73,171 |  |  | $ | 49,372 |  |  | $ | — |  |  | $ | 122,543 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 31,571 |  |  | $ | 31,571 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 6,952 |  |  | 6,952 |  |
| Public Warrant liability | 11,469 |  |  | — |  |  | — |  |  | 11,469 |  |
|  | $ | 11,469 |  |  | $ | — |  |  | $ | 38,523 |  |  | $ | 49,992 |  |

[0001628280-23-038311:notes:22]
[same as prior period, unchanged from 0001628280-23-028865:notes:17]

[0001628280-23-038311:notes:23]
Money market funds are included in cash and cash equivalents on the condensed consolidated balance sheets. U.S. treasury bills with maturities less than 3 months, which totaled $9.9 million as of September 30, 2023, are included in cash and cash equivalents, while treasury bills with maturities greater than 3 months, which totaled $39.5 million as of September 30, 2023, are reflected as marketable securities. The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources.

[0001628280-23-038311:notes:24]
The Company may also value its non-financial assets and liabilities, including items such as inventories and property and equipment, at fair value on a non-recurring basis if it is determined that impairment has occurred. Such fair value measurements use significant unobservable inputs and are classified as Level 3.

[0001628280-23-038311:notes:25]
During each of the three and nine months ended September 30, 2023 and 2022, there were no transfers between Level 1, Level 2 and Level 3.

[0001628280-23-038311:notes:26]
[same as prior period, unchanged from 0001628280-23-028865:notes:20]

[0001628280-23-038311:notes:27]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2022. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of September 30, 2023, no milestones have been achieved.

[0001628280-23-038311:notes:28]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of September 30, 2023 were as follows: 87.5% expected stock price volatility, a risk-free rate of return of 4.9%, a 25% likelihood of change in control and a remaining term of 2.4 years.

[0001628280-23-038311:notes:29]
[same as prior period, unchanged from 0001628280-23-028865:notes:23]

[0001628280-23-038311:notes:30]
| Balance at December 31, 2022 | $ | 14,218 |  |
| Change in fair value | 17,353 |  |
| Balance at September 30, 2023 | $ | 31,571 |  |

[0001628280-23-038311:notes:31]
[same as prior period, unchanged from 0001628280-23-028865:notes:25]

[0001628280-23-038311:notes:32]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock (the "Founder Shares"). Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 517,500 Founder Shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 outstanding Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2022. The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of September 30, 2023, no milestones have been achieved.

[0001628280-23-038311:notes:33]
The fair value of the contingently issued common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of September 30, 2023 were as follows: 87.5% expected stock price volatility, a risk-free rate of return of 4.8%, a 25% likelihood of change in control and a remaining term of 2.8 years.

[0001628280-23-038311:notes:34]
[same as prior period, unchanged from 0001628280-23-028865:notes:28]

[0001628280-23-038311:notes:35]
| Balance at December 31, 2022 | $ | 3,392 |  |
| Change in fair value | 3,560 |  |
| Balance at September 30, 2023 | $ | 6,952 |  |

[0001628280-23-038311:notes:36]
[same as prior period, unchanged from 0001628280-23-028865:notes:30]

[0001628280-23-038311:notes:37]
In connection with the closing of the Merger, the Company assumed warrants (the "Public Warrants") to purchase 14,325,000 shares of common stock at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. As of September 30, 2023, 14,324,893 Public Warrants are outstanding.

[0001628280-23-038311:notes:38]
[same as prior period, unchanged from 0001628280-23-028865:notes:32]

[0001628280-23-038311:notes:39]
| Balance at December 31, 2022 | $ | 6,124 |  |
| Change in fair value | 5,345 |  |
| Balance at September 30, 2023 | $ | 11,469 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-23-038311:notes:40]
Revenue Recognition
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

[0001628280-23-038311:notes:41]
[same as prior period, unchanged from 0001628280-23-028865:notes:35]

[0001628280-23-038311:notes:42]
[same as prior period, unchanged from 0001628280-23-028865:notes:36]

[0001628280-23-038311:notes:43]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2023.

[0001628280-23-038311:notes:44]
|  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue | $ | 2,469 |  |  | $ | — |  |  | $ | 2,469 |  |
| Subscription revenue | 51,258 |  |  | 108,942 |  |  | 160,200 |  |
| Service revenue | 18,173 |  |  | 40,284 |  |  | 58,457 |  |
| Total revenue | $ | 71,900 |  |  | $ | 149,226 |  |  | $ | 221,126 |  |

[0001628280-23-038311:notes:45]
The amount of minimum future leases included in subscription revenue in the table above is based on expected income recognition. As of September 30, 2023, future minimum payments on noncancelable leases are as follows (in thousands):

[0001628280-23-038311:notes:46]
| Year Ending December 31: |  |
| 2023 (three months remaining) | $ | 12,988 |  |
| 2024 | 50,800 |  |
| 2025 | 46,632 |  |
| 2026 | 35,489 |  |
| 2027 | 14,291 |  |
|  | $ | 160,200 |  |

[0001628280-23-038311:notes:47]
[same as prior period, unchanged from 0001628280-23-028865:notes:41]

[0001628280-23-038311:notes:48]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2023 and December 31, 2022, the Company had $3.7 million and $2.9 million in current portion of contract assets and $0.5 million and $1.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001628280-23-038311:notes:49]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $4.4 million and $16.5 million during the three and nine months ended September 30, 2023 that was included in the December 31, 2022 deferred revenue balance. The Company recognized revenue of $1.3 million and $6.0 million during the three and nine months ended September 30, 2022 that was included in the December 31, 2021 deferred revenue balance.

[0001628280-23-038311:notes:50]
[same as prior period, unchanged from 0001628280-23-028865:notes:44]

[0001628280-23-038311:notes:51]
| Balance at December 31, 2022 | $ | 35,968 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (16,507) |  |
| Revenue deferred | 53,058 |  |
| Balance at September 30, 2023 | $ | 72,519 |  |

[0001628280-23-038311:notes:52]
[same as prior period, unchanged from 0001628280-23-028865:notes:46]

[0001628280-23-038311:notes:53]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue from sales-type leases | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 1,135 |  |
| Interest income on lease receivables | 49 |  |  | 60 |  |  | 153 |  |  | 170 |  |
| Lease income - operating leases | 10,231 |  |  | 5,198 |  |  | 24,661 |  |  | 12,208 |  |
| Total lease revenue | $ | 10,280 |  |  | $ | 5,287 |  |  | $ | 24,814 |  |  | $ | 13,513 |  |

[0001628280-23-038311:notes:54]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.3 million and $0.5 million during the three and nine months ended September 30, 2023, respectively. Revenue related to leases entered into with related parties were $0.2 million and $0.4 million during the three and nine months ended September 30, 2022, respectively.

[0001628280-23-038311:notes:55]
[same as prior period, unchanged from 0001628280-23-028865:notes:49]

[0001628280-23-038311:notes:56]
[same as prior period, unchanged from 0001628280-23-028865:notes:50]

[0001628280-23-038311:notes:57]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Product revenue | $ | 3,191 |  |  | $ | 9,839 |  |  | $ | 19,188 |  |  | $ | 19,179 |  |
| Leased equipment | 10,231 |  |  | 5,198 |  |  | 24,661 |  |  | 12,208 |  |
| SaaS, maintenance, and other revenue | 4,397 |  |  | 1,180 |  |  | 11,296 |  |  | 2,277 |  |
| Professional services | 360 |  |  | 313 |  |  | 1,440 |  |  | 646 |  |
| License fee and other revenue | 2,012 |  |  | — |  |  | 2,012 |  |  | — |  |
| Total revenue | $ | 20,191 |  |  | $ | 16,530 |  |  | $ | 58,597 |  |  | $ | 34,310 |  |

[0001628280-23-038311:notes:58]
CommissionsThe Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $10.8 million and $9.0 million as of September 30, 2023 and December 31, 2022, respectively. During the three months ended September 30, 2023 and 2022, the Company recognized commission expense of $1.3 million and $1.2 million, respectively. During the nine months ended September 30, 2023 and 2022, the Company recognized commission expense of $4.4 million and $2.4 million, respectively.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001628280-23-038311:notes:59]
[same as prior period, unchanged from 0001628280-23-028865:notes:53]

[0001628280-23-038311:notes:60]
[same as prior period, unchanged from 0001628280-23-028865:notes:54]

[0001628280-23-038311:notes:61]
|  | Allowance for Doubtful Accounts |
| Balance at December 31, 2022 | $ | (200) |  |
| Provisions | (258) |  |
| Write-offs, net of recoveries | 21 |  |
| Balance at September 30, 2023 | $ | (437) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001628280-23-038311:notes:62]
[same as prior period, unchanged from 0001628280-23-028865:notes:56]

[0001628280-23-038311:notes:63]
|  | September 30,2023 |  | December 31,2022 |
| Raw materials | $ | 1,323 |  |  | $ | 2,334 |  |
| Finished goods | 6,503 |  |  | 7,923 |  |
| Total | $ | 7,826 |  |  | $ | 10,257 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-23-038311:notes:64]
[same as prior period, unchanged from 0001628280-23-028865:notes:58]

[0001628280-23-038311:notes:65]
|  | September 30,2023 |  | December 31,2022 |
| Computers and telecom equipment | $ | 1,256 |  |  | $ | 599 |  |
| Lab equipment | 981 |  |  | 871 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 566 |  |  | 542 |  |
| Leased equipment | 69,129 |  |  | 35,983 |  |
| Capitalized software | 7,041 |  |  | 4,150 |  |
| Sales demo equipment | 2,720 |  |  | 2,340 |  |
| Equipment held for lease1 | 25,656 |  |  | 7,826 |  |
| Construction in progress | 638 |  |  | 71 |  |
|  | 108,098 |  |  | 52,493 |  |
| Less: Accumulated depreciation and amortization | (14,103) |  |  | (7,786) |  |
|  | $ | 93,995 |  |  | $ | 44,707 |  |

[0001628280-23-038311:notes:66]
1 Represents equipment that has not yet been deployed to a customer and, accordingly, is not being depreciated.

[0001628280-23-038311:notes:67]
As of September 30, 2023 and December 31, 2022, the net book value of capitalized software was $5.7 million and $3.5 million, respectively. These amounts include $0.5 million and $0.2 million of capitalized stock compensation costs, respectively. Depreciation and amortization expense related to property and equipment was $2.7 million and $1.4 million for the three months ended September 30, 2023 and 2022, and $6.8 million and $3.8 million for the nine months ended September 30, 2023 and 2022, respectively.

[0001628280-23-038311:notes:68]
[same as prior period, unchanged from 0001628280-23-028865:notes:62]

[0001628280-23-038311:notes:69]
|  | September 30,2023 |  | December 31,2022 |
| Leased equipment | $ | 69,129 |  |  | $ | 35,983 |  |
| Accumulated depreciation | (10,698) |  |  | (5,802) |  |
| Leased equipment, net | $ | 58,431 |  |  | $ | 30,181 |  |

[0001628280-23-038311:notes:70]
Depreciation expense related to leased units was $2.2 million and $1.1 million during the three months ended September 30, 2023 and 2022, and $5.4 million and $3.0 million for the nine months ended September 30, 2023 and 2022, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.


## us-gaap:DebtDisclosureTextBlock

[0001628280-23-038311:notes:71]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001628280-23-038311:notes:72]
|  | September 30,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |

[0001628280-23-038311:notes:73]
Silicon Valley Bank Term Loan Agreement

[0001628280-23-038311:notes:74]
In December 2022, the Company entered into a loan and security agreement (the "2022 SVB Credit Agreement") with Silicon Valley Bank ("SVB") in order to finance purchases of hardware to be leased to customers. The 2022 SVB Credit Agreement provided for an initial term loan advance of $30.0 million, which was approximately equivalent to the value of all hardware purchases made to support leasing transactions with the Company's customers through December 21, 2022 (the "SVB Closing Date"), with the opportunity to obtain, within 18 months after the SVB Closing Date, additional term loan advances, subject to the satisfaction of certain conditions, in an aggregate principal amount equal to $20.0 million (subject to an increase of an additional $25.0 million upon the satisfaction of certain conditions and approval from SVB). The interest rate applicable to the SVB Term Loans was the greater of (a) the Wall Street Journal Prime Rate plus 1.0% or (b) 7.25% per annum. Interest and principal under the SVB Credit Agreement was payable monthly.

[0001628280-23-038311:notes:75]
On March 10, 2023, SVB was closed by the California Department of Financial Protection and Innovation, which appointed the Federal Deposit Corporation ("FDIC") as receiver. The FDIC created a successor bridge bank, Silicon Valley Bridge Bank, N.A. ("SVBB"), and all deposits of SVB were transferred to SVBB under a systemic risk exception approved by the Federal Reserve, the U.S. Treasury Department, and the FDIC. On March 12, 2023, the Federal Reserve, the U.S. Treasury Department, and the FDIC announced in a joint statement that all SVB deposits, including both insured and uninsured amounts, would be available in full to account holders. SVB was acquired by First Citizens Bank on March 27, 2023.

[0001628280-23-038311:notes:76]
In light of the foregoing, on March 28, 2023, upon the recommendation of the Company’s newly-formed Investment Committee of the Board of Directors, the Company (i) gave notice of its desire and intent to terminate the commitments under the 2022 SVB Credit Agreement and (ii) transferred its excess cash out of First Citizens Bank (the “Transfer”). The Transfer resulted in an event of default under the 2022 SVB Credit Agreement. Upon the occurrence of such event of default, First Citizens Bank could have, but was not required to, declare all obligations under the 2022 SVB Credit Agreement immediately due and payable. First Citizens Bank did not make such declaration following such event of default. 
On March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-23-038311:notes:77]
[same as prior period, unchanged from 0001628280-23-028865:notes:71]

[0001628280-23-038311:notes:78]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the nine months ended September 30, 2023 and 2022:

[0001628280-23-038311:notes:79]
|  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |
| Risk-free interest rate | 4.2 | % |  | 1.6 | % |
| Expected term (in years) | 6.1 |  | 6.1 |
| Expected volatility | 87.5 | % |  | 75.0 | % |
| Expected dividend yield | 0.0 | % |  | 0.0 | % |

[0001628280-23-038311:notes:80]
[same as prior period, unchanged from 0001628280-23-028865:notes:74]

[0001628280-23-038311:notes:81]
|  | Number ofShares |  | WeightedAverageExercise Price |
| Outstanding as of December 31, 2022 | 20,396,824 |  | $ | 0.73 |  |
| Granted | 2,840,421 |  | 3.12 |  |
| Exercised | (1,607,650) |  | 0.38 |  |
| Forfeited | (566,551) |  |  | 1.23 |  |
| Outstanding as of September 30, 2023 | 21,063,044 |  | 1.07 |  |

[0001628280-23-038311:notes:82]
[same as prior period, unchanged from 0001628280-23-028865:notes:76]

[0001628280-23-038311:notes:83]
[same as prior period, unchanged from 0001628280-23-028865:notes:77]

[0001628280-23-038311:notes:84]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2022 | 7,501,945 |  |  | $ | 3.54 |  |
| Granted | 7,917,033 |  |  | 3.33 |  |
| Vested | (2,586,184) |  |  | 3.47 |  |
| Forfeited | (735,686) |  |  | 3.62 |  |
| Outstanding as of September 30, 2023 | 12,097,108 |  |  | $ | 3.41 |  |

[0001628280-23-038311:notes:85]
[same as prior period, unchanged from 0001628280-23-028865:notes:79]

[0001628280-23-038311:notes:86]
[same as prior period, unchanged from 0001628280-23-028865:notes:80]

[0001628280-23-038311:notes:87]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2022 | 864,000 |  |  | $ | 2.65 |  |
| Granted | — |  |  | — |  |
| Vested | (432,000) |  |  | 2.65 |  |
| Forfeited | (46,000) |  |  | 2.66 |  |
| Outstanding as of September 30, 2023 | 386,000 |  |  | $ | 2.65 |  |

[0001628280-23-038311:notes:88]
[same as prior period, unchanged from 0001628280-23-028865:notes:82]

[0001628280-23-038311:notes:89]
[same as prior period, unchanged from 0001628280-23-028865:notes:83]

[0001628280-23-038311:notes:90]
During the three and nine months ended September 30, 2023, 0 and 830,216 Finback Common Stock Warrants were exercised, respectively. As of September 30, 2023, 273,657 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $1.2 million, and 1,317,327 Finback Common Stock Warrants are unvested and have a total unrecognized grant date fair value of $10.0 million. During the three months ended September 30, 2023 and 2022, the Company recorded $0.8 million and $1.3 million, respectively, of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants. During the nine months ended September 30, 2023 and 2022, the Company recorded $2.2 million and $2.1 million, respectively, of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants.

[0001628280-23-038311:notes:91]
[same as prior period, unchanged from 0001628280-23-028865:notes:85]

[0001628280-23-038311:notes:92]
[same as prior period, unchanged from 0001628280-23-028865:notes:86]

[0001628280-23-038311:notes:93]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of revenue | $ | 117 |  | $ | 227 |  | $ | 446 |  | $ | 615 |
| Research and development | 1,171 |  | 1,664 |  | 3,246 |  | 3,143 |
| Sales and marketing | 1,790 |  | 2,482 |  | 6,296 |  | 6,310 |
| General and administrative | 2,493 |  | 2,152 |  | 7,315 |  | 5,445 |
| Total stock-based compensation expense | $ | 5,571 |  | $ | 6,525 |  | $ | 17,303 |  | $ | 15,513 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-23-038311:notes:94]
Income Taxes
There is no provision for income taxes for the three and nine months ended September 30, 2023 and 2022 because the Company has historically incurred net operating losses and maintains a full valuation allowance against its deferred tax assets.

[0001628280-23-038311:notes:95]
[same as prior period, unchanged from 0001628280-23-028865:notes:89]


## us-gaap:EarningsPerShareTextBlock

[0001628280-23-038311:notes:96]
Net Income (Loss) per Share
Basic net income (loss) per share is calculated by dividing net income attributable to common stockholders by the weighted average shares outstanding during the period. Diluted net income (loss) per share is calculated by adjusting weighted average shares outstanding for the dilutive effect of potential common shares, determined using the treasury stock method. Basic and diluted net income (loss) per share attributable to common stockholders are calculated as follows (in thousands, except share and per share amounts):

[0001628280-23-038311:notes:97]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net Income (loss) | $ | 5,999 |  | $ | (18,615) |  | $ | (89,364) |  | $ | (58,102) |
| Reallocation of net income attributable to participating securities | (74) |  | — |  | — |  | — |
| Net income (loss) attributable to common stockholders – basic and diluted | $ | 5,925 |  | $ | (18,615) |  | $ | (89,364) |  | $ | (58,102) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding – basic | 150,206,893 |  | 144,117,273 |  | 148,521,299 |  | 143,522,555 |
| Weighted average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Stock options | 16,528,407 |  | — |  | — |  | — |
| Restricted stock units | 6,674,985 |  | — |  | — |  | — |
| Performance stock units | 356,780 |  | — |  | — |  | — |
| Finback Common Stock Warrants | 209,310 |  | — |  | — |  | — |
| Total potentially dilutive securities | 23,769,482 |  | — |  | — |  | — |
| Weighted average common shares outstanding — diluted | 173,976,375 |  | 144,117,273 |  | 148,521,299 |  | 143,522,555 |
| Net income (loss) per share attributable to common stockholders - basic | $ | 0.04 |  | $ | (0.13) |  | $ | (0.60) |  | $ | (0.40) |
| Net income (loss) per share attributable to common stockholders - diluted | $ | 0.03 |  | $ | (0.13) |  | $ | (0.60) |  | $ | (0.40) |

[0001628280-23-038311:notes:98]
[same as prior period, unchanged from 0001628280-23-028865:notes:92]

[0001628280-23-038311:notes:99]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Options issued and outstanding | — |  |  | 21,027,840 |  |  | 21,063,044 |  | 21,027,840 |  |
| Public Warrants to purchase common stock | 14,324,893 |  |  | 14,324,994 |  |  | 14,324,893 |  |  | 14,324,994 |  |
| Warrants to purchase common stock (Finback)** | 1,317,327 |  |  | 2,421,200 |  |  | 1,590,984 |  |  | 2,421,200 |  |
| Unvested restricted stock units | 397,771 |  |  | 7,336,179 |  |  | 12,097,108 |  |  | 7,336,179 |  |
| Unvested performance stock units | — |  |  | 889,000 |  |  | 386,000 |  |  | 889,000 |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |
| Contingently issuable common stock* | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |
|  | 32,937,491 |  |  | 62,896,713 |  |  | 66,359,529 |  |  | 62,896,713 |  |

[0001628280-23-038311:notes:100]
*Issuance of Earn-out shares and Contingently issuable common stock is contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period
**Includes 273,657 vested warrants and 1,317,327 unvested warrants as of September 30, 2023


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-23-038311:notes:101]
Related Party Transactions
Business Development Agreement with Finback

[0001628280-23-038311:notes:102]
In January 2021, the Company granted the Finback Common Stock Warrants subject to the terms of the Finback BDA, as discussed in Note 10.

[0001628280-23-038311:notes:103]
In connection with the Merger and pursuant to the Merger Agreement, in addition to earn-out shares allocated to Finback based on its common stock ownership percentage as of the Merger date, Finback is entitled to receive a proportional share of earn-out shares based upon its remaining unvested warrants as of the Merger Date.

[0001628280-23-038311:notes:104]
Original Equipment Manufacturer Partnership Agreement with Motorola

[0001628280-23-038311:notes:105]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended September 30, 2023 and 2022, revenue from Motorola's distributor services was $1.7 million and $2.3 million, respectively. During the nine months ended September 30, 2023 and 2022, revenue from Motorola's distributor services was $7.9 million and $5.0 million, respectively. As of September 30, 2023 and December 31, 2022, accounts receivable related to Motorola’s distributor services was $2.0 million and $12.5 million, respectively.

[0001628280-23-038311:notes:106]
Reseller Agreement with Stanley Black & Decker

[0001628280-23-038311:notes:107]
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB ("Securitas") in 2023. Securitas, directly or through its affiliates, resells the Company's products. During the three months ended September 30, 2023 and 2022, revenue from Securitas' reseller services was $0.4 million and $0.5 million, respectively. During the nine months ended September 30, 2023 and 2022, revenue from Securitas' reseller services was $1.3 million and $0.8 million, respectively. As of September 30, 2023 and December 31, 2022, accounts receivable related to Securitas' reseller services was $0.4 million and $2.2 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-23-038311:notes:108]
Commitments and Contingencies
Indemnification Agreements

[0001628280-23-038311:notes:109]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of September 30, 2023 or December 31, 2022.

[0001628280-23-038311:notes:110]
Legal Proceedings and Other Matters

[0001628280-23-038311:notes:111]
The Company is not a party to any litigation of a material nature and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.

[0001628280-23-038311:notes:112]
In the ordinary course of business, the Company is subject to regulatory and governmental examinations, information gathering requests, inquiries and investigations. For example, the U.S. Federal Trade Commission ("FTC") has previously requested information about certain aspects of the Company's marketing practices. The Company has provided, and continues to provide, documentation and information responsive to the FTC inquiry. We currently do not expect such examinations, requests, inquiries or investigations to have a material effect on our results of operations, financial condition or liquidity, either individually or in the aggregate.
