# EVLV notes — 0001628280-25-020353


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-25-020353:notes:1]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company designed to transform human security to make a safer, faster, and better experience for the world's most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics.

[0001628280-25-020353:notes:2]
The Company announced in the third quarter of 2024 the launch of a new product offering, Evolv eXpedite™, an autonomous AI-based weapons detection system for bags. This new offering, as well as existing products such as Evolv Express®, are designed to be integrated layers for detection as part of a unified Evolv Safer Experience System™. These products and their associated services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

[0001628280-25-020353:notes:3]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).

[0001628280-25-020353:notes:4]
[same as prior period, unchanged from 0001628280-24-036182:notes:4]

[0001628280-25-020353:notes:5]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001628280-25-020353:notes:6]
Liquidity and capital resources

[0001628280-25-020353:notes:7]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of September 30, 2024, the Company had $56.0 million in cash, cash equivalents, and marketable securities, and as of March 31, 2025, the Company had $35.0 million in cash, cash equivalents, and marketable securities. The Company incurred a net loss of $38.3 million and $90.9 million for the nine months ended September 30, 2024 and 2023, respectively. The Company incurred cash outflows from operating activities of $34.1 million and $6.7 million during the nine months ended September 30, 2024 and 2023, respectively. The Company expects to continue to generate losses for the foreseeable future.

[0001628280-25-020353:notes:8]
The Company maintains substantially all of its cash, cash equivalents, and marketable securities in accounts with U.S. and multi-national financial institutions and its cash deposits at these institutions exceed Federal Deposit Insurance Corporation insured limits. The Company does not believe it is exposed to any unusual credit risk or deposit concentration risk beyond the ordinary credit risk associated with commercial banking relationships.

[0001628280-25-020353:notes:9]
The Company expects its cash, cash equivalents, and marketable securities of $56.0 million as of December 31, 2024, together with cash it expects to generate from future operations, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company

[0001628280-25-020353:notes:10]
expects to continue to strategically and carefully invest in various areas of the business to support that growth. The Company may require additional capital to respond to expected growth in the demand for equipment to support its “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances.  To the extent that the Company's projected revenue growth does not materialize, the Company has established plans to preserve existing cash liquidity, which includes additional reductions to operating expenses and capital expenditures.

[0001628280-25-020353:notes:11]
Although not required to fund ongoing operations, in an improving interest rate environment the Company may choose to engage in debt financings or enter into credit facilities for other strategic reasons. If the Company is unable to obtain adequate financing or financing on terms satisfactory to it, when it requires it, the Company's ability to continue to grow or support the business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, tariffs, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing the Company's ability to access capital. If the Company is unable to raise additional funds when or on the terms desired, its business, financial condition and results of operations could be adversely affected.

[0001628280-25-020353:notes:12]
Additionally, there continues to be significant uncertainty regarding recent changes and potential future developments related to increased trade restrictions, tariffs or taxes on imports or exports relating to countries where we source or sell materials or products. The exact magnitude of any potential impact remains uncertain, as there may be further changes to tariffs and policies and, consequently, potential increased tension between the U.S. and targeted countries, and the Company's financial condition and results of operations could be adversely affected.

[0001628280-25-020353:notes:13]
[same as prior period, unchanged from 0001628280-24-036182:notes:6]

[0001628280-25-020353:notes:14]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2024, and for the three and nine months ended September 30, 2024 and 2023 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2023 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2024 and the results of its operations for the three and nine months ended September 30, 2024 and 2023 and cash flows for the nine months ended September 30, 2024 and 2023. The results for the three and nine months ended September 30, 2024 are not necessarily indicative of results to be expected for the year ending December 31, 2024, any other interim periods, or any future year or period.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001628280-25-020353:notes:15]
Restatement of Quarterly Financial Information
In September 2024, an ad hoc committee of independent directors (the “Committee”) of the Board, under the direction of the Board, commenced an investigation (the “Investigation”) of the Company’s sales practices, including whether certain sales of products and subscriptions to channel partners and end users were subject to extra-contractual terms and conditions that impacted revenue recognition and other metrics, and if so, when senior Company personnel became aware of these issues.

[0001628280-25-020353:notes:16]
As a result of the Investigation, the Committee determined that certain sales, including sales to one of its largest channel partners, were subject to extra-contractual terms and conditions, some of which were not shared with the Company’s accounting personnel, and that certain Company personnel engaged in misconduct in connection with those transactions. Furthermore, these extra-contractual terms and conditions were withheld from the Company’s Audit Committee of the Board (the “Audit Committee”) and the Company’s independent registered public accounting firm, PricewaterhouseCoopers LLP (“PwC”). The Committee also determined that certain accounting personnel were aware of indications of these extra-contractual terms and conditions during affected periods, and that related allegations were raised internally in July 2024 and known to senior finance and accounting personnel, but that those allegations were not escalated to the Audit Committee or communicated to PwC prior to the filing of the Company’s second quarter 2024 financial statements. As a result of the Investigation, the Board determined that new leadership was critical to moving the Company forward. In November 2024, the Company’s Chief Financial Officer resigned. Additionally, four other employees,

[0001628280-25-020353:notes:17]
including personnel from its sales, finance and accounting departments were terminated or resigned as a result of the investigation.

[0001628280-25-020353:notes:18]
In connection with the investigation, the Committee determined that the accounting for certain sales transactions was materially inaccurate and that, among other things, revenue was prematurely or incorrectly recognized (the “Impacted Transactions”) in connection with financial statements prepared for the fiscal years ended December 31, 2022 and December 31, 2023 contained in its Annual Report on Form 10-K for the year-ended December 31, 2023, and its condensed consolidated financial statements for the quarters and year-to-date periods ended June 30, 2022, September 30, 2022, March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024 and June 30, 2024 contained in its Quarterly Reports on Form 10-Q.

[0001628280-25-020353:notes:19]
A review of the transactions identified in the Investigation determined that restatement changes were necessary due to:

[0001628280-25-020353:notes:20]
•an overstatement or understatement of revenue and cost of revenue depending on the changes to revenue recognition start dates in each period of the consolidated statement of operations; and

[0001628280-25-020353:notes:21]
•an overstatement or understatement of other accounts affected by changes to revenue recognition start dates, including accounts receivable, inventory, contract assets, commission assets, property and equipment, net, deferred revenue, and sales and marketing expense.

[0001628280-25-020353:notes:22]
Misstatements related to the Impacted Transactions identified in the Investigation

[0001628280-25-020353:notes:23]
Revenue

[0001628280-25-020353:notes:24]
As discussed above, the Company became aware of the presence of extra-contractual terms and conditions through the Investigation. The extra-contractual terms and conditions created ambiguity with regard to whether the Company and its customers had reached a mutual understanding of the terms of the contracts. Ultimately, the Company decided to honor the customers’ understanding of the contracts, including the terms and conditions granted outside the written contracts.

[0001628280-25-020353:notes:25]
The extra-contractual terms and conditions affected the dates on which it was appropriate for the Company to recognize revenue, or commence revenue recognition for the Impacted Transactions. In order to correct the revenue recognition start dates for each of the Impacted Transactions to be restated, the Company reviewed the terms and circumstances of each transaction, including the contractual and extra-contractual terms and conditions.

[0001628280-25-020353:notes:26]
As described above, the Company offers products for purchase or multi-year subscription leases.  All products are sold with an underlying subscription for software and services. Contracts may include multiple performance obligations when customers purchase a combination of products and services.  For equipment sales, revenue is recognized at a point in time, whereas for leased equipment and software, revenue is recognized ratably over the term (“over time”).

[0001628280-25-020353:notes:27]
GAAP requires that revenue is recognized when (or as) the entity satisfies a performance obligation by transferring the underlying asset to a customer. An asset is transferred when (or as) the customer obtains control of that asset. Further, GAAP defines control as “…the ability to direct the use of, and obtain substantially all of the remaining benefits from, the asset.”

[0001628280-25-020353:notes:28]
Historically, the Company has recognized revenue, or commenced revenue recognition, upon shipment or delivery of the product to the customer, or to the end-user as directed by the customer, if the customer is a reseller. The findings of the Investigation and Financial Statement Review, as defined below, impact the timing of when revenue recognition should begin on certain arrangements. The Company determined that it should recognize or begin to recognize revenue on the Impacted Transactions at the point in time that the Company has an enforceable contract with the customer and control transfers to the customer, which, for the Impacted Transactions, was often the installation date, which is later than the shipment or delivery date. The extra-contractual terms created in substance consignment arrangements with customers,

[0001628280-25-020353:notes:29]
which resulted in no revenue recognition until control of the product was transferred to the customer (i.e., the installation date).

[0001628280-25-020353:notes:30]
For most of the Impacted Transactions, the Company determined that the customer was only committed to the agreement and began to receive and consume the benefits provided by the Company’s performance on the date the security screening system(s) and SaaS portal were both installed and activated at the end user site.  Therefore, revenue recognition for over time performance obligations was determined to begin at the installation date and recognized over the period in which the benefits are consumed (e.g., the subscription term). Product sales were also restated to be recorded at the installation date where appropriate. For point-in-time performance obligations, revenue was recognized at the installation date.

[0001628280-25-020353:notes:31]
Property, and Equipment / Inventory

[0001628280-25-020353:notes:32]
As stated above, the Company offers products for purchase or multi-year subscription leases. For equipment for which the revenue recognition start date was moved to a later date due to the timing of the transfer of control, the equipment cost was reclassified from Leased equipment to Equipment held for lease within Property and Equipment (for leased equipment), or added back to finished goods Inventory  (for equipment sales) until the point in time that the Company transferred control of the equipment to the customer, corresponding to the revenue recognition start date.

[0001628280-25-020353:notes:33]
Cost of Product Revenue / Cost of Subscription Revenue

[0001628280-25-020353:notes:34]
For leased equipment reclassified to equipment held for lease, as described above, the Company adjusted the dates placed in service to correspond to the revised date upon which revenue recognition commenced, thus achieving appropriate alignment of revenue recognition with the recognition of depreciation expense (cost of revenue), consistent with the company’s accounting policies. For equipment added back to inventory related to sales of equipment, the Company added back the associated cost of revenue in the period it was originally recognized, and restated the cost of revenue to correspond with the revenue recognition start date.

[0001628280-25-020353:notes:35]
Commissions Asset / Commissions Expense

[0001628280-25-020353:notes:36]
Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract, which generally begins upon transfer of control. For the Impacted Transactions on which the Company adjusted the revenue recognition start date, the amortization of the corresponding commission expense was adjusted to conform to the adjusted revenue recognition start date.

[0001628280-25-020353:notes:37]
Accounts Receivable, Contract Assets, Deferred Revenue

[0001628280-25-020353:notes:38]
Deferred Revenue, Contract Assets and Accounts Receivable relating to affected customer arrangements were adjusted to reflect the corresponding changes in revenue recognition start dates.

[0001628280-25-020353:notes:39]
Additional errors identified through the Financial Statement Review

[0001628280-25-020353:notes:40]
Following the Investigation, the Company completed a comprehensive review of its previously issued financial statements (the “Financial Statement Review”), which resulted in the identification of additional errors. These adjustments included:

[0001628280-25-020353:notes:41]
•an understatement of research and development expense and overstatement of property, plant and equipment in certain periods due to an error in the calculation of internal-use software costs in the first and second quarters of 2024;

[0001628280-25-020353:notes:42]
•an overstatement of cost of revenue and understatement of inventory and property and equipment, net in the first and second quarters of 2024 related to the expensing of inbound freight costs that should have been capitalized into inventory or property and equipment, net; and

[0001628280-25-020353:notes:43]
•an overstatement of accounts receivable and contract assets and corresponding understatement of deferred revenue in each period related to the incorrect classification of amounts due to the Company resulting from its contracts with customers.

[0001628280-25-020353:notes:44]
The impact of the correction of the misstatements and errors resulting from the Investigation and Financial Statement Review on the condensed consolidated financial statements in this Form 10-Q, as well as previously identified immaterial errors which have now been corrected, are summarized below. The applicable accompanying notes to the condensed consolidated financial statements have also been updated.

[0001628280-25-020353:notes:45]
The impact of the correction of the misstatements on the Condensed Consolidated Statements of Stockholders' Equity were solely within net (loss) income for errors impacting accumulated deficit and within stock-based compensation cost for errors impacting accumulated paid in capital.

[0001628280-25-020353:notes:46]
The impact of the correction of the misstatements and errors on the Condensed Consolidated Statements of Cash Flows were driven by changes in the related Consolidated Balance Sheet and Condensed Consolidated Statement of Operations and Comprehensive Income (Loss) line items, except as noted by footnote under each applicable table below.

[0001628280-25-020353:notes:47]
Where adjustments in the below tables relate to multiple categories, the adjustment amounts of each category are noted below each table and sum to the total adjustment reflected. Restatement adjustments are reflected as follows:

[0001628280-25-020353:notes:48]
ADJ 1: related to revenue recognition misstatements identified as part of the Investigation.

[0001628280-25-020353:notes:49]
ADJ 2: other immaterial errors previously identified in prior periods corrected as part of the restatement.

[0001628280-25-020353:notes:50]
ADJ 3: related to classification errors in contract assets and deferred revenue.

[0001628280-25-020353:notes:51]
As of the Year Ended December 31, 2023

[0001628280-25-020353:notes:52]
Restated Consolidated Balance Sheet

[0001628280-25-020353:notes:53]
(In thousands, except share and per share amounts)

[0001628280-25-020353:notes:54]
|  |  |  | As of December 31, 2023 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Assets |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 67,162 |  |  | $ | — |  |  | $ | 67,162 |  |
| Restricted cash |  |  | 275 |  |  | — |  |  | 275 |  |
| Marketable securities |  |  | 51,289 |  |  | — |  |  | 51,289 |  |
| Accounts receivable, net | ADJ 1, ADJ 3 |  | 22,611 |  |  | (1,064) |  |  | 21,547 |  |
| Inventory | ADJ 1 |  | 9,507 |  |  | 837 |  |  | 10,344 |  |
| Current portion of contract assets | ADJ 1, ADJ 3 |  | 3,707 |  |  | (2,310) |  |  | 1,397 |  |
| Current portion of commission asset | ADJ 1 |  | 4,339 |  |  | 48 |  |  | 4,387 |  |
| Prepaid expenses and other current assets | ADJ 1 |  | 16,954 |  |  | 3 |  |  | 16,957 |  |
| Total current assets |  |  | 175,844 |  |  | (2,486) |  |  | 173,358 |  |
| Contract assets, noncurrent | ADJ 1, ADJ 3 |  | 451 |  |  | 513 |  |  | 964 |  |
| Commission asset, noncurrent | ADJ 1 |  | 7,107 |  |  | 142 |  |  | 7,249 |  |
| Property and equipment, net | ADJ 1, ADJ 2 |  | 112,921 |  |  | 240 |  |  | 113,161 |  |
| Operating lease right-of-use assets |  |  | 1,195 |  |  | — |  |  | 1,195 |  |
| Other assets |  |  | 1,202 |  |  | — |  |  | 1,202 |  |
| Total assets |  |  | $ | 298,720 |  |  | $ | (1,591) |  |  | $ | 297,129 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 17,400 |  |  | $ | — |  |  | $ | 17,400 |  |
| Accrued expenses and other current liabilities | ADJ 2 |  | 15,578 |  |  | 125 |  |  | 15,703 |  |
| Current portion of deferred revenue | ADJ 1, ADJ 3 |  | 47,677 |  |  | (869) |  |  | 46,808 |  |
| Current portion of operating lease liabilities |  |  | 1,391 |  |  | — |  |  | 1,391 |  |
| Total current liabilities |  |  | 82,046 |  |  | (744) |  |  | 81,302 |  |
| Deferred revenue, noncurrent | ADJ 3 |  | 23,813 |  |  | 1,336 |  |  | 25,149 |  |
| Contingent earn-out liability |  |  | 29,119 |  |  | — |  |  | 29,119 |  |
| Contingently issuable common stock liability |  |  | 6,530 |  |  | — |  |  | 6,530 |  |
| Public warrant liability |  |  | 10,889 |  |  | — |  |  | 10,889 |  |
| Total liabilities |  |  | 152,397 |  |  | 592 |  |  | 152,989 |  |
| Commitments and contingencies (Note 16) |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Common stock |  |  | 15 |  |  | — |  |  | 15 |  |
| Additional paid-in capital |  |  | 444,825 |  |  | — |  |  | 444,825 |  |
| Accumulated other comprehensive loss |  |  | (53) |  |  | — |  |  | (53) |  |
| Accumulated deficit |  |  | (298,464) |  |  | (2,183) |  |  | (300,647) |  |
| Stockholders’ equity |  |  | 146,323 |  |  | (2,183) |  |  | 144,140 |  |
| Total liabilities and stockholders’ equity |  |  | $ | 298,720 |  |  | $ | (1,591) |  |  | $ | 297,129 |  |

[0001628280-25-020353:notes:55]
(a) Category references are described above. Where adjustments relate to multiple categories, the adjustment amounts of each category are noted below and sum to the total adjustment reflected in the table above:

[0001628280-25-020353:notes:56]
Accounts receivable, net: ADJ 1 = ($1,974), ADJ 3 = $910

[0001628280-25-020353:notes:57]
Current portion of contract assets: ADJ 1 = ($1,154), ADJ 3 = ($1,156)

[0001628280-25-020353:notes:58]
Contract assets, noncurrent: ADJ 1 = ($126), ADJ 3 = $639

[0001628280-25-020353:notes:59]
Property and equipment, net: ADJ 1 = $212, ADJ 2 = $28

[0001628280-25-020353:notes:60]
Current portion of deferred revenue: ADJ 1 = $73, ADJ 3 = ($942)

[0001628280-25-020353:notes:61]
For the Three and Nine Months Ended September 30, 2023

[0001628280-25-020353:notes:62]
Restated Condensed Consolidated Statements of Operations and Comprehensive Income (Loss) Data

[0001628280-25-020353:notes:63]
|  |  |  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |  | As Reported |  | Adjustment |  | As Restated |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | ADJ 1 |  | $ | 3,191 |  |  | $ | 265 |  |  | $ | 3,456 |  |  | $ | 19,188 |  |  | $ | 1,732 |  |  | $ | 20,920 |  |
| Subscription revenue | ADJ 1, ADJ 2 |  | 10,231 |  |  | (373) |  |  | 9,858 |  |  | 24,661 |  |  | (928) |  |  | 23,733 |  |
| Service revenue | ADJ 1, ADJ 2 |  | 4,435 |  |  | (90) |  |  | 4,345 |  |  | 11,126 |  |  | (376) |  |  | 10,750 |  |
| License fee and other revenue | ADJ 1 |  | 2,334 |  |  | (32) |  |  | 2,302 |  |  | 3,622 |  |  | (40) |  |  | 3,582 |  |
| Total revenue |  |  | 20,191 |  |  | (230) |  |  | 19,961 |  |  | 58,597 |  |  | 388 |  |  | 58,985 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | ADJ 1, ADJ 2 |  | 3,153 |  |  | 343 |  |  | 3,496 |  |  | 21,453 |  |  | 1,822 |  |  | 23,275 |  |
| Cost of subscription revenue | ADJ 1, ADJ 2 |  | 4,231 |  |  | (74) |  |  | 4,157 |  |  | 9,988 |  |  | (212) |  |  | 9,776 |  |
| Cost of service revenue |  |  | 1,219 |  |  | — |  |  | 1,219 |  |  | 2,816 |  |  | — |  |  | 2,816 |  |
| Cost of license fee and other revenue |  |  | 198 |  |  | — |  |  | 198 |  |  | 772 |  |  | — |  |  | 772 |  |
| Total cost of revenue |  |  | 8,801 |  |  | 269 |  |  | 9,070 |  |  | 35,029 |  |  | 1,610 |  |  | 36,639 |  |
| Gross profit |  |  | 11,390 |  |  | (499) |  |  | 10,891 |  |  | 23,568 |  |  | (1,222) |  |  | 22,346 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | ADJ 2 |  | 6,409 |  |  | (23) |  |  | 6,386 |  |  | 18,193 |  |  | (23) |  |  | 18,170 |  |
| Sales and marketing | ADJ 1, ADJ 2 |  | 13,919 |  |  | 489 |  |  | 14,408 |  |  | 40,336 |  |  | 306 |  |  | 40,642 |  |
| General and administrative | ADJ 2 |  | 11,273 |  |  | (12) |  |  | 11,261 |  |  | 31,073 |  |  | (19) |  |  | 31,054 |  |
| Loss from impairment of property and equipment |  |  | 28 |  |  | — |  |  | 28 |  |  | 322 |  |  | — |  |  | 322 |  |
| Total operating expenses |  |  | 31,629 |  |  | 454 |  |  | 32,083 |  |  | 89,924 |  |  | 264 |  |  | 90,188 |  |
| Loss from operations |  |  | (20,239) |  |  | (953) |  |  | (21,192) |  |  | (66,356) |  |  | (1,486) |  |  | (67,842) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | — |  |  | — |  |  | — |  |  | (654) |  |  | — |  |  | (654) |  |
| Interest income |  |  | 1,791 |  |  | — |  |  | 1,791 |  |  | 4,597 |  |  | — |  |  | 4,597 |  |
| Other expense, net |  |  | (64) |  |  | — |  |  | (64) |  |  | (67) |  |  | — |  |  | (67) |  |
| Loss on extinguishment of debt |  |  | — |  |  | — |  |  | — |  |  | (626) |  |  | — |  |  | (626) |  |
| Change in fair value of contingent earn-out liability |  |  | 14,078 |  |  | — |  |  | 14,078 |  |  | (17,353) |  |  | — |  |  | (17,353) |  |
| Change in fair value of contingently issuable common stock liability |  |  | 2,277 |  |  | — |  |  | 2,277 |  |  | (3,560) |  |  | — |  |  | (3,560) |  |
| Change in fair value of public warrant liability |  |  | 8,156 |  |  | — |  |  | 8,156 |  |  | (5,345) |  |  | — |  |  | (5,345) |  |
| Total other income (expense), net |  |  | 26,238 |  |  | — |  |  | 26,238 |  |  | (23,008) |  |  | — |  |  | (23,008) |  |
| Net income (loss) |  |  | $ | 5,999 |  |  | $ | (953) |  |  | $ | 5,046 |  |  | $ | (89,364) |  |  | $ | (1,486) |  |  | $ | (90,850) |  |

[0001628280-25-020353:notes:64]
| Net income (loss) attributable to common stockholders - basic and diluted |  |  | $ | 5,925 |  |  | $ | (942) |  |  | $ | 4,983 |  |  | $ | (89,364) |  |  | $ | (1,486) |  |  | $ | (90,850) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 150,206,893 |  |  | — |  |  | 150,206,893 |  |  | 148,521,299 |  |  | — |  |  | 148,521,299 |  |
| Diluted |  |  | 173,976,375 |  |  | — |  |  | 173,976,375 |  |  | 148,521,299 |  |  | — |  |  | 148,521,299 |  |
| Net income (loss) per share |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | $ | 0.04 |  |  | $ | (0.01) |  |  | $ | 0.03 |  |  | $ | (0.60) |  |  | $ | (0.01) |  |  | $ | (0.61) |  |
| Diluted |  |  | $ | 0.03 |  |  | $ | — |  |  | $ | 0.03 |  |  | $ | (0.60) |  |  | $ | (0.01) |  |  | $ | (0.61) |  |
| Net income (loss) |  |  | $ | 5,999 |  |  | $ | (953) |  |  | $ | 5,046 |  |  | $ | (89,364) |  |  | $ | (1,486) |  |  | $ | (90,850) |  |
| Other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  | 34 |  |  | — |  |  | 34 |  |  | 1 |  |  | — |  |  | 1 |  |
| Total other comprehensive income (loss) |  |  | 34 |  |  | — |  |  | 34 |  |  | 1 |  |  | — |  |  | 1 |  |
| Total comprehensive income (loss) |  |  | $ | 6,033 |  |  | $ | (953) |  |  | $ | 5,080 |  |  | $ | (89,363) |  |  | $ | (1,486) |  |  | $ | (90,849) |  |

[0001628280-25-020353:notes:65]
Three months ended:

[0001628280-25-020353:notes:66]
Subscription revenue: ADJ 1 = ($373)

[0001628280-25-020353:notes:67]
Service revenue: AD1 = ($90)

[0001628280-25-020353:notes:68]
Cost of product revenue: ADJ 1 = $346, ADJ 2 = ($3)

[0001628280-25-020353:notes:69]
Cost of subscription revenue: ADJ 1 = ($75), ADJ 2 = $1

[0001628280-25-020353:notes:70]
Sales and marketing: ADJ 1 = ($14), ADJ 2 = $503

[0001628280-25-020353:notes:71]
Nine months ended:

[0001628280-25-020353:notes:72]
Subscription revenue: ADJ 1 = ($907), ADJ 2 = ($21)

[0001628280-25-020353:notes:73]
Service revenue: ADJ 1 = ($397), ADJ 2 = $21

[0001628280-25-020353:notes:74]
Cost of product revenue: ADJ 1 = $2,128, ADJ 2 = ($306)

[0001628280-25-020353:notes:75]
Cost of subscription revenue: ADJ 1 = ($174), ADJ 2 = ($38)

[0001628280-25-020353:notes:76]
Sales and marketing: ADJ 1 = $26, ADJ 2 = $280

[0001628280-25-020353:notes:77]
Restated Condensed Consolidated Statement of Cash Flows

[0001628280-25-020353:notes:78]
(In thousands)

[0001628280-25-020353:notes:79]
|  |  |  | Nine Months Ended September 30, 2023 |
|  |  |  | As Reported |  | Adjustment |  | As Restated |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (89,364) |  |  | $ | (1,486) |  |  | $ | (90,850) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 6,781 |  |  | (211) |  |  | 6,570 |  |
| Write-off of inventory and change in inventory reserve |  |  | 581 |  |  | (303) |  |  | 278 |  |
| Loss from impairment of property and equipment |  |  | 322 |  |  | — |  |  | 322 |  |
| Stock-based compensation |  |  | 17,303 |  |  | 468 |  |  | 17,771 |  |
| Non-cash interest expense |  |  | 22 |  |  | — |  |  | 22 |  |
| Amortization (accretion) of premium (discount) on marketable securities, net of change in accrued interest |  |  | (482) |  |  | — |  |  | (482) |  |
| Non-cash lease expense |  |  | 136 |  |  | — |  |  | 136 |  |
| Change in allowance for expected credit losses |  |  | 237 |  |  | — |  |  | 237 |  |
| Loss on extinguishment of debt |  |  | 626 |  |  | — |  |  | 626 |  |
| Change in fair value of earn-out liability |  |  | 17,353 |  |  | — |  |  | 17,353 |  |
| Change in fair value of contingently issuable common stock |  |  | 3,560 |  |  | — |  |  | 3,560 |  |

[0001628280-25-020353:notes:80]
| Change in fair value of public warrant liability |  |  | 5,345 |  |  | — |  |  | 5,345 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 2,107 |  |  | (3,036) |  |  | (929) |  |
| Inventory |  |  | 2,041 |  |  | 2,129 |  |  | 4,170 |  |
| Commission assets |  |  | (1,757) |  |  | (345) |  |  | (2,102) |  |
| Contract assets |  |  | 75 |  |  | (160) |  |  | (85) |  |
| Other assets |  |  | 352 |  |  | — |  |  | 352 |  |
| Prepaid expenses and other current assets |  |  | (2,111) |  |  | 138 |  |  | (1,973) |  |
| Accounts payable |  |  | (6,396) |  |  | — |  |  | (6,396) |  |
| Deferred revenue |  |  | 36,551 |  |  | 2,806 |  |  | 39,357 |  |
| Accrued expenses and other current liabilities |  |  | 278 |  |  | — |  |  | 278 |  |
| Operating lease liability |  |  | (218) |  |  | — |  |  | (218) |  |
| Net cash used in operating activities |  |  | (6,658) |  |  | — |  |  | (6,658) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Development of internal-use software |  |  | (2,202) |  |  | — |  |  | (2,202) |  |
| Purchases of property and equipment |  |  | (51,646) |  |  | — |  |  | (51,646) |  |
| Proceeds from sale of property and equipment |  |  | 60 |  |  | — |  |  | 60 |  |
| Purchases of marketable securities |  |  | (58,652) |  |  | — |  |  | (58,652) |  |
| Proceeds from maturities of marketable securities |  |  | 19,647 |  |  | — |  |  | 19,647 |  |
| Net cash used in investing activities |  |  | (92,793) |  |  | — |  |  | (92,793) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 616 |  |  | — |  |  | 616 |  |
| Proceeds from long-term debt |  |  | 1,876 |  |  | — |  |  | 1,876 |  |
| Repayment of principal on long-term debt |  |  | (31,876) |  |  | — |  |  | (31,876) |  |
| Payment of debt issuance costs and prepayment penalty |  |  | (332) |  |  | — |  |  | (332) |  |
| Net cash used in financing activities |  |  | (29,716) |  |  | — |  |  | (29,716) |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1 |  |  | — |  |  | 1 |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (129,166) |  |  | — |  |  | (129,166) |  |
| Cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 230,058 |  |  | — |  |  | 230,058 |  |
| Cash, cash equivalents and restricted cash at end of period |  |  | $ | 100,892 |  |  | $ | — |  |  | $ | 100,892 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |
| Cash paid for interest |  |  | $ | 710 |  |  | $ | — |  |  | $ | 710 |  |
| Supplemental disclosure of non-cash activities |  |  |  |  |  |  |  |
| Transfer of property and equipment to inventory |  |  | $ | 191 |  |  | $ | — |  |  | $ | 191 |  |
| Capital expenditures incurred but not yet paid |  |  | 10,214 |  |  | — |  |  | 10,214 |  |
| Capitalization of stock compensation |  |  | 340 |  |  | — |  |  | 340 |  |
| Finback exercise price |  |  | 348 |  |  | — |  |  | 348 |  |
| Reconciliation of cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 99,617 |  |  | $ | — |  |  | $ | 99,617 |  |
| Restricted cash |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Total cash, cash equivalents and restricted cash shown in the statements of cash flows |  |  | $ | 100,892 |  |  | $ | — |  |  | $ | 100,892 |  |

[0001628280-25-020353:notes:81]
The footnotes that follow have been updated to reflect the restatement adjustments as described above.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-25-020353:notes:82]
[same as prior period, unchanged from 0001628280-24-036182:notes:11]

[0001628280-25-020353:notes:83]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2023, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2023. Other than "Contract Balances from Contracts with Customers", "Commissions" and "Consignment Sales" discussed below, there have been no material changes to the Company’s significant accounting policies during the nine months ended September 30, 2024.

[0001628280-25-020353:notes:84]
Contract Balances from Contracts with Customers

[0001628280-25-020353:notes:85]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent.

[0001628280-25-020353:notes:86]
Commissions

[0001628280-25-020353:notes:87]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract.

[0001628280-25-020353:notes:88]
Consignment Sales

[0001628280-25-020353:notes:89]
As discussed in Note 2, Restatement of Quarterly Financial Information, the Company entered into certain in-substance consignment arrangements with reseller partners for which product revenue has been recognized at the point in time when control transferred to the customer and the customer has an unconditional obligation to pay for the goods transferred, which was deemed to occur upon installation at the end-user site.

[0001628280-25-020353:notes:90]
Recently Issued Accounting Pronouncements

[0001628280-25-020353:notes:91]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures.” The updated accounting guidance requires a public entity to disclose significant segment expenses and other segment items on an annual and interim basis and to provide in interim periods all disclosures about a reportable segment’s profit or loss and assets that are currently required annually for entities with more than one reportable segment. Public entities with a single reporting segment are required to provide both the new disclosures and all of the existing disclosures required under ASC 280. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Retrospective application is required and early adoption is permitted. The Company will adopt this guidance retrospectively effective December 31, 2024. Since this new ASU addresses only disclosures, the adoption of this ASU will not have any material effects on its financial condition, results of operations, or cash flows.

[0001628280-25-020353:notes:92]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity should apply the amendments in ASU 2023-09 prospectively to all annual periods beginning after December 15, 2024. The

[0001628280-25-020353:notes:93]
Company determined that although the ASU is applicable, it addresses disclosures only, and as such will not have any material effects on its financial condition, results of operations, or cash flows.

[0001628280-25-020353:notes:94]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses.”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the condensed consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-25-020353:notes:95]
Marketable Securities
Marketable securities as of September 30, 2024 and December 31, 2023 consisted of the following:

[0001628280-25-020353:notes:96]
|  | September 30, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 9,960 |  |  | $ | — |  |  | $ | 9,960 |  |
| Total marketable securities | $ | 9,960 |  |  | $ | — |  |  | $ | 9,960 |  |

[0001628280-25-020353:notes:97]
|  | December 31, 2023 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |
| Total marketable securities | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |

[0001628280-25-020353:notes:98]
Marketable securities at September 30, 2024 and December 31, 2023 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and nine months ended September 30, 2024 and 2023. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive (loss) income.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-020353:notes:99]
[same as prior period, unchanged from 0001628280-24-036182:notes:20]

[0001628280-25-020353:notes:100]
|  | Fair Value Measurements at September 30, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 22,461 |  |  | $ | — |  |  | $ | — |  |  | $ | 22,461 |  |
| Treasury bills | — |  |  | 20,902 |  |  | — |  |  | 20,902 |  |
|  | $ | 22,461 |  |  | $ | 20,902 |  |  | $ | — |  |  | $ | 43,363 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 14,027 |  |  | $ | 14,027 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 4,312 |  |  | 4,312 |  |
| Public Warrant liability | 5,428 |  |  | — |  |  | — |  |  | 5,428 |  |
|  | $ | 5,428 |  |  | $ | — |  |  | $ | 18,339 |  |  | $ | 23,767 |  |

[0001628280-25-020353:notes:101]
[same as prior period, unchanged from 0001628280-24-036182:notes:22]

[0001628280-25-020353:notes:102]
Money market funds are included in cash and cash equivalents on the condensed consolidated balance sheets. As of September 30, 2024, U.S. treasury bills with maturities less than 3 months, which totaled $10.9 million, are included in cash and cash equivalents, while treasury bills with maturities greater than 3 months, which totaled $10.0 million, are reflected as marketable securities. As of December 31, 2023, all outstanding treasury bills, which totaled $51.3 million, had original maturities greater than three months and are reflected as marketable securities. The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources.

[0001628280-25-020353:notes:103]
[same as prior period, unchanged from 0001628280-24-036182:notes:24]

[0001628280-25-020353:notes:104]
[same as prior period, unchanged from 0001628280-24-036182:notes:25]

[0001628280-25-020353:notes:105]
During each of the nine months ended September 30, 2024 and 2023, there were no transfers between Level 1, Level 2 and Level 3.

[0001628280-25-020353:notes:106]
[same as prior period, unchanged from 0001628280-24-036182:notes:27]

[0001628280-25-020353:notes:107]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2023. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of September 30, 2024, no milestones have been achieved.

[0001628280-25-020353:notes:108]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of September 30, 2024 were as follows: 87.5% expected stock price volatility, a risk-free rate of return of 3.8%, a 25% likelihood of change in control and a remaining term of 1.4 years.

[0001628280-25-020353:notes:109]
[same as prior period, unchanged from 0001628280-24-036182:notes:30]

[0001628280-25-020353:notes:110]
| Balance at December 31, 2023 | $ | 29,119 |  |
| Change in fair value | (15,092) |  |
| Balance at September 30, 2024 | $ | 14,027 |  |

[0001628280-25-020353:notes:111]
[same as prior period, unchanged from 0001628280-24-036182:notes:32]

[0001628280-25-020353:notes:112]
[same as prior period, unchanged from 0001628280-24-036182:notes:33]

[0001628280-25-020353:notes:113]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock which were converted into shares of the Company's stock in connection with the Merger (the “Founder Shares”). Of these shares, 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 outstanding shares will vest upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2023. The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of September 30, 2024, no milestones have been achieved.

[0001628280-25-020353:notes:114]
The fair value of the contingently issued common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of September 30, 2024 were as follows: 87.5% expected stock price volatility, a risk-free rate of return of 3.7%, a 25% likelihood of change in control and a remaining term of 1.8 years.

[0001628280-25-020353:notes:115]
[same as prior period, unchanged from 0001628280-24-036182:notes:36]

[0001628280-25-020353:notes:116]
| Balance at December 31, 2023 | $ | 6,530 |  |
| Change in fair value | (2,218) |  |
| Balance at September 30, 2024 | $ | 4,312 |  |

[0001628280-25-020353:notes:117]
[same as prior period, unchanged from 0001628280-24-036182:notes:38]

[0001628280-25-020353:notes:118]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at

[0001628280-25-020353:notes:119]
each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. As of September 30, 2024, 14,324,893 Public Warrants are outstanding.

[0001628280-25-020353:notes:120]
[same as prior period, unchanged from 0001628280-24-036182:notes:40]

[0001628280-25-020353:notes:121]
| Balance at December 31, 2023 | $ | 10,889 |  |
| Change in fair value | (5,461) |  |
| Balance at September 30, 2024 | $ | 5,428 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-25-020353:notes:122]
[same as prior period, unchanged from 0001628280-24-036182:notes:42]

[0001628280-25-020353:notes:123]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after control passes to the customer. Revenue is recognized net of sales tax.

[0001628280-25-020353:notes:124]
[same as prior period, unchanged from 0001628280-24-036182:notes:44]

[0001628280-25-020353:notes:125]
[same as prior period, unchanged from 0001628280-24-036182:notes:45]

[0001628280-25-020353:notes:126]
[same as prior period, unchanged from 0001628280-24-036182:notes:46]

[0001628280-25-020353:notes:127]
[same as prior period, unchanged from 0001628280-24-036182:notes:47]

[0001628280-25-020353:notes:128]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2024:

[0001628280-25-020353:notes:129]
|  | Less than 1 year |  | 1 - 2 years |  | More than 2 years |  | Total |
| Product revenue | $ | 1,669 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,669 |  |
| Subscription revenue | 72,233 |  |  | 61,967 |  |  | 64,879 |  |  | 199,079 |  |
| Service revenue | 25,384 |  |  | 23,065 |  |  | 18,906 |  |  | 67,355 |  |
| License fee and other revenue | 790 |  |  | 12 |  |  | 22 |  |  | 824 |  |
| Total revenue | $ | 100,076 |  |  | $ | 85,044 |  |  | $ | 83,807 |  |  | $ | 268,927 |  |

[0001628280-25-020353:notes:130]
The amount of minimum future leases is based on expected income recognition. As of September 30, 2024, future minimum payments on noncancelable leases are as follows (in thousands):

[0001628280-25-020353:notes:131]
| Year Ending December 31: |  |
| 2024 (three months remaining) | $ | 18,703 |  |
| 2025 | 70,166 |  |
| 2026 | 58,474 |  |
| 2027 | 38,816 |  |
| 2028 | 12,430 |  |
| Thereafter | 490 |  |
|  | $ | 199,079 |  |

[0001628280-25-020353:notes:132]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2024 and December 31, 2023, the Company had less than $0.7 million and $1.4 million (as restated) in current portion of contract assets and $0.7 million and $1.0 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001628280-25-020353:notes:133]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $10.1 million and $40.8 million during the three and nine months ended September 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance. The Company recognized revenue (as restated) of $3.6 million and $15.5 million during the three and nine months ended September 30, 2023, respectively, that was included in the December 31, 2022 deferred revenue balance.

[0001628280-25-020353:notes:134]
[same as prior period, unchanged from 0001628280-24-036182:notes:55]

[0001628280-25-020353:notes:135]
| Balance at December 31, 2023 (restated) | $ | 71,957 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance (restated) | (40,780) |  |
| Revenue deferred (restated) | 54,339 |  |
| Balance at September 30, 2024 | $ | 85,516 |  |

[0001628280-25-020353:notes:136]
[same as prior period, unchanged from 0001628280-24-036182:notes:57]

[0001628280-25-020353:notes:137]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Interest income on lease receivables | $ | 40 |  |  | $ | 49 |  |  | $ | 123 |  |  | $ | 153 |  |
| Lease income - operating leases | 17,909 |  |  | 9,858 |  |  | 47,783 |  |  | 23,733 |  |
| Total lease revenue | $ | 17,949 |  |  | $ | 9,907 |  |  | $ | 47,906 |  |  | $ | 23,886 |  |

[0001628280-25-020353:notes:138]
Interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.5 million and $0.3 million during the three months ended September 30, 2024 and 2023, respectively. Revenue related to leases entered into with related parties were $1.1 million and $0.7 million (restated) during the nine months ended September 30, 2024 and 2023, respectively.

[0001628280-25-020353:notes:139]
[same as prior period, unchanged from 0001628280-24-036182:notes:60]

[0001628280-25-020353:notes:140]
[same as prior period, unchanged from 0001628280-24-036182:notes:61]

[0001628280-25-020353:notes:141]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Product revenue | $ | 1,344 |  |  | $ | 3,456 |  |  | $ | 4,789 |  |  | $ | 20,920 |  |
| Subscription revenue | 17,909 |  |  | 9,858 |  |  | 47,783 |  |  | 23,733 |  |
| Service revenue | 6,085 |  |  | 4,345 |  |  | 16,903 |  |  | 10,750 |  |
| License fees | 1,606 |  |  | 2,012 |  |  | 4,047 |  |  | 2,012 |  |
| Professional services and other revenue | 416 |  |  | 290 |  |  | 1,243 |  |  | 1,570 |  |
| Total revenue | $ | 27,360 |  |  | $ | 19,961 |  |  | $ | 74,765 |  |  | $ | 58,985 |  |

[0001628280-25-020353:notes:142]
Commissions
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had total deferred assets related to commissions of $12.6 million and $11.6 million (as restated) as of September 30, 2024 and December 31, 2023, respectively. During the three months ended September 30, 2024 and 2023, the Company recognized commission expense of $1.4 million and $1.3 million (as restated), respectively. During the nine months ended September 30, 2024 and 2023, the Company recognized commission expense of $4.3 million and $4.2 million  (as restated), respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-25-020353:notes:143]
Leases
Company Headquarters (Waltham, MA)

[0001628280-25-020353:notes:144]
In April 2021, the Company entered into a sublease agreement for office and storage space for its corporate headquarters located at 500 Totten Pond Road in Waltham, MA. The Company entered into an amendment to the sublease agreement during the three months ended September 30, 2023 in order to lease additional space within the building. During the three months ended March 31, 2024, the Company amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. Additionally, during the three months ended September 30, 2024, the Company amended the lease agreement again to expand our footprint in our headquarters and extend our lease until May 31, 2031. As a result of this amendment, no further option exists to extend the lease.

[0001628280-25-020353:notes:145]
The weighted-average remaining lease term and discount rate were as follows:

[0001628280-25-020353:notes:146]
|  | 2024 |  | 2023 |
| Weighted average remaining lease term | 6.7 years |  | 0.8 years |
| Weighted average discount rate | 9.48 | % |  | 7.75 | % |

[0001628280-25-020353:notes:147]
Future annual lease payments under non-cancelable operating leases as of September 30, 2024 were as follows (in thousands):

[0001628280-25-020353:notes:148]
| Year Ended December 31: |  |
| 2024 (remaining three months) | $ | 458 |  |
| 2025 | $ | 2,209 |  |
| 2026 | 2,961 |  |
| 2027 | 3,119 |  |
| 2028 | 3,214 |  |
| 2029 | 3,308 |  |
| 2030 | 3,403 |  |
| 2031 | 1,404 |  |
| Total future lease payments | 20,076 |  |
| Less: imputed interest | (5,513) |  |
| Present value of operating lease liability | $ | 14,563 |  |


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001628280-25-020353:notes:149]
[same as prior period, unchanged from 0001628280-24-036182:notes:64]

[0001628280-25-020353:notes:150]
[same as prior period, unchanged from 0001628280-24-036182:notes:65]

[0001628280-25-020353:notes:151]
|  | Allowance for Doubtful Accounts |
| Balance at December 31, 2023 (restated) | $ | (582) |  |
| Provisions | (374) |  |
| Write-offs, net of recoveries | 3 |  |
| Balance at September 30, 2024 | $ | (953) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001628280-25-020353:notes:152]
[same as prior period, unchanged from 0001628280-24-036182:notes:67]

[0001628280-25-020353:notes:153]
|  | September 30,2024 |  | December 31,2023 |
|  |  |  | (Restated) |
| Raw materials | $ | 3,605 |  |  | $ | 1,869 |  |
| Finished goods |  |  |  |
| Finished goods inventory | 12,460 |  |  | 7,638 |  |
| Uninstalled inventory | 211 |  |  | 837 |  |
| Total | $ | 16,276 |  |  | $ | 10,344 |  |

[0001628280-25-020353:notes:154]
As discussed in Note 2, Restatement of Previously Issued Consolidated Financial Statements, the Company offers products for purchase or multi-year subscription leases. For equipment for which the revenue recognition start date was moved to a later date due to the timing of the transfer of control, the equipment cost was added back to finished goods inventory (for equipment sales) until the point in time that the Company transferred control of the equipment to the customer, corresponding to the revenue recognition start date. Amounts added back to finished goods inventory are included in Uninstalled inventory in the table above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-25-020353:notes:155]
[same as prior period, unchanged from 0001628280-24-036182:notes:69]

[0001628280-25-020353:notes:156]
|  | September 30,2024 |  | December 31,2023 |
|  |  |  | (Restated) |
| Computers and telecom equipment | $ | 1,837 |  |  | $ | 1,331 |  |
| Lab equipment | 5,483 |  |  | 1,171 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 607 |  |  | 566 |  |
| Leased equipment | 105,251 |  |  | 80,188 |  |
| Capitalized software | 14,008 |  |  | 8,629 |  |
| Sales demo equipment | 3,622 |  |  | 2,758 |  |
| Vehicles | 567 |  |  | — |  |
| Equipment held for lease1 | 16,835 |  |  | 32,910 |  |
| Construction in progress | 602 |  |  | 2,493 |  |
|  | 148,923 |  |  | 130,157 |  |
| Less: Accumulated depreciation and amortization | (28,081) |  |  | (16,996) |  |
|  | $ | 120,842 |  |  | $ | 113,161 |  |

[0001628280-25-020353:notes:157]
[same as prior period, unchanged from 0001628280-24-036182:notes:71]

[0001628280-25-020353:notes:158]
As of September 30, 2024 and December 31, 2023, the net book value of capitalized software was $11.4 million and $7.0 million, respectively. These amounts include $1.4 million and $0.7 million of capitalized stock compensation costs, respectively. Depreciation and amortization expense related to property and equipment was $4.6 million and $2.6 million (as restated) for the three months ended September 30, 2024 and 2023, respectively, which included amortization expense of capitalized software of $0.4 million and $0.3 million, respectively. Depreciation and amortization expense related to property and equipment was $11.9 million and $6.6 million (as restated) for the nine months ended September 30, 2024 and 2023, respectively, which included amortization expense of capitalized software of $0.9 million and $0.7 million for the nine months ended September 30, 2024 and 2023, respectively.

[0001628280-25-020353:notes:159]
[same as prior period, unchanged from 0001628280-24-036182:notes:74]

[0001628280-25-020353:notes:160]
|  | September 30,2024 |  | December 31,2023 |
|  |  |  | (Restated) |
| Leased equipment | $ | 105,251 |  |  | $ | 80,188 |  |
| Accumulated depreciation | (21,861) |  |  | (13,026) |  |
| Leased equipment, net | $ | 83,390 |  |  | $ | 67,162 |  |

[0001628280-25-020353:notes:161]
Depreciation expense related to leased units was $3.7 million and $2.1 million (as restated) during the three months ended September 30, 2024 and 2023, respectively, and $9.7 million and $5.2 million (as restated) during the nine months ended September 30, 2024 and 2023, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.

[0001628280-25-020353:notes:162]
The Company recorded $0.2 million loss from impairment of property and equipment during each of the three and nine months ended September 30, 2024 and recorded less than $0.1 million and $0.3 million of loss from impairment of property and equipment during the three and nine months ended September 30, 2023, respectively. This primarily related to 
the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in an impairment of the remaining economic value of such units.


## us-gaap:DebtDisclosureTextBlock

[0001628280-25-020353:notes:163]
Long-term Debt
In December 2022, the Company entered into a loan and security agreement (the “2022 SVB Credit Agreement”) with Silicon Valley Bank (“SVB”) in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. Subsequently, on March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. During the nine months ended September 30, 2023, the Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs. The Company had no long-term debt as of September 30, 2024 and December 31, 2023.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-25-020353:notes:164]
[same as prior period, unchanged from 0001628280-24-036182:notes:78]

[0001628280-25-020353:notes:165]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the nine months ended September 30, 2024 and 2023:

[0001628280-25-020353:notes:166]
|  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |
| Risk-free interest rate | 4.1% |  | 4.2% |
| Expected term (in years) | 6.1 |  | 6.1 |
| Expected volatility | 90.0% |  | 87.5% |
| Expected dividend yield | 0.0% |  | 0.0% |

[0001628280-25-020353:notes:167]
[same as prior period, unchanged from 0001628280-24-036182:notes:81]

[0001628280-25-020353:notes:168]
|  | Number ofShares |  | WeightedAverageExercise Price |
| Outstanding as of December 31, 2023 | 20,324,528 |  | $ | 1.04 |  |
| Granted | 2,725,625 |  | 3.63 |  |
| Exercised | (2,001,136) |  | 0.58 |  |
| Forfeited | (15,447) |  |  | 0.42 |  |
| Expired | (69,816) |  |  | 0.74 |  |
| Outstanding as of September 30, 2024 | 20,963,754 |  | $ | 1.42 |  |

[0001628280-25-020353:notes:169]
[same as prior period, unchanged from 0001628280-24-036182:notes:83]

[0001628280-25-020353:notes:170]
[same as prior period, unchanged from 0001628280-24-036182:notes:84]

[0001628280-25-020353:notes:171]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2023 | 13,046,679 |  |  | $ | 3.49 |  |
| Granted | 8,561,382 |  |  | 3.56 |  |
| Vested | (4,597,530) |  |  | 3.49 |  |
| Forfeited | (1,537,240) |  |  | 3.60 |  |
| Nonvested as of September 30, 2024 | 15,473,291 |  |  | $ | 3.52 |  |

[0001628280-25-020353:notes:172]
[same as prior period, unchanged from 0001628280-24-036182:notes:86]

[0001628280-25-020353:notes:173]
[same as prior period, unchanged from 0001628280-24-036182:notes:87]

[0001628280-25-020353:notes:174]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2023 | 380,000 |  |  | $ | 2.64 |  |
| Granted | — |  |  | — |  |
| Vested | (380,000) |  |  | 2.64 |  |
| Forfeited | — |  |  | — |  |
| Nonvested as of September 30, 2024 | — |  |  | $ | — |  |

[0001628280-25-020353:notes:175]
[same as prior period, unchanged from 0001628280-24-036182:notes:89]

[0001628280-25-020353:notes:176]
In January 2021, the Company granted equity classified warrants (the “Finback Common Stock Warrants”) to purchase 2,552,913 shares of the Company's Class A common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC (“Finback”), a consulting group affiliated with one of the Company's stockholders. The Finback Common Stock Warrants vest upon meeting certain sales criteria as defined in a business development agreement (the “Finback BDA”), which had a term of 3 years. The Finback BDA expired on January 1, 2023 but included a 1-year “tail period” expiring on January 1, 2024. During the tail period, the Finback Common Stock Warrants continued to vest related to any sale consummated by the Company for which it was determined Finback provided services prior to January 1, 2023 in furtherance of the sale. The Finback Common Stock Warrants expire in January 2031. The Finback Common Stock Warrants are accounted for under ASC 718 Compensation – Stock Compensation as the warrants vest upon certain performance conditions being met.

[0001628280-25-020353:notes:177]
As of September 30, 2024, 117,423 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $0.4 million, and there were no Finback Common Stock Warrants that were unvested, given the expiration of the 1-year tail period on January 1, 2024. The Company recognized compensation expense for the Finback Common Stock Warrants when the warrants vested based on meeting the specified sales criteria. During the three and nine months ended September 30, 2024, there was no stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants. During the three and nine months ended September 30, 2023, the

[0001628280-25-020353:notes:178]
Company recorded $0.8 million and $2.2 million of stock-based compensation expense, respectively, within sales and marketing expense related to the Finback Common Stock Warrants.

[0001628280-25-020353:notes:179]
[same as prior period, unchanged from 0001628280-24-036182:notes:93]

[0001628280-25-020353:notes:180]
[same as prior period, unchanged from 0001628280-24-036182:notes:94]

[0001628280-25-020353:notes:181]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Cost of revenue | $ | 244 |  | $ | 114 |  | $ | 555 |  | $ | 443 |
| Research and development | 1,243 |  | 1,148 |  | 3,367 |  | 3,223 |
| Sales and marketing | 2,516 |  | 2,293 |  | 8,199 |  | 6,809 |
| General and administrative | 3,504 |  | 2,481 |  | 9,243 |  | 7,296 |
| Total stock-based compensation expense | $ | 7,507 |  | $ | 6,036 |  | $ | 21,364 |  | $ | 17,771 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-020353:notes:182]
Income Taxes
There is no provision for income taxes for the three and nine months ended September 30, 2024 and 2023 because the Company has historically incurred net operating losses and maintains a full valuation allowance against its deferred tax assets.

[0001628280-25-020353:notes:183]
[same as prior period, unchanged from 0001628280-24-036182:notes:97]


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-020353:notes:184]
Net (Loss) Income per Share
In periods in which the Company reported net income, net income attributable to common stockholders is computed using the two-class method as the Founder Shares are classified as participating securities containing rights to receive dividends. In accordance with the two-class method, a portion of net income is allocated to participating securities and excluded from the calculation of income allocated to common stock.

[0001628280-25-020353:notes:185]
Basic net (loss) income per share is calculated by dividing net (loss) income attributable to common stockholders by the weighted average shares outstanding during the period. Diluted net (loss) income per share is calculated by adjusting weighted average shares outstanding for the dilutive effect of potential common shares, determined using the treasury stock

[0001628280-25-020353:notes:186]
method. Basic and diluted net (loss) income per share attributable to common stockholders are calculated as follows (in thousands, except share and per share amounts):

[0001628280-25-020353:notes:187]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Net (loss) income | $ | (30,443) |  | $ | 5,046 |  | $ | (38,297) |  | $ | (90,850) |
| Reallocation of net income attributable to participating securities | — |  | (63) |  | — |  | — |
| Net (loss) income attributable to common stockholders – basic and diluted | $ | (30,443) |  | $ | 4,983 |  | $ | (38,297) |  | $ | (90,850) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding – basic | 157,709,229 |  | 150,206,893 |  | 155,760,149 |  | 148,521,299 |
| Weighted average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Stock options | — |  | 16,528,407 |  | — |  | — |
| Restricted stock units | — |  | 6,674,985 |  | — |  | — |
| Performance stock units | — |  | 356,780 |  | — |  | — |
| Finback Common Stock Warrants | — |  | 209,310 |  | — |  | — |
| Total potentially dilutive securities | — |  | 23,769,482 |  | — |  | — |
| Weighted average common shares outstanding – diluted | 157,709,229 |  | 173,976,375 |  | 155,760,149 |  | 148,521,299 |
| Net (loss) income per share attributable to common stockholders - basic | $ | (0.19) |  | $ | 0.03 |  | $ | (0.25) |  | $ | (0.61) |
| Net (loss) income per share attributable to common stockholders - diluted | $ | (0.19) |  | $ | 0.03 |  | $ | (0.25) |  | $ | (0.61) |

[0001628280-25-020353:notes:188]
The following potentially dilutive outstanding securities were excluded from the computation of diluted net (loss) income per share attributable to common stockholders because their effect would have been anti-dilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the period:

[0001628280-25-020353:notes:189]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Options issued and outstanding | 20,963,754 |  |  | — |  |  | 20,963,754 |  | 21,063,044 |  |
| Public Warrants to purchase common stock | 14,324,893 |  |  | 14,324,893 |  |  | 14,324,893 |  |  | 14,324,893 |  |
| Warrants to purchase common stock (Finback) | 117,423 |  |  | 1,317,327 |  |  | 117,423 |  |  | 1,590,984 |  |
| Unvested restricted stock units | 15,473,291 |  |  | 397,771 |  |  | 15,473,291 |  |  | 12,097,108 |  |
| Unvested performance stock units | — |  |  | — |  |  | — |  |  | 386,000 |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |
| Contingently issuable common stock* | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |
|  | 67,776,861 |  |  | 32,937,491 |  |  | 67,776,861 |  |  | 66,359,529 |  |

[0001628280-25-020353:notes:190]
[same as prior period, unchanged from 0001628280-24-036182:notes:104]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-25-020353:notes:191]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola

[0001628280-25-020353:notes:192]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended September 30, 2024 and 2023, revenue from Motorola's distributor services was $2.2 million and $1.7 million, respectively. During the nine months ended September 30, 2024 and 2023, revenue from Motorola's distributor services was $6.1 million and $7.9 million, respectively, which was a result of the Company's transition to pure subscription sales and sales under the distributor licensing model during this period. As of September 30, 2024 and December 31, 2023, accounts receivable related to Motorola’s distributor services was $1.1 million and $1.6 million, respectively.

[0001628280-25-020353:notes:193]
Reseller Agreement with Stanley Black & Decker
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB (“Securitas”) in 2023. Securitas, directly or through its affiliates, resells the Company's products. Effective in the first quarter of 2024, while the reseller agreement is still in effect, Securitas is no longer considered a related party. During the three and nine months ended September 30, 2023, revenue from Securitas' reseller services was $0.4 million and $1.3 million, respectively. As of December 31, 2023, accounts receivable related to Securitas' reseller services was $0.6 million.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-25-020353:notes:194]
Commitments and Contingencies
Indemnification Agreements

[0001628280-25-020353:notes:195]
In the ordinary course of business, the Company provides indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. Based on historical experience and evaluation of the agreements, we do not believe that any payments related to our indemnities will have a material impact on our financial condition or results of operations.

[0001628280-25-020353:notes:196]
Legal Proceedings

[0001628280-25-020353:notes:197]
We are from time to time subject to various claims, lawsuits, government and regulatory examinations, inquiries, information requests and investigations, and other legal and administrative proceedings arising in the ordinary course of business. The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. Except for the regulatory matters discussed below, based upon information presently known to management, the Company has not accrued a loss for any other legal matters, as a loss is not probable and reasonably estimable. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

[0001628280-25-020353:notes:198]
General Litigation

[0001628280-25-020353:notes:199]
On March 25, 2024, a putative class action lawsuit was filed against the Company in the United States District Court for the District of Massachusetts (the “Class Action”). The Class Action is a consolidation of two lawsuits, the second of which was filed on November 1, 2024, filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees.

[0001628280-25-020353:notes:200]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the anticipated motion to dismiss in the Class Action. On March 28, 2025, we filed a motion to dismiss the claims.

[0001628280-25-020353:notes:201]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Delaware Derivative Action”). The Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. Although the Delaware Derivative Action is in the early stages, we anticipate filing a motion to dismiss the claims if the case moves forward.

[0001628280-25-020353:notes:202]
We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. While a loss from this litigation is reasonably possible, we cannot reasonably estimate a range of possible losses at this time, as the proceedings remain in the early stages, alleged damages have not been specified, there is uncertainty as to the outcome of our anticipated motion to dismiss in the Class Action which was filed on March 28, 2025, there is uncertainty as to the likelihood of the proposed class in the Class Action being certified or the ultimate size of any class if certified, there is uncertainty as to the final complaint in the Massachusetts Derivative Action, as the plaintiff will not identify an operative complaint or file a consolidated complaint until disposition of our anticipated motion to dismiss in the Class Action, and there are significant factual and legal issues to be resolved in both the securities and derivative actions. For these reasons, we have not recorded a loss contingency liability for the above litigation as of September 30, 2024.

[0001628280-25-020353:notes:203]
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.

[0001628280-25-020353:notes:204]
Regulatory and Governmental Matters

[0001628280-25-020353:notes:205]
As previously disclosed, on October 12, 2023, the Company announced that the U.S. Federal Trade Commission (the “FTC”) had requested information about certain aspects of its marketing practices. The Company reached a settlement with the FTC and on December 5, 2024, a Stipulated Order for Permanent Injunction and Other Relief (the “Order”) was entered in the United States District Court for the District of Massachusetts Eastern Division. The Order (i) required that the Company permit a limited cohort of school customers to cancel their contracts, (ii) required that the Company take certain compliance actions and meet record keeping obligations, and (iii) enjoined the Company from making misleading or unsubstantiated marketing claims. The Order did not include any monetary relief. The period during which eligible

[0001628280-25-020353:notes:206]
customers may cancel closed on March 30, 2025. Any inability to adequately comply with the terms of the Order could result in enforcement actions or penalties imposed by the FTC.

[0001628280-25-020353:notes:207]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, 5 customers representing 24 Evolv Express units elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the three and nine months ended September 30, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and nine months ended September 30, 2024, as revenue will continue to be recognized on these deals through the cancellation dates of each contract, all of which are in June 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of September 30, 2024 were impacted by the cancellations.

[0001628280-25-020353:notes:208]
As of June 30, 2024, the Company had accrued $1.1 million as an estimated liability related to the FTC matter, which was recorded in other accrued liabilities in the condensed consolidated balance sheets and the associated expense was recorded in general and administrative expense in the condensed consolidated statements of operations. As the settlement of these matters occurred subsequent to September 30, 2024, but prior to our filing of this Quarterly Report on Form 10-Q, the Company accounted for the transaction as a recognized subsequent event for the three months ended September 30, 2024. As the settlement included no monetary fines or penalties, the loss reserve was reversed during the three months ended September 30, 2024.

[0001628280-25-020353:notes:209]
As previously reported, the Company self-reported to the Division of Enforcement of the Securities and Exchange Commission ("SEC") the Investigation. The Company has since received requests for documents and information from the SEC relating to this matter. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("USAO SDNY") relating to these same issues, and has since received additional requests for documents and information relating to this matter. The Company is cooperating with these investigations.

[0001628280-25-020353:notes:210]
As previously disclosed, in February 2024, the Company received a subpoena from the Division of Enforcement of the SEC, requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation.

[0001628280-25-020353:notes:211]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of legal and regulatory matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the condensed consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.

[0001628280-25-020353:notes:212]
Any resolution or litigation with the SEC, DOJ, or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to SEC or DOJ matters. The Company's defense counsel costs in connection with the securities litigation and the related SEC and DOJ matters are being covered under its directors and officers insurance policies subject to a typical reservation of rights. The Company has met the retention limits under these policies with respect to these matters and currently expects these policies will provide coverage for certain costs related to these matters, including certain expenses that have previously been paid. However, the Company cannot provide any assurance that costs related to these matters will not exceed the

[0001628280-25-020353:notes:213]
limits of its insurance policies, that such claims are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.

[0001628280-25-020353:notes:214]
Contract manufacturers

[0001628280-25-020353:notes:215]
The Company generally contracts with its contract manufacturer, Columbia Tech, on a cancellable, purchase-order basis. The Company has a contract in the normal course of business with Columbia Tech to provide manufacturing services for the Company's equipment sold or leased to customers. While these contracts are cancellable by the Company upon prior notice, payments due upon cancellation consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. These payments are not determinable, but could result in a material purchase commitment if the Company were to cancel their open purchase orders.


## us-gaap:SubsequentEventsTextBlock

[0001628280-25-020353:notes:216]
Subsequent Events
Resolution of FTC Inquiry

[0001628280-25-020353:notes:217]
As discussed above in Note 16, Commitments and Contingencies, the Company reached a settlement with the FTC and on December 5, 2024, the Order was entered in the United States District Court for the District of Massachusetts Eastern Division. The resolution did not involve any financial penalties or monetary relief. As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, a total of 5 customers representing 24 Evolv Express units elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the three and nine months ended September 30, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and nine months ended September 30, 2024, as revenue will continue to be recognized on these deals through the cancellation dates of each contract, all of which are in June 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of September 30, 2024 were impacted by the cancellations.

[0001628280-25-020353:notes:218]
As of June 30, 2024, the Company had accrued $1.1 million as an estimated liability related to the FTC matter, which was recorded in other accrued liabilities in the condensed consolidated balance sheets and the associated expense was recorded in general and administrative expense in the condensed consolidated statements of operations. As the settlement of these matters occurred subsequent to the September 30, 2024, but prior to our filing of this Quarterly Report on Form 10-Q, the Company accounted for the transaction as a recognized subsequent event for the three months ended September 30, 2024. As the settlement included no monetary fines or penalties, the loss reserve was reversed during the three months ended September 30, 2024.

[0001628280-25-020353:notes:219]
Reduction in force

[0001628280-25-020353:notes:220]
In January 2025, the Company implemented a Board-approved reduction in force affecting 40 members of its workforce. This action is part of the Company’s initiative to increase its annualized run rate cash savings as the Company seeks further flexibility to pursue its investment strategy with certain growth opportunities.

[0001628280-25-020353:notes:221]
The Company incurred pre-tax charges of $2.7 million for the reduction in force, substantially all of which was incurred in the first quarter of 2025. These charges consisted of one-time termination charges arising from severance obligations of $2.0 million, extended eligibility for the vesting of certain equity awards originally scheduled to vest on or before March 1, 2025, resulting in incremental non-cash expense of $0.5 million and other customary employee benefit payments in connection with a reduction in force of $0.2 million. Substantially all severance and related payments to 
affected individuals was completed by March 2025, with the exception of three employees who are subject to a continuous payment through July 2025
