# EVLV MD&A — 0001628280-25-020353


## mdna

[0001628280-25-020353:mdna:1]
[same as prior period, unchanged from 0001628280-24-036182:mdna:1]

[0001628280-25-020353:mdna:2]
[same as prior period, unchanged from 0001628280-24-036182:mdna:2]

[0001628280-25-020353:mdna:3]
Restatement of Prior Period Financial Statements

[0001628280-25-020353:mdna:4]
We have restated our previously issued condensed consolidated financial statements contained in this Quarterly Report on Form 10-Q. Refer to the “Explanatory Note” preceding Item 1, Financial Statements, for background on the restatement, the periods impacted, control considerations, and other information. In addition, we have restated certain previously reported financial information for the fiscal year ended December 31, 2023 and for the quarterly periods and year-to-date periods ended September 30, 2023 in this Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations, including but not limited to information within the Results of Operations section. See Notes 2 in the notes to the condensed consolidated financial statements in this Quarterly Report on Form 10-Q, for additional information related to the restatement, including descriptions of the misstatements and the impacts on our consolidated financial statements.

[0001628280-25-020353:mdna:5]
[same as prior period, unchanged from 0001628280-24-036182:mdna:3]

[0001628280-25-020353:mdna:6]
Evolv is a leading security technology company pioneering Artificial Intelligence (“AI”)-powered screening designed to help create safer experiences, with key market categories that include education, healthcare, sports, live entertainment, and industrial workplaces. Our mission is to make the world a safer and more enjoyable place to live, work, learn, and play. Our goal is to help facility operators address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks while maintaining a positive visitor experience.

[0001628280-25-020353:mdna:7]
Our solutions combine proprietary software and hardware, delivered as a long-term Security-as-a-Service (“SaaS”) subscription model and are designed to enhance security and improve the visitor experience. Evolv provides a cloud-connected, AI-driven approach to security that goes beyond just hardware, supporting the end-to-end screening experience. Our focus is weapons detection, and we offer two core solutions: Evolv Express® and Evolv eXpedite™, designed to efficiently screen high volumes of people and bags for concealed threats.

[0001628280-25-020353:mdna:8]
Our flagship product, Evolv Express, uses advanced sensors, AI-powered software, and cloud services to not only consistently detect firearms, improvised explosives, and certain types of knives and distinguish them from many harmless items such as cell phones and keys, but also visualize the location of the potential threat helping to enable security personnel to conduct targeted, minimally intrusive secondary screenings. Evolv eXpedite, our high-speed autonomous X-ray bag scanning solution, works with Evolv Express to provide a layered approach to security for concealed weapons detection in high clutter environments. Using eXpedite with Express aims to allow the checkpoint to operate at heightened sensitivity while potentially reducing the burden on security staff and optimizing the visitor experience.

[0001628280-25-020353:mdna:9]
Our innovative technology is designed to enhance security and provide an efficient, positive visitor and customer security experience. In addition to screening capabilities, our solution includes Evolv Insights®, a powerful software

[0001628280-25-020353:mdna:10]
[same as prior period, unchanged from 0001628280-24-036182:mdna:9]

[0001628280-25-020353:mdna:11]
analytics dashboard that allows customers to comprehensively review, analyze, and gather insights from the Evolv Express screening systems at their various venue or facility locations.  Available data includes visitor arrival patterns, throughput volumes, system detection performance, alarm statistics, weapons detected and detection settings.  Our customers can leverage this data to inform their security operations, while providing end-users with an approachable security experience. Our products, which are offered to our customers primarily under a multi-year subscription model, provide predictable revenue streams for us in addition to value for our customers.

[0001628280-25-020353:mdna:12]
We are focused on delivering value in the spaces in and around the physical threshold of venues and facilities. We believe that digitally transforming the visitor experience at the entry point to venues and facilities will be a critically important innovation in physical security. We believe that our solutions will not only help make venues and facilities safer and more enjoyable, but also more efficient, and more informed about their visitors’ needs.

[0001628280-25-020353:mdna:13]
Nasdaq Delinquency Notice

[0001628280-25-020353:mdna:14]
On November 21, 2024, the Company received written notice (the “Notice”) from the Nasdaq indicating that the Company was not in compliance with Nasdaq Listing Rule 5250(c)(1) (the "Nasdaq Listing Rule") as a result of the delayed filing of this Quarterly Report on Form 10-Q. The Nasdaq Listing Rule requires listed companies to timely file all required periodic financial reports with the SEC. On April 28, 2025, the Company filed this Quarterly Report on Form 10-Q with the SEC, therefore, curing the deficiency outlined in the Notice.

[0001628280-25-020353:mdna:15]
[same as prior period, unchanged from 0001628280-24-036182:mdna:10]

[0001628280-25-020353:mdna:16]
We believe that our performance and future success depend on many factors that present significant opportunities for us but also pose risks and challenges, including those discussed below and in the “Risk Factors” section of this Quarterly Report on Form 10-Q.

[0001628280-25-020353:mdna:17]
[same as prior period, unchanged from 0001628280-24-036182:mdna:12]

[0001628280-25-020353:mdna:18]
We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of rising inflation and interest rates on business spending; supply chain issues and the impacts on our manufacturing capabilities; public health emergencies; geopolitical conflicts and war, including the conflicts in Europe and the Middle East; and recessionary trends. See the risk factor titled “Our operating results may fluctuate for a variety of reasons, including our failure to close large volume opportunity customer sales” in the "Risk Factors" section in this Quarterly Report on Form 10-Q. While these factors continue to evolve, we plan to remain flexible and optimize our business as appropriate and allocate resources, as necessary.

[0001628280-25-020353:mdna:19]
[same as prior period, unchanged from 0001628280-24-036182:mdna:14]

[0001628280-25-020353:mdna:20]
[same as prior period, unchanged from 0001628280-24-036182:mdna:15]

[0001628280-25-020353:mdna:21]
[same as prior period, unchanged from 0001628280-24-036182:mdna:16]

[0001628280-25-020353:mdna:22]
We sell our solutions under two primary sales models. We offer a “pure subscription” model, where the customer leases hardware from us and we provide a multi-year security-as-a-service subscription. For end-user customers that prefer to purchase our hardware outright, we offer our “distributor licensing” model based on the Distribution and License Agreement we entered into with Columbia Tech in March of 2023. Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, currently serves as our primary contract manufacturer. Under this arrangement, we have granted a license of our intellectual property to Columbia Tech, which contracts directly with certain of our resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment. Columbia Tech pays us a hardware license fee for each system it manufactures and sells under this agreement. In these instances, we still contract directly with the reseller

[0001628280-25-020353:mdna:23]
to provide a multi-year security-as-a-service subscription to the end-users. We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our revenue, gross profit, gross margin, and overall profitability in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments.

[0001628280-25-020353:mdna:24]
[same as prior period, unchanged from 0001628280-24-036182:mdna:19]

[0001628280-25-020353:mdna:25]
Development and Commercialization of our Products

[0001628280-25-020353:mdna:26]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $74.8 million and $59.0 million for the nine months ended September 30, 2024 and 2023, respectively. We generated a net loss of $38.3 million and $90.9 million for the nine months ended September 30, 2024 and 2023, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-25-020353:mdna:27]
[same as prior period, unchanged from 0001628280-24-036182:mdna:162]

[0001628280-25-020353:mdna:28]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations, and if necessary, debt financings. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources” for more information. Additionally, as discussed in Note 16 (Commitments and Contingencies) to our consolidated financial statements for the nine months ended September 30, 2024, we are involved in certain legal proceedings, including government investigations. Given the uncertainty of such matters, no assurance can be given regarding the final outcome of such matters. However, the ultimate amount or range of potential loss, which might result to the Company may differ materially from our current estimates.

[0001628280-25-020353:mdna:29]
[same as prior period, unchanged from 0001628280-24-036182:mdna:23]

[0001628280-25-020353:mdna:30]
[same as prior period, unchanged from 0001628280-24-036182:mdna:24]

[0001628280-25-020353:mdna:31]
[same as prior period, unchanged from 0001628280-24-036182:mdna:25]

[0001628280-25-020353:mdna:32]
[same as prior period, unchanged from 0001628280-24-036182:mdna:26]

[0001628280-25-020353:mdna:33]
We derive a portion of our revenue from the sale of our Evolv Express equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We anticipate future growth in product revenue to be driven by underlying demand for our solutions as well as by the distribution mix across our various sales and fulfillment models.

[0001628280-25-020353:mdna:34]
[same as prior period, unchanged from 0001628280-24-036182:mdna:39]

[0001628280-25-020353:mdna:35]
[same as prior period, unchanged from 0001628280-24-036182:mdna:28]

[0001628280-25-020353:mdna:36]
[same as prior period, unchanged from 0001628280-24-036182:mdna:29]

[0001628280-25-020353:mdna:37]
Lease arrangements generally include both lease and non-lease components. The non-lease components relate to (1) distinct services, including professional services, SaaS, and maintenance, and (2) any add-on accessories. Professional services are included in license fees and other revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive (loss) income.

[0001628280-25-020353:mdna:38]
[same as prior period, unchanged from 0001628280-24-036182:mdna:31]

[0001628280-25-020353:mdna:39]
[same as prior period, unchanged from 0001628280-24-036182:mdna:32]

[0001628280-25-020353:mdna:40]
[same as prior period, unchanged from 0001628280-24-036182:mdna:33]

[0001628280-25-020353:mdna:41]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from Columbia Tech to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration. Revenue for professional services and other one-time revenue, which had previously been included in service revenue, has been reclassified for prior periods to License fee and other revenue on the consolidated statements of operations and comprehensive (loss) income. We anticipate changes in license fee and other revenue to be driven by underlying demand for our solutions as well as any changes in demand for our distributor licensing model.

[0001628280-25-020353:mdna:42]
[same as prior period, unchanged from 0001628280-24-036182:mdna:35]

[0001628280-25-020353:mdna:43]
[same as prior period, unchanged from 0001628280-24-036182:mdna:36]

[0001628280-25-020353:mdna:44]
[same as prior period, unchanged from 0001628280-24-036182:mdna:37]

[0001628280-25-020353:mdna:45]
[same as prior period, unchanged from 0001628280-24-036182:mdna:38]

[0001628280-25-020353:mdna:46]
[same as prior period, unchanged from 0001628280-24-036182:mdna:40]

[0001628280-25-020353:mdna:47]
[same as prior period, unchanged from 0001628280-24-036182:mdna:41]

[0001628280-25-020353:mdna:48]
[same as prior period, unchanged from 0001628280-24-036182:mdna:42]

[0001628280-25-020353:mdna:49]
[same as prior period, unchanged from 0001628280-24-036182:mdna:43]

[0001628280-25-020353:mdna:50]
[same as prior period, unchanged from 0001628280-24-036182:mdna:44]

[0001628280-25-020353:mdna:51]
[same as prior period, unchanged from 0001628280-24-036182:mdna:45]

[0001628280-25-020353:mdna:52]
4

[0001628280-25-020353:mdna:53]
[same as prior period, unchanged from 0001628280-24-036182:mdna:46]

[0001628280-25-020353:mdna:54]
Our gross profit is calculated based on the difference between our revenues and cost of revenues. Gross margin is the percentage obtained by dividing gross profit by our revenue.

[0001628280-25-020353:mdna:55]
We expect our gross margins to fluctuate over time based on the following factors:

[0001628280-25-020353:mdna:56]
[same as prior period, unchanged from 0001628280-24-036182:mdna:48]

[0001628280-25-020353:mdna:57]
[same as prior period, unchanged from 0001628280-24-036182:mdna:49]

[0001628280-25-020353:mdna:58]
[same as prior period, unchanged from 0001628280-24-036182:mdna:50]

[0001628280-25-020353:mdna:59]
[same as prior period, unchanged from 0001628280-24-036182:mdna:51]

[0001628280-25-020353:mdna:60]
[same as prior period, unchanged from 0001628280-24-036182:mdna:52]

[0001628280-25-020353:mdna:61]
[same as prior period, unchanged from 0001628280-24-036182:mdna:53]

[0001628280-25-020353:mdna:62]
We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our gross profit and gross margin in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments.

[0001628280-25-020353:mdna:63]
[same as prior period, unchanged from 0001628280-24-036182:mdna:55]

[0001628280-25-020353:mdna:64]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, stock-based compensation, prototypes, design expenses, and consulting and contractor costs. We expect our research and development costs will remain relatively consistent for the year ending December 31, 2025 compared to the year ended December 31, 2024 as we look to leverage previous investments made in people and processes.

[0001628280-25-020353:mdna:65]
[same as prior period, unchanged from 0001628280-24-036182:mdna:57]

[0001628280-25-020353:mdna:66]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will decrease for the year ending December 31, 2025 compared to the year ended December 31, 2024 as a result of certain cost cutting measures we have taken, including the reduction in force implemented in January 2025.

[0001628280-25-020353:mdna:67]
[same as prior period, unchanged from 0001628280-24-036182:mdna:59]

[0001628280-25-020353:mdna:68]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and insurance. We expect our general and administrative expenses will remain relatively consistent for the year ending December 31, 2025 compared to the year ended December 31, 2024 as we look to leverage previous investments made in people and processes. Our general and administrative expenses may be impacted by regulatory compliance costs related to the ongoing SEC matters and other legal matters.

[0001628280-25-020353:mdna:69]
[same as prior period, unchanged from 0001628280-24-036182:mdna:61]

[0001628280-25-020353:mdna:70]
[same as prior period, unchanged from 0001628280-24-036182:mdna:62]

[0001628280-25-020353:mdna:71]
[same as prior period, unchanged from 0001628280-24-036182:mdna:75]

[0001628280-25-020353:mdna:72]
[same as prior period, unchanged from 0001628280-24-036182:mdna:63]

[0001628280-25-020353:mdna:73]
[same as prior period, unchanged from 0001628280-24-036182:mdna:64]

[0001628280-25-020353:mdna:74]
[same as prior period, unchanged from 0001628280-24-036182:mdna:65]

[0001628280-25-020353:mdna:75]
[same as prior period, unchanged from 0001628280-24-036182:mdna:66]

[0001628280-25-020353:mdna:76]
[same as prior period, unchanged from 0001628280-24-036182:mdna:67]

[0001628280-25-020353:mdna:77]
[same as prior period, unchanged from 0001628280-24-036182:mdna:68]

[0001628280-25-020353:mdna:78]
[same as prior period, unchanged from 0001628280-24-036182:mdna:69]

[0001628280-25-020353:mdna:79]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders are entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive (loss) income.

[0001628280-25-020353:mdna:80]
[same as prior period, unchanged from 0001628280-24-036182:mdna:71]

[0001628280-25-020353:mdna:81]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock, referred to as Founder Shares. Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 1,897,500 Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones, and 517,500 Founder Shares were contributed to Give Evolv LLC. The 1,897,500 outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive (loss) income.

[0001628280-25-020353:mdna:82]
[same as prior period, unchanged from 0001628280-24-036182:mdna:73]

[0001628280-25-020353:mdna:83]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are currently exercisable and expire in July 2026. We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger as a component of other income (expense), net in the consolidated statements of operations and comprehensive (loss) income with the offset to additional paid-in capital.

[0001628280-25-020353:mdna:84]
[same as prior period, unchanged from 0001628280-24-036182:mdna:77]

[0001628280-25-020353:mdna:85]
[same as prior period, unchanged from 0001628280-24-036182:mdna:78]

[0001628280-25-020353:mdna:86]
[same as prior period, unchanged from 0001628280-24-036182:mdna:79]

[0001628280-25-020353:mdna:87]
During the year ended December 31, 2023, the Company began classifying revenue from professional services, which includes installation, training, and event support, as well as one-time revenue within license fee and other revenue on the consolidated statements of operations and comprehensive (loss) income, whereas the revenue for these services has previously been included in service revenue. Correspondingly, the Company began classifying costs associated with

[0001628280-25-020353:mdna:88]
professional services within cost of license fee and other revenue, whereas these costs were previously included in cost of service revenue. These reclassifications were made to align the presentation of professional services with the Company's internal reporting and analysis.

[0001628280-25-020353:mdna:89]
[same as prior period, unchanged from 0001628280-24-036182:mdna:82]

[0001628280-25-020353:mdna:90]
Comparison of the Three Months Ended September 30, 2024 and 2023

[0001628280-25-020353:mdna:91]
The following table summarizes our results of operations for the three months ended September 30, 2024 and 2023 (in thousands):

[0001628280-25-020353:mdna:92]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 1,344 |  |  | $ | 3,456 |  |  | $ | (2,112) |  |  | (61) | % |
| Subscription revenue | 17,909 |  |  | 9,858 |  |  | 8,051 |  |  | 82 |  |
| Service revenue | 6,085 |  |  | 4,345 |  |  | 1,740 |  |  | 40 |  |
| License fee and other revenue | 2,022 |  |  | 2,302 |  |  | (280) |  |  | (12) |  |
| Total revenue | 27,360 |  |  | 19,961 |  |  | 7,399 |  |  | 37 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 2,616 |  |  | 3,496 |  |  | (880) |  |  | (25) |  |
| Cost of subscription revenue | 7,348 |  |  | 4,157 |  |  | 3,191 |  |  | 77 |  |
| Cost of service revenue | 1,404 |  |  | 1,219 |  |  | 185 |  |  | 15 |  |
| Cost of license fee and other revenue | 183 |  |  | 198 |  |  | (15) |  |  | (8) |  |
| Total cost of revenue | 11,551 |  |  | 9,070 |  |  | 2,481 |  |  | 27 |  |
| Gross profit | 15,809 |  |  | 10,891 |  |  | 4,918 |  |  | 45 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,810 |  |  | 6,386 |  |  | (576) |  |  | (9) |  |
| Sales and marketing | 14,966 |  |  | 14,408 |  |  | 558 |  |  | 4 |  |
| General and administrative | 13,976 |  |  | 11,261 |  |  | 2,715 |  |  | 24 |  |
| Loss from impairment of property and equipment | 209 |  |  | 28 |  |  | 181 |  |  | 646 |  |
| Total operating expenses | 34,961 |  |  | 32,083 |  |  | 2,878 |  |  | 9 |  |
| Loss from operations | (19,152) |  |  | (21,192) |  |  | 2,040 |  |  | 10 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest income | 628 |  |  | 1,791 |  |  | (1,163) |  |  | (65) |  |
| Other income (expense), net | 34 |  |  | (64) |  |  | 98 |  |  | 153 |  |
| Change in fair value of contingent earn-out liability | (8,321) |  |  | 14,078 |  |  | (22,399) |  |  | (159) |  |
| Change in fair value of contingently issuable common stock liability | (2,056) |  |  | 2,277 |  |  | (4,333) |  |  | (190) |  |
| Change in fair value of public warrant liability | (1,576) |  |  | 8,156 |  |  | (9,732) |  |  | (119) |  |
| Total other income (expense), net | (11,291) |  |  | 26,238 |  |  | (37,529) |  |  | (143) |  |
| Net (loss) income | $ | (30,443) |  |  | $ | 5,046 |  |  | $ | (35,489) |  |  | (703) | % |

[0001628280-25-020353:mdna:93]
7

[0001628280-25-020353:mdna:94]
[same as prior period, unchanged from 0001628280-24-036182:mdna:86]

[0001628280-25-020353:mdna:95]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 52 new customers during the three months ended September 30, 2024, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020353:mdna:96]
[same as prior period, unchanged from 0001628280-24-036182:mdna:88]

[0001628280-25-020353:mdna:97]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Product revenue | $ | 1,344 |  |  | $ | 3,456 |  |  | $ | (2,112) |  |  | (61) | % |
| Cost of product revenue | $ | 2,616 |  |  | $ | 3,496 |  |  | $ | (880) |  |  | (25) | % |
| Gross profit - Product revenue | $ | (1,272) |  |  | $ | (40) |  |  | $ | (1,232) |  |  | (3080) | % |
| Gross profit margin - Product revenue | (95) | % |  | (1) | % |  | N/A |  | (93) | % |

[0001628280-25-020353:mdna:98]
The decreases in product revenue and cost of product revenue are primarily due to a transition to pure subscription sales and sales under our distributor licensing model during the preceding twelve months. The decrease in product gross profit margin for the three months ended September 30, 2024 compared to the prior year period is primarily due to a large decrease in product revenue explained above as well as decreases in cost of revenue and third party costs of revenue.

[0001628280-25-020353:mdna:99]
[same as prior period, unchanged from 0001628280-24-036182:mdna:91]

[0001628280-25-020353:mdna:100]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Subscription revenue | $ | 17,909 |  |  | $ | 9,858 |  |  | $ | 8,051 |  |  | 82 | % |
| Cost of subscription revenue | $ | 7,348 |  |  | $ | 4,157 |  |  | $ | 3,191 |  |  | 77 | % |
| Gross profit - Subscription revenue | $ | 10,561 |  |  | $ | 5,701 |  |  | $ | 4,860 |  |  | 85 | % |
| Gross profit margin - Subscription revenue | 59 | % |  | 58 | % |  | N/A |  | 1 | % |

[0001628280-25-020353:mdna:101]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to continued growth in our customer base as of September 30, 2024 compared to the prior year, which was due to a

[0001628280-25-020353:mdna:102]
transition to our pure subscription model and a higher number of active Evolv Express units deployed under our pure subscription model.

[0001628280-25-020353:mdna:103]
[same as prior period, unchanged from 0001628280-24-036182:mdna:94]

[0001628280-25-020353:mdna:104]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Service revenue | $ | 6,085 |  |  | $ | 4,345 |  |  | $ | 1,740 |  |  | 40 | % |
| Cost of service revenue | $ | 1,404 |  |  | $ | 1,219 |  |  | $ | 185 |  |  | 15 | % |
| Gross profit - Service revenue | $ | 4,681 |  |  | $ | 3,126 |  |  | $ | 1,555 |  |  | 50 | % |
| Gross profit margin - Service revenue | 77 | % |  | 72 | % |  | N/A |  | 5 | % |

[0001628280-25-020353:mdna:105]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech under our distributor licensing model, for the three months ended September 30, 2024 compared to the prior year period.

[0001628280-25-020353:mdna:106]
[same as prior period, unchanged from 0001628280-24-036182:mdna:98]

[0001628280-25-020353:mdna:107]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| License fee and other revenue | $ | 2,022 |  |  | $ | 2,302 |  |  | $ | (280) |  |  | (12) | % |
| Cost of license fee and other revenue | $ | 183 |  |  | $ | 198 |  |  | $ | (15) |  |  | (8) | % |
| Gross profit - License fee and other revenue | $ | 1,839 |  |  | $ | 2,104 |  |  | $ | (265) |  |  | (13) | % |
| Gross profit margin - License fee and other revenue | 91 | % |  | 91 | % |  | N/A |  | — | % |

[0001628280-25-020353:mdna:108]
The decrease in license fee and other revenue and gross profit was primarily driven by $1.6 million of license fees earned during the three months ended September 30, 2024 compared to $2.0 million earned during the prior year period under the Distribution and License Agreement.

[0001628280-25-020353:mdna:109]
[same as prior period, unchanged from 0001628280-24-036182:mdna:101]

[0001628280-25-020353:mdna:110]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 4,075 |  |  | $ | 4,527 |  |  | $ | (452) |  |  | (10) | % |
| Materials and prototypes | 614 |  |  | 364 |  |  | 250 |  |  | 69 | % |
| Professional fees | 713 |  |  | 1,100 |  |  | (387) |  |  | (35) | % |
| Other | 408 |  |  | 395 |  |  | 13 |  |  | 3 | % |
|  | $ | 5,810 |  |  | $ | 6,386 |  |  | $ | (576) |  |  | (9) | % |

[0001628280-25-020353:mdna:111]
The decrease in personnel related expenses is due to a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $0.5 million. The increase in materials and prototypes expense of $0.3 million is due to increased design and engineering costs related to the development of the next generation of our Evolv Express system and new product offerings. The decrease in professional fees primarily relates to higher amount of costs capitalized related to internal-use software and software embedded in products to be sold or leased for software consultants of $0.3 million.

[0001628280-25-020353:mdna:112]
[same as prior period, unchanged from 0001628280-24-036182:mdna:107]

[0001628280-25-020353:mdna:113]
[same as prior period, unchanged from 0001628280-24-036182:mdna:104]

[0001628280-25-020353:mdna:114]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 10,346 |  |  | $ | 10,049 |  |  | $ | 297 |  |  | 3 | % |
| Advertising and direct marketing | 1,316 |  |  | 980 |  |  | 336 |  |  | 34 | % |
| Travel and entertainment | 1,305 |  |  | 1,506 |  |  | (201) |  |  | (13) | % |
| Professional fees | 915 |  |  | 716 |  |  | 199 |  |  | 28 | % |
| Other | 1,084 |  |  | 1,157 |  |  | (73) |  |  | (6) | % |
|  | $ | 14,966 |  |  | $ | 14,408 |  |  | $ | 558 |  |  | 4 | % |

[0001628280-25-020353:mdna:115]
The increase in personnel related expenses is due to an increase of $0.3 million in payroll costs and stock-based compensation resulting primarily from new hires in our sales and marketing functions to support increased sales volume during the past twelve months. The increase in advertising and direct marketing expense is primarily due to an increase in expenses related to trade shows and events of $0.2 million. The decrease in travel and entertainment expense is due to a decrease in travel and entertainment costs for in-person sales personnel meetings of $0.2 million. Professional fees increased by $0.2 million due to an increase in marketing consulting costs.

[0001628280-25-020353:mdna:116]
[same as prior period, unchanged from 0001628280-24-036182:mdna:108]

[0001628280-25-020353:mdna:117]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 6,789 |  |  | $ | 6,083 |  |  | $ | 706 |  |  | 12 | % |
| Professional fees | 1,441 |  |  | 1,764 |  |  | (323) |  |  | (18) | % |
| Insurance costs | 830 |  |  | 708 |  |  | 122 |  |  | 17 | % |
| Other | 4,916 |  |  | 2,706 |  |  | 2,210 |  |  | 82 | % |
|  | $ | 13,976 |  |  | $ | 11,261 |  |  | $ | 2,715 |  |  | 24 | % |

[0001628280-25-020353:mdna:118]
The increase in personnel related expenses is due to an increase of $0.8 million in payroll costs and stock-based compensation resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $3.5 million for the three months ended September 30, 2024 compared to $2.5 million for the three months ended September 30, 2023. The decrease in professional fees of $0.3 million was primarily related to a decrease in outsourced accounting consultancy and audit fees. The increase in insurance costs of $0.1 million was primarily related to an increase in director and officer insurance premiums. Other expense increased primarily due to a $1.5 million increase in certain one-time expenses incurred related to our ongoing legal matters which included a $1.1 million reversal of legal accruals related to the FTC matters, as well as increases in rent of $0.2 million for additional leased space and IT and software subscription costs of $0.5 million.

[0001628280-25-020353:mdna:119]
[same as prior period, unchanged from 0001628280-24-036182:mdna:111]

[0001628280-25-020353:mdna:120]
$0.2 million loss from impairment of property and equipment was recognized for the three months ended September 30, 2024, compared to less than $0.1 million for the three months ended September 30, 2023, primarily related to the removal of Evolv Edge units and Evolv Express units from service, resulting in impairment of the remaining economic value of such units.

[0001628280-25-020353:mdna:121]
[same as prior period, unchanged from 0001628280-24-036182:mdna:113]

[0001628280-25-020353:mdna:122]
Interest income of $0.6 million for the three months ended September 30, 2024 and $1.8 million for the three months ended September 30, 2023 related primarily to interest earned on money market funds and the accretion of discounts on treasury bills.

[0001628280-25-020353:mdna:123]
10

[0001628280-25-020353:mdna:124]
[same as prior period, unchanged from 0001628280-24-036182:mdna:115]

[0001628280-25-020353:mdna:125]
Change in the fair value of the contingent earn-out liability resulted in a $8.3 million loss and $14.1 million gain for the three months ended September 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020353:mdna:126]
[same as prior period, unchanged from 0001628280-24-036182:mdna:117]

[0001628280-25-020353:mdna:127]
Change in the fair value of the contingently issuable common stock liability resulted in a $2.1 million loss and $2.3 million gain for the three months ended September 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020353:mdna:128]
[same as prior period, unchanged from 0001628280-24-036182:mdna:119]

[0001628280-25-020353:mdna:129]
Change in the fair value of the public warrant liability resulted in a $1.6 million loss and a $8.2 million gain for the three months ended September 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020353:mdna:130]
[same as prior period, unchanged from 0001628280-24-036182:mdna:124]

[0001628280-25-020353:mdna:131]
Comparison of the Nine Months Ended September 30, 2024 and 2023

[0001628280-25-020353:mdna:132]
The following table summarizes our results of operations for the nine months ended September 30, 2024 and 2023 (in thousands):

[0001628280-25-020353:mdna:133]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 4,789 |  |  | $ | 20,920 |  |  | $ | (16,131) |  |  | (77) | % |
| Subscription revenue | 47,783 |  |  | 23,733 |  |  | 24,050 |  |  | 101 |  |
| Service revenue | 16,903 |  |  | 10,750 |  |  | 6,153 |  |  | 57 |  |
| License fee and other revenue | 5,290 |  |  | 3,582 |  |  | 1,708 |  |  | 48 |  |
| Total revenue | 74,765 |  |  | 58,985 |  |  | 15,780 |  |  | 27 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 8,569 |  |  | 23,275 |  |  | (14,706) |  |  | (63) |  |
| Cost of subscription revenue | 19,242 |  |  | 9,776 |  |  | 9,466 |  |  | 97 |  |
| Cost of service revenue | 3,923 |  |  | 2,816 |  |  | 1,107 |  |  | 39 |  |
| Cost of license fee and other revenue | 484 |  |  | 772 |  |  | (288) |  |  | (37) |  |
| Total cost of revenue | 32,218 |  |  | 36,639 |  |  | (4,421) |  |  | (12) |  |
| Gross profit | 42,547 |  |  | 22,346 |  |  | 20,201 |  |  | 90 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 18,056 |  |  | 18,170 |  |  | (114) |  |  | (1) |  |
| Sales and marketing | 47,836 |  |  | 40,642 |  |  | 7,194 |  |  | 18 |  |
| General and administrative | 39,875 |  |  | 31,054 |  |  | 8,821 |  |  | 28 |  |
| Loss from impairment of property and equipment | 209 |  |  | 322 |  |  | (113) |  |  | (35) |  |
| Total operating expenses | 105,976 |  |  | 90,188 |  |  | 15,788 |  |  | 18 |  |
| Loss from operations | (63,429) |  |  | (67,842) |  |  | 4,413 |  |  | 7 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (654) |  |  | 654 |  |  | 100 |  |
| Interest income | 2,394 |  |  | 4,597 |  |  | (2,203) |  |  | (48) |  |
| Other expense, net | (33) |  |  | (67) |  |  | 34 |  |  | 51 |  |
| Loss on extinguishment of debt | — |  |  | (626) |  |  | 626 |  |  | * |
| Change in fair value of contingent earn-out liability | 15,092 |  |  | (17,353) |  |  | 32,445 |  |  | 187 |  |
| Change in fair value of contingently issuable common stock liability | 2,218 |  |  | (3,560) |  |  | 5,778 |  |  | 162 |  |
| Change in fair value of public warrant liability | 5,461 |  |  | (5,345) |  |  | 10,806 |  |  | 202 |  |
| Total other income (expense), net | 25,132 |  |  | (23,008) |  |  | 48,140 |  |  | 209 |  |
| Net loss | $ | (38,297) |  |  | $ | (90,850) |  |  | $ | 52,553 |  |  | 58 | % |

[0001628280-25-020353:mdna:134]
[same as prior period, unchanged from 0001628280-24-036182:mdna:133]

[0001628280-25-020353:mdna:135]
[same as prior period, unchanged from 0001628280-24-036182:mdna:125]

[0001628280-25-020353:mdna:136]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 189 new customers during the nine months ended September 30, 2024, (iii) the expansion of our existing customers’ initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020353:mdna:137]
[same as prior period, unchanged from 0001628280-24-036182:mdna:127]

[0001628280-25-020353:mdna:138]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Product revenue | $ | 4,789 |  |  | $ | 20,920 |  |  | $ | (16,131) |  |  | (77) | % |
| Cost of product revenue | $ | 8,569 |  |  | $ | 23,275 |  |  | $ | (14,706) |  |  | (63) | % |
| Gross profit - Product revenue | $ | (3,780) |  |  | $ | (2,355) |  |  | $ | (1,425) |  |  | (61) | % |
| Gross profit margin - Product revenue | (79) | % |  | (11) | % |  | N/A |  | (68) | % |

[0001628280-25-020353:mdna:139]
The decreases in product revenue and cost of product revenue are primarily due to a transition to pure subscription sales and sales under our distributor licensing model during the preceding twelve months. The decrease in product gross profit margin is further driven by $2.5 million of one-time expense related to an increase to our inventory reserve, $1.1 million of expense associated with adverse non-cancellable inventory purchase commitments, and $0.3 million increase in manufacturing expense, each of which relate primarily to the ongoing transition of our manufacturing operations to the next generation of Evolv Express systems and the determination that certain components within our legacy systems will not be used in the next generation systems.

[0001628280-25-020353:mdna:140]
[same as prior period, unchanged from 0001628280-24-036182:mdna:130]

[0001628280-25-020353:mdna:141]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Subscription revenue | $ | 47,783 |  |  | $ | 23,733 |  |  | $ | 24,050 |  |  | 101 | % |
| Cost of subscription revenue | $ | 19,242 |  |  | $ | 9,776 |  |  | $ | 9,466 |  |  | 97 | % |
| Gross profit - Subscription revenue | $ | 28,541 |  |  | $ | 13,957 |  |  | $ | 14,584 |  |  | 104 | % |
| Gross profit margin - Subscription revenue | 60 | % |  | 59 | % |  | N/A |  | 1 | % |

[0001628280-25-020353:mdna:142]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to continued growth in our customer base as of September 30, 2024 compared to the prior year, which was due to a transition to our pure subscription model and a higher number of active Evolv Express units deployed under our pure subscription contract model.

[0001628280-25-020353:mdna:143]
[same as prior period, unchanged from 0001628280-24-036182:mdna:143]

[0001628280-25-020353:mdna:144]
[same as prior period, unchanged from 0001628280-24-036182:mdna:134]

[0001628280-25-020353:mdna:145]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Service revenue | $ | 16,903 |  |  | $ | 10,750 |  |  | $ | 6,153 |  |  | 57 | % |
| Cost of service revenue | $ | 3,923 |  |  | $ | 2,816 |  |  | $ | 1,107 |  |  | 39 | % |
| Gross profit - Service revenue | $ | 12,980 |  |  | $ | 7,934 |  |  | $ | 5,046 |  |  | 64 | % |
| Gross profit margin - Service revenue | 77 | % |  | 74 | % |  | N/A |  | 3 | % |

[0001628280-25-020353:mdna:146]
The increases in service revenue, cost of service revenue, and service gross profit are primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech under our distributor licensing model, for the nine months ended September 30, 2024 compared to the nine months ended September 30, 2023.

[0001628280-25-020353:mdna:147]
[same as prior period, unchanged from 0001628280-24-036182:mdna:137]

[0001628280-25-020353:mdna:148]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| License fee and other revenue | $ | 5,290 |  |  | $ | 3,582 |  |  | $ | 1,708 |  |  | 48 | % |
| Cost of license fee and other revenue | $ | 484 |  |  | $ | 772 |  |  | $ | (288) |  |  | (37) | % |
| Gross profit - License fee and other revenue | $ | 4,806 |  |  | $ | 2,810 |  |  | $ | 1,996 |  |  | 71 | % |
| Gross profit margin - License fee and other revenue | 91 | % |  | 78 | % |  | N/A |  | 12 | % |

[0001628280-25-020353:mdna:149]
The increase in license fee and other revenue, gross profit, and gross profit margin was primarily driven by $4.0 million of license fees earned during the nine months ended September 30, 2024 compared to $2.0 million earned during the nine months ended September 30, 2023 under the Distribution and License Agreement which was executed in March 2023.

[0001628280-25-020353:mdna:150]
[same as prior period, unchanged from 0001628280-24-036182:mdna:140]

[0001628280-25-020353:mdna:151]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 12,324 |  |  | $ | 12,687 |  |  | $ | (363) |  |  | (3) | % |
| Materials and prototypes | 1,957 |  |  | 1,561 |  |  | 396 |  |  | 25 | % |
| Professional fees | 2,559 |  |  | 3,025 |  |  | (466) |  |  | (15) | % |
| Other | 1,216 |  |  | 897 |  |  | 319 |  |  | 36 | % |
|  | $ | 18,056 |  |  | $ | 18,170 |  |  | $ | (114) |  |  | (1) | % |

[0001628280-25-020353:mdna:152]
The decrease in personnel related expenses is due to a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $1.6 million, partially offset by an increase in payroll costs primarily resulting from new hires in our research and development function during the past twelve months. The increase in materials and prototypes expense of $0.4 million is due to inventory reserve on unused components, which relate primarily to the development of the next generation of our Evolv Express system. The decrease in professional fees of $0.5 million relates to higher amount of consulting costs capitalized related to internal-use software and software embedded in products to be sold or leased, offset by consulting costs incurred for product development and engineering. The increase in other expense of  $0.3 million is primarily due to an increase in IT and software subscription costs.

[0001628280-25-020353:mdna:153]
[same as prior period, unchanged from 0001628280-24-036182:mdna:144]

[0001628280-25-020353:mdna:154]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 34,825 |  |  | $ | 29,573 |  |  | $ | 5,252 |  |  | 18 | % |
| Advertising and direct marketing | 3,170 |  |  | 2,807 |  |  | 363 |  |  | 13 | % |
| Travel and entertainment | 3,963 |  |  | 3,648 |  |  | 315 |  |  | 9 | % |
| Professional fees | 2,754 |  |  | 1,810 |  |  | 944 |  |  | 52 | % |
| Other | 3,124 |  |  | 2,804 |  |  | 320 |  |  | 11 | % |
|  | $ | 47,836 |  |  | $ | 40,642 |  |  | $ | 7,194 |  |  | 18 | % |

[0001628280-25-020353:mdna:155]
The increase in personnel related expenses of $5.3 million is due to an increase in payroll costs and stock-based compensation of $5.4 million resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increased sales volume and certain other one-time employee termination costs. Stock compensation expense included in sales and marketing expenses was $8.2 million for the nine months ended September 30, 2024 compared to $6.8 million for the nine months ended September 30, 2023. The increase in advertising and direct marketing expense of $0.4 million is due to an increase in sponsorship fees and expenses related to trade shows and events. The increase in travel and entertainment expenses of $0.3 million is due to an increase in travel costs for in-person sales personnel meetings. Professional fees increased by $0.9 million due primarily to an increase in marketing consulting costs. Other expense increased by $0.3 million primarily due to an increase in IT and software subscription costs.

[0001628280-25-020353:mdna:156]
[same as prior period, unchanged from 0001628280-24-036182:mdna:147]

[0001628280-25-020353:mdna:157]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 19,944 |  |  | $ | 17,250 |  |  | $ | 2,694 |  |  | 16 | % |
| Professional fees | 5,653 |  |  | 4,673 |  |  | 980 |  |  | 21 | % |
| Insurance costs | 2,338 |  |  | 2,774 |  |  | (436) |  |  | (16) | % |
| Other | 11,940 |  |  | 6,357 |  |  | 5,583 |  |  | 88 | % |
|  | $ | 39,875 |  |  | $ | 31,054 |  |  | $ | 8,821 |  |  | 28 | % |

[0001628280-25-020353:mdna:158]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation of $2.8 million resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $9.2 million for the nine months ended September 30, 2024 compared to $7.3 million for the nine months ended September 30, 2023. The increase in professional fees of $1.0 million was primarily related to an increase in outsourced accounting consultancy and audit fees. The decrease in insurance costs of $0.4 million was primarily related to a decrease in director and officer insurance premiums. Other expense increased by $5.6 million primarily due to a $3.7 million increase in certain one-time expenses incurred primarily related to certain one-time regulatory matters, as well as increases in rent for additional leased space of $0.6 million, IT and software subscription costs of $1.1 million, and property taxes of $0.5 million.

[0001628280-25-020353:mdna:159]
[same as prior period, unchanged from 0001628280-24-036182:mdna:150]

[0001628280-25-020353:mdna:160]
$0.2 million loss from impairment of property and equipment was recognized for the nine months ended September 30, 2024, compared to $0.3 million for the nine months ended September 30, 2023, primarily related to the removal of Evolv Edge units and Evolv Express units from service, resulting in impairment of the remaining economic value of such units.

[0001628280-25-020353:mdna:161]
15

[0001628280-25-020353:mdna:162]
[same as prior period, unchanged from 0001628280-24-036182:mdna:152]

[0001628280-25-020353:mdna:163]
No interest expense was recognized for the nine months ended September 30, 2024, compared to $0.7 million for the nine months ended September 30, 2023. During March 2023, the Company fully repaid all borrowings and accrued interest under its term loans with SVB pursuant to the 2022 SVB Credit Agreement.

[0001628280-25-020353:mdna:164]
[same as prior period, unchanged from 0001628280-24-036182:mdna:154]

[0001628280-25-020353:mdna:165]
Interest income of $2.4 million and $4.6 million for the nine months ended September 30, 2024 and 2023, respectively, related primarily to interest earned on money market funds and the accretion of discounts on treasury bills.

[0001628280-25-020353:mdna:166]
[same as prior period, unchanged from 0001628280-24-036182:mdna:156]

[0001628280-25-020353:mdna:167]
Change in the fair value of the contingent earn-out liability resulted in a $15.1 million gain and $17.4 million loss for the nine months ended September 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020353:mdna:168]
[same as prior period, unchanged from 0001628280-24-036182:mdna:158]

[0001628280-25-020353:mdna:169]
Change in the fair value of the contingently issuable common stock liability resulted in a $2.2 million gain and $3.6 million loss for the nine months ended September 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020353:mdna:170]
[same as prior period, unchanged from 0001628280-24-036182:mdna:160]

[0001628280-25-020353:mdna:171]
Change in the fair value of the public warrant liability resulted in a $5.5 million gain and a $5.3 million loss for the nine months ended September 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020353:mdna:172]
Liquidity and Capital Resources

[0001628280-25-020353:mdna:173]
Our financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. As of September 30, 2024, we had $56.0 million in cash, cash equivalents, and marketable securities, and as of March 31, 2025, we had $35.0 million in cash, cash equivalents, and marketable securities. We incurred a net loss of $30.4 million and a net income of $5.0 million for the three months ended September 30, 2024 and 2023, respectively, and incurred a net loss of $38.3 million and $90.9 million for the nine months ended September 30, 2024 and 2023, respectively. We incurred cash outflows from operating activities of $34.1 million and $6.7 million during the nine months ended September 30, 2024 and 2023, respectively. We expect to continue to generate losses for the foreseeable future.

[0001628280-25-020353:mdna:174]
We maintain substantially all of our cash, cash equivalents, and marketable securities in accounts with U.S. and multi-national financial institutions and our cash deposits at these institutions exceed Federal Deposit Insurance Corporation insured limits. We do not believe we are exposed to any unusual credit risk or deposit concentration risk beyond the ordinary credit risk associated with commercial banking relationships.

[0001628280-25-020353:mdna:175]
We expect our cash, cash equivalents, and marketable securities of $56.0 million as of September 30, 2024, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to strategically and carefully invest in various areas of the business to support that growth. We may require additional capital to respond to expected growth in the demand for equipment to support our “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances. To the extent that our projected revenue growth does not materialize, we have established plans to preserve existing cash liquidity, which includes additional reductions operating expenses and capital expenditures.

[0001628280-25-020353:mdna:176]
[same as prior period, unchanged from 0001628280-24-036182:mdna:178]

[0001628280-25-020353:mdna:177]
Although not required to fund ongoing operations, in an improving interest rate environment, we may choose to engage in debt financings or enter into credit facilities for other strategic reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, tariffs, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001628280-25-020353:mdna:178]
Additionally, there continues to be significant uncertainty regarding recent changes and potential future developments related to increased trade restrictions, tariffs or taxes on imports or exports relating to countries where we source or sell materials or products. The exact magnitude of any potential impact remains uncertain, as there may be further changes to tariffs and policies and, consequently, potential increased tension between the U.S. and targeted countries, and the Company's financial condition and results of operations could be adversely affected.

[0001628280-25-020353:mdna:179]
[same as prior period, unchanged from 0001628280-24-036182:mdna:166]

[0001628280-25-020353:mdna:180]
During March 2023, we fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. We have no debt outstanding as of September 30, 2024.

[0001628280-25-020353:mdna:181]
[same as prior period, unchanged from 0001628280-24-036182:mdna:168]

[0001628280-25-020353:mdna:182]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of September 30, 2024. We anticipate fulfilling such commitments with our existing cash, cash equivalents, and marketable securities, as well as cash and cash equivalents obtained through operations and, if necessary, proceeds from long-term debt. Cash, cash equivalents, and marketable securities amounted to $56.0 million as of September 30, 2024.

[0001628280-25-020353:mdna:183]
We are party to a lease agreement for office space at our headquarters in Waltham, MA. During the three months ended March 31, 2024, we amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. Additionally, during the three months ended September 30, 2024, we amended the lease agreement again to expand our footprint in our headquarters and extend the term of the lease through May 2031. Per the second lease amendment, we are no longer required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space. As of September 30, 2024, the process of cancelling the letter of credit underlying the minimum cash balance  requirement had not been completed, and as such, this amount is classified as restricted cash, current on the condensed consolidated balance sheet as of September 30, 2024, which is also where this amount was classified as of December 31, 2023. Total future minimum lease payments under this noncancelable operating lease amount to $20.1 million as of September 30, 2024.

[0001628280-25-020353:mdna:184]
[same as prior period, unchanged from 0001628280-24-036182:mdna:171]

[0001628280-25-020353:mdna:185]
[same as prior period, unchanged from 0001628280-24-036182:mdna:172]

[0001628280-25-020353:mdna:186]
|  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |
|  |  |  | (Restated) |
| Net cash used in operating activities | $ | (34,057) |  |  | $ | (6,658) |  |
| Net cash used in investing activities | 11,852 |  |  | (92,793) |  |
| Net cash provided by (used in) financing activities | 1,151 |  |  | (29,716) |  |
| Effect of exchange rate changes on cash and cash equivalents | (75) |  |  | 1 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (21,129) |  |  | $ | (129,166) |  |

[0001628280-25-020353:mdna:187]
17

[0001628280-25-020353:mdna:188]
[same as prior period, unchanged from 0001628280-24-036182:mdna:174]

[0001628280-25-020353:mdna:189]
|  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |
|  |  |  | (Restated) |
| Net loss | $ | (38,297) |  |  | $ | (90,850) |  |
| Non-cash expense | 15,634 |  |  | 51,738 |  |
| Changes in operating assets and liabilities | (11,394) |  |  | 32,454 |  |
| Net cash used in operating activities | $ | (34,057) |  |  | $ | (6,658) |  |

[0001628280-25-020353:mdna:190]
Net loss decreased from $90.9 million for the nine months ended September 30, 2023 to $38.3 million for the nine months ended September 30, 2024 primarily due to changes in the fair value of the contingent earn-out liability, contingently issuable common stock liability, and public warrant liability. See "Results of Operations" above for further discussion.

[0001628280-25-020353:mdna:191]
Non-cash expense for the nine months ended September 30, 2024 is primarily attributable to $21.4 million of stock-based compensation expense and $11.9 million of depreciation and amortization, offset by $22.8 million of an aggregate change in fair value of the contingent earn-out liability, contingently issuable common stock liability, and public warrant liability. Non-cash expense for the nine months ended September 30, 2023 is primarily attributable to $17.8 million of stock-based compensation expense, $6.6 million of depreciation and amortization, and $26.3 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability.

[0001628280-25-020353:mdna:192]
Changes in operating assets and liabilities for the nine months ended September 30, 2024 are primarily related to the following:

[0001628280-25-020353:mdna:193]
•$13.7 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001628280-25-020353:mdna:194]
•$8.3 million increase in inventory primarily due to increased purchases to satisfy future expected demand for the first generation of Evolv Express systems and for the ongoing transition to the next generation of Evolv Express systems;

[0001628280-25-020353:mdna:195]
•$4.1 million increase in prepaid expenses and other current assets primarily due to prepaid deposits related to orders placed for Evolv Express units; partially offset by

[0001628280-25-020353:mdna:196]
•$13.6 million increase in deferred revenue due to a higher volume of sales;

[0001628280-25-020353:mdna:197]
•$1.7 million increase in accrued expenses due to the timing of certain payments; and

[0001628280-25-020353:mdna:198]
•$1.0 million decrease in contract assets related to the timing of revenue recognition.

[0001628280-25-020353:mdna:199]
Changes in operating assets and liabilities for the nine months ended September 30, 2023 are primarily related to the following:

[0001628280-25-020353:mdna:200]
•$4.2 million decrease in inventory primarily due to a higher proportion of finished goods recorded as property and equipment based on our expectations of the future mix of Evolv Express units to be leased to customers versus sold to customers;

[0001628280-25-020353:mdna:201]
•$39.4 million increase in deferred revenue due to a higher volume of sales; partially offset by

[0001628280-25-020353:mdna:202]
•$6.4 million decrease in accounts payable (excluding the non-cash change in capital expenditures incurred but not yet paid from December 31, 2022 to September 30, 2023) primarily due to a decrease in inventory.

[0001628280-25-020353:mdna:203]
[same as prior period, unchanged from 0001628280-24-036182:mdna:190]

[0001628280-25-020353:mdna:204]
During the nine months ended September 30, 2024, cash provided by investing activities was $11.9 million, consisting of $24.4 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers and $4.8 million for the development of internal-use software and software embedded in products to be sold or leased, offset by a net $41.1 million inflow related to purchases and redemptions of marketable securities.

[0001628280-25-020353:mdna:205]
18

[0001628280-25-020353:mdna:206]
During the nine months ended September 30, 2023, cash used in investing activities was $92.8 million, consisting primarily of $51.6 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers, $2.2 million for the development of internal-use software and software embedded in products to be sold or leased, and a net $39.0 million outflow related to purchases and redemptions of marketable securities.

[0001628280-25-020353:mdna:207]
[same as prior period, unchanged from 0001628280-24-036182:mdna:193]

[0001628280-25-020353:mdna:208]
During the nine months ended September 30, 2024, cash provided by financing activities was $1.2 million, consisting of $1.2 million of proceeds from the exercise of stock options.

[0001628280-25-020353:mdna:209]
During the nine months ended September 30, 2023, cash used in financing activities was $29.7 million, consisting of $1.9 million of proceeds under the 2022 SVB Credit Agreement and $0.6 million of proceeds from the exercise of stock options, offset by $31.9 million related to the full repayment of amounts owed under the 2022 SVB Credit Agreement and $0.3 million payment of debt issuance costs and a prepayment penalty.

[0001628280-25-020353:mdna:210]
[same as prior period, unchanged from 0001628280-24-036182:mdna:196]

[0001628280-25-020353:mdna:211]
[same as prior period, unchanged from 0001628280-24-036182:mdna:197]

[0001628280-25-020353:mdna:212]
Critical Accounting Estimates

[0001628280-25-020353:mdna:213]
Our critical accounting estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” of the 2023 Form 10-K. There have been no material changes to our critical accounting policies and estimates during the nine months ended September 30, 2024.
