# EVLV notes — 0001558370-22-008639


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001558370-22-008639:notes:1]
[same as prior period, unchanged from 0001558370-21-015999:notes:1]

[0001558370-22-008639:notes:2]
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a global leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks in a cost-effective manner while improving the visitor experience. The Company is headquartered in Waltham, Massachusetts.

[0001558370-22-008639:notes:3]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC. References to “NHIC” refer to the company prior to the consummation of the Merger (as defined in Note 3) and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001558370-22-008639:notes:4]
[same as prior period, unchanged from 0001558370-21-015999:notes:13]

[0001558370-22-008639:notes:5]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001558370-22-008639:notes:6]
All share and per share amounts contained herein for periods prior to the Merger have been retroactively adjusted to give effect to the Exchange Ratio (as defined in Note 3), unless otherwise indicated.

[0001558370-22-008639:notes:7]
[same as prior period, unchanged from 0001558370-21-015999:notes:19]

[0001558370-22-008639:notes:8]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2022, and for the three months ended March 31, 2022 and 2021 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2021 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2022 and the results of its operations for the three months ended March 31, 2022 and 2021 and cash flows for the three months ended March 31, 2022 and 2021. The results for the three months ended March 31, 2022 are not necessarily indicative of results to be expected for the year ending December 31, 2022, any other interim periods, or any future year or period.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001558370-22-008639:notes:9]
[same as prior period, unchanged from 0001558370-21-015999:notes:22]

[0001558370-22-008639:notes:10]
Significant Accounting Policies

[0001558370-22-008639:notes:11]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2021, and the notes thereto, which are included in our Annual Report on Form 10-K. There have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2022 outside of the items as described below.

[0001558370-22-008639:notes:12]
Leases as a Lessee

[0001558370-22-008639:notes:13]
Prior to January 1, 2022, the Company accounted for leases in accordance with ASC 840, Leases. At lease inception, the Company determined if an arrangement was an operating or capital lease. For operating leases, the Company recognized rent expense, inclusive of rent escalation, on a straight-line basis over the lease term.

[0001558370-22-008639:notes:14]
Effective on January 1, 2022, the Company accounts for leases in accordance with ASC 842, Leases. At contract inception, the Company determines if an arrangement is or contains a lease. A lease conveys the right to control the use of an identified asset for a period of time in exchange for consideration. If determined to be or contain a lease, the lease is assessed for classification as either an operating or finance lease at the lease commencement date, defined as the date on which the leased asset is made available for use by the Company (when the Company is the lessee). Where the Company is the lessee, for each lease with a term greater than twelve months, the Company records a right-of-use asset and lease liability.

[0001558370-22-008639:notes:15]
A right-of-use asset represents the economic benefit conveyed to the Company by the right to use the underlying asset over the lease term. A lease liability represents the obligation to make lease payments arising from the use of the asset over the lease term. Lease liabilities are measured at lease commencement and calculated as the present value of the future lease payments in the contract using the rate implicit in the contract, when available. If an implicit rate is not readily determinable, the Company uses an incremental borrowing rate measured as the rate at which the Company could borrow, on a fully collateralized basis, a commensurate loan in the same currency over a period consistent with the lease term at the commencement date. Right-of-use assets are measured as the amount of the initial lease liability plus initial direct costs and prepaid lease payments, less lease incentives granted by the lessor. The lease term is measured as the noncancelable period in the contract, adjusted for any options to extend or terminate when it is reasonably certain the Company will extend the lease term via such options based on an assessment of economic factors present as of the lease commencement date. The Company elected the practical expedient to not recognize leases with a lease term of twelve months or less.

[0001558370-22-008639:notes:16]
Components of a lease are split into three categories: lease components, non-lease components, and non-components. The fixed and in-substance fixed contract consideration (including any consideration related to non-components) are allocated, based on the respective relative fair values, to the lease components and non-lease components. The Company has elected the practical expedient to account for lease and non-lease components together as a single lease component for all underlying assets and allocate all of the contract consideration to the lease component only.

[0001558370-22-008639:notes:17]
The Company’s operating leases are presented in the condensed consolidated balance sheet as operating lease right-of-use assets, classified as noncurrent assets, and operating lease liabilities, classified as current and noncurrent liabilities. Operating lease expense is recognized on a straight-line basis over the lease term. Variable costs associated with a lease, such as maintenance and utilities, are not included in the measurement of the lease liabilities and right-of-use assets but rather are expensed when the events determining the amount of variable consideration to be paid have occurred.

[0001558370-22-008639:notes:18]
Subscription Revenue - Leases as Lessor

[0001558370-22-008639:notes:19]
In addition to selling our products directly to customers, we also derive revenue from leasing our equipment, which we classify as subscription revenue. Lease terms are typically four years, do not include options to extend, terminate or to purchase the underlying asset, and customers generally pay either a quarterly or annual fixed payment for the lease and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as they do not meet any of the sales-type lease criteria per ASC 842 and recognized ratably over the duration of the lease. There are no variable lease payments as a part of these arrangements.

[0001558370-22-008639:notes:20]
The accounting provisions we use to classify transactions as sales-type are: (i) whether the lease transfers ownership of the equipment by the end of the lease term, (ii) whether the lease grants the customer an option to purchase the equipment and the customer is reasonably certain to do so, (iii) whether the lease term is for the major part of the economic life of the underlying equipment,  (iv) whether the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments,  is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (v) whether the equipment is specific to the customer and of such a specialized nature that it is expected to have no alternative use to the Company at the end of

[0001558370-22-008639:notes:21]
the lease term. Leasing arrangements meeting any of these conditions are accounted for as sales-type leases and revenue attributable to the lease component is recognized in a manner consistent with the equipment sales and the related equipment is derecognized with the associated expense presented as a cost of revenue. Leasing arrangements that do not meet the criteria for classification as a sales-type lease will be accounted for as a direct-financing lease if the following two conditions are met: (i) the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments and any other third party unrelated to the Company, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (ii) it is probable that the Company will collect the lease payments and amounts necessary to satisfy a residual value guarantee. Leasing arrangements that do not meet any of the sales-type lease classification criteria are accounted for as operating leases and revenue is recognized straight-line over the term of the lease.

[0001558370-22-008639:notes:22]
The Company considers the economic life of most of our products to be seven years. The Company believes seven years is representative of the period during which the equipment is expected to be economically usable by one or more users, with normal service, for the purpose for which it is intended. The unguaranteed residual value is estimated to be the value at the end of the lease term based on the anticipated fair market value of the units. The Company mitigates residual value risk of our leased equipment by performing regular management and maintenance, as necessary.

[0001558370-22-008639:notes:23]
Generally, lease arrangements include both lease and non-lease components. The lease component relates to the customer’s right-to-use the equipment over the lease term. The non-lease components relate to (1) distinct services, such as SaaS and maintenance, (2) any add-on accessories, and (3) installation and training. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the Company elected the practical expedient to aggregate non-lease components with the associated lease component and account for the combined component as an operating lease for all underlying asset classes. In the evaluation of whether the lease component (equipment) or the non-lease components associated with the lease component (SaaS and maintenance) is the predominant  component, the Company determined that the lease component is predominant as customers would clearly be expected to ascribe more value to the use of the security equipment than that of the SaaS and maintenance services. Therefore, the Company will account for the combined lease component under ASC 842. The equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in the condensed consolidated statements of operations and comprehensive loss. The installation and training services represent distinct services provided to customers. These activities are considered separate performance obligations to the customer and therefore are considered non-lease components. As installation and training services are performed prior to lease commencement, the timing and pattern of transfer for these services differ from that of the lease component (i.e., security hardware) and are not eligible to be combined.

[0001558370-22-008639:notes:24]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party. Revenue related to leases entered into with related parties were $0.1 million during the three months ended March 31, 2022.

[0001558370-22-008639:notes:25]
Installation and training are generally billed to the lessee as part of the lease contract billing, according to various contractual terms. The installation and training costs incurred by the Company are accounted for as a fulfillment cost and are included in the cost of services revenue in the condensed consolidated statements of operations and comprehensive loss.

[0001558370-22-008639:notes:26]
Recently Adopted Accounting Pronouncements

[0001558370-22-008639:notes:27]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), as subsequently amended (collectively “ASC 842”). The guidance amends the existing accounting standards for lease accounting, including requirements for lessees to recognize assets and liabilities related to long-term leases on the balance sheet and expanding disclosure requirements regarding leasing arrangements. For lessees, leases will be classified as finance or operating, with classification affecting the pattern and classification of expense recognition in the income statement. Lessors are required to classify leases as a sales-type, direct financing, or operating lease. A lease is a sales-type lease if it effectively transfers control of the underlying asset to the lessee as indicated by any one of five criteria being met. All leases that are not sales-type or direct financing leases will be classified as operating leases. In July 2018, the FASB issued additional guidance, which offers a transition option to entities adopting ASC 842 in which entities can elect to

[0001558370-22-008639:notes:28]
apply the new guidance using a modified retrospective approach at the beginning of the year in which the new lease standard is adopted. The Company utilized this transition option whereby financial information for prior periods presented before the ASC 842 effective date will not be updated. In November 2019, the FASB issued ASU 2019-10 deferring the effective date for private entities (also applicable for public companies that qualify as emerging growth companies) for fiscal years beginning after December 15, 2020, and interim periods within fiscal years beginning after December 15, 2021. In June 2020, the FASB issued ASU 2020-05 which further defers the effective date for private entities for fiscal years beginning after December 15, 2021, and interim periods within fiscal years beginning after December 15, 2022.

[0001558370-22-008639:notes:29]
The Company adopted this guidance effective January 1, 2022. ASC 842 provides several optional practical expedients in transition. The Company applied the ‘package of practical expedients’ which allow the Company to not reassess whether existing or expired arrangements contain a lease, the lease classification of existing or expired leases, or whether previous initial direct costs would qualify for capitalization under ASC 842.

[0001558370-22-008639:notes:30]
The adoption of ASC 842 resulted in the recognition of operating lease liabilities of $3.0 million and operating right-of-use assets of $2.5 million, along with the write-off of certain deferred rent balances of $0.5 million within the Company’s condensed consolidated balance sheets as of January 1, 2022. The adoption did not have a significant impact on the Company’s condensed consolidated statements of operations and comprehensive loss and condensed consolidated statements of cash flows.

[0001558370-22-008639:notes:31]
In December 2019, the FASB issued ASU 2019 12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019 12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.

[0001558370-22-008639:notes:32]
In August 2020, the FASB issued ASU 2020-06, “Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity,” which simplifies and clarifies certain calculation and presentation matters related to convertible and equity and debt instruments. Specifically, ASU 2020-06 removes requirements to separately account for conversion features as a derivative under ASC Topic 815 and removing the requirement to account for beneficial conversion features on such instruments. ASU 2020-06 also provides clearer guidance surrounding disclosure of such instruments and provides specific guidance for how such instruments are to be incorporated in the calculation of Diluted EPS. The guidance under ASU 2020-06 is effective for fiscal years beginning after December 15, 2021, including interim periods within those fiscal years. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.

[0001558370-22-008639:notes:33]
Recently Issued Accounting Pronouncements

[0001558370-22-008639:notes:34]
The Company qualifies as an “emerging growth company” as defined in the Jumpstart Our Business Startups Act of 2012 and has elected not to “opt out” to the extended transition related to complying with new or revised accounting standards, which means that when a standard is issued or revised and it has different application dates for public and nonpublic companies, the Company will adopt the new or revised standard at the time nonpublic companies adopt the new or revised standard and will do so until such time that the Company either (1) irrevocably elects to “opt out” of such extended transition period or (2) no longer qualifies as an emerging growth company. The Company may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for nonpublic companies.

[0001558370-22-008639:notes:35]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its condensed consolidated financial statements and related disclosures.

[0001558370-22-008639:notes:36]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its condensed consolidated financial statements and related disclosures.

[0001558370-22-008639:notes:37]
Out-of-Period Adjustment

[0001558370-22-008639:notes:38]
During the three months ended March 31, 2022, the Company recorded an immaterial out-of-period adjustment that resulted in a $1.0 million increase of stock-based compensation expense within sales and marketing expense in the condensed statements of operations and comprehensive loss, a $1.0 million increase to change in fair value of contingent earn-out liability in the condensed statements of operations and comprehensive loss, a $0.5 million decrease to additional paid-in capital in the condensed balance sheets, and a $0.5 million increase to contingent earn-out liability in the condensed balance sheets. The out-of-period adjustment related to an error in the Company’s accounting for the contingent earn-out liability for the third and fourth quarters of fiscal year 2021. The Company has determined the adjustment is not material to the current period or any previously issued financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001558370-22-008639:notes:39]
3. Merger with NHIC and Related Transactions

[0001558370-22-008639:notes:40]
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the Merger as a wholly owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001558370-22-008639:notes:41]
The transaction was accounted for as a “reverse recapitalization” in accordance with GAAP. Under this method of accounting, NHIC was treated as the “acquired” company for financial reporting purposes. This determination was primarily because subsequent to the Merger, Legacy Evolv’s shareholders have a majority of the voting power of the combined company, Legacy Evolv comprises all of the ongoing operations of the combined entity, Legacy Evolv comprises a majority of the governing body of the combined company, and Legacy Evolv’s senior management comprises all of the senior management of the combined company. Accordingly, for accounting purposes, this

[0001558370-22-008639:notes:42]
transaction was treated as the equivalent of Legacy Evolv issuing shares for the net assets of NHIC, accompanied by a recapitalization. The shares and net loss per common share, prior to the Merger, have been retroactively restated as shares reflecting the Exchange Ratio established in the Merger. The net assets of NHIC were recorded at historical costs, with no goodwill or other intangible assets recorded. Operations prior to the Reverse Recapitalization are those of Legacy Evolv.

[0001558370-22-008639:notes:43]
Evolv had previously indicated that it would list units (consisting of one share of common stock and one-half of one warrant) on Nasdaq under the ticker symbol EVLVU, in continuation of the listing of the units NHIC sold in its initial public offering on August 4, 2020 under the ticker symbol NHICU. In September 2021, our transfer agent separated the units into the component shares and warrants at the closing of the Merger, and as a result the Evolv units were not made eligible to settle through the facilities of The Depositary Trust Company. Accordingly, all trades in the units from July 19, 2021 (the first trading day after the completion of the Merger) until August 24, 2021 were settled between brokers in the shares and warrants underlying the units. Trading in ticker symbol EVLVU was halted on August 24, 2021, and no trades in the units were permitted or occurred since that date. The units were delisted from Nasdaq effective September 10, 2021.

[0001558370-22-008639:notes:44]
Upon closing of the Merger each share of NHIC Class B common stock issued and outstanding immediately prior to the effective time of the Merger, which totaled 10,391,513 shares held by the NHIC Initial Shareholders (“Initial Shareholders”), was automatically converted into one validly-issued share of our common stock.

[0001558370-22-008639:notes:45]
In addition, pursuant to the Merger Agreement, certain Legacy Evolv Shareholders became entitled to receive up to 15,000,000 shares of common stock as earn-out shares.

[0001558370-22-008639:notes:46]
[same as prior period, unchanged from 0001558370-21-015999:notes:163]

[0001558370-22-008639:notes:47]
|  | ● | all of 24,359,107 shares of Legacy Evolv’s Series A-1 convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis; |

[0001558370-22-008639:notes:48]
|  | ● | all of 3,484,240 shares of Legacy Evolv’s Series A convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a two-to-one basis; |

[0001558370-22-008639:notes:49]
|  | ● | all of 34,129,398 shares of Legacy Evolv’s Series B-1 convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis; and |

[0001558370-22-008639:notes:50]
|  | ● | all of 15,367,312 shares of Legacy Evolv’s Series B convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis. |

[0001558370-22-008639:notes:51]
On the closing date of the Merger, each share of Legacy Evolv common stock then issued and outstanding was canceled and the holders thereof in exchange received 94,192,534 shares of the Company’s common stock, which is equal to 0.378 newly-issued shares of the Company’s common stock for each share of Legacy Evolv common stock (the “Exchange Ratio”).

[0001558370-22-008639:notes:52]
All outstanding warrants exercisable for common stock in Legacy Evolv (other than warrants that expired, were exercised or were deemed automatically net exercised immediately prior to the Merger) were exchanged for warrants exercisable for the Company’s common stock with the same terms and conditions except adjusted by the Exchange Ratio.

[0001558370-22-008639:notes:53]
All outstanding stock options of Legacy Evolv common stock, totaling 57,938,375 stock options, were canceled and the holders thereof in exchange received options to receive 0.378 shares of the Company’s common stock for a total of 21,891,254 stock options. The modification of the stock options to reflect the exchange ratio did not result in an incremental compensation expense upon closing of the Merger.

[0001558370-22-008639:notes:54]
Prior to the completion of the Merger, the Company entered into subscription agreements (collectively, the “PIPE Investment”) with certain parties subscribing for shares of the Company’s common stock (the “Subscribers”) pursuant to which the Subscribers agreed to purchase. Pursuant to the PIPE Investment, the Company issued 30,000,000 shares of common stock for a purchase price of $10.00 per share with gross proceeds of $300.0 million.

[0001558370-22-008639:notes:55]
The proceeds, net of redemptions, received from the Merger were $84.9 million and gross proceeds received from the PIPE investment were $300.0 million. Based on the number of shares of common stock outstanding on July 16, 2021 (in each case, not giving effect to any shares issuable upon exercise of warrants, options, or earn-out shares), Legacy Evolv shareholders owned approximately 92.7% of the common stock of the Company and NHIC shareholders owned approximately 7.3%.


## us-gaap:FairValueDisclosuresTextBlock

[0001558370-22-008639:notes:56]
[same as prior period, unchanged from 0001558370-21-015999:notes:174]

[0001558370-22-008639:notes:57]
[same as prior period, unchanged from 0001558370-21-015999:notes:175]

[0001558370-22-008639:notes:58]
| ​ | ​ | Fair Value Measurements at March 31, 2022 |
| ​ |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Money market funds | ​ | $ | 257,555 | ​ | $ | — | ​ | $ | — | ​ | $ | 257,555 |
| ​ | ​ | $ | 257,555 | ​ | $ | — | ​ | $ | — | ​ | $ | 257,555 |
| Liabilities: | ​ | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Contingent earn-out liability | ​ | $ | — | ​ | $ | — | ​ | $ | 18,128 | ​ | $ | 18,128 |
| Contingently issuable common stock liability | ​ | ​ | — | ​ | ​ | — | ​ | ​ | 3,792 | ​ | ​ | 3,792 |
| Public Warrant liability | ​ | ​ | — | ​ | ​ | — | ​ | ​ | 5,444 | ​ | ​ | 5,444 |
| ​ | ​ | $ | — | ​ | $ | — | ​ | $ | 27,364 | ​ | $ | 27,364 |

[0001558370-22-008639:notes:59]
| ​ | ​ | Fair Value Measurements as of December 31, 2021 |
| ​ |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Money market funds | ​ | $ | 297,536 | ​ | $ | — | ​ | $ | — | ​ | $ | 297,536 |
| ​ | ​ | $ | 297,536 | ​ | $ | — | ​ | $ | — | ​ | $ | 297,536 |
| Liabilities: | ​ | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Contingent earn-out liability | ​ | $ | — | ​ | $ | — | ​ | $ | 20,809 | ​ | $ | 20,809 |
| Contingently issuable common stock liability | ​ | ​ | — | ​ | ​ | — | ​ | ​ | 5,264 | ​ | ​ | 5,264 |
| Public Warrant liability | ​ | ​ | — | ​ | ​ | — | ​ | ​ | 11,030 | ​ | ​ | 11,030 |
| ​ | ​ | $ | — | ​ | $ | — | ​ | $ | 37,103 | ​ | $ | 37,103 |

[0001558370-22-008639:notes:60]
As of March 31, 2022 and December 31, 2021, respectively, money market funds are included in cash and cash equivalents on the condensed consolidated balance sheets.

[0001558370-22-008639:notes:61]
During the three months ended March 31, 2022 and 2021, respectively, there were no transfers between Level 1, Level 2 and Level 3.

[0001558370-22-008639:notes:62]
[same as prior period, unchanged from 0001558370-21-015999:notes:191]

[0001558370-22-008639:notes:63]
Pursuant to the Merger Agreement, the Legacy Evolv shareholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2021. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out

[0001558370-22-008639:notes:64]
liability upon the closing of the Merger and are remeasured at each reporting period. As of March 31, 2022, no milestones have been achieved.

[0001558370-22-008639:notes:65]
The estimated fair value of the initial contingent earn-out was determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. As of March 31, 2022, the contingent earn-out was revalued using a similar Monte Carlo analysis. The significant assumptions to the model as of December 31, 2021 were as follows: 55% expected stock price volatility, a drift rate of 1.2%, 25% likelihood of change in control and an expected term of 4.5 years. The significant assumptions to the model as of March 31, 2022 were as follows: 92.5% expected stock price volatility, a drift rate of 2.4%, 25% likelihood of change in control and an expected term of 4.3 years.

[0001558370-22-008639:notes:66]
[same as prior period, unchanged from 0001558370-21-015999:notes:194]

[0001558370-22-008639:notes:67]
| Balance at December 31, 2021 | ​ | $ | 20,809 |
| Change in fair value | ​ |  | (4,226) |
| Out-of-period adjustment | ​ | ​ | 1,545 |
| Balance at March 31, 2022 | ​ | $ | 18,128 |

[0001558370-22-008639:notes:68]
[same as prior period, unchanged from 0001558370-21-015999:notes:196]

[0001558370-22-008639:notes:69]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 Founder Shares. 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC and the remaining 1,897,500 outstanding shares shall vest upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2021. The Company’s contingently issuable common stock was recorded at fair value as contingent shares on the closing of the Merger and will be remeasured at each reporting period. As of March 31, 2022, no milestones have been achieved.

[0001558370-22-008639:notes:70]
The estimated fair value of the initial contingently issued common shares was determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. As of March 31, 2022, the contingently issuable common shares were revalued using a similar Monte Carlo analysis. The significant assumptions to the model as of December 31, 2021 were as follows: 55% expected stock price volatility, a drift rate of 1.2%, 25% likelihood of change in control and an expected term of 4.5 years. The significant assumptions to the model as of March 31, 2022 were as follows: 92.5% expected stock price volatility, a drift rate of 2.4%, 25% likelihood of change in control and an expected term of 4.3 years.

[0001558370-22-008639:notes:71]
[same as prior period, unchanged from 0001558370-21-015999:notes:199]

[0001558370-22-008639:notes:72]
| Balance at December 31, 2021 | ​ | $ | 5,264 |
| Change in fair value | ​ |  | (1,472) |
| Balance at March 31, 2022 | ​ | $ | 3,792 |

[0001558370-22-008639:notes:73]
[same as prior period, unchanged from 0001558370-21-015999:notes:201]

[0001558370-22-008639:notes:74]
Upon the closing of the Merger, the Company assumed the Public Warrants to purchase shares of the Company’s common stock (see Note 13). The Public Warrants are publicly traded and the initial fair value of the public warrants were based on the closing price as reported by Nasdaq on the date of the Merger and remeasured at each reporting period.

[0001558370-22-008639:notes:75]
[same as prior period, unchanged from 0001558370-21-015999:notes:203]

[0001558370-22-008639:notes:76]
| Balance at December 31, 2021 | ​ | $ | 11,030 |
| Change in fair value | ​ |  | (5,586) |
| Balance at March 31, 2022 | ​ | $ | 5,444 |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001558370-22-008639:notes:77]
5. Revenue Recognition

[0001558370-22-008639:notes:78]
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

[0001558370-22-008639:notes:79]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases under ASC 842 and (2) from the sale of products, inclusive of SaaS and maintenance and (3) professional services. The Company’s arrangements are generally noncancelable and nonrefundable after ownership passes to the customer for product sales and upon installation for subscriptions. Revenue is recognized net of sales tax.

[0001558370-22-008639:notes:80]
Remaining Performance Obligations

[0001558370-22-008639:notes:81]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2022.

[0001558370-22-008639:notes:82]
| ​ |  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue |  | $ | 166 |  | $ | 39 |  | $ | 205 |
| Subscription revenue |  | ​ | 12,784 |  | ​ | 29,041 |  | ​ | 41,825 |
| Service revenue |  | ​ | 6 | ​ | ​ | — | ​ | ​ | 6 |
| Maintenance revenue | ​ | ​ | 2,415 | ​ | ​ | 6,086 | ​ | ​ | 8,501 |
| Total revenue | ​ | $ | 15,371 | ​ | $ | 35,166 | ​ | $ | 50,537 |

[0001558370-22-008639:notes:83]
The amount of minimum future leases is based on expected income recognition. As of March 31, 2022, future minimum payments on noncancelable leases are as follows (in thousands):

[0001558370-22-008639:notes:84]
| Future operating lease component: |  | ​ |  |
| Year Ending December 31: | ​ | ​ | ​ |
| 2022 (nine months remaining) | ​ | $ | 9,677 |
| 2023 | ​ |  | 12,330 |
| 2024 | ​ |  | 11,137 |
| 2025 | ​ |  | 7,438 |
| 2026 | ​ | ​ | 1,131 |
| Thereafter | ​ |  | 112 |
| ​ | ​ | $ | 41,825 |

[0001558370-22-008639:notes:85]
Contract Balances from Contracts with Customers

[0001558370-22-008639:notes:86]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of

[0001558370-22-008639:notes:87]
time. As of March 31, 2022 and December 31, 2021, the Company had $1.4 million and $1.5 million in current portion of contract assets and $3.3 million and $3.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001558370-22-008639:notes:88]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized $2.5 million during the three months ended March 31, 2022 of revenue that was previously included in the 2021 deferred revenue balance and recognized $0.9 million during the three months ended March 31, 2021 of revenue that was previously included in the 2020 deferred revenue balance.

[0001558370-22-008639:notes:89]
The following table provides a rollforward of deferred revenue (in thousands):

[0001558370-22-008639:notes:90]
| Balance at December 31, 2021 | ​ | $ | 9,165 |
| Revenue recognized | ​ |  | (6,409) |
| Revenue deferred | ​ |  | 9,194 |
| Balance at March 31, 2022 | ​ | $ | 11,950 |

[0001558370-22-008639:notes:91]
The following table presents the Company’s components of lease revenue (in thousands):

[0001558370-22-008639:notes:92]
| ​ | ​ | Three Months Ended March 31, |
| ​ | ​ | 2022 | ​ | ​ | 2021 |
| Revenue from sales-type leases | $ | 1,312 | ​ | $ | — |
| Interest income on lease receivables | ​ | 190 | ​ |  | — |
| Lease income - operating leases | ​ | 3,020 | ​ | ​ | 1,300 |
| Total lease revenue | $ | 4,522 | ​ | $ | 1,300 |

[0001558370-22-008639:notes:93]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified as other income (expense), net in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss.

[0001558370-22-008639:notes:94]
Disaggregated Revenue

[0001558370-22-008639:notes:95]
The following table presents the Company’s revenue by revenue stream (in thousands):

[0001558370-22-008639:notes:96]
| ​ | ​ | Three Months Ended March 31, |
| ​ | ​ | 2022 |  | 2021 |
| Product revenue | ​ | ​ | 5,194 |  | ​ | 2,502 |
| Leased equipment | ​ | ​ | 3,020 |  | ​ | 1,300 |
| SaaS and Maintenance revenue | ​ | ​ | 353 |  | ​ | 132 |
| Professional services revenue | ​ | ​ | 148 | ​ | ​ | 65 |
| Total revenue | ​ | $ | 8,715 | ​ | $ | 3,999 |

[0001558370-22-008639:notes:97]
Contract Acquisition Costs

[0001558370-22-008639:notes:98]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $5.7 million and $5.4 million as of March 31, 2022 and December 31, 2021, respectively. The Company amortized commissions of $0.1 million during the three months ended March 31, 2022 which related to 2022 commissions and $0.3 million which related to 2021 commissions.

[0001558370-22-008639:notes:99]
Give Evolv LLC

[0001558370-22-008639:notes:100]
Upon the closing of the Merger, the NHIC Founders transferred 517,500 shares of its common stock to Evolv NewHold Benefit LLC (“ENHB”), which represented the initial contribution to be used to pay for the donation of Evolv’s Express units to public venues and institutions, primarily schools in locations that might not otherwise be able to afford weapon detection security screening systems and related products and services. In September 2021, ENHB was renamed to Give Evolv LLC (“Give Evolv”). Give Evolv is deemed an entity under common control and a consolidating entity as it is under the same management as the Company. As such, the shares held by Give Evolv are not considered outstanding or issued.

[0001558370-22-008639:notes:101]
For such arrangements, Give Evolv generally purchases the related products and services from Evolv Technologies, Inc. through an intercompany transaction using the available donated proceeds from the transfer of common stock upon the closing of the Merger. Evolv Technologies, Inc. will be responsible for the delivery of the units, in addition to providing related services, such as installation, training, and maintenance. Consideration transferred to Evolv Technologies, Inc. for the related products and services may be in the form of common stock or cash. Shares of common stock may be sold to generate funds for the purposes of paying for the donated goods and services. The sales transactions between Evolv Technologies, Inc. and Give Evolv eliminate in consolidation.

[0001558370-22-008639:notes:102]
During the three months ended March 31, 2022, the Company donated three Evolv Express units to schools, resulting in $0.2 million in general and administrative expense in the Company’s condensed consolidated statements of operations and comprehensive loss.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001558370-22-008639:notes:103]
6. Leases

[0001558370-22-008639:notes:104]
Company Headquarters (Waltham, MA)

[0001558370-22-008639:notes:105]
In April 2021, the Company entered a sublease agreement for office and storage space for its corporate headquarters located at 500 Totten Pond Road in Waltham, MA. The sublease has an initial term of 42 months beginning on May 1, 2021, and expiring on October 31, 2024. The Company is required to maintain a minimum cash balance of $0.7 million as a security deposit on the space which is classified as restricted cash, current and restricted cash, non-current on the condensed consolidated balance sheets. The Company pays for its proportionate share of building operating expenses and taxes that are treated as variable costs and excluded from the measurement of the lease. The sublease grants the Company an option to extend the term for an additional three years at the then fair market rent by giving the landlord nine months’ written notice. The Company was not reasonably certain to exercise the option to extend the lease and therefore the extension term was excluded from the measurement of the lease.

[0001558370-22-008639:notes:106]
Storage Facilities

[0001558370-22-008639:notes:107]
The Company additionally leases three storage spaces on a month-to-month basis that are classified as short-term leases.

[0001558370-22-008639:notes:108]
The following tables contains a summary of the lease costs recognized under ASC 842 and other information pertaining to the Company’s operating leases for the three months ended March 31, 2022.

[0001558370-22-008639:notes:109]
The components of lease cost under ASC 842 were as follows (in thousands):

[0001558370-22-008639:notes:110]
| Operating lease cost |  | $ | 245 |

[0001558370-22-008639:notes:111]
Supplemental disclosure of cash flow information related to leases was as follows (in thousands):

[0001558370-22-008639:notes:112]
| Cash paid for amounts included in the measurement of lease liabilities |  | $ | 278 |

[0001558370-22-008639:notes:113]
The weighted-average remaining lease term and discount rate were as follows:

[0001558370-22-008639:notes:114]
| Weighted average remaining lease term (in years) |  | ​ | 2.6 | ​ |
| Weighted average discount rate |  | ​ | 6.95 | % |

[0001558370-22-008639:notes:115]
Future annual lease payments under non-cancelable operating leases as of March 31, 2022 were as follows (in thousands):

[0001558370-22-008639:notes:116]
| Year Ended December 31: |  | ​ | ​ |
| 2022 (remaining nine months) |  | $ | 838 |
| 2023 | ​ | ​ | 1,149 |
| 2024 | ​ | ​ | 982 |
| Total future lease payments | ​ | $ | 2,969 |
| Less: imputed interest | ​ | ​ | (246) |
| Present value of operating lease liability | ​ | $ | 2,723 |

[0001558370-22-008639:notes:117]
Rent expense for the three months ended March 31, 2021 was approximately $0.1 million in accordance with ASC 840. Rent expense for the year ended December 31, 2021 was approximately $0.9 million in accordance with ASC 840.

[0001558370-22-008639:notes:118]
Future annual lease payments under non-cancelable operating leases as of December 31, 2021 under ASC 840 were as follows (in thousands):

[0001558370-22-008639:notes:119]
| Year Ended December 31: |  | ​ | ​ |
| 2022 |  | $ | 1,116 |
| 2023 | ​ | ​ | 1,150 |
| 2024 | ​ | ​ | 981 |
| Total | ​ | $ | 3,247 |


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001558370-22-008639:notes:120]
7. Accounts Receivable

[0001558370-22-008639:notes:121]
Allowance for Doubtful Accounts

[0001558370-22-008639:notes:122]
As of March 31, 2022 and December 31, 2021, the Company’s allowance for doubtful accounts of $0.1 million, respectively. Changes in the allowance for doubtful accounts were as follows (in thousands):

[0001558370-22-008639:notes:123]
| ​ | ​ | Allowance for Doubtful Accounts |
| Balance at December 31, 2021 | ​ | $ | (50) |
| Provisions | ​ |  | — |
| Write-offs, net of recoveries | ​ |  | — |
| Balance at March 31, 2022 | ​ | $ | (50) |


## us-gaap:InventoryDisclosureTextBlock

[0001558370-22-008639:notes:124]
8. Inventory

[0001558370-22-008639:notes:125]
[same as prior period, unchanged from 0001558370-21-015999:notes:206]

[0001558370-22-008639:notes:126]
| ​ | ​ | March 31, | ​ | December 31, |
| ​ |  | 2022 |  | 2021 |
| Raw materials | ​ | $ | 1,172 | ​ | $ | 1,050 |
| Finished goods | ​ |  | 6,009 | ​ |  | 4,090 |
| Total | ​ | $ | 7,181 | ​ | $ | 5,140 |


## nhic:PrepaidExpenseAndOtherAssetsCurrentTextBlock

[0001558370-22-008639:notes:127]
9. Prepaid Expenses and Other Current Assets

[0001558370-22-008639:notes:128]
[same as prior period, unchanged from 0001558370-21-015999:notes:209]

[0001558370-22-008639:notes:129]
| ​ |  | March 31, | ​ | December 31, |
| ​ |  | 2022 |  | 2021 |
| Prepaid deposits | ​ | $ | 13,479 | ​ | $ | 7,591 |
| Prepaid insurance | ​ | ​ | 1,625 | ​ | ​ | 2,803 |
| Prepaid subscriptions | ​ | ​ | 625 | ​ | ​ | 411 |
| Other | ​ |  | 1,523 | ​ |  | 242 |
| Total | ​ | $ | 17,252 | ​ | $ | 11,047 |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001558370-22-008639:notes:130]
10. Property and Equipment, Net

[0001558370-22-008639:notes:131]
[same as prior period, unchanged from 0001558370-21-015999:notes:212]

[0001558370-22-008639:notes:132]
| ​ | ​ | March 31, | ​ | December 31, |
| ​ | ​ | 2022 |  | 2021 |
| Computers and telecom equipment | ​ | $ | 329 | ​ | $ | 40 |
| Lab equipment | ​ |  | 568 | ​ |  | 568 |
| Purchased software | ​ |  | 59 | ​ |  | — |
| Furniture and fixtures | ​ |  | 37 | ​ |  | 37 |
| Leasehold improvements | ​ |  | 538 | ​ |  | 491 |
| Leased equipment | ​ | ​ | 24,217 | ​ | ​ | 21,100 |
| Internal-use software | ​ | ​ | 1,820 | ​ | ​ | 1,029 |
| Sales demo equipment | ​ |  | 2,149 | ​ |  | 1,938 |
| ​ | ​ |  | 29,717 | ​ |  | 25,203 |
| Less: Accumulated depreciation and amortization | ​ |  | (4,435) | ​ |  | (3,611) |
| ​ | ​ | $ | 25,282 | ​ | $ | 21,592 |

[0001558370-22-008639:notes:133]
As of March 31, 2022 and December 31, 2021, the net book value of internal-use software was $1.7 million and $1.0 million, respectively. Depreciation expense and amortization expense related to property and equipment was $0.9 million and $0.5 million for the three months ended March 31, 2022 and 2021, respectively, which included amortization expense of internal-use software of less than $0.1 million and $0 for the three months ended March 31, 2022 and 2021, respectively.

[0001558370-22-008639:notes:134]
Leased equipment and the related accumulated depreciation were as follows (in thousands):

[0001558370-22-008639:notes:135]
| ​ | ​ | March 31, | ​ | December 31, |
| ​ | ​ | 2022 |  | 2021 |
| Leased equipment | ​ | $ | 24,217 | ​ | $ | 21,100 |
| Accumulated depreciation | ​ |  | (3,390) | ​ |  | (2,761) |
| Leased equipment, net | ​ | $ | 20,827 | ​ | $ | 18,339 |

[0001558370-22-008639:notes:136]
Depreciation related to leased units was $0.8 million and $0.4 million during the three months ended March 31, 2022 and 2021, respectively. Depreciable lives generally range from 4 to 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.

[0001558370-22-008639:notes:137]
Impairment of property and equipment was $0.1 million for the three months ended March 31, 2022. There was no impairment recognized for the three months ended March 31, 2021. This related to Edge units and Express prototype units that were removed from service and retired. The Company is transitioning its domestic customers from the Edge units to the most current Express units, which also resulted in an impairment of the remaining economic value of such assets.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001558370-22-008639:notes:138]
11. Accrued Expenses and Other Current Liabilities

[0001558370-22-008639:notes:139]
[same as prior period, unchanged from 0001558370-21-015999:notes:220]

[0001558370-22-008639:notes:140]
| ​ | ​ | March 31, | ​ | December 31, |
| ​ | ​ | 2022 |  | 2021 |
| Accrued employee compensation and benefits expense | ​ | $ | 2,198 | ​ | $ | 5,536 |
| Accrued professional services and consulting | ​ |  | 1,438 | ​ |  | 1,441 |
| Accrued sales tax | ​ | ​ | 1,213 | ​ | ​ | 1,091 |
| Accrued marketing | ​ | ​ | 521 | ​ | ​ | — |
| Accrued property tax | ​ | ​ | 472 | ​ | ​ | — |
| Accrued interest | ​ | ​ | 48 | ​ | ​ | 64 |
| Other | ​ |  | 1,228 | ​ |  | 1,051 |
| Total | ​ | $ | 7,118 | ​ | $ | 9,183 |


## us-gaap:DebtDisclosureTextBlock

[0001558370-22-008639:notes:141]
12. Long-term Debt

[0001558370-22-008639:notes:142]
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001558370-22-008639:notes:143]
| ​ | ​ | March 31, | ​ | December 31, |
| ​ | ​ | 2022 |  | 2021 |
| Term loans payable | ​ | $ | 10,000 | ​ | $ | 10,000 |
| Less: Unamortized discount | ​ |  | (50) | ​ |  | (55) |
| ​ | ​ |  | 9,950 | ​ |  | 9,945 |
| Less: Current portion of long-term debt | ​ |  | 3,000 | ​ |  | 2,000 |
| Long-term debt, net of discount | ​ | $ | 6,950 | ​ | $ | 7,945 |

[0001558370-22-008639:notes:144]
Term Loan Agreements

[0001558370-22-008639:notes:145]
JPMorgan Chase Bank, N.A.(“JPM”) Credit Agreement

[0001558370-22-008639:notes:146]
In December 2020, the Company entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024 and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022.

[0001558370-22-008639:notes:147]
Principal and interest on the JPM Credit Agreement is payable monthly commencing on July 1, 2022. The JPM Credit Agreement accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 2.25% or (B) 5.5%. The revolving line of credit accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 1.25% or (B) 4.5%. Upon closing, the Company issued warrants to purchase 377,837 shares of common stock to the lender with an exercise price of $0.42 per share with a fair value of $0.1 million on the date of issuance. The Company incurred debt issuance costs of $0.1 million equal to the fair value of the warrants in connection with the JPM Credit Agreement. These costs were recorded as debt discount and are amortized to interest expense, using the effective interest method, over the term of the loan. Upon the closing of the Merger, the warrants were converted into shares of the Company’s common stock.

[0001558370-22-008639:notes:148]
As of March 31, 2022, the unamortized debt discount was $0.1 million. As of March 31, 2022, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the condensed consolidated balance sheet. Interest expense related to the JPM Credit Agreement totaled $0.1 million and $0.2 million for the three months ended March 31, 2022 and 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million and $0.1 million for the three months ended March 31, 2022 and 2021, respectively. The interest rate in effect as of March 31, 2022 was 5.75% for the JPM Credit Agreement. During the year ended December 31, 2021, the Company fully repaid the $5.4 million drawn down on the revolving line of credit.

[0001558370-22-008639:notes:149]
The Company’s obligations under the JPM Credit Agreement are secured by a first-priority security interest in all of its assets, including intellectual property.

[0001558370-22-008639:notes:150]
As of March 31, 2022, future principal payments on long-term debt are as follows (in thousands):

[0001558370-22-008639:notes:151]
| Year Ending December 31, |  | ​ | ​ |
| 2022 (remaining nine months) | ​ | $ | 2,000 |
| 2023 | ​ |  | 4,000 |
| 2024 | ​ |  | 4,000 |
| ​ | ​ | $ | 10,000 |

[0001558370-22-008639:notes:152]
Convertible Note

[0001558370-22-008639:notes:153]
In September 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) with an investor for gross proceeds of $2.0 million with a stated interest rate of 6.0% per annum. An additional $2.0 million in gross proceeds were made available in December 2020 upon achievement of the integration milestone, whereby the Company successfully created software utilizing the investor’s application programming interface. The 2020 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds of the issuance of preferred stock totaled at least $10.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2020 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $1.0 million, and the notes, with an initial carrying value of $3.0 million, and included in long-

[0001558370-22-008639:notes:154]
term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the Merger.

[0001558370-22-008639:notes:155]
Interest expense for the 2020 Convertible Notes totaled $0 and $0.1 million for the three months ended March 31, 2022 and 2021, respectively.

[0001558370-22-008639:notes:156]
In January and February 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $7.0 million, and the notes, with an initial carrying value of $23.0 million, and included in long-term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the Merger.

[0001558370-22-008639:notes:157]
In June 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. This modification of the notes resulted in an extinguishment and the Company recognized a loss on extinguishment of the 2021 Convertible Notes of $11.8 million. The $26.7 million carrying value of the notes at June 21, 2021 was derecognized and replacement notes with an initial carrying value of $29.6 million were recorded. Additionally, in the extinguishment accounting, a derivative liability of $19.2 million was recognized, which represents the value of the 1,000,000 NHIC shares as well as a bifurcated embedded derivative for the conversion option.

[0001558370-22-008639:notes:158]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense).

[0001558370-22-008639:notes:159]
Interest expense for the 2021 Convertible Notes totaled $0 and $1.9 million for the three months ended March 31, 2022 and 2021, respectively.


## nhic:WarrantsAndRightsNoteDisclosureTextBlock

[0001558370-22-008639:notes:160]
13. Warrants

[0001558370-22-008639:notes:161]
In January 2021, in connection with a Business Development Agreement entered into with Finback Evolv II, LLC (“Finback BDA”), the Company issued a warrant to Finback for the purchase of 2,552,913 shares of common stock at an exercise price of $0.42 per share. The 2021 Finback common stock warrants vest upon meeting certain sales criteria as defined in the agreement and expires in January 2031. The warrants will be accounted for under ASC 718 Compensation – Stock Compensation as the warrants will vest upon certain performance conditions being met (see Note 16).

[0001558370-22-008639:notes:162]
In connection with the closing of the Merger, the Company assumed the Public Warrants for the purchase of 14,325,000 shares of common stock at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and were recorded at its fair value of $23.6 million

[0001558370-22-008639:notes:163]
on the date of the closing of the Merger with an offset to additional paid-in-capital and is subsequently remeasured to fair value at each reporting date based on the publicly available trading price. The change in fair value of the public warrant liability of $5.6 million and $0 was recognized as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss for the three months ended March 31, 2022 and 2021, respectively. As of March 31, 2022, none of the vested 2021 Finback common stock warrants were exercised.

[0001558370-22-008639:notes:164]
As of March 31, 2022 and December 31, 2021, warrants to purchase the following class of Common stock outstanding consisted of the following in the tables below:

[0001558370-22-008639:notes:165]
| March 31, 2022 |
| ​ | ​ | Contractual | ​ | ​ | ​ | ​ | ​ | Shares Issuable | ​ | Weighted |
| ​ | ​ | Term | ​ | Underlying Equity | ​ | Balance Sheet | ​ | Upon Exercise | ​ | Average |
| Issuance Date |  | (in years) |  | Instrument |  | Classification |  | of Warrant |  | Exercise Price |
| January 13, 2021 |  | 10 |  | Common stock |  | Equity |  | 2,552,913 | ​ | $ | 0.42 |
| July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,993 | ​ | $ | 11.50 |
| ​ | ​ | ​ |  |  |  |  |  | 16,877,906 | ​ |  |  |

[0001558370-22-008639:notes:166]
| December 31, 2021 |
| ​ | ​ | Contractual | ​ | ​ | ​ | ​ | ​ | Shares Issuable | ​ | Weighted |
| ​ | ​ | Term | ​ | Underlying Equity | ​ | Balance Sheet | ​ | Upon Exercise of | ​ | Average |
| Issuance Date |  | (in years) |  | Instrument |  | Classification |  | Warrant |  | Exercise Price |
| January 13, 2021 |  | 10 |  | Common stock |  | Equity |  | 2,552,913 | ​ | $ | 0.42 |
| July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,994 | ​ | $ | 11.50 |
| ​ | ​ | ​ |  |  |  |  |  | 16,877,907 | ​ |  |  |


## nhic:TemporaryEquityDisclosureTextBlock

[0001558370-22-008639:notes:167]
14. Convertible Preferred Stock

[0001558370-22-008639:notes:168]
[same as prior period, unchanged from 0001558370-21-015999:notes:249]

[0001558370-22-008639:notes:169]
Pursuant to the Merger Agreement, immediately prior to the Merger, each share of Legacy Evolv’s Series A-1, Series B-1, and Series B preferred stock outstanding converted to Legacy Evolv common stock on a 1:1 conversion ratio. Pursuant to the Merger Agreement, immediately prior to the Merger, each share of Legacy Evolv’s Series A preferred stock outstanding converted to Legacy Evolv common stock on a 2:1 conversion ratio. On the closing date of the Merger, each share of Legacy Evolv common stock then issued and outstanding was canceled and the holders thereof in exchange received shares of Evolv Technologies Holdings, Inc. equal to 0.378 shares for each share of Legacy Evolv common stock. As of December 31, 2021, the Company has no preferred stock outstanding as all convertible preferred stock converted to common stock upon closing of the Merger.


## nhic:CommonStockDisclosureTextBlock

[0001558370-22-008639:notes:170]
15. Common Stock

[0001558370-22-008639:notes:171]
As of March 31, 2022 and December 31, 2021, the Company had reserved 74,863,862 and 76,008,377 shares, respectively, of common stock for the conversion of the outstanding Preferred Stock, exercise of outstanding stock options, granting of awards under the Company’s 2021 Equity Incentive Plan and 2013 Equity Incentive Plan (see Note 16) and the exercise of outstanding warrants (see Note 13).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001558370-22-008639:notes:172]
16. Stock-Based Compensation

[0001558370-22-008639:notes:173]
[same as prior period, unchanged from 0001558370-21-015999:notes:273]

[0001558370-22-008639:notes:174]
As of March 31, 2022 and December 31, 2021, shares of common stock that may be issued under the 2021 Plan were 21,177,295. As of March 31, 2022 and December 31, 2021, 11,938,665 and 19,511,916 shares remained available for future grant under the 2021 Plan. Shares that are expired, forfeited, canceled or otherwise terminated without having been fully exercised will be available for future grant under the 2021 Plan. In addition, shares of common stock that are tendered to the Company by a participant to exercise an award are added to the number of shares of common stock available for future grants.

[0001558370-22-008639:notes:175]
During the three months ended March 31, 2022, the Company granted 2,262,925 options.

[0001558370-22-008639:notes:176]
[same as prior period, unchanged from 0001558370-21-015999:notes:281]

[0001558370-22-008639:notes:177]
| ​ | ​ | Three Months Ended March 31, |  |
| ​ |  | 2022 |  | 2021 |  |
| Risk-free interest rate |  | 1.6 | % | 0.5 | % |
| Expected term (in years) |  | 6.1 | ​ | 4.6 | ​ |
| Expected volatility |  | 75.0 | % | 23.9 | % |
| Expected dividend yield |  | 0.0 | % | 0.0 | % |

[0001558370-22-008639:notes:178]
The following tables summarize the Company’s stock option activity since December 31, 2021 (in thousands, except for share and per share data):

[0001558370-22-008639:notes:179]
| ​ |  | ​ |  | ​ | ​ |  | Weighted |  | ​ | ​ |
| ​ | ​ | ​ | ​ | Weighted | ​ | Average | ​ | ​ | ​ |
| ​ | ​ | Number of | ​ | Average | ​ | Remaining | ​ | Aggregate |
| ​ | ​ | Shares | ​ | Exercise Price | ​ | Contractual Term | ​ | Intrinsic Value |
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | (in years) | ​ | ​ | ​ |
| Outstanding as of December 31, 2021 | ​ | 20,769,130 | ​ | $ | 0.39 | ​ | ​ | ​ | ​ | ​ |
| Granted |  | 2,262,925 | ​ | ​ | 2.32 |  | ​ |  | ​ | ​ |
| Exercised |  | (499,767) | ​ | ​ | 0.42 | ​ | ​ |  | ​ | ​ |
| Forfeited | ​ | (567,979) | ​ | ​ | 0.42 |  | ​ |  | ​ | ​ |
| Outstanding as of March 31, 2022 |  | 21,964,309 | ​ | ​ | 0.59 | ​ | 7.70 | ​ | $ | 45,207 |
| Vested and expected to vest as of March 31, 2022 |  | 21,964,309 | ​ | $ | 0.59 |  | 7.70 | ​ | $ | 45,207 |
| Options exercisable as of March 31, 2022 |  | 12,025,749 | ​ | $ | 0.38 |  | 6.77 | ​ | $ | 27,356 |

[0001558370-22-008639:notes:180]
[same as prior period, unchanged from 0001558370-21-015999:notes:285]

[0001558370-22-008639:notes:181]
[same as prior period, unchanged from 0001558370-21-015999:notes:288]

[0001558370-22-008639:notes:182]
The following table summarizes the Company’s restricted stock units activity since December 31, 2021:

[0001558370-22-008639:notes:183]
| ​ | ​ | Number of | ​ | Grant Date Fair |
| ​ | ​ | Shares | ​ | Value |
| Outstanding as of December 31, 2021 | ​ | 1,951,924 | ​ | $ | 6.76 |
| Granted |  | 4,425,142 |  | ​ | 3.50 |
| Vested |  | (80,044) |  | ​ | 7.95 |
| Canceled |  | (46,020) |  | ​ | 5.92 |
| Outstanding as of March 31, 2022 |  | 6,251,002 | ​ | $ | 4.44 |

[0001558370-22-008639:notes:184]
During the three months ended March 31, 2022, the Company issued 4,425,142 shares of restricted stock units with an aggregate grant-date fair value of $15.5 million under the 2021 Plan. The terms of the RSU’s under the 2021 Plan allow for the following vesting periods, which are determined on an individual basis on the date of grant:

[0001558370-22-008639:notes:185]
(A) The restricted stock units will vest over four years from the Vesting Commencement Date, with 25% of the restricted stock units vesting on the first anniversary of the Vesting Commencement Date and the remaining restricted stock units vesting quarterly thereafter over the remaining three years, subject to the individual remaining a Service Provider (as defined in the 2021 Plan) through the applicable vesting date.

[0001558370-22-008639:notes:186]
(B) The restricted stock units will vest over three years from the Vesting Commencement Date, with one third of the restricted stock units vesting on the first anniversary of the Vesting Commencement Date and the remaining restricted stock units vesting annually thereafter over the remaining two years, subject to the individual remaining a Service Provider (as defined in the 2021 Plan) through the applicable vesting date.

[0001558370-22-008639:notes:187]
(C) The restricted stock units will vest over one year from the Vesting Commencement Date, with the full amount vesting on the first anniversary of the Vesting Commencement Date, subject to the individual remaining a Service Provider (as defined in the 2021 Plan) through the applicable vesting date.

[0001558370-22-008639:notes:188]
Performance Stock Units

[0001558370-22-008639:notes:189]
The following table summarizes the Company’s performance stock units activity since December 31, 2021:

[0001558370-22-008639:notes:190]
| ​ | ​ | Number of | ​ | Grant Date Fair |
| ​ | ​ | Shares | ​ | Value |
| Outstanding as of December 31, 2021 | ​ | — | ​ | $ | — |
| Granted |  | 934,000 |  | ​ | 2.65 |
| Vested |  | — |  | ​ | — |
| Canceled |  | — |  | ​ | — |
| Outstanding as of March 31, 2022 |  | 934,000 | ​ | $ | 2.65 |

[0001558370-22-008639:notes:191]
During the three months ended March 31, 2022, the Company issued 934,000 shares of with an aggregate grant-date fair value of $2.5 million under the 2021 Plan. Based upon the terms of the award agreements, 50% of the applicable units shall vest on January 1, 2023, provided that the Company has achieved its annual bookings goal for fiscal year 2022; and the remaining 50% of the units shall vest on January 1, 2024 if and only if the 2022 fiscal year bookings goal was achieved and subject to the grantee’s continued service through the applicable vesting date.

[0001558370-22-008639:notes:192]
[same as prior period, unchanged from 0001558370-21-015999:notes:278]

[0001558370-22-008639:notes:193]
As of March 31, 2022 and December 31, 2021, 3,435,748 shares of the Company’s common stock were available for future issuance. The Company’s Board of Directors may from time to time grant or provide for the grant to eligible employees of options to purchase common stock under the 2021 Employee Stock Purchase Plan during a specific offering period. As of March 31, 2022, no offerings have been approved.

[0001558370-22-008639:notes:194]
[same as prior period, unchanged from 0001558370-21-015999:notes:295]

[0001558370-22-008639:notes:195]
In January 2021, in connection with a Business Development Agreement entered into with Finback Evolv II, LLC, the Company issued a warrant to Finback for the purchase of 2,552,913 shares of common stock at an exercise price of $0.42 per share. The 2021 Finback common stock warrants vest upon meeting certain sales criteria as defined in the agreement and expires in January 2031. The warrants will be accounted for under ASC 718 Compensation – Stock Compensation as the warrants will vest upon certain performance conditions being met.

[0001558370-22-008639:notes:196]
[same as prior period, unchanged from 0001558370-21-015999:notes:297]

[0001558370-22-008639:notes:197]
| Warrants - Black Scholes |  | ​ | ​ |
| Risk-free interest rate |  | 0.4 | % |
| Expected term (in years) |  | 3.00 | ​ |
| Expected volatility |  | 23.9 | % |
| Expected dividend yield |  | 0.0 | % |

[0001558370-22-008639:notes:198]
On the date of issuance, the total value of the 2021 Finback common stock warrants were valued as $19.5 million.

[0001558370-22-008639:notes:199]
As of March 31, 2022, 341,094 shares of the 2021 Finback common stock warrants were exercisable at a total aggregate intrinsic value of $2.6 million. The remaining 2,211,819 shares of the 2021 Finback common stock warrants are unvested and have a total aggregate intrinsic value of $16.9 million. As of March 31, 2022, none of the 2021 Finback common stock warrants were exercised. The Company will recognize compensation expense for the 2021 Finback common stock warrants when the warrants become vested based on meeting the certain sales criteria. During the three months ended March 31, 2022 and 2021, the Company recorded $0.4 million and $0.8 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.

[0001558370-22-008639:notes:200]
Stock-Based Compensation

[0001558370-22-008639:notes:201]
Stock-based compensation expense was classified in the condensed consolidated statements of operations and comprehensive loss as follows (in thousands):

[0001558370-22-008639:notes:202]
| ​ | ​ | Three Months Ended March 31, |
| ​ | ​ | 2022 |  | 2021 |
| Cost of revenue | ​ | $ | 60 | ​ | $ | 5 |
| Sales and marketing | ​ |  | 2,770 | ​ |  | 933 |
| General and administrative | ​ |  | 1,787 | ​ |  | 94 |
| Research and development | ​ |  | 573 | ​ |  | 50 |
| Total stock-based compensation expense | ​ | $ | 5,190 | ​ | $ | 1,082 |

[0001558370-22-008639:notes:203]
Stock-based compensation expense was classified by award type in the condensed consolidated statements of operations and comprehensive loss as follows (in thousands):

[0001558370-22-008639:notes:204]
| ​ | ​ | ​ | Three Months Ended March 31, |
| ​ | ​ | 2022 |  | 2021 |
| Stock options | ​ | $ | 242 | ​ | $ | 203 |
| Earn-out shares | ​ | ​ | 2,699 | ​ | ​ | — |
| Warrants | ​ | ​ | 436 | ​ | ​ | 807 |
| Restricted stock units | ​ | ​ | 1,813 | ​ | ​ | 72 |
| Total stock-based compensation expense | ​ | $ | 5,190 | ​ | $ | 1,082 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001558370-22-008639:notes:205]
17. Income Taxes

[0001558370-22-008639:notes:206]
During the three months ended March 31, 2022 and 2021, the Company did not record income tax provisions or income tax benefits due to the net loss before income taxes expected to be incurred for the year ending December 31, 2022, as well as the Company’s continued maintenance of a full valuation allowance against its net deferred tax assets, and the net loss before income taxes incurred for the year ended December 31, 2021.

[0001558370-22-008639:notes:207]
[same as prior period, unchanged from 0001558370-21-015999:notes:308]


## us-gaap:EarningsPerShareTextBlock

[0001558370-22-008639:notes:208]
18. Net Loss per Share

[0001558370-22-008639:notes:209]
Basic and diluted net loss per share was calculated as follows (in thousands, except share and per share amounts):

[0001558370-22-008639:notes:210]
| ​ | ​ | Three Months Ended March 31, |
| ​ |  | 2022 |  | 2021 |
| Numerator: | ​ | ​ |  |  | ​ |  |
| Net loss – basic and diluted | ​ | $ | (14,551) | ​ | $ | (13,755) |
| Denominator: | ​ |  | ​ | ​ |  | ​ |
| Weighted average common shares outstanding — basic and diluted | ​ | ​ | 142,878,406 | ​ | ​ | 10,443,323 |
| Net loss - basic and diluted | ​ | $ | (0.10) | ​ | $ | (1.32) |

[0001558370-22-008639:notes:211]
[same as prior period, unchanged from 0001558370-21-015999:notes:314]

[0001558370-22-008639:notes:212]
| ​ | ​ | Three Months Ended March 31, | ​ |
| ​ |  | 2022 |  | 2021 |  |
| Options issued and outstanding | ​ | 21,964,309 | ​ | 23,651,872 | ​ |
| Public Warrants to purchase common stock | ​ | 14,324,993 | ​ | — | ​ |
| Convertible preferred stock (as converted to common stock) | ​ | — | ​ | 80,833,007 | ​ |
| Warrants to purchase preferred stock (as converted to warrants to purchase common stock) | ​ | — | ​ | 1,014,963 | ​ |
| Warrants to purchase common stock | ​ | — | ​ | 922,297 | ​ |
| Warrants to purchase common stock (Finback)** | ​ | 2,552,913 | ​ | 2,552,913 | ​ |
| Unvested restricted stock units | ​ | 6,251,002 | ​ | 289,047 | ​ |
| Unvested performance stock units | ​ | 934,000 | ​ | — | ​ |
| Earn-out shares** | ​ | 15,000,000 | ​ | — | ​ |
| Contingently issuable common stock** | ​ | 1,897,500 | ​ | — | ​ |
| Convertible notes (as converted to common stock)* | ​ | — | ​ | 4,101,960 | ​ |
| ​ | ​ | 62,924,717 |  | 113,366,059 | ​ |

[0001558370-22-008639:notes:213]
* Conversion feature is only triggered upon the closing of a Qualified Financing Event.

[0001558370-22-008639:notes:214]
** Issuance of Earn-out shares, Contingently issuable common stock and Finback warrants are contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001558370-22-008639:notes:215]
19. Related Party Transactions

[0001558370-22-008639:notes:216]
Nonrecourse Promissory Note with Officer

[0001558370-22-008639:notes:217]
In August 2020, the Company entered into a $0.4 million promissory note with an officer with the proceeds being used to exercise options for 1,469,366 shares of common stock at a price of $0.24 per share. The promissory note bore interest at the Wall Street Journal Prime Rate and was secured by the underlying shares of common stock that were issued upon the exercise of the stock options. The promissory note was treated as nonrecourse as the loan was only secured by the common stock issued from the exercise of the stock options. As such, (i) the underlying stock option grant was still considered to be outstanding and the shares of common stock were not considered issued and outstanding for accounting purposes until the loan was repaid in full or otherwise forgiven and (ii) no receivable was recorded for the promissory note on the Company’s condensed consolidated balance sheets. As such, the promissory note effectively extended the maturity date of the option grant for the life of the loan, this change is treated as a stock option modification. The incremental fair value from the stock option modification was deemed immaterial. The interest on this nonrecourse loan is also considered nonrecourse. As the Company has no intent to collect interest, no accrued interest was recorded.

[0001558370-22-008639:notes:218]
In June 2021, the Company agreed to repurchase 43,665 shares of common stock valued at $8.05 per share of common stock held by the officer of the Company. In exchange for the repurchase of the common stock by the Company, the $0.4 million promissory note held by the officer was considered repaid in full.

[0001558370-22-008639:notes:219]
Business Development Agreement with Finback

[0001558370-22-008639:notes:220]
In March 2021, the Company granted a warrant exercisable for 2,552,913 shares of common stock to Finback, a consulting group who is an affiliate of one of the Company’s shareholders, with performance-based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years. During the three months ended March 31, 2022 and 2021, the Company recorded $0.4 million and $0.8 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.

[0001558370-22-008639:notes:221]
In connection with the Merger and pursuant to the Merger Agreement, Finback is entitled to receive a proportional share of earn-out shares as an earn-out service provider, based upon the remaining unvested warrants as of the Merger Date. As of March 31, 2022 Finback can earn 280,410 earn-out shares subject to stock-based compensation, based on the achievement of certain milestones. During the three months ended March 31, 2022 and 2021, the Company recorded $1.5 million and $0, respectively, of stock-based compensation expense within sales and marketing expense for the earn-out shares allocated to Finback.

[0001558370-22-008639:notes:222]
Original Equipment Manufacturer Partnership Agreement with Motorola

[0001558370-22-008639:notes:223]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement (the “Distribution Agreement”) with Motorola, an investor in the Company. In June 2021, the partnership agreement was amended by the Amended and Restated Distribution Agreement (the “Amended and Restated Distribution Agreement”). Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended March 31, 2022 and 2021, revenue from Motorola’s distributor services was $0.8 million and $0, respectively. As of March 31, 2022 and December 31, 2021, accounts receivable related to Motorola’s distributor services was $1.6 million and $1.2 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001558370-22-008639:notes:224]
20. Commitments and Contingencies

[0001558370-22-008639:notes:225]
Indemnification Agreements

[0001558370-22-008639:notes:226]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of March 31, 2022 or December 31, 2021.

[0001558370-22-008639:notes:227]
Legal Proceedings

[0001558370-22-008639:notes:228]
The Company is not a party to any litigation and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.
