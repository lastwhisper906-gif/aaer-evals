# EVLV note change history — 0001558370-21-015999 → 0001558370-22-008639


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-13):
[0001558370-22-008639:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of March 31, 2022 or December 31, 2021.
  (was, 2021-11-15, similarity 0.9571):
[0001558370-21-015999:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its consolidated financial statements as of September 30, 2021 or December 31, 2020.

- changed (2022-05-13):
[0001558370-22-008639:note_history:2]
The Company is not a party to any litigation and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.
  (was, 2021-11-15, similarity 0.8783):
[0001558370-21-015999:note_history:2]
The Company is not a party to any litigation and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses as incurred the costs related to such legal proceedings.

- removed (2022-05-13):
[0001558370-21-015999:note_history:3]
Operating Leases

- removed (2022-05-13):
[0001558370-21-015999:note_history:4]
The Company entered into a new lease agreement for additional office space starting May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. In May 2021, the Company leased the space. The Company is required to maintain a minimum cash balance of $0.7 million as a security deposit on the space which is classified as restricted cash, current and restricted cash, non-current on the consolidated balance sheet as of September 30, 2021. The Company is generally obligated for the cost of property taxes, insurance, and maintenance relating to this lease.

- removed (2022-05-13):
[0001558370-21-015999:note_history:5]
Total future minimum lease payments under this noncancelable operating lease amount to $3.4 million. Rent expense for the three months ended September 30, 2021 and 2020 was approximately $0.3 million and $0.1 million, respectively. Rent expense for the nine months ended September 30, 2021 and 2020 was approximately $0.7 million and $0.3 million, respectively.

- removed (2022-05-13):
[0001558370-21-015999:note_history:6]
Future minimum rental commitments to be paid by the Company at September 30, 2021 for this lease is as follows (in thousands):

- removed (2022-05-13):
[0001558370-21-015999:note_history:7]
| Year Ending December 31: | ​ |  | ​ |
| 2021 (remaining three months) | ​ | $ | 185 |
| 2022 | ​ | ​ | 1,116 |
| 2023 | ​ |  | 1,150 |
| 2024 | ​ |  | 981 |
| Total future minimum lease payments | ​ | $ | 3,432 |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-05-13):
[0001558370-22-008639:note_history:8]
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a global leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks in a cost-effective manner while improving the visitor experience. The Company is headquartered in Waltham, Massachusetts.

- added (2022-05-13):
[0001558370-22-008639:note_history:9]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC. References to “NHIC” refer to the company prior to the consummation of the Merger (as defined in Note 3) and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

- changed (2022-05-13):
[0001558370-22-008639:note_history:10]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).
  (was, 2021-11-15, similarity 0.9097):
[0001558370-21-015999:note_history:10]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly owned subsidiary in the United Kingdom, Evolv Technologies UK Ltd. and its wholly owned subsidiary Give Evolv LLC. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

- added (2022-05-13):
[0001558370-22-008639:note_history:11]
All share and per share amounts contained herein for periods prior to the Merger have been retroactively adjusted to give effect to the Exchange Ratio (as defined in Note 3), unless otherwise indicated.

- changed (2022-05-13):
[0001558370-22-008639:note_history:12]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2022, and for the three months ended March 31, 2022 and 2021 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2021 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2022 and the results of its operations for the three months ended March 31, 2022 and 2021 and cash flows for the three months ended March 31, 2022 and 2021. The results for the three months ended March 31, 2022 are not necessarily indicative of results to be expected for the year ending December 31, 2022, any other interim periods, or any future year or period.
  (was, 2021-11-15, similarity 0.6608):
[0001558370-21-015999:note_history:12]
The accompanying unaudited consolidated financial statements as of September 30, 2021, and for the three and nine months ended September 30, 2021 and 2020 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2020 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2021 and the results of its operations for the three and nine months ended September 30, 2021 and 2020 and cash flows for the nine months ended September 30, 2021 and 2020. The results for the three and nine months ended September 30, 2021 are not necessarily indicative of results to be expected for the year ending December 31, 2021, any other interim periods, or any future year or period.

- removed (2022-05-13):
[0001558370-21-015999:note_history:13]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of the Merger and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

- removed (2022-05-13):
[0001558370-21-015999:note_history:14]
Legacy Evolv was incorporated under the laws of the State of Delaware on July 8, 2013. The Company is the global leader in AI-based touchless security screening. The Company’s mission is to make the world a safer and more enjoyable place to live, work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to address the chronic epidemic of mass shootings and terrorist attacks in a cost-effective manner while improving the visitor experience. The Company is headquartered in Waltham, Massachusetts.

- removed (2022-05-13):
[0001558370-21-015999:note_history:15]
Merger with NewHold Investment Corp.

- removed (2022-05-13):
[0001558370-21-015999:note_history:16]
On July 16, 2021 (the “Closing Date”), the predecessor company, consummated the previously announced Merger with Legacy Evolv, pursuant to the Agreement and Plan of Merger dated as of March 5, 2021, and amended by the First Amendment to Agreement and Plan of Merger (the “Merger Agreement”), dated as of June 5, 2021. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. and the officers of NHIC, the predecessor company resigned. The officers of Legacy Evolv became the officers of the Company, and the Company listed its shares of common stock, par value $0.0001 per share, on Nasdaq under the symbol “EVLV” (see Note 3).

- removed (2022-05-13):
[0001558370-21-015999:note_history:17]
Subscription Agreement

- removed (2022-05-13):
[0001558370-21-015999:note_history:18]
Prior to the completion of the Merger, the Company entered into subscription agreements (collectively, the “PIPE Investment”) with certain parties subscribing for shares of the Company’s common stock (the “Subscribers”) pursuant to which the Subscribers agreed to purchase. Pursuant to the PIPE Investment, the Company issued 30,000,000 shares of Class A common stock for a purchase price of $10.00 per share with gross proceeds of $300.0 million.

- removed (2022-05-13):
[0001558370-21-015999:note_history:19]
Risks and uncertainties

- removed (2022-05-13):
[0001558370-21-015999:note_history:20]
The Company is subject to risks and uncertainties common to early-stage companies in the human security industry including, but not limited to, the successful development, commercialization, marketing and sale of existing and new products, fluctuations in operating results and financial risks, protection of proprietary knowledge and patent risks, dependence on key personnel, competition, technological risks, cybersecurity risks, customer demand and management of growth. Potential risks and uncertainties also include, without limitation, uncertainties regarding the duration and magnitude of the impact of the COVID-19 pandemic, including variants, on the Company’s business and the economy in general.

- removed (2022-05-13):
[0001558370-21-015999:note_history:21]
In March 2020, the World Health Organization declared the global novel coronavirus disease 2019 (“COVID-19”) outbreak a pandemic. The impact of this pandemic has been and will likely continue to be extensive in many aspects of society, which has resulted in and will likely continue to result in significant disruptions to the global economy, as well as businesses and capital markets around the world. The Company cannot at this time predict the ultimate extent, duration, or full impact that the COVID-19 pandemic will have on its future financial condition and operations. The impact of the COVID-19 pandemic  on the Company’s financial performance will depend on future developments, including the duration and spread of the pandemic, including variants, and related governmental advisories and restrictions, the progression and effectiveness of vaccination roll-outs, vaccine hesitancy, and the actions

- removed (2022-05-13):
[0001558370-21-015999:note_history:22]
taken to contain or treat COVID-19, as well as the economic impact on local, regional, national and international customers and markets. The situation surrounding COVID-19 remains fluid and the potential for a material impact on the Company increases the longer the virus impacts the level of economic activity in the United States and globally. Given the ongoing evolution of the COVID-19 and the global responses to curb its spread, the Company is not able to estimate the effects of the COVID-19 on its results of operations, financial condition, or liquidity for the year ending December 31, 2021 and beyond. If the financial markets and/or the overall economy are impacted for an extended period, the Company’s results may be materially adversely affected.

- removed (2022-05-13):
[0001558370-21-015999:note_history:23]
Future impacts to the Company’s business as a result of COVID-19 could include disruptions to the Company’s revenue caused by closures of customer operations, manufacturing operations and supply chain caused by facility closures, reductions in operating hours, staggered shifts and other social distancing efforts; labor shortages; decreased productivity and unavailability of materials or components; limitations on its employees’ and customers’ ability to travel, and delays in shipments to and from affected countries and within the United States. While the Company maintains an inventory of finished products and raw materials used in its products, a prolonged pandemic could lead to shortages in the raw materials necessary to manufacture its products.

- removed (2022-05-13):
[0001558370-21-015999:note_history:24]
Revision of Prior Period Financial Statements

- removed (2022-05-13):
[0001558370-21-015999:note_history:25]
During the year ended December 31, 2020, an error was identified by the Company related to the preferred stock warrant classification in prior periods. Specifically, the Company had misclassified these warrants for the purchase of shares of its preferred stock as equity for the period from September 2016 through December 2018 when these warrants should have been liability classified and changes to fair value recorded in the Statement of Operations, therefore retained earnings were understated for changes in fair value of the warrant over that period of time of liability classification. Upon the modified retrospective adoption of ASU No. 2018-07 Compensation - Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting and ASU No. 2019-08 Codification Improvements-Share-Based Consideration Payable to a Customer, on January 1, 2019, the warrants were classified within temporary equity. The Company concluded that the impacts of the error were not material to the consolidated financial statements as of and for the years ended December 31, 2020 and 2019. While not material, the Company has elected to revise the previously issued consolidated financial statements as of and for the years ended December 31, 2020 and 2019 for the impacts of the error. In addition, the applicable notes to the accompanying financial statements have also been revised to correct for these misstatements.

- removed (2022-05-13):
[0001558370-21-015999:note_history:26]
The following table (in thousands) reflects the impacts of the error on the consolidated financial statements and gives effect to the retrospective restatement to reflect the exchange ratio of 0.378 established in the Merger as described in Note 3.

- removed (2022-05-13):
[0001558370-21-015999:note_history:27]
| ​ |  | As of December 31, 2020 |  | As of December 31, 2019 |
| ​ | ​ | As previously | ​ | ​ | ​ | ​ | ​ | ​ | ​ | As previously | ​ | ​ | ​ | ​ | ​ | ​ |
| ​ | ​ | reported |  | Adjustment |  | Revised |  | reported |  | Adjustment |  | Revised |
| Convertible preferred stock | ​ | $ | 75,393 | ​ | $ | 484 | ​ | $ | 75,877 | ​ | $ | 72,399 | ​ | $ | 484 | ​ | $ | 72,883 |
| Additional paid-in capital | ​ | $ | 9,946 | ​ | $ | (752) | ​ | $ | 9,194 | ​ | $ | 8,730 | ​ | $ | (752) | ​ | $ | 7,978 |
| Accumulated deficit | ​ | $ | (94,149) | ​ | $ | 268 | ​ | $ | (93,881) | ​ | $ | (66,757) | ​ | $ | 268 | ​ | $ | (66,489) |
| Stockholders’ deficit | ​ | $ | (84,202) | ​ | $ | (484) | ​ | $ | (84,686) | ​ | $ | (58,026) | ​ | $ | (484) | ​ | $ | (58,510) |

- removed (2022-05-13):
[0001558370-21-015999:note_history:28]
Accordingly, these unaudited interim consolidated financial statements should be read in conjunction with the audited annual consolidated financial statements and notes thereto for the years ended December 31, 2020 and 2019 included in the Prospectus filed with the SEC on September 3, 2021 (the “Prospectus”).


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-05-13):
[0001558370-22-008639:note_history:29]
Significant Accounting Policies

- added (2022-05-13):
[0001558370-22-008639:note_history:30]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2021, and the notes thereto, which are included in our Annual Report on Form 10-K. There have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2022 outside of the items as described below.

- added (2022-05-13):
[0001558370-22-008639:note_history:31]
Leases as a Lessee

- added (2022-05-13):
[0001558370-22-008639:note_history:32]
Prior to January 1, 2022, the Company accounted for leases in accordance with ASC 840, Leases. At lease inception, the Company determined if an arrangement was an operating or capital lease. For operating leases, the Company recognized rent expense, inclusive of rent escalation, on a straight-line basis over the lease term.

- added (2022-05-13):
[0001558370-22-008639:note_history:33]
Effective on January 1, 2022, the Company accounts for leases in accordance with ASC 842, Leases. At contract inception, the Company determines if an arrangement is or contains a lease. A lease conveys the right to control the use of an identified asset for a period of time in exchange for consideration. If determined to be or contain a lease, the lease is assessed for classification as either an operating or finance lease at the lease commencement date, defined as the date on which the leased asset is made available for use by the Company (when the Company is the lessee). Where the Company is the lessee, for each lease with a term greater than twelve months, the Company records a right-of-use asset and lease liability.

- added (2022-05-13):
[0001558370-22-008639:note_history:34]
A right-of-use asset represents the economic benefit conveyed to the Company by the right to use the underlying asset over the lease term. A lease liability represents the obligation to make lease payments arising from the use of the asset over the lease term. Lease liabilities are measured at lease commencement and calculated as the present value of the future lease payments in the contract using the rate implicit in the contract, when available. If an implicit rate is not readily determinable, the Company uses an incremental borrowing rate measured as the rate at which the Company could borrow, on a fully collateralized basis, a commensurate loan in the same currency over a period consistent with the lease term at the commencement date. Right-of-use assets are measured as the amount of the initial lease liability plus initial direct costs and prepaid lease payments, less lease incentives granted by the lessor. The lease term is measured as the noncancelable period in the contract, adjusted for any options to extend or terminate when it is reasonably certain the Company will extend the lease term via such options based on an assessment of economic factors present as of the lease commencement date. The Company elected the practical expedient to not recognize leases with a lease term of twelve months or less.

- added (2022-05-13):
[0001558370-22-008639:note_history:35]
Components of a lease are split into three categories: lease components, non-lease components, and non-components. The fixed and in-substance fixed contract consideration (including any consideration related to non-components) are allocated, based on the respective relative fair values, to the lease components and non-lease components. The Company has elected the practical expedient to account for lease and non-lease components together as a single lease component for all underlying assets and allocate all of the contract consideration to the lease component only.

- added (2022-05-13):
[0001558370-22-008639:note_history:36]
The Company’s operating leases are presented in the condensed consolidated balance sheet as operating lease right-of-use assets, classified as noncurrent assets, and operating lease liabilities, classified as current and noncurrent liabilities. Operating lease expense is recognized on a straight-line basis over the lease term. Variable costs associated with a lease, such as maintenance and utilities, are not included in the measurement of the lease liabilities and right-of-use assets but rather are expensed when the events determining the amount of variable consideration to be paid have occurred.

- changed (2022-05-13):
[0001558370-22-008639:note_history:37]
Subscription Revenue - Leases as Lessor
  (was, 2021-11-15, similarity 0.678):
[0001558370-21-015999:note_history:37]
Subscription Revenue

- added (2022-05-13):
[0001558370-22-008639:note_history:38]
In addition to selling our products directly to customers, we also derive revenue from leasing our equipment, which we classify as subscription revenue. Lease terms are typically four years, do not include options to extend, terminate or to purchase the underlying asset, and customers generally pay either a quarterly or annual fixed payment for the lease and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as they do not meet any of the sales-type lease criteria per ASC 842 and recognized ratably over the duration of the lease. There are no variable lease payments as a part of these arrangements.

- added (2022-05-13):
[0001558370-22-008639:note_history:39]
The accounting provisions we use to classify transactions as sales-type are: (i) whether the lease transfers ownership of the equipment by the end of the lease term, (ii) whether the lease grants the customer an option to purchase the equipment and the customer is reasonably certain to do so, (iii) whether the lease term is for the major part of the economic life of the underlying equipment,  (iv) whether the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments,  is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (v) whether the equipment is specific to the customer and of such a specialized nature that it is expected to have no alternative use to the Company at the end of

- added (2022-05-13):
[0001558370-22-008639:note_history:40]
the lease term. Leasing arrangements meeting any of these conditions are accounted for as sales-type leases and revenue attributable to the lease component is recognized in a manner consistent with the equipment sales and the related equipment is derecognized with the associated expense presented as a cost of revenue. Leasing arrangements that do not meet the criteria for classification as a sales-type lease will be accounted for as a direct-financing lease if the following two conditions are met: (i) the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments and any other third party unrelated to the Company, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (ii) it is probable that the Company will collect the lease payments and amounts necessary to satisfy a residual value guarantee. Leasing arrangements that do not meet any of the sales-type lease classification criteria are accounted for as operating leases and revenue is recognized straight-line over the term of the lease.

- added (2022-05-13):
[0001558370-22-008639:note_history:41]
The Company considers the economic life of most of our products to be seven years. The Company believes seven years is representative of the period during which the equipment is expected to be economically usable by one or more users, with normal service, for the purpose for which it is intended. The unguaranteed residual value is estimated to be the value at the end of the lease term based on the anticipated fair market value of the units. The Company mitigates residual value risk of our leased equipment by performing regular management and maintenance, as necessary.

- added (2022-05-13):
[0001558370-22-008639:note_history:42]
Generally, lease arrangements include both lease and non-lease components. The lease component relates to the customer’s right-to-use the equipment over the lease term. The non-lease components relate to (1) distinct services, such as SaaS and maintenance, (2) any add-on accessories, and (3) installation and training. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the Company elected the practical expedient to aggregate non-lease components with the associated lease component and account for the combined component as an operating lease for all underlying asset classes. In the evaluation of whether the lease component (equipment) or the non-lease components associated with the lease component (SaaS and maintenance) is the predominant  component, the Company determined that the lease component is predominant as customers would clearly be expected to ascribe more value to the use of the security equipment than that of the SaaS and maintenance services. Therefore, the Company will account for the combined lease component under ASC 842. The equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in the condensed consolidated statements of operations and comprehensive loss. The installation and training services represent distinct services provided to customers. These activities are considered separate performance obligations to the customer and therefore are considered non-lease components. As installation and training services are performed prior to lease commencement, the timing and pattern of transfer for these services differ from that of the lease component (i.e., security hardware) and are not eligible to be combined.

- added (2022-05-13):
[0001558370-22-008639:note_history:43]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party. Revenue related to leases entered into with related parties were $0.1 million during the three months ended March 31, 2022.

- added (2022-05-13):
[0001558370-22-008639:note_history:44]
Installation and training are generally billed to the lessee as part of the lease contract billing, according to various contractual terms. The installation and training costs incurred by the Company are accounted for as a fulfillment cost and are included in the cost of services revenue in the condensed consolidated statements of operations and comprehensive loss.

- added (2022-05-13):
[0001558370-22-008639:note_history:45]
Recently Adopted Accounting Pronouncements

- added (2022-05-13):
[0001558370-22-008639:note_history:46]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), as subsequently amended (collectively “ASC 842”). The guidance amends the existing accounting standards for lease accounting, including requirements for lessees to recognize assets and liabilities related to long-term leases on the balance sheet and expanding disclosure requirements regarding leasing arrangements. For lessees, leases will be classified as finance or operating, with classification affecting the pattern and classification of expense recognition in the income statement. Lessors are required to classify leases as a sales-type, direct financing, or operating lease. A lease is a sales-type lease if it effectively transfers control of the underlying asset to the lessee as indicated by any one of five criteria being met. All leases that are not sales-type or direct financing leases will be classified as operating leases. In July 2018, the FASB issued additional guidance, which offers a transition option to entities adopting ASC 842 in which entities can elect to

- added (2022-05-13):
[0001558370-22-008639:note_history:47]
apply the new guidance using a modified retrospective approach at the beginning of the year in which the new lease standard is adopted. The Company utilized this transition option whereby financial information for prior periods presented before the ASC 842 effective date will not be updated. In November 2019, the FASB issued ASU 2019-10 deferring the effective date for private entities (also applicable for public companies that qualify as emerging growth companies) for fiscal years beginning after December 15, 2020, and interim periods within fiscal years beginning after December 15, 2021. In June 2020, the FASB issued ASU 2020-05 which further defers the effective date for private entities for fiscal years beginning after December 15, 2021, and interim periods within fiscal years beginning after December 15, 2022.

- added (2022-05-13):
[0001558370-22-008639:note_history:48]
The Company adopted this guidance effective January 1, 2022. ASC 842 provides several optional practical expedients in transition. The Company applied the ‘package of practical expedients’ which allow the Company to not reassess whether existing or expired arrangements contain a lease, the lease classification of existing or expired leases, or whether previous initial direct costs would qualify for capitalization under ASC 842.

- added (2022-05-13):
[0001558370-22-008639:note_history:49]
The adoption of ASC 842 resulted in the recognition of operating lease liabilities of $3.0 million and operating right-of-use assets of $2.5 million, along with the write-off of certain deferred rent balances of $0.5 million within the Company’s condensed consolidated balance sheets as of January 1, 2022. The adoption did not have a significant impact on the Company’s condensed consolidated statements of operations and comprehensive loss and condensed consolidated statements of cash flows.

- changed (2022-05-13):
[0001558370-22-008639:note_history:50]
In December 2019, the FASB issued ASU 2019 12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019 12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.
  (was, 2021-11-15, similarity 0.9188):
[0001558370-21-015999:note_history:50]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company expects to adopt this guidance effective January 1, 2022, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

- changed (2022-05-13):
[0001558370-22-008639:note_history:51]
In August 2020, the FASB issued ASU 2020-06, “Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity,” which simplifies and clarifies certain calculation and presentation matters related to convertible and equity and debt instruments. Specifically, ASU 2020-06 removes requirements to separately account for conversion features as a derivative under ASC Topic 815 and removing the requirement to account for beneficial conversion features on such instruments. ASU 2020-06 also provides clearer guidance surrounding disclosure of such instruments and provides specific guidance for how such instruments are to be incorporated in the calculation of Diluted EPS. The guidance under ASU 2020-06 is effective for fiscal years beginning after December 15, 2021, including interim periods within those fiscal years. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.
  (was, 2021-11-15, similarity 0.9333):
[0001558370-21-015999:note_history:51]
In August 2020, the FASB issued ASU 2020-06, “Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity,” which simplifies and clarifies certain calculation and presentation matters related to convertible and equity and debt instruments. Specifically, ASU 2020-06 removes requirements to separately account for conversion features as a derivative under ASC Topic 815 and removing the requirement to account for beneficial conversion features on such instruments. ASU 2020-06 also provides clearer guidance surrounding disclosure of such instruments and provides specific guidance for how such instruments are to be incorporated in the calculation of Diluted EPS. The guidance under ASU 2020-06 is effective for fiscal years beginning after December 15, 2021, including interim periods within those fiscal years. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020. The Company expects to adopt this guidance effective January 1, 2022, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

- changed (2022-05-13):
[0001558370-22-008639:note_history:52]
The Company qualifies as an “emerging growth company” as defined in the Jumpstart Our Business Startups Act of 2012 and has elected not to “opt out” to the extended transition related to complying with new or revised accounting standards, which means that when a standard is issued or revised and it has different application dates for public and nonpublic companies, the Company will adopt the new or revised standard at the time nonpublic companies adopt the new or revised standard and will do so until such time that the Company either (1) irrevocably elects to “opt out” of such extended transition period or (2) no longer qualifies as an emerging growth company. The Company may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for nonpublic companies.
  (was, 2021-11-15, similarity 0.9969):
[0001558370-21-015999:note_history:52]
The Company qualifies as an “emerging growth company” as defined in the Jumpstart Our Business Startups Act of 2012 and has elected not to “opt out” to the extended transition related to complying with new or revised accounting standards, which means that when a standard is issued or revised and it has different application dates for public and nonpublic companies, the Company will adopt the new or revised standard at the time nonpublic companies adopt the new or revised standard and will do so until such time that the Company either (i) irrevocably elects to “opt out” of such extended transition period or (ii) no longer qualifies as an emerging growth company. The Company may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for nonpublic companies.

- changed (2022-05-13):
[0001558370-22-008639:note_history:53]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its condensed consolidated financial statements and related disclosures.
  (was, 2021-11-15, similarity 0.9959):
[0001558370-21-015999:note_history:53]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

- changed (2022-05-13):
[0001558370-22-008639:note_history:54]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its condensed consolidated financial statements and related disclosures.
  (was, 2021-11-15, similarity 0.9951):
[0001558370-21-015999:note_history:54]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

- added (2022-05-13):
[0001558370-22-008639:note_history:55]
Out-of-Period Adjustment

- added (2022-05-13):
[0001558370-22-008639:note_history:56]
During the three months ended March 31, 2022, the Company recorded an immaterial out-of-period adjustment that resulted in a $1.0 million increase of stock-based compensation expense within sales and marketing expense in the condensed statements of operations and comprehensive loss, a $1.0 million increase to change in fair value of contingent earn-out liability in the condensed statements of operations and comprehensive loss, a $0.5 million decrease to additional paid-in capital in the condensed balance sheets, and a $0.5 million increase to contingent earn-out liability in the condensed balance sheets. The out-of-period adjustment related to an error in the Company’s accounting for the contingent earn-out liability for the third and fourth quarters of fiscal year 2021. The Company has determined the adjustment is not material to the current period or any previously issued financial statements.

- removed (2022-05-13):
[0001558370-21-015999:note_history:57]
Use of Estimates

- removed (2022-05-13):
[0001558370-21-015999:note_history:58]
The preparation of the Company’s consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the reporting periods. Significant estimates and assumptions reflected in these consolidated financial statements include but are not limited to calculating the standalone selling price for revenue recognition, the valuation of inventory, the valuation of derivative liability, the valuation of common stock for the periods prior to the Company listing its shares on Nasdaq, stock-based awards, the valuation of the preferred stock warrant liability, the valuation of the contingent earn-out liability and the valuation of the contingently issuable common stock. The Company bases its estimates on historical experience, known trends and other market-specific or other relevant factors that it believes to be reasonable under the circumstances. On an ongoing basis, management evaluates its estimates when there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results could differ from those estimates.

- removed (2022-05-13):
[0001558370-21-015999:note_history:59]
Due to the COVID-19 pandemic, there has been uncertainty and disruption in the global economy and financial markets. The full extent to which the COVID-19 pandemic will directly or indirectly impact the Company’s business, results of operations and financial condition, including revenues and expenses, will depend on future developments that are highly uncertain, including as a result of new information that may emerge concerning COVID-19 and the actions taken to contain it or treat COVID-19. Management has made estimates of the impact of COVID-19 within the Company’s consolidated financial statements and there may be changes to those estimates in future periods. These

- removed (2022-05-13):
[0001558370-21-015999:note_history:60]
estimates may change, as new events occur, and additional information is obtained. On an ongoing basis, management evaluates its estimates as there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results may differ from those estimates or assumptions.

- removed (2022-05-13):
[0001558370-21-015999:note_history:61]
Risk of Concentrations of Credit, Significant Customers and Significant Suppliers

- removed (2022-05-13):
[0001558370-21-015999:note_history:62]
Financial instruments that potentially expose the Company to concentrations of credit risk consist primarily of cash and cash equivalents, restricted cash, and accounts receivable, net. Periodically, the Company maintains deposits in accredited financial institutions in excess of federally insured limits. The Company maintains its cash, cash equivalents and restricted cash with financial institutions that management believes to be of high credit quality. The Company has not experienced any losses on such accounts and does not believe it is exposed to any unusual credit risk beyond the normal credit risk associated with commercial banking relationships.

- removed (2022-05-13):
[0001558370-21-015999:note_history:63]
Significant customers are those which represent more than 10% of the Company’s total revenue or accounts receivable, net balance at each respective balance sheet date. The following table presents customers that represent 10% or more of the Company’s total revenue:

- removed (2022-05-13):
[0001558370-21-015999:note_history:64]
| ​ |  | Three Months Ended |  | ​ | Nine Months Ended |  | ​ |
| ​ | ​ | September 30, | ​ | ​ | September 30, | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 |  | ​ | 2021 | ​ | 2020 |  | ​ |
| Customer A |  | — | ​ | 20.0 | % | ​ | — | ​ | 11.0 | % | ​ |
| Customer B |  | 21.2 | % | — | ​ | ​ | 10.0 | % | — | ​ | ​ |
| ​ |  | 21.2 | % | 20.0 | % | ​ | 10.0 | % | 11.0 | % | ​ |

- removed (2022-05-13):
[0001558370-21-015999:note_history:65]
Customer A revenue is from subscriptions and Customer B revenue is from product revenue.

- removed (2022-05-13):
[0001558370-21-015999:note_history:66]
The following table presents customers that represent 10% or more of the Company’s accounts receivable, net:

- removed (2022-05-13):
[0001558370-21-015999:note_history:67]
| ​ |  | September 30, | ​ | December 31, |  | ​ |
| ​ | ​ | 2021 | ​ | 2020 |  | ​ |
| Customer B |  | 16.0 | % | — | ​ | ​ |
| Customer C |  | — | ​ | 28.3 | % | ​ |
| Customer D |  | — | ​ | 23.4 | % | ​ |
| ​ |  | 16.0 | % | 51.7 | % | ​ |

- removed (2022-05-13):
[0001558370-21-015999:note_history:68]
The Company relies on third parties for the supply and manufacture of its products as well as third-party logistics providers. In instances where these parties fail to perform their obligations, the Company may be unable to find alternative suppliers to satisfactorily deliver its products to its customers on time, if at all, which could have a material adverse effect on the Company’s operating results, financial condition and cash flows and damage its customer relationships.

- removed (2022-05-13):
[0001558370-21-015999:note_history:69]
Debt Issuance Costs

- removed (2022-05-13):
[0001558370-21-015999:note_history:70]
The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated debt on the consolidated balance sheet and amortized as interest expense on the consolidated statement of operations and comprehensive loss using the effective interest method. As of September 30, 2021, and December 31, 2020, debt issuance costs totaled $0.1 million and $0.1 million, respectively, and were recorded as a reduction in the carrying amount of long-term debt in the consolidated balance sheets. During the three months ended September 30, 2021 and 2020, and nine months ended September 30, 2021 and 2020, the Company recorded less than $0.1 million in

- removed (2022-05-13):
[0001558370-21-015999:note_history:71]
amortization of the debt issuance costs recorded within interest expense in the consolidated statement of operations and comprehensive income (loss).

- removed (2022-05-13):
[0001558370-21-015999:note_history:72]
Cash, Cash Equivalents, and Restricted Cash

- removed (2022-05-13):
[0001558370-21-015999:note_history:73]
Cash, cash equivalents, and restricted cash as reported on the consolidated statement of cash flows consists of the following (in thousands):

- removed (2022-05-13):
[0001558370-21-015999:note_history:74]
| ​ |  | September 30, | ​ | December 31, |
| ​ | ​ | 2021 | ​ | 2020 |
| Cash and cash equivalents |  | $ | 333,747 | ​ | $ | 4,704 |
| Restricted cash |  | ​ | 675 | ​ | ​ | — |
| Total cash, cash equivalents, and restricted cash |  | $ | 334,422 | ​ | $ | 4,704 |

- removed (2022-05-13):
[0001558370-21-015999:note_history:75]
The Company considers all short-term, highly liquid investments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents. Restricted cash consists of a security deposit on the Company’s new office lease in Waltham, Massachusetts, with $0.4 million included in the current portion of restricted cash which will be returned during the first half of 2022, and $0.3 million included in restricted cash, noncurrent in the consolidated balance sheets.

- removed (2022-05-13):
[0001558370-21-015999:note_history:76]
Property and Equipment

- removed (2022-05-13):
[0001558370-21-015999:note_history:77]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization expense is recognized using the straight-line method over the estimated useful life of each asset, as follows:

- removed (2022-05-13):
[0001558370-21-015999:note_history:78]
| ​ |  | Estimated Useful Life |
| Computers and telecommunications equipment |  | 3 years |
| Lab equipment |  | 5 years |
| Software |  | 4 years |
| Furniture and fixtures |  | 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |
| Leased equipment |  | 4-7 years |

- removed (2022-05-13):
[0001558370-21-015999:note_history:79]
Estimated useful lives are periodically assessed to determine if changes are appropriate. Leasehold improvements are amortized using the straight-line method over the lesser of the lease term or its estimated economic useful life. Lease terms are used based upon the initial lease agreement and do not consider potential renewals or extensions until such time that the renewals or extensions are contracted. Maintenance and repairs are charged to expense as incurred. When assets are retired or otherwise disposed of, the cost of these assets and related accumulated depreciation or amortization are eliminated from the consolidated balance sheet and any resulting gains or losses are included in the consolidated statement of operations and comprehensive income (loss) in the period of disposal. Costs for capital assets not yet placed into service are capitalized as construction-in-progress and depreciated once placed into service.

- removed (2022-05-13):
[0001558370-21-015999:note_history:80]
The Company’s leases for leased equipment generally are 48 months. The Company’s subscription contracts are classified as operating leases because title does not transfer and they do not meet any of the other criteria per ASC 840. To date, the Company has not had any subscription arrangements come up for renewal and will reassess the classification of any such leases upon renewal.

- removed (2022-05-13):
[0001558370-21-015999:note_history:81]
The Company evaluates leased equipment for obsolescence and impairment whenever circumstances indicate that the carrying value of such equipment is not recoverable by considering any (1) reduced demand in the markets in

- removed (2022-05-13):
[0001558370-21-015999:note_history:82]
which the Company operate, (2) technological obsolescence due to developments of new products and improvements, or (3) changes in economic or other events and conditions that impact the market price for the Company’s products. Based on the Company’s evaluations, an impairment loss on property and equipment of $1.7 million was recorded during the three and nine months ended September 30, 2021. This was related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of these assets and resulted in impairment.

- removed (2022-05-13):
[0001558370-21-015999:note_history:83]
Contingent Earn-out

- removed (2022-05-13):
[0001558370-21-015999:note_history:84]
In connection with the Merger and pursuant to the Merger Agreement, certain of the Legacy Evolv’s shareholders and Legacy Evolv service providers are entitled to receive additional shares of the Company’s Class A common stock (the “Earn-Out Shares”) upon the Company achieving certain milestones:

- removed (2022-05-13):
[0001558370-21-015999:note_history:85]
|  | ● | Triggering Event I – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s Class A common stock is greater than $12.50 per share for any 20 trading days within any 30 trading day period. |

- removed (2022-05-13):
[0001558370-21-015999:note_history:86]
|  | ● | Triggering Event II – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s Class A common stock is greater than $15.00 per share for any 20 trading days within any 30 trading day period. |

- removed (2022-05-13):
[0001558370-21-015999:note_history:87]
|  | ● | Triggering Event III – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s Class A common stock is greater than $17.50 per share for any 20 trading days within any 30 trading day period. |

- removed (2022-05-13):
[0001558370-21-015999:note_history:88]
In accordance with ASC 815 – Derivatives and Hedging, the earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a change in fair value of contingent earn-out liability in other income (expense), net in the consolidated statements of operations and comprehensive income (loss). When the Triggering Events have been achieved and the Earn-Out Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share. Of the total 15,000,000 earn-out shares, 12,137,397 earn-out shares are with the Legacy Evolv shareholders.

- removed (2022-05-13):
[0001558370-21-015999:note_history:89]
The estimated fair value of the contingent earn-out shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, drift rate, percentage of change in control and expected term.

- removed (2022-05-13):
[0001558370-21-015999:note_history:90]
The contingent earn-out liability is categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingent earn-out payments involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

- removed (2022-05-13):
[0001558370-21-015999:note_history:91]
The Earn-Out Shares issued to employees, officers, directors, and non-employees are based achievement of certain target share price contingencies and for the employees and officers, subject to continued employment, (the “Earn-Out Service Providers”) represents share-based compensation and is classified as equity on the Company’s balance

- removed (2022-05-13):
[0001558370-21-015999:note_history:92]
sheet. Corresponding stock-based compensation expense is recorded in the consolidated statements of operations and comprehensive income (loss) in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. Of the total 15,000,000 earn-out shares, 2,862,603 earn-out shares are with the Legacy Evolv service providers and subject to share-based compensation.

- removed (2022-05-13):
[0001558370-21-015999:note_history:93]
Contingently Issuable Common Stock

- removed (2022-05-13):
[0001558370-21-015999:note_history:94]
Prior to the Merger, NewHold Industrial Technology Holdings, LLC, the sponsor of the NHIC special purpose acquisition company owned 4,312,500 shares of NHIC Class B common stock (the “Founder Shares). Upon the closing of the merger, NHIC Class A and Class B common stock became the Company’s common stock. The Founder Shares outstanding were subject to certain share-performance-based vesting provisions as follows:

- removed (2022-05-13):
[0001558370-21-015999:note_history:95]
|  | ● | Vesting Provision I - 1,897,500 shares of the Company’s common stock shall vest and no longer be subject to forfeiture as of the Merger; |

- removed (2022-05-13):
[0001558370-21-015999:note_history:96]
|  | ● | Vesting Provision II - if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $12.50 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30 trading day period, then 948,750 shares of the Company’s common stock shall vest and no longer be subject to forfeiture; |

- removed (2022-05-13):
[0001558370-21-015999:note_history:97]
|  | ● | Vesting Provision III - if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $15.00 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30-trading day period, then 948,750 shares of the Company’s common stock) shall vest and no longer be subject to forfeiture; |

- removed (2022-05-13):
[0001558370-21-015999:note_history:98]
The remaining 517,500 Founder Shares were contributed to Give Evolv LLC.

- removed (2022-05-13):
[0001558370-21-015999:note_history:99]
If Vesting Provision II and/or Vesting Provision III are not satisfied, the corresponding number of shares specified shall be forfeited and no longer issued and outstanding. If there is a Change of Control event prior to Vesting Provision II and/or Vesting Provision III are satisfied, the Founder shares are no longer subject to forfeiture and shall vest immediately upon the occurrence of a Change of Control event.

- removed (2022-05-13):
[0001558370-21-015999:note_history:100]
In accordance with ASC 815 – Derivatives and Hedging, the contingently issuable common stock is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as change in fair value of contingently issuable common stock liability in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Vesting Provisions have been achieved and the contingently issuable common shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

- removed (2022-05-13):
[0001558370-21-015999:note_history:101]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, and risk-free rate.

- removed (2022-05-13):
[0001558370-21-015999:note_history:102]
The contingently issuable common shares are categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various

- removed (2022-05-13):
[0001558370-21-015999:note_history:103]
potential pay-out scenarios. Contingently issuable shares involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

- removed (2022-05-13):
[0001558370-21-015999:note_history:104]
Impairment of Long-Lived Assets

- removed (2022-05-13):
[0001558370-21-015999:note_history:105]
Long-lived assets consist of property and equipment. Long-lived assets to be held and used are tested for recoverability whenever events or changes in business circumstances indicate that the carrying amount of the assets may not be fully recoverable. Factors that the Company considers in deciding when to perform an impairment review include significant underperformance of the business in relation to expectations, significant negative industry or economic trends and significant changes or planned changes in the use of the assets. If an impairment review is performed to evaluate a long-lived asset group for recoverability, the Company compares forecasts of undiscounted cash flows expected to result from the use and eventual disposition of the long-lived asset group to its carrying value. An impairment loss would be recognized in loss from operations when estimated undiscounted future cash flows expected to result from the use of an asset group are less than its carrying amount. The impairment loss is based on the excess of the carrying value of the impaired asset group over its fair value, determined based on discounted cash flows. The Company recorded a $1.7 million impairment loss on long-lived assets during the three and nine months ended September 30, 2021. This was related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of these assets and resulted in impairment. The Company did not record any impairment losses on long-lived assets during the three and nine months ended September 30, 2020.

- removed (2022-05-13):
[0001558370-21-015999:note_history:106]
Fair Value Measurements of Financial Instruments

- removed (2022-05-13):
[0001558370-21-015999:note_history:107]
Certain assets and liabilities of the Company are carried at fair value under GAAP. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. Valuation techniques used to measure fair value must maximize the use of observable inputs and minimize the use of unobservable inputs. Financial assets and liabilities carried at fair value are to be classified and disclosed in one of the following three levels of the fair value hierarchy, of which the first two are considered observable and the last is considered unobservable:

- removed (2022-05-13):
[0001558370-21-015999:note_history:108]
|  | ● | Level 1 — Quoted prices in active markets for identical assets or liabilities. |

- removed (2022-05-13):
[0001558370-21-015999:note_history:109]
|  | ● | Level 2 — Observable inputs (other than Level 1 quoted prices), such as quoted prices in active markets for similar assets or liabilities, quoted prices in markets that are not active for identical or similar assets or liabilities, or other inputs that are observable or can be corroborated by observable market data. |

- removed (2022-05-13):
[0001558370-21-015999:note_history:110]
|  | ● | Level 3 — Unobservable inputs that are supported by little or no market activity that are significant to determining the fair value of the assets or liabilities, including pricing models, discounted cash flow methodologies and similar techniques. |

- removed (2022-05-13):
[0001558370-21-015999:note_history:111]
The Company’s cash equivalents, derivative liability, contingent earn-out liability, contingently issuable common stock liability and its common stock warrant liability are carried at fair value, determined according to the fair value hierarchy described above (see Note 4). The carrying values of the Company’s accounts receivable, net, accounts payable and accrued expenses approximate their fair values due to the short-term nature of these assets and liabilities. The carrying value of the Company’s long-term debt approximates its fair value (a Level 2 measurement) at each balance sheet date due to its variable interest rate, which approximates a market interest rate.

- removed (2022-05-13):
[0001558370-21-015999:note_history:112]
Assets that are measured at fair value on a nonrecurring basis primarily relate to property and equipment. We do not periodically adjust carrying value to fair value for property and equipment. Rather, the carrying value of the asset is reduced to its fair value when we determine that impairment has occurred. During the three and nine months ended September 30, 2021, impairment of property and equipment was $1.7 million, respectively. This was related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of these assets and resulted in impairment. There was no impairment for the three and nine months ended September 30, 2020.

- removed (2022-05-13):
[0001558370-21-015999:note_history:113]
Derivative Liability Related to Convertible Notes

- removed (2022-05-13):
[0001558370-21-015999:note_history:114]
In August through September 2019 and in September through December 2020, the Company issued Convertible Notes to several investors (see Note 9) that provided a conversion option whereby upon the closing of a specified financing event the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 85% and 80%, respectively, of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative that was required to be bifurcated and accounted for separately from the notes. The derivative liability was initially recorded at fair value upon issuance of the notes and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the derivative liability are recognized in the consolidated statements of operations and comprehensive income (loss). In October 2019, the specified financing event was consummated, as such the Convertible Notes issued August through September 2019 were converted into shares of Series B-1 Preferred Stock (see Note 10), and the derivative liability was extinguished. The derivative liability related to the 2020 convertible note is outstanding as of December 31, 2020 and is included as a derivative liability in the consolidated balance sheets.

- removed (2022-05-13):
[0001558370-21-015999:note_history:115]
Between January 21, 2021 and February 4, 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes,” and together with the 2020 Convertible Notes, the “Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability and current portion of long-term debt on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method.

- removed (2022-05-13):
[0001558370-21-015999:note_history:116]
On June 21, 2021, the Company and the holders of the 2021 Convertible Notes agreed that, in connection with the Merger, such holders would receive an additional 1,000,000 shares of NHIC common stock as further consideration for the automatic conversion of such notes upon closing of the Merger. This modification of the 2021 Convertible Notes resulted in an extinguishment, and recognition of a derivative liability, which represents both the value of the 1,000,000 NHIC shares as of June 21, 2021 as well as a bifurcated embedded derivative for conversion into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors.

- removed (2022-05-13):
[0001558370-21-015999:note_history:117]
Upon the closing of the Merger, the September through December 2020 Convertible Notes and the 2021 Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on

- removed (2022-05-13):
[0001558370-21-015999:note_history:118]
extinguishment of debt of $0.9 million recorded in other income (expense) in the consolidated statements of operations and comprehensive income (loss).

- removed (2022-05-13):
[0001558370-21-015999:note_history:119]
Classification of Convertible Preferred Stock

- removed (2022-05-13):
[0001558370-21-015999:note_history:120]
Prior to the closing of the Merger, the holders of Legacy Evolv Series A, Series A-1, Series B and Series B-1 convertible preferred stock had certain liquidation rights in the event of a deemed liquidation event that, in certain situations, is not solely within the control of the Company and would call for the redemption of the then outstanding Series A, Series A-1, Series B and Series B-1 convertible preferred stock (see Note 10). Therefore, the Legacy Evolv Series A, Series A-1, Series B and Series B-1 convertible preferred stock were classified outside of stockholders’ equity (deficit) on the consolidated balance sheets.

- removed (2022-05-13):
[0001558370-21-015999:note_history:121]
In connection with the closing of the Merger, all shares of redeemable convertible Preferred Stock were converted into shares of the Company’s common stock. Accordingly, there was no redeemable convertible preferred stock outstanding as of September 30, 2021. As of December 31, 2020, the carrying value of the redeemable convertible Preferred Stock was $75.9 million (see Note 10).

- removed (2022-05-13):
[0001558370-21-015999:note_history:122]
Common Stock Warrant Liability and Public Warrant Liability

- removed (2022-05-13):
[0001558370-21-015999:note_history:123]
The Company classifies certain warrants for the purchase of shares of its common stock (see Note 11) as a liability on its consolidated balance sheets as these warrants are freestanding financial instruments that may require the Company to adjust the exercise price and number of shares that is not consistent with a fixed-for-fixed option pricing model. The warrant liability is initially recorded at fair value on the issuance date of each warrant and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the common stock warrant liability are recognized as a component of other income (expense), net in the consolidated statements of operations and comprehensive income (loss). Changes in the fair value of the common stock warrant liability are recognized until the warrants are exercised, expire or qualify for equity classification.

- removed (2022-05-13):
[0001558370-21-015999:note_history:124]
In connection with the closing of the Merger, the Company assumed warrants to purchase shares of common stock (the “Public Warrant”) and are classified as a liability pursuant to ASC 815 – Derivatives and Hedging as the equity derivative scope exception was not met. As of September 30, 2021, the Public Warrant is outstanding (see Note 11). All other warrants that were issued prior to the closing of the Merger were converted into shares of the Company’s common stock (the “common stock warrant”) upon the closing of the Merger. Accordingly, the Company remeasured the warrants to fair value upon the closing of Merger with the offset to additional paid-in capital (see Note 11).

- removed (2022-05-13):
[0001558370-21-015999:note_history:125]
Equity Classified Preferred Stock Warrants

- removed (2022-05-13):
[0001558370-21-015999:note_history:126]
The Company classifies warrants for the purchase of shares of its preferred stock (see Note 11) as temporary equity on its consolidated balance sheets. In connection with a customer development agreement, the Company issued preferred stock warrants to a customer to purchase shares of its Legacy Evolv Series A-1 Preferred Stock. Upon adoption of ASU No. 2018-07 and ASU No. 2019-08 on January 1, 2019, any liability classified warrants issued to non-employees for goods or services were reclassified to temporary equity.

- removed (2022-05-13):
[0001558370-21-015999:note_history:127]
In connection with the closing of the Merger, all preferred stock warrants to purchase shares of common stock were converted into shares of the Company’s common stock. Accordingly, there were no preferred stock warrants outstanding as of September 30, 2021. The Company assessed the features of these warrants and determined that they qualify for classification as permanent equity.

- removed (2022-05-13):
[0001558370-21-015999:note_history:128]
Equity Classified Common Stock Warrants

- removed (2022-05-13):
[0001558370-21-015999:note_history:129]
The Company classifies certain warrants for the purchase of shares of its common stock (see Note 11) as equity on its consolidated balance sheets as these warrants are considered to meet the derivative scope exception for freestanding equity contracts. For these warrants that are classified on the Company’s consolidated balance sheets as equity instruments, the Company uses the Black-Scholes model to measure the value of the warrants at issuance.

- removed (2022-05-13):
[0001558370-21-015999:note_history:130]
In connection with the closing of the Merger, all outstanding Legacy Evolv vested warrants to purchase shares of common stock were converted into shares of the Company’s common stock.

- removed (2022-05-13):
[0001558370-21-015999:note_history:131]
Revenue Recognition

- removed (2022-05-13):
[0001558370-21-015999:note_history:132]
The Company recognizes revenue in accordance with ASC 606. Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

- removed (2022-05-13):
[0001558370-21-015999:note_history:133]
The Company derives revenue from (1) subscription arrangements accounted for as operating leases under ASC 840 and (2) from the sale of products, inclusive of maintenance and services. The Company’s arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

- removed (2022-05-13):
[0001558370-21-015999:note_history:134]
Product Revenue

- removed (2022-05-13):
[0001558370-21-015999:note_history:135]
The Company derives revenue from the sale of its Express and Edge equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer. Transfer of control occurs when the Company has transferred title and risk of loss and has a present right to payment for the equipment, which is generally upon delivery as the Company’s normal terms of sale are freight on board destination. Products are predominately sold with distinct services, which are described in the services section below.

- removed (2022-05-13):
[0001558370-21-015999:note_history:136]
In addition to selling its products directly to customers, the Company also leases Express and Edge equipment. These arrangements convey the right to use the equipment for a period of time in exchange for consideration and therefore are accounted for under ASC 840 due to the scope exception of ASC 606-10-15-2. Lease terms are typically four years and customers pay quarterly or annual fixed payments for the lease and maintenance elements over the contractual lease term. In accordance with ASC 840, Leases, the Company considers only the fixed payments for purposes of allocating between the lease and non-lease deliverables on a relative fair value basis. Equipment leases are generally classified as operating leases as they do not meet any of the capital lease criteria per ASC 840.

- removed (2022-05-13):
[0001558370-21-015999:note_history:137]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (i) distinct services, such as installation, training and maintenance, and (ii) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern and because revenue allocated to maintenance components is not material, the equipment lease and maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations.

- removed (2022-05-13):
[0001558370-21-015999:note_history:138]
As leases with customers are classified as operating leases, lease revenue is recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

- removed (2022-05-13):
[0001558370-21-015999:note_history:139]
Services Revenue

- removed (2022-05-13):
[0001558370-21-015999:note_history:140]
The Company provides installation, training and maintenance services for its products. Revenue for installation and training is recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes, and when-and-if-available threat updates. Maintenance revenue is recognized ratably over the period of the arrangement. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are recognized ratably over the associated service period.

- removed (2022-05-13):
[0001558370-21-015999:note_history:141]
Revenue from Distributors

- removed (2022-05-13):
[0001558370-21-015999:note_history:142]
A portion of the Company’s revenue is also generated by sales in conjunction with its distributors. When the Company transacts with a distributor, its contractual arrangement is with the distributor and not with the end-use customer. In these transactions, the distributor is considered the customer; the Company has discretion over the pricing to the distributor and maintains overall control of the inventory and sales process to the distributor. Revenue is recognized upon delivery to the distributors. Right of return does not generally exist. Whether the Company transacts with a distributor and receives the order from a distributor or directly from an end-use customer, its revenue recognition policy and resulting pattern of revenue recognition is the same upon delivery.

- removed (2022-05-13):
[0001558370-21-015999:note_history:143]
Transaction Price

- removed (2022-05-13):
[0001558370-21-015999:note_history:144]
The transaction price is the amount of consideration that the Company expects to be entitled for providing goods and services under a contract. It includes not only fixed consideration, such as the stated amount in a contract, but also several other types of variable consideration or adjustments (generally discounts or incentives which are included as a part of the standalone selling price (“SSP”) estimation process). The Company provides discounts to customers which reduces the transaction price. From time-to-time, the Company may offer customers the option to purchase additional goods and services at a fixed price. In these limited circumstances, the Company assesses whether these offers constitute a material right, and if so, the Company would account for the material right as a separate performance obligation. Other types of variable consideration are not considered significant. The Company does not normally provide for rights of returns to customers on product sales and, therefore, does not record a provision for returns.

- removed (2022-05-13):
[0001558370-21-015999:note_history:145]
Performance Obligations

- removed (2022-05-13):
[0001558370-21-015999:note_history:146]
A performance obligation is a promise in a contract to transfer a distinct product or service to a customer that is both capable of being distinct, whereby the customer can benefit from the product or service either on its own or together with other resources that are readily available, and is distinct in the context of the contract, whereby the transfer of the product or service is separately identifiable from other promises in the contract.

- removed (2022-05-13):
[0001558370-21-015999:note_history:147]
For both Express and Edge units, equipment is sold or leased with embedded software, which is considered a single performance obligation. Maintenance, which includes future updates, security threat updates, and minor bug fixes on a when-and-if available basis, is considered a single performance obligation. As a part of reported subscription sales, certain non-lease components, such as maintenance, are included within the subscription revenue amount. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are accounted for as separate performance obligations. Installation and training are considered separate performance obligations and are included within services revenue. Any add-on accessories are also considered separate performance obligations.

- removed (2022-05-13):
[0001558370-21-015999:note_history:148]
Payment terms

- removed (2022-05-13):
[0001558370-21-015999:note_history:149]
Payment terms for customer orders are typically 30 days after the shipment or delivery of the product. For certain products, services and customer types, the Company requires payment before the products or services are delivered to, or performed for, the customer. Generally, the Company’s contracts do not contain a significant financing component.

- removed (2022-05-13):
[0001558370-21-015999:note_history:150]
Multiple Performance Obligations within an Arrangement

- removed (2022-05-13):
[0001558370-21-015999:note_history:151]
The Company’s contracts may include multiple performance obligations when customers purchase a combination of products and services. When the Company’s customer arrangements have multiple performance obligations that contain a lease for Express or Edge equipment for the customer’s use at its site as well as distinct services that are delivered simultaneously, the Company allocates the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, the Company allocates the contract’s transaction price to each performance obligation on a relative SSP basis. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company estimates the SSP taking into account available information such as market conditions and internally approved pricing guidelines related to the performance obligation.

- removed (2022-05-13):
[0001558370-21-015999:note_history:152]
Remaining Performance Obligations

- removed (2022-05-13):
[0001558370-21-015999:note_history:153]
ASC 606 requires that the Company disclose the aggregate amount of transaction price that is allocated to performance obligations that have not yet been satisfied as of September 30, 2021. The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2021. Note that with respect to ASC 840, Subscription revenue includes maintenance in addition to the operating lease components of these transactions (in thousands).

- removed (2022-05-13):
[0001558370-21-015999:note_history:154]
| ​ |  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue |  | $ | 111 |  | $ | 36 |  | $ | 147 |
| Subscription revenue |  | ​ | 9,304 |  | ​ | 21,802 |  | ​ | 31,106 |
| Service revenue |  | ​ | 24 |  | ​ | — |  | ​ | 24 |
| Maintenance revenue |  | ​ | 903 |  | ​ | 1,972 |  | ​ | 2,875 |
| Total revenue | ​ | $ | 10,342 | ​ | $ | 23,810 | ​ | $ | 34,152 |

- removed (2022-05-13):
[0001558370-21-015999:note_history:155]
The amount of minimum future leases is based on expected income recognition. As of September 30, 2021, future minimum payments on noncancelable leases are as follows (in thousands):

- removed (2022-05-13):
[0001558370-21-015999:note_history:156]
| Future operating lease component (in thousands): |  | ​ |  |
| Quarter Ending September 30, 2021: | ​ | ​ | ​ |
| 2021 | ​ | $ | 2,355 |
| 2022 | ​ |  | 9,262 |
| 2023 | ​ |  | 8,800 |
| 2024 | ​ |  | 7,054 |
| 2025 | ​ |  | 3,166 |
| Thereafter | ​ |  | 469 |
| ​ | ​ | $ | 31,106 |

- removed (2022-05-13):
[0001558370-21-015999:note_history:157]
Contract Balances from Contracts with Customers

- removed (2022-05-13):
[0001558370-21-015999:note_history:158]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2021 and December 31, 2020, the Company had $0.9 million and $0 of contract assets included within prepaid expenses and other current assets and $2.6 million and $0 in long-term contract assets on the consolidated balance sheets, respectively.

- removed (2022-05-13):
[0001558370-21-015999:note_history:159]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as noncurrent deferred revenue. The Company recognized $0.5 million and $2.3 million during the three months and nine months ended September 30, 2021 of revenue that was previously included in the 2020 deferred revenue balance, respectively. The following table provides a rollforward of deferred revenue (in thousands):

- removed (2022-05-13):
[0001558370-21-015999:note_history:160]
| ​ | ​ | (in thousands) |
| Balance at December 31, 2020 | ​ | $ | 4,197 |
| Revenue recognized | ​ |  | (6,356) |
| Revenue deferred | ​ |  | 8,815 |
| Balance at September 30, 2021 | ​ | $ | 6,656 |

- removed (2022-05-13):
[0001558370-21-015999:note_history:161]
Disaggregated Revenue

- removed (2022-05-13):
[0001558370-21-015999:note_history:162]
The following table presents the Company’s revenue by revenue stream (in thousands):

- removed (2022-05-13):
[0001558370-21-015999:note_history:163]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended | ​ |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| (in thousands) |  | 2021 |  | 2020 | ​ | 2021 |  | 2020 | ​ |
| Product revenue |  | $ | 5,345 |  | $ | 349 | ​ | ​ | 10,299 |  | $ | 422 | ​ |
| Subscription revenue(1) |  | ​ | 2,305 |  | ​ | 794 | ​ | ​ | 5,118 |  | ​ | 1,743 | ​ |
| Service revenue |  | ​ | 417 |  | ​ | 165 | ​ | ​ | 773 |  | ​ | 170 | ​ |
| Maintenance revenue |  | ​ | 300 |  | ​ | 153 | ​ | ​ | 656 |  | ​ | 415 | ​ |
| Total revenue | ​ | $ | 8,367 | ​ | $ | 1,461 | ​ | $ | 16,846 | ​ | $ | 2,750 | ​ |

- removed (2022-05-13):
[0001558370-21-015999:note_history:164]
| (1) | Subscription revenue is inclusive of $0.5 million and $0.2 million of maintenance revenue during the three months ended September 30, 2021 and 2020, respectively, and of $1.0 million and $0.4 million of maintenance revenue during the nine months ended September 30, 2021 and 2020, respectively, determined based on a relative fair value allocation as prescribed by ASC 606. |

- removed (2022-05-13):
[0001558370-21-015999:note_history:165]
Contract Acquisition Costs

- removed (2022-05-13):
[0001558370-21-015999:note_history:166]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the sale occurs and the services are provided. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $3.4 million at September 30, 2021 and $2.3 million at December 31, 2020. The increase in deferred assets is due to an increase of subscription revenue in 2020 and 2021 for which the related revenue and commissions are recognized over the contract term. The Company amortized commissions of $1.3 million during the three months ended September 30, 2021 which related to 2021 commissions, $0.1 million which related to 2020

- removed (2022-05-13):
[0001558370-21-015999:note_history:167]
commissions and less than $0.1 million which related to 2019 commissions. The Company amortized commissions of $1.6 million during the nine months ended September 30, 2021 which related to 2021 commissions, $0.3 million which related to 2020 commissions and $0.1 million which related to 2019 commissions.

- removed (2022-05-13):
[0001558370-21-015999:note_history:168]
Stock-Based Compensation

- removed (2022-05-13):
[0001558370-21-015999:note_history:169]
The Company measures all stock-based awards granted to employees, officers, directors and non-employees based on their fair value on the date of the grant and recognizes compensation expense for those awards over the requisite service period, which is generally the vesting period of the respective award. The Company classifies stock-based compensation expense in its consolidated statements of operations and comprehensive income (loss) in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified.

- removed (2022-05-13):
[0001558370-21-015999:note_history:170]
The Company issues stock-based awards with service-based vesting conditions and records the expense for these awards using the straight-line method. Forfeitures are accounted for as they occur. The Company has issued stock-based awards with performance-based vesting conditions. In August 2020, the Company granted an officer 560,189 stock options with a performance-based milestone vesting condition which vested immediately upon achievement of a certain sales milestone. The milestone was achieved in December 2020, and the Company recorded $0.1 million in stock compensation expense upon vesting during the year ended December 31, 2020.

- removed (2022-05-13):
[0001558370-21-015999:note_history:171]
In March 2021, the Company granted a warrant exercisable for 2,554,015 shares of common stock to a consulting group (“2021 Finback common stock warrants”) with performance based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years.

- removed (2022-05-13):
[0001558370-21-015999:note_history:172]
Prior to the closing of the Merger, there was not a public market for the shares of the Company’s common stock. The Company’s determination of the fair value of stock options on the date of grant utilized the Black-Scholes option-pricing model and was impacted by its common stock price, as determined by the Board of Directors with input from the Company’s management, as well as changes in assumptions regarding a number of subjective variables. These variables included, but were not limited to, the expected term that options remained outstanding, the expected common stock price volatility over the term of the option awards, risk-free interest rates, and expected dividends. The Company values its common stock taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the Company determined the fair value of each share of common stock underlying stock-based awards based on the closing price of the Company’s common stock as reported by Nasdaq on the date of grant.

- removed (2022-05-13):
[0001558370-21-015999:note_history:173]
Pursuant to the Merger Agreement, the Company will issue 15,000,000 earn-out shares of the Company’s common stock to Legacy Evolv shareholders and Legacy Evolv service providers including employees, officers, directors and non-employees based on the achievement of certain target share price contingencies and for the employees and officers subject to continued employment. The company classifies the share-based compensation arrangement with Legacy Evolv service providers as equity on its balance sheet and corresponding stock-based compensation expense in its consolidated statements of operations and comprehensive income (loss) in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. Of the total 15,000,000 earn-out shares of the Company’s common stock, 2,862,603 earn-out shares are with the Legacy Evolv service providers and subject to the share-based compensation. Stock-based compensation expense attributable to Legacy Evolv service providers is $2.0 million for the three and nine months ended September 30, 2021.

- removed (2022-05-13):
[0001558370-21-015999:note_history:174]
Income Taxes

- removed (2022-05-13):
[0001558370-21-015999:note_history:175]
The Company accounts for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in the consolidated financial statements or in the Company’s tax returns. Deferred tax assets and liabilities are determined on the basis of the differences between the consolidated financial statements and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. Changes in deferred tax assets and liabilities are recorded in the provision for income taxes.

- removed (2022-05-13):
[0001558370-21-015999:note_history:176]
The Company assesses the likelihood that its deferred tax assets will be recovered from future sources of income and, to the extent it believes, based upon the weight of available evidence, that it is more likely than not that all or a portion of the deferred tax assets will not be realized, a valuation allowance is established through a charge to income tax expense. Potential for recovery of deferred tax assets is evaluated by analyzing past operating results, estimating the future taxable profits expected and considering prudent and feasible tax planning strategies.

- removed (2022-05-13):
[0001558370-21-015999:note_history:177]
The Company accounts for uncertainty in income taxes recognized in the consolidated financial statements by applying a two-step process to determine the amount of tax benefit to be recognized. First, the tax position must be evaluated to determine the likelihood that it will be sustained upon external examination by the taxing authorities. If the tax position is deemed more-likely-than-not to be sustained, the tax position is then assessed to determine the amount of benefit to recognize in the consolidated financial statements. The amount of the benefit that may be recognized is the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. The provision for income taxes includes the effects of any resulting tax reserves, or unrecognized tax benefits, that are considered appropriate as well as the related net interest and penalties.

- removed (2022-05-13):
[0001558370-21-015999:note_history:178]
The Company evaluates at the end of each reporting period whether some or all of the undistributed earnings of its foreign subsidiaries are permanently reinvested. The Company would recognize deferred income tax liabilities to the extent that management asserts that undistributed earnings of its foreign subsidiaries are not permanently reinvested and will not be permanently reinvested in the future. As of September 30, 2021 and December 31, 2020 the Company had no foreign earnings in any foreign jurisdictions.

- removed (2022-05-13):
[0001558370-21-015999:note_history:179]
Net Income (Loss) per Share Attributable to Common Stockholders

- removed (2022-05-13):
[0001558370-21-015999:note_history:180]
Basic net income (loss) per share attributable to common stockholders is computed by dividing the net income (loss) attributable to common stockholders by the weighted average number of common shares outstanding for the period. Diluted net income (loss) attributable to common stockholders is computed by adjusting net income (loss) attributable to common stockholders for the profit or loss impact to the extent a denominator adjustment is required.  Diluted net income (loss) per share attributable to common stockholders is computed by dividing the diluted net income (loss) attributable to common stockholders by the weighted average number of common shares outstanding for the period, including potential dilutive common shares. For purposes of this calculation, outstanding stock options, convertible preferred stock, convertible notes, warrants to purchase common stock, and warrants to purchase preferred stock are considered potential dilutive common shares.

- removed (2022-05-13):
[0001558370-21-015999:note_history:181]
In periods in which the Company reported a net loss attributable to common stockholders, diluted net loss per share attributable to common stockholders is the same as basic net loss per share attributable to common stockholders, since dilutive common shares are not assumed to have been issued if their effect is anti-dilutive. The Company reported net income and a net loss attributable to common stockholders for the three months ended September 30, 2021 and 2020, respectively. For the three months ended September 30, 2021, no undistributed earnings were attributed to the convertible preferred shares which converted into common stock upon closing of the merger and have no contractual right to participate in the gains resulting from the change in fair value of earnouts and warrants that occurred after

- removed (2022-05-13):
[0001558370-21-015999:note_history:182]
conversion. The Company reported a net loss attributable to common stockholders for the nine months ended September 30, 2021 and 2020.

- removed (2022-05-13):
[0001558370-21-015999:note_history:183]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which sets out the principles for the recognition, measurement, presentation and disclosure of leases for both parties to a contract (i.e., lessees and lessors). The new standard requires lessees to apply a dual approach, classifying leases as either finance or operating leases based on the principle of whether or not the lease is effectively a financed purchase by the lessee. This classification will determine whether lease expense is recognized based on an effective interest method or on a straight-line basis over the term of the lease. A lessee is also required to record a right-of-use asset and a lease liability for all leases with a term of greater than 12 months regardless of their classification. Leases with a term of 12 months or less may be accounted for similar to existing guidance for operating leases today. For nonpublic entities, this guidance is effective for annual periods beginning after December 15, 2021. In July 2018, the FASB issued ASU No. 2018-11, Leases (Topic 842), which added an optional transition method under which financial statements may be prepared under the revised guidance for the year of adoption, but not for prior years. Under the latter method, entities will recognize a cumulative catch-up adjustment to the opening balance of retained earnings in the period of adoption. The Company expects to adopt this guidance effective January 1, 2022, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-13):
[0001558370-22-008639:note_history:184]
| ​ | ​ | March 31, | ​ | December 31, |
| ​ | ​ | 2022 |  | 2021 |
| Term loans payable | ​ | $ | 10,000 | ​ | $ | 10,000 |
| Less: Unamortized discount | ​ |  | (50) | ​ |  | (55) |
| ​ | ​ |  | 9,950 | ​ |  | 9,945 |
| Less: Current portion of long-term debt | ​ |  | 3,000 | ​ |  | 2,000 |
| Long-term debt, net of discount | ​ | $ | 6,950 | ​ | $ | 7,945 |
  (was, 2021-11-15, similarity 0.6349):
[0001558370-21-015999:note_history:184]
| ​ | ​ | September 30, | ​ | December 31, | ​ |
| ​ |  | 2021 |  | 2020 | ​ |
| Term loans payable | ​ | $ | 10,000 | ​ | $ | 10,000 | ​ |
| Revolving line of credit outstanding | ​ |  | 5,422 | ​ |  | 3,550 | ​ |
| Convertible note | ​ |  | — | ​ |  | 3,000 | ​ |
| Less: Unamortized discount | ​ |  | (63) | ​ |  | (118) | ​ |
| ​ | ​ |  | 15,359 | ​ |  | 16,432 | ​ |
| Less: Current portion of long-term debt | ​ |  | 1,000 | ​ |  | — | ​ |
| Long-term debt, net of discount | ​ | $ | 14,359 | ​ | $ | 16,432 | ​ |

- added (2022-05-13):
[0001558370-22-008639:note_history:185]
In December 2020, the Company entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024 and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022.

- changed (2022-05-13):
[0001558370-22-008639:note_history:186]
Principal and interest on the JPM Credit Agreement is payable monthly commencing on July 1, 2022. The JPM Credit Agreement accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 2.25% or (B) 5.5%. The revolving line of credit accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 1.25% or (B) 4.5%. Upon closing, the Company issued warrants to purchase 377,837 shares of common stock to the lender with an exercise price of $0.42 per share with a fair value of $0.1 million on the date of issuance. The Company incurred debt issuance costs of $0.1 million equal to the fair value of the warrants in connection with the JPM Credit Agreement. These costs were recorded as debt discount and are amortized to interest expense, using the effective interest method, over the term of the loan. Upon the closing of the Merger, the warrants were converted into shares of the Company’s common stock.
  (was, 2021-11-15, similarity 0.9438):
[0001558370-21-015999:note_history:186]
Principal and interest on the JPM Credit Agreement is payable monthly commencing on July 1, 2022. The JPM Credit Agreement accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 2.25% or (B) 5.5%. The revolving line of credit accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 1.25% or (B) 4.5%. Upon closing, the Company issued warrants to purchase 378,000 shares of common stock to the lender with an exercise price of $0.42 per share with a fair value of $0.1 million on the date of issuance. The Company incurred debt issuance costs of $0.1 million equal to the fair value of the warrants in connection with the JPM Credit Agreement. These costs were recorded as debt discount and are amortized to interest expense, using the effective interest method, over the term of the loan.

- added (2022-05-13):
[0001558370-22-008639:note_history:187]
As of March 31, 2022, the unamortized debt discount was $0.1 million. As of March 31, 2022, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the condensed consolidated balance sheet. Interest expense related to the JPM Credit Agreement totaled $0.1 million and $0.2 million for the three months ended March 31, 2022 and 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million and $0.1 million for the three months ended March 31, 2022 and 2021, respectively. The interest rate in effect as of March 31, 2022 was 5.75% for the JPM Credit Agreement. During the year ended December 31, 2021, the Company fully repaid the $5.4 million drawn down on the revolving line of credit.

- changed (2022-05-13):
[0001558370-22-008639:note_history:188]
As of March 31, 2022, future principal payments on long-term debt are as follows (in thousands):
  (was, 2021-11-15, similarity 0.9457):
[0001558370-21-015999:note_history:188]
As of September 30, 2021, future principal payments on long-term debt are as follows (in thousands):

- changed (2022-05-13):
[0001558370-22-008639:note_history:189]
| Year Ending December 31, |  | ​ | ​ |
| 2022 (remaining nine months) | ​ | $ | 2,000 |
| 2023 | ​ |  | 4,000 |
| 2024 | ​ |  | 4,000 |
| ​ | ​ | $ | 10,000 |
  (was, 2021-11-15, similarity 0.8591):
[0001558370-21-015999:note_history:189]
| Year Ending December 31, |  | ​ | ​ |
| 2021 (remaining three months) | ​ | $ | — |
| 2022 | ​ |  | 7,422 |
| 2023 | ​ |  | 4,000 |
| 2024 | ​ |  | 4,000 |
| 2025 | ​ | ​ | — |
| ​ | ​ | $ | 15,422 |

- added (2022-05-13):
[0001558370-22-008639:note_history:190]
In September 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) with an investor for gross proceeds of $2.0 million with a stated interest rate of 6.0% per annum. An additional $2.0 million in gross proceeds were made available in December 2020 upon achievement of the integration milestone, whereby the Company successfully created software utilizing the investor’s application programming interface. The 2020 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds of the issuance of preferred stock totaled at least $10.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2020 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $1.0 million, and the notes, with an initial carrying value of $3.0 million, and included in long-

- added (2022-05-13):
[0001558370-22-008639:note_history:191]
term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the Merger.

- added (2022-05-13):
[0001558370-22-008639:note_history:192]
Interest expense for the 2020 Convertible Notes totaled $0 and $0.1 million for the three months ended March 31, 2022 and 2021, respectively.

- changed (2022-05-13):
[0001558370-22-008639:note_history:193]
In January and February 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $7.0 million, and the notes, with an initial carrying value of $23.0 million, and included in long-term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the Merger.
  (was, 2021-11-15, similarity 0.9895):
[0001558370-21-015999:note_history:193]
Between January 21, 2021 and February 4, 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $7.0 million, and the notes, with an initial carrying value of $23.0 million, and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of September 30, 2021 as the liability was settled pursuant to the closing of the merger.

- changed (2022-05-13):
[0001558370-22-008639:note_history:194]
In June 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. This modification of the notes resulted in an extinguishment and the Company recognized a loss on extinguishment of the 2021 Convertible Notes of $11.8 million. The $26.7 million carrying value of the notes at June 21, 2021 was derecognized and replacement notes with an initial carrying value of $29.6 million were recorded. Additionally, in the extinguishment accounting, a derivative liability of $19.2 million was recognized, which represents the value of the 1,000,000 NHIC shares as well as a bifurcated embedded derivative for the conversion option.
  (was, 2021-11-15, similarity 0.9973):
[0001558370-21-015999:note_history:194]
On June 21, 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. This modification of the notes resulted in an extinguishment and the Company recognized a loss on extinguishment of the 2021 Convertible Notes of $11.8 million. The $26.7 million carrying value of the notes at June 21, 2021 was derecognized and replacement notes with an initial carrying value of $29.6 million were recorded. Additionally, in the extinguishment accounting, a derivative liability of $19.2 million was recognized, which represents the value of the 1,000,000 NHIC shares as well as a bifurcated embedded derivative for the conversion option.

- added (2022-05-13):
[0001558370-22-008639:note_history:195]
Interest expense for the 2021 Convertible Notes totaled $0 and $1.9 million for the three months ended March 31, 2022 and 2021, respectively.

- removed (2022-05-13):
[0001558370-21-015999:note_history:196]
Silicon Valley Bank (“SVB”) Term Loan

- removed (2022-05-13):
[0001558370-21-015999:note_history:197]
On July 5, 2017, the Company entered into a $5.0 million Loan and Security Agreement with Silicon Valley Bank (“2017 SVB Term Loan”), which provided the Company with a first term loan advance of $4.0 million which was drawn down on July 5, 2017 (“Term Loan A Advance”) and a second term loan advance of $1.0 million that was available to be drawn down until May 31, 2018 (“Term Loan B Advance”; collectively, “Term Loan Advances”). The agreement also provided the Company with a revolving line of credit of up to $1.0 million. Interest payments were due monthly and commenced upon receipt of principal. Principal was payable in 36 monthly payments and commenced on June 1, 2018. The 2017 SVB Term Loan accrued interest at an annual rate calculated as the Wall Street Journal Prime Rate plus 1.25%.

- removed (2022-05-13):
[0001558370-21-015999:note_history:198]
On February 12, 2019, the Company amended the 2017 SVB Term Loan (“2019 Term Loan Advance”) to change the interest rate to the greater of the (A) Wall Street Journal Prime Rate or (B) 5.25%. Additionally, the maturity date was extended to August 2022. Upon closing, the Company issued warrants to purchase 28,350 shares of common stock to SVB with an exercise price of $0.24 per share (see Note 11).

- removed (2022-05-13):
[0001558370-21-015999:note_history:199]
As of December 31, 2019, the Company was not in compliance with certain reporting related covenants within the SVB Loan and Security Agreement. As a result, SVB had the right to call for prepayment of the debt and it was therefore considered current as of December 31, 2019.

- removed (2022-05-13):
[0001558370-21-015999:note_history:200]
In March 2020, the Company entered into a Loan Modification Agreement with SVB (“2020 SVB Term Loan”), which provided a $5.0 million term loan and a revolving line of credit of up to $7.0 million. The Company repaid the outstanding balance owed on the 2017 SVB Term Loan of $3.1 million of principal and accrued interest with the proceeds from the 2020 SVB Term Loan. The Loan Modification Agreement with SVB resulted in the Company being in compliance with certain reporting related covenants.

- removed (2022-05-13):
[0001558370-21-015999:note_history:201]
Additionally, upon closing, the Company issued warrants to purchase 280,095 shares of common stock to SVB with an exercise price of $0.40 per share with a fair value of less than $0.1 million on the date of issuance. The Company also paid debt issuance costs of less than $0.1 million and owed an end-of-term charge of $0.1 million to SVB. The debt issuance costs were recorded as debt discount and were being amortized to interest expense, using the effective interest method, over the term of the loan. The 2020 SVB Term Loan interest was payable monthly and the principal was payable in 36 monthly payments commencing on April 1, 2021. The 2020 SVB Term Loan accrued interest at an annual

- removed (2022-05-13):
[0001558370-21-015999:note_history:202]
rate calculated as the greater of (A) Wall Street Journal Prime Rate plus 0.50% or (B) 5.0%. In December 2020, the Company repaid the outstanding balance on the 2020 SVB Term loan of $8.0 million.

- removed (2022-05-13):
[0001558370-21-015999:note_history:203]
In December 2020, the Company entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024 and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022. The Company repaid the outstanding balance on the 2020 SVB Term Loan Advance, including the $5.0 million in principal and $3.0 million outstanding on the revolving line of credit. Upon repayment of the outstanding amounts, the Company recorded a loss on extinguishment of debt of less than $0.1 million, which was included in interest expense in the December 31, 2020 consolidated statements of operations and comprehensive income (loss).

- removed (2022-05-13):
[0001558370-21-015999:note_history:204]
As of September 30, 2021, the unamortized debt discount was $0.1 million. As of September 30, 2021, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the consolidated balance sheet. Interest expense totaled $0.2 million for the three months ended September 30, 2021, which includes the amortization of the debt discount which totaled less than $0.1 million. Interest expense totaled $0.6 million for the nine months ended September 30, 2021, which includes the amortization of the debt discount which totaled less than $0.1 million. The interest rate in effect as of September 30, 2021 was 5.5% and 4.5% for the JPM Credit Agreement and revolving line of credit, respectively. As of September 30, 2021, the Company has drawn down $5.4 million on the revolving line of credit.

- removed (2022-05-13):
[0001558370-21-015999:note_history:205]
In September 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) with an investor for gross proceeds of $2.0 million with a stated interest rate of 6.0% per annum. An additional $2.0 million in gross proceeds were made available in December 2020 upon achievement of the integration milestone,

- removed (2022-05-13):
[0001558370-21-015999:note_history:206]
whereby the Company successfully created software utilizing the investor’s application programming interface. The 2020 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds of the issuance of preferred stock totaled at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2020 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $1.0 million, and the notes, with an initial carrying value of $3.0 million, and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of September 30, 2021 as the liability was settled pursuant to the closing of the merger.

- removed (2022-05-13):
[0001558370-21-015999:note_history:207]
As of September 30, 2021 and December 31, 2020, the accrued interest on the 2020 Convertible Notes was $0 and less than $0.1 million, respectively. Interest expense totaled less than $0.1 million and $0.3 million for the three and nine months ended September 30, 2021, respectively. Interest expense totaled less than $0.1 million for the three and nine months ended September 30, 2020, respectively.

- removed (2022-05-13):
[0001558370-21-015999:note_history:208]
As of September 30, 2021 and December 31, 2020, the accrued interest on the 2021 Convertible Notes was $0. Interest expense totaled less than $0.1 million and $4.9 million for the three and nine months ended September 30, 2021, respectively.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2022-05-13):
[0001558370-21-015999:note_history:209]
Debt Issuance Costs

- removed (2022-05-13):
[0001558370-21-015999:note_history:210]
The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated debt on the consolidated balance sheet and amortized as interest expense on the consolidated statement of operations and comprehensive loss using the effective interest method. As of September 30, 2021, and December 31, 2020, debt issuance costs totaled $0.1 million and $0.1 million, respectively, and were recorded as a reduction in the carrying amount of long-term debt in the consolidated balance sheets. During the three months ended September 30, 2021 and 2020, and nine months ended September 30, 2021 and 2020, the Company recorded less than $0.1 million in

- removed (2022-05-13):
[0001558370-21-015999:note_history:211]
amortization of the debt issuance costs recorded within interest expense in the consolidated statement of operations and comprehensive income (loss).


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-13):
[0001558370-22-008639:note_history:212]
| ​ | ​ | March 31, | ​ | December 31, |
| ​ | ​ | 2022 |  | 2021 |
| Term loans payable | ​ | $ | 10,000 | ​ | $ | 10,000 |
| Less: Unamortized discount | ​ |  | (50) | ​ |  | (55) |
| ​ | ​ |  | 9,950 | ​ |  | 9,945 |
| Less: Current portion of long-term debt | ​ |  | 3,000 | ​ |  | 2,000 |
| Long-term debt, net of discount | ​ | $ | 6,950 | ​ | $ | 7,945 |
  (was, 2021-11-15, similarity 0.6349):
[0001558370-21-015999:note_history:212]
| ​ | ​ | September 30, | ​ | December 31, | ​ |
| ​ |  | 2021 |  | 2020 | ​ |
| Term loans payable | ​ | $ | 10,000 | ​ | $ | 10,000 | ​ |
| Revolving line of credit outstanding | ​ |  | 5,422 | ​ |  | 3,550 | ​ |
| Convertible note | ​ |  | — | ​ |  | 3,000 | ​ |
| Less: Unamortized discount | ​ |  | (63) | ​ |  | (118) | ​ |
| ​ | ​ |  | 15,359 | ​ |  | 16,432 | ​ |
| Less: Current portion of long-term debt | ​ |  | 1,000 | ​ |  | — | ​ |
| Long-term debt, net of discount | ​ | $ | 14,359 | ​ | $ | 16,432 | ​ |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-13):
[0001558370-22-008639:note_history:213]
As of March 31, 2022, future principal payments on long-term debt are as follows (in thousands):
  (was, 2021-11-15, similarity 0.9457):
[0001558370-21-015999:note_history:213]
As of September 30, 2021, future principal payments on long-term debt are as follows (in thousands):

- changed (2022-05-13):
[0001558370-22-008639:note_history:214]
| Year Ending December 31, |  | ​ | ​ |
| 2022 (remaining nine months) | ​ | $ | 2,000 |
| 2023 | ​ |  | 4,000 |
| 2024 | ​ |  | 4,000 |
| ​ | ​ | $ | 10,000 |
  (was, 2021-11-15, similarity 0.8591):
[0001558370-21-015999:note_history:214]
| Year Ending December 31, |  | ​ | ​ |
| 2021 (remaining three months) | ​ | $ | — |
| 2022 | ​ |  | 7,422 |
| 2023 | ​ |  | 4,000 |
| 2024 | ​ |  | 4,000 |
| 2025 | ​ | ​ | — |
| ​ | ​ | $ | 15,422 |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-05-13):
[0001558370-22-008639:note_history:215]
In August 2020, the Company entered into a $0.4 million promissory note with an officer with the proceeds being used to exercise options for 1,469,366 shares of common stock at a price of $0.24 per share. The promissory note bore interest at the Wall Street Journal Prime Rate and was secured by the underlying shares of common stock that were issued upon the exercise of the stock options. The promissory note was treated as nonrecourse as the loan was only secured by the common stock issued from the exercise of the stock options. As such, (i) the underlying stock option grant was still considered to be outstanding and the shares of common stock were not considered issued and outstanding for accounting purposes until the loan was repaid in full or otherwise forgiven and (ii) no receivable was recorded for the promissory note on the Company’s condensed consolidated balance sheets. As such, the promissory note effectively extended the maturity date of the option grant for the life of the loan, this change is treated as a stock option modification. The incremental fair value from the stock option modification was deemed immaterial. The interest on this nonrecourse loan is also considered nonrecourse. As the Company has no intent to collect interest, no accrued interest was recorded.
  (was, 2021-11-15, similarity 0.9961):
[0001558370-21-015999:note_history:215]
In August 2020, the Company entered into a $0.4 million promissory note with an officer with the proceeds being used to exercise options for 1,469,999 shares of common stock at a price of $0.24 per share. The promissory note bore interest at the Wall Street Journal Prime Rate and was secured by the underlying shares of common stock that were issued upon the exercise of the stock options. The promissory note was treated as nonrecourse as the loan was only secured by the common stock issued from the exercise of the stock options. As such, (i) the underlying stock option grant was still considered to be outstanding and the shares of common stock were not considered issued and outstanding for accounting purposes until the loan was repaid in full or otherwise forgiven and (ii) no receivable was recorded for the promissory note on the Company’s consolidated balance sheets. As such, the promissory note effectively extended the maturity date of the option grant for the life of the loan, this change is treated as a stock option modification. The incremental fair value from the stock option modification was deemed immaterial. The interest on this nonrecourse loan is also considered nonrecourse. As the Company has no intent to collect interest, no accrued interest was recorded.

- changed (2022-05-13):
[0001558370-22-008639:note_history:216]
In March 2021, the Company granted a warrant exercisable for 2,552,913 shares of common stock to Finback, a consulting group who is an affiliate of one of the Company’s shareholders, with performance-based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years. During the three months ended March 31, 2022 and 2021, the Company recorded $0.4 million and $0.8 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.
  (was, 2021-11-15, similarity 0.7465):
[0001558370-21-015999:note_history:216]
In March 2021, the Company granted a warrant exercisable for 2,554,015 shares of common stock to Finback, a consulting group who is an affiliate of one of the Company’s shareholders, with performance-based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years.

- added (2022-05-13):
[0001558370-22-008639:note_history:217]
In connection with the Merger and pursuant to the Merger Agreement, Finback is entitled to receive a proportional share of earn-out shares as an earn-out service provider, based upon the remaining unvested warrants as of the Merger Date. As of March 31, 2022 Finback can earn 280,410 earn-out shares subject to stock-based compensation, based on the achievement of certain milestones. During the three months ended March 31, 2022 and 2021, the Company recorded $1.5 million and $0, respectively, of stock-based compensation expense within sales and marketing expense for the earn-out shares allocated to Finback.

- added (2022-05-13):
[0001558370-22-008639:note_history:218]
Original Equipment Manufacturer Partnership Agreement with Motorola

- added (2022-05-13):
[0001558370-22-008639:note_history:219]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement (the “Distribution Agreement”) with Motorola, an investor in the Company. In June 2021, the partnership agreement was amended by the Amended and Restated Distribution Agreement (the “Amended and Restated Distribution Agreement”). Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended March 31, 2022 and 2021, revenue from Motorola’s distributor services was $0.8 million and $0, respectively. As of March 31, 2022 and December 31, 2021, accounts receivable related to Motorola’s distributor services was $1.6 million and $1.2 million, respectively.

- removed (2022-05-13):
[0001558370-21-015999:note_history:220]
During the three and nine months ended September 30, 2021, the Company recorded less than $0.1 million and $1.0 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-05-13):
[0001558370-22-008639:note_history:221]
| ​ | ​ | Three Months Ended March 31, |
| ​ | ​ | 2022 |  | 2021 |
| Product revenue | ​ | ​ | 5,194 |  | ​ | 2,502 |
| Leased equipment | ​ | ​ | 3,020 |  | ​ | 1,300 |
| SaaS and Maintenance revenue | ​ | ​ | 353 |  | ​ | 132 |
| Professional services revenue | ​ | ​ | 148 | ​ | ​ | 65 |
| Total revenue | ​ | $ | 8,715 | ​ | $ | 3,999 |

- removed (2022-05-13):
[0001558370-21-015999:note_history:222]
The following table presents the Company’s revenue by revenue stream (in thousands):

- removed (2022-05-13):
[0001558370-21-015999:note_history:223]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended | ​ |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| (in thousands) |  | 2021 |  | 2020 | ​ | 2021 |  | 2020 | ​ |
| Product revenue |  | $ | 5,345 |  | $ | 349 | ​ | ​ | 10,299 |  | $ | 422 | ​ |
| Subscription revenue(1) |  | ​ | 2,305 |  | ​ | 794 | ​ | ​ | 5,118 |  | ​ | 1,743 | ​ |
| Service revenue |  | ​ | 417 |  | ​ | 165 | ​ | ​ | 773 |  | ​ | 170 | ​ |
| Maintenance revenue |  | ​ | 300 |  | ​ | 153 | ​ | ​ | 656 |  | ​ | 415 | ​ |
| Total revenue | ​ | $ | 8,367 | ​ | $ | 1,461 | ​ | $ | 16,846 | ​ | $ | 2,750 | ​ |

- removed (2022-05-13):
[0001558370-21-015999:note_history:224]
| (1) | Subscription revenue is inclusive of $0.5 million and $0.2 million of maintenance revenue during the three months ended September 30, 2021 and 2020, respectively, and of $1.0 million and $0.4 million of maintenance revenue during the nine months ended September 30, 2021 and 2020, respectively, determined based on a relative fair value allocation as prescribed by ASC 606. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: title_similarity, score: 0.9268

- changed (2022-05-13):
[0001558370-22-008639:note_history:225]
5. Revenue Recognition
  (was, 2021-11-15, similarity 0.95):
[0001558370-21-015999:note_history:225]
Revenue Recognition

- changed (2022-05-13):
[0001558370-22-008639:note_history:226]
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.
  (was, 2021-11-15, similarity 0.9425):
[0001558370-21-015999:note_history:226]
The Company recognizes revenue in accordance with ASC 606. Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

- changed (2022-05-13):
[0001558370-22-008639:note_history:227]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases under ASC 842 and (2) from the sale of products, inclusive of SaaS and maintenance and (3) professional services. The Company’s arrangements are generally noncancelable and nonrefundable after ownership passes to the customer for product sales and upon installation for subscriptions. Revenue is recognized net of sales tax.
  (was, 2021-11-15, similarity 0.8377):
[0001558370-21-015999:note_history:227]
The Company derives revenue from (1) subscription arrangements accounted for as operating leases under ASC 840 and (2) from the sale of products, inclusive of maintenance and services. The Company’s arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

- added (2022-05-13):
[0001558370-22-008639:note_history:228]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2022.

- changed (2022-05-13):
[0001558370-22-008639:note_history:229]
| ​ |  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue |  | $ | 166 |  | $ | 39 |  | $ | 205 |
| Subscription revenue |  | ​ | 12,784 |  | ​ | 29,041 |  | ​ | 41,825 |
| Service revenue |  | ​ | 6 | ​ | ​ | — | ​ | ​ | 6 |
| Maintenance revenue | ​ | ​ | 2,415 | ​ | ​ | 6,086 | ​ | ​ | 8,501 |
| Total revenue | ​ | $ | 15,371 | ​ | $ | 35,166 | ​ | $ | 50,537 |
  (was, 2021-11-15, similarity 0.9268):
[0001558370-21-015999:note_history:229]
| ​ |  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue |  | $ | 111 |  | $ | 36 |  | $ | 147 |
| Subscription revenue |  | ​ | 9,304 |  | ​ | 21,802 |  | ​ | 31,106 |
| Service revenue |  | ​ | 24 |  | ​ | — |  | ​ | 24 |
| Maintenance revenue |  | ​ | 903 |  | ​ | 1,972 |  | ​ | 2,875 |
| Total revenue | ​ | $ | 10,342 | ​ | $ | 23,810 | ​ | $ | 34,152 |

- changed (2022-05-13):
[0001558370-22-008639:note_history:230]
The amount of minimum future leases is based on expected income recognition. As of March 31, 2022, future minimum payments on noncancelable leases are as follows (in thousands):
  (was, 2021-11-15, similarity 0.9711):
[0001558370-21-015999:note_history:230]
The amount of minimum future leases is based on expected income recognition. As of September 30, 2021, future minimum payments on noncancelable leases are as follows (in thousands):

- added (2022-05-13):
[0001558370-22-008639:note_history:231]
| Future operating lease component: |  | ​ |  |
| Year Ending December 31: | ​ | ​ | ​ |
| 2022 (nine months remaining) | ​ | $ | 9,677 |
| 2023 | ​ |  | 12,330 |
| 2024 | ​ |  | 11,137 |
| 2025 | ​ |  | 7,438 |
| 2026 | ​ | ​ | 1,131 |
| Thereafter | ​ |  | 112 |
| ​ | ​ | $ | 41,825 |

- changed (2022-05-13):
[0001558370-22-008639:note_history:232]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of
  (was, 2021-11-15, similarity 0.6362):
[0001558370-21-015999:note_history:232]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2021 and December 31, 2020, the Company had $0.9 million and $0 of contract assets included within prepaid expenses and other current assets and $2.6 million and $0 in long-term contract assets on the consolidated balance sheets, respectively.

- added (2022-05-13):
[0001558370-22-008639:note_history:233]
time. As of March 31, 2022 and December 31, 2021, the Company had $1.4 million and $1.5 million in current portion of contract assets and $3.3 million and $3.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2022-05-13):
[0001558370-22-008639:note_history:234]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized $2.5 million during the three months ended March 31, 2022 of revenue that was previously included in the 2021 deferred revenue balance and recognized $0.9 million during the three months ended March 31, 2021 of revenue that was previously included in the 2020 deferred revenue balance.
  (was, 2021-11-15, similarity 0.8215):
[0001558370-21-015999:note_history:234]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as noncurrent deferred revenue. The Company recognized $0.5 million and $2.3 million during the three months and nine months ended September 30, 2021 of revenue that was previously included in the 2020 deferred revenue balance, respectively. The following table provides a rollforward of deferred revenue (in thousands):

- added (2022-05-13):
[0001558370-22-008639:note_history:235]
The following table provides a rollforward of deferred revenue (in thousands):

- changed (2022-05-13):
[0001558370-22-008639:note_history:236]
| Balance at December 31, 2021 | ​ | $ | 9,165 |
| Revenue recognized | ​ |  | (6,409) |
| Revenue deferred | ​ |  | 9,194 |
| Balance at March 31, 2022 | ​ | $ | 11,950 |
  (was, 2021-11-15, similarity 0.8825):
[0001558370-21-015999:note_history:236]
| ​ | ​ | (in thousands) |
| Balance at December 31, 2020 | ​ | $ | 4,197 |
| Revenue recognized | ​ |  | (6,356) |
| Revenue deferred | ​ |  | 8,815 |
| Balance at September 30, 2021 | ​ | $ | 6,656 |

- added (2022-05-13):
[0001558370-22-008639:note_history:237]
The following table presents the Company’s components of lease revenue (in thousands):

- added (2022-05-13):
[0001558370-22-008639:note_history:238]
| ​ | ​ | Three Months Ended March 31, |
| ​ | ​ | 2022 | ​ | ​ | 2021 |
| Revenue from sales-type leases | $ | 1,312 | ​ | $ | — |
| Interest income on lease receivables | ​ | 190 | ​ |  | — |
| Lease income - operating leases | ​ | 3,020 | ​ | ​ | 1,300 |
| Total lease revenue | $ | 4,522 | ​ | $ | 1,300 |

- added (2022-05-13):
[0001558370-22-008639:note_history:239]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified as other income (expense), net in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss.

- added (2022-05-13):
[0001558370-22-008639:note_history:240]
| ​ | ​ | Three Months Ended March 31, |
| ​ | ​ | 2022 |  | 2021 |
| Product revenue | ​ | ​ | 5,194 |  | ​ | 2,502 |
| Leased equipment | ​ | ​ | 3,020 |  | ​ | 1,300 |
| SaaS and Maintenance revenue | ​ | ​ | 353 |  | ​ | 132 |
| Professional services revenue | ​ | ​ | 148 | ​ | ​ | 65 |
| Total revenue | ​ | $ | 8,715 | ​ | $ | 3,999 |

- added (2022-05-13):
[0001558370-22-008639:note_history:241]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $5.7 million and $5.4 million as of March 31, 2022 and December 31, 2021, respectively. The Company amortized commissions of $0.1 million during the three months ended March 31, 2022 which related to 2022 commissions and $0.3 million which related to 2021 commissions.

- added (2022-05-13):
[0001558370-22-008639:note_history:242]
Give Evolv LLC

- added (2022-05-13):
[0001558370-22-008639:note_history:243]
Upon the closing of the Merger, the NHIC Founders transferred 517,500 shares of its common stock to Evolv NewHold Benefit LLC (“ENHB”), which represented the initial contribution to be used to pay for the donation of Evolv’s Express units to public venues and institutions, primarily schools in locations that might not otherwise be able to afford weapon detection security screening systems and related products and services. In September 2021, ENHB was renamed to Give Evolv LLC (“Give Evolv”). Give Evolv is deemed an entity under common control and a consolidating entity as it is under the same management as the Company. As such, the shares held by Give Evolv are not considered outstanding or issued.

- added (2022-05-13):
[0001558370-22-008639:note_history:244]
For such arrangements, Give Evolv generally purchases the related products and services from Evolv Technologies, Inc. through an intercompany transaction using the available donated proceeds from the transfer of common stock upon the closing of the Merger. Evolv Technologies, Inc. will be responsible for the delivery of the units, in addition to providing related services, such as installation, training, and maintenance. Consideration transferred to Evolv Technologies, Inc. for the related products and services may be in the form of common stock or cash. Shares of common stock may be sold to generate funds for the purposes of paying for the donated goods and services. The sales transactions between Evolv Technologies, Inc. and Give Evolv eliminate in consolidation.

- added (2022-05-13):
[0001558370-22-008639:note_history:245]
During the three months ended March 31, 2022, the Company donated three Evolv Express units to schools, resulting in $0.2 million in general and administrative expense in the Company’s condensed consolidated statements of operations and comprehensive loss.

- removed (2022-05-13):
[0001558370-21-015999:note_history:246]
Product Revenue

- removed (2022-05-13):
[0001558370-21-015999:note_history:247]
The Company derives revenue from the sale of its Express and Edge equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer. Transfer of control occurs when the Company has transferred title and risk of loss and has a present right to payment for the equipment, which is generally upon delivery as the Company’s normal terms of sale are freight on board destination. Products are predominately sold with distinct services, which are described in the services section below.

- removed (2022-05-13):
[0001558370-21-015999:note_history:248]
Subscription Revenue

- removed (2022-05-13):
[0001558370-21-015999:note_history:249]
In addition to selling its products directly to customers, the Company also leases Express and Edge equipment. These arrangements convey the right to use the equipment for a period of time in exchange for consideration and therefore are accounted for under ASC 840 due to the scope exception of ASC 606-10-15-2. Lease terms are typically four years and customers pay quarterly or annual fixed payments for the lease and maintenance elements over the contractual lease term. In accordance with ASC 840, Leases, the Company considers only the fixed payments for purposes of allocating between the lease and non-lease deliverables on a relative fair value basis. Equipment leases are generally classified as operating leases as they do not meet any of the capital lease criteria per ASC 840.

- removed (2022-05-13):
[0001558370-21-015999:note_history:250]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (i) distinct services, such as installation, training and maintenance, and (ii) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern and because revenue allocated to maintenance components is not material, the equipment lease and maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations.

- removed (2022-05-13):
[0001558370-21-015999:note_history:251]
As leases with customers are classified as operating leases, lease revenue is recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

- removed (2022-05-13):
[0001558370-21-015999:note_history:252]
Services Revenue

- removed (2022-05-13):
[0001558370-21-015999:note_history:253]
The Company provides installation, training and maintenance services for its products. Revenue for installation and training is recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes, and when-and-if-available threat updates. Maintenance revenue is recognized ratably over the period of the arrangement. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are recognized ratably over the associated service period.

- removed (2022-05-13):
[0001558370-21-015999:note_history:254]
Revenue from Distributors

- removed (2022-05-13):
[0001558370-21-015999:note_history:255]
A portion of the Company’s revenue is also generated by sales in conjunction with its distributors. When the Company transacts with a distributor, its contractual arrangement is with the distributor and not with the end-use customer. In these transactions, the distributor is considered the customer; the Company has discretion over the pricing to the distributor and maintains overall control of the inventory and sales process to the distributor. Revenue is recognized upon delivery to the distributors. Right of return does not generally exist. Whether the Company transacts with a distributor and receives the order from a distributor or directly from an end-use customer, its revenue recognition policy and resulting pattern of revenue recognition is the same upon delivery.

- removed (2022-05-13):
[0001558370-21-015999:note_history:256]
Transaction Price

- removed (2022-05-13):
[0001558370-21-015999:note_history:257]
The transaction price is the amount of consideration that the Company expects to be entitled for providing goods and services under a contract. It includes not only fixed consideration, such as the stated amount in a contract, but also several other types of variable consideration or adjustments (generally discounts or incentives which are included as a part of the standalone selling price (“SSP”) estimation process). The Company provides discounts to customers which reduces the transaction price. From time-to-time, the Company may offer customers the option to purchase additional goods and services at a fixed price. In these limited circumstances, the Company assesses whether these offers constitute a material right, and if so, the Company would account for the material right as a separate performance obligation. Other types of variable consideration are not considered significant. The Company does not normally provide for rights of returns to customers on product sales and, therefore, does not record a provision for returns.

- removed (2022-05-13):
[0001558370-21-015999:note_history:258]
Performance Obligations

- removed (2022-05-13):
[0001558370-21-015999:note_history:259]
A performance obligation is a promise in a contract to transfer a distinct product or service to a customer that is both capable of being distinct, whereby the customer can benefit from the product or service either on its own or together with other resources that are readily available, and is distinct in the context of the contract, whereby the transfer of the product or service is separately identifiable from other promises in the contract.

- removed (2022-05-13):
[0001558370-21-015999:note_history:260]
For both Express and Edge units, equipment is sold or leased with embedded software, which is considered a single performance obligation. Maintenance, which includes future updates, security threat updates, and minor bug fixes on a when-and-if available basis, is considered a single performance obligation. As a part of reported subscription sales, certain non-lease components, such as maintenance, are included within the subscription revenue amount. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are accounted for as separate performance obligations. Installation and training are considered separate performance obligations and are included within services revenue. Any add-on accessories are also considered separate performance obligations.

- removed (2022-05-13):
[0001558370-21-015999:note_history:261]
Payment terms

- removed (2022-05-13):
[0001558370-21-015999:note_history:262]
Payment terms for customer orders are typically 30 days after the shipment or delivery of the product. For certain products, services and customer types, the Company requires payment before the products or services are delivered to, or performed for, the customer. Generally, the Company’s contracts do not contain a significant financing component.

- removed (2022-05-13):
[0001558370-21-015999:note_history:263]
Multiple Performance Obligations within an Arrangement

- removed (2022-05-13):
[0001558370-21-015999:note_history:264]
The Company’s contracts may include multiple performance obligations when customers purchase a combination of products and services. When the Company’s customer arrangements have multiple performance obligations that contain a lease for Express or Edge equipment for the customer’s use at its site as well as distinct services that are delivered simultaneously, the Company allocates the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, the Company allocates the contract’s transaction price to each performance obligation on a relative SSP basis. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company estimates the SSP taking into account available information such as market conditions and internally approved pricing guidelines related to the performance obligation.

- removed (2022-05-13):
[0001558370-21-015999:note_history:265]
ASC 606 requires that the Company disclose the aggregate amount of transaction price that is allocated to performance obligations that have not yet been satisfied as of September 30, 2021. The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2021. Note that with respect to ASC 840, Subscription revenue includes maintenance in addition to the operating lease components of these transactions (in thousands).

- removed (2022-05-13):
[0001558370-21-015999:note_history:266]
| Future operating lease component (in thousands): |  | ​ |  |
| Quarter Ending September 30, 2021: | ​ | ​ | ​ |
| 2021 | ​ | $ | 2,355 |
| 2022 | ​ |  | 9,262 |
| 2023 | ​ |  | 8,800 |
| 2024 | ​ |  | 7,054 |
| 2025 | ​ |  | 3,166 |
| Thereafter | ​ |  | 469 |
| ​ | ​ | $ | 31,106 |

- removed (2022-05-13):
[0001558370-21-015999:note_history:267]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended | ​ |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| (in thousands) |  | 2021 |  | 2020 | ​ | 2021 |  | 2020 | ​ |
| Product revenue |  | $ | 5,345 |  | $ | 349 | ​ | ​ | 10,299 |  | $ | 422 | ​ |
| Subscription revenue(1) |  | ​ | 2,305 |  | ​ | 794 | ​ | ​ | 5,118 |  | ​ | 1,743 | ​ |
| Service revenue |  | ​ | 417 |  | ​ | 165 | ​ | ​ | 773 |  | ​ | 170 | ​ |
| Maintenance revenue |  | ​ | 300 |  | ​ | 153 | ​ | ​ | 656 |  | ​ | 415 | ​ |
| Total revenue | ​ | $ | 8,367 | ​ | $ | 1,461 | ​ | $ | 16,846 | ​ | $ | 2,750 | ​ |

- removed (2022-05-13):
[0001558370-21-015999:note_history:268]
| (1) | Subscription revenue is inclusive of $0.5 million and $0.2 million of maintenance revenue during the three months ended September 30, 2021 and 2020, respectively, and of $1.0 million and $0.4 million of maintenance revenue during the nine months ended September 30, 2021 and 2020, respectively, determined based on a relative fair value allocation as prescribed by ASC 606. |

- removed (2022-05-13):
[0001558370-21-015999:note_history:269]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the sale occurs and the services are provided. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $3.4 million at September 30, 2021 and $2.3 million at December 31, 2020. The increase in deferred assets is due to an increase of subscription revenue in 2020 and 2021 for which the related revenue and commissions are recognized over the contract term. The Company amortized commissions of $1.3 million during the three months ended September 30, 2021 which related to 2021 commissions, $0.1 million which related to 2020

- removed (2022-05-13):
[0001558370-21-015999:note_history:270]
commissions and less than $0.1 million which related to 2019 commissions. The Company amortized commissions of $1.6 million during the nine months ended September 30, 2021 which related to 2021 commissions, $0.3 million which related to 2020 commissions and $0.1 million which related to 2019 commissions.
