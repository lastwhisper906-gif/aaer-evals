# EVLV 8-K — 0001104659-22-058798 filed 2022-05-11

## item codes, every 8-K on or before 2022-05-13

- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2022-05-13

- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-22-058798:8k_2_02:1]
EX-99.1
2
tm2214985d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-22-058798:8k_2_02:2]
Exhibit 99.1

[0001104659-22-058798:8k_2_02:3]
| Investor Relations: Brian Norris Vice President of Investor Relations bnorris@evolvtechnology.com |

[0001104659-22-058798:8k_2_02:4]
Evolv Technology Reports Strong First Quarter
Financial Results

[0001104659-22-058798:8k_2_02:5]
– Company Reaffirms Outlook for
2022 –

[0001104659-22-058798:8k_2_02:6]
|  | · | Q1 Revenue of $8.7 million, up 118% year-over-year |
|  | · | Q1 Ending ARR of $16.6 million, up 207% year-over-year |
|  | · | Q1 Ending Evolv Express® subscriptions of 910, up 227% year-over-year |

[0001104659-22-058798:8k_2_02:7]
Waltham, Massachusetts – May 11,
2022 – Evolv Technology (NASDAQ: EVLV), a global leader in weapons detection security screening, today announced financial results
for its first quarter ended March 31, 2022 and reaffirmed its business outlook for 2022.

[0001104659-22-058798:8k_2_02:8]
“We’re pleased to report solid first
quarter results which were highlighted by strong growth in revenues, new customers and Evolv Express subscribers,” said Peter George,
President and Chief Executive Officer of Evolv Technology. “Our results continue to reflect our expanding leadership position in
North America as more facility operators adopt our solutions to digitally transform their security operations. Looking ahead, we believe
we remain well positioned to execute on our strategic growth plans.”

[0001104659-22-058798:8k_2_02:9]
Results for the First Quarter of 2022

[0001104659-22-058798:8k_2_02:10]
Total revenue for the first quarter of 2022 was
$8.7 million, an increase of 118% compared to $4.0 million for the first quarter of 2021. Total Contract Value (“TCV”)1
of orders booked for the first quarter of 2022 was $19.2 million, an increase of 128% compared to $8.4 million in the first quarter of
2021. Annual Recurring Revenue (“ARR”)2 was $16.6 million at the end of first quarter of 2022, an increase of 207%
compared to $5.4 million in the first quarter of 2021. Net loss for the first quarter of 2022 was ($14.6) million, or ($0.10) per basic
and diluted share, compared to net loss of ($13.8) million, or ($1.32) per basic and diluted share, for the first quarter of 2021. Adjusted
earnings (loss)3 for the first quarter of 2022 was ($19.1) million, or ($0.13) per basic and diluted share, compared to ($10.5)
million, or ($1.01) per basic and diluted share, for the first quarter of 2021. Adjusted EBITDA3 for the first quarter
of 2022 was ($18.2) million, compared to ($7.6) million for the first quarter of 2021. As of
March 31, 2022, the Company had cash and cash equivalents of $270.9 million compared to $307.5 million as of December 31,
2021.

[0001104659-22-058798:8k_2_02:11]
Company Reaffirms Outlook for 2022

[0001104659-22-058798:8k_2_02:12]
The Company today commented on its business outlook
for 2022. The Company's outlook is based on the current indications for its business, which may change at any time.

[0001104659-22-058798:8k_2_02:13]
|  |  | 2022 Business Outlook |
| Estimate (In millions) |  | Issued March 14, 2022 |  | Issued May 11, 2022 |
| Total Revenue |  | $29-$31 |  | No change |
| Annual Recurring Revenue2 (ARR) at 12/31 |  | $27-$28 |  | No change |
| Adjusted EBITDA3 |  | ($65-$67) |  | No change |
| Cash and Cash Equivalents |  | $220-$230 |  | No change |

[0001104659-22-058798:8k_2_02:14]
Company to Host Live Conference Call and Webcast

[0001104659-22-058798:8k_2_02:15]
The Company’s management team plans to
host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s
outlook for the business and other matters. The conference call may be accessed in the United States by dialing +1.877.692.8955 and using
access code 774298. The conference call may be accessed outside of the United States by dialing +1.234.720.6979 and using the same access
code. The conference call will be simultaneously webcast on the Company’s investor relations website, which can be accessed at
http://ir.evolvtechnology.com. A replay of the conference call will be available for a period of 30 days by dialing +1.866.207.1041
or +1.402.970.0847 and using access code 5434851 or by accessing the webcast replay on the Company’s investor relations website
at http://ir.evolvtechnology.com.

[0001104659-22-058798:8k_2_02:16]
About Evolv Technology

[0001104659-22-058798:8k_2_02:17]
Evolv Technology (NASDAQ: EVLV) is a global leader
in weapons detection security screening. Our mission is Evolv Technology (NASDAQ: EVLV) is a leader in weapons detection for security
screening, securing the world’s most iconic venues and companies. Its mission is enabling a better experience and better security
for venues, creating a safer world to work, learn, and play by transforming physical security to make everywhere safer. It gives sports
fans, theme park visitors, concertgoers, shoppers, employees, students, and others peace of mind so that they can gather without fear
of violence. Its security screening has scanned more than 250 million people, second only to the Department of Homeland Security’s
Transportation Security Administration (TSA) in the United States, and its technology combines powerful, advanced sensors with proven
artificial intelligence (AI), security ecosystem integrations, and comprehensive venue analytics to reliably detect threats 10 times
faster than traditional metal detectors. Evolv Technology, Evolv Express®, Evolv Insights™, and Evolv Cortex AI™ are
registered trademarks or trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information,
visit https://evolvtechnology.com.

[0001104659-22-058798:8k_2_02:18]
1 We define Total Contract Value,
or TCV, of orders booked as the total value of the contract over the specified term. Our calculation of TCV is not adjusted for the impact
of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases). TCV
should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of TCV may
differ from similarly titled metrics presented by other companies.

[0001104659-22-058798:8k_2_02:19]
2 We define Annual Recurring Revenue,
or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter
normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as
customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on
its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR
at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other
changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR
should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may
differ from similarly titled metrics presented by other companies.

[0001104659-22-058798:8k_2_02:20]
3 Non-GAAP Financial Measures
In this press release, the Company’s adjusted gross profit, adjusted gross margin, adjusted
EBITDA and adjusted earnings (loss) are not presented in accordance with generally accepted accounting principles (GAAP) and are
not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit
and adjusted gross margin exclude one-time items which management believes provides a more meaningful representation of contribution margin.
Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, share-based compensation, and certain other one-time
expenses. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, change in fair value of derivative liability,
change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in
fair value of public warrant liability, change in fair value of common stock warrant liability, restructuring expenses, loss on impairment
of lease equipment, and certain other one-time expenses. Management presents non-GAAP financial measures because it considers them to
be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including
analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels
of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and
investors in evaluating the Company's financial and operational performance. However, non-GAAP financial measures have limitations as
an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide
non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will
provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their
most directly comparable GAAP financial measures. A reconciliation of our non-GAAP financial measures to their most directly comparable
GAAP measures has been provided in this press release.

[0001104659-22-058798:8k_2_02:21]
Forward-Looking Statements

[0001104659-22-058798:8k_2_02:22]
Evolv
Technology

[0001104659-22-058798:8k_2_02:23]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE
LOSS

[0001104659-22-058798:8k_2_02:24]
(In thousands, except share and per share data)

[0001104659-22-058798:8k_2_02:25]
(Unaudited)

[0001104659-22-058798:8k_2_02:26]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Product revenue |  | $ | 5,194 |  |  | $ | 2,502 |  |
| Subscription revenue |  |  | 3,020 |  |  |  | 1,300 |  |
| Service revenue |  |  | 501 |  |  |  | 197 |  |
| Total revenue |  |  | 8,715 |  |  |  | 3,999 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Cost of product revenue |  |  | 5,576 |  |  |  | 2,229 |  |
| Cost of subscription revenue |  |  | 1,065 |  |  |  | 595 |  |
| Cost of service revenue |  |  | 448 |  |  |  | 127 |  |
| Total cost of revenue |  |  | 7,089 |  |  |  | 2,951 |  |
| Gross profit |  |  | 1,626 |  |  |  | 1,048 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 4,286 |  |  |  | 3,612 |  |
| Sales and marketing |  |  | 12,053 |  |  |  | 3,684 |  |
| General and administrative |  |  | 11,093 |  |  |  | 2,899 |  |
| Loss from impairment of property and equipment |  |  | 96 |  |  |  | - |  |
| Total operating expenses |  |  | 27,528 |  |  |  | 10,195 |  |
| Loss from operations |  |  | (25,902 | ) |  |  | (9,147 | ) |
| Interest expense |  |  | (142 | ) |  |  | (2,447 | ) |
| Interest income |  |  | 209 |  |  |  | - |  |
| Change in fair value of derivative liability |  |  | — |  |  |  | (1,425 | ) |
| Change in fair value of contingent earn-out liability |  |  | 4,226 |  |  |  | - |  |
| Change in fair value of contingently issuable common stock liability |  |  | 1,472 |  |  |  | - |  |
| Change in fair value of public warrant liability |  |  | 5,586 |  |  |  | - |  |
| Change in fair value of common stock warrant liability |  |  | — |  |  |  | (736 | ) |
| Total other income (expense) |  | $ | 11,351 |  |  | $ | (4,608 | ) |
| Net loss and comprehensive loss – basic and diluted |  | $ | (14,551 | ) |  | $ | (13,755 | ) |
| Net loss per share – basic and diluted |  | $ | (0.10 | ) |  | $ | (1.32 | ) |
| Weighted average common shares outstanding – basic and diluted |  |  | 142,878,406 |  |  |  | 10,443,323 |  |

[0001104659-22-058798:8k_2_02:27]
Evolv
Technology

[0001104659-22-058798:8k_2_02:28]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-22-058798:8k_2_02:29]
(In thousands, except share and per share data)

[0001104659-22-058798:8k_2_02:30]
(Unaudited)

[0001104659-22-058798:8k_2_02:31]
|  |  | March 31, 2022 |  |  | December 31, 2021 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 270,872 |  |  | $ | 307,492 |  |
| Restricted cash |  |  | 400 |  |  |  | 400 |  |
| Accounts receivable, net |  |  | 8,589 |  |  |  | 6,477 |  |
| Inventory |  |  | 7,181 |  |  |  | 5,140 |  |
| Current portion of contract assets |  |  | 1,448 |  |  |  | 1,459 |  |
| Current portion of commission asset |  |  | 1,477 |  |  |  | 1,645 |  |
| Prepaid expenses and other current assets |  |  | 17,252 |  |  |  | 11,047 |  |
| Total current assets |  |  | 307,219 |  |  |  | 333,660 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  |  | 275 |  |
| Contract assets, noncurrent |  |  | 3,321 |  |  |  | 3,418 |  |
| Commission asset, noncurrent |  |  | 4,239 |  |  |  | 3,719 |  |
| Property and equipment, net |  |  | 25,282 |  |  |  | 21,592 |  |
| Operating lease right-of-use assets |  |  | 2,287 |  |  |  | - |  |
| Other assets |  |  | 1,275 |  |  |  | 401 |  |
| Total assets |  | $ | 343,898 |  |  | $ | 363,065 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 4,645 |  |  | $ | 6,363 |  |
| Accrued expenses and other current liabilities |  |  | 7,118 |  |  |  | 9,183 |  |
| Current portion of deferred revenue |  |  | 7,433 |  |  |  | 6,690 |  |
| Current portion of deferred rent |  |  | — |  |  |  | 135 |  |
| Current portion of long-term debt |  |  | 3,000 |  |  |  | 2,000 |  |
| Current portion of operating lease liabilities |  |  | 1,089 |  |  |  | — |  |
| Total current liabilities |  |  | 23,285 |  |  |  | 24,371 |  |
| Deferred revenue, noncurrent |  |  | 4,517 |  |  |  | 2,475 |  |
| Deferred rent, noncurrent |  |  | — |  |  |  | 333 |  |
| Long-term debt, noncurrent |  |  | 6,950 |  |  |  | 7,945 |  |
| Operating lease liabilities, noncurrent |  |  | 1,634 |  |  |  | — |  |
| Contingent earn-out liability |  |  | 18,128 |  |  |  | 20,809 |  |
| Contingently issuable common stock liability |  |  | 3,792 |  |  |  | 5,264 |  |
| Public warrant liability |  |  | 5,444 |  |  |  | 11,030 |  |
| Total liabilities |  |  | 63,750 |  |  |  | 72,227 |  |
| Stockholders’ Equity: |  |  |  |  |  |  |  |  |
| Preferred stock |  |  | - |  |  |  | - |  |
| Common stock |  |  | 14 |  |  |  | 14 |  |
| Additional paid-in capital |  |  | 399,424 |  |  |  | 395,563 |  |
| Accumulated deficit |  |  | (119,290 | ) |  |  | (104,739 | ) |
| Total stockholders’ equity |  |  | 280,148 |  |  |  | 290,838 |  |
| Total liabilities and stockholders’ equity |  | $ | 343,898 |  |  | $ | 363,065 |  |

[0001104659-22-058798:8k_2_02:32]
EVOlv
TECHNOLOGY

[0001104659-22-058798:8k_2_02:33]
Consolidated
Statements Of Cash Flows

[0001104659-22-058798:8k_2_02:34]
(In thousands)

[0001104659-22-058798:8k_2_02:35]
(Unaudited)

[0001104659-22-058798:8k_2_02:36]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (14,551 | ) |  | $ | (13,755 | ) |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 948 |  |  |  | 452 |  |
| Write off of inventory |  |  | 324 |  |  |  | — |  |
| Adjustment to property and equipment for sales type leases |  |  | (321 | ) |  |  | — |  |
| Loss from impairment of property and equipment |  |  | 96 |  |  |  | — |  |
| Stock-based compensation |  |  | 5,190 |  |  |  | 1,082 |  |
| Noncash interest expense |  |  | 5 |  |  |  | 2,344 |  |
| Noncash lease expense |  |  | 197 |  |  |  | — |  |
| Provision recorded for allowance for doubtful accounts |  |  | — |  |  |  | (63 | ) |
| Change in fair value of derivative liability |  |  | — |  |  |  | 1,425 |  |
| Change in fair value of common stock warrant liability |  |  | — |  |  |  | 736 |  |
| Change in fair value of earn-out liability |  |  | (4,226 | ) |  |  | — |  |
| Change in fair value of contingently issuable common stock |  |  | (1,472 | ) |  |  | — |  |
| Change in fair value of public warrant liability |  |  | (5,586 | ) |  |  | — |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (2,112 | ) |  |  | (874 | ) |
| Inventory |  |  | (6,985 | ) |  |  | (433 | ) |
| Commission assets |  |  | (351 | ) |  |  | (391 | ) |
| Contract assets |  |  | 108 |  |  |  | (119 | ) |
| Prepaid expenses and other current assets |  |  | (5,280 | ) |  |  | (4,104 | ) |
| Accounts payable |  |  | (1,867 | ) |  |  | 1,194 |  |
| Deferred revenue |  |  | 2,778 |  |  |  | (621 | ) |
| Deferred rent |  |  | (468 | ) |  |  | (11 | ) |
| Accrued expenses and other current liabilities |  |  | (2,065 | ) |  |  | 1,100 |  |
| Operating lease liabilities |  |  | (229 | ) |  |  | — |  |
| Net cash used in operating activities |  |  | (35,867 | ) |  |  | (12,038 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Development of internal-use software |  |  | (646 | ) |  |  | - |  |
| Purchases of property and equipment |  |  | (323 | ) |  |  | (2,522 | ) |
| Net cash used in investing activities |  |  | (969 | ) |  |  | (2,522 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 216 |  |  |  | 455 |  |
| Repayment of financing obligations |  |  | - |  |  |  | (359 | ) |
| Proceeds from long-term debt, net of issuance costs |  |  | - |  |  |  | 31,882 |  |
| Net cash provided by financing activities |  |  | 216 |  |  |  | 31,978 |  |
| Net increase (decrease) in Cash, cash equivalents and restricted cash |  |  | (36,620 | ) |  |  | 17,418 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  | 308,167 |  |  |  | 4,704 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 271,547 |  |  | $ | 22,122 |  |

[0001104659-22-058798:8k_2_02:37]
EVOlv
TECHNOLOGY

[0001104659-22-058798:8k_2_02:38]
Reconciliation
of FORECASTED 2022 NET Loss to Adjusted EBITDA

[0001104659-22-058798:8k_2_02:39]
(In thousands)

[0001104659-22-058798:8k_2_02:40]
(Unaudited)

[0001104659-22-058798:8k_2_02:41]
|  |  | Twelve Months Ended December 31, 2022 |  |
|  |  | High |  |  | Low |  |
| Net income (loss) |  | $ | (83,000 | ) |  | $ | (85,000 | ) |
| Adjustments to reconcile net income (loss) to Adjusted EBITDA: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 6,000 |  |  |  | 6,000 |  |
| Stock-based compensation |  |  | 11,000 |  |  |  | 11,000 |  |
| Other expense |  |  | 1,000 |  |  |  | 1,000 |  |
| Adjusted EBITDA |  | $ | (65,000 | ) |  | $ | (67,000 | ) |

[0001104659-22-058798:8k_2_02:42]
EVOlv
TECHNOLOGY

[0001104659-22-058798:8k_2_02:43]
SuMMARY
OF KEY OPERATING STATISTICS

[0001104659-22-058798:8k_2_02:44]
(Unaudited)

[0001104659-22-058798:8k_2_02:45]
| ($ in thousands) |  | December 31, 2020 |  |  | March 31, 2021 |  |  | June 30, 2021 |  |  | September 30, 2021 |  |  | December 31, 2021 |  |  | March 31, 2022 |  |
| New customers |  |  | 6 |  |  |  | 13 |  |  |  | 21 |  |  |  | 23 |  |  |  | 27 |  |  |  | 44 |  |
| Total contract value of orders booked |  | $ | 5,956 |  |  | $ | 8,424 |  |  | $ | 10,476 |  |  | $ | 16,995 |  |  | $ | 17,916 |  |  | $ | 19,167 |  |
| Annual recurring revenue |  | $ | 4,034 |  |  | $ | 5,424 |  |  | $ | 7,423 |  |  | $ | 9,932 |  |  | $ | 12,907 |  |  | $ | 16,641 |  |
| Remaining performance obligation |  | $ | 13,381 |  |  | $ | 17,658 |  |  | $ | 24,930 |  |  | $ | 34,152 |  |  | $ | 40,160 |  |  | $ | 50,537 |  |
| Contract value for units in backlog |  |  | n/a |  |  |  | n/a |  |  |  | n/a |  |  |  | n/a |  |  | $ | 11,270 |  |  | $ | 13,213 |  |
| Net additions |  |  | 32 |  |  |  | 64 |  |  |  | 113 |  |  |  | 176 |  |  |  | 136 |  |  |  | 207 |  |
| Ending deployed units |  |  | 214 |  |  |  | 278 |  |  |  | 391 |  |  |  | 567 |  |  |  | 703 |  |  |  | 910 |  |

[0001104659-22-058798:8k_2_02:46]
EVOlv
TECHNOLOGY

[0001104659-22-058798:8k_2_02:47]
Reconciliation
of GAAP to ADJSUTED Gross profit and GAAP operating income TO ADJUSTED OPERATING INCOME

[0001104659-22-058798:8k_2_02:48]
(In thousands)

[0001104659-22-058798:8k_2_02:49]
(Unaudited)

[0001104659-22-058798:8k_2_02:50]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Revenue |  | $ | 8,715 |  |  | $ | 3,999 |  |
| Cost of revenue |  |  | 7,089 |  |  |  | 2,951 |  |
| Gross Profit |  |  | 1,626 |  |  |  | 1,048 |  |
| Stock-based compensation |  |  | 60 |  |  |  | 5 |  |
| Adjusted Gross Profit |  | $ | 1,686 |  |  | $ | 1,053 |  |
| Gross Margin % |  |  | 18.7 | % |  |  | 26.2 | % |
| Adjusted Gross Margin % |  |  | 19.3 | % |  |  | 26.3 | % |

[0001104659-22-058798:8k_2_02:51]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Operating income (loss) GAAP |  | $ | (25,902 | ) |  | $ | (9,147 | ) |
| Stock-based compensation |  |  | 5,190 |  |  |  | 1,082 |  |
| Restructuring expenses |  |  | 324 |  |  |  | - |  |
| Loss on impairment of lease equipment |  |  | 96 |  |  |  | - |  |
| Other one-time expenses |  |  | 1,107 |  |  |  | - |  |
| Adjusted Operating Income (loss) |  | $ | (19,185 | ) |  | $ | (8,065 | ) |

[0001104659-22-058798:8k_2_02:52]
EVOlv
TECHNOLOGY

[0001104659-22-058798:8k_2_02:53]
Reconciliation
of GAAP NEt income to adjusted EBITDA

[0001104659-22-058798:8k_2_02:54]
(In thousands)

[0001104659-22-058798:8k_2_02:55]
(Unaudited)

[0001104659-22-058798:8k_2_02:56]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Net income (loss) |  | $ | (14,551 | ) |  | $ | (13,755 | ) |
| Depreciation & Amortization |  |  | 948 |  |  |  | 452 |  |
| Stock-based compensation |  |  | 5,190 |  |  |  | 1,082 |  |
| Interest and other income (expense) |  |  | (67 | ) |  |  | 2,447 |  |
| Loss on disposal of property & equipment |  |  | - |  |  |  | - |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | - |  |
| Change in fair value of derivative liability |  |  | - |  |  |  | 1,425 |  |
| Change in fair value of contingent earn-out liability |  |  | (4,226 | ) |  |  | - |  |
| Change in fair value of contingently issuable common stock liability |  |  | (1,472 | ) |  |  | - |  |
| Change in fair value of public warrant liability |  |  | (5,586 | ) |  |  | - |  |
| Change in fair value of common stock warrant liability |  |  | - |  |  |  | 736 |  |
| Restructuring expenses |  |  | 324 |  |  |  | - |  |
| Loss on impairment of lease equipment |  |  | 96 |  |  |  | - |  |
| Other one-time expenses |  |  | 1,107 |  |  |  | - |  |
| Adjusted EBITDA |  | $ | (18,237 | ) |  | $ | (7,613 | ) |

[0001104659-22-058798:8k_2_02:57]
EVOlv
TECHNOLOGY

[0001104659-22-058798:8k_2_02:58]
Reconciliation
of GAAP NEt income and earnings per share to ADJUSTED EARNINGS AND earnings per share

[0001104659-22-058798:8k_2_02:59]
(In thousands, except share and per share data)

[0001104659-22-058798:8k_2_02:60]
(Unaudited)

[0001104659-22-058798:8k_2_02:61]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Net income (loss) |  | $ | (14,551 | ) |  | $ | (13,755 | ) |
| Stock-based compensation |  |  | 5,190 |  |  |  | 1,082 |  |
| Change in fair value of derivative liability |  |  | - |  |  |  | 1,425 |  |
| Change in fair value of contingent earn-out liability |  |  | (4,226 | ) |  |  | - |  |
| Change in fair value of contingently issuable common stock liability |  |  | (1,472 | ) |  |  | - |  |
| Change in fair value of public warrant liability |  |  | (5,586 | ) |  |  | - |  |
| Change in fair value of common stock warrant liability |  |  | - |  |  |  | 736 |  |
| Restructuring expenses |  |  | 324 |  |  |  | - |  |
| Loss on impairment of lease equipment |  |  | 96 |  |  |  | - |  |
| Other one-time expenses |  |  | 1,107 |  |  |  | - |  |
| Adjusted earnings (loss) |  | $ | (19,118 | ) |  | $ | (10,512 | ) |
| Weighted average common shares outstanding – basic and diluted |  |  | 142,878,406 |  |  |  | 10,443,323 |  |
| Adjusted EPS |  | $ | (0.13 | ) |  | $ | (1.01 | ) |

[0001104659-22-058798:8k_2_02:62]
# # #
