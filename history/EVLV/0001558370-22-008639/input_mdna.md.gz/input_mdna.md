# EVLV MD&A — 0001558370-22-008639


## mdna

[0001558370-22-008639:mdna:1]
[same as prior period, unchanged from 0001558370-21-015999:mdna:1]

[0001558370-22-008639:mdna:2]
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the merger as a wholly owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC.

[0001558370-22-008639:mdna:3]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of the Merger and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001558370-22-008639:mdna:4]
[same as prior period, unchanged from 0001558370-21-015999:mdna:3]

[0001558370-22-008639:mdna:5]
We are a global leader in AI-based weapons detection for security screening. Unlike conventional walk-through metal detectors, our products use advanced sensors, artificial intelligence software, and cloud services to reliably detect guns, improvised explosives, and large knives while ignoring harmless items like phones and keys. This not only enhances security at venues and facilities but also improves the visitor experience by making screening up to ten times faster than alternatives at up to 70% lower total cost.

[0001558370-22-008639:mdna:6]
Our products have screened over 250 million visitors worldwide. We believe that we have screened more people through advanced systems than any organization other than the United States Transportation Security Administration (“TSA”). Our customers include many iconic venues across a wide variety of industries including major sports teams, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, large industrial workplaces, large school districts, and prominent houses of worship. We offer our products for purchase and primarily under a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue and creates expansion and upsell opportunities.

[0001558370-22-008639:mdna:7]
[same as prior period, unchanged from 0001558370-21-015999:mdna:6]

[0001558370-22-008639:mdna:8]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $8.7 million and $4.0 million for the three months ended

[0001558370-22-008639:mdna:9]
March 31, 2022 and 2021, respectively. We generated a net loss of $14.6 million and $13.8 million for the three months ended March 31, 2022 and 2021, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products in both the United States and international markets, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001558370-22-008639:mdna:10]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through a combination of equity offerings and debt financings. In July 2021, we received gross proceeds of $300.0 million from our PIPE Investment as well as $84.9 million in proceeds, net of redemptions received from the closing of the Merger. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources.”

[0001558370-22-008639:mdna:11]
Merger Agreement

[0001558370-22-008639:mdna:12]
[same as prior period, unchanged from 0001558370-21-015999:mdna:14]

[0001558370-22-008639:mdna:13]
On July 16, 2021, we completed the previously announced Merger, pursuant to the Agreement and Plan of Merger, dated as of March 5, 2021, and amended by the First Amendment to Agreement and Plan of Merger (the “Merger Agreement”), dated as of June 5, 2021. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. and the officers of NHIC, the legal predecessor company, resigned. The officers of Legacy Evolv became the officers of the Company, and the Company listed its shares of common stock, par value $0.0001 per share, on Nasdaq under the symbol “EVLV”.

[0001558370-22-008639:mdna:14]
Prior to the completion of the Merger, we entered into subscription agreements (collectively, the “PIPE Investment”) with certain parties subscribing for shares of our common stock (the “Subscribers”). Pursuant to the PIPE Investment, we issued 30,000,000 shares of common stock for a purchase price of $10.00 per share with gross proceeds of $300.0 million. The purpose of the PIPE Investment was to fund general corporate expenses.

[0001558370-22-008639:mdna:15]
Upon the closing of the Merger, each share of NHIC Class B common stock issued and outstanding immediately prior to the effective time of the Merger, which totaled 10,391,513 shares held by the NHIC Initial Shareholders (“Initial Shareholders”), was automatically converted into one validly-issued share of our common stock.

[0001558370-22-008639:mdna:16]
Additional information regarding the Merger Agreement appears in Note 3 of our condensed consolidated financial statements in Item 1. Part I of this Report.

[0001558370-22-008639:mdna:17]
[same as prior period, unchanged from 0001558370-21-015999:mdna:31]

[0001558370-22-008639:mdna:18]
We have taken, and will continue to take, actions to mitigate the impact of the COVID-19 pandemic on our cash flow and results of operations and financial condition. While we have experienced supply chain challenges during the three months ended March 31, 2022, we do see this being overcome in the near future. In the long-term, we believe that the COVID-19 pandemic may encourage organizations to continue to reassess their security screening processes and may continue to accelerate their adoption of solutions such as touchless security screening, which could create additional demand for our products.

[0001558370-22-008639:mdna:19]
Additional information regarding COVID-19 risks appear in the “Risk Factors” section of our Annual Report on Form 10-K for the year ended December 31, 2021.

[0001558370-22-008639:mdna:20]
[same as prior period, unchanged from 0001558370-21-015999:mdna:39]

[0001558370-22-008639:mdna:21]
[same as prior period, unchanged from 0001558370-21-015999:mdna:40]

[0001558370-22-008639:mdna:22]
[same as prior period, unchanged from 0001558370-21-015999:mdna:59]

[0001558370-22-008639:mdna:23]
[same as prior period, unchanged from 0001558370-21-015999:mdna:60]

[0001558370-22-008639:mdna:24]
[same as prior period, unchanged from 0001558370-21-015999:mdna:61]

[0001558370-22-008639:mdna:25]
Revenue generated by the sale of products represented 60% and 63% of our total revenue for the three months ended March 31, 2022 and 2021, respectively. The remaining revenue was generated from subscription sales and services for our products. Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions. Subscription revenue was $3.0 million and $1.3 million for the three months ended March 31, 2022 and 2021, respectively. With the further development, enhancement, and maintenance of Evolv Insights and its analytical platform during the three months ended December 31, 2021, we expect this source of subscription revenue to become a more significant portion of our total revenue in the year ended December 31, 2022, given its new features, functions and capabilities.

[0001558370-22-008639:mdna:26]
Pricing may also vary by region due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales/bookings/business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products` to our customers.

[0001558370-22-008639:mdna:27]
[same as prior period, unchanged from 0001558370-21-015999:mdna:64]

[0001558370-22-008639:mdna:28]
We believe that we are a global leader in AI-based weapons detection for security screening, offering transformative technologies that enable higher throughput, a more frictionless visitor experience, and substantial cost savings through our product innovations. Our performance is significantly dependent on the investment we make in our research and development efforts and on our ability to be at the forefront of the security screening industry. It is essential that we continually identify and respond to rapidly evolving customer requirements, develop and introduce innovative new products, enhance existing products and generate customer demand for our products. We believe that investment in our security screening products will contribute to long-term revenue growth, but it may adversely affect our near-term profitability.

[0001558370-22-008639:mdna:29]
[same as prior period, unchanged from 0001558370-21-015999:mdna:41]

[0001558370-22-008639:mdna:30]
In connection with the Merger and pursuant to the Merger Agreement, certain of the Legacy Evolv shareholders and Legacy Evolv Service Providers are entitled to receive additional shares of the Company’s common stock (the “Earn-Out Shares”) upon the Company achieving certain milestones.

[0001558370-22-008639:mdna:31]
The Earn-Out Shares are classified as liabilities in our condensed consolidated balance sheets and were initially measured at fair value. Each reporting period, the Earn-Out Shares are remeasured and changes in the fair value of the contingent earn-out are recorded in other income (expense), net in our condensed consolidated statements of operations and comprehensive loss. When the Triggering Events have been achieved and the Earn-Out Shares are issued, the

[0001558370-22-008639:mdna:32]
Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001558370-22-008639:mdna:33]
Additional information regarding Contingent Earn-out Shares vesting provisions and accounting treatment appear in Note 2 of our consolidated financial statements for the year ended December 31, 2021 of our Annual Report on Form 10-K.

[0001558370-22-008639:mdna:34]
[same as prior period, unchanged from 0001558370-21-015999:mdna:50]

[0001558370-22-008639:mdna:35]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 Founder Shares. 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC. The remaining 1,897,500 outstanding shares shall vest upon the Company achieving certain milestones.

[0001558370-22-008639:mdna:36]
The Founders Shares (the “Contingently Issuable Common Stock”) are classified as liabilities in our condensed consolidated balance sheets and were initially measured at fair value. Each reporting period, the Founders Shares are remeasured and changes in the fair value of the contingently issuable common stock are recorded in other income (expense), net in our condensed consolidated statements of operations and comprehensive loss. When the Triggering Events have been achieved and the Founders Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001558370-22-008639:mdna:37]
Additional information regarding Contingently Issuable Common Stock vesting provisions and accounting treatment appear in Note 2 of our consolidated financial statements for the year ended December 31, 2021 of our Annual Report on Form 10-K.

[0001558370-22-008639:mdna:38]
[same as prior period, unchanged from 0001558370-21-015999:mdna:66]

[0001558370-22-008639:mdna:39]
[same as prior period, unchanged from 0001558370-21-015999:mdna:67]

[0001558370-22-008639:mdna:40]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, (2) from the sale of products, inclusive of SaaS and maintenance, and (3) professional services. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer for product sales and upon installation for subscriptions. Revenue is recognized net of sales tax.

[0001558370-22-008639:mdna:41]
[same as prior period, unchanged from 0001558370-21-015999:mdna:69]

[0001558370-22-008639:mdna:42]
We derive a portion of our revenue from the sale of our Express and Edge equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We expect product revenue to decline as a percentage of our overall revenue overtime as more and more customers enter full subscription transactions with us and as our subscription becomes more valuable to our business.

[0001558370-22-008639:mdna:43]
[same as prior period, unchanged from 0001558370-21-015999:mdna:71]

[0001558370-22-008639:mdna:44]
In addition to selling our products directly to customers, we also lease our Express and Edge equipment which we classify as subscription revenue. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as they do not meet any of the sales-type lease criteria per ASC 842 and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001558370-22-008639:mdna:45]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (1) distinct services, such as SaaS, maintenance installation and training, and (2) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern the equipment lease and SaaS/maintenance performance

[0001558370-22-008639:mdna:46]
obligations are classified as a single category of subscription revenue in our condensed consolidated statements of operations and comprehensive loss.

[0001558370-22-008639:mdna:47]
[same as prior period, unchanged from 0001558370-21-015999:mdna:75]

[0001558370-22-008639:mdna:48]
We provide SaaS, maintenance installation and training services for our products. Revenue for installation and training are recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes and when-and-if available threat updates. SaaS and maintenance revenue is recognized ratably over the period of the arrangement. We sell separately priced extended or nonstandard warranty services and preventative maintenance plans, which are recognized ratably over the associated service period.

[0001558370-22-008639:mdna:49]
[same as prior period, unchanged from 0001558370-21-015999:mdna:77]

[0001558370-22-008639:mdna:50]
We recognize cost of revenue in the same manner that the related revenue is recognized.

[0001558370-22-008639:mdna:51]
[same as prior period, unchanged from 0001558370-21-015999:mdna:79]

[0001558370-22-008639:mdna:52]
Cost of product revenue consists primarily of costs paid to third party manufacturers, labor costs, shipping costs, amortization expense related to internal-use software, and stock-based compensation expense.

[0001558370-22-008639:mdna:53]
[same as prior period, unchanged from 0001558370-21-015999:mdna:81]

[0001558370-22-008639:mdna:54]
Cost of subscription revenue consists primarily of labor costs, shipping costs, amortization expense related to internal-use software, depreciation expense related to leased units, and stock-based compensation expense.

[0001558370-22-008639:mdna:55]
[same as prior period, unchanged from 0001558370-21-015999:mdna:83]

[0001558370-22-008639:mdna:56]
Cost of services revenue consists of costs related to SaaS and maintenance services. Costs of services revenue related to SaaS consists of costs of maintaining the Evolv cloud portal and our internal-use software, associated with our Evolv Express units. Cost of services revenue related to maintenance consists primarily of labor, spare parts, shipping costs, field service repair costs, equipment, supplies, and stock-based compensation expense.

[0001558370-22-008639:mdna:57]
A provision for the estimated cost related to warranty is recorded to cost of product, subscription, or services revenue at the time the associated revenue is recognized as necessary. Our estimate of costs to service the warranty obligations is based on historical experience and expectations of future conditions. As of March 31, 2022, the warranty accrual was less than $0.1 million.

[0001558370-22-008639:mdna:58]
[same as prior period, unchanged from 0001558370-21-015999:mdna:86]

[0001558370-22-008639:mdna:59]
[same as prior period, unchanged from 0001558370-21-015999:mdna:87]

[0001558370-22-008639:mdna:60]
|  | • | Market conditions that may impact our pricing; |

[0001558370-22-008639:mdna:61]
|  | • | Product mix changes between established products and new products; |

[0001558370-22-008639:mdna:62]
|  | • | Our cost structure for manufacturing operations, including contract manufacturers, relative to volume, and our product support obligations; |

[0001558370-22-008639:mdna:63]
|  | • | Our ability to maintain our costs on the components that go into the manufacture of our product; and |

[0001558370-22-008639:mdna:64]
|  | • | Write-offs of inventory. |

[0001558370-22-008639:mdna:65]
[same as prior period, unchanged from 0001558370-21-015999:mdna:92]

[0001558370-22-008639:mdna:66]
[same as prior period, unchanged from 0001558370-21-015999:mdna:93]

[0001558370-22-008639:mdna:67]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, stock-based compensation, prototypes, design expenses, consulting and contractor costs, and the impact of the capitalization of costs associated with developing the Evolv cloud portal, our internal-use software. We expect research and development costs will increase on an absolute dollar basis for the year ended December 31, 2022 compared to the year ended December 31, 2021 as we continue to invest in advancing our portfolio of security screening products.

[0001558370-22-008639:mdna:68]
[same as prior period, unchanged from 0001558370-21-015999:mdna:95]

[0001558370-22-008639:mdna:69]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success and global service, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will increase on an absolute dollar basis for the year ended December 31, 2022 compared to the year ended December 31, 2021 as we expand our headcount and initiate new marketing campaigns.

[0001558370-22-008639:mdna:70]
[same as prior period, unchanged from 0001558370-21-015999:mdna:97]

[0001558370-22-008639:mdna:71]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and sales tax contingencies. We expect our general and administrative expenses will increase on an absolute dollar basis for the year ended December 31, 2022 compared to the year ended December 31, 2021 as a result of operating as a public company, including expenses necessary to comply with the rules and regulations applicable to companies listed on a national securities exchange and related to compliance and reporting obligations pursuant to the rules and regulations of the SEC, as well as increased expenses for general and director and officer insurance, and other administrative and professional services. In addition, we expect to incur additional costs as we hire additional personnel and enhance our infrastructure to support the anticipated growth of the business.

[0001558370-22-008639:mdna:72]
[same as prior period, unchanged from 0001558370-21-015999:mdna:99]

[0001558370-22-008639:mdna:73]
Impairment of property and equipment relates to Edge units and Express prototype units that were removed from service and retired. We are transitioning our domestic customers from the Edge units to our most current Express units, which also resulted in an impairment of the remaining economic value of such assets.

[0001558370-22-008639:mdna:74]
[same as prior period, unchanged from 0001558370-21-015999:mdna:101]

[0001558370-22-008639:mdna:75]
Interest expense includes cash interest paid on our long-term debt and amortization of deferred financing fees and costs.

[0001558370-22-008639:mdna:76]
Interest Income

[0001558370-22-008639:mdna:77]
Interest income relates to interest earned on our lease receivables for our Evolv Express units.

[0001558370-22-008639:mdna:78]
[same as prior period, unchanged from 0001558370-21-015999:mdna:109]

[0001558370-22-008639:mdna:79]
In August through September 2019 and in September 2020, we issued Convertible Notes to several investors (the “2020 Convertible Notes”) that provided a conversion option whereby upon the closing of a specified financing event the notes would automatically convert into shares of the same class and series of our capital stock issued to other investors in the financing at a conversion price equal to 85% and 80%, respectively, of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative that was required to be bifurcated and accounted for separately from the notes. The derivative liability was initially recorded at fair value upon issuance of

[0001558370-22-008639:mdna:80]
6

[0001558370-22-008639:mdna:81]
the notes and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the derivative liability are recognized in the condensed consolidated statements of operations and comprehensive loss. In October 2019, the specified financing event was consummated, as such the 2020 Convertible Notes issued August through September 2019 were converted into shares of Series B-1 Preferred Stock and the derivative liability was extinguished.

[0001558370-22-008639:mdna:82]
In January and February 2021, we entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability and included in long-term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method.

[0001558370-22-008639:mdna:83]
In June 2021, we modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. The modification of the 2021 Convertible Notes resulted in the recognition of a derivative liability for the fair value of the 1,000,000 NHIC shares as of June 21, 2021 as well as a bifurcated embedded derivative for conversion feature into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors.

[0001558370-22-008639:mdna:84]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense), net in the condensed consolidated statements of operations and comprehensive loss.

[0001558370-22-008639:mdna:85]
[same as prior period, unchanged from 0001558370-21-015999:mdna:114]

[0001558370-22-008639:mdna:86]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders are entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss.

[0001558370-22-008639:mdna:87]
[same as prior period, unchanged from 0001558370-21-015999:mdna:116]

[0001558370-22-008639:mdna:88]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 shares of Founder Shares. 1,897,500 shares vested at the closing of the Merger, 1,897,500 shares shall vest upon us achieving certain milestones and 517,500 shares were contributed to Give Evolv LLC. Those 1,897,500 outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss.

[0001558370-22-008639:mdna:89]
[same as prior period, unchanged from 0001558370-21-015999:mdna:118]

[0001558370-22-008639:mdna:90]
In connection with the closing of the Merger, the Company assumed a warrant to purchase shares of common stock (the “Public Warrants”). We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger with the offset to additional paid-in capital.

[0001558370-22-008639:mdna:91]
[same as prior period, unchanged from 0001558370-21-015999:mdna:120]

[0001558370-22-008639:mdna:92]
We classify certain warrants for the purchase of shares of our common stock as a liability on our condensed consolidated balance sheets as these warrants are freestanding financial instruments that may require us to adjust the exercise price and number of shares that is not consistent with a fixed-for-fixed option pricing model. The warrant liability is initially recorded at fair value on the issuance date of each warrant and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the common stock warrant liability are recognized as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss. Changes in fair value of the common stock warrant liability will continue to be recognized until the warrants are exercised, expire or qualify for equity classification. In connection with the closing of the Merger, all common stock warrants that were issued prior to the closing of the Merger were converted into shares of the Company’s common stock.

[0001558370-22-008639:mdna:93]
[same as prior period, unchanged from 0001558370-21-015999:mdna:122]

[0001558370-22-008639:mdna:94]
Our income tax provision consists of an estimate for U.S. federal and state income taxes based on enacted rates, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. There is no provision for income taxes for the three months ended March 31, 2022 and 2021 because we have historically incurred net operating losses and maintain a full valuation allowance against its deferred tax assets.

[0001558370-22-008639:mdna:95]
8

[0001558370-22-008639:mdna:96]
[same as prior period, unchanged from 0001558370-21-015999:mdna:124]

[0001558370-22-008639:mdna:97]
Comparison of the Three Months Ended March 31, 2022 and 2021

[0001558370-22-008639:mdna:98]
The following table summarizes our results of operations for the three months ended March 31, 2022 and 2021 (in thousands):

[0001558370-22-008639:mdna:99]
| ​ | ​ | Three Months Ended March 31, | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2022 | ​ | 2021 | ​ | $ Change |  | % Change |
| Revenue: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ | ​ |
| Product revenue | ​ | $ | 5,194 | ​ | $ | 2,502 | ​ | $ | 2,692 | ​ | 108 | % |
| Subscription revenue | ​ |  | 3,020 | ​ |  | 1,300 | ​ |  | 1,720 | ​ | 132 | ​ |
| Service revenue | ​ |  | 501 | ​ |  | 197 | ​ |  | 304 | ​ | 154 | ​ |
| Total revenue | ​ |  | 8,715 | ​ |  | 3,999 | ​ |  | 4,716 | ​ | 118 | ​ |
| Cost of revenue: | ​ |  |  | ​ |  |  | ​ |  | ​ | ​ | ​ | ​ |
| Cost of product revenue | ​ |  | 5,576 | ​ |  | 2,229 | ​ |  | 3,347 | ​ | 150 | ​ |
| Cost of subscription revenue | ​ |  | 1,065 | ​ |  | 595 | ​ |  | 470 | ​ | 79 | ​ |
| Cost of service revenue | ​ |  | 448 | ​ |  | 127 | ​ |  | 321 | ​ | 253 | ​ |
| Total cost of revenue | ​ |  | 7,089 | ​ |  | 2,951 | ​ |  | 4,138 | ​ | 140 | ​ |
| Gross profit | ​ |  | 1,626 | ​ |  | 1,048 | ​ |  | 578 | ​ | 55 | ​ |
| Operating expenses: | ​ |  |  | ​ |  |  | ​ |  | ​ | ​ | ​ | ​ |
| Research and development | ​ |  | 4,286 | ​ |  | 3,612 | ​ |  | 674 | ​ | 19 | ​ |
| Sales and marketing | ​ |  | 12,053 | ​ |  | 3,684 | ​ |  | 8,369 | ​ | 227 | ​ |
| General and administrative | ​ | ​ | 11,093 | ​ | ​ | 2,899 | ​ | ​ | 8,194 | ​ | 283 | ​ |
| Loss from impairment of property and equipment | ​ |  | 96 | ​ |  | — | ​ |  | 96 | ​ | * | ​ |
| Total operating expenses | ​ |  | 27,528 | ​ |  | 10,195 | ​ |  | 17,333 | ​ | 170 | ​ |
| Loss from operations | ​ |  | (25,902) | ​ |  | (9,147) | ​ |  | (16,755) | ​ | 183 | ​ |
| Other income (expense), net: | ​ |  |  | ​ |  |  | ​ |  | ​ | ​ | ​ | ​ |
| Interest expense | ​ |  | (142) | ​ |  | (2,447) | ​ |  | 2,305 | ​ | (94) | ​ |
| Interest income | ​ | ​ | 209 | ​ | ​ | — | ​ | ​ | 209 | ​ | * | ​ |
| Change in fair value of derivative liability | ​ | ​ | - | ​ | ​ | (1,425) | ​ | ​ | 1,425 | ​ | * | ​ |
| Change in fair value of contingent earn-out liability | ​ |  | 4,226 | ​ |  | — | ​ |  | 4,226 | ​ | * | ​ |
| Change in fair value of contingently issuable common stock liability | ​ |  | 1,472 | ​ |  | — | ​ |  | 1,472 | ​ | * | ​ |
| Change in fair value of public warrant liability | ​ | ​ | 5,586 | ​ | ​ | — | ​ | ​ | 5,586 | ​ | * | ​ |
| Change in fair value of common stock warrant liability | ​ | ​ | - | ​ | ​ | (736) | ​ | ​ | 736 | ​ | * | ​ |
| Total other income (expense), net | ​ |  | 11,351 | ​ |  | (4,608) | ​ |  | 15,959 | ​ | (346) | ​ |
| Net loss | ​ | $ | (14,551) | ​ | $ | (13,755) | ​ | $ | (796) | ​ | 6 | % |

[0001558370-22-008639:mdna:100]
* – Not meaningful

[0001558370-22-008639:mdna:101]
[same as prior period, unchanged from 0001558370-21-015999:mdna:128]

[0001558370-22-008639:mdna:102]
[same as prior period, unchanged from 0001558370-21-015999:mdna:232]

[0001558370-22-008639:mdna:103]
| ​ | ​ | Three Months Ended March 31, | ​ | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2022 | ​ | 2021 | ​ | ​ | $ Change |  | % Change |
| Product revenue | ​ | $ | 5,194 | ​ | $ | 2,502 | ​ | ​ | $ | 2,692 | ​ | 108 | % |
| Cost of product revenue | ​ | $ | 5,576 | ​ | $ | 2,229 | ​ | ​ | $ | 3,347 | ​ | 150 | % |
| Gross profit - Product revenue | ​ | $ | (382) | ​ | $ | 273 | ​ | ​ | $ | (655) | ​ | (240) | % |
| Gross profit margin - Product revenue | ​ |  | (7) | % |  | 11 | % | ​ | ​ | N/A | ​ | (18) | % |

[0001558370-22-008639:mdna:104]
The increase in product revenue and increase in cost of product revenue are primarily due to the increases in product sales of Evolv Express units, which included the significant increase in the adoption of Evolv Express units by schools, hotels and casinos, and professional sports arenas. The decreases in gross profit and gross profit margin are primarily driven by purchase price variances recorded on raw materials and the costs associated with the write-off of scrap inventory incurred without corresponding revenue. We expect to see improvement in our gross margins as we continue to engineer our product with lower cost components. As we continue to gain leverage in the marketplace with increased sales, we expect higher discounts from suppliers. We also expect to see improvements in gross margin to the extent shipping costs and high demand costs decline when global supply chain disruptions ease.

[0001558370-22-008639:mdna:105]
[same as prior period, unchanged from 0001558370-21-015999:mdna:234]

[0001558370-22-008639:mdna:106]
| ​ | ​ | Three Months Ended March 31, | ​ | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2022 | ​ | 2021 | ​ | ​ | $ Change |  | % Change |
| Subscription revenue | ​ | $ | 3,020 | ​ | $ | 1,300 | ​ | ​ | $ | 1,720 | ​ | 132 | % |
| Cost of subscription revenue | ​ | $ | 1,065 | ​ | $ | 595 | ​ | ​ | $ | 470 | ​ | 79 | % |
| Gross profit - Subscription revenue | ​ | $ | 1,955 | ​ | $ | 705 | ​ | ​ | $ | 1,250 | ​ | 177 | % |
| Gross profit margin - Subscription revenue | ​ |  | 65 | % |  | 54 | % | ​ | ​ | N/A | ​ | 11 | % |

[0001558370-22-008639:mdna:107]
The increase in subscription revenue and increase in cost of subscription revenue are primarily due to a higher number of active Evolv Express units installed during the period, growth in our customer base and contribution from our channel partners. The increase in gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin was primarily driven by increased recurring revenue from increased active subscriptions and customer growth, which we expect to continue.

[0001558370-22-008639:mdna:108]
Service Revenue

[0001558370-22-008639:mdna:109]
| ​ | ​ | Three Months Ended March 31, | ​ | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2022 | ​ | 2021 | ​ | ​ | $ Change |  | % Change |
| Service revenue | ​ | $ | 501 | ​ | $ | 197 | ​ | ​ | $ | 304 | ​ | 154 | % |
| Cost of service revenue | ​ | $ | 448 | ​ | $ | 127 | ​ | ​ | $ | 321 | ​ | 253 | % |
| Gross profit - Service revenue | ​ | $ | 53 | ​ | $ | 70 | ​ | ​ | $ | (17) | ​ | (24) | % |
| Gross profit margin - Service revenue | ​ |  | 11 | % |  | 36 | % | ​ | ​ | N/A | ​ | (25) | % |

[0001558370-22-008639:mdna:110]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding twelve months and increased installation and training related to the Evolv Express units. The decrease in gross profit is due the increase in field services costs associated with the Evolv Express units.

[0001558370-22-008639:mdna:111]
[same as prior period, unchanged from 0001558370-21-015999:mdna:138]

[0001558370-22-008639:mdna:112]
| ​ | ​ | Three Months Ended March 31, | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2022 | ​ | 2021 | ​ | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | ​ | $ | 3,220 | ​ | $ | 990 | ​ | $ | 2,230 | ​ | 225 | % |
| Materials and prototypes | ​ | ​ | 388 | ​ | ​ | 2,284 | ​ | ​ | (1,896) | ​ | (83) | ​ |
| Professional fees | ​ | ​ | 562 | ​ | ​ | 260 | ​ | ​ | 302 | ​ | 116 | ​ |
| Facilities related and other | ​ |  | 116 | ​ | ​ | 78 | ​ |  | 38 | ​ | 49 | ​ |
| Total research and development expenses | ​ | $ | 4,286 | ​ | $ | 3,612 | ​ | $ | 674 | ​ | 19 | % |

[0001558370-22-008639:mdna:113]
The increase in personnel related expenses is due to an increase in additional personnel costs resulting from new hires in our research and development function during the second half of 2021 and the first three months in 2022, an increase in bonuses, an increase in stock-based compensation and an increase in recruiting costs, partially offset by of $0.3 million of wages capitalized in association with the development of internal-use software. The decrease in materials and prototype costs is due to the transition from prototype production to standard manufacturing of the Evolv Express, which results in lower prototyping costs. The increase in professional fees is due to an increase in consulting related to research and development efforts for Evolv Express units. The capitalization of the development of internal-use software is due to internal and external costs associated with further developing the Evolv cloud portal associated with our Evolv Express units.

[0001558370-22-008639:mdna:114]
[same as prior period, unchanged from 0001558370-21-015999:mdna:140]

[0001558370-22-008639:mdna:115]
| ​ | ​ | Three Months Ended March 31, | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2022 | ​ | 2021 | ​ | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | ​ | $ | 8,379 | ​ | $ | 2,767 | ​ | $ | 5,612 | ​ | 203 | % |
| Direct marketing and customer field services | ​ | ​ | 2,082 | ​ | ​ | 401 | ​ | ​ | 1,681 | ​ | 419 | ​ |
| Travel and entertainment | ​ | ​ | 686 | ​ | ​ | 151 | ​ | ​ | 535 | ​ | 354 | ​ |
| Professional fees | ​ | ​ | 272 | ​ | ​ | 186 | ​ | ​ | 86 | ​ | 46 | ​ |
| Facilities related and other | ​ |  | 634 | ​ | ​ | 179 | ​ |  | 455 | ​ | 254 | ​ |
| Total sales and marketing expenses | ​ | $ | 12,053 | ​ | $ | 3,684 | ​ | $ | 8,369 | ​ | 227 | % |

[0001558370-22-008639:mdna:116]
The increase in personnel related expenses is due to an increase in additional personnel costs resulting from new hires in our sales and marketing functions, which includes functions such as partner development, customer success, technical sales and support, and other business development, during the second half of 2021 and the first three months in 2022, an increase in bonuses and commissions, and an increase in stock-based compensation. The increase in direct marketing and customer field services is due to an increase in trade shows and events and an increase in sales volume. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings and events. The increase in professional fees is due to an increase in consulting fees related to business development and marketing as part of efforts to drive sales growth. The increase in facilities related and other expenses is primarily due to an increase in subscriptions related to gathering market research.

[0001558370-22-008639:mdna:117]
11

[0001558370-22-008639:mdna:118]
[same as prior period, unchanged from 0001558370-21-015999:mdna:142]

[0001558370-22-008639:mdna:119]
| ​ | ​ | Three Months Ended March 31, | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2022 | ​ | 2021 | ​ | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | ​ | $ | 4,235 | ​ | $ | 574 | ​ | $ | 3,661 | ​ | 638 | % |
| Professional fees | ​ | ​ | 3,314 | ​ | ​ | 2,004 | ​ | ​ | 1,310 | ​ | 65 | ​ |
| Director and officer insurance | ​ | ​ | 1,427 | ​ | ​ | 92 | ​ | ​ | 1,335 | ​ | 1,451 | ​ |
| Non-income taxes | ​ | ​ | 776 | ​ | ​ | — | ​ | ​ | 776 | ​ | * | ​ |
| Facilities related and other | ​ |  | 1,341 | ​ | ​ | 229 | ​ |  | 1,112 | ​ | 486 | ​ |
| Total general and administrative expenses | ​ | $ | 11,093 | ​ | $ | 2,899 | ​ | $ | 8,194 | ​ | 283 | % |

[0001558370-22-008639:mdna:120]
* – Not meaningful

[0001558370-22-008639:mdna:121]
The increase in personnel related expenses is due to an increase in salaries and related costs resulting from expanding our administrative team, an increase in stock-based compensation, and severance. The increase in professional fees is due to an increase in accounting, audit, tax, and legal services provided to the Company to support public company requirements. The increase in director and officer insurance expense is due to us operating as a public company. The increase in non-income taxes is due to an increase in property taxes as well as an increase in our sales tax contingency liability as we may owe additional sales and use taxes in various jurisdictions. The increase in facilities related and other expenses is due to us relocating to our new corporate headquarters with a larger office space to accommodate our growth and a $0.4 million one-time payment to a former employee.

[0001558370-22-008639:mdna:122]
[same as prior period, unchanged from 0001558370-21-015999:mdna:144]

[0001558370-22-008639:mdna:123]
Loss from impairment of property and equipment was $0.1 million for the three months ended March 31, 2022. There was no impairment for the three months ended March 31, 2021. This related to Edge units and Express prototype units that were removed from service and retired. We are transitioning our domestic customers from the Edge units to our most current Express units, which also resulted in an impairment of the remaining economic value of such assets.

[0001558370-22-008639:mdna:124]
[same as prior period, unchanged from 0001558370-21-015999:mdna:146]

[0001558370-22-008639:mdna:125]
Interest expense was $0.1 million for the three months ended March 31, 2022, compared to $2.4 million for the three months ended March 31, 2021. The decrease of $2.3 million was primarily due to the Convertible Notes and corresponding accrued interest being converted into the Company’s common stock upon closing of the Merger.

[0001558370-22-008639:mdna:126]
Interest Income

[0001558370-22-008639:mdna:127]
Interest income was $0.2 million for the three months ended March 31, 2022. There was no interest income for the three months ended March 31, 2021. This related to the interest earned our lease receivables for our Evolv Express units.

[0001558370-22-008639:mdna:128]
[same as prior period, unchanged from 0001558370-21-015999:mdna:152]

[0001558370-22-008639:mdna:129]
Change in fair value of the derivative liability was $0 for the three months ended March 31, 2022, compared to $1.4 million for the three months ended March 31, 2021. The change in fair value of the derivative liability was due to mark to market fluctuations prior to the conversion of the Convertible Notes upon the closing of the Merger.

[0001558370-22-008639:mdna:130]
[same as prior period, unchanged from 0001558370-21-015999:mdna:154]

[0001558370-22-008639:mdna:131]
Change in fair value of the contingent earn-out liability was $4.2 million for the three months ended March 31, 2022, compared to $0 for the three months ended March 31, 2021. This was due to establishing the contingent earn-out liability in connection with the closing of the Merger. The change in fair value of the contingent earn-out liability from

[0001558370-22-008639:mdna:132]
issuance through period end is due to mark to market fluctuations driven by a decrease in stock price, resulting in income recognized in other income (expense), net in our condensed consolidated statements of operations and comprehensive loss.

[0001558370-22-008639:mdna:133]
[same as prior period, unchanged from 0001558370-21-015999:mdna:156]

[0001558370-22-008639:mdna:134]
Change in fair value of the contingently issuable common stock liability was $1.5 million for the three months ended March 31, 2022, compared to $0 for the three months ended March 31, 2021. This was due to establishing the contingently issuable common stock liability in connection with the closing of the Merger. The change in fair value of the contingently issuable common stock liability from issuance through period end is due to mark to market fluctuations driven by a decrease in stock price, resulting in income recognized in other income (expense), net in our condensed consolidated statements of operations and comprehensive loss.

[0001558370-22-008639:mdna:135]
[same as prior period, unchanged from 0001558370-21-015999:mdna:158]

[0001558370-22-008639:mdna:136]
Change in fair value of the public warrant liability was $5.6 million for the three months ended March 31, 2022, compared to $0 for the three months ended March 31, 2021. This was due to establishing the public warrant liability in connection with the closing of the Merger. The change in fair value of the public warrant liability from issuance through period end is due to mark to market fluctuations driven by a decrease in the publicly traded warrant price, resulting in income recognized in other income (expense), net in our condensed consolidated statements of operations and comprehensive loss.

[0001558370-22-008639:mdna:137]
[same as prior period, unchanged from 0001558370-21-015999:mdna:160]

[0001558370-22-008639:mdna:138]
Change in fair value of the common stock warrant liability was $0 for the three months ended March 31, 2022, compared to $0.7 million for the three months ended March 31, 2021. The change in fair value of the common stock warrant liability was due mark to market fluctuations prior to the conversion of the common stock warrant liability upon the closing of the Merger.

[0001558370-22-008639:mdna:139]
[same as prior period, unchanged from 0001558370-21-015999:mdna:198]

[0001558370-22-008639:mdna:140]
There is no provision for income taxes for the three months ended March 31, 2022 and 2021 because we have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets. We have provided a valuation allowance for all of our deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001558370-22-008639:mdna:141]
[same as prior period, unchanged from 0001558370-21-015999:mdna:200]

[0001558370-22-008639:mdna:142]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. Prior to the Merger, as an early-stage company, we primarily obtained cash to fund our operations through preferred stock offerings and debt instruments. As of March 31, 2022, we had $270.9 million in cash and cash equivalents. We incurred a net loss of $14.6 million and $13.8 million for the three months ended March 31, 2022 and 2021, respectively. We incurred cash outflows from operating activities of $35.9 million and $12.0 million during the three months ended March 31, 2022 and 2021, respectively.

[0001558370-22-008639:mdna:143]
We expect our cash and cash equivalents, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our

[0001558370-22-008639:mdna:144]
sales and marketing teams worldwide. We are likely to require additional capital to respond to technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions or unforeseen circumstances and in either the short-term or long-term may determine to engage in equity or debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, the widespread COVID-19 pandemic, including variants, has resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001558370-22-008639:mdna:145]
PIPE Investment and Proceeds from the closing of the Merger

[0001558370-22-008639:mdna:146]
In July 2021, we received gross proceeds of $300.0 million from our PIPE Investment, as well as $84.9 million in proceeds, net of redemptions received in connection with the closing of the Merger.

[0001558370-22-008639:mdna:147]
[same as prior period, unchanged from 0001558370-21-015999:mdna:206]

[0001558370-22-008639:mdna:148]
In December 2020, we entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024, and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022, which extinguished the 2020 Silicon Valley Bank Term Loan. Under the terms of the JPM Credit Agreement, we received proceeds of $10.0 million. As of March 31, 2022, we had $9.9 million of debt outstanding. In September and December of 2020, we issued a total of $4.0 million of convertible notes (the “2020 Convertible Notes”). In January and February 2021, we issued a total of $30.0 million of convertible notes with a maturity date of September 2021.

[0001558370-22-008639:mdna:149]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense), net, which was recorded during the three and nine months ended September 30, 2021.

[0001558370-22-008639:mdna:150]
Material Cash Requirements for Known Contractual and Other Obligations

[0001558370-22-008639:mdna:151]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of March 31, 2022. We anticipate fulfilling such commitments with our existing cash and cash equivalents obtained through operations, proceeds from long-term debt, closing of the Merger, and issuance of common stock in connection with the PIPE investment. Cash and cash equivalents amounted to $270.9 million as of March 31, 2022.

[0001558370-22-008639:mdna:152]
We entered into a new lease agreement for additional office space starting May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. We are required to maintain a minimum cash balance of $0.7 million as a security deposit on the leased space which is classified as restricted cash, current and restricted cash, non-current on the condensed consolidated balance sheet as of March 31, 2022. Total future minimum lease payments under this noncancelable operating lease amount to $3.0 million. See Note 6 to our condensed consolidated financial statements for the three months ended March 31, 2022.

[0001558370-22-008639:mdna:153]
[same as prior period, unchanged from 0001558370-21-015999:mdna:209]

[0001558370-22-008639:mdna:154]
[same as prior period, unchanged from 0001558370-21-015999:mdna:210]

[0001558370-22-008639:mdna:155]
| ​ |  | Three Months Ended |
| ​ | ​ | March 31, |
| ​ | ​ | 2022 | ​ | 2021 |
| Net cash used in operating activities | ​ | $ | (35,867) | ​ | $ | (12,038) |
| Net cash used in investing activities |  | ​ | (969) |  | ​ | (2,522) |
| Net cash provided by financing activities |  | ​ | 216 |  | ​ | 31,978 |
| Net increase (decrease) in cash, cash equivalents and restricted cash | ​ | $ | (36,620) | ​ | $ | 17,418 |

[0001558370-22-008639:mdna:156]
[same as prior period, unchanged from 0001558370-21-015999:mdna:212]

[0001558370-22-008639:mdna:157]
| ​ |  | Three Months Ended |
| ​ | ​ | March 31, |
| ​ | ​ | 2022 | ​ | 2021 |
| Net loss | ​ | $ | (14,551) | ​ | $ | (13,755) |
| Noncash (income) expense |  | ​ | (4,845) |  | ​ | 5,976 |
| Changes in operating assets and liabilities |  | ​ | (16,471) |  | ​ | (4,259) |
| Net cash used in operating activities | ​ | $ | (35,867) | ​ | $ | (12,038) |

[0001558370-22-008639:mdna:158]
Net loss increased from $13.8 million for the three months ended March 31, 2021 to $14.6 million for the three months ended March 31, 2022 as a result of the factors discussed in the “Results of Operations” above.

[0001558370-22-008639:mdna:159]
Noncash income for the three months ended March 31, 2022 was primarily driven by $11.3 million of positive fair value adjustments to financial liabilities, partially offset by $5.2 million of stock-based compensation expense and $1.0 million of depreciation and amortization expense. Noncash expenses for the three months ended March 31, 2021 were primarily driven by $2.2 million of negative fair value adjustments to financial liabilities, $2.3 million of noncash interest expense primarily related to the accretion of the debt discount associated with the 2021 Convertible Notes and $1.1 million of stock-based compensation expense.

[0001558370-22-008639:mdna:160]
The $16.5 million change in operating assets and liabilities for the three months ended March 31, 2022 are primarily related to the following:

[0001558370-22-008639:mdna:161]
|  | ● | $7.0 million increase in inventory primarily due to increased production of units to meet customer demand; |

[0001558370-22-008639:mdna:162]
|  | ● | $5.3 million increase in prepaid expenses and other current assets primarily due to an increase in prepaid deposits related to orders placed for Express units; |

[0001558370-22-008639:mdna:163]
|  | ● | $2.1 million increase in accounts receivable primarily due to higher sales driven by an increase in customers and the timing of billings to customers; |

[0001558370-22-008639:mdna:164]
|  | ● | $2.1 million decrease in accrued expenses and other current liabilities primarily due to the payment of 2021 compensation, bonuses and commissions paid during the three months ended March 31, 2022; |

[0001558370-22-008639:mdna:165]
|  | ● | $1.9 million decrease in accounts payable due to the timing of invoicing and payments to vendors; |

[0001558370-22-008639:mdna:166]
|  | ● | $0.5 million decrease in deferred rent due to the write-off of our deferred rent balances upon the adoption of the new lease standard; |

[0001558370-22-008639:mdna:167]
|  | ● | $0.4 million increase in commission assets primarily due to a continued shift towards a subscription-based model; |

[0001558370-22-008639:mdna:168]
|  | ● | $0.2 million decrease in operating lease liabilities due to the payments made on our operating lease, partially offset by |

[0001558370-22-008639:mdna:169]
|  | ● | $2.8 million increase in deferred revenue primarily due to an increase in billings associated with higher sales. |

[0001558370-22-008639:mdna:170]
The $4.3 million change in operating assets and liabilities for the three months ended March 31, 2021 are primarily related to the following:

[0001558370-22-008639:mdna:171]
|  | ● | $4.1 million increase in prepaid expenses and other current assets primarily due to prepaid subscriptions and insurance; |

[0001558370-22-008639:mdna:172]
|  | ● | $1.0 million increase in commission assets and deferred revenue primarily due to a continued shift towards a subscription-based model; |

[0001558370-22-008639:mdna:173]
|  | ● | $0.9 million increase in accounts receivable primarily due to higher sales driven by an increase in customers and the timing of billings to customers; |

[0001558370-22-008639:mdna:174]
|  | ● | $0.4 million increase in inventory primarily due to lower shipments to customers in the first quarter of the year compared to the fourth quarter of the year and due to an increase in the production of Express units to meet customer demand, partially offset by |

[0001558370-22-008639:mdna:175]
|  | ● | $2.3 million increase in accrued expenses and other current liabilities and accounts payable primarily due to an increase in research and development and general and administrative expenses due to the growth in our business, the anticipation of the closing of the Merger, and the timing of vendor invoicing and payments. |

[0001558370-22-008639:mdna:176]
[same as prior period, unchanged from 0001558370-21-015999:mdna:217]

[0001558370-22-008639:mdna:177]
During the three months ended March 31, 2022, cash used in investing activities was $1.0 million, consisting of $0.3 million for the purchases of property and equipment and $0.6 million for the development of internal-use software.

[0001558370-22-008639:mdna:178]
During the three months ended March 31, 2021, cash used in investing activities was $2.5 million, consisting of the purchases of property and equipment.

[0001558370-22-008639:mdna:179]
[same as prior period, unchanged from 0001558370-21-015999:mdna:219]

[0001558370-22-008639:mdna:180]
During the three months ended March 31, 2022, cash provided by financing activities was $0.2 million,  consisting of $0.2 million from the exercise of stock options.

[0001558370-22-008639:mdna:181]
During the three months ended March 31, 2021, cash provided by financing activities was $32.0 million, consisting of $31.9 million from the issuance of long-term debt, net of issuance costs, and $0.5 million from the exercise of stock options, partially offset by $0.4 million in net cash out flows for the repayment of our finance obligations.

[0001558370-22-008639:mdna:182]
[same as prior period, unchanged from 0001558370-21-015999:mdna:222]

[0001558370-22-008639:mdna:183]
A description of recently issued accounting pronouncements that may potentially impact our financial position, results of operations or cash flows is disclosed in Note 2 to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001558370-22-008639:mdna:184]
Critical Accounting Policies and Estimates

[0001558370-22-008639:mdna:185]
Our critical accounting policies and estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” for the year ended December 31, 2021 in our Annual Report on Form 10-K. There have been no material changes to our critical accounting policies and estimates during the three months ended March 31, 2022 outside of our critical accounting policies and estimates described below.

[0001558370-22-008639:mdna:186]
[same as prior period, unchanged from 0001558370-21-015999:mdna:264]

[0001558370-22-008639:mdna:187]
We lease our corporate headquarters under a non-cancelable operating lease that expires in October 2024. We determine if our arrangement contains a lease at inception. We do not separate lease and non-lease components of our arrangement determined to contain a lease.

[0001558370-22-008639:mdna:188]
We use our estimated incremental borrowing rate, which is derived from information available at the lease commencement date, in determining the present value of operating lease payments. To determine the estimated incremental borrowing rate, we use publicly available credit ratings for peer companies and estimate the incremental borrowing rate using yields for maturities that are in line with the duration of the lease payments.

[0001558370-22-008639:mdna:189]
To determine the residual value estimates and useful life of equipment that we lease to our customers, we are required to make judgments about future events that are subject to risks and uncertainties outside of their control, such as inventory levels of new equipment, changing consumer preferences, new technology and mandatory regulations. We have disciplines related to the management and maintenance of our leased equipment designed to manage the risk associated with the residual values of our revenue generating equipment. We periodically review and adjust, as appropriate, the estimated residual values and useful lives of existing revenue generating equipment for the purposes of recording depreciation expense. Based on the results of our analysis, we may adjust the estimated residual values and useful lives of individual assets of our revenue generating equipment each year.

[0001558370-22-008639:mdna:190]
[same as prior period, unchanged from 0001558370-21-015999:mdna:269]

[0001558370-22-008639:mdna:191]
The Jumpstart Our Business Startups Act of 2012, or the JOBS Act, permits an “emerging growth company” such as us to take advantage of an extended transition period to comply with new or revised accounting standards applicable to public companies until those standards would otherwise apply to private companies. We meet the definition of an “emerging growth company” and have elected to use this extended transition period for complying with new or revised accounting standards that have different effective dates for public and private companies until the earlier of the date we (1) are no longer an emerging growth company or (2) affirmatively and irrevocably opt out of the extended transition period provided in the JOBS Act. As a result of this election, we will not be subject to the same new or revised accounting standards as other public companies that are not emerging growth companies and our condensed consolidated financial statements may not be comparable to other public companies that comply with new or revised accounting pronouncements as of public company effective dates. We may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for private companies.

[0001558370-22-008639:mdna:192]
We will remain an emerging growth company until the earlier of (1) the last day of the fiscal year (a) following the fifth anniversary of the completion of the initial public offering, (b) in which we have total annual gross revenue of at least $1.07 billion or (c) in which we are deemed to be a large accelerated filer, and (2) the date on which we have issued more than $1.0 billion in non-convertible debt during the prior three-year period.

[0001558370-22-008639:mdna:193]
[same as prior period, unchanged from 0001558370-21-015999:mdna:272]
