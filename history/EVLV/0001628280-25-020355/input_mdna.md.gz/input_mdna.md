# EVLV MD&A — 0001628280-25-020355


## mdna

[0001628280-25-020355:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001628280-25-020355:mdna:2]
As used in this Annual Report on Form 10-K, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to our legal predecessor, a special purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”) and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001628280-25-020355:mdna:3]
Restatement of Prior Period Financial Statements

[0001628280-25-020355:mdna:4]
We have restated our previously issued consolidated financial statements contained in this Annual Report on Form 10-K. Refer to the “Explanatory Note” preceding Item 1, Business, for background on the restatement, the periods impacted, control considerations, and other information. In addition, we have restated certain previously reported financial information for the fiscal years ended December 31, 2023 and December 31, 2022 and for the quarterly periods and year-to-date periods ended June 30, 2022, September 30, 2022, March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024, and June 30, 2024 in this Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, including but not limited to information within the Results of Operations section. See Notes 2 and 23 in the notes to the consolidated financial statements in this Annual Report on Form 10-K, for additional information related to the restatement, including descriptions of the misstatements and the impacts on our consolidated financial statements.

[0001628280-25-020355:mdna:5]
Business Overview

[0001628280-25-020355:mdna:6]
Evolv is a leading security technology company pioneering Artificial Intelligence (“AI”)-powered screening designed to help create safer experiences, with key market categories that include education, healthcare, sports, and live entertainment. Our mission is to make the world a safer and more enjoyable place to live, work, learn, and play. Our goal is to help facility operators address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks while maintaining a positive visitor experience.

[0001628280-25-020355:mdna:7]
Our solutions combine proprietary software and hardware, delivered as a long-term Security-as-a-Service ("SaaS") subscription model and are designed to enhance security and improve the visitor experience. Evolv provides a cloud-connected, AI-driven approach to security that goes beyond just hardware, supporting the end-to-end screening experience. Our focus is weapons detection, and we offer two core solutions: Evolv Express® and Evolv eXpedite® – designed to efficiently screen high volumes of people and bags for concealed threats.

[0001628280-25-020355:mdna:8]
Our flagship product, Evolv Express®, uses advanced sensors, AI-powered software, and cloud services to not only consistently detect firearms, improvised explosives, and certain types of knives and distinguish them from many harmless items such as cell phones and keys, but also visualize the location of the potential threat helping to enable security personnel to conduct targeted, minimally intrusive secondary screenings. Evolv eXpedite, our autonomous X-ray bag scanning solution, works with Evolv Express to provide a layered approach to security for concealed weapons detection in high clutter environments. Using eXpedite with Express aims to allow the checkpoint to operate at heightened sensitivity while potentially reducing the burden on security staff and optimizing the visitor experience.

[0001628280-25-020355:mdna:9]
Our innovative technology is designed to enhance security and provide an efficient, positive visitor and customer experience. In addition to screening capabilities, our solution includes Evolv Insights, a powerful software analytics dashboard that allows customers to comprehensively review, analyze, and gather insights from the Evolv Express screening systems at their various venue or facility locations.  Available data includes visitor arrival patterns, throughput volumes, system detection performance, alarm statistics, and detection settings.  Our customers can leverage this data to inform their security operations, while providing end-users with an approachable security experience. Our products, which are offered to our customers primarily under a multi-year subscription model, provide predictable revenue streams for us in addition to value for our customers.

[0001628280-25-020355:mdna:10]
We are focused on delivering value in the spaces in and around the physical threshold of venues and facilities. We believe that digitally transforming the visitor experience at the entry point to venues and facilities will be a critically important innovation in physical security. We believe that our solutions will not only help make venues and facilities safer and more enjoyable, but also more efficient, and more informed about their visitors’ needs.

[0001628280-25-020355:mdna:11]
Key Factors Affecting Our Operating Results

[0001628280-25-020355:mdna:12]
We believe that our performance and future success depend on many factors that present significant opportunities for us but also pose risks and challenges, including those discussed below and in the "Risk Factors" section of this Annual Report on Form 10-K.

[0001628280-25-020355:mdna:13]
General Economic and Market Conditions

[0001628280-25-020355:mdna:14]
We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of inflation and interest rates on business spending; supply chain issues and the impacts on our manufacturing capabilities; public health emergencies; geopolitical conflicts and war, including the conflicts in Europe and the Middle East; and recessionary trends. See the risk factor titled “Our operating results may fluctuate for a variety of reasons, including our failure to close large volume opportunity customer sales” in Item 1A. Risk Factors of this Annual Report on Form 10-K. While these factors continue to evolve, we plan to remain flexible and optimize our business as appropriate and allocate resources, as necessary.

[0001628280-25-020355:mdna:15]
Adoption of our Security Screening Products

[0001628280-25-020355:mdna:16]
We believe the world will continue to focus on the safety and security of people in the places where they gather. Many of these locations, such as professional sports venues, educational institutions, and healthcare facilities, are moving toward a more frictionless security screening experience. We are well-positioned to take advantage of this opportunity due to our proprietary technologies and distribution capabilities. Our products are designed to empower venues and facilities to realize the full benefits of touchless security screening, including a rapid visitor throughput and minimal security staff to screened visitor physical contact. We expect that our results of operations, including revenue, will fluctuate for the foreseeable future as venues and facilities continue to shift away from conventional security screening processes towards touchless security screening or consider security screening processes for the first time. The degree to which potential and current customers recognize these benefits and invest in our products will affect our financial results.

[0001628280-25-020355:mdna:17]
Sales Mix, Pricing, Product Cost and Margins

[0001628280-25-020355:mdna:18]
We sell our solutions under two primary sales models. We offer a “pure subscription” model, where the customer leases hardware from us and we provide a multi-year security-as-a-service subscription. For end-user customers that prefer to purchase our hardware outright, we offer our “distributor licensing” model based on the Distribution and License Agreement we entered into with Columbia Tech in March of 2023. Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, currently serves as our primary contract manufacturer. Under this arrangement, we have granted a license of our intellectual property to Columbia Tech, which contracts directly with certain of our resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment. Columbia Tech pays us a hardware license fee for each system it manufactures and sells under this agreement. In these instances, we still contract directly with the reseller to provide a multi-year security-as-a-service subscription to the end-users. We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our revenue, gross profit, gross margin, and overall profitability in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments.

[0001628280-25-020355:mdna:19]
Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions, primarily within the United States. Pricing may vary by region or vertical market due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales, bookings, and business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products to our customers.

[0001628280-25-020355:mdna:20]
Development and Commercialization of our Products

[0001628280-25-020355:mdna:21]
46

[0001628280-25-020355:mdna:22]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $103.9 million and $79.6 million for the years ended December 31, 2024 and 2023, respectively. We generated a net loss of $54.0 million and $108.0 million for the years ended December 31, 2024 and 2023, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-25-020355:mdna:23]
Liquidity and Capital Resources

[0001628280-25-020355:mdna:24]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations, and if necessary, debt financings. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources” for more information. Additionally, as discussed in Note 20 (Commitments and Contingencies) to our consolidated financial statements for the year ended December 31, 2024, we are involved in certain legal proceedings, including government investigations. Given the uncertainty of such matters, no assurance can be given regarding the final outcome of such matters. However, the ultimate amount or range of potential loss, which might result to the Company may differ materially from our current estimates.

[0001628280-25-020355:mdna:25]
Components of Results of Operations

[0001628280-25-020355:mdna:26]
Revenue

[0001628280-25-020355:mdna:27]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement, (4) license fees related to the Distribution and License Agreement, and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax.

[0001628280-25-020355:mdna:28]
Product Revenue

[0001628280-25-020355:mdna:29]
We derive a portion of our revenue from the sale of our Evolv Express equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We anticipate future growth in product revenue to be driven by underlying demand for our solutions as well as by the distribution mix across our various sales and fulfillment models.

[0001628280-25-020355:mdna:30]
Subscription Revenue

[0001628280-25-020355:mdna:31]
Subscription revenue consists of revenue derived from leasing Evolv Express units to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001628280-25-020355:mdna:32]
Lease arrangements generally include both lease and non-lease components. The non-lease components relate to (1) distinct services, including professional services, SaaS, and maintenance, and (2) any add-on accessories. Professional services are included in license fees and other revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive (loss) income.

[0001628280-25-020355:mdna:33]
Service Revenue

[0001628280-25-020355:mdna:34]
Service revenue consists of subscription-based SaaS and maintenance revenue related to Evolv Express units sold to customers. Customers generally pay either a quarterly or annual fixed payment for SaaS and maintenance. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically four years.

[0001628280-25-020355:mdna:35]
License Fee and Other Revenue

[0001628280-25-020355:mdna:36]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and revenue from other one-time services. License fee revenue is recognized upon the shipment of product from Columbia Tech to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration. Revenue for professional services and other one-time service revenue, which had previously been included in service revenue, has been reclassified for prior periods to License fee and other revenue on the consolidated statements of operations and comprehensive (loss) income. We anticipate changes in license fee and other revenue to be driven by underlying demand for our solutions as well as any changes in demand for our distributor licensing model.

[0001628280-25-020355:mdna:37]
Cost of Revenue

[0001628280-25-020355:mdna:38]
We recognize cost of revenue in the same manner that the related revenue is recognized.

[0001628280-25-020355:mdna:39]
Cost of Product Revenue

[0001628280-25-020355:mdna:40]
Cost of product revenue consists primarily of costs paid to our third-party manufacturer and other suppliers, labor costs (including stock-based compensation), and shipping costs.

[0001628280-25-020355:mdna:41]
Cost of Subscription Revenue

[0001628280-25-020355:mdna:42]
Cost of subscription revenue consists primarily of depreciation expense related to leased units, an allocated portion of internal-use software amortization expense, shipping costs, and maintenance costs related to leased units. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001628280-25-020355:mdna:43]
Cost of Service Revenue

[0001628280-25-020355:mdna:44]
Cost of services revenue consists of maintenance costs related to units purchased by customers and an allocated portion of internal-use software amortization expense. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001628280-25-020355:mdna:45]
Cost of License Fee and Other Revenue

[0001628280-25-020355:mdna:46]
Cost of license fees and other revenue consists primarily of internal and third-party costs related to professional services, such as installation, training, and event support.

[0001628280-25-020355:mdna:47]
Gross Profit and Gross Margin

[0001628280-25-020355:mdna:48]
Our gross profit is calculated based on the difference between our revenues and cost of revenues. Gross margin is the percentage obtained by dividing gross profit by our revenue.

[0001628280-25-020355:mdna:49]
We expect our gross margins to fluctuate over time based on the following factors:

[0001628280-25-020355:mdna:50]
•Mix of sales between our pure subscription, purchase subscription, and distributor licensing sales models;

[0001628280-25-020355:mdna:51]
•Market conditions that may impact our pricing;

[0001628280-25-020355:mdna:52]
•Product mix changes between established products and new products;

[0001628280-25-020355:mdna:53]
•Our cost structure for manufacturing operations, including contract manufacturers, relative to volume, and our product support obligations;

[0001628280-25-020355:mdna:54]
•Our ability to maintain our costs on the components that go into the manufacture of our products; and

[0001628280-25-020355:mdna:55]
•Write-offs of inventory.

[0001628280-25-020355:mdna:56]
We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our gross profit and gross margin in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments.

[0001628280-25-020355:mdna:57]
Research and Development

[0001628280-25-020355:mdna:58]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, stock-based compensation, prototypes, design expenses, and consulting and contractor costs. We expect our research and development costs will remain relatively consistent for the year ending December 31, 2025 compared to the year ended December 31, 2024 as we look to leverage previous investments made in people and processes.

[0001628280-25-020355:mdna:59]
Sales and Marketing

[0001628280-25-020355:mdna:60]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will decrease for the year ending December 31, 2025 compared to the year ended December 31, 2024 as a result of certain cost cutting measures we have taken, including the reduction in force implemented in January 2025.

[0001628280-25-020355:mdna:61]
General and Administrative

[0001628280-25-020355:mdna:62]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and insurance. During the year ended 2024, we experienced a significant increase in general and administrative expenses, primarily for legal fee and consulting expenses, as a result of the Investigation and related actions, as described in the “Explanatory Note” preceding Item 1, Business. We expect this increased level of expenses to continue through the second quarter of 2025. As such actions become completed, we expect our general and administrative expenses to decrease in the second half of 2025 and to remain consistent at more normalized levels thereafter.

[0001628280-25-020355:mdna:63]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:64]
Loss from impairment of property and equipment relates to (i) leased Evolv Edge units and Evolv Express prototype units that are removed from service and retired as we transition our domestic customers to our most current Evolv Express units and (ii) damaged or destroyed leased units.

[0001628280-25-020355:mdna:65]
Interest Expense

[0001628280-25-020355:mdna:66]
Interest expense includes cash interest paid on long-term debt and amortization of deferred financing fees and costs.

[0001628280-25-020355:mdna:67]
Interest Income

[0001628280-25-020355:mdna:68]
Interest income relates to interest earned on money market funds and treasury bills, and interest earned on our lease receivables for our Evolv Express units recognized as sales-type leases.

[0001628280-25-020355:mdna:69]
Loss on Extinguishment of Debt

[0001628280-25-020355:mdna:70]
In December 2022, the Company entered into a loan and security agreement (the "2022 SVB Credit Agreement") with Silicon Valley Bank ("SVB") in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. Subsequently, the Company terminated the 2022 SVB Credit Agreement on March 31, 2023. As a result of the termination of the SVB Credit Agreement, the Company incurred a loss on extinguishment of debt.

[0001628280-25-020355:mdna:71]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:72]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders are entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive (loss) income.

[0001628280-25-020355:mdna:73]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:74]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock, referred to as Founder Shares. Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 1,897,500 Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones, and 517,500 Founder Shares were contributed to Give Evolv LLC. The 1,897,500 outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive (loss) income.

[0001628280-25-020355:mdna:75]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:76]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are currently exercisable and expire in July 2026. We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger as a component of other income (expense), net in the consolidated statements of operations and comprehensive (loss) income with the offset to additional paid-in capital.

[0001628280-25-020355:mdna:77]
Income Taxes

[0001628280-25-020355:mdna:78]
Our income tax provision consists of an estimate for federal, state, and foreign income taxes based on enacted rates in the jurisdictions in which we operate, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. We have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets.

[0001628280-25-020355:mdna:79]
Results of Operations

[0001628280-25-020355:mdna:80]
Comparison of the Years Ended December 31, 2024 and 2023

[0001628280-25-020355:mdna:81]
The following table summarizes our results of operations for the years ended December 31, 2024 and 2023 (in thousands):

[0001628280-25-020355:mdna:82]
50

[0001628280-25-020355:mdna:83]
|  | Year Ended December 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 6,464 |  |  | $ | 22,768 |  |  | $ | (16,304) |  |  | (72) | % |
| Subscription revenue | 65,046 |  |  | 36,201 |  |  | 28,845 |  |  | 80 |  |
| Service revenue | 23,467 |  |  | 15,606 |  |  | 7,861 |  |  | 50 |  |
| License fee and other revenue | 8,888 |  |  | 4,990 |  |  | 3,898 |  |  | 78 |  |
| Total revenue | 103,865 |  |  | 79,565 |  |  | 24,300 |  |  | 31 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 10,735 |  |  | 27,967 |  |  | (17,232) |  |  | (62) |  |
| Cost of subscription revenue | 27,846 |  |  | 14,760 |  |  | 13,086 |  |  | 89 |  |
| Cost of service revenue | 5,399 |  |  | 3,982 |  |  | 1,417 |  |  | 36 |  |
| Cost of license fee and other revenue | 597 |  |  | 949 |  |  | (352) |  |  | (37) |  |
| Total cost of revenue | 44,577 |  |  | 47,658 |  |  | (3,081) |  |  | (6) |  |
| Gross profit | 59,288 |  |  | 31,907 |  |  | 27,381 |  |  | 86 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 23,446 |  |  | 24,473 |  |  | (1,027) |  |  | (4) |  |
| Sales and marketing | 61,291 |  |  | 54,986 |  |  | 6,305 |  |  | 11 |  |
| General and administrative | 56,634 |  |  | 42,182 |  |  | 14,452 |  |  | 34 |  |
| Loss from impairment of property and equipment | 224 |  |  | 322 |  |  | (98) |  |  | (30) |  |
| Total operating expenses | 141,595 |  |  | 121,963 |  |  | 19,632 |  |  | 16 |  |
| Loss from operations | (82,307) |  |  | (90,056) |  |  | 7,749 |  |  | 9 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (654) |  |  | 654 |  |  | * |
| Interest income | 2,942 |  |  | 6,227 |  |  | (3,285) |  |  | (53) |  |
| Other expense, net | (83) |  |  | (84) |  |  | 1 |  |  | 1 |  |
| Loss on extinguishment of debt | — |  |  | (626) |  |  | 626 |  |  | * |
| Change in fair value of contingent earn-out liability | 16,310 |  |  | (14,901) |  |  | 31,211 |  |  | 209 |  |
| Change in fair value of contingently issuable common stock liability | 2,529 |  |  | (3,138) |  |  | 5,667 |  |  | 181 |  |
| Change in fair value of public warrant liability | 6,592 |  |  | (4,765) |  |  | 11,357 |  |  | 238 |  |
| Total other income (expense), net | 28,290 |  |  | (17,941) |  |  | 46,231 |  |  | 258 |  |
| Loss before income taxes | (54,017) |  |  | (107,997) |  |  | 53,980 |  |  | 50 | % |
| Provision for income taxes | — |  |  | (51) |  |  | 51 |  |  | * |
| Net loss | $ | (54,017) |  |  | $ | (108,048) |  |  | $ | 54,031 |  |  | 50 | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (66) % |  | (23) % |  | N/A |  | (43) % |
| Subscription revenue | 57 % |  | 59 % |  | N/A |  | (2) % |
| Service revenue | 77 % |  | 74 % |  | N/A |  | 3 % |
| License fee and other revenue | 93 % |  | 81 % |  | N/A |  | 12 % |

[0001628280-25-020355:mdna:84]
*N/A – Not meaningful

[0001628280-25-020355:mdna:85]
51

[0001628280-25-020355:mdna:86]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:87]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 249 new customers during the year ended December 31, 2024, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:88]
Product Revenue

[0001628280-25-020355:mdna:89]
The decreases in product revenue and cost of product revenue are primarily due to a transition to pure subscription sales and sales under our distributor licensing model during the preceding twelve months. The decrease in product gross profit margin for the year ended December 31, 2024 compared to the year ended December 31, 2023 was also impacted by $2.4 million of expense related to our inventory reserve during the year ended December 31, 2024, which related primarily to the transition of our manufacturing operations to the next generation of Evolv Express systems and the determination that certain components within our legacy systems will not be used in the next generation systems.

[0001628280-25-020355:mdna:90]
Subscription Revenue

[0001628280-25-020355:mdna:91]
The increases in subscription revenue, cost of subscription revenue, and gross profit are primarily due to continued growth in our customer base as of December 31, 2024 compared to the prior year, which was due to a transition to our pure subscription model and a higher number of active Evolv Express units deployed under our pure subscription contract model.

[0001628280-25-020355:mdna:92]
Service Revenue

[0001628280-25-020355:mdna:93]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to an increased number of active revenue-generating units purchased by customers directly from Columbia Tech under our distributor licensing model, for the year ended December 31, 2024 compared to the year ended December 31, 2023.

[0001628280-25-020355:mdna:94]
License fee and other revenue

[0001628280-25-020355:mdna:95]
The increase in license fee and other revenue, gross profit, and gross profit margin was primarily driven by $7.2 million of license fees earned during the year ended December 31, 2024 compared to $3.0 million earned during the year ended December 31, 2023 under the Distribution and License Agreement.

[0001628280-25-020355:mdna:96]
Research and Development Expenses

[0001628280-25-020355:mdna:97]
The decrease in research and development expense was due to a decrease in personnel related expenses of $0.4 million due to a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $1.5 million, partially offset by an increase in payroll costs of $1.0 million primarily resulting from new hires in our research and development function during the past twelve months. Materials and prototypes expense decreased by $0.4 million due to lower prototype expenses of $1.0 million, partially offset by an inventory reserve on unused components of $0.4 million, which relate primarily to the development of the next generation of our Evolv Express system. Professional fees decreased by $0.7 million primarily related to a higher amount of costs capitalized related to internal-use software and software embedded in products to be sold or leased of $0.6 million, partially offset by increases in IT and software subscription costs of $0.4 million.

[0001628280-25-020355:mdna:98]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:99]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $4.8 million, which included an increase in payroll costs of $3.1 million and stock-based compensation of $1.6 million resulting primarily from new hires in our sales and marketing functions during the year to support increased sales volume, and certain other one-time termination benefits. Stock compensation expense included in sales and marketing expenses was $10.9 million for the year ended December 31, 2024 compared to $9.4 million for the year ended December 31, 2023. Advertising and direct marketing expense remained consistent. Travel and entertainment expenses decreased by $0.2 million due to a decrease in travel costs for in-person sales personnel meetings. Professional fees increased by $1.3 million due primarily to an increase in marketing consulting costs. Other expense increased by $0.5 million primarily due to an increase in IT and software subscription costs of $0.4 million.

[0001628280-25-020355:mdna:100]
General and Administrative Expenses

[0001628280-25-020355:mdna:101]
The increase in general and administrative expense was due to an increase in personnel related expenses of $0.7 million, which included an increase in severance expenses of $2.0 million partially offset by a decrease in stock-based compensation of $1.4 million mainly driven by the impact of forfeited stock-based awards during the year ended December 31, 2024. Stock compensation expense included in general and administrative expense was $8.5 million for the year ended December 31, 2024 compared to $9.9 million for the year ended December 31, 2023. Professional fees increased by $1.4 million primarily due to an increase in outsourced accounting consultancy and audit fees of $1.1 million. Other expense increased by $12.6 million primarily due to a $10.7 million increase in certain one-time expenses incurred during the year ended December 31, 2024 compared to the year ended December 31, 2023, primarily due to consulting and legal fees related to the Investigation and related matters, as well as increases in rent of $0.9 million for additional leased space, IT and software subscription costs of $1.4 million, and property taxes of $0.4 million, partially offset by decreases in director and officer insurance premiums of $0.3 million.

[0001628280-25-020355:mdna:102]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:103]
$0.2 million loss from impairment of property and equipment was recognized for the year ended December 31, 2024, compared to $0.3 million for the year ended December 31, 2023, primarily related to the removal of certain Evolv Express units from service, resulting in impairment of the remaining economic value of such units.

[0001628280-25-020355:mdna:104]
Interest Expense

[0001628280-25-020355:mdna:105]
No interest expense was recognized for the year ended December 31, 2024, compared to $0.7 million for the year ended December 31, 2023. During March 2023, the Company fully repaid all borrowings and accrued interest under its term loans with SVB pursuant to the 2022 SVB Credit Agreement.

[0001628280-25-020355:mdna:106]
Interest Income

[0001628280-25-020355:mdna:107]
Interest income of $2.9 million and $6.2 million for the years ended December 31, 2024 and 2023, respectively, related primarily to interest earned on money market funds and for the year ended December 31, 2024, the amortization of premium, and for the year ended December 31, 2023, the accretion of discounts on treasury bills.

[0001628280-25-020355:mdna:108]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:109]
Change in the fair value of the contingent earn-out liability resulted in a $16.3 million gain and a $14.9 million loss for the years ended December 31, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:110]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:111]
Change in the fair value of the contingently issuable common stock liability resulted in a $2.5 million gain and a $3.1 million loss for the years ended December 31, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:112]
53

[0001628280-25-020355:mdna:113]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:114]
Change in the fair value of the public warrant liability resulted in a $6.6 million gain and a $4.8 million loss for the years ended December 31, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:115]
Income Taxes

[0001628280-25-020355:mdna:116]
Our effective tax rate (“ETR”) on income before taxes for each of the years ended December 31, 2024 and  December 31, 2023 was 0%. For the years ended December 31, 2024 and 2023, the ETR was primarily impacted by the full valuation allowance maintained on the Company’s net deferred tax assets and non-deductible fair value adjustments. We have provided a valuation allowance for all of our net deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001628280-25-020355:mdna:117]
54

[0001628280-25-020355:mdna:118]
Comparison of the Years Ended December 31, 2023 and 2022

[0001628280-25-020355:mdna:119]
The following table summarizes our results of operations for the years ended December 31, 2023 and 2022 (in thousands):

[0001628280-25-020355:mdna:120]
|  | Year Ended December 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
|  | (Restated) |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 22,768 |  |  | $ | 29,787 |  |  | $ | (7,019) |  |  | (24) | % |
| Subscription revenue | 36,201 |  |  | 17,041 |  |  | 19,160 |  |  | 112 |  |
| Service revenue | 15,606 |  |  | 4,595 |  |  | 11,011 |  |  | 240 |  |
| License fee and other revenue | 4,990 |  |  | 1,296 |  |  | 3,694 |  |  | 285 |  |
| Total revenue | 79,565 |  |  | 52,719 |  |  | 26,846 |  |  | 51 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 27,967 |  |  | 39,437 |  |  | (11,470) |  |  | (29) |  |
| Cost of subscription revenue | 14,760 |  |  | 7,460 |  |  | 7,300 |  |  | 98 |  |
| Cost of service revenue | 3,982 |  |  | 2,200 |  |  | 1,782 |  |  | 81 |  |
| Cost of license fee and other revenue | 949 |  |  | 2,222 |  |  | (1,273) |  |  | (57) |  |
| Total cost of revenue | 47,658 |  |  | 51,319 |  |  | (3,661) |  |  | (7) |  |
| Gross profit | 31,907 |  |  | 1,400 |  |  | 30,507 |  |  | 2,179 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 24,473 |  |  | 18,537 |  |  | 5,936 |  |  | 32 |  |
| Sales and marketing | 54,986 |  |  | 46,683 |  |  | 8,303 |  |  | 18 |  |
| General and administrative | 42,182 |  |  | 37,969 |  |  | 4,213 |  |  | 11 |  |
| Loss from impairment of property and equipment | 322 |  |  | 1,161 |  |  | (839) |  |  | (72) |  |
| Total operating expenses | 121,963 |  |  | 104,350 |  |  | 17,613 |  |  | 17 |  |
| Loss from operations | (90,056) |  |  | (102,950) |  |  | 12,894 |  |  | 13 |  |
| Other (expense) income, net: |  |  |  |  |  |  |  |
| Interest expense | (654) |  |  | (712) |  |  | 58 |  |  | 8 |  |
| Interest income | 6,227 |  |  | 3,165 |  |  | 3,062 |  |  | 97 |  |
| Other expense, net | (84) |  |  | (64) |  |  | (20) |  |  | (31) |  |
| Loss on extinguishment of debt | (626) |  |  | — |  |  | (626) |  |  | * |
| Change in fair value of contingent earn-out liability | (14,901) |  |  | 6,988 |  |  | (21,889) |  |  | (313) |  |
| Change in fair value of contingently issuable common stock liability | (3,138) |  |  | 1,872 |  |  | (5,010) |  |  | (268) |  |
| Change in fair value of public warrant liability | (4,765) |  |  | 4,906 |  |  | (9,671) |  |  | (197) |  |
| Total other (expense) income, net | (17,941) |  |  | 16,155 |  |  | (34,096) |  |  | (211) |  |
| Loss before income taxes | (107,997) |  |  | (86,795) |  |  | (21,202) |  |  | (24) | % |
| Provision for income taxes | (51) |  |  | — |  |  | (51) |  |  | * |
| Net loss | $ | (108,048) |  |  | $ | (86,795) |  |  | $ | (21,253) |  |  | (24) | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (23) % |  | (32) % |  | N/A |  | 10 % |
| Subscription revenue | 59 % |  | 56 % |  | N/A |  | 3 % |
| Service revenue | 74 % |  | 52 % |  | N/A |  | 22 % |
| License fee and other revenue | 81 % |  | (71) % |  | N/A |  | 152 % |

[0001628280-25-020355:mdna:121]
*N/A – Not meaningful

[0001628280-25-020355:mdna:122]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:123]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for

[0001628280-25-020355:mdna:124]
customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 280 new customers during the year ended December 31, 2023, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:125]
Product Revenue

[0001628280-25-020355:mdna:126]
The decreases in product revenue and cost of product revenue and the increase in gross profit for the year ended December 31, 2023 compared to the year ended December 31, 2022 are primarily due to a gradual transition to pure subscription sales and sales under our distributor licensing model. Cost of product revenue for the year ended December 31, 2023 includes $1.9 million of costs, primarily cancellation fees associated with firm inventory purchase commitments, related to the planned transition of our manufacturing operations to the next generation of the Evolv Express system in 2024.

[0001628280-25-020355:mdna:127]
Subscription Revenue

[0001628280-25-020355:mdna:128]
The increases in subscription revenue, cost of subscription revenue and subscription gross profit are primarily due to growth in our customer base for the year ended December 31, 2023, compared to the year ended December 31, 2022, which was due to a gradual transition to our pure subscription contract model and a higher number of active Evolv Express units deployed under our pure subscription model. Subscription gross profit margin increased slightly as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:129]
Service Revenue

[0001628280-25-020355:mdna:130]
The increase in service revenue and gross profit is primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech, for the year ended December 31, 2023 compared to the year ended December 31, 2022. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:131]
License fee and other revenue

[0001628280-25-020355:mdna:132]
The increase in license fee and other revenue, gross profit, and gross profit margin was primarily driven by $3.0 million of license fees earned during the year ended December 31, 2023 under the Distribution and License Agreement which was executed in March 2023, compared to no license fees earned during the year ended December 31, 2022. Professional services expense, consisting primarily of installation, training, and event support, increased to $1.9 million for the year ended December 31, 2023 compared to $1.0 million for the year ended December 31, 2022, primarily as the result of a higher number of new Express systems deployed during the year ended December 31, 2023 compared to the prior year.

[0001628280-25-020355:mdna:133]
Research and Development Expenses

[0001628280-25-020355:mdna:134]
The increase in research and development expense was due to an increase in personnel related expenses of $2.4 million due to an increase in payroll of $3.3 million and stock-based compensation expense of $0.5 million, which was primarily attributable to increased headcount in connection with new hires in our research and development function. This was partially offset by an increase in capitalized personnel costs of  $1.3 million. Stock compensation expense was $4.3 million for the year ended December 31, 2023, compared to $3.8 million for the year ended December 31, 2022. Materials and prototype costs increased $1.8 million due to an increase in design and engineering costs in connection with the development of the next generation of our Evolv Express system. Professional fees increased by $1.2 million primarily due to consulting costs incurred for product development and engineering. Other expenses increased by $0.6 million primarily due to an increase in IT and software subscription costs.

[0001628280-25-020355:mdna:135]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:136]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $8.7 million, which included an increase in payroll costs and commissions of $6.0 million resulting primarily from new hires in our sales and marketing functions during the year ended December 31, 2023 to support increased sales volume, as well as an increase of $2.6 million in allocated overhead costs. Stock compensation expense was $9.4 million for the year ended December 31, 2023, compared to $10.0 million for the year ended December 31, 2022. Advertising and direct marketing expense decreased by $1.9 million due to lower spending at trade shows. Travel and entertainment expense increased by $1.7 million due to an increase in travel costs for in-person sales personnel meetings and events. Professional fees increased by $0.8 million primarily due to an increase in marketing consulting costs. Other expense decreased by $1.0 million primarily due to $1.0 million of certain-one-time expenses incurred during the year ended December 31, 2022 related to one-time payments to former employees.

[0001628280-25-020355:mdna:137]
General and Administrative Expenses

[0001628280-25-020355:mdna:138]
The increase in general and administrative expense was due to an increase in personnel related expenses of $5.1 million was primarily due to an increase in payroll costs and stock-based compensation of $3.5 million and $2.0 million respectively as a result of expanding our team during the year ended December 31, 2023. Stock compensation expense was $9.9 million for the year ended December 31, 2023, compared to $7.9 million for the year ended December 31, 2022. Professional fees decreased by $2.0 million due to a decrease in outsourced accounting consultancy and audit fees of $2.1 million. Insurance costs decreased $1.1 million due to a decrease in director and officer insurance premiums. Other expenses increased by $2.1 million due to a $1.0 million increase in IT and software subscription costs, a $0.4 million increase in property taxes, and a $0.3 million increase in the allowance for expected credit losses.

[0001628280-25-020355:mdna:139]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:140]
$0.3 million loss from impairment of property and equipment was recognized for the year ended December 31, 2023, compared to $1.2 million for the year ended December 31, 2022, primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in impairment of the remaining economic value of such units.

[0001628280-25-020355:mdna:141]
Interest Expense and Loss on Extinguishment of Debt

[0001628280-25-020355:mdna:142]
Interest expense remained flat on a year-over-year basis at $0.7 million for the years ended December 31, 2023 and 2022. In March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write off of $0.3 million of unamortized debt issuance costs.

[0001628280-25-020355:mdna:143]
Interest Income

[0001628280-25-020355:mdna:144]
Interest income of $6.2 million and $3.2 million for the years ended December 31, 2023 and December 31, 2022, respectively, related primarily to interest earned on money market funds, and for the year ended December 31, 2023, accretion of discounts on treasury bills.

[0001628280-25-020355:mdna:145]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:146]
Change in fair value of the contingent earn-out liability resulted in a $14.9 million loss and a $7.0 million gain for the years ended December 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:147]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:148]
Change in the fair value of the contingently issuable common stock liability resulted in a $3.1 million loss and a $1.9 million gain for the years ended December 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:149]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:150]
Change in the fair value of the public warrant liability resulted in a $4.8 million loss and a $4.9 million gain for the years ended December 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:151]
Income Taxes

[0001628280-25-020355:mdna:152]
Our ETR on income before taxes for each of the years ended December 31, 2023 and  December 31, 2022 was 0%. For December 31, 2023, the ETR was primarily impacted by the full valuation allowance maintained on the Company’s net deferred tax assets and non-deductible fair value adjustments.  For the year ended December 31, 2022, the ETR was primarily impacted by the full valuation allowance maintained on the Company’s net deferred tax assets and non-taxable fair value adjustments. We have provided a valuation allowance for all of our net deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001628280-25-020355:mdna:153]
58

[0001628280-25-020355:mdna:154]
Comparison of the Years Ended December 31, 2022 and 2021

[0001628280-25-020355:mdna:155]
The following table summarizes our results of operations for the years ended December 31, 2022 and 2021 (in thousands):

[0001628280-25-020355:mdna:156]
|  | Year Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
|  | (Restated) |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 29,787 |  |  | $ | 13,631 |  |  | $ | 16,156 |  |  | 119 | % |
| Subscription revenue | 17,041 |  |  | 7,803 |  |  | 9,238 |  |  | 118 |  |
| Service revenue | 4,595 |  |  | 792 |  |  | 3,803 |  |  | 480 |  |
| License fee and other revenue | 1,296 |  |  | 1,167 |  |  | 129 |  |  | 11 |  |
| Total revenue | 52,719 |  |  | 23,393 |  |  | 29,326 |  |  | 125 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 39,437 |  |  | 12,279 |  |  | 27,158 |  |  | 221 |  |
| Cost of subscription revenue | 7,460 |  |  | 4,501 |  |  | 2,959 |  |  | 66 |  |
| Cost of service revenue | 2,200 |  |  | 937 |  |  | 1,263 |  |  | 135 |  |
| Cost of license fee and other revenue | 2,222 |  |  | 1,647 |  |  | 575 |  |  | 35 |
| Total cost of revenue | 51,319 |  |  | 19,364 |  |  | 31,955 |  |  | 165 |  |
| Gross profit | 1,400 |  |  | 4,029 |  |  | (2,629) |  |  | (65) |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 18,537 |  |  | 11,458 |  |  | 7,079 |  |  | 62 |  |
| Sales and marketing | 46,683 |  |  | 26,099 |  |  | 20,584 |  |  | 79 |  |
| General and administrative | 37,969 |  |  | 19,869 |  |  | 18,100 |  |  | 91 |  |
| Loss from impairment of property and equipment | 1,161 |  |  | 1,869 |  |  | (708) |  |  | (38) |  |
| Total operating expenses | 104,350 |  |  | 59,295 |  |  | 45,055 |  |  | 76 |  |
| Loss from operations | (102,950) |  |  | (55,266) |  |  | (47,684) |  |  | (86) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (712) |  |  | (6,068) |  |  | 5,356 |  |  | 88 |  |
| Interest income | 3,165 |  |  | — |  |  | 3,165 |  |  | * |
| Other expense, net | (64) |  |  | (617) |  |  | 553 |  |  | 90 |  |
| Loss on extinguishment of debt | — |  |  | (12,685) |  |  | 12,685 |  |  | * |
| Change in fair value of derivative liability | — |  |  | (1,745) |  |  | 1,745 |  |  | * |
| Change in fair value of contingent earn-out liability | 6,988 |  |  | 47,360 |  |  | (40,372) |  |  | (85) |  |
| Change in fair value of contingently issuable common stock liability | 1,872 |  |  | 6,406 |  |  | (4,534) |  |  | (71) |  |
| Change in fair value of public warrant liability | 4,906 |  |  | 12,606 |  |  | (7,700) |  |  | (61) |  |
| Change in fair value of common stock warrant liability | — |  |  | (879) |  |  | 879 |  |  | * |
| Total other income (expense), net | 16,155 |  |  | 44,378 |  |  | (28,223) |  |  | (64) |  |
| Net loss | $ | (86,795) |  |  | $ | (10,888) |  |  | $ | (75,907) |  |  | (697) | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (32) % |  | 10 % |  | N/A |  | (42) % |
| Subscription revenue | 56 % |  | 42 % |  | N/A |  | 14 % |
| Service revenue | 52 % |  | (18) % |  | N/A |  | 70 % |
| License fee and other revenue | (71) % |  | (41) % |  | N/A |  | (30) % |

[0001628280-25-020355:mdna:157]
*N/A – Not meaningful

[0001628280-25-020355:mdna:158]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:159]
We believe there are several key trends driving increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition

[0001628280-25-020355:mdna:160]
59

[0001628280-25-020355:mdna:161]
of 295 new customers during the year ended December 31, 2022, (iii) the expansion of our existing customers' initial Evolv Express deployments to their other owned venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:162]
Product Revenue

[0001628280-25-020355:mdna:163]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which include the significant increase in the adoption of Evolv Express units by schools, healthcare facilities, hotels, casinos, and professional sports arenas. Further, during the year ended December 31, 2022, a higher relative mix of sales contracts were in the form of purchase subscription sales compared to leases.

[0001628280-25-020355:mdna:164]
The decrease in product gross profit and gross profit margin during the year ended December 31, 2022 compared to the year ended December 31, 2021 is attributable to several factors. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, and therefore a lower gross margin, during the year ended December 31, 2022 compared to the prior year. Product gross profit and gross profit margin were also adversely impacted by marketing and sponsorship arrangements with certain customers (which are reflected as an offset to revenue), increases in shipping costs, and the costs associated with the write-off of scrap inventory incurred without corresponding revenue.

[0001628280-25-020355:mdna:165]
Subscription Revenue

[0001628280-25-020355:mdna:166]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base and a higher number of leased Evolv Express units deployed under our pure subscription contract model during the year ended December 31, 2022 compared to the year ended December 31, 2021. Subscription gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:167]
Service Revenue

[0001628280-25-020355:mdna:168]
The increase in service revenue, cost of service revenue, and service gross profit are primarily due to the increased number of purchase subscription units deployed during the year ended December 31, 2022 compared to the year ended December 31, 2021, as well as an increase in the number of installation and training services performed. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:169]
License fee and other revenue

[0001628280-25-020355:mdna:170]
The increase in license fee and other revenue, gross profit, and gross profit margin was driven by an increase of $0.1 million of other revenue, primarily related to shipping amounts billed to customers, earned during the year ended December 31, 2022 compared to the prior year period.

[0001628280-25-020355:mdna:171]
Research and Development Expenses

[0001628280-25-020355:mdna:172]
The increase in research and development expense was due to an increase in personnel related expenses of $7.0 million, which included an increase in payroll costs and stock-based compensation of $7.4 million, resulting primarily from a full year of expense related to new employees hired in our research and development function during the year ended December 31, 2021 and, to a lesser extent, new hires during the year ended December 31, 2022. This was partially offset by a decrease in research and development ("R&D") recruiting fees of $0.4 million. Stock compensation expense included in research and development expense was $3.8 million for the year ended December 31, 2022 compared to $0.9 million for the year ended December 31, 2021. Materials and prototype costs decreased by $1.2 million due to the transition from prototype production to standard manufacturing of the Evolv Express. Professional fees increased by $1.2 million due to consulting costs incurred for product development and engineering.

[0001628280-25-020355:mdna:173]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:174]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $14.3 million which included an increase in payroll costs and stock-based compensation of $14.3 million resulting primarily from a full year of expense related to new employees hired in our sales and marketing functions during the year ended December 31, 2021, and to a lesser extent, new hires during the year ended December 31, 2022, as well as an increase in commission expense of $1.5 million related to higher sales during the year ended December 31, 2022 compared to the prior year. Stock compensation expense included in sales and marketing expenses was $10.0 million for the year ended December 31, 2022 compared to $5.8 million for the year ended December 31, 2021. Direct marketing increased by $1.0 million primarily due to an increase in trade shows and events of $0.8 million, which have begun to return to pre-pandemic levels. Travel and entertainment expense increased by $1.7 million due to an increase in travel costs for in-person sales personnel meetings and events. Professional fees increased by $0.6 million due to consulting costs incurred for training and website development. Other expenses increased by $3.0 million due to $1.4 million of increased shipping costs related to demo units and $1.0 million of certain termination benefits paid to former employees.

[0001628280-25-020355:mdna:175]
General and Administrative Expenses

[0001628280-25-020355:mdna:176]
The increase in general and administrative expense was due to an increase in personnel related expenses of $10.1 million which included an increase in payroll costs and stock-based compensation of $10.0 million resulting from expanding our team during the years ended December 31, 2022 and 2021. Stock compensation expense included in general and administrative expenses was $7.9 million for the year ended December 31, 2022 compared to $2.8 million for the year ended December 31, 2021. Professional fees increased by $3.2 million due to an increase in accounting, audit, tax, and legal services provided to the Company to support public company requirements. Insurance costs increased by $2.1 million due primarily to director and officer insurance expense in relation to being a public company. Non-income taxes decreased $0.8 million due to a reduction in our sales tax contingency liability related to additional sales and use taxes in various jurisdictions we may incur. Other expenses increased by $2.7 million due primarily to $1.5 million increase of certain one-time personnel-related benefits, a $1.0 million increase in IT and software subscription costs, a $0.3 million increase in depreciation and amortization expense, and $0.2 million of expense related to Express units donated through Give Evolv, partially offset by $0.7 million of non-capitalizable transaction costs incurred during the year ended December 31, 2021 related to the Merger.

[0001628280-25-020355:mdna:177]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:178]
Impairment of property and equipment was $1.2 million and $1.9 million for the years ended December 31, 2022 and 2021, respectively. As we transition existing domestic customers to our current Express model, we are removing Edge units and Express prototype units from service, which results in the impairment of the remaining economic value of such units.

[0001628280-25-020355:mdna:179]
Interest Expense

[0001628280-25-020355:mdna:180]
Interest expense was $0.7 million for the year ended December 31, 2022, compared to $6.1 million for the year ended December 31, 2021. The decrease was primarily due to interest expense on the Convertible Notes during the year ended December 31, 2021. The Convertible Notes converted to the Company’s common stock upon closing of the Merger in July 2021.

[0001628280-25-020355:mdna:181]
Interest Income

[0001628280-25-020355:mdna:182]
Interest income of $3.2 million for the year ended December 31, 2022 related primarily to interest earned on money market funds. No interest income was earned for the year ended December 31, 2021.

[0001628280-25-020355:mdna:183]
Loss on Extinguishment of Debt

[0001628280-25-020355:mdna:184]
Loss on extinguishment of debt of $12.7 million for the year ended December 31, 2021 related to a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes.

[0001628280-25-020355:mdna:185]
61

[0001628280-25-020355:mdna:186]
Change in Fair Value of Derivative Liability

[0001628280-25-020355:mdna:187]
Change in the fair value of the derivative liability resulted in a loss of $1.7 million for the year ended December 31, 2021, resulting from an increase in the fair value of the Company's stock given the pending Merger. The derivative liability was derecognized in connection with the closing of the Merger.

[0001628280-25-020355:mdna:188]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:189]
Change in the fair value of the contingent earn-out liability resulted in gains of $7.0 million and $47.4 million for the years ended December 31, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:190]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:191]
Change in the fair value of the contingently issuable common stock liability resulted in gains of $1.9 million and $6.4 million for the years ended December 31, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:192]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:193]
Change in the fair value of the public warrant liability resulted in gains of $4.9 million and $12.6 million for the years ended December 31, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:194]
Change in Fair Value of Common Stock Warrant Liability

[0001628280-25-020355:mdna:195]
Change in the fair value of the common stock warrant liability resulted in a $0.9 million loss for the year ended December 31, 2021, resulting from the conversion of the common stock warrant liability upon the closing of the Merger and mark-to-market adjustments prior to the closing of the Merger.

[0001628280-25-020355:mdna:196]
Income Taxes

[0001628280-25-020355:mdna:197]
There is no provision for income taxes for the years ended December 31, 2022 and 2021 because we have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets. We have provided a valuation allowance for all of our deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001628280-25-020355:mdna:198]
Quarterly Financial Information (Unaudited)

[0001628280-25-020355:mdna:199]
As a result of the restatement described above, we are restating our comparisons of impacted periods as follows:

[0001628280-25-020355:mdna:200]
62

[0001628280-25-020355:mdna:201]
Comparison of the Three Months Ended June 30, 2024 and 2023

[0001628280-25-020355:mdna:202]
The following table summarizes our results of operations for the three months ended June 30, 2024 and 2023 (in thousands):

[0001628280-25-020355:mdna:203]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  | (Restated) |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 1,954 |  |  | $ | 6,852 |  |  | $ | (4,898) |  |  | (71) | % |
| Subscription revenue | 15,655 |  |  | 7,702 |  |  | 7,953 |  |  | 103 |  |
| Service revenue | 5,566 |  |  | 3,646 |  |  | 1,920 |  |  | 53 |  |
| License fee and other revenue | 2,049 |  |  | 702 |  |  | 1,347 |  |  | 192 |  |
| Total revenue | 25,224 |  |  | 18,902 |  |  | 6,322 |  |  | 33 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 2,839 |  |  | 7,417 |  |  | (4,578) |  |  | (62) |  |
| Cost of subscription revenue | 6,309 |  |  | 3,285 |  |  | 3,024 |  |  | 92 |  |
| Cost of service revenue | 1,321 |  |  | 1,014 |  |  | 307 |  |  | 30 |  |
| Cost of license fee and other revenue | 172 |  |  | 270 |  |  | (98) |  |  | (36) |  |
| Total cost of revenue | 10,641 |  |  | 11,986 |  |  | (1,345) |  |  | (11) |  |
| Gross profit | 14,583 |  |  | 6,916 |  |  | 7,667 |  |  | 111 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,850 |  |  | 6,389 |  |  | (539) |  |  | (8) |  |
| Sales and marketing | 17,011 |  |  | 13,596 |  |  | 3,415 |  |  | 25 |  |
| General and administrative | 14,093 |  |  | 10,865 |  |  | 3,228 |  |  | 30 |  |
| Loss from impairment of property and equipment | — |  |  | 157 |  |  | (157) |  |  | * |
| Total operating expenses | 36,954 |  |  | 31,007 |  |  | 5,947 |  |  | 19 |  |
| Loss from operations | (22,371) |  |  | (24,091) |  |  | 1,720 |  |  | 7 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest income | 681 |  |  | 1,853 |  |  | (1,172) |  |  | (63) |  |
| Other income (expense), net | (39) |  |  | (22) |  |  | (17) |  |  | (77) |  |
| Change in fair value of contingent earn-out liability | 16,514 |  |  | (28,113) |  |  | 44,627 |  |  | 159 |  |
| Change in fair value of contingently issuable common stock liability | 3,747 |  |  | (5,095) |  |  | 8,842 |  |  | 174 |  |
| Change in fair value of public warrant liability | 4,886 |  |  | (11,751) |  |  | 16,637 |  |  | 142 |  |
| Total other income (expense), net | 25,789 |  |  | (43,128) |  |  | 68,917 |  |  | 160 |  |
| Net income (loss) | $ | 3,418 |  |  | $ | (67,219) |  |  | $ | 70,637 |  |  | 105 | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (45) % |  | (8) % |  | N/A |  | (37) % |
| Subscription revenue | 60 % |  | 57 % |  | N/A |  | 2 % |
| Service revenue | 76 % |  | 72 % |  | N/A |  | 4 % |
| License fee and other revenue | 92 % |  | 62 % |  | N/A |  | 30 % |

[0001628280-25-020355:mdna:204]
*N/A – Not meaningful

[0001628280-25-020355:mdna:205]
63

[0001628280-25-020355:mdna:206]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:207]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 84 new customers during the three months ended June 30, 2024, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:208]
Product Revenue

[0001628280-25-020355:mdna:209]
The decreases in product revenue and cost of product revenue are primarily due to a transition to pure subscription sales and sales under our distributor licensing model during the preceding twelve months. The decrease in product gross profit margin for the three months ended June 30, 2024 compared to the prior year period is primarily attributable to $0.4 million of expense related to an increase to our inventory reserve and $0.3 million increase in manufacturing expenses.

[0001628280-25-020355:mdna:210]
Subscription Revenue

[0001628280-25-020355:mdna:211]
The increases in subscription revenue, cost of subscription revenue and subscription gross profit are primarily due to continued growth in our customer base for the three months ended June 30, 2024 compared to the prior year period, which was due to a transition to our pure subscription model and a higher number of active Evolv Express units deployed under our pure subscription model.

[0001628280-25-020355:mdna:212]
Service Revenue

[0001628280-25-020355:mdna:213]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech under our distributor licensing model, for the three months ended June 30, 2024 compared to the prior year period.

[0001628280-25-020355:mdna:214]
License fee and other revenue

[0001628280-25-020355:mdna:215]
The increase in license fee and other revenue, gross profit, and gross profit margin was primarily driven by $1.7 million of license fees earned during the three months ended June 30, 2024 compared to no license fees earned during the prior year period under the Distribution and License Agreement which was executed in March 2023.

[0001628280-25-020355:mdna:216]
Research and Development Expenses

[0001628280-25-020355:mdna:217]
The decrease in research and development expense was due to a decrease in personnel related expenses of $0.2 million which included a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $0.7 million, partially offset by an increase of $0.4 million in payroll costs primarily resulting from new hires in our research and development function during the past twelve months. Materials and prototypes expense decreased by $0.3 million due to decreased design and engineering costs related to the development of the next generation of our Evolv Express system. Professional fees and other expense remained consistent.

[0001628280-25-020355:mdna:218]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:219]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $2.4 million which included an increase in payroll costs and stock-based compensation of $2.0 million resulting primarily from new hires in our sales and marketing functions to support increased sales volume during the past twelve months and certain other one-time employee-related benefits. Stock compensation expense included in sales and marketing expense was $2.7 million for the three months ended June 30, 2024 compared to $2.5 million for the three months ended June 30, 2023. Advertising and direct marketing expense increased by $0.4 million due to an increase in expenses related to trade shows and events of $0.3 million. Travel and entertainment expense increased by $0.1 million due to an increase in travel costs for in-person sales personnel meetings. Professional fees increased by $0.3 million due primarily to an increase in marketing consulting costs. Other expense increased by $0.1 million primarily due to an increase in IT and software subscription costs.

[0001628280-25-020355:mdna:220]
64

[0001628280-25-020355:mdna:221]
General and Administrative Expenses

[0001628280-25-020355:mdna:222]
The increase in general and administrative expense was due to an increase in personnel related expenses of $0.9 million which included an increase in payroll costs and stock-based compensation of $0.9 million resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $3.3 million for the three months ended June 30, 2024 compared to $2.8 million for the three months ended June 30, 2023. Professional fees increased by $0.2 million due to an increase in outsourced accounting consultancy and audit fees. Other expense increased by $2.5 million primarily due to an increase of $1.8 million of certain one-time expenses incurred during the three months ended June 30, 2024 compared to $0.4 million for the three months ended June 30, 2023, primarily due to consulting and legal fees related to the FTC and SEC investigations, as well as increases in rent for additional leased space of $0.2 million, IT and software subscription costs of $0.4 million, and bad debt expenses of $0.4 million. Increases in general and administrative expense were partially offset by a decrease in insurance expense as director and officer insurance premiums for the period decreased by $0.3 million.

[0001628280-25-020355:mdna:223]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:224]
No loss from impairment of property and equipment was recognized for the three months ended June 30, 2024, compared to $0.2 million for the three months ended June 30, 2023, primarily related to the removal of Evolv Express units from service, resulting in impairment of the remaining economic value of such units.

[0001628280-25-020355:mdna:225]
Interest Income

[0001628280-25-020355:mdna:226]
Interest income of $0.7 million for the three months ended June 30, 2024 and $1.9 million for the three months ended June 30, 2023 related primarily to interest earned on money market funds and the accretion of discounts on treasury bills.

[0001628280-25-020355:mdna:227]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:228]
Change in the fair value of the contingent earn-out liability resulted in a $16.5 million gain and a $28.1 million loss for the three months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:229]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:230]
Change in the fair value of the contingently issuable common stock liability resulted in a $3.7 million gain and a $5.1 million loss for the three months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:231]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:232]
Change in the fair value of the public warrant liability resulted in a $4.9 million gain and a $11.8 million loss for the three months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:233]
65

[0001628280-25-020355:mdna:234]
Comparison of the Six Months Ended June 30, 2024 and 2023

[0001628280-25-020355:mdna:235]
The following table summarizes our results of operations for the six months ended June 30, 2024 and 2023 (in thousands):

[0001628280-25-020355:mdna:236]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  | (Restated) |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 3,445 |  |  | $ | 17,464 |  |  | $ | (14,019) |  |  | (80) | % |
| Subscription revenue | 29,874 |  |  | 13,875 |  |  | 15,999 |  |  | 115 |  |
| Service revenue | 10,818 |  |  | 6,405 |  |  | 4,413 |  |  | 69 |  |
| License fee and other revenue | 3,268 |  |  | 1,280 |  |  | 1,988 |  |  | 155 |  |
| Total revenue | 47,405 |  |  | 39,024 |  |  | 8,381 |  |  | 21 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 5,953 |  |  | 19,779 |  |  | (13,826) |  |  | (70) |  |
| Cost of subscription revenue | 11,894 |  |  | 5,619 |  |  | 6,275 |  |  | 112 |  |
| Cost of service revenue | 2,519 |  |  | 1,597 |  |  | 922 |  |  | 58 |  |
| Cost of license fee and other revenue | 301 |  |  | 574 |  |  | (273) |  |  | (48) |  |
| Total cost of revenue | 20,667 |  |  | 27,569 |  |  | (6,902) |  |  | (25) |  |
| Gross profit | 26,738 |  |  | 11,455 |  |  | 15,283 |  |  | 133 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 12,246 |  |  | 11,784 |  |  | 462 |  |  | 4 |  |
| Sales and marketing | 32,870 |  |  | 26,234 |  |  | 6,636 |  |  | 25 |  |
| General and administrative | 25,899 |  |  | 19,793 |  |  | 6,106 |  |  | 31 |  |
| Loss from impairment of property and equipment | — |  |  | 294 |  |  | (294) |  |  | * |
| Total operating expenses | 71,015 |  |  | 58,105 |  |  | 12,910 |  |  | 22 |  |
| Loss from operations | (44,277) |  |  | (46,650) |  |  | 2,373 |  |  | 5 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (654) |  |  | 654 |  |  | * |
| Interest income | 1,766 |  |  | 2,806 |  |  | (1,040) |  |  | (37) |  |
| Other expense, net | (67) |  |  | (3) |  |  | (64) |  |  | (2,133) |  |
| Loss on extinguishment of debt | — |  |  | (626) |  |  | 626 |  |  | * |
| Change in fair value of contingent earn-out liability | 23,413 |  |  | (31,431) |  |  | 54,844 |  |  | 174 |  |
| Change in fair value of contingently issuable common stock liability | 4,274 |  |  | (5,837) |  |  | 10,111 |  |  | 173 |  |
| Change in fair value of public warrant liability | 7,037 |  |  | (13,501) |  |  | 20,538 |  |  | 152 |  |
| Total other income (expense), net | 36,423 |  |  | (49,246) |  |  | 85,669 |  |  | 174 |  |
| Net loss | $ | (7,854) |  |  | $ | (95,896) |  |  | $ | 88,042 |  |  | 92 | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (73) % |  | (13) % |  | N/A |  | (60) % |
| Subscription revenue | 60 % |  | 60 % |  | N/A |  | 1 % |
| Service revenue | 77 % |  | 75 % |  | N/A |  | 2 % |
| License fee and other revenue | 91 % |  | 55 % |  | N/A |  | 36 % |

[0001628280-25-020355:mdna:237]
*N/A – Not meaningful

[0001628280-25-020355:mdna:238]
66

[0001628280-25-020355:mdna:239]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:240]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 137 new customers during the six months ended June 30, 2024, (iii) the expansion of our existing customers’ initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:241]
Product Revenue

[0001628280-25-020355:mdna:242]
The decreases in product revenue and cost of product revenue are primarily due to a transition to pure subscription sales and sales under our distributor licensing model during the preceding twelve months. The decrease in product gross profit margin for the six months ended June 30, 2024 compared to the six months ended June 30, 2023 is primarily attributable to $1.0 million of expense related to an increase to our inventory reserve and $1.2 million of expense associated with adverse non-cancellable inventory purchase commitments during the six months ended June 30, 2024, both of which relate primarily to the ongoing transition of our manufacturing operations to the next generation of Evolv Express systems and the determination that certain components within our legacy systems will not be used in the next generation systems.

[0001628280-25-020355:mdna:243]
Subscription Revenue

[0001628280-25-020355:mdna:244]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to continued growth in our customer base for the six months ended June 30, 2024 compared to the six months ended June 30, 2023, which was due to a transition to our pure subscription model and a higher number of active Evolv Express units deployed under our pure subscription contract model.

[0001628280-25-020355:mdna:245]
Service Revenue

[0001628280-25-020355:mdna:246]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech under our distributor licensing model, for the six months ended June 30, 2024 compared to the six months ended June 30, 2023.

[0001628280-25-020355:mdna:247]
License fee and other revenue

[0001628280-25-020355:mdna:248]
The increase in license fee and other revenue, gross profit, and gross profit margin was primarily driven by $2.4 million of license fees earned during the six months ended June 30, 2024 compared to no license fees earned during the six months ended June 30, 2023 under the Distribution and License Agreement which was executed in March 2023.

[0001628280-25-020355:mdna:249]
Research and Development Expenses

[0001628280-25-020355:mdna:250]
The increase in research and development expense was due to an increase in materials and prototypes expense of $0.1 million, due to an increase of inventory reserve on unused components of $0.4 million offset by the decrease of design and engineering costs of $0.2 million, both of which relate primarily to the development of the next generation of our Evolv Express system. Professional fees decreased by $0.1 million due to consulting costs incurred for product development and engineering. Other expense increased by $0.3 million due to an increase in IT and software subscription costs of $0.2 million. Personnel related expenses increased by $0.1 million due to a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $1.1 million, partially offset by an increase in payroll costs of $1.1 million primarily resulting from new hires in our research and development function during the past twelve months.

[0001628280-25-020355:mdna:251]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:252]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $5.0 million which included an increase in payroll costs and stock-based compensation of $4.6 million resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increased sales volume and certain other one-time employee-related termination costs. Stock compensation expense included in sales and marketing expenses was $5.7 million for the six months ended June 30, 2024 compared to $4.5 million for the six months ended June 30, 2023. Advertising and direct marketing expense remained consistent. Travel and entertainment expense increased by $0.5 million due to an increase in travel costs for in-person sales personnel meetings. Professional fees increased by $0.7 million due primarily to an increase in marketing consulting costs. Other expense increased by $0.4 million primarily due to an increase in IT and software subscription costs of $0.2 million.

[0001628280-25-020355:mdna:253]
General and Administrative Expenses

[0001628280-25-020355:mdna:254]
The increase in general and administrative expense was due to an increase in personnel related expenses of $2.0 million, which included an increase in payroll costs and stock-based compensation of $2.0 million resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $5.7 million for the six months ended June 30, 2024 compared to $4.8 million for the six months ended June 30, 2023. Professional fees increased by $1.3 million due to an increase in outsourced accounting consultancy and audit fees. Insurance costs decreased by $0.6 million due to a decrease in director and officer insurance premiums. Other expense increased by $3.4 million primarily due to a $1.1 million accrual for ongoing regulatory matters and an increase of $2.2 million of certain one-time expenses, primarily due to consulting and legal fees, as well as increases in rent for additional leased space of $0.3 million, IT and software subscription costs of $0.6 million, and property taxes of $0.4 million.

[0001628280-25-020355:mdna:255]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:256]
No loss from impairment of property and equipment was recognized for the six months ended June 30, 2024, compared to $0.3 million for the six months ended June 30, 2023, primarily related to the removal of Evolv Express units from service, resulting in impairment of the remaining economic value of such units.

[0001628280-25-020355:mdna:257]
Interest Expense

[0001628280-25-020355:mdna:258]
No interest expense was recognized for the six months ended June 30, 2024, compared to $0.7 million for the six months ended June 30, 2023. During March 2023, the Company fully repaid all borrowings and accrued interest under its term loans with SVB pursuant to the 2022 SVB Credit Agreement.

[0001628280-25-020355:mdna:259]
Interest Income

[0001628280-25-020355:mdna:260]
Interest income of $1.8 million and $2.8 million for the six months ended June 30, 2024 and 2023, respectively, related primarily to interest earned on money market funds and the accretion of discounts on treasury bills.

[0001628280-25-020355:mdna:261]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:262]
Change in the fair value of the contingent earn-out liability resulted in a $23.4 million gain and a $31.4 million loss for the six months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:263]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:264]
Change in the fair value of the contingently issuable common stock liability resulted in a $4.3 million gain and a $5.8 million loss for the six months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:265]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:266]
Change in the fair value of the public warrant liability resulted in a $7.0 million gain and a $13.5 million loss for the six months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:267]
68

[0001628280-25-020355:mdna:268]
Comparison of the Three Months Ended March 31, 2024 and 2023

[0001628280-25-020355:mdna:269]
The following table summarizes our results of operations for the three months ended March 31, 2024 and 2023 (in thousands):

[0001628280-25-020355:mdna:270]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
|  | (Restated) |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 1,491 |  |  | $ | 10,612 |  |  | $ | (9,121) |  |  | (86) | % |
| Subscription revenue | 14,219 |  |  | 6,173 |  |  | 8,046 |  |  | 130 |  |
| Service revenue | 5,252 |  |  | 2,759 |  |  | 2,493 |  |  | 90 |  |
| License fee and other revenue | 1,219 |  |  | 578 |  |  | 641 |  |  | 111 |  |
| Total revenue | 22,181 |  |  | 20,122 |  |  | 2,059 |  |  | 10 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 3,114 |  |  | 12,362 |  |  | (9,248) |  |  | (75) |  |
| Cost of subscription revenue | 5,585 |  |  | 2,334 |  |  | 3,251 |  |  | 139 |  |
| Cost of service revenue | 1,198 |  |  | 583 |  |  | 615 |  |  | 105 |  |
| Cost of license fee and other revenue | 129 |  |  | 304 |  |  | (175) |  |  | (58) |  |
| Total cost of revenue | 10,026 |  |  | 15,583 |  |  | (5,557) |  |  | (36) |  |
| Gross profit | 12,155 |  |  | 4,539 |  |  | 7,616 |  |  | 168 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,396 |  |  | 5,395 |  |  | 1,001 |  |  | 19 |  |
| Sales and marketing | 15,859 |  |  | 12,638 |  |  | 3,221 |  |  | 25 |  |
| General and administrative | 11,806 |  |  | 8,928 |  |  | 2,878 |  |  | 32 |  |
| Loss from impairment of property and equipment | — |  |  | 137 |  |  | (137) |  |  | * |
| Total operating expenses | 34,061 |  |  | 27,098 |  |  | 6,963 |  |  | 26 |  |
| Loss from operations | (21,906) |  |  | (22,559) |  |  | 653 |  |  | 3 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (654) |  |  | 654 |  |  | * |
| Interest income | 1,085 |  |  | 953 |  |  | 132 |  |  | 14 |  |
| Other income (expense), net | (28) |  |  | 19 |  |  | (47) |  |  | (247) |  |
| Loss on extinguishment of debt | — |  |  | (626) |  |  | 626 |  |  | * |
| Change in fair value of contingent earn-out liability | 6,899 |  |  | (3,318) |  |  | 10,217 |  |  | 308 |  |
| Change in fair value of contingently issuable common stock liability | 527 |  |  | (742) |  |  | 1,269 |  |  | 171 |  |
| Change in fair value of public warrant liability | 2,151 |  |  | (1,750) |  |  | 3,901 |  |  | 223 |  |
| Total other income (expense), net | 10,634 |  |  | (6,118) |  |  | 16,752 |  |  | 274 |  |
| Net loss | $ | (11,272) |  |  | $ | (28,677) |  |  | $ | 17,405 |  |  | 61 | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (109) % |  | (16) % |  | N/A |  | (92) % |
| Subscription revenue | 61 % |  | 62 % |  | N/A |  | (1) % |
| Service revenue | 77 % |  | 79 % |  | N/A |  | (2) % |
| License fee and other revenue | 89 % |  | 47 % |  | N/A |  | 42 % |

[0001628280-25-020355:mdna:271]
*N/A – Not meaningful

[0001628280-25-020355:mdna:272]
69

[0001628280-25-020355:mdna:273]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:274]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 53 new customers during the three months ended March 31, 2024, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:275]
Our average sales cycle increased to five months during the first fiscal quarter of 2024 compared to three months during the first fiscal quarter of 2023, an increase of approximately 40%. We believe the FTC and SEC investigations were the primary reason for the lengthening of the sales cycle as customers work to satisfy incremental due diligence requirements. However, the investigations did not materially impact our win rate, which increased year over year.

[0001628280-25-020355:mdna:276]
Product Revenue

[0001628280-25-020355:mdna:277]
The decreases in product revenue and cost of product revenue are primarily due to a transition to pure subscription sales and sales under our distributor licensing model during the preceding twelve months. The decrease in product gross profit margin for the three months ended March 31, 2024 compared to the prior year period is primarily attributable to $0.7 million of expense related to an increase to our inventory reserve and $1.2 million of expense associated with adverse non-cancellable inventory purchase commitments, both of which relate primarily to the ongoing transition of our manufacturing operations to the next generation of Evolv Express systems and the determination that certain components within our legacy systems will not be used in the next generation systems.

[0001628280-25-020355:mdna:278]
Subscription Revenue

[0001628280-25-020355:mdna:279]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base for the three months ended March 31, 2024 compared to the prior year period, which was due to a transition to our pure subscription model and a higher number of active Evolv Express units deployed under our pure subscription contract model.

[0001628280-25-020355:mdna:280]
Service Revenue

[0001628280-25-020355:mdna:281]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech, for the three months ended March 31, 2024 compared to the prior year period.

[0001628280-25-020355:mdna:282]
License fee and other revenue

[0001628280-25-020355:mdna:283]
The increase in license fee and other revenue, gross profit, and gross profit margin was primarily driven by $0.7 million of license fees earned during the three months ended March 31, 2024 compared to no license fees earned during the prior year period under the Distribution and License Agreement which was executed in March 2023. Revenue from install, training, and professional services was $0.5 million for the three months ended March 31, 2024 compared to $0.6 million for the prior year period.

[0001628280-25-020355:mdna:284]
Research and Development Expenses

[0001628280-25-020355:mdna:285]
The increase in research and development expense was due to an increase in personnel related expenses of $0.3 million which included an increase in payroll costs of $0.7 million primarily resulting from new hires in our research and development function during the past twelve months, offset by a $0.4 million higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased. Materials and prototypes expense increased by $0.5 million due to increased design and engineering costs related to the development of the next generation of our Evolv Express system. Other expense increased by $0.3 million due to an increase in IT and software subscription costs of $0.1 million and an increase in supplies cost of $0.1 million. Professional fees decreased by $0.1 million due to higher amount of costs capitalized related to internal-use software and software embedded in products to be sold or leased, offset by consulting costs incurred for product development and engineering.

[0001628280-25-020355:mdna:286]
70

[0001628280-25-020355:mdna:287]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:288]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $2.6 million, due to an increase in payroll costs and stock-based compensation of $2.7 million resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increased sales volume. Stock compensation expense included in sales and marketing expenses was $3.0 million for the three months ended March 31, 2024 compared to $2.0 million for the three months ended March 31, 2023. Travel and entertainment expense increased by $0.4 million due to an increase in travel costs for in-person sales personnel meetings. Professional fees increased by $0.4 million due primarily to an increase in marketing consulting costs. Other expense increased by $0.3 million primarily due to an increase in IT and software subscription costs of $0.1 million. These costs were partially offset by a decrease in advertising and direct marketing expense of $0.4 million primarily due to a decrease in expense related to trade shows and events.

[0001628280-25-020355:mdna:289]
General and Administrative Expenses

[0001628280-25-020355:mdna:290]
The increase in general and administrative expense was due to an increase in personnel related expenses of $1.1 million due to an increase in payroll costs and stock-based compensation of $1.0 million resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expense was $2.4 million for the three months ended March 31, 2024 compared to $2.1 million for the three months ended March 31, 2023. Professional fees increased by $1.1 million due to an increase in outsourced accounting consultancy and audit fees. Other expense increased by $0.8 million primarily due to $0.4 million of certain one-time expenses incurred during the three months ended March 31, 2024, primarily due to consulting and legal fees, as well as increases in rent, IT and software subscription costs, and property taxes of $0.2 million each. Increases in general and administrative expense were partially offset by a decrease in director and officer insurance premiums by $0.2 million.

[0001628280-25-020355:mdna:291]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:292]
No loss from impairment of property and equipment was recognized for the three months ended March 31, 2024, compared to $0.1 million for the three months ended March 31, 2023, primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in impairment of the remaining economic value of such units.

[0001628280-25-020355:mdna:293]
Interest Expense

[0001628280-25-020355:mdna:294]
No interest expense was recognized for the three months ended March 31, 2024, compared to $0.7 million for the three months ended March 31, 2023. During March 2023, the Company fully repaid all borrowings and accrued interest under its term loans with SVB pursuant to the 2022 SVB Credit Agreement.

[0001628280-25-020355:mdna:295]
Interest Income

[0001628280-25-020355:mdna:296]
Interest income of $1.1 million for the three months ended March 31, 2024 and $1.0 million for the three months ended March 31, 2023 related primarily to interest earned on money market funds, and for the three months ended March 31, 2024, accretion of discounts on treasury bills.

[0001628280-25-020355:mdna:297]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:298]
Change in the fair value of the contingent earn-out liability resulted in a $6.9 million gain and a $3.3 million loss for the three months ended March 31, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:299]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:300]
Change in the fair value of the contingently issuable common stock liability resulted in a $0.5 million gain and a $0.7 million loss for the three months ended March 31, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:301]
71

[0001628280-25-020355:mdna:302]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:303]
Change in the fair value of the public warrant liability resulted in a $2.2 million gain and a $1.8 million loss for the three months ended March 31, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:304]
Comparison of the Three Months Ended September 30, 2023 and 2022

[0001628280-25-020355:mdna:305]
The following table summarizes our results of operations for the three months ended September 30, 2023 and 2022 (in thousands):

[0001628280-25-020355:mdna:306]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
|  | (Restated) |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 3,456 |  |  | $ | 9,607 |  |  | $ | (6,151) |  |  | (64) | % |
| Subscription revenue | 9,858 |  |  | 5,105 |  |  | 4,753 |  |  | 93 |  |
| Service revenue | 4,345 |  |  | 1,303 |  |  | 3,042 |  |  | 233 |  |
| License fee and other revenue | 2,302 |  |  | 281 |  |  | 2,021 |  |  | 719 |  |
| Total revenue | 19,961 |  |  | 16,296 |  |  | 3,665 |  |  | 22 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 3,496 |  |  | 13,064 |  |  | (9,568) |  |  | (73) |  |
| Cost of subscription revenue | 4,157 |  |  | 2,177 |  |  | 1,980 |  |  | 91 |  |
| Cost of service revenue | 1,219 |  |  | 500 |  |  | 719 |  |  | 144 |  |
| Cost of license fee and other revenue | 198 |  |  | 638 |  |  | (440) |  |  | (69) |  |
| Total cost of revenue | 9,070 |  |  | 16,379 |  |  | (7,309) |  |  | (45) |  |
| Gross profit | 10,891 |  |  | (83) |  |  | 10,974 |  |  | 13,222 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,386 |  |  | 5,182 |  |  | 1,204 |  |  | 23 |  |
| Sales and marketing | 14,408 |  |  | 11,969 |  |  | 2,439 |  |  | 20 |  |
| General and administrative | 11,261 |  |  | 9,093 |  |  | 2,168 |  |  | 24 |  |
| Loss from impairment of property and equipment | 28 |  |  | 189 |  |  | (161) |  |  | (85) |  |
| Total operating expenses | 32,083 |  |  | 26,433 |  |  | 5,650 |  |  | 21 |  |
| Loss from operations | (21,192) |  |  | (26,516) |  |  | 5,324 |  |  | 20 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (188) |  |  | 188 |  |  | * |
| Interest income | 1,791 |  |  | 1,052 |  |  | 739 |  |  | 70 |  |
| Other income (expense), net | (64) |  |  | (57) |  |  | (7) |  |  | (12) |  |
| Change in fair value of contingent earn-out liability | 14,078 |  |  | 7,245 |  |  | 6,833 |  |  | 94 |  |
| Change in fair value of contingently issuable common stock liability | 2,277 |  |  | 1,081 |  |  | 1,196 |  |  | 111 |  |
| Change in fair value of public warrant liability | 8,156 |  |  | (1,146) |  |  | 9,302 |  |  | 812 |  |
| Total other income (expense), net | 26,238 |  |  | 7,987 |  |  | 18,251 |  |  | 229 |  |
| Net income (loss) | $ | 5,046 |  |  | $ | (18,529) |  |  | $ | 23,575 |  |  | 127 | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (1) % |  | (36) % |  | N/A |  | 35 % |
| Subscription revenue | 58 % |  | 57 % |  | N/A |  | — % |
| Service revenue | 72 % |  | 62 % |  | N/A |  | 10 % |
| License fee and other revenue | 91 % |  | (127) % |  | N/A |  | 218 % |

[0001628280-25-020355:mdna:307]
72

[0001628280-25-020355:mdna:308]
*N/A – Not meaningful

[0001628280-25-020355:mdna:309]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:310]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 70 new customers during the three months ended September 30, 2023, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:311]
Product Revenue

[0001628280-25-020355:mdna:312]
The decreases in product revenue and cost of product revenue are primarily due to a transition to pure subscription sales and sales under our distributor licensing model during the preceding twelve months. The increases in product gross profit and product gross profit margin during the three months ended September 30, 2023 compared to the prior year period reflects a higher average number of units sold per transaction across our target end markets, particularly in the professional sports vertical.

[0001628280-25-020355:mdna:313]
Subscription Revenue

[0001628280-25-020355:mdna:314]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base, a transition to our pure subscription model, and a higher number of active Evolv Express units deployed under our pure subscription contract model. Subscription gross profit margin increased slightly as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:315]
Service Revenue

[0001628280-25-020355:mdna:316]
The increases in service revenue and gross profit are primarily due to an increased number of active revenue-generating purchase subscription units and an increase in installation and training services. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:317]
License fee and other revenue

[0001628280-25-020355:mdna:318]
License fee and other revenue for the three months ended September 30, 2023 consists of $2.0 million of license fees earned in connection to the Distribution and License Agreement. The Company did not earn any license fee revenue for periods prior to the three months ended September 30, 2023.

[0001628280-25-020355:mdna:319]
Research and Development Expenses

[0001628280-25-020355:mdna:320]
The increase in research and development expense was due to an increase in personnel related expenses of $0.7 million, which included an increase in payroll costs and stock-based compensation of $0.9 million primarily resulting from new hires in our research and development function during the past twelve months, offset by an increase of $0.4 million of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased. Stock-based compensation expense included in research and development expenses was $1.1 million for the three months ended September 30, 2023 compared to $1.2 million for the three months ended September 30, 2022. Materials and prototypes expense increased by $0.2 million due to increased design and engineering costs related to the development of the next generation of our Evolv Express system. Professional fees increased by $0.1 million due to consulting costs incurred for product development and engineering. Other expense increased by $0.3 million primarily due to software subscriptions.

[0001628280-25-020355:mdna:321]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:322]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $2.0 million, which included an increase in payroll costs and commissions of $1.6 million resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increased sales volume. Stock compensation expense included in sales and marketing expenses was $2.3 million for the three months ended September 30, 2023 compared to $2.7 million for the three months ended September 30, 2022. Travel and entertainment expense increased by $0.5 million due to an increase in travel costs for in-person sales personnel meetings and events. Professional fees increased by $0.3 million due primarily to an increase in marketing consulting costs. These increases in sales and marketing expense were partially offset by a decrease in advertising and direct marketing expense of $0.6 million.

[0001628280-25-020355:mdna:323]
74

[0001628280-25-020355:mdna:324]
General and Administrative Expenses

[0001628280-25-020355:mdna:325]
The increase in general and administrative expense was due to an increase in personnel related expenses of $1.3 million, which included an increase in payroll costs and stock-based compensation of $1.1 million resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $2.5 million for the three months ended September 30, 2023 compared to $2.4 million for the three months ended September 30, 2022. Other expense increased by $1.2 million primarily due to $0.9 million of certain one-time expenses incurred during the three months ended September 30, 2023, primarily related to legal fees for one-time matters, as well as increases in software subscriptions of $0.3 million and other miscellaneous expenses.

[0001628280-25-020355:mdna:326]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:327]
Loss from impairment of property and equipment was less than $0.1 million and $0.2 million for the three months ended September 30, 2023 and 2022, respectively, primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in impairment of the remaining economic value of such units.

[0001628280-25-020355:mdna:328]
Interest Expense

[0001628280-25-020355:mdna:329]
No interest expense was recognized for the three months ended September 30, 2023, compared to $0.2 million for the three months ended September 30, 2022. During March 2023, the Company fully repaid all borrowings and accrued interest under its term loans with SVB pursuant to the 2022 SVB Credit Agreement.

[0001628280-25-020355:mdna:330]
Interest Income

[0001628280-25-020355:mdna:331]
Interest income of $1.8 million for the three months ended September 30, 2023 and $1.1 million for the three months ended September 30, 2022 related primarily to interest earned on money market funds, and for the three months ended September 30, 2023, accretion of discounts on treasury bills.

[0001628280-25-020355:mdna:332]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:333]
Change in the fair value of the contingent earn-out liability resulted in gains of $14.1 million and $7.2 million for the three months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:334]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:335]
Change in the fair value of the contingently issuable common stock liability resulted in gains of $2.3 million and $1.1 million for the three months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:336]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:337]
Change in the fair value of the public warrant liability resulted in a $8.2 million gain and a $1.1 million loss for the three months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:338]
Comparison of the Nine Months Ended September 30, 2023 and 2022

[0001628280-25-020355:mdna:339]
The following table summarizes our results of operations for the nine months ended September 30, 2023 and 2022, (in thousands):

[0001628280-25-020355:mdna:340]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
|  | (Restated) |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 20,920 |  |  | $ | 18,965 |  |  | $ | 1,955 |  |  | 10 | % |
| Subscription revenue | 23,733 |  |  | 11,881 |  |  | 11,852 |  |  | 100 |  |
| Service revenue | 10,750 |  |  | 2,411 |  |  | 8,339 |  |  | 346 |  |
| License fee and other revenue | 3,582 |  |  | 670 |  |  | 2,912 |  |  | 435 |  |
| Total revenue | 58,985 |  |  | 33,927 |  |  | 25,058 |  |  | 74 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 23,275 |  |  | 23,617 |  |  | (342) |  |  | (1) |  |
| Cost of subscription revenue | 9,776 |  |  | 5,726 |  |  | 4,050 |  |  | 71 |  |
| Cost of service revenue | 2,816 |  |  | 1,652 |  |  | 1,164 |  |  | 70 |  |
| Cost of license fee and other revenue | 772 |  |  | 1,740 |  |  | (968) |  |  | (56) |  |
| Total cost of revenue | 36,639 |  |  | 32,735 |  |  | 3,904 |  |  | 12 |  |
| Gross profit | 22,346 |  |  | 1,192 |  |  | 21,154 |  |  | 1,775 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 18,170 |  |  | 13,731 |  |  | 4,439 |  |  | 32 |  |
| Sales and marketing | 40,642 |  |  | 33,246 |  |  | 7,396 |  |  | 22 |  |
| General and administrative | 31,054 |  |  | 29,484 |  |  | 1,570 |  |  | 5 |  |
| Loss from impairment of property and equipment | 322 |  |  | 1,038 |  |  | (716) |  |  | (69) |  |
| Total operating expenses | 90,188 |  |  | 77,499 |  |  | 12,689 |  |  | 16 |  |
| Loss from operations | (67,842) |  |  | (76,307) |  |  | 8,465 |  |  | 11 |  |
| Other (expense) income, net: |  |  |  |  |  |  |  |
| Interest expense | (654) |  |  | (489) |  |  | (165) |  |  | (34) |  |
| Interest income | 4,597 |  |  | 1,611 |  |  | 2,986 |  |  | 185 |  |
| Other expense, net | (67) |  |  | (57) |  |  | (10) |  |  | (18) |  |
| Loss on extinguishment of debt | (626) |  |  | — |  |  | (626) |  |  | * |
| Change in fair value of contingent earn-out liability | (17,353) |  |  | 9,754 |  |  | (27,107) |  |  | (278) |  |
| Change in fair value of contingently issuable common stock liability | (3,560) |  |  | 2,529 |  |  | (6,089) |  |  | (241) |  |
| Change in fair value of public warrant liability | (5,345) |  |  | 4,297 |  |  | (9,642) |  |  | (224) |  |
| Total other (expense) income, net | (23,008) |  |  | 17,645 |  |  | (40,653) |  |  | (230) |  |
| Net loss | $ | (90,850) |  |  | $ | (58,662) |  |  | $ | (32,188) |  |  | (55) | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (11) % |  | (25) % |  | N/A |  | 13 % |
| Subscription revenue | 59 % |  | 52 % |  | N/A |  | 7 % |
| Service revenue | 74 % |  | 31 % |  | N/A |  | 42 % |
| License fee and other revenue | 78 % |  | (160) % |  | N/A |  | 238 % |

[0001628280-25-020355:mdna:341]
*N/A – Not meaningful

[0001628280-25-020355:mdna:342]
76

[0001628280-25-020355:mdna:343]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:344]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 205 new customers during the nine months ended September 30, 2023, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:345]
Product Revenue

[0001628280-25-020355:mdna:346]
The decreases in product revenue and cost of product revenue are primarily due to a transition to pure subscription sales and sales under our distributor licensing model during the preceding twelve months. The increases in product gross profit and product gross profit margin during the nine months ended September 30, 2023 compared to the prior year period reflects a higher average number of units sold per transaction across our target end markets, particularly in the professional sports vertical.

[0001628280-25-020355:mdna:347]
Subscription Revenue

[0001628280-25-020355:mdna:348]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base, a transition to our pure subscription model, and a higher number of active Evolv Express units deployed under our pure subscription contract model. Subscription gross profit margin increased as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:349]
Service Revenue

[0001628280-25-020355:mdna:350]
The increase in service revenue and gross profit is primarily due to an increased number of active revenue-generating purchase subscription units and an increase in installation and training services. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:351]
License fee and other revenue

[0001628280-25-020355:mdna:352]
License fee and other revenue for the nine months ended September 30, 2023 consists of $2.0 million of license fees earned in connection to the Distribution and License Agreement. The Company did not earn any license fee revenue for periods prior to the nine months ended September 30, 2023.

[0001628280-25-020355:mdna:353]
Research and Development Expenses

[0001628280-25-020355:mdna:354]
The increase in research and development expense was due to an increase in personnel related expenses of $1.6 million, which included an increase in payroll costs and stock-based compensation of $2.8 million primarily resulting from new hires in our research and development function during the past twelve months, partially offset by a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $1.0 million. Stock compensation expense included in research and development expenses was $3.2 million for the nine months ended September 30, 2023 compared to $2.9 million for the nine months ended September 30, 2022. Materials and prototypes increased by $1.1 million due to design and engineering costs related to the next generation of our Evolv Express system. Professional fees increased by $1.3 million primarily due to consulting costs incurred for product development and engineering, offset by capitalized costs relating to consultants.

[0001628280-25-020355:mdna:355]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:356]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $8.1 million, which included an increase in payroll costs and commissions of $4.5 million resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increased sales volume, which drove increases in salaries of $1.8 million and commissions of $1.8 million. Stock compensation expense included in sales and marketing expenses was $6.8 million for the nine months ended September 30, 2023 compared to $6.4 million for the nine months ended September 30, 2022. Advertising and direct marketing expense decreased by $1.7 million  due to a decrease in expense related to trade shows and events, and other marketing costs. Travel and entertainment expense increased by $1.1 million due to an increase in travel costs for in-person sales personnel meetings and events. Professional fees increased by $0.8 million due primarily to an increase in marketing consulting costs. Other expense decreased by $0.9 million due primarily to $1.0 million of certain one-time retention benefits incurred during the nine months ended September 30, 2022 that were not incurred during the nine months ended September 30, 2023.

[0001628280-25-020355:mdna:357]
General and Administrative Expenses

[0001628280-25-020355:mdna:358]
The increase in general and administrative expense was due to an increase in personnel related expenses of $4.2 million, which included an increase in payroll costs and stock-based compensation of $4.6 million resulting from expanding our administrative team during the past twelve months partially offset by a decrease in recruiting expenses of $0.4 million. Stock compensation expense included in general and administrative expenses was $7.3 million for the nine months ended September 30, 2023 compared to $5.7 million for the nine months ended September 30, 2022. Professional fees decreased by $2.6 million due to a decrease in outsourced accounting consultancy and audit fees. Insurance expense decreased by $0.8 million primarily related to a decrease in director and officer insurance premiums.

[0001628280-25-020355:mdna:359]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:360]
Loss from impairment of property and equipment was $0.3 million and $1.0 million for the nine months ended September 30, 2023 and 2022, respectively, primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in impairment of the remaining economic value of such units.

[0001628280-25-020355:mdna:361]
Interest Expense and Loss on Extinguishment of Debt

[0001628280-25-020355:mdna:362]
Interest expense was $0.7 million for the nine months ended September 30, 2023, compared to $0.5 million for the nine months ended September 30, 2022. The increase was primarily due to interest expense incurred during the three months ended March 31, 2023 related to the Company's term loans with SVB pursuant to the 2022 SVB Credit Agreement. During March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write off of $0.3 million of unamortized debt issuance costs.

[0001628280-25-020355:mdna:363]
Interest Income

[0001628280-25-020355:mdna:364]
Interest income of $4.6 million for the nine months ended September 30, 2023 and $1.6 million for the nine months ended September 30, 2022 related primarily to interest earned on money market funds, and for the nine months ended September 30, 2023, accretion of discounts on treasury bills.

[0001628280-25-020355:mdna:365]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:366]
Change in the fair value of the contingent earn-out liability resulted in a $17.4 million loss and a $9.8 million gain for the nine months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:367]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:368]
Change in the fair value of the contingently issuable common stock liability resulted in a $3.6 million loss and a $2.5 million gain for the nine months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:369]
78

[0001628280-25-020355:mdna:370]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:371]
Change in the fair value of the public warrant liability resulted in a $5.3 million loss and a $4.3 million gain for the nine months ended September 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:372]
79

[0001628280-25-020355:mdna:373]
Comparison of the Three Months Ended June 30, 2023 and 2022

[0001628280-25-020355:mdna:374]
The following table summarizes our results of operations for the three months ended June 30, 2023 and 2022 (in thousands):

[0001628280-25-020355:mdna:375]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
|  | (Restated) |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 6,852 |  |  | $ | 4,164 |  |  | $ | 2,688 |  |  | 65 | % |
| Subscription revenue | 7,702 |  |  | 3,772 |  |  | 3,930 |  |  | 104 |  |
| Service revenue | 3,646 |  |  | 782 |  |  | 2,864 |  |  | 366 |  |
| License fee and other revenue | 702 |  |  | 203 |  |  | 499 |  |  | 246 |  |
| Total revenue | 18,902 |  |  | 8,921 |  |  | 9,981 |  |  | 112 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 7,417 |  |  | 5,347 |  |  | 2,070 |  |  | 39 |  |
| Cost of subscription revenue | 3,285 |  |  | 2,007 |  |  | 1,278 |  |  | 64 |  |
| Cost of service revenue | 1,014 |  |  | 467 |  |  | 547 |  |  | 117 |  |
| Cost of license fee and other revenue | 270 |  |  | 722 |  |  | (452) |  |  | (63) |  |
| Total cost of revenue | 11,986 |  |  | 8,543 |  |  | 3,443 |  |  | 40 |  |
| Gross profit | 6,916 |  |  | 378 |  |  | 6,538 |  |  | 1,730 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,389 |  |  | 4,374 |  |  | 2,015 |  |  | 46 |  |
| Sales and marketing | 13,596 |  |  | 11,605 |  |  | 1,991 |  |  | 17 |  |
| General and administrative | 10,865 |  |  | 9,574 |  |  | 1,291 |  |  | 13 |  |
| Loss from impairment of property and equipment | 157 |  |  | 753 |  |  | (596) |  |  | (79) |  |
| Total operating expenses | 31,007 |  |  | 26,306 |  |  | 4,701 |  |  | 18 |  |
| Loss from operations | (24,091) |  |  | (25,928) |  |  | 1,837 |  |  | 7 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (159) |  |  | 159 |  |  | * |
| Interest income | 1,853 |  |  | 491 |  |  | 1,362 |  |  | 277 |  |
| Other income (expense), net | (22) |  |  | — |  |  | (22) |  |  | * |
| Change in fair value of contingent earn-out liability | (28,113) |  |  | (569) |  |  | (27,544) |  |  | (4,841) |  |
| Change in fair value of contingently issuable common stock liability | (5,095) |  |  | (24) |  |  | (5,071) |  |  | (21,129) |  |
| Change in fair value of public warrant liability | (11,751) |  |  | (143) |  |  | (11,608) |  |  | (8,117) |  |
| Total other income (expense), net | (43,128) |  |  | (404) |  |  | (42,724) |  |  | (10,575) |  |
| Net loss | $ | (67,219) |  |  | $ | (26,332) |  |  | $ | (40,887) |  |  | (155) | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (8) % |  | (28) % |  | N/A |  | 20 % |
| Subscription revenue | 57 % |  | 47 % |  | N/A |  | 11 % |
| Service revenue | 72 % |  | 40 % |  | N/A |  | 32 % |
| License fee and other revenue | 62 % |  | (256) % |  | N/A |  | 317 % |

[0001628280-25-020355:mdna:376]
*N/A – Not meaningful

[0001628280-25-020355:mdna:377]
80

[0001628280-25-020355:mdna:378]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:379]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition of 74 new customers during the three months ended June 30, 2023, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:380]
Product Revenue

[0001628280-25-020355:mdna:381]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which reflect an ongoing increase in the adoption of Evolv Express units by schools and healthcare facilities. The increase in product gross profit and product gross profit margin during the three months ended June 30, 2023 compared to the prior year period is attributable primarily to higher average revenue per unit sold. These increases were tempered by (i) a continued strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets (single lane configurations typically generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price), and (ii) a higher percentage of sales made through our channel partners, which are generally at a lower average sale price.

[0001628280-25-020355:mdna:382]
Subscription Revenue

[0001628280-25-020355:mdna:383]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed under our pure subscription contract model. Subscription gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:384]
Service Revenue

[0001628280-25-020355:mdna:385]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding year, as well as the increase in the number of installation and training services performed. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:386]
License fee and other revenue

[0001628280-25-020355:mdna:387]
The change in license fee and other revenue, gross profit, and gross profit margin was a result of the change in installation, training and professional service revenue earned during the period compared to the prior period.

[0001628280-25-020355:mdna:388]
Research and Development Expenses

[0001628280-25-020355:mdna:389]
The increase in research and development expense was due to an increase in personnel related expenses of $0.5 million, which included an increase in payroll costs and stock-based compensation of $0.8 million primarily resulting from new hires in our research and development function during the past twelve months, offset by a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $0.4 million. Stock-based compensation expense included in research and development expenses was $1.2 million for the three months ended June 30, 2023 compared to $1.1 million for the three months ended June 30, 2022. Materials and prototypes expense increased by $0.9 million due to increased design and engineering costs related to the development of the next generation of our Evolv Express system. Professional fees increased by $0.5 million primarily due to consulting costs incurred for product development and engineering.

[0001628280-25-020355:mdna:390]
81

[0001628280-25-020355:mdna:391]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:392]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $2.8 million, which included an increase in payroll costs, commissions and stock-based compensation of $1.3 million resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increase sales volume, as well as an increase of $0.9 million in overhead costs. Stock compensation expense included in sales and marketing expenses was $2.5 million for the three months ended June 30, 2023 compared to $2.2 million for the three months ended June 30, 2022. Advertising and direct marketing expense decreased by $0.4 million due to a decrease in expense related to trade shows and events and other marketing. Travel and entertainment expense increased by $0.4 million due to an increase in travel costs for in-person sales personnel meetings and events. Professional fees increased by $0.3 million due to an increase in marketing consulting costs. Other expense decreased  by $1.0 million due primarily to $1.0 million of certain one-time retention benefits incurred during the three months ended June 30, 2022 that were not incurred during the three months ended June 30, 2023.

[0001628280-25-020355:mdna:393]
General and Administrative Expenses

[0001628280-25-020355:mdna:394]
The increase in general and administrative expense was due to an increase in personnel related expenses of $2.1 million, which included an increase in payroll costs and stock-based compensation of $2.1 million resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $2.8 million for the three months ended June 30, 2023 compared to $1.5 million for the three months ended June 30, 2022. Professional fees decreased by $0.5 million due to a decrease in outsourced accounting consultancy fees. Insurance costs decreased by $0.3 million due to a decrease in director and officer insurance premiums.

[0001628280-25-020355:mdna:395]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:396]
Loss from impairment of property and equipment was an immaterial $0.2 million and $0.8 million for the three months ended June 30, 2023 and 2022, respectively.

[0001628280-25-020355:mdna:397]
Interest Expense

[0001628280-25-020355:mdna:398]
Interest expense was $0 for the three months ended June 30, 2023, compared to $0.2 million for the three months ended June 30, 2022. During March 2023, the Company fully repaid all borrowings and accrued interest under its term loans with SVB pursuant to the 2022 SVB Credit Agreement.

[0001628280-25-020355:mdna:399]
Interest Income

[0001628280-25-020355:mdna:400]
Interest income of $1.9 million for the three months ended June 30, 2023 and $0.5 million for the three months ended June 30, 2022 related primarily to interest earned on money market funds, and for the three months ended June 30, 2023, accretion of discounts on treasury bills.

[0001628280-25-020355:mdna:401]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:402]
Change in the fair value of the contingent earn-out liability resulted in losses of $28.1 million and $0.6 million for the three months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:403]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:404]
Change in the fair value of the contingently issuable common stock liability resulted in losses of $5.1 million and less than $0.1 million for the three months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:405]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:406]
Change in the fair value of the public warrant liability resulted in losses of $11.8 million and $0.1 million for the three months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:407]
Comparison of the Six Months Ended June 30, 2023 and 2022

[0001628280-25-020355:mdna:408]
The following table summarizes our results of operations for the six months ended June 30, 2023 and 2022, (in thousands):

[0001628280-25-020355:mdna:409]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
|  | (Restated) |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 17,464 |  |  | $ | 9,358 |  |  | $ | 8,106 |  |  | 87 | % |
| Subscription revenue | 13,875 |  |  | 6,776 |  |  | 7,099 |  |  | 105 |  |
| Service revenue | 6,405 |  |  | 1,108 |  |  | 5,297 |  |  | 478 |  |
| License fee and other revenue | 1,280 |  |  | 389 |  |  | 891 |  |  | 229 |  |
| Total revenue | 39,024 |  |  | 17,631 |  |  | 21,393 |  |  | 121 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 19,779 |  |  | 10,553 |  |  | 9,226 |  |  | 87 |  |
| Cost of subscription revenue | 5,619 |  |  | 3,549 |  |  | 2,070 |  |  | 58 |  |
| Cost of service revenue | 1,597 |  |  | 1,152 |  |  | 445 |  |  | 39 |  |
| Cost of license fee and other revenue | 574 |  |  | 1,102 |  |  | (528) |  |  | (48) |  |
| Total cost of revenue | 27,569 |  |  | 16,356 |  |  | 11,213 |  |  | 69 |  |
| Gross profit | 11,455 |  |  | 1,275 |  |  | 10,180 |  |  | 798 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 11,784 |  |  | 8,549 |  |  | 3,235 |  |  | 38 |  |
| Sales and marketing | 26,234 |  |  | 21,277 |  |  | 4,957 |  |  | 23 |  |
| General and administrative | 19,793 |  |  | 20,391 |  |  | (598) |  |  | (3) |  |
| Loss from impairment of property and equipment | 294 |  |  | 849 |  |  | (555) |  |  | (65) |  |
| Total operating expenses | 58,105 |  |  | 51,066 |  |  | 7,039 |  |  | 14 |  |
| Loss from operations | (46,650) |  |  | (49,791) |  |  | 3,141 |  |  | 6 |  |
| Other (expense) income, net: |  |  |  |  |  |  |  |
| Interest expense | (654) |  |  | (301) |  |  | (353) |  |  | (117) |  |
| Interest income | 2,806 |  |  | 559 |  |  | 2,247 |  |  | 402 |  |
| Other expense, net | (3) |  |  | — |  |  | (3) |  |  | * |
| Loss on extinguishment of debt | (626) |  |  | — |  |  | (626) |  |  | * |
| Change in fair value of contingent earn-out liability | (31,431) |  |  | 2,509 |  |  | (33,940) |  |  | (1,353) |  |
| Change in fair value of contingently issuable common stock liability | (5,837) |  |  | 1,448 |  |  | (7,285) |  |  | (503) |  |
| Change in fair value of public warrant liability | (13,501) |  |  | 5,443 |  |  | (18,944) |  |  | (348) |  |
| Total other (expense) income, net | (49,246) |  |  | 9,658 |  |  | (58,904) |  |  | (610) |  |
| Net loss | $ | (95,896) |  |  | $ | (40,133) |  |  | $ | (55,763) |  |  | (139) | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (13) % |  | (13) % |  | N/A |  | — % |
| Subscription revenue | 60 % |  | 48 % |  | N/A |  | 12 % |
| Service revenue | 75 % |  | (4) % |  | N/A |  | 79 % |
| License fee and other revenue | 55 % |  | (183) % |  | N/A |  | 238 % |

[0001628280-25-020355:mdna:410]
*N/A – Not meaningful

[0001628280-25-020355:mdna:411]
83

[0001628280-25-020355:mdna:412]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:413]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition of 135 new customers during the six months ended June 30, 2023, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:414]
Product Revenue

[0001628280-25-020355:mdna:415]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which reflect an ongoing increase in the adoption of Evolv Express units by schools and healthcare facilities.

[0001628280-25-020355:mdna:416]
The decrease in product gross profit during the six months ended June 30, 2023 compared to the prior year period is attributable primarily to an increase in product sales as product gross profit margin remained relatively consistent between periods. Product gross profit margin improved during the three months ended June 30, 2023 (negative 7%) compared to the three months ended March 31, 2023 (negative 21%) primarily as the result of higher average revenue per unit sold. These increases were tempered by (i) continued strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets (single lane configurations typically generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price), and (ii) a higher percentage of sales made through our channel partners, which are generally at a lower average sale price.

[0001628280-25-020355:mdna:417]
Subscription Revenue

[0001628280-25-020355:mdna:418]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed under our pure subscription contract model. Subscription gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:419]
Service Revenue

[0001628280-25-020355:mdna:420]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding year, as well as the increase in the number of installation and training services performed. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:421]
License fee and other revenue

[0001628280-25-020355:mdna:422]
The change in license fee and other revenue, gross profit, and gross profit margin was a result of the change in installation, training and professional service revenue earned during the period compared to the prior period.

[0001628280-25-020355:mdna:423]
Research and Development Expenses

[0001628280-25-020355:mdna:424]
The increase in research and development expense was due to an increase in personnel related expenses of $1.0 million, which included an increase in payroll costs and stock-based compensation of $1.9 million primarily resulting from new hires in our research and development function during the past twelve months, offset by a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $0.7 million. Stock compensation expense included in research and development expenses was $2.1 million for the six months ended June 30, 2023 compared to $1.7 million for the six months ended June 30, 2022. Materials and prototypes increased by $1.0 million due to design and engineering costs related to the next generation of our Evolv Express system. Professional fees increased by $1.2 million primarily due to consulting costs incurred for product development and engineering.

[0001628280-25-020355:mdna:425]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:426]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $6.0 million is due to an increase in payroll costs, commissions and stock-based compensation of $3.5 million resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increase sales volume, as well as an increase of $1.9 million in overhead costs. Stock compensation expense included in sales and marketing expenses was $4.5 million for the six months ended June 30, 2023 compared to $3.7 million for the six months ended June 30, 2022. Advertising and direct marketing expense decreased by $1.0 million primarily due to a decrease in expense related to trade shows and events and other marketing costs. Travel and entertainment expense increased by $0.6 million due to an increase in travel costs for in-person sales personnel meetings and events. Professional fees increased by $0.5 million due primarily to an increase in marketing consulting costs. Other expense decreased by $1.2 million due primarily to $1.0 million of certain one-time retention benefits incurred during the six months ended June 30, 2022 that were not incurred during the six months ended June 30, 2023.

[0001628280-25-020355:mdna:427]
General and Administrative Expenses

[0001628280-25-020355:mdna:428]
The decrease in general and administrative expense included an increase in personnel related expenses of $2.9 million, which included an increase in payroll costs and stock-based compensation of $3.5 million resulting from expanding our administrative team during the past twelve months, offset by a decrease of $0.3 million related to restructuring expense. Stock compensation expense included in general and administrative expenses was $4.8 million for the six months ended June 30, 2023 compared to $3.3 million for the six months ended June 30, 2022. Professional fees decreased by $2.4 million primarily related to a decrease in outsourced accounting consultancy fees. Insurance expense decreased by $0.6 million primarily related to a decrease in director and officer insurance premiums. Other expense decreased by $0.5 million primarily due to $1.0 million of certain one-time expenses and a $0.4 million one-time payment to a former employee during the six months ended June 30, 2022, offset by increases in software subscriptions of $0.5 million.

[0001628280-25-020355:mdna:429]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:430]
Loss from impairment of property and equipment was $0.3 million and $0.8 million for the six months ended June 30, 2023 and 2022, respectively.

[0001628280-25-020355:mdna:431]
Interest Expense and Loss on Extinguishment of Debt

[0001628280-25-020355:mdna:432]
Interest expense was $0.7 million for the six months ended June 30, 2023, compared to $0.3 million for the six months ended June 30, 2022. The increase was primarily due to interest expense incurred during the three months ended March 31, 2023 related to the Company's term loans with SVB pursuant to the 2022 SVB Credit Agreement. During March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write off of $0.3 million of unamortized debt issuance costs.

[0001628280-25-020355:mdna:433]
Interest Income

[0001628280-25-020355:mdna:434]
Interest income of $2.8 million for the six months ended June 30, 2023 and $0.6 million for the six months ended June 30, 2022 related primarily to interest earned on money market funds, and for the six months ended June 30, 2023, accretion of discounts on treasury bills.

[0001628280-25-020355:mdna:435]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:436]
Change in the fair value of the contingent earn-out liability resulted in a $31.4 million loss and a $2.5 million gain for the six months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:437]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:438]
Change in the fair value of the contingently issuable common stock liability resulted in a $5.8 million loss and a $1.4 million gain for the six months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market

[0001628280-25-020355:mdna:439]
85

[0001628280-25-020355:mdna:440]
adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:441]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:442]
Change in the fair value of the public warrant liability resulted in a $13.5 million loss and a $5.4 million gain for the six months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:443]
86

[0001628280-25-020355:mdna:444]
Comparison of the Three Months Ended March 31, 2023 and 2022

[0001628280-25-020355:mdna:445]
The following table summarizes our results of operations for the three months ended March 31, 2023 and 2022, (in thousands):

[0001628280-25-020355:mdna:446]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
|  | (Restated) |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 10,612 |  |  | $ | 5,194 |  |  | $ | 5,418 |  |  | 104 | % |
| Subscription revenue | 6,173 |  |  | 3,004 |  |  | 3,169 |  |  | 105 |  |
| Service revenue | 2,759 |  |  | 326 |  |  | 2,433 |  |  | 746 |  |
| License fee and other revenue | 578 |  |  | 186 |  |  | 392 |  |  | 211 |  |
| Total revenue | 20,122 |  |  | 8,710 |  |  | 11,412 |  |  | 131 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 12,362 |  |  | 5,206 |  |  | 7,156 |  |  | 137 |  |
| Cost of subscription revenue | 2,334 |  |  | 1,542 |  |  | 792 |  |  | 51 |  |
| Cost of service revenue | 583 |  |  | 685 |  |  | (102) |  |  | (15) |  |
| Cost of license fee and other revenue | 304 |  |  | 380 |  |  | (76) |  |  | (20) |  |
| Total cost of revenue | 15,583 |  |  | 7,813 |  |  | 7,770 |  |  | 99 |  |
| Gross profit | 4,539 |  |  | 897 |  |  | 3,642 |  |  | 406 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,395 |  |  | 4,175 |  |  | 1,220 |  |  | 29 |  |
| Sales and marketing | 12,638 |  |  | 9,672 |  |  | 2,966 |  |  | 31 |  |
| General and administrative | 8,928 |  |  | 10,817 |  |  | (1,889) |  |  | (17) |  |
| Loss from impairment of property and equipment | 137 |  |  | 96 |  |  | 41 |  |  | 43 |  |
| Total operating expenses | 27,098 |  |  | 24,760 |  |  | 2,338 |  |  | 9 |  |
| Loss from operations | (22,559) |  |  | (23,863) |  |  | 1,304 |  |  | 5 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (654) |  |  | (142) |  |  | (512) |  |  | (361) |  |
| Interest income | 953 |  |  | 68 |  |  | 885 |  |  | 1,301 |  |
| Other income (expense), net | 19 |  |  | — |  |  | 19 |  |  | * |
| Loss on extinguishment of debt | (626) |  |  | — |  |  | (626) |  |  | * |
| Change in fair value of contingent earn-out liability | (3,318) |  |  | 3,078 |  |  | (6,396) |  |  | (208) |  |
| Change in fair value of contingently issuable common stock liability | (742) |  |  | 1,472 |  |  | (2,214) |  |  | (150) |  |
| Change in fair value of public warrant liability | (1,750) |  |  | 5,586 |  |  | (7,336) |  |  | (131) |  |
| Total other income (expense), net | (6,118) |  |  | 10,062 |  |  | (16,180) |  |  | (161) |  |
| Net loss | $ | (28,677) |  |  | $ | (13,801) |  |  | $ | (14,876) |  |  | (108) | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (16) % |  | — % |  | N/A |  | (16) % |
| Subscription revenue | 62 % |  | 49 % |  | N/A |  | 14 % |
| Service revenue | 79 % |  | (110) % |  | N/A |  | 189 % |
| License fee and other revenue | 47 % |  | (104) % |  | N/A |  | 152 % |

[0001628280-25-020355:mdna:447]
*N/A – Not meaningful

[0001628280-25-020355:mdna:448]
87

[0001628280-25-020355:mdna:449]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:450]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition of 61 new customers during the three months ended March 31, 2023, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:451]
Product Revenue

[0001628280-25-020355:mdna:452]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which include ongoing increase in the adoption of Evolv Express units by schools, healthcare facilities, and professional sports arenas.

[0001628280-25-020355:mdna:453]
The decrease in product gross profit and product gross profit margin during the three months ended March 31, 2023 compared to the prior year period is attributable to several factors. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, and therefore a lower gross profit margin, during the three months ended March 31, 2023 compared to the prior year period.

[0001628280-25-020355:mdna:454]
Subscription Revenue

[0001628280-25-020355:mdna:455]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed under our pure subscription contract model. Subscription gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:456]
Service Revenue

[0001628280-25-020355:mdna:457]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding year, as well as the increase in the number of installation and training services performed. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-25-020355:mdna:458]
License fee and other revenue

[0001628280-25-020355:mdna:459]
The change in license fee and other revenue, gross profit, and gross profit margin was a result of the change in installation, training and professional service revenue earned during the period compared to the prior period.

[0001628280-25-020355:mdna:460]
Research and Development Expenses

[0001628280-25-020355:mdna:461]
The increase in research and development expense was due to an increase in personnel related expenses of $0.5 million, which included an increase in payroll costs and stock-based compensation of $1.0 million primarily resulting from new hires in our research and development function during the past twelve months, offset by a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $0.3 million. Stock compensation expense included in research and development expenses was $0.8 million for the three months ended March 31, 2023 compared to $0.5 million for the three months ended March 31, 2022. Professional fees increased by $0.7 million primarily relates to consulting costs incurred for product development and engineering.

[0001628280-25-020355:mdna:462]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:463]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $3.3 million, which included an increase in payroll costs, commissions and stock-based compensation of $2.1 million resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increase sales volume, as well as an increase of $1.0 million in overhead costs. Stock compensation expense included in sales and marketing expenses was $2.0 million for the three months ended March 31, 2023 compared to $1.5 million for the three months ended March 31, 2022. Advertising and direct marketing expense decreased by $0.6 million primarily due to a decrease in expense related to trade shows and events and other marketing costs.

[0001628280-25-020355:mdna:464]
88

[0001628280-25-020355:mdna:465]
General and Administrative Expenses

[0001628280-25-020355:mdna:466]
The decrease in general and administrative expense included an increase in personnel related expenses of $0.8 million, which included an increase in payroll costs and stock-based compensation of $1.3 million resulting from expanding our administrative team during the past twelve months, offset by $0.3 million in restructuring expense and $0.2 million in recruiting expenses. Stock compensation expense included in general and administrative expenses was $2.1 million for the three months ended March 31, 2023 compared to $1.8 million for the three months ended March 31, 2022. Professional fees decreased by $1.9 million due to a decrease in outsourced accounting consultancy fees. The decrease in non-income taxes of $0.2 million relates to expense incurred during the three months ended March 31, 2022 related to a sales tax contingency liability. Other expenses decreased by $0.5 million primarily due to a $0.4 million one-time payment to a former employee during the three months ended March 31, 2022.

[0001628280-25-020355:mdna:467]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:468]
Loss from impairment of property and equipment was an immaterial $0.1 million and $0.1 million for the three months ended March 31, 2023 and 2022, respectively.

[0001628280-25-020355:mdna:469]
Interest Expense

[0001628280-25-020355:mdna:470]
Interest expense was $0.7 million for the three months ended March 31, 2023, compared to $0.1 million for the three months ended March 31, 2022. The increase was primarily due to interest expense incurred related to the Company's term loans with SVB pursuant to the 2022 SVB Credit Agreement. During March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement.

[0001628280-25-020355:mdna:471]
Interest Income

[0001628280-25-020355:mdna:472]
Interest income of $1.0 million for the three months ended March 31, 2023 related primarily to interest earned on money market funds. $0.1 million interest income was earned for the three months ended March 31, 2022.

[0001628280-25-020355:mdna:473]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:474]
Change in fair value of the contingent earn-out liability resulted in a $3.3 million loss and a $3.1 million gain for the three months ended March 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:475]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:476]
Change in the fair value of the contingently issuable common stock liability resulted in a $0.7 million loss and a $1.5 million gain for the three months ended March 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:477]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:478]
Change in the fair value of the public warrant liability resulted in a $1.8 million loss and a $5.6 million gain for the three months ended March 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:479]
89

[0001628280-25-020355:mdna:480]
Comparison of the Three Months Ended September 30, 2022 and 2021

[0001628280-25-020355:mdna:481]
The following table summarizes our results of operations for the three months ended September 30, 2022 and 2021, (in thousands):

[0001628280-25-020355:mdna:482]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
|  | (Restated) |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 9,607 |  |  | $ | 5,395 |  |  | $ | 4,212 |  |  | 78 | % |
| Subscription revenue | 5,105 |  |  | 2,312 |  |  | 2,793 |  |  | 121 |  |
| Service revenue | 1,303 |  |  | 300 |  |  | 1,003 |  |  | 334 |  |
| License fee and other revenue | 281 |  |  | 417 |  |  | (136) |  |  | (33) |  |
| Total revenue | 16,296 |  |  | 8,424 |  |  | 7,872 |  |  | 93 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 13,064 |  |  | 2,967 |  |  | 10,097 |  |  | 340 |  |
| Cost of subscription revenue | 2,177 |  |  | 1,277 |  |  | 900 |  |  | 70 |  |
| Cost of service revenue | 500 |  |  | 193 |  |  | 307 |  |  | 159 |  |
| Cost of license fee and other revenue | 638 |  |  | 520 |  |  | 118 |  |  | 23 |
| Total cost of revenue | 16,379 |  |  | 4,957 |  |  | 11,422 |  |  | 230 |  |
| Gross profit | (83) |  |  | 3,467 |  |  | (3,550) |  |  | (102) |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,182 |  |  | 3,612 |  |  | 1,570 |  |  | 43 |  |
| Sales and marketing | 11,969 |  |  | 10,024 |  |  | 1,945 |  |  | 19 |  |
| General and administrative | 9,093 |  |  | 7,535 |  |  | 1,558 |  |  | 21 |  |
| Loss from impairment of property and equipment | 189 |  |  | 1,656 |  |  | (1,467) |  |  | (89) |  |
| Total operating expenses | 26,433 |  |  | 22,827 |  |  | 3,606 |  |  | 16 |  |
| Loss from operations | (26,516) |  |  | (19,360) |  |  | (7,156) |  |  | (37) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (188) |  |  | (295) |  |  | 107 |  |  | 36 |  |
| Interest income | 1,052 |  |  | — |  |  | 1,052 |  |  | * |
| Other income (expense), net | (57) |  |  | (669) |  |  | 612 |  |  | 91 |  |
| Loss on extinguishment of debt | — |  |  | (865) |  |  | 865 |  |  | * |
| Change in fair value of derivative liability | — |  |  | 475 |  |  | (475) |  |  | * |
| Change in fair value of contingent earn-out liability | 7,245 |  |  | 32,609 |  |  | (25,364) |  |  | (78) |  |
| Change in fair value of contingently issuable common stock liability | 1,081 |  |  | 5,718 |  |  | (4,637) |  |  | (81) |  |
| Change in fair value of public warrant liability | (1,146) |  |  | 3,152 |  |  | (4,298) |  |  | (136) |  |
| Change in fair value of common stock warrant liability | — |  |  | 42 |  |  | (42) |  |  | * |
| Total other income (expense), net | 7,987 |  |  | 40,167 |  |  | (32,180) |  |  | (80) |  |
| Net (loss) income | $ | (18,529) |  |  | $ | 20,807 |  |  | $ | (39,336) |  |  | (189) | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (36) % |  | 45 % |  | N/A |  | (81) % |
| Subscription revenue | 57 % |  | 45 % |  | N/A |  | 13 % |
| Service revenue | 62 % |  | 36 % |  | N/A |  | 26 % |
| License fee and other revenue | (127) % |  | (25) % |  | N/A |  | (102) % |

[0001628280-25-020355:mdna:483]
*N/A – Not meaningful

[0001628280-25-020355:mdna:484]
90

[0001628280-25-020355:mdna:485]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:486]
We believe there are several key trends driving increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition of 92 new customers during the three months ended September 30, 2022, (iii) the expansion of our customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:487]
Product Revenue

[0001628280-25-020355:mdna:488]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which include the significant increase in the adoption of Evolv Express units by schools, healthcare facilities, hotels, casinos, and professional sports arenas.

[0001628280-25-020355:mdna:489]
The decrease in gross profit and gross profit margin during the three months ended September 30, 2022 compared to the prior year period is attributable to several factors. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, and therefore a lower gross margin, during the three months ended September 30, 2022 compared to the prior year period. Gross profit and gross profit margin were also adversely impacted by marketing and sponsorship arrangements with certain customers, increases in shipping costs, and the costs associated with the write-off of scrap inventory incurred without corresponding revenue.

[0001628280-25-020355:mdna:490]
Subscription Revenue

[0001628280-25-020355:mdna:491]
The increases in subscription revenue and cost of subscription revenue are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed in the preceding twelve months. The increase in gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin is primarily driven by increased recurring revenue from increased active subscriptions and customer growth.

[0001628280-25-020355:mdna:492]
Service Revenue

[0001628280-25-020355:mdna:493]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding twelve months and increased installation and training related to the Evolv Express units. Gross profit and gross profit margin increased for the three months ended September 30, 2022 compared to the prior year period due

[0001628280-25-020355:mdna:494]
91

[0001628280-25-020355:mdna:495]
primarily to a larger mix of service revenue being derived from purchase subscriptions, which typically generate a higher gross profit margin compared to installation and training services.

[0001628280-25-020355:mdna:496]
License fee and other revenue

[0001628280-25-020355:mdna:497]
The change in license fee and other revenue, gross profit, and gross profit margin was a result of the change in installation, training and professional service revenue earned during the period compared to the prior period.

[0001628280-25-020355:mdna:498]
Research and Development Expenses

[0001628280-25-020355:mdna:499]
The increase in research and development expense was due to an increase in personnel related expenses of $0.9 million, which included an increase in payroll costs and stock-based compensation of $1.4 million primarily resulting from new hires in our research and development function during the past twelve months, offset by a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $0.2 million and a decrease of $0.4 million in recruiting expenses. Stock compensation expense included in research and development expenses was $1.2 million for the three months ended September 30, 2022 compared to $0.3 million for the three months ended September 30, 2021. Professional fees increased by $0.5 million due to consulting costs incurred for product development and engineering.

[0001628280-25-020355:mdna:500]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:501]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $1.0 million, which included an increase in payroll costs and commissions of $1.5 million resulting from new hires in our sales and marketing functions during the past twelve months, which includes functions such as partner development, customer success, and other business development, partially offset by a decrease in stock compensation expense included in sales and marketing expenses, which was $2.7 million for the three months ended September 30, 2022 compared to $3.3 million for the three months ended September 30, 2021. Travel and entertainment expense  increased by $0.5 million due to an increase in travel costs for in-person sales personnel meetings and events. Other expenses increased by $0.4 million primarily due to an increase in shipping costs related to demo units.

[0001628280-25-020355:mdna:502]
General and Administrative Expenses

[0001628280-25-020355:mdna:503]
The increase in general and administrative expense was due to an increase in personnel related expenses of $1.5 million, which included an increase in payroll costs and stock-based compensation of $2.1 million resulting from expanding our administrative team during the past twelve months, offset by a large transaction expense of $0.7 million that took place during the three months ended September 30, 2021, related to the merger. Stock compensation expense included in general and administrative expenses was $2.4 million for the three months ended September 30, 2022 compared to $1.0 million for the three months ended September 30, 2021. Other expenses increased by $0.2 million due to $0.6 million increase of property tax offset by a $0.5 million decrease in State and Local taxes.

[0001628280-25-020355:mdna:504]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:505]
Impairment of property and equipment was $0.2 million and $1.7 million for the three months ended September 30, 2022 and 2021, respectively. As we transition existing domestic customers to our current Express model, we are removing Edge units and Express prototype units from service, resulting in the impairment of the remaining economic value of such units.

[0001628280-25-020355:mdna:506]
Interest Expense

[0001628280-25-020355:mdna:507]
Interest expense was $0.2 million for the three months ended September 30, 2022, compared to $0.3 million for the three months ended September 30, 2021. The decrease was primarily due to interest expense and debt discount amortization related to the Convertible Notes during the three months ended September 30, 2021. The Convertible Notes converted to the Company’s stock upon closing of the Merger in July 2021.

[0001628280-25-020355:mdna:508]
Interest Income

[0001628280-25-020355:mdna:509]
Interest income of $1.1 million for the three months ended September 30, 2022 related primarily to interest earned on money market funds. No interest income was earned for the three months ended September 30, 2021.

[0001628280-25-020355:mdna:510]
92

[0001628280-25-020355:mdna:511]
Loss on Extinguishment of Debt

[0001628280-25-020355:mdna:512]
Loss on extinguishment of debt of $0.9 million for the three months ended September 30, 2021 related to a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes.

[0001628280-25-020355:mdna:513]
Change in Fair Value of Derivative Liability

[0001628280-25-020355:mdna:514]
Change in the fair value of the derivative liability resulted in a $0.5 million gain for the three months ended September 30, 2021, resulting from the settlement of the derivative liability upon the closing of the Merger.

[0001628280-25-020355:mdna:515]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:516]
Change in the fair value of the contingent earn-out liability resulted in gains of $7.2 million and $32.6 million for the three months ended September 30, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:517]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:518]
Change in the fair value of the contingently issuable common stock liability resulted in gains of $1.1 million and $5.7 million for the three months ended September 30, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:519]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:520]
Change in the fair value of the public warrant liability resulted in a $1.1 million loss and a $3.2 million gain for the three months ended September 30, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:521]
Change in Fair Value of Common Stock Warrant Liability

[0001628280-25-020355:mdna:522]
Change in the fair value of the common stock warrant liability resulted in less than $0.1 million gain for the three months ended September 30, 2021, resulting from the conversion of the common stock warrant liability upon the closing of the Merger and mark-to-market adjustments prior to the closing of the Merger.

[0001628280-25-020355:mdna:523]
Comparison of the Nine Months ended September 30, 2022 and 2021

[0001628280-25-020355:mdna:524]
The following table summarizes our results of operations for the nine months ended September 30, 2022 and 2021, (in thousands):

[0001628280-25-020355:mdna:525]
93

[0001628280-25-020355:mdna:526]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
|  | (Restated) |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 18,965 |  |  | $ | 10,279 |  |  | $ | 8,686 |  |  | 85 | % |
| Subscription revenue | 11,881 |  |  | 5,060 |  |  | 6,821 |  |  | 135 |  |
| Service revenue | 2,411 |  |  | 662 |  |  | 1,749 |  |  | 264 |  |
| License fee and other revenue | 670 |  |  | 794 |  |  | (124) |  |  | (16) |  |
| Total revenue | 33,927 |  |  | 16,795 |  |  | 17,132 |  |  | 102 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 23,617 |  |  | 7,386 |  |  | 16,231 |  |  | 220 |  |
| Cost of subscription revenue | 5,726 |  |  | 3,080 |  |  | 2,646 |  |  | 86 |  |
| Cost of service revenue | 1,652 |  |  | 733 |  |  | 919 |  |  | 125 |  |
| Cost of license fee and other revenue | 1,740 |  |  | 952 |  |  | 788 |  |  | 83 |
| Total cost of revenue | 32,735 |  |  | 12,151 |  |  | 20,584 |  |  | 169 |  |
| Gross profit | 1,192 |  |  | 4,644 |  |  | (3,452) |  |  | (74) |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 13,731 |  |  | 8,399 |  |  | 5,332 |  |  | 63 |  |
| Sales and marketing | 33,246 |  |  | 17,756 |  |  | 15,490 |  |  | 87 |  |
| General and administrative | 29,484 |  |  | 12,058 |  |  | 17,426 |  |  | 145 |  |
| Loss from impairment of property and equipment | 1,038 |  |  | 1,656 |  |  | (618) |  |  | (37) |  |
| Total operating expenses | 77,499 |  |  | 39,869 |  |  | 37,630 |  |  | 94 |  |
| Loss from operations | (76,307) |  |  | (35,225) |  |  | (41,082) |  |  | (117) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (489) |  |  | (5,952) |  |  | 5,463 |  |  | 92 |  |
| Interest income | 1,611 |  |  | — |  |  | 1,611 |  |  | * |
| Other expense, net | (57) |  |  | (669) |  |  | 612 |  |  | 91 |  |
| Loss on extinguishment of debt | — |  |  | (12,685) |  |  | 12,685 |  |  | * |
| Change in fair value of derivative liability | — |  |  | (1,745) |  |  | 1,745 |  |  | * |
| Change in fair value of contingent earn-out liability | 9,754 |  |  | 32,609 |  |  | (22,855) |  |  | (70) |  |
| Change in fair value of contingently issuable common stock liability | 2,529 |  |  | 5,718 |  |  | (3,189) |  |  | (56) |  |
| Change in fair value of public warrant liability | 4,297 |  |  | 3,152 |  |  | 1,145 |  |  | 36 |  |
| Change in fair value of common stock warrant liability | — |  |  | (879) |  |  | 879 |  |  | * |
| Total other income (expense), net | 17,645 |  |  | 19,549 |  |  | (1,904) |  |  | (10) |  |
| Net loss | $ | (58,662) |  |  | $ | (15,676) |  |  | $ | (42,986) |  |  | (274) | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (25) % |  | 28 % |  | N/A |  | (53) % |
| Subscription revenue | 52 % |  | 39 % |  | N/A |  | 13 % |
| Service revenue | 31 % |  | (11) % |  | N/A |  | 42 % |
| License fee and other revenue | (160) % |  | (20) % |  | N/A |  | (140) % |

[0001628280-25-020355:mdna:527]
*N/A – Not meaningful

[0001628280-25-020355:mdna:528]
94

[0001628280-25-020355:mdna:529]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:530]
We believe there are several key trends driving increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition of 189 new customers during the nine months ended September 30, 2022, (iii) the expansion of our customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-020355:mdna:531]
Product Revenue

[0001628280-25-020355:mdna:532]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which include the significant increase in the adoption of Evolv Express units by schools, healthcare facilities, hotels, casinos, and professional sports arenas.

[0001628280-25-020355:mdna:533]
The decrease in gross profit and gross profit margin during the nine months ended September 30, 2022 compared to the prior year period is attributable to several factors. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, and therefore a lower gross margin, during the nine months ended September 30, 2022 compared to the prior year period. Gross profit and gross profit margin were also adversely impacted by marketing and sponsorship arrangements with certain customers, increases in shipping costs, and the costs associated with the write-off of scrap inventory incurred without corresponding revenue.

[0001628280-25-020355:mdna:534]
Subscription Revenue

[0001628280-25-020355:mdna:535]
The increases in subscription revenue and cost of subscription revenue are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed in the preceding twelve months. The increase in gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin is primarily driven by increased recurring revenue from increased active subscriptions and customer growth.

[0001628280-25-020355:mdna:536]
Service Revenue

[0001628280-25-020355:mdna:537]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding twelve months and increased installation and training related to the Evolv Express units. The negative gross profit and gross profit margin in each period are due primarily to field services costs associated with the Evolv Express units.

[0001628280-25-020355:mdna:538]
95

[0001628280-25-020355:mdna:539]
License fee and other revenue

[0001628280-25-020355:mdna:540]
The change in license fee and other revenue, gross profit, and gross profit margin was a result of the change in installation, training and professional service revenue earned during the period compared to the prior period.

[0001628280-25-020355:mdna:541]
Research and Development Expenses

[0001628280-25-020355:mdna:542]
The increase in research and development expense was due to an increase in personnel related expenses of $5.6 million, which included an increase in payroll costs and stock-based compensation of $6.3 million resulting from new hires in our research and development function during the past twelve months, offset by $0.4 million increase in capitalized cost related to internal use software. Stock compensation expense included in research and development expenses was $2.9 million for the nine months ended September 30, 2022 compared to $0.4 million for the nine months ended September 30, 2021. Materials and prototype costs decreased by $1.1 million due to the transition from prototype production to standard manufacturing of the Evolv Express, which results in lower prototyping costs. Professional fees increased by $0.7 million primarily due to consulting costs incurred for product development and engineering.

[0001628280-25-020355:mdna:543]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:544]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $9.2 million, which included an increase in payroll costs, commissions and stock-based compensation of $10.8 million resulting from new hires in our sales and marketing functions during the past twelve months, which includes functions such as partner development, customer success, and other business development, offset primarily by a decrease of $1.0 million in overhead costs. Stock compensation expense included in sales and marketing expenses was $6.4 million for the nine months ended September 30, 2022 compared to $4.4 million for the nine months ended September 30, 2021. Advertising and direct marketing expense increased by $1.6 million due to an increase in trade shows and events, which have begun to return to pre-pandemic levels. Travel and entertainment expense increased by $1.5 million due to an increase in travel costs for in-person sales personnel meetings and events. Professional fees increased by $0.3 million due to consulting fees.  Other expenses increased by $2.8 million primarily due to $1.0 million of certain one-time retention benefits as well as an increase in shipping costs related to demo units of $1.2 million.

[0001628280-25-020355:mdna:545]
General and Administrative Expenses

[0001628280-25-020355:mdna:546]
The increase in general and administrative expense was due to an increase in personnel related expenses of $8.4 million, which included an increase in payroll costs and stock-based compensation of $8.2 million resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $5.7 million for the nine months ended September 30, 2022 compared to $1.2 million for the nine months ended September 30, 2021. Professional fees increased by $3.7 million due to an increase in accounting, audit, tax, and legal services provided to the Company to support public company requirements. Insurance costs increased by $2.3 million due primarily to director and officer insurance expense in relation to being a public company. The increase in non-income taxes of $0.4 million is due to a sales tax contingency liability as we may owe additional sales and use taxes in various jurisdictions. Other expenses increased by $3.0 million due primarily to $1.5 million of certain one-time retention benefits, and a $0.7 million increase in IT and software subscription costs, offset by $0.7 million of non-capitalizable transaction costs incurred during the nine months ended September 30, 2021 related to the Merger.

[0001628280-25-020355:mdna:547]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:548]
Impairment of property and equipment was $1.0 million and $1.7 million for the nine months ended September 30, 2022 and 2021 respectively. As we transition existing domestic customers to our current Express model, we are removing Edge units and Express prototype units from service, which results in the impairment of the remaining economic value of such units.

[0001628280-25-020355:mdna:549]
Interest Expense

[0001628280-25-020355:mdna:550]
Interest expense was $0.5 million for the nine months ended September 30, 2022, compared to $6.0 million for the nine months ended September 30, 2021. The decrease was primarily due to interest expense on the Convertible Notes during the nine months ended September 30, 2021. The Convertible Notes converted to the Company’s common stock upon closing of the Merger in July 2021.

[0001628280-25-020355:mdna:551]
96

[0001628280-25-020355:mdna:552]
Interest Income

[0001628280-25-020355:mdna:553]
Interest income of $1.6 million for the nine months ended September 30, 2022 related primarily to interest earned on money market funds. No interest income was earned for the nine months ended September 30, 2021.

[0001628280-25-020355:mdna:554]
Loss on Extinguishment of Debt

[0001628280-25-020355:mdna:555]
Loss on extinguishment of debt of $12.7 million for the nine months ended September 30, 2021 related to a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes.

[0001628280-25-020355:mdna:556]
Change in Fair Value of Derivative Liability

[0001628280-25-020355:mdna:557]
Change in the fair value of the derivative liability resulted in a loss of $1.7 million for the nine months ended September 30, 2021, resulting from an increase in the fair value of the Company's stock given the pending Merger. The derivative liability was derecognized in connection with the closing of the Merger.

[0001628280-25-020355:mdna:558]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:559]
Change in the fair value of the contingent earn-out liability resulted in gains of $9.8 million and $32.6 million for the nine months ended September 30, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:560]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:561]
Change in the fair value of the contingently issuable common stock liability resulted in gains of $2.5 million and $5.7 million for the nine months ended September 30, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:562]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:563]
Change in the fair value of the public warrant liability resulted in gains of $4.3 million and $3.2 million for the nine months ended September 30, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:564]
Change in Fair Value of Common Stock Warrant Liability

[0001628280-25-020355:mdna:565]
Change in the fair value of the common stock warrant liability resulted in a loss of $0.9 million for the nine months ended September 30, 2021, resulting from the conversion of the common stock warrant liability upon the closing of the Merger and mark-to-market adjustments prior to the closing of the Merger.

[0001628280-25-020355:mdna:566]
Income Taxes

[0001628280-25-020355:mdna:567]
There is no provision for income taxes for the three and nine months ended September 30, 2022 and 2021 because we have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets. We have provided a valuation allowance for all of our deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001628280-25-020355:mdna:568]
97

[0001628280-25-020355:mdna:569]
Comparison of the Three Months Ended June 30, 2022 and 2021

[0001628280-25-020355:mdna:570]
The following table summarizes our results of operations for the three months ended June 30, 2022 and 2021, (in thousands):

[0001628280-25-020355:mdna:571]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
|  | (Restated) |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 4,164 |  |  | $ | 2,617 |  |  | $ | 1,547 |  |  | 59 | % |
| Subscription revenue | 3,772 |  |  | 1,521 |  |  | 2,251 |  |  | 148 |  |
| Service revenue | 782 |  |  | 230 |  |  | 552 |  |  | 240 |  |
| License fee and other revenue | 203 |  |  | 310 |  |  | (107) |  |  | (35) |  |
| Total revenue | 8,921 |  |  | 4,678 |  |  | 4,243 |  |  | 91 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 5,347 |  |  | 2,203 |  |  | 3,144 |  |  | 143 |  |
| Cost of subscription revenue | 2,007 |  |  | 1,060 |  |  | 947 |  |  | 89 |  |
| Cost of service revenue | 467 |  |  | 413 |  |  | 54 |  |  | 13 |  |
| Cost of license fee and other revenue | 722 |  |  | 274 |  |  | 448 |  |  | 164 |
| Total cost of revenue | 8,543 |  |  | 3,950 |  |  | 4,593 |  |  | 116 |  |
| Gross profit | 378 |  |  | 728 |  |  | (350) |  |  | (48) |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 4,374 |  |  | 1,047 |  |  | 3,327 |  |  | 318 |  |
| Sales and marketing | 11,605 |  |  | 5,124 |  |  | 6,481 |  |  | 126 |  |
| General and administrative | 9,574 |  |  | 1,471 |  |  | 8,103 |  |  | 551 |  |
| Loss from impairment of property and equipment | 753 |  |  | — |  |  | 753 |  |  | * |
| Total operating expenses | 26,306 |  |  | 7,642 |  |  | 18,664 |  |  | 244 |  |
| Loss from operations | (25,928) |  |  | (6,914) |  |  | (19,014) |  |  | (275) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (159) |  |  | (3,263) |  |  | 3,104 |  |  | 95 |  |
| Interest income | 491 |  |  | — |  |  | 491 |  |  | * |
| Loss on extinguishment of debt | — |  |  | (11,820) |  |  | 11,820 |  |  | * |
| Change in fair value of derivative liability | — |  |  | (795) |  |  | 795 |  |  | * |
| Change in fair value of contingent earn-out liability | (569) |  |  | — |  |  | (569) |  |  | * |
| Change in fair value of contingently issuable common stock liability | (24) |  |  | — |  |  | (24) |  |  | * |
| Change in fair value of public warrant liability | (143) |  |  | — |  |  | (143) |  |  | * |
| Change in fair value of common stock warrant liability | — |  |  | (185) |  |  | 185 |  |  | * |
| Total other income (expense), net | (404) |  |  | (16,063) |  |  | 15,659 |  |  | 97 |  |
| Net loss | $ | (26,332) |  |  | $ | (22,977) |  |  | $ | (3,355) |  |  | (15) | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (28) % |  | 16 % |  | N/A |  | (44) % |
| Subscription revenue | 47 % |  | 30 % |  | N/A |  | 16 % |
| Service revenue | 40 % |  | (80) % |  | N/A |  | 120 % |
| License fee and other revenue | (256) % |  | 12 % |  | N/A |  | (267) % |

[0001628280-25-020355:mdna:572]
*N/A – Not meaningful

[0001628280-25-020355:mdna:573]
98

[0001628280-25-020355:mdna:574]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:575]
Product Revenue

[0001628280-25-020355:mdna:576]
The increases in product revenue and cost of product revenue are primarily due to the increase in sales of Evolv Express units, which include the significant increase in the adoption of Evolv Express units by schools, hotels and casinos, and professional sports arenas. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, during the three months ended June 30, 2022 compared to the prior year period. Gross profit and gross profit margin were also adversely impacted by purchase price variances recorded on raw materials and the costs associated with the write-off of scrap inventory incurred without corresponding revenue.

[0001628280-25-020355:mdna:577]
Subscription Revenue

[0001628280-25-020355:mdna:578]
The increases in subscription revenue and cost of subscription revenue are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed in the preceding twelve months. The increase in gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin was primarily driven by increased recurring revenue from increased active subscriptions and customer growth.

[0001628280-25-020355:mdna:579]
Service Revenue

[0001628280-25-020355:mdna:580]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding twelve months and increased installation and training related to the Evolv Express units. The negative

[0001628280-25-020355:mdna:581]
99

[0001628280-25-020355:mdna:582]
gross profit and gross profit margin in each period are due primarily to field services costs associated with the Evolv Express units.

[0001628280-25-020355:mdna:583]
License fee and other revenue

[0001628280-25-020355:mdna:584]
The change in license fee and other revenue, gross profit, and gross profit margin was a result of the change in installation, training and professional service revenue earned during the period compared to the prior period.

[0001628280-25-020355:mdna:585]
Research and Development Expenses

[0001628280-25-020355:mdna:586]
The increase in research and development expense was due to an increase in personnel related expenses of $2.4 million, which included an increase in payroll costs and stock-based compensation of $2.6 million resulting from new hires in our research and development function during the second half of 2021 and the first half of 2022, offset by $0.1 million increase in capitalized cost related to internal use software. Stock compensation expense included in research and development expenses was $1.1 million for the three months ended June 30, 2022 compared to less than $0.1 million for the three months ended June 30, 2021. The $0.7 million decrease in income recognized during the three months ended June 30, 2021, which did was not earned during the three months ended June 30, 2022, related to materials and prototypes is due to capitalization of prototypes during the period which had been expensed in prior periods.

[0001628280-25-020355:mdna:587]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:588]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $3.9 million, which included an increase in payroll costs, commissions and stock-based compensation of $4.5 million resulting from new hires in our sales and marketing functions, which includes functions such as partner development, customer success, and other business development, during the second half of 2021 and the first six months of 2022, offset by a decrease of $0.4 million in overhead costs. Stock compensation expense included in sales and marketing expenses was $2.2 million for the three months ended June 30, 2022 compared to $0.9 million for the three months ended June 30, 2021. Advertising and direct marketing increased by $0.3 million due to an increase in trade shows and events, which have begun to return to pre-pandemic levels, and an increase in sales volume. Travel and entertainment expense increased by $0.5 million due to an increase in travel costs for in-person sales personnel meetings and events. Facilities related and other expenses increased by $1.6 million primarily due to $1.0 million of certain one-time retention benefits as well as an increase in shipping costs related to demo units of $0.5 million.

[0001628280-25-020355:mdna:589]
General and Administrative Expenses

[0001628280-25-020355:mdna:590]
The increase in general and administrative expense was due to an increase in personnel related expenses of $3.2 million, which included an increase in payroll costs and stock-based compensation of $3.0 million resulting from expanding our administrative team. Stock compensation expense included in general and administrative expenses was $1.5 million for the three months ended June 30, 2022 compared to $0.1 million for the three months ended June 30, 2021. Professional fees increased by $2.3 million due to an increase in accounting, audit, tax, and legal services provided to the Company to support public company requirements. Insurance costs increased by $1.3 million due primarily to director and officer insurance expense in relation to the Merger. Facilities related and other expenses increased by $1.3 million due primarily to $1.0 million of certain one-time retention benefits, as well as increases in software subscriptions and rent expense of $0.2 million and $0.2 million respectively.

[0001628280-25-020355:mdna:591]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:592]
Impairment of property and equipment was $0.8 million for the three months ended June 30, 2022. This related to Edge units and Express prototype units that were removed from service and retired. We have been and are continuing to transition our domestic customers from the Edge units to our most current Express units, which has resulted in an impairment of the remaining economic value of such assets. There was no impairment for the three months ended June 30, 2021.

[0001628280-25-020355:mdna:593]
Interest Expense

[0001628280-25-020355:mdna:594]
Interest expense was $0.2 million for the three months ended June 30, 2022, compared to $3.3 million for the three months ended June 30, 2021. The decrease was primarily due to interest expense on the Convertible Notes during the three months ended June 30, 2021. The Convertible Notes converted to the Company’s stock upon closing of the Merger in July 2021.

[0001628280-25-020355:mdna:595]
100

[0001628280-25-020355:mdna:596]
Interest Income

[0001628280-25-020355:mdna:597]
Interest income of $0.5 million for the three months ended June 30, 2022 related primarily to interest earned on money market funds. No interest income was earned for the three months ended June 30, 2021.

[0001628280-25-020355:mdna:598]
Loss on Extinguishment of Debt

[0001628280-25-020355:mdna:599]
Loss on extinguishment of debt of $11.8 million for the three months ended June 30, 2021 related to a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes.

[0001628280-25-020355:mdna:600]
Change in Fair Value of Derivative Liability

[0001628280-25-020355:mdna:601]
Change in the fair value of the derivative liability resulted in a $0.8 million loss for the three months ended June 30, 2021, resulting from an increase in the fair value of the Company's stock given the pending Merger. The derivative liability was derecognized in connection with the closing of the Merger.

[0001628280-25-020355:mdna:602]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:603]
Change in the fair value of the contingent earn-out liability resulted in a $0.6 million loss for the three months ended June 30, 2022, resulting from a quarterly mark-to-market adjustment. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:604]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:605]
Change in the fair value of the contingently issuable common stock liability resulted in less than $0.1 million loss for the three months ended June 30, 2022, resulting from a quarterly mark-to-market adjustment. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:606]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:607]
Change in the fair value of the public warrant liability resulted in a $0.1 million loss for the three months ended June 30, 2022, resulting from a quarterly mark-to-market adjustment. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:608]
Change in Fair Value of Common Stock Warrant Liability

[0001628280-25-020355:mdna:609]
Change in the fair value of the common stock warrant liability resulted in a $0.2 million loss for the three months ended June 30, 2021, resulting from a quarterly mark-to-market adjustment. The common stock warrant liability was derecognized in connection with the closing of the Merger.

[0001628280-25-020355:mdna:610]
Comparison of the Six Months ended June 30, 2022 and 2021

[0001628280-25-020355:mdna:611]
The following table summarizes our results of operations for the six months ended June 30, 2022 and 2021, (in thousands):

[0001628280-25-020355:mdna:612]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
|  | (Restated) |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 9,358 |  |  | $ | 4,884 |  |  | $ | 4,474 |  |  | 92 | % |
| Subscription revenue | 6,776 |  |  | 2,748 |  |  | 4,028 |  |  | 147 |  |
| Service revenue | 1,108 |  |  | 362 |  |  | 746 |  |  | 206 |  |
| License fee and other revenue | 389 |  |  | 377 |  |  | 12 |  |  | 3 |  |
| Total revenue | 17,631 |  |  | 8,371 |  |  | 9,260 |  |  | 111 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 10,553 |  |  | 4,419 |  |  | 6,134 |  |  | 139 |  |
| Cost of subscription revenue | 3,549 |  |  | 1,803 |  |  | 1,746 |  |  | 97 |  |
| Cost of service revenue | 1,152 |  |  | 540 |  |  | 612 |  |  | 113 |  |
| Cost of license fee and other revenue | 1,102 |  |  | 432 |  |  | 670 |  |  | 155 |
| Total cost of revenue | 16,356 |  |  | 7,194 |  |  | 9,162 |  |  | 127 |  |
| Gross profit | 1,275 |  |  | 1,177 |  |  | 98 |  |  | 8 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 8,549 |  |  | 4,787 |  |  | 3,762 |  |  | 79 |  |
| Sales and marketing | 21,277 |  |  | 7,732 |  |  | 13,545 |  |  | 175 |  |
| General and administrative | 20,391 |  |  | 4,523 |  |  | 15,868 |  |  | 351 |  |
| Loss from impairment of property and equipment | 849 |  |  | — |  |  | 849 |  |  | * |
| Total operating expenses | 51,066 |  |  | 17,042 |  |  | 34,024 |  |  | 200 |  |
| Loss from operations | (49,791) |  |  | (15,865) |  |  | (33,926) |  |  | (214) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (301) |  |  | (5,657) |  |  | 5,356 |  |  | 95 |  |
| Interest income | 559 |  |  | — |  |  | 559 |  |  | * |
| Other expense, net | — |  |  | — |  |  | — |  |  | * |
| Loss on extinguishment of debt | — |  |  | (11,820) |  |  | 11,820 |  |  | * |
| Change in fair value of derivative liability |  |  | (2,220) |  |  | 2,220 |  |  | * |
| Change in fair value of contingent earn-out liability | 2,509 |  |  | — |  |  | 2,509 |  |  | * |
| Change in fair value of contingently issuable common stock liability | 1,448 |  |  | — |  |  | 1,448 |  |  | * |
| Change in fair value of public warrant liability | 5,443 |  |  | — |  |  | 5,443 |  |  | * |
| Change in fair value of common stock warrant liability |  |  | (921) |  |  | 921 |  |  | * |
| Total other income (expense), net | 9,658 |  |  | (20,618) |  |  | 30,276 |  |  | 147 |  |
| Net loss | $ | (40,133) |  |  | $ | (36,483) |  |  | $ | (3,650) |  |  | (10) | % |
| Gross profit margin: |  |  |  |  |  |  |  |
| Product revenue | (13) % |  | 10 % |  | N/A |  | (22) % |
| Subscription revenue | 48 % |  | 34 % |  | N/A |  | 13 % |
| Service revenue | (4) % |  | (49) % |  | N/A |  | 45 % |
| License fee and other revenue | (183) % |  | (15) % |  | N/A |  | (169) % |

[0001628280-25-020355:mdna:613]
*N/A – Not meaningful

[0001628280-25-020355:mdna:614]
102

[0001628280-25-020355:mdna:615]
Revenue, Cost of Revenue and Gross Profit

[0001628280-25-020355:mdna:616]
Product Revenue

[0001628280-25-020355:mdna:617]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which included the significant increase in the adoption of Evolv Express units by schools, hotels and casinos, and professional sports arenas. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, during the six months ended June 30, 2022 compared to the prior year period. Gross profit and gross profit margin were also adversely impacted by purchase price variances recorded on raw materials and the costs associated with the write-off of scrap inventory incurred without corresponding revenue.

[0001628280-25-020355:mdna:618]
Subscription Revenue

[0001628280-25-020355:mdna:619]
The increases in subscription revenue and cost of subscription revenue are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed in the preceding twelve months. The increase in gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin was primarily driven by increased recurring revenue from increased active subscriptions and customer growth.

[0001628280-25-020355:mdna:620]
Service Revenue

[0001628280-25-020355:mdna:621]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding twelve months and increased installation and training related to the Evolv Express units. The negative

[0001628280-25-020355:mdna:622]
103

[0001628280-25-020355:mdna:623]
gross profit and gross profit margin in each period are due primarily to field services costs associated with the Evolv Express units.

[0001628280-25-020355:mdna:624]
License fee and other revenue

[0001628280-25-020355:mdna:625]
The increase in license fee and other revenue, gross profit, and gross profit margin was a result of increases in installation, training and professional service revenue earned during the period.

[0001628280-25-020355:mdna:626]
Research and Development Expenses

[0001628280-25-020355:mdna:627]
The increase in research and development expense was due to an increase in personnel related expenses of $4.7 million, which included an increase in payroll costs and stock-based compensation of $4.9 million resulting from new hires in our research and development function during the second half of 2021 and the first half of 2022, offset by $0.2 million increase in capitalized cost related to internal use software. Stock compensation expense included in research and development expenses was $1.7 million for the six months ended June 30, 2022 compared to $0.1 million for the six months ended June 30, 2021. Materials and prototype costs decreased by $1.2 million due to the transition from prototype production to standard manufacturing of the Evolv Express, which results in lower prototyping costs.  Professional fees increased by $0.2 million due to an increase in consulting fees for the period.

[0001628280-25-020355:mdna:628]
Sales and Marketing Expenses

[0001628280-25-020355:mdna:629]
The increase in sales and marketing expense was due to an increase in personnel related expenses of $8.3 million, which included an increase in payroll costs, commissions and stock-based compensation of $9.3 million resulting from new hires in our sales and marketing functions, which includes functions such as partner development, customer success, and other business development, during the second half of 2021 and the first six months in 2022, offset by a $0.1 million decrease in recruiting costs and by a decrease of $1.0 million in overhead costs. Stock compensation expense included in sales and marketing expenses was $3.7 million for the six months ended June 30, 2022 compared to $1.1 million for the six months ended June 30, 2021. Advertising and direct marketing expense increased by $1.7 million due to an increase in trade shows and events, which have begun to return to pre-pandemic levels, and an increase in sales volume. Travel and entertainment expense increased by $1.0 million due to an increase in travel costs for in-person sales personnel meetings and events. Facilities related and other expenses increased by $2.3 million primarily due to $1.0 million of certain one-time retention benefits as well as an increase in shipping costs related to demo units of $0.7 million.

[0001628280-25-020355:mdna:630]
General and Administrative Expenses

[0001628280-25-020355:mdna:631]
The increase in general and administrative expense was due to an increase in personnel related expenses of $6.9 million, which included an increase in payroll costs and stock-based compensation of $6.1 million resulting from expanding our administrative team. Stock compensation expense included in general and administrative expenses was $3.3 million for the six months ended June 30, 2022 compared to $0.2 million for the six months ended June 30, 2021. Professional fees increased by $3.7 million  due to an increase in accounting, audit, tax, and legal services provided to the Company to support public company requirements. Insurance costs increased by $2.4 million due primarily to director and officer insurance expense in relation to the Merger. The increase in non-income taxes is due to a sales tax contingency liability as we may owe additional sales and use taxes in various jurisdictions. Facilities related and other expenses increased by $2.9 million due primarily to $1.5 million of certain one-time retention benefits, and increases in software subscription fees of $0.4 million, and state and local income taxes of $0.6 million.

[0001628280-25-020355:mdna:632]
Loss From Impairment of Property and Equipment

[0001628280-25-020355:mdna:633]
Impairment of property and equipment was $0.8 million for the six months ended June 30, 2022. This related to Edge units and Express prototype units that were removed from service and retired. We have been and are continuing to transition our domestic customers from the Edge units to our most current Express units, which also resulted in an impairment of the remaining economic value of such assets. There was no impairment for the six months ended June 30, 2021.

[0001628280-25-020355:mdna:634]
Interest Expense

[0001628280-25-020355:mdna:635]
Interest expense was $0.3 million for the six months ended June 30, 2022, compared to $5.7 million for the six months ended June 30, 2021. The decrease was primarily due to interest expense on the Convertible Notes during the six months ended June 30, 2021. The Convertible Notes converted to the Company’s common stock upon closing of the Merger in July 2021.

[0001628280-25-020355:mdna:636]
104

[0001628280-25-020355:mdna:637]
Interest Income

[0001628280-25-020355:mdna:638]
Interest income of $0.6 million for the six months ended June 30, 2022 related primarily to interest earned on money market funds. No interest income was earned for the six months ended June 30, 2021.

[0001628280-25-020355:mdna:639]
Loss on Extinguishment of Debt

[0001628280-25-020355:mdna:640]
Loss on extinguishment of debt of $11.8 million for the six months ended June 30, 2021 related to a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes.

[0001628280-25-020355:mdna:641]
Change in Fair Value of Derivative Liability

[0001628280-25-020355:mdna:642]
Change in the fair value of the derivative liability resulted in a $2.2 million loss for the six months ended June 30, 2021, resulting from an increase in the fair value of the Company's stock given the pending Merger. The derivative liability was derecognized in connection with the closing of the Merger.

[0001628280-25-020355:mdna:643]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-25-020355:mdna:644]
Change in the fair value of the contingent earn-out liability resulted in a $2.5 million gain for the six months ended June 30, 2022, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:645]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:646]
Change in the fair value of the contingently issuable common stock liability resulted in a $1.4 million gain for the six months ended June 30, 2022, resulting from quarterly market-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:647]
Change in Fair Value of Public Warrant Liability

[0001628280-25-020355:mdna:648]
Change in the fair value of the public warrant liability resulted in a $5.4 million gain for the six months ended June 30, 2022, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-020355:mdna:649]
Change in Fair Value of Common Stock Warrant Liability

[0001628280-25-020355:mdna:650]
Change in the fair value of the common stock warrant liability resulted in a $0.9 million loss for the six months ended June 30, 2021, resulting from quarterly mark-to-market adjustments. The common stock warrant liability was derecognized in connection with the closing of the Merger.

[0001628280-25-020355:mdna:651]
Income Taxes

[0001628280-25-020355:mdna:652]
There is no provision for income taxes for the three and six months ended June 30, 2022 and 2021 because we have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets. We have provided a valuation allowance for all of our deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001628280-25-020355:mdna:653]
Comparison of the Three Months ended March 31, 2022 and 2021

[0001628280-25-020355:mdna:654]
We have not provided a comparison of the three Months ended March 31, 2022 and 2021 as we did not restate any previously reported financial information for these quarterly periods. Our results of operations for the three months ended March 31, 2022, including a discussion of the three months ended March 31, 2022 compared to the three months ended March 31, 2021, have been reported previously in our Quarterly Report on Form 10-Q for the three months ended March

[0001628280-25-020355:mdna:655]
105

[0001628280-25-020355:mdna:656]
31, 2022, filed with the SEC on May 13, 2022, under the heading “Management’s Discussion and Analysis of Financial Condition and Results of Operations.”

[0001628280-25-020355:mdna:657]
Liquidity and Capital Resources

[0001628280-25-020355:mdna:658]
Our financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. As of December 31, 2024, we had $51.9 million in cash, cash equivalents, and marketable securities, and as of March 31, 2025, we had $35.0 million in cash, cash equivalents, and marketable securities. We incurred a net loss of $54.0 million and $108.0 million for the years ended December 31, 2024 and 2023, respectively. We incurred cash outflows from operating activities of $30.9 million and $9.8 million during the years ended December 31, 2024 and 2023, respectively. We expect to continue to generate losses for the foreseeable future.

[0001628280-25-020355:mdna:659]
We maintain substantially all of our cash, cash equivalents, and marketable securities in accounts with U.S. and multi-national financial institutions and our cash deposits at these institutions exceed Federal Deposit Insurance Corporation insured limits. We do not believe we are exposed to any unusual credit risk or deposit concentration risk beyond the ordinary credit risk associated with commercial banking relationships.

[0001628280-25-020355:mdna:660]
We expect our cash, cash equivalents, and marketable securities of $51.9 million as of December 31, 2024, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months and thereafter from the date of this Annual Report on Form 10-K. As we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to strategically and carefully invest in various areas of the business to support that growth. We may require additional capital to respond to expected growth in the demand for equipment to support our “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances. To the extent that our projected revenue growth does not materialize, we have established plans to preserve existing cash liquidity, which includes additional reductions operating expenses and capital expenditures.

[0001628280-25-020355:mdna:661]
Although not required to fund ongoing operations, in an improving interest rate environment, we may choose to engage in debt financings or enter into credit facilities for other strategic reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, tariffs, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected. See “Risk Factors – Our operating results may fluctuate for a variety of reasons, including our failure to close large volume opportunity customer sales.”

[0001628280-25-020355:mdna:662]
Additionally, there continues to be significant uncertainty regarding recent changes and potential future developments related to increased trade restrictions, tariffs or taxes on imports or exports relating to countries where we source or sell materials or products. The exact magnitude of any potential impact remains uncertain, as there may be further changes to tariffs and policies and, consequently, potential increased tension between the U.S. and targeted countries, and the Company's financial condition and results of operations could be adversely affected.

[0001628280-25-020355:mdna:663]
Financing Arrangements

[0001628280-25-020355:mdna:664]
During March 2023, we fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. We have no debt outstanding as of December 31, 2024.

[0001628280-25-020355:mdna:665]
Material Cash Requirements for Known Contractual and Other Obligations

[0001628280-25-020355:mdna:666]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of December 31, 2024. We anticipate fulfilling such commitments with our existing cash, cash equivalents, and marketable securities, as well as cash and cash equivalents obtained through operations and, if necessary,

[0001628280-25-020355:mdna:667]
proceeds from long-term debt. Cash, cash equivalents, and marketable securities amounted to $51.9 million as of December 31, 2024.

[0001628280-25-020355:mdna:668]
We are party to a lease agreement for office space at our headquarters in Waltham, MA. During the three months ended March 31, 2024, we amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. Additionally, during the three months ended September 30, 2024, we amended the lease agreement again to expand our footprint in our headquarters and extend the term of the lease through May 2031. Per the second lease amendment, we are no longer required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space. As of December 31, 2024, the process of cancelling the letter of credit underlying the minimum cash balance requirement was completed. This amount was previously classified as restricted cash, non-current as of December 31, 2023. Total future minimum lease payments under this noncancelable operating lease amount to $19.6 million as of December 31, 2024.

[0001628280-25-020355:mdna:669]
Cash Flows

[0001628280-25-020355:mdna:670]
The following table sets forth a summary of cash flows for the periods presented:

[0001628280-25-020355:mdna:671]
|  | Year EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (Restated) |  | (Restated) |
| Net cash used in operating activities | $ | (30,853) |  |  | $ | (9,801) |  |  | $ | (74,740) |  |
| Net cash used in investing activities | (1,399) |  |  | (123,113) |  |  | (23,869) |  |
| Net cash provided by (used in) financing activities | 1,809 |  |  | (29,664) |  |  | 20,510 |  |
| Effect of exchange rate changes on cash and cash equivalents | 21 |  |  | (43) |  |  | (10) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (30,422) |  |  | $ | (162,621) |  |  | $ | (78,109) |  |

[0001628280-25-020355:mdna:672]
Operating Activities

[0001628280-25-020355:mdna:673]
|  | Year EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (Restated) |  | (Restated) |
| Net loss | $ | (54,017) |  |  | $ | (108,048) |  |  | $ | (86,795) |  |
| Non-cash expense | 22,504 |  |  | 59,199 |  |  | 17,331 |  |
| Changes in operating assets and liabilities | 660 |  |  | 39,048 |  |  | (5,276) |  |
| Net cash used in operating activities | $ | (30,853) |  |  | $ | (9,801) |  |  | $ | (74,740) |  |

[0001628280-25-020355:mdna:674]
Net loss decreased from $108.0 million for the year ended December 31, 2023 to $54.0 million for the year ended December 31, 2024 primarily due to changes in the fair value of the contingent earn-out liability, contingently issuable common stock liability, and public warrant liability. Net loss increased from $86.8 million for the year ended December 31, 2022 to $108.0 million for the year ended December 31, 2023. See "Results of Operations" above for further discussion.

[0001628280-25-020355:mdna:675]
Non-cash expense for the year ended December 31, 2024 is primarily attributable to $24.8 million of stock-based compensation expense and $17.4 million of depreciation and amortization, offset by $25.4 million of an aggregate change in fair value of the contingent earn-out liability, contingently issuable common stock liability, and public warrant liability. Non-cash expense for the year ended December 31, 2023 is primarily attributable to $24.1 million of stock-based compensation expense, $9.7 million of depreciation and amortization, and $22.8 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability. Non-cash expenses for the year ended December 31, 2022 were primarily attributable to $22.5 million of stock-based compensation expense, $5.4 million of depreciation and amortization, $1.6 million of write-off of inventory, and $1.2 million of loss from impairment of property and equipment, offset by $13.8 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability.

[0001628280-25-020355:mdna:676]
107

[0001628280-25-020355:mdna:677]
Changes in operating assets and liabilities for the year ended December 31, 2024 are primarily related to the following:

[0001628280-25-020355:mdna:678]
•$7.0 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001628280-25-020355:mdna:679]
•$7.9 million increase in inventory primarily due to raw material purchase increase for the next generation of Evolv Express systems and Evolv eXpedite, partially offset by inventory decrease of first generation of Evolv Express systems for the ongoing transition to the next generation of Evolv Express systems;

[0001628280-25-020355:mdna:680]
•$1.1 million decrease in operating lease liability due to amortization;

[0001628280-25-020355:mdna:681]
•$1.4 million increase in commission assets due to a higher volume of sales; partially offset by

[0001628280-25-020355:mdna:682]
•$12.8 million increase in deferred revenue due to a higher volume of sales; and

[0001628280-25-020355:mdna:683]
•$4.5 million increase in accrued expenses due to the timing of certain payments.

[0001628280-25-020355:mdna:684]
Changes in operating assets and liabilities for the year ended December 31, 2023 are primarily related to the following:

[0001628280-25-020355:mdna:685]
•$39.5 million increase in deferred revenue to a higher volume of sales;

[0001628280-25-020355:mdna:686]
•$4.5 million decrease in accounts receivable primarily due to the Company's transition away from the purchase subscription model during the preceding twelve months, under which upfront billings to customers are generally higher; and

[0001628280-25-020355:mdna:687]
•$3.9 million increase in accrued expenses and other current liabilities, related to accrued consulting and professional fees and an accrual for purchase order cancellation fees, offset by

[0001628280-25-020355:mdna:688]
•$6.0 million decrease in accounts payable (excluding the non-cash portion related to capital expenditures incurred but not yet paid from December 31, 2022 to December 31, 2023) due primarily to the timing of vendor payments;

[0001628280-25-020355:mdna:689]
•$2.4 million increase in prepaid expense and other current assets due to an increase in vendor deposits; and

[0001628280-25-020355:mdna:690]
•$2.8 million increase in commission assets due to a higher volume of sales.

[0001628280-25-020355:mdna:691]
Changes in operating assets and liabilities for the year ended December 31, 2022 are primarily related to the following:

[0001628280-25-020355:mdna:692]
•$23.4 million increase in deferred revenue due to a higher volume of sales;

[0001628280-25-020355:mdna:693]
•$7.7 million increase in accounts payable primarily due to amounts payable to the Company's contract manufacturer; offset by

[0001628280-25-020355:mdna:694]
•$20.1 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001628280-25-020355:mdna:695]
•$10.6 million increase in inventory primarily due to increased production of units to meet customer demand;

[0001628280-25-020355:mdna:696]
•$3.5 million increase in commission assets due to a higher volume of sales; and

[0001628280-25-020355:mdna:697]
•$3.3 million increase in prepaid expenses and other current assets primarily due to deposits paid to the Company's contract manufacturer.

[0001628280-25-020355:mdna:698]
Investing Activities

[0001628280-25-020355:mdna:699]
During the year ended December 31, 2024, cash provided by investing activities was $1.4 million, consisting of $31.2 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers and $6.1 million for the development of internal-use software and software embedded in products to be sold or leased, offset by a net $35.9 million inflow related to purchases and redemptions of marketable securities.

[0001628280-25-020355:mdna:700]
During the year ended December 31, 2023, cash used in investing activities was $123.1 million, consisting primarily of $69.1 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers, $3.5 million for the development of internal-use software and software embedded in products to be sold or leased, and a net $50.7 million outflow related to purchases and redemptions of marketable securities.

[0001628280-25-020355:mdna:701]
During the year ended December 31, 2022, cash used in investing activities was $23.9 million, consisting of $21.5 million for the purchase of property and equipment, primarily related to the purchase of Express units to be leased to

[0001628280-25-020355:mdna:702]
customers, and $2.7 million for the development of internal-use software, offset by $0.3 million of proceeds from the sale of property and equipment.

[0001628280-25-020355:mdna:703]
Financing Activities

[0001628280-25-020355:mdna:704]
During the year ended December 31, 2024, cash provided by financing activities was $1.8 million, consisting of $1.8 million of proceeds from the exercise of stock options.

[0001628280-25-020355:mdna:705]
During the year ended December 31, 2023, cash used in financing activities was $29.7 million, consisting primarily of $1.9 million of proceeds under the 2022 SVB Credit Agreement and $0.7 million of proceeds from the exercise of stock options, offset by $31.9 million related to the full repayment of amounts owed under the 2022 SVB Credit Agreement and $0.3 million payment of debt issuance costs and a prepayment penalty.

[0001628280-25-020355:mdna:706]
During the year ended December 31, 2022, cash provided by financing activities was $20.5 million, consisting of $29.7 million of proceeds from long-term debt, net of issuance costs, and $0.8 million of proceeds from the exercise of stock options, offset by $10.0 million of debt repayments.

[0001628280-25-020355:mdna:707]
Critical Accounting Estimates

[0001628280-25-020355:mdna:708]
Our consolidated financial statements are prepared in accordance with generally accepted accounting principles in the United States. The preparation of our consolidated financial statements and related disclosures requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, costs and expenses, and the disclosure of contingent assets and liabilities in our consolidated financial statements. We base our estimates on historical experience, known trends and events and various other factors that we believe are reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. We evaluate our estimates and assumptions on an ongoing basis. Our actual results may differ from these estimates under different assumptions or conditions.

[0001628280-25-020355:mdna:709]
While our significant accounting policies are described in more detail in Note 3 to our consolidated financial statements, we believe that the following accounting estimates are those most critical to the judgments and estimates used in the preparation of our consolidated financial statements.

[0001628280-25-020355:mdna:710]
Marketable Securities

[0001628280-25-020355:mdna:711]
Marketable securities are reported at fair value and, at December 31, 2024, are comprised solely of zero coupon U.S. treasury bills with maturities of less than one year that are classified as available-for-sale debt securities. The Company considers an available-for-sale debt security to be impaired if the fair value of the investment is less than its amortized cost basis. The entire difference between the amortized cost basis and the fair value of the Company’s available-for-sale debt securities is recognized on the consolidated statements of operations as an impairment if, (i) the fair value of the security is below its amortized cost and (ii) the Company intends to sell or is more likely than not required to sell the security before recovery of its amortized cost basis. If neither criterion is met, the Company evaluates whether the decline in fair value is due to credit losses or other factors. In making this assessment, the Company considers the changes to the rating of the security by third-party rating agencies, and adverse conditions specific to the security, among other factors. If the Company’s assessment indicates that a credit loss exists, the credit loss is measured based on the Company’s best estimate of the cash flows expected to be collected. When developing its estimate of cash flows expected to be collected, the Company considers all available information relevant to the collectability of the security, including past events, current conditions, and reasonable and supportable forecasts.

[0001628280-25-020355:mdna:712]
Revenue Recognition

[0001628280-25-020355:mdna:713]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement, (4) license fees under the Distribution and License Agreement, and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after control passes to the customer. Revenue is recognized net of sales tax.

[0001628280-25-020355:mdna:714]
Product Revenue

[0001628280-25-020355:mdna:715]
We derive a portion of our revenue from the sale of our Evolv Express equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract.

[0001628280-25-020355:mdna:716]
Subscription Revenue

[0001628280-25-020355:mdna:717]
Subscription revenue is comprised of revenue derived from leasing Evolv Express and Evolv Edge units to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001628280-25-020355:mdna:718]
Lease arrangements generally include both lease and non-lease components. The non-lease components relate to (1) distinct services, including professional services, SaaS, and maintenance, and (2) any add-on accessories. Professional services are included in license fees and other revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive loss.

[0001628280-25-020355:mdna:719]
Service Revenue

[0001628280-25-020355:mdna:720]
Service revenue consists of subscription-based SaaS and maintenance revenue related to products sold to a customer. Customers generally pay either a quarterly or annual fixed payment for SaaS and maintenance. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically four years.

[0001628280-25-020355:mdna:721]
License Fee and Other Revenue

[0001628280-25-020355:mdna:722]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from our third-party manufacturer to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration.

[0001628280-25-020355:mdna:723]
Revenue from Reseller Partners

[0001628280-25-020355:mdna:724]
A portion of our revenue is generated by sales in conjunction with our reseller partners. When we transact with a reseller partner, our contractual arrangement is with the reseller partner and not with the end-use customer. Whether we transact with a reseller partner and receive the order from a reseller partner or directly from an end-use customer, our revenue recognition policy and resulting pattern of revenue recognition is the same.

[0001628280-25-020355:mdna:725]
Standalone Selling Price

[0001628280-25-020355:mdna:726]
We allocate the transaction price to each distinct performance obligation based on the standalone selling price (“SSP”) of each product or service. Our contracts may include multiple performance obligations when customers purchase a combination of products and services. When our customer arrangements have multiple performance obligations that contain a lease as well as distinct services that are delivered simultaneously, we allocate the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, we allocate the contract’s transaction price to each performance obligation on a relative SSP basis.

[0001628280-25-020355:mdna:727]
Stock-Based Compensation

[0001628280-25-020355:mdna:728]
We measure stock-based option awards granted to employees, consultants and directors based on their fair value on the date of grant using the Black-Scholes option-pricing model. Compensation expense for those awards is recognized, net of estimated forfeitures, over the requisite service period, which is generally the vesting period of the respective award.

[0001628280-25-020355:mdna:729]
Prior to the closing of the Merger, the fair value of each stock option grant was estimated on the date of grant using the Black-Scholes option-pricing model, which uses the following inputs: (1) the fair value per share of the common

[0001628280-25-020355:mdna:730]
stock issuable upon exercise of the option, (2) the expected term of the option, (3) expected volatility of the price of the common stock, (4) the risk-free interest rate, and (5) the expected dividend yield.

[0001628280-25-020355:mdna:731]
After the closing of the Merger, we determine the fair value of each share of common stock underlying stock-based awards based on the closing price of our common stock as reported by Nasdaq on the date of grant.

[0001628280-25-020355:mdna:732]
The Black-Scholes option-pricing model uses as inputs the fair value of our common shares and assumptions we make for the volatility of our common shares, the expected term of our stock options, the risk-free interest rate for a period that approximates the expected term of our stock options, and our expected dividend yield. As a result of being a private company prior to the Merger, the Company lacked sufficient company-specific historical and implied volatility information to solely utilize its own data for purposes of establishing the volatility assumption for use in the Black-Scholes model. Therefore, we estimated our expected share volatility based on a mix of company-specific historical volatility and historical volatility of a publicly traded set of peer companies.

[0001628280-25-020355:mdna:733]
Valuation of Contingent Earn-out Liability

[0001628280-25-020355:mdna:734]
The estimated fair value of the contingent earn-out shares is determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including volatility, risk-free rate of return, likelihood of a change in control, and expected remaining term. For potential common stock issuances related to a stock price milestones, the fair value was determined based on our expectations of achieving such a milestone and the simulated estimated stock price on the expected date of achievement.

[0001628280-25-020355:mdna:735]
We believe our assumptions are reasonable based on available information, our experience, knowledge, and judgments. These estimates can be affected by factors that are difficult to predict including future (1) EVLV closing price per share on the Nasdaq, (2) estimated stock price volatility over the earn-out period, and (3) risk free rates. Changes in assumptions and estimates used in our analysis, or future results that vary from assumptions used in the analysis, could affect the fair value of the contingent earn-out and could result in material changes in future periods.

[0001628280-25-020355:mdna:736]
Valuation of Contingently Issuable Common Stock Liability

[0001628280-25-020355:mdna:737]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the vesting period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including volatility, risk-free rate of return, likelihood of a change in control, and expected remaining term.

[0001628280-25-020355:mdna:738]
We believe our assumptions are reasonable based on available information, our experience, knowledge, and judgments. These estimates can be affected by factors that are difficult to predict including future (1) EVLV closing price per share on the Nasdaq, (2) estimated stock price volatility over the contingently issuable common shares period, and (3) risk free rates. Changes in assumptions and estimates used in our analysis, or future results that vary from assumptions used in the analysis, could affect the fair value of the contingently issuable common stock and could result in material changes in future periods.

[0001628280-25-020355:mdna:739]
Valuation of Public Warrant Liability

[0001628280-25-020355:mdna:740]
In connection with the closing of the Merger, we assumed the Public Warrants to purchase shares of common stock, which were classified as a liability, as the Public Warrants do not meet the criteria to be indexed to our common stock. Accordingly, we recorded the Public Warrants at fair value upon the closing of the Merger with a corresponding adjustment to additional paid-in capital. After the initial measurement, the fair value of the Public Warrants is subsequently remeasured quarterly based on the listed market price on the Nasdaq of such Public Warrants.

[0001628280-25-020355:mdna:741]
Valuation of Inventory

[0001628280-25-020355:mdna:742]
Inventory is valued at the lower of cost or net realizable value. Cost is computed using the weighted average method. We regularly review inventory quantities on-hand for excess and obsolete inventory and, when circumstances indicate, record charges to write down inventories to their estimated net realizable value, after evaluating historical sales, future demand, our estimates of forecasted net revenue, market conditions and expected product life cycles. A significant change in the timing or level of demand for our products as compared to forecasted amounts may result in recording

[0001628280-25-020355:mdna:743]
111

[0001628280-25-020355:mdna:744]
additional write-offs. Such charges are classified as cost of product revenue in the statements of operations and comprehensive loss. Any write-down of inventory to net realizable value creates a new cost basis.

[0001628280-25-020355:mdna:745]
Capitalized Software

[0001628280-25-020355:mdna:746]
Software development costs consist of certain consulting costs and compensation expenses for employees who devote time to the development of our internal-use software and software embedded in products to be sold or leased, as well as certain upgrades and enhancements that are expected to result in enhanced functionality. We amortize these development costs over the estimated useful life of four years. We determined that a four year life is appropriate for our capitalized software based on our best estimate of the useful life of the software after considering factors such as continuous developments in the technology, obsolescence, and anticipated life of the service offering before significant upgrades. Management evaluates the useful lives of these assets on a quarterly basis and tests for impairment whenever events or changes in circumstances occur that could impact the recoverability of these assets.

[0001628280-25-020355:mdna:747]
We determine the amount of software costs to be capitalized based on the amount of time spent by our developers and consultants on projects in the application stage of development. There is judgment in estimating the time allocated to a particular project in the application stage. A significant change in the time spent on each project could have a material impact on the amount capitalized and related amortization expense in subsequent periods.

[0001628280-25-020355:mdna:748]
Leases

[0001628280-25-020355:mdna:749]
To determine the residual value estimates and useful life of equipment that we lease to our customers, we are required to make judgments about future events that are subject to risks and uncertainties outside of their control, such as inventory levels of new equipment, changing consumer preferences, new technology and mandatory regulations. We have disciplines related to the management and maintenance of our leased equipment designed to manage the risk associated with the residual values of our revenue generating equipment. We periodically review and adjust, as appropriate, the estimated residual values and useful lives of existing revenue generating equipment for the purposes of classifying transactions as operating or sales-type leases and recording depreciation expense. Based on the results of our analysis, we may adjust the estimated residual values and useful lives of individual assets of our revenue generating equipment each year.
