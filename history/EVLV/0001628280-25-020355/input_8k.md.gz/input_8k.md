# EVLV 8-K — 0001628280-25-020351 filed 2025-04-28

## item codes, every 8-K on or before 2025-04-28

- 2025-04-28 0001628280-25-020351 — 2.02, 9.01
- 2025-04-23 0001104659-25-037732 — 5.02, 7.01, 9.01
- 2025-04-22 0001104659-25-037530 — 3.01, 7.01, 9.01
- 2025-02-04 0001104659-25-008892 — 5.02, 7.01, 9.01
- 2025-01-24 0001104659-25-005796 — 5.02, 7.01, 8.01, 9.01
- 2025-01-23 0001628280-25-002293 — 2.02, 2.05, 7.01, 9.01
- 2024-12-23 0001104659-24-131278 — 5.02
- 2024-12-12 0001104659-24-128006 — 5.02
- 2024-12-09 0001104659-24-126542 — 5.02, 7.01, 9.01
- 2024-11-22 0001104659-24-122102 — 3.01, 7.01, 9.01
- 2024-11-21 0001104659-24-121349 — 5.02, 7.01, 8.01, 9.01
- 2024-10-31 0001104659-24-112868 — 5.02, 7.01, 9.01
- 2024-10-25 0001104659-24-111310 — 4.02, 7.01, 9.01
- 2024-08-08 0001628280-24-036115 — 2.02, 9.01
- 2024-06-04 0001628280-24-026572 — 5.07
- 2024-05-09 0001628280-24-022265 — 2.02, 9.01
- 2024-02-29 0001628280-24-007980 — 2.02, 9.01
- 2024-02-20 0001104659-24-025077 — 7.01, 9.01
- 2024-01-31 0001628280-24-002618 — 5.03, 9.01
- 2023-11-09 0001628280-23-038267 — 2.02, 9.01
- 2023-11-06 0001104659-23-114499 — 5.02
- 2023-10-25 0001628280-23-035145 — 4.02
- 2023-10-12 0001104659-23-108693 — 2.02, 7.01, 9.01
- 2023-08-10 0001628280-23-028861 — 2.02, 9.01
- 2023-06-02 0001628280-23-020680 — 5.07
- 2023-05-10 0001628280-23-017243 — 2.02, 9.01
- 2023-04-03 0001628280-23-010402 — 1.02, 2.04, 8.01, 9.01
- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2025-04-28

- 2025-03-31 0001104659-25-029637 — NT 10-K, for the period ended 2024-12-31
- 2024-11-13 0001104659-24-117677 — NT 10-Q, for the period ended 2024-09-30
- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-25-020351:8k_2_02:1]
EX-99.1
2
evlv-20250428exx991.htm
EX-99.1

[0001628280-25-020351:8k_2_02:2]
Document

[0001628280-25-020351:8k_2_02:3]
Exhibit 99.1

[0001628280-25-020351:8k_2_02:4]
Evolv Technology Completes Restatement of Previously Issued Financial Statements

[0001628280-25-020351:8k_2_02:5]
and Reports Third Quarter, Fourth Quarter and Full Year 2024 Financial Results

[0001628280-25-020351:8k_2_02:6]
—  Company Regains Compliance with SEC Reporting and NASDAQ Listing Requirements —

[0001628280-25-020351:8k_2_02:7]
— Company Achieves Positive Adjusted EBITDA1 in Q4'24 —

[0001628280-25-020351:8k_2_02:8]
•Q4'24 Revenue of $29.1 million, up 41% year-over-year

[0001628280-25-020351:8k_2_02:9]
•Q4'24 Ending ARR2 of $99.4 million, up 39% year-over-year

[0001628280-25-020351:8k_2_02:10]
•Q4'24 Adjusted EBITDA of $0.4 million

[0001628280-25-020351:8k_2_02:11]
•Q4'24 Ending RPO3 of $266.7 million

[0001628280-25-020351:8k_2_02:12]
Waltham, Massachusetts – April 28, 2025 – Evolv Technologies Holdings, Inc (NASDAQ: EVLV), a leading security technology company pioneering AI-based solutions designed to help create safer experiences, today announced financial results for the quarter and year ended December 31, 2024 and the filing of its 2024 Annual Report on Form 10-K with the U.S. Securities and Exchange Commission ("SEC"). The Company concurrently filed with the SEC its Quarterly Report on Form 10-Q for the quarter ended September 30, 2024, and restated financial results for the periods from the second quarter of 2022 through the second quarter of 2024. The restatements correct inaccurate accounting for certain sales transactions that led to premature or incorrectly recognized revenue. The errors resulted in premature or incorrect recognition of approximately $3.1 million of revenue on a net basis from the second quarter of 2022 through the second quarter of 2024 (considering revenue prematurely recognized but offset by amounts appropriately recognized in subsequent periods).

[0001628280-25-020351:8k_2_02:13]
“Completing this restatement—which brings the Company back into full compliance with SEC reporting and Nasdaq listing requirements—marks an important milestone in our ongoing work to rebuild stakeholder confidence,” said John Kedzierski, President and Chief Executive Officer of Evolv Technology, Inc. “Looking ahead, we are focused on prioritizing disciplined execution, transparent communication, and an unwavering commitment to best-in-class compliance.  With both the restatement and the FTC resolution now firmly behind us and having achieved our long-standing profitability goals six months ahead of schedule, we believe we are well-positioned as we enter our next phase of growth. We are poised to lead the transformation of the security technology landscape—making the world a safer place where people can live, work, learn, and play.”

[0001628280-25-020351:8k_2_02:14]
Results for the Third Quarter of 2024

[0001628280-25-020351:8k_2_02:15]
Total revenue for the third quarter of 2024 was $27.4 million, an increase of 37% compared to $20.0 million (as restated) for the third quarter of 2023. Annual Recurring Revenue (“ARR”)2 was $93.7 million at the end of third quarter of 2024, an increase of 46% compared to $64.4 million (as restated) at the end of the third quarter of 2023. Net loss for the third quarter of 2024 was $(30.4) million, or $(0.19) per basic and diluted share, compared to net income of $5.0 million (as restated), or $0.03 (as restated) per basic and diluted share, in the third quarter of 2023. Adjusted earnings (loss)1 for the third quarter of 2024 was $(6.9) million, or $(0.04) per diluted share, compared to adjusted earnings (loss)1 of $(12.4) million (as restated), or $(0.08) per diluted share, for the third quarter of 2023. Adjusted EBITDA1 for the third quarter of 2024 was $(3.0) million compared to $(11.6) million (as restated) in the third quarter of 2023. As of September 30, 2024, the Company had cash, cash equivalents, marketable securities, and restricted cash of $56.3 million and no debt.

[0001628280-25-020351:8k_2_02:16]
Total revenue for the nine months ended September 30, 2024 was $74.8 million, an increase of 27% compared to $59.0 million (as restated) for the nine months ended September 30, 2023. Net loss for the nine months ended September 30, 2024 was $(38.3) million, or $(0.25) per basic and diluted share, compared to $(90.9) million (as restated), or $(0.61) (as restated) per basic and diluted share, in the nine months ended September 30, 2023. Adjusted earnings (loss)1 for the nine months ended September 30, 2024 was $(30.8) million, or $(0.20) per diluted share, compared to adjusted earnings (loss)1 of $(44.2) million (as restated), or $(0.30) (as restated) per diluted share, for the nine months ended September 30, 2023. Adjusted EBITDA1 for the nine months ended September 30, 2024 was $(21.3) million compared to $(41.6) million (as restated) in the nine months ended September 30, 2023.

[0001628280-25-020351:8k_2_02:17]
Results for the Fourth Quarter of 2024

[0001628280-25-020351:8k_2_02:18]
Total revenue for the fourth quarter of 2024 was $29.1 million, an increase of 41% compared to $20.6 million (as restated) for the fourth quarter of 2023. Annual Recurring Revenue (“ARR”)2 was $99.4 million at the end of fourth quarter of 2024, an increase of 39% compared to $71.3 million (as restated) at the end of the fourth quarter of 2023. Net loss for the fourth quarter of 2024 was $(15.7) million, or $(0.10) per basic and diluted share, compared to net loss of $(17.2) million (as restated), or $(0.11) per basic and diluted share, in the fourth quarter of 2023. Adjusted earnings (loss)1 for the fourth quarter of 2024 was $(4.4) million, or $(0.03) per diluted share, compared to adjusted earnings (loss)1 of $(11.8) million (as restated), or $(0.08) (as restated) per diluted share, for the fourth quarter of 2023. Adjusted EBITDA1 for the fourth quarter of 2024 was $0.4 million compared to $(10.3) million (as restated) in the fourth quarter of 2023. As of December 31, 2024, the Company had cash, cash equivalents, marketable securities, and restricted cash of $51.9 million and no debt.  Remaining Performance Obligation3 as of December 31, 2024 was $266.7 million.  The Company had approximately 6,100 units deployed as of December 31, 2024,  reflecting a one time adjustment to remove approximately (100) non-revenue generating units from the Company's deployed unit count related to Evolv Edge, the Company's first generation product offering.

[0001628280-25-020351:8k_2_02:19]
Total revenue for the twelve months ended December 31, 2024 was $103.9 million, an increase of 31% compared to $79.6 million (as restated) for the twelve months ended December 31, 2023. Net loss for the twelve months ended December 31, 2024 was $(54.0) million, or $(0.34) per basic and diluted share, compared to $(108.0) million (as restated), or $(0.72) (as restated) per basic and diluted share, in the twelve months ended December 31, 2023. Adjusted earnings (loss)1 for the twelve months ended December 31, 2024 was $(35.3) million, or $(0.23) per diluted share, compared to adjusted earnings (loss)1 of $(56.0) million (as restated), or $(0.38) (as restated) per diluted share, for the twelve months ended December 31, 2023. Adjusted EBITDA1 for the twelve months ended December 31, 2024 was $(21.0) million compared to $(51.8) million (as restated) in the twelve months ended December 31, 2023.

[0001628280-25-020351:8k_2_02:20]
The following table summarizes the breakdown of recurring and non-recurring revenue4 for each period presented:

[0001628280-25-020351:8k_2_02:21]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | % Change |  | 2024 |  | 2023 |  | % Change |
|  |  |  | (Restated) |  |  |  |  |  | (Restated) |  |  |
| Recurring revenue | $ | 23,678 |  |  | $ | 17,074 |  |  | 39 | % |  | $ | 87,419 |  |  | $ | 50,915 |  |  | 72 | % |
| Non-recurring revenue | 5,422 |  |  | 3,506 |  |  | 55 | % |  | 16,446 |  |  | 28,650 |  |  | (43) | % |
| Total revenue | $ | 29,100 |  |  | $ | 20,580 |  |  | 41 | % |  | $ | 103,865 |  |  | $ | 79,565 |  |  | 31 | % |

[0001628280-25-020351:8k_2_02:22]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | % Change |  | 2024 |  | 2023 |  | % Change |
|  |  |  | (Restated) |  |  |  |  |  | (Restated) |  |  |
| Recurring revenue | $ | 23,764 |  |  | $ | 13,907 |  |  | 71 | % |  | $ | 63,741 |  |  | $ | 33,841 |  |  | 88 | % |
| Non-recurring revenue | 3,596 |  |  | 6,054 |  |  | (41) | % |  | 11,024 |  |  | 25,144 |  |  | (56) | % |
| Total revenue | $ | 27,360 |  |  | $ | 19,961 |  |  | 37 | % |  | $ | 74,765 |  |  | $ | 58,985 |  |  | 27 | % |

[0001628280-25-020351:8k_2_02:23]
The following table summarizes operating cash flows for each period presented:

[0001628280-25-020351:8k_2_02:24]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Net loss | $ | (15,720) |  |  | $ | (17,198) |  |  | $ | (54,017) |  |  | $ | (108,048) |  |
| Non-cash expense | 6,870 |  |  | 7,461 |  |  | 22,504 |  |  | 59,199 |  |
| Changes in operating assets and liabilities | 12,054 |  |  | 6,594 |  |  | 660 |  |  | 39,048 |  |
| Net cash used in operating activities | $ | 3,204 |  |  | $ | (3,143) |  |  | $ | (30,853) |  |  | $ | (9,801) |  |

[0001628280-25-020351:8k_2_02:25]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Net loss | $ | (30,443) |  |  | $ | 5,046 |  |  | $ | (38,297) |  |  | $ | (90,850) |  |
| Non-cash expense | 26,306 |  |  | (16,055) |  |  | 15,634 |  |  | 51,738 |  |
| Changes in operating assets and liabilities | 7,812 |  |  | 13,106 |  |  | (11,394) |  |  | 32,454 |  |
| Net cash used in operating activities | $ | 3,675 |  |  | $ | 2,097 |  |  | $ | (34,057) |  |  | $ | (6,658) |  |

[0001628280-25-020351:8k_2_02:26]
About Evolv Technology

[0001628280-25-020351:8k_2_02:27]
Evolv Technologies Holdings, Inc (NASDAQ: EVLV) is designed to transform human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics. Its mission is to transform security to create a safer world to live, work, learn, and play. Evolv has digitally transformed the gateways in many places where people gather by enabling seamless integration combined with powerful analytics and insights. Evolv’s advanced systems have scanned more than two billion people since 2019. Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) 2024 New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category, as well as Sport Business Journal’s (SBJ) 2024 awards for “Best In Fan Experience Technology” and “Best In Sports Technology”. Evolv®, Evolv Express®, Evolv Insights®, Evolv Visual Gun Detection™, Evolv eXpedite™, and Evolv Eva™ are registered trademarks or trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit evolv.com.

[0001628280-25-020351:8k_2_02:28]
1 Non-GAAP Financial Measures In this press release, the Company’s adjusted gross profit (loss), adjusted gross margin, adjusted operating expenses, adjusted operating income (loss), adjusted EBITDA, adjusted earnings (loss), and adjusted earnings per diluted share are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted operating expenses is defined as operating expenses less stock-based compensation expense, loss on impairment of lease equipment, one-time employee separation costs, and one-time legal and regulatory costs, which management believes provides a more meaningful representation of on-going operating expense levels. One time legal and regulatory costs include one-time legal, accounting and professional fees related to the internal investigation, subsequent restatement, certain one-time regulatory, litigation and legal matters, as well as fees related to the resolution of the U.S. Federal Trade Commission investigation. Adjusted gross profit and adjusted gross margin exclude stock-based compensation expense, amortization of capitalized stock-based compensation, losses from impairment of intangible assets, one-time employee separation costs, and one-time inventory charges, which management believes provides a more meaningful representation of contribution margin.  Adjusted operating loss is defined as operating loss, excluding stock-based compensation expense, amortization of capitalized stock-based compensation, losses from impairment of lease equipment and intangible assets, one-time employee separation costs, one-time inventory charges, and one-time legal and regulatory expenses, which management believes provides a more meaningful representation of operating results. Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, stock-based compensation, interest expense (income), provision for income taxes, loss on extinguishment of debt, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of lease equipment and intangible assets, one-time employee separation costs, one-time inventory charges, and one-time legal and regulatory expenses. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, amortization of capitalized stock-based compensation, loss on extinguishment of debt, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of lease equipment and intangible assets, one-time employee separation costs, one-time inventory charges, and one-time legal and regulatory expenses. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operating performance.

[0001628280-25-020351:8k_2_02:29]
However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release. The Company is unable to provide a reconciliation of Adjusted Gross Margin to GAAP Gross Margin and Adjusted EBITDA to Net Income (Loss), each measure's most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact these GAAP financial measures are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of derivative liabilities, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001628280-25-020351:8k_2_02:30]
2 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001628280-25-020351:8k_2_02:31]
3 We define Remaining Performance Obligation, or RPO, as estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied or partially satisfied as of the end of the quarter.

[0001628280-25-020351:8k_2_02:32]
4 Recurring revenue includes the recurring portion of revenue associated with pure subscription contracts and hardware purchase subscription contracts. Non-recurring revenue includes revenue that is one-time in nature, such as product revenue, shipping revenue, and revenue from installation, training, and professional services.

[0001628280-25-020351:8k_2_02:33]
Forward-Looking Statements

[0001628280-25-020351:8k_2_02:34]
by other economic, business, and/or competitive factors; operational risk; risks related to material weaknesses in our internal control over financial reporting and our remediation plans; risks related to increasing attention to and evolving expectations for, environmental, social, and governance initiatives; the impact of fluctuating general economic and market conditions and reductions in spending; the need for additional capital to support business growth, which might not be available on acceptable terms, if at all; and litigation and regulatory enforcement risks, including the diversion of management time and attention and the additional costs and demands on resources. These and other important factors discussed under the caption “Risk Factors” in our Annual Report on Form 10-K for the year ended December 31, 2024 filed with the Securities and Exchange Commission ("SEC") on April 28, 2025, could cause actual results to differ materially from those indicated by the forward-looking statements made in this press release. The forward-looking statements in this press release and related presentation materials are based upon information available to us as of the date hereof, and while we believe such information forms a reasonable basis for such statements, it may be limited or incomplete, and our statements should not be read to indicate that we have conducted an exhaustive inquiry into, or review of, all potentially available relevant information. These statements are inherently uncertain and investors are cautioned not to unduly rely upon these statements.

[0001628280-25-020351:8k_2_02:35]
You should review this press release and the documents that we reference in this press release and related presentation materials with the understanding that our actual future results, levels of activity, performance and achievements may be materially different from what we expect. We qualify all of our forward-looking statements by these cautionary statements. Except as required by applicable law, we do not plan to publicly update or revise any forward-looking statements contained in this press release and related presentation materials, whether as a result of any new information, future events or otherwise.

[0001628280-25-020351:8k_2_02:36]
Investor Relations:

[0001628280-25-020351:8k_2_02:37]
Brian Norris

[0001628280-25-020351:8k_2_02:38]
Senior Vice President of Finance and Investor Relations

[0001628280-25-020351:8k_2_02:39]
bnorris@evolvtechnology.com

[0001628280-25-020351:8k_2_02:40]
EVOLV TECHNOLOGY

[0001628280-25-020351:8k_2_02:41]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001628280-25-020351:8k_2_02:42]
(In thousands, except share and per share data)

[0001628280-25-020351:8k_2_02:43]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 1,675 |  |  | $ | 1,848 |  |  | $ | 6,464 |  |  | $ | 22,768 |  |
| Subscription revenue | 17,263 |  |  | 12,468 |  |  | 65,046 |  |  | 36,201 |  |
| Service revenue | 6,564 |  |  | 4,856 |  |  | 23,467 |  |  | 15,606 |  |
| License fee and other revenue | 3,598 |  |  | 1,408 |  |  | 8,888 |  |  | 4,990 |  |
| Total revenue | 29,100 |  |  | 20,580 |  |  | 103,865 |  |  | 79,565 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 2,166 |  |  | 4,692 |  |  | 10,735 |  |  | 27,967 |  |
| Cost of subscription revenue | 8,604 |  |  | 4,984 |  |  | 27,846 |  |  | 14,760 |  |
| Cost of service revenue | 1,476 |  |  | 1,166 |  |  | 5,399 |  |  | 3,982 |  |
| Cost of license fee and other revenue | 113 |  |  | 177 |  |  | 597 |  |  | 949 |  |
| Total cost of revenue | 12,359 |  |  | 11,019 |  |  | 44,577 |  |  | 47,658 |  |
| Gross profit | 16,741 |  |  | 9,561 |  |  | 59,288 |  |  | 31,907 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,390 |  |  | 6,303 |  |  | 23,446 |  |  | 24,473 |  |
| Sales and marketing | 13,455 |  |  | 14,344 |  |  | 61,291 |  |  | 54,986 |  |
| General and administrative | 16,759 |  |  | 11,128 |  |  | 56,634 |  |  | 42,182 |  |
| Loss from impairment of property and equipment | 15 |  |  | — |  |  | 224 |  |  | 322 |  |
| Total operating expenses | 35,619 |  |  | 31,775 |  |  | 141,595 |  |  | 121,963 |  |
| Loss from operations | (18,878) |  |  | (22,214) |  |  | (82,307) |  |  | (90,056) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | — |  |  | — |  |  | (654) |  |
| Interest income | 548 |  |  | 1,630 |  |  | 2,942 |  |  | 6,227 |  |
| Other expense, net | (50) |  |  | (17) |  |  | (83) |  |  | (84) |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | (626) |  |
| Change in fair value of contingent earn-out liability | 1,218 |  |  | 2,452 |  |  | 16,310 |  |  | (14,901) |  |
| Change in fair value of contingently issuable common stock liability | 311 |  |  | 422 |  |  | 2,529 |  |  | (3,138) |  |
| Change in fair value of public warrant liability | 1,131 |  |  | 580 |  |  | 6,592 |  |  | (4,765) |  |
| Total other income (expense), net | 3,158 |  |  | 5,067 |  |  | 28,290 |  |  | (17,941) |  |
| Loss before income taxes | (15,720) |  |  | (17,147) |  |  | (54,017) |  |  | (107,997) |  |
| Provision for income taxes | — |  |  | (51) |  |  | $ | — |  |  | $ | (51) |  |
| Net loss | $ | (15,720) |  |  | $ | (17,198) |  |  | $ | (54,017) |  |  | $ | (108,048) |  |
| Net income (loss) attributable to common stockholders – basic and diluted | $ | (15,720) |  |  | $ | (17,198) |  |  | $ | (54,017) |  |  | $ | (108,048) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |
| Basic | 158,997,410 |  | 151,087,430 |  | 156,573,886 |  | 149,168,105 |
| Diluted | 158,997,410 |  | 151,087,430 |  | 156,573,886 |  | 149,168,105 |
| Net loss per share |  |  |  |  |  |  |  |
| Basic | $ | (0.10) |  |  | $ | (0.11) |  |  | $ | (0.34) |  |  | $ | (0.72) |  |
| Diluted | $ | (0.10) |  |  | $ | (0.11) |  |  | $ | (0.34) |  |  | $ | (0.72) |  |
| Weighted average common shares outstanding – basic and diluted | 158,997,410 |  |  | 151,087,430 |  |  | 156,573,886 |  |  | 149,168,105 |  |
| Net loss per share - basic and diluted | $ | (0.10) |  |  | $ | (0.11) |  |  | $ | (0.34) |  |  | $ | (0.72) |  |
| Net loss | $ | (15,720) |  |  | $ | (17,198) |  |  | $ | (54,017) |  |  | $ | (108,048) |  |

[0001628280-25-020351:8k_2_02:44]
| Other comprehensive income (loss) |  |  |  |  |  |  |  |
| Cumulative translation adjustment | 96 |  |  | (44) |  |  | 21 |  |  | (43) |  |
| Total other comprehensive income (loss) | 96 |  |  | (44) |  |  | 21 |  |  | (43) |  |
| Total comprehensive loss | $ | (15,624) |  |  | $ | (17,242) |  |  | $ | (53,996) |  |  | $ | (108,091) |  |

[0001628280-25-020351:8k_2_02:45]
EVOLV TECHNOLOGY

[0001628280-25-020351:8k_2_02:46]
CONSOLIDATED BALANCE SHEETS

[0001628280-25-020351:8k_2_02:47]
(In thousands, except share and per share data)

[0001628280-25-020351:8k_2_02:48]
|  | December 31, 2024 |  | December 31, 2023 |
|  |  |  | (Restated) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 37,015 |  |  | $ | 67,162 |  |
| Restricted cash | — |  |  | 275 |  |
| Marketable securities | 14,927 |  |  | 51,289 |  |
| Accounts receivable, net | 28,392 |  |  | 21,547 |  |
| Inventory | 16,963 |  |  | 10,344 |  |
| Current portion of contract assets | 799 |  |  | 1,397 |  |
| Current portion of commission asset | 5,429 |  |  | 4,387 |  |
| Prepaid expenses and other current assets | 17,921 |  |  | 16,957 |  |
| Total current assets | 121,446 |  |  | 173,358 |  |
| Contract assets, noncurrent | 657 |  |  | 964 |  |
| Commission asset, noncurrent | 7,567 |  |  | 7,249 |  |
| Property and equipment, net | 123,661 |  |  | 113,161 |  |
| Operating lease right-of-use assets | 13,993 |  |  | 1,195 |  |
| Other assets | 735 |  |  | 1,202 |  |
| Total assets | $ | 268,059 |  |  | $ | 297,129 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 10,492 |  |  | $ | 17,400 |  |
| Accrued expenses and other current liabilities | 19,508 |  |  | 15,703 |  |
| Current portion of deferred revenue | 64,506 |  |  | 46,808 |  |
| Current portion of operating lease liabilities | 2,203 |  |  | 1,391 |  |
| Total current liabilities | 96,709 |  |  | 81,302 |  |
| Deferred revenue, noncurrent | 20,266 |  |  | 25,149 |  |
| Operating lease liabilities, noncurrent | 12,326 |  |  | — |  |
| Contingent earn-out liability | 12,809 |  |  | 29,119 |  |
| Contingently issuable common stock liability | 4,001 |  |  | 6,530 |  |
| Public warrant liability | 4,297 |  |  | 10,889 |  |
| Total liabilities | 150,408 |  |  | 152,989 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at December 31, 2024 and December 31, 2023; no shares issued and outstanding at December 31, 2024 and December 31, 2023 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at December 31, 2024 and December 31, 2023; 159,602,069 and 151,310,080 shares issued and outstanding at December 31, 2024 and December 31, 2023, respectively | 16 |  |  | 15 |  |
| Additional paid-in capital | 472,331 |  |  | 444,825 |  |
| Accumulated other comprehensive loss | (32) |  |  | (53) |  |
| Accumulated deficit | (354,664) |  |  | (300,647) |  |
| Stockholders’ equity | 117,651 |  |  | 144,140 |  |
| Total liabilities and stockholders’ equity | $ | 268,059 |  |  | $ | 297,129 |  |

[0001628280-25-020351:8k_2_02:49]
EVOLV TECHNOLOGY

[0001628280-25-020351:8k_2_02:50]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-25-020351:8k_2_02:51]
(In thousands)

[0001628280-25-020351:8k_2_02:52]
|  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |
|  |  |  | (Restated) |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (54,017) |  |  | $ | (108,048) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 17,375 |  |  | 9,702 |  |
| Write-off of inventory and change in inventory reserve | 2,578 |  |  | 1,309 |  |
| Loss from impairment of property and equipment | 224 |  |  | 322 |  |
| Loss from impairment of intangible asset | 983 |  |  | — |  |
| Stock-based compensation | 24,756 |  |  | 24,129 |  |
| Non-cash interest expense | — |  |  | 22 |  |
| Amortization (accretion) of premium (discount) on marketable securities, net of change in accrued interest | 447 |  |  | (575) |  |
| Non-cash lease expense | 1,420 |  |  | 478 |  |
| Change in allowance for expected credit losses | 152 |  |  | 382 |  |
| Loss on extinguishment of debt | — |  |  | 626 |  |
| Change in fair value of earn-out liability | (16,310) |  |  | 14,901 |  |
| Change in fair value of contingently issuable common stock | (2,529) |  |  | 3,138 |  |
| Change in fair value of public warrant liability | (6,592) |  |  | 4,765 |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (6,997) |  |  | 4,510 |  |
| Inventory | (7,852) |  |  | 960 |  |
| Commission assets | (1,360) |  |  | (2,779) |  |
| Contract assets | 905 |  |  | 1,383 |  |
| Other assets | 467 |  |  | 633 |  |
| Prepaid expenses and other current assets | (964) |  |  | (2,426) |  |
| Accounts payable | 192 |  |  | (5,963) |  |
| Deferred revenue | 12,815 |  |  | 39,488 |  |
| Accrued expenses and other current liabilities | 4,534 |  |  | 3,857 |  |
| Operating lease liability | (1,080) |  |  | (615) |  |
| Net cash used in operating activities | (30,853) |  |  | (9,801) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (6,125) |  |  | (3,535) |  |
| Purchases of property and equipment | (31,189) |  |  | (69,134) |  |
| Proceeds from sale of property and equipment | — |  |  | 270 |  |
| Purchases of marketable securities | (29,367) |  |  | (89,898) |  |
| Proceeds from maturities of marketable securities | 65,282 |  |  | 39,184 |  |
| Net cash provided by (used in) investing activities | (1,399) |  |  | (123,113) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 1,809 |  |  | 668 |  |
| Proceeds from long-term debt | — |  |  | 1,876 |  |
| Repayment of principal on long-term debt | — |  |  | (31,876) |  |
| Payment of debt issuance costs and prepayment penalty | — |  |  | (332) |  |
| Net cash provided by (used in) financing activities | 1,809 |  |  | (29,664) |  |
| Effect of exchange rate changes on cash and cash equivalents | 21 |  |  | (43) |  |
| Net decrease in cash, cash equivalents and restricted cash | (30,422) |  |  | (162,621) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 67,437 |  |  | 230,058 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 37,015 |  |  | $ | 67,437 |  |

[0001628280-25-020351:8k_2_02:53]
EVOLV TECHNOLOGY

[0001628280-25-020351:8k_2_02:54]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (LOSS)

[0001628280-25-020351:8k_2_02:55]
(In thousands, except share and per share data)

[0001628280-25-020351:8k_2_02:56]
(Unaudited)

[0001628280-25-020351:8k_2_02:57]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 1,344 |  |  | $ | 3,456 |  |  | $ | 4,789 |  |  | $ | 20,920 |  |
| Subscription revenue | 17,909 |  |  | 9,858 |  |  | 47,783 |  |  | 23,733 |  |
| Service revenue | 6,085 |  |  | 4,345 |  |  | 16,903 |  |  | 10,750 |  |
| License fee and other revenue | 2,022 |  |  | 2,302 |  |  | 5,290 |  |  | 3,582 |  |
| Total revenue | 27,360 |  |  | 19,961 |  |  | 74,765 |  |  | 58,985 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 2,616 |  |  | 3,496 |  |  | 8,569 |  |  | 23,275 |  |
| Cost of subscription revenue | 7,348 |  |  | 4,157 |  |  | 19,242 |  |  | 9,776 |  |
| Cost of service revenue | 1,404 |  |  | 1,219 |  |  | 3,923 |  |  | 2,816 |  |
| Cost of license fee and other revenue | 183 |  |  | 198 |  |  | 484 |  |  | 772 |  |
| Total cost of revenue | 11,551 |  |  | 9,070 |  |  | 32,218 |  |  | 36,639 |  |
| Gross profit | 15,809 |  |  | 10,891 |  |  | 42,547 |  |  | 22,346 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,810 |  |  | 6,386 |  |  | 18,056 |  |  | 18,170 |  |
| Sales and marketing | 14,966 |  |  | 14,408 |  |  | 47,836 |  |  | 40,642 |  |
| General and administrative | 13,976 |  |  | 11,261 |  |  | 39,875 |  |  | 31,054 |  |
| Loss from impairment of property and equipment | 209 |  |  | 28 |  |  | 209 |  |  | 322 |  |
| Total operating expenses | 34,961 |  |  | 32,083 |  |  | 105,976 |  |  | 90,188 |  |
| Loss from operations | (19,152) |  |  | (21,192) |  |  | (63,429) |  |  | (67,842) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | — |  |  | — |  |  | (654) |  |
| Interest income | 628 |  |  | 1,791 |  |  | 2,394 |  |  | 4,597 |  |
| Other income (expense), net | 34 |  |  | (64) |  |  | (33) |  |  | (67) |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | (626) |  |
| Change in fair value of contingent earn-out liability | (8,321) |  |  | 14,078 |  |  | 15,092 |  |  | (17,353) |  |
| Change in fair value of contingently issuable common stock liability | (2,056) |  |  | 2,277 |  |  | 2,218 |  |  | (3,560) |  |
| Change in fair value of public warrant liability | (1,576) |  |  | 8,156 |  |  | 5,461 |  |  | (5,345) |  |
| Total other (expense) income, net | (11,291) |  |  | 26,238 |  |  | 25,132 |  |  | (23,008) |  |
| Net (loss) income | $ | (30,443) |  |  | $ | 5,046 |  |  | $ | (38,297) |  |  | $ | (90,850) |  |
| Net (loss) income attributable to common stockholders – basic and diluted | $ | (30,443) |  |  | $ | 4,983 |  |  | $ | (38,297) |  |  | $ | (90,850) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |
| Basic | 157,709,229 |  | 150,206,893 |  | 155,760,149 |  | 148,521,299 |
| Diluted | 157,709,229 |  | 173,976,375 |  | 155,760,149 |  | 148,521,299 |
| Net (loss) income per share |  |  |  |  |  |  |  |
| Basic | $ | (0.19) |  |  | $ | 0.03 |  |  | $ | (0.25) |  |  | $ | (0.61) |  |
| Diluted | $ | (0.19) |  |  | $ | 0.03 |  |  | $ | (0.25) |  |  | $ | (0.61) |  |
| Net (loss) income | $ | (30,443) |  |  | $ | 5,046 |  |  | $ | (38,297) |  |  | $ | (90,850) |  |
| Other comprehensive (loss) income |  |  |  |  |  |  |  |
| Cumulative translation adjustment | (86) |  |  | 34 |  |  | (75) |  |  | 1 |  |
| Total other comprehensive (loss) income | (86) |  |  | 34 |  |  | (75) |  |  | 1 |  |
| Total comprehensive (loss) income | $ | (30,529) |  |  | $ | 5,080 |  |  | $ | (38,372) |  |  | $ | (90,849) |  |

[0001628280-25-020351:8k_2_02:58]
EVOLV TECHNOLOGY

[0001628280-25-020351:8k_2_02:59]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-25-020351:8k_2_02:60]
(In thousands, except share and per share data)

[0001628280-25-020351:8k_2_02:61]
(Unaudited)

[0001628280-25-020351:8k_2_02:62]
|  | September 30, 2024 |  | December 31, 2023 |
|  |  |  | (Restated) |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 46,033 |  |  | $ | 67,162 |  |
| Restricted cash | 275 |  |  | 275 |  |
| Marketable securities | 9,960 |  |  | 51,289 |  |
| Accounts receivable, net | 34,855 |  |  | 21,547 |  |
| Inventory | 16,276 |  |  | 10,344 |  |
| Current portion of contract assets | 696 |  |  | 1,397 |  |
| Current portion of commission asset | 5,256 |  |  | 4,387 |  |
| Prepaid expenses and other current assets | 21,050 |  |  | 16,957 |  |
| Total current assets | 134,401 |  |  | 173,358 |  |
| Contract assets, noncurrent | 672 |  |  | 964 |  |
| Commission asset, noncurrent | 7,385 |  |  | 7,249 |  |
| Property and equipment, net | 120,842 |  |  | 113,161 |  |
| Operating lease right-of-use assets | 14,297 |  |  | 1,195 |  |
| Other assets | 869 |  |  | 1,202 |  |
| Total assets | $ | 278,466 |  |  | $ | 297,129 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 8,619 |  |  | $ | 17,400 |  |
| Accrued expenses and other current liabilities | 17,016 |  |  | 15,703 |  |
| Current portion of deferred revenue | 61,649 |  |  | 46,808 |  |
| Current portion of operating lease liabilities | 2,191 |  |  | 1,391 |  |
| Total current liabilities | 89,475 |  |  | 81,302 |  |
| Deferred revenue, noncurrent | 23,867 |  |  | 25,149 |  |
| Operating lease liabilities, noncurrent | 12,372 |  |  | — |  |
| Contingent earn-out liability | 14,027 |  |  | 29,119 |  |
| Contingently issuable common stock liability | 4,312 |  |  | 6,530 |  |
| Public warrant liability | 5,428 |  |  | 10,889 |  |
| Total liabilities | 149,481 |  |  | 152,989 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at September 30, 2024 and December 31, 2023; no shares issued and outstanding at September 30, 2024 and December 31, 2023 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at September 30, 2024 and December 31, 2023; 158,288,746 and 151,310,080 shares issued and outstanding at September 30, 2024 and December 31, 2023, respectively | 16 |  |  | 15 |  |
| Additional paid-in capital | 468,041 |  |  | 444,825 |  |
| Accumulated other comprehensive loss | (128) |  |  | (53) |  |
| Accumulated deficit | (338,944) |  |  | (300,647) |  |
| Stockholders’ equity | 128,985 |  |  | 144,140 |  |
| Total liabilities and stockholders’ equity | $ | 278,466 |  |  | $ | 297,129 |  |

[0001628280-25-020351:8k_2_02:63]
EVOLV TECHNOLOGY

[0001628280-25-020351:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-25-020351:8k_2_02:65]
(In thousands)

[0001628280-25-020351:8k_2_02:66]
(Unaudited)

[0001628280-25-020351:8k_2_02:67]
|  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |
|  |  |  | (Restated) |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (38,297) |  |  | $ | (90,850) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 11,933 |  |  | 6,570 |  |
| Write-off of inventory and change in inventory reserve | 3,151 |  |  | 278 |  |
| Loss from impairment of property and equipment | 209 |  |  | 322 |  |
| Stock-based compensation | 21,364 |  |  | 17,771 |  |
| Non-cash interest expense | — |  |  | 22 |  |
| Amortization (accretion) of premium (discount) on marketable securities, net of change in accrued interest | 261 |  |  | (482) |  |
| Non-cash lease expense | 1,116 |  |  | 136 |  |
| Change in allowance for expected credit losses | 371 |  |  | 237 |  |
| Loss on extinguishment of debt | — |  |  | 626 |  |
| Change in fair value of earn-out liability | (15,092) |  |  | 17,353 |  |
| Change in fair value of contingently issuable common stock | (2,218) |  |  | 3,560 |  |
| Change in fair value of public warrant liability | (5,461) |  |  | 5,345 |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (13,679) |  |  | (929) |  |
| Inventory | (8,327) |  |  | 4,170 |  |
| Commission assets | (1,005) |  |  | (2,102) |  |
| Contract assets | 993 |  |  | (85) |  |
| Other assets | 333 |  |  | 352 |  |
| Prepaid expenses and other current assets | (4,093) |  |  | (1,973) |  |
| Accounts payable | 216 |  |  | (6,396) |  |
| Deferred revenue | 13,559 |  |  | 39,357 |  |
| Accrued expenses and other current liabilities | 1,655 |  |  | 278 |  |
| Operating lease liability | (1,046) |  |  | (218) |  |
| Net cash used in operating activities | (34,057) |  |  | (6,658) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (4,773) |  |  | (2,202) |  |
| Purchases of property and equipment | (24,443) |  |  | (51,646) |  |
| Proceeds from sale of property and equipment | — |  |  | 60 |  |
| Purchases of marketable securities | (14,567) |  |  | (58,652) |  |
| Proceeds from maturities of marketable securities | 55,635 |  |  | 19,647 |  |
| Net cash provided by (used in) investing activities | 11,852 |  |  | (92,793) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 1,151 |  |  | 616 |  |
| Proceeds from long-term debt | — |  |  | 1,876 |  |
| Repayment of principal on long-term debt | — |  |  | (31,876) |  |
| Payment of debt issuance costs and prepayment penalty | — |  |  | (332) |  |
| Net cash provided by (used in) financing activities | 1,151 |  |  | (29,716) |  |
| Effect of exchange rate changes on cash and cash equivalents | (75) |  |  | 1 |  |
| Net decrease in cash, cash equivalents and restricted cash | (21,129) |  |  | (129,166) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 67,437 |  |  | 230,058 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 46,308 |  |  | $ | 100,892 |  |

[0001628280-25-020351:8k_2_02:68]
EVOLV TECHNOLOGY

[0001628280-25-020351:8k_2_02:69]
SUMMARY OF KEY OPERATING STATISTICS

[0001628280-25-020351:8k_2_02:70]
(Unaudited)

[0001628280-25-020351:8k_2_02:71]
|  |  |  |  |  |  |  |  |  |  | Three Months Ended or as of, |
| ($ in thousands) |  |  |  |  |  |  |  |  |  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |
| New customers |  |  |  |  |  |  |  |  |  | 53 |  |  | 84 |  |  | 52 |  |  | 60 |  |
| Annual recurring revenue |  |  |  |  |  |  |  |  |  | $ | 79,192 |  |  | $ | 87,011 |  |  | $ | 93,676 |  |  | $ | 99,351 |  |
| Recurring revenue |  |  |  |  |  |  |  |  |  | $ | 18,961 |  |  | $ | 21,016 |  |  | $ | 23,764 |  |  | $ | 23,678 |  |
| Total net units shipped* |  |  |  |  |  |  |  |  |  | 375 |  |  | 447 |  |  | 468 |  |  | 458 |  |

[0001628280-25-020351:8k_2_02:72]
*Net Units Shipped reflects total units shipped (excluding rental units, upgrade units, etc.) less units churned.

[0001628280-25-020351:8k_2_02:73]
EVOLV TECHNOLOGY

[0001628280-25-020351:8k_2_02:74]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001628280-25-020351:8k_2_02:75]
(In thousands)

[0001628280-25-020351:8k_2_02:76]
(Unaudited)

[0001628280-25-020351:8k_2_02:77]
|  | Three Months Ended, |
|  |  | March 31,2023 |  | June 30,2023 |  | September 30,2023 |  | December 31,2023 |  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |
|  |  | (Restated) |  | (Restated) |  | (Restated) |  | (Restated) |  | (Restated) |  | (Restated) |  |  |  |  |
| Operating expenses, GAAP |  | $ | 27,098 |  |  | $ | 31,007 |  |  | $ | 32,083 |  |  | $ | 31,775 |  |  | $ | 34,061 |  |  | $ | 36,954 |  |  | $ | 34,961 |  |  | $ | 35,619 |  |
| Stock-based compensation |  | (4,888) |  |  | (6,518) |  |  | (5,922) |  |  | (6,218) |  |  | (6,292) |  |  | (7,254) |  |  | (7,263) |  |  | (3,159) |  |
| Loss on impairment of lease equipment |  | (137) |  |  | (157) |  |  | (28) |  |  | — |  |  | — |  |  | — |  |  | (209) |  |  | (15) |  |
| One-time employee separation costs |  | — |  |  | (282) |  |  | (61) |  |  | (262) |  |  | — |  |  | (826) |  |  | — |  |  | (2,059) |  |
| Other one-time legal and regulatory costs |  | (53) |  |  | (401) |  |  | (884) |  |  | (273) |  |  | (476) |  |  | (2,185) |  |  | (2,339) |  |  | (7,285) |  |
| Adjusted operating expenses |  | $ | 22,020 |  |  | $ | 23,649 |  |  | $ | 25,188 |  |  | $ | 25,022 |  |  | $ | 27,293 |  |  | $ | 26,689 |  |  | $ | 25,150 |  |  | $ | 23,101 |  |

[0001628280-25-020351:8k_2_02:78]
EVOLV TECHNOLOGY

[0001628280-25-020351:8k_2_02:79]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT, GAAP GROSS MARGIN TO ADJUSTED GROSS MARGIN AND GAAP OPERATING INCOME (LOSS) TO ADJUSTED OPERATING INCOME (LOSS)

[0001628280-25-020351:8k_2_02:80]
(In thousands)

[0001628280-25-020351:8k_2_02:81]
(Unaudited)

[0001628280-25-020351:8k_2_02:82]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Revenue | $ | 29,100 |  |  | $ | 20,580 |  |  | $ | 103,865 |  |  | $ | 79,565 |  |
| Cost of revenue | 12,359 |  |  | 11,019 |  |  | 44,577 |  |  | 47,658 |  |
| Gross profit, GAAP | 16,741 |  |  | 9,561 |  |  | 59,288 |  |  | 31,907 |  |
| Stock-based compensation | 233 |  |  | 140 |  |  | 788 |  |  | 583 |  |
| Amortization of capitalized stock-based compensation | 85 |  |  | 14 |  |  | 137 |  |  | 47 |  |
| Loss from impairment of intangible asset | 983 |  |  | — |  |  | 983 |  |  | — |  |
| One-time employee separation costs | — |  |  | — |  |  | 174 |  |  | — |  |
| One-time inventory charges | 123 |  |  | 1,925 |  |  | 2,729 |  |  | 1,925 |  |
| Adjusted gross profit | $ | 18,165 |  |  | $ | 11,640 |  |  | $ | 64,100 |  |  | $ | 34,462 |  |
| Gross margin % | 57.5 | % |  | 46.5 | % |  | 57.1 | % |  | 40.1 | % |
| Adjusted gross margin % | 62.4 | % |  | 56.6 | % |  | 61.7 | % |  | 43.3 | % |

[0001628280-25-020351:8k_2_02:83]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Revenue | $ | 27,360 |  |  | $ | 19,961 |  |  | $ | 74,765 |  |  | $ | 58,985 |  |
| Cost of revenue | 11,551 |  |  | 9,070 |  |  | 32,218 |  |  | 36,639 |  |
| Gross profit, GAAP | 15,809 |  |  | 10,891 |  |  | 42,547 |  |  | 22,346 |  |
| Stock-based compensation | 244 |  |  | 114 |  |  | 555 |  |  | 443 |  |
| Amortization of capitalized stock-based compensation | 23 |  |  | 12 |  |  | 52 |  |  | 33 |  |
| One-time employee separation costs | — |  |  | — |  |  | 174 |  |  | — |  |
| One-time inventory charges | 1,471 |  |  | — |  |  | 2,607 |  |  | — |  |
| Adjusted gross profit | $ | 17,547 |  |  | $ | 11,017 |  |  | $ | 45,935 |  |  | $ | 22,822 |  |
| Gross margin % | 57.8 | % |  | 54.6 | % |  | 56.9 | % |  | 37.9 | % |
| Adjusted gross margin % | 64.1 | % |  | 55.2 | % |  | 61.4 | % |  | 38.7 | % |

[0001628280-25-020351:8k_2_02:84]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Operating loss, GAAP | $ | (18,878) |  |  | $ | (22,214) |  |  | $ | (82,307) |  |  | $ | (90,056) |  |
| Stock-based compensation | 3,392 |  |  | 6,358 |  |  | 24,756 |  |  | 24,129 |  |
| Amortization of capitalized stock-based compensation | 85 |  |  | 14 |  |  | 137 |  |  | 47 |  |
| Loss on impairment of lease equipment | 15 |  |  | — |  |  | 224 |  |  | 322 |  |
| Loss from impairment of intangible asset | 983 |  |  | — |  |  | 983 |  |  | — |  |
| One-time employee separation costs | 2,060 |  |  | 262 |  |  | 3,060 |  |  | 605 |  |
| One-time inventory charges | 123 |  |  | 1,925 |  |  | 2,729 |  |  | 1,925 |  |
| Other one-time legal and regulatory costs | 7,284 |  |  | 273 |  |  | 12,285 |  |  | 1,611 |  |
| Adjusted operating loss | $ | (4,936) |  |  | $ | (13,382) |  |  | $ | (38,133) |  |  | $ | (61,417) |  |

[0001628280-25-020351:8k_2_02:85]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Operating loss, GAAP | $ | (19,152) |  |  | $ | (21,192) |  |  | $ | (63,429) |  |  | $ | (67,842) |  |
| Stock-based compensation | 7,507 |  |  | 6,036 |  |  | 21,364 |  |  | 17,771 |  |
| Amortization of capitalized stock-based compensation | 23 |  |  | 12 |  |  | 52 |  |  | 33 |  |
| Loss on impairment of lease equipment | 209 |  |  | 28 |  |  | 209 |  |  | 322 |  |
| One-time employee separation costs | — |  |  | 61 |  |  | 1,000 |  |  | 343 |  |
| One-time inventory charges | 1,471 |  |  | — |  |  | 2,607 |  |  | — |  |
| Other one-time legal and regulatory costs | 2,339 |  |  | 884 |  |  | 5,000 |  |  | 1,338 |  |
| Adjusted operating loss | $ | (7,603) |  |  | $ | (14,171) |  |  | $ | (33,197) |  |  | $ | (48,035) |  |

[0001628280-25-020351:8k_2_02:86]
EVOLV TECHNOLOGY

[0001628280-25-020351:8k_2_02:87]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-25-020351:8k_2_02:88]
(In thousands)

[0001628280-25-020351:8k_2_02:89]
(Unaudited)

[0001628280-25-020351:8k_2_02:90]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Net loss | $ | (15,720) |  |  | $ | (17,198) |  |  | $ | (54,017) |  |  | $ | (108,048) |  |
| Depreciation & amortization | 5,442 |  |  | 3,132 |  |  | 17,375 |  |  | 9,702 |  |
| Stock-based compensation | 3,392 |  |  | 6,358 |  |  | 24,756 |  |  | 24,129 |  |
| Interest expense (income) | (548) |  |  | (1,630) |  |  | (2,942) |  |  | (5,573) |  |
| Provision for income taxes | — |  |  | 51 |  |  | — |  |  | 51 |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | 626 |  |
| Change in fair value of contingent earn-out liability | (1,218) |  |  | (2,452) |  |  | (16,310) |  |  | 14,901 |  |
| Change in fair value of contingently issuable common stock liability | (311) |  |  | (422) |  |  | (2,529) |  |  | 3,138 |  |
| Change in fair value of public warrant liability | (1,131) |  |  | (580) |  |  | (6,592) |  |  | 4,765 |  |
| Loss on impairment of lease equipment | 15 |  |  | — |  |  | 224 |  |  | 322 |  |
| Loss from impairment of intangible asset | 983 |  |  | — |  |  | 983 |  |  | — |  |
| One-time employee separation costs | 2,060 |  |  | 262 |  |  | 3,060 |  |  | 605 |  |
| One-time inventory charges | 123 |  |  | 1,925 |  |  | 2,729 |  |  | 1,925 |  |
| Other one-time legal and regulatory costs | 7,284 |  |  | 273 |  |  | 12,285 |  |  | 1,611 |  |
| Adjusted EBITDA | $ | 371 |  |  | $ | (10,281) |  |  | $ | (20,978) |  |  | $ | (51,846) |  |

[0001628280-25-020351:8k_2_02:91]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Net (loss) income | $ | (30,443) |  |  | $ | 5,046 |  |  | $ | (38,297) |  |  | $ | (90,850) |  |
| Depreciation & amortization | 4,575 |  |  | 2,620 |  |  | 11,933 |  |  | 6,570 |  |
| Stock-based compensation | 7,507 |  |  | 6,036 |  |  | 21,364 |  |  | 17,771 |  |
| Interest expense (income) | (628) |  |  | (1,791) |  |  | (2,394) |  |  | (3,943) |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | 626 |  |
| Change in fair value of contingent earn-out liability | 8,321 |  |  | (14,078) |  |  | (15,092) |  |  | 17,353 |  |
| Change in fair value of contingently issuable common stock liability | 2,056 |  |  | (2,277) |  |  | (2,218) |  |  | 3,560 |  |
| Change in fair value of public warrant liability | 1,576 |  |  | (8,156) |  |  | (5,461) |  |  | 5,345 |  |
| Loss on impairment of lease equipment | 209 |  |  | 28 |  |  | 209 |  |  | 322 |  |
| One-time employee separation costs | — |  |  | 61 |  |  | 1,000 |  |  | 343 |  |
| One-time inventory charges | 1,471 |  |  | — |  |  | 2,607 |  |  | — |  |
| Other one-time legal and regulatory costs | 2,339 |  |  | 884 |  |  | 5,000 |  |  | 1,338 |  |
| Adjusted EBITDA | $ | (3,017) |  |  | $ | (11,627) |  |  | $ | (21,349) |  |  | $ | (41,565) |  |

[0001628280-25-020351:8k_2_02:92]
EVOLV TECHNOLOGY

[0001628280-25-020351:8k_2_02:93]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001628280-25-020351:8k_2_02:94]
(In thousands, except share and per share data)

[0001628280-25-020351:8k_2_02:95]
(Unaudited)

[0001628280-25-020351:8k_2_02:96]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Net loss | $ | (15,720) |  |  | $ | (17,198) |  |  | $ | (54,017) |  |  | $ | (108,048) |  |
| Stock-based compensation | 3,392 |  |  | 6,358 |  |  | 24,756 |  |  | 24,129 |  |
| Amortization of capitalized stock-based compensation | 85 |  |  | 14 |  |  | 137 |  |  | 47 |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | 626 |  |
| Change in fair value of contingent earn-out liability | (1,218) |  |  | (2,452) |  |  | (16,310) |  |  | 14,901 |  |
| Change in fair value of contingently issuable common stock liability | (311) |  |  | (422) |  |  | (2,529) |  |  | 3,138 |  |
| Change in fair value of public warrant liability | (1,131) |  |  | (580) |  |  | (6,592) |  |  | 4,765 |  |
| Loss on impairment of lease equipment | 15 |  |  | — |  |  | 224 |  |  | 322 |  |
| Loss from impairment of intangible asset | 983 |  |  | — |  |  | 983 |  |  | — |  |
| One-time employee separation costs | 2,060 |  |  | 262 |  |  | 3,060 |  |  | 605 |  |
| One-time inventory charges | 123 |  |  | 1,925 |  |  | 2,729 |  |  | 1,925 |  |
| Other one-time legal and regulatory costs | 7,284 |  |  | 273 |  |  | 12,285 |  |  | 1,611 |  |
| Adjusted loss | $ | (4,438) |  |  | $ | (11,820) |  |  | $ | (35,274) |  |  | $ | (55,979) |  |
| Weighted average common shares outstanding – diluted | 158,997,410 |  |  | 151,087,430 |  |  | 156,573,886 |  |  | 149,168,105 |  |
| Adjusted loss per share – diluted | $ | (0.03) |  |  | $ | (0.08) |  |  | $ | (0.23) |  |  | $ | (0.38) |  |

[0001628280-25-020351:8k_2_02:97]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Net (loss) income | $ | (30,443) |  |  | $ | 5,046 |  |  | $ | (38,297) |  |  | $ | (90,850) |  |
| Stock-based compensation | 7,507 |  |  | 6,036 |  |  | 21,364 |  |  | 17,771 |  |
| Amortization of capitalized stock-based compensation | 23 |  |  | 12 |  |  | 52 |  |  | 33 |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | 626 |  |
| Change in fair value of contingent earn-out liability | 8,321 |  |  | (14,078) |  |  | (15,092) |  |  | 17,353 |  |
| Change in fair value of contingently issuable common stock liability | 2,056 |  |  | (2,277) |  |  | (2,218) |  |  | 3,560 |  |
| Change in fair value of public warrant liability | 1,576 |  |  | (8,156) |  |  | (5,461) |  |  | 5,345 |  |
| Loss on impairment of lease equipment | 209 |  |  | 28 |  |  | 209 |  |  | 322 |  |
| One-time employee separation costs | — |  |  | 61 |  |  | 1,000 |  |  | 343 |  |
| One-time inventory charges | 1,471 |  |  | — |  |  | 2,607 |  |  | — |  |
| Other one-time legal and regulatory costs | 2,339 |  |  | 884 |  |  | 5,000 |  |  | 1,338 |  |
| Adjusted loss | $ | (6,941) |  |  | $ | (12,444) |  |  | $ | (30,836) |  |  | $ | (44,159) |  |
| Weighted average common shares outstanding – diluted | 157,709,229 |  |  | 150,206,893 |  |  | 155,760,149 |  |  | 148,521,299 |  |
| Adjusted loss per share – diluted | $ | (0.04) |  |  | $ | (0.08) |  |  | $ | (0.20) |  |  | $ | (0.30) |  |

[0001628280-25-020351:8k_2_02:98]
*In the consolidated statements of operations, one-time inventory reserves were recorded in cost of product revenue and one-time legal and regulatory costs were recorded in general and administrative expense. Stock-based compensation, amortization of capitalized stock-based compensation, and one-time employee termination costs were recorded as follows. Prior period amounts are being shown for comparative purposes:

[0001628280-25-020351:8k_2_02:99]
|  | Three Months Ended, |
|  | March 31,2023 |  | June 30,2023 |  | September 30,2023 |  | December 31,2023 |  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |
|  | (Restated) |  | (Restated) |  | (Restated) |  | (Restated) |  | (Restated) |  | (Restated) |  |  |  |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 16 |  |  | $ | 12 |  |  | $ | — |  |  | $ | 6 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 4 |  |  | $ | 8 |  |
| Cost of subscription revenue | 52 |  |  | 82 |  |  | 74 |  |  | 82 |  |  | 91 |  |  | 110 |  |  | 169 |  |  | 154 |  |
| Cost of service revenue | 47 |  |  | 61 |  |  | 38 |  |  | 47 |  |  | 44 |  |  | 51 |  |  | 63 |  |  | 61 |  |
| Cost of license fee and other revenue | 31 |  |  | 28 |  |  | 2 |  |  | 5 |  |  | 3 |  |  | 7 |  |  | 8 |  |  | 10 |  |
| Research and development | 843 |  |  | 1,232 |  |  | 1,148 |  |  | 1,079 |  |  | 902 |  |  | 1,222 |  |  | 1,243 |  |  | 1,153 |  |
| Sales and marketing | 1,980 |  |  | 2,536 |  |  | 2,293 |  |  | 2,572 |  |  | 2,959 |  |  | 2,724 |  |  | 2,516 |  |  | 2,747 |  |
| General and administrative | 2,065 |  |  | 2,750 |  |  | 2,481 |  |  | 2,567 |  |  | 2,431 |  |  | 3,308 |  |  | 3,504 |  |  | (741) |  |
| Total stock-based compensation | $ | 5,034 |  |  | $ | 6,701 |  |  | $ | 6,036 |  |  | $ | 6,358 |  |  | $ | 6,430 |  |  | $ | 7,427 |  |  | $ | 7,507 |  |  | $ | 3,392 |  |
| Amortization of capitalized stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of subscription revenue | 5 |  |  | 5 |  |  | 6 |  |  | 8 |  |  | 8 |  |  | 8 |  |  | 13 |  |  | 47 |  |
| Cost of service revenue | 5 |  |  | 6 |  |  | 6 |  |  | 6 |  |  | 6 |  |  | 7 |  |  | 10 |  |  | 38 |  |
| Total amortization of capitalized stock-based compensation | $ | 10 |  |  | $ | 11 |  |  | $ | 12 |  |  | $ | 14 |  |  | $ | 14 |  |  | $ | 15 |  |  | $ | 23 |  |  | $ | 85 |  |
| One-time employee separation costs: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of service revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 174 |  |  | $ | — |  |  | $ | — |  |
| Sales and marketing | — |  |  | 282 |  |  | 61 |  |  | 262 |  |  | — |  |  | 794 |  |  | — |  |  | 63 |  |
| General and administrative | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 32 |  |  | — |  |  | 1,997 |  |
| Total other one-time expenses | $ | — |  |  | $ | 282 |  |  | $ | 61 |  |  | $ | 262 |  |  | $ | — |  |  | $ | 1,000 |  |  | $ | — |  |  | $ | 2,060 |  |
