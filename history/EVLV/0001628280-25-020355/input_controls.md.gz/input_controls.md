# EVLV 10-K controls and the auditor's report


## auditors_report

[0001628280-25-020355:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001628280-25-020355:auditors_report:2]
To the Board of Directors and Stockholders of Evolv Technologies Holdings, Inc.

[0001628280-25-020355:auditors_report:3]
Opinion on the Financial Statements

[0001628280-25-020355:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Evolv Technologies Holdings, Inc. and its subsidiaries (the “Company”) as of December 31, 2024 and 2023, and the related consolidated statements of operations and comprehensive loss, of stockholders' equity and of cash flows for each of the three years in the period ended December 31, 2024, including the related notes (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of December 31, 2024 and 2023, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2024 in conformity with accounting principles generally accepted in the United States of America.

[0001628280-25-020355:auditors_report:5]
Restatement of Previously Issued Financial Statements

[0001628280-25-020355:auditors_report:6]
As discussed in Note 2 to the consolidated financial statements, the Company has restated its 2023 and 2022 financial statements to correct misstatements.

[0001628280-25-020355:auditors_report:7]
See also the “Revenue Recognition – Impact of the Investigation” critical audit matter.

[0001628280-25-020355:auditors_report:8]
Basis for Opinion

[0001628280-25-020355:auditors_report:9]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s consolidated financial statements based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001628280-25-020355:auditors_report:10]
We conducted our audits of these consolidated financial statements in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud. The Company is not required to have, nor were we engaged to perform, an audit of its internal control over financial reporting. As part of our audits we are required to obtain an understanding of internal control over financial reporting but not for the purpose of expressing an opinion on the effectiveness of the Company's internal control over financial reporting. Accordingly, we express no such opinion.

[0001628280-25-020355:auditors_report:11]
Our audits included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001628280-25-020355:auditors_report:12]
Critical Audit Matters

[0001628280-25-020355:auditors_report:13]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001628280-25-020355:auditors_report:14]
114

[0001628280-25-020355:auditors_report:15]
Consolidated Financial Statements - Impact of Controls Related to Financial Reporting

[0001628280-25-020355:auditors_report:16]
The completeness and accuracy of the consolidated financial statements, including the financial condition, results of operations and cash flows, is dependent on, in part, (i) demonstrating a commitment to maintaining integrity and ethical values; (ii) maintaining a sufficient complement of personnel with an appropriate level of internal controls and accounting knowledge, training and experience commensurate with the Company’s financial reporting requirements; (iii) designing and maintaining effective controls in response to the risks of material misstatement to financial reporting; (iv) designing and maintaining effective controls for communicating and sharing information between the sales, accounting and finance departments; (v) designing and maintaining effective controls over the period-end financial reporting process; (vi) designing and maintaining effective controls to analyze, account for and disclose non-routine, unusual or complex transactions; (vii) designing and maintaining formal accounting policies, procedures, and controls to achieve complete, accurate, and timely financial accounting, reporting and disclosures, including controls over the preparation and review of account reconciliations and journal entries; and (viii) designing and maintaining effective controls over information technology general controls for information systems that are relevant to the preparation of the consolidated financial statements, including program change management, user access, computer operations, and program development.

[0001628280-25-020355:auditors_report:17]
The principal considerations for our determination that performing procedures relating to the consolidated financial statements – impact of controls related to financial reporting is a critical audit matter are a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating audit evidence related to business processes that affect all of the Company’s significant accounts and disclosures. As disclosed by management, material weaknesses were identified related to this matter.

[0001628280-25-020355:auditors_report:18]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included, among others, evaluating and determining the nature and extent of audit procedures performed and evidence obtained that are responsive to the material weaknesses identified. These procedures also included (i) evaluating whether segregation of duties was maintained over the preparation and review of account reconciliations and recording of journal entries; (ii) testing the completeness and accuracy of period-end financial reporting, including the classification and presentation of accounts and disclosures; and (iii)  manually testing the completeness and accuracy of system reports or other information generated by the Company’s information systems.

[0001628280-25-020355:auditors_report:19]
Revenue Recognition – Impact of the Investigation

[0001628280-25-020355:auditors_report:20]
As described in Note 2 to the consolidated financial statements, in September 2024, an ad hoc committee of independent directors (the “Committee”) of the Company’s Board of Directors (the “Board”), under the direction of the Board, commenced an investigation (the “Investigation”) of the Company’s sales practices, including whether certain sales of products and subscriptions to channel partners and end users were subject to extra-contractual terms and conditions that impacted revenue recognition and other metrics, and if so, when senior Company personnel became aware of these issues. As a result of the Investigation, the Committee determined that certain sales, including sales to one of the Company’s largest channel partners, were subject to extra-contractual terms and conditions.  Accordingly, the Committee determined that the accounting for certain sales transactions was materially inaccurate and that, among other things, revenue was prematurely or incorrectly recognized in connection with financial statements prepared for certain periods. Total revenue for the year ended December 31, 2024 was $104 million. See also the “Restatement of Previously Issued Financial Statements” section of our report.

[0001628280-25-020355:auditors_report:21]
The principal considerations for our determination that performing procedures relating to revenue recognition – impact of the Investigation is a critical audit matter are (i) a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating audit evidence related to revenue recognition and (ii) the audit effort involved the use of professionals with specialized skill and knowledge. As disclosed by management, material weaknesses were identified related to this matter.

[0001628280-25-020355:auditors_report:22]
115

[0001628280-25-020355:auditors_report:23]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included, among others, evaluating and determining the nature and extent of audit procedures performed and evidence obtained that are responsive to the Investigation and the misstatements identified. These procedures also included (i) evaluating the impact of the material weaknesses related to the control environment, including the lack of a sufficient complement of personnel, risk assessment, and information and communication components of internal control, as well as  revenue control activities; (ii) evaluating the sufficiency of the Investigation conducted by the Committee of the Board; (iii) expanding the nature and extent of fraud inquiries performed with Company personnel; and (iv) considering the Investigation findings in assessing the risks associated with revenue recognition and designing incremental audit procedures to be performed. Incremental audit procedures performed included, for a sample of transactions, confirming terms and conditions of sales arrangements directly with customers, including performing alternative procedures when responses were not received; and evaluating the timing of revenue recognition and that revenue was recognized in the appropriate period. The incremental audit procedures also included testing the revenue-related journal entries recorded by Company personnel that engaged in misconduct; and testing the completeness and accuracy of the restatement adjustments. Professionals with specialized skill and knowledge were used to assist in evaluating the sufficiency of the Investigation conducted by the Committee of the Board.

[0001628280-25-020355:auditors_report:24]
/s/ PricewaterhouseCoopers LLP

[0001628280-25-020355:auditors_report:25]
Boston, Massachusetts

[0001628280-25-020355:auditors_report:26]
April 28, 2025

[0001628280-25-020355:auditors_report:27]
We have served as the Company’s auditor since 2015.

[0001628280-25-020355:auditors_report:28]
116

[0001628280-25-020355:auditors_report:29]
EVOLV TECHNOLOGIES HOLDINGS, INC.


## item_9a

[0001628280-25-020355:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0001628280-25-020355:item_9a:2]
Limitations on effectiveness of controls and procedures

[0001628280-25-020355:item_9a:3]
We maintain disclosure controls and procedures (as that term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) that are designed to provide reasonable assurance that information required to be disclosed in the reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms, and that such information is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate, to allow timely decisions regarding required disclosures. In designing and evaluating our disclosure controls and procedures, management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply judgment in evaluating the benefits of our controls and procedures relative to their costs.

[0001628280-25-020355:item_9a:4]
Evaluation of disclosure controls and procedures

[0001628280-25-020355:item_9a:5]
Our management, with the participation of our principal executive officer and principal financial officer, evaluated, as of the end of the period covered by this Annual Report on Form 10-K, the effectiveness of our disclosure controls and procedures (as that term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act). Based on that evaluation, our principal executive officer and principal financial officer concluded that our disclosure controls and procedures were not effective as of December 31, 2024, due to the material weaknesses in our internal control over financial reporting as described below.

[0001628280-25-020355:item_9a:6]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001628280-25-020355:item_9a:7]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as that term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our management, including our principal executive officer and principal financial officer, conducted an assessment as of December 31, 2024 of the effectiveness of our internal control over financial reporting based on the criteria set forth in “Internal Control–Integrated Framework” (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this assessment, management concluded that, as of December 31, 2024, our internal control over financial reporting was not effective due to the material weaknesses described below.

[0001628280-25-020355:item_9a:8]
A material weakness is a deficiency, or combination of deficiencies, in internal control over financial reporting, such that there is reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. The material weaknesses are as follows:

[0001628280-25-020355:item_9a:9]
•We did not design and maintain an effective control environment as we did not demonstrate a commitment to maintaining integrity and ethical values.  Specifically, we did not sufficiently promote, monitor or enforce appropriate accounting policies and procedures, thereby resulting in inappropriate recognition of revenue due to the failure to consider the impact of certain extra-contractual terms and conditions in sales agreements on the amount and timing of revenue to be recognized;

[0001628280-25-020355:item_9a:10]
•Additionally, we lacked a sufficient complement of personnel with an appropriate level of internal controls and accounting knowledge, training and experience commensurate with our financial reporting requirements. The limited personnel resulted in our inability to consistently establish appropriate authorities and responsibilities in pursuit of our financial reporting objectives, as demonstrated by, among other things, insufficient segregation of duties in our finance and accounting functions;

[0001628280-25-020355:item_9a:11]
•We did not design and maintain effective controls in response to the risks of material misstatement as changes to existing controls or the implementation of new controls were not sufficient to respond to changes to the risks of material misstatement to financial reporting;

[0001628280-25-020355:item_9a:12]
•We did not design and maintain effective controls for communicating and sharing information between the sales, accounting and finance departments. Specifically, the accounting and finance departments were not consistently provided the complete and adequate support, documentation, and information including the nature of relationships with certain customers to record revenue transactions within the financial statements timely, completely and accurately. Additionally, there have been instances in which indications of extra-contractual terms and conditions in sales arrangements were not disclosed to the Audit Committee of the Board and the external auditors;

[0001628280-25-020355:item_9a:13]
•We did not design and maintain effective controls over the period-end financial reporting process to achieve complete, accurate, and timely financial accounting, reporting and disclosures, including the classification of various accounts in the financial statements and the presentation and disclosure of items in the consolidated statements of cash flows;

[0001628280-25-020355:item_9a:14]
•We did not design and maintain effective controls to analyze, account for and disclose non-routine, unusual or complex transactions. Specifically, we did not design and maintain controls to timely analyze and account for debt modifications and extinguishments, convertible notes, warrant instruments, non-routine complex revenue transactions including the leasing of products and transfer of inventory for leased assets into property plant and equipment, merger transactions, and the accounting and valuation of earn out liabilities; and

[0001628280-25-020355:item_9a:15]
•We did not design and maintain formal accounting policies, procedures, and controls to achieve complete, accurate, and timely financial accounting, reporting and disclosures, including controls over the preparation and review of account reconciliations and journal entries, and control activities related to all significant accounts and disclosures.

[0001628280-25-020355:item_9a:16]
The material weaknesses in the control environment, including the lack of a sufficient complement of personnel, risk assessment, and information and communication components of internal control, as well as the material weakness related to revenue control activities resulted in the restatement of the consolidated financial statements for the annual periods ended December 31, 2022 and 2023, and the quarterly periods included in such fiscal years beginning with the second quarter of 2022, and for the quarterly periods as of and for the periods ended March 31, 2024 and June 30, 2024; as well as adjustments to the consolidated annual financial statements for the year-ended December 31, 2024, and the quarterly period ended September 30, 2024, that were recorded prior to the issuance of those financial statements.

[0001628280-25-020355:item_9a:17]
The material weaknesses related to the lack of sufficient complement of personnel with an appropriate level of internal controls and accounting knowledge, training and experience, risk assessment, lack of effective controls over the period-end financial reporting process, lack of effective controls related to non-routine, unusual or complex transactions, and the lack of effective control activities related to all significant accounts and disclosures resulted in:

[0001628280-25-020355:item_9a:18]
•the restatement of the Company’s financial statements as of and for the three and six months ended June 30, 2023;

[0001628280-25-020355:item_9a:19]
•the revision of the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022; and

[0001628280-25-020355:item_9a:20]
•adjustments and certain immaterial misstatements in the consolidated financial statements to prepaid and other current assets, accounts payable and accrued liabilities, long-term and short-term debt, convertible notes, contingent earn-out liabilities, change in fair value of contingent earn-out liability, equity, commission assets, contract assets, revenue, deferred revenue, accounts receivable, inventory, property plant and equipment, cost of sales, and various expense line items and related financial statement disclosures as of and for the years ended December 31, 2019, 2020, 2021, 2022, 2023, and 2024; as well as certain quarterly periods within those years.

[0001628280-25-020355:item_9a:21]
Additionally, the material weaknesses could result in a misstatement of the consolidated financial statements and disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0001628280-25-020355:item_9a:22]
•In addition to the foregoing, we did not design and maintain effective controls over information technology (“IT”) general controls for information systems that are relevant to the preparation of our consolidated financial statements, specifically, with respect to: (i) program change management controls for financial

[0001628280-25-020355:item_9a:23]
systems to ensure that IT program and data changes affecting financial IT applications and underlying accounting records are identified, tested, authorized, and implemented appropriately; (ii) user access controls to ensure appropriate segregation of duties and that adequately restrict user and privileged access to financial applications, programs, and data to appropriate company personnel; (iii) computer operations controls to ensure that critical batch jobs are monitored and data backups are authorized and monitored; and (iv) testing and approval controls for program development to ensure that new software development is aligned with business and IT requirements. These IT deficiencies did not result in a misstatement to the consolidated financial statements; however, the deficiencies, when aggregated, could impact maintaining effective segregation of duties, as well as the effectiveness of IT-dependent controls (such as automated controls that address the risk of material misstatement to one or more assertions, along with the IT controls and underlying data that support the effectiveness of system-generated data and reports) that could result in misstatements potentially impacting all financial statement accounts and disclosures that would not be prevented or detected. Accordingly, management has determined these deficiencies in the aggregate constitute a material weakness.

[0001628280-25-020355:item_9a:24]
Remediation Plan for the Material Weaknesses

[0001628280-25-020355:item_9a:25]
We continue to be focused on designing and implementing effective internal controls to improve our internal control over financial reporting and remediate the material weaknesses. Our efforts include a number of actions:

[0001628280-25-020355:item_9a:26]
•Our new leadership team, together with other senior executives, is committed to achieving and maintaining a strong control environment, high ethical standards, and financial reporting integrity.  This commitment will be communicated to and reinforced with every Evolv employee and external stakeholders;

[0001628280-25-020355:item_9a:27]
•The development and communication of a framework that will serve as a set of guiding principles emphasizing our commitment to accounting and financial reporting integrity as well as transparency and robust and complete communications with, and disclosures to, the Board of Directors and external auditors;

[0001628280-25-020355:item_9a:28]
•We continue to reinforce the importance of communication between the sales, accounting and finance departments regarding key terms of, and changes or modifications to, sales transactions, including by establishing controls requiring finance department approval of certain non-standard terms;

[0001628280-25-020355:item_9a:29]
•We are designing a new deal review policy and process, including enhanced certification by the Sales team of terms and conditions, to ensure proper communication to the accounting and finance departments to allow for an effective review of the accounting for the transactions;

[0001628280-25-020355:item_9a:30]
•We are implementing a new channel partner program intended to strengthen compliance with contractual terms and conditions, as well as to enhance controls over related communication and sharing of information with the accounting and finance departments;

[0001628280-25-020355:item_9a:31]
•We have reviewed and updated our Audit Committee and Compliance Committee Charters to ensure enhanced risk oversight and adherence to our ethical values;

[0001628280-25-020355:item_9a:32]
•We have, and will continue to hire, additional accounting personnel to bolster our reporting, technical accounting, and internal control capabilities. Additionally, we are in the process of designing and implementing controls to formalize roles and review responsibilities to align with our team’s skills and experience and designing and implementing controls over segregation of duties;

[0001628280-25-020355:item_9a:33]
•We have enhanced the competencies of our accounting function including the hiring of a new Chief Accounting Officer ("CAO") in January 2025. Our CAO has extensive public company experience and will strengthen our internal accounting team by providing technical accounting oversight over our financial reporting and disclosure processes and controls. Additionally, we hired a new Chief Revenue Officer in February 2025 to provide leadership and accountability over our sales agreement and revenue recognition accounting processes;

[0001628280-25-020355:item_9a:34]
•We have launched additional trainings to the Finance and Sales teams around the responsibility of preventing financial misconduct and commitment to maintaining integrity and ethical values. We intend to launch additional company-wide trainings related to our Code of Business Conduct to promote an ethical culture, further educate employees on Company policies and align with public company standards;

[0001628280-25-020355:item_9a:35]
•We have designed and implemented additional review and training procedures within Evolv's accounting and finance functions to enhance knowledge and understanding of internal control over financial reporting;

[0001628280-25-020355:item_9a:36]
•We have performed, and will continue to perform, a financial statement risk assessment in order to identify material financial statement line items for which key controls are needed in order to ensure complete and accurate financial reporting. Additionally, we have engaged outside consultants to assist with the design and implementation of control activities resulting from the aforementioned risk assessment;

[0001628280-25-020355:item_9a:37]
•We have engaged a large national advisory firm as of January 2025 to assist in the design and implementation of control activities across the business processes that support the Company’s significant accounts and disclosures;

[0001628280-25-020355:item_9a:38]
•Over the past year, we implemented controls related to, among other items, (i) the period-end financial reporting process and classification of various accounts in our consolidated financial statements, including the presentation and disclosure of items in the consolidated statements of cash flows, (ii) timely identification and accounting for non-routine, unusual and complex transactions, including controls over the preparation and review of accounting memoranda addressing these matters, (iii) revenue recognition, including non-routine complex revenue transactions that may also include the leasing of products and the recording of revenue transactions in the appropriate period, (iv) completeness and accuracy of accounts payable and accrued liabilities, and (v) completeness, accuracy, valuation, and classification of cash equivalents and marketable securities. We are in the process of designing and implementing controls over the preparation and review of journal entries and account reconciliations to ensure proper segregation of duties;

[0001628280-25-020355:item_9a:39]
•We are in the process of creating and maintaining formal accounting policies, procedures and controls to achieve complete, accurate and timely financial accounting, reporting and disclosures;

[0001628280-25-020355:item_9a:40]
•We are in the process of designing and implementing information technology general controls for all relevant information systems, including controls over program change management, the review, approval and update of user access rights and privileges, controls over batch jobs and data backups, and program development approvals and testing for new systems;

[0001628280-25-020355:item_9a:41]
• We continue to make investments in our technology platforms including enhancing our financial and human resources systems to further automate processes and reduce the risk of manual errors; and

[0001628280-25-020355:item_9a:42]
•We are continuing to assess the need for new systems for which IT general controls will be designed and implemented.

[0001628280-25-020355:item_9a:43]
The process of designing and maintaining effective internal control over financial reporting is a continuous effort that requires management to anticipate and react to changes in our business, economic, and regulatory environments and to expend significant resources. As we continue to evaluate our internal control over financial reporting, we may take additional actions to remediate the material weaknesses or modify the remediation actions described above.

[0001628280-25-020355:item_9a:44]
While we continue to devote significant time and attention to these remediation efforts, the material weaknesses will not be considered remediated until management completes the design and implementation of the actions described above and the controls operate for a sufficient period of time, and management has concluded, through testing, that these controls are effective.

[0001628280-25-020355:item_9a:45]
Changes in Internal Control over Financial Reporting

[0001628280-25-020355:item_9a:46]
There were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended December 31, 2024 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
