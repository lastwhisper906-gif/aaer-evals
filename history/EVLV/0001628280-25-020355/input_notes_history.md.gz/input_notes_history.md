# EVLV note change history — 0001628280-24-036182 → 0001628280-25-020353


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-04-28):
[0001628280-25-020353:note_history:1]
In the ordinary course of business, the Company provides indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. Based on historical experience and evaluation of the agreements, we do not believe that any payments related to our indemnities will have a material impact on our financial condition or results of operations.
  (was, 2024-08-08, similarity 0.8115):
[0001628280-24-036182:note_history:1]
In the ordinary course of business, the Company provides indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. The Company has not incurred or accrued for any material costs as a result of such indemnifications in its condensed consolidated financial statements as of June 30, 2024 or December 31, 2023.

- changed (2025-04-28):
[0001628280-25-020353:note_history:2]
We are from time to time subject to various claims, lawsuits, government and regulatory examinations, inquiries, information requests and investigations, and other legal and administrative proceedings arising in the ordinary course of business. The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. Except for the regulatory matters discussed below, based upon information presently known to management, the Company has not accrued a loss for any other legal matters, as a loss is not probable and reasonably estimable. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.
  (was, 2024-08-08, similarity 0.8933):
[0001628280-24-036182:note_history:2]
The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. Except for the regulatory matters discussed below, based upon information presently known to management, the Company has not accrued a loss for any other legal matters, as a loss is not probable and reasonably estimable. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

- added (2025-04-28):
[0001628280-25-020353:note_history:3]
General Litigation

- added (2025-04-28):
[0001628280-25-020353:note_history:4]
On March 25, 2024, a putative class action lawsuit was filed against the Company in the United States District Court for the District of Massachusetts (the “Class Action”). The Class Action is a consolidation of two lawsuits, the second of which was filed on November 1, 2024, filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees.

- added (2025-04-28):
[0001628280-25-020353:note_history:5]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the anticipated motion to dismiss in the Class Action. On March 28, 2025, we filed a motion to dismiss the claims.

- added (2025-04-28):
[0001628280-25-020353:note_history:6]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Delaware Derivative Action”). The Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. Although the Delaware Derivative Action is in the early stages, we anticipate filing a motion to dismiss the claims if the case moves forward.

- added (2025-04-28):
[0001628280-25-020353:note_history:7]
We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. While a loss from this litigation is reasonably possible, we cannot reasonably estimate a range of possible losses at this time, as the proceedings remain in the early stages, alleged damages have not been specified, there is uncertainty as to the outcome of our anticipated motion to dismiss in the Class Action which was filed on March 28, 2025, there is uncertainty as to the likelihood of the proposed class in the Class Action being certified or the ultimate size of any class if certified, there is uncertainty as to the final complaint in the Massachusetts Derivative Action, as the plaintiff will not identify an operative complaint or file a consolidated complaint until disposition of our anticipated motion to dismiss in the Class Action, and there are significant factual and legal issues to be resolved in both the securities and derivative actions. For these reasons, we have not recorded a loss contingency liability for the above litigation as of September 30, 2024.

- added (2025-04-28):
[0001628280-25-020353:note_history:8]
As previously disclosed, on October 12, 2023, the Company announced that the U.S. Federal Trade Commission (the “FTC”) had requested information about certain aspects of its marketing practices. The Company reached a settlement with the FTC and on December 5, 2024, a Stipulated Order for Permanent Injunction and Other Relief (the “Order”) was entered in the United States District Court for the District of Massachusetts Eastern Division. The Order (i) required that the Company permit a limited cohort of school customers to cancel their contracts, (ii) required that the Company take certain compliance actions and meet record keeping obligations, and (iii) enjoined the Company from making misleading or unsubstantiated marketing claims. The Order did not include any monetary relief. The period during which eligible

- added (2025-04-28):
[0001628280-25-020353:note_history:9]
customers may cancel closed on March 30, 2025. Any inability to adequately comply with the terms of the Order could result in enforcement actions or penalties imposed by the FTC.

- added (2025-04-28):
[0001628280-25-020353:note_history:10]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, 5 customers representing 24 Evolv Express units elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the three and nine months ended September 30, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and nine months ended September 30, 2024, as revenue will continue to be recognized on these deals through the cancellation dates of each contract, all of which are in June 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of September 30, 2024 were impacted by the cancellations.

- added (2025-04-28):
[0001628280-25-020353:note_history:11]
As of June 30, 2024, the Company had accrued $1.1 million as an estimated liability related to the FTC matter, which was recorded in other accrued liabilities in the condensed consolidated balance sheets and the associated expense was recorded in general and administrative expense in the condensed consolidated statements of operations. As the settlement of these matters occurred subsequent to September 30, 2024, but prior to our filing of this Quarterly Report on Form 10-Q, the Company accounted for the transaction as a recognized subsequent event for the three months ended September 30, 2024. As the settlement included no monetary fines or penalties, the loss reserve was reversed during the three months ended September 30, 2024.

- added (2025-04-28):
[0001628280-25-020353:note_history:12]
As previously reported, the Company self-reported to the Division of Enforcement of the Securities and Exchange Commission ("SEC") the Investigation. The Company has since received requests for documents and information from the SEC relating to this matter. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("USAO SDNY") relating to these same issues, and has since received additional requests for documents and information relating to this matter. The Company is cooperating with these investigations.

- added (2025-04-28):
[0001628280-25-020353:note_history:13]
As previously disclosed, in February 2024, the Company received a subpoena from the Division of Enforcement of the SEC, requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation.

- added (2025-04-28):
[0001628280-25-020353:note_history:14]
Any resolution or litigation with the SEC, DOJ, or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to SEC or DOJ matters. The Company's defense counsel costs in connection with the securities litigation and the related SEC and DOJ matters are being covered under its directors and officers insurance policies subject to a typical reservation of rights. The Company has met the retention limits under these policies with respect to these matters and currently expects these policies will provide coverage for certain costs related to these matters, including certain expenses that have previously been paid. However, the Company cannot provide any assurance that costs related to these matters will not exceed the

- added (2025-04-28):
[0001628280-25-020353:note_history:15]
limits of its insurance policies, that such claims are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.

- added (2025-04-28):
[0001628280-25-020353:note_history:16]
Contract manufacturers

- added (2025-04-28):
[0001628280-25-020353:note_history:17]
The Company generally contracts with its contract manufacturer, Columbia Tech, on a cancellable, purchase-order basis. The Company has a contract in the normal course of business with Columbia Tech to provide manufacturing services for the Company's equipment sold or leased to customers. While these contracts are cancellable by the Company upon prior notice, payments due upon cancellation consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. These payments are not determinable, but could result in a material purchase commitment if the Company were to cancel their open purchase orders.

- removed (2025-04-28):
[0001628280-24-036182:note_history:18]
We are from time to time subject to various claims, lawsuits, and other legal and administrative proceedings arising in the ordinary course of business.

- removed (2025-04-28):
[0001628280-24-036182:note_history:19]
In March 2024, an Evolv shareholder filed in the U.S. District Court for the District of Massachusetts a putative class action lawsuit, captioned Raby v. Evolv Technologies Holdings, Inc., et al. case number 1:24-cv-10761, alleging that Evolv and certain of its current and former executives and other individuals violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 based on alleged misstatements concerning the Company’s products. This litigation is in the preliminary stages, and the outcome of any complex legal proceeding is inherently unpredictable and subject to significant uncertainties. The Company intends to vigorously defend itself in this matter.

- removed (2025-04-28):
[0001628280-24-036182:note_history:20]
In the ordinary course of business, the Company is subject to regulatory and governmental examinations, information gathering requests, inquiries, and investigations. The U.S. Federal Trade Commission (“FTC”) has requested information about certain aspects of the Company's marketing practices. The Company is cooperating with the investigation and has provided documentation and information responsive to the FTC inquiry. Further, in February 2024, we received a subpoena from the SEC, Division of Enforcement, requesting that we produce certain documents and information. We are cooperating and intend to continue to cooperate with the SEC's investigation.

- removed (2025-04-28):
[0001628280-24-036182:note_history:21]
Any resolution or litigation with the FTC, the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate. As of June 30, 2024, we have accrued $1.1 million for such matters. These amounts were recorded in other accrued liabilities in the condensed consolidated balance sheets and the associated expenses were recorded in general and administrative expenses in the condensed consolidated statements of operations. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations. Actual loss can be significantly greater or less than our estimated accrual. Legal fees incurred in connection with ongoing legal matters are considered period costs and are expensed as incurred.

- removed (2025-04-28):
[0001628280-24-036182:note_history:22]
We can offer no assurances as to the outcome of these investigations or their potential effect, if any, on us or our results of operations. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-04-28):
[0001628280-25-020353:note_history:23]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company designed to transform human security to make a safer, faster, and better experience for the world's most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics.

- added (2025-04-28):
[0001628280-25-020353:note_history:24]
The Company announced in the third quarter of 2024 the launch of a new product offering, Evolv eXpedite™, an autonomous AI-based weapons detection system for bags. This new offering, as well as existing products such as Evolv Express®, are designed to be integrated layers for detection as part of a unified Evolv Safer Experience System™. These products and their associated services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

- changed (2025-04-28):
[0001628280-25-020353:note_history:25]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).
  (was, 2024-08-08, similarity 0.9989):
[0001628280-24-036182:note_history:25]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly-owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).

- added (2025-04-28):
[0001628280-25-020353:note_history:26]
Liquidity and capital resources

- added (2025-04-28):
[0001628280-25-020353:note_history:27]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of September 30, 2024, the Company had $56.0 million in cash, cash equivalents, and marketable securities, and as of March 31, 2025, the Company had $35.0 million in cash, cash equivalents, and marketable securities. The Company incurred a net loss of $38.3 million and $90.9 million for the nine months ended September 30, 2024 and 2023, respectively. The Company incurred cash outflows from operating activities of $34.1 million and $6.7 million during the nine months ended September 30, 2024 and 2023, respectively. The Company expects to continue to generate losses for the foreseeable future.

- added (2025-04-28):
[0001628280-25-020353:note_history:28]
The Company maintains substantially all of its cash, cash equivalents, and marketable securities in accounts with U.S. and multi-national financial institutions and its cash deposits at these institutions exceed Federal Deposit Insurance Corporation insured limits. The Company does not believe it is exposed to any unusual credit risk or deposit concentration risk beyond the ordinary credit risk associated with commercial banking relationships.

- added (2025-04-28):
[0001628280-25-020353:note_history:29]
The Company expects its cash, cash equivalents, and marketable securities of $56.0 million as of December 31, 2024, together with cash it expects to generate from future operations, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company

- added (2025-04-28):
[0001628280-25-020353:note_history:30]
expects to continue to strategically and carefully invest in various areas of the business to support that growth. The Company may require additional capital to respond to expected growth in the demand for equipment to support its “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances.  To the extent that the Company's projected revenue growth does not materialize, the Company has established plans to preserve existing cash liquidity, which includes additional reductions to operating expenses and capital expenditures.

- added (2025-04-28):
[0001628280-25-020353:note_history:31]
Although not required to fund ongoing operations, in an improving interest rate environment the Company may choose to engage in debt financings or enter into credit facilities for other strategic reasons. If the Company is unable to obtain adequate financing or financing on terms satisfactory to it, when it requires it, the Company's ability to continue to grow or support the business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, tariffs, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing the Company's ability to access capital. If the Company is unable to raise additional funds when or on the terms desired, its business, financial condition and results of operations could be adversely affected.

- added (2025-04-28):
[0001628280-25-020353:note_history:32]
Additionally, there continues to be significant uncertainty regarding recent changes and potential future developments related to increased trade restrictions, tariffs or taxes on imports or exports relating to countries where we source or sell materials or products. The exact magnitude of any potential impact remains uncertain, as there may be further changes to tariffs and policies and, consequently, potential increased tension between the U.S. and targeted countries, and the Company's financial condition and results of operations could be adversely affected.

- added (2025-04-28):
[0001628280-25-020353:note_history:33]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2024, and for the three and nine months ended September 30, 2024 and 2023 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2023 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2024 and the results of its operations for the three and nine months ended September 30, 2024 and 2023 and cash flows for the nine months ended September 30, 2024 and 2023. The results for the three and nine months ended September 30, 2024 are not necessarily indicative of results to be expected for the year ending December 31, 2024, any other interim periods, or any future year or period.

- removed (2025-04-28):
[0001628280-24-036182:note_history:34]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company pioneering AI-based screening designed to help create safer experiences, with key market categories that include education, healthcare, sports, and live entertainment.

- removed (2025-04-28):
[0001628280-24-036182:note_history:35]
The Company's solutions combine proprietary software and hardware, delivered as a long-term Software-as-a-Service subscription model.  Its flagship product, Evolv Express®, uses advanced sensors, artificial intelligence powered software, and cloud services to reliably detect firearms, improvised explosives, and certain types of knives while ignoring many harmless items such as cell phones and keys.  These solutions and services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

- removed (2025-04-28):
[0001628280-24-036182:note_history:36]
The accompanying unaudited condensed consolidated financial statements as of June 30, 2024, and for the three and six months ended June 30, 2024 and 2023 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2023 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of June 30, 2024 and the results of its operations for the three and six months ended June 30, 2024 and 2023 and cash flows for the six months ended June 30, 2024 and 2023. The results for the three and six months ended June 30, 2024 are not necessarily indicative of results to be expected for the year ending December 31, 2024, any other interim periods, or any future year or period.

- removed (2025-04-28):
[0001628280-24-036182:note_history:37]
Reclassifications

- removed (2025-04-28):
[0001628280-24-036182:note_history:38]
During the year ended December 31, 2023, the Company began classifying revenue from professional services, which includes installation, training, and event support, as well as other one-time revenue, within license fee and other revenue on the consolidated statements of operations and comprehensive loss, whereas the revenue for these services has previously been included in service revenue. Correspondingly, the Company began classifying costs associated with professional services within cost of license fee and other revenue, whereas these costs were previously included in cost of service revenue. These reclassifications were made to align the presentation of professional services with the Company's internal reporting and analysis. The reclassifications did not impact total revenue or total cost of revenue for any period. Prior year amounts included in this Quarterly Report on Form 10-Q have been reclassified to conform to the current presentation.

- removed (2025-04-28):
[0001628280-24-036182:note_history:39]
For the three and six months ended June 30, 2023, the reclassifications resulted in an increase in license fee and other revenue of $0.7 million and $1.3 million, respectively, and a corresponding decrease in service revenue, as well as an increase in cost of license fee and other revenue of $0.3 million and $0.6 million, respectively, and a corresponding decrease in cost of service revenue.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-04-28):
[0001628280-25-020353:note_history:40]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2023, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2023. Other than "Contract Balances from Contracts with Customers", "Commissions" and "Consignment Sales" discussed below, there have been no material changes to the Company’s significant accounting policies during the nine months ended September 30, 2024.
  (was, 2024-08-08, similarity 0.8385):
[0001628280-24-036182:note_history:40]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2023, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2023. There have been no material changes to the Company’s significant accounting policies during the six months ended June 30, 2024.

- added (2025-04-28):
[0001628280-25-020353:note_history:41]
Contract Balances from Contracts with Customers

- added (2025-04-28):
[0001628280-25-020353:note_history:42]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent.

- added (2025-04-28):
[0001628280-25-020353:note_history:43]
Commissions

- added (2025-04-28):
[0001628280-25-020353:note_history:44]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract.

- added (2025-04-28):
[0001628280-25-020353:note_history:45]
Consignment Sales

- added (2025-04-28):
[0001628280-25-020353:note_history:46]
As discussed in Note 2, Restatement of Quarterly Financial Information, the Company entered into certain in-substance consignment arrangements with reseller partners for which product revenue has been recognized at the point in time when control transferred to the customer and the customer has an unconditional obligation to pay for the goods transferred, which was deemed to occur upon installation at the end-user site.

- added (2025-04-28):
[0001628280-25-020353:note_history:47]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures.” The updated accounting guidance requires a public entity to disclose significant segment expenses and other segment items on an annual and interim basis and to provide in interim periods all disclosures about a reportable segment’s profit or loss and assets that are currently required annually for entities with more than one reportable segment. Public entities with a single reporting segment are required to provide both the new disclosures and all of the existing disclosures required under ASC 280. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Retrospective application is required and early adoption is permitted. The Company will adopt this guidance retrospectively effective December 31, 2024. Since this new ASU addresses only disclosures, the adoption of this ASU will not have any material effects on its financial condition, results of operations, or cash flows.

- changed (2025-04-28):
[0001628280-25-020353:note_history:48]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity should apply the amendments in ASU 2023-09 prospectively to all annual periods beginning after December 15, 2024. The
  (was, 2024-08-08, similarity 0.8947):
[0001628280-24-036182:note_history:48]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity should apply the amendments in ASU 2023-09 prospectively to all annual periods beginning after December 15, 2024. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

- added (2025-04-28):
[0001628280-25-020353:note_history:49]
Company determined that although the ASU is applicable, it addresses disclosures only, and as such will not have any material effects on its financial condition, results of operations, or cash flows.

- added (2025-04-28):
[0001628280-25-020353:note_history:50]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses.”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the condensed consolidated financial statements.

- removed (2025-04-28):
[0001628280-24-036182:note_history:51]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures.” The updated accounting guidance requires enhanced reportable segment disclosures, primarily related to significant segment expenses which are regularly provided to the chief operating decision maker. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Retrospective application is required and early adoption is permitted. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-04-28):
[0001628280-25-020353:note_history:52]
Long-term Debt
In December 2022, the Company entered into a loan and security agreement (the “2022 SVB Credit Agreement”) with Silicon Valley Bank (“SVB”) in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. Subsequently, on March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. During the nine months ended September 30, 2023, the Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs. The Company had no long-term debt as of September 30, 2024 and December 31, 2023.
  (was, 2024-08-08, similarity 0.9014):
[0001628280-24-036182:note_history:52]
Long-term Debt
In December 2022, the Company entered into a loan and security agreement (the “2022 SVB Credit Agreement”) with Silicon Valley Bank (“SVB”) in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. Subsequently, on March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. During the six months ended June 30, 2023, the Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs. The Company had no long-term debt as of June 30, 2024 and December 31, 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-04-28):
[0001628280-25-020353:note_history:53]
Marketable Securities
Marketable securities as of September 30, 2024 and December 31, 2023 consisted of the following:
  (was, 2024-08-08, similarity 0.9479):
[0001628280-24-036182:note_history:53]
Marketable Securities
Marketable securities as of June 30, 2024 and December 31, 2023 consisted of the following:

- changed (2025-04-28):
[0001628280-25-020353:note_history:54]
|  | September 30, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 9,960 |  |  | $ | — |  |  | $ | 9,960 |  |
| Total marketable securities | $ | 9,960 |  |  | $ | — |  |  | $ | 9,960 |  |
  (was, 2024-08-08, similarity 0.9681):
[0001628280-24-036182:note_history:54]
|  | June 30, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 20,757 |  |  | $ | — |  |  | $ | 20,757 |  |
| Total marketable securities | $ | 20,757 |  |  | $ | — |  |  | $ | 20,757 |  |

- added (2025-04-28):
[0001628280-25-020353:note_history:55]
Marketable securities at September 30, 2024 and December 31, 2023 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and nine months ended September 30, 2024 and 2023. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive (loss) income.

- removed (2025-04-28):
[0001628280-24-036182:note_history:56]
Marketable securities at June 30, 2024 and December 31, 2023 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and six months ended June 30, 2024 and 2023. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive income.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-04-28):
[0001628280-25-020353:note_history:57]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended September 30, 2024 and 2023, revenue from Motorola's distributor services was $2.2 million and $1.7 million, respectively. During the nine months ended September 30, 2024 and 2023, revenue from Motorola's distributor services was $6.1 million and $7.9 million, respectively, which was a result of the Company's transition to pure subscription sales and sales under the distributor licensing model during this period. As of September 30, 2024 and December 31, 2023, accounts receivable related to Motorola’s distributor services was $1.1 million and $1.6 million, respectively.
  (was, 2024-08-08, similarity 0.7432):
[0001628280-24-036182:note_history:57]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended June 30, 2024 and 2023, revenue from Motorola's distributor services was $2.0 million and $2.9 million, respectively. During the six months ended June 30, 2024 and 2023, revenue from Motorola's distributor services was $3.9 million and $6.2 million, respectively. As of June 30, 2024 and December 31, 2023, accounts receivable related to Motorola’s distributor services was $2.9 million and $1.2 million, respectively.

- changed (2025-04-28):
[0001628280-25-020353:note_history:58]
Reseller Agreement with Stanley Black & Decker
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB (“Securitas”) in 2023. Securitas, directly or through its affiliates, resells the Company's products. Effective in the first quarter of 2024, while the reseller agreement is still in effect, Securitas is no longer considered a related party. During the three and nine months ended September 30, 2023, revenue from Securitas' reseller services was $0.4 million and $1.3 million, respectively. As of December 31, 2023, accounts receivable related to Securitas' reseller services was $0.6 million.
  (was, 2024-08-08, similarity 0.7839):
[0001628280-24-036182:note_history:58]
Reseller Agreement with Stanley Black & Decker
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB (“Securitas”) in 2023. Securitas, directly or through its affiliates, resells the Company's products. Effective in the first quarter of 2024, while the reseller agreement is still in effect, Securitas is no longer considered a related party. During the three and six months ended June 30, 2023, revenue from Securitas' reseller services was $0.5 million and $0.9 million, respectively. As of December 31, 2023, accounts receivable related to Securitas' reseller services was $0.6 million.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-04-28):
[0001628280-25-020353:note_history:59]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Product revenue | $ | 1,344 |  |  | $ | 3,456 |  |  | $ | 4,789 |  |  | $ | 20,920 |  |
| Subscription revenue | 17,909 |  |  | 9,858 |  |  | 47,783 |  |  | 23,733 |  |
| Service revenue | 6,085 |  |  | 4,345 |  |  | 16,903 |  |  | 10,750 |  |
| License fees | 1,606 |  |  | 2,012 |  |  | 4,047 |  |  | 2,012 |  |
| Professional services and other revenue | 416 |  |  | 290 |  |  | 1,243 |  |  | 1,570 |  |
| Total revenue | $ | 27,360 |  |  | $ | 19,961 |  |  | $ | 74,765 |  |  | $ | 58,985 |  |

- removed (2025-04-28):
[0001628280-24-036182:note_history:60]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Product revenue | $ | 2,044 |  |  | $ | 7,243 |  |  | $ | 2,647 |  |  | $ | 15,997 |  |
| Subscription revenue | 15,903 |  |  | 7,964 |  |  | 30,406 |  |  | 14,430 |  |
| Service revenue | 5,553 |  |  | 3,905 |  |  | 10,937 |  |  | 6,691 |  |
| License fees | 1,717 |  |  | — |  |  | 2,441 |  |  | — |  |
| Professional services and other revenue | 323 |  |  | 713 |  |  | 777 |  |  | 1,288 |  |
| Total revenue | $ | 25,540 |  |  | $ | 19,825 |  |  | $ | 47,208 |  |  | $ | 38,406 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2025-04-28):
[0001628280-25-020353:note_history:61]
Contract Balances from Contracts with Customers

- added (2025-04-28):
[0001628280-25-020353:note_history:62]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-04-28):
[0001628280-25-020353:note_history:63]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after control passes to the customer. Revenue is recognized net of sales tax.
  (was, 2024-08-08, similarity 0.9793):
[0001628280-24-036182:note_history:63]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

- changed (2025-04-28):
[0001628280-25-020353:note_history:64]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2024:
  (was, 2024-08-08, similarity 0.9705):
[0001628280-24-036182:note_history:64]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of June 30, 2024:

- changed (2025-04-28):
[0001628280-25-020353:note_history:65]
The amount of minimum future leases is based on expected income recognition. As of September 30, 2024, future minimum payments on noncancelable leases are as follows (in thousands):
  (was, 2024-08-08, similarity 0.9681):
[0001628280-24-036182:note_history:65]
The amount of minimum future leases is based on expected income recognition. As of June 30, 2024, future minimum payments on noncancelable leases are as follows (in thousands):

- changed (2025-04-28):
[0001628280-25-020353:note_history:66]
| Year Ending December 31: |  |
| 2024 (three months remaining) | $ | 18,703 |  |
| 2025 | 70,166 |  |
| 2026 | 58,474 |  |
| 2027 | 38,816 |  |
| 2028 | 12,430 |  |
| Thereafter | 490 |  |
|  | $ | 199,079 |  |
  (was, 2024-08-08, similarity 0.9737):
[0001628280-24-036182:note_history:66]
| Year Ending December 31: |  |
| 2024 (six months remaining) | $ | 34,992 |  |
| 2025 | 63,964 |  |
| 2026 | 52,682 |  |
| 2027 | 32,219 |  |
| 2028 | 7,133 |  |
| Thereafter | 134 |  |
|  | $ | 191,124 |  |

- changed (2025-04-28):
[0001628280-25-020353:note_history:67]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2024 and December 31, 2023, the Company had less than $0.7 million and $1.4 million (as restated) in current portion of contract assets and $0.7 million and $1.0 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2024-08-08, similarity 0.936):
[0001628280-24-036182:note_history:67]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of June 30, 2024 and December 31, 2023, the Company had $1.7 million and $3.7 million in current portion of contract assets and $0.1 million and $0.5 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2025-04-28):
[0001628280-25-020353:note_history:68]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $10.1 million and $40.8 million during the three and nine months ended September 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance. The Company recognized revenue (as restated) of $3.6 million and $15.5 million during the three and nine months ended September 30, 2023, respectively, that was included in the December 31, 2022 deferred revenue balance.
  (was, 2024-08-08, similarity 0.9447):
[0001628280-24-036182:note_history:68]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $14.1 million and $31.4 million during the three and six months ended June 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance. The Company recognized revenue of $5.3 million and $12.1 million during the three and six months ended June 30, 2023, respectively, that was included in the December 31, 2022 deferred revenue balance.

- changed (2025-04-28):
[0001628280-25-020353:note_history:69]
| Balance at December 31, 2023 (restated) | $ | 71,957 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance (restated) | (40,780) |  |
| Revenue deferred (restated) | 54,339 |  |
| Balance at September 30, 2024 | $ | 85,516 |  |
  (was, 2024-08-08, similarity 0.8981):
[0001628280-24-036182:note_history:69]
| Balance at December 31, 2023 | $ | 71,490 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (31,445) |  |
| Revenue deferred | 39,778 |  |
| Balance at June 30, 2024 | $ | 79,823 |  |

- added (2025-04-28):
[0001628280-25-020353:note_history:70]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Interest income on lease receivables | $ | 40 |  |  | $ | 49 |  |  | $ | 123 |  |  | $ | 153 |  |
| Lease income - operating leases | 17,909 |  |  | 9,858 |  |  | 47,783 |  |  | 23,733 |  |
| Total lease revenue | $ | 17,949 |  |  | $ | 9,907 |  |  | $ | 47,906 |  |  | $ | 23,886 |  |

- changed (2025-04-28):
[0001628280-25-020353:note_history:71]
Interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.5 million and $0.3 million during the three months ended September 30, 2024 and 2023, respectively. Revenue related to leases entered into with related parties were $1.1 million and $0.7 million (restated) during the nine months ended September 30, 2024 and 2023, respectively.
  (was, 2024-08-08, similarity 0.9079):
[0001628280-24-036182:note_history:71]
Interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.3 million and less than $0.1 million during the three months ended June 30, 2024 and June 30, 2023, respectively. Revenue related to leases entered into with related parties were $0.6 million and $0.2 million during the six months ended June 30, 2024 and June 30, 2023, respectively.

- added (2025-04-28):
[0001628280-25-020353:note_history:72]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Product revenue | $ | 1,344 |  |  | $ | 3,456 |  |  | $ | 4,789 |  |  | $ | 20,920 |  |
| Subscription revenue | 17,909 |  |  | 9,858 |  |  | 47,783 |  |  | 23,733 |  |
| Service revenue | 6,085 |  |  | 4,345 |  |  | 16,903 |  |  | 10,750 |  |
| License fees | 1,606 |  |  | 2,012 |  |  | 4,047 |  |  | 2,012 |  |
| Professional services and other revenue | 416 |  |  | 290 |  |  | 1,243 |  |  | 1,570 |  |
| Total revenue | $ | 27,360 |  |  | $ | 19,961 |  |  | $ | 74,765 |  |  | $ | 58,985 |  |

- changed (2025-04-28):
[0001628280-25-020353:note_history:73]
Commissions
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had total deferred assets related to commissions of $12.6 million and $11.6 million (as restated) as of September 30, 2024 and December 31, 2023, respectively. During the three months ended September 30, 2024 and 2023, the Company recognized commission expense of $1.4 million and $1.3 million (as restated), respectively. During the nine months ended September 30, 2024 and 2023, the Company recognized commission expense of $4.3 million and $4.2 million  (as restated), respectively.
  (was, 2024-08-08, similarity 0.9182):
[0001628280-24-036182:note_history:73]
Commissions
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $11.9 million and $11.4 million as of June 30, 2024 and December 31, 2023, respectively. During the three months ended June 30, 2024 and 2023, the Company recognized commission expense of $1.6 million and $1.5 million, respectively. During the six months ended June 30, 2024 and 2023, the Company recognized commission expense of $3.0 million and $3.1 million, respectively.

- removed (2025-04-28):
[0001628280-24-036182:note_history:74]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest income on lease receivables | $ | 41 |  |  | $ | 51 |  |  | $ | 83 |  |  | $ | 104 |  |
| Lease income - operating leases | 15,903 |  |  | 7,964 |  |  | 30,406 |  |  | 14,430 |  |
| Total lease revenue | $ | 15,944 |  |  | $ | 8,015 |  |  | $ | 30,489 |  |  | $ | 14,534 |  |

- removed (2025-04-28):
[0001628280-24-036182:note_history:75]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Product revenue | $ | 2,044 |  |  | $ | 7,243 |  |  | $ | 2,647 |  |  | $ | 15,997 |  |
| Subscription revenue | 15,903 |  |  | 7,964 |  |  | 30,406 |  |  | 14,430 |  |
| Service revenue | 5,553 |  |  | 3,905 |  |  | 10,937 |  |  | 6,691 |  |
| License fees | 1,717 |  |  | — |  |  | 2,441 |  |  | — |  |
| Professional services and other revenue | 323 |  |  | 713 |  |  | 777 |  |  | 1,288 |  |
| Total revenue | $ | 25,540 |  |  | $ | 19,825 |  |  | $ | 47,208 |  |  | $ | 38,406 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-04-28):
[0001628280-25-020353:note_history:76]
Subsequent Events
Resolution of FTC Inquiry

- added (2025-04-28):
[0001628280-25-020353:note_history:77]
As discussed above in Note 16, Commitments and Contingencies, the Company reached a settlement with the FTC and on December 5, 2024, the Order was entered in the United States District Court for the District of Massachusetts Eastern Division. The resolution did not involve any financial penalties or monetary relief. As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, a total of 5 customers representing 24 Evolv Express units elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the three and nine months ended September 30, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and nine months ended September 30, 2024, as revenue will continue to be recognized on these deals through the cancellation dates of each contract, all of which are in June 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of September 30, 2024 were impacted by the cancellations.

- added (2025-04-28):
[0001628280-25-020353:note_history:78]
As of June 30, 2024, the Company had accrued $1.1 million as an estimated liability related to the FTC matter, which was recorded in other accrued liabilities in the condensed consolidated balance sheets and the associated expense was recorded in general and administrative expense in the condensed consolidated statements of operations. As the settlement of these matters occurred subsequent to the September 30, 2024, but prior to our filing of this Quarterly Report on Form 10-Q, the Company accounted for the transaction as a recognized subsequent event for the three months ended September 30, 2024. As the settlement included no monetary fines or penalties, the loss reserve was reversed during the three months ended September 30, 2024.

- added (2025-04-28):
[0001628280-25-020353:note_history:79]
Reduction in force

- added (2025-04-28):
[0001628280-25-020353:note_history:80]
In January 2025, the Company implemented a Board-approved reduction in force affecting 40 members of its workforce. This action is part of the Company’s initiative to increase its annualized run rate cash savings as the Company seeks further flexibility to pursue its investment strategy with certain growth opportunities.

- added (2025-04-28):
[0001628280-25-020353:note_history:81]
The Company incurred pre-tax charges of $2.7 million for the reduction in force, substantially all of which was incurred in the first quarter of 2025. These charges consisted of one-time termination charges arising from severance obligations of $2.0 million, extended eligibility for the vesting of certain equity awards originally scheduled to vest on or before March 1, 2025, resulting in incremental non-cash expense of $0.5 million and other customary employee benefit payments in connection with a reduction in force of $0.2 million. Substantially all severance and related payments to 
affected individuals was completed by March 2025, with the exception of three employees who are subject to a continuous payment through July 2025
