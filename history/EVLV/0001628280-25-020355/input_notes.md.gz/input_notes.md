# EVLV notes — 0001628280-25-020355


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-25-020355:notes:1]
Certain portions of the information required to be furnished pursuant to Part III of this Annual Report on Form 10-K will be set forth in, and incorporated by reference from, the registrant’s definitive proxy statement for the annual meeting of stockholders which will be filed with the Securities and Exchange Commission no later than 120 days after the end of the fiscal year ended December 31, 2024 (the "Proxy Statement").


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001628280-25-020355:notes:2]
Cybersecurity Risk Management and Strategy

[0001628280-25-020355:notes:3]
We have developed and implemented a cybersecurity risk management program intended to protect the confidentiality, integrity, and availability of our critical systems and information.

[0001628280-25-020355:notes:4]
We design and assess our program based on the National Institute of Standards and Technology Cybersecurity Framework ("NIST CSF") and SOC 2 trust principles on security. This does not imply that we meet any particular technical standards, specifications, or requirements, only that we use these frameworks as a guide to help us identify, assess, and manage cybersecurity risks relevant to our business.

[0001628280-25-020355:notes:5]
Our cybersecurity risk management program is integrated into our overall enterprise risk management program, and shares common methodologies, reporting channels and governance processes that apply across the enterprise risk management program to other legal, compliance, strategic, operational, and financial risk areas.

[0001628280-25-020355:notes:6]
Key elements of our cybersecurity risk management program include:

[0001628280-25-020355:notes:7]
•risk assessments designed to help identify material cybersecurity risks to our critical systems, information, products, services, and our broader enterprise IT environment;

[0001628280-25-020355:notes:8]
•a security team principally responsible for managing (1) our cybersecurity risk assessment processes, (2) our security controls, and (3) our response to cybersecurity incidents;

[0001628280-25-020355:notes:9]
•the use of external service providers, where appropriate, to assess, test or otherwise assist with aspects of our security controls;

[0001628280-25-020355:notes:10]
•cybersecurity awareness training of our employees, incident response personnel, and senior management;

[0001628280-25-020355:notes:11]
•a cybersecurity incident response plan that includes procedures for responding to cybersecurity incidents; and

[0001628280-25-020355:notes:12]
•a third-party risk management process for service providers that includes a diligence and contracting process depending on our assessment of each provider's respective criticality and risk profile.

[0001628280-25-020355:notes:13]
We have not identified risks from known cybersecurity threats, including as a result of any prior cybersecurity incidents, that have materially affected us, including our operations, business strategy, results of operations, or financial condition. We face certain ongoing risks from cybersecurity threats that, if realized, are reasonably likely to materially affect us, including our operations, business strategy, results of operations, or financial condition. See “Risk Factors – Because our products collect and store visitor and related information and images, domestic and international privacy and cybersecurity concerns, and other laws and regulations, could result in additional costs and liabilities to us or inhibit sales of our products.”


## cyd:CybersecurityRiskProcessForInformingBoardCommitteeOrSubcommitteeResponsibleForOversightTextBlock

[0001628280-25-020355:notes:14]
Our Board considers cybersecurity risk as part of its risk oversight function and has delegated to the Audit Committee ("Audit Committee") oversight of cybersecurity and other IT risks. The Audit Committee oversees management’s implementation of our cybersecurity risk management program.

[0001628280-25-020355:notes:15]
The Audit Committee receives periodic reports from our Vice President of Cybersecurity and Information Technology on our cybersecurity risks, updates, as necessary, regarding any cybersecurity incidents, as well as any incidents with lesser impact potential. 
The Audit Committee reports to the full Board regarding its activities, including those related to cybersecurity.


## cyd:CybersecurityRiskProcessForInformingManagementOrCommitteesResponsibleTextBlock

[0001628280-25-020355:notes:16]
Our Vice President of Cybersecurity and Information Technology is responsible for assessing and managing our material risks from cybersecurity threats and has primary responsibility for our overall cybersecurity risk management program and supervises both our internal cybersecurity personnel and our retained external cybersecurity consultants. Our Vice President of Cybersecurity and Information Technology has served in that position since 2022, and has extensive experience assessing and managing cybersecurity programs and technology risk. Prior to joining Evolv, our Vice President of Cybersecurity and Information Technology was the Leader of Global Information Security for New Balance.
Our Vice President of Cybersecurity and Information Technology supervises efforts to prevent, detect, mitigate, and remediate cybersecurity risks and incidents through various means, which may include briefings from internal security personnel; threat intelligence and other information obtained from governmental, public or private sources, including external consultants engaged by us; and alerts and reports produced by security tools deployed in the IT environment.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-25-020355:notes:17]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company designed to transform human security to make a safer, faster, and better experience for the world's most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics.

[0001628280-25-020355:notes:18]
The Company announced in the third quarter of 2024 the launch of a new product offering, Evolv eXpedite™, an autonomous AI-based weapons detection system for bags. This new offering, as well as existing products such as Evolv Express®, are designed to be integrated layers for detection as part of a unified Evolv Safer Experience System™. These products and their associated services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

[0001628280-25-020355:notes:19]
As used in this Annual Report on Form 10-K, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).

[0001628280-25-020355:notes:20]
Liquidity and capital resources

[0001628280-25-020355:notes:21]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of December 31, 2024, the Company had $51.9 million in cash, cash equivalents, and marketable securities, and as of March 31, 2025, the Company had $35.0 million in cash, cash equivalents, and marketable securities. The Company incurred a net loss of $54.0 million and $108.0 million for the years ended December 31, 2024 and 2023, respectively. The Company incurred cash outflows from operating activities of $30.9 million and $9.8 million during the years ended December 31, 2024 and 2023, respectively. The Company expects to continue to generate losses for the foreseeable future.

[0001628280-25-020355:notes:22]
The Company maintains substantially all of its cash, cash equivalents, and marketable securities in accounts with U.S. and multi-national financial institutions and its cash deposits at these institutions exceed Federal Deposit Insurance Corporation insured limits. The Company does not believe it is exposed to any unusual credit risk or deposit concentration risk beyond the ordinary credit risk associated with commercial banking relationships.

[0001628280-25-020355:notes:23]
The Company expects its cash, cash equivalents, and marketable securities of $51.9 million as of December 31, 2024, together with cash it expects to generate from future operations, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Annual Report on Form 10-K. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth. The Company may require additional capital to respond to expected growth in the demand for equipment to support its “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances. To the extent that the Company's projected revenue growth does not materialize, the Company has established plans to preserve existing cash liquidity, which includes additional reductions to operating expenses and capital expenditures.

[0001628280-25-020355:notes:24]
Although not required to fund ongoing operations, in an improving interest rate environment the Company may choose to engage in debt financings or enter into credit facilities for other strategic reasons. If the Company is unable to

[0001628280-25-020355:notes:25]
obtain adequate financing or financing on terms satisfactory to it, when it requires it, the Company's ability to continue to grow or support the business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, tariffs, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing the Company's ability to access capital. If the Company is unable to raise additional funds when or on the terms desired, its business, financial condition and results of operations could be adversely affected.

[0001628280-25-020355:notes:26]
Additionally, there continues to be significant uncertainty regarding recent changes and potential future developments related to increased trade restrictions, tariffs or taxes on imports or exports relating to countries where we source or sell materials or products. The exact magnitude of any potential impact remains uncertain, as there may be further changes to tariffs and policies and, consequently, potential increased tension between the U.S. and targeted countries, and the Company's financial condition and results of operations could be adversely affected.

[0001628280-25-020355:notes:27]
Risks and uncertainties

[0001628280-25-020355:notes:28]
There is significant uncertainty in the current macroeconomic environment due to inflationary pressures globally, conflicts in Europe and the Middle East, and foreign currency volatility and their impacts on the Company’s business. If economic conditions were to worsen, the Company’s results of operations, financial condition, and cash flows from operations may be materially and adversely impacted.

[0001628280-25-020355:notes:29]
Basis of presentation

[0001628280-25-020355:notes:30]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001628280-25-020355:notes:31]
Reclassifications

[0001628280-25-020355:notes:32]
During the year ended December 31, 2023, the Company began classifying revenue from professional services, which includes installation, training, and event support, as well as other one-time revenue, within license fee and other revenue on the consolidated statements of operations and comprehensive loss, whereas the revenue for these services has previously been included in service revenue. Correspondingly, the Company began classifying costs associated with professional services within cost of license fee and other revenue, whereas these costs were previously included in cost of service revenue. These reclassifications were made to align the presentation of professional services with the Company's internal reporting and analysis. The reclassifications did not impact total revenue or total cost of revenue for any period. Prior year amounts included in this Annual Report on Form 10-K have been reclassified to conform to the current presentation. For all periods presented in this Annual Report on Form 10-K, the total of License fees and other revenue and cost of revenue was included in Service revenue and cost of revenue in prior years.


## us-gaap:ErrorCorrectionTextBlock

[0001628280-25-020355:notes:33]
Restatement of Previously Issued Financial Statements
In September 2024, an ad hoc committee of independent directors (the “Committee”) of the Board, under the direction of the Board, commenced an investigation (the “Investigation”) of the Company’s sales practices, including whether certain sales of products and subscriptions to channel partners and end users were subject to extra-contractual terms and conditions that impacted revenue recognition and other metrics, and if so, when senior Company personnel became aware of these issues.

[0001628280-25-020355:notes:34]
As a result of the Investigation, the Committee determined that certain sales, including sales to one of its largest channel partners, were subject to extra-contractual terms and conditions, some of which were not shared with the Company’s accounting personnel, and that certain Company personnel engaged in misconduct in connection with those transactions. Furthermore, these extra-contractual terms and conditions were withheld from the Company’s Audit Committee of the Board (the “Audit Committee”) and the Company’s independent registered public accounting firm, PricewaterhouseCoopers LLP (“PwC”). The Committee also determined that certain accounting personnel were aware of

[0001628280-25-020355:notes:35]
indications of these extra-contractual terms and conditions during affected periods, and that related allegations were raised internally in July 2024 and known to senior finance and accounting personnel, but that those allegations were not escalated to the Audit Committee or communicated to PwC prior to the filing of the Company’s second quarter 2024 financial statements. As a result of the Investigation, the Board determined that new leadership was critical to moving the Company forward. In November 2024, the Company’s Chief Financial Officer resigned. Additionally, four other employees, including personnel from its sales, finance and accounting departments were terminated or resigned as a result of the investigation.

[0001628280-25-020355:notes:36]
In connection with the investigation, the Committee determined that the accounting for certain sales transactions was materially inaccurate and that, among other things, revenue was prematurely or incorrectly recognized (the “Impacted Transactions”) in connection with financial statements prepared for the fiscal years ended December 31, 2022 and December 31, 2023 contained in its Annual Report on Form 10-K for the year-ended December 31, 2023, and its condensed consolidated financial statements for the quarters and year-to-date periods ended June 30, 2022, September 30, 2022, March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024 and June 30, 2024 contained in its Quarterly Reports on Form 10-Q.

[0001628280-25-020355:notes:37]
A review of the transactions identified in the Investigation determined that restatement changes were necessary due to:

[0001628280-25-020355:notes:38]
•an overstatement or understatement of revenue and cost of revenue depending on the changes to revenue recognition start dates in each period of the consolidated statement of operations; and

[0001628280-25-020355:notes:39]
•an overstatement or understatement of other accounts affected by changes to revenue recognition start dates, including accounts receivable, inventory, contract assets, commission assets, property and equipment, net, deferred revenue, and sales and marketing expense.

[0001628280-25-020355:notes:40]
Misstatements related to the Impacted Transactions identified in the Investigation

[0001628280-25-020355:notes:41]
Revenue

[0001628280-25-020355:notes:42]
As discussed above, the Company became aware of the presence of extra-contractual terms and conditions through the Investigation. The extra-contractual terms and conditions created ambiguity with regard to whether the Company and its customers had reached a mutual understanding of the terms of the contracts. Ultimately, the Company decided to honor the customers’ understanding of the contracts, including the terms and conditions granted outside the written contracts.

[0001628280-25-020355:notes:43]
The extra-contractual terms and conditions affected the dates on which it was appropriate for the Company to recognize revenue, or commence revenue recognition for the Impacted Transactions. In order to correct the revenue recognition start dates for each of the Impacted Transactions to be restated, the Company reviewed the terms and circumstances of each transaction, including the contractual and extra-contractual terms and conditions.

[0001628280-25-020355:notes:44]
As described above, the Company offers products for purchase or multi-year subscription leases.  All products are sold with an underlying subscription for software and services. Contracts may include multiple performance obligations when customers purchase a combination of products and services.  For equipment sales, revenue is recognized at a point in time, whereas for leased equipment and software, revenue is recognized ratably over the term (“over time”).

[0001628280-25-020355:notes:45]
GAAP requires that revenue is recognized when (or as) the entity satisfies a performance obligation by transferring the underlying asset to a customer. An asset is transferred when (or as) the customer obtains control of that asset. Further, GAAP defines control as “…the ability to direct the use of, and obtain substantially all of the remaining benefits from, the asset.”

[0001628280-25-020355:notes:46]
Historically, the Company has recognized revenue, or commenced revenue recognition, upon shipment or delivery of the product to the customer, or to the end-user as directed by the customer, if the customer is a reseller. The findings of the Investigation and Financial Statement Review, as defined below, impact the timing of when revenue recognition should begin on certain arrangements. The Company determined that it should recognize or begin to recognize revenue on the Impacted Transactions at the point in time that the Company has an enforceable contract with the customer and control

[0001628280-25-020355:notes:47]
transfers to the customer, which, for the Impacted Transactions, was often the installation date, which is later than the shipment or delivery date. The extra-contractual terms created in substance consignment arrangements with customers, which resulted in no revenue recognition until control of the product was transferred to the customer (i.e., the installation date).

[0001628280-25-020355:notes:48]
For most of the Impacted Transactions, the Company determined that the customer was only committed to the agreement and began to receive and consume the benefits provided by the Company’s performance on the date the security screening system(s) and SaaS portal were both installed and activated at the end user site.  Therefore, revenue recognition for over time performance obligations was determined to begin at the installation date and recognized over the period in which the benefits are consumed (e.g., the subscription term). Product sales were also restated to be recorded at the installation date where appropriate. For point-in-time performance obligations, revenue was recognized at the installation date.

[0001628280-25-020355:notes:49]
Property, and Equipment / Inventory

[0001628280-25-020355:notes:50]
As stated above, the Company offers products for purchase or multi-year subscription leases. For equipment for which the revenue recognition start date was moved to a later date due to the timing of the transfer of control, the equipment cost was reclassified from Leased equipment to Equipment held for lease within Property and Equipment (for leased equipment), or added back to finished goods Inventory  (for equipment sales) until the point in time that the Company transferred control of the equipment to the customer, corresponding to the revenue recognition start date.

[0001628280-25-020355:notes:51]
Cost of Product Revenue / Cost of Subscription Revenue

[0001628280-25-020355:notes:52]
For leased equipment reclassified to equipment held for lease, as described above, the Company adjusted the dates placed in service to correspond to the revised date upon which revenue recognition commenced, thus achieving appropriate alignment of revenue recognition with the recognition of depreciation expense (cost of revenue), consistent with the company’s accounting policies. For equipment added back to inventory related to sales of equipment, the Company added back the associated cost of revenue in the period it was originally recognized, and restated the cost of revenue to correspond with the revenue recognition start date.

[0001628280-25-020355:notes:53]
Commissions Asset / Commissions Expense

[0001628280-25-020355:notes:54]
Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract, which generally begins upon transfer of control. For the Impacted Transactions on which the Company adjusted the revenue recognition start date, the amortization of the corresponding commission expense was adjusted to conform to the adjusted revenue recognition start date.

[0001628280-25-020355:notes:55]
Accounts Receivable, Contract Assets, Deferred Revenue

[0001628280-25-020355:notes:56]
Deferred Revenue, Contract Assets and Accounts Receivable relating to affected customer arrangements were adjusted to reflect the corresponding changes in revenue recognition start dates.

[0001628280-25-020355:notes:57]
Additional errors identified through the Financial Statement Review

[0001628280-25-020355:notes:58]
Following the Investigation, the Company completed a comprehensive review of its previously issued financial statements (the “Financial Statement Review”), which resulted in the identification of additional errors. These adjustments included:

[0001628280-25-020355:notes:59]
•an understatement of research and development expense and overstatement of property, plant and equipment in certain periods due to an error in the calculation of internal-use software costs in the first and second quarters of 2024;

[0001628280-25-020355:notes:60]
•an overstatement of cost of revenue and understatement of inventory and property and equipment, net in the first and second quarters of 2024 related to the expensing of inbound freight costs that should have been capitalized into inventory or property and equipment, net; and

[0001628280-25-020355:notes:61]
•an overstatement of accounts receivable and contract assets and corresponding understatement of deferred revenue in each period related to the incorrect classification of amounts due to the Company resulting from its contracts with customers.

[0001628280-25-020355:notes:62]
The impact of the correction of the misstatements and errors resulting from the Investigation and Financial Statement Review on the consolidated financial statements for the quarterly periods ended June 30, 2022, September 30, 2022, March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024, and June 30, 2024 are summarized in Note 23, Restatement of Quarterly Financial Information (Unaudited).

[0001628280-25-020355:notes:63]
The impact of the correction of the misstatements on the consolidated financial statements related to the Investigation as of and for the years ended December 31, 2023 and 2022, as well as previously identified immaterial errors which have now been corrected, is summarized below. The applicable accompanying notes to the consolidated financial statements have also been updated.

[0001628280-25-020355:notes:64]
The impact of the correction of the misstatements and errors on the Consolidated Statements of Stockholders' Equity were solely within net (loss) income for errors impacting accumulated deficit and within stock-based compensation cost for errors impacting accumulated paid in capital.

[0001628280-25-020355:notes:65]
The impact of the correction of the misstatements and errors on the Consolidated Statements of Cash Flows were driven by changes in the related Consolidated Balance Sheet and Consolidated Statement of Operations and Comprehensive Income (Loss) line items, except as noted by footnote under each applicable table below.

[0001628280-25-020355:notes:66]
Where adjustments in the below tables relate to multiple categories, the adjustment amounts of each category are noted below each table and sum to the total adjustment reflected. Restatement adjustments are reflected as follows:

[0001628280-25-020355:notes:67]
ADJ 1: related to revenue recognition misstatements identified as part of the Investigation.

[0001628280-25-020355:notes:68]
ADJ 2: related to errors in capitalized internal-use software costs.

[0001628280-25-020355:notes:69]
ADJ 3: related to errors in capitalized freight costs.

[0001628280-25-020355:notes:70]
ADJ 4: other immaterial errors previously identified in prior periods corrected as part of the restatement.

[0001628280-25-020355:notes:71]
ADJ 5: related to classification errors in contract assets and deferred revenue.

[0001628280-25-020355:notes:72]
As of and for the Year Ended December 31, 2023

[0001628280-25-020355:notes:73]
Restated Consolidated Balance Sheet

[0001628280-25-020355:notes:74]
(In thousands, except share and per share amounts)

[0001628280-25-020355:notes:75]
|  |  |  | As of December 31, 2023 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Assets |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 67,162 |  |  | $ | — |  |  | $ | 67,162 |  |
| Restricted cash |  |  | 275 |  |  | — |  |  | 275 |  |
| Marketable securities |  |  | 51,289 |  |  | — |  |  | 51,289 |  |
| Accounts receivable, net | ADJ 1, ADJ 5 |  | 22,611 |  |  | (1,064) |  |  | 21,547 |  |
| Inventory | ADJ 1 |  | 9,507 |  |  | 837 |  |  | 10,344 |  |
| Current portion of contract assets | ADJ 1, ADJ 5 |  | 3,707 |  |  | (2,310) |  |  | 1,397 |  |
| Current portion of commission asset | ADJ 1 |  | 4,339 |  |  | 48 |  |  | 4,387 |  |
| Prepaid expenses and other current assets | ADJ 1 |  | 16,954 |  |  | 3 |  |  | 16,957 |  |
| Total current assets |  |  | 175,844 |  |  | (2,486) |  |  | 173,358 |  |
| Contract assets, noncurrent | ADJ 1, ADJ 5 |  | 451 |  |  | 513 |  |  | 964 |  |
| Commission asset, noncurrent | ADJ 1 |  | 7,107 |  |  | 142 |  |  | 7,249 |  |
| Property and equipment, net | ADJ 1, ADJ 4 |  | 112,921 |  |  | 240 |  |  | 113,161 |  |
| Operating lease right-of-use assets |  |  | 1,195 |  |  | — |  |  | 1,195 |  |
| Other assets |  |  | 1,202 |  |  | — |  |  | 1,202 |  |
| Total assets |  |  | $ | 298,720 |  |  | $ | (1,591) |  |  | $ | 297,129 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 17,400 |  |  | $ | — |  |  | $ | 17,400 |  |
| Accrued expenses and other current liabilities | ADJ 4 |  | 15,578 |  |  | 125 |  |  | 15,703 |  |
| Current portion of deferred revenue | ADJ 1, ADJ 5 |  | 47,677 |  |  | (869) |  |  | 46,808 |  |
| Current portion of operating lease liabilities |  |  | 1,391 |  |  | — |  |  | 1,391 |  |
| Total current liabilities |  |  | 82,046 |  |  | (744) |  |  | 81,302 |  |
| Deferred revenue, noncurrent | ADJ 5 |  | 23,813 |  |  | 1,336 |  |  | 25,149 |  |
| Contingent earn-out liability |  |  | 29,119 |  |  | — |  |  | 29,119 |  |
| Contingently issuable common stock liability |  |  | 6,530 |  |  | — |  |  | 6,530 |  |
| Public warrant liability |  |  | 10,889 |  |  | — |  |  | 10,889 |  |
| Total liabilities |  |  | 152,397 |  |  | 592 |  |  | 152,989 |  |
| Commitments and contingencies (Note 20) |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  | — |  |  | — |  |
| Common stock |  |  | 15 |  |  | — |  |  | 15 |  |
| Additional paid-in capital |  |  | 444,825 |  |  | — |  |  | 444,825 |  |
| Accumulated other comprehensive loss |  |  | (53) |  |  | — |  |  | (53) |  |
| Accumulated deficit |  |  | (298,464) |  |  | (2,183) |  |  | (300,647) |  |
| Stockholders’ equity |  |  | 146,323 |  |  | (2,183) |  |  | 144,140 |  |
| Total liabilities and stockholders’ equity |  |  | $ | 298,720 |  |  | $ | (1,591) |  |  | $ | 297,129 |  |

[0001628280-25-020355:notes:76]
(a) Category references are described above. Where adjustments relate to multiple categories, the adjustment amounts of each category are noted below and sum to the total adjustment reflected in the table above:

[0001628280-25-020355:notes:77]
Accounts receivable, net: ADJ 1 = ($1,974), ADJ 5 = $910

[0001628280-25-020355:notes:78]
Current portion of contract assets: ADJ 1 = ($1,154), ADJ 5 = ($1,156)

[0001628280-25-020355:notes:79]
Contract assets, noncurrent: ADJ 1 = ($126), ADJ 5 = $639

[0001628280-25-020355:notes:80]
Property and equipment, net: ADJ1 = $212, ADJ 4 = $28

[0001628280-25-020355:notes:81]
Current portion of deferred revenue: ADJ 1 = $73, ADJ 5 = ($942)

[0001628280-25-020355:notes:82]
Restated Consolidated Statement of Operations and Comprehensive Loss Data

[0001628280-25-020355:notes:83]
|  |  |  |  |  | Year Ended December 31, 2023 |
|  |  |  |  |  |  |  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue |  |  |  |  |  |  | ADJ1 |  | $ | 21,977 |  |  | $ | 791 |  |  | $ | 22,768 |  |
| Subscription revenue |  |  |  |  |  |  | ADJ 1,ADJ 4 |  | 37,247 |  |  | (1,046) |  |  | 36,201 |  |
| Service revenue |  |  |  |  |  |  | ADJ 1,ADJ 4 |  | 16,141 |  |  | (535) |  |  | 15,606 |  |
| License fee and other revenue |  |  |  |  |  |  | ADJ 1 |  | 5,053 |  |  | (63) |  |  | 4,990 |  |
| Total revenue |  |  |  |  |  |  |  |  | 80,418 |  |  | (853) |  |  | 79,565 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue |  |  |  |  |  |  | ADJ 1, ADJ 4 |  | 26,667 |  |  | 1,300 |  |  | 27,967 |  |
| Cost of subscription revenue |  |  |  |  |  |  | ADJ 1, ADJ 4 |  | 14,991 |  |  | (231) |  |  | 14,760 |  |
| Cost of service revenue |  |  |  |  |  |  |  |  | 3,982 |  |  | — |  |  | 3,982 |  |
| Cost of license fee and other revenue |  |  |  |  |  |  |  |  | 949 |  |  | — |  |  | 949 |  |
| Total cost of revenue |  |  |  |  |  |  |  |  | 46,589 |  |  | 1,069 |  |  | 47,658 |  |
| Gross profit |  |  |  |  |  |  |  |  | 33,829 |  |  | (1,922) |  |  | 31,907 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  | ADJ 4 |  | 24,455 |  |  | 18 |  |  | 24,473 |  |
| Sales and marketing |  |  |  |  |  |  | ADJ 1, ADJ 4 |  | 55,223 |  |  | (237) |  |  | 54,986 |  |
| General and administrative |  |  |  |  |  |  | ADJ 4 |  | 42,091 |  |  | 91 |  |  | 42,182 |  |
| Loss from impairment of property and equipment |  |  |  |  |  |  |  |  | 322 |  |  | — |  |  | 322 |  |
| Total operating expenses |  |  |  |  |  |  |  |  | 122,091 |  |  | (128) |  |  | 121,963 |  |
| Loss from operations |  |  |  |  |  |  |  |  | (88,262) |  |  | (1,794) |  |  | (90,056) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  |  |  |  |  |  |  | (654) |  |  | — |  |  | (654) |  |
| Interest income |  |  |  |  |  |  |  |  | 6,227 |  |  | — |  |  | 6,227 |  |
| Other expense, net |  |  |  |  |  |  |  |  | (84) |  |  | — |  |  | (84) |  |
| Loss on extinguishment of debt |  |  |  |  |  |  |  |  | (626) |  |  | — |  |  | (626) |  |
| Change in fair value of contingent earn-out liability |  |  |  |  |  |  |  |  | (14,901) |  |  | — |  |  | (14,901) |  |
| Change in fair value of contingently issuable common stock liability |  |  |  |  |  |  |  |  | (3,138) |  |  | — |  |  | (3,138) |  |
| Change in fair value of public warrant liability |  |  |  |  |  |  |  |  | (4,765) |  |  | — |  |  | (4,765) |  |
| Total other income (expense), net |  |  |  |  |  |  |  |  | (17,941) |  |  | — |  |  | (17,941) |  |
| Loss before income taxes |  |  |  |  |  |  |  |  | (106,203) |  |  | (1,794) |  |  | (107,997) |  |
| Provision for income taxes |  |  |  |  |  |  |  |  | (51) |  |  | — |  |  | (51) |  |
| Net loss |  |  |  |  |  |  |  |  | $ | (106,254) |  |  | $ | (1,794) |  |  | $ | (108,048) |  |
| Weighted average common shares outstanding – basic and diluted |  |  |  |  |  |  |  |  | 149,168,105 |  |  | — |  |  | 149,168,105 |  |
| Net loss per share - basic and diluted |  |  |  |  |  |  |  |  | $ | (0.71) |  |  | $ | (0.01) |  |  | $ | (0.72) |  |
| Net loss |  |  |  |  |  |  |  |  | $ | (106,254) |  |  | $ | (1,794) |  |  | $ | (108,048) |  |
| Other comprehensive loss |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  |  |  |  |  |  |  | (43) |  |  | — |  |  | (43) |  |
| Total other comprehensive loss |  |  |  |  |  |  |  |  | (43) |  |  | — |  |  | (43) |  |
| Total comprehensive loss |  |  |  |  |  |  |  |  | $ | (106,297) |  |  | $ | (1,794) |  |  | $ | (108,091) |  |

[0001628280-25-020355:notes:84]
Subscription revenue: ADJ 1 = ($1,025), ADJ 4 = ($21)

[0001628280-25-020355:notes:85]
Service revenue: ADJ 1 = ($556), ADJ 4 = $21

[0001628280-25-020355:notes:86]
Cost of product revenue: ADJ 1 = $1,603, ADJ 4 = ($303)

[0001628280-25-020355:notes:87]
Cost of subscription revenue: ADJ 1 = ($194), ADJ 4 = ($37)

[0001628280-25-020355:notes:88]
Sales and marketing: ADJ 1 = $2, ADJ 4 = ($239)

[0001628280-25-020355:notes:89]
Restated Consolidated Statement of Cash Flows

[0001628280-25-020355:notes:90]
(In thousands)

[0001628280-25-020355:notes:91]
|  |  |  | Year Ended December 31, 2023 |
|  |  |  | As Reported |  | Adjustment |  | As Restated |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (106,254) |  |  | $ | (1,794) |  |  | $ | (108,048) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 9,932 |  |  | (230) |  |  | 9,702 |  |
| Write-off of inventory and change in inventory reserve |  |  | 1,612 |  |  | (303) |  |  | 1,309 |  |
| Loss from impairment of property and equipment |  |  | 322 |  |  | — |  |  | 322 |  |
| Stock-based compensation |  |  | 24,151 |  |  | (22) |  |  | 24,129 |  |
| Non-cash interest expense |  |  | 22 |  |  | — |  |  | 22 |  |
| Accretion of discount on marketable securities, net of change in accrued interest |  |  | (575) |  |  | — |  |  | (575) |  |
| Non-cash lease expense |  |  | 478 |  |  | — |  |  | 478 |  |
| Change in allowance for expected credit losses |  |  | 382 |  |  | — |  |  | 382 |  |
| Loss on extinguishment of debt |  |  | 626 |  |  | — |  |  | 626 |  |
| Change in fair value of earn-out liability |  |  | 14,901 |  |  | — |  |  | 14,901 |  |
| Change in fair value of contingently issuable common stock |  |  | 3,138 |  |  | — |  |  | 3,138 |  |
| Change in fair value of public warrant liability |  |  | 4,765 |  |  | — |  |  | 4,765 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 8,927 |  |  | (4,417) |  |  | 4,510 |  |
| Inventory |  |  | (644) |  |  | 1,604 |  |  | 960 |  |
| Commission assets |  |  | (2,407) |  |  | (372) |  |  | (2,779) |  |
| Contract assets |  |  | 80 |  |  | 1,303 |  |  | 1,383 |  |
| Other assets |  |  | 633 |  |  | — |  |  | 633 |  |
| Prepaid expenses and other current assets |  |  | (2,566) |  |  | 140 |  |  | (2,426) |  |
| Accounts payable |  |  | (5,963) |  |  | — |  |  | (5,963) |  |
| Deferred revenue |  |  | 35,522 |  |  | 3,966 |  |  | 39,488 |  |
| Accrued expenses and other current liabilities |  |  | 3,732 |  |  | 125 |  |  | 3,857 |  |
| Operating lease liability |  |  | (615) |  |  | — |  |  | (615) |  |
| Net cash used in operating activities |  |  | (9,801) |  |  | — |  |  | (9,801) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Development of internal-use software |  |  | (3,535) |  |  | — |  |  | (3,535) |  |
| Purchases of property and equipment |  |  | (69,134) |  |  | — |  |  | (69,134) |  |
| Proceeds from sale of property and equipment |  |  | 270 |  |  | — |  |  | 270 |  |
| Purchases of marketable securities |  |  | (89,898) |  |  | — |  |  | (89,898) |  |
| Proceeds from maturities of marketable securities |  |  | 39,184 |  |  | — |  |  | 39,184 |  |
| Net cash used in investing activities |  |  | (123,113) |  |  | — |  |  | (123,113) |  |

[0001628280-25-020355:notes:92]
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 668 |  |  | — |  |  | 668 |  |
| Proceeds from long-term debt |  |  | 1,876 |  |  | — |  |  | 1,876 |  |
| Repayment of principal on long-term debt |  |  | (31,876) |  |  | — |  |  | (31,876) |  |
| Payment of debt issuance costs and prepayment penalty |  |  | (332) |  |  | — |  |  | (332) |  |
| Net cash used in financing activities |  |  | (29,664) |  |  | — |  |  | (29,664) |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (43) |  |  | — |  |  | (43) |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (162,621) |  |  | — |  |  | (162,621) |  |
| Cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 230,058 |  |  | — |  |  | 230,058 |  |
| Cash, cash equivalents and restricted cash at end of period |  |  | $ | 67,437 |  |  | $ | — |  |  | $ | 67,437 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |
| Cash paid for interest |  |  | $ | 710 |  |  | $ | — |  |  | $ | 710 |  |
| Supplemental disclosure of non-cash activities |  |  |  |  |  |  |  |
| Transfer of property and equipment to inventory |  |  | $ | 218 |  |  | $ | — |  |  | $ | 218 |  |
| Capital expenditures incurred but not yet paid |  |  | 13,322 |  |  | — |  |  | 13,322 |  |
| Capitalization of stock compensation |  |  | 516 |  |  | — |  |  | 516 |  |
| Finback exercise price |  |  | 464 |  |  | — |  |  | 464 |  |
| Reconciliation of cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 67,162 |  |  | $ | — |  |  | $ | 67,162 |  |
| Restricted cash |  |  | 275 |  |  | — |  |  | 275 |  |
| Total cash, cash equivalents and restricted cash shown in the statements of cash flows |  |  | $ | 67,437 |  |  | $ | — |  |  | $ | 67,437 |  |

[0001628280-25-020355:notes:93]
As of and for the Year Ended December 31, 2022

[0001628280-25-020355:notes:94]
|  |  |  | As of December 31, 2022 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Assets |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 229,783 |  |  | $ | — |  |  | $ | 229,783 |  |
| Accounts receivable, net | ADJ 1 |  | 31,920 |  |  | (5,481) |  |  | 26,439 |  |
| Inventory | ADJ 1, ADJ 4 |  | 10,257 |  |  | 2,138 |  |  | 12,395 |  |
| Current portion of contract assets | ADJ 1, ADJ 5 |  | 2,852 |  |  | (459) |  |  | 2,393 |  |
| Current portion of commission asset | ADJ 1, ADJ 4 |  | 3,384 |  |  | (220) |  |  | 3,164 |  |
| Prepaid expenses and other current assets | ADJ 1 |  | 14,388 |  |  | 143 |  |  | 14,531 |  |
| Total current assets |  |  | 292,584 |  |  | (3,879) |  |  | 288,705 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Contract assets, noncurrent | ADJ 1, ADJ 5 |  | 1,386 |  |  | (35) |  |  | 1,351 |  |
| Commission asset, noncurrent | ADJ 1 |  | 5,655 |  |  | 38 |  |  | 5,693 |  |
| Property and equipment, net | ADJ 1, ADJ 4 |  | 44,707 |  |  | 10 |  |  | 44,717 |  |
| Operating lease right-of-use assets |  |  | 1,673 |  |  | — |  |  | 1,673 |  |
| Other assets |  |  | 1,835 |  |  | — |  |  | 1,835 |  |
| Total assets |  |  | $ | 348,115 |  |  | $ | (3,866) |  |  | $ | 344,249 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 18,194 |  |  | $ | — |  |  | $ | 18,194 |  |
| Accrued expenses and other current liabilities |  |  | 11,545 |  |  | — |  |  | 11,545 |  |
| Current portion of deferred revenue | ADJ 1, ADJ 5 |  | 18,273 |  |  | (248) |  |  | 18,025 |  |
| Current portion of long-term debt |  |  | 10,000 |  |  | — |  |  | 10,000 |  |
| Current portion of operating lease liabilities |  |  | 1,114 |  |  | — |  |  | 1,114 |  |
| Total current liabilities |  |  | 59,126 |  |  | (248) |  |  | 58,878 |  |
| Deferred revenue, noncurrent | ADJ 5 |  | 17,695 |  |  | (3,251) |  |  | 14,444 |  |
| Long-term debt, noncurrent |  |  | 19,683 |  |  | — |  |  | 19,683 |  |
| Operating lease liabilities, noncurrent |  |  | 892 |  |  | — |  |  | 892 |  |
| Contingent earn-out liability |  |  | 14,218 |  |  | — |  |  | 14,218 |  |
| Contingently issuable common stock liability |  |  | 3,392 |  |  | — |  |  | 3,392 |  |
| Public warrant liability |  |  | 6,124 |  |  | — |  |  | 6,124 |  |
| Total liabilities |  |  | 121,130 |  |  | (3,499) |  |  | 117,631 |  |
| Commitments and contingencies (Note 20) |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  | — |  |  | — |  |
| Common stock |  |  | 15 |  |  | — |  |  | 15 |  |
| Additional paid-in capital | ADJ 4 |  | 419,190 |  |  | 22 |  |  | 419,212 |  |
| Accumulated other comprehensive loss |  |  | (10) |  |  | — |  |  | (10) |  |
| Accumulated deficit |  |  | (192,210) |  |  | (389) |  |  | (192,599) |  |
| Stockholders’ equity |  |  | 226,985 |  |  | (367) |  |  | 226,618 |  |
| Total liabilities and stockholders’ equity |  |  | $ | 348,115 |  |  | $ | (3,866) |  |  | $ | 344,249 |  |

[0001628280-25-020355:notes:95]
Inventory: ADJ 1 = $2,441, ADJ 4 = ($303)

[0001628280-25-020355:notes:96]
Current portion of contract assets: ADJ 1 = ($484), ADJ 5 = $25

[0001628280-25-020355:notes:97]
Current portion of commission assets: ADJ 1 = $13, ADJ 4 = ($233)

[0001628280-25-020355:notes:98]
Contract assets, noncurrent: ADJ 1 = $1, ADJ 5 = ($36)

[0001628280-25-020355:notes:99]
Current portion of deferred revenue: ADJ 1 = ($3,487), ADJ 5 = $3,239

[0001628280-25-020355:notes:100]
Property and equipment, net: ADJ 1 = $18, ADJ 4 = ($8)

[0001628280-25-020355:notes:101]
|  |  |  |  |  | Year Ended December 31, 2022 |
|  |  |  |  |  |  |  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue |  |  |  |  |  |  | ADJ 1 |  | $ | 31,985 |  |  | $ | (2,198) |  |  | $ | 29,787 |  |
| Subscription revenue |  |  |  |  |  |  | ADJ 1, ADJ 4 |  | 17,569 |  |  | (528) |  |  | 17,041 |  |
| Service revenue |  |  |  |  |  |  | ADJ 1, ADJ 4 |  | 4,331 |  |  | 264 |  |  | 4,595 |  |
| License fee and other revenue |  |  |  |  |  |  | ADJ 1 |  | 1,310 |  |  | (14) |  |  | 1,296 |  |
| Total revenue |  |  |  |  |  |  |  |  | 55,195 |  |  | (2,476) |  |  | 52,719 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue |  |  |  |  |  |  | ADJ 1, ADJ 4 |  | 41,575 |  |  | (2,138) |  |  | 39,437 |  |
| Cost of subscription revenue |  |  |  |  |  |  | ADJ 1, ADJ 4 |  | 7,469 |  |  | (9) |  |  | 7,460 |  |
| Cost of service revenue |  |  |  |  |  |  |  |  | 2,200 |  |  | — |  |  | 2,200 |  |
| Cost of license fee and other revenue |  |  |  |  |  |  |  |  | 2,222 |  |  | — |  |  | 2,222 |  |
| Total cost of revenue |  |  |  |  |  |  |  |  | 53,466 |  |  | (2,147) |  |  | 51,319 |  |
| Gross profit |  |  |  |  |  |  |  |  | 1,729 |  |  | (329) |  |  | 1,400 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  | ADJ 4 |  | 18,771 |  |  | (234) |  |  | 18,537 |  |
| Sales and marketing |  |  |  |  |  |  | ADJ 1, ADJ 4 |  | 46,639 |  |  | 44 |  |  | 46,683 |  |
| General and administrative |  |  |  |  |  |  | ADJ 4 |  | 37,719 |  |  | 250 |  |  | 37,969 |  |
| Loss from impairment of property and equipment |  |  |  |  |  |  |  |  | 1,161 |  |  | — |  |  | 1,161 |  |
| Total operating expenses |  |  |  |  |  |  |  |  | 104,290 |  |  | 60 |  |  | 104,350 |  |
| Loss from operations |  |  |  |  |  |  |  |  | (102,561) |  |  | (389) |  |  | (102,950) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  |  |  |  |  |  |  | (712) |  |  | — |  |  | (712) |  |
| Interest income |  |  |  |  |  |  |  |  | 3,165 |  |  | — |  |  | 3,165 |  |
| Other expense, net |  |  |  |  |  |  |  |  | (64) |  |  | — |  |  | (64) |  |
| Change in fair value of contingent earn-out liability |  |  |  |  |  |  |  |  | 6,988 |  |  | — |  |  | 6,988 |  |
| Change in fair value of contingently issuable common stock liability |  |  |  |  |  |  |  |  | 1,872 |  |  | — |  |  | 1,872 |  |
| Change in fair value of public warrant liability |  |  |  |  |  |  |  |  | 4,906 |  |  | — |  |  | 4,906 |  |
| Total other income (expense), net |  |  |  |  |  |  |  |  | 16,155 |  |  | — |  |  | 16,155 |  |
| Loss before income taxes |  |  |  |  |  |  |  |  | (86,406) |  |  | (389) |  |  | (86,795) |  |
| Net loss |  |  |  |  |  |  |  |  | $ | (86,406) |  |  | $ | (389) |  |  | $ | (86,795) |  |
| Weighted average common shares outstanding – basic and diluted |  |  |  |  |  |  |  |  | 143,858,668 |  |  | — |  |  | 143,858,668 |  |
| Net loss per share - basic and diluted |  |  |  |  |  |  |  |  | $ | (0.60) |  |  | $ | — |  |  | $ | (0.60) |  |
| Net loss |  |  |  |  |  |  |  |  | $ | (86,406) |  |  | $ | (389) |  |  | $ | (86,795) |  |
| Other comprehensive loss |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  |  |  |  |  |  |  | (10) |  |  | — |  |  | (10) |  |
| Total other comprehensive loss |  |  |  |  |  |  |  |  | (10) |  |  | — |  |  | (10) |  |
| Total comprehensive loss |  |  |  |  |  |  |  |  | $ | (86,416) |  |  | $ | (389) |  |  | $ | (86,805) |  |

[0001628280-25-020355:notes:102]
(a) Category references are described in above. Where adjustments relate to multiple categories, the adjustment amounts of each category are noted below and sum to the total adjustment reflected in the table above:

[0001628280-25-020355:notes:103]
Subscription revenue: ADJ 1 = ($109), ADJ 4 = ($419)

[0001628280-25-020355:notes:104]
Service revenue: ADJ 1 = ($155), ADJ 4 = $419

[0001628280-25-020355:notes:105]
Cost of product revenue: ADJ 1 = ($2,441), ADJ 4 = $303

[0001628280-25-020355:notes:106]
Cost of subscription revenue: ADJ 1 = ($17), ADJ 4 = $8

[0001628280-25-020355:notes:107]
Sales and marketing: ADJ 1 = ($195), ADJ 4 = $239

[0001628280-25-020355:notes:108]
|  |  |  | Year Ended December 31, 2022 |
|  |  |  | As Reported |  | Adjustment |  | As Restated |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (86,406) |  |  | $ | (389) |  |  | $ | (86,795) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 5,465 |  |  | (22) |  |  | 5,443 |  |
| Write-off of inventory and change in inventory reserve |  |  | 1,582 |  |  | — |  |  | 1,582 |  |
| Adjustment to property and equipment for sales type leases |  |  | (625) |  |  | — |  |  | (625) |  |
| Loss from impairment of property and equipment |  |  | 1,161 |  |  | — |  |  | 1,161 |  |
| Stock-based compensation |  |  | 22,498 |  |  | 22 |  |  | 22,520 |  |
| Non-cash interest expense |  |  | 55 |  |  | — |  |  | 55 |  |
| Non-cash lease expense |  |  | 811 |  |  | — |  |  | 811 |  |
| Change in allowance for expected credit losses |  |  | 150 |  |  | — |  |  | 150 |  |
| Change in fair value of earn-out liability |  |  | (6,988) |  |  | — |  |  | (6,988) |  |
| Change in fair value of contingently issuable common stock |  |  | (1,872) |  |  | — |  |  | (1,872) |  |
| Change in fair value of public warrant liability |  |  | (4,906) |  |  | — |  |  | (4,906) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (25,593) |  |  | 5,481 |  |  | (20,112) |  |
| Inventory |  |  | (8,495) |  |  | (2,138) |  |  | (10,633) |  |
| Commission assets |  |  | (3,675) |  |  | 182 |  |  | (3,493) |  |
| Contract assets |  |  | 639 |  |  | 494 |  |  | 1,133 |  |
| Other assets |  |  | (419) |  |  | — |  |  | (419) |  |
| Prepaid expenses and other current assets |  |  | (3,174) |  |  | (143) |  |  | (3,317) |  |
| Accounts payable |  |  | 7,661 |  |  | — |  |  | 7,661 |  |
| Deferred revenue |  |  | 26,887 |  |  | (3,499) |  |  | 23,388 |  |
| Accrued expenses and other current liabilities |  |  | 1,462 |  |  | — |  |  | 1,462 |  |
| Operating lease liability |  |  | (946) |  |  | — |  |  | (946) |  |
| Net cash used in operating activities |  |  | (74,728) |  |  | (12) |  |  | (74,740) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Development of internal-use software |  |  | (2,720) |  |  | — |  |  | (2,720) |  |
| Purchases of property and equipment (1) |  |  | (21,473) |  |  | 12 |  |  | (21,461) |  |
| Proceeds from sale of property and equipment |  |  | 312 |  |  | — |  |  | 312 |  |
| Net cash used in investing activities |  |  | (23,881) |  |  | 12 |  |  | (23,869) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 827 |  |  | — |  |  | 827 |  |
| Proceeds from long-term debt |  |  | 29,683 |  |  | — |  |  | 29,683 |  |
| Repayment of principal on long-term debt |  |  | (10,000) |  |  | — |  |  | (10,000) |  |
| Net cash provided by financing activities |  |  | 20,510 |  |  | — |  |  | 20,510 |  |

[0001628280-25-020355:notes:109]
| Effect of exchange rate changes on cash and cash equivalents |  |  | (10) |  |  | — |  |  | (10) |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (78,109) |  |  | — |  |  | (78,109) |  |
| Cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 308,167 |  |  | — |  |  | 308,167 |  |
| Cash, cash equivalents and restricted cash at end of period |  |  | $ | 230,058 |  |  | $ | — |  |  | $ | 230,058 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |
| Cash paid for interest |  |  | $ | 581 |  |  | $ | — |  |  | $ | 581 |  |
| Supplemental disclosure of non-cash activities |  |  |  |  |  |  |  |
| Capital expenditures incurred but not yet paid |  |  | 7,552 |  |  | — |  |  | 7,552 |  |
| Capitalization of stock compensation |  |  | 205 |  |  | — |  |  | 205 |  |
| Reconciliation of cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 229,783 |  |  | $ | — |  |  | $ | 229,783 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Total cash, cash equivalents and restricted cash shown in the statements of cash flows |  |  | $ | 230,058 |  |  | $ | — |  |  | $ | 230,058 |  |

[0001628280-25-020355:notes:110]
(1) Relates to adjustments related to ADJ 4.

[0001628280-25-020355:notes:111]
The footnotes that follow have been updated to reflect the restatement adjustments as described above.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-25-020355:notes:112]
Summary of Significant Accounting Policies
Use of Estimates

[0001628280-25-020355:notes:113]
The preparation of the Company’s consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the reporting periods. Significant estimates and assumptions reflected in these consolidated financial statements include but are not limited to marketable securities, calculating the standalone selling price for revenue recognition, the valuation of inventory, the expensing and capitalization of costs associated with internal-use software, stock-based awards, the valuation of the contingent earn-out liability, the valuation of the contingently issuable common stock, the valuation of the public warrant liability, the valuation of inventory and the useful life of our leased equipment. The Company bases its estimates on historical experience, known trends and other market-specific or other relevant factors that it believes to be reasonable under the circumstances. On an ongoing basis, management evaluates its estimates when there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results could differ from those estimates.

[0001628280-25-020355:notes:114]
Risk of Concentrations of Credit, Significant Customers and Significant Suppliers

[0001628280-25-020355:notes:115]
Financial instruments that potentially expose the Company to concentrations of credit risk consist primarily of cash equivalents, restricted cash, marketable securities, and accounts receivable, net. We maintain substantially all of our cash and cash equivalents with U.S. and multi-national financial institutions, and our deposits are generally in excess of federally insured limits. The Company maintains its cash, cash equivalents, restricted cash, and marketable securities with financial institutions that management believes to be of high credit quality. The Company has not experienced any losses on such accounts and does not believe it is exposed to any unusual credit risk beyond the normal credit risk associated with commercial banking relationships.

[0001628280-25-020355:notes:116]
Significant customers are those which represent more than 10% of the Company’s total revenue or accounts receivable, net balance at each respective balance sheet date. The following table presents customers that represent 10% or

[0001628280-25-020355:notes:117]
more of the Company’s total revenue for the years ended December 31, 2024, 2023 and 2022. Each customer shown is a reseller partner of the Company.

[0001628280-25-020355:notes:118]
|  | Year Ended December 31, 2024 |  | Year Ended December 31, 2023 |  | Year Ended December 31, 2022 |
|  |  |  | (Restated) |  | (Restated) |
| Motorola Solutions, Inc. | * |  | 12.1 | % |  | 21.9 | % |
| Customer A | * |  | * |  | 10.5 | % |
| Customer B | 12.6 | % |  | 10.6 | % |  | * |
|  | 12.6 | % |  | 22.7 | % |  | 32.4 | % |

[0001628280-25-020355:notes:119]
* Less than 10%

[0001628280-25-020355:notes:120]
The following table presents a customer that represents 10% or more of the Company’s accounts receivable, net.

[0001628280-25-020355:notes:121]
|  | December 31, |
|  | 2024 |  | 2023 |
| Columbia Tech | 11.0 | % |  | * |
| Customer B | 11.3 | % |  | * |
|  | 22.3 | % |  | * |

[0001628280-25-020355:notes:122]
The Company relies on one primary third-party contract manufacturer, Columbia Tech, for the production of our touchless security screening systems. Columbia Tech provides a variety of services including sourcing off-the-shelf components, manufacturing custom components/assemblies, final product assembly and integration, end of line testing and quality assurance per our specifications, material and finished goods inventory, and direct shipping to our customers. We also use a different third-party manufacturer as a second source for the production of a key sensor component used in our systems. In instances where these parties fail to perform their obligations, the Company may be unable to find alternative suppliers to satisfactorily deliver its products to its customers on time, if at all, which could have a material adverse effect on the Company’s operating results, financial condition and cash flows and damage its customer relationships.

[0001628280-25-020355:notes:123]
Cash, Cash Equivalents, and Restricted Cash

[0001628280-25-020355:notes:124]
The Company considers all short-term, highly liquid investments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents. Restricted cash related to a letter of credit on the Company’s office lease in Waltham, Massachusetts, all of which is included in restricted cash, current on the consolidated balance sheet as of December 31, 2023. During the three months ended September 30, 2024, as a result of an amendment to our lease, the restricted cash was no longer required, and the related letter of credit expired on October 31, 2024. See Note 7, Leases, for more information.

[0001628280-25-020355:notes:125]
Marketable Securities

[0001628280-25-020355:notes:126]
Marketable securities are reported at fair value and, at December 31, 2024, are comprised solely of zero coupon U.S. treasury bills with maturities of less than one year that are classified as available-for-sale debt securities. The Company considers an available-for-sale debt security to be impaired if the fair value of the investment is less than its amortized cost basis. The entire difference between the amortized cost basis and the fair value of the Company’s available-for-sale debt securities is recognized on the consolidated statements of operations as an impairment if, (i) the fair value of the security is below its amortized cost and (ii) the Company intends to sell or is more likely than not required to sell the

[0001628280-25-020355:notes:127]
security before recovery of its amortized cost basis. If neither criterion is met, the Company evaluates whether the decline in fair value is due to credit losses or other factors. In making this assessment, the Company considers the changes to the rating of the security by third-party rating agencies, and adverse conditions specific to the security, among other factors. If the Company’s assessment indicates that a credit loss exists, the credit loss is measured based on the Company’s best estimate of the cash flows expected to be collected. When developing its estimate of cash flows expected to be collected, the Company considers all available information relevant to the collectability of the security, including past events, current conditions, and reasonable and supportable forecasts.

[0001628280-25-020355:notes:128]
Unrealized gains and losses, net of tax, on marketable securities, if any, are recognized in accumulated other comprehensive income (loss) in the accompanying consolidated balance sheets. Realized net gains and losses on marketable securities, if any, are reflected in interest income in the accompanying consolidated statements of operations and comprehensive loss.

[0001628280-25-020355:notes:129]
Contract Balances from Contracts with Customers

[0001628280-25-020355:notes:130]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent.

[0001628280-25-020355:notes:131]
Fair Value Measurements of Financial Instruments

[0001628280-25-020355:notes:132]
Certain assets and liabilities of the Company are carried at fair value under GAAP. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. Valuation techniques used to measure fair value must maximize the use of observable inputs and minimize the use of unobservable inputs. Financial assets and liabilities carried at fair value are to be classified and disclosed in one of the following three levels of the fair value hierarchy, of which the first two are considered observable and the last is considered unobservable:

[0001628280-25-020355:notes:133]
•Level 1 — Quoted prices in active markets for identical assets or liabilities.

[0001628280-25-020355:notes:134]
•Level 2 — Observable inputs (other than Level 1 quoted prices), such as quoted prices in active markets for similar assets or liabilities, quoted prices in markets that are not active for identical or similar assets or liabilities, or other inputs that are observable or can be corroborated by observable market data.

[0001628280-25-020355:notes:135]
•Level 3 — Unobservable inputs that are supported by little or no market activity that are significant to determining the fair value of the assets or liabilities, including pricing models, discounted cash flow methodologies and similar techniques.

[0001628280-25-020355:notes:136]
The Company’s cash equivalents, restricted cash, marketable securities, derivative liability, contingent earn-out liability, contingently issuable common stock liability and its common stock warrant liability are carried at fair value, determined according to the fair value hierarchy described above (see Note 4). The carrying values of the Company’s accounts receivable, net, accounts payable and accrued expenses approximate their fair values due to the short-term nature of these assets and liabilities. The carrying value of the Company’s long-term debt approximates its fair value (a Level 2 measurement) at each balance sheet date due to its variable interest rate, which approximates a market interest rate.

[0001628280-25-020355:notes:137]
Assets that are measured at fair value on a nonrecurring basis primarily relate to property and equipment. We do not periodically adjust carrying value to fair value for property and equipment. Rather, the carrying value of the asset is reduced to its fair value when we determine that impairment has occurred.

[0001628280-25-020355:notes:138]
Contingent Earn-out

[0001628280-25-020355:notes:139]
In connection with the Merger and pursuant to the Merger Agreement, certain of the Legacy Evolv’s shareholders and Legacy Evolv Service Providers are entitled to receive additional shares of the Company’s common stock (the “Earn-Out Shares”) upon the Company achieving certain milestones:

[0001628280-25-020355:notes:140]
•Triggering Event I – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock is greater than $12.50 per share for any 20 trading days within any 30 trading day period.

[0001628280-25-020355:notes:141]
•Triggering Event II – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock is greater than $15.00 per share for any 20 trading days within any 30 trading day period.

[0001628280-25-020355:notes:142]
•Triggering Event III – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock is greater than $17.50 per share for any 20 trading days within any 30 trading day period.

[0001628280-25-020355:notes:143]
In accordance with ASC 815 – Derivatives and Hedging, the earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a change in fair value of contingent earn-out liability in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Triggering Events have been achieved and the Earn-Out Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001628280-25-020355:notes:144]
The estimated fair value of the contingent earn-out shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, drift rate, percentage of change in control and expected term.

[0001628280-25-020355:notes:145]
The contingent earn-out liability is categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingent earn-out payments involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001628280-25-020355:notes:146]
The Earn-Out Shares issued to employees, officers, directors, and non-employees are based on achievement of certain target share price contingencies and for the employees and officers, subject to continued employment, (the “Earn-Out Service Providers”) represents share-based compensation and is included in additional paid-in capital on the Company’s balance sheet. Corresponding stock-based compensation expense is recorded in the consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. As a condition to being issued Earn-Out Shares, the Earn-Out Service Providers must still be providing services to the Company on the date of the issuance of the shares. If the relationship with the service provider is terminated prior to the issuance of the Earn-Out Shares, the shares will be redistributed to the remaining participants in the Earn-Out Shares.

[0001628280-25-020355:notes:147]
Contingently Issuable Common Stock

[0001628280-25-020355:notes:148]
Prior to the Merger, NewHold Industrial Technology Holdings, LLC, the sponsor of the NHIC special purpose acquisition company owned 4,312,500 shares of NHIC Class B common stock (the “Founder Shares). Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company’s common stock. The Founder Shares outstanding were subject to certain share-performance-based vesting provisions as follows:

[0001628280-25-020355:notes:149]
•Vesting Provision I – 1,897,500 shares of the Company’s common stock shall vest and no longer be subject to forfeiture as of the Merger;

[0001628280-25-020355:notes:150]
•Vesting Provision II – if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $12.50 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30 trading day period, then 948,750 shares of the Company’s common stock shall vest and no longer be subject to forfeiture and

[0001628280-25-020355:notes:151]
•Vesting Provision III – if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $15.00 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30-trading day period, then 948,750 shares of the Company’s common stock) shall vest and no longer be subject to forfeiture.

[0001628280-25-020355:notes:152]
The remaining 517,500 Founder Shares were contributed to Give Evolv LLC.

[0001628280-25-020355:notes:153]
If Vesting Provision II and/or Vesting Provision III are not satisfied, the corresponding number of shares specified shall be forfeited and no longer issued and outstanding. If there is a Change of Control event prior to Vesting Provision II and/or Vesting Provision III are satisfied, the Founder shares are no longer subject to forfeiture and shall vest immediately upon the occurrence of a Change of Control event.

[0001628280-25-020355:notes:154]
In accordance with ASC 815 – Derivatives and Hedging, the contingently issuable common stock is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as change in fair value of contingently issuable common stock liability in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Vesting Provisions have been achieved and the contingently issuable common shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001628280-25-020355:notes:155]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, likelihood of change in control, and remaining term.

[0001628280-25-020355:notes:156]
The contingently issuable common shares are categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingently issuable shares involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001628280-25-020355:notes:157]
Public Warrant Liability

[0001628280-25-020355:notes:158]
In connection with the closing of the Merger, the Company assumed warrants for the purchase of 14,325,000 shares of common stock at an exercise price of $11.50 (the “Public Warrants”). The Public Warrants are classified as a liability pursuant to ASC 815 – Derivatives and Hedging as the equity derivative scope exception was not met and are measured at fair value, with the changes in fair value reported in earnings as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss with the offset to additional paid in capital.

[0001628280-25-020355:notes:159]
Leases as a Lessee

[0001628280-25-020355:notes:160]
The Company accounts for leases in accordance with ASC 842, Leases. At contract inception, the Company determines if an arrangement is or contains a lease. A lease conveys the right to control the use of an identified asset for a period of time in exchange for consideration. If determined to be or contain a lease, the lease is assessed for classification as either an operating or finance lease at the lease commencement date, defined as the date on which the leased asset is made available for use by the Company (when the Company is the lessee). Where the Company is the lessee, for each lease with a term greater than twelve months, the Company records a right-of-use asset and lease liability.

[0001628280-25-020355:notes:161]
A right-of-use asset represents the economic benefit conveyed to the Company by the right to use the underlying asset over the lease term. A lease liability represents the obligation to make lease payments arising from the use of the asset over the lease term. Lease liabilities are measured at lease commencement and calculated as the present value of the future

[0001628280-25-020355:notes:162]
lease payments in the contract using the rate implicit in the contract, when available. If an implicit rate is not readily determinable, the Company uses an incremental borrowing rate measured as the rate at which the Company could borrow, on a fully collateralized basis, a commensurate loan in the same currency over a period consistent with the lease term at the commencement date. Right-of-use assets are measured as the amount of the initial lease liability plus initial direct costs and prepaid lease payments, less lease incentives granted by the lessor. The lease term is measured as the noncancelable period in the contract, adjusted for any options to extend or terminate when it is reasonably certain the Company will extend the lease term via such options based on an assessment of economic factors present as of the lease commencement date. The Company elected the practical expedient to not recognize leases with a lease term of twelve months or less.

[0001628280-25-020355:notes:163]
Components of a lease are split into three categories: lease components, non-lease components, and non-components. The fixed and in-substance fixed contract consideration (including any consideration related to non-components) are allocated, based on the respective relative fair values, to the lease components and non-lease components. The Company has elected the practical expedient to account for lease and non-lease components together as a single lease component for all underlying assets and allocate all of the contract consideration to the lease component only.

[0001628280-25-020355:notes:164]
The Company’s operating leases are presented in the consolidated balance sheet as operating lease right-of-use assets, classified as noncurrent assets, and operating lease liabilities, classified as current and noncurrent liabilities. Operating lease expense is recognized on a straight-line basis over the lease term. Variable costs associated with a lease, such as maintenance and utilities, are not included in the measurement of the lease liabilities and right-of-use assets but rather are expensed when the events determining the amount of variable consideration to be paid have occurred.

[0001628280-25-020355:notes:165]
Inventory

[0001628280-25-020355:notes:166]
Inventory is stated at the lower of cost or net realizable value with cost being determined using the weighted average method. The Company regularly reviews inventory quantities on-hand for excess and obsolete inventory and, when circumstances indicate, records charges to write down inventories to their estimated net realizable value, after evaluating historical sales, future demand, market conditions and expected product life cycles. Such charges are classified as product cost of revenues in the consolidated statement of operations and comprehensive loss. Any write-down of inventory to net realizable value creates a new cost basis. The Company recorded $2.6 million, $1.3 million (as restated) and $1.6 million in inventory write-offs and change in inventory reserves during the years ended December 31, 2024, 2023 and 2022, respectively. Inventory write-offs primarily related to Edge units and prior generation Express units and related components, as the Company is no longer selling these products, as well as other inventory that was determined to be obsolete or unsellable.

[0001628280-25-020355:notes:167]
Property and Equipment

[0001628280-25-020355:notes:168]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization expense are recognized using the straight-line method over the estimated useful life of each asset, as follows:

[0001628280-25-020355:notes:169]
|  | Estimated Useful Life |
| Computers and telecommunications equipment | 3 years |
| Lab equipment | 5 years |
| Software | 4 years |
| Furniture and fixtures | 5 years |
| Leasehold improvements | Shorter of useful life of 7 years or remaining lease term |
| Leased equipment | 4-7 years |
| Internal-use software | 4 years |
| Sales demo equipment | 7 years |
| Vehicles | 5 years |

[0001628280-25-020355:notes:170]
Estimated useful lives are periodically assessed to determine if changes are appropriate. Leasehold improvements are depreciated using the straight-line method over the lesser of the lease term or its estimated economic useful life. Lease terms are used based upon the initial lease agreement and do not consider potential renewals or extensions until such time that the renewals or extensions are contracted. Maintenance and repairs are charged to expense as incurred. When assets are retired or otherwise disposed of, the cost of these assets and related accumulated depreciation are eliminated from the consolidated balance sheet and any resulting gains or losses are included in the consolidated statements of operations and comprehensive loss in the period of disposal. Costs for capital assets not yet placed into service are capitalized as construction-in-progress and depreciated once placed into service.

[0001628280-25-020355:notes:171]
The Company’s leases for leased equipment generally are 48 months. The Company’s subscription contracts are generally classified as operating leases because title does not transfer and they do not meet any of the other criteria per Accounting Standards Codification 842 – Leases (“ASC 842”).

[0001628280-25-020355:notes:172]
The Company evaluates property and equipment for obsolescence and impairment whenever events or changes in business circumstances indicate that the carrying amount of the assets may not be fully recoverable. Factors that the Company considers in deciding when to perform an impairment review include significant underperformance of the business in relation to expectations, significant negative industry or economic trends and significant changes or planned changes in the use of the assets. If an impairment review is performed to evaluate a long-lived asset group for recoverability, the Company compares forecasts of undiscounted cash flows expected to result from the use and eventual disposition of the long-lived asset group to its carrying value. An impairment loss would be recognized in loss from operations and comprehensive loss when estimated undiscounted future cash flows expected to result from the use of an asset group are less than its carrying amount. The impairment loss is based on the excess of the carrying value of the impaired asset group over its fair value, determined based on discounted cash flows. The Company recorded impairment losses of $0.2 million, $0.3 million, and $1.2 million during the years ended December 31, 2024, 2023, and 2022, respectively. These impairment losses related primarily to Edge and Express prototype units that were taken out of service and retired.

[0001628280-25-020355:notes:173]
The Company capitalizes certain software development costs, including consulting costs and compensation expenses for employees who devote time to the development projects, beginning upon completion of the preliminary project stage (in relation to internal-use software) or upon establishment of technological feasibility (in relation to software embedded in products to be sold or leased), and through the date the software is ready for its intended use. The Company

[0001628280-25-020355:notes:174]
records software development costs in property and equipment, net. Costs incurred in the preliminary stages of development activities and post implementation are expensed in the period incurred and are recorded in research and development expense in the consolidated statements of operations and comprehensive loss. The Company also capitalizes costs related to specific upgrades and enhancements when it is probable the expenditures will result in additional functionality.

[0001628280-25-020355:notes:175]
Once the project is available for general release, capitalization ceases, and the asset can begin amortization. Capitalized software costs are amortized on a straight-line basis over their estimated useful life, which is generally four years, and are recorded in cost of subscription revenue and cost of service revenue in the consolidated statements of operations and comprehensive loss.

[0001628280-25-020355:notes:176]
Debt Issuance Costs

[0001628280-25-020355:notes:177]
The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated debt on the consolidated balance sheet and amortized as interest expense on the consolidated statement of operations and comprehensive loss using the effective interest method.

[0001628280-25-020355:notes:178]
Segment Information

[0001628280-25-020355:notes:179]
The Company determined that it has one operating segment after considering the Company’s organizational structure and the information regularly reviewed and evaluated by the Company’s chief operating decision maker (“CODM”) in deciding how to allocate resources and assess performance. The Company has determined that its CODM is its President and Chief Executive Officer. The CODM reviews the financial information on a consolidated basis for purposes of evaluating financial performance and allocating resources. On the basis of these factors, the Company determined that it operates and manages its business as one operating segment, that develops, manufactures, markets and sells security screening products and specific services, and accordingly has one reportable segment for financial reporting purposes. Refer to Note 22, Segment Information, for more detail.

[0001628280-25-020355:notes:180]
Revenue Recognition

[0001628280-25-020355:notes:181]
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

[0001628280-25-020355:notes:182]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after control passes to the customer. Revenue is recognized net of sales tax.

[0001628280-25-020355:notes:183]
Distribution and License Agreement

[0001628280-25-020355:notes:184]
In March 2023, the Company entered into a distributor licensing agreement (the "Distribution and License Agreement") with Columbia Electrical Contractors, Inc. ("Columbia Tech"). Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, serves as the Company's primary contract manufacturer. Under this arrangement, the Company has granted a license of its intellectual property to Columbia Tech, which contracts directly with certain of the Company's resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment as opposed to lease the equipment. Columbia Tech pays the Company a hardware license fee for each system it manufactures and sells

[0001628280-25-020355:notes:185]
under the agreement. In these instances, the Company still contracts directly with the reseller to provide a multi-year SaaS and maintenance subscription to the end-users.

[0001628280-25-020355:notes:186]
The Company has assessed whether it operates as the principal or as an agent in relation to the sale of product  made by Columbia Tech to the Company's resellers pursuant to the Distribution and License Agreement. The Company considered various factors, including but not limited to, inventory risk, discretion in establishing pricing, and which entity is primarily responsible for fulfillment. Based on an evaluation of the facts and circumstances, the Company concluded that Columbia Tech is the principal in the arrangement. The Company therefore does not recognize revenue in relation to sales of product pursuant to the Distribution and License Agreement, but does recognize revenue in relation to license fees received from Columbia Tech and the SaaS and maintenance subscription contracts, each as further described below.

[0001628280-25-020355:notes:187]
Product Revenue

[0001628280-25-020355:notes:188]
The Company derives revenue from the sale of its Evolv Express equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer. Transfer of control occurs when the Company has transferred title and risk of loss and has a present right to payment for the equipment, which follows the terms of each customer contract. Products are predominantly sold with distinct services, which are described in the services section below.

[0001628280-25-020355:notes:189]
Consignment Sales

[0001628280-25-020355:notes:190]
As discussed in Note 2, Restatement of Previously Issued Financial Statements, the Company entered into certain in-substance consignment arrangements with reseller partners for which product revenue has been recognized at the point in time when control transferred to the customer and the customer has an unconditional obligation to pay for the goods transferred, which was deemed to occur upon installation at the end-user site.

[0001628280-25-020355:notes:191]
Subscription Revenue - Leases as Lessor

[0001628280-25-020355:notes:192]
In addition to selling our products directly to customers, we also derive revenue from leasing our equipment, which we classify as subscription revenue. Lease terms are typically four years, generally do not include unilateral options by either the Company or our customer to extend, terminate or to purchase the underlying asset, and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. There are no variable lease payments as a part of these arrangements.

[0001628280-25-020355:notes:193]
The accounting provisions we use to classify transactions as sales-type are: (i) whether the lease transfers ownership of the equipment by the end of the lease term, (ii) whether the lease grants the customer an option to purchase the equipment and the customer is reasonably certain to do so, (iii) whether the lease term is for the major part of the economic life of the underlying equipment, (iv) whether the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (v) whether the equipment is specific to the customer and of such a specialized nature that it is expected to have no alternative use to the Company at the end of the lease term. Leasing arrangements meeting any of these conditions are accounted for as sales-type leases and revenue attributable to the lease component is recognized in a manner consistent with product revenue and the related equipment is derecognized with the associated expense presented as a cost of revenue. Leasing arrangements that do not meet the criteria for classification as a sales-type lease will be accounted for as a direct-financing lease if the following two conditions are met: (i) the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments and any other third party unrelated to the Company, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (ii) it is probable that the Company will collect the lease payments and amounts necessary to satisfy a residual value guarantee. Leasing arrangements that do not meet any of the sales-type lease or direct-financing lease classification criteria are accounted for as operating leases and revenue is recognized straight-line over the term of the lease. Historically, nearly all of the Company's equipment leases have been classified as operating leases.

[0001628280-25-020355:notes:194]
The Company considers the economic life of most of our products to be seven years. The Company believes seven years is representative of the period during which the equipment is expected to be economically usable by one or more users, with normal service, for the purpose for which it is intended. The unguaranteed residual value is estimated to be the

[0001628280-25-020355:notes:195]
value at the end of the lease term based on the anticipated fair market value of the units. The Company mitigates residual value risk of our leased equipment by performing regular management and maintenance, as necessary.

[0001628280-25-020355:notes:196]
Generally, lease arrangements include both lease and non-lease components. The lease component relates to the customer’s right-to-use the equipment over the lease term. The non-lease components relate to (1) distinct services, such as SaaS and maintenance, (2) any add-on accessories, and (3) professional services, including installation, training, and event. Professional services are included in license fees and other revenue, as described below, and add-on accessories are included in product revenue. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the Company elected the practical expedient to aggregate non-lease components with the associated lease component and account for the combined component as an operating lease for all underlying asset classes. In the evaluation of whether the lease component (equipment) or the non-lease components associated with the lease component (SaaS and maintenance) is the predominant component, the Company determined that the lease component is predominant as we believe the customer would ascribe more value to the use of the security equipment than that of the SaaS and maintenance services. Therefore, the Company accounts for the combined lease component under ASC 842. The equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations and comprehensive loss. The professional services represent distinct services provided to customers. These activities are considered separate performance obligations to the customer and therefore are considered non-lease components. As professional services are generally performed prior to lease commencement, the timing and pattern of transfer for these services differ from that of the lease component and are not eligible to be combined.

[0001628280-25-020355:notes:197]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party.

[0001628280-25-020355:notes:198]
Service Revenue

[0001628280-25-020355:notes:199]
Service revenue consists of subscription-based SaaS and maintenance revenue related to products sold to a customer by either the Company or by Columbia Tech pursuant to the Distribution and License Agreement. Customers generally pay either a quarterly or annual fixed payment for SaaS and maintenance. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically 4 years.

[0001628280-25-020355:notes:200]
License Fee and Other Revenue

[0001628280-25-020355:notes:201]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from our third-party manufacturer to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration.

[0001628280-25-020355:notes:202]
Professional services are generally billed to the lessee as part of the lease contract billing, according to various contractual terms. Professional services costs incurred by the Company are accounted for as a fulfillment cost and are included in the cost of license fees and other revenue in the consolidated statements of operations and comprehensive loss.

[0001628280-25-020355:notes:203]
Revenue from Reseller Partners

[0001628280-25-020355:notes:204]
A portion of the Company’s revenue is also generated by sales to its reseller partners. When the Company transacts with a reseller partner, its contractual arrangement is with the reseller partner and not with the end-use customer. In these transactions, the reseller partner is considered the customer; the Company has discretion over the pricing to the reseller partner and maintains overall control of the inventory and sales process to the reseller partner. Right of return does not generally exist.

[0001628280-25-020355:notes:205]
Transaction Price

[0001628280-25-020355:notes:206]
The transaction price is the amount of consideration that the Company expects to be entitled for providing goods and services under a contract, which includes fixed amounts, and on rare occasions, variable consideration. The Company may also provide discounts to customers which reduce the transaction price. On infrequent occasions, the Company may offer customers the option to purchase additional goods and services at a fixed price. In these circumstances, the Company

[0001628280-25-020355:notes:207]
assesses whether these offers constitute a material right, and if so, the Company would account for the material right as a separate performance obligation. The Company does not normally provide for rights of returns to customers on product sales and, therefore, does not record a provision for returns. Amounts paid or payable to customers, including those related to sponsorship arrangements, are recognized as a reduction of the transaction price, and therefore, of revenue unless the payment is in exchange for a distinct good or service.

[0001628280-25-020355:notes:208]
Performance Obligations

[0001628280-25-020355:notes:209]
A performance obligation is a promise in a contract to transfer a distinct product or service to a customer that is both capable of being distinct, whereby the customer can benefit from the product or service either on its own or together with other resources that are readily available, and is distinct in the context of the contract, whereby the transfer of the product or service is separately identifiable from other promises in the contract.

[0001628280-25-020355:notes:210]
Equipment is sold or leased with embedded software, which is considered a single performance obligation. Maintenance, which includes preventative maintenance, future updates, security threat updates, and minor bug fixes on a when-and-if available basis, is considered a single performance obligation. SaaS, which includes data-driven security information and analytics insights, is also considered a performance obligation. Professional services, including installation, training, and event support, are considered separate performance obligations and are included within license fee and other revenue. Any add-on accessories are also considered separate performance obligations and are included in product revenue.

[0001628280-25-020355:notes:211]
Payment terms

[0001628280-25-020355:notes:212]
Payment terms for customer orders are typically 30 days after the shipment or installation of the product. Generally, the Company’s contracts do not contain a significant financing component.

[0001628280-25-020355:notes:213]
Multiple Performance Obligations within an Arrangement

[0001628280-25-020355:notes:214]
The Company’s contracts may include multiple performance obligations when customers purchase a combination of products and services. When the Company’s customer arrangements have multiple performance obligations that contain an equipment lease for the customer’s use as well as distinct services that are delivered simultaneously, the Company allocates the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, the Company allocates the contract’s transaction price to each performance obligation on a relative SSP basis. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company estimates the SSP taking into account available information such as market conditions, internally approved pricing guidelines, and observable pricing data such as standard cost metrics related to the performance obligation.

[0001628280-25-020355:notes:215]
Commissions

[0001628280-25-020355:notes:216]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract.

[0001628280-25-020355:notes:217]
Stock-Based Compensation

[0001628280-25-020355:notes:218]
The Company measures all stock-based awards granted to employees, officers, directors and non-employees based on their fair value on the date of the grant and recognizes compensation expense for those awards over the requisite service period, which is generally the vesting period of the respective award. The vesting period for stock options is generally four years and the vesting period for restricted stock units is generally three years. The Company classifies stock-based compensation expense in its consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. The Company issues stock-based awards with service-based vesting conditions and records the expense for these awards using the straight-line method. Forfeitures are accounted for as they occur.

[0001628280-25-020355:notes:219]
In January 2021, the Company granted warrants (the "Finback Common Stock Warrants") exercisable for 2,552,913 shares of common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC ("Finback"), a consulting group affiliated with one of the Company's shareholders. The Finback Common Stock Warrants vest upon meeting certain sales criteria as defined in a business development agreement (the "Finback BDA") which has a term of three years. The Finback Common Stock Warrants expire in January 2031. The Finback Common Stock Warrants are accounted for under ASC 718 Compensation - Stock Compensation as the warrants vest upon certain performance conditions being met.

[0001628280-25-020355:notes:220]
Prior to the closing of the Merger, there was not a public market for the shares of the Company’s common stock. The Company’s determination of the fair value of stock options on the date of grant utilized the Black-Scholes option-pricing model and was impacted by its common stock price, as determined by the Board of Directors with input from the Company’s management, as well as changes in assumptions regarding a number of subjective variables. These variables included, but were not limited to, the expected term that options remained outstanding, the expected common stock price volatility over the term of the option awards, risk-free interest rates, and expected dividends. The Company valued its common stock taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the Company determines the fair value of each share of common stock underlying stock-based awards based on the closing price of the Company’s common stock as reported by Nasdaq on the date of grant.

[0001628280-25-020355:notes:221]
Pursuant to the Merger Agreement, the Company will issue 15,000,000 earn-out shares of the Company’s common stock to Legacy Evolv shareholders and Legacy Evolv Service Providers including employees, officers, directors, and non-employees based on the achievement of certain target share price contingencies and subject to continued employment. The company classifies the share-based compensation arrangement with Legacy Evolv Service Providers as equity on its balance sheet and corresponding stock-based compensation expense in its consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. As of December 31, 2024, of the total 15,000,000 earn-out shares of the Company’s common stock, 1,348,918 earn-out shares can be earned by the Legacy Evolv Service Providers and are subject to the stock-based compensation guidance. As a condition for Earn-Out Shares being issued to Earn-Out Service Providers, the service provider must be providing services to the Company on the date of the issuance of the shares. If the relationship with the service provider is terminated prior to the issuance of the Earn-Out Shares, the shares will be redistributed to the remaining participants in the Earn-Out Shares.

[0001628280-25-020355:notes:222]
Income Taxes

[0001628280-25-020355:notes:223]
The Company accounts for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in the consolidated financial statements or in the Company’s tax returns. Deferred tax assets and liabilities are determined on the basis of the differences between the consolidated financial statements and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. Changes in deferred tax assets and liabilities are recorded in the provision for income taxes.

[0001628280-25-020355:notes:224]
The Company assesses the likelihood that its deferred tax assets will be recovered from future sources of income and, to the extent it believes, based upon the weight of available evidence, that it is more likely than not that all or a portion of the deferred tax assets will not be realized, a valuation allowance is established through a charge to income tax expense. The potential for recovery of deferred tax assets is evaluated by analyzing past operating results, estimating the future taxable profits expected and considering prudent and feasible tax planning strategies.

[0001628280-25-020355:notes:225]
The Company accounts for uncertainty in income taxes recognized in the consolidated financial statements by applying a two-step process to determine the amount of tax benefit to be recognized. First, the tax position must be evaluated to determine the likelihood that it will be sustained upon external examination by the taxing authorities. If the tax position is deemed more-likely-than-not to be sustained, the tax position is then assessed to determine the amount of benefit to recognize in the consolidated financial statements. The amount of the benefit that may be recognized is the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. The provision for income taxes includes the effects of any resulting tax reserves, or unrecognized tax benefits, that are considered appropriate as well as the related net interest and penalties.

[0001628280-25-020355:notes:226]
The Company evaluates at the end of each reporting period whether some or all the undistributed earnings of its foreign subsidiaries are permanently reinvested. The Company would recognize deferred income tax liabilities to the extent that management asserts that undistributed earnings of its foreign subsidiaries are not permanently reinvested and will not be permanently reinvested in the future. The Company will continue to evaluate its position in the future based on its future strategy and cash needs.

[0001628280-25-020355:notes:227]
Net Loss per Share Attributable to Common Stockholders

[0001628280-25-020355:notes:228]
Basic net loss per share attributable to common stockholders is computed by dividing the net loss attributable to common stockholders by the weighted average number of common shares outstanding for the period. Diluted net loss attributable to common stockholders is computed by adjusting net loss attributable to common stockholders for the impact to the extent a denominator adjustment is required. Diluted net loss per share attributable to common stockholders is computed by dividing the diluted net loss attributable to common stockholders by the weighted average number of common shares outstanding for the period, including the dilutive effect of potential dilutive common shares as determined under the treasury stock method. For purposes of this calculation, outstanding stock options, convertible preferred stock, convertible notes, warrants to purchase common stock, and warrants to purchase preferred stock are considered potential dilutive common shares.

[0001628280-25-020355:notes:229]
In periods in which the Company reported a net loss attributable to common stockholders, diluted net loss per share attributable to common stockholders is the same as basic net loss per share attributable to common stockholders, since dilutive common shares are not assumed to have been issued if their effect is anti-dilutive. The Company reported a net loss attributable to common stockholders for the years ended December 31, 2024, 2023, and 2022.

[0001628280-25-020355:notes:230]
Recently Adopted Accounting Pronouncements

[0001628280-25-020355:notes:231]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures.” The updated accounting guidance requires a public entity to disclose significant segment expenses and other segment items on an annual and interim basis and to provide in interim periods all disclosures about a reportable segment’s profit or loss and assets that are currently required annually for entities with more than one reportable segment. Public entities with a single reporting segment are required to provide both the new disclosures and all of the existing disclosures required under ASC 280. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Retrospective application is required and early adoption is permitted. The Company adopted this guidance effective December 31, 2024. Since this new ASU addresses only disclosures, the adoption of this ASU did not have any material effects on its financial condition, results of operations, or cash flows.

[0001628280-25-020355:notes:232]
Recently Issued Accounting Pronouncements

[0001628280-25-020355:notes:233]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity should apply the amendments in ASU 2023-09 prospectively to all annual periods beginning after December 15, 2024. The Company determined that although ASU 2023-09 is applicable, it addresses disclosures only, and as such will not have any material effects on its financial condition, results of operations, or cash flows.

[0001628280-25-020355:notes:234]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-25-020355:notes:235]
Marketable Securities
Marketable securities as of December 31, 2024 consisted of the following:

[0001628280-25-020355:notes:236]
|  | December 31, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 14,927 |  |  | $ | — |  |  | $ | 14,927 |  |
| Total marketable securities | $ | 14,927 |  |  | $ | — |  |  | $ | 14,927 |  |

[0001628280-25-020355:notes:237]
|  | December 31, 2023 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |
| Total marketable securities | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |

[0001628280-25-020355:notes:238]
Marketable securities at December 31, 2024 and December 31, 2023 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the year ended December 31, 2024 and 2023. The accretion of discounts on marketable securities is included in interest income on the consolidated statements of operations and comprehensive income.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-020355:notes:239]
Fair Value Measurements
The following tables present information about the Company’s financial assets and liabilities measured at fair value on a recurring basis and indicate the level of the fair value hierarchy used to determine such fair values (in thousands):

[0001628280-25-020355:notes:240]
|  | Fair Value Measurements at December 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 28,946 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,946 |  |
| Treasury bills | — |  |  | 27,417 |  |  | — |  |  | 27,417 |  |
|  | $ | 28,946 |  |  | $ | 27,417 |  |  | $ | — |  |  | $ | 56,363 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 12,809 |  |  | $ | 12,809 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 4,001 |  |  | 4,001 |  |
| Public Warrant liability | 4,297 |  |  | — |  |  | — |  |  | 4,297 |  |
|  | $ | 4,297 |  |  | $ | — |  | $ | — |  | $ | 16,810 |  | $ | — |  | $ | 21,107 |  |

[0001628280-25-020355:notes:241]
|  | Fair Value Measurements at December 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 57,829 |  |  | $ | — |  |  | $ | — |  |  | $ | 57,829 |  |
| Treasury bills | $ | — |  |  | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |
|  | $ | 57,829 |  |  | $ | 51,289 |  |  | $ | — |  |  | $ | 109,118 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | — |  |  | — |  |  | 29,119 |  |  | 29,119 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 6,530 |  |  | 6,530 |  |
| Public Warrant liability | 10,889 |  |  | — |  |  | — |  |  | 10,889 |  |
|  | $ | 10,889 |  |  | $ | — |  |  | $ | 35,649 |  |  | $ | 46,538 |  |

[0001628280-25-020355:notes:242]
Money market funds are included in cash and cash equivalents on the consolidated balance sheets. As of December 31, 2024, U.S. treasury bills with maturities less than 3 months, which totaled $12.5 million, are included in cash and cash equivalents, while treasury bills with maturities greater than 3 months, which totaled $14.9 million, are reflected as marketable securities. As December 31, 2023, all outstanding treasury bills, which totaled $51.3 million, had original maturities greater than three months and are reflected as marketable securities. The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources.

[0001628280-25-020355:notes:243]
The Company may also value its non-financial assets and liabilities, including items such as inventories and property and equipment, at fair value on a non-recurring basis if it is determined that impairment has occurred. Such fair value measurements use significant unobservable inputs and are classified as Level 3.

[0001628280-25-020355:notes:244]
The carrying amounts of cash and cash equivalents, accounts receivable, restricted cash, accounts payable, accrued liabilities, and other accrued expenses approximate fair value because of their short maturity.

[0001628280-25-020355:notes:245]
During each of the years ended December 31, 2024 and 2023, there were no transfers between Level 1, Level 2, and Level 3.

[0001628280-25-020355:notes:246]
Valuation of Contingent Earn-out

[0001628280-25-020355:notes:247]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 3. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of December 31, 2024, no milestones have been achieved.

[0001628280-25-020355:notes:248]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of December 31, 2024 were as follows: 93% expected stock price volatility, a risk-free rate of return of 4.2%, a 25% likelihood of change in control, and a remaining term of 1.2 years.

[0001628280-25-020355:notes:249]
The following table provides a rollforward of the contingent earn-out liability (in thousands):

[0001628280-25-020355:notes:250]
| Balance at December 31, 2021 | $ | 21,206 |  |
| Change in fair value | (6,988) |  |
| Balance at December 31, 2022 | $ | 14,218 |  |
| Change in fair value | 14,901 |  |
| Balance at December 31, 2023 | $ | 29,119 |  |
| Change in fair value | (16,310) |  |
| Balance at December 31, 2024 | $ | 12,809 |  |

[0001628280-25-020355:notes:251]
The decrease in fair value of the contingent earn-out liability is primarily due to lowered probability to achieve the stock price milestones based on the Company's current stock price and a shorter remaining term.

[0001628280-25-020355:notes:252]
Valuation of Contingently Issuable Common Stock

[0001628280-25-020355:notes:253]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 Founder Shares. Of these shares, 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 outstanding shares will vest upon the Company achieving certain milestones as described in Note 3. The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of December 31, 2024, no milestones have been achieved.

[0001628280-25-020355:notes:254]
The fair value of the contingently issued common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of December 31, 2024 were as follows: 93% expected stock price volatility, a risk-free rate of return of 4.2%, a 25% likelihood of change in control, and a remaining term of 1.5 years.

[0001628280-25-020355:notes:255]
The following table provides a rollforward of the contingently issuable common shares (in thousands):

[0001628280-25-020355:notes:256]
| Balance at December 31, 2021 | $ | 5,264 |  |
| Change in fair value | (1,872) |  |
| Balance at December 31, 2022 | $ | 3,392 |  |
| Change in fair value | 3,138 |  |
| Balance at December 31, 2023 | $ | 6,530 |  |
| Change in fair value | (2,529) |  |
| Balance at December 31, 2024 | $ | 4,001 |  |

[0001628280-25-020355:notes:257]
Valuation of Public Warrant Liability

[0001628280-25-020355:notes:258]
In connection with the closing of the Merger, the Company assumed the Public Warrants to purchase shares of the Company’s common stock. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. As of December 31, 2024, 14,324,893 Public Warrants are outstanding.

[0001628280-25-020355:notes:259]
The following table provides a rollforward of the public warrant liability (in thousands):

[0001628280-25-020355:notes:260]
| Balance at December 31, 2021 | $ | 11,030 |  |
| Change in fair value | (4,906) |  |
| Balance at December 31, 2022 | $ | 6,124 |  |
| Change in fair value | 4,765 |  |
| Balance at December 31, 2023 | $ | 10,889 |  |
| Change in fair value | (6,592) |  |
| Balance at December 31, 2024 | $ | 4,297 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-25-020355:notes:261]
Revenue Recognition
Remaining Performance Obligations

[0001628280-25-020355:notes:262]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of December 31, 2024.

[0001628280-25-020355:notes:263]
|  | Less than 1 year |  | 1 - 2 years |  | More than 2 years |  | Total |
| Product revenue | $ | 4,748 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,748 |  |
| Subscription revenue | 72,928 |  |  | 61,137 |  |  | 57,509 |  |  | 191,574 |  |
| Service revenue | 27,527 |  |  | 23,356 |  |  | 19,021 |  |  | 69,904 |  |
| License fee and other revenue | 451 |  |  | 10 |  |  | 17 |  |  | 478 |  |
| Total revenue | $ | 105,654 |  |  | $ | 84,503 |  |  | $ | 76,547 |  |  | $ | 266,704 |  |

[0001628280-25-020355:notes:264]
The amount of minimum future leases is based on expected income recognition. As of December 31, 2024, future minimum payments on noncancelable leases are as follows (in thousands):

[0001628280-25-020355:notes:265]
| Year Ending December 31: |  |
| 2025 | $ | 72,928 |  |
| 2026 | 61,137 |  |
| 2027 | 41,316 |  |
| 2028 | 15,399 |  |
| Thereafter | 794 |  |
|  | $ | 191,574 |  |

[0001628280-25-020355:notes:266]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of December 31, 2024 and December 31, 2023, the Company had $0.8 million and $1.4 million (as restated) in current portion of contract assets and $0.7 million and $1.0 million (as restated) in contract assets, noncurrent on the consolidated balance sheets, respectively.

[0001628280-25-020355:notes:267]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred

[0001628280-25-020355:notes:268]
revenue, noncurrent. The Company recognized revenue of $46.4 million during the year ended December 31, 2024 that was included in the December 31, 2023 deferred revenue balance. The Company recognized revenue of $17.9 million (as restated) during the year ended December 31, 2023 that was included in the December 31, 2022 deferred revenue balance. The Company recognized revenue of $6.6 million (as restated) during the year ended December 31, 2022 that was included in the December 31, 2021 deferred revenue balance.

[0001628280-25-020355:notes:269]
The following table provides a rollforward of deferred revenue (in thousands):

[0001628280-25-020355:notes:270]
| Balance at December 31, 2021 | $ | 9,074 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance (restated) | (6,592) |  |
| Revenue deferred (restated) | 29,987 |  |
| Balance at December 31, 2022 (restated) | $ | 32,469 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance (restated) | (17,886) |  |
| Revenue deferred (restated) | 57,374 |  |
| Balance at December 31, 2023 (restated) | $ | 71,957 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (46,431) |  |
| Revenue deferred | 59,246 |  |
| Balance at December 31, 2024 | $ | 84,772 |  |

[0001628280-25-020355:notes:271]
The following table presents the Company’s components of lease revenue (in thousands):

[0001628280-25-020355:notes:272]
|  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (Restated) |  | (Restated) |
| Revenue from sales-type leases | — |  |  | — |  |  | 1,123 |  |
| Interest income on lease receivables | 154 |  |  | 197 |  |  | 224 |  |
| Lease income - operating leases | 65,046 |  |  | 36,201 |  |  | 17,041 |  |
| Total lease revenue | $ | 65,200 |  |  | $ | 36,398 |  |  | $ | 18,388 |  |

[0001628280-25-020355:notes:273]
The interest income on lease receivables is classified under interest income in the consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the consolidated statements of operations and

[0001628280-25-020355:notes:274]
comprehensive loss. Revenue related to leases entered into with related parties were $1.1 million, $1.1 million (as restated), and $0.9 million (as restated) during the years ended December 31, 2024, 2023, and 2022, respectively.

[0001628280-25-020355:notes:275]
Disaggregated Revenue

[0001628280-25-020355:notes:276]
The following table presents the Company’s revenue by revenue stream (in thousands). Certain prior period amounts have been reclassified to conform to current period presentation:

[0001628280-25-020355:notes:277]
|  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (Restated) |  | (Restated) |
| Product revenue | $ | 6,464 |  |  | $ | 22,768 |  |  | $ | 29,787 |  |
| Subscription revenue | 65,046 |  |  | 36,201 |  |  | 17,041 |  |
| Service revenue | 23,467 |  |  | 15,606 |  |  | 4,595 |  |
| License fees | 7,181 |  |  | 2,963 |  |  | — |  |
| Professional services and other revenue | 1,707 |  |  | 2,027 |  |  | 1,296 |  |
| Total revenue | $ | 103,865 |  |  | $ | 79,565 |  |  | $ | 52,719 |  |

[0001628280-25-020355:notes:278]
The following table presents the Company's revenue by geographical region based on customer location (in thousands):

[0001628280-25-020355:notes:279]
|  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (Restated) |  | (Restated) |
| United States | $ | 99,995 |  |  | $ | 77,703 |  |  | $ | 51,316 |  |
| Foreign | 3,870 |  |  | 1,862 |  |  | 1,403 |  |
| Total revenue | $ | 103,865 |  |  | $ | 79,565 |  |  | $ | 52,719 |  |

[0001628280-25-020355:notes:280]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had total deferred assets related to commissions of $13.0 million and $11.6 million (as restated) as of December 31, 2024 and December 31, 2023, respectively. During the years ended December 31, 2024, 2023 and 2022, the Company recognized commission expense of $5.7 million, $5.4 million (as restated) and $4.2 million (as restated), respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-25-020355:notes:281]
Leases
Company Headquarters (Waltham, MA)

[0001628280-25-020355:notes:282]
In April 2021, the Company entered into a sublease agreement for office and storage space for its corporate headquarters located at 500 Totten Pond Road in Waltham, MA. The Company entered into an amendment to the sublease agreement during the three months ended September 30, 2023 in order to lease additional space within the building. During the three months ended March 31, 2024, the Company amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. Additionally, during the three

[0001628280-25-020355:notes:283]
months ended September 30, 2024, the Company amended the lease agreement again to expand our footprint in our headquarters and extend our lease until May 31, 2031. As a result of this amendment, no further option exists to extend the lease.

[0001628280-25-020355:notes:284]
As of December 31, 2023, the Company was required to maintain a minimum cash balance of $0.3 million as a security deposit on the space which was classified as restricted cash, current on the consolidated balance sheets. The security deposit requirement expired on October 31, 2024, and consequently, the balance was no longer restricted as of December 31, 2024. The Company pays for its proportionate share of building operating expenses and taxes that are treated as variable costs and excluded from the measurement of the lease.

[0001628280-25-020355:notes:285]
Storage Facilities

[0001628280-25-020355:notes:286]
The Company additionally leases three storage spaces on a month-to-month basis that are classified as short-term leases.

[0001628280-25-020355:notes:287]
Operating lease cost recognized during the years ended December 31, 2024 and December 31, 2023 was $2.1 million and $1.2 million, respectively. Cash paid for amounts included in the measurement of lease liabilities for the years ended December 31, 2024 and December 31, 2023 was $1.8 million and $1.4 million, respectively.

[0001628280-25-020355:notes:288]
The weighted-average remaining lease term and discount rate were as follows:

[0001628280-25-020355:notes:289]
|  | December 31, |
|  | 2024 |  | 2023 |
| Weighted average remaining lease term | 6.4 years |  | 0.8 years |
| Weighted average discount rate | 9.23 | % |  | 7.75 | % |

[0001628280-25-020355:notes:290]
Future annual lease payments under non-cancelable operating leases as of December 31, 2024 were as follows (in thousands):

[0001628280-25-020355:notes:291]
| Year Ended December 31: |  |
| 2025 | $ | 2,181 |  |
| 2026 | 2,963 |  |
| 2027 | 3,105 |  |
| 2028 | 3,199 |  |
| 2029 | 3,292 |  |
| 2030 | 3,386 |  |
| 2031 | 1,444 |  |
| Total future lease payments | 19,570 |  |
| Less: imputed interest | (5,041) |  |
| Present value of operating lease liability | $ | 14,529 |  |


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001628280-25-020355:notes:292]
Accounts Receivable
Allowance for Expected Credit Losses

[0001628280-25-020355:notes:293]
Changes in the allowance for expected credit losses were as follows (in thousands):

[0001628280-25-020355:notes:294]
|  | Allowance for Expected Credit Losses |
| December 31, 2021 | $ | (50) |  |
| Provisions | (150) |  |
| Write-offs, net of recoveries | — |
| December 31, 2022 | $ | (200) |  |
| Provisions | (410) |  |
| Write-offs, net of recoveries | 28 |
| December 31, 2023 | $ | (582) |  |
| Provisions | (155) |  |
| Write-offs, net of recoveries | 3 |
| December 31, 2024 | $ | (734) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001628280-25-020355:notes:295]
Inventory
Inventory consisted of the following (in thousands):

[0001628280-25-020355:notes:296]
|  | December 31, |
|  | 2024 |  | 2023 |
|  |  |  | (Restated) |
| Raw materials | $ | 4,362 |  |  | $ | 1,869 |  |
| Finished goods |  |  |  |
| Finished goods inventory | 12,153 |  |  | 7,638 |  |
| Uninstalled inventory | 448 |  |  | 837 |  |
| Total | $ | 16,963 |  |  | $ | 10,344 |  |

[0001628280-25-020355:notes:297]
As discussed in Note 2, Restatement of Previously Issued Consolidated Financial Statements, the Company offers products for purchase or multi-year subscription leases. For equipment for which the revenue recognition start date was moved to a later date due to the timing of the transfer of control, the equipment cost was added back to finished goods inventory (for equipment sales) until the point in time that the Company transferred control of the equipment to the customer, corresponding to the revenue recognition start date. Amounts added back to finished goods inventory are included in Uninstalled inventory in the table above.


## evlv:PrepaidExpenseAndOtherAssetsCurrentTextBlock

[0001628280-25-020355:notes:298]
Prepaid expenses and other current assets
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001628280-25-020355:notes:299]
|  | December 31, |
|  | 2024 |  | 2023 |
|  |  |  | (Restated) |
| Prepaid deposits | $ | 12,582 |  |  | $ | 12,177 |  |
| Prepaid subscriptions | 2,087 |  |  | 1,868 |  |
| Current portion of net investment in sales-type leases | 376 |  |  | 367 |  |
| Prepaid insurance | 1,167 |  |  | 1,208 |  |
| Other | 1,709 |  |  | 1,337 |  |
| Total | $ | 17,921 |  |  | $ | 16,957 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-25-020355:notes:300]
Property and Equipment, Net
Property and equipment, net consisted of the following (in thousands):

[0001628280-25-020355:notes:301]
|  | December 31, |
|  | 2024 |  | 2023 |
|  |  |  | (Restated) |
| Computers and telecom equipment | $ | 2,064 |  |  | $ | 1,331 |  |
| Lab equipment | 5,564 |  |  | 1,171 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 607 |  |  | 566 |  |
| Leased equipment | 112,078 |  |  | 80,188 |  |
| Capitalized software | 14,555 |  |  | 8,629 |  |
| Sales demo equipment | 3,649 |  |  | 2,758 |  |
| Vehicles | 604 |  |  | — |  |
| Equipment held for lease1 | 17,347 |  |  | 32,910 |  |
| Construction in progress | 477 |  |  | 2,493 |  |
|  | 157,056 |  |  | 130,157 |  |
| Less: Accumulated depreciation and amortization | (33,395) |  |  | (16,996) |  |
|  | $ | 123,661 |  |  | $ | 113,161 |  |

[0001628280-25-020355:notes:302]
1 Represents equipment that has not yet been deployed to a customer and, accordingly, is not being depreciated.

[0001628280-25-020355:notes:303]
As of December 31, 2024 and 2023, the net book value of capitalized software was $11.1 million and $7.0 million, respectively. These amounts include $1.7 million and approximately $0.7 million of capitalized stock compensation costs, respectively. Depreciation expense and amortization expense related to property and equipment was $17.4 million, $9.7 million (as restated), and $5.4 million (as restated) for the years ended December 31, 2024, 2023, and 2022, respectively, which included amortization expense of capitalized software of $1.7 million, $1.0 million, and $0.6 million for the years ended December 31, 2024, 2023, and 2022, respectively.

[0001628280-25-020355:notes:304]
Leased equipment and the related accumulated depreciation were as follows:

[0001628280-25-020355:notes:305]
|  | December 31, |
|  | 2024 |  | 2023 |
|  |  |  | (Restated) |
| Leased equipment | $ | 112,078 |  |  | $ | 80,188 |  |
| Accumulated depreciation | (25,726) |  |  | (13,026) |  |
| Leased equipment, net | $ | 86,352 |  |  | $ | 67,162 |  |

[0001628280-25-020355:notes:306]
Depreciation expense related to leased units was $13.6 million, $7.7 million (as restated), and $4.2 million (as restated) during the years ended December 31, 2024, 2023, and 2022, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.

[0001628280-25-020355:notes:307]
Loss from impairment of property and equipment was $0.2 million, $0.3 million, and $1.2 million during the years ended December 31, 2024, 2023, and 2022, respectively. This primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in an impairment of the remaining economic value of such units. During the year ended December 31, 2024, the company recorded an impairment charge related to certain of its software development projects that had previously been capitalized. This resulted in an impairment charge of $1.0 million, and was recorded in cost of subscription revenue.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001628280-25-020355:notes:308]
Accrued Expenses and Other Current Liabilities
Accrued expenses and other current liabilities consisted of the following (in thousands):

[0001628280-25-020355:notes:309]
|  | December 31, |
|  | 2024 |  | 2023 |
|  |  |  | (Restated) |
| Accrued employee compensation and benefits expense | $ | 5,332 |  |  | $ | 7,780 |  |
| Accrued professional services and consulting | 5,674 |  |  | 1,704 |  |
| Accrued sales tax | 1,109 |  |  | 1,643 |  |
| Purchase order cancellation fees | — |  |  | 1,188 |  |
| Other | 7,393 |  |  | 3,388 |  |
|  | $ | 19,508 |  |  | $ | 15,703 |  |

[0001628280-25-020355:notes:310]
Included in accrued employee compensation and benefits expense in the table above is $2.0 million of charges related to the departure of certain employees in the fourth quarter of 2024 as a result of the Investigation. These charges primarily included continuation of pay through the fourth quarter of 2025 for those individuals, substantially all of which remained unpaid as of December 31, 2024.


## us-gaap:DebtDisclosureTextBlock

[0001628280-25-020355:notes:311]
Long-term DebtIn December 2022, the Company entered into a loan and security agreement (the "2022 SVB Credit Agreement") with Silicon Valley Bank ("SVB") in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. Subsequently, on March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. During the year ended December 31, 2023, the Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs. The Company had no long-term debt as of December 31, 2024 and December 31, 2023.


## evlv:WarrantsAndRightsNoteDisclosureTextBlock

[0001628280-25-020355:notes:312]
Warrants
As of December 31, 2024 and 2023, warrants to purchase the following classes of common stock outstanding consisted of the following:

[0001628280-25-020355:notes:313]
| December 31, 2024 |
| Warrant Description |  | Issuance Date |  | ContractualTerm(in years) |  | Underlying EquityInstrument |  | Balance SheetClassification |  | Shares IssuableUpon Exerciseof Warrant |  | WeightedAverageExercise Price |
| Finback Common Stock Warrants (see Note 16) |  | January 13, 2021 |  | 10 |  | Common stock |  | Equity |  | 117,423 |  |  | $ | 0.42 |  |
| Public Warrants (see Note 3) |  | July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,893 |  |  | $ | 11.50 |  |
|  |  |  |  |  |  |  |  |  |  | 14,442,316 |  |  |  |

[0001628280-25-020355:notes:314]
| December 31, 2023 |
| Warrant Description |  | Issuance Date |  | ContractualTerm(in years) |  | Underlying EquityInstrument |  | Balance SheetClassification |  | Shares IssuableUpon Exerciseof Warrant |  | WeightedAverageExercise Price |
| Finback Common Stock Warrants (see Note 16) |  | January 13, 2021 |  | 10 |  | Common stock |  | Equity |  | 1,317,327 |  |  | $ | 0.42 |  |
| Public Warrants (see Note 3) |  | July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,893 |  |  | $ | 11.50 |  |
|  |  |  |  |  |  |  |  |  |  | 15,642,220 |  |  |  |


## evlv:CommonStockDisclosureTextBlock

[0001628280-25-020355:notes:315]
Common Stock
Each share of common stock entitles the holder to one vote on all matters submitted to a vote of the Company’s stockholders. Common stockholders are entitled to receive dividends, as may be declared by the board of directors, subject to the preferential dividend rights of Preferred Stock. As of December 31, 2024 and 2023, no cash dividends had been declared or paid.
As of December 31, 2024 and 2023, the Company had reserved 78,252,044 and 80,298,297 shares, respectively, of common stock for the exercise of outstanding stock options, vesting of outstanding restricted stock units, vesting of contingent earn-out shares, vesting of contingently issuable common stock, granting of awards under the Company’s 2021 Equity Incentive Plan (see Note 16), and the exercise of outstanding warrants (see Note 14). In addition, as of December 31, 2024 and 2023, the Company had 7,828,349 and 6,315,248 shares, respectively, of common stock available to be issued under the 2021 Employee Stock Purchase Plan (see Note 16).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-25-020355:notes:316]
Stock-Based Compensation
2021 Equity Incentive Plan

[0001628280-25-020355:notes:317]
The Company’s 2021 Equity Incentive Plan (the “2021 Plan”) provides for the Company to grant incentive stock options or nonqualified stock options, restricted stock awards, restricted stock units, performance stock units, and other stock-based awards to employees, officers, directors, and non-employees of the Company. A total of 21,177,295 shares of common stock were initially authorized under the 2021 Plan, subject to annual evergreen increases of up to 5% of total common shares outstanding as of the end of the prior year. As of December 31, 2024, 16,670,634 shares were available for future grant under the 2021 Plan. Shares, units, and options that are expired, forfeited, canceled, or otherwise terminated without having been fully exercised will be available for future grant under the 2021 Plan. In addition, shares of common stock that are tendered to the Company by a participant to exercise an award are added to the number of shares of common stock available for future grants.

[0001628280-25-020355:notes:318]
The 2021 Plan is administered by the Board of Directors or, at the discretion of the Board of Directors, by a committee of the Board of Directors. The exercise prices, vesting, and other restrictions are determined at the discretion of the Board of Directors, or its committee if so delegated, except that the exercise price per share of stock options may not be less than 100% of the fair market value of a share of common stock on the date of grant and the term of the stock option may not be greater than ten years. Stock options granted to employees, officers, members of the Board of Directors and non-employees vesting terms are determined on an individual basis on the date of grant. Prior to the closing of the Merger, the Company’s Board of Directors valued the Company’s common stock, taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors which may have changed since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the fair value of each share of common stock underlying stock-based awards is based on the closing price of our common stock as reported by Nasdaq on the date of grant.

[0001628280-25-020355:notes:319]
Stock Options

[0001628280-25-020355:notes:320]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the years ended December 31, 2024 and 2023:

[0001628280-25-020355:notes:321]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |
| Risk-free interest rate | 4.1 | % |  | 4.2 | % |
| Expected term (in years) | 6.1 |  | 6.1 |
| Expected volatility | 90.0 | % |  | 87.5 | % |
| Expected dividend yield | 0.0 | % |  | 0.0 | % |

[0001628280-25-020355:notes:322]
The following tables summarize the Company’s stock option activity under the 2021 Equity Incentive Plan (in thousands, except for share and per share data):

[0001628280-25-020355:notes:323]
|  | Number ofShares |  | WeightedAverageExercise Price |  | WeightedAverageRemainingContractual Term (in years) |  | AggregateIntrinsic Value |
| Outstanding as of December 31, 2023 | 20,324,528 |  | $ | 1.04 |  |  |  |  |  |
| Granted | 2,725,625 |  | 3.63 |  |  |  |  |  |
| Exercised | (2,557,792) |  | 0.71 |  |  |  |  |  |
| Forfeited | (2,296,608) |  | 3.39 |  |  |  |  |  |
| Expired | (69,816) |  | 0.74 |  |  |  |  |  |
| Outstanding as of December 31, 2024 | 18,125,937 |  | $ | 1.18 |  |  | 3.8 |  | $ | 50,186 |  |
| Vested and expected to vest as of December 31, 2024 | 18,125,937 |  | $ | 1.18 |  |  | 3.8 |  | $ | 50,186 |  |
| Options exercisable as of December 31, 2024 | 16,096,510 |  | $ | 0.90 |  |  | 3.2 |  | $ | 49,028 |  |

[0001628280-25-020355:notes:324]
The aggregate intrinsic value of options is calculated as the difference between the exercise price of the stock options and the fair value of the Company’s common stock for those options that had exercise prices lower than the fair value of the Company’s common stock.

[0001628280-25-020355:notes:325]
The weighted average grant date fair value of stock options granted was $2.77 and $2.35 during the years ended December 31, 2024 and 2023, respectively. The aggregate intrinsic value of the stock options exercised was $7.3 million and $8.7 million during the years ended December 31, 2024 and 2023, respectively.

[0001628280-25-020355:notes:326]
Restricted Stock Units

[0001628280-25-020355:notes:327]
The following table summarizes the Company’s restricted stock units activity under its existing restricted stock unit plan:

[0001628280-25-020355:notes:328]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2023 | 13,046,679 |  | $ | 3.49 |  |
| Granted | 8,974,392 |  | 3.54 |  |
| Vested | (5,354,197) |  | 3.60 |  |
| Forfeited | (4,551,217) |  | 3.45 |  |
| Outstanding as of December 31, 2024 | 12,115,657 |  | $ | 3.50 |  |

[0001628280-25-020355:notes:329]
During the years ended December 31, 2024 and 2023, the aggregate grant-date fair value of restricted stock units issued under the 2021 Plan was $31.8 million and $33.0 million, respectively. RSUs generally vest ratably over a three year period subject to the grantee's continued service through the applicable vesting date. During the year ended December 31, 2024 and 2023, the total fair value of shares vested was $19.3 million and $10.1 million, respectively.

[0001628280-25-020355:notes:330]
Performance Stock Units

[0001628280-25-020355:notes:331]
The following table summarizes the Company's performance stock units activity under its existing performance stock units plan:

[0001628280-25-020355:notes:332]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2023 | 380,000 |  |  | $ | 2.64 |  |
| Granted | — |  |  | — |  |
| Vested | (380,000) |  |  | 2.64 |  |
| Forfeited | — |  |  | — |  |
| Outstanding as of December 31, 2024 | — |  |  | $ | — |  |

[0001628280-25-020355:notes:333]
Based upon the terms of the award agreements and achievement of the performance goal, 50% of the applicable performance stock units vested on January 1, 2023 and 50% on January 1, 2024, subject to the grantee’s continued service through the applicable vesting date.

[0001628280-25-020355:notes:334]
2021 Employee Stock Purchase Plan

[0001628280-25-020355:notes:335]
In July 2021, the Company’s Board of Directors adopted the 2021 Employee Stock Purchase Plan (“2021 ESPP”), which was subsequently approved by the Company’s stockholders and became effective on July 16, 2021. The 2021 ESPP authorizes the initial issuance of up to 3,435,748 shares of the Company’s common stock to eligible employees of the Company or, as designated by the Company’s Board of Directors, employees of a related company. The 2021 ESPP provides that the number of shares reserved and available for issuance under the 2021 ESPP will automatically increase each January 1, beginning on January 1, 2022 and ending on (and including) January 1, 2032, by an amount equal to the lesser of (i) 1% of the outstanding number of shares of common stock on the immediately preceding December 31 and (ii) such smaller number of shares as determined by the Company’s Board of Directors. As of December 31, 2024, 7,828,349 shares of the Company’s common stock were available for future issuance. The Company’s Board of Directors may from time to time grant or provide for the grant to eligible employees of options to purchase common stock under the 2021 ESPP during a specific offering period. As of December 31, 2024, no offerings have been approved.

[0001628280-25-020355:notes:336]
Finback Common Stock Warrants

[0001628280-25-020355:notes:337]
The Company utilized a Black-Scholes pricing model to determine the grant-date fair value of the Finback Common Stock Warrants. The assumptions used are presented in the following table:

[0001628280-25-020355:notes:338]
| Warrants - Black Scholes |  |
| Risk-free interest rate | 0.4 | % |
| Expected term (in years) | 3.0 |
| Expected volatility | 23.9 | % |
| Expected dividend yield | — | % |

[0001628280-25-020355:notes:339]
In January 2021, the Company granted equity classified warrants (the "Finback Common Stock Warrants") to purchase 2,552,913 shares of the Company's Class A common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC ("Finback"), a consulting group affiliated with one of the Company's stockholders. The Finback Common Stock Warrants vest upon meeting certain sales criteria as defined in a business development agreement (the "Finback BDA"), which has a term of 3 years. The Finback BDA expired on January 1, 2023, subject to a 1-year "tail period" expiring on January 1, 2024. During the tail period, the Finback Common Stock Warrants continued to vest related to any sale consummated by the Company for which it was determined Finback provided services prior to January 1, 2023 in furtherance of the sale. The Finback Common Stock Warrants expire in January 2031. The Finback Common Stock Warrants are accounted for under ASC 718 Compensation – Stock Compensation as the warrants vest upon certain performance conditions being met.

[0001628280-25-020355:notes:340]
As of December 31, 2024, 117,423 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $0.4 million, and there were no Finback Common Stock Warrants that were unvested, given the expiration of the 1-year tail period on January 1, 2024. The Company recognized compensation expense for the Finback Common Stock Warrants when the warrants vested based on meeting the specified sales criteria. During the year ended December 31, 2024, there was no stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants. During the year ended December 31, 2023, the Company recorded $3.1 million of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants.

[0001628280-25-020355:notes:341]
Stock-based compensation expense was classified in the consolidated statements of operations and comprehensive loss as follows (in thousands):

[0001628280-25-020355:notes:342]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (Restated) |  | (Restated) |
| Cost of revenue | $ | 788 |  | $ | 583 |  | $ | 829 |
| Research and development | 4,520 |  | 4,302 |  | 3,775 |
| Sales and marketing | 10,946 |  | 9,381 |  | 10,044 |
| General and administrative | 8,502 |  | 9,863 |  | 7,872 |
| Total stock-based compensation expense | $ | 24,756 |  | $ | 24,129 |  | $ | 22,520 |

[0001628280-25-020355:notes:343]
Stock-based compensation expense by award type recognized in the consolidated statements of operations and comprehensive loss was as follows (in thousands):

[0001628280-25-020355:notes:344]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (Restated) |  |  |
| Stock options | $ | 3,767 |  | $ | 2,925 |  | $ | 1,594 |
| Earn-out shares | 11 |  | 2,053 |  | 6,519 |
| Warrants | — |  | 3,147 |  | 4,523 |
| RSUs and PSUs | 20,978 |  | 16,004 |  | 9,884 |
| Total stock-based compensation expense | $ | 24,756 |  | $ | 24,129 |  | $ | 22,520 |

[0001628280-25-020355:notes:345]
Total unrecognized compensation expense related to stock options and restricted stock units as of December 31, 2024, was $32.9 million, which is expected to be recognized over a weighted average period of 1.8 years. Total unrecognized compensation expense related to earn-out shares associated with the share-based compensation arrangement as of December 31, 2024, was $0.1 million, which is expected to be recognized over a weighted average period of 0.8 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-020355:notes:346]
Income Taxes
The components of the Company’s loss before income tax expense are as follows (in thousands):

[0001628280-25-020355:notes:347]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (Restated) |  | (Restated) |
| United States | $ | (54,046) |  |  | $ | (108,055) |  |  | $ | (86,149) |  |
| Foreign | 29 |  |  | 58 |  |  | (646) |  |
| Loss before income tax provision | $ | (54,017) |  |  | $ | (107,997) |  |  | $ | (86,795) |  |

[0001628280-25-020355:notes:348]
Income tax expense is comprised of the following (in thousands):

[0001628280-25-020355:notes:349]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Current: |  |  |  |  |  |
| Federal | $ | — |  | $ | — |  | $ | — |
| State | — |  | 27 |  | — |
| Foreign | — |  | 24 |  | — |
| Total current income tax expense | $ | — |  | $ | 51 |  | $ | — |
| Deferred: |  |  |  |  |  |
| Federal | $ | — |  | $ | — |  | $ | — |
| State | — |  | — |  | — |
| Foreign | — |  | — |  | — |
| Total deferred income tax expense | $ | — |  | $ | — |  | $ | — |
| Total income tax expense | $ | — |  | $ | 51 |  | $ | — |

[0001628280-25-020355:notes:350]
The effective tax rate differs from the U.S. federal statutory rate primarily due to the full valuation allowance maintained on the Company’s net deferred tax assets and non-deductible fair value adjustments for the years ended December 31, 2024, 2023, and 2022. A reconciliation of the U.S. federal statutory income tax rate to the Company’s effective income tax rate is as follows:

[0001628280-25-020355:notes:351]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (Restated) |  | (Restated) |
| Federal statutory income tax rate | 21.0 % |  | 21.0 % |  | 21.0 % |
| State income taxes, net of federal benefit | 7.7 |  |  | 3.4 |  |  | 3.4 |  |
| Federal and state research and development tax credits | (0.1) |  |  | — |  |  | (1.2) |  |
| Change in fair value of contingent earn-out liability and contingently issuable common stock liability | 9.9 |  |  | (4.4) |  |  | 3.3 |  |
| Change in valuation allowance | (42.9) |  |  | (17.1) |  |  | (23.5) |  |
| Change in uncertain tax positions | (0.1) |  |  | (0.4) |  |  | — |  |
| Change in tax rate | 3.3 |  |  | 0.7 |  |  | (0.1) |  |
| Stock-based compensation | 1.1 |  |  | (0.6) |  |  | (0.2) |  |
| Non-deductible compensation | 0.5 |  |  | (2.4) |  |  | (2.5) |  |
| Permanent differences | (0.2) |  |  | (0.1) |  |  | (0.2) |  |
| Other | (0.2) |  |  | (0.1) |  |  | — |  |
| Effective income tax rate | 0.0 | % |  | 0.0 | % |  | 0.0 | % |

[0001628280-25-020355:notes:352]
Net deferred tax assets consisted of the following (in thousands):

[0001628280-25-020355:notes:353]
|  | December 31, |
|  | 2024 |  | 2023 |  |  |
|  |  |  | (Restated) |  |  |
| Deferred tax assets: |  |  |  |  |  |
| Net operating loss carryforwards | $ | 57,450 |  | $ | 41,914 |  |  |
| Research and development tax credit carryforwards | 3,594 |  | 3,802 |  |  |
| Capitalized research and development costs | 15,868 |  | 13,043 |  |  |
| Accrued expenses | 9,991 |  | 7,236 |  |  |
| Deferred revenue | 22,531 |  | 18,324 |  |  |
| Lease liability | 3,848 |  | 351 |  |  |
| Other | 2,960 |  | 1,304 |  |  |
| Total deferred tax assets | 116,242 |  | 85,974 |  |  |
| Valuation allowance | (106,268) |  |  | (83,113) |  |  |  |
| Total deferred tax assets, net of valuation allowance | 9,974 |  | 2,861 |  |  |
| Deferred tax liabilities: |  |  |  |  |  |
| Depreciation and amortization | (6,250) |  |  | (2,542) |  |  |  |
| Right of use lease asset | (3,706) |  | (302) |  |  |
| Other | (18) |  | (17) |  |  |
| Total deferred tax liabilities | (9,974) |  | (2,861) |  |  |
| Net deferred tax assets | $ | — |  | $ | — |  |  |

[0001628280-25-020355:notes:354]
As of December 31, 2024, the Company had federal net operating loss carryforwards of $20.1 million, which begin to expire in 2033. These losses were generated before 2018 and are subject to a 20-year carryforward period under

[0001628280-25-020355:notes:355]
the tax rules in effect at that time. The Company also had federal net operating loss carryforwards of $203.3 million and $144.1 million (as restated) as of December 31, 2024 and 2023, respectively, which do not expire but are generally limited to offsetting up to 80% of taxable income in any given year. These amounts were generated after 2017 and are subject to the provisions of the Tax Cuts and Jobs Act, which eliminated the expiration period but imposed a limitation on usage.

[0001628280-25-020355:notes:356]
The Company had state net operating loss carryforwards of $201.1 million and $142.8 million (as restated) as of December 31, 2024 and 2023, respectively, which may be available to offset future state taxable income and which begin to expire in 2033, depending on jurisdiction-specific rules. Additionally, as of December 31, 2024 and 2023, the Company had United Kingdom net operating loss carryforwards of approximately $1.7 million and $1.6 million (as restated), respectively, which do not expire under current UK tax law.

[0001628280-25-020355:notes:357]
As of December 31, 2024, the Company had gross U.S. federal and state research and development and other tax credit carryforwards of $2.4 million and $1.5 million, respectively, which may be available to offset future tax liabilities and the majority of which begin to expire in 2033 and 2030, respectively. As of December 31, 2023, the Company had gross U.S. federal and state research and development and other tax credit carryforwards of $2.5 million and $1.6 million, respectively, which may be available to offset future tax liabilities and the majority of which begin to expire in 2033 and 2029, respectively.

[0001628280-25-020355:notes:358]
Utilization of the U.S. federal and state net operating loss carryforwards and research and development tax credit carryforwards may be subject to a substantial annual limitation under Sections 382 and 383 of the Internal Revenue Code of 1986, and corresponding provisions of state law, due to ownership changes that have occurred previously or that could occur in the future. These ownership changes may limit the amount of carryforwards that can be utilized annually to offset future taxable income or tax liabilities. In general, an ownership change, as defined by Section 382, results from transactions increasing the ownership of certain stockholders or public groups in the stock of a corporation by more than 50% over a three-year period.  If the Company has experienced a change of control, as defined by Section 382, at any time since inception, utilization of the net operating loss carryforwards or research and development tax credit carryforwards would be subject to an annual limitation under Section 382, which is determined by first multiplying the value of the Company’s stock at the time of the ownership change by the applicable long-term tax-exempt rate, and then could be subject to additional adjustments. Any limitation may result in the expiration of a portion of the net operating loss carryforwards or research and development tax credit carryforwards before utilization.

[0001628280-25-020355:notes:359]
The Company believes that an ownership change within the meaning of section 382 occurred on July 16, 2021, in connection with the Merger. Based on the estimated annual limitation, the company would have been able to fully utilize all of its Section 382-limited net operating losses and tax credit carryforwards in the 2022 tax year. The Company believes that no additional ownership changes have occurred since then.

[0001628280-25-020355:notes:360]
The Company considered the evidence of its history of cumulative net operating losses incurred since inception, as well as other positive and negative evidence bearing upon its ability to realize deferred tax assets in respect of our net operating loss carryforwards, and has concluded that it is more likely than not that the Company will not realize the benefits of the deferred tax assets. Accordingly, a full valuation allowance has been established against the net deferred tax assets as of December 31, 2024 and 2023. If or when recognized, the tax benefits related to any reversal of the valuation allowance on deferred tax assets as of December 31, 2024, will be accounted for as follows: approximately $104.1 million will be recognized as a reduction of income tax expense and $2.2 million will be recorded as an increase in equity. The Company reevaluates the positive and negative evidence at each reporting period.

[0001628280-25-020355:notes:361]
Changes in the valuation allowance for deferred tax assets related primarily to the increase in net operating loss carryforwards and capitalized R&D costs and were as follows (in thousands):

[0001628280-25-020355:notes:362]
|  | December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (As Restated) |  | (As Restated) |
| Valuation allowance as of beginning of year | $ | 83,113 |  | $ | 64,677 |  | $ | 43,966 |
| Additions charged to provision for income taxes | 23,155 |  | 18,436 |  | 20,427 |
| Additions charged to equity | — |  | — |  | 332 |
| Currency translation and other | — |  | — |  | (48) |
| Valuation allowance as of end of year | $ | 106,268 |  | $ | 83,113 |  | $ | 64,677 |

[0001628280-25-020355:notes:363]
The Company accounts for income tax uncertainties in accordance with ASC 740 Income Taxes, which prescribes a recognition threshold and measurement criteria for the financial statement recognition and measurement of a tax position taken or expected to be taken in a tax return. Benefits from tax positions should be recognized in the financial statements only when it is more likely than not that the tax position will be sustained upon examination by the appropriate taxing authority that would have full knowledge of all relevant information. A tax position that meets the more likely than not recognition threshold is measured at the largest amount of benefit that is greater than fifty percent likely of being realized upon ultimate settlement. Tax positions that previously failed to meet the more likely than not recognition threshold should be recognized in the first subsequent financial reporting period in which that threshold is met. Previously recognized tax positions that no longer meet the more likely than not recognition threshold should be derecognized in the first subsequent financial reporting period in which that threshold is no longer met. ASC 740 also provides guidance on the accounting for and disclosure of liabilities for uncertain tax positions, interest and penalties. The Company’s policy is to record interest and penalties related to income taxes as part of its income tax provision.

[0001628280-25-020355:notes:364]
The following table summarizes the activity related to the Company’s uncertain tax positions (excluding interest and penalties and related tax attributes) (in thousands):

[0001628280-25-020355:notes:365]
|  | December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Balance at beginning of fiscal year | $ | 428 |  | $ | — |  | $ | — |
| Gross increases related to prior year tax positions | 20 |  | 407 |  | — |
| Foreign exchange and others | (1) |  | 21 |  | — |
| Balance at end of fiscal year | $ | 447 |  | $ | 428 |  | $ | — |

[0001628280-25-020355:notes:366]
The Company’s liability for uncertain tax positions as of December 31, 2024, includes $0.4 million related to amounts that, if recognized, would affect the effective tax rate (excluding related interest and penalties).

[0001628280-25-020355:notes:367]
The Company files income tax returns as prescribed by the tax laws of the jurisdictions in which it operates. In the normal course of business, the Company is subject to examination by federal, state, and non-US jurisdictions, where applicable. The Company is open to future tax examinations in the US under statute from 2021 to the present; however, carryforward attributes that were generated before 2021 may still be adjusted upon examination by federal, state, or local tax authorities if they either have been or will be used in a future period. The Company is also subject to future tax examinations under UK statute for the period from 2021 to the present, with a standard look-back period of 4 years, extendable to 6 years in cases of carelessness. The Company has not received notice of examination in any jurisdiction for any tax year open under statute.


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-020355:notes:368]
Net Loss per Share
Basic and diluted net loss per share attributable to common stockholders was calculated as follows (in thousands, except share and per share amounts):

[0001628280-25-020355:notes:369]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  |  |  | (Restated) |  | (Restated) |
| Numerator: |  |  |  |  |  |
| Net loss attributable to common stockholders – basic and diluted | $ | (54,017) |  |  | $ | (108,048) |  |  | $ | (86,795) |  |
| Denominator: |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 156,573,886 |  | 149,168,105 |  | 143,858,668 |
| Net loss per share attributable to common stockholders – basic and diluted | $ | (0.34) |  |  | $ | (0.72) |  |  | $ | (0.60) |  |

[0001628280-25-020355:notes:370]
The following potentially dilutive outstanding securities were excluded from the computation of diluted net loss per share attributable to common stockholders because their effect would have been anti-dilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the period:

[0001628280-25-020355:notes:371]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Options issued and outstanding | 18,125,937 |  |  | 20,324,528 |  |  | 20,396,824 |  |
| Public Warrants to purchase common stock | 14,324,893 |  |  | 14,324,893 |  |  | 14,324,994 |  |
| Warrants to purchase common stock (Finback) | 117,423 |  |  | 1,317,327 |  |  | 2,421,200 |  |
| Unvested restricted stock units | 12,115,657 |  |  | 13,046,679 |  |  | 7,501,945 |  |
| Unvested performance stock units | — |  |  | 380,000 |  |  | 864,000 |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |
| Contingently issuable common stock* | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |
|  | 61,581,410 |  |  | 66,290,927 |  |  | 62,406,463 |  |

[0001628280-25-020355:notes:372]
*Issuance of Earn-out shares and Contingently issuable common stock is contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-25-020355:notes:373]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola Solutions, Inc.

[0001628280-25-020355:notes:374]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. Effective in the fourth quarter of 2024, while the partnership agreement is still in effect, Motorola is no longer considered a related party. During the years ended December 31, 2024, 2023, and 2022, revenue from Motorola’s distributor services was $6.1 million, $9.6 million, and $11.6 million, respectively, which was a result of the Company's transition to pure subscription sales and sales under the distributor licensing model. As of December 31, 2023, accounts receivable related to Motorola’s distributor services was $1.6 million.

[0001628280-25-020355:notes:375]
Reseller Agreement with Stanley Black & Decker

[0001628280-25-020355:notes:376]
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB (“Securitas”) in 2023. Securitas, directly or through its affiliates, resells the Company's products. Effective in the first quarter of 2024, while the reseller agreement is still in effect, Securitas is no longer considered a related party. During the year ended December 31, 2023 and 2022, revenue from Stanley Black & Decker’s reseller services was $1.7 million and $1.9 million. As of December 31, 2023, accounts receivable related to Stanley Black & Decker’s reseller services was $0.6 million.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-25-020355:notes:377]
Commitments and Contingencies
Indemnification Agreements

[0001628280-25-020355:notes:378]
In the ordinary course of business, the Company provides indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. Based on historical experience and evaluation of the agreements, we do not believe that any payments related to our indemnities will have a material impact on our financial condition or results of operations.

[0001628280-25-020355:notes:379]
Legal Proceedings

[0001628280-25-020355:notes:380]
We are from time to time subject to various claims, lawsuits, government and regulatory examinations, inquiries, information requests and investigations, and other legal and administrative proceedings arising in the ordinary course of business. The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. Except for the regulatory matters discussed below, based upon information presently known to management, the Company has not accrued a loss for any other legal matters, as a loss is not probable and reasonably estimable. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

[0001628280-25-020355:notes:381]
General Litigation

[0001628280-25-020355:notes:382]
On March 25, 2024, a putative class action lawsuit was filed against the Company in the United States District Court for the District of Massachusetts (the “Class Action”). The Class Action is a consolidation of two lawsuits, the second of which was filed on November 1, 2024, filed against the Company, certain former executives, a current director,

[0001628280-25-020355:notes:383]
and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees.

[0001628280-25-020355:notes:384]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the anticipated motion to dismiss in the Class Action. On March 28, 2025, we filed a motion to dismiss the claims.

[0001628280-25-020355:notes:385]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Delaware Derivative Action”). The Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. Although the Delaware Derivative Action is in the early stages, we anticipate filing a motion to dismiss the claims if the case moves forward.

[0001628280-25-020355:notes:386]
We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. While a loss from this litigation is reasonably possible, we cannot reasonably estimate a range of possible losses at this time, as the proceedings remain in the early stages, alleged damages have not been specified, there is uncertainty as to the outcome of our anticipated motion to dismiss in the Class Action which was filed on March 28, 2025, there is uncertainty as to the likelihood of the proposed class in the Class Action being certified or the ultimate size of any class if certified, there is uncertainty as to the final complaint in the Massachusetts Derivative Action, as the plaintiff will not identify an operative complaint or file a consolidated complaint until disposition of our anticipated motion to dismiss in the Class Action, and there are significant factual and legal issues to be resolved in both the securities and derivative actions. For these reasons, we have not recorded a loss contingency liability for the above litigation as of December 31, 2024.

[0001628280-25-020355:notes:387]
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.

[0001628280-25-020355:notes:388]
Regulatory and Governmental Matters

[0001628280-25-020355:notes:389]
As previously disclosed, on October 12, 2023, the Company announced that the U.S. Federal Trade Commission (the “FTC”) had requested information about certain aspects of its marketing practices. The Company reached a settlement with the FTC and on December 5, 2024, a Stipulated Order for Permanent Injunction and Other Relief (the “Order”) was entered in the United States District Court for the District of Massachusetts Eastern Division. The Order (i) required that the Company permit a limited cohort of school customers to cancel their contracts, (ii) required that the Company take certain compliance actions and meet record keeping obligations, and (iii) enjoined the Company from making misleading or unsubstantiated marketing claims. The Order did not include any monetary relief. The period during which eligible customers may cancel closed on March 30, 2025. Any inability to adequately comply with the terms of the Order could result in enforcement actions or penalties imposed by the FTC.

[0001628280-25-020355:notes:390]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, 5 customers representing 24 Evolv Express units elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled

[0001628280-25-020355:notes:391]
are required to be returned to the customer, but these amounts were immaterial for the year ended December 31, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for year ended December 31, 2024, as revenue will continue to be recognized on these deals through the cancellation dates of each contract, all of which are in June 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of December 31, 2024 were impacted by the cancellations.

[0001628280-25-020355:notes:392]
As previously reported, the Company self-reported to the Division of Enforcement of the Securities and Exchange Commission ("SEC") the Investigation. The Company has since received requests for documents and information from the SEC relating to this matter. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("USAO SDNY") relating to these same issues, and has since received additional requests for documents and information relating to this matter. The Company is cooperating with these investigations.

[0001628280-25-020355:notes:393]
As previously disclosed, in February 2024, the Company received a subpoena from the Division of Enforcement of the SEC, requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation.

[0001628280-25-020355:notes:394]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of legal and regulatory matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.

[0001628280-25-020355:notes:395]
Any resolution or litigation with the SEC, USAO SDNY, or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to SEC or USAO SDNY matters. The Company's defense counsel costs in connection with the securities litigation and the related SEC and USAO SDNY matters are being covered under its directors and officers insurance policies subject to a typical reservation of rights. The Company has met the retention limits under these policies with respect to these matters and currently expects these policies will provide coverage for certain costs related to these matters, including certain expenses that have previously been paid. However, the Company cannot provide any assurance that costs related to these matters will not exceed the limits of its insurance policies, that such claims are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.

[0001628280-25-020355:notes:396]
Contract manufacturers

[0001628280-25-020355:notes:397]
The Company generally contracts with its contract manufacturer, Columbia Tech, on a cancellable, purchase-order basis. The Company has a contract in the normal course of business with Columbia Tech to provide manufacturing services for the Company's equipment sold or leased to customers. While these contracts are cancellable by the Company upon prior notice, payments due upon cancellation consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. These payments are not determinable, but could result in a material purchase commitment if the Company were to cancel their open purchase orders.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001628280-25-020355:notes:398]
Benefit Plans
The Company established a defined contribution savings plan under Section 401(k) of the Code. This plan covers all employees who meet minimum age and service requirements and allows participants to defer a portion of their annual compensation on a pre-tax basis. The Company made $0.8 million and $0.3 million matching contributions to the plan during the years ended December 31, 2024 and December 31, 2023, respectively. The Company did not make any matching contributions to the plan during the year ended December 31, 2022.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-25-020355:notes:399]
Segment Information
The Company determined that it has one operating and reporting segment after considering the Company’s organizational structure and the information regularly reviewed and evaluated by the Company’s CODM in deciding how to allocate resources and assess performance. The Company has determined that its CODM is its President and Chief Executive Officer. The CODM evaluates the performance of our segment based upon consolidated net income and considers budget-to-actual or forecast-to-actual variances to assess performance and make decisions about allocating resources. The CODM evaluates segment assets based on total assets on the consolidated balance sheets. Asset information is not presented here because its presentation here would be duplicative of the consolidated balance sheets. On the basis of these factors, the Company determined that it operates and manages its business as one operating and reporting segment, that develops, manufactures, markets and sells security screening products and specific services, and accordingly has one reportable segment for financial reporting purposes.

[0001628280-25-020355:notes:400]
Information by reportable segment is as follows (in thousands):

[0001628280-25-020355:notes:401]
|  | Twelve Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2022 |
| Segment revenue | $ | 103,865 |  |  | $ | 79,565 |  |  | $ | 52,719 |  |
| Less: |  |  |  |  |  |
| Employee expense | 66,847 |  |  | 61,287 |  |  | 45,663 |  |
| Travel and expense | 6,043 |  |  | 6,159 |  |  | 3,863 |  |
| Capitalized R&D expense | (6,027) |  |  | (3,963) |  |  | (1,706) |  |
| Stock-based compensation expense | 24,756 |  |  | 24,129 |  |  | 22,520 |  |
| Other one-time expenses | 18,072 |  |  | 4,141 |  |  | 3,250 |  |
| Consulting and contract staffing | 12,732 |  |  | 11,651 |  |  | 9,499 |  |
| Software subscriptions | 6,814 |  |  | 4,541 |  |  | 2,655 |  |
| Depreciation and amortization | 17,375 |  |  | 9,702 |  |  | 5,443 |  |
| Other cost of revenue | 18,320 |  |  | 31,347 |  |  | 43,798 |  |
| Other operating expenses | 21,240 |  |  | 20,627 |  |  | 20,684 |  |
| Other segment items1 | (28,290) |  |  | 17,941 |  |  | (16,155) |  |
| Provision for income taxes | — |  |  | 51 |  |  | — |  |
| Segment net loss | $ | (54,017) |  |  | $ | (108,048) |  |  | $ | (86,795) |  |

[0001628280-25-020355:notes:402]
1 Refer to Total other income (expense), net in the Consolidated Statements of Operations and Comprehensive Loss.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001628280-25-020355:notes:403]
Restatement of Quarterly Financial Information (Unaudited)
The following tables present selected unaudited condensed consolidated Statements of Operations and Comprehensive Income (Loss) for each quarter of the periods indicated:

[0001628280-25-020355:notes:404]
|  | Three Months Ended |
|  | March 31, 2024 |  | June 30, 2024 |  | September 30, 2024 |  | December 31, 2024 |
|  | (Restated) |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 1,491 |  |  | $ | 1,954 |  |  | $ | 1,344 |  |  | $ | 1,675 |  |
| Subscription revenue | 14,219 |  |  | 15,655 |  |  | 17,909 |  |  | 17,263 |  |
| Service revenue | 5,252 |  |  | 5,566 |  |  | 6,085 |  |  | 6,564 |  |
| License fee and other revenue | 1,219 |  |  | 2,049 |  |  | 2,022 |  |  | 3,598 |  |
| Total revenue | 22,181 |  |  | 25,224 |  |  | 27,360 |  |  | 29,100 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 3,114 |  |  | 2,839 |  |  | 2,616 |  |  | 2,166 |  |
| Cost of subscription revenue | 5,585 |  |  | 6,309 |  |  | 7,348 |  |  | 8,604 |  |
| Cost of service revenue | 1,198 |  |  | 1,321 |  |  | 1,404 |  |  | 1,476 |  |
| Cost of license fee and other revenue | 129 |  |  | 172 |  |  | 183 |  |  | 113 |  |
| Total cost of revenue | 10,026 |  |  | 10,641 |  |  | 11,551 |  |  | 12,359 |  |
| Gross profit | 12,155 |  |  | 14,583 |  |  | 15,809 |  |  | 16,741 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,396 |  |  | 5,850 |  |  | 5,810 |  |  | 5,390 |  |
| Sales and marketing | 15,859 |  |  | 17,011 |  |  | 14,966 |  |  | 13,455 |  |
| General and administrative | 11,806 |  |  | 14,093 |  |  | 13,976 |  |  | 16,759 |  |
| Loss from impairment of property and equipment | — |  |  | — |  |  | 209 |  |  | 15 |  |
| Total operating expenses | 34,061 |  |  | 36,954 |  |  | 34,961 |  |  | 35,619 |  |
| Loss from operations | (21,906) |  |  | (22,371) |  |  | (19,152) |  |  | (18,878) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest income | 1,085 |  |  | 681 |  |  | 628 |  |  | 548 |  |
| Other income (expense), net | (28) |  |  | (39) |  |  | 34 |  |  | (50) |  |
| Change in fair value of contingent earn-out liability | 6,899 |  |  | 16,514 |  |  | (8,321) |  |  | 1,218 |  |
| Change in fair value of contingently issuable common stock liability | 527 |  |  | 3,747 |  |  | (2,056) |  |  | 311 |  |
| Change in fair value of public warrant liability | 2,151 |  |  | 4,886 |  |  | (1,576) |  |  | 1,131 |  |
| Total other income (expense), net | 10,634 |  |  | 25,789 |  |  | (11,291) |  |  | 3,158 |  |
| Net (loss) income | $ | (11,272) |  |  | $ | 3,418 |  |  | $ | (30,443) |  |  | $ | (15,720) |  |

[0001628280-25-020355:notes:405]
|  | Three Months Ended |
|  | March 31, 2023 |  | June 30, 2023 |  | September 30, 2023 |  | December 31, 2023 |
|  | (Restated) |  | (Restated) |  | (Restated) |  | (Restated) |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 10,612 |  |  | $ | 6,852 |  |  | $ | 3,456 |  |  | $ | 1,848 |  |
| Subscription revenue | 6,173 |  |  | 7,702 |  |  | 9,858 |  |  | 12,468 |  |
| Service revenue | 2,759 |  |  | 3,646 |  |  | 4,345 |  |  | 4,856 |  |
| License fee and other revenue | 578 |  |  | 702 |  |  | 2,302 |  |  | 1,408 |  |
| Total revenue | 20,122 |  |  | 18,902 |  |  | 19,961 |  |  | 20,580 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 12,362 |  |  | 7,417 |  |  | 3,496 |  |  | 4,692 |  |
| Cost of subscription revenue | 2,334 |  |  | 3,285 |  |  | 4,157 |  |  | 4,984 |  |
| Cost of service revenue | 583 |  |  | 1,014 |  |  | 1,219 |  |  | 1,166 |  |
| Cost of license fee and other revenue | 304 |  |  | 270 |  |  | 198 |  |  | 177 |  |
| Total cost of revenue | 15,583 |  |  | 11,986 |  |  | 9,070 |  |  | 11,019 |  |
| Gross profit | 4,539 |  |  | 6,916 |  |  | 10,891 |  |  | 9,561 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,395 |  |  | 6,389 |  |  | 6,386 |  |  | 6,303 |  |
| Sales and marketing | 12,638 |  |  | 13,596 |  |  | 14,408 |  |  | 14,344 |  |
| General and administrative | 8,928 |  |  | 10,865 |  |  | 11,261 |  |  | 11,128 |  |
| Loss from impairment of property and equipment | 137 |  |  | 157 |  |  | 28 |  |  | — |  |
| Total operating expenses | 27,098 |  |  | 31,007 |  |  | 32,083 |  |  | 31,775 |  |
| Loss from operations | (22,559) |  |  | (24,091) |  |  | (21,192) |  |  | (22,214) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (654) |  |  | — |  |  | — |  |  | — |  |
| Interest income | 953 |  |  | 1,853 |  |  | 1,791 |  |  | 1,630 |  |
| Other income (expense), net | 19 |  |  | (22) |  |  | (64) |  |  | (17) |  |
| Loss on extinguishment of debt | (626) |  |  | — |  |  | — |  |  | — |  |
| Change in fair value of contingent earn-out liability | (3,318) |  |  | (28,113) |  |  | 14,078 |  |  | 2,452 |  |
| Change in fair value of contingently issuable common stock liability | (742) |  |  | (5,095) |  |  | 2,277 |  |  | 422 |  |
| Change in fair value of public warrant liability | (1,750) |  |  | (11,751) |  |  | 8,156 |  |  | 580 |  |
| Total other income (expense), net | (6,118) |  |  | (43,128) |  |  | 26,238 |  |  | 5,067 |  |
| Loss (income) before income taxes | (28,677) |  |  | (67,219) |  |  | 5,046 |  |  | (17,147) |  |
| Provision for income taxes | — |  |  | — |  |  | — |  |  | (51) |  |
| Net (loss) income | $ | (28,677) |  |  | $ | (67,219) |  |  | $ | 5,046 |  |  | $ | (17,198) |  |

[0001628280-25-020355:notes:406]
As discussed in Note 2, Restatement of Previously Issued Financial Statements, the Company is hereby providing restated unaudited financial information for the quarterly periods ended June 30, 2022, September 30, 2022, March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024, and June 30, 2024. The following tables reflect the correction of the errors described in Note 2. The errors did not impact the condensed consolidated financial statements as of and for the three months ended March 31, 2022 and therefore this period has not been presented below. No other financial statement line items beyond those presented below were impacted. Certain amounts reported previously have been reclassified.

[0001628280-25-020355:notes:407]
The impact of the correction of the errors on the Condensed Consolidated Statements of Stockholders' Equity were solely within net (loss) income for errors impacting accumulated deficit and within stock-based compensation cost for errors impacting accumulated paid in capital, and as such the Company did not include these tables below.

[0001628280-25-020355:notes:408]
The impact of the correction of the errors on the Consolidated Statements of Cash Flows were driven by changes in the related Consolidated Balance Sheet and Condensed Consolidated Statement of Operations and Comprehensive Income (Loss) line items, except as noted by footnote under each applicable table below.

[0001628280-25-020355:notes:409]
Adjustments referenced in the following tables are described in Note 2. Restatement of Financial Statements. Where adjustments relate to multiple categories, the adjustment amounts of each category are noted below each table and sum to the total adjustment reflected. Restatement adjustments are reflected as follows:

[0001628280-25-020355:notes:410]
As of and for the Three and Six Months Ended June 30, 2024

[0001628280-25-020355:notes:411]
Restated Condensed Consolidated Balance Sheet

[0001628280-25-020355:notes:412]
|  |  |  | As of June 30, 2024 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Assets |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 35,698 |  |  | $ | — |  |  | $ | 35,698 |  |
| Marketable securities |  |  | 20,757 |  |  | — |  |  | 20,757 |  |
| Accounts receivable, net | ADJ 1 |  | 36,428 |  |  | (1,017) |  |  | 35,411 |  |
| Inventory | ADJ 1, ADJ 3 |  | 18,604 |  |  | 525 |  |  | 19,129 |  |
| Current portion of contract assets | ADJ 1, ADJ 5 |  | 1,690 |  |  | (174) |  |  | 1,516 |  |
| Current portion of commission asset | ADJ 1 |  | 4,810 |  |  | 55 |  |  | 4,865 |  |
| Prepaid expenses and other current assets | ADJ 1 |  | 19,912 |  |  | 2 |  |  | 19,914 |  |
| Total current assets |  |  | 137,899 |  |  | (609) |  |  | 137,290 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Contract assets, noncurrent | ADJ 1, ADJ 5 |  | 144 |  |  | 464 |  |  | 608 |  |
| Commission asset, noncurrent | ADJ 1 |  | 7,128 |  |  | 164 |  |  | 7,292 |  |
| Property and equipment, net | ADJ 1, ADJ 2, ADJ 3, ADJ 4 |  | 120,045 |  |  | 531 |  |  | 120,576 |  |
| Operating lease right-of-use assets |  |  | 2,161 |  |  | — |  |  | 2,161 |  |
| Other assets |  |  | 865 |  |  | — |  |  | 865 |  |
| Total assets |  |  | $ | 268,517 |  |  | $ | 550 |  |  | $ | 269,067 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 5,574 |  |  | $ | — |  |  | $ | 5,574 |  |
| Accrued expenses and other current liabilities |  |  | 15,913 |  |  | — |  |  | 15,913 |  |
| Current portion of deferred revenue | ADJ 1, ADJ 5 |  | 56,168 |  |  | 688 |  |  | 56,856 |  |
| Current portion of operating lease liabilities |  |  | 1,754 |  |  | — |  |  | 1,754 |  |
| Total current liabilities |  |  | 79,409 |  |  | 688 |  |  | 80,097 |  |
| Deferred revenue, noncurrent | ADJ 5 |  | 23,655 |  |  | 1,717 |  |  | 25,372 |  |
| Operating lease liabilities, noncurrent |  |  | 566 |  |  | — |  |  | 566 |  |
| Contingent earn-out liability |  |  | 5,706 |  |  | — |  |  | 5,706 |  |
| Contingently issuable common stock liability |  |  | 2,256 |  |  | — |  |  | 2,256 |  |
| Public warrant liability |  |  | 3,852 |  |  | — |  |  | 3,852 |  |
| Total liabilities |  |  | 115,444 |  |  | 2,405 |  |  | 117,849 |  |
| Commitments and contingencies (Note 20) |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  | — |  |  | — |  |
| Common stock |  |  | 16 |  |  | — |  |  | 16 |  |
| Additional paid-in capital |  |  | 459,745 |  |  | — |  |  | 459,745 |  |
| Accumulated other comprehensive loss |  |  | (42) |  |  | — |  |  | (42) |  |
| Accumulated deficit |  |  | (306,646) |  |  | (1,855) |  |  | (308,501) |  |
| Stockholders’ equity |  |  | 153,073 |  |  | (1,855) |  |  | 151,218 |  |
| Total liabilities and stockholders’ equity |  |  | $ | 268,517 |  |  | $ | 550 |  |  | $ | 269,067 |  |

[0001628280-25-020355:notes:413]
(a) Category references are described in Note 2. Restatement of Financial Statements. Where adjustments relate to multiple categories, the adjustment amounts of each category are noted below and sum to the total adjustment reflected in the table above:

[0001628280-25-020355:notes:414]
Inventory: ADJ 1 = $441, ADJ 3 = $84

[0001628280-25-020355:notes:415]
Property and equipment, net: ADJ 1 = $328, ADJ 2 = ($314), ADJ 3 = $464, ADJ 4 = $53

[0001628280-25-020355:notes:416]
Current portion of contract assets: ADJ 1 = ($117), ADJ 5 = ($57)

[0001628280-25-020355:notes:417]
Contract assets, noncurrent: ADJ 1 = ($4), ADJ 5 = $468

[0001628280-25-020355:notes:418]
Current portion of deferred revenue: ADJ 1 = $1,994, ADJ 5 = ($1,306)

[0001628280-25-020355:notes:419]
Restated Condensed Consolidated Statements of Operations and Comprehensive Income (Loss) Data

[0001628280-25-020355:notes:420]
|  |  |  | Three Months Ended June 30, 2024 |  | Six Months Ended June 30, 2024 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |  | As Reported |  | Adjustment |  | As Restated |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | ADJ 1 |  | $ | 2,044 |  |  | $ | (90) |  |  | $ | 1,954 |  |  | $ | 2,647 |  |  | $ | 798 |  |  | $ | 3,445 |  |
| Subscription revenue | ADJ 1 |  | 15,903 |  |  | (248) |  |  | 15,655 |  |  | 30,406 |  |  | (532) |  |  | 29,874 |  |
| Service revenue | ADJ 1 |  | 5,553 |  |  | 13 |  |  | 5,566 |  |  | 10,937 |  |  | (119) |  |  | 10,818 |  |
| License fee and other revenue | ADJ 1 |  | 2,040 |  |  | 9 |  |  | 2,049 |  |  | 3,218 |  |  | 50 |  |  | 3,268 |  |
| Total revenue |  |  | 25,540 |  |  | (316) |  |  | 25,224 |  |  | 47,208 |  |  | 197 |  |  | 47,405 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | ADJ 1, ADJ 3, ADJ 4 |  | 3,149 |  |  | (310) |  |  | 2,839 |  |  | 5,926 |  |  | 27 |  |  | 5,953 |  |
| Cost of subscription revenue | ADJ 1, ADJ 2, ADJ 3, ADJ 4 |  | 6,436 |  |  | (127) |  |  | 6,309 |  |  | 12,215 |  |  | (321) |  |  | 11,894 |  |
| Cost of service revenue | ADJ 1, ADJ 2, ADJ 4 |  | 1,311 |  |  | 10 |  |  | 1,321 |  |  | 2,522 |  |  | (3) |  |  | 2,519 |  |
| Cost of license fee and other revenue |  |  | 172 |  |  | — |  |  | 172 |  |  | 301 |  |  | — |  |  | 301 |  |
| Total cost of revenue |  |  | 11,068 |  |  | (427) |  |  | 10,641 |  |  | 20,964 |  |  | (297) |  |  | 20,667 |  |
| Gross profit |  |  | 14,472 |  |  | 111 |  |  | 14,583 |  |  | 26,244 |  |  | 494 |  |  | 26,738 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | ADJ 2, ADJ 4 |  | 5,722 |  |  | 128 |  |  | 5,850 |  |  | 11,927 |  |  | 319 |  |  | 12,246 |  |
| Sales and marketing | ADJ 1, ADJ 4 |  | 16,892 |  |  | 119 |  |  | 17,011 |  |  | 32,897 |  |  | (27) |  |  | 32,870 |  |
| General and administrative | ADJ 4 |  | 14,185 |  |  | (92) |  |  | 14,093 |  |  | 26,025 |  |  | (126) |  |  | 25,899 |  |
| Total operating expenses |  |  | 36,799 |  |  | 155 |  |  | 36,954 |  |  | 70,849 |  |  | 166 |  |  | 71,015 |  |
| Loss from operations |  |  | (22,327) |  |  | (44) |  |  | (22,371) |  |  | (44,605) |  |  | 328 |  |  | (44,277) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 681 |  |  | — |  |  | 681 |  |  | 1,766 |  |  | — |  |  | 1,766 |  |
| Other expense, net |  |  | (39) |  |  | — |  |  | (39) |  |  | (67) |  |  | — |  |  | (67) |  |
| Change in fair value of contingent earn-out liability |  |  | 16,514 |  |  | — |  |  | 16,514 |  |  | 23,413 |  |  | — |  |  | 23,413 |  |
| Change in fair value of contingently issuable common stock liability |  |  | 3,747 |  |  | — |  |  | 3,747 |  |  | 4,274 |  |  | — |  |  | 4,274 |  |
| Change in fair value of public warrant liability |  |  | 4,886 |  |  | — |  |  | 4,886 |  |  | 7,037 |  |  | — |  |  | 7,037 |  |
| Total other income (expense), net |  |  | 25,789 |  |  | — |  |  | 25,789 |  |  | 36,423 |  |  | — |  |  | 36,423 |  |
| Loss before income taxes |  |  | 3,462 |  |  | (44) |  |  | 3,418 |  |  | (8,182) |  |  | 328 |  |  | (7,854) |  |
| Net income (loss) |  |  | $ | 3,462 |  |  | $ | (44) |  |  | $ | 3,418 |  |  | $ | (8,182) |  |  | $ | 328 |  |  | $ | (7,854) |  |
| Net income (loss) attributable to common stockholders - basic and diluted |  |  | $ | 3,421 |  |  | $ | (44) |  |  | $ | 3,377 |  |  | $ | (8,182) |  |  | $ | 328 |  |  | $ | (7,854) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 156,473,080 |  |  | — |  |  | 156,473,080 |  |  | 154,774,899 |  |  | — |  |  | 154,774,899 |  |
| Diluted |  |  | 171,563,943 |  |  | — |  |  | 171,563,943 |  |  | 154,774,899 |  |  | — |  |  | 154,774,899 |  |
| Net income (loss) per share |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | $ | 0.02 |  |  | $ | — |  |  | $ | 0.02 |  |  | $ | (0.05) |  |  | $ | — |  |  | $ | (0.05) |  |
| Diluted |  |  | $ | 0.02 |  |  | $ | — |  |  | $ | 0.02 |  |  | $ | (0.05) |  |  | $ | — |  |  | $ | (0.05) |  |
| Net income (loss) |  |  | $ | 3,462 |  |  | $ | (44) |  |  | $ | 3,418 |  |  | $ | (8,182) |  |  | $ | 328 |  |  | $ | (7,854) |  |
| Other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  | 8 |  |  | — |  |  | 8 |  |  | 11 |  |  | — |  |  | 11 |  |
| Total other comprehensive income (loss) |  |  | 8 |  |  | — |  |  | 8 |  |  | 11 |  |  | — |  |  | 11 |  |
| Total comprehensive income (loss) |  |  | $ | 3,470 |  |  | $ | (44) |  |  | $ | 3,426 |  |  | $ | (8,171) |  |  | $ | 328 |  |  | $ | (7,843) |  |

[0001628280-25-020355:notes:421]
Three months ended:

[0001628280-25-020355:notes:422]
Cost of product revenue: ADJ 1 = $12, ADJ 3 = ($270), ADJ 4 = ($52)

[0001628280-25-020355:notes:423]
Cost of subscription revenue: ADJ 1 = ($60), ADJ 2 = ($2), ADJ 3 = ($64), ADJ 4 = ($1)

[0001628280-25-020355:notes:424]
Cost of service revenue: ADJ 1 = $1, ADJ 2 = ($2), ADJ 4 = $11

[0001628280-25-020355:notes:425]
Research and development: ADJ 2 = $70, ADJ 4 =  $58

[0001628280-25-020355:notes:426]
Sales and marketing: ADJ 1 = ($16), ADJ 4 = $135

[0001628280-25-020355:notes:427]
Six months ended:

[0001628280-25-020355:notes:428]
Cost of product revenue: ADJ 1 = $397, ADJ 3 = ($314), ADJ 4 = ($56)

[0001628280-25-020355:notes:429]
Cost of subscription revenue: ADJ 1 = ($116), ADJ 2 = ($3), ADJ 3 = ($235), ADJ 4 = $33

[0001628280-25-020355:notes:430]
Cost of service revenue: ADJ 2 = ($2), ADJ 4 = ($1)

[0001628280-25-020355:notes:431]
Research and development: ADJ 2 = $319

[0001628280-25-020355:notes:432]
Sales and marketing: ADJ 1 = ($27)

[0001628280-25-020355:notes:433]
Restated Condensed Consolidated Statement of Cash Flows

[0001628280-25-020355:notes:434]
|  |  |  | Six Months Ended June 30, 2024 |
|  |  |  | As Reported |  | Adjustment |  | As Restated |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (8,182) |  |  | $ | 328 |  |  | $ | (7,854) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 7,442 |  |  | (84) |  |  | 7,358 |  |
| Write-off of inventory and change in inventory reserve |  |  | 1,725 |  |  | — |  |  | 1,725 |  |
| Stock-based compensation |  |  | 13,834 |  |  | 23 |  |  | 13,857 |  |
| Amortization (accretion) of premium (discount) on marketable securities, net of change in accrued interest |  |  | 181 |  |  | — |  |  | 181 |  |
| Non-cash lease expense |  |  | 728 |  |  | — |  |  | 728 |  |
| Change in allowance for expected credit losses |  |  | 203 |  |  | — |  |  | 203 |  |
| Change in fair value of earn-out liability |  |  | (23,413) |  |  | — |  |  | (23,413) |  |
| Change in fair value of contingently issuable common stock |  |  | (4,274) |  |  | — |  |  | (4,274) |  |
| Change in fair value of public warrant liability |  |  | (7,037) |  |  | — |  |  | (7,037) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (14,020) |  |  | (47) |  |  | (14,067) |  |
| Inventory |  |  | (10,354) |  |  | 312 |  |  | (10,042) |  |
| Commission assets |  |  | (492) |  |  | (29) |  |  | (521) |  |
| Contract assets |  |  | 2,324 |  |  | (2,087) |  |  | 237 |  |
| Other assets |  |  | 337 |  |  | — |  |  | 337 |  |
| Prepaid expenses and other current assets |  |  | (2,958) |  |  | 1 |  |  | (2,957) |  |
| Accounts payable |  |  | (1,653) |  |  | — |  |  | (1,653) |  |
| Deferred revenue |  |  | 8,333 |  |  | 1,938 |  |  | 10,271 |  |
| Accrued expenses and other current liabilities |  |  | 79 |  |  | (125) |  |  | (46) |  |
| Operating lease liability |  |  | (765) |  |  | — |  |  | (765) |  |
| Net cash used in operating activities |  |  | (37,962) |  |  | 230 |  |  | (37,732) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Development of internal-use software(1) |  |  | (3,408) |  |  | 296 |  |  | (3,112) |  |
| Purchases of property and equipment(2) |  |  | (21,092) |  |  | (526) |  |  | (21,618) |  |
| Purchases of marketable securities |  |  | (14,567) |  |  | — |  |  | (14,567) |  |
| Proceeds from maturities of marketable securities |  |  | 44,918 |  |  | — |  |  | 44,918 |  |
| Net cash provided by investing activities |  |  | 5,851 |  |  | (230) |  |  | 5,621 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 636 |  |  | — |  |  | 636 |  |

[0001628280-25-020355:notes:435]
| Net cash provided by financing activities |  |  | 636 |  |  | — |  |  | 636 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 11 |  |  | — |  |  | 11 |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (31,464) |  |  | — |  |  | (31,464) |  |
| Cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 67,437 |  |  | — |  |  | 67,437 |  |
| Cash, cash equivalents and restricted cash at end of period |  |  | $ | 35,973 |  |  | $ | — |  |  | $ | 35,973 |  |
| Supplemental disclosure of non-cash activities |  |  |  |  |  |  |  |
| Transfer of property and equipment to inventory |  |  | $ | 468 |  |  | $ | — |  |  | $ | 468 |  |
| Capital expenditures incurred but not yet paid |  |  | 3,407 |  |  | — |  |  | 3,407 |  |
| Capitalization of stock compensation |  |  | 450 |  |  | (23) |  |  | 427 |  |
| Operating lease liabilities arising from obtaining right-of-use assets |  |  | 1,694 |  |  | — |  |  | 1,694 |  |
| Reconciliation of cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 35,698 |  |  | $ | — |  |  | $ | 35,698 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Total cash, cash equivalents and restricted cash shown in the statements of cash flows |  |  | $ | 35,973 |  |  | $ | — |  |  | $ | 35,973 |  |

[0001628280-25-020355:notes:436]
(1) Relates to adjustments related to ADJ 2.

[0001628280-25-020355:notes:437]
(2) Relates to the following adjustments: ADJ 3 = ($464), ADJ 4 = ($62)

[0001628280-25-020355:notes:438]
As of and for the Three Months Ended March 31, 2024

[0001628280-25-020355:notes:439]
|  |  |  | As of March 31, 2024 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Assets |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 44,596 |  |  | $ | — |  |  | $ | 44,596 |  |
| Marketable securities |  |  | 36,415 |  |  | — |  |  | 36,415 |  |
| Accounts receivable, net | ADJ 1 |  | 22,030 |  |  | (2,373) |  |  | 19,657 |  |
| Inventory | ADJ 1, ADJ 3 |  | 11,007 |  |  | 506 |  |  | 11,513 |  |
| Current portion of contract assets | ADJ 1, ADJ 5 |  | 2,538 |  |  | (1,879) |  |  | 659 |  |
| Current portion of commission asset | ADJ 1 |  | 4,516 |  |  | 52 |  |  | 4,568 |  |
| Prepaid expenses and other current assets | ADJ 1 |  | 20,700 |  |  | (5) |  |  | 20,695 |  |
| Total current assets |  |  | 141,802 |  |  | (3,699) |  |  | 138,103 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Contract assets, noncurrent | ADJ 1, ADJ 5 |  | 307 |  |  | 1,115 |  |  | 1,422 |  |
| Commission asset, noncurrent | ADJ 1 |  | 7,000 |  |  | 157 |  |  | 7,157 |  |
| Property and equipment, net | ADJ 1, ADJ 2, ADJ 3, ADJ 4 |  | 129,342 |  |  | 171 |  |  | 129,513 |  |
| Operating lease right-of-use assets |  |  | 2,535 |  |  | — |  |  | 2,535 |  |
| Other assets |  |  | 999 |  |  | — |  |  | 999 |  |
| Total assets |  |  | $ | 282,260 |  |  | $ | (2,256) |  |  | $ | 280,004 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable | ADJ 4 |  | $ | 15,584 |  |  | $ | 65 |  |  | $ | 15,649 |  |
| Accrued expenses and other current liabilities | ADJ 4 |  | 13,712 |  |  | (188) |  |  | 13,524 |  |
| Current portion of deferred revenue | ADJ 1, ADJ 5 |  | 48,913 |  |  | (3,433) |  |  | 45,480 |  |
| Current portion of operating lease liabilities |  |  | 1,713 |  |  | — |  |  | 1,713 |  |
| Total current liabilities |  |  | 79,922 |  |  | (3,556) |  |  | 76,366 |  |
| Deferred revenue, noncurrent | ADJ 5 |  | 22,808 |  |  | 3,111 |  |  | 25,919 |  |
| Operating lease liabilities, noncurrent |  |  | 980 |  |  | — |  |  | 980 |  |
| Contingent earn-out liability |  |  | 22,220 |  |  | — |  |  | 22,220 |  |
| Contingently issuable common stock liability |  |  | 6,003 |  |  | — |  |  | 6,003 |  |
| Public warrant liability |  |  | 8,738 |  |  | — |  |  | 8,738 |  |
| Total liabilities |  |  | 140,671 |  |  | (445) |  |  | 140,226 |  |
| Commitments and contingencies (Note 20) |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  | — |  |  | — |  |
| Common stock |  |  | 16 |  |  | — |  |  | 16 |  |
| Additional paid-in capital |  |  | 451,731 |  |  | — |  |  | 451,731 |  |
| Accumulated other comprehensive loss |  |  | (50) |  |  | — |  |  | (50) |  |
| Accumulated deficit |  |  | (310,108) |  |  | (1,811) |  |  | (311,919) |  |
| Stockholders’ equity |  |  | 141,589 |  |  | (1,811) |  |  | 139,778 |  |
| Total liabilities and stockholders’ equity |  |  | $ | 282,260 |  |  | $ | (2,256) |  |  | $ | 280,004 |  |

[0001628280-25-020355:notes:440]
Inventory: ADJ 1 = $452, ADJ 3 = $54

[0001628280-25-020355:notes:441]
Property and equipment, net: ADJ 1 = $267, ADJ 2 = ($247), ADJ 3 = $162, ADJ 4 = ($11)

[0001628280-25-020355:notes:442]
Current portion of contract assets: ADJ 1 = ($284), ADJ 5 = ($1,595)

[0001628280-25-020355:notes:443]
Contract assets, noncurrent: ADJ 1 = ($2), ADJ 5 = $1,117

[0001628280-25-020355:notes:444]
Current portion of deferred revenue: ADJ 1 = $156, ADJ 5 = ($3,589)

[0001628280-25-020355:notes:445]
Restated Condensed Consolidated Statement of Operations and Comprehensive Loss Data

[0001628280-25-020355:notes:446]
|  |  |  | Three Months Ended March 31, 2024 |  |  |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | ADJ 1 |  | $ | 603 |  |  | $ | 888 |  |  | $ | 1,491 |  |  |  |  |  |  |  |
| Subscription revenue | ADJ1 |  | 14,503 |  |  | (284) |  |  | 14,219 |  |  |  |  |  |  |  |
| Service revenue | ADJ1 |  | 5,384 |  |  | (132) |  |  | 5,252 |  |  |  |  |  |  |  |
| License fee and other revenue | ADJ1 |  | 1,178 |  |  | 41 |  |  | 1,219 |  |  |  |  |  |  |  |
| Total revenue |  |  | 21,668 |  |  | 513 |  |  | 22,181 |  |  |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | ADJ 1, ADJ 3, ADJ 4 |  | 2,777 |  |  | 337 |  |  | 3,114 |  |  |  |  |  |  |  |
| Cost of subscription revenue | ADJ 1, ADJ 2, ADJ 3, ADJ 4 |  | 5,779 |  |  | (194) |  |  | 5,585 |  |  |  |  |  |  |  |
| Cost of service revenue | ADJ 2, ADJ 4 |  | 1,211 |  |  | (13) |  |  | 1,198 |  |  |  |  |  |  |  |
| Cost of license fee and other revenue |  |  | 129 |  |  | — |  |  | 129 |  |  |  |  |  |  |  |
| Total cost of revenue |  |  | 9,896 |  |  | 130 |  |  | 10,026 |  |  |  |  |  |  |  |
| Gross profit |  |  | 11,772 |  |  | 383 |  |  | 12,155 |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | ADJ 2, ADJ 4 |  | 6,205 |  |  | 191 |  |  | 6,396 |  |  |  |  |  |  |  |
| Sales and marketing | ADJ 1, ADJ 4 |  | 16,005 |  |  | (146) |  |  | 15,859 |  |  |  |  |  |  |  |
| General and administrative | ADJ 4 |  | 11,840 |  |  | (34) |  |  | 11,806 |  |  |  |  |  |  |  |
| Total operating expenses |  |  | 34,050 |  |  | 11 |  |  | 34,061 |  |  |  |  |  |  |  |
| Loss from operations |  |  | (22,278) |  |  | 372 |  |  | (21,906) |  |  |  |  |  |  |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 1,085 |  |  | — |  |  | 1,085 |  |  |  |  |  |  |  |
| Other expense, net |  |  | (28) |  |  | — |  |  | (28) |  |  |  |  |  |  |  |
| Change in fair value of contingent earn-out liability |  |  | 6,899 |  |  | — |  |  | 6,899 |  |  |  |  |  |  |  |
| Change in fair value of contingently issuable common stock liability |  |  | 527 |  |  | — |  |  | 527 |  |  |  |  |  |  |  |
| Change in fair value of public warrant liability |  |  | 2,151 |  |  | — |  |  | 2,151 |  |  |  |  |  |  |  |
| Total other income (expense), net |  |  | 10,634 |  |  | — |  |  | 10,634 |  |  |  |  |  |  |  |
| Loss before income taxes |  |  | (11,644) |  |  | 372 |  |  | (11,272) |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (11,644) |  |  | $ | 372 |  |  | $ | (11,272) |  |  |  |  |  |  |  |
| Weighted average common shares outstanding – basic and diluted |  |  | 153,076,719 |  |  | — |  |  | 153,076,719 |  |  |  |  |  |  |  |
| Net loss per share - basic and diluted |  |  | $ | (0.08) |  |  | $ | 0.01 |  |  | $ | (0.07) |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (11,644) |  |  | $ | 372 |  |  | $ | (11,272) |  |  |  |  |  |  |  |
| Other comprehensive loss |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  | 3 |  |  | — |  |  | 3 |  |  |  |  |  |  |  |
| Total other comprehensive loss |  |  | 3 |  |  | — |  |  | 3 |  |  |  |  |  |  |  |
| Total comprehensive loss |  |  | $ | (11,641) |  |  | $ | 372 |  |  | $ | (11,269) |  |  |  |  |  |  |  |

[0001628280-25-020355:notes:447]
Cost of product revenue: ADJ 1 = $385, ADJ 3 = ($44), ADJ 4 = ($4)

[0001628280-25-020355:notes:448]
Cost of subscription revenue: ADJ 1 = ($56), ADJ 2 = ($1), ADJ 3 = ($171), ADJ 4  = $34

[0001628280-25-020355:notes:449]
Cost of service revenue: ADJ 2 = ($1), ADJ 4 = ($12)

[0001628280-25-020355:notes:450]
Research and development: ADJ 2 = $249, ADJ 4 =  ($58)

[0001628280-25-020355:notes:451]
Sales and marketing: ADJ 1 = ($11), ADJ 4 = ($135)

[0001628280-25-020355:notes:452]
|  |  |  | Three Months Ended March 31, 2024 |
|  |  |  | As Reported |  | Adjustment |  | As Restated |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (11,644) |  |  | $ | 372 |  |  | $ | (11,272) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,474 |  |  | (17) |  |  | 3,457 |  |
| Write-off of inventory and change in inventory reserve |  |  | 1,059 |  |  | — |  |  | 1,059 |  |
| Stock-based compensation |  |  | 6,410 |  |  | 20 |  |  | 6,430 |  |
| Amortization (accretion) of premium (discount) on marketable securities, net of change in accrued interest |  |  | 200 |  |  | — |  |  | 200 |  |
| Non-cash lease expense |  |  | 354 |  |  | — |  |  | 354 |  |
| Change in allowance for expected credit losses |  |  | (267) |  |  | — |  |  | (267) |  |
| Change in fair value of earn-out liability |  |  | (6,899) |  |  | — |  |  | (6,899) |  |
| Change in fair value of contingently issuable common stock |  |  | (527) |  |  | — |  |  | (527) |  |
| Change in fair value of public warrant liability |  |  | (2,151) |  |  | — |  |  | (2,151) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 848 |  |  | 1,309 |  |  | 2,157 |  |
| Inventory |  |  | (2,091) |  |  | 331 |  |  | (1,760) |  |
| Commission assets |  |  | (70) |  |  | (19) |  |  | (89) |  |
| Contract assets |  |  | 1,313 |  |  | (1,033) |  |  | 280 |  |
| Other assets |  |  | 203 |  |  | — |  |  | 203 |  |
| Prepaid expenses and other current assets |  |  | (3,746) |  |  | 8 |  |  | (3,738) |  |
| Accounts payable |  |  | (760) |  |  | 65 |  |  | (695) |  |
| Deferred revenue |  |  | 231 |  |  | (789) |  |  | (558) |  |
| Accrued expenses and other current liabilities |  |  | (1,628) |  |  | (315) |  |  | (1,943) |  |
| Operating lease liability |  |  | (392) |  |  | — |  |  | (392) |  |
| Net cash used in operating activities |  |  | (16,083) |  |  | (68) |  |  | (16,151) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Development of internal-use software(1) |  |  | (1,797) |  |  | 230 |  |  | (1,567) |  |
| Purchases of property and equipment(2) |  |  | (19,665) |  |  | (162) |  |  | (19,827) |  |
| Purchases of marketable securities |  |  | (14,567) |  |  | — |  |  | (14,567) |  |
| Proceeds from maturities of marketable securities |  |  | 29,241 |  |  | — |  |  | 29,241 |  |
| Net cash used in investing activities |  |  | (6,788) |  |  | 68 |  |  | (6,720) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 302 |  |  | — |  |  | 302 |  |
| Net cash provided by financing activities |  |  | 302 |  |  | — |  |  | 302 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 3 |  |  | — |  |  | 3 |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (22,566) |  |  | — |  |  | (22,566) |  |
| Cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 67,437 |  |  | — |  |  | 67,437 |  |
| Cash, cash equivalents and restricted cash at end of period |  |  | $ | 44,871 |  |  | $ | — |  |  | $ | 44,871 |  |

[0001628280-25-020355:notes:453]
| Supplemental disclosure of non-cash activities |  |  |  |  |  |  |  |
| Transfer of property and equipment to inventory |  |  | $ | 468 |  |  | $ | — |  |  | $ | 468 |  |
| Capital expenditures incurred but not yet paid |  |  | 12,030 |  |  | — |  |  | 12,030 |  |
| Capitalization of stock compensation |  |  | 195 |  |  | (20) |  |  | 175 |  |
| Operating lease liabilities arising from obtaining right-of-use assets |  |  | 1,694 |  |  | — |  |  | 1,694 |  |
| Reconciliation of cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 44,596 |  |  | $ | — |  |  | $ | 44,596 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Total cash, cash equivalents and restricted cash shown in the statements of cash flows |  |  | $ | 44,871 |  |  | $ | — |  |  | $ | 44,871 |  |

[0001628280-25-020355:notes:454]
(2) Relates to adjustments related to ADJ 4.

[0001628280-25-020355:notes:455]
As of September 30, 2023

[0001628280-25-020355:notes:456]
|  |  |  | As of September 30, 2023 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Assets |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 99,617 |  |  | $ | — |  |  | $ | 99,617 |  |
| Restricted cash |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Marketable securities |  |  | 39,487 |  |  | — |  |  | 39,487 |  |
| Accounts receivable, net | ADJ 1 |  | 29,786 |  |  | (2,445) |  |  | 27,341 |  |
| Inventory | ADJ 1 |  | 7,826 |  |  | 312 |  |  | 8,138 |  |
| Current portion of contract assets | ADJ 1, ADJ 4 |  | 3,667 |  |  | (460) |  |  | 3,207 |  |
| Current portion of commission asset |  |  | 3,908 |  |  | 41 |  |  | 3,949 |  |
| Prepaid expenses and other current assets | ADJ 1 |  | 16,500 |  |  | 5 |  |  | 16,505 |  |
| Total current assets |  |  | 201,791 |  |  | (2,547) |  |  | 199,244 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Contract assets, noncurrent | ADJ 4 |  | 496 |  |  | 126 |  |  | 622 |  |
| Commission asset, noncurrent | ADJ 1 |  | 6,888 |  |  | 122 |  |  | 7,010 |  |
| Property and equipment, net | ADJ 1, ADJ 4 |  | 93,995 |  |  | 221 |  |  | 94,216 |  |
| Operating lease right-of-use assets |  |  | 1,537 |  |  | — |  |  | 1,537 |  |
| Other assets |  |  | 1,483 |  |  | — |  |  | 1,483 |  |
| Total assets |  |  | $ | 306,465 |  |  | $ | (2,078) |  |  | $ | 304,387 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 13,887 |  |  | $ | — |  |  | $ | 13,887 |  |
| Accrued expenses and other current liabilities |  |  | 12,164 |  |  | — |  |  | 12,164 |  |
| Current portion of deferred revenue | ADJ 1, ADJ 4 |  | 53,041 |  |  | (6,335) |  |  | 46,706 |  |
| Current portion of operating lease liabilities |  |  | 1,655 |  |  | — |  |  | 1,655 |  |
| Total current liabilities |  |  | 80,747 |  |  | (6,335) |  |  | 74,412 |  |
| Deferred revenue, noncurrent | ADJ 4 |  | 19,478 |  |  | 5,642 |  |  | 25,120 |  |
| Operating lease liabilities, noncurrent |  |  | 133 |  |  | — |  |  | 133 |  |
| Contingent earn-out liability |  |  | 31,571 |  |  | — |  |  | 31,571 |  |
| Contingently issuable common stock liability |  |  | 6,952 |  |  | — |  |  | 6,952 |  |
| Public warrant liability |  |  | 11,469 |  |  | — |  |  | 11,469 |  |
| Total liabilities |  |  | 150,350 |  |  | (693) |  |  | 149,657 |  |
| Commitments and contingencies (Note 20) |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  | — |  |  | — |  |
| Common stock |  |  | 15 |  |  | — |  |  | 15 |  |
| Additional paid-in capital | ADJ 4 |  | 437,683 |  |  | 490 |  |  | 438,173 |  |
| Accumulated other comprehensive loss |  |  | (9) |  |  | — |  |  | (9) |  |
| Accumulated deficit |  |  | (281,574) |  |  | (1,875) |  |  | (283,449) |  |
| Stockholders’ equity |  |  | 156,115 |  |  | (1,385) |  |  | 154,730 |  |
| Total liabilities and stockholders’ equity |  |  | $ | 306,465 |  |  | $ | (2,078) |  |  | $ | 304,387 |  |

[0001628280-25-020355:notes:457]
Current portion of contract assets: ADJ 1 = ($329), ADJ 4 = ($131)

[0001628280-25-020355:notes:458]
Property and plant, net: ADJ 1 = $192, ADJ 4 = $29

[0001628280-25-020355:notes:459]
Current portion of deferred revenue: ADJ 1 = ($688), ADJ 4 = ($5,647)

[0001628280-25-020355:notes:460]
As of and for the Three and Six Months Ended June 30, 2023

[0001628280-25-020355:notes:461]
|  |  |  | As of June 30, 2023 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Assets |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 125,890 |  |  | $ | — |  |  | $ | 125,890 |  |
| Restricted cash |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Marketable securities |  |  | 29,647 |  |  | — |  |  | 29,647 |  |
| Accounts receivable, net | ADJ 1 |  | 32,393 |  |  | (6,250) |  |  | 26,143 |  |
| Inventory | ADJ 1 |  | 5,032 |  |  | 658 |  |  | 5,690 |  |
| Current portion of contract assets | ADJ 1 |  | 4,732 |  |  | (253) |  |  | 4,479 |  |
| Current portion of commission asset | ADJ 1 |  | 3,648 |  |  | 34 |  |  | 3,682 |  |
| Prepaid expenses and other current assets | ADJ 1 |  | 13,808 |  |  | 18 |  |  | 13,826 |  |
| Total current assets |  |  | 216,150 |  |  | (5,793) |  |  | 210,357 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Contract assets, noncurrent | ADJ 1 |  | 690 |  |  | 1 |  |  | 691 |  |
| Commission asset, noncurrent | ADJ 1 |  | 6,649 |  |  | 102 |  |  | 6,751 |  |
| Property and equipment, net | ADJ 1, ADJ 4 |  | 81,085 |  |  | 148 |  |  | 81,233 |  |
| Operating lease right-of-use assets |  |  | 1,241 |  |  | — |  |  | 1,241 |  |
| Other assets |  |  | 1,878 |  |  | — |  |  | 1,878 |  |
| Total assets |  |  | $ | 307,968 |  |  | $ | (5,542) |  |  | $ | 302,426 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 16,912 |  |  | $ | — |  |  | $ | 16,912 |  |
| Accrued expenses and other current liabilities |  |  | 10,821 |  |  | — |  |  | 10,821 |  |
| Current portion of deferred revenue | ADJ 1, ADJ 4 |  | 39,366 |  |  | (8,477) |  |  | 30,889 |  |
| Current portion of operating lease liabilities |  |  | 1,130 |  |  | — |  |  | 1,130 |  |
| Total current liabilities |  |  | 68,229 |  |  | (8,477) |  |  | 59,752 |  |
| Deferred revenue, noncurrent | ADJ 4 |  | 20,715 |  |  | 3,832 |  |  | 24,547 |  |
| Operating lease liabilities, noncurrent |  |  | 363 |  |  | — |  |  | 363 |  |
| Contingent earn-out liability |  |  | 45,649 |  |  | — |  |  | 45,649 |  |
| Contingently issuable common stock liability |  |  | 9,229 |  |  | — |  |  | 9,229 |  |
| Public warrant liability |  |  | 19,625 |  |  | — |  |  | 19,625 |  |
| Total liabilities |  |  | 163,810 |  |  | (4,645) |  |  | 159,165 |  |
| Commitments and contingencies (Note 20) |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  | — |  |  | — |  |
| Common stock |  |  | 15 |  |  | — |  |  | 15 |  |
| Additional paid-in capital | ADJ 4 |  | 431,759 |  |  | 25 |  |  | 431,784 |  |
| Accumulated other comprehensive loss |  |  | (43) |  |  | — |  |  | (43) |  |
| Accumulated deficit |  |  | (287,573) |  |  | (922) |  |  | (288,495) |  |
| Stockholders’ equity |  |  | 144,158 |  |  | (897) |  |  | 143,261 |  |
| Total liabilities and stockholders’ equity |  |  | $ | 307,968 |  |  | $ | (5,542) |  |  | $ | 302,426 |  |

[0001628280-25-020355:notes:462]
Property and equipment, net: ADJ 1 = $118, ADJ 4 = $30

[0001628280-25-020355:notes:463]
Current portion of deferred revenue: ADJ 1 = ($4,645), ADJ 4 = ($3,832)

[0001628280-25-020355:notes:464]
Restated Condensed Consolidated Statements of Operations and Comprehensive Loss Data

[0001628280-25-020355:notes:465]
|  |  |  | Three Months Ended June 30, 2023 |  | Six Months Ended June 30, 2023 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |  | As Reported |  | Adjustment |  | As Restated |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | ADJ 1 |  | $ | 7,243 |  |  | $ | (391) |  |  | $ | 6,852 |  |  | $ | 15,997 |  |  | $ | 1,467 |  |  | $ | 17,464 |  |
| Subscription revenue | ADJ 1, ADJ 4 |  | 7,964 |  |  | (262) |  |  | 7,702 |  |  | 14,430 |  |  | (555) |  |  | 13,875 |  |
| Service revenue | ADJ 1, ADJ 4 |  | 3,905 |  |  | (259) |  |  | 3,646 |  |  | 6,691 |  |  | (286) |  |  | 6,405 |  |
| License fee and other revenue | ADJ 1 |  | 713 |  |  | (11) |  |  | 702 |  |  | 1,288 |  |  | (8) |  |  | 1,280 |  |
| Total revenue |  |  | 19,825 |  |  | (923) |  |  | 18,902 |  |  | 38,406 |  |  | 618 |  |  | 39,024 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | ADJ 1, ADJ 4 |  | 7,722 |  |  | (305) |  |  | 7,417 |  |  | 18,300 |  |  | 1,479 |  |  | 19,779 |  |
| Cost of subscription revenue | ADJ 1, ADJ 4 |  | 3,406 |  |  | (121) |  |  | 3,285 |  |  | 5,757 |  |  | (138) |  |  | 5,619 |  |
| Cost of service revenue |  |  | 1,014 |  |  | — |  |  | 1,014 |  |  | 1,597 |  |  | — |  |  | 1,597 |  |
| Cost of license fee and other revenue |  |  | 270 |  |  | — |  |  | 270 |  |  | 574 |  |  | — |  |  | 574 |  |
| Total cost of revenue |  |  | 12,412 |  |  | (426) |  |  | 11,986 |  |  | 26,228 |  |  | 1,341 |  |  | 27,569 |  |
| Gross profit |  |  | 7,413 |  |  | (497) |  |  | 6,916 |  |  | 12,178 |  |  | (723) |  |  | 11,455 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | ADJ 4 |  | 6,395 |  |  | (6) |  |  | 6,389 |  |  | 11,784 |  |  | — |  |  | 11,784 |  |
| Sales and marketing | ADJ 1, ADJ 4 |  | 13,613 |  |  | (17) |  |  | 13,596 |  |  | 26,417 |  |  | (183) |  |  | 26,234 |  |
| General and administrative | ADJ 4 |  | 10,874 |  |  | (9) |  |  | 10,865 |  |  | 19,800 |  |  | (7) |  |  | 19,793 |  |
| Loss from impairment of property and equipment |  |  | 157 |  |  | — |  |  | 157 |  |  | 294 |  |  | — |  |  | 294 |  |
| Total operating expenses |  |  | 31,039 |  |  | (32) |  |  | 31,007 |  |  | 58,295 |  |  | (190) |  |  | 58,105 |  |
| Loss from operations |  |  | (23,626) |  |  | (465) |  |  | (24,091) |  |  | (46,117) |  |  | (533) |  |  | (46,650) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | — |  |  | — |  |  | — |  |  | (654) |  |  | — |  |  | (654) |  |
| Interest income |  |  | 1,853 |  |  | — |  |  | 1,853 |  |  | 2,806 |  |  | — |  |  | 2,806 |  |
| Other expense, net |  |  | (22) |  |  | — |  |  | (22) |  |  | (3) |  |  | — |  |  | (3) |  |
| Loss on extinguishment of debt |  |  | — |  |  | — |  |  | — |  |  | (626) |  |  | — |  |  | (626) |  |
| Change in fair value of contingent earn-out liability |  |  | (28,113) |  |  | — |  |  | (28,113) |  |  | (31,431) |  |  | — |  |  | (31,431) |  |
| Change in fair value of contingently issuable common stock liability |  |  | (5,095) |  |  | — |  |  | (5,095) |  |  | (5,837) |  |  | — |  |  | (5,837) |  |
| Change in fair value of public warrant liability |  |  | (11,751) |  |  | — |  |  | (11,751) |  |  | (13,501) |  |  | — |  |  | (13,501) |  |
| Total other income (expense), net |  |  | (43,128) |  |  | — |  |  | (43,128) |  |  | (49,246) |  |  | — |  |  | (49,246) |  |
| Net loss |  |  | $ | (66,754) |  |  | $ | (465) |  |  | $ | (67,219) |  |  | $ | (95,363) |  |  | $ | (533) |  |  | $ | (95,896) |  |
| Weighted average common shares outstanding – basic and diluted |  |  | 148,882,160 |  |  | — |  |  | 148,882,160 |  |  | 147,664,534 |  |  | — |  |  | 147,664,534 |  |
| Net loss per share - basic and diluted |  |  | $ | (0.45) |  |  | $ | — |  |  | $ | (0.45) |  |  | $ | (0.65) |  |  | $ | — |  |  | $ | (0.65) |  |
| Net loss |  |  | $ | (66,754) |  |  | $ | (465) |  |  | $ | (67,219) |  |  | $ | (95,363) |  |  | $ | (533) |  |  | $ | (95,896) |  |
| Other comprehensive loss |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  | (17) |  |  | — |  |  | (17) |  |  | (33) |  |  | — |  |  | (33) |  |
| Total other comprehensive loss |  |  | (17) |  |  | — |  |  | (17) |  |  | (33) |  |  | — |  |  | (33) |  |
| Total comprehensive loss |  |  | $ | (66,771) |  |  | $ | (465) |  |  | $ | (67,236) |  |  | $ | (95,396) |  |  | $ | (533) |  |  | $ | (95,929) |  |

[0001628280-25-020355:notes:466]
Subscription revenue: ADJ 1 = ($431), ADJ 4 = $169

[0001628280-25-020355:notes:467]
Service revenue: ADJ 1 = ($90), ADJ 4 = ($169)

[0001628280-25-020355:notes:468]
Cost of product revenue: ADJ 1 = ($304), ADJ 4 = ($1)

[0001628280-25-020355:notes:469]
Cost of subscription revenue: ADJ 1 = ($83), ADJ 4 = ($38)

[0001628280-25-020355:notes:470]
Sales and marketing: ADJ 1 = ($45), ADJ 4 = $28

[0001628280-25-020355:notes:471]
Subscription revenue: ADJ 1 = ($534), ADJ 4 = ($21)

[0001628280-25-020355:notes:472]
Service revenue: ADJ 1 = ($307), ADJ 4 = $21

[0001628280-25-020355:notes:473]
Cost of product revenue: ADJ 1 = $1,782, ADJ 4 = ($303)

[0001628280-25-020355:notes:474]
Cost of subscription revenue: ADJ 1 = ($99) , ADJ 4 = ($39)

[0001628280-25-020355:notes:475]
Sales and marketing: ADJ 1 = $40, ADJ 4 = ($223)

[0001628280-25-020355:notes:476]
|  |  |  | Six Months Ended June 30, 2023 |
|  |  |  | As Reported |  | Adjustment |  | As Restated |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (95,363) |  |  | $ | (533) |  |  | $ | (95,896) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 4,087 |  |  | (137) |  |  | 3,950 |  |
| Write-off of inventory and change in inventory reserve |  |  | 337 |  |  | (303) |  |  | 34 |  |
| Loss from impairment of property and equipment |  |  | 294 |  |  | — |  |  | 294 |  |
| Stock-based compensation |  |  | 11,732 |  |  | 3 |  |  | 11,735 |  |
| Non-cash interest expense |  |  | 22 |  |  | — |  |  | 22 |  |
| Amortization (accretion) of premium (discount) on marketable securities, net of change in accrued interest |  |  | (242) |  |  | — |  |  | (242) |  |
| Non-cash lease expense |  |  | 432 |  |  | — |  |  | 432 |  |
| Change in allowance for expected credit losses |  |  | 173 |  |  | — |  |  | 173 |  |
| Loss on extinguishment of debt |  |  | 626 |  |  | — |  |  | 626 |  |
| Change in fair value of earn-out liability |  |  | 31,431 |  |  | — |  |  | 31,431 |  |
| Change in fair value of contingently issuable common stock |  |  | 5,837 |  |  | — |  |  | 5,837 |  |
| Change in fair value of public warrant liability |  |  | 13,501 |  |  | — |  |  | 13,501 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (646) |  |  | 769 |  |  | 123 |  |
| Inventory |  |  | 5,080 |  |  | 1,783 |  |  | 6,863 |  |
| Commission assets |  |  | (1,258) |  |  | (318) |  |  | (1,576) |  |
| Contract assets |  |  | (1,184) |  |  | (242) |  |  | (1,426) |  |
| Other assets |  |  | (43) |  |  | — |  |  | (43) |  |
| Prepaid expenses and other current assets |  |  | 580 |  |  | 125 |  |  | 705 |  |
| Accounts payable |  |  | (7,409) |  |  | — |  |  | (7,409) |  |
| Deferred revenue |  |  | 24,113 |  |  | (1,147) |  |  | 22,966 |  |
| Accrued expenses and other current liabilities |  |  | (342) |  |  | — |  |  | (342) |  |
| Operating lease liability |  |  | (513) |  |  | — |  |  | (513) |  |
| Net cash used in operating activities |  |  | (8,755) |  |  | — |  |  | (8,755) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Development of internal-use software |  |  | (1,599) |  |  | — |  |  | (1,599) |  |
| Purchases of property and equipment |  |  | (33,173) |  |  | — |  |  | (33,173) |  |

[0001628280-25-020355:notes:477]
| Proceeds from sale of property and equipment |  |  | 60 |  |  | — |  |  | 60 |  |
| Purchases of marketable securities |  |  | (29,405) |  |  | — |  |  | (29,405) |  |
| Net cash used in investing activities |  |  | (64,117) |  |  | — |  |  | (64,117) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 344 |  |  | — |  |  | 344 |  |
| Proceeds from long-term debt |  |  | 1,876 |  |  | — |  |  | 1,876 |  |
| Repayment of principal on long-term debt |  |  | (31,876) |  |  | — |  |  | (31,876) |  |
| Payment of debt issuance costs and prepayment penalty |  |  | (332) |  |  | — |  |  | (332) |  |
| Net cash used in financing activities |  |  | (29,988) |  |  | — |  |  | (29,988) |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (33) |  |  | — |  |  | (33) |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (102,893) |  |  | — |  |  | (102,893) |  |
| Cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 230,058 |  |  | — |  |  | 230,058 |  |
| Cash, cash equivalents and restricted cash at end of period |  |  | $ | 127,165 |  |  | $ | — |  |  | $ | 127,165 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |
| Cash paid for interest |  |  | $ | 710 |  |  | $ | — |  |  | $ | 710 |  |
| Supplemental disclosure of non-cash activities |  |  |  |  |  |  |  |
| Transfer of property and equipment to inventory |  |  | $ | 191 |  |  | $ | — |  |  | $ | 191 |  |
| Capital expenditures incurred but not yet paid |  |  | 13,572 |  |  | — |  |  | 13,572 |  |
| Capitalization of stock compensation |  |  | 218 |  |  | — |  |  | 218 |  |
| Finback exercise price |  |  | 348 |  |  | — |  |  | 348 |  |
| Reconciliation of cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 125,890 |  |  | $ | — |  |  | $ | 125,890 |  |
| Restricted cash |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Total cash, cash equivalents and restricted cash shown in the statements of cash flows |  |  | $ | 127,165 |  |  | $ | — |  |  | $ | 127,165 |  |

[0001628280-25-020355:notes:478]
As of and for the Three Months Ended March 31, 2023

[0001628280-25-020355:notes:479]
|  |  |  | As of March 31, 2023 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Assets |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 180,996 |  |  | $ | — |  |  | $ | 180,996 |  |
| Restricted cash |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Accounts receivable, net | ADJ 1 |  | 23,156 |  |  | (1,254) |  |  | 21,902 |  |
| Inventory | ADJ 1 |  | 8,816 |  |  | 355 |  |  | 9,171 |  |
| Current portion of contract assets | ADJ 1 |  | 3,265 |  |  | (81) |  |  | 3,184 |  |
| Current portion of commission asset | ADJ 1 |  | 3,293 |  |  | 26 |  |  | 3,319 |  |
| Prepaid expenses and other current assets | ADJ 1 |  | 14,413 |  |  | 5 |  |  | 14,418 |  |
| Total current assets |  |  | 234,939 |  |  | (949) |  |  | 233,990 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Contract assets, noncurrent | ADJ 1 |  | 715 |  |  | 1 |  |  | 716 |  |
| Commission asset, noncurrent | ADJ 1 |  | 6,390 |  |  | 77 |  |  | 6,467 |  |
| Property and equipment, net | ADJ 1, ADJ 4 |  | 59,789 |  |  | 27 |  |  | 59,816 |  |
| Operating lease right-of-use assets |  |  | 1,459 |  |  | — |  |  | 1,459 |  |
| Other assets |  |  | 1,965 |  |  | — |  |  | 1,965 |  |
| Total assets |  |  | $ | 305,532 |  |  | $ | (844) |  |  | $ | 304,688 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 19,192 |  |  | $ | — |  |  | $ | 19,192 |  |
| Accrued expenses and other current liabilities |  |  | 6,477 |  |  | — |  |  | 6,477 |  |
| Current portion of deferred revenue | ADJ 1 |  | 23,977 |  |  | (400) |  |  | 23,577 |  |
| Current portion of operating lease liabilities |  |  | 1,122 |  |  | — |  |  | 1,122 |  |
| Total current liabilities |  |  | 50,768 |  |  | (400) |  |  | 50,368 |  |
| Deferred revenue, noncurrent |  |  | 20,748 |  |  | — |  |  | 20,748 |  |
| Operating lease liabilities, noncurrent |  |  | 630 |  |  | — |  |  | 630 |  |
| Contingent earn-out liability |  |  | 17,536 |  |  | — |  |  | 17,536 |  |
| Contingently issuable common stock liability |  |  | 4,134 |  |  | — |  |  | 4,134 |  |
| Public warrant liability |  |  | 7,874 |  |  | — |  |  | 7,874 |  |
| Total liabilities |  |  | 101,690 |  |  | (400) |  |  | 101,290 |  |
| Commitments and contingencies (Note 20) |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  | — |  |  | — |  |
| Common stock |  |  | 15 |  |  | — |  |  | 15 |  |
| Additional paid-in capital | ADJ 4 |  | 424,672 |  |  | 13 |  |  | 424,685 |  |
| Accumulated other comprehensive loss |  |  | (26) |  |  | — |  |  | (26) |  |
| Accumulated deficit |  |  | (220,819) |  |  | (457) |  |  | (221,276) |  |
| Stockholders’ equity |  |  | 203,842 |  |  | (444) |  |  | 203,398 |  |
| Total liabilities and stockholders’ equity |  |  | $ | 305,532 |  |  | $ | (844) |  |  | $ | 304,688 |  |

[0001628280-25-020355:notes:480]
Property and equipment, net: ADJ 1 = $35, ADJ 4 = ($8)

[0001628280-25-020355:notes:481]
|  |  |  | Three Months Ended March 31, 2023 |  |  |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | ADJ 1 |  | $ | 8,754 |  |  | $ | 1,858 |  |  | $ | 10,612 |  |  |  |  |  |  |  |
| Subscription revenue | ADJ 1, ADJ 4 |  | 6,466 |  |  | (293) |  |  | 6,173 |  |  |  |  |  |  |  |
| Service revenue | ADJ 1, ADJ 4 |  | 2,786 |  |  | (27) |  |  | 2,759 |  |  |  |  |  |  |  |
| License fee and other revenue | ADJ 1 |  | 575 |  |  | 3 |  |  | 578 |  |  |  |  |  |  |  |
| Total revenue |  |  | 18,581 |  |  | 1,541 |  |  | 20,122 |  |  |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | ADJ 1, ADJ 4 |  | 10,578 |  |  | 1,784 |  |  | 12,362 |  |  |  |  |  |  |  |
| Cost of subscription revenue | ADJ 1, ADJ 4 |  | 2,351 |  |  | (17) |  |  | 2,334 |  |  |  |  |  |  |  |
| Cost of service revenue |  |  | 583 |  |  | — |  |  | 583 |  |  |  |  |  |  |  |
| Cost of license fee and other revenue |  |  | 304 |  |  | — |  |  | 304 |  |  |  |  |  |  |  |
| Total cost of revenue |  |  | 13,816 |  |  | 1,767 |  |  | 15,583 |  |  |  |  |  |  |  |
| Gross profit |  |  | 4,765 |  |  | (226) |  |  | 4,539 |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | ADJ 4 |  | 5,389 |  |  | 6 |  |  | 5,395 |  |  |  |  |  |  |  |
| Sales and marketing | ADJ 1, ADJ 4 |  | 12,804 |  |  | (166) |  |  | 12,638 |  |  |  |  |  |  |  |
| General and administrative | ADJ 4 |  | 8,926 |  |  | 2 |  |  | 8,928 |  |  |  |  |  |  |  |
| Loss from impairment of property and equipment |  |  | 137 |  |  | — |  |  | 137 |  |  |  |  |  |  |  |
| Total operating expenses |  |  | 27,256 |  |  | (158) |  |  | 27,098 |  |  |  |  |  |  |  |
| Loss from operations |  |  | (22,491) |  |  | (68) |  |  | (22,559) |  |  |  |  |  |  |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (654) |  |  | — |  |  | (654) |  |  |  |  |  |  |  |
| Interest income |  |  | 953 |  |  | — |  |  | 953 |  |  |  |  |  |  |  |
| Other income, net |  |  | 19 |  |  | — |  |  | 19 |  |  |  |  |  |  |  |
| Loss on extinguishment of debt |  |  | (626) |  |  | — |  |  | (626) |  |  |  |  |  |  |  |
| Change in fair value of contingent earn-out liability |  |  | (3,318) |  |  | — |  |  | (3,318) |  |  |  |  |  |  |  |
| Change in fair value of contingently issuable common stock liability |  |  | (742) |  |  | — |  |  | (742) |  |  |  |  |  |  |  |
| Change in fair value of public warrant liability |  |  | (1,750) |  |  | — |  |  | (1,750) |  |  |  |  |  |  |  |
| Total other income (expense), net |  |  | (6,118) |  |  | — |  |  | (6,118) |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (28,609) |  |  | $ | (68) |  |  | $ | (28,677) |  |  |  |  |  |  |  |
| Weighted average common shares outstanding – basic and diluted |  |  | 146,433,378 |  |  | — |  |  | 146,433,378 |  |  |  |  |  |  |  |
| Net loss per share - basic and diluted |  |  | $ | (0.20) |  |  | $ | — |  |  | $ | (0.20) |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (28,609) |  |  | $ | (68) |  |  | $ | (28,677) |  |  |  |  |  |  |  |
| Other comprehensive loss |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  | (16) |  |  | — |  |  | (16) |  |  |  |  |  |  |  |
| Total other comprehensive loss |  |  | (16) |  |  | — |  |  | (16) |  |  |  |  |  |  |  |
| Total comprehensive loss |  |  | $ | (28,625) |  |  | $ | (68) |  |  | $ | (28,693) |  |  |  |  |  |  |  |

[0001628280-25-020355:notes:482]
Subscription revenue: ADJ 1 = ($103), ADJ 4 = ($190)

[0001628280-25-020355:notes:483]
Service revenue: ADJ 1 = ($217), ADJ 4 = $190

[0001628280-25-020355:notes:484]
Cost of product revenue: ADJ 1 = $2,086, ADJ 4 = ($302)

[0001628280-25-020355:notes:485]
Cost of subscription revenue: ADJ 1 = ($16), ADJ 4 = ($1)

[0001628280-25-020355:notes:486]
Sales and marketing: ADJ 1 = $85, ADJ 4 = ($251)

[0001628280-25-020355:notes:487]
|  |  |  | Three Months Ended March 31, 2023 |
|  |  |  | As Reported |  | Adjustment |  | As Restated |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (28,609) |  |  | $ | (68) |  |  | $ | (28,677) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 1,815 |  |  | (17) |  |  | 1,798 |  |
| Write-off of inventory and change in inventory reserve |  |  | 214 |  |  | (303) |  |  | (89) |  |
| Loss from impairment of property and equipment |  |  | 137 |  |  | — |  |  | 137 |  |
| Stock-based compensation |  |  | 5,043 |  |  | (9) |  |  | 5,034 |  |
| Non-cash interest expense |  |  | 22 |  |  | — |  |  | 22 |  |
| Non-cash lease expense |  |  | 214 |  |  | — |  |  | 214 |  |
| Change in allowance for expected credit losses |  |  | 124 |  |  | — |  |  | 124 |  |
| Loss on extinguishment of debt |  |  | 626 |  |  | — |  |  | 626 |  |
| Change in fair value of earn-out liability |  |  | 3,318 |  |  | — |  |  | 3,318 |  |
| Change in fair value of contingently issuable common stock |  |  | 742 |  |  | — |  |  | 742 |  |
| Change in fair value of public warrant liability |  |  | 1,750 |  |  | — |  |  | 1,750 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 8,640 |  |  | (4,227) |  |  | 4,413 |  |
| Inventory |  |  | 1,418 |  |  | 2,086 |  |  | 3,504 |  |
| Commission assets |  |  | (644) |  |  | (285) |  |  | (929) |  |
| Contract assets |  |  | 258 |  |  | (414) |  |  | (156) |  |
| Other assets |  |  | (130) |  |  | — |  |  | (130) |  |
| Prepaid expenses and other current assets |  |  | (25) |  |  | 138 |  |  | 113 |  |
| Accounts payable |  |  | (2,213) |  |  | — |  |  | (2,213) |  |
| Deferred revenue |  |  | 8,757 |  |  | 3,099 |  |  | 11,856 |  |
| Accrued expenses and other current liabilities |  |  | (4,637) |  |  | — |  |  | (4,637) |  |
| Operating lease liability |  |  | (254) |  |  | — |  |  | (254) |  |
| Net cash used in operating activities |  |  | (3,434) |  |  | — |  |  | (3,434) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Development of internal-use software |  |  | (733) |  |  | — |  |  | (733) |  |
| Purchases of property and equipment |  |  | (13,365) |  |  | — |  |  | (13,365) |  |
| Proceeds from sale of property and equipment |  |  | 60 |  |  | — |  |  | 60 |  |
| Net cash used in investing activities |  |  | (14,038) |  |  | — |  |  | (14,038) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 33 |  |  | — |  |  | 33 |  |
| Proceeds from long-term debt |  |  | 1,876 |  |  | — |  |  | 1,876 |  |
| Repayment of principal on long-term debt |  |  | (31,876) |  |  | — |  |  | (31,876) |  |
| Payment of debt issuance costs and prepayment penalty |  |  | (332) |  |  | — |  |  | (332) |  |
| Net cash used in financing activities |  |  | (30,299) |  |  | — |  |  | (30,299) |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (16) |  |  | — |  |  | (16) |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (47,787) |  |  | — |  |  | (47,787) |  |
| Cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 230,058 |  |  | — |  |  | 230,058 |  |
| Cash, cash equivalents and restricted cash at end of period |  |  | $ | 182,271 |  |  | $ | — |  |  | $ | 182,271 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |

[0001628280-25-020355:notes:488]
| Cash paid for interest |  |  | $ | 710 |  |  | $ | — |  |  | $ | 710 |  |
| Supplemental disclosure of non-cash activities |  |  |  |  |  |  |  |
| Transfer of property and equipment to inventory |  |  | $ | 191 |  |  | $ | — |  |  | $ | 191 |  |
| Capital expenditures incurred but not yet paid |  |  | 10,648 |  |  | — |  |  | 10,648 |  |
| Capitalization of stock compensation |  |  | 91 |  |  | — |  |  | 91 |  |
| Finback exercise price |  |  | 348 |  |  | — |  |  | 348 |  |
| Reconciliation of cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 180,996 |  |  | $ | — |  |  | $ | 180,996 |  |
| Restricted cash |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Total cash, cash equivalents and restricted cash shown in the statements of cash flows |  |  | $ | 182,271 |  |  | $ | — |  |  | $ | 182,271 |  |

[0001628280-25-020355:notes:489]
As of and for the Three and Nine Months Ended September 30, 2022

[0001628280-25-020355:notes:490]
|  |  |  | As of September 30, 2022 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Assets |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 218,499 |  |  | $ | — |  |  | $ | 218,499 |  |
| Restricted cash |  |  | 400 |  |  | — |  |  | 400 |  |
| Accounts receivable, net | ADJ 1 |  | 21,199 |  |  | 1,442 |  |  | 22,641 |  |
| Inventory | ADJ 1, ADJ 4 |  | 6,732 |  |  | (104) |  |  | 6,628 |  |
| Current portion of contract assets | ADJ 1 |  | 5,291 |  |  | (1,975) |  |  | 3,316 |  |
| Current portion of commission asset | ADJ 1 |  | 2,413 |  |  | 4 |  |  | 2,417 |  |
| Prepaid expenses and other current assets | ADJ 1 |  | 20,223 |  |  | 13 |  |  | 20,236 |  |
| Total current assets |  |  | 274,757 |  |  | (620) |  |  | 274,137 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Contract assets, noncurrent | ADJ 1 |  | 1,524 |  |  | (27) |  |  | 1,497 |  |
| Commission asset, noncurrent | ADJ 1 |  | 4,607 |  |  | 11 |  |  | 4,618 |  |
| Property and equipment, net | ADJ 1, ADJ 4 |  | 40,532 |  |  | 5 |  |  | 40,537 |  |
| Operating lease right-of-use assets |  |  | 1,882 |  |  | — |  |  | 1,882 |  |
| Other assets |  |  | 2,045 |  |  | — |  |  | 2,045 |  |
| Total assets |  |  | $ | 325,622 |  |  | $ | (631) |  |  | $ | 324,991 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 11,139 |  |  | $ | — |  |  | $ | 11,139 |  |
| Accrued expenses and other current liabilities | ADJ 4 |  | 8,884 |  |  | 106 |  |  | 8,990 |  |
| Current portion of deferred revenue | ADJ 1 |  | 15,852 |  |  | (177) |  |  | 15,675 |  |
| Current portion of long-term debt |  |  | 4,000 |  |  | — |  |  | 4,000 |  |
| Current portion of operating lease liabilities |  |  | 1,106 |  |  | — |  |  | 1,106 |  |
| Total current liabilities |  |  | 40,981 |  |  | (71) |  |  | 40,910 |  |
| Deferred revenue, noncurrent |  |  | 9,234 |  |  | — |  |  | 9,234 |  |
| Long-term debt, noncurrent |  |  | 4,959 |  |  | — |  |  | 4,959 |  |
| Operating lease liabilities, noncurrent |  |  | 1,147 |  |  | — |  |  | 1,147 |  |
| Contingent earn-out liability |  |  | 11,452 |  |  | — |  |  | 11,452 |  |
| Contingently issuable common stock liability |  |  | 2,735 |  |  | — |  |  | 2,735 |  |
| Public warrant liability |  |  | 6,733 |  |  | — |  |  | 6,733 |  |
| Total liabilities |  |  | 77,241 |  |  | (71) |  |  | 77,170 |  |
| Commitments and contingencies (Note 20) |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  | — |  |  | — |  |
| Common stock |  |  | 14 |  |  | — |  |  | 14 |  |
| Additional paid-in capital |  |  | 412,238 |  |  | — |  |  | 412,238 |  |
| Accumulated other comprehensive loss |  |  | 35 |  |  | — |  |  | 35 |  |
| Accumulated deficit |  |  | (163,906) |  |  | (560) |  |  | (164,466) |  |
| Stockholders’ equity |  |  | 248,381 |  |  | (560) |  |  | 247,821 |  |
| Total liabilities and stockholders’ equity |  |  | $ | 325,622 |  |  | $ | (631) |  |  | $ | 324,991 |  |

[0001628280-25-020355:notes:491]
Inventory: ADJ 1 = $284, ADJ 4 = ($388)

[0001628280-25-020355:notes:492]
Property and equipment, net: ADJ 1 = $14, ADJ 4 = ($9)

[0001628280-25-020355:notes:493]
|  |  |  | Three Months Ended September 30, 2022 |  | Nine Months Ended September 30, 2022 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |  | As Reported |  | Adjustment |  | As Restated |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | ADJ 1 |  | $ | 9,839 |  |  | $ | (232) |  |  | $ | 9,607 |  |  | $ | 19,179 |  |  | $ | (214) |  |  | $ | 18,965 |  |
| Subscription revenue | ADJ 1, ADJ 4 |  | 5,198 |  |  | (93) |  |  | 5,105 |  |  | 12,208 |  |  | (327) |  |  | 11,881 |  |
| Service revenue | ADJ 1, ADJ 4 |  | 1,190 |  |  | 113 |  |  | 1,303 |  |  | 2,237 |  |  | 174 |  |  | 2,411 |  |
| License fee and other revenue | ADJ 1 |  | 303 |  |  | (22) |  |  | 281 |  |  | 686 |  |  | (16) |  |  | 670 |  |
| Total revenue |  |  | 16,530 |  |  | (234) |  |  | 16,296 |  |  | 34,310 |  |  | (383) |  |  | 33,927 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | ADJ 1, ADJ 4 |  | 12,960 |  |  | 104 |  |  | 13,064 |  |  | 23,513 |  |  | 104 |  |  | 23,617 |  |
| Cost of subscription revenue | ADJ 1, ADJ 4 |  | 2,207 |  |  | (30) |  |  | 2,177 |  |  | 5,730 |  |  | (4) |  |  | 5,726 |  |
| Cost of service revenue |  |  | 500 |  |  | — |  |  | 500 |  |  | 1,652 |  |  | — |  |  | 1,652 |  |
| Cost of license fee and other revenue |  |  | 638 |  |  | — |  |  | 638 |  |  | 1,740 |  |  | — |  |  | 1,740 |  |
| Total cost of revenue |  |  | 16,305 |  |  | 74 |  |  | 16,379 |  |  | 32,635 |  |  | 100 |  |  | 32,735 |  |
| Gross profit |  |  | 225 |  |  | (308) |  |  | (83) |  |  | 1,675 |  |  | (483) |  |  | 1,192 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | ADJ 4 |  | 5,616 |  |  | (434) |  |  | 5,182 |  |  | 13,947 |  |  | (216) |  |  | 13,731 |  |
| Sales and marketing | ADJ 1, ADJ 4 |  | 11,746 |  |  | 223 |  |  | 11,969 |  |  | 33,169 |  |  | 77 |  |  | 33,246 |  |
| General and administrative | ADJ 4 |  | 8,839 |  |  | 254 |  |  | 9,093 |  |  | 29,268 |  |  | 216 |  |  | 29,484 |  |
| Loss from impairment of property and equipment | ADJ 4 |  | 626 |  |  | (437) |  |  | 189 |  |  | 1,038 |  |  | — |  |  | 1,038 |  |
| Total operating expenses |  |  | 26,827 |  |  | (394) |  |  | 26,433 |  |  | 77,422 |  |  | 77 |  |  | 77,499 |  |
| Loss from operations |  |  | (26,602) |  |  | 86 |  |  | (26,516) |  |  | (75,747) |  |  | (560) |  |  | (76,307) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (188) |  |  | — |  |  | (188) |  |  | (489) |  |  | — |  |  | (489) |  |
| Interest income |  |  | 1,052 |  |  | — |  |  | 1,052 |  |  | 1,611 |  |  | — |  |  | 1,611 |  |
| Other expense, net |  |  | (57) |  |  | — |  |  | (57) |  |  | (57) |  |  | — |  |  | (57) |  |
| Change in fair value of contingent earn-out liability |  |  | 7,245 |  |  | — |  |  | 7,245 |  |  | 9,754 |  |  | — |  |  | 9,754 |  |
| Change in fair value of contingently issuable common stock liability |  |  | 1,081 |  |  | — |  |  | 1,081 |  |  | 2,529 |  |  | — |  |  | 2,529 |  |
| Change in fair value of public warrant liability |  |  | (1,146) |  |  | — |  |  | (1,146) |  |  | 4,297 |  |  | — |  |  | 4,297 |  |
| Total other income (expense), net |  |  | 7,987 |  |  | — |  |  | 7,987 |  |  | 17,645 |  |  | — |  |  | 17,645 |  |
| Net loss |  |  | $ | (18,615) |  |  | $ | 86 |  |  | $ | (18,529) |  |  | $ | (58,102) |  |  | $ | (560) |  |  | $ | (58,662) |  |
| Weighted average common shares outstanding – basic and diluted |  |  | 144,117,273 |  |  | — |  |  | 144,117,273 |  |  | 143,522,555 |  |  | — |  |  | 143,522,555 |  |
| Net loss per share - basic and diluted |  |  | $ | (0.13) |  |  | $ | — |  |  | $ | (0.13) |  |  | $ | (0.40) |  |  | $ | (0.01) |  |  | $ | (0.41) |  |
| Net loss |  |  | $ | (18,615) |  |  | $ | 86 |  |  | $ | (18,529) |  |  | $ | (58,102) |  |  | $ | (560) |  |  | $ | (58,662) |  |
| Other comprehensive loss |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  | 45 |  |  | — |  |  | 45 |  |  | 35 |  |  | — |  |  | 35 |  |
| Total other comprehensive loss |  |  | 45 |  |  | — |  |  | 45 |  |  | 35 |  |  | — |  |  | 35 |  |
| Total comprehensive loss |  |  | $ | (18,570) |  |  | $ | 86 |  |  | $ | (18,484) |  |  | $ | (58,067) |  |  | $ | (560) |  |  | $ | (58,627) |  |

[0001628280-25-020355:notes:494]
Subscription revenue: ADJ 1 = $100, ADJ 4 = ($193)

[0001628280-25-020355:notes:495]
Service revenue: ADJ 1 = ($80), ADJ 4 = $193

[0001628280-25-020355:notes:496]
Cost of product revenue: ADJ 1 = ($284), ADJ 4 = $388

[0001628280-25-020355:notes:497]
Cost of subscription revenue: ADJ 1 = $1, ADJ 4 = ($31)

[0001628280-25-020355:notes:498]
Sales and marketing: ADJ 1 = ($28), ADJ 4 = $251

[0001628280-25-020355:notes:499]
Nine months ended:

[0001628280-25-020355:notes:500]
Subscription revenue: ADJ 1 = ($73), ADJ 4 = ($254)

[0001628280-25-020355:notes:501]
Service revenue: ADJ 1 = ($80), ADJ 4 = $254

[0001628280-25-020355:notes:502]
Cost of subscription revenue: ADJ 1 = ($13) , ADJ 4 = $9

[0001628280-25-020355:notes:503]
Sales and marketing: ADJ 1 = ($29), ADJ 4 = $106

[0001628280-25-020355:notes:504]
|  |  |  | Nine Months Ended September 30, 2022 |
|  |  |  | As Reported |  | Adjustment |  | As Restated |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (58,102) |  |  | $ | (560) |  |  | $ | (58,662) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,782 |  |  | (17) |  |  | 3,765 |  |
| Write-off of inventory and change in inventory reserve |  |  | 559 |  |  | — |  |  | 559 |  |
| Adjustment to property and equipment for sales type leases |  |  | (625) |  |  | — |  |  | (625) |  |
| Loss from impairment of property and equipment |  |  | 1,038 |  |  | — |  |  | 1,038 |  |
| Stock-based compensation |  |  | 15,513 |  |  | 106 |  |  | 15,619 |  |
| Non-cash interest expense |  |  | 14 |  |  | — |  |  | 14 |  |
| Non-cash lease expense |  |  | 602 |  |  | — |  |  | 602 |  |
| Change in allowance for expected credit losses |  |  | 100 |  |  | — |  |  | 100 |  |
| Change in fair value of earn-out liability |  |  | (9,754) |  |  | — |  |  | (9,754) |  |
| Change in fair value of contingently issuable common stock |  |  | (2,529) |  |  | — |  |  | (2,529) |  |
| Change in fair value of public warrant liability |  |  | (4,297) |  |  | — |  |  | (4,297) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (14,822) |  |  | (1,442) |  |  | (16,264) |  |
| Inventory |  |  | (4,401) |  |  | 104 |  |  | (4,297) |  |
| Commission assets |  |  | (1,656) |  |  | (15) |  |  | (1,671) |  |
| Contract assets |  |  | (1,938) |  |  | 2,002 |  |  | 64 |  |
| Other assets |  |  | (629) |  |  | — |  |  | (629) |  |
| Prepaid expenses and other current assets |  |  | (9,009) |  |  | (13) |  |  | (9,022) |  |
| Accounts payable |  |  | 2,177 |  |  | — |  |  | 2,177 |  |
| Deferred revenue |  |  | 16,005 |  |  | (177) |  |  | 15,828 |  |
| Accrued expenses and other current liabilities |  |  | (750) |  |  | — |  |  | (750) |  |
| Operating lease liability |  |  | (699) |  |  | — |  |  | (699) |  |
| Net cash used in operating activities |  |  | (69,421) |  |  | (12) |  |  | (69,433) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Development of internal-use software |  |  | (1,936) |  |  | — |  |  | (1,936) |  |
| Purchases of property and equipment(1) |  |  | (17,554) |  |  | 12 |  |  | (17,542) |  |
| Proceeds from sale of property and equipment |  |  | 312 |  |  | — |  |  | 312 |  |
| Net cash used in investing activities |  |  | (19,178) |  |  | 12 |  |  | (19,166) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 571 |  |  | — |  |  | 571 |  |
| Repayment of principal on long-term debt |  |  | (1,000) |  |  | — |  |  | (1,000) |  |

[0001628280-25-020355:notes:505]
| Net cash used in financing activities |  |  | (429) |  |  | — |  |  | (429) |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 35 |  |  | — |  |  | 35 |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (88,993) |  |  | — |  |  | (88,993) |  |
| Cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 308,167 |  |  | — |  |  | 308,167 |  |
| Cash, cash equivalents and restricted cash at end of period |  |  | $ | 219,174 |  |  | $ | — |  |  | $ | 219,174 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |
| Cash paid for interest |  |  | $ | 478 |  |  | $ | — |  |  | $ | 478 |  |
| Supplemental disclosure of non-cash activities |  |  |  |  |  |  |  |
| Capital expenditures incurred but not yet paid |  |  | 5,935 |  |  | — |  |  | 5,935 |  |
| Capitalization of stock compensation |  |  | 90 |  |  | — |  |  | 90 |  |
| Reconciliation of cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 218,499 |  |  | $ | — |  |  | $ | 218,499 |  |
| Restricted cash |  |  | 400 |  |  | — |  |  | 400 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Total cash, cash equivalents and restricted cash shown in the statements of cash flows |  |  | $ | 219,174 |  |  | $ | — |  |  | $ | 219,174 |  |

[0001628280-25-020355:notes:506]
As of and for the Three and Six Months Ended June 30, 2022

[0001628280-25-020355:notes:507]
|  |  |  | As of June 30, 2022 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |
| Assets |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 242,691 |  |  | $ | — |  |  | $ | 242,691 |  |
| Restricted cash |  |  | 400 |  |  | — |  |  | 400 |  |
| Accounts receivable, net | ADJ 1, ADJ 4 |  | 12,183 |  |  | 687 |  |  | 12,870 |  |
| Inventory |  |  | 6,010 |  |  | — |  |  | 6,010 |  |
| Current portion of contract assets | ADJ 1, ADJ 4 |  | 3,070 |  |  | (947) |  |  | 2,123 |  |
| Current portion of commission asset |  |  | 2,079 |  |  | — |  |  | 2,079 |  |
| Prepaid expenses and other current assets |  |  | 20,920 |  |  | — |  |  | 20,920 |  |
| Total current assets |  |  | 287,353 |  |  | (260) |  |  | 287,093 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Contract assets, noncurrent |  |  | 3,159 |  |  | — |  |  | 3,159 |  |
| Commission asset, noncurrent | ADJ 1 |  | 3,624 |  |  | 2 |  |  | 3,626 |  |
| Property and equipment, net | ADJ 1, ADJ 4 |  | 34,379 |  |  | (463) |  |  | 33,916 |  |
| Operating lease right-of-use assets |  |  | 2,092 |  |  | — |  |  | 2,092 |  |
| Other assets |  |  | 2,172 |  |  | — |  |  | 2,172 |  |
| Total assets |  |  | $ | 333,054 |  |  | $ | (721) |  |  | $ | 332,333 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 9,427 |  |  | $ | — |  |  | $ | 9,427 |  |
| Accrued expenses and other current liabilities | ADJ 4 |  | 7,759 |  |  | 35 |  |  | 7,794 |  |
| Current portion of deferred revenue | ADJ 1 |  | 10,782 |  |  | (110) |  |  | 10,672 |  |
| Current portion of long-term debt |  |  | 4,000 |  |  | — |  |  | 4,000 |  |
| Current portion of operating lease liabilities |  |  | 1,097 |  |  | — |  |  | 1,097 |  |
| Total current liabilities |  |  | 33,065 |  |  | (75) |  |  | 32,990 |  |
| Deferred revenue, noncurrent |  |  | 4,330 |  |  | — |  |  | 4,330 |  |
| Long-term debt, noncurrent |  |  | 5,955 |  |  | — |  |  | 5,955 |  |
| Operating lease liabilities, noncurrent |  |  | 1,398 |  |  | — |  |  | 1,398 |  |
| Contingent earn-out liability |  |  | 18,697 |  |  | — |  |  | 18,697 |  |
| Contingently issuable common stock liability |  |  | 3,816 |  |  | — |  |  | 3,816 |  |
| Public warrant liability |  |  | 5,587 |  |  | — |  |  | 5,587 |  |
| Total liabilities |  |  | 72,848 |  |  | (75) |  |  | 72,773 |  |
| Commitments and contingencies (Note 20) |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Preferred stock |  |  | — |  |  | — |  |  | — |  |
| Common stock |  |  | 14 |  |  | — |  |  | 14 |  |
| Additional paid-in capital |  |  | 405,493 |  |  | — |  |  | 405,493 |  |
| Accumulated other comprehensive loss |  |  | (10) |  |  | — |  |  | (10) |  |
| Accumulated deficit |  |  | (145,291) |  |  | (646) |  |  | (145,937) |  |
| Stockholders’ equity |  |  | 260,206 |  |  | (646) |  |  | 259,560 |  |
| Total liabilities and stockholders’ equity |  |  | $ | 333,054 |  |  | $ | (721) |  |  | $ | 332,333 |  |

[0001628280-25-020355:notes:508]
Accounts receivable, net: ADJ 1 = ($130), ADJ 4 = $817

[0001628280-25-020355:notes:509]
Current portion of contract assets: ADJ 1 = ($130), ADJ 4 = ($817)

[0001628280-25-020355:notes:510]
Property and equipment, net: ADJ 1 = $14, ADJ 4 = ($477)

[0001628280-25-020355:notes:511]
|  |  |  | Three Months Ended June 30, 2022 |  | Six Months Ended June 30, 2022 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |  | As Reported |  | Adjustment |  | As Restated |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | ADJ 1 |  | $ | 4,146 |  |  | $ | 18 |  |  | $ | 4,164 |  |  | $ | 9,340 |  |  | $ | 18 |  |  | $ | 9,358 |  |
| Subscription revenue | ADJ 1, ADJ 4 |  | 4,006 |  |  | (234) |  |  | 3,772 |  |  | 7,010 |  |  | (234) |  |  | 6,776 |  |
| Service revenue | ADJ 4 |  | 721 |  |  | 61 |  |  | 782 |  |  | 1,047 |  |  | 61 |  |  | 1,108 |  |
| License fee and other revenue | ADJ 1 |  | 197 |  |  | 6 |  |  | 203 |  |  | 383 |  |  | 6 |  |  | 389 |  |
| Total revenue |  |  | 9,070 |  |  | (149) |  |  | 8,921 |  |  | 17,780 |  |  | (149) |  |  | 17,631 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue |  |  | 5,347 |  |  | — |  |  | 5,347 |  |  | 10,553 |  |  | — |  |  | 10,553 |  |
| Cost of subscription revenue | ADJ 1, ADJ 4 |  | 1,981 |  |  | 26 |  |  | 2,007 |  |  | 3,523 |  |  | 26 |  |  | 3,549 |  |
| Cost of service revenue |  |  | 467 |  |  | — |  |  | 467 |  |  | 1,152 |  |  | — |  |  | 1,152 |  |
| Cost of license fee and other revenue |  |  | 722 |  |  | — |  |  | 722 |  |  | 1,102 |  |  | — |  |  | 1,102 |  |
| Total cost of revenue |  |  | 8,517 |  |  | 26 |  |  | 8,543 |  |  | 16,330 |  |  | 26 |  |  | 16,356 |  |
| Gross profit |  |  | 553 |  |  | (175) |  |  | 378 |  |  | 1,450 |  |  | (175) |  |  | 1,275 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | ADJ 4 |  | 4,156 |  |  | 218 |  |  | 4,374 |  |  | 8,331 |  |  | 218 |  |  | 8,549 |  |
| Sales and marketing | ADJ 1, ADJ 4 |  | 11,751 |  |  | (146) |  |  | 11,605 |  |  | 21,423 |  |  | (146) |  |  | 21,277 |  |
| General and administrative | ADJ 4 |  | 9,612 |  |  | (38) |  |  | 9,574 |  |  | 20,429 |  |  | (38) |  |  | 20,391 |  |
| Loss from impairment of property and equipment | ADJ 4 |  | 316 |  |  | 437 |  |  | 753 |  |  | 412 |  |  | 437 |  |  | 849 |  |
| Total operating expenses |  |  | 25,835 |  |  | 471 |  |  | 26,306 |  |  | 50,595 |  |  | 471 |  |  | 51,066 |  |
| Loss from operations |  |  | (25,282) |  |  | (646) |  |  | (25,928) |  |  | (49,145) |  |  | (646) |  |  | (49,791) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (159) |  |  | — |  |  | (159) |  |  | (301) |  |  | — |  |  | (301) |  |
| Interest income |  |  | 491 |  |  | — |  |  | 491 |  |  | 559 |  |  | — |  |  | 559 |  |
| Change in fair value of contingent earn-out liability |  |  | (569) |  |  | — |  |  | (569) |  |  | 2,509 |  |  | — |  |  | 2,509 |  |
| Change in fair value of contingently issuable common stock liability |  |  | (24) |  |  | — |  |  | (24) |  |  | 1,448 |  |  | — |  |  | 1,448 |  |
| Change in fair value of public warrant liability |  |  | (143) |  |  | — |  |  | (143) |  |  | 5,443 |  |  | — |  |  | 5,443 |  |
| Total other income (expense), net |  |  | (404) |  |  | — |  |  | (404) |  |  | 9,658 |  |  | — |  |  | 9,658 |  |
| Loss before income taxes |  |  | (25,686) |  |  | (646) |  |  | (26,332) |  |  | (39,487) |  |  | (646) |  |  | (40,133) |  |
| Net loss |  |  | $ | (25,686) |  |  | $ | (646) |  |  | $ | (26,332) |  |  | $ | (39,487) |  |  | $ | (646) |  |  | $ | (40,133) |  |
| Weighted average common shares outstanding – basic and diluted |  |  | 143,552,032 |  |  | — |  |  | 143,552,032 |  |  | 143,220,268 |  |  | — |  |  | 143,220,268 |  |
| Net loss per share - basic and diluted |  |  | $ | (0.18) |  |  | $ | — |  |  | $ | (0.18) |  |  | $ | (0.28) |  |  | $ | — |  |  | $ | (0.28) |  |
| Net loss |  |  | $ | (25,686) |  |  | $ | (646) |  |  | $ | (26,332) |  |  | $ | (39,487) |  |  | $ | (646) |  |  | $ | (40,133) |  |
| Other comprehensive loss |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  | (10) |  |  | — |  |  | (10) |  |  | (10) |  |  | — |  |  | (10) |  |
| Total other comprehensive loss |  |  | (10) |  |  | — |  |  | (10) |  |  | (10) |  |  | — |  |  | (10) |  |
| Total comprehensive loss |  |  | $ | (25,696) |  |  | $ | (646) |  |  | $ | (26,342) |  |  | $ | (39,497) |  |  | $ | (646) |  |  | $ | (40,143) |  |

[0001628280-25-020355:notes:512]
Subscription revenue: ADJ 1 = ($173), ADJ 4 = ($61)

[0001628280-25-020355:notes:513]
Cost of subscription revenue: ADJ 1 = ($14), ADJ 4 = $40

[0001628280-25-020355:notes:514]
Sales and marketing: ADJ 1 = ($1), ADJ 4 = ($145)

[0001628280-25-020355:notes:515]
|  |  |  | Six Months Ended June 30, 2022 |
|  |  |  | As Reported |  | Adjustment |  | As Restated |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (39,487) |  |  | $ | (646) |  |  | $ | (40,133) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 2,350 |  |  | (17) |  |  | 2,333 |  |
| Write-off of inventory and change in inventory reserve |  |  | 425 |  |  | — |  |  | 425 |  |
| Adjustment to property and equipment for sales type leases |  |  | (625) |  |  | — |  |  | (625) |  |
| Loss from impairment of property and equipment |  |  | 412 |  |  | 437 |  |  | 849 |  |
| Stock-based compensation |  |  | 8,988 |  |  | 35 |  |  | 9,023 |  |
| Non-cash interest expense |  |  | 10 |  |  | — |  |  | 10 |  |
| Non-cash lease expense |  |  | 392 |  |  | — |  |  | 392 |  |
| Change in allowance for expected credit losses |  |  | 80 |  |  | — |  |  | 80 |  |
| Change in fair value of earn-out liability |  |  | (2,509) |  |  | — |  |  | (2,509) |  |
| Change in fair value of contingently issuable common stock |  |  | (1,448) |  |  | — |  |  | (1,448) |  |
| Change in fair value of public warrant liability |  |  | (5,443) |  |  | — |  |  | (5,443) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (5,786) |  |  | (687) |  |  | (6,473) |  |
| Inventory |  |  | (3,545) |  |  | — |  |  | (3,545) |  |
| Commission assets |  |  | (339) |  |  | (2) |  |  | (341) |  |
| Contract assets |  |  | (1,352) |  |  | 947 |  |  | (405) |  |
| Other assets |  |  | (756) |  |  | — |  |  | (756) |  |
| Prepaid expenses and other current assets |  |  | (9,707) |  |  | — |  |  | (9,707) |  |
| Accounts payable |  |  | 2,147 |  |  | — |  |  | 2,147 |  |
| Deferred revenue |  |  | 6,031 |  |  | (110) |  |  | 5,921 |  |
| Accrued expenses and other current liabilities |  |  | (1,876) |  |  | 1 |  |  | (1,875) |  |
| Operating lease liability |  |  | (457) |  |  | — |  |  | (457) |  |
| Net cash used in operating activities |  |  | (52,495) |  |  | (42) |  |  | (52,537) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Development of internal-use software |  |  | (1,301) |  |  | — |  |  | (1,301) |  |
| Purchases of property and equipment(1) |  |  | (11,379) |  |  | 42 |  |  | (11,337) |  |
| Net cash used in investing activities |  |  | (12,680) |  |  | 42 |  |  | (12,638) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 384 |  |  | — |  |  | 384 |  |
| Net cash provided by financing activities |  |  | 384 |  |  | — |  |  | 384 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (10) |  |  | — |  |  | (10) |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (64,801) |  |  | — |  |  | (64,801) |  |
| Cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 308,167 |  |  | — |  |  | 308,167 |  |
| Cash, cash equivalents and restricted cash at end of period |  |  | $ | 243,366 |  |  | $ | — |  |  | $ | 243,366 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |
| Cash paid for interest |  |  | $ | 277 |  |  | $ | — |  |  | $ | 277 |  |
| Supplemental disclosure of non-cash activities |  |  |  |  |  |  |  |
| Capital expenditures incurred but not yet paid |  |  | 4,256 |  |  | — |  |  | 4,256 |  |
| Capitalization of stock compensation |  |  | 57 |  |  | — |  |  | 57 |  |

[0001628280-25-020355:notes:516]
| Reconciliation of cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 242,691 |  |  | $ | — |  |  | $ | 242,691 |  |
| Restricted cash |  |  | 400 |  |  | — |  |  | 400 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Total cash, cash equivalents and restricted cash shown in the statements of cash flows |  |  | $ | 243,366 |  |  | $ | — |  |  | $ | 243,366 |  |


## us-gaap:SubsequentEventsTextBlock

[0001628280-25-020355:notes:517]
Subsequent Events
In January 2025, the Company implemented a Board-approved reduction in force affecting 40 members of its workforce. This action is part of the Company’s initiative to increase its annualized run rate cash savings as the Company seeks further flexibility to pursue its investment strategy with certain growth opportunities.

[0001628280-25-020355:notes:518]
The Company incurred pre-tax charges of $2.7 million for the reduction in force, substantially all of which was incurred in the first quarter of 2025. These charges consist of one-time termination charges arising from severance obligations of approximately $2.0 million, extended eligibility for the vesting of certain equity awards originally scheduled to vest on or before March 1, 2025, resulting in incremental non-cash expense of $0.5 million and other customary employee benefit payments in connection with a reduction in force of $0.2 million. Substantially all severance and related payments to affected individuals were completed by March 2025, with the exception of three employees who are subject to a continuous payment through July 2025 under the Company's Severance And Change In Control Plan.
