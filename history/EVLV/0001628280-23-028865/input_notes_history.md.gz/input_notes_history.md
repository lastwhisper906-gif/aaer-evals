# EVLV note change history — 0001628280-23-017260 → 0001628280-23-028865


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0001628280-23-028865:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of June 30, 2023 or December 31, 2022.
  (was, 2023-05-10, similarity 0.9961):
[0001628280-23-017260:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of March 31, 2023 or December 31, 2022.

- changed (2023-08-10):
[0001628280-23-028865:note_history:2]
Legal Proceedings and Other Matters
  (was, 2023-05-10, similarity 0.6538):
[0001628280-23-017260:note_history:2]
Legal Proceedings

- changed (2023-08-10):
[0001628280-23-028865:note_history:3]
The Company is not a party to any litigation of a material nature and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.
In the ordinary course of business, the Company is subject to regulatory and governmental examinations, information gathering requests, inquiries and investigations. We do not expect such examinations, requests, inquiries or investigations to have a material effect on our results of operations, financial condition or liquidity, either individually or in the aggregate.
  (was, 2023-05-10, similarity 0.7183):
[0001628280-23-017260:note_history:3]
The Company is not a party to any litigation of a material nature and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-08-10):
[0001628280-23-028865:note_history:4]
The accompanying unaudited condensed consolidated financial statements as of June 30, 2023, and for the three and six months ended June 30, 2023 and 2022 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2022 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of June 30, 2023 and the results of its operations for the three and six months ended June 30, 2023 and 2022 and cash flows for the six months ended June 30, 2023 and 2022. The results for the three and six months ended June 30, 2023 are not necessarily indicative of results to be expected for the year ending December 31, 2023, any other interim periods, or any future year or period.

- changed (2023-08-10):
[0001628280-23-028865:note_history:5]
Merger
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the Merger as a wholly-owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).
  (was, 2023-05-10, similarity 0.9965):
[0001628280-23-017260:note_history:5]
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the Merger as a wholly-owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

- removed (2023-08-10):
[0001628280-23-017260:note_history:6]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2023, and for the three months ended March 31, 2023 and 2022 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2022 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2023 and the results of its operations for the three months ended March 31, 2023 and 2022 and cash flows for the three months ended March 31, 2023 and 2022. The results for the three months ended March 31, 2023 are not necessarily indicative of results to be expected for the year ending December 31, 2023, any other interim periods, or any future year or period.

- removed (2023-08-10):
[0001628280-23-017260:note_history:7]
Merger

- removed (2023-08-10):
[0001628280-23-017260:note_history:8]
Revision of Prior Period Financial Statements

- removed (2023-08-10):
[0001628280-23-017260:note_history:9]
In preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified errors in its previously issued financial statements whereby (a) certain expenses that were cost of subscription revenue related and cost of service revenue related were inaccurately classified as sales and marketing expenses on the consolidated statements of operations and comprehensive loss, (b) certain equipment under lease or held for lease was inaccurately classified as inventory on the consolidated balance sheets and a portion of the cash outflows related to the equipment under lease or held for lease were misclassified between operating and investing cash flows on the consolidated statements of cash flows, and (c) the vesting of warrants related to the Business Development Agreement 
disclosed in Note 9 were not accounted for accurately. The identified errors impacted the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022. The Company has made adjustments to the prior period amounts presented in these financial statements accordingly. Additionally, the Company has made adjustments to correct for other previously identified immaterial errors. The Company evaluated the errors and determined that the related impacts were not material to any previously issued annual or interim financial statements. The impact of the revisions to the quarterly period ended March 31, 2022 is presented in Note 14.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0001628280-23-028865:note_history:10]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2022, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended
  (was, 2023-05-10, similarity 0.8309):
[0001628280-23-017260:note_history:10]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2022, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2022. There have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2023.

- added (2023-08-10):
[0001628280-23-028865:note_history:11]
December 31, 2022. There have been no material changes to the Company’s significant accounting policies during the six months ended June 30, 2023.

- changed (2023-08-10):
[0001628280-23-028865:note_history:12]
The Company qualifies as an “emerging growth company” as defined in the Jumpstart Our Business Startups Act of 2012 and has elected not to “opt out” to the extended transition related to complying with new or revised accounting standards, which means that when a standard is issued or revised and it has different application dates for public and nonpublic companies, the Company will adopt the new or revised standard at the time nonpublic companies adopt the new or revised standard and will do so until such time that the Company either (1) irrevocably elects to “opt out” of such extended transition period or (2) no longer qualifies as an emerging growth company. The Company may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for nonpublic companies. Based on our public float as of June 30, 2023, we expect to become a large accelerated filer and lose emerging growth company status as of December 31, 2023. As of December 31, 2023, we will be required to adopt new or revised accounting standards when they are applicable to public companies that are not emerging growth companies. Based on our public float as of June 30, 2023, we also expect to transition out of smaller reporting company status as of December 31, 2023 and will no longer be able to rely on the scaled disclosure requirements allowed for smaller reporting companies.
  (was, 2023-05-10, similarity 0.7438):
[0001628280-23-017260:note_history:12]
The Company qualifies as an “emerging growth company” as defined in the Jumpstart Our Business Startups Act of 2012 and has elected not to “opt out” to the extended transition related to complying with new or revised accounting standards, which means that when a standard is issued or revised and it has different application dates for public and nonpublic companies, the Company will adopt the new or revised standard at the time nonpublic companies adopt the new or revised standard and will do so until such time that the Company either (1) irrevocably elects to “opt out” of such extended transition period or (2) no longer qualifies as an emerging growth company. The Company may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for nonpublic companies.

- changed (2023-08-10):
[0001628280-23-028865:note_history:13]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years, and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have an impact on its consolidated financial statements and related disclosures.
  (was, 2023-05-10, similarity 0.6361):
[0001628280-23-017260:note_history:13]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have an impact on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0001628280-23-028865:note_history:14]
|  | June 30,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |
  (was, 2023-05-10, similarity 0.9822):
[0001628280-23-017260:note_history:14]
|  | March 31,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |

- changed (2023-08-10):
[0001628280-23-028865:note_history:15]
In light of the foregoing, on March 28, 2023, upon the recommendation of the Company’s newly-formed Investment Committee of the Board of Directors, the Company (i) gave notice of its desire and intent to terminate the commitments under the 2022 SVB Credit Agreement and (ii) transferred its excess cash out of First Citizens Bank (the “Transfer”). The Transfer resulted in an event of default under the 2022 SVB Credit Agreement. Upon the occurrence of such event of default, First Citizens Bank could have, but was not required to, declare all obligations under the 2022 SVB 
Credit Agreement immediately due and payable. First Citizens Bank did not make such declaration following such event of default. On March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs.
  (was, 2023-05-10, similarity 0.9992):
[0001628280-23-017260:note_history:15]
In light of the foregoing, on March 28, 2023, upon the recommendation of the Company’s newly-formed Investment Committee of the Board of Directors, the Company (i) gave notice of its desire and intent to terminate the commitments under the 2022 SVB Credit Agreement and (ii) transferred its excess cash out of First Citizens Bank (the “Transfer”). The Transfer resulted in an event of default under the 2022 SVB Credit Agreement. Upon the occurrence of such event of default, First Citizens Bank could have, but was not required to, declare all obligations under the 2022 SVB 
Credit Agreement immediately due and payable. First Citizens Bank did not make such declaration following such event of default. On March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write off of $0.3 million of unamortized debt issuance costs.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0001628280-23-028865:note_history:16]
|  | June 30,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |
  (was, 2023-05-10, similarity 0.9822):
[0001628280-23-017260:note_history:16]
|  | March 31,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0001628280-23-028865:note_history:17]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended June 30, 2023 and 2022, revenue from Motorola's distributor services was $2.9 million and $1.9 million, respectively. During the six months ended June 30, 2023 and 2022, revenue from Motorola's distributor services was $6.2 million and $2.8 million, respectively. As of June 30, 2023 and December 31, 2022, accounts receivable related to Motorola’s distributor services was $3.0 million and $12.5 million, respectively.
  (was, 2023-05-10, similarity 0.8231):
[0001628280-23-017260:note_history:17]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended March 31, 2023 and 2022, revenue from Motorola's distributor services was  $3.2 million and $0.8 million, respectively. As of March 31, 2023 and December 31, 2022, accounts receivable related to Motorola’s distributor services was $4.7 million and $12.5 million, respectively.

- changed (2023-08-10):
[0001628280-23-028865:note_history:18]
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB ("Securitas") in 2023. Securitas, directly or through its affiliates, resells the Company's products. During the three months ended June 30, 2023 and 2022, revenue from Securitas' reseller services was $0.5 million and $0.3 million, respectively. During the six months ended June 30, 2023 and 2022, revenue from Securitas' reseller services was $0.9 million and $0.3 million, respectively. As of June 30, 2023 and December 31, 2022, accounts receivable related to Securitas' reseller services was $0.9 million and $2.2 million, respectively.
  (was, 2023-05-10, similarity 0.7852):
[0001628280-23-017260:note_history:18]
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB ("Securitas") in 2023. Securitas, directly or through its affiliates, resells the Company's products. During the three months ended March 31, 2023 and 2022, revenue from Securitas' reseller services was $0.4 million and less than $0.1 million, respectively. As of March 31, 2023 and December 31, 2022, accounts receivable related to Securitas' reseller services was $0.6 million and $2.2 million, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0001628280-23-028865:note_history:19]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Product revenue | $ | 7,243 |  |  | $ | 4,146 |  |  | $ | 15,997 |  |  | $ | 9,340 |  |
| Leased equipment | 7,964 |  |  | 4,006 |  |  | 14,430 |  |  | 7,010 |  |
| SaaS, maintenance, and other revenue | 4,121 |  |  | 729 |  |  | 6,899 |  |  | 1,097 |  |
| Professional services | 497 |  |  | 189 |  |  | 1,080 |  |  | 333 |  |
| Total revenue | $ | 19,825 |  |  | $ | 9,070 |  |  | $ | 38,406 |  |  | $ | 17,780 |  |
  (was, 2023-05-10, similarity 0.7686):
[0001628280-23-017260:note_history:19]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Product revenue | $ | 8,754 |  |  | $ | 5,194 |  |  |  |  |  |
| Leased equipment | 6,466 |  |  | 3,004 |  |  |  |  |  |
| SaaS, maintenance, and other revenue | 2,778 |  |  | 368 |  |  |  |  |  |
| Professional services | 583 |  |  | 144 |  |  |  |  |  |
| Total revenue | $ | 18,581 |  |  | $ | 8,710 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0001628280-23-028865:note_history:20]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases under ASC 842 and (2) from the sale of products, inclusive of SaaS and maintenance, (3) professional services, and (4) license fees related to a distribution and license agreement with the Company's primary contract manufacturer. The Company’s arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax.
  (was, 2023-05-10, similarity 0.8527):
[0001628280-23-017260:note_history:20]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases under ASC 842 and (2) from the sale of products, inclusive of SaaS and maintenance and (3) professional services. The Company’s arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax.

- changed (2023-08-10):
[0001628280-23-028865:note_history:21]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of June 30, 2023.
  (was, 2023-05-10, similarity 0.9755):
[0001628280-23-017260:note_history:21]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2023.

- changed (2023-08-10):
[0001628280-23-028865:note_history:22]
The amount of minimum future leases is based on expected income recognition. As of June 30, 2023, future minimum payments on noncancelable leases are as follows (in thousands):
  (was, 2023-05-10, similarity 0.9736):
[0001628280-23-017260:note_history:22]
The amount of minimum future leases is based on expected income recognition. As of March 31, 2023, future minimum payments on noncancelable leases are as follows (in thousands):

- changed (2023-08-10):
[0001628280-23-028865:note_history:23]
| Year Ending December 31: |  |
| 2023 (six months remaining) | $ | 21,253 |  |
| 2024 | 41,340 |  |
| 2025 | 37,364 |  |
| 2026 | 26,748 |  |
| 2027 | 7,511 |  |
| Thereafter | 23 |  |
|  | $ | 134,239 |  |
  (was, 2023-05-10, similarity 0.9835):
[0001628280-23-017260:note_history:23]
| Year Ending December 31: |  |
| 2023 (nine months remaining) | $ | 23,898 |  |
| 2024 | 30,446 |  |
| 2025 | 26,586 |  |
| 2026 | 16,060 |  |
| 2027 | 2,065 |  |
| Thereafter | 17 |  |
|  | $ | 99,072 |  |

- changed (2023-08-10):
[0001628280-23-028865:note_history:24]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of June 30, 2023 and December 31, 2022, the Company had $4.7 million and $2.9 million in current portion of contract assets and $0.7 million and $1.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2023-05-10, similarity 0.9903):
[0001628280-23-017260:note_history:24]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of March 31, 2023 and December 31, 2022, the Company had $3.3 million and $2.9 million in current portion of contract assets and $0.7 million and $1.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2023-08-10):
[0001628280-23-028865:note_history:25]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $5.3 million and $12.1 million during the three and six months ended June 30, 2023 that was included in the December 31, 2022 deferred revenue balance. The Company recognized revenue of $2.2 million and $4.7 million during the three and six months ended June 30, 2022 that was included in the December 31, 2021 deferred revenue balance.
  (was, 2023-05-10, similarity 0.8099):
[0001628280-23-017260:note_history:25]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $6.9 million during the three months ended March 31, 2023 that was included in the December 31, 2022 deferred revenue balance. The Company recognized revenue of $2.5 million during the three months ended March 31, 2022 that was included in the December 31, 2021 deferred revenue balance.

- changed (2023-08-10):
[0001628280-23-028865:note_history:26]
| Balance at December 31, 2022 | $ | 35,968 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (12,140) |  |
| Revenue deferred | 36,253 |  |
| Balance at June 30, 2023 | $ | 60,081 |  |
  (was, 2023-05-10, similarity 0.9772):
[0001628280-23-017260:note_history:26]
| Balance at December 31, 2022 | $ | 35,968 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (6,887) |  |
| Revenue deferred | 15,644 |  |
| Balance at March 31, 2023 | $ | 44,725 |  |

- changed (2023-08-10):
[0001628280-23-028865:note_history:27]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue from sales-type leases | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,106 |  |
| Interest income on lease receivables | 51 |  |  | 61 |  |  | 104 |  |  | 110 |  |
| Lease income - operating leases | 7,964 |  |  | 4,006 |  |  | 14,430 |  |  | 7,010 |  |
| Total lease revenue | $ | 8,015 |  |  | $ | 4,067 |  |  | $ | 14,534 |  |  | $ | 8,226 |  |
  (was, 2023-05-10, similarity 0.7455):
[0001628280-23-017260:note_history:27]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Revenue from sales-type leases | $ | — |  |  | $ | 1,106 |  |  |  |  |  |
| Interest income on lease receivables | 53 |  |  | 49 |  |  |  |  |  |
| Lease income - operating leases | 6,466 |  |  | 3,004 |  |  |  |  |  |
| Total lease revenue | $ | 6,519 |  |  | $ | 4,159 |  |  |  |  |  |

- changed (2023-08-10):
[0001628280-23-028865:note_history:28]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were less than $0.1 million and $0.2 million during the three and six months ended June 30, 2023, respectively. Revenue related to leases entered into with related parties were $0.2 million and $0.3 million during the three and six months ended June 30, 2022, respectively.
  (was, 2023-05-10, similarity 0.8544):
[0001628280-23-017260:note_history:28]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified as other income (expense), net in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.2 million and $0.1 million during the three months ended March 31, 2023 and 2022, respectively.

- changed (2023-08-10):
[0001628280-23-028865:note_history:29]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Product revenue | $ | 7,243 |  |  | $ | 4,146 |  |  | $ | 15,997 |  |  | $ | 9,340 |  |
| Leased equipment | 7,964 |  |  | 4,006 |  |  | 14,430 |  |  | 7,010 |  |
| SaaS, maintenance, and other revenue | 4,121 |  |  | 729 |  |  | 6,899 |  |  | 1,097 |  |
| Professional services | 497 |  |  | 189 |  |  | 1,080 |  |  | 333 |  |
| Total revenue | $ | 19,825 |  |  | $ | 9,070 |  |  | $ | 38,406 |  |  | $ | 17,780 |  |
  (was, 2023-05-10, similarity 0.7686):
[0001628280-23-017260:note_history:29]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Product revenue | $ | 8,754 |  |  | $ | 5,194 |  |  |  |  |  |
| Leased equipment | 6,466 |  |  | 3,004 |  |  |  |  |  |
| SaaS, maintenance, and other revenue | 2,778 |  |  | 368 |  |  |  |  |  |
| Professional services | 583 |  |  | 144 |  |  |  |  |  |
| Total revenue | $ | 18,581 |  |  | $ | 8,710 |  |  |  |  |  |

- changed (2023-08-10):
[0001628280-23-028865:note_history:30]
Commissions
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $10.3 million and $9.0 million as of June 30, 2023 and December 31, 2022, respectively. During the three months ended June 30, 2023 and 2022, the Company recognized commission expense of $1.5 million and $0.9 million, respectively. During the six months ended June 30, 2023 and 2022, the Company recognized commission expense of $3.1 million and $1.2 million, respectively.
  (was, 2023-05-10, similarity 0.6971):
[0001628280-23-017260:note_history:30]
Contract Acquisition Costs
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $9.7 million and $9.0 million as of March 31, 2023 and December 31, 2022, respectively. During the three months ended March 31, 2023 and 2022, the Company amortized commission expense of $1.6 million and $0.4 million, respectively.
