# EVLV 8-K — 0001628280-23-028861 filed 2023-08-10

## item codes, every 8-K on or before 2023-08-10

- 2023-08-10 0001628280-23-028861 — 2.02, 9.01
- 2023-06-02 0001628280-23-020680 — 5.07
- 2023-05-10 0001628280-23-017243 — 2.02, 9.01
- 2023-04-03 0001628280-23-010402 — 1.02, 2.04, 8.01, 9.01
- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2023-08-10

- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-23-028861:8k_2_02:1]
EX-99.1
2
evlv-20230810exx991.htm
EX-99.1

[0001628280-23-028861:8k_2_02:2]
Document

[0001628280-23-028861:8k_2_02:3]
Exhibit 99.1

[0001628280-23-028861:8k_2_02:4]
Investor Relations:

[0001628280-23-028861:8k_2_02:5]
Brian Norris

[0001628280-23-028861:8k_2_02:6]
Senior Vice President of Finance and Investor Relations

[0001628280-23-028861:8k_2_02:7]
bnorris@evolvtechnology.com

[0001628280-23-028861:8k_2_02:8]
Evolv Technology Reports Record Second Quarter Financial Results

[0001628280-23-028861:8k_2_02:9]
– Company Raises Outlook for 2023 –

[0001628280-23-028861:8k_2_02:10]
•Q2 Revenue of $19.8 million, up 119% year-over-year

[0001628280-23-028861:8k_2_02:11]
•Q2 Ending ARR1 of $54.3 million, up 160% year-over-year

[0001628280-23-028861:8k_2_02:12]
•Q2 Ending RPO2 of $198.3 million, up 145% year-over-year

[0001628280-23-028861:8k_2_02:13]
•Q2 Ending Evolv Express® subscriptions of 3,386, up 195% year-over-year

[0001628280-23-028861:8k_2_02:14]
Waltham, Massachusetts – August 10, 2023 – Evolv Technology (NASDAQ: EVLV), the leader in AI-based weapons detection security screening, today announced financial results for the quarter ended June 30, 2023 and raised its business outlook for 2023.

[0001628280-23-028861:8k_2_02:15]
Results for the Second Quarter of 2023

[0001628280-23-028861:8k_2_02:16]
Total revenue for the second quarter of 2023 was $19.8 million, an increase of 119% compared to $9.1 million for the second quarter of 2022. Annual Recurring Revenue (“ARR”)1 was $54.3 million at the end of second quarter of 2023, an increase of 160% compared to $20.9 million at the end of the second quarter of 2022. Net loss for the second quarter of 2023 was $(66.8) million, or $(0.45) per basic and diluted share, compared to net loss of $(25.7) million, or $(0.18) per basic and diluted share, in the second quarter of 2022. Adjusted earnings (loss)3 for the second quarter of 2023 was $(14.3) million, or $(0.10) per diluted share, compared to adjusted earnings (loss)3 of  $(17.3) million, or $(0.12) per diluted share, for the second quarter of 2022. Adjusted EBITDA3 for the second quarter of 2023 was $(13.8) million compared to $(16.4) million in the second quarter of 2022. As of June 30, 2023, the Company had cash, cash equivalents, and restricted cash of $156.8 million and no debt.

[0001628280-23-028861:8k_2_02:17]
Results for the First Six Month of 2023

[0001628280-23-028861:8k_2_02:18]
Total revenue for the six months ended June 30, 2023 was $38.4 million, an increase of 116% compared to $17.8 million for the six months ended June 30, 2022. Net loss for the six months ended June 30, 2023 was $(95.4) million, or $(0.65) per basic and diluted share, compared to net loss of $(39.5) million, or $(0.28) per basic and diluted share, in the six months ended June 30, 2022. Adjusted earnings (loss)3 for the six months ended June 30, 2023 was $(31.2) million, or $(0.21) per diluted share, compared to adjusted earnings (loss)3 of  $(35.8) million, or $(0.25) per diluted share, for the six months ended June 30, 2022. Adjusted EBITDA3 for the six months ended June 30, 2023 was $(29.3) million compared to $(33.7) million in the six months ended June 30, 2022.

[0001628280-23-028861:8k_2_02:19]
The following table summarizes the breakdown of recurring and non-recurring revenue4 during each quarter:

[0001628280-23-028861:8k_2_02:20]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | % Change |  | 2023 |  | 2022 |  | % Change |
| Recurring revenue | $ | 11,689 |  |  | $ | 4,604 |  |  | 154 | % |  | $ | 20,764 |  |  | $ | 7,763 |  |  | 167 | % |
| Non-recurring revenue | 8,136 |  |  | 4,466 |  |  | 82 | % |  | 17,642 |  |  | 10,017 |  |  | 76 | % |
| Total revenue | $ | 19,825 |  |  | $ | 9,070 |  |  | 119 | % |  | $ | 38,406 |  |  | $ | 17,780 |  |  | 116 | % |

[0001628280-23-028861:8k_2_02:21]
The following table summarizes operating cash flows during each quarter:

[0001628280-23-028861:8k_2_02:22]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net loss | $ | (66,754) |  |  | $ | (25,686) |  |  | $ | (95,363) |  |  | $ | (39,487) |  |
| Non-cash (income) expense | 54,467 |  |  | 7,758 |  |  | 68,472 |  |  | 2,632 |  |
| Changes in operating assets and liabilities | 7,208 |  |  | (5,137) |  |  | 18,378 |  |  | (15,640) |  |
| Net cash used in operating activities | $ | (5,079) |  |  | $ | (23,065) |  |  | $ | (8,513) |  |  | $ | (52,495) |  |

[0001628280-23-028861:8k_2_02:23]
Company Raises Outlook for 2023

[0001628280-23-028861:8k_2_02:24]
The Company today commented on its business outlook for 2023. The Company's outlook is based on the current indications for its business, which may change at any time.

[0001628280-23-028861:8k_2_02:25]
|  |  | 2023 Business Outlook |
| Estimate (In millions) |  | Issued May 10, 2023 |  | Issued August 10, 2023 |
| Total Revenue |  | $60-$65 |  | $70-$75 |
| Annual Recurring Revenue1 (ARR) at 12/31/23 |  | $67-$71 |  | $70-$72 |
| Adjusted Gross Margin3 |  | 35%-40% |  | 38%-42% |
| Adjusted EBITDA3 |  | ($53-$58) |  | ($52-$56) |

[0001628280-23-028861:8k_2_02:26]
Company to Host Live Conference Call and Webcast

[0001628280-23-028861:8k_2_02:27]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business and other matters.  The conference call may be accessed in the United States by dialing +1.877.692.8955 and using access code 825879.  The conference call may be accessed outside of the United States by dialing +1.234.720.6979 and using the same access code. The conference call will be simultaneously webcast on the Company’s investor relations website, which can be accessed at http://ir.evolvtechnology.com.  A replay of the conference call will be available for a period of 30 days by dialing +1.866.207.1041 or +1.402.970.0847 and using access code 1955791 or by accessing the webcast replay on the Company’s investor relations website at http://ir.evolvtechnology.com.

[0001628280-23-028861:8k_2_02:28]
About Evolv Technology

[0001628280-23-028861:8k_2_02:29]
Evolv Technology (NASDAQ: EVLV) is transforming human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered weapons detection and analytics. Its mission is to transform security to create a safer world to work, learn, and play. Evolv has digitally transformed the gateways in places where people gather by enabling seamless integration combined with powerful analytics and insights. Evolv’s advanced systems have scanned more than 750 million people, second only to the Department of Homeland Security’s Transportation Security Administration (TSA) in the United States. Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category. Evolv Technology®,

[0001628280-23-028861:8k_2_02:30]
Evolv Express®, Evolv Insights®, and Evolv Cortex AI® are registered trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit https://evolvtechnology.com.

[0001628280-23-028861:8k_2_02:31]
1 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001628280-23-028861:8k_2_02:32]
2 We define Remaining Performance Obligation, or RPO, as estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied or partially satisfied as of the end of the quarter.

[0001628280-23-028861:8k_2_02:33]
3 Non-GAAP Financial Measures In this press release, the Company’s adjusted gross profit (loss), adjusted gross margin, adjusted operating expenses, adjusted operating income (loss), adjusted EBITDA, adjusted earnings (loss), and adjusted earnings per diluted share are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit and adjusted gross margin exclude one-time items and stock-based compensation expense which management believes provides a more meaningful representation of contribution margin. Adjusted operating expenses is defined as operating expenses less one-time items, stock-based compensation expense, restructuring expenses, and loss on impairment of lease equipment which management believes provides a more meaningful representation of on-going operating expense levels. Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, share-based compensation, and certain other one-time expenses. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, change in fair value of derivative liability, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, change in fair value of common stock warrant liability, restructuring expenses, loss on impairment of lease equipment, and certain other one-time expenses. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operating performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release. The Company is unable to provide a reconciliation of Adjusted Gross Margin to GAAP Gross Margin and non-GAAP Adjusted EBITDA to Net Income (Loss), each measure's most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact these GAAP financial measures are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of derivative liabilities, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001628280-23-028861:8k_2_02:34]
4 Recurring revenue includes the recurring portion of revenue associated with pure subscription contracts and hardware purchase subscription contracts. Non-recurring revenue includes revenue that is one-time in nature, such as product revenue, shipping revenue, and revenue from installation, training, and professional services.

[0001628280-23-028861:8k_2_02:35]
Forward-Looking Statements

[0001628280-23-028861:8k_2_02:36]
acceptable terms, if at all; litigation and regulatory enforcement risks, including the diversion of management time and attention and the additional costs and demands on resources, and the Company’s ability to identify and implement digital advances in its technology. These and other important factors discussed under the caption “Risk Factors” in our Annual Report on Form 10-K for the year ended December 31, 2022 filed with the Securities and Exchange Commission ("SEC") on March 24, 2023, as may be updated from time to time in other filings we make with the SEC including our Quarterly Report on Form 10-Q for the quarter ended on March 31, 2023 that was filed with the SEC on May 10, 2023, could cause actual results to differ materially from those indicated by the forward-looking statements made in this press release.

[0001628280-23-028861:8k_2_02:37]
EVOLV TECHNOLOGY

[0001628280-23-028861:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001628280-23-028861:8k_2_02:39]
(In thousands, except share and per share data)

[0001628280-23-028861:8k_2_02:40]
(Unaudited)

[0001628280-23-028861:8k_2_02:41]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 7,243 |  |  | $ | 4,146 |  |  | $ | 15,997 |  |  | $ | 9,340 |  |
| Subscription revenue | 7,964 |  |  | 4,006 |  |  | 14,430 |  |  | 7,010 |  |
| Service revenue | 4,618 |  |  | 918 |  |  | 7,979 |  |  | 1,430 |  |
| Total revenue | 19,825 |  |  | 9,070 |  |  | 38,406 |  |  | 17,780 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 7,722 |  |  | 5,347 |  |  | 18,300 |  |  | 10,553 |  |
| Cost of subscription revenue | 3,406 |  |  | 1,981 |  |  | 5,757 |  |  | 3,523 |  |
| Cost of service revenue | 1,284 |  |  | 1,189 |  |  | 2,171 |  |  | 2,254 |  |
| Total cost of revenue | 12,412 |  |  | 8,517 |  |  | 26,228 |  |  | 16,330 |  |
| Gross profit | 7,413 |  |  | 553 |  |  | 12,178 |  |  | 1,450 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,395 |  |  | 4,156 |  |  | 11,784 |  |  | 8,331 |  |
| Sales and marketing | 13,613 |  |  | 11,751 |  |  | 26,417 |  |  | 21,423 |  |
| General and administrative | 10,874 |  |  | 9,612 |  |  | 19,800 |  |  | 20,429 |  |
| Loss from impairment of property and equipment | 157 |  |  | 316 |  |  | 294 |  |  | 412 |  |
| Total operating expenses | 31,039 |  |  | 25,835 |  |  | 58,295 |  |  | 50,595 |  |
| Loss from operations | (23,626) |  |  | (25,282) |  |  | (46,117) |  |  | (49,145) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (159) |  |  | (654) |  |  | (301) |  |
| Interest income | 1,853 |  |  | 491 |  |  | 2,806 |  |  | 559 |  |
| Other expense, net | (22) |  |  | — |  |  | (3) |  |  | — |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | (626) |  |  | — |  |
| Change in fair value of contingent earn-out liability | (28,113) |  |  | (569) |  |  | (31,431) |  |  | 2,509 |  |
| Change in fair value of contingently issuable common stock liability | (5,095) |  |  | (24) |  |  | (5,837) |  |  | 1,448 |  |
| Change in fair value of public warrant liability | (11,751) |  |  | (143) |  |  | (13,501) |  |  | 5,443 |  |
| Total other income (expense), net | (43,128) |  |  | (404) |  |  | $ | (49,246) |  |  | $ | 9,658 |  |
| Net loss | $ | (66,754) |  |  | $ | (25,686) |  |  | $ | (95,363) |  |  | $ | (39,487) |  |
| Weighted average common shares outstanding – basic and diluted | 148,882,160 |  |  | 143,552,032 |  |  | 147,664,534 |  |  | 143,220,268 |  |
| Net loss per share - basic and diluted | $ | (0.45) |  |  | $ | (0.18) |  |  | $ | (0.65) |  |  | $ | (0.28) |  |
| Net loss | $ | (66,754) |  |  | $ | (25,686) |  |  | $ | (95,363) |  |  | $ | (39,487) |  |
| Other comprehensive income (loss) |  |  |  |  |  |  |  |
| Cumulative translation adjustment | (17) |  |  | (10) |  |  | (33) |  |  | (10) |  |
| Total other comprehensive loss | (17) |  |  | (10) |  |  | (33) |  |  | (10) |  |
| Total comprehensive loss | $ | (66,771) |  |  | $ | (25,696) |  |  | $ | (95,396) |  |  | $ | (39,497) |  |

[0001628280-23-028861:8k_2_02:42]
EVOLV TECHNOLOGY

[0001628280-23-028861:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-23-028861:8k_2_02:44]
(In thousands, except share and per share data)

[0001628280-23-028861:8k_2_02:45]
(Unaudited)

[0001628280-23-028861:8k_2_02:46]
|  | June 30, 2023 |  | December 31, 2022 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 155,537 |  |  | $ | 229,783 |  |
| Restricted cash | 1,000 |  |  | — |  |
| Accounts receivable, net | 32,393 |  |  | 31,920 |  |
| Inventory | 5,032 |  |  | 10,257 |  |
| Current portion of contract assets | 4,732 |  |  | 2,852 |  |
| Current portion of commission asset | 3,648 |  |  | 3,384 |  |
| Prepaid expenses and other current assets | 13,808 |  |  | 14,388 |  |
| Total current assets | 216,150 |  |  | 292,584 |  |
| Restricted cash, noncurrent | 275 |  |  | 275 |  |
| Contract assets, noncurrent | 690 |  |  | 1,386 |  |
| Commission asset, noncurrent | 6,649 |  |  | 5,655 |  |
| Property and equipment, net | 81,085 |  |  | 44,707 |  |
| Operating lease right-of-use assets | 1,241 |  |  | 1,673 |  |
| Other assets | 1,878 |  |  | 1,835 |  |
| Total assets | $ | 307,968 |  |  | $ | 348,115 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 16,912 |  |  | $ | 18,194 |  |
| Accrued expenses and other current liabilities | 10,821 |  |  | 11,545 |  |
| Current portion of deferred revenue | 39,366 |  |  | 18,273 |  |
| Current portion of long-term debt | — |  |  | 10,000 |  |
| Current portion of operating lease liabilities | 1,130 |  |  | 1,114 |  |
| Total current liabilities | 68,229 |  |  | 59,126 |  |
| Deferred revenue, noncurrent | 20,715 |  |  | 17,695 |  |
| Long-term debt, noncurrent | — |  |  | 19,683 |  |
| Operating lease liabilities, noncurrent | 363 |  |  | 892 |  |
| Contingent earn-out liability | 45,649 |  |  | 14,218 |  |
| Contingently issuable common stock liability | 9,229 |  |  | 3,392 |  |
| Public warrant liability | 19,625 |  |  | 6,124 |  |
| Total liabilities | 163,810 |  |  | 121,130 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at June 30, 2023 and December 31, 2022; no shares issued and outstanding at June 30, 2023 and December 31, 2022 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at June 30, 2023 and December 31, 2022; 149,790,742 and 145,204,974 shares issued and outstanding at June 30, 2023 and December 31, 2022, respectively | 15 |  |  | 15 |  |
| Additional paid-in capital | 431,759 |  |  | 419,190 |  |
| Accumulated other comprehensive loss | (43) |  |  | (10) |  |
| Accumulated deficit | (287,573) |  |  | (192,210) |  |
| Stockholders’ equity | 144,158 |  |  | 226,985 |  |
| Total liabilities and stockholders’ equity | $ | 307,968 |  |  | $ | 348,115 |  |

[0001628280-23-028861:8k_2_02:47]
EVOLV TECHNOLOGY

[0001628280-23-028861:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-23-028861:8k_2_02:49]
(In thousands)

[0001628280-23-028861:8k_2_02:50]
(Unaudited)

[0001628280-23-028861:8k_2_02:51]
|  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (95,363) |  |  | $ | (39,487) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 4,087 |  |  | 2,350 |  |
| Write-off of inventory and change in inventory reserve | 337 |  |  | 425 |  |
| Adjustment to property and equipment for sales type leases | — |  |  | (625) |  |
| Loss from impairment of property and equipment | 294 |  |  | 412 |  |
| Stock-based compensation | 11,732 |  |  | 8,988 |  |
| Non-cash interest expense | 22 |  |  | 10 |  |
| Non-cash lease expense | 432 |  |  | 392 |  |
| Change in allowance for expected credit losses | 173 |  |  | 80 |  |
| Loss on extinguishment of debt | 626 |  |  | — |  |
| Change in fair value of earn-out liability | 31,431 |  |  | (2,509) |  |
| Change in fair value of contingently issuable common stock | 5,837 |  |  | (1,448) |  |
| Change in fair value of public warrant liability | 13,501 |  |  | (5,443) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (646) |  |  | (5,786) |  |
| Inventory | 5,080 |  |  | (3,545) |  |
| Commission assets | (1,258) |  |  | (339) |  |
| Contract assets | (1,184) |  |  | (1,352) |  |
| Other assets | (43) |  |  | (756) |  |
| Prepaid expenses and other current assets | 580 |  |  | (9,707) |  |
| Accounts payable | (7,409) |  |  | 2,147 |  |
| Deferred revenue | 24,113 |  |  | 6,031 |  |
| Accrued expenses and other current liabilities | (342) |  |  | (1,876) |  |
| Operating lease liability | (513) |  |  | (457) |  |
| Net cash used in operating activities | (8,513) |  |  | (52,495) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (1,599) |  |  | (1,301) |  |
| Purchases of property and equipment | (33,173) |  |  | (11,379) |  |
| Proceeds from sale of property and equipment | 60 |  |  | — |  |
| Net cash used in investing activities | (34,712) |  |  | (12,680) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options and warrants | 344 |  |  | 384 |  |
| Proceeds from long-term debt | 1,876 |  |  | — |  |
| Repayment of principal on long-term debt | (31,876) |  |  | — |  |
| Payment of debt issuance costs and prepayment penalty | (332) |  |  | — |  |
| Net cash provided by (used in) financing activities | (29,988) |  |  | 384 |  |
| Effect of exchange rate changes on cash and cash equivalents | (33) |  |  | (10) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (73,246) |  |  | (64,801) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 230,058 |  |  | 308,167 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 156,812 |  |  | $ | 243,366 |  |

[0001628280-23-028861:8k_2_02:52]
EVOLV TECHNOLOGY

[0001628280-23-028861:8k_2_02:53]
SUMMARY OF KEY OPERATING STATISTICS

[0001628280-23-028861:8k_2_02:54]
(Unaudited)

[0001628280-23-028861:8k_2_02:55]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |  | December 31,2022 |  | March 31,2023 |  | June 30,2023 |  |  |  |  |
| New customers |  | 44 |  |  | 53 |  |  | 92 |  |  | 106 |  |  | 61 |  |  | 74 |  |  |  |  |  |
| Annual recurring revenue |  | $ | 16,641 |  |  | $ | 20,865 |  |  | $ | 28,741 |  |  | $ | 34,120 |  |  | $ | 42,021 |  |  | $ | 54,339 |  |  |  |  |  |
| Recurring revenue |  | $ | 3,159 |  |  | $ | 4,604 |  |  | $ | 6,221 |  |  | $ | 7,388 |  |  | $ | 9,075 |  |  | $ | 11,689 |  |  |  |  |  |
| Remaining performance obligation |  | $ | 63,750 |  |  | $ | 80,978 |  |  | $ | 109,407 |  |  | $ | 144,561 |  |  | $ | 161,813 |  |  | $ | 198,296 |  |  |  |  |  |
| Net additions |  | 207 |  |  | 237 |  |  | 545 |  |  | 575 |  |  | 520 |  |  | 599 |  |  |  |  |  |
| Ending deployed units |  | 910 |  |  | 1,147 |  |  | 1,692 |  |  | 2,267 |  |  | 2,787 |  |  | 3,386 |  |  |  |  |  |

[0001628280-23-028861:8k_2_02:56]
EVOLV TECHNOLOGY

[0001628280-23-028861:8k_2_02:57]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001628280-23-028861:8k_2_02:58]
(In thousands)

[0001628280-23-028861:8k_2_02:59]
(Unaudited)

[0001628280-23-028861:8k_2_02:60]
|  | Three Months Ended, |  |  |  |
|  |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |  | December 31,2022 |  | March 31,2023 |  | June 30,2023 |  |  |  |  |
| Operating expenses, GAAP |  | $ | 24,760 |  |  | $ | 25,835 |  |  | $ | 26,827 |  |  | $ | 26,868 |  |  | $ | 27,256 |  |  | $ | 31,039 |  |  |  |  |  |
| Stock-based compensation |  | (3,819) |  |  | (4,781) |  |  | (6,298) |  |  | (6,771) |  |  | (4,898) |  |  | (6,505) |  |  |  |  |  |
| Restructuring expenses |  | (324) |  |  | 13 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |
| Loss on impairment of lease equipment |  | (96) |  |  | (316) |  |  | (626) |  |  | (123) |  |  | (137) |  |  | (157) |  |  |  |  |  |
| Other one-time expenses |  | (1,107) |  |  | (2,298) |  |  | (69) |  |  | (41) |  |  | (53) |  |  | (683) |  |  |  |  |  |
| Adjusted Operating Expenses |  | $ | 19,414 |  |  | $ | 18,453 |  |  | $ | 19,834 |  |  | $ | 19,933 |  |  | $ | 22,168 |  |  | $ | 23,694 |  |  |  |  |  |

[0001628280-23-028861:8k_2_02:61]
EVOLV TECHNOLOGY

[0001628280-23-028861:8k_2_02:62]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT, GAAP GROSS MARGIN TO ADJUSTED GROSS MARGIN AND GAAP OPERATING INCOME (LOSS) TO ADJUSTED OPERATING INCOME (LOSS)

[0001628280-23-028861:8k_2_02:63]
(In thousands)

[0001628280-23-028861:8k_2_02:64]
(Unaudited)

[0001628280-23-028861:8k_2_02:65]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue | $ | 19,825 |  |  | $ | 9,070 |  |  | $ | 38,406 |  |  | $ | 17,780 |  |
| Cost of Revenue | 12,412 |  |  | 8,517 |  |  | 26,228 |  |  | 16,330 |  |
| Gross Profit, GAAP | 7,413 |  |  | 553 |  |  | 12,178 |  |  | 1,450 |  |
| Stock-based compensation | 184 |  |  | 280 |  |  | 329 |  |  | 388 |  |
| Amortization of capitalized stock-based compensation | 11 |  |  | 6 |  |  | 21 |  |  | 9 |  |
| Adjusted Gross Profit | $ | 7,608 |  |  | $ | 839 |  |  | $ | 12,528 |  |  | $ | 1,847 |  |
| Gross Margin % | 37.4 | % |  | 6.1 | % |  | 31.7 | % |  | 8.2 | % |
| Adjusted Gross Margin % | 38.4 | % |  | 9.3 | % |  | 32.6 | % |  | 10.4 | % |

[0001628280-23-028861:8k_2_02:66]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Operating income (loss), GAAP | $ | (23,626) |  |  | $ | (25,282) |  |  | $ | (46,117) |  |  | $ | (49,145) |  |
| Stock-based compensation | 6,689 |  |  | 5,061 |  |  | 11,732 |  |  | 8,988 |  |
| Amortization of capitalized stock-based compensation | 11 |  |  | 6 |  |  | 21 |  |  | 9 |  |
| Restructuring expenses | — |  |  | (13) |  |  | — |  |  | 311 |  |
| Loss on impairment of lease equipment | 157 |  |  | 316 |  |  | 294 |  |  | 412 |  |
| Other one-time expenses | 683 |  |  | 2,298 |  |  | 736 |  |  | 3,405 |  |
| Adjusted Operating Income (Loss) | $ | (16,086) |  |  | $ | (17,614) |  |  | $ | (33,334) |  |  | $ | (36,020) |  |

[0001628280-23-028861:8k_2_02:67]
EVOLV TECHNOLOGY

[0001628280-23-028861:8k_2_02:68]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-23-028861:8k_2_02:69]
(In thousands)

[0001628280-23-028861:8k_2_02:70]
(Unaudited)

[0001628280-23-028861:8k_2_02:71]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net loss | $ | (66,754) |  |  | $ | (25,686) |  |  | $ | (95,363) |  |  | $ | (39,487) |  |
| Depreciation & amortization | 2,272 |  |  | 1,264 |  |  | 4,087 |  |  | 2,350 |  |
| Stock-based compensation | 6,689 |  |  | 5,061 |  |  | 11,732 |  |  | 8,988 |  |
| Interest expense (income) | (1,853) |  |  | (332) |  |  | (2,152) |  |  | (258) |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | 626 |  |  | — |  |
| Change in fair value of contingent earn-out liability | 28,113 |  |  | 569 |  |  | 31,431 |  |  | (2,509) |  |
| Change in fair value of contingently issuable common stock liability | 5,095 |  |  | 24 |  |  | 5,837 |  |  | (1,448) |  |
| Change in fair value of public warrant liability | 11,751 |  |  | 143 |  |  | 13,501 |  |  | (5,443) |  |
| Restructuring expenses | — |  |  | (13) |  |  | — |  |  | 311 |  |
| Loss on impairment of lease equipment | 157 |  |  | 316 |  |  | 294 |  |  | 412 |  |
| Other one-time expenses | 683 |  |  | 2,298 |  |  | 736 |  |  | 3,405 |  |
| Adjusted EBITDA | $ | (13,847) |  |  | $ | (16,356) |  |  | $ | (29,271) |  |  | $ | (33,679) |  |

[0001628280-23-028861:8k_2_02:72]
EVOLV TECHNOLOGY

[0001628280-23-028861:8k_2_02:73]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001628280-23-028861:8k_2_02:74]
(In thousands, except share and per share data)

[0001628280-23-028861:8k_2_02:75]
(Unaudited)

[0001628280-23-028861:8k_2_02:76]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net loss | $ | (66,754) |  |  | $ | (25,686) |  |  | $ | (95,363) |  |  | $ | (39,487) |  |
| Stock-based compensation | 6,689 |  |  | 5,061 |  |  | 11,732 |  |  | 8,988 |  |
| Amortization of capitalized stock-based compensation | 11 |  |  | 6 |  |  | 21 |  |  | 9 |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | 626 |  |  | — |  |
| Change in fair value of contingent earn-out liability | 28,113 |  |  | 569 |  |  | 31,431 |  |  | (2,509) |  |
| Change in fair value of contingently issuable common stock liability | 5,095 |  |  | 24 |  |  | 5,837 |  |  | (1,448) |  |
| Change in fair value of public warrant liability | 11,751 |  |  | 143 |  |  | 13,501 |  |  | (5,443) |  |
| Restructuring expenses | — |  |  | (13) |  |  | — |  |  | 311 |  |
| Loss on impairment of lease equipment | 157 |  |  | 316 |  |  | 294 |  |  | 412 |  |
| Other one-time expenses | 683 |  |  | 2,298 |  |  | 736 |  |  | 3,405 |  |
| Adjusted Earnings (Loss) | $ | (14,255) |  |  | $ | (17,282) |  |  | $ | (31,185) |  |  | $ | (35,762) |  |
| Weighted average common shares outstanding – diluted | 148,882,160 |  |  | 143,552,032 |  |  | 147,664,534 |  |  | 143,220,268 |  |
| Adjusted Earnings (Loss) Per Share – diluted | $ | (0.10) |  |  | $ | (0.12) |  |  | $ | (0.21) |  |  | $ | (0.25) |  |
