# EVLV notes — 0001628280-23-028865


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-23-028865:notes:1]
[same as prior period, unchanged from 0001628280-23-017260:notes:1]

[0001628280-23-028865:notes:2]
[same as prior period, unchanged from 0001628280-23-017260:notes:2]

[0001628280-23-028865:notes:3]
[same as prior period, unchanged from 0001628280-23-017260:notes:3]

[0001628280-23-028865:notes:4]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001628280-23-028865:notes:5]
[same as prior period, unchanged from 0001628280-23-017260:notes:5]

[0001628280-23-028865:notes:6]
The accompanying unaudited condensed consolidated financial statements as of June 30, 2023, and for the three and six months ended June 30, 2023 and 2022 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2022 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of June 30, 2023 and the results of its operations for the three and six months ended June 30, 2023 and 2022 and cash flows for the six months ended June 30, 2023 and 2022. The results for the three and six months ended June 30, 2023 are not necessarily indicative of results to be expected for the year ending December 31, 2023, any other interim periods, or any future year or period.

[0001628280-23-028865:notes:7]
Merger
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the Merger as a wholly-owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-23-028865:notes:8]
[same as prior period, unchanged from 0001628280-23-017260:notes:11]

[0001628280-23-028865:notes:9]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2022, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended

[0001628280-23-028865:notes:10]
December 31, 2022. There have been no material changes to the Company’s significant accounting policies during the six months ended June 30, 2023.

[0001628280-23-028865:notes:11]
Recently Adopted Accounting Pronouncements

[0001628280-23-028865:notes:12]
The Company qualifies as an “emerging growth company” as defined in the Jumpstart Our Business Startups Act of 2012 and has elected not to “opt out” to the extended transition related to complying with new or revised accounting standards, which means that when a standard is issued or revised and it has different application dates for public and nonpublic companies, the Company will adopt the new or revised standard at the time nonpublic companies adopt the new or revised standard and will do so until such time that the Company either (1) irrevocably elects to “opt out” of such extended transition period or (2) no longer qualifies as an emerging growth company. The Company may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for nonpublic companies. Based on our public float as of June 30, 2023, we expect to become a large accelerated filer and lose emerging growth company status as of December 31, 2023. As of December 31, 2023, we will be required to adopt new or revised accounting standards when they are applicable to public companies that are not emerging growth companies. Based on our public float as of June 30, 2023, we also expect to transition out of smaller reporting company status as of December 31, 2023 and will no longer be able to rely on the scaled disclosure requirements allowed for smaller reporting companies.

[0001628280-23-028865:notes:13]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have a material impact on its consolidated financial statements and related disclosures.

[0001628280-23-028865:notes:14]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years, and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have an impact on its consolidated financial statements and related disclosures.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-23-028865:notes:15]
[same as prior period, unchanged from 0001628280-23-017260:notes:17]

[0001628280-23-028865:notes:16]
|  | Fair Value Measurements at June 30, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 141,612 |  |  | $ | — |  |  | $ | — |  |  | $ | 141,612 |  |
|  | $ | 141,612 |  |  | $ | — |  |  | $ | — |  |  | $ | 141,612 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 45,649 |  |  | $ | 45,649 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 9,229 |  |  | 9,229 |  |
| Public Warrant liability | 19,625 |  |  | — |  |  | — |  |  | 19,625 |  |
|  | $ | 19,625 |  |  | $ | — |  |  | $ | 54,878 |  |  | $ | 74,503 |  |

[0001628280-23-028865:notes:17]
[same as prior period, unchanged from 0001628280-23-017260:notes:19]

[0001628280-23-028865:notes:18]
[same as prior period, unchanged from 0001628280-23-017260:notes:20]

[0001628280-23-028865:notes:19]
During each of the three and six months ended June 30, 2023 and 2022, there were no transfers between Level 1, Level 2 and Level 3.

[0001628280-23-028865:notes:20]
[same as prior period, unchanged from 0001628280-23-017260:notes:22]

[0001628280-23-028865:notes:21]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2022. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of June 30, 2023, no milestones have been achieved.

[0001628280-23-028865:notes:22]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of June 30, 2023 were as follows: 85% expected stock price volatility, a risk-free rate of return of 4.6%, a 25% likelihood of change in control and a remaining term of 2.7 years.

[0001628280-23-028865:notes:23]
[same as prior period, unchanged from 0001628280-23-017260:notes:25]

[0001628280-23-028865:notes:24]
| Balance at December 31, 2022 | $ | 14,218 |  |
| Change in fair value | 31,431 |  |
| Balance at June 30, 2023 | $ | 45,649 |  |

[0001628280-23-028865:notes:25]
[same as prior period, unchanged from 0001628280-23-017260:notes:27]

[0001628280-23-028865:notes:26]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock (the "Founder Shares"). Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 517,500 Founder Shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 outstanding Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2022. The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of June 30, 2023, no milestones have been achieved.

[0001628280-23-028865:notes:27]
The fair value of the contingently issued common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of June 30, 2023 were as follows: 85% expected stock price volatility, a risk-free rate of return of 4.5%, a 25% likelihood of change in control and a remaining term of 3.1 years.

[0001628280-23-028865:notes:28]
[same as prior period, unchanged from 0001628280-23-017260:notes:30]

[0001628280-23-028865:notes:29]
| Balance at December 31, 2022 | $ | 3,392 |  |
| Change in fair value | 5,837 |  |
| Balance at June 30, 2023 | $ | 9,229 |  |

[0001628280-23-028865:notes:30]
[same as prior period, unchanged from 0001628280-23-017260:notes:32]

[0001628280-23-028865:notes:31]
In connection with the closing of the Merger, the Company assumed warrants (the "Public Warrants") to purchase 14,325,000 shares of common stock at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. As of June 30, 2023, 14,324,893 Public Warrants are outstanding.

[0001628280-23-028865:notes:32]
[same as prior period, unchanged from 0001628280-23-017260:notes:34]

[0001628280-23-028865:notes:33]
| Balance at December 31, 2022 | $ | 6,124 |  |
| Change in fair value | 13,501 |  |
| Balance at June 30, 2023 | $ | 19,625 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-23-028865:notes:34]
[same as prior period, unchanged from 0001628280-23-017260:notes:36]

[0001628280-23-028865:notes:35]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases under ASC 842 and (2) from the sale of products, inclusive of SaaS and maintenance, (3) professional services, and (4) license fees related to a distribution and license agreement with the Company's primary contract manufacturer. The Company’s arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax.

[0001628280-23-028865:notes:36]
[same as prior period, unchanged from 0001628280-23-017260:notes:38]

[0001628280-23-028865:notes:37]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of June 30, 2023.

[0001628280-23-028865:notes:38]
|  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue | $ | 3,050 |  |  | $ | — |  |  | $ | 3,050 |  |
| Subscription revenue | 42,140 |  |  | 92,099 |  |  | 134,239 |  |
| Service revenue | 17,883 |  |  | 43,124 |  |  | 61,007 |  |
| Total revenue | $ | 63,073 |  |  | $ | 135,223 |  |  | $ | 198,296 |  |

[0001628280-23-028865:notes:39]
The amount of minimum future leases is based on expected income recognition. As of June 30, 2023, future minimum payments on noncancelable leases are as follows (in thousands):

[0001628280-23-028865:notes:40]
| Year Ending December 31: |  |
| 2023 (six months remaining) | $ | 21,253 |  |
| 2024 | 41,340 |  |
| 2025 | 37,364 |  |
| 2026 | 26,748 |  |
| 2027 | 7,511 |  |
| Thereafter | 23 |  |
|  | $ | 134,239 |  |

[0001628280-23-028865:notes:41]
[same as prior period, unchanged from 0001628280-23-017260:notes:43]

[0001628280-23-028865:notes:42]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of June 30, 2023 and December 31, 2022, the Company had $4.7 million and $2.9 million in current portion of contract assets and $0.7 million and $1.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001628280-23-028865:notes:43]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $5.3 million and $12.1 million during the three and six months ended June 30, 2023 that was included in the December 31, 2022 deferred revenue balance. The Company recognized revenue of $2.2 million and $4.7 million during the three and six months ended June 30, 2022 that was included in the December 31, 2021 deferred revenue balance.

[0001628280-23-028865:notes:44]
[same as prior period, unchanged from 0001628280-23-017260:notes:46]

[0001628280-23-028865:notes:45]
| Balance at December 31, 2022 | $ | 35,968 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (12,140) |  |
| Revenue deferred | 36,253 |  |
| Balance at June 30, 2023 | $ | 60,081 |  |

[0001628280-23-028865:notes:46]
[same as prior period, unchanged from 0001628280-23-017260:notes:48]

[0001628280-23-028865:notes:47]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue from sales-type leases | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,106 |  |
| Interest income on lease receivables | 51 |  |  | 61 |  |  | 104 |  |  | 110 |  |
| Lease income - operating leases | 7,964 |  |  | 4,006 |  |  | 14,430 |  |  | 7,010 |  |
| Total lease revenue | $ | 8,015 |  |  | $ | 4,067 |  |  | $ | 14,534 |  |  | $ | 8,226 |  |

[0001628280-23-028865:notes:48]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were less than $0.1 million and $0.2 million during the three and six months ended June 30, 2023, respectively. Revenue related to leases entered into with related parties were $0.2 million and $0.3 million during the three and six months ended June 30, 2022, respectively.

[0001628280-23-028865:notes:49]
[same as prior period, unchanged from 0001628280-23-017260:notes:51]

[0001628280-23-028865:notes:50]
[same as prior period, unchanged from 0001628280-23-017260:notes:52]

[0001628280-23-028865:notes:51]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Product revenue | $ | 7,243 |  |  | $ | 4,146 |  |  | $ | 15,997 |  |  | $ | 9,340 |  |
| Leased equipment | 7,964 |  |  | 4,006 |  |  | 14,430 |  |  | 7,010 |  |
| SaaS, maintenance, and other revenue | 4,121 |  |  | 729 |  |  | 6,899 |  |  | 1,097 |  |
| Professional services | 497 |  |  | 189 |  |  | 1,080 |  |  | 333 |  |
| Total revenue | $ | 19,825 |  |  | $ | 9,070 |  |  | $ | 38,406 |  |  | $ | 17,780 |  |

[0001628280-23-028865:notes:52]
Commissions
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $10.3 million and $9.0 million as of June 30, 2023 and December 31, 2022, respectively. During the three months ended June 30, 2023 and 2022, the Company recognized commission expense of $1.5 million and $0.9 million, respectively. During the six months ended June 30, 2023 and 2022, the Company recognized commission expense of $3.1 million and $1.2 million, respectively.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001628280-23-028865:notes:53]
[same as prior period, unchanged from 0001628280-23-017260:notes:55]

[0001628280-23-028865:notes:54]
[same as prior period, unchanged from 0001628280-23-017260:notes:56]

[0001628280-23-028865:notes:55]
|  | Allowance for Doubtful Accounts |
| Balance at December 31, 2022 | $ | (200) |  |
| Provisions | (182) |  |
| Write-offs, net of recoveries | 9 |  |
| Balance at June 30, 2023 | $ | (373) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001628280-23-028865:notes:56]
[same as prior period, unchanged from 0001628280-23-017260:notes:58]

[0001628280-23-028865:notes:57]
|  | June 30,2023 |  | December 31,2022 |
| Raw materials | $ | 3,250 |  |  | $ | 2,334 |  |
| Finished goods | 1,782 |  |  | 7,923 |  |
| Total | $ | 5,032 |  |  | $ | 10,257 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-23-028865:notes:58]
[same as prior period, unchanged from 0001628280-23-017260:notes:60]

[0001628280-23-028865:notes:59]
|  | June 30,2023 |  | December 31,2022 |
| Computers and telecom equipment | $ | 1,001 |  |  | $ | 599 |  |
| Lab equipment | 951 |  |  | 871 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 542 |  |  | 542 |  |
| Leased equipment | 57,143 |  |  | 35,983 |  |
| Capitalized software | 6,002 |  |  | 4,150 |  |
| Sales demo equipment | 2,689 |  |  | 2,340 |  |
| Equipment held for lease1 | 24,183 |  |  | 7,826 |  |
| Construction in progress | 156 |  |  | 71 |  |
|  | 92,778 |  |  | 52,493 |  |
| Less: Accumulated depreciation and amortization | (11,693) |  |  | (7,786) |  |
|  | $ | 81,085 |  |  | $ | 44,707 |  |

[0001628280-23-028865:notes:60]
[same as prior period, unchanged from 0001628280-23-017260:notes:62]

[0001628280-23-028865:notes:61]
As of June 30, 2023 and December 31, 2022, the net book value of capitalized software was $4.9 million and $3.5 million, respectively. These amounts include $0.4 million and $0.2 million of capitalized stock compensation costs, respectively. Depreciation and amortization expense related to property and equipment was $2.3 million and $1.3 million for the three months ended June 30, 2023 and 2022, and $4.1 million and $2.4 million for the six months ended June 30, 2023 and 2022, respectively.

[0001628280-23-028865:notes:62]
[same as prior period, unchanged from 0001628280-23-017260:notes:64]

[0001628280-23-028865:notes:63]
|  | June 30,2023 |  | December 31,2022 |
| Leased equipment | $ | 57,143 |  |  | $ | 35,983 |  |
| Accumulated depreciation | (8,805) |  |  | (5,802) |  |
| Leased equipment, net | $ | 48,338 |  |  | $ | 30,181 |  |

[0001628280-23-028865:notes:64]
Depreciation expense related to leased units was $1.8 million and $1.0 million during the three months ended June 30, 2023 and 2022, and $3.2 million and $1.9 million for the six months ended June 30, 2023 and 2022, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.


## us-gaap:DebtDisclosureTextBlock

[0001628280-23-028865:notes:65]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001628280-23-028865:notes:66]
|  | June 30,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |

[0001628280-23-028865:notes:67]
Silicon Valley Bank Term Loan Agreement

[0001628280-23-028865:notes:68]
In December 2022, the Company entered into a loan and security agreement (the "2022 SVB Credit Agreement") with Silicon Valley Bank ("SVB") in order to finance purchases of hardware to be leased to customers. The 2022 SVB Credit Agreement provided for an initial term loan advance of $30.0 million, which was approximately equivalent to the value of all hardware purchases made to support leasing transactions with the Company's customers through December 21, 2022 (the "SVB Closing Date"), with the opportunity to obtain, within 18 months after the SVB Closing Date, additional term loan advances, subject to the satisfaction of certain conditions, in an aggregate principal amount equal to $20.0 million (subject to an increase of an additional $25.0 million upon the satisfaction of certain conditions and approval from SVB). The interest rate applicable to the SVB Term Loans was the greater of (a) the Wall Street Journal Prime Rate plus 1.0% or (b) 7.25% per annum. Interest and principal under the SVB Credit Agreement was payable monthly.

[0001628280-23-028865:notes:69]
On March 10, 2023, SVB was closed by the California Department of Financial Protection and Innovation, which appointed the Federal Deposit Corporation ("FDIC") as receiver. The FDIC created a successor bridge bank, Silicon Valley Bridge Bank, N.A. ("SVBB"), and all deposits of SVB were transferred to SVBB under a systemic risk exception approved by the Federal Reserve, the U.S. Treasury Department, and the FDIC. On March 12, 2023, the Federal Reserve, the U.S. Treasury Department, and the FDIC announced in a joint statement that all SVB deposits, including both insured and uninsured amounts, would be available in full to account holders. SVB was acquired by First Citizens Bank on March 27, 2023.

[0001628280-23-028865:notes:70]
In light of the foregoing, on March 28, 2023, upon the recommendation of the Company’s newly-formed Investment Committee of the Board of Directors, the Company (i) gave notice of its desire and intent to terminate the commitments under the 2022 SVB Credit Agreement and (ii) transferred its excess cash out of First Citizens Bank (the “Transfer”). The Transfer resulted in an event of default under the 2022 SVB Credit Agreement. Upon the occurrence of such event of default, First Citizens Bank could have, but was not required to, declare all obligations under the 2022 SVB 
Credit Agreement immediately due and payable. First Citizens Bank did not make such declaration following such event of default. On March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-23-028865:notes:71]
[same as prior period, unchanged from 0001628280-23-017260:notes:73]

[0001628280-23-028865:notes:72]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the six months ended June 30, 2023 and 2022:

[0001628280-23-028865:notes:73]
|  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |
| Risk-free interest rate | 4.2 | % |  | 1.6 | % |
| Expected term (in years) | 6.1 |  | 6.1 |
| Expected volatility | 87.5 | % |  | 75.0 | % |
| Expected dividend yield | 0.0 | % |  | 0.0 | % |

[0001628280-23-028865:notes:74]
[same as prior period, unchanged from 0001628280-23-017260:notes:76]

[0001628280-23-028865:notes:75]
|  | Number ofShares |  | WeightedAverageExercise Price |
| Outstanding as of December 31, 2022 | 20,396,824 |  | $ | 0.73 |  |
| Granted | 2,840,421 |  | 3.12 |  |
| Exercised | (875,780) |  | 0.39 |  |
| Forfeited | (20,468) |  |  | 0.42 |  |
| Outstanding as of June 30, 2023 | 22,340,997 |  | 1.05 |  |

[0001628280-23-028865:notes:76]
[same as prior period, unchanged from 0001628280-23-017260:notes:78]

[0001628280-23-028865:notes:77]
[same as prior period, unchanged from 0001628280-23-017260:notes:79]

[0001628280-23-028865:notes:78]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2022 | 7,501,945 |  |  | $ | 3.54 |  |
| Granted | 7,742,983 |  |  | 3.25 |  |
| Vested | (2,447,672) |  |  | 3.40 |  |
| Forfeited | (345,516) |  |  | 3.75 |  |
| Outstanding as of June 30, 2023 | 12,451,740 |  |  | $ | 3.38 |  |

[0001628280-23-028865:notes:79]
[same as prior period, unchanged from 0001628280-23-017260:notes:81]

[0001628280-23-028865:notes:80]
[same as prior period, unchanged from 0001628280-23-017260:notes:82]

[0001628280-23-028865:notes:81]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2022 | 864,000 |  |  | $ | 2.65 |  |
| Granted | — |  |  | — |  |
| Vested | (432,000) |  |  | 2.65 |  |
| Forfeited | (25,000) |  |  | 2.65 |  |
| Outstanding as of June 30, 2023 | 407,000 |  |  | $ | 2.65 |  |

[0001628280-23-028865:notes:82]
[same as prior period, unchanged from 0001628280-23-017260:notes:84]

[0001628280-23-028865:notes:83]
In January 2021, the Company granted warrants (the "Finback Common Stock Warrants") to purchase 2,552,913 shares of the Company's Class A common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC ("Finback"), a consulting group affiliated with one of the Company's stockholders. The Finback Common Stock Warrants vest upon meeting certain sales criteria as defined in a business development agreement (the "Finback BDA"), which has a term of 3 years. The Finback BDA expired on January 1, 2023 but includes a 1-year "tail period" expiring on January 1, 2024. During the tail period, Finback Common Stock Warrants will continue to vest related to any sale consummated by the Company for which it is determined Finback provided services prior to January 1, 2023 in furtherance of the sale. The Finback Common Stock Warrants expire in January 2031. The Finback Common Stock Warrants are accounted for under ASC 718 Compensation – Stock Compensation as the warrants vest upon certain performance conditions being met.

[0001628280-23-028865:notes:84]
During the six months ended June 30, 2023, 830,216 Finback Common Stock Warrants were exercised. As of June 30, 2023, 175,599 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $1.0 million, and 1,415,385 Finback Common Stock Warrants are unvested and have a total unrecognized grant date fair value of $10.8 million. During the three months ended June 30, 2023 and 2022, the Company recorded $0.8 million and $0.6 million, respectively, of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants. During the six months ended June 30, 2023 and 2022, the Company recorded $1.4 million and $0.8 million, respectively, of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants.

[0001628280-23-028865:notes:85]
[same as prior period, unchanged from 0001628280-23-017260:notes:87]

[0001628280-23-028865:notes:86]
[same as prior period, unchanged from 0001628280-23-017260:notes:88]

[0001628280-23-028865:notes:87]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of revenue | $ | 184 |  | $ | 280 |  | $ | 329 |  | $ | 388 |
| Research and development | 1,238 |  | 931 |  | 2,075 |  | 1,479 |
| Sales and marketing | 2,508 |  | 2,344 |  | 4,506 |  | 3,828 |
| General and administrative | 2,759 |  | 1,506 |  | 4,822 |  | 3,293 |
| Total stock-based compensation expense | $ | 6,689 |  | $ | 5,061 |  | $ | 11,732 |  | $ | 8,988 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-23-028865:notes:88]
Income Taxes
There is no provision for income taxes for the three and six months ended June 30, 2023 and 2022 because the Company has historically incurred net operating losses and maintains a full valuation allowance against its deferred tax assets.

[0001628280-23-028865:notes:89]
The Company’s tax provision and the resulting effective tax rate for interim periods is determined based upon its estimated annual effective tax rate (“AETR”), adjusted for the effect of discrete items arising in that quarter. The impact of such inclusions could result in a higher or lower effective tax rate during a particular quarter, based upon the mix and timing of actual earnings or losses versus annual projections. In each quarter, the Company updates its estimate of the annual effective tax rate, and if the estimated annual tax rate changes, a cumulative adjustment is made in that quarter.


## us-gaap:EarningsPerShareTextBlock

[0001628280-23-028865:notes:90]
[same as prior period, unchanged from 0001628280-23-017260:notes:91]

[0001628280-23-028865:notes:91]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) attributable to common stockholders – basic and diluted | $ | (66,754) |  | $ | (25,686) | $ | — |  | $ | (95,363) |  | $ | (39,487) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 148,882,160 |  |  | 143,552,032 |  |  | 147,664,534 |  |  | 143,220,268 |  |
| Net loss per share attributable to common stockholders – basic and diluted | $ | (0.45) |  |  | $ | (0.18) |  |  | $ | (0.65) |  |  | $ | (0.28) |  |

[0001628280-23-028865:notes:92]
[same as prior period, unchanged from 0001628280-23-017260:notes:93]

[0001628280-23-028865:notes:93]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Options issued and outstanding | 22,340,997 |  | 21,567,577 |  |  | 22,340,997 |  | 21,567,577 |  |
| Public Warrants to purchase common stock | 14,324,893 |  |  | 14,324,994 |  |  | 14,324,893 |  |  | 14,324,994 |  |
| Warrants to purchase common stock (Finback)** | 1,590,984 |  |  | 2,421,200 |  |  | 1,590,984 |  |  | 2,421,200 |  |
| Unvested restricted stock units | 12,451,740 |  |  | 7,446,143 |  |  | 12,451,740 |  |  | 7,446,143 |  |
| Unvested performance stock units | 407,000 |  |  | 914,000 |  |  | 407,000 |  |  | 914,000 |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |
| Contingently issuable common stock* | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |
|  | 68,013,114 |  |  | 63,571,414 |  |  | 68,013,114 |  |  | 63,571,414 |  |

[0001628280-23-028865:notes:94]
*Issuance of Earn-out shares and Contingently issuable common stock is contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period
**Includes 175,599 vested warrants and 1,415,385 unvested warrants as of June 30, 2023


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-23-028865:notes:95]
Related Party Transactions
Business Development Agreement with Finback

[0001628280-23-028865:notes:96]
In January 2021, the Company granted the Finback Common Stock Warrants subject to the terms of the Finback BDA, as discussed in Note 9.

[0001628280-23-028865:notes:97]
In connection with the Merger and pursuant to the Merger Agreement, in addition to earn-out shares allocated to Finback based on its common stock ownership percentage as of the Merger date, Finback is entitled to receive a proportional share of earn-out shares based upon its remaining unvested warrants as of the Merger Date.

[0001628280-23-028865:notes:98]
Original Equipment Manufacturer Partnership Agreement with Motorola

[0001628280-23-028865:notes:99]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended June 30, 2023 and 2022, revenue from Motorola's distributor services was $2.9 million and $1.9 million, respectively. During the six months ended June 30, 2023 and 2022, revenue from Motorola's distributor services was $6.2 million and $2.8 million, respectively. As of June 30, 2023 and December 31, 2022, accounts receivable related to Motorola’s distributor services was $3.0 million and $12.5 million, respectively.

[0001628280-23-028865:notes:100]
Reseller Agreement with Stanley Black & Decker

[0001628280-23-028865:notes:101]
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB ("Securitas") in 2023. Securitas, directly or through its affiliates, resells the Company's products. During the three months ended June 30, 2023 and 2022, revenue from Securitas' reseller services was $0.5 million and $0.3 million, respectively. During the six months ended June 30, 2023 and 2022, revenue from Securitas' reseller services was $0.9 million and $0.3 million, respectively. As of June 30, 2023 and December 31, 2022, accounts receivable related to Securitas' reseller services was $0.9 million and $2.2 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-23-028865:notes:102]
Commitments and Contingencies
Indemnification Agreements

[0001628280-23-028865:notes:103]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of June 30, 2023 or December 31, 2022.

[0001628280-23-028865:notes:104]
Legal Proceedings and Other Matters

[0001628280-23-028865:notes:105]
The Company is not a party to any litigation of a material nature and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.
In the ordinary course of business, the Company is subject to regulatory and governmental examinations, information gathering requests, inquiries and investigations. We do not expect such examinations, requests, inquiries or investigations to have a material effect on our results of operations, financial condition or liquidity, either individually or in the aggregate.
