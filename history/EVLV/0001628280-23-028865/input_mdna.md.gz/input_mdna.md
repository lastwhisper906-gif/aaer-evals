# EVLV MD&A — 0001628280-23-028865


## mdna

[0001628280-23-028865:mdna:1]
[same as prior period, unchanged from 0001628280-23-017260:mdna:1]

[0001628280-23-028865:mdna:2]
[same as prior period, unchanged from 0001628280-23-017260:mdna:3]

[0001628280-23-028865:mdna:3]
[same as prior period, unchanged from 0001628280-23-017260:mdna:4]

[0001628280-23-028865:mdna:4]
[same as prior period, unchanged from 0001628280-23-017260:mdna:5]

[0001628280-23-028865:mdna:5]
[same as prior period, unchanged from 0001628280-23-017260:mdna:6]

[0001628280-23-028865:mdna:6]
Our products have screened over 750 million visitors worldwide since our inception. We believe that we have screened more people through advanced systems than any organization other than the United States Transportation Security Administration (“TSA”). Our customers include many iconic venues across a wide variety of industries, including major sports stadiums and arenas, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, hospitals, large industrial workplaces, schools, and prominent houses of worship. We offer our products for lease or purchase and utilize a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue, and creates expansion and upsell opportunities.

[0001628280-23-028865:mdna:7]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $19.8 million and $9.1 million for the three months ended June 30, 2023 and 2022, respectively. We generated a net loss of $66.8 million and $25.7 million for the three months ended June 30, 2023 and 2022, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-23-028865:mdna:8]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations, and if necessary, debt financings. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable

[0001628280-23-028865:mdna:9]
terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources.”

[0001628280-23-028865:mdna:10]
[same as prior period, unchanged from 0001628280-23-017260:mdna:10]

[0001628280-23-028865:mdna:11]
[same as prior period, unchanged from 0001628280-23-017260:mdna:11]

[0001628280-23-028865:mdna:12]
[same as prior period, unchanged from 0001628280-23-017260:mdna:12]

[0001628280-23-028865:mdna:13]
We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of rising inflation and interest rates on business spending; supply chain issues and the impacts on our manufacturing capabilities; public health emergencies; the ongoing Russian invasion of Ukraine and related geopolitical impacts; and a possible prolonged economic recession. While these factors continue to evolve, we plan to remain flexible and to optimize our business as appropriate and allocate resources, as necessary.

[0001628280-23-028865:mdna:14]
[same as prior period, unchanged from 0001628280-23-017260:mdna:14]

[0001628280-23-028865:mdna:15]
We believe the world will continue to focus on the safety and security of people in the places where they gather. Many of these locations, such as professional sports venues, educational institutions, and healthcare facilities, are moving toward a more frictionless security screening experience. We believe that we are well-positioned to take advantage of this opportunity due to our proprietary technologies and distribution capabilities. Our products are designed to empower venues and facilities to realize the full benefits of touchless security screening, including faster visitor throughput, reduced security staff requirements, and a less invasive screening experience for visitors. We expect that our results of operations, including revenue, will fluctuate for the foreseeable future as venues and facilities continue to shift away from conventional security screening processes towards touchless security screening or consider security screening processes for the first time. The degree to which potential and current customers recognize these benefits and invest in our products will affect our financial results.

[0001628280-23-028865:mdna:16]
[same as prior period, unchanged from 0001628280-23-017260:mdna:16]

[0001628280-23-028865:mdna:17]
Revenue generated by the sale of products represented 37% and 46% of our total revenue for the three months ended June 30, 2023 and 2022, respectively. The remaining revenue was generated from subscription sales and services for our products, and an immaterial amount from license fees, as discussed below. Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions, primarily within the United States.

[0001628280-23-028865:mdna:18]
We continue to transition our go-to-market strategy to focus on our "pure subscription" sales model, where the customer leases our hardware, as opposed to purchasing the hardware outright, and enters into a multi-year security-as-a-service subscription. Accordingly, we expect subscription revenue as a percentage of total revenue to increase in future periods. We believe that the pure subscription model aligns more closely with the SaaS nature of our business and results in a more predictable and consistent recurring revenue stream as compared to the purchase subscription model. As part of this overall strategy, we entered into a distribution and license agreement in March 2023 (the "Distribution and License Agreement") with Columbia Electrical Contractors, Inc. ("Columbia Tech"), which currently serves as our primary contract manufacturer. Under this arrangement, we have granted a limited, non-exclusive license under our intellectual property rights to Columbia Tech, and Columbia Tech manufactures hardware systems and contracts directly with certain of our resellers to fulfill sales demand where the end-user customer requires the contract to be in form of a hardware purchase. Columbia Tech pays us a hardware license fee for each system sold under this agreement. In these instances, we still contract directly with the reseller to provide a multi-year security-as-a-service subscription to the end-users.

[0001628280-23-028865:mdna:19]
[same as prior period, unchanged from 0001628280-23-017260:mdna:19]

[0001628280-23-028865:mdna:20]
[same as prior period, unchanged from 0001628280-23-017260:mdna:20]

[0001628280-23-028865:mdna:21]
[same as prior period, unchanged from 0001628280-23-017260:mdna:21]

[0001628280-23-028865:mdna:22]
[same as prior period, unchanged from 0001628280-23-017260:mdna:22]

[0001628280-23-028865:mdna:23]
[same as prior period, unchanged from 0001628280-23-017260:mdna:23]

[0001628280-23-028865:mdna:24]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, (2) the sale of products, inclusive of SaaS and maintenance, (3) professional services, and (4) license fees related to the Distribution and License Agreement. Our arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax.

[0001628280-23-028865:mdna:25]
[same as prior period, unchanged from 0001628280-23-017260:mdna:25]

[0001628280-23-028865:mdna:26]
We derive a portion of our revenue from the sale of our Evolv Express equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We expect product revenue to decline as a percentage of our overall revenue over time as more customers enter full subscription transactions with us and as our subscription becomes more valuable to our business.

[0001628280-23-028865:mdna:27]
[same as prior period, unchanged from 0001628280-23-017260:mdna:27]

[0001628280-23-028865:mdna:28]
[same as prior period, unchanged from 0001628280-23-017260:mdna:28]

[0001628280-23-028865:mdna:29]
[same as prior period, unchanged from 0001628280-23-017260:mdna:29]

[0001628280-23-028865:mdna:30]
[same as prior period, unchanged from 0001628280-23-017260:mdna:30]

[0001628280-23-028865:mdna:31]
Services revenue includes subscription-based SaaS and maintenance revenue related to products sold to customers, installation and training services, and license fees related to the Distribution and License Agreement. Maintenance consists of technical support, bug fixes, and when-and-if available threat updates. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically four years. Revenue for installation and training are recognized upon transfer of control of these services, which are normally rendered over a short duration. License fee revenue is recognized upon the shipment of product from Columbia Tech to the reseller.

[0001628280-23-028865:mdna:32]
[same as prior period, unchanged from 0001628280-23-017260:mdna:32]

[0001628280-23-028865:mdna:33]
[same as prior period, unchanged from 0001628280-23-017260:mdna:33]

[0001628280-23-028865:mdna:34]
[same as prior period, unchanged from 0001628280-23-017260:mdna:34]

[0001628280-23-028865:mdna:35]
Cost of product revenue consists primarily of costs paid to third party manufacturers and other suppliers and shipping costs.

[0001628280-23-028865:mdna:36]
[same as prior period, unchanged from 0001628280-23-017260:mdna:36]

[0001628280-23-028865:mdna:37]
Cost of subscription revenue consists primarily of depreciation expense related to leased units, an allocated portion of internal-use software amortization expense, shipping costs, and maintenance costs related to leased units. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001628280-23-028865:mdna:38]
[same as prior period, unchanged from 0001628280-23-017260:mdna:38]

[0001628280-23-028865:mdna:39]
Cost of services revenue consists of costs related to installation and training services, an allocated portion of internal-use software amortization expense, and maintenance costs related to units purchased by customers. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001628280-23-028865:mdna:40]
[same as prior period, unchanged from 0001628280-23-017260:mdna:40]

[0001628280-23-028865:mdna:41]
[same as prior period, unchanged from 0001628280-23-017260:mdna:41]

[0001628280-23-028865:mdna:42]
[same as prior period, unchanged from 0001628280-23-017260:mdna:42]

[0001628280-23-028865:mdna:43]
[same as prior period, unchanged from 0001628280-23-017260:mdna:43]

[0001628280-23-028865:mdna:44]
[same as prior period, unchanged from 0001628280-23-017260:mdna:44]

[0001628280-23-028865:mdna:45]
[same as prior period, unchanged from 0001628280-23-017260:mdna:45]

[0001628280-23-028865:mdna:46]
[same as prior period, unchanged from 0001628280-23-017260:mdna:46]

[0001628280-23-028865:mdna:47]
[same as prior period, unchanged from 0001628280-23-017260:mdna:47]

[0001628280-23-028865:mdna:48]
[same as prior period, unchanged from 0001628280-23-017260:mdna:48]

[0001628280-23-028865:mdna:49]
[same as prior period, unchanged from 0001628280-23-017260:mdna:49]

[0001628280-23-028865:mdna:50]
[same as prior period, unchanged from 0001628280-23-017260:mdna:50]

[0001628280-23-028865:mdna:51]
[same as prior period, unchanged from 0001628280-23-017260:mdna:51]

[0001628280-23-028865:mdna:52]
[same as prior period, unchanged from 0001628280-23-017260:mdna:52]

[0001628280-23-028865:mdna:53]
[same as prior period, unchanged from 0001628280-23-017260:mdna:54]

[0001628280-23-028865:mdna:54]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and sales tax contingencies. We expect our general and administrative expenses will remain relatively consistent for the year ending December 31, 2023 compared to the year ended December 31, 2022 as we look to leverage previous investments made in people and processes.

[0001628280-23-028865:mdna:55]
[same as prior period, unchanged from 0001628280-23-017260:mdna:56]

[0001628280-23-028865:mdna:56]
[same as prior period, unchanged from 0001628280-23-017260:mdna:57]

[0001628280-23-028865:mdna:57]
[same as prior period, unchanged from 0001628280-23-017260:mdna:58]

[0001628280-23-028865:mdna:58]
[same as prior period, unchanged from 0001628280-23-017260:mdna:59]

[0001628280-23-028865:mdna:59]
[same as prior period, unchanged from 0001628280-23-017260:mdna:60]

[0001628280-23-028865:mdna:60]
[same as prior period, unchanged from 0001628280-23-017260:mdna:61]

[0001628280-23-028865:mdna:61]
[same as prior period, unchanged from 0001628280-23-017260:mdna:62]

[0001628280-23-028865:mdna:62]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial stockholders are entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv stockholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss.

[0001628280-23-028865:mdna:63]
[same as prior period, unchanged from 0001628280-23-017260:mdna:64]

[0001628280-23-028865:mdna:64]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock (the "Founder Shares"). Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 1,897,500 Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones, and 517,500 Founder Shares were contributed to Give Evolv LLC. The 1,897,500 outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss.

[0001628280-23-028865:mdna:65]
[same as prior period, unchanged from 0001628280-23-017260:mdna:66]

[0001628280-23-028865:mdna:66]
In connection with the closing of the Merger, the Company assumed a warrant to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger with the offset to additional paid-in capital.

[0001628280-23-028865:mdna:67]
[same as prior period, unchanged from 0001628280-23-017260:mdna:68]

[0001628280-23-028865:mdna:68]
Our income tax provision consists of an estimate for U.S. federal and state income taxes based on enacted rates, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. There is no provision for income taxes for the three and six months ended June 30, 2023 and 2022 because we have historically incurred net operating losses and maintain a full valuation allowance against its deferred tax assets.

[0001628280-23-028865:mdna:69]
[same as prior period, unchanged from 0001628280-23-017260:mdna:70]

[0001628280-23-028865:mdna:70]
Comparison of the Three Months Ended June 30, 2023 and 2022

[0001628280-23-028865:mdna:71]
The following table summarizes our results of operations for the three months ended June 30, 2023 and 2022 (in thousands):

[0001628280-23-028865:mdna:72]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 7,243 |  |  | $ | 4,146 |  |  | $ | 3,097 |  |  | 75 | % |
| Subscription revenue | 7,964 |  |  | 4,006 |  |  | 3,958 |  |  | 99 |  |
| Service revenue | 4,618 |  |  | 918 |  |  | 3,700 |  |  | 403 |  |
| Total revenue | 19,825 |  |  | 9,070 |  |  | 10,755 |  |  | 119 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 7,722 |  |  | 5,347 |  |  | 2,375 |  |  | 44 |  |
| Cost of subscription revenue | 3,406 |  |  | 1,981 |  |  | 1,425 |  |  | 72 |  |
| Cost of service revenue | 1,284 |  |  | 1,189 |  |  | 95 |  |  | 8 |  |
| Total cost of revenue | 12,412 |  |  | 8,517 |  |  | 3,895 |  |  | 46 |  |
| Gross profit | 7,413 |  |  | 553 |  |  | 6,860 |  |  | 1,241 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 6,395 |  |  | 4,156 |  |  | 2,239 |  |  | 54 |  |
| Sales and marketing | 13,613 |  |  | 11,751 |  |  | 1,862 |  |  | 16 |  |
| General and administrative | 10,874 |  |  | 9,612 |  |  | 1,262 |  |  | 13 |  |
| Loss from impairment of property and equipment | 157 |  |  | 316 |  |  | (159) |  |  | (50) |  |
| Total operating expenses | 31,039 |  |  | 25,835 |  |  | 5,204 |  |  | 20 |  |
| Loss from operations | (23,626) |  |  | (25,282) |  |  | 1,656 |  |  | 7 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (159) |  |  | 159 |  |  | 100 |  |
| Interest income | 1,853 |  |  | 491 |  |  | 1,362 |  |  | 277 |  |
| Other expense, net | (22) |  |  | — |  |  | (22) |  |  | * |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | * |
| Change in fair value of contingent earn-out liability | (28,113) |  |  | (569) |  |  | (27,544) |  |  | (4,841) |  |
| Change in fair value of contingently issuable common stock liability | (5,095) |  |  | (24) |  |  | (5,071) |  |  | (21,129) |  |
| Change in fair value of public warrant liability | (11,751) |  |  | (143) |  |  | (11,608) |  |  | (8,117) |  |
| Total other income (expense), net | (43,128) |  |  | (404) |  |  | (42,724) |  |  | (10,575) |  |
| Net loss attributable to common stockholders – basic and diluted | $ | (66,754) |  |  | $ | (25,686) |  |  | $ | (41,068) |  |  | (160) | % |

[0001628280-23-028865:mdna:73]
* Not meaningful

[0001628280-23-028865:mdna:74]
[same as prior period, unchanged from 0001628280-23-017260:mdna:75]

[0001628280-23-028865:mdna:75]
[same as prior period, unchanged from 0001628280-23-017260:mdna:76]

[0001628280-23-028865:mdna:76]
[same as prior period, unchanged from 0001628280-23-017260:mdna:77]

[0001628280-23-028865:mdna:77]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Product revenue | $ | 7,243 |  |  | $ | 4,146 |  |  | $ | 3,097 |  |  | 75 | % |
| Cost of product revenue | $ | 7,722 |  |  | $ | 5,347 |  |  | $ | 2,375 |  |  | 44 | % |
| Gross profit - Product revenue | $ | (479) |  |  | $ | (1,201) |  |  | $ | 722 |  |  | 60 | % |
| Gross profit margin - Product revenue | (7) | % |  | (29) | % |  | N/A |  | 22 | % |

[0001628280-23-028865:mdna:78]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which reflect an ongoing increase in the adoption of Evolv Express units by schools and healthcare facilities.

[0001628280-23-028865:mdna:79]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our product sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition of 74 new customers during the three months ended June 30, 2023 compared to 53 new customers during the three months ended June 30, 2022, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-23-028865:mdna:80]
The increase in product gross profit and product gross profit margin during the three months ended June 30, 2023 compared to the prior year period is attributable primarily to higher average revenue per unit sold. These increases were tempered by (i) a continued strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets (single lane configurations typically generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price), and (ii) a higher percentage of sales made through our channel partners, which are generally at a lower average sale price. We expect to continue to see improvement in our gross profit margin as we continue to engineer our product with lower cost components.

[0001628280-23-028865:mdna:81]
[same as prior period, unchanged from 0001628280-23-017260:mdna:82]

[0001628280-23-028865:mdna:82]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Subscription revenue | $ | 7,964 |  |  | $ | 4,006 |  |  | $ | 3,958 |  |  | 99 | % |
| Cost of subscription revenue | $ | 3,406 |  |  | $ | 1,981 |  |  | $ | 1,425 |  |  | 72 | % |
| Gross profit - Subscription revenue | $ | 4,558 |  |  | $ | 2,025 |  |  | $ | 2,533 |  |  | 125 | % |
| Gross profit margin - Subscription revenue | 57 | % |  | 51 | % |  | N/A |  | 7 | % |

[0001628280-23-028865:mdna:83]
[same as prior period, unchanged from 0001628280-23-017260:mdna:84]

[0001628280-23-028865:mdna:84]
7

[0001628280-23-028865:mdna:85]
[same as prior period, unchanged from 0001628280-23-017260:mdna:85]

[0001628280-23-028865:mdna:86]
[same as prior period, unchanged from 0001628280-23-017260:mdna:86]

[0001628280-23-028865:mdna:87]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Service revenue | $ | 4,618 |  |  | $ | 918 |  |  | $ | 3,700 |  |  | 403 | % |
| Cost of service revenue | $ | 1,284 |  |  | $ | 1,189 |  |  | $ | 95 |  |  | 8 | % |
| Gross profit - Service revenue | $ | 3,334 |  |  | $ | (271) |  |  | $ | 3,605 |  |  | 1,330 | % |
| Gross profit margin - Service revenue | 72 | % |  | (30) | % |  | N/A |  | 102 | % |

[0001628280-23-028865:mdna:88]
[same as prior period, unchanged from 0001628280-23-017260:mdna:88]

[0001628280-23-028865:mdna:89]
[same as prior period, unchanged from 0001628280-23-017260:mdna:89]

[0001628280-23-028865:mdna:90]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 4,313 |  |  | $ | 3,596 |  |  | $ | 717 |  |  | 20 | % |
| Materials and prototypes | 839 |  |  | (109) |  |  | 948 |  |  | 870 | % |
| Professional fees | 926 |  |  | 423 |  |  | 503 |  |  | 119 | % |
| Other | 317 |  |  | 246 |  |  | 71 |  |  | 29 | % |
|  | $ | 6,395 |  |  | $ | 4,156 |  |  | $ | 2,239 |  |  | 54 | % |

[0001628280-23-028865:mdna:91]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation primarily resulting from new hires in our research and development function during the past twelve months, offset by a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased. Stock-based compensation expense included in research and development expenses was $1.2 million for the three months ended June 30, 2023 compared to $0.9 million for the three months ended June 30, 2022. The increase in materials and prototypes expense is due to increased design and engineering costs related to the development of the next generation of our Evolv Express system. The increase in professional fees primarily relates to consulting costs incurred for product development and engineering.

[0001628280-23-028865:mdna:92]
[same as prior period, unchanged from 0001628280-23-017260:mdna:92]

[0001628280-23-028865:mdna:93]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 10,258 |  |  | $ | 7,583 |  |  | $ | 2,675 |  |  | 35 | % |
| Advertising and direct marketing | 612 |  |  | 1,045 |  |  | (433) |  |  | (41) | % |
| Travel and entertainment | 1,252 |  |  | 852 |  |  | 400 |  |  | 47 | % |
| Professional fees | 569 |  |  | 280 |  |  | 289 |  |  | 103 | % |
| Other | 922 |  |  | 1,991 |  |  | (1,069) |  |  | (54) | % |
|  | $ | 13,613 |  |  | $ | 11,751 |  |  | $ | 1,862 |  |  | 16 | % |

[0001628280-23-028865:mdna:94]
The increase in personnel related expenses is due to an increase in payroll costs, commissions and stock-based compensation resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increase sales volume. Stock compensation expense included in sales and marketing expenses was $2.5 million for the three months ended June 30, 2023 compared to $2.3 million for the three months ended June 30, 2022. The decrease in advertising and direct marketing expense is primarily due to a decrease in expense related to trade shows and events. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings and

[0001628280-23-028865:mdna:95]
8

[0001628280-23-028865:mdna:96]
events. Professional fees increased due primarily to an increase in marketing consulting costs. Other expense decreased due primarily to $1.0 million of certain one-time expenses incurred during the three months ended June 30, 2022.

[0001628280-23-028865:mdna:97]
[same as prior period, unchanged from 0001628280-23-017260:mdna:95]

[0001628280-23-028865:mdna:98]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 6,113 |  |  | $ | 4,019 |  |  | $ | 2,094 |  |  | 52 | % |
| Professional fees | 1,504 |  |  | 2,042 |  |  | (538) |  |  | (26) | % |
| Director and officer insurance | 1,093 |  |  | 1,380 |  |  | (287) |  |  | (21) | % |
| Other | 2,164 |  |  | 2,171 |  |  | (7) |  |  | — | % |
|  | $ | 10,874 |  |  | $ | 9,612 |  |  | $ | 1,262 |  |  | 13 | % |

[0001628280-23-028865:mdna:99]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $2.8 million for the three months ended June 30, 2023 compared to $1.5 million for the three months ended June 30, 2022. The decrease in professional fees is primarily related to a decrease in outsourced accounting consultancy fees. The decrease in insurance expense is primarily related to a decrease in director and officer insurance premiums. Other expense decreased primarily due to $1.2 million of certain one-time expenses incurred during the three months ended June 30, 2022, offset by increases in software subscriptions, non-income taxes, and other miscellaneous expenses.

[0001628280-23-028865:mdna:100]
[same as prior period, unchanged from 0001628280-23-017260:mdna:98]

[0001628280-23-028865:mdna:101]
Loss from impairment of property and equipment was an immaterial $0.2 million and $0.3 million for the three months ended June 30, 2023 and 2022, respectively.

[0001628280-23-028865:mdna:102]
[same as prior period, unchanged from 0001628280-23-017260:mdna:100]

[0001628280-23-028865:mdna:103]
Interest expense was $0 for the three months ended June 30, 2023, compared to $0.2 million for the three months ended June 30, 2022. During March 2023, the Company fully repaid all borrowings and accrued interest under its term loans with Silicon Valley Bank ("SVB") pursuant to a loan and security agreement entered into in December 2022 (the "2022 SVB Credit Agreement").

[0001628280-23-028865:mdna:104]
[same as prior period, unchanged from 0001628280-23-017260:mdna:102]

[0001628280-23-028865:mdna:105]
Interest income of $1.9 million for the three months ended June 30, 2023 and $0.5 million for the three months ended June 30, 2022 related primarily to interest earned on money market funds.

[0001628280-23-028865:mdna:106]
[same as prior period, unchanged from 0001628280-23-017260:mdna:104]

[0001628280-23-028865:mdna:107]
Change in the fair value of the contingent earn-out liability resulted in losses of $28.1 million and $0.6 million for the three months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-23-028865:mdna:108]
[same as prior period, unchanged from 0001628280-23-017260:mdna:106]

[0001628280-23-028865:mdna:109]
Change in the fair value of the contingently issuable common stock liability resulted in losses of $5.1 million and less than $0.1 million for the three months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-23-028865:mdna:110]
[same as prior period, unchanged from 0001628280-23-017260:mdna:108]

[0001628280-23-028865:mdna:111]
Change in the fair value of the public warrant liability resulted in losses of $11.8 million and $0.1 million for the three months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-23-028865:mdna:112]
Comparison of the Six Months Ended June 30, 2023 and 2022

[0001628280-23-028865:mdna:113]
The following table summarizes our results of operations for the six months ended June 30, 2023 and 2022, (in thousands):

[0001628280-23-028865:mdna:114]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 15,997 |  |  | $ | 9,340 |  |  | $ | 6,657 |  |  | 71 | % |
| Subscription revenue | 14,430 |  |  | 7,010 |  |  | 7,420 |  |  | 106 |  |
| Service revenue | 7,979 |  |  | 1,430 |  |  | 6,549 |  |  | 458 |  |
| Total revenue | 38,406 |  |  | 17,780 |  |  | 20,626 |  |  | 116 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 18,300 |  |  | 10,553 |  |  | 7,747 |  |  | 73 |  |
| Cost of subscription revenue | 5,757 |  |  | 3,523 |  |  | 2,234 |  |  | 63 |  |
| Cost of service revenue | 2,171 |  |  | 2,254 |  |  | (83) |  |  | (4) |  |
| Total cost of revenue | 26,228 |  |  | 16,330 |  |  | 9,898 |  |  | 61 |  |
| Gross profit | 12,178 |  |  | 1,450 |  |  | 10,728 |  |  | 740 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 11,784 |  |  | 8,331 |  |  | 3,453 |  |  | 41 |  |
| Sales and marketing | 26,417 |  |  | 21,423 |  |  | 4,994 |  |  | 23 |  |
| General and administrative | 19,800 |  |  | 20,429 |  |  | (629) |  |  | (3) |  |
| Loss from impairment of property and equipment | 294 |  |  | 412 |  |  | (118) |  |  | (29) |  |
| Total operating expenses | 58,295 |  |  | 50,595 |  |  | 7,700 |  |  | 15 |  |
| Loss from operations | (46,117) |  |  | (49,145) |  |  | 3,028 |  |  | 6 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (654) |  |  | (301) |  |  | (353) |  |  | (117) |  |
| Interest income | 2,806 |  |  | 559 |  |  | 2,247 |  |  | 402 |  |
| Other expense, net | (3) |  |  | — |  |  | (3) |  |  | * |
| Loss on extinguishment of debt | (626) |  |  | — |  |  | (626) |  |  | * |
| Change in fair value of contingent earn-out liability | (31,431) |  |  | 2,509 |  |  | (33,940) |  |  | (1,353) |  |
| Change in fair value of contingently issuable common stock liability | (5,837) |  |  | 1,448 |  |  | (7,285) |  |  | (503) |  |
| Change in fair value of public warrant liability | (13,501) |  |  | 5,443 |  |  | (18,944) |  |  | (348) |  |
| Total other income (expense), net | (49,246) |  |  | 9,658 |  |  | (58,904) |  |  | (610) |  |
| Net loss | $ | (95,363) |  |  | $ | (39,487) |  |  | $ | (55,876) |  |  | (142) | % |

[0001628280-23-028865:mdna:115]
* Not meaningful

[0001628280-23-028865:mdna:116]
[same as prior period, unchanged from 0001628280-23-017260:mdna:119]

[0001628280-23-028865:mdna:117]
Revenue, Cost of Revenue and Gross Profit

[0001628280-23-028865:mdna:118]
Product Revenue

[0001628280-23-028865:mdna:119]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Product revenue | $ | 15,997 |  |  | $ | 9,340 |  |  | $ | 6,657 |  |  | 71 | % |
| Cost of product revenue | $ | 18,300 |  |  | $ | 10,553 |  |  | $ | 7,747 |  |  | 73 | % |
| Gross profit - Product revenue | $ | (2,303) |  |  | $ | (1,213) |  |  | $ | (1,090) |  |  | (90) | % |
| Gross profit margin - Product revenue | (14) | % |  | (13) | % |  | N/A |  | (1) | % |

[0001628280-23-028865:mdna:120]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which reflect an ongoing increase in the adoption of Evolv Express units by schools and healthcare facilities.

[0001628280-23-028865:mdna:121]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our product sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition of 135 new customers during the six months ended June 30, 2023 compared to 97 new customers during the six months ended June 30, 2022, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-23-028865:mdna:122]
The decrease in product gross profit during the six months ended June 30, 2023 compared to the prior year period is attributable primarily to an increase in product sales as product gross profit margin remained relatively consistent between periods. Product gross profit margin improved during the three months ended June 30, 2023 (negative 7%) compared to the three months ended March 31, 2023 (negative 21%) primarily as the result of higher average revenue per unit sold. These increases were tempered by (i) continued strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets (single lane configurations typically generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price), and (ii) a higher percentage of sales made through our channel partners, which are generally at a lower average sale price. We expect to continue to see improvement in our gross profit margin as we continue to engineer our product with lower cost components.

[0001628280-23-028865:mdna:123]
Subscription Revenue

[0001628280-23-028865:mdna:124]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Subscription revenue | $ | 14,430 |  |  | $ | 7,010 |  |  | $ | 7,420 |  |  | 106 | % |
| Cost of subscription revenue | $ | 5,757 |  |  | $ | 3,523 |  |  | $ | 2,234 |  |  | 63 | % |
| Gross profit - Subscription revenue | $ | 8,673 |  |  | $ | 3,487 |  |  | $ | 5,186 |  |  | 149 | % |
| Gross profit margin - Subscription revenue | 60 | % |  | 50 | % |  | N/A |  | 10 | % |

[0001628280-23-028865:mdna:125]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed under our pure subscription

[0001628280-23-028865:mdna:126]
contract model. Subscription gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-23-028865:mdna:127]
Service Revenue

[0001628280-23-028865:mdna:128]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Service revenue | $ | 7,979 |  |  | $ | 1,430 |  |  | $ | 6,549 |  |  | 458 | % |
| Cost of service revenue | $ | 2,171 |  |  | $ | 2,254 |  |  | $ | (83) |  |  | (4) | % |
| Gross profit - Service revenue | $ | 5,808 |  |  | $ | (824) |  |  | $ | 6,632 |  |  | 805 | % |
| Gross profit margin - Service revenue | 73 | % |  | (58) | % |  | N/A |  | 130 | % |

[0001628280-23-028865:mdna:129]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding year, as well as the increase in the number of installation and training services performed. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-23-028865:mdna:130]
Research and Development Expenses

[0001628280-23-028865:mdna:131]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 8,160 |  |  | $ | 6,962 |  |  | $ | 1,198 |  |  | 17 | % |
| Materials and prototypes | 1,197 |  |  | 236 |  |  | 961 |  |  | 407 | % |
| Professional fees | 1,925 |  |  | 732 |  |  | 1,193 |  |  | 163 | % |
| Other | 502 |  |  | 401 |  |  | 101 |  |  | 25 | % |
|  | $ | 11,784 |  |  | $ | 8,331 |  |  | $ | 3,453 |  |  | 41 | % |

[0001628280-23-028865:mdna:132]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation primarily resulting from new hires in our research and development function during the past twelve months, offset by a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased. Stock compensation expense included in research and development expenses was $2.1 million for the six months ended June 30, 2023 compared to $1.5 million for the six months ended June 30, 2022. The increase in materials and prototypes is due to design and engineering costs related to the next generation of our Evolv Express system. The increase in professional fees primarily relates to consulting costs incurred for product development and engineering.

[0001628280-23-028865:mdna:133]
Sales and Marketing Expenses

[0001628280-23-028865:mdna:134]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 19,707 |  |  | $ | 13,613 |  |  | $ | 6,094 |  |  | 45 | % |
| Advertising and direct marketing | 1,827 |  |  | 2,889 |  |  | (1,062) |  |  | (37) | % |
| Travel and entertainment | 2,142 |  |  | 1,538 |  |  | 604 |  |  | 39 | % |
| Professional fees | 1,094 |  |  | 552 |  |  | 542 |  |  | 98 | % |
| Other | 1,647 |  |  | 2,831 |  |  | (1,184) |  |  | (42) | % |
|  | $ | 26,417 |  |  | $ | 21,423 |  |  | $ | 4,994 |  |  | 23 | % |

[0001628280-23-028865:mdna:135]
The increase in personnel related expenses is due to an increase in payroll costs, commissions and stock-based compensation resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increase sales volume. Stock compensation expense included in sales and marketing expenses was $4.5 million for the six months ended June 30, 2023 compared to $3.8 million for the six months ended June 30, 2022. The decrease in advertising and direct marketing expense is primarily due to a decrease in expense related to trade shows and events. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings and

[0001628280-23-028865:mdna:136]
events. Professional fees increased due primarily to an increase in marketing consulting costs. Other expense decreased due primarily to $1.0 million of certain one-time expenses incurred during the six months ended June 30, 2022.

[0001628280-23-028865:mdna:137]
General and Administrative Expenses

[0001628280-23-028865:mdna:138]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 11,173 |  |  | $ | 7,965 |  |  | $ | 3,208 |  |  | 40 | % |
| Professional fees | 2,909 |  |  | 5,339 |  |  | (2,430) |  |  | (46) | % |
| Insurance costs | 2,066 |  |  | 2,630 |  |  | (564) |  |  | (21) | % |
| Other | 3,652 |  |  | 4,495 |  |  | (843) |  |  | (19) | % |
|  | $ | 19,800 |  |  | $ | 20,429 |  |  | $ | (629) |  |  | (3) | % |

[0001628280-23-028865:mdna:139]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $4.8 million for the six months ended June 30, 2023 compared to $3.3 million for the six months ended June 30, 2022. The decrease in professional fees is primarily related to a decrease in outsourced accounting consultancy fees. The decrease in insurance expense is primarily related to a decrease in director and officer insurance premiums. Other expense decreased primarily due to $1.3 million of certain one-time expenses and a $0.4 million one-time payment to a former employee during the six months ended June 30, 2022, offset by increases in software subscriptions and other miscellaneous expenses.

[0001628280-23-028865:mdna:140]
Loss From Impairment of Property and Equipment

[0001628280-23-028865:mdna:141]
Loss from impairment of property and equipment was $0.3 million and $0.4 million for the six months ended June 30, 2023 and 2022, respectively.

[0001628280-23-028865:mdna:142]
Interest Expense and Loss on Extinguishment of Debt

[0001628280-23-028865:mdna:143]
Interest expense was $0.7 million for the six months ended June 30, 2023, compared to $0.3 million for the six months ended June 30, 2022. The increase was primarily due to interest expense incurred during the three months ended March 31, 2023 related to the Company's term loans with SVB pursuant to the 2022 SVB Credit Agreement. During March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write off of $0.3 million of unamortized debt issuance costs.

[0001628280-23-028865:mdna:144]
Interest Income

[0001628280-23-028865:mdna:145]
Interest income of $2.8 million for the six months ended June 30, 2023 and $0.6 million for the six months ended June 30, 2022 related primarily to interest earned on money market funds.

[0001628280-23-028865:mdna:146]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-23-028865:mdna:147]
Change in the fair value of the contingent earn-out liability resulted in a $31.4 million loss and a $2.5 million gain for the six months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-23-028865:mdna:148]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-23-028865:mdna:149]
Change in the fair value of the contingently issuable common stock liability resulted in a $5.8 million loss and a $1.4 million gain for the six months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-23-028865:mdna:150]
13

[0001628280-23-028865:mdna:151]
Change in Fair Value of Public Warrant Liability

[0001628280-23-028865:mdna:152]
Change in the fair value of the public warrant liability resulted in a $13.5 million loss and a $5.4 million gain for the six months ended June 30, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-23-028865:mdna:153]
[same as prior period, unchanged from 0001628280-23-017260:mdna:110]

[0001628280-23-028865:mdna:154]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. As of June 30, 2023, we had $155.5 million in cash and cash equivalents. We incurred a net loss of $66.8 million and $25.7 million for the three months ended June 30, 2023 and 2022, respectively, and a net loss of $95.4 million and $39.5 million for the six months ended June 30, 2023 and 2022, respectively. We incurred cash outflows from operating activities of $8.5 million and $52.5 million during the six months ended June 30, 2023 and 2022, respectively.

[0001628280-23-028865:mdna:155]
We maintain substantially all of our cash and cash equivalents in accounts with a diverse set of U.S. and multi-national financial institutions and our deposits at these institutions exceed Federal Deposit Insurance Corporation insured limits. The Company does not believe it is exposed to any unusual credit risk or deposit concentration risk beyond the ordinary credit risk associated with commercial banking relationships.

[0001628280-23-028865:mdna:156]
We expect our cash and cash equivalents, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our sales and marketing team. We may require additional capital to respond to the expected growth in the demand for equipment purchases to support our "leased equipment" offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances and in either the short-term or long-term may determine to engage in debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as the public health emergencies, including the COVID-19 pandemic and its variants, international political turmoil, including Russia's invasion of Ukraine and related international sanctions, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001628280-23-028865:mdna:157]
[same as prior period, unchanged from 0001628280-23-017260:mdna:114]

[0001628280-23-028865:mdna:158]
During March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. The Company has no debt outstanding as of June 30, 2023.

[0001628280-23-028865:mdna:159]
[same as prior period, unchanged from 0001628280-23-017260:mdna:116]

[0001628280-23-028865:mdna:160]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of June 30, 2023. We anticipate fulfilling such commitments with our existing cash and cash equivalents, as well as cash and cash equivalents obtained through operations and, if necessary, proceeds from long-term debt. Cash and cash equivalents amounted to $155.5 million as of June 30, 2023.

[0001628280-23-028865:mdna:161]
We entered into a lease agreement for additional office space starting May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. We are required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space which is classified as restricted cash, non-current on the condensed consolidated balance sheet as of June 30, 2023. Total future minimum lease payments under this noncancelable operating lease amount to $1.6 million.

[0001628280-23-028865:mdna:162]
[same as prior period, unchanged from 0001628280-23-017260:mdna:120]

[0001628280-23-028865:mdna:163]
[same as prior period, unchanged from 0001628280-23-017260:mdna:121]

[0001628280-23-028865:mdna:164]
|  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |
| Net cash used in operating activities | $ | (8,513) |  |  | $ | (52,495) |  |
| Net cash used in investing activities | (34,712) |  |  | (12,680) |  |
| Net cash provided by (used in) financing activities | (29,988) |  |  | 384 |  |
| Effect of exchange rate changes on cash and cash equivalents | (33) |  |  | (10) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (73,246) |  |  | $ | (64,801) |  |

[0001628280-23-028865:mdna:165]
[same as prior period, unchanged from 0001628280-23-017260:mdna:123]

[0001628280-23-028865:mdna:166]
|  | Six Months EndedJune 30, |
|  | 2023 |  | 2022 |
| Net loss | $ | (95,363) |  |  | $ | (39,487) |  |
| Non-cash (income) expense | 68,472 |  |  | 2,632 |  |
| Changes in operating assets and liabilities | 18,378 |  |  | (15,640) |  |
| Net cash used in operating activities | $ | (8,513) |  |  | $ | (52,495) |  |

[0001628280-23-028865:mdna:167]
Net loss increased from $39.5 million for the six months ended June 30, 2022 to $95.4 million for the six months ended June 30, 2023 primarily due to changes in the fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability. See "Results of Operations" above for further discussion.

[0001628280-23-028865:mdna:168]
Non-cash expense for the six months ended June 30, 2023 is primarily attributable to $11.7 million of stock-based compensation expense, $4.1 million of depreciation and amortization, $0.6 million of loss from extinguishment of debt, and $50.8 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability. Non-cash income for the six months ended June 30, 2022 is primarily attributable to $9.4 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability, offset by $9.0 million of stock-based compensation expense and $2.4 million of depreciation and amortization.

[0001628280-23-028865:mdna:169]
Changes in operating assets and liabilities for the six months ended June 30, 2023 are primarily related to the following:

[0001628280-23-028865:mdna:170]
•$5.1 million decrease in inventory primarily due to a higher proportion of finished goods recorded as property and equipment based on our expectations of the future mix of Evolv Express units to be leased to customers versus sold to customers;

[0001628280-23-028865:mdna:171]
•$24.1 million increase in deferred revenue due to a higher volume of sales; offset by

[0001628280-23-028865:mdna:172]
•$7.4 million decrease in accounts payable (excluding the non-cash change in capital expenditures incurred but not yet paid from December 31, 2022 to June 30, 2023) primarily due to a decrease in inventory.

[0001628280-23-028865:mdna:173]
Changes in operating assets and liabilities for the six months ended June 30, 2022 are primarily related to the following:

[0001628280-23-028865:mdna:174]
•$5.8 million increase in accounts receivable primarily due to higher sales driven by an increase in customers and the timing of billings to customers;

[0001628280-23-028865:mdna:175]
•$3.5 million increase in inventory primarily due to increased production of units to meet customer demand;

[0001628280-23-028865:mdna:176]
•$9.7 million increase in prepaid expense and other current assets primarily due to prepaid deposits related to orders placed for Evolv Express units; offset by

[0001628280-23-028865:mdna:177]
•$6.0 million increase in deferred revenue primarily due to an increase in billings associated with higher sales.

[0001628280-23-028865:mdna:178]
15

[0001628280-23-028865:mdna:179]
[same as prior period, unchanged from 0001628280-23-017260:mdna:139]

[0001628280-23-028865:mdna:180]
During the six months ended June 30, 2023, cash used in investing activities was $34.7 million, consisting of $33.2 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers, and $1.6 million for the development of internal-use software and software embedded in products to be sold or leased.

[0001628280-23-028865:mdna:181]
During the six months ended June 30, 2022, cash used in investing activities was $12.7 million, consisting of $11.4 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers, and $1.3 million for the development of internal-use software.

[0001628280-23-028865:mdna:182]
[same as prior period, unchanged from 0001628280-23-017260:mdna:142]

[0001628280-23-028865:mdna:183]
During the six months ended June 30, 2023, cash used in financing activities was $30.0 million, consisting of $1.9 million of proceeds under the 2022 SVB Credit Agreement and $0.3 million of proceeds from the exercise of stock options, offset by $31.9 million related to the full repayment of amounts owed under the 2022 SVB Credit Agreement and $0.3 million payment of debt issuance costs and a prepayment penalty.

[0001628280-23-028865:mdna:184]
During the six months ended June 30, 2022, cash provided by financing activities was $0.4 million, relating entirely to the exercise of stock options.

[0001628280-23-028865:mdna:185]
[same as prior period, unchanged from 0001628280-23-017260:mdna:145]

[0001628280-23-028865:mdna:186]
There were no new accounting pronouncements that were issued or became effective since the issuance of the 2022 Form 10-K that had, or are expected to have, a material impact on its consolidated financial position, results of operations or cash flows.

[0001628280-23-028865:mdna:187]
[same as prior period, unchanged from 0001628280-23-017260:mdna:147]

[0001628280-23-028865:mdna:188]
Our critical accounting policies and estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” of the 2022 Form 10-K. There have been no material changes to our critical accounting policies and estimates during the three months ended June 30, 2023.

[0001628280-23-028865:mdna:189]
[same as prior period, unchanged from 0001628280-23-017260:mdna:149]

[0001628280-23-028865:mdna:190]
[same as prior period, unchanged from 0001628280-23-017260:mdna:150]

[0001628280-23-028865:mdna:191]
Based on our public float as of June 30, 2023, we expect to become a large accelerated filer and lose emerging growth company status as of December 31, 2023. As of December 31, 2023, we will be required to adopt new or revised accounting standards when they are applicable to public companies that are not emerging growth companies.
