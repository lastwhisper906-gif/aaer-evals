# EVLV note change history — 0001628280-22-029319 → 0001628280-23-017260


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0001628280-23-017260:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of March 31, 2023 or December 31, 2022.
  (was, 2022-11-09, similarity 0.9939):
[0001628280-22-029319:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of September 30, 2022 or December 31, 2021.

- added (2023-05-10):
[0001628280-23-017260:note_history:2]
The Company is not a party to any litigation of a material nature and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.

- removed (2023-05-10):
[0001628280-22-029319:note_history:3]
The Company is not a party to any litigation and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-05-10):
[0001628280-23-017260:note_history:4]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to live, work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to better address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks in a cost-effective manner while improving safety and the visitor experience. The Company is headquartered in Waltham, Massachusetts.

- changed (2023-05-10):
[0001628280-23-017260:note_history:5]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly-owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC.
  (was, 2022-11-09, similarity 0.749):
[0001628280-22-029319:note_history:5]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC. References to “NHIC” refer to the company prior to the consummation of the Merger (as defined in Note 3) and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

- changed (2023-05-10):
[0001628280-23-017260:note_history:6]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).
  (was, 2022-11-09, similarity 0.9983):
[0001628280-22-029319:note_history:6]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

- changed (2023-05-10):
[0001628280-23-017260:note_history:7]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2023, and for the three months ended March 31, 2023 and 2022 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2022 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2023 and the results of its operations for the three months ended March 31, 2023 and 2022 and cash flows for the three months ended March 31, 2023 and 2022. The results for the three months ended March 31, 2023 are not necessarily indicative of results to be expected for the year ending December 31, 2023, any other interim periods, or any future year or period.
  (was, 2022-11-09, similarity 0.7157):
[0001628280-22-029319:note_history:7]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2022, and for the three and nine months ended September 30, 2022 and 2021 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2021 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2022 and the results of its operations for the three and nine months ended September 30, 2022 and 2021 and cash flows for the nine months ended September 30, 2022 and 2021. The results for the three and nine months ended September 30, 2022 are not necessarily indicative of results to be expected for the year ending December 31, 2022, any other interim periods, or any future year or period.

- added (2023-05-10):
[0001628280-23-017260:note_history:8]
Merger

- added (2023-05-10):
[0001628280-23-017260:note_history:9]
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the Merger as a wholly-owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

- changed (2023-05-10):
[0001628280-23-017260:note_history:10]
In preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified errors in its previously issued financial statements whereby (a) certain expenses that were cost of subscription revenue related and cost of service revenue related were inaccurately classified as sales and marketing expenses on the consolidated statements of operations and comprehensive loss, (b) certain equipment under lease or held for lease was inaccurately classified as inventory on the consolidated balance sheets and a portion of the cash outflows related to the equipment under lease or held for lease were misclassified between operating and investing cash flows on the consolidated statements of cash flows, and (c) the vesting of warrants related to the Business Development Agreement 
disclosed in Note 9 were not accounted for accurately. The identified errors impacted the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022. The Company has made adjustments to the prior period amounts presented in these financial statements accordingly. Additionally, the Company has made adjustments to correct for other previously identified immaterial errors. The Company evaluated the errors and determined that the related impacts were not material to any previously issued annual or interim financial statements. The impact of the revisions to the quarterly period ended March 31, 2022 is presented in Note 14.
  (was, 2022-11-09, similarity 0.9578):
[0001628280-22-029319:note_history:10]
In preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified errors in its previously issued financial statements whereby (a) certain expenses that were cost of subscription revenue related and cost of service revenue related were inaccurately classified as sales and marketing expenses on the consolidated statements of operations and comprehensive loss, (b) certain equipment under lease or held for lease was inaccurately classified as inventory on the consolidated balance sheets and a portion of the cash outflows related to the equipment under lease or held for lease were misclassified between operating and investing cash flows on the consolidated statements of cash flows, and (c) the vesting of warrants related to the Business Development Agreement disclosed in Note 16 were not accounted for accurately. The identified errors impacted the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022. The Company has made adjustments to the prior period amounts presented in these financial statements accordingly. Additionally, the Company has made adjustments to correct for other previously identified immaterial errors. The Company evaluated the errors and determined that the related impacts were not material 
to any previously issued annual or interim financial statements. A summary of the revisions to the previously reported financial information is included in Note 21.

- removed (2023-05-10):
[0001628280-22-029319:note_history:11]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a global leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks in a cost-effective manner while improving the visitor experience. The Company is headquartered in Waltham, Massachusetts.

- removed (2023-05-10):
[0001628280-22-029319:note_history:12]
All share and per share amounts contained herein for periods prior to the Merger have been retroactively adjusted to give effect to the Exchange Ratio (as defined in Note 3), unless otherwise indicated.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0001628280-23-017260:note_history:13]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2022, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2022. There have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2023.
  (was, 2022-11-09, similarity 0.9369):
[0001628280-22-029319:note_history:13]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2021, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2021. There have been no material changes to the Company’s significant accounting policies during the three months ended September 30, 2022 outside of the items as described below.

- changed (2023-05-10):
[0001628280-23-017260:note_history:14]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have a material impact on its consolidated financial statements and related disclosures.
  (was, 2022-11-09, similarity 0.9196):
[0001628280-22-029319:note_history:14]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and does not expect that adoption of the guidance will have a material impact on its condensed consolidated financial statements.

- changed (2023-05-10):
[0001628280-23-017260:note_history:15]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have an impact on its consolidated financial statements and related disclosures.
  (was, 2022-11-09, similarity 0.8894):
[0001628280-22-029319:note_history:15]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company expects to adopt this guidance effective January 1, 2023, and does not expect that adoption of the guidance will have a material impact on its condensed consolidated financial statements.

- removed (2023-05-10):
[0001628280-22-029319:note_history:16]
Leases as a Lessee

- removed (2023-05-10):
[0001628280-22-029319:note_history:17]
Prior to January 1, 2022, the Company accounted for leases in accordance with ASC 840, Leases. At lease inception, the Company determined if an arrangement was an operating or capital lease. For operating leases, the Company recognized rent expense, inclusive of rent escalation, on a straight-line basis over the lease term.

- removed (2023-05-10):
[0001628280-22-029319:note_history:18]
Effective on January 1, 2022, the Company accounts for leases in accordance with ASC 842, Leases. At contract inception, the Company determines if an arrangement is or contains a lease. A lease conveys the right to control the use of an identified asset for a period of time in exchange for consideration. If determined to be or contain a lease, the lease is assessed for classification as either an operating or finance lease at the lease commencement date, defined as the date on which the leased asset is made available for use by the Company (when the Company is the lessee). Where the Company is the lessee, for each lease with a term greater than twelve months, the Company records a right-of-use asset and lease liability.

- removed (2023-05-10):
[0001628280-22-029319:note_history:19]
A right-of-use asset represents the economic benefit conveyed to the Company by the right to use the underlying asset over the lease term. A lease liability represents the obligation to make lease payments arising from the use of the asset over the lease term. Lease liabilities are measured at lease commencement and calculated as the present value of the future lease payments in the contract using the rate implicit in the contract, when available. If an implicit rate is not readily determinable, the Company uses an incremental borrowing rate measured as the rate at which the Company could borrow, on a fully collateralized basis, a commensurate loan in the same currency over a period consistent with the lease term at the commencement date. Right-of-use assets are measured as the amount of the initial lease liability plus initial direct costs and prepaid lease payments, less lease incentives granted by the lessor. The lease term is measured as the noncancelable period in the contract, adjusted for any options to extend or terminate when it is reasonably certain the Company will extend the lease term via such options based on an assessment of economic factors present as of the lease commencement date. The Company elected the practical expedient to not recognize leases with a lease term of twelve months or less.

- removed (2023-05-10):
[0001628280-22-029319:note_history:20]
Components of a lease are split into three categories: lease components, non-lease components, and non-components. The fixed and in-substance fixed contract consideration (including any consideration related to non-components) are allocated, based on the respective relative fair values, to the lease components and non-lease components. The Company has elected the practical expedient to account for lease and non-lease components together as a single lease component for all underlying assets and allocate all of the contract consideration to the lease component only.

- removed (2023-05-10):
[0001628280-22-029319:note_history:21]
The Company’s operating leases are presented in the condensed consolidated balance sheet as operating lease right-of-use assets, classified as noncurrent assets, and operating lease liabilities, classified as current and noncurrent liabilities. Operating lease expense is recognized on a straight-line basis over the lease term. Variable costs associated with a lease, such as maintenance and utilities, are not included in the measurement of the lease liabilities and right-of-use assets but rather are expensed when the events determining the amount of variable consideration to be paid have occurred.

- removed (2023-05-10):
[0001628280-22-029319:note_history:22]
Subscription Revenue - Leases as Lessor

- removed (2023-05-10):
[0001628280-22-029319:note_history:23]
In addition to selling our products directly to customers, we also derive revenue from leasing our equipment, which we classify as subscription revenue. Lease terms are typically four years, generally do not include unilateral options by either the Company or our customer to extend, terminate or to purchase the underlying asset, and customers generally pay either a quarterly or annual fixed payment for the lease and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as they do not meet any of the sales-type lease criteria per ASC 842 and recognized ratably over the duration of the lease. There are no variable lease payments as a part of these arrangements.

- removed (2023-05-10):
[0001628280-22-029319:note_history:24]
The accounting provisions we use to classify transactions as sales-type are: (i) whether the lease transfers ownership of the equipment by the end of the lease term, (ii) whether the lease grants the customer an option to purchase the equipment and the customer is reasonably certain to do so, (iii) whether the lease term is for the major part of the economic life of the underlying equipment, (iv) whether the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (v) whether the equipment is specific to the customer and of such a specialized nature that it is expected to have no alternative use to the Company at the end of the lease term. Leasing arrangements meeting any of these conditions are accounted for as sales-type leases and revenue attributable to the lease component is recognized in a manner consistent with product revenue and the related equipment is derecognized with the associated expense presented as a cost of revenue. Leasing arrangements that do not meet the criteria for classification as a sales-type lease will be accounted for as a direct-financing lease if the following two conditions are met: (i) the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments and any other third party unrelated to the Company, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (ii) it is probable that the Company will collect the lease payments and amounts necessary to satisfy a residual value guarantee. Leasing arrangements that do not meet any of the sales-type lease or direct-financing lease classification criteria are accounted for as operating leases and revenue is recognized straight-line over the term of the lease.

- removed (2023-05-10):
[0001628280-22-029319:note_history:25]
The Company considers the economic life of most of our products to be seven years. The Company believes seven years is representative of the period during which the equipment is expected to be economically usable by one or more users, with normal service, for the purpose for which it is intended. The unguaranteed residual value is estimated to be the value at the end of the lease term based on the anticipated fair market value of the units. The Company mitigates residual value risk of our leased equipment by performing regular management and maintenance, as necessary.

- removed (2023-05-10):
[0001628280-22-029319:note_history:26]
Generally, lease arrangements include both lease and non-lease components. The lease component relates to the customer’s right-to-use the equipment over the lease term. The non-lease components relate to (1) distinct services, such as SaaS and maintenance, (2) any add-on accessories, and (3) installation and training. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the Company elected the practical expedient to aggregate non-lease components with the associated lease component and account for the combined component as an operating lease for all underlying asset classes. In the evaluation of whether the lease component (equipment) or the non-lease components associated with the lease component (SaaS and maintenance) is the predominant component, the Company determined that the lease component is predominant as we believe the customer would ascribe more value to the use of the security equipment than that of the SaaS and maintenance services. Therefore, the Company will account for the combined lease component under ASC 842. The equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in the condensed consolidated statements of operations and comprehensive loss. The installation and training services represent distinct services provided to customers. These activities are considered separate performance obligations to the customer and therefore are considered non-lease components. As installation and training services are performed prior to lease commencement, the timing and pattern of transfer for these services differ from that of the lease component (i.e., security hardware) and are not eligible to be combined.

- removed (2023-05-10):
[0001628280-22-029319:note_history:27]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party. Revenue related to leases entered into with related parties were $0.2 million and $0.4 million during the three and nine months ended September 30, 2022, respectively.

- removed (2023-05-10):
[0001628280-22-029319:note_history:28]
Installation and training are generally billed to the lessee as part of the lease contract billing, according to various contractual terms. The installation and training costs incurred by the Company are accounted for as a fulfillment cost and are included in the cost of services revenue in the condensed consolidated statements of operations and comprehensive loss.

- removed (2023-05-10):
[0001628280-22-029319:note_history:29]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), as subsequently amended (collectively “ASC 842”). The guidance amends the existing accounting standards for lease accounting, including requirements for lessees to recognize assets and liabilities related to long-term leases on the balance sheet and expanding disclosure requirements regarding leasing arrangements. For lessees, leases will be classified as finance or operating, with classification affecting the pattern and classification of expense recognition in the income statement. Lessors are required to classify leases as a sales-type, direct financing, or operating lease. A lease is a sales-type lease if it effectively transfers control of the underlying asset to the lessee as indicated by any one of five criteria being met. All leases that are not sales-type or direct financing leases will be classified as operating leases. In July 2018, the FASB issued additional guidance, which offers a transition option to entities adopting ASC 842 in which entities can elect to apply the new guidance using a modified retrospective approach at the beginning of the year in which the new lease standard is adopted. The Company utilized this transition option whereby financial information for prior periods presented before the ASC 842 effective date will not be updated. In November 2019, the FASB issued ASU 2019-10 deferring the effective date for private entities (also applicable for public companies that qualify as emerging growth companies) for fiscal years beginning after December 15, 2020, and interim periods within fiscal years beginning after December 15, 2021. In June 2020, the FASB issued ASU 2020-05 which further defers the effective date for private entities for fiscal years beginning after December 15, 2021, and interim periods within fiscal years beginning after December 15, 2022.

- removed (2023-05-10):
[0001628280-22-029319:note_history:30]
The Company adopted this guidance effective January 1, 2022. ASC 842 provides several optional practical expedients in transition. The Company applied the ‘package of practical expedients’ which allow the Company to not reassess whether existing or expired arrangements contain a lease, the lease classification of existing or expired leases, or whether previous initial direct costs would qualify for capitalization under ASC 842.

- removed (2023-05-10):
[0001628280-22-029319:note_history:31]
The adoption of ASC 842 resulted in the recognition of operating lease liabilities of $3.0 million and operating right-of-use assets of $2.5 million, along with the write-off of certain deferred rent balances of $0.5 million within the Company’s condensed consolidated balance sheets as of January 1, 2022. The adoption did not have a significant impact on the Company’s condensed consolidated statements of operations and comprehensive loss and condensed consolidated statements of cash flows.

- removed (2023-05-10):
[0001628280-22-029319:note_history:32]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.

- removed (2023-05-10):
[0001628280-22-029319:note_history:33]
In August 2020, the FASB issued ASU 2020-06, Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies and clarifies certain calculation and presentation matters related to convertible and equity and debt instruments. Specifically, ASU 2020-06 removes requirements to separately account for conversion features as a derivative under ASC Topic 815 and removing the requirement to account for beneficial conversion features on such instruments. ASU 2020-06 also provides clearer guidance surrounding disclosure of such instruments and provides specific guidance for how such instruments are to be incorporated in the calculation of Diluted EPS. The guidance under ASU 2020-06 is effective for fiscal years beginning after December 15, 2021, including interim periods within those fiscal

- removed (2023-05-10):
[0001628280-22-029319:note_history:34]
years. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.

- removed (2023-05-10):
[0001628280-22-029319:note_history:35]
Recently Issued Accounting Pronouncements


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0001628280-23-017260:note_history:36]
|  | March 31,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |
  (was, 2022-11-09, similarity 0.7237):
[0001628280-22-029319:note_history:36]
|  | September 30,2022 |  | December 31,2021 |
| Term loans payable | $ | 9,000 |  |  | $ | 10,000 |  |
| Less: Unamortized discount | (41) |  |  | (55) |  |
|  | 8,959 |  |  | 9,945 |  |
| Less: Current portion of long-term debt | 4,000 |  |  | 2,000 |  |
| Long-term debt, net of discount | $ | 4,959 |  |  | $ | 7,945 |  |

- changed (2023-05-10):
[0001628280-23-017260:note_history:37]
Silicon Valley Bank Term Loan Agreement
  (was, 2022-11-09, similarity 0.6441):
[0001628280-22-029319:note_history:37]
Term Loan Agreements

- added (2023-05-10):
[0001628280-23-017260:note_history:38]
In December 2022, the Company entered into a loan and security agreement (the "2022 SVB Credit Agreement") with Silicon Valley Bank ("SVB") in order to finance purchases of hardware to be leased to customers. The 2022 SVB Credit Agreement provided for an initial term loan advance of $30.0 million, which was approximately equivalent to the value of all hardware purchases made to support leasing transactions with the Company's customers through December 21, 2022 (the "SVB Closing Date"), with the opportunity to obtain, within 18 months after the SVB Closing Date, additional term loan advances, subject to the satisfaction of certain conditions, in an aggregate principal amount equal to $20.0 million (subject to an increase of an additional $25.0 million upon the satisfaction of certain conditions and approval from SVB). The interest rate applicable to the SVB Term Loans was the greater of (a) the Wall Street Journal Prime Rate plus 1.0% or (b) 7.25% per annum. Interest and principal under the SVB Credit Agreement was payable monthly.

- added (2023-05-10):
[0001628280-23-017260:note_history:39]
On March 10, 2023, SVB was closed by the California Department of Financial Protection and Innovation, which appointed the Federal Deposit Corporation ("FDIC") as receiver. The FDIC created a successor bridge bank, Silicon Valley Bridge Bank, N.A. ("SVBB"), and all deposits of SVB were transferred to SVBB under a systemic risk exception approved by the Federal Reserve, the U.S. Treasury Department, and the FDIC. On March 12, 2023, the Federal Reserve, the U.S. Treasury Department, and the FDIC announced in a joint statement that all SVB deposits, including both insured and uninsured amounts, would be available in full to account holders. SVB was acquired by First Citizens Bank on March 27, 2023.

- added (2023-05-10):
[0001628280-23-017260:note_history:40]
In light of the foregoing, on March 28, 2023, upon the recommendation of the Company’s newly-formed Investment Committee of the Board of Directors, the Company (i) gave notice of its desire and intent to terminate the commitments under the 2022 SVB Credit Agreement and (ii) transferred its excess cash out of First Citizens Bank (the “Transfer”). The Transfer resulted in an event of default under the 2022 SVB Credit Agreement. Upon the occurrence of such event of default, First Citizens Bank could have, but was not required to, declare all obligations under the 2022 SVB 
Credit Agreement immediately due and payable. First Citizens Bank did not make such declaration following such event of default. On March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write off of $0.3 million of unamortized debt issuance costs.

- removed (2023-05-10):
[0001628280-22-029319:note_history:41]
JPMorgan Chase Bank, N.A.(“JPM”) Credit Agreement

- removed (2023-05-10):
[0001628280-22-029319:note_history:42]
In December 2020, the Company entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024 and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022.

- removed (2023-05-10):
[0001628280-22-029319:note_history:43]
Principal and interest on the JPM Credit Agreement is payable monthly commencing on July 1, 2022. The JPM Credit Agreement accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 2.25% or (B) 5.5%. The revolving line of credit accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 1.25% or (B) 4.5%. Upon closing, the Company issued warrants to purchase 377,837 shares of common stock to the lender with an exercise price of $0.42 per share with a fair value of $0.1 million on the date of issuance. The Company incurred debt issuance costs of $0.1 million equal to the fair value of the warrants in connection with the JPM Credit Agreement. These costs were recorded as debt discount and are amortized to interest expense, using the effective interest method, over the term of the loan. Upon the closing of the Merger, the warrants were converted into shares of the Company's common stock.

- removed (2023-05-10):
[0001628280-22-029319:note_history:44]
As of September 30, 2022, the unamortized debt discount was less than $0.1 million. As of September 30, 2022, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the condensed consolidated balance sheet. Interest expense related to the JPM Credit Agreement totaled $0.2 million and $0.2 million for the three months ended September 30, 2022 and September 30, 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million in each period. Interest expense related to the JPM Credit Agreement totaled $0.5 million and $0.6 million for the nine months ended September 30, 2022 and September 30, 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million in each period. The interest rate in effect as of September 30, 2022 was 8.50% for the JPM Credit Agreement.

- removed (2023-05-10):
[0001628280-22-029319:note_history:45]
The Company’s obligations under the JPM Credit Agreement are secured by a first-priority security interest in all of its assets, including intellectual property.

- removed (2023-05-10):
[0001628280-22-029319:note_history:46]
As of September 30, 2022, future principal payments on long-term debt are as follows (in thousands):

- removed (2023-05-10):
[0001628280-22-029319:note_history:47]
| December 31, |  |
| 2022 (remaining three months) | $ | 1,000 |  |
| 2023 | 4,000 |  |
| 2024 | 4,000 |  |
|  | $ | 9,000 |  |

- removed (2023-05-10):
[0001628280-22-029319:note_history:48]
Convertible Note

- removed (2023-05-10):
[0001628280-22-029319:note_history:49]
In September 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) with an investor for gross proceeds of $2.0 million with a stated interest rate of 6.0% per annum. An additional $2.0 million in gross proceeds were made available in December 31, 2020 upon achievement of the integration milestone, whereby the Company successfully created software utilizing the investor’s application programming interface. The 2020 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds of the issuance of preferred stock totaled at least $10.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2020 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $1.0 million, and the notes, with an initial carrying value of $3.0 million, and included in long-term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the

- removed (2023-05-10):
[0001628280-22-029319:note_history:50]
effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the merger.

- removed (2023-05-10):
[0001628280-22-029319:note_history:51]
Interest expense related to the 2020 Convertible Notes totaled less than $0.1 million and $0.3 million for the three and nine months ended September 30, 2021, respectively. No interest expense was recognized related to the 2020 Convertible Notes for the three and nine months ended September 30, 2022.

- removed (2023-05-10):
[0001628280-22-029319:note_history:52]
In January and February 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80.0% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $7.0 million, and the notes, with an initial carrying value of $23.0 million, and included in long-term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the Merger.

- removed (2023-05-10):
[0001628280-22-029319:note_history:53]
In June 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. This modification of the notes resulted in an extinguishment and the Company recognized a loss on extinguishment of the 2021 Convertible Notes of $11.8 million. The $26.7 million carrying value of the notes at June 21, 2021 was derecognized and replacement notes with an initial carrying value of $29.6 million were recorded. Additionally, in the extinguishment accounting, a derivative liability of $19.2 million was recognized, which represents the value of the 1,000,000 NHIC shares as well as a bifurcated embedded derivative for the conversion option.

- removed (2023-05-10):
[0001628280-22-029319:note_history:54]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense).

- removed (2023-05-10):
[0001628280-22-029319:note_history:55]
Interest expense related to the 2021 Convertible Notes totaled $0.1 million and $4.9 million for the three and nine months ended September 30, 2021, respectively. No interest expense was recognized related to the 2021 Convertible Notes for the three and nine months ended September 30, 2022.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0001628280-23-017260:note_history:56]
|  | March 31,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |
  (was, 2022-11-09, similarity 0.7237):
[0001628280-22-029319:note_history:56]
|  | September 30,2022 |  | December 31,2021 |
| Term loans payable | $ | 9,000 |  |  | $ | 10,000 |  |
| Less: Unamortized discount | (41) |  |  | (55) |  |
|  | 8,959 |  |  | 9,945 |  |
| Less: Current portion of long-term debt | 4,000 |  |  | 2,000 |  |
| Long-term debt, net of discount | $ | 4,959 |  |  | $ | 7,945 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-05-10):
[0001628280-22-029319:note_history:57]
As of September 30, 2022, future principal payments on long-term debt are as follows (in thousands):

- removed (2023-05-10):
[0001628280-22-029319:note_history:58]
| December 31, |  |
| 2022 (remaining three months) | $ | 1,000 |  |
| 2023 | 4,000 |  |
| 2024 | 4,000 |  |
|  | $ | 9,000 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0001628280-23-017260:note_history:59]
Related Party Transactions
Business Development Agreement with Finback
  (was, 2022-11-09, similarity 0.7611):
[0001628280-22-029319:note_history:59]
Business Development Agreement with Finback

- added (2023-05-10):
[0001628280-23-017260:note_history:60]
In January 2021, the Company granted the Finback Common Stock Warrants subject to the terms of the Finback BDA, as discussed in Note 9.

- added (2023-05-10):
[0001628280-23-017260:note_history:61]
In connection with the Merger and pursuant to the Merger Agreement, in addition to earn-out shares allocated to Finback based on its common stock ownership percentage as of the Merger date, Finback is entitled to receive a proportional share of earn-out shares based upon its remaining unvested warrants as of the Merger Date.

- changed (2023-05-10):
[0001628280-23-017260:note_history:62]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended March 31, 2023 and 2022, revenue from Motorola's distributor services was  $3.2 million and $0.8 million, respectively. As of March 31, 2023 and December 31, 2022, accounts receivable related to Motorola’s distributor services was $4.7 million and $12.5 million, respectively.
  (was, 2022-11-09, similarity 0.6082):
[0001628280-22-029319:note_history:62]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement (the “Distribution Agreement”) with Motorola, an investor in the Company. In June 2021, the partnership agreement was amended by the Amended and Restated Distribution Agreement (the “Amended and Restated Distribution Agreement”). Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended September 30, 2022 and 2021, revenue from sales to Motorola was  $2.3 million and less than $0.1 million, respectively. During the nine months ended September 30, 2022 and 2021, revenue from sales to Motorola was $5.0 million and less than $0.1 million, respectively. As of September 30, 2022 and December 31, 2021, accounts receivable related to Motorola’s distributor services was $4.1 million and $1.2 million, respectively.

- added (2023-05-10):
[0001628280-23-017260:note_history:63]
Reseller Agreement with Stanley Black & Decker

- added (2023-05-10):
[0001628280-23-017260:note_history:64]
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB ("Securitas") in 2023. Securitas, directly or through its affiliates, resells the Company's products. During the three months ended March 31, 2023 and 2022, revenue from Securitas' reseller services was $0.4 million and less than $0.1 million, respectively. As of March 31, 2023 and December 31, 2022, accounts receivable related to Securitas' reseller services was $0.6 million and $2.2 million, respectively.

- removed (2023-05-10):
[0001628280-22-029319:note_history:65]
Related Party Transactions
Nonrecourse Promissory Note with Officer

- removed (2023-05-10):
[0001628280-22-029319:note_history:66]
In August 2020, the Company entered into a $0.4 million promissory note with an officer with the proceeds being used to exercise options for 1,469,366 shares of common stock at a price of $0.24 per share. The promissory note bore interest at the Wall Street Journal Prime Rate and was secured by the underlying shares of common stock that were issued upon the exercise of the stock options. The promissory note was treated as nonrecourse as the loan was only secured by the common stock issued from the exercise of the stock options. As such, (i) the underlying stock option grant was still considered to be outstanding and the shares of common stock were not considered issued and outstanding for accounting purposes until the loan was repaid in full or otherwise forgiven and (ii) no receivable was recorded for the promissory note on the Company’s condensed consolidated balance sheets. As such, the promissory note effectively extended the maturity date of the option grant for the life of the loan, this change is treated as a stock option modification. The incremental fair value from the stock option modification was deemed immaterial. The interest on this nonrecourse loan is also considered nonrecourse. As the Company has no intent to collect interest, no accrued interest was recorded.

- removed (2023-05-10):
[0001628280-22-029319:note_history:67]
In June 2021, the Company agreed to repurchase 43,665 shares of common stock valued at $8.05 per share of common stock held by the officer of the Company. In exchange for the repurchase of the common stock by the Company, the $0.4 million promissory note held by the officer was considered repaid in full.

- removed (2023-05-10):
[0001628280-22-029319:note_history:68]
In January 2021, the Company granted the Finback Common Stock Warrants. During the three months ended September 30, 2022 and 2021, the Company recorded $1.3 million and $1.0 million, respectively, of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants. During the nine months ended September 30, 2022 and 2021, the Company recorded $2.1 million and $1.8 million, respectively, of stock-based compensation expense within sales and marketing expense for the Finback Common Stock Warrants.

- removed (2023-05-10):
[0001628280-22-029319:note_history:69]
In connection with the Merger and pursuant to the Merger Agreement, Finback is entitled to receive a proportional share of earn-out shares as an earn-out service provider, based upon the remaining unvested warrants as of the Merger

- removed (2023-05-10):
[0001628280-22-029319:note_history:70]
Date. As of September 30, 2022, Finback can earn 284,511 earn-out shares subject to stock-based compensation, based on the achievement of certain milestones. During the three and nine months ended September 30, 2021, $1.5 million stock-based compensation expense was recorded within sales and marketing expense for the earn-out shares allocated to Finback. During the three and nine months ended September 30, 2022, no stock-based compensation expense was recorded within sales and marketing expense for the earn-out shares allocated to Finback.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-05-10):
[0001628280-23-017260:note_history:71]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Product revenue | $ | 8,754 |  |  | $ | 5,194 |  |  |  |  |  |
| Leased equipment | 6,466 |  |  | 3,004 |  |  |  |  |  |
| SaaS, maintenance, and other revenue | 2,778 |  |  | 368 |  |  |  |  |  |
| Professional services | 583 |  |  | 144 |  |  |  |  |  |
| Total revenue | $ | 18,581 |  |  | $ | 8,710 |  |  |  |  |  |

- removed (2023-05-10):
[0001628280-22-029319:note_history:72]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Product revenue | $ | 9,839 |  |  | $ | 5,395 |  |  | $ | 19,179 |  |  | $ | 10,279 |  |
| Leased equipment | 5,198 |  |  | 2,312 |  |  | 12,208 |  |  | 5,060 |  |
| SaaS and Maintenance revenue | 1,180 |  |  | 300 |  |  | 2,277 |  |  | 662 |  |
| Professional services and other revenue | 313 |  |  | 417 |  |  | 646 |  |  | 794 |  |
| Total revenue | $ | 16,530 |  |  | $ | 8,424 |  |  | $ | 34,310 |  |  | $ | 16,795 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0001628280-23-017260:note_history:73]
Revenue RecognitionThe Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the 
contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.
  (was, 2022-11-09, similarity 0.9994):
[0001628280-22-029319:note_history:73]
Revenue Recognition
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

- changed (2023-05-10):
[0001628280-23-017260:note_history:74]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases under ASC 842 and (2) from the sale of products, inclusive of SaaS and maintenance and (3) professional services. The Company’s arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax.
  (was, 2022-11-09, similarity 0.9066):
[0001628280-22-029319:note_history:74]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases under ASC 842 and (2) from the sale of products, inclusive of SaaS and maintenance and (3) professional services. The Company’s arrangements are generally noncancelable and nonrefundable after ownership passes to the customer for product sales and upon installation for subscriptions. Revenue is recognized net of sales tax.

- changed (2023-05-10):
[0001628280-23-017260:note_history:75]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2023.
  (was, 2022-11-09, similarity 0.9731):
[0001628280-22-029319:note_history:75]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2022.

- changed (2023-05-10):
[0001628280-23-017260:note_history:76]
The amount of minimum future leases is based on expected income recognition. As of March 31, 2023, future minimum payments on noncancelable leases are as follows (in thousands):
  (was, 2022-11-09, similarity 0.9711):
[0001628280-22-029319:note_history:76]
The amount of minimum future leases is based on expected income recognition. As of September 30, 2022, future minimum payments on noncancelable leases are as follows (in thousands):

- changed (2023-05-10):
[0001628280-23-017260:note_history:77]
| Year Ending December 31: |  |
| 2023 (nine months remaining) | $ | 23,898 |  |
| 2024 | 30,446 |  |
| 2025 | 26,586 |  |
| 2026 | 16,060 |  |
| 2027 | 2,065 |  |
| Thereafter | 17 |  |
|  | $ | 99,072 |  |
  (was, 2022-11-09, similarity 0.977):
[0001628280-22-029319:note_history:77]
| Year Ending December 31: |  |
| 2022 (three months remaining) | $ | 5,734 |  |
| 2023 | 22,403 |  |
| 2024 | 20,956 |  |
| 2025 | 17,067 |  |
| 2026 | 6,377 |  |
| Thereafter | 80 |  |
|  | $ | 72,617 |  |

- changed (2023-05-10):
[0001628280-23-017260:note_history:78]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of March 31, 2023 and December 31, 2022, the Company had $3.3 million and $2.9 million in current portion of contract assets and $0.7 million and $1.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2022-11-09, similarity 0.9849):
[0001628280-22-029319:note_history:78]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2022 and December 31, 2021, the Company had $5.3 million and $1.5 million in current portion of contract assets and $1.5 million and $3.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2023-05-10):
[0001628280-23-017260:note_history:79]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $6.9 million during the three months ended March 31, 2023 that was included in the December 31, 2022 deferred revenue balance. The Company recognized revenue of $2.5 million during the three months ended March 31, 2022 that was included in the December 31, 2021 deferred revenue balance.
  (was, 2022-11-09, similarity 0.6836):
[0001628280-22-029319:note_history:79]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue

- changed (2023-05-10):
[0001628280-23-017260:note_history:80]
| Balance at December 31, 2022 | $ | 35,968 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (6,887) |  |
| Revenue deferred | 15,644 |  |
| Balance at March 31, 2023 | $ | 44,725 |  |
  (was, 2022-11-09, similarity 0.7576):
[0001628280-22-029319:note_history:80]
| Balance at December 31, 2021 | $ | 9,074 |  |
| Revenue recognized | 5,995 |  |
| Revenue deferred | 10,017 |  |
| Balance at September 30, 2022 | $ | 25,086 |  |

- changed (2023-05-10):
[0001628280-23-017260:note_history:81]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Revenue from sales-type leases | $ | — |  |  | $ | 1,106 |  |  |  |  |  |
| Interest income on lease receivables | 53 |  |  | 49 |  |  |  |  |  |
| Lease income - operating leases | 6,466 |  |  | 3,004 |  |  |  |  |  |
| Total lease revenue | $ | 6,519 |  |  | $ | 4,159 |  |  |  |  |  |
  (was, 2022-11-09, similarity 0.7334):
[0001628280-22-029319:note_history:81]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue from sales-type leases | $ | 29 |  |  | $ | — |  |  | $ | 1,341 |  |  | $ | — |  |
| Interest income on lease receivables | 60 |  |  | — |  |  | 170 |  |  | — |  |
| Lease income - operating leases | 5,198 |  |  | 2,312 |  |  | 12,208 |  |  | 5,060 |  |
| Total lease revenue | $ | 5,287 |  |  | $ | 2,312 |  |  | $ | 13,719 |  |  | $ | 5,060 |  |

- changed (2023-05-10):
[0001628280-23-017260:note_history:82]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified as other income (expense), net in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.2 million and $0.1 million during the three months ended March 31, 2023 and 2022, respectively.
  (was, 2022-11-09, similarity 0.899):
[0001628280-22-029319:note_history:82]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified as other income (expense), net in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss.

- added (2023-05-10):
[0001628280-23-017260:note_history:83]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Product revenue | $ | 8,754 |  |  | $ | 5,194 |  |  |  |  |  |
| Leased equipment | 6,466 |  |  | 3,004 |  |  |  |  |  |
| SaaS, maintenance, and other revenue | 2,778 |  |  | 368 |  |  |  |  |  |
| Professional services | 583 |  |  | 144 |  |  |  |  |  |
| Total revenue | $ | 18,581 |  |  | $ | 8,710 |  |  |  |  |  |

- changed (2023-05-10):
[0001628280-23-017260:note_history:84]
Contract Acquisition Costs
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $9.7 million and $9.0 million as of March 31, 2023 and December 31, 2022, respectively. During the three months ended March 31, 2023 and 2022, the Company amortized commission expense of $1.6 million and $0.4 million, respectively.
  (was, 2022-11-09, similarity 0.854):
[0001628280-22-029319:note_history:84]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $7.0 million and $5.4 million as of September 30, 2022 and December 31, 2021,

- removed (2023-05-10):
[0001628280-22-029319:note_history:85]
and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $1.3 million and $6.0 million during the three and nine months ended September 30, 2022, respectively, that was included in the 2021 deferred revenue balance. The Company recognized revenue of $0.5 million and $2.3 million during the three and nine months ended September 30, 2021, respectively, that was included in the 2020 deferred revenue balance.

- removed (2023-05-10):
[0001628280-22-029319:note_history:86]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Product revenue | $ | 9,839 |  |  | $ | 5,395 |  |  | $ | 19,179 |  |  | $ | 10,279 |  |
| Leased equipment | 5,198 |  |  | 2,312 |  |  | 12,208 |  |  | 5,060 |  |
| SaaS and Maintenance revenue | 1,180 |  |  | 300 |  |  | 2,277 |  |  | 662 |  |
| Professional services and other revenue | 313 |  |  | 417 |  |  | 646 |  |  | 794 |  |
| Total revenue | $ | 16,530 |  |  | $ | 8,424 |  |  | $ | 34,310 |  |  | $ | 16,795 |  |

- removed (2023-05-10):
[0001628280-22-029319:note_history:87]
Contract Acquisition Costs

- removed (2023-05-10):
[0001628280-22-029319:note_history:88]
respectively. During the three months ended September 30, 2022 and 2021, the Company amortized commission expense of $1.2 million and $1.4 million, respectively. During the nine months ended September 30, 2022 and 2021, the Company amortized commission expense of $2.4 million and $2.0 million, respectively.

- removed (2023-05-10):
[0001628280-22-029319:note_history:89]
Give Evolv LLC

- removed (2023-05-10):
[0001628280-22-029319:note_history:90]
Upon the closing of the Merger, the NHIC Founders transferred 517,500 shares of its common stock to Evolv NewHold Benefit LLC (“ENHB”), which represented the initial contribution to be used to pay for the donation of Evolv’s Express units to public venues and institutions, primarily schools in locations that might not otherwise be able to afford weapon detection security screening systems and related products and services. In September 2021, ENHB was renamed to Give Evolv LLC (“Give Evolv”). Give Evolv is deemed an entity under common control and a consolidating entity as it is under the same management as the Company. As such, the shares held by Give Evolv are not considered outstanding or issued.

- removed (2023-05-10):
[0001628280-22-029319:note_history:91]
For such arrangements, Give Evolv generally purchases the related products and services from Evolv Technologies, Inc. through an intercompany transaction using the available donated proceeds from the transfer of common stock upon the closing of the Merger. Evolv Technologies, Inc. will be responsible for the delivery of the units, in addition to providing related services, such as installation, training, and maintenance. Consideration transferred to Evolv Technologies, Inc. for the related products and services may be in the form of common stock or cash. Shares of common stock may be sold to generate funds for the purposes of paying for the donated goods and services. The sales transactions between Evolv Technologies, Inc. and Give Evolv eliminate in consolidation.

- removed (2023-05-10):
[0001628280-22-029319:note_history:92]
During the nine months ended September 30, 2022, the Company donated six Evolv Express units to schools, resulting in $0.2 million in general and administrative expense in the Company’s condensed consolidated statements of operations and comprehensive loss. No Evolv Express units were donated during the nine months ended September 30, 2021.
