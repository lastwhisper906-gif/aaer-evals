# EVLV MD&A — 0001628280-23-017260


## mdna

[0001628280-23-017260:mdna:1]
[same as prior period, unchanged from 0001628280-22-029319:mdna:1]

[0001628280-23-017260:mdna:2]
During the year ended December 31, 2022, we identified immaterial errors in our previously issued financial statements. We have corrected the amounts as presented in this Item 7 accordingly. Please refer to Notes 1 and 14 to the financial statements included in Part 1 of this Quarterly Report on Form 10-Q for additional information.

[0001628280-23-017260:mdna:3]
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the merger as a wholly-owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001628280-23-017260:mdna:4]
[same as prior period, unchanged from 0001628280-22-029319:mdna:4]

[0001628280-23-017260:mdna:5]
[same as prior period, unchanged from 0001628280-22-029319:mdna:5]

[0001628280-23-017260:mdna:6]
We are a leader in AI-based weapons detection for security screening. Unlike conventional walk-through metal detectors, our products use advanced sensors, artificial intelligence software, and cloud services to reliably detect guns, improvised explosives, and large knives while ignoring harmless items like phones and keys. This not only enhances security at venues and facilities but also improves the visitor experience by making screening up to ten times faster than alternatives at up to 70% lower total cost.

[0001628280-23-017260:mdna:7]
Our products have screened over 600 million visitors worldwide since our inception. We believe that we have screened more people through advanced systems than any organization other than the United States Transportation Security Administration (“TSA”). Our customers include many iconic venues across a wide variety of industries, including major sports stadiums and arenas, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, hospitals, large industrial workplaces, schools, and prominent houses of worship. We offer our products for lease or purchase and utilize a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue, and creates expansion and upsell opportunities.

[0001628280-23-017260:mdna:8]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $18.6 million and $8.7 million for the three months ended March 31, 2023 and 2022, respectively. We generated a net loss of $28.6 million and $13.8 million for the three months ended March 31, 2023 and 2022, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-23-017260:mdna:9]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations, and if necessary, debt financings. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources.”

[0001628280-23-017260:mdna:10]
[same as prior period, unchanged from 0001628280-22-029319:mdna:21]

[0001628280-23-017260:mdna:11]
We believe that our performance and future success depend on many factors that present significant opportunities for us but also pose risks and challenges, including those discussed below and in the "Risk Factors" section of our 2022 Form 10-K.

[0001628280-23-017260:mdna:12]
General Economic and Market Conditions

[0001628280-23-017260:mdna:13]
We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of rising inflation and interest rates on business spending; supply chain issues and the impacts on our manufacturing capabilities; the continued effects of the COVID-19 pandemic and other public health emergencies; the Russian invasion of Ukraine and related geopolitical impacts; and a possible economic recession. While these factors continue to evolve, we plan to remain flexible and to optimize our business as appropriate and allocate resources, as necessary.

[0001628280-23-017260:mdna:14]
[same as prior period, unchanged from 0001628280-22-029319:mdna:24]

[0001628280-23-017260:mdna:15]
We believe the world will continue to focus on the safety and security of people in the places where they gather. Many of these locations, such as professional sports venues, educational institutions, and healthcare facilities, are moving toward a more frictionless security screening experience. We believe that we are well-positioned to take advantage of this opportunity due to our proprietary technologies and global distribution capabilities. Our products are designed to empower venues and facilities to realize the full benefits of touchless security screening, including faster visitor throughput, reduced security staff requirements, and a less invasive screening experience for visitors. We expect that our results of operations, including revenue, will fluctuate for the foreseeable future as venues and facilities continue to shift away from conventional security screening processes towards touchless security screening or consider security screening processes for the first time. The degree to which potential and current customers recognize these benefits and invest in our products will affect our financial results.

[0001628280-23-017260:mdna:16]
Sales Mix, Pricing, Product Cost and Margins

[0001628280-23-017260:mdna:17]
Revenue generated by the sale of products represented 47% and 60% of our total revenue for the three months ended March 31, 2023 and 2022, respectively. The remaining revenue was generated from subscription sales and services for our products. Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions, primarily within the United States.

[0001628280-23-017260:mdna:18]
We continue to transition our go-to-market strategy to focus on our "pure subscription" sales model, where the customer leases our hardware, as opposed to purchasing the hardware outright, and enters into a multi-year security-as-a-service subscription. Accordingly, we expect subscription revenue as a percentage of total revenue to increase in future periods. We believe that the pure subscription model aligns more closely with the SaaS nature of our business and results in a more predictable and consistent recurring revenue stream as compared to the purchase subscription model. As part of this overall strategy, we entered into a distribution and license agreement in March 2023 with Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, which currently serves as our primary contract manufacturer. Under this arrangement, we have granted a limited, non-exclusive license under our intellectual property rights to Columbia Tech, and Columbia Tech will manufacture hardware systems and contract directly with certain of our resellers to fulfill sales demand where the end-user customer requires the contract to be in form of a hardware purchase. Columbia Tech will pay us a hardware license fee for each system sold under this agreement. In these instances, we will still contract directly with the reseller to provide a multi-year security-as-a-service subscription to the end-users. We expect sales under this distribution and license agreement will commence by the end of the second fiscal quarter of 2023.

[0001628280-23-017260:mdna:19]
Pricing may vary by region due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales, bookings, and business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products to our customers.

[0001628280-23-017260:mdna:20]
[same as prior period, unchanged from 0001628280-22-029319:mdna:29]

[0001628280-23-017260:mdna:21]
We are a leader in AI-based weapons detection for security screening, offering transformative technologies that enable enhanced security, higher throughput, a more frictionless visitor experience, and substantial cost savings through our product innovations. Our performance is significantly dependent on the investment we make in our research and development efforts and on our ability to be at the forefront of the security screening industry. It is essential that we continually identify and respond to rapidly evolving customer requirements, develop and introduce innovative new products, enhance existing products and generate customer demand for our products. We believe that investment in our security screening products will contribute to long-term revenue growth, but it may adversely affect our near-term profitability.

[0001628280-23-017260:mdna:22]
[same as prior period, unchanged from 0001628280-22-029319:mdna:39]

[0001628280-23-017260:mdna:23]
[same as prior period, unchanged from 0001628280-22-029319:mdna:40]

[0001628280-23-017260:mdna:24]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, (2) the sale of products, inclusive of SaaS and maintenance, and (3) professional services. Our arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax.

[0001628280-23-017260:mdna:25]
[same as prior period, unchanged from 0001628280-22-029319:mdna:42]

[0001628280-23-017260:mdna:26]
We derive a portion of our revenue from the sale of our Evolv Express equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We expect product revenue to decline as a percentage of our overall revenue overtime as more customers enter full subscription transactions with us and as our subscription becomes more valuable to our business.

[0001628280-23-017260:mdna:27]
[same as prior period, unchanged from 0001628280-22-029319:mdna:44]

[0001628280-23-017260:mdna:28]
Subscription revenue consists of revenue derived from leasing Evolv Express and Evolv Edge units to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as they do not meet any of the sales-type lease criteria per ASC 842 and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001628280-23-017260:mdna:29]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (1) distinct services, such as installation, training, SaaS, and maintenance and (2) any add-on accessories. Installation and training are included in services revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our condensed consolidated statements of operations and comprehensive loss.

[0001628280-23-017260:mdna:30]
[same as prior period, unchanged from 0001628280-22-029319:mdna:47]

[0001628280-23-017260:mdna:31]
Services revenue includes subscription-based SaaS and maintenance revenue related to products sold to customers, as well as installation and training services. Revenue for installation and training are recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes, and when-and-if available threat updates. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically four years.

[0001628280-23-017260:mdna:32]
[same as prior period, unchanged from 0001628280-22-029319:mdna:50]

[0001628280-23-017260:mdna:33]
[same as prior period, unchanged from 0001628280-22-029319:mdna:51]

[0001628280-23-017260:mdna:34]
[same as prior period, unchanged from 0001628280-22-029319:mdna:52]

[0001628280-23-017260:mdna:35]
Cost of product revenue consists primarily of costs paid to third party manufacturers and other suppliers, labor costs (including stock-based compensation), and shipping costs.

[0001628280-23-017260:mdna:36]
[same as prior period, unchanged from 0001628280-22-029319:mdna:54]

[0001628280-23-017260:mdna:37]
Cost of subscription revenue consists primarily of shipping costs, an allocated portion of internal-use software amortization expense, depreciation expense related to leased units, and maintenance costs related to leased units. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001628280-23-017260:mdna:38]
[same as prior period, unchanged from 0001628280-22-029319:mdna:56]

[0001628280-23-017260:mdna:39]
Cost of services revenue consists of costs related to installation and training services, an allocated portion of internal-use software amortization expense, and maintenance costs related to units purchased by customers. Maintenance costs consists primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001628280-23-017260:mdna:40]
[same as prior period, unchanged from 0001628280-22-029319:mdna:59]

[0001628280-23-017260:mdna:41]
[same as prior period, unchanged from 0001628280-22-029319:mdna:60]

[0001628280-23-017260:mdna:42]
[same as prior period, unchanged from 0001628280-22-029319:mdna:61]

[0001628280-23-017260:mdna:43]
[same as prior period, unchanged from 0001628280-22-029319:mdna:62]

[0001628280-23-017260:mdna:44]
•Mix between purchase subscription sales and pure subscription sales;

[0001628280-23-017260:mdna:45]
[same as prior period, unchanged from 0001628280-22-029319:mdna:63]

[0001628280-23-017260:mdna:46]
[same as prior period, unchanged from 0001628280-22-029319:mdna:64]

[0001628280-23-017260:mdna:47]
[same as prior period, unchanged from 0001628280-22-029319:mdna:65]

[0001628280-23-017260:mdna:48]
[same as prior period, unchanged from 0001628280-22-029319:mdna:66]

[0001628280-23-017260:mdna:49]
[same as prior period, unchanged from 0001628280-22-029319:mdna:67]

[0001628280-23-017260:mdna:50]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, stock-based compensation, prototypes, design expenses, and consulting and contractor costs. We expect research and development costs will continue to increase during the year ending December 31, 2023 primarily due to incremental investments in headcount and programs we are making to support our new product development efforts.

[0001628280-23-017260:mdna:51]
[same as prior period, unchanged from 0001628280-22-029319:mdna:69]

[0001628280-23-017260:mdna:52]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will continue to increase during the year ending December 31, 2023 due to an expected increase in customer facing headcount as we build out our sales, business development, and customer support capabilities.

[0001628280-23-017260:mdna:53]
[same as prior period, unchanged from 0001628280-22-029319:mdna:49]

[0001628280-23-017260:mdna:54]
[same as prior period, unchanged from 0001628280-22-029319:mdna:71]

[0001628280-23-017260:mdna:55]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and sales tax contingencies. We expect our general and administrative expenses will remain relatively consistent for the year ending December 31, 2023 compared to the year ended December 31, 2022 as we look to leverage previous investments made in people and processes.

[0001628280-23-017260:mdna:56]
[same as prior period, unchanged from 0001628280-22-029319:mdna:73]

[0001628280-23-017260:mdna:57]
Loss from impairment of property and equipment relates to: (i) leased Evolv Edge units and Evolv Express prototype units that are removed from service and retired as we transition our domestic customers to our most current Evolv Express units and (ii) damaged or destroyed leased units.

[0001628280-23-017260:mdna:58]
[same as prior period, unchanged from 0001628280-22-029319:mdna:75]

[0001628280-23-017260:mdna:59]
Interest expense includes cash interest paid on long-term debt and amortization of deferred financing fees and costs.

[0001628280-23-017260:mdna:60]
[same as prior period, unchanged from 0001628280-22-029319:mdna:77]

[0001628280-23-017260:mdna:61]
Interest income relates to interest earned on money market funds and interest earned on our lease receivables for our Evolv Express units recognized as sales type leases.

[0001628280-23-017260:mdna:62]
[same as prior period, unchanged from 0001628280-22-029319:mdna:85]

[0001628280-23-017260:mdna:63]
[same as prior period, unchanged from 0001628280-22-029319:mdna:86]

[0001628280-23-017260:mdna:64]
[same as prior period, unchanged from 0001628280-22-029319:mdna:87]

[0001628280-23-017260:mdna:65]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 shares of NHIC Class B common stock (the "Founder Shares"). Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 1,897,500 Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones, and 517,500 Founder Shares were contributed to Give Evolv LLC. The 1,897,500 outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss.

[0001628280-23-017260:mdna:66]
[same as prior period, unchanged from 0001628280-22-029319:mdna:89]

[0001628280-23-017260:mdna:67]
[same as prior period, unchanged from 0001628280-22-029319:mdna:90]

[0001628280-23-017260:mdna:68]
[same as prior period, unchanged from 0001628280-22-029319:mdna:93]

[0001628280-23-017260:mdna:69]
Our income tax provision consists of an estimate for U.S. federal and state income taxes based on enacted rates, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. There is no provision for income taxes for the three months ended March 31, 2023 and 2022 because we have historically incurred net operating losses and maintain a full valuation allowance against its deferred tax assets.

[0001628280-23-017260:mdna:70]
[same as prior period, unchanged from 0001628280-22-029319:mdna:96]

[0001628280-23-017260:mdna:71]
Comparison of the Three Months Ended March 31, 2023 and 2022

[0001628280-23-017260:mdna:72]
The following table summarizes our results of operations for the three months ended March 31, 2023 and 2022, (in thousands):

[0001628280-23-017260:mdna:73]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 8,754 |  |  | $ | 5,194 |  |  | $ | 3,560 |  |  | 69 | % |
| Subscription revenue | 6,466 |  |  | 3,004 |  |  | 3,462 |  |  | 115 |  |
| Service revenue | 3,361 |  |  | 512 |  |  | 2,849 |  |  | 556 |  |
| Total revenue | 18,581 |  |  | 8,710 |  |  | 9,871 |  |  | 113 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 10,578 |  |  | 5,206 |  |  | 5,372 |  |  | 103 |  |
| Cost of subscription revenue | 2,351 |  |  | 1,542 |  |  | 809 |  |  | 52 |  |
| Cost of service revenue | 887 |  |  | 1,065 |  |  | (178) |  |  | (17) |  |
| Total cost of revenue | 13,816 |  |  | 7,813 |  |  | 6,003 |  |  | 77 |  |
| Gross profit | 4,765 |  |  | 897 |  |  | 3,868 |  |  | 431 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,389 |  |  | 4,175 |  |  | 1,214 |  |  | 29 |  |
| Sales and marketing | 12,804 |  |  | 9,672 |  |  | 3,132 |  |  | 32 |  |
| General and administrative | 8,926 |  |  | 10,817 |  |  | (1,891) |  |  | (17) |  |
| Loss from impairment of property and equipment | 137 |  |  | 96 |  |  | 41 |  |  | 43 |  |
| Total operating expenses | 27,256 |  |  | 24,760 |  |  | 2,496 |  |  | 10 |  |
| Loss from operations | (22,491) |  |  | (23,863) |  |  | 1,372 |  |  | (6) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (654) |  |  | (142) |  |  | (512) |  |  | 361 |  |
| Interest income | 953 |  |  | 68 |  |  | 885 |  |  | 1301 | % |
| Other expense, net | 19 |  |  | — |  |  | 19 |  |  | * |
| Loss on extinguishment of debt | (626) |  |  | — |  |  | (626) |  |  | * |
| Change in fair value of contingent earn-out liability | (3,318) |  |  | 3,078 |  |  | (6,396) |  |  | (208) |  |
| Change in fair value of contingently issuable common stock liability | (742) |  |  | 1,472 |  |  | (2,214) |  |  | (150) |  |
| Change in fair value of public warrant liability | (1,750) |  |  | 5,586 |  |  | (7,336) |  |  | (131) |  |
| Total other income (expense), net | (6,118) |  |  | 10,062 |  |  | (16,180) |  |  | (161) |  |
| Net loss attributable to common stockholders – basic and diluted | $ | (28,609) |  |  | $ | (13,801) |  |  | $ | (14,808) |  |  | 107 | % |

[0001628280-23-017260:mdna:74]
[same as prior period, unchanged from 0001628280-22-029319:mdna:100]

[0001628280-23-017260:mdna:75]
6

[0001628280-23-017260:mdna:76]
[same as prior period, unchanged from 0001628280-22-029319:mdna:102]

[0001628280-23-017260:mdna:77]
[same as prior period, unchanged from 0001628280-22-029319:mdna:103]

[0001628280-23-017260:mdna:78]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Product revenue | $ | 8,754 |  |  | $ | 5,194 |  |  | $ | 3,560 |  |  | 69 | % |
| Cost of product revenue | $ | 10,578 |  |  | $ | 5,206 |  |  | $ | 5,372 |  |  | 103 | % |
| Gross profit - Product revenue | $ | (1,824) |  |  | $ | (12) |  |  | $ | (1,812) |  |  | 15100 | % |
| Gross profit margin - Product revenue | (21) | % |  | — | % |  | N/A |  | (21) | % |

[0001628280-23-017260:mdna:79]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which include ongoing increase in the adoption of Evolv Express units by schools, healthcare facilities, and professional sports arenas.

[0001628280-23-017260:mdna:80]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our product sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition of 61 new customers during the three months ended March 31, 2023 compared to 44 new customers during the three months ended March 31, 2022, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-23-017260:mdna:81]
The decrease in product gross profit and product gross profit margin during the three months ended March 31, 2023 compared to the prior year period is attributable to several factors. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, and therefore a lower gross profit margin, during the three months ended March 31, 2023 compared to the prior year period. We expect to see improvement in our gross profit margin as we continue to engineer our product with lower cost components.

[0001628280-23-017260:mdna:82]
[same as prior period, unchanged from 0001628280-22-029319:mdna:107]

[0001628280-23-017260:mdna:83]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Subscription revenue | $ | 6,466 |  |  | $ | 3,004 |  |  | $ | 3,462 |  |  | 115 | % |
| Cost of subscription revenue | $ | 2,351 |  |  | $ | 1,542 |  |  | $ | 809 |  |  | 52 | % |
| Gross profit - Subscription revenue | $ | 4,115 |  |  | $ | 1,462 |  |  | $ | 2,653 |  |  | 181 | % |
| Gross profit margin - Subscription revenue | 64 | % |  | 49 | % |  | N/A |  | 15 | % |

[0001628280-23-017260:mdna:84]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed under our pure subscription

[0001628280-23-017260:mdna:85]
contract model. Subscription gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-23-017260:mdna:86]
[same as prior period, unchanged from 0001628280-22-029319:mdna:111]

[0001628280-23-017260:mdna:87]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Service revenue | $ | 3,361 |  |  | $ | 512 |  |  | $ | 2,849 |  |  | 556 | % |
| Cost of service revenue | $ | 887 |  |  | $ | 1,065 |  |  | $ | (178) |  |  | (17) | % |
| Gross profit - Service revenue | $ | 2,474 |  |  | $ | (553) |  |  | $ | 3,027 |  |  | (547) | % |
| Gross profit margin - Service revenue | 74 | % |  | (108) | % |  | N/A |  | 182 | % |

[0001628280-23-017260:mdna:88]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding year, as well as the increase in the number of installation and training services performed. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-23-017260:mdna:89]
[same as prior period, unchanged from 0001628280-22-029319:mdna:114]

[0001628280-23-017260:mdna:90]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 3,509 |  |  | $ | 3,366 |  |  | $ | 143 |  |  | 4 | % |
| Materials and prototypes | 358 |  |  | 345 |  |  | 13 |  |  | 4 | % |
| Professional fees | 1,337 |  |  | 309 |  |  | 1,028 |  |  | 333 | % |
| Other | 185 |  |  | 155 |  |  | 30 |  |  | 19 | % |
|  | $ | 5,389 |  |  | $ | 4,175 |  |  | $ | 1,214 |  |  | 29 | % |

[0001628280-23-017260:mdna:91]
The increase in personnel related expenses is due to a modest increase in payroll costs and stock-based compensation primarily resulting from new hires in our research and development function during the past twelve months, offset by a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased. Stock compensation expense included in research and development expenses was $0.8 million for the three months ended March 31, 2023 compared to $0.5 million for the three months ended March 31, 2022. The increase in professional fees primarily relates to consulting costs incurred for product development and engineering.

[0001628280-23-017260:mdna:92]
[same as prior period, unchanged from 0001628280-22-029319:mdna:117]

[0001628280-23-017260:mdna:93]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 9,449 |  |  | $ | 6,030 |  |  | $ | 3,419 |  |  | 57 | % |
| Advertising and direct marketing | 1,215 |  |  | 1,844 |  |  | (629) |  |  | (34) | % |
| Travel and entertainment | 890 |  |  | 686 |  |  | 204 |  |  | 30 | % |
| Professional fees | 525 |  |  | 272 |  |  | 253 |  |  | 93 | % |
| Other | 725 |  |  | 840 |  |  | (115) |  |  | (14) | % |
|  | $ | 12,804 |  |  | $ | 9,672 |  |  | $ | 3,132 |  |  | 32 | % |

[0001628280-23-017260:mdna:94]
The increase in personnel related expenses is due to an increase in payroll costs, commissions and stock-based compensation resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increase sales volume. Stock compensation expense included in sales and marketing expenses was $2.0 million for the three months ended March 31, 2023 compared to $1.5 million for the three months ended March 31, 2022. The decrease in advertising and direct marketing expense is primarily due to a decrease in expense related to trade shows and events.

[0001628280-23-017260:mdna:95]
[same as prior period, unchanged from 0001628280-22-029319:mdna:120]

[0001628280-23-017260:mdna:96]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2023 |  | 2022 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 5,060 |  |  | $ | 3,946 |  |  | $ | 1,114 |  |  | 28 | % |
| Professional fees | 1,405 |  |  | 3,297 |  |  | (1,892) |  |  | (57) | % |
| Director and officer insurance | 973 |  |  | 1,250 |  |  | (277) |  |  | (22) | % |
| Non-income taxes | 90 |  |  | 474 |  |  | (384) |  |  | (81) | % |
| Other | 1,398 |  |  | 1,850 |  |  | (452) |  |  | (24) | % |
|  | $ | 8,926 |  |  | $ | 10,817 |  |  | $ | (1,891) |  |  | (17) | % |

[0001628280-23-017260:mdna:97]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $2.1 million for the three months ended March 31, 2023 compared to $1.8 million for the three months ended March 31, 2022. The decrease in professional fees is primarily related to a decrease in outsourced accounting consultancy fees. The decrease in non-income taxes relates to expense incurred during the three months ended March 31, 2022 related to a sales tax contingency liability. The decrease in other expenses is primarily due to a $0.4 million one-time payment to a former employee during the three months ended March 31, 2022.

[0001628280-23-017260:mdna:98]
[same as prior period, unchanged from 0001628280-22-029319:mdna:123]

[0001628280-23-017260:mdna:99]
Loss from impairment of property and equipment was an immaterial $0.1 million and $0.1 million for the three months ended March 31, 2023 and 2022, respectively.

[0001628280-23-017260:mdna:100]
[same as prior period, unchanged from 0001628280-22-029319:mdna:125]

[0001628280-23-017260:mdna:101]
Interest expense was $0.7 million for the three months ended March 31, 2023, compared to $0.1 million for the three months ended March 31, 2022. The increase was primarily due to interest expense incurred related to the Company's term loans with Silicon Valley Bank ("SVB") pursuant to a loan and security agreement entered into in December 2022 (the "2022 SVB Credit Agreement"). During March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement.

[0001628280-23-017260:mdna:102]
[same as prior period, unchanged from 0001628280-22-029319:mdna:127]

[0001628280-23-017260:mdna:103]
Interest income of $1.0 million for the three months ended March 31, 2023 related primarily to interest earned on money market funds. $0.1 million interest income was earned for the three months ended March 31, 2022.

[0001628280-23-017260:mdna:104]
[same as prior period, unchanged from 0001628280-22-029319:mdna:133]

[0001628280-23-017260:mdna:105]
Change in fair value of the contingent earn-out liability resulted in a $3.3 million loss and a $3.1 million gain for the three months ended March 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-23-017260:mdna:106]
[same as prior period, unchanged from 0001628280-22-029319:mdna:135]

[0001628280-23-017260:mdna:107]
Change in the fair value of the contingently issuable common stock liability resulted in a $0.7 million loss and a $1.5 million gain for the three months ended March 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-23-017260:mdna:108]
[same as prior period, unchanged from 0001628280-22-029319:mdna:139]

[0001628280-23-017260:mdna:109]
Change in the fair value of the public warrant liability resulted in a $1.8 million loss and a $5.6 million gain for the three months ended March 31, 2023 and 2022, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-23-017260:mdna:110]
[same as prior period, unchanged from 0001628280-22-029319:mdna:191]

[0001628280-23-017260:mdna:111]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. As of March 31, 2023, we had $181.0 million in cash and cash equivalents. We incurred a net loss of $28.6 million and $13.8 million for the three months ended March 31, 2023 and 2022, respectively. We incurred cash outflows from operating activities of $3.4 million and $29.4 million during the three months ended March 31, 2023 and 2022, respectively.

[0001628280-23-017260:mdna:112]
We maintain substantially all of our cash and cash equivalents in accounts with U.S. and multi-national financial institutions and our deposits at these institutions exceed Federal Deposit Insurance Corporation ("FDIC") insured limits. The Company does not believe it is exposed to any unusual credit risk or deposit concentration risk beyond the normal credit risk associated with commercial banking relationships.

[0001628280-23-017260:mdna:113]
We expect our cash and cash equivalents, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our sales and marketing team. We may require additional capital to respond to the expected growth in the demand for equipment purchases to support our "leased equipment" offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions or unforeseen circumstances and in either the short-term or long-term may determine to engage in debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as the public health emergencies, including the COVID-19 pandemic and its variants, international political turmoil, including Russia's invasion of Ukraine and related international sanctions, supply chain disruptions, the ongoing negotiations regarding the United States' federal government's debt limit, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001628280-23-017260:mdna:114]
[same as prior period, unchanged from 0001628280-22-029319:mdna:198]

[0001628280-23-017260:mdna:115]
During March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. The Company has no debt outstanding as of March 31, 2023.

[0001628280-23-017260:mdna:116]
[same as prior period, unchanged from 0001628280-22-029319:mdna:201]

[0001628280-23-017260:mdna:117]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of March 31, 2023. We anticipate fulfilling such commitments with our existing cash and cash equivalents, as well as cash and cash equivalents obtained through operations and, if necessary, proceeds from long-term debt. Cash and cash equivalents amounted to $181.0 million as of March 31, 2023.

[0001628280-23-017260:mdna:118]
We entered into a lease agreement for additional office space starting May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. We are required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space which is classified as restricted cash, non-current on the condensed consolidated balance sheet as of March 31, 2023. Total future minimum lease payments under this noncancelable operating lease amount to $1.8 million.

[0001628280-23-017260:mdna:119]
10

[0001628280-23-017260:mdna:120]
[same as prior period, unchanged from 0001628280-22-029319:mdna:204]

[0001628280-23-017260:mdna:121]
[same as prior period, unchanged from 0001628280-22-029319:mdna:205]

[0001628280-23-017260:mdna:122]
|  | Three Months EndedMarch 31, |
|  | 2023 |  | 2022 |
| Net cash used in operating activities | $ | (3,434) |  |  | $ | (29,430) |  |
| Net cash used in investing activities | (14,038) |  |  | (7,417) |  |
| Net cash provided by (used in) financing activities | (30,299) |  |  | 227 |  |
| Effect of exchange rate changes on cash and cash equivalents | (16) |  |  | — |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (47,787) |  |  | $ | (36,620) |  |

[0001628280-23-017260:mdna:123]
[same as prior period, unchanged from 0001628280-22-029319:mdna:208]

[0001628280-23-017260:mdna:124]
|  | Three Months EndedMarch 31, |
|  | 2023 |  | 2022 |
| Net loss | $ | (28,609) |  |  | $ | (13,801) |  |
| Non-cash (income) expense | 14,005 |  |  | (5,126) |  |
| Changes in operating assets and liabilities | 11,170 |  |  | (10,503) |  |
| Net cash used in operating activities | $ | (3,434) |  |  | $ | (29,430) |  |

[0001628280-23-017260:mdna:125]
Net loss increased from $13.8 million for the three months ended March 31, 2022 to $28.6 million for the three months ended March 31, 2023 primarily due to changes in the fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability. See "Results of Operations" above for further discussion.

[0001628280-23-017260:mdna:126]
Non-cash expense for the three months ended March 31, 2023 is primarily attributable to $5.0 million of stock-based compensation expense, $1.8 million of depreciation and amortization, $0.6 million of loss from extinguishment of debt, and $5.8 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability. Non-cash income for the three months ended March 31, 2022 is primarily attributable to $10.1 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability, offset by $3.9 million of stock-based compensation expense and $1.1 million of depreciation and amortization.

[0001628280-23-017260:mdna:127]
Changes in operating assets and liabilities for the three months ended March 31, 2023 are primarily related to the following:

[0001628280-23-017260:mdna:128]
•$8.6 million decrease in accounts receivable primarily due to increased collections and timing of billings to customers;

[0001628280-23-017260:mdna:129]
•$1.4 million decrease in inventory primarily due to a higher proportion of finished goods recorded as property and equipment based on our expectations of the future mix of Evolv Express units to be leased to customers versus sold to customers;

[0001628280-23-017260:mdna:130]
•$8.8 million increase in deferred revenue due to a higher volume of sales; offset by

[0001628280-23-017260:mdna:131]
•$2.2 million decrease in accounts payable (excluding the non-cash change in capital expenditures incurred but not yet paid from December 31, 2022 to March 31, 2023) primarily due to a decrease in inventory; and

[0001628280-23-017260:mdna:132]
•$4.6 million decrease in accrued expenses and other current liabilities primarily due to the payment of 2022 compensation, bonuses, and commissions during the three months ended March 31, 2023.

[0001628280-23-017260:mdna:133]
Changes in operating assets and liabilities for the three months ended March 31, 2022 are primarily related to the following:

[0001628280-23-017260:mdna:134]
•$2.1 million increase in accounts receivable primarily due to higher sales driven by an increase in customers and the timing of billings to customers;

[0001628280-23-017260:mdna:135]
•$1.3 million increase in inventory primarily due to increased production of units to meet customer demand;

[0001628280-23-017260:mdna:136]
•$5.6 million increase in prepaid expense and other current assets primarily due to prepaid deposits related to orders placed for Evolv Express units;

[0001628280-23-017260:mdna:137]
•$2.4 million decrease in accrued expenses and other current liabilities due to the payment of 2021 compensation, bonuses, and commissions paid during the three months ended March 31, 2022; offset by

[0001628280-23-017260:mdna:138]
•$2.6 million increase in deferred revenue primarily due to an increase in billings associated with higher sales.

[0001628280-23-017260:mdna:139]
[same as prior period, unchanged from 0001628280-22-029319:mdna:220]

[0001628280-23-017260:mdna:140]
During the three months ended March 31, 2023, cash used in investing activities was $14.0 million, consisting primarily of $13.4 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers, and $0.7 million for the development of internal-use software and software embedded in products to be sold or leased.

[0001628280-23-017260:mdna:141]
During the three months ended March 31, 2022, cash used in investing activities was $7.4 million, consisting of $6.7 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers, and $0.7 million for the development of internal-use software.

[0001628280-23-017260:mdna:142]
[same as prior period, unchanged from 0001628280-22-029319:mdna:223]

[0001628280-23-017260:mdna:143]
During the three months ended March 31, 2023, cash used in financing activities was $30.3 million, consisting of $1.9 million of proceeds under the 2022 SVB Credit Agreement, offset by $31.9 million related to the full repayment of amounts owed under the 2022 SVB Credit Agreement and $0.3 million payment of debt issuance costs and a prepayment penalty.

[0001628280-23-017260:mdna:144]
During the three months ended March 31, 2022, cash provided by financing activities was $0.2 million, relating entirely to the exercise of stock options.

[0001628280-23-017260:mdna:145]
[same as prior period, unchanged from 0001628280-22-029319:mdna:227]

[0001628280-23-017260:mdna:146]
There were no new accounting pronouncements that were issued or became effective since the issuance of the Company's Annual Report on Form 10-K for the year ended December 31, 2022 that had, or are expected to have, a material impact on its consolidated financial position, results of operations or cash flows.

[0001628280-23-017260:mdna:147]
[same as prior period, unchanged from 0001628280-22-029319:mdna:229]

[0001628280-23-017260:mdna:148]
Our critical accounting policies and estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” for the year ended December 31, 2022 in our Annual Report on Form 10-K. There have been no material changes to our critical accounting policies and estimates during the three months ended March 31, 2023.

[0001628280-23-017260:mdna:149]
[same as prior period, unchanged from 0001628280-22-029319:mdna:235]

[0001628280-23-017260:mdna:150]
[same as prior period, unchanged from 0001628280-22-029319:mdna:236]
