# EVLV 8-K — 0001628280-23-017243 filed 2023-05-10

## item codes, every 8-K on or before 2023-05-10

- 2023-05-10 0001628280-23-017243 — 2.02, 9.01
- 2023-04-03 0001628280-23-010402 — 1.02, 2.04, 8.01, 9.01
- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2023-05-10

- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-23-017243:8k_2_02:1]
EX-99.1
2
evlv-20230510exx991.htm
EX-99.1

[0001628280-23-017243:8k_2_02:2]
Document

[0001628280-23-017243:8k_2_02:3]
Exhibit 99.1

[0001628280-23-017243:8k_2_02:4]
Investor Relations:

[0001628280-23-017243:8k_2_02:5]
Brian Norris

[0001628280-23-017243:8k_2_02:6]
Senior Vice President of Finance and Investor Relations

[0001628280-23-017243:8k_2_02:7]
bnorris@evolvtechnology.com

[0001628280-23-017243:8k_2_02:8]
Evolv Technology Reports Record First Quarter Financial Results

[0001628280-23-017243:8k_2_02:9]
– Company Raises Outlook for 2023 –

[0001628280-23-017243:8k_2_02:10]
•Q1 Revenue of $18.6 million, up 113% year-over-year

[0001628280-23-017243:8k_2_02:11]
•Q1 Ending ARR1 of $42.0 million, up 153% year-over-year

[0001628280-23-017243:8k_2_02:12]
•Q1 Ending RPO2 of $161.8 million, up 154% year-over-year

[0001628280-23-017243:8k_2_02:13]
•Q1 Ending Evolv Express® subscriptions of 2,787, up 206% year-over-year

[0001628280-23-017243:8k_2_02:14]
Waltham, Massachusetts – May 10, 2023 – Evolv Technology (NASDAQ: EVLV), the leader in AI-based weapons detection security screening, today announced financial results for the quarter ended March 31, 2023 and raised its business outlook for 2023.

[0001628280-23-017243:8k_2_02:15]
Results for the First Quarter of 2023

[0001628280-23-017243:8k_2_02:16]
Total revenue for the first quarter of 2023 was $18.6 million, an increase of 113% compared to $8.7 million for the first quarter of 2022. Annual Recurring Revenue (“ARR”)1 was $42.0 million at the end of first quarter of 2023, an increase of 153% compared to $16.6 million at the end of the first quarter of 2022. Net loss for the first quarter of 2023 was $(28.6) million, or $(0.20) per basic and diluted share, compared to net loss of $(13.8) million, or $(0.10) per basic and diluted share, in the first quarter of 2022. Adjusted earnings (loss)3 for the first quarter of 2023 was $(16.9) million, or $(0.12) per diluted share, compared to adjusted earnings (loss)3 of  $(18.5) million, or $(0.13) per diluted share, for the first quarter of 2022. Adjusted EBITDA3 for the first quarter of 2023 was $(15.4) million compared to $(17.3) million in the first quarter of 2022. Cash and cash equivalents as of March 31, 2023 was $182 million which reflected the Company's decision to pay off its $30 million debt facility during the first quarter of 2023.  The Company had no debt as of March 31, 2023.

[0001628280-23-017243:8k_2_02:17]
The following table summarizes the breakdown of recurring and non-recurring revenue4 during each quarter:

[0001628280-23-017243:8k_2_02:18]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  | % Change |  |  |  |  |
| Recurring revenue | $ | 9,075 |  |  | $ | 3,159 |  |  | 187 | % |  |  |  |  |
| Non-recurring revenue | 9,506 |  |  | 5,551 |  |  | 71 | % |  |  |  |  |
| Total revenue | $ | 18,581 |  |  | $ | 8,710 |  |  | 113 | % |  |  |  |  |

[0001628280-23-017243:8k_2_02:19]
The following table summarizes operating cash flows during each quarter:

[0001628280-23-017243:8k_2_02:20]
|  | Three Months EndedMarch 31, |
|  | 2023 |  | 2022 |
| Net loss | $ | (28,609) |  |  | $ | (13,801) |  |
| Non-cash (income) expense | 14,005 |  |  | (5,126) |  |
| Changes in operating assets and liabilities | 11,170 |  |  | (10,503) |  |
| Net cash used in operating activities | $ | (3,434) |  |  | $ | (29,430) |  |

[0001628280-23-017243:8k_2_02:21]
Company Raises Outlook for 2023

[0001628280-23-017243:8k_2_02:22]
The Company today commented on its business outlook for 2023. The Company's outlook is based on the current indications for its business, which may change at any time.

[0001628280-23-017243:8k_2_02:23]
|  |  | 2023 Business Outlook |
| Estimate (In millions) |  | Issued March 1, 2023 |  | Issued May 10, 2023 |
| Total Revenue |  | $55-$60 |  | $60-$65 |
| Annual Recurring Revenue1 (ARR) at 12/31/23 |  | $65-$70 |  | $67-$71 |
| Adjusted Gross Margin3 |  | 30%-35% |  | 35%-40% |
| Adjusted EBITDA3 |  | ($55-$60) |  | ($53-$58) |

[0001628280-23-017243:8k_2_02:24]
Company to Host Live Conference Call and Webcast

[0001628280-23-017243:8k_2_02:25]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business and other matters.  The conference call may be accessed in the United States by dialing +1.877.692.8955 and using access code 825879.  The conference call may be accessed outside of the United States by dialing +1.234.720.6979 and using the same access code. The conference call will be simultaneously webcast on the Company’s investor relations website, which can be accessed at http://ir.evolvtechnology.com.  A replay of the conference call will be available for a period of 30 days by dialing +1.866.207.1041 or +1.402.970.0847 and using access code 9795540 or by accessing the webcast replay on the Company’s investor relations website at http://ir.evolvtechnology.com.

[0001628280-23-017243:8k_2_02:26]
About Evolv Technology

[0001628280-23-017243:8k_2_02:27]
Evolv Technology (NASDAQ: EVLV) is transforming human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered weapons detection and analytics. Its mission is to transform security to create a safer world to work, learn, and play. Evolv has digitally transformed the gateways in places where people gather by enabling seamless integration combined with powerful analytics and insights. Evolv’s advanced systems have scanned more than 600 million people, second only to the Department of Homeland Security’s Transportation Security Administration (TSA) in the United States. Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category. Evolv Technology®, Evolv Express®, Evolv Insights®, and Evolv Cortex AI® are registered trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit https://evolvtechnology.com.

[0001628280-23-017243:8k_2_02:28]
1 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001628280-23-017243:8k_2_02:29]
2 We define Remaining Performance Obligation, or RPO, as estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied or partially satisfied as of the end of the quarter.

[0001628280-23-017243:8k_2_02:30]
3 Non-GAAP Financial Measures In this press release, the Company’s adjusted operating expenses, adjusted gross profit (loss), adjusted gross margin, adjusted operating income (loss), adjusted EBITDA, adjusted earnings (loss), and adjusted earnings per share-diluted are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit and adjusted gross margin exclude one-time items including stock-based compensation expense which management believes provides a more meaningful representation of contribution margin. Adjusted operating expenses is defined as operating expenses less one-time items including stock-based compensation expense, restructuring expenses, and loss on impairment of lease equipment which management believes provides a more meaningful representation of on-going operating expense levels. Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, share-based compensation, and certain other one-time expenses. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, change in fair value of derivative liability, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, change in fair value of common stock warrant liability, restructuring expenses, loss on impairment of lease equipment, and certain other one-time expenses. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release. The Company is unable to provide a reconciliation of Adjusted Gross Margin to GAAP Gross Margin and non-GAAP Adjusted EBITDA to Net Income (Loss), each measure's most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact these GAAP financial measures are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of derivative liabilities, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001628280-23-017243:8k_2_02:31]
4 Recurring revenue includes the recurring portion of revenue associated with pure subscription contracts and hardware purchase subscription contracts. Non-recurring revenue includes revenue that is one-time in nature, such as product revenue, shipping revenue, and revenue from installation, training, and professional services.

[0001628280-23-017243:8k_2_02:32]
Forward-Looking Statements

[0001628280-23-017243:8k_2_02:33]
EVOLV TECHNOLOGY

[0001628280-23-017243:8k_2_02:34]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001628280-23-017243:8k_2_02:35]
(In thousands, except share and per share data)

[0001628280-23-017243:8k_2_02:36]
(Unaudited)

[0001628280-23-017243:8k_2_02:37]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 8,754 |  |  | $ | 5,194 |  |  |  |  |  |
| Subscription revenue | 6,466 |  |  | 3,004 |  |  |  |  |  |
| Service revenue | 3,361 |  |  | 512 |  |  |  |  |  |
| Total revenue | 18,581 |  |  | 8,710 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 10,578 |  |  | 5,206 |  |  |  |  |  |
| Cost of subscription revenue | 2,351 |  |  | 1,542 |  |  |  |  |  |
| Cost of service revenue | 887 |  |  | 1,065 |  |  |  |  |  |
| Total cost of revenue | 13,816 |  |  | 7,813 |  |  |  |  |  |
| Gross profit | 4,765 |  |  | 897 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,389 |  |  | 4,175 |  |  |  |  |  |
| Sales and marketing | 12,804 |  |  | 9,672 |  |  |  |  |  |
| General and administrative | 8,926 |  |  | 10,817 |  |  |  |  |  |
| Loss from impairment of property and equipment | 137 |  |  | 96 |  |  |  |  |  |
| Total operating expenses | 27,256 |  |  | 24,760 |  |  |  |  |  |
| Loss from operations | (22,491) |  |  | (23,863) |  |  |  |  |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (654) |  |  | (142) |  |  |  |  |  |
| Interest income | 953 |  |  | 68 |  |  |  |  |  |
| Other expense, net | 19 |  |  | — |  |  |  |  |  |
| Loss on extinguishment of debt | (626) |  |  | — |  |  |  |  |  |
| Change in fair value of contingent earn-out liability | (3,318) |  |  | 3,078 |  |  |  |  |  |
| Change in fair value of contingently issuable common stock liability | (742) |  |  | 1,472 |  |  |  |  |  |
| Change in fair value of public warrant liability | (1,750) |  |  | 5,586 |  |  |  |  |  |
| Total other income (expense), net | (6,118) |  |  | 10,062 |  |  |  |  |  |
| Net loss | $ | (28,609) |  |  | $ | (13,801) |  |  |  |  |  |
| Weighted average common shares outstanding – basic and diluted | 146,433,378 |  |  | 142,878,406 |  |  |  |  |  |
| Net loss per share - basic and diluted | $ | (0.20) |  |  | $ | (0.10) |  |  |  |  |  |
| Net loss | $ | (28,609) |  |  | $ | (13,801) |  |  |  |  |  |
| Other comprehensive income (loss) |  |  |  |  |  |  |  |
| Cumulative translation adjustment | (16) |  |  | — |  |  |  |  |  |
| Total other comprehensive loss | (16) |  |  | — |  |  |  |  |  |
| Total comprehensive loss | $ | (28,625) |  |  | $ | (13,801) |  |  |  |  |  |

[0001628280-23-017243:8k_2_02:38]
EVOLV TECHNOLOGY

[0001628280-23-017243:8k_2_02:39]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-23-017243:8k_2_02:40]
(In thousands, except share and per share data)

[0001628280-23-017243:8k_2_02:41]
(Unaudited)

[0001628280-23-017243:8k_2_02:42]
|  | March 31, 2023 |  | December 31, 2022 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 180,996 |  |  | $ | 229,783 |  |
| Restricted cash | 1,000 |  |  | — |  |
| Accounts receivable, net | 23,156 |  |  | 31,920 |  |
| Inventory | 8,816 |  |  | 10,257 |  |
| Current portion of contract assets | 3,265 |  |  | 2,852 |  |
| Current portion of commission asset | 3,293 |  |  | 3,384 |  |
| Prepaid expenses and other current assets | 14,413 |  |  | 14,388 |  |
| Total current assets | 234,939 |  |  | 292,584 |  |
| Restricted cash, noncurrent | 275 |  |  | 275 |  |
| Contract assets, noncurrent | 715 |  |  | 1,386 |  |
| Commission asset, noncurrent | 6,390 |  |  | 5,655 |  |
| Property and equipment, net | 59,789 |  |  | 44,707 |  |
| Operating lease right-of-use assets | 1,459 |  |  | 1,673 |  |
| Other assets | 1,965 |  |  | 1,835 |  |
| Total assets | $ | 305,532 |  |  | $ | 348,115 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 19,192 |  |  | $ | 18,194 |  |
| Accrued expenses and other current liabilities | 6,477 |  |  | 11,545 |  |
| Current portion of deferred revenue | 23,977 |  |  | 18,273 |  |
| Current portion of long-term debt | — |  |  | 10,000 |  |
| Current portion of operating lease liabilities | 1,122 |  |  | 1,114 |  |
| Total current liabilities | 50,768 |  |  | 59,126 |  |
| Deferred revenue, noncurrent | 20,748 |  |  | 17,695 |  |
| Long-term debt, noncurrent | — |  |  | 19,683 |  |
| Operating lease liabilities, noncurrent | 630 |  |  | 892 |  |
| Contingent earn-out liability | 17,536 |  |  | 14,218 |  |
| Contingently issuable common stock liability | 4,134 |  |  | 3,392 |  |
| Public warrant liability | 7,874 |  |  | 6,124 |  |
| Total liabilities | 101,690 |  |  | 121,130 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at March 31, 2023 and December 31, 2022; no shares issued and outstanding at March 31, 2023 and December 31, 2022 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at March 31, 2023 and December 31, 2022; 147,977,034 and 145,204,974 shares issued and outstanding at March 31, 2023 and December 31, 2022, respectively | 15 |  |  | 15 |  |
| Additional paid-in capital | 424,672 |  |  | 419,190 |  |
| Accumulated other comprehensive loss | (26) |  |  | (10) |  |
| Accumulated deficit | (220,819) |  |  | (192,210) |  |
| Stockholders’ equity | 203,842 |  |  | 226,985 |  |
| Total liabilities and stockholders’ equity | $ | 305,532 |  |  | $ | 348,115 |  |

[0001628280-23-017243:8k_2_02:43]
EVOLV TECHNOLOGY

[0001628280-23-017243:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-23-017243:8k_2_02:45]
(In thousands)

[0001628280-23-017243:8k_2_02:46]
(Unaudited)

[0001628280-23-017243:8k_2_02:47]
|  | Three Months EndedMarch 31, |
|  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (28,609) |  |  | $ | (13,801) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 1,815 |  |  | 1,086 |  |
| Write-off of inventory and change in inventory reserve | 214 |  |  | 324 |  |
| Adjustment to property and equipment for sales type leases | — |  |  | (625) |  |
| Loss from impairment of property and equipment | 137 |  |  | 96 |  |
| Stock-based compensation | 5,043 |  |  | 3,927 |  |
| Non-cash interest expense | 22 |  |  | 5 |  |
| Non-cash lease expense | 214 |  |  | 197 |  |
| Change in allowance for expected credit losses | 124 |  |  | — |  |
| Loss on extinguishment of debt | 626 |  |  | — |  |
| Change in fair value of earn-out liability | 3,318 |  |  | (3,078) |  |
| Change in fair value of contingently issuable common stock | 742 |  |  | (1,472) |  |
| Change in fair value of public warrant liability | 1,750 |  |  | (5,586) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | 8,640 |  |  | (2,112) |  |
| Inventory | 1,418 |  |  | (1,310) |  |
| Commission assets | (644) |  |  | (351) |  |
| Contract assets | 258 |  |  | 108 |  |
| Other assets | (130) |  |  | 141 |  |
| Prepaid expenses and other current assets | (25) |  |  | (5,571) |  |
| Accounts payable | (2,213) |  |  | (855) |  |
| Deferred revenue | 8,757 |  |  | 2,577 |  |
| Accrued expenses and other current liabilities | (4,637) |  |  | (2,433) |  |
| Operating lease liability | (254) |  |  | (697) |  |
| Net cash used in operating activities | (3,434) |  |  | (29,430) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (733) |  |  | (728) |  |
| Purchases of property and equipment | (13,365) |  |  | (6,689) |  |
| Proceeds from sale of property and equipment | 60 |  |  | — |  |
| Net cash used in investing activities | (14,038) |  |  | (7,417) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 33 |  |  | 227 |  |
| Proceeds from long-term debt | 1,876 |  |  | — |  |
| Repayment of principal on long-term debt | (31,876) |  |  | — |  |
| Payment of debt issuance costs and prepayment penalty | (332) |  |  | — |  |
| Net cash provided by (used in) financing activities | (30,299) |  |  | 227 |  |
| Effect of exchange rate changes on cash and cash equivalents | (16) |  |  | — |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (47,787) |  |  | (36,620) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 230,058 |  |  | 308,167 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 182,271 |  |  | $ | 271,547 |  |

[0001628280-23-017243:8k_2_02:48]
EVOLV TECHNOLOGY

[0001628280-23-017243:8k_2_02:49]
REVISION OF PRIOR PERIOD FINANCIAL STATEMENTS

[0001628280-23-017243:8k_2_02:50]
(In thousands)

[0001628280-23-017243:8k_2_02:51]
(Unaudited)

[0001628280-23-017243:8k_2_02:52]
In preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified various errors in its previously issued financial statements. The identified errors impacted the Company's previously issued quarterly financial statements for the three months ended March 31, 2022, and accordingly the Company has made adjustments to the prior period amounts presented herein. Additionally, the Company has made adjustments to correct for other previously identified immaterial errors. The Company evaluated the errors and determined that the related impacts were not material to any previously issued annual or interim financial statements. The impact of the revisions to the quarterly period ending March 31, 2022 is presented as follows (in thousands):

[0001628280-23-017243:8k_2_02:53]
|  | Three Months EndedMarch 31, 2022 |
|  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |
| Product revenue | $ | 5,194 |  |  | $ | — |  |  | $ | 5,194 |  |
| Subscription revenue | 3,020 |  |  | (16) |  |  | 3,004 |  |
| Service revenue | 501 |  |  | 11 |  |  | 512 |  |
| Total revenue | 8,715 |  |  | (5) |  |  | 8,710 |  |
| Cost of revenue: |  |  |  |  |  |
| Cost of product revenue | 5,576 |  |  | (370) |  |  | 5,206 |  |
| Cost of subscription revenue | 1,065 |  |  | 477 |  |  | 1,542 |  |
| Cost of service revenue | 448 |  |  | 617 |  |  | 1,065 |  |
| Total cost of revenue | 7,089 |  |  | 724 |  |  | 7,813 |  |
| Gross profit | 1,626 |  |  | (729) |  |  | 897 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 4,286 |  |  | (111) |  |  | 4,175 |  |
| Sales and marketing expense | 12,053 |  |  | (2,381) |  |  | 9,672 |  |
| General and administrative | 11,093 |  |  | (276) |  |  | 10,817 |  |
| Loss from impairment of property and equipment | 96 |  |  | — |  |  | 96 |  |
| Total operating expenses | 27,528 |  |  | (2,768) |  |  | 24,760 |  |
| Loss from operations | (25,902) |  |  | 2,039 |  |  | (23,863) |  |
| Other income (expense), net: |  |  |  |  |  |
| Interest expense | (142) |  |  | — |  |  | (142) |  |
| Interest income | 209 |  |  | (141) |  |  | 68 |  |
| Change in fair value of contingent earn-out liability | 4,226 |  |  | (1,148) |  |  | 3,078 |  |
| Change in fair value of contingently issuable common stock liability | 1,472 |  |  | — |  |  | 1,472 |  |
| Change in fair value of public warrant liability | 5,586 |  |  | — |  |  | 5,586 |  |
| Total other income (expense), net | 11,351 |  |  | (1,289) |  |  | 10,062 |  |
| Net loss | $ | (14,551) |  |  | $ | 750 |  |  | $ | (13,801) |  |
| Weighted average common shares outstanding - basic and diluted | 142,878,406 |  |  | — |  |  | 142,878,406 |  |
| Net loss per share - basic and diluted | $ | (0.10) |  |  | $ | — |  |  | $ | (0.10) |  |

[0001628280-23-017243:8k_2_02:54]
|  | Three Months EndedMarch 31, 2022 |
|  | As Previously Reported | Adjustment | As Revised |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (14,551) |  | $ | 750 |  | $ | (13,801) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 948 |  | 138 |  | 1,086 |  |
| Write-off of inventory | 324 |  | — |  | 324 |  |
| Adjustment to property and equipment for sales type leases | (321) |  | (304) |  | (625) |  |
| Loss from impairment of property and equipment | 96 |  | — |  | 96 |  |
| Stock-based compensation | 5,190 |  | (1,263) |  | 3,927 |  |
| Non-cash interest expense | 5 |  | — |  | 5 |  |
| Non-cash lease expense | 197 |  | — |  | 197 |  |
| Change in fair value of earn-out liability | (4,226) |  | 1,148 |  | (3,078) |  |
| Change in fair value of contingently issuable common stock | (1,472) |  | — |  | (1,472) |  |
| Change in fair value of public warrant liability | (5,586) |  | — |  | (5,586) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (2,112) |  | — |  | (2,112) |  |
| Inventory | (6,985) |  | 5,675 |  | (1,310) |  |
| Commission assets | (351) |  | — |  | (351) |  |
| Contract assets | 108 |  | — |  | 108 |  |
| Other assets | — |  | 141 |  | 141 |  |
| Prepaid expenses and other current assets | (5,280) |  | (291) |  | (5,571) |  |
| Accounts payable | (1,867) |  | 1,012 |  | (855) |  |
| Deferred revenue | 2,778 |  | (201) |  | 2,577 |  |
| Deferred rent | (468) |  | 468 |  | — |  |
| Accrued expenses and other current liabilities | (2,065) |  | (368) |  | (2,433) |  |
| Operating lease liability | (229) |  | (468) |  | (697) |  |
| Net cash used in operating activities | (35,867) |  | 6,437 |  | (29,430) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (646) |  | (82) |  | (728) |  |
| Purchases of property and equipment | (323) |  | (6,366) |  | (6,689) |  |
| Net cash used in investing activities | (969) |  | (6,448) |  | (7,417) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 216 |  | 11 |  | 227 |  |
| Net cash provided by financing activities | 216 |  | 11 |  | 227 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (36,620) |  | — |  | (36,620) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 308,167 |  | — |  | 308,167 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 271,547 |  | $ | — |  | $ | 271,547 |  |
| Supplemental disclosure of non-cash activities |  |  |  |
| Transfer of inventory to property and equipment | $ | 4,620 |  | $ | (4,620) |  | $ | — |  |
| Capital expenditures incurred but not yet paid | 1,693 |  | 698 |  | 2,391 |  |

[0001628280-23-017243:8k_2_02:55]
EVOLV TECHNOLOGY

[0001628280-23-017243:8k_2_02:56]
SUMMARY OF KEY OPERATING STATISTICS

[0001628280-23-017243:8k_2_02:57]
(Unaudited)

[0001628280-23-017243:8k_2_02:58]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |  | December 31,2022 |  | March 31,2023 |  |  |  |  |  |  |
| New customers |  | 44 |  |  | 53 |  |  | 92 |  |  | 106 |  |  | 61 |  |  |  |  |  |  |  |
| Annual recurring revenue |  | $ | 16,641 |  |  | $ | 20,865 |  |  | $ | 28,741 |  |  | $ | 34,120 |  |  | $ | 42,021 |  |  |  |  |  |  |  |
| Recurring revenue |  | $ | 3,159 |  |  | $ | 4,604 |  |  | $ | 6,221 |  |  | $ | 7,388 |  |  | $ | 9,075 |  |  |  |  |  |  |  |
| Remaining performance obligation |  | $ | 63,750 |  |  | $ | 80,978 |  |  | $ | 109,407 |  |  | $ | 144,561 |  |  | $ | 161,813 |  |  |  |  |  |  |  |
| Net additions |  | 207 |  |  | 237 |  |  | 545 |  |  | 575 |  |  | 520 |  |  |  |  |  |  |  |
| Ending deployed units |  | 910 |  |  | 1,147 |  |  | 1,692 |  |  | 2,267 |  |  | 2,787 |  |  |  |  |  |  |  |

[0001628280-23-017243:8k_2_02:59]
EVOLV TECHNOLOGY

[0001628280-23-017243:8k_2_02:60]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001628280-23-017243:8k_2_02:61]
(In thousands)

[0001628280-23-017243:8k_2_02:62]
(Unaudited)

[0001628280-23-017243:8k_2_02:63]
|  | Three Months Ended, |  |  |  |
|  |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |  | December 31,2022 |  | March 31,2023 |  |  |  |  |  |  |
| Operating expenses, GAAP |  | $ | 24,760 |  |  | $ | 25,835 |  |  | $ | 26,827 |  |  | $ | 26,868 |  |  | $ | 27,256 |  |  |  |  |  |  |  |
| Stock-based compensation |  | (3,819) |  |  | (4,781) |  |  | (6,298) |  |  | (6,771) |  |  | (4,898) |  |  |  |  |  |  |  |
| Restructuring expenses |  | (324) |  |  | 13 |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Loss on impairment of lease equipment |  | (96) |  |  | (316) |  |  | (626) |  |  | (123) |  |  | (137) |  |  |  |  |  |  |  |
| Other one-time expenses |  | (1,107) |  |  | (2,298) |  |  | (69) |  |  | (41) |  |  | (53) |  |  |  |  |  |  |  |
| Adjusted Operating Expenses |  | $ | 19,414 |  |  | $ | 18,453 |  |  | $ | 19,834 |  |  | $ | 19,933 |  |  | $ | 22,168 |  |  |  |  |  |  |  |

[0001628280-23-017243:8k_2_02:64]
EVOLV TECHNOLOGY

[0001628280-23-017243:8k_2_02:65]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT, GAAP GROSS MARGIN TO ADJUSTED GROSS MARGIN AND GAAP OPERATING INCOME (LOSS) TO ADJUSTED OPERATING INCOME (LOSS)

[0001628280-23-017243:8k_2_02:66]
(In thousands)

[0001628280-23-017243:8k_2_02:67]
(Unaudited)

[0001628280-23-017243:8k_2_02:68]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Revenue | $ | 18,581 |  |  | $ | 8,710 |  |  |  |  |  |
| Cost of revenue | 13,816 |  |  | 7,813 |  |  |  |  |  |
| Gross Profit, GAAP | 4,765 |  |  | 897 |  |  |  |  |  |
| Stock-based compensation | 145 |  |  | 108 |  |  |  |  |  |
| Amortization of capitalized stock-based compensation | 10 |  |  | 3 |  |  |  |  |  |
| Adjusted Gross Profit | $ | 4,920 |  |  | $ | 1,008 |  |  |  |  |  |
| Gross Margin % | 25.6 | % |  | 10.3 | % |  |  |  |  |
| Adjusted Gross Margin % | 26.5 | % |  | 11.6 | % |  |  |  |  |

[0001628280-23-017243:8k_2_02:69]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Operating income (loss), GAAP | $ | (22,491) |  |  | $ | (23,863) |  |  |  |  |  |
| Stock-based compensation | 5,043 |  |  | 3,927 |  |  |  |  |  |
| Amortization of capitalized stock-based compensation | 10 |  |  | 3 |  |  |  |  |  |
| Restructuring expenses | — |  |  | 324 |  |  |  |  |  |
| Loss on impairment of lease equipment | 137 |  |  | 96 |  |  |  |  |  |
| Other one-time expenses | 53 |  |  | 1,107 |  |  |  |  |  |
| Adjusted Operating Income (Loss) | $ | (17,248) |  |  | $ | (18,406) |  |  |  |  |  |

[0001628280-23-017243:8k_2_02:70]
EVOLV TECHNOLOGY

[0001628280-23-017243:8k_2_02:71]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-23-017243:8k_2_02:72]
(In thousands)

[0001628280-23-017243:8k_2_02:73]
(Unaudited)

[0001628280-23-017243:8k_2_02:74]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Net loss | $ | (28,609) |  |  | $ | (13,801) |  |  |  |  |  |
| Depreciation & amortization | 1,815 |  |  | 1,086 |  |  |  |  |  |
| Stock-based compensation | 5,043 |  |  | 3,927 |  |  |  |  |  |
| Interest expense (income) | (299) |  |  | 74 |  |  |  |  |  |
| Loss on disposal of property & equipment | — |  |  | — |  |  |  |  |  |
| Loss on extinguishment of debt | 626 |  |  | — |  |  |  |  |  |
| Change in fair value of contingent earn-out liability | 3,318 |  |  | (3,078) |  |  |  |  |  |
| Change in fair value of contingently issuable common stock liability | 742 |  |  | (1,472) |  |  |  |  |  |
| Change in fair value of public warrant liability | 1,750 |  |  | (5,586) |  |  |  |  |  |
| Restructuring expenses | — |  |  | 324 |  |  |  |  |  |
| Loss on impairment of lease equipment | 137 |  |  | 96 |  |  |  |  |  |
| Other one-time expenses | 53 |  |  | 1,107 |  |  |  |  |  |
| Adjusted EBITDA | $ | (15,424) |  |  | $ | (17,323) |  |  |  |  |  |

[0001628280-23-017243:8k_2_02:75]
EVOLV TECHNOLOGY

[0001628280-23-017243:8k_2_02:76]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001628280-23-017243:8k_2_02:77]
(In thousands, except share and per share data)

[0001628280-23-017243:8k_2_02:78]
(Unaudited)

[0001628280-23-017243:8k_2_02:79]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Net loss | $ | (28,609) |  |  | $ | (13,801) |  |  |  |  |  |
| Stock-based compensation | 5,043 |  |  | 3,927 |  |  |  |  |  |
| Amortization of capitalized stock-based compensation | 10 |  |  | 3 |  |  |  |  |  |
| Loss on extinguishment of debt | 626 |  |  | — |  |  |  |  |  |
| Change in fair value of contingent earn-out liability | 3,318 |  |  | (3,078) |  |  |  |  |  |
| Change in fair value of contingently issuable common stock liability | 742 |  |  | (1,472) |  |  |  |  |  |
| Change in fair value of public warrant liability | 1,750 |  |  | (5,586) |  |  |  |  |  |
| Restructuring expenses | — |  |  | 324 |  |  |  |  |  |
| Loss on impairment of lease equipment | 137 |  |  | 96 |  |  |  |  |  |
| Other one-time expenses | 53 |  |  | 1,107 |  |  |  |  |  |
| Adjusted Earnings (Loss) | $ | (16,930) |  |  | $ | (18,480) |  |  |  |  |  |
| Weighted average common shares outstanding – diluted | 146,433,378 |  |  | 142,878,406 |  |  |  |  |  |
| Adjusted Earnings (Loss) Per Share – diluted | $ | (0.12) |  |  | $ | (0.13) |  |  |  |  |  |
