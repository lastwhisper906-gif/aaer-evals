# EVLV notes — 0001628280-23-017260


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-23-017260:notes:1]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to live, work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to better address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks in a cost-effective manner while improving safety and the visitor experience. The Company is headquartered in Waltham, Massachusetts.

[0001628280-23-017260:notes:2]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly-owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC.

[0001628280-23-017260:notes:3]
[same as prior period, unchanged from 0001628280-22-029319:notes:3]

[0001628280-23-017260:notes:4]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001628280-23-017260:notes:5]
[same as prior period, unchanged from 0001628280-22-029319:notes:6]

[0001628280-23-017260:notes:6]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2023, and for the three months ended March 31, 2023 and 2022 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2022 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2023 and the results of its operations for the three months ended March 31, 2023 and 2022 and cash flows for the three months ended March 31, 2023 and 2022. The results for the three months ended March 31, 2023 are not necessarily indicative of results to be expected for the year ending December 31, 2023, any other interim periods, or any future year or period.

[0001628280-23-017260:notes:7]
Merger

[0001628280-23-017260:notes:8]
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the Merger as a wholly-owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001628280-23-017260:notes:9]
[same as prior period, unchanged from 0001628280-22-029319:notes:8]

[0001628280-23-017260:notes:10]
In preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified errors in its previously issued financial statements whereby (a) certain expenses that were cost of subscription revenue related and cost of service revenue related were inaccurately classified as sales and marketing expenses on the consolidated statements of operations and comprehensive loss, (b) certain equipment under lease or held for lease was inaccurately classified as inventory on the consolidated balance sheets and a portion of the cash outflows related to the equipment under lease or held for lease were misclassified between operating and investing cash flows on the consolidated statements of cash flows, and (c) the vesting of warrants related to the Business Development Agreement 
disclosed in Note 9 were not accounted for accurately. The identified errors impacted the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022. The Company has made adjustments to the prior period amounts presented in these financial statements accordingly. Additionally, the Company has made adjustments to correct for other previously identified immaterial errors. The Company evaluated the errors and determined that the related impacts were not material to any previously issued annual or interim financial statements. The impact of the revisions to the quarterly period ended March 31, 2022 is presented in Note 14.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-23-017260:notes:11]
[same as prior period, unchanged from 0001628280-22-029319:notes:10]

[0001628280-23-017260:notes:12]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2022, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2022. There have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2023.

[0001628280-23-017260:notes:13]
Recently Adopted Accounting Pronouncements

[0001628280-23-017260:notes:14]
[same as prior period, unchanged from 0001628280-22-029319:notes:33]

[0001628280-23-017260:notes:15]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have a material impact on its consolidated financial statements and related disclosures.

[0001628280-23-017260:notes:16]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company adopted this guidance effective January 1, 2023, and the adoption of this guidance did not have an impact on its consolidated financial statements and related disclosures.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-23-017260:notes:17]
[same as prior period, unchanged from 0001628280-22-029319:notes:53]

[0001628280-23-017260:notes:18]
|  | Fair Value Measurements at March 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 17 |  |  | $ | — |  |  | $ | — |  |  | $ | 17 |  |
|  | $ | 17 |  |  | $ | — |  |  | $ | — |  |  | $ | 17 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 17,536 |  |  | $ | 17,536 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 4,134 |  |  | 4,134 |  |
| Public Warrant liability | 7,874 |  |  | — |  |  | — |  |  | 7,874 |  |
|  | $ | 7,874 |  |  | $ | — |  |  | $ | 21,670 |  |  | $ | 29,544 |  |

[0001628280-23-017260:notes:19]
|  | Fair Value Measurements as of December 31, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 149,971 |  |  | $ | — |  |  | $ | — |  |  | $ | 149,971 |  |
|  | $ | 149,971 |  |  | $ | — |  |  | $ | — |  |  | $ | 149,971 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 14,218 |  |  | $ | 14,218 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 3,392 |  |  | 3,392 |  |
| Public Warrant liability | 6,124 |  |  | — |  |  | — |  |  | 6,124 |  |
|  | $ | 6,124 |  |  | $ | — |  |  | $ | 17,610 |  |  | $ | 23,734 |  |

[0001628280-23-017260:notes:20]
Money market funds are included in cash and cash equivalents on the condensed consolidated balance sheets. The Company may also value its non-financial assets and liabilities, including items such as inventories and property and equipment, at fair value on a non-recurring basis if it is determined that impairment has occurred. Such fair value measurements use significant unobservable inputs and are classified as Level 3.

[0001628280-23-017260:notes:21]
During each of the three months ended March 31, 2023 and 2022, there were no transfers between Level 1, Level 2 and Level 3.

[0001628280-23-017260:notes:22]
[same as prior period, unchanged from 0001628280-22-029319:notes:58]

[0001628280-23-017260:notes:23]
Pursuant to the Merger Agreement, the Legacy Evolv shareholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2022. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of March 31, 2023, no milestones have been achieved.

[0001628280-23-017260:notes:24]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of March 31, 2023 were as follows: 90% expected stock price volatility, a risk-free rate of return of 3.8%, a 25% likelihood of change in control and a remaining term of 2.9 years.

[0001628280-23-017260:notes:25]
[same as prior period, unchanged from 0001628280-22-029319:notes:62]

[0001628280-23-017260:notes:26]
| Balance at December 31, 2022 | $ | 14,218 |
| Change in fair value | 3,318 |
| Balance at March 31, 2023 | $ | 17,536 |

[0001628280-23-017260:notes:27]
[same as prior period, unchanged from 0001628280-22-029319:notes:64]

[0001628280-23-017260:notes:28]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 shares of NHIC Class B common stock (the "Founder Shares"). Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 517,500 Founder Shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 outstanding Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2022. The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of March 31, 2023, no milestones have been achieved.

[0001628280-23-017260:notes:29]
The fair value of the contingently issued common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of March 31, 2023 were as follows: 90% expected stock price volatility, a risk-free rate of return of 3.8%, a 25% likelihood of change in control and a remaining term of 3.3 years.

[0001628280-23-017260:notes:30]
[same as prior period, unchanged from 0001628280-22-029319:notes:67]

[0001628280-23-017260:notes:31]
| Balance at December 31, 2022 | $ | 3,392 |  |
| Change in fair value | 742 |  |
| Balance at March 31, 2023 | $ | 4,134 |  |

[0001628280-23-017260:notes:32]
[same as prior period, unchanged from 0001628280-22-029319:notes:69]

[0001628280-23-017260:notes:33]
In connection with the closing of the Merger, the Company assumed warrants (the "Public Warrants") to purchase 14,325,000 shares of common stock at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. None of the Public Warrants have been exercised as of March 31, 2023.

[0001628280-23-017260:notes:34]
[same as prior period, unchanged from 0001628280-22-029319:notes:71]

[0001628280-23-017260:notes:35]
| Balance at December 31, 2022 | $ | 6,124 |
| Change in fair value | 1,750 |  |
| Balance at March 31, 2023 | $ | 7,874 |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-23-017260:notes:36]
Revenue RecognitionThe Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the 
contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

[0001628280-23-017260:notes:37]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases under ASC 842 and (2) from the sale of products, inclusive of SaaS and maintenance and (3) professional services. The Company’s arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax.

[0001628280-23-017260:notes:38]
[same as prior period, unchanged from 0001628280-22-029319:notes:75]

[0001628280-23-017260:notes:39]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2023.

[0001628280-23-017260:notes:40]
|  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue | $ | 5,435 |  |  | $ | — |  |  | $ | 5,435 |  |
| Subscription revenue | 31,659 |  |  | 67,413 |  |  | 99,072 |  |
| Service revenue | 15,930 |  |  | 41,376 |  |  | 57,306 |  |
| Total revenue | $ | 53,024 |  |  | $ | 108,789 |  |  | $ | 161,813 |  |

[0001628280-23-017260:notes:41]
The amount of minimum future leases is based on expected income recognition. As of March 31, 2023, future minimum payments on noncancelable leases are as follows (in thousands):

[0001628280-23-017260:notes:42]
| Year Ending December 31: |  |
| 2023 (nine months remaining) | $ | 23,898 |  |
| 2024 | 30,446 |  |
| 2025 | 26,586 |  |
| 2026 | 16,060 |  |
| 2027 | 2,065 |  |
| Thereafter | 17 |  |
|  | $ | 99,072 |  |

[0001628280-23-017260:notes:43]
[same as prior period, unchanged from 0001628280-22-029319:notes:80]

[0001628280-23-017260:notes:44]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of March 31, 2023 and December 31, 2022, the Company had $3.3 million and $2.9 million in current portion of contract assets and $0.7 million and $1.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001628280-23-017260:notes:45]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $6.9 million during the three months ended March 31, 2023 that was included in the December 31, 2022 deferred revenue balance. The Company recognized revenue of $2.5 million during the three months ended March 31, 2022 that was included in the December 31, 2021 deferred revenue balance.

[0001628280-23-017260:notes:46]
[same as prior period, unchanged from 0001628280-22-029319:notes:84]

[0001628280-23-017260:notes:47]
| Balance at December 31, 2022 | $ | 35,968 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (6,887) |  |
| Revenue deferred | 15,644 |  |
| Balance at March 31, 2023 | $ | 44,725 |  |

[0001628280-23-017260:notes:48]
[same as prior period, unchanged from 0001628280-22-029319:notes:86]

[0001628280-23-017260:notes:49]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Revenue from sales-type leases | $ | — |  |  | $ | 1,106 |  |  |  |  |  |
| Interest income on lease receivables | 53 |  |  | 49 |  |  |  |  |  |
| Lease income - operating leases | 6,466 |  |  | 3,004 |  |  |  |  |  |
| Total lease revenue | $ | 6,519 |  |  | $ | 4,159 |  |  |  |  |  |

[0001628280-23-017260:notes:50]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified as other income (expense), net in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.2 million and $0.1 million during the three months ended March 31, 2023 and 2022, respectively.

[0001628280-23-017260:notes:51]
[same as prior period, unchanged from 0001628280-22-029319:notes:89]

[0001628280-23-017260:notes:52]
[same as prior period, unchanged from 0001628280-22-029319:notes:90]

[0001628280-23-017260:notes:53]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Product revenue | $ | 8,754 |  |  | $ | 5,194 |  |  |  |  |  |
| Leased equipment | 6,466 |  |  | 3,004 |  |  |  |  |  |
| SaaS, maintenance, and other revenue | 2,778 |  |  | 368 |  |  |  |  |  |
| Professional services | 583 |  |  | 144 |  |  |  |  |  |
| Total revenue | $ | 18,581 |  |  | $ | 8,710 |  |  |  |  |  |

[0001628280-23-017260:notes:54]
Contract Acquisition Costs
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $9.7 million and $9.0 million as of March 31, 2023 and December 31, 2022, respectively. During the three months ended March 31, 2023 and 2022, the Company amortized commission expense of $1.6 million and $0.4 million, respectively.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001628280-23-017260:notes:55]
Accounts Receivable
Allowance for Expected Credit Losses

[0001628280-23-017260:notes:56]
Changes in the allowance for expected credit losses were as follows (in thousands):

[0001628280-23-017260:notes:57]
|  | Allowance for Doubtful Accounts |
| Balance at December 31, 2022 | $ | (200) |  |
| Provisions | (124) |  |
| Write-offs, net of recoveries | — |  |
| Balance at March 31, 2023 | $ | (324) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001628280-23-017260:notes:58]
[same as prior period, unchanged from 0001628280-22-029319:notes:114]

[0001628280-23-017260:notes:59]
|  | March 31,2023 |  | December 31,2022 |
| Raw materials | $ | 2,406 |  |  | $ | 2,334 |  |
| Finished goods | 6,410 |  |  | 7,923 |  |
| Total | $ | 8,816 |  |  | $ | 10,257 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-23-017260:notes:60]
[same as prior period, unchanged from 0001628280-22-029319:notes:118]

[0001628280-23-017260:notes:61]
|  | March 31,2023 |  | December 31,2022 |
| Computers and telecom equipment | $ | 843 |  |  | $ | 599 |  |
| Lab equipment | 902 |  |  | 871 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 542 |  |  | 542 |  |
| Leased equipment | 44,147 |  |  | 35,983 |  |
| Capitalized software | 5,013 |  |  | 4,150 |  |
| Sales demo equipment | 2,411 |  |  | 2,340 |  |
| Equipment held for lease1 | 15,322 |  |  | 7,826 |  |
| Construction in progress | 23 |  |  | 71 |  |
|  | 69,314 |  |  | 52,493 |  |
| Less: Accumulated depreciation and amortization | (9,525) |  |  | (7,786) |  |
|  | $ | 59,789 |  |  | $ | 44,707 |  |

[0001628280-23-017260:notes:62]
[same as prior period, unchanged from 0001628280-22-029319:notes:120]

[0001628280-23-017260:notes:63]
As of March 31, 2023 and December 31, 2022, the net book value of capitalized software was $4.2 million and $3.5 million, respectively. These amounts include $0.1 million and $0.2 million of capitalized stock compensation costs, respectively. Depreciation and amortization expense related to property and equipment was $1.8 million and $1.1 million for the three months ended March 31, 2023 and 2022.

[0001628280-23-017260:notes:64]
[same as prior period, unchanged from 0001628280-22-029319:notes:122]

[0001628280-23-017260:notes:65]
|  | March 31,2023 |  | December 31,2022 |
| Leased equipment | $ | 44,147 |  |  | $ | 35,983 |  |
| Accumulated depreciation | (7,115) |  |  | (5,802) |  |
| Leased equipment, net | $ | 37,032 |  |  | $ | 30,181 |  |

[0001628280-23-017260:notes:66]
Depreciation expense related to leased units was $1.4 million and $0.9 million during the three months ended March 31, 2023 and 2022, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.


## us-gaap:DebtDisclosureTextBlock

[0001628280-23-017260:notes:67]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001628280-23-017260:notes:68]
|  | March 31,2023 |  | December 31,2022 |
| Term loans payable | $ | — |  |  | $ | 30,000 |  |
| Less: Unamortized discount | — |  |  | (317) |  |
|  | — |  |  | 29,683 |  |
| Less: Current portion of long-term debt | — |  |  | 10,000 |  |
| Long-term debt, net of discount | $ | — |  |  | $ | 19,683 |  |

[0001628280-23-017260:notes:69]
Silicon Valley Bank Term Loan Agreement

[0001628280-23-017260:notes:70]
In December 2022, the Company entered into a loan and security agreement (the "2022 SVB Credit Agreement") with Silicon Valley Bank ("SVB") in order to finance purchases of hardware to be leased to customers. The 2022 SVB Credit Agreement provided for an initial term loan advance of $30.0 million, which was approximately equivalent to the value of all hardware purchases made to support leasing transactions with the Company's customers through December 21, 2022 (the "SVB Closing Date"), with the opportunity to obtain, within 18 months after the SVB Closing Date, additional term loan advances, subject to the satisfaction of certain conditions, in an aggregate principal amount equal to $20.0 million (subject to an increase of an additional $25.0 million upon the satisfaction of certain conditions and approval from SVB). The interest rate applicable to the SVB Term Loans was the greater of (a) the Wall Street Journal Prime Rate plus 1.0% or (b) 7.25% per annum. Interest and principal under the SVB Credit Agreement was payable monthly.

[0001628280-23-017260:notes:71]
On March 10, 2023, SVB was closed by the California Department of Financial Protection and Innovation, which appointed the Federal Deposit Corporation ("FDIC") as receiver. The FDIC created a successor bridge bank, Silicon Valley Bridge Bank, N.A. ("SVBB"), and all deposits of SVB were transferred to SVBB under a systemic risk exception approved by the Federal Reserve, the U.S. Treasury Department, and the FDIC. On March 12, 2023, the Federal Reserve, the U.S. Treasury Department, and the FDIC announced in a joint statement that all SVB deposits, including both insured and uninsured amounts, would be available in full to account holders. SVB was acquired by First Citizens Bank on March 27, 2023.

[0001628280-23-017260:notes:72]
In light of the foregoing, on March 28, 2023, upon the recommendation of the Company’s newly-formed Investment Committee of the Board of Directors, the Company (i) gave notice of its desire and intent to terminate the commitments under the 2022 SVB Credit Agreement and (ii) transferred its excess cash out of First Citizens Bank (the “Transfer”). The Transfer resulted in an event of default under the 2022 SVB Credit Agreement. Upon the occurrence of such event of default, First Citizens Bank could have, but was not required to, declare all obligations under the 2022 SVB 
Credit Agreement immediately due and payable. First Citizens Bank did not make such declaration following such event of default. On March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. The Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write off of $0.3 million of unamortized debt issuance costs.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-23-017260:notes:73]
Stock-Based Compensation
Stock Options

[0001628280-23-017260:notes:74]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the three months ended March 31, 2023 and 2022:

[0001628280-23-017260:notes:75]
|  | Three Months Ended March 31, |
|  | 2023 |  | 2022 |
| Risk-free interest rate | 4.2 | % |  | 1.6 | % |
| Expected term (in years) | 6.1 |  | 6.1 |
| Expected volatility | 87.5 | % |  | 75.0 | % |
| Expected dividend yield | 0.0 | % |  | 0.0 | % |

[0001628280-23-017260:notes:76]
The following table summarizes the Company’s stock option activity since December 31, 2022 (in thousands, except for share and per share data):

[0001628280-23-017260:notes:77]
|  | Number ofShares |  | WeightedAverageExercise Price |
| Outstanding as of December 31, 2022 | 20,396,824 |  | $ | 0.73 |  |
| Granted | 2,840,421 |  | 3.12 |  |
| Exercised | (100,587) |  | 0.33 |  |
| Forfeited | — |  |  | — |  |
| Outstanding as of March 31, 2023 | 23,136,658 |  | 1.03 |  |

[0001628280-23-017260:notes:78]
[same as prior period, unchanged from 0001628280-22-029319:notes:165]

[0001628280-23-017260:notes:79]
The following table summarizes the Company's restricted stock units activity since December 31, 2022:

[0001628280-23-017260:notes:80]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2022 | 7,501,945 |  |  | $ | 3.54 |  |
| Granted | 6,491,541 |  |  | 3.10 |  |
| Vested | (1,409,257) |  |  | 3.54 |  |
| Forfeited | (188,696) |  |  | 3.95 |  |
| Outstanding as of March 31, 2023 | 12,395,533 |  |  | $ | 3.30 |  |

[0001628280-23-017260:notes:81]
[same as prior period, unchanged from 0001628280-22-029319:notes:169]

[0001628280-23-017260:notes:82]
The following table summarizes the Company's performance stock units activity since December 31, 2022:

[0001628280-23-017260:notes:83]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2022 | 864,000 |  |  | $ | 2.65 |  |
| Granted | — |  |  | — |  |
| Vested | (432,000) |  |  | 2.65 |  |
| Forfeited | (17,500) |  |  | 2.65 |  |
| Outstanding as of March 31, 2023 | 414,500 |  |  | $ | 2.65 |  |

[0001628280-23-017260:notes:84]
[same as prior period, unchanged from 0001628280-22-029319:notes:175]

[0001628280-23-017260:notes:85]
In January 2021, the Company granted warrants (the "Finback Common Stock Warrants") to purchase 2,552,913 shares of the Company's common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC ("Finback"), a consulting group affiliated with one of the Company's shareholders. The Finback Common Stock Warrants vest upon meeting certain sales criteria as defined in a business development agreement (the "Finback BDA"), which has a term of 3 years. The BDA expired on January 1, 2023, but includes a 1-year "tail period" expiring on January 1, 2024. During the tail period, Finback Common Stock Warrants will continue to vest related to any sale consummated by the Company for which it is determined Finback provided services prior to January 1, 2023 in furtherance of the sale. The Finback Common Stock Warrants expire in January 2031. The Finback Common Stock Warrants are accounted for under ASC 718 Compensation – Stock Compensation as the warrants vest upon certain performance conditions being met.

[0001628280-23-017260:notes:86]
During the three months ended March 31, 2023, 830,216 Finback Common Stock Warrants were exercised. As of March 31, 2023, 79,677 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $0.2 million, and 1,511,307 Finback Common Stock Warrants are unvested and have a total unrecognized grant date fair value of $11.5 million. During the three months ended March 31, 2023 and 2022, the Company recorded $0.6 million and $0.2 million, respectively, of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants.

[0001628280-23-017260:notes:87]
[same as prior period, unchanged from 0001628280-22-029319:notes:180]

[0001628280-23-017260:notes:88]
[same as prior period, unchanged from 0001628280-22-029319:notes:181]

[0001628280-23-017260:notes:89]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Cost of revenue | $ | 145 |  | $ | 108 |  |  |  |  |
| Research and development | 837 |  | 548 |  |  |  |  |
| Sales and marketing | 1,998 |  | 1,484 |  |  |  |  |
| General and administrative | 2,063 |  | 1,787 |  |  |  |  |
| Total stock-based compensation expense | $ | 5,043 |  | $ | 3,927 |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-23-017260:notes:90]
Income TaxesThere is no provision for income taxes for the three months ended March 31, 2023 and 2022 because the Company has historically incurred net operating losses and maintains a full valuation allowance against its deferred tax assets.The Company’s tax provision and the resulting effective tax rate for interim periods is determined based upon its estimated annual effective tax rate (“AETR”), adjusted for the effect of discrete items arising in that quarter. The impact of such inclusions could result in a higher or lower effective tax rate during a particular quarter, based upon the mix and timing of actual earnings or losses versus annual projections. In each quarter, the Company updates its estimate of the annual effective tax rate, and if the estimated annual tax rate changes, a cumulative adjustment is made in that quarter.


## us-gaap:EarningsPerShareTextBlock

[0001628280-23-017260:notes:91]
[same as prior period, unchanged from 0001628280-22-029319:notes:187]

[0001628280-23-017260:notes:92]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) attributable to common stockholders – basic and diluted | $ | (28,609) |  | $ | (13,801) |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 146,433,378 |  |  | 142,878,406 |  |  |  |  |  |
| Net loss per share attributable to common stockholders – basic and diluted | $ | (0.20) |  |  | $ | (0.10) |  |  |  |  |  |

[0001628280-23-017260:notes:93]
[same as prior period, unchanged from 0001628280-22-029319:notes:189]

[0001628280-23-017260:notes:94]
|  | Three Months EndedMarch 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Options issued and outstanding | 23,136,658 |  | 21,964,309 |  |  |  |  |  |
| Public Warrants to purchase common stock | 14,324,994 |  |  | 14,324,993 |  |  |  |  |  |
| Warrants to purchase common stock (Finback)** | 1,590,984 |  |  | 2,421,200 |  |  |  |  |  |
| Unvested restricted stock units | 12,395,533 |  |  | 6,251,002 |  |  |  |  |  |
| Unvested performance stock units | 414,500 |  |  | 934,000 |  |  |  |  |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |  |  |  |  |
| Contingently issuable common stock* | 1,897,500 |  |  | 1,897,500 |  |  |  |  |  |
|  | 68,760,169 |  |  | 62,793,004 |  |  |  |  |  |

[0001628280-23-017260:notes:95]
*Issuance of Earn-out shares and Contingently issuable common stock are contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period
**Includes 79,677 vested warrants and 1,511,307 unvested warrants as of March 31, 2023


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-23-017260:notes:96]
Related Party Transactions
Business Development Agreement with Finback

[0001628280-23-017260:notes:97]
In January 2021, the Company granted the Finback Common Stock Warrants subject to the terms of the Finback BDA, as discussed in Note 9.

[0001628280-23-017260:notes:98]
In connection with the Merger and pursuant to the Merger Agreement, in addition to earn-out shares allocated to Finback based on its common stock ownership percentage as of the Merger date, Finback is entitled to receive a proportional share of earn-out shares based upon its remaining unvested warrants as of the Merger Date.

[0001628280-23-017260:notes:99]
Original Equipment Manufacturer Partnership Agreement with Motorola

[0001628280-23-017260:notes:100]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended March 31, 2023 and 2022, revenue from Motorola's distributor services was  $3.2 million and $0.8 million, respectively. As of March 31, 2023 and December 31, 2022, accounts receivable related to Motorola’s distributor services was $4.7 million and $12.5 million, respectively.

[0001628280-23-017260:notes:101]
Reseller Agreement with Stanley Black & Decker

[0001628280-23-017260:notes:102]
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB ("Securitas") in 2023. Securitas, directly or through its affiliates, resells the Company's products. During the three months ended March 31, 2023 and 2022, revenue from Securitas' reseller services was $0.4 million and less than $0.1 million, respectively. As of March 31, 2023 and December 31, 2022, accounts receivable related to Securitas' reseller services was $0.6 million and $2.2 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-23-017260:notes:103]
Commitments and Contingencies
Indemnification Agreements

[0001628280-23-017260:notes:104]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of March 31, 2023 or December 31, 2022.

[0001628280-23-017260:notes:105]
Legal Proceedings

[0001628280-23-017260:notes:106]
The Company is not a party to any litigation of a material nature and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.


## us-gaap:ErrorCorrectionTextBlock

[0001628280-23-017260:notes:107]
Revision of Prior Period Financial StatementsAs discussed in Note 1, in preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified errors in its previously issued financial statements whereby (a) certain expenses that were cost of subscription revenue related and cost of service revenue related were inaccurately classified as sales and marketing expenses on the consolidated statements of operations and comprehensive loss, (b) certain equipment under lease or held for lease was inaccurately classified as inventory on the consolidated balance sheets and a portion of the cash outflows related to the equipment under lease or held for lease were misclassified between operating and investing cash flows on the consolidated statements of cash flows, and (c) the vesting of warrants related to the Business Development Agreement disclosed in Note 16 were not accounted for accurately. The identified errors impacted the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022. The Company has made adjustments to the prior period amounts presented in these financial statements accordingly. Additionally, the Company has made adjustments to correct for other previously identified immaterial errors. The Company evaluated the errors and determined that the related impacts were not material to any previously issued annual or interim financial statements. The impact of the revisions to the quarterly period ending March 31, 2022 is presented as follows (in thousands):
Revised Condensed Consolidated Statement of Operations and Comprehensive Loss

[0001628280-23-017260:notes:108]
|  | Three Months EndedMarch 31, 2022 |
|  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |
| Product revenue | $ | 5,194 |  |  | $ | — |  |  | $ | 5,194 |  |
| Subscription revenue | 3,020 |  |  | (16) |  |  | 3,004 |  |
| Service revenue | 501 |  |  | 11 |  |  | 512 |  |
| Total revenue | 8,715 |  |  | (5) |  |  | 8,710 |  |
| Cost of revenue: |  |  |  |  |  |
| Cost of product revenue | 5,576 |  |  | (370) |  |  | 5,206 |  |
| Cost of subscription revenue | 1,065 |  |  | 477 |  |  | 1,542 |  |
| Cost of service revenue | 448 |  |  | 617 |  |  | 1,065 |  |
| Total cost of revenue | 7,089 |  |  | 724 |  |  | 7,813 |  |
| Gross profit | 1,626 |  |  | (729) |  |  | 897 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 4,286 |  |  | (111) |  |  | 4,175 |  |
| Sales and marketing expense | 12,053 |  |  | (2,381) |  |  | 9,672 |  |
| General and administrative | 11,093 |  |  | (276) |  |  | 10,817 |  |
| Loss from impairment of property and equipment | 96 |  |  | — |  |  | 96 |  |
| Total operating expenses | 27,528 |  |  | (2,768) |  |  | 24,760 |  |
| Loss from operations | (25,902) |  |  | 2,039 |  |  | (23,863) |  |
| Other income (expense), net: |  |  |  |  |  |
| Interest expense | (142) |  |  | — |  |  | (142) |  |
| Interest income | 209 |  |  | (141) |  |  | 68 |  |
| Change in fair value of contingent earn-out liability | 4,226 |  |  | (1,148) |  |  | 3,078 |  |
| Change in fair value of contingently issuable common stock liability | 1,472 |  |  | — |  |  | 1,472 |  |
| Change in fair value of public warrant liability | 5,586 |  |  | — |  |  | 5,586 |  |
| Total other income (expense), net | 11,351 |  |  | (1,289) |  |  | 10,062 |  |
| Net loss | $ | (14,551) |  |  | $ | 750 |  |  | $ | (13,801) |  |
| Weighted average common shares outstanding - basic and diluted | 142,878,406 |  |  | — |  |  | 142,878,406 |  |
| Net loss per share - basic and diluted | $ | (0.10) |  |  | $ | — |  |  | $ | (0.10) |  |

[0001628280-23-017260:notes:109]
Revised Condensed Consolidated Statement of Cash Flows

[0001628280-23-017260:notes:110]
|  | Three Months EndedMarch 31, 2022 |
|  | As Previously Reported | Adjustment | As Revised |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (14,551) |  | $ | 750 |  | $ | (13,801) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 948 |  | 138 |  | 1,086 |  |
| Write-off of inventory | 324 |  | — |  | 324 |  |
| Adjustment to property and equipment for sales type leases | (321) |  | (304) |  | (625) |  |
| Loss from impairment of property and equipment | 96 |  | — |  | 96 |  |
| Stock-based compensation | 5,190 |  | (1,263) |  | 3,927 |  |
| Non-cash interest expense | 5 |  | — |  | 5 |  |
| Non-cash lease expense | 197 |  | — |  | 197 |  |
| Change in fair value of earn-out liability | (4,226) |  | 1,148 |  | (3,078) |  |
| Change in fair value of contingently issuable common stock | (1,472) |  | — |  | (1,472) |  |
| Change in fair value of public warrant liability | (5,586) |  | — |  | (5,586) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (2,112) |  | — |  | (2,112) |  |
| Inventory | (6,985) |  | 5,675 |  | (1,310) |  |
| Commission assets | (351) |  | — |  | (351) |  |
| Contract assets | 108 |  | — |  | 108 |  |
| Other assets | — |  | 141 |  | 141 |  |
| Prepaid expenses and other current assets | (5,280) |  | (291) |  | (5,571) |  |
| Accounts payable | (1,867) |  | 1,012 |  | (855) |  |
| Deferred revenue | 2,778 |  | (201) |  | 2,577 |  |
| Deferred rent | (468) |  | 468 |  | — |  |
| Accrued expenses and other current liabilities | (2,065) |  | (368) |  | (2,433) |  |
| Operating lease liability | (229) |  | (468) |  | (697) |  |
| Net cash used in operating activities | (35,867) |  | 6,437 |  | (29,430) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (646) |  | (82) |  | (728) |  |
| Purchases of property and equipment | (323) |  | (6,366) |  | (6,689) |  |
| Net cash used in investing activities | (969) |  | (6,448) |  | (7,417) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 216 |  | 11 |  | 227 |  |
| Net cash provided by financing activities | 216 |  | 11 |  | 227 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (36,620) |  | — |  | (36,620) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 308,167 |  | — |  | 308,167 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 271,547 |  | $ | — |  | $ | 271,547 |  |
| Supplemental disclosure of non-cash activities |  |  |  |
| Transfer of inventory to property and equipment | $ | 4,620 |  | $ | (4,620) |  | $ | — |  |
| Capital expenditures incurred but not yet paid | 1,693 |  | 698 |  | 2,391 |  |
