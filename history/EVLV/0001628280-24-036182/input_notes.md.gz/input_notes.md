# EVLV notes — 0001628280-24-036182


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-24-036182:notes:1]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company pioneering AI-based screening designed to help create safer experiences, with key market categories that include education, healthcare, sports, and live entertainment.

[0001628280-24-036182:notes:2]
The Company's solutions combine proprietary software and hardware, delivered as a long-term Software-as-a-Service subscription model.  Its flagship product, Evolv Express®, uses advanced sensors, artificial intelligence powered software, and cloud services to reliably detect firearms, improvised explosives, and certain types of knives while ignoring many harmless items such as cell phones and keys.  These solutions and services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

[0001628280-24-036182:notes:3]
[same as prior period, unchanged from 0001628280-24-022282:notes:2]

[0001628280-24-036182:notes:4]
[same as prior period, unchanged from 0001628280-24-022282:notes:3]

[0001628280-24-036182:notes:5]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001628280-24-036182:notes:6]
[same as prior period, unchanged from 0001628280-24-022282:notes:5]

[0001628280-24-036182:notes:7]
The accompanying unaudited condensed consolidated financial statements as of June 30, 2024, and for the three and six months ended June 30, 2024 and 2023 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2023 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of June 30, 2024 and the results of its operations for the three and six months ended June 30, 2024 and 2023 and cash flows for the six months ended June 30, 2024 and 2023. The results for the three and six months ended June 30, 2024 are not necessarily indicative of results to be expected for the year ending December 31, 2024, any other interim periods, or any future year or period.

[0001628280-24-036182:notes:8]
[same as prior period, unchanged from 0001628280-24-022282:notes:7]

[0001628280-24-036182:notes:9]
[same as prior period, unchanged from 0001628280-24-022282:notes:8]

[0001628280-24-036182:notes:10]
For the three and six months ended June 30, 2023, the reclassifications resulted in an increase in license fee and other revenue of $0.7 million and $1.3 million, respectively, and a corresponding decrease in service revenue, as well as an increase in cost of license fee and other revenue of $0.3 million and $0.6 million, respectively, and a corresponding decrease in cost of service revenue.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-24-036182:notes:11]
[same as prior period, unchanged from 0001628280-24-022282:notes:10]

[0001628280-24-036182:notes:12]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2023, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2023. There have been no material changes to the Company’s significant accounting policies during the six months ended June 30, 2024.

[0001628280-24-036182:notes:13]
Recently Issued Accounting Pronouncements

[0001628280-24-036182:notes:14]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures.” The updated accounting guidance requires enhanced reportable segment disclosures, primarily related to significant segment expenses which are regularly provided to the chief operating decision maker. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Retrospective application is required and early adoption is permitted. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

[0001628280-24-036182:notes:15]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity should apply the amendments in ASU 2023-09 prospectively to all annual periods beginning after December 15, 2024. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-24-036182:notes:16]
Marketable Securities
Marketable securities as of June 30, 2024 and December 31, 2023 consisted of the following:

[0001628280-24-036182:notes:17]
|  | June 30, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 20,757 |  |  | $ | — |  |  | $ | 20,757 |  |
| Total marketable securities | $ | 20,757 |  |  | $ | — |  |  | $ | 20,757 |  |

[0001628280-24-036182:notes:18]
|  | December 31, 2023 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |
| Total marketable securities | $ | 51,289 |  |  | $ | — |  |  | $ | 51,289 |  |

[0001628280-24-036182:notes:19]
Marketable securities at June 30, 2024 and December 31, 2023 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and six months ended June 30, 2024 and 2023. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive income.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-24-036182:notes:20]
[same as prior period, unchanged from 0001628280-24-022282:notes:19]

[0001628280-24-036182:notes:21]
|  | Fair Value Measurements at June 30, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 28,025 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,025 |  |
| Treasury bills | — |  |  | 20,757 |  |  | — |  |  | 20,757 |  |
|  | $ | 28,025 |  |  | $ | 20,757 |  |  | $ | — |  |  | $ | 48,782 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 5,706 |  |  | $ | 5,706 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 2,256 |  |  | 2,256 |  |
| Public Warrant liability | 3,852 |  |  | — |  |  | — |  |  | 3,852 |  |
|  | $ | 3,852 |  |  | $ | — |  |  | $ | 7,962 |  |  | $ | 11,814 |  |

[0001628280-24-036182:notes:22]
|  | Fair Value Measurements at December 31, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 57,829 |  |  | $ | — |  |  | $ | — |  |  | $ | 57,829 |  |
| Treasury bills | — |  |  | 51,289 |  |  | — |  |  | 51,289 |  |
|  | $ | 57,829 |  |  | $ | 51,289 |  |  | $ | — |  |  | $ | 109,118 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 29,119 |  |  | $ | 29,119 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 6,530 |  |  | 6,530 |  |
| Public Warrant liability | 10,889 |  |  | — |  |  | — |  |  | 10,889 |  |
|  | $ | 10,889 |  |  | $ | — |  |  | $ | 35,649 |  |  | $ | 46,538 |  |

[0001628280-24-036182:notes:23]
Money market funds are included in cash and cash equivalents on the condensed consolidated balance sheets. As of June 30, 2024 and December 31, 2023, all outstanding treasury bills, which totaled $20.8 million and $51.3 million, respectively, had original maturities greater than 3 months and are reflected as marketable securities. The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources.

[0001628280-24-036182:notes:24]
[same as prior period, unchanged from 0001628280-24-022282:notes:23]

[0001628280-24-036182:notes:25]
[same as prior period, unchanged from 0001628280-24-022282:notes:24]

[0001628280-24-036182:notes:26]
During each of the six months ended June 30, 2024 and 2023, there were no transfers between Level 1, Level 2 and Level 3.

[0001628280-24-036182:notes:27]
[same as prior period, unchanged from 0001628280-24-022282:notes:26]

[0001628280-24-036182:notes:28]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2023. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of June 30, 2024, no milestones have been achieved.

[0001628280-24-036182:notes:29]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of June 30, 2024 were as follows: 87.5% expected stock price volatility, a risk-free rate of return of 4.8%, a 25% likelihood of change in control and a remaining term of 1.7 years.

[0001628280-24-036182:notes:30]
[same as prior period, unchanged from 0001628280-24-022282:notes:29]

[0001628280-24-036182:notes:31]
| Balance at December 31, 2023 | $ | 29,119 |  |
| Change in fair value | (23,413) |  |
| Balance at June 30, 2024 | $ | 5,706 |  |

[0001628280-24-036182:notes:32]
The decrease in fair value of the contingent earn-out liability is primarily due to lowered probability to achieve the stock price milestones based on the Company's current stock price and a shorter remaining term.

[0001628280-24-036182:notes:33]
[same as prior period, unchanged from 0001628280-24-022282:notes:31]

[0001628280-24-036182:notes:34]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock which were converted into shares of the Company's stock in connection with the Merger (the “Founder Shares”). Of these shares, 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 outstanding shares will vest upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2023. The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of June 30, 2024, no milestones have been achieved.

[0001628280-24-036182:notes:35]
The fair value of the contingently issued common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of June 30, 2024 were as follows: 85% expected stock price volatility, a risk-free rate of return of 4.7%, a 25% likelihood of change in control and a remaining term of 2.0 years.

[0001628280-24-036182:notes:36]
[same as prior period, unchanged from 0001628280-24-022282:notes:34]

[0001628280-24-036182:notes:37]
| Balance at December 31, 2023 | $ | 6,530 |  |
| Change in fair value | (4,274) |  |
| Balance at June 30, 2024 | $ | 2,256 |  |

[0001628280-24-036182:notes:38]
[same as prior period, unchanged from 0001628280-24-022282:notes:36]

[0001628280-24-036182:notes:39]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. As of June 30, 2024, 14,324,893 Public Warrants are outstanding.

[0001628280-24-036182:notes:40]
[same as prior period, unchanged from 0001628280-24-022282:notes:38]

[0001628280-24-036182:notes:41]
| Balance at December 31, 2023 | $ | 10,889 |  |
| Change in fair value | (7,037) |  |
| Balance at June 30, 2024 | $ | 3,852 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-24-036182:notes:42]
[same as prior period, unchanged from 0001628280-24-022282:notes:40]

[0001628280-24-036182:notes:43]
[same as prior period, unchanged from 0001628280-24-022282:notes:41]

[0001628280-24-036182:notes:44]
[same as prior period, unchanged from 0001628280-24-022282:notes:42]

[0001628280-24-036182:notes:45]
[same as prior period, unchanged from 0001628280-24-022282:notes:43]

[0001628280-24-036182:notes:46]
[same as prior period, unchanged from 0001628280-24-022282:notes:44]

[0001628280-24-036182:notes:47]
[same as prior period, unchanged from 0001628280-24-022282:notes:45]

[0001628280-24-036182:notes:48]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of June 30, 2024:

[0001628280-24-036182:notes:49]
|  | Less than 1 year |  | 1 - 2 years |  | More than 2 years |  | Total |
| Product revenue | $ | 1,670 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,670 |  |
| Subscription revenue | 67,956 |  |  | 59,326 |  |  | 63,842 |  |  | 191,124 |  |
| Service revenue | 24,238 |  |  | 23,019 |  |  | 21,076 |  |  | 68,333 |  |
| License fee and other revenue | 1,789 |  |  | 10 |  |  | 21 |  |  | 1,820 |  |
| Total revenue | $ | 95,653 |  |  | $ | 82,355 |  |  | $ | 84,939 |  |  | $ | 262,947 |  |

[0001628280-24-036182:notes:50]
The amount of minimum future leases is based on expected income recognition. As of June 30, 2024, future minimum payments on noncancelable leases are as follows (in thousands):

[0001628280-24-036182:notes:51]
| Year Ending December 31: |  |
| 2024 (six months remaining) | $ | 34,992 |  |
| 2025 | 63,964 |  |
| 2026 | 52,682 |  |
| 2027 | 32,219 |  |
| 2028 | 7,133 |  |
| Thereafter | 134 |  |
|  | $ | 191,124 |  |

[0001628280-24-036182:notes:52]
[same as prior period, unchanged from 0001628280-24-022282:notes:50]

[0001628280-24-036182:notes:53]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of June 30, 2024 and December 31, 2023, the Company had $1.7 million and $3.7 million in current portion of contract assets and $0.1 million and $0.5 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001628280-24-036182:notes:54]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $14.1 million and $31.4 million during the three and six months ended June 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance. The Company recognized revenue of $5.3 million and $12.1 million during the three and six months ended June 30, 2023, respectively, that was included in the December 31, 2022 deferred revenue balance.

[0001628280-24-036182:notes:55]
[same as prior period, unchanged from 0001628280-24-022282:notes:53]

[0001628280-24-036182:notes:56]
| Balance at December 31, 2023 | $ | 71,490 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (31,445) |  |
| Revenue deferred | 39,778 |  |
| Balance at June 30, 2024 | $ | 79,823 |  |

[0001628280-24-036182:notes:57]
[same as prior period, unchanged from 0001628280-24-022282:notes:55]

[0001628280-24-036182:notes:58]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest income on lease receivables | $ | 41 |  |  | $ | 51 |  |  | $ | 83 |  |  | $ | 104 |  |
| Lease income - operating leases | 15,903 |  |  | 7,964 |  |  | 30,406 |  |  | 14,430 |  |
| Total lease revenue | $ | 15,944 |  |  | $ | 8,015 |  |  | $ | 30,489 |  |  | $ | 14,534 |  |

[0001628280-24-036182:notes:59]
Interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.3 million and less than $0.1 million during the three months ended June 30, 2024 and June 30, 2023, respectively. Revenue related to leases entered into with related parties were $0.6 million and $0.2 million during the six months ended June 30, 2024 and June 30, 2023, respectively.

[0001628280-24-036182:notes:60]
[same as prior period, unchanged from 0001628280-24-022282:notes:58]

[0001628280-24-036182:notes:61]
[same as prior period, unchanged from 0001628280-24-022282:notes:59]

[0001628280-24-036182:notes:62]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Product revenue | $ | 2,044 |  |  | $ | 7,243 |  |  | $ | 2,647 |  |  | $ | 15,997 |  |
| Subscription revenue | 15,903 |  |  | 7,964 |  |  | 30,406 |  |  | 14,430 |  |
| Service revenue | 5,553 |  |  | 3,905 |  |  | 10,937 |  |  | 6,691 |  |
| License fees | 1,717 |  |  | — |  |  | 2,441 |  |  | — |  |
| Professional services and other revenue | 323 |  |  | 713 |  |  | 777 |  |  | 1,288 |  |
| Total revenue | $ | 25,540 |  |  | $ | 19,825 |  |  | $ | 47,208 |  |  | $ | 38,406 |  |

[0001628280-24-036182:notes:63]
Commissions
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $11.9 million and $11.4 million as of June 30, 2024 and December 31, 2023, respectively. During the three months ended June 30, 2024 and 2023, the Company recognized commission expense of $1.6 million and $1.5 million, respectively. During the six months ended June 30, 2024 and 2023, the Company recognized commission expense of $3.0 million and $3.1 million, respectively.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001628280-24-036182:notes:64]
[same as prior period, unchanged from 0001628280-24-022282:notes:62]

[0001628280-24-036182:notes:65]
[same as prior period, unchanged from 0001628280-24-022282:notes:63]

[0001628280-24-036182:notes:66]
|  | Allowance for Doubtful Accounts |
| Balance at December 31, 2023 | $ | (582) |  |
| Provisions | (206) |  |
| Write-offs, net of recoveries | 3 |  |
| Balance at June 30, 2024 | $ | (785) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001628280-24-036182:notes:67]
[same as prior period, unchanged from 0001628280-24-022282:notes:65]

[0001628280-24-036182:notes:68]
|  | June 30,2024 |  | December 31,2023 |
| Raw materials | $ | 2,974 |  |  | $ | 1,869 |  |
| Finished goods | 15,630 |  |  | 7,638 |  |
| Total | $ | 18,604 |  |  | $ | 9,507 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-24-036182:notes:69]
[same as prior period, unchanged from 0001628280-24-022282:notes:67]

[0001628280-24-036182:notes:70]
|  | June 30,2024 |  | December 31,2023 |
| Computers and telecom equipment | $ | 1,574 |  |  | $ | 1,331 |  |
| Lab equipment | 4,494 |  |  | 1,171 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 592 |  |  | 566 |  |
| Leased equipment | 97,746 |  |  | 80,206 |  |
| Capitalized software | 12,396 |  |  | 8,629 |  |
| Sales demo equipment | 3,180 |  |  | 2,758 |  |
| Equipment held for lease1 | 22,739 |  |  | 32,910 |  |
| Construction in progress | 1,415 |  |  | 2,493 |  |
|  | 144,247 |  |  | 130,175 |  |
| Less: Accumulated depreciation and amortization | (24,202) |  |  | (17,254) |  |
|  | $ | 120,045 |  |  | $ | 112,921 |  |

[0001628280-24-036182:notes:71]
[same as prior period, unchanged from 0001628280-24-022282:notes:69]

[0001628280-24-036182:notes:72]
As of June 30, 2024 and December 31, 2023, the net book value of capitalized software was $10.1 million and $7.0 million, respectively. These amounts include $1.2 million and $0.7 million of capitalized stock compensation costs, respectively. Depreciation and amortization expense related to property and equipment was $4.0 million and $2.3 million for the three months ended June 30, 2024 and 2023, respectively, which included amortization expense of capitalized software of $0.3 million and $0.2 million, respectively. Depreciation and amortization expense related to property and

[0001628280-24-036182:notes:73]
equipment was $7.4 million and $4.1 million for the six months ended June 30, 2024 and 2023, respectively, which included amortization expense of capitalized software of $0.6 million and $0.4 million for the six months ended June 30, 2024 and 2023, respectively.

[0001628280-24-036182:notes:74]
[same as prior period, unchanged from 0001628280-24-022282:notes:71]

[0001628280-24-036182:notes:75]
|  | June 30,2024 |  | December 31,2023 |
| Leased equipment | $ | 97,746 |  |  | $ | 80,206 |  |
| Accumulated depreciation | (18,896) |  |  | (13,283) |  |
| Leased equipment, net | $ | 78,850 |  |  | $ | 66,923 |  |

[0001628280-24-036182:notes:76]
Depreciation expense related to leased units was $3.2 million and $1.8 million during the three months ended June 30, 2024 and 2023, respectively, and $6.1 million and $3.2 million during the six months ended June 30, 2024 and 2023, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.
The Company did not record any loss from impairment of property and equipment during the three and six months ended June 30, 2024 and recorded $0.2 million and $0.3 million of loss from impairment of property and equipment during the three and six months ended June 30, 2023, respectively. This primarily related to the removal of Evolv Edge units and Evolv Express prototypes from service, resulting in an impairment of the remaining economic value of such units.


## us-gaap:DebtDisclosureTextBlock

[0001628280-24-036182:notes:77]
Long-term Debt
In December 2022, the Company entered into a loan and security agreement (the “2022 SVB Credit Agreement”) with Silicon Valley Bank (“SVB”) in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. Subsequently, on March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. During the six months ended June 30, 2023, the Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs. The Company had no long-term debt as of June 30, 2024 and December 31, 2023.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-24-036182:notes:78]
[same as prior period, unchanged from 0001628280-24-022282:notes:75]

[0001628280-24-036182:notes:79]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the six months ended June 30, 2024 and 2023:

[0001628280-24-036182:notes:80]
|  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |
| Risk-free interest rate | 4.1% |  | 4.2% |
| Expected term (in years) | 6.1 |  | 6.1 |
| Expected volatility | 90.0% |  | 87.5% |
| Expected dividend yield | 0.0% |  | 0.0% |

[0001628280-24-036182:notes:81]
[same as prior period, unchanged from 0001628280-24-022282:notes:78]

[0001628280-24-036182:notes:82]
|  | Number ofShares |  | WeightedAverageExercise Price |
| Outstanding as of December 31, 2023 | 20,324,528 |  | $ | 1.04 |  |
| Granted | 2,725,625 |  | 3.63 |  |
| Exercised | (1,342,136) |  | 0.48 |  |
| Forfeited | (13,085) |  |  | 0.42 |  |
| Expired | (13,141) |  |  | 0.42 |  |
| Outstanding as of June 30, 2024 | 21,681,791 |  | $ | 1.40 |  |

[0001628280-24-036182:notes:83]
[same as prior period, unchanged from 0001628280-24-022282:notes:80]

[0001628280-24-036182:notes:84]
[same as prior period, unchanged from 0001628280-24-022282:notes:81]

[0001628280-24-036182:notes:85]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2023 | 13,046,679 |  |  | $ | 3.49 |  |
| Granted | 8,422,954 |  |  | 3.57 |  |
| Vested | (4,441,906) |  |  | 3.44 |  |
| Forfeited | (910,339) |  |  | 3.74 |  |
| Nonvested as of June 30, 2024 | 16,117,388 |  |  | $ | 3.54 |  |

[0001628280-24-036182:notes:86]
[same as prior period, unchanged from 0001628280-24-022282:notes:83]

[0001628280-24-036182:notes:87]
[same as prior period, unchanged from 0001628280-24-022282:notes:84]

[0001628280-24-036182:notes:88]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2023 | 380,000 |  |  | $ | 2.64 |  |
| Granted | — |  |  | — |  |
| Vested | (380,000) |  |  | 2.64 |  |
| Forfeited | — |  |  | — |  |
| Nonvested as of June 30, 2024 | — |  |  | $ | — |  |

[0001628280-24-036182:notes:89]
[same as prior period, unchanged from 0001628280-24-022282:notes:86]

[0001628280-24-036182:notes:90]
In January 2021, the Company granted equity classified warrants (the “Finback Common Stock Warrants”) to purchase 2,552,913 shares of the Company's Class A common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC (“Finback”), a consulting group affiliated with one of the Company's stockholders. The Finback Common Stock Warrants vest upon meeting certain sales criteria as defined in a business development agreement (the “Finback BDA”), which had a term of 3 years. The Finback BDA expired on January 1, 2023 but included a 1-year “tail period” expiring on January 1, 2024. During the tail period, the Finback Common Stock Warrants continued to vest related to any sale consummated by the Company for which it was determined Finback provided services prior to January 1, 2023

[0001628280-24-036182:notes:91]
in furtherance of the sale. The Finback Common Stock Warrants expire in January 2031. The Finback Common Stock Warrants are accounted for under ASC 718 Compensation – Stock Compensation as the warrants vest upon certain performance conditions being met.

[0001628280-24-036182:notes:92]
As of June 30, 2024, 117,423 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $0.3 million, and there were no Finback Common Stock Warrants that were unvested, given the expiration of the 1-year tail period on January 1, 2024. The Company recognized compensation expense for the Finback Common Stock Warrants when the warrants vested based on meeting the specified sales criteria. During the three and six months ended June 30, 2024, there was no stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants. During the three and six months ended June 30, 2023, the Company recorded $0.8 million and $1.4 million of stock-based compensation expense, respectively, within sales and marketing expense related to the Finback Common Stock Warrants.

[0001628280-24-036182:notes:93]
[same as prior period, unchanged from 0001628280-24-022282:notes:90]

[0001628280-24-036182:notes:94]
[same as prior period, unchanged from 0001628280-24-022282:notes:91]

[0001628280-24-036182:notes:95]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cost of revenue | $ | 173 |  | $ | 184 |  | $ | 311 |  | $ | 329 |
| Research and development | 1,219 |  | 1,238 |  | 2,101 |  | 2,075 |
| Sales and marketing | 2,724 |  | 2,508 |  | 5,683 |  | 4,506 |
| General and administrative | 3,308 |  | 2,759 |  | 5,739 |  | 4,822 |
| Total stock-based compensation expense | $ | 7,424 |  | $ | 6,689 |  | $ | 13,834 |  | $ | 11,732 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-24-036182:notes:96]
Income Taxes
There is no provision for income taxes for the three and six months ended June 30, 2024 and 2023 because the Company has historically incurred net operating losses and maintains a full valuation allowance against its deferred tax assets.

[0001628280-24-036182:notes:97]
[same as prior period, unchanged from 0001628280-24-022282:notes:94]


## us-gaap:EarningsPerShareTextBlock

[0001628280-24-036182:notes:98]
Net Income (Loss) per Share
In periods in which the Company reported net income, net income attributable to common stockholders is computed using the two-class method as the Founder Shares are classified as participating securities containing rights to receive dividends. In accordance with the two-class method, a portion of net income is allocated to participating securities and excluded from the calculation of income allocated to common stock.

[0001628280-24-036182:notes:99]
Basic net income (loss) per share is calculated by dividing net income (loss) attributable to common stockholders by the weighted average shares outstanding during the period. Diluted net income (loss) per share is calculated by adjusting weighted average shares outstanding for the dilutive effect of potential common shares, determined using the treasury stock

[0001628280-24-036182:notes:100]
method. Basic and diluted net income (loss) per share attributable to common stockholders are calculated as follows (in thousands, except share and per share amounts):

[0001628280-24-036182:notes:101]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income (loss) | $ | 3,462 |  | $ | (66,754) |  | $ | (8,182) |  | $ | (95,363) |
| Reallocation of net income attributable to participating securities | (41) |  | — |  | — |  | — |
| Net income (loss) attributable to common stockholders – basic and diluted | $ | 3,421 |  | $ | (66,754) |  | $ | (8,182) |  | $ | (95,363) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding – basic | 156,473,080 |  | 148,882,160 |  | 154,774,899 |  | 147,664,534 |
| Weighted average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Stock options | 13,047,919 |  | — |  | — |  | — |
| Restricted stock units | 1,940,411 |  | — |  | — |  | — |
| Finback Common Stock Warrants | 102,533 |  | — |  | — |  | — |
| Total potentially dilutive securities | 15,090,863 |  | — |  | — |  | — |
| Weighted average common shares outstanding – diluted | 171,563,943 |  | 148,882,160 |  | 154,774,899 |  | 147,664,534 |
| Net income (loss) per share attributable to common stockholders - basic | $ | 0.02 |  | $ | (0.45) |  | $ | (0.05) |  | $ | (0.65) |
| Net income (loss) per share attributable to common stockholders - diluted | $ | 0.02 |  | $ | (0.45) |  | $ | (0.05) |  | $ | (0.65) |

[0001628280-24-036182:notes:102]
The following potentially dilutive outstanding securities were excluded from the computation of diluted net income (loss) per share attributable to common stockholders because their effect would have been anti-dilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the period:

[0001628280-24-036182:notes:103]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Options issued and outstanding | 7,237,746 |  |  | 22,340,997 |  |  | 21,681,791 |  | 22,340,997 |  |
| Public Warrants to purchase common stock | 14,324,893 |  |  | 14,324,893 |  |  | 14,324,893 |  |  | 14,324,893 |  |
| Warrants to purchase common stock (Finback) | — |  |  | 1,590,984 |  |  | 117,423 |  |  | 1,590,984 |  |
| Unvested restricted stock units | 8,843,186 |  |  | 12,451,740 |  |  | 16,117,388 |  |  | 12,451,740 |  |
| Unvested performance stock units | — |  |  | 407,000 |  |  | — |  |  | 407,000 |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |
| Contingently issuable common stock* | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |
|  | 47,303,325 |  |  | 68,013,114 |  |  | 69,138,995 |  |  | 68,013,114 |  |

[0001628280-24-036182:notes:104]
[same as prior period, unchanged from 0001628280-24-022282:notes:99]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-24-036182:notes:105]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola

[0001628280-24-036182:notes:106]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended June 30, 2024 and 2023, revenue from Motorola's distributor services was $2.0 million and $2.9 million, respectively. During the six months ended June 30, 2024 and 2023, revenue from Motorola's distributor services was $3.9 million and $6.2 million, respectively. As of June 30, 2024 and December 31, 2023, accounts receivable related to Motorola’s distributor services was $2.9 million and $1.2 million, respectively.

[0001628280-24-036182:notes:107]
Reseller Agreement with Stanley Black & Decker
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB (“Securitas”) in 2023. Securitas, directly or through its affiliates, resells the Company's products. Effective in the first quarter of 2024, while the reseller agreement is still in effect, Securitas is no longer considered a related party. During the three and six months ended June 30, 2023, revenue from Securitas' reseller services was $0.5 million and $0.9 million, respectively. As of December 31, 2023, accounts receivable related to Securitas' reseller services was $0.6 million.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-24-036182:notes:108]
Commitments and Contingencies
Indemnification Agreements

[0001628280-24-036182:notes:109]
In the ordinary course of business, the Company provides indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. The Company has not incurred or accrued for any material costs as a result of such indemnifications in its condensed consolidated financial statements as of June 30, 2024 or December 31, 2023.

[0001628280-24-036182:notes:110]
Legal Proceedings

[0001628280-24-036182:notes:111]
We are from time to time subject to various claims, lawsuits, and other legal and administrative proceedings arising in the ordinary course of business.

[0001628280-24-036182:notes:112]
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.

[0001628280-24-036182:notes:113]
The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. Except for the regulatory matters discussed below, based upon information presently known to management, the Company has not accrued a loss for any other legal matters, as a loss is not probable and reasonably estimable. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

[0001628280-24-036182:notes:114]
In March 2024, an Evolv shareholder filed in the U.S. District Court for the District of Massachusetts a putative class action lawsuit, captioned Raby v. Evolv Technologies Holdings, Inc., et al. case number 1:24-cv-10761, alleging that Evolv and certain of its current and former executives and other individuals violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 based on alleged misstatements concerning the Company’s products. This litigation is in the preliminary stages, and the outcome of any complex legal proceeding is inherently unpredictable and subject to significant uncertainties. The Company intends to vigorously defend itself in this matter.

[0001628280-24-036182:notes:115]
Regulatory and Governmental Matters

[0001628280-24-036182:notes:116]
In the ordinary course of business, the Company is subject to regulatory and governmental examinations, information gathering requests, inquiries, and investigations. The U.S. Federal Trade Commission (“FTC”) has requested information about certain aspects of the Company's marketing practices. The Company is cooperating with the investigation and has provided documentation and information responsive to the FTC inquiry. Further, in February 2024, we received a subpoena from the SEC, Division of Enforcement, requesting that we produce certain documents and information. We are cooperating and intend to continue to cooperate with the SEC's investigation.

[0001628280-24-036182:notes:117]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of legal and regulatory matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the condensed consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.

[0001628280-24-036182:notes:118]
Any resolution or litigation with the FTC, the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate. As of June 30, 2024, we have accrued $1.1 million for such matters. These amounts were recorded in other accrued liabilities in the condensed consolidated balance sheets and the associated expenses were recorded in general and administrative expenses in the condensed consolidated statements of operations. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations. Actual loss can be significantly greater or less than our estimated accrual. Legal fees incurred in connection with ongoing legal matters are considered period costs and are expensed as incurred.

[0001628280-24-036182:notes:119]
We can offer no assurances as to the outcome of these investigations or their potential effect, if any, on us or our results of operations. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.
