# EVLV MD&A — 0001628280-24-036182


## mdna

[0001628280-24-036182:mdna:1]
[same as prior period, unchanged from 0001628280-24-022282:mdna:1]

[0001628280-24-036182:mdna:2]
[same as prior period, unchanged from 0001628280-24-022282:mdna:2]

[0001628280-24-036182:mdna:3]
[same as prior period, unchanged from 0001628280-24-022282:mdna:3]

[0001628280-24-036182:mdna:4]
We are a leading security technology company pioneering AI-based screening designed to help create safer experiences, with key market categories that include education, healthcare, sports, and live entertainment.

[0001628280-24-036182:mdna:5]
Our solutions combine proprietary software and hardware, delivered as a long-term Software-as-a-Service subscription model. Our flagship product, Evolv Express®, uses advanced sensors, artificial intelligence powered software, and cloud services to reliably detect firearms, improvised explosives, and certain types of knives while ignoring many harmless items such as cell phones and keys. Our solutions and services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience.

[0001628280-24-036182:mdna:6]
Our products have screened over 1.5 billion visitors worldwide since our inception. We believe that we have screened more people through advanced systems than any organization other than the United States Transportation Security Administration (“TSA”). Our customers include many iconic venues across a wide variety of industries, including major sports stadiums and arenas, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, hospitals, large industrial workplaces, schools, and prominent houses of worship. We offer our products for lease or purchase and primarily under a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue, and creates expansion and upsell opportunities.

[0001628280-24-036182:mdna:7]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $25.5 million and $19.8 million for the three months ended June 30, 2024 and 2023, respectively. We generated operating losses for the three months ended June 30, 2024 and 2023 of $22.3 million and $23.6 million, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-24-036182:mdna:8]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations, and if necessary, debt financings. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources.” Additionally, as discussed in Note 14 (Commitments and Contingencies) to our condensed consolidated financial statements for the three months ended June 30, 2024, certain legal proceedings, including government investigations, have been initiated involving us. Given the uncertainty of such matters, no assurance can be given regarding the final outcome of such matters. During the three months ended June 30, 2024, we accrued $1.1 million related to such matters. However, the ultimate amount or range of potential loss, which might result to the Company may differ materially from our current estimates.

[0001628280-24-036182:mdna:9]
[same as prior period, unchanged from 0001628280-24-022282:mdna:8]

[0001628280-24-036182:mdna:10]
[same as prior period, unchanged from 0001628280-24-022282:mdna:9]

[0001628280-24-036182:mdna:11]
[same as prior period, unchanged from 0001628280-24-022282:mdna:10]

[0001628280-24-036182:mdna:12]
[same as prior period, unchanged from 0001628280-24-022282:mdna:11]

[0001628280-24-036182:mdna:13]
[same as prior period, unchanged from 0001628280-24-022282:mdna:12]

[0001628280-24-036182:mdna:14]
[same as prior period, unchanged from 0001628280-24-022282:mdna:13]

[0001628280-24-036182:mdna:15]
[same as prior period, unchanged from 0001628280-24-022282:mdna:14]

[0001628280-24-036182:mdna:16]
[same as prior period, unchanged from 0001628280-24-022282:mdna:15]

[0001628280-24-036182:mdna:17]
[same as prior period, unchanged from 0001628280-24-022282:mdna:16]

[0001628280-24-036182:mdna:18]
[same as prior period, unchanged from 0001628280-24-022282:mdna:17]

[0001628280-24-036182:mdna:19]
[same as prior period, unchanged from 0001628280-24-022282:mdna:18]

[0001628280-24-036182:mdna:20]
[same as prior period, unchanged from 0001628280-24-022282:mdna:19]

[0001628280-24-036182:mdna:21]
We are a leading security technology company pioneering AI-based screening designed to help create safer experiences. Our investment into our research and development program drives growth by improving our existing products, developing potential new products for the market and expanding what is possible for physical security.

[0001628280-24-036182:mdna:22]
2

[0001628280-24-036182:mdna:23]
[same as prior period, unchanged from 0001628280-24-022282:mdna:22]

[0001628280-24-036182:mdna:24]
[same as prior period, unchanged from 0001628280-24-022282:mdna:23]

[0001628280-24-036182:mdna:25]
[same as prior period, unchanged from 0001628280-24-022282:mdna:24]

[0001628280-24-036182:mdna:26]
[same as prior period, unchanged from 0001628280-24-022282:mdna:25]

[0001628280-24-036182:mdna:27]
[same as prior period, unchanged from 0001628280-24-022282:mdna:26]

[0001628280-24-036182:mdna:28]
[same as prior period, unchanged from 0001628280-24-022282:mdna:27]

[0001628280-24-036182:mdna:29]
[same as prior period, unchanged from 0001628280-24-022282:mdna:28]

[0001628280-24-036182:mdna:30]
Lease arrangements generally include both lease and non-lease components. The non-lease components relate to (1) distinct services, including professional services, SaaS, and maintenance, and (2) any add-on accessories. Professional services are included in license fees and other revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive income (loss).

[0001628280-24-036182:mdna:31]
[same as prior period, unchanged from 0001628280-24-022282:mdna:30]

[0001628280-24-036182:mdna:32]
[same as prior period, unchanged from 0001628280-24-022282:mdna:31]

[0001628280-24-036182:mdna:33]
[same as prior period, unchanged from 0001628280-24-022282:mdna:32]

[0001628280-24-036182:mdna:34]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from Columbia Tech to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration. Revenue for professional services and other one-time revenue, which had previously been included in service revenue, has been reclassified for prior periods to License fee and other revenue on the consolidated statements of operations and comprehensive income (loss). We expect license fee and other revenue to continue to increase as we continue to focus our go-to-market strategy on our distributor licensing sales model.

[0001628280-24-036182:mdna:35]
[same as prior period, unchanged from 0001628280-24-022282:mdna:34]

[0001628280-24-036182:mdna:36]
[same as prior period, unchanged from 0001628280-24-022282:mdna:35]

[0001628280-24-036182:mdna:37]
[same as prior period, unchanged from 0001628280-24-022282:mdna:37]

[0001628280-24-036182:mdna:38]
[same as prior period, unchanged from 0001628280-24-022282:mdna:38]

[0001628280-24-036182:mdna:39]
[same as prior period, unchanged from 0001628280-24-022282:mdna:36]

[0001628280-24-036182:mdna:40]
[same as prior period, unchanged from 0001628280-24-022282:mdna:39]

[0001628280-24-036182:mdna:41]
[same as prior period, unchanged from 0001628280-24-022282:mdna:40]

[0001628280-24-036182:mdna:42]
[same as prior period, unchanged from 0001628280-24-022282:mdna:41]

[0001628280-24-036182:mdna:43]
[same as prior period, unchanged from 0001628280-24-022282:mdna:42]

[0001628280-24-036182:mdna:44]
[same as prior period, unchanged from 0001628280-24-022282:mdna:43]

[0001628280-24-036182:mdna:45]
[same as prior period, unchanged from 0001628280-24-022282:mdna:44]

[0001628280-24-036182:mdna:46]
[same as prior period, unchanged from 0001628280-24-022282:mdna:45]

[0001628280-24-036182:mdna:47]
[same as prior period, unchanged from 0001628280-24-022282:mdna:46]

[0001628280-24-036182:mdna:48]
[same as prior period, unchanged from 0001628280-24-022282:mdna:49]

[0001628280-24-036182:mdna:49]
[same as prior period, unchanged from 0001628280-24-022282:mdna:47]

[0001628280-24-036182:mdna:50]
[same as prior period, unchanged from 0001628280-24-022282:mdna:48]

[0001628280-24-036182:mdna:51]
[same as prior period, unchanged from 0001628280-24-022282:mdna:50]

[0001628280-24-036182:mdna:52]
[same as prior period, unchanged from 0001628280-24-022282:mdna:51]

[0001628280-24-036182:mdna:53]
[same as prior period, unchanged from 0001628280-24-022282:mdna:52]

[0001628280-24-036182:mdna:54]
[same as prior period, unchanged from 0001628280-24-022282:mdna:53]

[0001628280-24-036182:mdna:55]
[same as prior period, unchanged from 0001628280-24-022282:mdna:54]

[0001628280-24-036182:mdna:56]
[same as prior period, unchanged from 0001628280-24-022282:mdna:55]

[0001628280-24-036182:mdna:57]
[same as prior period, unchanged from 0001628280-24-022282:mdna:56]

[0001628280-24-036182:mdna:58]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will increase for the year ending December 31, 2024 compared to the year ended December 31, 2023 primarily due to an overall increase in personnel related expense.

[0001628280-24-036182:mdna:59]
[same as prior period, unchanged from 0001628280-24-022282:mdna:60]

[0001628280-24-036182:mdna:60]
[same as prior period, unchanged from 0001628280-24-022282:mdna:61]

[0001628280-24-036182:mdna:61]
[same as prior period, unchanged from 0001628280-24-022282:mdna:62]

[0001628280-24-036182:mdna:62]
[same as prior period, unchanged from 0001628280-24-022282:mdna:63]

[0001628280-24-036182:mdna:63]
[same as prior period, unchanged from 0001628280-24-022282:mdna:64]

[0001628280-24-036182:mdna:64]
[same as prior period, unchanged from 0001628280-24-022282:mdna:65]

[0001628280-24-036182:mdna:65]
[same as prior period, unchanged from 0001628280-24-022282:mdna:66]

[0001628280-24-036182:mdna:66]
[same as prior period, unchanged from 0001628280-24-022282:mdna:67]

[0001628280-24-036182:mdna:67]
[same as prior period, unchanged from 0001628280-24-022282:mdna:68]

[0001628280-24-036182:mdna:68]
In December 2022, the Company entered into a loan and security agreement (the “2022 SVB Credit Agreement”) with Silicon Valley Bank (“SVB”) in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. Subsequently, the Company terminated the 2022 SVB Credit Agreement on March 31, 2023. As a result of the termination of the SVB Credit Agreement, the Company incurred a loss on extinguishment of debt.

[0001628280-24-036182:mdna:69]
[same as prior period, unchanged from 0001628280-24-022282:mdna:70]

[0001628280-24-036182:mdna:70]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders are entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive income (loss).

[0001628280-24-036182:mdna:71]
[same as prior period, unchanged from 0001628280-24-022282:mdna:72]

[0001628280-24-036182:mdna:72]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock, referred to as Founder Shares. Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 1,897,500 Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones, and 517,500 Founder Shares were contributed to Give Evolv LLC. The 1,897,500 outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive income (loss).

[0001628280-24-036182:mdna:73]
[same as prior period, unchanged from 0001628280-24-022282:mdna:74]

[0001628280-24-036182:mdna:74]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are currently exercisable and expire in July 2026. We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger as a component of other

[0001628280-24-036182:mdna:75]
5

[0001628280-24-036182:mdna:76]
income (expense), net in the consolidated statements of operations and comprehensive income (loss) with the offset to additional paid-in capital.

[0001628280-24-036182:mdna:77]
[same as prior period, unchanged from 0001628280-24-022282:mdna:76]

[0001628280-24-036182:mdna:78]
[same as prior period, unchanged from 0001628280-24-022282:mdna:77]

[0001628280-24-036182:mdna:79]
[same as prior period, unchanged from 0001628280-24-022282:mdna:78]

[0001628280-24-036182:mdna:80]
During the year ended December 31, 2023, the Company began classifying revenue from professional services, which includes installation, training, and event support, as well as one-time revenue within license fee and other revenue on the consolidated statements of operations and comprehensive income (loss), whereas the revenue for these services has previously been included in service revenue. Correspondingly, the Company began classifying costs associated with professional services within cost of license fee and other revenue, whereas these costs were previously included in cost of service revenue. These reclassifications were made to align the presentation of professional services with the Company's internal reporting and analysis.

[0001628280-24-036182:mdna:81]
6

[0001628280-24-036182:mdna:82]
[same as prior period, unchanged from 0001628280-24-022282:mdna:80]

[0001628280-24-036182:mdna:83]
Comparison of the Three Months Ended June 30, 2024 and 2023

[0001628280-24-036182:mdna:84]
The following table summarizes our results of operations for the three months ended June 30, 2024 and 2023 (in thousands):

[0001628280-24-036182:mdna:85]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 2,044 |  |  | $ | 7,243 |  |  | $ | (5,199) |  |  | (72) | % |
| Subscription revenue | 15,903 |  |  | 7,964 |  |  | 7,939 |  |  | 100 |  |
| Service revenue | 5,553 |  |  | 3,905 |  |  | 1,648 |  |  | 42 |  |
| License fee and other revenue | 2,040 |  |  | 713 |  |  | 1,327 |  |  | 186 |  |
| Total revenue | 25,540 |  |  | 19,825 |  |  | 5,715 |  |  | 29 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 3,149 |  |  | 7,722 |  |  | (4,573) |  |  | (59) |  |
| Cost of subscription revenue | 6,436 |  |  | 3,406 |  |  | 3,030 |  |  | 89 |  |
| Cost of service revenue | 1,311 |  |  | 1,014 |  |  | 297 |  |  | 29 |  |
| Cost of license fee and other revenue | 172 |  |  | 270 |  |  | (98) |  |  | (36) |  |
| Total cost of revenue | 11,068 |  |  | 12,412 |  |  | (1,344) |  |  | (11) |  |
| Gross profit | 14,472 |  |  | 7,413 |  |  | 7,059 |  |  | 95 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,722 |  |  | 6,395 |  |  | (673) |  |  | (11) |  |
| Sales and marketing | 16,892 |  |  | 13,613 |  |  | 3,279 |  |  | 24 |  |
| General and administrative | 14,185 |  |  | 10,874 |  |  | 3,311 |  |  | 30 |  |
| Loss from impairment of property and equipment | — |  |  | 157 |  |  | (157) |  |  | (100) |  |
| Total operating expenses | 36,799 |  |  | 31,039 |  |  | 5,760 |  |  | 19 |  |
| Loss from operations | (22,327) |  |  | (23,626) |  |  | 1,299 |  |  | 5 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest income | 681 |  |  | 1,853 |  |  | (1,172) |  |  | (63) |  |
| Other income (expense), net | (39) |  |  | (22) |  |  | (17) |  |  | (77) |  |
| Change in fair value of contingent earn-out liability | 16,514 |  |  | (28,113) |  |  | 44,627 |  |  | 159 |  |
| Change in fair value of contingently issuable common stock liability | 3,747 |  |  | (5,095) |  |  | 8,842 |  |  | 174 |  |
| Change in fair value of public warrant liability | 4,886 |  |  | (11,751) |  |  | 16,637 |  |  | 142 |  |
| Total other income (expense), net | 25,789 |  |  | (43,128) |  |  | 68,917 |  |  | 160 |  |
| Net income (loss) | $ | 3,462 |  |  | $ | (66,754) |  |  | $ | 70,216 |  |  | 105 | % |

[0001628280-24-036182:mdna:86]
[same as prior period, unchanged from 0001628280-24-022282:mdna:85]

[0001628280-24-036182:mdna:87]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 84 new customers during the three months ended June 30, 2024 and 74 new customers during the three months ended June 30, 2023, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-24-036182:mdna:88]
[same as prior period, unchanged from 0001628280-24-022282:mdna:88]

[0001628280-24-036182:mdna:89]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Product revenue | $ | 2,044 |  |  | $ | 7,243 |  |  | $ | (5,199) |  |  | (72) | % |
| Cost of product revenue | $ | 3,149 |  |  | $ | 7,722 |  |  | $ | (4,573) |  |  | (59) | % |
| Gross profit - Product revenue | $ | (1,105) |  |  | $ | (479) |  |  | $ | (626) |  |  | (131) | % |
| Gross profit margin - Product revenue | (54) | % |  | (7) | % |  | N/A |  | (47) | % |

[0001628280-24-036182:mdna:90]
The decreases in product revenue and cost of product revenue are primarily due to a continued transition to pure subscription sales and sales under our distributor model during the preceding twelve months. The decrease in product gross profit margin for the three months ended June 30, 2024 compared to the prior year period is primarily attributable to $0.4 million of expense related to an increase to our inventory reserve and $0.3 million increase in manufacturing expenses.

[0001628280-24-036182:mdna:91]
[same as prior period, unchanged from 0001628280-24-022282:mdna:91]

[0001628280-24-036182:mdna:92]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Subscription revenue | $ | 15,903 |  |  | $ | 7,964 |  |  | $ | 7,939 |  |  | 100 | % |
| Cost of subscription revenue | $ | 6,436 |  |  | $ | 3,406 |  |  | $ | 3,030 |  |  | 89 | % |
| Gross profit - Subscription revenue | $ | 9,467 |  |  | $ | 4,558 |  |  | $ | 4,909 |  |  | 108 | % |
| Gross profit margin - Subscription revenue | 60 | % |  | 57 | % |  | N/A |  | 2 | % |

[0001628280-24-036182:mdna:93]
The increases in subscription revenue, cost of subscription revenue and subscription gross profit are primarily due to continued growth in our customer base for the three months ended June 30, 2024 compared to the prior year period, which was due to a transition to our pure subscription model and a higher number of active Evolv Express units deployed under our pure subscription model.

[0001628280-24-036182:mdna:94]
[same as prior period, unchanged from 0001628280-24-022282:mdna:95]

[0001628280-24-036182:mdna:95]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Service revenue | $ | 5,553 |  |  | $ | 3,905 |  |  | $ | 1,648 |  |  | 42 | % |
| Cost of service revenue | $ | 1,311 |  |  | $ | 1,014 |  |  | $ | 297 |  |  | 29 | % |
| Gross profit - Service revenue | $ | 4,242 |  |  | $ | 2,891 |  |  | $ | 1,351 |  |  | 47 | % |
| Gross profit margin - Service revenue | 76 | % |  | 74 | % |  | N/A |  | 2 | % |

[0001628280-24-036182:mdna:96]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by

[0001628280-24-036182:mdna:97]
customers directly from Columbia Tech under our distributor model, for the three months ended June 30, 2024 compared to the prior year period.

[0001628280-24-036182:mdna:98]
[same as prior period, unchanged from 0001628280-24-022282:mdna:98]

[0001628280-24-036182:mdna:99]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| License fee and other revenue | $ | 2,040 |  |  | $ | 713 |  |  | $ | 1,327 |  |  | 186 | % |
| Cost of license fee and other revenue | $ | 172 |  |  | $ | 270 |  |  | $ | (98) |  |  | (36) | % |
| Gross profit - License fee and other revenue | $ | 1,868 |  |  | $ | 443 |  |  | $ | 1,425 |  |  | 322 | % |
| Gross profit margin - License fee and other revenue | 92 | % |  | 62 | % |  | N/A |  | 29 | % |

[0001628280-24-036182:mdna:100]
The increase in license fee and other revenue, gross profit, and gross profit margin was primarily driven by $1.7 million of license fees earned during the three months ended June 30, 2024 compared to no license fees earned during the prior year period under the Distribution and License Agreement which was executed in March 2023.

[0001628280-24-036182:mdna:101]
[same as prior period, unchanged from 0001628280-24-022282:mdna:101]

[0001628280-24-036182:mdna:102]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 3,943 |  |  | $ | 4,313 |  |  | $ | (370) |  |  | (9) | % |
| Materials and prototypes | 504 |  |  | 839 |  |  | (335) |  |  | (40) | % |
| Professional fees | 929 |  |  | 926 |  |  | 3 |  |  | — | % |
| Other | 346 |  |  | 317 |  |  | 29 |  |  | 9 | % |
|  | $ | 5,722 |  |  | $ | 6,395 |  |  | $ | (673) |  |  | (11) | % |

[0001628280-24-036182:mdna:103]
The decrease in personnel related expenses is due to a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased, partially offset by an increase in payroll costs primarily resulting from new hires in our research and development function during the past twelve months. The decrease in materials and prototypes expense is due to decreased design and engineering costs related to the development of the next generation of our Evolv Express system. Professional fees and other expense remained consistent.

[0001628280-24-036182:mdna:104]
[same as prior period, unchanged from 0001628280-24-022282:mdna:104]

[0001628280-24-036182:mdna:105]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 12,514 |  |  | $ | 10,258 |  |  | $ | 2,256 |  |  | 22 | % |
| Advertising and direct marketing | 1,044 |  |  | 612 |  |  | 432 |  |  | 71 | % |
| Travel and entertainment | 1,388 |  |  | 1,252 |  |  | 136 |  |  | 11 | % |
| Professional fees | 880 |  |  | 569 |  |  | 311 |  |  | 55 | % |
| Other | 1,066 |  |  | 922 |  |  | 144 |  |  | 16 | % |
|  | $ | 16,892 |  |  | $ | 13,613 |  |  | $ | 3,279 |  |  | 24 | % |

[0001628280-24-036182:mdna:106]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting primarily from new hires in our sales and marketing functions to support increased sales volume during the past twelve months and certain other one-time employee-related costs. Stock compensation expense included in sales and marketing expenses was $2.7 million for the three months ended June 30, 2024 compared to $2.5 million for the three months ended June 30, 2023. The increase in advertising and direct marketing expense is primarily due to an increase in expenses related to trade shows and events. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings. Professional fees increased due primarily to an increase in marketing consulting costs. Other expense increased primarily due to an increase in IT and software subscription costs.

[0001628280-24-036182:mdna:107]
9

[0001628280-24-036182:mdna:108]
[same as prior period, unchanged from 0001628280-24-022282:mdna:107]

[0001628280-24-036182:mdna:109]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 6,918 |  |  | $ | 6,113 |  |  | $ | 805 |  |  | 13 | % |
| Professional fees | 1,791 |  |  | 1,504 |  |  | 287 |  |  | 19 | % |
| Insurance costs | 766 |  |  | 1,093 |  |  | (327) |  |  | (30) | % |
| Other | 4,710 |  |  | 2,164 |  |  | 2,546 |  |  | 118 | % |
|  | $ | 14,185 |  |  | $ | 10,874 |  |  | $ | 3,311 |  |  | 30 | % |

[0001628280-24-036182:mdna:110]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $3.3 million for the three months ended June 30, 2024 compared to $2.8 million for the three months ended June 30, 2023. The increase in professional fees was primarily related to an increase in outsourced accounting consultancy and audit fees. The decrease in insurance costs was primarily related to a decrease in director and officer insurance premiums. Other expense increased primarily due to a $1.1 million accrual for ongoing regulatory matters and $1.1 million of certain one-time expenses incurred during the three months ended June 30, 2024 compared to $0.4 million for the three months ended June 30, 2023, as well as increases in rent for additional leased space, IT and software subscription costs, and bad debt expenses.

[0001628280-24-036182:mdna:111]
[same as prior period, unchanged from 0001628280-24-022282:mdna:110]

[0001628280-24-036182:mdna:112]
No loss from impairment of property and equipment was recognized for the three months ended June 30, 2024, compared to $0.2 million for the three months ended June 30, 2023, primarily related to the removal of Evolv Express units from service, resulting in impairment of the remaining economic value of such units.

[0001628280-24-036182:mdna:113]
[same as prior period, unchanged from 0001628280-24-022282:mdna:114]

[0001628280-24-036182:mdna:114]
Interest income of $0.7 million for the three months ended June 30, 2024 and $1.9 million for the three months ended June 30, 2023 related primarily to interest earned on money market funds and the accretion of discounts on treasury bills.

[0001628280-24-036182:mdna:115]
[same as prior period, unchanged from 0001628280-24-022282:mdna:116]

[0001628280-24-036182:mdna:116]
Change in the fair value of the contingent earn-out liability resulted in a $16.5 million gain and $28.1 million loss for the three months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-24-036182:mdna:117]
[same as prior period, unchanged from 0001628280-24-022282:mdna:118]

[0001628280-24-036182:mdna:118]
Change in the fair value of the contingently issuable common stock liability resulted in a $3.7 million gain and $5.1 million loss for the three months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-24-036182:mdna:119]
[same as prior period, unchanged from 0001628280-24-022282:mdna:120]

[0001628280-24-036182:mdna:120]
Change in the fair value of the public warrant liability resulted in a $4.9 million gain and a $11.8 million loss for the three months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-24-036182:mdna:121]
Comparison of the Six Months Ended June 30, 2024 and 2023

[0001628280-24-036182:mdna:122]
The following table summarizes our results of operations for the six months ended June 30, 2024 and 2023 (in thousands):

[0001628280-24-036182:mdna:123]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 2,647 |  |  | $ | 15,997 |  |  | $ | (13,350) |  |  | (83) | % |
| Subscription revenue | 30,406 |  |  | 14,430 |  |  | 15,976 |  |  | 111 |  |
| Service revenue | 10,937 |  |  | 6,691 |  |  | 4,246 |  |  | 63 |  |
| License fee and other revenue | 3,218 |  |  | 1,288 |  |  | 1,930 |  |  | 150 |  |
| Total revenue | 47,208 |  |  | 38,406 |  |  | 8,802 |  |  | 23 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 5,926 |  |  | 18,300 |  |  | (12,374) |  |  | (68) |  |
| Cost of subscription revenue | 12,215 |  |  | 5,757 |  |  | 6,458 |  |  | 112 |  |
| Cost of service revenue | 2,522 |  |  | 1,597 |  |  | 925 |  |  | 58 |  |
| Cost of license fee and other revenue | 301 |  |  | 574 |  |  | (273) |  |  | (48) |  |
| Total cost of revenue | 20,964 |  |  | 26,228 |  |  | (5,264) |  |  | (20) |  |
| Gross profit | 26,244 |  |  | 12,178 |  |  | 14,066 |  |  | 116 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 11,927 |  |  | 11,784 |  |  | 143 |  |  | 1 |  |
| Sales and marketing | 32,897 |  |  | 26,417 |  |  | 6,480 |  |  | 25 |  |
| General and administrative | 26,025 |  |  | 19,800 |  |  | 6,225 |  |  | 31 |  |
| Loss from impairment of property and equipment | — |  |  | 294 |  |  | (294) |  |  | (100) |  |
| Total operating expenses | 70,849 |  |  | 58,295 |  |  | 12,554 |  |  | 22 |  |
| Loss from operations | (44,605) |  |  | (46,117) |  |  | 1,512 |  |  | 3 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | (654) |  |  | 654 |  |  | 100 |  |
| Interest income | 1,766 |  |  | 2,806 |  |  | (1,040) |  |  | (37) |  |
| Other expense, net | (67) |  |  | (3) |  |  | (64) |  |  | (2,133) |  |
| Loss on extinguishment of debt | — |  |  | (626) |  |  | 626 |  |  | * |
| Change in fair value of contingent earn-out liability | 23,413 |  |  | (31,431) |  |  | 54,844 |  |  | 174 |  |
| Change in fair value of contingently issuable common stock liability | 4,274 |  |  | (5,837) |  |  | 10,111 |  |  | 173 |  |
| Change in fair value of public warrant liability | 7,037 |  |  | (13,501) |  |  | 20,538 |  |  | 152 |  |
| Total other income (expense), net | 36,423 |  |  | (49,246) |  |  | 85,669 |  |  | 174 |  |
| Net loss | $ | (8,182) |  |  | $ | (95,363) |  |  | $ | 87,181 |  |  | 91 | % |

[0001628280-24-036182:mdna:124]
11

[0001628280-24-036182:mdna:125]
Revenue, Cost of Revenue and Gross Profit

[0001628280-24-036182:mdna:126]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 137 new customers during the six months ended June 30, 2024 and 135 new customers during the six months ended June 30, 2023, (iii) the expansion of our existing customers’ initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-24-036182:mdna:127]
Product Revenue

[0001628280-24-036182:mdna:128]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Product revenue | $ | 2,647 |  |  | $ | 15,997 |  |  | $ | (13,350) |  |  | (83) | % |
| Cost of product revenue | $ | 5,926 |  |  | $ | 18,300 |  |  | $ | (12,374) |  |  | (68) | % |
| Gross profit - Product revenue | $ | (3,279) |  |  | $ | (2,303) |  |  | $ | (976) |  |  | (42) | % |
| Gross profit margin - Product revenue | (124) | % |  | (14) | % |  | N/A |  | (109) | % |

[0001628280-24-036182:mdna:129]
The decreases in product revenue and cost of product revenue are primarily due to a continued transition to pure subscription sales and sales under our distributor model during the preceding twelve months. The decrease in product gross profit margin for the six months ended June 30, 2024 compared to the six months ended June 30, 2023 is primarily attributable to $1.0 million of expense related to an increase to our inventory reserve and $1.2 million of expense associated with adverse non-cancellable inventory purchase commitments during the six months ended June 30, 2024, both of which relate primarily to the ongoing transition of our manufacturing operations to the next generation of Evolv Express systems and the determination that certain components within our legacy systems will not be used in the next generation systems.

[0001628280-24-036182:mdna:130]
Subscription Revenue

[0001628280-24-036182:mdna:131]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Subscription revenue | $ | 30,406 |  |  | $ | 14,430 |  |  | $ | 15,976 |  |  | 111 | % |
| Cost of subscription revenue | $ | 12,215 |  |  | $ | 5,757 |  |  | $ | 6,458 |  |  | 112 | % |
| Gross profit - Subscription revenue | $ | 18,191 |  |  | $ | 8,673 |  |  | $ | 9,518 |  |  | 110 | % |
| Gross profit margin - Subscription revenue | 60 | % |  | 60 | % |  | N/A |  | — | % |

[0001628280-24-036182:mdna:132]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to continued growth in our customer base for the six months ended June 30, 2024 compared to the six months ended June 30, 2023, which was due to a transition to our pure subscription model and a higher number of active Evolv Express units deployed under our pure subscription contract model.

[0001628280-24-036182:mdna:133]
12

[0001628280-24-036182:mdna:134]
Service Revenue

[0001628280-24-036182:mdna:135]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Service revenue | $ | 10,937 |  |  | $ | 6,691 |  |  | $ | 4,246 |  |  | 63 | % |
| Cost of service revenue | $ | 2,522 |  |  | $ | 1,597 |  |  | $ | 925 |  |  | 58 | % |
| Gross profit - Service revenue | $ | 8,415 |  |  | $ | 5,094 |  |  | $ | 3,321 |  |  | 65 | % |
| Gross profit margin - Service revenue | 77 | % |  | 76 | % |  | N/A |  | 1 | % |

[0001628280-24-036182:mdna:136]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech under our distributor model, for the six months ended June 30, 2024 compared to the six months ended June 30, 2023.

[0001628280-24-036182:mdna:137]
License fee and other revenue

[0001628280-24-036182:mdna:138]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| License fee and other revenue | $ | 3,218 |  |  | $ | 1,288 |  |  | $ | 1,930 |  |  | 150 | % |
| Cost of license fee and other revenue | $ | 301 |  |  | $ | 574 |  |  | $ | (273) |  |  | (48) | % |
| Gross profit - License fee and other revenue | $ | 2,917 |  |  | $ | 714 |  |  | $ | 2,203 |  |  | 309 | % |
| Gross profit margin - License fee and other revenue | 91 | % |  | 55 | % |  | N/A |  | 35 | % |

[0001628280-24-036182:mdna:139]
The increase in license fee and other revenue, gross profit, and gross profit margin was primarily driven by $2.4 million of license fees earned during the six months ended June 30, 2024 compared to no license fees earned during the six months ended June 30, 2023 under the Distribution and License Agreement which was executed in March 2023.

[0001628280-24-036182:mdna:140]
Research and Development Expenses

[0001628280-24-036182:mdna:141]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 7,930 |  |  | $ | 8,160 |  |  | $ | (230) |  |  | (3) | % |
| Materials and prototypes | 1,343 |  |  | 1,197 |  |  | 146 |  |  | 12 | % |
| Professional fees | 1,846 |  |  | 1,925 |  |  | (79) |  |  | (4) | % |
| Other | 808 |  |  | 502 |  |  | 306 |  |  | 61 | % |
|  | $ | 11,927 |  |  | $ | 11,784 |  |  | $ | 143 |  |  | 1 | % |

[0001628280-24-036182:mdna:142]
The decrease in personnel related expenses is due to a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased, partially offset by an increase in payroll costs primarily resulting from new hires in our research and development function during the past twelve months. The increase in materials and prototypes expense is due to inventory reserve on unused components offset by the decreased design and engineering costs, both of which relate primarily to the development of the next generation of our Evolv Express system. The decrease in professional fees primarily relates to higher amount of costs capitalized related to internal-use software and software embedded in products to be sold or leased, offset by consulting costs incurred for product development and engineering. The increase in other expense is primarily due to an increase in IT and software subscription costs.

[0001628280-24-036182:mdna:143]
13

[0001628280-24-036182:mdna:144]
Sales and Marketing Expenses

[0001628280-24-036182:mdna:145]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 24,506 |  |  | $ | 19,707 |  |  | $ | 4,799 |  |  | 24 | % |
| Advertising and direct marketing | 1,854 |  |  | 1,827 |  |  | 27 |  |  | 1 | % |
| Travel and entertainment | 2,658 |  |  | 2,142 |  |  | 516 |  |  | 24 | % |
| Professional fees | 1,839 |  |  | 1,094 |  |  | 745 |  |  | 68 | % |
| Other | 2,040 |  |  | 1,647 |  |  | 393 |  |  | 24 | % |
|  | $ | 32,897 |  |  | $ | 26,417 |  |  | $ | 6,480 |  |  | 25 | % |

[0001628280-24-036182:mdna:146]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting primarily from new hires in our sales and marketing functions during the past twelve months to support increased sales volume and certain other one-time employee-related costs. Stock compensation expense included in sales and marketing expenses was $5.7 million for the six months ended June 30, 2024 compared to $4.5 million for the six months ended June 30, 2023. Advertising and direct marketing expense remained consistent. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings. Professional fees increased due primarily to an increase in marketing consulting costs. Other expense increased primarily due to an increase in IT and software subscription costs.

[0001628280-24-036182:mdna:147]
General and Administrative Expenses

[0001628280-24-036182:mdna:148]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2024 |  | 2023 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 13,156 |  |  | $ | 11,173 |  |  | $ | 1,983 |  |  | 18 | % |
| Professional fees | 4,337 |  |  | 2,909 |  |  | 1,428 |  |  | 49 | % |
| Insurance costs | 1,508 |  |  | 2,066 |  |  | (558) |  |  | (27) | % |
| Other | 7,024 |  |  | 3,652 |  |  | 3,372 |  |  | 92 | % |
|  | $ | 26,025 |  |  | $ | 19,800 |  |  | $ | 6,225 |  |  | 31 | % |

[0001628280-24-036182:mdna:149]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team during the past twelve months. Stock compensation expense included in general and administrative expenses was $5.7 million for the six months ended June 30, 2024 compared to $4.8 million for the six months ended June 30, 2023. The increase in professional fees was primarily related to an increase in outsourced accounting consultancy and audit fees. The decrease in insurance costs was primarily related to a decrease in director and officer insurance premiums. Other expense increased primarily due to a $1.1 million accrual for ongoing regulatory matters and $1.6 million of certain one-time expenses incurred during the six months ended June 30, 2024 compared to $0.5 million for the six months ended June 30, 2023, as well as increases in rent for additional leased space, IT and software subscription costs, and property taxes.

[0001628280-24-036182:mdna:150]
Loss From Impairment of Property and Equipment

[0001628280-24-036182:mdna:151]
No loss from impairment of property and equipment was recognized for the six months ended June 30, 2024, compared to $0.3 million for the six months ended June 30, 2023, primarily related to the removal of Evolv Express units from service, resulting in impairment of the remaining economic value of such units.

[0001628280-24-036182:mdna:152]
[same as prior period, unchanged from 0001628280-24-022282:mdna:112]

[0001628280-24-036182:mdna:153]
No interest expense was recognized for the six months ended June 30, 2024, compared to $0.7 million for the six months ended June 30, 2023. During March 2023, the Company fully repaid all borrowings and accrued interest under its term loans with Silicon Valley Bank (“SVB”) pursuant to a loan and security agreement entered into in December 2022 (the “2022 SVB Credit Agreement”).

[0001628280-24-036182:mdna:154]
Interest Income

[0001628280-24-036182:mdna:155]
Interest income of $1.8 million and $2.8 million for the six months ended June 30, 2024 and 2023, respectively, related primarily to interest earned on money market funds and the accretion of discounts on treasury bills.

[0001628280-24-036182:mdna:156]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-24-036182:mdna:157]
Change in the fair value of the contingent earn-out liability resulted in a $23.4 million gain and $31.4 million loss for the six months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-24-036182:mdna:158]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-24-036182:mdna:159]
Change in the fair value of the contingently issuable common stock liability resulted in a $4.3 million gain and $5.8 million loss for the six months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-24-036182:mdna:160]
Change in Fair Value of Public Warrant Liability

[0001628280-24-036182:mdna:161]
Change in the fair value of the public warrant liability resulted in a $7.0 million gain and a $13.5 million loss for the six months ended June 30, 2024 and 2023, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-24-036182:mdna:162]
[same as prior period, unchanged from 0001628280-24-022282:mdna:122]

[0001628280-24-036182:mdna:163]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. As of June 30, 2024, we had $56.5 million in cash, cash equivalents, and marketable securities. We incurred a net income of $3.5 million and a net loss of $66.8 million for the three months ended June 30, 2024 and 2023, respectively, and incurred a net loss of $8.2 million and $95.4 million for the six months ended June 30, 2024 and 2023, respectively. We incurred cash outflows from operating activities of $38.0 million and $8.8 million during the six months ended June 30, 2024 and 2023, respectively.

[0001628280-24-036182:mdna:164]
[same as prior period, unchanged from 0001628280-24-022282:mdna:124]

[0001628280-24-036182:mdna:165]
We expect our cash, cash equivalents, and marketable securities, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our sales and marketing team. While we are expecting a higher percentage of sales to go through our distribution model over time, we may require additional capital to respond to expected growth in the demand for equipment to support our “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances and in either the short-term or long-term may determine to engage in debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001628280-24-036182:mdna:166]
[same as prior period, unchanged from 0001628280-24-022282:mdna:126]

[0001628280-24-036182:mdna:167]
During March 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. The Company has no debt outstanding as of June 30, 2024.

[0001628280-24-036182:mdna:168]
[same as prior period, unchanged from 0001628280-24-022282:mdna:128]

[0001628280-24-036182:mdna:169]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of June 30, 2024. We anticipate fulfilling such commitments with our existing cash, cash equivalents, and marketable securities, as well as cash and cash equivalents obtained through operations and, if necessary, proceeds from long-term debt. Cash, cash equivalents, and marketable securities amounted to $56.5 million as of June 30, 2024.

[0001628280-24-036182:mdna:170]
We are party to a lease agreement for office space at our headquarters in Waltham, MA. During the three months ended March 31, 2024, we amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. We are required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space which is classified as restricted cash, non-current on the condensed consolidated balance sheet as of June 30, 2024. Total future minimum lease payments under this noncancelable operating lease amount to $2.5 million as of June 30, 2024.

[0001628280-24-036182:mdna:171]
[same as prior period, unchanged from 0001628280-24-022282:mdna:131]

[0001628280-24-036182:mdna:172]
[same as prior period, unchanged from 0001628280-24-022282:mdna:132]

[0001628280-24-036182:mdna:173]
|  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |
| Net cash used in operating activities | $ | (37,962) |  |  | $ | (8,755) |  |
| Net cash used in investing activities | 5,851 |  |  | (64,117) |  |
| Net cash provided by (used in) financing activities | 636 |  |  | (29,988) |  |
| Effect of exchange rate changes on cash and cash equivalents | 11 |  |  | (33) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (31,464) |  |  | $ | (102,893) |  |

[0001628280-24-036182:mdna:174]
[same as prior period, unchanged from 0001628280-24-022282:mdna:134]

[0001628280-24-036182:mdna:175]
|  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |
| Net loss | $ | (8,182) |  |  | $ | (95,363) |  |
| Non-cash expense | (10,611) |  |  | 68,230 |  |
| Changes in operating assets and liabilities | (19,169) |  |  | 18,378 |  |
| Net cash used in operating activities | $ | (37,962) |  |  | $ | (8,755) |  |

[0001628280-24-036182:mdna:176]
Net loss decreased from $95.4 million for the six months ended June 30, 2023 to $8.2 million for the six months ended June 30, 2024 primarily due to changes in the fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability. See "Results of Operations" above for further discussion.

[0001628280-24-036182:mdna:177]
Non-cash expense for the six months ended June 30, 2024 is primarily attributable to $13.8 million of stock-based compensation expense, $7.4 million of depreciation and amortization, and $34.7 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability. Non-cash expense for the six months ended June 30, 2023 is primarily attributable to $11.7 million of stock-based compensation expense, $4.1 million of depreciation and amortization, $0.6 million of loss from extinguishment of debt, and $50.8 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability.

[0001628280-24-036182:mdna:178]
16

[0001628280-24-036182:mdna:179]
Changes in operating assets and liabilities for the six months ended June 30, 2024 are primarily related to the following:

[0001628280-24-036182:mdna:180]
•$14.0 million increase in accounts receivable primarily due to the timing of customer billings;

[0001628280-24-036182:mdna:181]
•$10.4 million increase in inventory primarily due to increased purchases to satisfy future expected demand and for the ongoing transition to the next generation of Evolv Express systems;

[0001628280-24-036182:mdna:182]
•$3.0 million increase in prepaid expenses and other current assets primarily due to prepaid deposits related to orders placed for Evolv Express units; partially offset by

[0001628280-24-036182:mdna:183]
•$8.3 million increase in deferred revenue due to a higher volume of sales;

[0001628280-24-036182:mdna:184]
•$1.7 million decrease in accounts payable (excluding the non-cash portion related to capital expenditures incurred but not yet paid) due primarily to the timing of vendor payments; and

[0001628280-24-036182:mdna:185]
•$2.3 million decrease in contract assets related to the timing of revenue recognition.

[0001628280-24-036182:mdna:186]
Changes in operating assets and liabilities for the six months ended June 30, 2023 are primarily related to the following:

[0001628280-24-036182:mdna:187]
•$5.1 million decrease in inventory primarily due to a higher proportion of finished goods recorded as property and equipment based on our expectations of the future mix of Evolv Express units to be leased to customers versus sold to customers;

[0001628280-24-036182:mdna:188]
•$24.1 million increase in deferred revenue due to a higher volume of sales; partially offset by

[0001628280-24-036182:mdna:189]
•$7.4 million decrease in accounts payable (excluding the non-cash change in capital expenditures incurred but not yet paid from December 31, 2022 to June 30, 2023) primarily due to a decrease in inventory

[0001628280-24-036182:mdna:190]
[same as prior period, unchanged from 0001628280-24-022282:mdna:149]

[0001628280-24-036182:mdna:191]
During the six months ended June 30, 2024, cash used in investing activities was $5.9 million, consisting of $21.1 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers and $3.4 million for the development of internal-use software and software embedded in products to be sold or leased, offset by a net $30.3 million inflow related to purchases and redemptions of marketable securities.

[0001628280-24-036182:mdna:192]
During the six months ended June 30, 2023, cash used in investing activities was $64.1 million, consisting primarily of $33.2 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers, $29.4 million outflow related to purchases of marketable securities, and $1.6 million for the development of internal-use software.

[0001628280-24-036182:mdna:193]
[same as prior period, unchanged from 0001628280-24-022282:mdna:152]

[0001628280-24-036182:mdna:194]
During the six months ended June 30, 2024, cash used in financing activities was $0.6 million, consisting of $0.6 million of proceeds from the exercise of stock options.

[0001628280-24-036182:mdna:195]
During the six months ended June 30, 2023, cash used in financing activities was $30.0 million, consisting of $1.9 million of proceeds under the 2022 SVB Credit Agreement and $0.3 million of proceeds from the exercise of stock options, offset by $31.9 million related to the full repayment of amounts owed under the 2022 SVB Credit Agreement and $0.3 million payment of debt issuance costs and a prepayment penalty.

[0001628280-24-036182:mdna:196]
[same as prior period, unchanged from 0001628280-24-022282:mdna:155]

[0001628280-24-036182:mdna:197]
[same as prior period, unchanged from 0001628280-24-022282:mdna:156]

[0001628280-24-036182:mdna:198]
[same as prior period, unchanged from 0001628280-24-022282:mdna:157]

[0001628280-24-036182:mdna:199]
Our critical accounting policies and estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” of the 2023 Form 10-K. There have been no material changes to our critical accounting policies and estimates during the six months ended June 30, 2024.
