# EVLV 8-K — 0001628280-24-036115 filed 2024-08-08

## item codes, every 8-K on or before 2024-08-08

- 2024-08-08 0001628280-24-036115 — 2.02, 9.01
- 2024-06-04 0001628280-24-026572 — 5.07
- 2024-05-09 0001628280-24-022265 — 2.02, 9.01
- 2024-02-29 0001628280-24-007980 — 2.02, 9.01
- 2024-02-20 0001104659-24-025077 — 7.01, 9.01
- 2024-01-31 0001628280-24-002618 — 5.03, 9.01
- 2023-11-09 0001628280-23-038267 — 2.02, 9.01
- 2023-11-06 0001104659-23-114499 — 5.02
- 2023-10-25 0001628280-23-035145 — 4.02
- 2023-10-12 0001104659-23-108693 — 2.02, 7.01, 9.01
- 2023-08-10 0001628280-23-028861 — 2.02, 9.01
- 2023-06-02 0001628280-23-020680 — 5.07
- 2023-05-10 0001628280-23-017243 — 2.02, 9.01
- 2023-04-03 0001628280-23-010402 — 1.02, 2.04, 8.01, 9.01
- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2024-08-08

- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-24-036115:8k_2_02:1]
EX-99.1
2
evlv-20240808exx991.htm
EX-99.1

[0001628280-24-036115:8k_2_02:2]
Document

[0001628280-24-036115:8k_2_02:3]
Exhibit 99.1

[0001628280-24-036115:8k_2_02:4]
Investor Relations:

[0001628280-24-036115:8k_2_02:5]
Brian Norris

[0001628280-24-036115:8k_2_02:6]
Senior Vice President of Finance and Investor Relations

[0001628280-24-036115:8k_2_02:7]
bnorris@evolvtechnology.com

[0001628280-24-036115:8k_2_02:8]
Evolv Technology Reports Second Quarter Financial Results

[0001628280-24-036115:8k_2_02:9]
•Q2 Revenue of $25.5 million, up 29% year-over-year

[0001628280-24-036115:8k_2_02:10]
•Q2 Ending ARR1 of $88.9 million, up 64% year-over-year

[0001628280-24-036115:8k_2_02:11]
•Q2 Ending RPO2 of $262.9 million, up 33% year-over-year

[0001628280-24-036115:8k_2_02:12]
•Q2 Ending Evolv Express® subscriptions of 5,323, up 57% year-over-year

[0001628280-24-036115:8k_2_02:13]
Waltham, Massachusetts – August 8, 2024 – Evolv Technology (NASDAQ: EVLV), a leading security technology company pioneering AI-based screening designed to help create safer experiences, today announced financial results for the quarter ended June 30, 2024.

[0001628280-24-036115:8k_2_02:14]
Results for the Second Quarter of 2024

[0001628280-24-036115:8k_2_02:15]
Total revenue for the second quarter of 2024 was $25.5 million, an increase of 29% compared to $19.8 million for the second quarter of 2023. Annual Recurring Revenue (“ARR”)1 was $88.9 million at the end of second quarter of 2024, an increase of 64% compared to $54.3 million at the end of the second quarter of 2023. Net income for the second quarter of 2024 was $3.5 million, or $0.02 per basic and diluted share, compared to net loss of $(66.8) million, or $(0.45) per basic and diluted share, in the second quarter of 2023. Adjusted earnings (loss)3 for the second quarter of 2024 was $(11.1) million, or $(0.06) per diluted share, compared to adjusted earnings (loss)3 of $(14.3) million, or $(0.10) per diluted share, for the second quarter of 2023. Adjusted EBITDA3 for the second quarter of 2024 was $(7.9) million compared to $(13.8) million in the second quarter of 2023. As of June 30, 2024, the Company had cash, cash equivalents, marketable securities, and restricted cash of $56.7 million and no debt.

[0001628280-24-036115:8k_2_02:16]
Results for the First Six Months of 2024

[0001628280-24-036115:8k_2_02:17]
Total revenue for the six months ended June 30, 2024 was $47.2 million, an increase of 23% compared to $38.4 million for the six months ended June 30, 2023. Net loss for the six months ended June 30, 2024 was $(8.2) million, or $(0.05) per basic and diluted share, compared to $(95.4) million, or $(0.65) per basic and diluted share, in the six months ended June 30, 2023. Adjusted earnings (loss)3 for the six months ended June 30, 2024 was $(24.2) million, or $(0.16) per diluted share, compared to adjusted earnings (loss)3 of $(31.2) million, or $(0.21) per diluted share, for the six months ended June 30, 2023. Adjusted EBITDA3 for the six months ended June 30, 2024 was $(18.6) million compared to $(29.3) million in the six months ended June 30, 2023.

[0001628280-24-036115:8k_2_02:18]
The following table summarizes the breakdown of recurring and non-recurring revenue4 for each period presented:

[0001628280-24-036115:8k_2_02:19]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | % Change |  | 2024 |  | 2023 |  | % Change |
| Recurring revenue | $ | 21,249 |  |  | $ | 11,689 |  |  | 82 | % |  | $ | 40,630 |  |  | $ | 20,764 |  |  | 96 | % |
| Non-recurring revenue | 4,291 |  |  | 8,136 |  |  | (47) | % |  | 6,578 |  |  | 17,642 |  |  | (63) | % |
| Total revenue | $ | 25,540 |  |  | $ | 19,825 |  |  | 29 | % |  | $ | 47,208 |  |  | $ | 38,406 |  |  | 23 | % |

[0001628280-24-036115:8k_2_02:20]
The following table summarizes operating cash flows for each period presented:

[0001628280-24-036115:8k_2_02:21]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net loss | $ | 3,462 |  |  | $ | (66,754) |  |  | $ | (8,182) |  |  | $ | (95,363) |  |
| Non-cash expense | (12,264) |  |  | 54,225 |  |  | (10,611) |  |  | 68,230 |  |
| Changes in operating assets and liabilities | (13,077) |  |  | 7,208 |  |  | (19,169) |  |  | 18,378 |  |
| Net cash used in operating activities | $ | (21,879) |  |  | $ | (5,321) |  |  | $ | (37,962) |  |  | $ | (8,755) |  |

[0001628280-24-036115:8k_2_02:22]
Company Comments on Outlook for 2024

[0001628280-24-036115:8k_2_02:23]
The Company today commented on its business outlook for 2024. The Company's outlook is based on the current indications for its business, which may change at any time.

[0001628280-24-036115:8k_2_02:24]
| Estimate ($ in millions) |  | Issued May 9, 2024 |  | Issued August 8, 2024 |
| Total Revenue |  | ~$100 |  | Reaffirmed |
| ARR1 (ARR) at 12/31/24 |  | ~$100 |  | Reaffirmed |
| Adjusted Gross Margin3 |  | ~60% |  | Reaffirmed |
| Adjusted EBITDA3 |  | Improve by 40%+ |  | Reaffirmed |

[0001628280-24-036115:8k_2_02:25]
Company to Host Live Conference Call and Webcast

[0001628280-24-036115:8k_2_02:26]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business and other matters.  The conference call may be accessed in the United States by dialing +1.877.692.8955 and using access code 825879.  The conference call may be accessed outside of the United States by dialing +1.234.720.6979 and using the same access code. The conference call will be simultaneously webcast on the Company’s investor relations website, which can be accessed at http://ir.evolvtechnology.com.  The press release with the financial results will be available on the Company’s website prior to the conference call. A replay of the conference call will be available for a period of 30 days by dialing +1.866.207.1041 or +1.402.970.0847 and using access code 8674340 or by accessing the webcast replay on the Company’s investor relations website at http://ir.evolvtechnology.com.

[0001628280-24-036115:8k_2_02:27]
About Evolv Technology

[0001628280-24-036115:8k_2_02:28]
Evolv Technology (NASDAQ: EVLV) uses advanced sensors, artificial intelligence powered software, and cloud services to reliably detect firearms, improvised explosives, and certain types of knives while ignoring many harmless items such as cell phones and keys. Its solutions and services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. Evolv has digitally transformed the gateways in many places where people gather by enabling seamless integration combined with powerful analytics and insights. Evolv’s advanced systems have scanned more than a billion people since 2019. Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category, as well as Sport Business Journal’s (SBJ) awards for “Best In Fan Experience Technology” and “Best In Sports Technology”. Evolv®, Evolv Express®, Evolv Insights®, Evolv Cortex AI®, and Evolv Visual Gun Detection™ are registered trademarks or trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit https://evolvtechnology.com.

[0001628280-24-036115:8k_2_02:29]
1 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001628280-24-036115:8k_2_02:30]
2 We define Remaining Performance Obligation, or RPO, as estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied or partially satisfied as of the end of the quarter.

[0001628280-24-036115:8k_2_02:31]
3 Non-GAAP Financial Measures In this press release, the Company’s adjusted gross profit (loss), adjusted gross margin, adjusted operating expenses, adjusted operating income (loss), adjusted EBITDA, adjusted earnings (loss), and adjusted earnings per diluted share are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit and adjusted gross margin exclude one-time expenses, stock-based compensation expense, and amortization of capitalized stock-based compensation which management believes provides a more meaningful representation of contribution margin. Adjusted operating expenses is defined as operating expenses less one-time expenses, stock-based compensation expense, amortization of capitalized stock-based compensation, and loss on impairment of lease equipment which management believes provides a more meaningful representation of on-going operating expense levels. Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, share-based compensation, interest expense (income), loss on extinguishment of debt, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of lease equipment, and certain other one-time expenses. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, amortization of capitalized stock-based compensation, loss on extinguishment of debt, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of lease equipment, and certain other one-time expenses. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operating performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release. The Company is unable to provide a reconciliation of Adjusted Gross Margin to GAAP Gross Margin and Adjusted EBITDA to Net Income (Loss), each measure's most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact these GAAP financial measures are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of derivative liabilities, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001628280-24-036115:8k_2_02:32]
4 Recurring revenue includes the recurring portion of revenue associated with pure subscription contracts and hardware purchase subscription contracts. Non-recurring revenue includes revenue that is one-time in nature, such as product revenue, shipping revenue, and revenue from installation, training, and professional services.

[0001628280-24-036115:8k_2_02:33]
Forward-Looking Statements

[0001628280-24-036115:8k_2_02:34]
prospective performance and opportunities and competitors, revenues, products and services, pricing, operating expenses, market trends, liquidity, cash flows and uses of cash, capital expenditures; the Company’s reliance on third party contract manufacturing and distribution, and a global supply chain; the Company recognizes a substantial portion of its revenue ratably over the term of its agreements, and, as a result, downturns or upturns in sales may not be immediately reflected in its operating results; the rate of innovation required to maintain competitiveness in the markets in which the Company competes; the competitiveness of the market in which the Company competes; the failure of our products to detect threats could result in injury or loss of life, which could harm our brand, reputation, and results of operations; the loss of designation of our Evolv Express® system as a Qualified Anti-Terrorism Technology under the Homeland Security SAFETY Act; risks related to our business model, which is predicated, in part, on building a customer base that will generate a recurring stream of revenues through the sale of our subscription contracts; the ability for the Company to obtain, maintain, protect and enforce the Company’s intellectual property rights and use of “open source” software; the concentration of the Company’s revenues on a single solution; the Company’s ability to timely design, produce and launch its solutions, the Company’s ability to invest in growth initiatives and pursue acquisition opportunities; the limited liquidity and trading of the Company’s securities; risks related to existing and changing tax laws; geopolitical risk and changes in applicable laws or regulations; the possibility that the Company may be adversely affected by other economic, business, and/or competitive factors; operational risk; risks related to material weaknesses in our internal control over financial reporting and our remediation plans; risks related to increasing attention to and evolving expectations for, environmental, social, and governance initiatives; the impact of fluctuating general economic and market conditions and reductions in spending; the need for additional capital to support business growth, which might not be available on acceptable terms, if at all; and litigation and regulatory enforcement risks, including the diversion of management time and attention and the additional costs and demands on resources. These and other important factors discussed under the caption “Risk Factors” in our Annual Report on Form 10-K for the year ended December 31, 2023 filed with the Securities and Exchange Commission ("SEC") on February 29, 2024, as any such factors may be updated from time to time in our other filings with the SEC, including the Quarterly Report on Form 10-Q for the quarter ended June 30, 2024. The forward-looking statements in this press release and related presentation materials are based upon information available to us as of the date hereof, and while we believe such information forms a reasonable basis for such statements, it may be limited or incomplete, and our statements should not be read to indicate that we have conducted an exhaustive inquiry into, or review of, all potentially available relevant information. These statements are inherently uncertain and investors are cautioned not to unduly rely upon these statements.

[0001628280-24-036115:8k_2_02:35]
You should review this press release and the documents that we reference in this press release and related presentation materials with the understanding that our actual future results, levels of activity, performance and achievements may be materially different from what we expect. We qualify all of our forward-looking statements by these cautionary statements. Except as required by applicable law, we do not plan to publicly update or revise any forward-looking statements contained in this press release and related presentation materials, whether as a result of any new information, future events or otherwise.

[0001628280-24-036115:8k_2_02:36]
EVOLV TECHNOLOGY

[0001628280-24-036115:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (LOSS)

[0001628280-24-036115:8k_2_02:38]
(In thousands, except share and per share data)

[0001628280-24-036115:8k_2_02:39]
(Unaudited)

[0001628280-24-036115:8k_2_02:40]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 2,044 |  |  | $ | 7,243 |  |  | $ | 2,647 |  |  | $ | 15,997 |  |
| Subscription revenue | 15,903 |  |  | 7,964 |  |  | 30,406 |  |  | 14,430 |  |
| Service revenue | 5,553 |  |  | 3,905 |  |  | 10,937 |  |  | 6,691 |  |
| License fee and other revenue | 2,040 |  |  | 713 |  |  | 3,218 |  |  | 1,288 |  |
| Total revenue | 25,540 |  |  | 19,825 |  |  | 47,208 |  |  | 38,406 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 3,149 |  |  | 7,722 |  |  | 5,926 |  |  | 18,300 |  |
| Cost of subscription revenue | 6,436 |  |  | 3,406 |  |  | 12,215 |  |  | 5,757 |  |
| Cost of service revenue | 1,311 |  |  | 1,014 |  |  | 2,522 |  |  | 1,597 |  |
| Cost of license fee and other revenue | 172 |  |  | 270 |  |  | 301 |  |  | 574 |  |
| Total cost of revenue | 11,068 |  |  | 12,412 |  |  | 20,964 |  |  | 26,228 |  |
| Gross profit | 14,472 |  |  | 7,413 |  |  | 26,244 |  |  | 12,178 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,722 |  |  | 6,395 |  |  | 11,927 |  |  | 11,784 |  |
| Sales and marketing | 16,892 |  |  | 13,613 |  |  | 32,897 |  |  | 26,417 |  |
| General and administrative | 14,185 |  |  | 10,874 |  |  | 26,025 |  |  | 19,800 |  |
| Loss from impairment of property and equipment | — |  |  | 157 |  |  | — |  |  | 294 |  |
| Total operating expenses | 36,799 |  |  | 31,039 |  |  | 70,849 |  |  | 58,295 |  |
| Loss from operations | (22,327) |  |  | (23,626) |  |  | (44,605) |  |  | (46,117) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | — |  |  | — |  |  | (654) |  |
| Interest income | 681 |  |  | 1,853 |  |  | 1,766 |  |  | 2,806 |  |
| Other income (expense), net | (39) |  |  | (22) |  |  | (67) |  |  | (3) |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | (626) |  |
| Change in fair value of contingent earn-out liability | 16,514 |  |  | (28,113) |  |  | 23,413 |  |  | (31,431) |  |
| Change in fair value of contingently issuable common stock liability | 3,747 |  |  | (5,095) |  |  | 4,274 |  |  | (5,837) |  |
| Change in fair value of public warrant liability | 4,886 |  |  | (11,751) |  |  | 7,037 |  |  | (13,501) |  |
| Total other income (expense), net | 25,789 |  |  | (43,128) |  |  | 36,423 |  |  | (49,246) |  |
| Net income (loss) | $ | 3,462 |  |  | $ | (66,754) |  |  | $ | (8,182) |  |  | $ | (95,363) |  |
| Net income (loss) attributable to common stockholders – basic and diluted | $ | 3,421 |  |  | $ | (66,754) |  |  | $ | (8,182) |  |  | $ | (95,363) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |
| Basic | 156,473,080 |  | 148,882,160 |  | 154,774,899 |  | 147,664,534 |
| Diluted | 171,563,943 |  | 148,882,160 |  | 154,774,899 |  | 147,664,534 |
| Net income (loss) per share |  |  |  |  |  |  |  |
| Basic | $ | 0.02 |  |  | $ | (0.45) |  |  | $ | (0.05) |  |  | $ | (0.65) |  |
| Diluted | $ | 0.02 |  |  | $ | (0.45) |  |  | $ | (0.05) |  |  | $ | (0.65) |  |
| Net income (loss) | $ | 3,462 |  |  | $ | (66,754) |  |  | $ | (8,182) |  |  | $ | (95,363) |  |
| Other comprehensive income (loss) |  |  |  |  |  |  |  |
| Cumulative translation adjustment | 8 |  |  | (17) |  |  | 11 |  |  | (33) |  |
| Total other comprehensive income (loss) | 8 |  |  | (17) |  |  | 11 |  |  | (33) |  |
| Total comprehensive income (loss) | $ | 3,470 |  |  | $ | (66,771) |  |  | $ | (8,171) |  |  | $ | (95,396) |  |

[0001628280-24-036115:8k_2_02:41]
EVOLV TECHNOLOGY

[0001628280-24-036115:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-24-036115:8k_2_02:43]
(In thousands, except share and per share data)

[0001628280-24-036115:8k_2_02:44]
(Unaudited)

[0001628280-24-036115:8k_2_02:45]
|  | June 30, 2024 |  | December 31, 2023 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 35,698 |  |  | $ | 67,162 |  |
| Restricted cash | — |  |  | 275 |  |
| Marketable securities | 20,757 |  |  | 51,289 |  |
| Accounts receivable, net | 36,428 |  |  | 22,611 |  |
| Inventory | 18,604 |  |  | 9,507 |  |
| Current portion of contract assets | 1,690 |  |  | 3,707 |  |
| Current portion of commission asset | 4,810 |  |  | 4,339 |  |
| Prepaid expenses and other current assets | 19,912 |  |  | 16,954 |  |
| Total current assets | 137,899 |  |  | 175,844 |  |
| Restricted cash, noncurrent | 275 |  |  | — |  |
| Contract assets, noncurrent | 144 |  |  | 451 |  |
| Commission asset, noncurrent | 7,128 |  |  | 7,107 |  |
| Property and equipment, net | 120,045 |  |  | 112,921 |  |
| Operating lease right-of-use assets | 2,161 |  |  | 1,195 |  |
| Other assets | 865 |  |  | 1,202 |  |
| Total assets | $ | 268,517 |  |  | $ | 298,720 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 5,574 |  |  | $ | 17,400 |  |
| Accrued expenses and other current liabilities | 15,913 |  |  | 15,578 |  |
| Current portion of deferred revenue | 56,168 |  |  | 47,677 |  |
| Current portion of operating lease liabilities | 1,754 |  |  | 1,391 |  |
| Total current liabilities | 79,409 |  |  | 82,046 |  |
| Deferred revenue, noncurrent | 23,655 |  |  | 23,813 |  |
| Operating lease liabilities, noncurrent | 566 |  |  | — |  |
| Contingent earn-out liability | 5,706 |  |  | 29,119 |  |
| Contingently issuable common stock liability | 2,256 |  |  | 6,530 |  |
| Public warrant liability | 3,852 |  |  | 10,889 |  |
| Total liabilities | 115,444 |  |  | 152,397 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at June 30, 2024 and December 31, 2023; no shares issued and outstanding at June 30, 2024 and December 31, 2023 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at June 30, 2024 and December 31, 2023; 157,474,122 and 151,310,080 shares issued and outstanding at June 30, 2024 and December 31, 2023, respectively | 16 |  |  | 15 |  |
| Additional paid-in capital | 459,745 |  |  | 444,825 |  |
| Accumulated other comprehensive loss | (42) |  |  | (53) |  |
| Accumulated deficit | (306,646) |  |  | (298,464) |  |
| Stockholders’ equity | 153,073 |  |  | 146,323 |  |
| Total liabilities and stockholders’ equity | $ | 268,517 |  |  | $ | 298,720 |  |

[0001628280-24-036115:8k_2_02:46]
EVOLV TECHNOLOGY

[0001628280-24-036115:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-24-036115:8k_2_02:48]
(In thousands)

[0001628280-24-036115:8k_2_02:49]
(Unaudited)

[0001628280-24-036115:8k_2_02:50]
|  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (8,182) |  |  | $ | (95,363) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 7,442 |  |  | 4,087 |  |
| Write-off of inventory and change in inventory reserve | 1,725 |  |  | 337 |  |
| Loss from impairment of property and equipment | — |  |  | 294 |  |
| Stock-based compensation | 13,834 |  |  | 11,732 |  |
| Non-cash interest expense | — |  |  | 22 |  |
| Amortization (accretion) of premium (discount) on marketable securities, net of change in accrued interest | 181 |  |  | (242) |  |
| Non-cash lease expense | 728 |  |  | 432 |  |
| Change in allowance for expected credit losses | 203 |  |  | 173 |  |
| Loss on extinguishment of debt | — |  |  | 626 |  |
| Change in fair value of earn-out liability | (23,413) |  |  | 31,431 |  |
| Change in fair value of contingently issuable common stock | (4,274) |  |  | 5,837 |  |
| Change in fair value of public warrant liability | (7,037) |  |  | 13,501 |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (14,020) |  |  | (646) |  |
| Inventory | (10,354) |  |  | 5,080 |  |
| Commission assets | (492) |  |  | (1,258) |  |
| Contract assets | 2,324 |  |  | (1,184) |  |
| Other assets | 337 |  |  | (43) |  |
| Prepaid expenses and other current assets | (2,958) |  |  | 580 |  |
| Accounts payable | (1,653) |  |  | (7,409) |  |
| Deferred revenue | 8,333 |  |  | 24,113 |  |
| Accrued expenses and other current liabilities | 79 |  |  | (342) |  |
| Operating lease liability | (765) |  |  | (513) |  |
| Net cash used in operating activities | (37,962) |  |  | (8,755) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (3,408) |  |  | (1,599) |  |
| Purchases of property and equipment | (21,092) |  |  | (33,173) |  |
| Proceeds from sale of property and equipment | — |  |  | 60 |  |
| Purchases of marketable securities | (14,567) |  |  | (29,405) |  |
| Proceeds from maturities of marketable securities | 44,918 |  |  | — |  |
| Net cash provided by (used in) investing activities | 5,851 |  |  | (64,117) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 636 |  |  | 344 |  |
| Proceeds from long-term debt | — |  |  | 1,876 |  |
| Repayment of principal on long-term debt | — |  |  | (31,876) |  |
| Payment of debt issuance costs and prepayment penalty | — |  |  | (332) |  |
| Net cash provided by (used in) financing activities | 636 |  |  | (29,988) |  |
| Effect of exchange rate changes on cash and cash equivalents | 11 |  |  | (33) |  |
| Net decrease in cash, cash equivalents and restricted cash | (31,464) |  |  | (102,893) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 67,437 |  |  | 230,058 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 35,973 |  |  | $ | 127,165 |  |

[0001628280-24-036115:8k_2_02:51]
EVOLV TECHNOLOGY

[0001628280-24-036115:8k_2_02:52]
SUMMARY OF KEY OPERATING STATISTICS

[0001628280-24-036115:8k_2_02:53]
(Unaudited)

[0001628280-24-036115:8k_2_02:54]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2023 |  | June 30,2023 |  | September 30,2023 |  | December 31,2023 |  | March 31,2024 |  | June 30,2024 |  |  |  |  |
| New customers |  | 61 |  |  | 74 |  |  | 70 |  |  | 75 |  |  | 53 |  |  | 84 |  |  |  |  |  |
| Annual recurring revenue |  | $ | 42,021 |  |  | $ | 54,339 |  |  | $ | 65,774 |  |  | $ | 74,989 |  |  | $ | 82,511 |  |  | $ | 88,864 |  |  |  |  |  |
| Recurring revenue |  | $ | 9,075 |  |  | $ | 11,689 |  |  | $ | 14,377 |  |  | $ | 17,350 |  |  | $ | 19,381 |  |  | $ | 21,249 |  |  |  |  |  |
| Remaining performance obligation |  | $ | 161,813 |  |  | $ | 198,296 |  |  | $ | 221,126 |  |  | $ | 240,513 |  |  | $ | 254,070 |  |  | $ | 262,947 |  |  |  |  |  |
| Net additions |  | 520 |  |  | 599 |  |  | 628 |  |  | 491 |  |  | 377 |  |  | 441 |  |  |  |  |  |
| Ending deployed units |  | 2,787 |  |  | 3,386 |  |  | 4,014 |  |  | 4,505 |  |  | 4,882 |  |  | 5,323 |  |  |  |  |  |

[0001628280-24-036115:8k_2_02:55]
EVOLV TECHNOLOGY

[0001628280-24-036115:8k_2_02:56]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001628280-24-036115:8k_2_02:57]
(In thousands)

[0001628280-24-036115:8k_2_02:58]
(Unaudited)

[0001628280-24-036115:8k_2_02:59]
|  | Three Months Ended, |
|  |  | March 31,2023 |  | June 30,2023 |  | September 30,2023 |  | December 31,2023 |  | March 31,2024 |  | June 30,2024 |  |  |  |  |
| Operating expenses, GAAP |  | $ | 27,256 |  |  | $ | 31,039 |  |  | $ | 31,629 |  |  | $ | 32,167 |  |  | $ | 34,050 |  |  | $ | 36,799 |  |  |  |  |  |
| Stock-based compensation |  | (4,898) |  |  | (6,505) |  |  | (5,454) |  |  | (6,711) |  |  | (6,272) |  |  | (7,251) |  |  |  |  |  |
| Loss on impairment of lease equipment |  | (137) |  |  | (157) |  |  | (28) |  |  | — |  |  | — |  |  | — |  |  |  |  |  |
| Other one-time expenses |  | (53) |  |  | (683) |  |  | (945) |  |  | (535) |  |  | (476) |  |  | (3,011) |  |  |  |  |  |
| Adjusted operating expenses |  | $ | 22,168 |  |  | $ | 23,694 |  |  | $ | 25,202 |  |  | $ | 24,921 |  |  | $ | 27,302 |  |  | $ | 26,537 |  |  |  |  |  |

[0001628280-24-036115:8k_2_02:60]
EVOLV TECHNOLOGY

[0001628280-24-036115:8k_2_02:61]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT, GAAP GROSS MARGIN TO ADJUSTED GROSS MARGIN AND GAAP OPERATING INCOME (LOSS) TO ADJUSTED OPERATING INCOME (LOSS)

[0001628280-24-036115:8k_2_02:62]
(In thousands)

[0001628280-24-036115:8k_2_02:63]
(Unaudited)

[0001628280-24-036115:8k_2_02:64]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue | $ | 25,540 |  |  | $ | 19,825 |  |  | $ | 47,208 |  |  | $ | 38,406 |  |
| Cost of revenue | 11,068 |  |  | 12,412 |  |  | 20,964 |  |  | 26,228 |  |
| Gross profit, GAAP | 14,472 |  |  | 7,413 |  |  | 26,244 |  |  | 12,178 |  |
| Stock-based compensation | 173 |  |  | 184 |  |  | 311 |  |  | 329 |  |
| Amortization of capitalized stock-based compensation | 15 |  |  | 11 |  |  | 29 |  |  | 21 |  |
| Other one-time expenses | 106 |  |  | — |  |  | 1,310 |  |  | — |  |
| Adjusted gross profit | $ | 14,766 |  |  | $ | 7,608 |  |  | $ | 27,894 |  |  | $ | 12,528 |  |
| Gross margin % | 56.7 | % |  | 37.4 | % |  | 55.6 | % |  | 31.7 | % |
| Adjusted gross margin % | 57.8 | % |  | 38.4 | % |  | 59.1 | % |  | 32.6 | % |

[0001628280-24-036115:8k_2_02:65]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Operating loss, GAAP | $ | (22,327) |  |  | $ | (23,626) |  |  | $ | (44,605) |  |  | $ | (46,117) |  |
| Stock-based compensation | 7,424 |  |  | 6,689 |  |  | 13,834 |  |  | 11,732 |  |
| Amortization of capitalized stock-based compensation | 15 |  |  | 11 |  |  | 29 |  |  | 21 |  |
| Loss on impairment of lease equipment | — |  |  | 157 |  |  | — |  |  | 294 |  |
| Other one-time expenses | 3,117 |  |  | 683 |  |  | 4,797 |  |  | 736 |  |
| Adjusted operating loss | $ | (11,771) |  |  | $ | (16,086) |  |  | $ | (25,945) |  |  | $ | (33,334) |  |

[0001628280-24-036115:8k_2_02:66]
EVOLV TECHNOLOGY

[0001628280-24-036115:8k_2_02:67]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-24-036115:8k_2_02:68]
(In thousands)

[0001628280-24-036115:8k_2_02:69]
(Unaudited)

[0001628280-24-036115:8k_2_02:70]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income (loss) | $ | 3,462 |  |  | $ | (66,754) |  |  | $ | (8,182) |  |  | $ | (95,363) |  |
| Depreciation & amortization | 3,968 |  |  | 2,272 |  |  | 7,442 |  |  | 4,087 |  |
| Stock-based compensation | 7,424 |  |  | 6,689 |  |  | 13,834 |  |  | 11,732 |  |
| Interest expense (income) | (681) |  |  | (1,853) |  |  | (1,766) |  |  | (2,152) |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | 626 |  |
| Change in fair value of contingent earn-out liability | (16,514) |  |  | 28,113 |  |  | (23,413) |  |  | 31,431 |  |
| Change in fair value of contingently issuable common stock liability | (3,747) |  |  | 5,095 |  |  | (4,274) |  |  | 5,837 |  |
| Change in fair value of public warrant liability | (4,886) |  |  | 11,751 |  |  | (7,037) |  |  | 13,501 |  |
| Loss on impairment of lease equipment | — |  |  | 157 |  |  | — |  |  | 294 |  |
| Other one-time expenses | 3,117 |  |  | 683 |  |  | 4,797 |  |  | 736 |  |
| Adjusted EBITDA | $ | (7,857) |  |  | $ | (13,847) |  |  | $ | (18,599) |  |  | $ | (29,271) |  |

[0001628280-24-036115:8k_2_02:71]
EVOLV TECHNOLOGY

[0001628280-24-036115:8k_2_02:72]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001628280-24-036115:8k_2_02:73]
(In thousands, except share and per share data)

[0001628280-24-036115:8k_2_02:74]
(Unaudited)

[0001628280-24-036115:8k_2_02:75]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income (loss) | $ | 3,462 |  |  | $ | (66,754) |  |  | $ | (8,182) |  |  | $ | (95,363) |  |
| Stock-based compensation | 7,424 |  |  | 6,689 |  |  | 13,834 |  |  | 11,732 |  |
| Amortization of capitalized stock-based compensation | 15 |  |  | 11 |  |  | 29 |  |  | 21 |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | 626 |  |
| Change in fair value of contingent earn-out liability | (16,514) |  |  | 28,113 |  |  | (23,413) |  |  | 31,431 |  |
| Change in fair value of contingently issuable common stock liability | (3,747) |  |  | 5,095 |  |  | (4,274) |  |  | 5,837 |  |
| Change in fair value of public warrant liability | (4,886) |  |  | 11,751 |  |  | (7,037) |  |  | 13,501 |  |
| Loss on impairment of lease equipment | — |  |  | 157 |  |  | — |  |  | 294 |  |
| Other one-time expenses | 3,117 |  |  | 683 |  |  | 4,797 |  |  | 736 |  |
| Adjusted loss | $ | (11,129) |  |  | $ | (14,255) |  |  | $ | (24,246) |  |  | $ | (31,185) |  |
| Weighted average common shares outstanding – diluted | 171,563,943 |  |  | 148,882,160 |  |  | 154,774,899 |  |  | 147,664,534 |  |
| Adjusted loss per share – diluted | $ | (0.06) |  |  | $ | (0.10) |  |  | $ | (0.16) |  |  | $ | (0.21) |  |
