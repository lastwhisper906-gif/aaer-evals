# EVLV note change history — 0001628280-24-022282 → 0001628280-24-036182


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-08-08):
[0001628280-24-036182:note_history:1]
In the ordinary course of business, the Company provides indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. The Company has not incurred or accrued for any material costs as a result of such indemnifications in its condensed consolidated financial statements as of June 30, 2024 or December 31, 2023.
  (was, 2024-05-09, similarity 0.8481):
[0001628280-24-022282:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is

- added (2024-08-08):
[0001628280-24-036182:note_history:2]
The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. Except for the regulatory matters discussed below, based upon information presently known to management, the Company has not accrued a loss for any other legal matters, as a loss is not probable and reasonably estimable. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

- changed (2024-08-08):
[0001628280-24-036182:note_history:3]
In March 2024, an Evolv shareholder filed in the U.S. District Court for the District of Massachusetts a putative class action lawsuit, captioned Raby v. Evolv Technologies Holdings, Inc., et al. case number 1:24-cv-10761, alleging that Evolv and certain of its current and former executives and other individuals violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 based on alleged misstatements concerning the Company’s products. This litigation is in the preliminary stages, and the outcome of any complex legal proceeding is inherently unpredictable and subject to significant uncertainties. The Company intends to vigorously defend itself in this matter.
  (was, 2024-05-09, similarity 0.9494):
[0001628280-24-022282:note_history:3]
In March 2024, an Evolv shareholder filed in the U.S. District Court for the District of Massachusetts a putative class action lawsuit, captioned Raby v. Evolv Technologies Holdings, Inc., et al. case number 1:24-cv-10761, alleging that Evolv and certain of its current and former executives and other individuals violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 based on alleged misstatements concerning the Company’s products. This litigation is in the preliminary stages, and the outcome of any complex legal proceeding is inherently unpredictable and subject to significant uncertainties.

- added (2024-08-08):
[0001628280-24-036182:note_history:4]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of legal and regulatory matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the condensed consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.

- added (2024-08-08):
[0001628280-24-036182:note_history:5]
Any resolution or litigation with the FTC, the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate. As of June 30, 2024, we have accrued $1.1 million for such matters. These amounts were recorded in other accrued liabilities in the condensed consolidated balance sheets and the associated expenses were recorded in general and administrative expenses in the condensed consolidated statements of operations. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations. Actual loss can be significantly greater or less than our estimated accrual. Legal fees incurred in connection with ongoing legal matters are considered period costs and are expensed as incurred.

- removed (2024-08-08):
[0001628280-24-022282:note_history:6]
not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of March 31, 2024 or December 31, 2023.

- removed (2024-08-08):
[0001628280-24-022282:note_history:7]
The Company has identified certain claims as a result of which a loss may be incurred, but in the aggregate any loss is expected to be immaterial. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. Based upon information presently known to management, the Company has not accrued a loss for these matters, including the matter described below, as a loss is not probable and reasonably estimable. While it is reasonably possible a loss may be incurred, the Company is unable to estimate a loss or range of loss in these matters. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

- removed (2024-08-08):
[0001628280-24-022282:note_history:8]
Any resolution or litigation with the FTC, the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on us and/or require us to make changes to our business practices. These costs and requirements may be material both individually and in the aggregate.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-08-08):
[0001628280-24-036182:note_history:9]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company pioneering AI-based screening designed to help create safer experiences, with key market categories that include education, healthcare, sports, and live entertainment.

- added (2024-08-08):
[0001628280-24-036182:note_history:10]
The Company's solutions combine proprietary software and hardware, delivered as a long-term Software-as-a-Service subscription model.  Its flagship product, Evolv Express®, uses advanced sensors, artificial intelligence powered software, and cloud services to reliably detect firearms, improvised explosives, and certain types of knives while ignoring many harmless items such as cell phones and keys.  These solutions and services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

- added (2024-08-08):
[0001628280-24-036182:note_history:11]
The accompanying unaudited condensed consolidated financial statements as of June 30, 2024, and for the three and six months ended June 30, 2024 and 2023 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2023 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of June 30, 2024 and the results of its operations for the three and six months ended June 30, 2024 and 2023 and cash flows for the six months ended June 30, 2024 and 2023. The results for the three and six months ended June 30, 2024 are not necessarily indicative of results to be expected for the year ending December 31, 2024, any other interim periods, or any future year or period.

- added (2024-08-08):
[0001628280-24-036182:note_history:12]
For the three and six months ended June 30, 2023, the reclassifications resulted in an increase in license fee and other revenue of $0.7 million and $1.3 million, respectively, and a corresponding decrease in service revenue, as well as an increase in cost of license fee and other revenue of $0.3 million and $0.6 million, respectively, and a corresponding decrease in cost of service revenue.

- removed (2024-08-08):
[0001628280-24-022282:note_history:13]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to live, work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to better address the chronic epidemic of escalating gun violence, mass shootings, and terrorist attacks in a cost-effective manner while improving safety and the visitor experience. The Company is headquartered in Waltham, Massachusetts.

- removed (2024-08-08):
[0001628280-24-022282:note_history:14]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2024, and for the three months ended March 31, 2024 and 2023 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2023 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2024 and the results of its operations for the three months ended March 31, 2024 and 2023 and cash flows for the three months ended March 31, 2024 and 2023. The results for the three months ended March 31, 2024 are not necessarily indicative of results to be expected for the year ending December 31, 2024, any other interim periods, or any future year or period.

- removed (2024-08-08):
[0001628280-24-022282:note_history:15]
For the three months ended March 31, 2023, the reclassifications resulted in an increase in license fee and other revenue of $0.6 million and a corresponding decrease in service revenue, as well as in increase in cost of license fee and other revenue of $0.3 million and a corresponding decrease in cost of service revenue.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-08-08):
[0001628280-24-036182:note_history:16]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2023, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2023. There have been no material changes to the Company’s significant accounting policies during the six months ended June 30, 2024.
  (was, 2024-05-09, similarity 0.9443):
[0001628280-24-022282:note_history:16]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2023, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2023. There have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2024.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-08-08):
[0001628280-24-036182:note_history:17]
Long-term Debt
In December 2022, the Company entered into a loan and security agreement (the “2022 SVB Credit Agreement”) with Silicon Valley Bank (“SVB”) in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. Subsequently, on March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. During the six months ended June 30, 2023, the Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs. The Company had no long-term debt as of June 30, 2024 and December 31, 2023.

- removed (2024-08-08):
[0001628280-24-022282:note_history:18]
Long-term Debt
In December 2022, the Company entered into a loan and security agreement (the “2022 SVB Credit Agreement”) with Silicon Valley Bank (“SVB”) in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. In light of the foregoing, on March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. During the three months ended March 31, 2023, the Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs. The Company had no long-term debt as of March 31, 2024 and December 31, 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-08):
[0001628280-24-036182:note_history:19]
Marketable Securities
Marketable securities as of June 30, 2024 and December 31, 2023 consisted of the following:
  (was, 2024-05-09, similarity 0.9565):
[0001628280-24-022282:note_history:19]
Marketable Securities
Marketable securities as of March 31, 2024 and December 31, 2023 consisted of the following:

- changed (2024-08-08):
[0001628280-24-036182:note_history:20]
|  | June 30, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 20,757 |  |  | $ | — |  |  | $ | 20,757 |  |
| Total marketable securities | $ | 20,757 |  |  | $ | — |  |  | $ | 20,757 |  |
  (was, 2024-05-09, similarity 0.9777):
[0001628280-24-022282:note_history:20]
|  | March 31, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 36,415 |  |  | $ | — |  |  | $ | 36,415 |  |
| Total marketable securities | $ | 36,415 |  |  | $ | — |  |  | $ | 36,415 |  |

- changed (2024-08-08):
[0001628280-24-036182:note_history:21]
Marketable securities at June 30, 2024 and December 31, 2023 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and six months ended June 30, 2024 and 2023. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive income.
  (was, 2024-05-09, similarity 0.8044):
[0001628280-24-022282:note_history:21]
Marketable securities at March 31, 2024 and December 31, 2023 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. The Company did not record any unrealized gains or losses on available-for-sale securities for each of the three months ended March 31, 2024 and 2023 as unrealized gains or losses were not material. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive income.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-08-08):
[0001628280-24-036182:note_history:22]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended June 30, 2024 and 2023, revenue from Motorola's distributor services was $2.0 million and $2.9 million, respectively. During the six months ended June 30, 2024 and 2023, revenue from Motorola's distributor services was $3.9 million and $6.2 million, respectively. As of June 30, 2024 and December 31, 2023, accounts receivable related to Motorola’s distributor services was $2.9 million and $1.2 million, respectively.
  (was, 2024-05-09, similarity 0.8231):
[0001628280-24-022282:note_history:22]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended March 31, 2024 and 2023, revenue from Motorola's distributor services was $1.9 million and $3.2 million, respectively. As of March 31, 2024 and December 31, 2023, accounts receivable related to Motorola’s distributor services was $2.1 million and $1.2 million, respectively.

- changed (2024-08-08):
[0001628280-24-036182:note_history:23]
Reseller Agreement with Stanley Black & Decker
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB (“Securitas”) in 2023. Securitas, directly or through its affiliates, resells the Company's products. Effective in the first quarter of 2024, while the reseller agreement is still in effect, Securitas is no longer considered a related party. During the three and six months ended June 30, 2023, revenue from Securitas' reseller services was $0.5 million and $0.9 million, respectively. As of December 31, 2023, accounts receivable related to Securitas' reseller services was $0.6 million.
  (was, 2024-05-09, similarity 0.8211):
[0001628280-24-022282:note_history:23]
Reseller Agreement with Stanley Black & Decker
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB (“Securitas”) in 2023. Securitas, directly or through its affiliates, resells the Company's products. Effective in the first fiscal quarter of 2024, while the reseller agreement is still in effect, Securitas is no longer considered a related party. During the three months ended March 31, 2023, revenue from Securitas' reseller services was $0.4 million. As of December 31, 2023, accounts receivable related to Securitas' reseller services was $0.6 million.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-08-08):
[0001628280-24-036182:note_history:24]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Product revenue | $ | 2,044 |  |  | $ | 7,243 |  |  | $ | 2,647 |  |  | $ | 15,997 |  |
| Subscription revenue | 15,903 |  |  | 7,964 |  |  | 30,406 |  |  | 14,430 |  |
| Service revenue | 5,553 |  |  | 3,905 |  |  | 10,937 |  |  | 6,691 |  |
| License fees | 1,717 |  |  | — |  |  | 2,441 |  |  | — |  |
| Professional services and other revenue | 323 |  |  | 713 |  |  | 777 |  |  | 1,288 |  |
| Total revenue | $ | 25,540 |  |  | $ | 19,825 |  |  | $ | 47,208 |  |  | $ | 38,406 |  |

- removed (2024-08-08):
[0001628280-24-022282:note_history:25]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Product revenue | $ | 603 |  |  | $ | 8,754 |  |  |  |  |  |
| Subscription revenue | 14,503 |  |  | 6,466 |  |  |  |  |  |
| Service revenue | 5,384 |  |  | 2,786 |  |  |  |  |  |
| License fees | 724 |  |  | — |  |  |  |  |  |
| Professional services and other revenue | 454 |  |  | 575 |  |  |  |  |  |
| Total revenue | $ | 21,668 |  |  | $ | 18,581 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-08):
[0001628280-24-036182:note_history:26]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of June 30, 2024:
  (was, 2024-05-09, similarity 0.9728):
[0001628280-24-022282:note_history:26]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2024.

- changed (2024-08-08):
[0001628280-24-036182:note_history:27]
The amount of minimum future leases is based on expected income recognition. As of June 30, 2024, future minimum payments on noncancelable leases are as follows (in thousands):
  (was, 2024-05-09, similarity 0.9736):
[0001628280-24-022282:note_history:27]
The amount of minimum future leases is based on expected income recognition. As of March 31, 2024, future minimum payments on noncancelable leases are as follows (in thousands):

- changed (2024-08-08):
[0001628280-24-036182:note_history:28]
| Year Ending December 31: |  |
| 2024 (six months remaining) | $ | 34,992 |  |
| 2025 | 63,964 |  |
| 2026 | 52,682 |  |
| 2027 | 32,219 |  |
| 2028 | 7,133 |  |
| Thereafter | 134 |  |
|  | $ | 191,124 |  |
  (was, 2024-05-09, similarity 0.9835):
[0001628280-24-022282:note_history:28]
| Year Ending December 31: |  |
| 2024 (nine months remaining) | $ | 48,486 |  |
| 2025 | 58,972 |  |
| 2026 | 47,647 |  |
| 2027 | 27,312 |  |
| 2028 | 4,033 |  |
| Thereafter | 119 |  |
|  | $ | 186,569 |  |

- changed (2024-08-08):
[0001628280-24-036182:note_history:29]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of June 30, 2024 and December 31, 2023, the Company had $1.7 million and $3.7 million in current portion of contract assets and $0.1 million and $0.5 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2024-05-09, similarity 0.9903):
[0001628280-24-022282:note_history:29]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of March 31, 2024 and December 31, 2023, the Company had $2.5 million and $3.7 million in current portion of contract assets and $0.3 million and $0.5 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2024-08-08):
[0001628280-24-036182:note_history:30]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $14.1 million and $31.4 million during the three and six months ended June 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance. The Company recognized revenue of $5.3 million and $12.1 million during the three and six months ended June 30, 2023, respectively, that was included in the December 31, 2022 deferred revenue balance.
  (was, 2024-05-09, similarity 0.7937):
[0001628280-24-022282:note_history:30]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $17.3 million during the three months ended March 31, 2024 that was included in the December 31, 2023 deferred revenue balance. The Company recognized revenue of $6.9 million during the three months ended March 31, 2023 that was included in the December 31, 2022 deferred revenue balance.

- changed (2024-08-08):
[0001628280-24-036182:note_history:31]
| Balance at December 31, 2023 | $ | 71,490 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (31,445) |  |
| Revenue deferred | 39,778 |  |
| Balance at June 30, 2024 | $ | 79,823 |  |
  (was, 2024-05-09, similarity 0.9772):
[0001628280-24-022282:note_history:31]
| Balance at December 31, 2023 | $ | 71,490 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (17,323) |  |
| Revenue deferred | 17,554 |  |
| Balance at March 31, 2024 | $ | 71,721 |  |

- added (2024-08-08):
[0001628280-24-036182:note_history:32]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest income on lease receivables | $ | 41 |  |  | $ | 51 |  |  | $ | 83 |  |  | $ | 104 |  |
| Lease income - operating leases | 15,903 |  |  | 7,964 |  |  | 30,406 |  |  | 14,430 |  |
| Total lease revenue | $ | 15,944 |  |  | $ | 8,015 |  |  | $ | 30,489 |  |  | $ | 14,534 |  |

- changed (2024-08-08):
[0001628280-24-036182:note_history:33]
Interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.3 million and less than $0.1 million during the three months ended June 30, 2024 and June 30, 2023, respectively. Revenue related to leases entered into with related parties were $0.6 million and $0.2 million during the six months ended June 30, 2024 and June 30, 2023, respectively.
  (was, 2024-05-09, similarity 0.6887):
[0001628280-24-022282:note_history:33]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the condensed consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.3 million and $0.2 million during the three months ended March 31, 2024 and 2023, respectively.

- added (2024-08-08):
[0001628280-24-036182:note_history:34]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Product revenue | $ | 2,044 |  |  | $ | 7,243 |  |  | $ | 2,647 |  |  | $ | 15,997 |  |
| Subscription revenue | 15,903 |  |  | 7,964 |  |  | 30,406 |  |  | 14,430 |  |
| Service revenue | 5,553 |  |  | 3,905 |  |  | 10,937 |  |  | 6,691 |  |
| License fees | 1,717 |  |  | — |  |  | 2,441 |  |  | — |  |
| Professional services and other revenue | 323 |  |  | 713 |  |  | 777 |  |  | 1,288 |  |
| Total revenue | $ | 25,540 |  |  | $ | 19,825 |  |  | $ | 47,208 |  |  | $ | 38,406 |  |

- changed (2024-08-08):
[0001628280-24-036182:note_history:35]
Commissions
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $11.9 million and $11.4 million as of June 30, 2024 and December 31, 2023, respectively. During the three months ended June 30, 2024 and 2023, the Company recognized commission expense of $1.6 million and $1.5 million, respectively. During the six months ended June 30, 2024 and 2023, the Company recognized commission expense of $3.0 million and $3.1 million, respectively.
  (was, 2024-05-09, similarity 0.7256):
[0001628280-24-022282:note_history:35]
Commissions
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $11.5 million and $11.4 million as of March 31, 2024 and December 31, 2023, respectively. During the three months ended March 31, 2024 and 2023, the Company recognized commission expense of $1.4 million and $1.6 million, respectively.

- removed (2024-08-08):
[0001628280-24-022282:note_history:36]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Interest income on lease receivables | 42 |  |  | 53 |  |  |  |  |  |
| Lease income - operating leases | 14,503 |  |  | 6,466 |  |  |  |  |  |
| Total lease revenue | $ | 14,545 |  |  | $ | 6,519 |  |  |  |  |  |

- removed (2024-08-08):
[0001628280-24-022282:note_history:37]
|  | Three Months EndedMarch 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Product revenue | $ | 603 |  |  | $ | 8,754 |  |  |  |  |  |
| Subscription revenue | 14,503 |  |  | 6,466 |  |  |  |  |  |
| Service revenue | 5,384 |  |  | 2,786 |  |  |  |  |  |
| License fees | 724 |  |  | — |  |  |  |  |  |
| Professional services and other revenue | 454 |  |  | 575 |  |  |  |  |  |
| Total revenue | $ | 21,668 |  |  | $ | 18,581 |  |  |  |  |  |
