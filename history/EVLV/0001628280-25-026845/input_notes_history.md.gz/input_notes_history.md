# EVLV note change history — 0001628280-25-020353 → 0001628280-25-026845


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2025-05-20):
[0001628280-25-026845:note_history:1]
Commitments and Contingencies
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. Below is a summary of the various types of matters subject to this guidance.

- changed (2025-05-20):
[0001628280-25-026845:note_history:2]
Indemnification Agreements
  (was, 2025-04-28, similarity 0.6341):
[0001628280-25-020353:note_history:2]
Commitments and Contingencies
Indemnification Agreements

- changed (2025-05-20):
[0001628280-25-026845:note_history:3]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the anticipated motion to dismiss in the Class Action. On March 28, 2025, the Company filed a motion to dismiss the claims.
  (was, 2025-04-28, similarity 0.9938):
[0001628280-25-020353:note_history:3]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the anticipated motion to dismiss in the Class Action. On March 28, 2025, we filed a motion to dismiss the claims.

- changed (2025-05-20):
[0001628280-25-026845:note_history:4]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Delaware Derivative Action”). The Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. The Delaware Derivative Action is stayed pending the outcome of the anticipated motion to dismiss in the Class Action.
  (was, 2025-04-28, similarity 0.8155):
[0001628280-25-020353:note_history:4]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Delaware Derivative Action”). The Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. Although the Delaware Derivative Action is in the early stages, we anticipate filing a motion to dismiss the claims if the case moves forward.

- added (2025-05-20):
[0001628280-25-026845:note_history:5]
The Company expects to incur legal and professional services expenses associated with this litigation in future periods. The Company will recognize these expenses as services are received. While a loss from this litigation is reasonably possible, we cannot reasonably estimate a range of possible losses at this time, as the proceedings remain in the early stages, alleged damages have not been specified, there is uncertainty as to the outcome of our anticipated motion to dismiss in the Class Action which was filed on March 28, 2025, there is uncertainty as to the likelihood of the proposed class in the Class Action being certified or the ultimate size of any class if certified, there is uncertainty as to the final complaint in the Massachusetts Derivative Action, as the plaintiff will not identify an operative complaint or file a consolidated complaint until disposition of our anticipated motion to dismiss in the Class Action, and there are significant factual and legal issues to be resolved in both the securities and derivative actions. For these reasons, the Company has not recorded a loss contingency liability for the above litigation as of March 31, 2025.

- changed (2025-05-20):
[0001628280-25-026845:note_history:6]
As previously disclosed, on October 12, 2023, the Company announced that the U.S. Federal Trade Commission (the “FTC”) had requested information about certain aspects of its marketing practices. The Company reached a settlement with the FTC and on December 5, 2024, a Stipulated Order for Permanent Injunction and Other Relief (the “Order”) was entered in the United States District Court for the District of Massachusetts Eastern Division. The Order (i) required that the Company permit a limited cohort of school customers to cancel their contracts, (ii) required that the Company take certain compliance actions and meet record keeping obligations, and (iii) enjoined the Company from making misleading or unsubstantiated marketing claims. The Order did not include any monetary relief. The period during which eligible customers may cancel closed on March 30, 2025. Any inability to adequately comply with the terms of the Order could result in enforcement actions or penalties imposed by the FTC.
  (was, 2025-04-28, similarity 0.9036):
[0001628280-25-020353:note_history:6]
As previously disclosed, on October 12, 2023, the Company announced that the U.S. Federal Trade Commission (the “FTC”) had requested information about certain aspects of its marketing practices. The Company reached a settlement with the FTC and on December 5, 2024, a Stipulated Order for Permanent Injunction and Other Relief (the “Order”) was entered in the United States District Court for the District of Massachusetts Eastern Division. The Order (i) required that the Company permit a limited cohort of school customers to cancel their contracts, (ii) required that the Company take certain compliance actions and meet record keeping obligations, and (iii) enjoined the Company from making misleading or unsubstantiated marketing claims. The Order did not include any monetary relief. The period during which eligible

- added (2025-05-20):
[0001628280-25-026845:note_history:7]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, 5 customers representing 24 Evolv Express units elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the year ended December 31, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three months ended March 31, 2025, as revenue will continue to be recognized on these deals through the cancellation dates of each contract, all of which are in June 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of the effective date of the Order were impacted by the cancellations, which has been excluded from the remaining performance obligations disclosed in Note 6 Revenue Recognition.

- changed (2025-05-20):
[0001628280-25-026845:note_history:8]
As previously disclosed, in February 2024, the Company received a subpoena from the Division of Enforcement of the Securities and Exchange Commission (the “SEC”), requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation.
  (was, 2025-04-28, similarity 0.9404):
[0001628280-25-020353:note_history:8]
As previously disclosed, in February 2024, the Company received a subpoena from the Division of Enforcement of the SEC, requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation.

- added (2025-05-20):
[0001628280-25-026845:note_history:9]
As previously reported, the Company self-reported to the Division of Enforcement of the SEC the Investigation. The Company has since received requests for documents and information from the SEC relating to this matter. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("DOJ") relating to these same issues, and has since received additional requests for documents and information relating to this matter. The Company is cooperating with these investigations.

- changed (2025-05-20):
[0001628280-25-026845:note_history:10]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of legal and regulatory matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.
  (was, 2025-04-28, similarity 0.9958):
[0001628280-25-020353:note_history:10]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of legal and regulatory matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the condensed consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.

- added (2025-05-20):
[0001628280-25-026845:note_history:11]
Any resolution or litigation with the SEC, DOJ, or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to SEC or DOJ matters. The Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matters, including certain expenses that have previously been paid, are expected to be reimbursed. As of March 31, 2025, the Company recognized an estimated loss recovery related to insurance coverage for these matters of $3.9 million, which was recorded in general and administrative expense in the condensed consolidated statements of

- added (2025-05-20):
[0001628280-25-026845:note_history:12]
operations and comprehensive loss and a related asset in prepaid and other current assets in the condensed consolidated balance sheets. This amount reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company expects realization of the claim for recovery is probable. As it relates to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement  action or litigation, which is necessarily uncertain.

- removed (2025-05-20):
[0001628280-25-020353:note_history:13]
We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. While a loss from this litigation is reasonably possible, we cannot reasonably estimate a range of possible losses at this time, as the proceedings remain in the early stages, alleged damages have not been specified, there is uncertainty as to the outcome of our anticipated motion to dismiss in the Class Action which was filed on March 28, 2025, there is uncertainty as to the likelihood of the proposed class in the Class Action being certified or the ultimate size of any class if certified, there is uncertainty as to the final complaint in the Massachusetts Derivative Action, as the plaintiff will not identify an operative complaint or file a consolidated complaint until disposition of our anticipated motion to dismiss in the Class Action, and there are significant factual and legal issues to be resolved in both the securities and derivative actions. For these reasons, we have not recorded a loss contingency liability for the above litigation as of September 30, 2024.

- removed (2025-05-20):
[0001628280-25-020353:note_history:14]
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.

- removed (2025-05-20):
[0001628280-25-020353:note_history:15]
customers may cancel closed on March 30, 2025. Any inability to adequately comply with the terms of the Order could result in enforcement actions or penalties imposed by the FTC.

- removed (2025-05-20):
[0001628280-25-020353:note_history:16]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, 5 customers representing 24 Evolv Express units elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the three and nine months ended September 30, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and nine months ended September 30, 2024, as revenue will continue to be recognized on these deals through the cancellation dates of each contract, all of which are in June 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of September 30, 2024 were impacted by the cancellations.

- removed (2025-05-20):
[0001628280-25-020353:note_history:17]
As of June 30, 2024, the Company had accrued $1.1 million as an estimated liability related to the FTC matter, which was recorded in other accrued liabilities in the condensed consolidated balance sheets and the associated expense was recorded in general and administrative expense in the condensed consolidated statements of operations. As the settlement of these matters occurred subsequent to September 30, 2024, but prior to our filing of this Quarterly Report on Form 10-Q, the Company accounted for the transaction as a recognized subsequent event for the three months ended September 30, 2024. As the settlement included no monetary fines or penalties, the loss reserve was reversed during the three months ended September 30, 2024.

- removed (2025-05-20):
[0001628280-25-020353:note_history:18]
As previously reported, the Company self-reported to the Division of Enforcement of the Securities and Exchange Commission ("SEC") the Investigation. The Company has since received requests for documents and information from the SEC relating to this matter. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("USAO SDNY") relating to these same issues, and has since received additional requests for documents and information relating to this matter. The Company is cooperating with these investigations.

- removed (2025-05-20):
[0001628280-25-020353:note_history:19]
Any resolution or litigation with the SEC, DOJ, or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to SEC or DOJ matters. The Company's defense counsel costs in connection with the securities litigation and the related SEC and DOJ matters are being covered under its directors and officers insurance policies subject to a typical reservation of rights. The Company has met the retention limits under these policies with respect to these matters and currently expects these policies will provide coverage for certain costs related to these matters, including certain expenses that have previously been paid. However, the Company cannot provide any assurance that costs related to these matters will not exceed the

- removed (2025-05-20):
[0001628280-25-020353:note_history:20]
limits of its insurance policies, that such claims are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0001628280-25-026845:note_history:21]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company with products designed to transform human security to make a safer, faster, and better experience for the world's most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics.
  (was, 2025-04-28, similarity 0.9841):
[0001628280-25-020353:note_history:21]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company designed to transform human security to make a safer, faster, and better experience for the world's most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics.

- changed (2025-05-20):
[0001628280-25-026845:note_history:22]
The Company recently launched a new product offering, Evolv eXpedite™, an autonomous AI-based weapons detection system for bags. This new offering, as well as existing products such as Evolv Express®, are designed to be integrated layers for detection as part of a unified Evolv Safer Experience System™. These products and their associated services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.
  (was, 2025-04-28, similarity 0.9462):
[0001628280-25-020353:note_history:22]
The Company announced in the third quarter of 2024 the launch of a new product offering, Evolv eXpedite™, an autonomous AI-based weapons detection system for bags. This new offering, as well as existing products such as Evolv Express®, are designed to be integrated layers for detection as part of a unified Evolv Safer Experience System™. These products and their associated services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

- changed (2025-05-20):
[0001628280-25-026845:note_history:23]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of March 31, 2025, the Company had $35.0 million in cash, cash equivalents, and marketable securities. The Company incurred a net loss of $1.7 million and $11.3 million for the three months ended March 31, 2025 and 2024, respectively. The Company incurred cash outflows from operating activities of $2.5 million and $16.2 million during the three months ended March 31, 2025 and 2024, respectively. The Company expects to continue to generate losses for the foreseeable future.
  (was, 2025-04-28, similarity 0.8828):
[0001628280-25-020353:note_history:23]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of September 30, 2024, the Company had $56.0 million in cash, cash equivalents, and marketable securities, and as of March 31, 2025, the Company had $35.0 million in cash, cash equivalents, and marketable securities. The Company incurred a net loss of $38.3 million and $90.9 million for the nine months ended September 30, 2024 and 2023, respectively. The Company incurred cash outflows from operating activities of $34.1 million and $6.7 million during the nine months ended September 30, 2024 and 2023, respectively. The Company expects to continue to generate losses for the foreseeable future.

- changed (2025-05-20):
[0001628280-25-026845:note_history:24]
The Company expects its cash, cash equivalents, and marketable securities of $35.0 million as of March 31, 2025, together with cash it expects to generate from future operations, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth. The Company may
  (was, 2025-04-28, similarity 0.8639):
[0001628280-25-020353:note_history:24]
The Company expects its cash, cash equivalents, and marketable securities of $56.0 million as of December 31, 2024, together with cash it expects to generate from future operations, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company

- changed (2025-05-20):
[0001628280-25-026845:note_history:25]
require additional capital to respond to expected growth in the demand for equipment to support its “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances. To the extent that the Company's projected revenue growth does not materialize, it has established plans to preserve existing cash liquidity, which includes additional reductions in operating expenses and capital expenditures.
  (was, 2025-04-28, similarity 0.8741):
[0001628280-25-020353:note_history:25]
expects to continue to strategically and carefully invest in various areas of the business to support that growth. The Company may require additional capital to respond to expected growth in the demand for equipment to support its “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances.  To the extent that the Company's projected revenue growth does not materialize, the Company has established plans to preserve existing cash liquidity, which includes additional reductions to operating expenses and capital expenditures.

- added (2025-05-20):
[0001628280-25-026845:note_history:26]
Although not required to fund ongoing operations, in an improving interest rate environment the Company may choose to engage in debt financings or enter into credit facilities for prudent capital management purposes and to provide additional readily available capital for strategic and other purposes. If the Company is unable to obtain adequate financing or financing on terms satisfactory to it, when it requires it, the Company's ability to continue to grow or support the business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, tariffs, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing the Company's ability to access capital. If the Company is unable to raise additional funds when or on the terms desired, its business, financial condition and results of operations could be adversely affected.

- changed (2025-05-20):
[0001628280-25-026845:note_history:27]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2025, and for the three months ended March 31, 2025 and 2024 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2024 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2025, the results of its operations for the three months ended March 31, 2025 and 2024 and cash flows for the three months ended March 31, 2025 and 2024. The results for the three months ended March 31, 2025 are not necessarily indicative of results to be expected for the year ending December 31, 2025, any other interim periods, or any future year or period.
  (was, 2025-04-28, similarity 0.7175):
[0001628280-25-020353:note_history:27]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2024, and for the three and nine months ended September 30, 2024 and 2023 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2023 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2024 and the results of its operations for the three and nine months ended September 30, 2024 and 2023 and cash flows for the nine months ended September 30, 2024 and 2023. The results for the three and nine months ended September 30, 2024 are not necessarily indicative of results to be expected for the year ending December 31, 2024, any other interim periods, or any future year or period.

- removed (2025-05-20):
[0001628280-25-020353:note_history:28]
Although not required to fund ongoing operations, in an improving interest rate environment the Company may choose to engage in debt financings or enter into credit facilities for other strategic reasons. If the Company is unable to obtain adequate financing or financing on terms satisfactory to it, when it requires it, the Company's ability to continue to grow or support the business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, tariffs, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing the Company's ability to access capital. If the Company is unable to raise additional funds when or on the terms desired, its business, financial condition and results of operations could be adversely affected.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0001628280-25-026845:note_history:29]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2024, and the notes thereto, which are included in our 2024 Form 10-K. Except for the estimates used to determine the grant date valuation for certain market-based stock units (“MSUs”), as described below, which began being granted during the three months ended March 31, 2025, there have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2025.
  (was, 2025-04-28, similarity 0.6705):
[0001628280-25-020353:note_history:29]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2023, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2023. Other than "Contract Balances from Contracts with Customers", "Commissions" and "Consignment Sales" discussed below, there have been no material changes to the Company’s significant accounting policies during the nine months ended September 30, 2024.

- added (2025-05-20):
[0001628280-25-026845:note_history:30]
Market-based Stock Units

- added (2025-05-20):
[0001628280-25-026845:note_history:31]
The estimated grant date fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.

- changed (2025-05-20):
[0001628280-25-026845:note_history:32]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity may apply the amendments in ASU 2023-09 either prospectively to all annual periods beginning after December 15, 2024, or retrospectively to prior periods. The Company determined that ASU 2023-09 is applicable and will be adopted in our Annual Report on Form 10-K for the year ended December 31, 2025. It addresses disclosures only, the Company expects it will not have any material effects on its financial condition, results of operations, or cash flows.
  (was, 2025-04-28, similarity 0.6911):
[0001628280-25-020353:note_history:32]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity should apply the amendments in ASU 2023-09 prospectively to all annual periods beginning after December 15, 2024. The

- changed (2025-05-20):
[0001628280-25-026845:note_history:33]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses.”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.
  (was, 2025-04-28, similarity 0.9953):
[0001628280-25-020353:note_history:33]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses.”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the condensed consolidated financial statements.

- removed (2025-05-20):
[0001628280-25-020353:note_history:34]
Contract Balances from Contracts with Customers

- removed (2025-05-20):
[0001628280-25-020353:note_history:35]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent.

- removed (2025-05-20):
[0001628280-25-020353:note_history:36]
Commissions

- removed (2025-05-20):
[0001628280-25-020353:note_history:37]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract.

- removed (2025-05-20):
[0001628280-25-020353:note_history:38]
Consignment Sales

- removed (2025-05-20):
[0001628280-25-020353:note_history:39]
As discussed in Note 2, Restatement of Quarterly Financial Information, the Company entered into certain in-substance consignment arrangements with reseller partners for which product revenue has been recognized at the point in time when control transferred to the customer and the customer has an unconditional obligation to pay for the goods transferred, which was deemed to occur upon installation at the end-user site.

- removed (2025-05-20):
[0001628280-25-020353:note_history:40]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures.” The updated accounting guidance requires a public entity to disclose significant segment expenses and other segment items on an annual and interim basis and to provide in interim periods all disclosures about a reportable segment’s profit or loss and assets that are currently required annually for entities with more than one reportable segment. Public entities with a single reporting segment are required to provide both the new disclosures and all of the existing disclosures required under ASC 280. The guidance is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Retrospective application is required and early adoption is permitted. The Company will adopt this guidance retrospectively effective December 31, 2024. Since this new ASU addresses only disclosures, the adoption of this ASU will not have any material effects on its financial condition, results of operations, or cash flows.

- removed (2025-05-20):
[0001628280-25-020353:note_history:41]
Company determined that although the ASU is applicable, it addresses disclosures only, and as such will not have any material effects on its financial condition, results of operations, or cash flows.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2025-05-20):
[0001628280-25-020353:note_history:42]
Long-term Debt
In December 2022, the Company entered into a loan and security agreement (the “2022 SVB Credit Agreement”) with Silicon Valley Bank (“SVB”) in order to finance purchases of hardware to be leased to customers. On March 10, 2023, SVB was closed by California state regulators and the FDIC was appointed as receiver. Subsequently, on March 31, 2023, the Company fully repaid all borrowings and accrued interest under the 2022 SVB Credit Agreement and terminated the 2022 SVB Credit Agreement. In accordance with the terms of the 2022 SVB Credit Agreement, the Company was required to pay a prepayment premium equal to 1.0% of the principal balance on the date of repayment. During the nine months ended September 30, 2023, the Company incurred a loss on debt extinguishment of $0.6 million, consisting of the prepayment penalty of $0.3 million and the write-off of $0.3 million of unamortized debt issuance costs. The Company had no long-term debt as of September 30, 2024 and December 31, 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0001628280-25-026845:note_history:43]
Marketable Securities
Marketable securities as of March 31, 2025 and December 31, 2024 consisted of the following:
  (was, 2025-04-28, similarity 0.9528):
[0001628280-25-020353:note_history:43]
Marketable Securities
Marketable securities as of September 30, 2024 and December 31, 2023 consisted of the following:

- changed (2025-05-20):
[0001628280-25-026845:note_history:44]
|  | March 31, 2025 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 9,931 |  |  | $ | — |  |  | $ | 9,931 |  |
| Total marketable securities | $ | 9,931 |  |  | $ | — |  |  | $ | 9,931 |  |
  (was, 2025-04-28, similarity 0.9706):
[0001628280-25-020353:note_history:44]
|  | September 30, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 9,960 |  |  | $ | — |  |  | $ | 9,960 |  |
| Total marketable securities | $ | 9,960 |  |  | $ | — |  |  | $ | 9,960 |  |

- changed (2025-05-20):
[0001628280-25-026845:note_history:45]
Marketable securities at March 31, 2025 and December 31, 2024 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three months ended March 31, 2025 and 2024. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive loss.
  (was, 2025-04-28, similarity 0.8634):
[0001628280-25-020353:note_history:45]
Marketable securities at September 30, 2024 and December 31, 2023 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and nine months ended September 30, 2024 and 2023. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive (loss) income.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2025-05-20):
[0001628280-25-026845:note_history:46]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. While the partnership agreement is still in effect, effective in the fourth quarter of 2024, Motorola is no longer considered a related party. During the three months ended March 31, 2024, revenue from Motorola's distributor services was $1.9 million.

- removed (2025-05-20):
[0001628280-25-020353:note_history:47]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola

- removed (2025-05-20):
[0001628280-25-020353:note_history:48]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended September 30, 2024 and 2023, revenue from Motorola's distributor services was $2.2 million and $1.7 million, respectively. During the nine months ended September 30, 2024 and 2023, revenue from Motorola's distributor services was $6.1 million and $7.9 million, respectively, which was a result of the Company's transition to pure subscription sales and sales under the distributor licensing model during this period. As of September 30, 2024 and December 31, 2023, accounts receivable related to Motorola’s distributor services was $1.1 million and $1.6 million, respectively.

- removed (2025-05-20):
[0001628280-25-020353:note_history:49]
Reseller Agreement with Stanley Black & Decker
In June 2020, the Company entered into a reseller agreement with Stanley Black & Decker, an investor in the Company. Stanley Black & Decker's electronic security business was acquired by Securitas AB (“Securitas”) in 2023. Securitas, directly or through its affiliates, resells the Company's products. Effective in the first quarter of 2024, while the reseller agreement is still in effect, Securitas is no longer considered a related party. During the three and nine months ended September 30, 2023, revenue from Securitas' reseller services was $0.4 million and $1.3 million, respectively. As of December 31, 2023, accounts receivable related to Securitas' reseller services was $0.6 million.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0001628280-25-026845:note_history:50]
The following table presents the Company’s revenue by revenue stream (in thousands):
  (was, 2025-04-28, similarity 0.6388):
[0001628280-25-020353:note_history:50]
The following table presents the Company’s revenue by revenue stream (in thousands). Certain prior period amounts have been reclassified to conform to current period presentation:

- added (2025-05-20):
[0001628280-25-026845:note_history:51]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Product revenue |  |  |  |  | $ | 2,322 |  |  | $ | 1,491 |  |
| Subscription revenue |  |  |  |  | 19,237 |  |  | 14,219 |  |
| Service revenue |  |  |  |  | 6,730 |  |  | 5,252 |  |
| License fees |  |  |  |  | 3,203 |  |  | 724 |  |
| Professional services and other revenue |  |  |  |  | 515 |  |  | 495 |  |
| Total revenue |  |  |  |  | $ | 32,007 |  |  | $ | 22,181 |  |

- removed (2025-05-20):
[0001628280-25-020353:note_history:52]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Product revenue | $ | 1,344 |  |  | $ | 3,456 |  |  | $ | 4,789 |  |  | $ | 20,920 |  |
| Subscription revenue | 17,909 |  |  | 9,858 |  |  | 47,783 |  |  | 23,733 |  |
| Service revenue | 6,085 |  |  | 4,345 |  |  | 16,903 |  |  | 10,750 |  |
| License fees | 1,606 |  |  | 2,012 |  |  | 4,047 |  |  | 2,012 |  |
| Professional services and other revenue | 416 |  |  | 290 |  |  | 1,243 |  |  | 1,570 |  |
| Total revenue | $ | 27,360 |  |  | $ | 19,961 |  |  | $ | 74,765 |  |  | $ | 58,985 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2025-05-20):
[0001628280-25-020353:note_history:53]
Contract Balances from Contracts with Customers

- removed (2025-05-20):
[0001628280-25-020353:note_history:54]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0001628280-25-026845:note_history:55]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4)
  (was, 2025-04-28, similarity 0.6161):
[0001628280-25-020353:note_history:55]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after control passes to the customer. Revenue is recognized net of sales tax.

- added (2025-05-20):
[0001628280-25-026845:note_history:56]
license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after control passes to the customer. Revenue is recognized net of sales tax.

- changed (2025-05-20):
[0001628280-25-026845:note_history:57]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2025:
  (was, 2025-04-28, similarity 0.9733):
[0001628280-25-020353:note_history:57]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2024:

- changed (2025-05-20):
[0001628280-25-026845:note_history:58]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time.  As of March 31, 2025 and December 31, 2024, the Company had $0.9 million and $0.8 million in current portion of contract assets and $0.9 million and $0.7 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2025-04-28, similarity 0.9602):
[0001628280-25-020353:note_history:58]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2024 and December 31, 2023, the Company had less than $0.7 million and $1.4 million (as restated) in current portion of contract assets and $0.7 million and $1.0 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2025-05-20):
[0001628280-25-026845:note_history:59]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $24.7 million during the three months ended March 31, 2025 that was included in the December 31, 2024 deferred revenue balance. The Company recognized revenue of $16.9 million
  (was, 2025-04-28, similarity 0.8642):
[0001628280-25-020353:note_history:59]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $10.1 million and $40.8 million during the three and nine months ended September 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance. The Company recognized revenue (as restated) of $3.6 million and $15.5 million during the three and nine months ended September 30, 2023, respectively, that was included in the December 31, 2022 deferred revenue balance.

- added (2025-05-20):
[0001628280-25-026845:note_history:60]
(as restated) during the three months ended March 31, 2024 that was included in the December 31, 2023 deferred revenue balance.

- changed (2025-05-20):
[0001628280-25-026845:note_history:61]
| Balance at December 31, 2024 | $ | 84,772 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (24,737) |  |
| Revenue deferred | 25,237 |  |
| Balance at March 31, 2025 | $ | 85,272 |  |
  (was, 2025-04-28, similarity 0.7991):
[0001628280-25-020353:note_history:61]
| Balance at December 31, 2023 (restated) | $ | 71,957 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance (restated) | (40,780) |  |
| Revenue deferred (restated) | 54,339 |  |
| Balance at September 30, 2024 | $ | 85,516 |  |

- added (2025-05-20):
[0001628280-25-026845:note_history:62]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Interest income on lease receivables |  |  |  |  | $ | 29 |  |  | $ | 42 |  |
| Lease income - operating leases |  |  |  |  | 19,237 |  |  | 14,219 |  |
| Total lease revenue |  |  |  |  | $ | 19,266 |  |  | $ | 14,261 |  |

- changed (2025-05-20):
[0001628280-25-026845:note_history:63]
The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties was $0.3 million during the three months ended March 31, 2024. There was no revenue related to leases entered into with related parties during the three months ended March 31, 2025.
  (was, 2025-04-28, similarity 0.76):
[0001628280-25-020353:note_history:63]
Interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties were $0.5 million and $0.3 million during the three months ended September 30, 2024 and 2023, respectively. Revenue related to leases entered into with related parties were $1.1 million and $0.7 million (restated) during the nine months ended September 30, 2024 and 2023, respectively.

- changed (2025-05-20):
[0001628280-25-026845:note_history:64]
The following table presents the Company’s revenue by revenue stream (in thousands):
  (was, 2025-04-28, similarity 0.6388):
[0001628280-25-020353:note_history:64]
The following table presents the Company’s revenue by revenue stream (in thousands). Certain prior period amounts have been reclassified to conform to current period presentation:

- added (2025-05-20):
[0001628280-25-026845:note_history:65]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Product revenue |  |  |  |  | $ | 2,322 |  |  | $ | 1,491 |  |
| Subscription revenue |  |  |  |  | 19,237 |  |  | 14,219 |  |
| Service revenue |  |  |  |  | 6,730 |  |  | 5,252 |  |
| License fees |  |  |  |  | 3,203 |  |  | 724 |  |
| Professional services and other revenue |  |  |  |  | 515 |  |  | 495 |  |
| Total revenue |  |  |  |  | $ | 32,007 |  |  | $ | 22,181 |  |

- added (2025-05-20):
[0001628280-25-026845:note_history:66]
Commissions

- changed (2025-05-20):
[0001628280-25-026845:note_history:67]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $12.8 million and $13.0 million as of March 31, 2025 and December 31, 2024, respectively. During the three months ended March 31, 2025 and 2024, the Company recognized commission expense of $1.5 million and $1.3 million (as restated), respectively.
  (was, 2025-04-28, similarity 0.86):
[0001628280-25-020353:note_history:67]
Commissions
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had total deferred assets related to commissions of $12.6 million and $11.6 million (as restated) as of September 30, 2024 and December 31, 2023, respectively. During the three months ended September 30, 2024 and 2023, the Company recognized commission expense of $1.4 million and $1.3 million (as restated), respectively. During the nine months ended September 30, 2024 and 2023, the Company recognized commission expense of $4.3 million and $4.2 million  (as restated), respectively.

- added (2025-05-20):
[0001628280-25-026845:note_history:68]
Leases

- added (2025-05-20):
[0001628280-25-026845:note_history:69]
As of March 31, 2025, future minimum noncancelable payments related to leases of the Company's equipment are as follows (in thousands):

- changed (2025-05-20):
[0001628280-25-026845:note_history:70]
| Year Ending December 31: |  |
| 2025 (nine months remaining) | $ | 58,776 |  |
| 2026 | 67,180 |  |
| 2027 | 45,766 |  |
| 2028 | 20,471 |  |
| 2029 | 2,328 |  |
| Thereafter | 7 |  |
|  | $ | 194,528 |  |
  (was, 2025-04-28, similarity 0.977):
[0001628280-25-020353:note_history:70]
| Year Ending December 31: |  |
| 2024 (three months remaining) | $ | 18,703 |  |
| 2025 | 70,166 |  |
| 2026 | 58,474 |  |
| 2027 | 38,816 |  |
| 2028 | 12,430 |  |
| Thereafter | 490 |  |
|  | $ | 199,079 |  |

- removed (2025-05-20):
[0001628280-25-020353:note_history:71]
The amount of minimum future leases is based on expected income recognition. As of September 30, 2024, future minimum payments on noncancelable leases are as follows (in thousands):

- removed (2025-05-20):
[0001628280-25-020353:note_history:72]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Interest income on lease receivables | $ | 40 |  |  | $ | 49 |  |  | $ | 123 |  |  | $ | 153 |  |
| Lease income - operating leases | 17,909 |  |  | 9,858 |  |  | 47,783 |  |  | 23,733 |  |
| Total lease revenue | $ | 17,949 |  |  | $ | 9,907 |  |  | $ | 47,906 |  |  | $ | 23,886 |  |

- removed (2025-05-20):
[0001628280-25-020353:note_history:73]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Product revenue | $ | 1,344 |  |  | $ | 3,456 |  |  | $ | 4,789 |  |  | $ | 20,920 |  |
| Subscription revenue | 17,909 |  |  | 9,858 |  |  | 47,783 |  |  | 23,733 |  |
| Service revenue | 6,085 |  |  | 4,345 |  |  | 16,903 |  |  | 10,750 |  |
| License fees | 1,606 |  |  | 2,012 |  |  | 4,047 |  |  | 2,012 |  |
| Professional services and other revenue | 416 |  |  | 290 |  |  | 1,243 |  |  | 1,570 |  |
| Total revenue | $ | 27,360 |  |  | $ | 19,961 |  |  | $ | 74,765 |  |  | $ | 58,985 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0001628280-25-026845:note_history:74]
Subsequent Events
Appointment of Chief Financial Officer
  (was, 2025-04-28, similarity 0.6263):
[0001628280-25-020353:note_history:74]
Subsequent Events
Resolution of FTC Inquiry

- added (2025-05-20):
[0001628280-25-026845:note_history:75]
On April 29, 2025, the Company appointed a new executive officer. In connection with this appointment, on May 1, 2025, the Board granted the officer (i) market-based restricted stock units with an aggregate grant date fair market value of $1,750,000, which will vest based on the achievement of certain Company stock price performance goals, as described in Note 3, Summary of Significant Accounting Policies and Estimates, and (ii) restricted stock units with an aggregate grant date fair market value of $1,750,000, which will vest based on the executive's continued service with the Company in three equal annual installments, pursuant to the Company’s 2021 Incentive Award Plan.

- removed (2025-05-20):
[0001628280-25-020353:note_history:76]
As discussed above in Note 16, Commitments and Contingencies, the Company reached a settlement with the FTC and on December 5, 2024, the Order was entered in the United States District Court for the District of Massachusetts Eastern Division. The resolution did not involve any financial penalties or monetary relief. As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, a total of 5 customers representing 24 Evolv Express units elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the three and nine months ended September 30, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and nine months ended September 30, 2024, as revenue will continue to be recognized on these deals through the cancellation dates of each contract, all of which are in June 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of September 30, 2024 were impacted by the cancellations.

- removed (2025-05-20):
[0001628280-25-020353:note_history:77]
As of June 30, 2024, the Company had accrued $1.1 million as an estimated liability related to the FTC matter, which was recorded in other accrued liabilities in the condensed consolidated balance sheets and the associated expense was recorded in general and administrative expense in the condensed consolidated statements of operations. As the settlement of these matters occurred subsequent to the September 30, 2024, but prior to our filing of this Quarterly Report on Form 10-Q, the Company accounted for the transaction as a recognized subsequent event for the three months ended September 30, 2024. As the settlement included no monetary fines or penalties, the loss reserve was reversed during the three months ended September 30, 2024.

- removed (2025-05-20):
[0001628280-25-020353:note_history:78]
Reduction in force

- removed (2025-05-20):
[0001628280-25-020353:note_history:79]
In January 2025, the Company implemented a Board-approved reduction in force affecting 40 members of its workforce. This action is part of the Company’s initiative to increase its annualized run rate cash savings as the Company seeks further flexibility to pursue its investment strategy with certain growth opportunities.

- removed (2025-05-20):
[0001628280-25-020353:note_history:80]
The Company incurred pre-tax charges of $2.7 million for the reduction in force, substantially all of which was incurred in the first quarter of 2025. These charges consisted of one-time termination charges arising from severance obligations of $2.0 million, extended eligibility for the vesting of certain equity awards originally scheduled to vest on or before March 1, 2025, resulting in incremental non-cash expense of $0.5 million and other customary employee benefit payments in connection with a reduction in force of $0.2 million. Substantially all severance and related payments to 
affected individuals was completed by March 2025, with the exception of three employees who are subject to a continuous payment through July 2025
