# EVLV 8-K — 0001628280-25-026833 filed 2025-05-20

## item codes, every 8-K on or before 2025-05-20

- 2025-05-20 0001628280-25-026833 — 2.02, 9.01
- 2025-04-28 0001628280-25-020351 — 2.02, 9.01
- 2025-04-23 0001104659-25-037732 — 5.02, 7.01, 9.01
- 2025-04-22 0001104659-25-037530 — 3.01, 7.01, 9.01
- 2025-02-04 0001104659-25-008892 — 5.02, 7.01, 9.01
- 2025-01-24 0001104659-25-005796 — 5.02, 7.01, 8.01, 9.01
- 2025-01-23 0001628280-25-002293 — 2.02, 2.05, 7.01, 9.01
- 2024-12-23 0001104659-24-131278 — 5.02
- 2024-12-12 0001104659-24-128006 — 5.02
- 2024-12-09 0001104659-24-126542 — 5.02, 7.01, 9.01
- 2024-11-22 0001104659-24-122102 — 3.01, 7.01, 9.01
- 2024-11-21 0001104659-24-121349 — 5.02, 7.01, 8.01, 9.01
- 2024-10-31 0001104659-24-112868 — 5.02, 7.01, 9.01
- 2024-10-25 0001104659-24-111310 — 4.02, 7.01, 9.01
- 2024-08-08 0001628280-24-036115 — 2.02, 9.01
- 2024-06-04 0001628280-24-026572 — 5.07
- 2024-05-09 0001628280-24-022265 — 2.02, 9.01
- 2024-02-29 0001628280-24-007980 — 2.02, 9.01
- 2024-02-20 0001104659-24-025077 — 7.01, 9.01
- 2024-01-31 0001628280-24-002618 — 5.03, 9.01
- 2023-11-09 0001628280-23-038267 — 2.02, 9.01
- 2023-11-06 0001104659-23-114499 — 5.02
- 2023-10-25 0001628280-23-035145 — 4.02
- 2023-10-12 0001104659-23-108693 — 2.02, 7.01, 9.01
- 2023-08-10 0001628280-23-028861 — 2.02, 9.01
- 2023-06-02 0001628280-23-020680 — 5.07
- 2023-05-10 0001628280-23-017243 — 2.02, 9.01
- 2023-04-03 0001628280-23-010402 — 1.02, 2.04, 8.01, 9.01
- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2025-05-20

- 2025-05-15 0001104659-25-049608 — NT 10-Q, for the period ended 2025-03-31
- 2025-03-31 0001104659-25-029637 — NT 10-K, for the period ended 2024-12-31
- 2024-11-13 0001104659-24-117677 — NT 10-Q, for the period ended 2024-09-30
- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-25-026833:8k_2_02:1]
EX-99.1
2
evlv-20250520exx991.htm
EX-99.1

[0001628280-25-026833:8k_2_02:2]
Document

[0001628280-25-026833:8k_2_02:3]
Exhibit 99.1

[0001628280-25-026833:8k_2_02:4]
Evolv Technology Reports First Quarter Financial Results

[0001628280-25-026833:8k_2_02:5]
—  Company Surpasses 6,600 Total Subscriptions  —

[0001628280-25-026833:8k_2_02:6]
—  Company Expects Revenue Growth of 20%-25% with Positive Full Year Adjusted EBITDA in 2025 —

[0001628280-25-026833:8k_2_02:7]
•Q1'25 Revenue of $32.0 million, up 44% year-over-year

[0001628280-25-026833:8k_2_02:8]
•Q1'25 Ending ARR1 of $106.0 million, up 34% year-over-year

[0001628280-25-026833:8k_2_02:9]
•Q1'25 Net Loss of $(1.7) million, compared to $(11.3) million in Q1'24

[0001628280-25-026833:8k_2_02:10]
•Q1'25 Net Profit Margin of (5)%, compared to (51)% in Q1'24

[0001628280-25-026833:8k_2_02:11]
•Q1'25 Adjusted EBITDA1 of $1.7 million, with Adjusted EBITDA Margin1 of 5%

[0001628280-25-026833:8k_2_02:12]
Waltham, Massachusetts – May 20, 2025 – Evolv Technologies Holdings, Inc (NASDAQ: EVLV), a leading security technology company pioneering AI-based solutions designed to help create safer experiences, today announced financial results for the quarter ended March 31, 2025.

[0001628280-25-026833:8k_2_02:13]
“I am pleased with our solid first quarter results and the foundation we’re building for continued growth and operational excellence,” said John Kedzierski, President and Chief Executive Officer of Evolv Technology. “This performance represents a meaningful step in rebuilding a consistent track record of execution.”

[0001628280-25-026833:8k_2_02:14]
Results for the First Quarter of 2025

[0001628280-25-026833:8k_2_02:15]
Total revenue for the first quarter of 2025 was $32.0 million, an increase of 44% compared to $22.2 million (as restated) for the first quarter of 2024. Annual Recurring Revenue (“ARR”)2 was $106.0 million at the end of first quarter of 2025, an increase of 34% compared to $79.2 million (as restated) at the end of the first quarter of 2024. Net loss for the first quarter of 2025 was $(1.7) million, or $(0.01) per basic and diluted share, compared to net loss of $(11.3) million (as restated), or $(0.07) per basic and diluted share (as restated), in the first quarter of 2024. Adjusted earnings (loss)1 for the first quarter of 2025 was $(3.4) million, or $(0.02) per diluted share, compared to adjusted earnings (loss)1 of $(12.7) million (as restated), or $(0.08) per diluted share (as restated), for the first quarter of 2024. Adjusted EBITDA1 for the first quarter of 2025 was $1.7 million compared to $(10.4) million (as restated) in the first quarter of 2024. As of March 31, 2025, the Company had cash, cash equivalents and marketable securities of $35.0 million and no debt.

[0001628280-25-026833:8k_2_02:16]
The following table summarizes the breakdown of recurring and non-recurring revenue3 for each period presented:

[0001628280-25-026833:8k_2_02:17]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  |  |  | 2025 |  | 2024 |  | % Change |
|  |  |  |  |  |  |  |  |  | (Restated) |  |  |
| Recurring revenue |  |  |  |  |  |  | $ | 25,753 |  |  | $ | 18,961 |  |  | 36 | % |
| Non-recurring revenue |  |  |  |  |  |  | 6,254 |  |  | 3,220 |  |  | 94 | % |
| Total revenue |  |  |  |  |  |  | $ | 32,007 |  |  | $ | 22,181 |  |  | 44 | % |

[0001628280-25-026833:8k_2_02:18]
The following table summarizes operating cash flows for each period presented:

[0001628280-25-026833:8k_2_02:19]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Net loss |  |  |  |  | $ | (1,689) |  |  | $ | (11,272) |  |
| Non-cash expense |  |  |  |  | (1,082) |  |  | 1,656 |  |
| Changes in operating assets and liabilities |  |  |  |  | 232 |  |  | (6,535) |  |
| Net cash used in operating activities |  |  |  |  | $ | (2,539) |  |  | $ | (16,151) |  |

[0001628280-25-026833:8k_2_02:20]
Company Comments on Outlook for 2025

[0001628280-25-026833:8k_2_02:21]
The Company today commented on its business outlook for 2025. The Company's outlook is based on the current indications for its business, which may change at any time.  The Company expects total revenues in 2025 to be between $125 to $130 million, reflecting growth of 20% to 25% compared to 2024.  The Company believes that this revenue growth, coupled with a focus on operational efficiency, will drive improved profitability and cash flow.  To further strengthen its operations, the Company plans to make near-term investments of approximately $2 million in 2025 in systems and processes to enhance internal controls and drive efficiencies. Inclusive of these investments, the Company expects to deliver positive full year Adjusted EBITDA1 in 2025 with Adjusted EBITDA1 margins in the low to mid-single digits.  The Company expects to deliver positive free cash flow in the fourth quarter of 2025.

[0001628280-25-026833:8k_2_02:22]
Company to Host Live Conference Call and Webcast

[0001628280-25-026833:8k_2_02:23]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business.  The conference call will be webcast live at http://ir.evolvtechnology.com.

[0001628280-25-026833:8k_2_02:24]
About Evolv Technology

[0001628280-25-026833:8k_2_02:25]
Evolv Technologies Holdings, Inc (NASDAQ: EVLV) is designed to transform human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics. Its mission is to transform security to create a safer world to live, work, learn, and play. Evolv has digitally transformed the gateways in many places where people gather by enabling seamless integration combined with powerful analytics and insights. Evolv’s advanced systems have scanned more than two billion people since 2019. Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) 2024 New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category, as well as Sport Business Journal’s (SBJ) 2024 awards for “Best In Fan Experience Technology” and “Best In Sports Technology”. Evolv®, Evolv Express®, Evolv Insights®, Evolv Visual Gun Detection™, Evolv eXpedite™, and Evolv Eva™ are registered trademarks or trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit evolv.com.

[0001628280-25-026833:8k_2_02:26]
1 Non-GAAP Financial Measures In this press release, the Company’s adjusted gross profit (loss), adjusted gross margin, adjusted operating expenses, adjusted operating income (loss), adjusted EBITDA, adjusted EBITDA margin, adjusted earnings (loss), and adjusted earnings per diluted share are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted operating expenses is defined as operating expenses less stock-based compensation expense, loss on impairment of lease equipment, one-time employee separation costs, and one-time legal and regulatory costs, which management believes provides a more meaningful representation of on-going operating expense levels. One time legal and regulatory costs include one-time legal, accounting and professional fees related to the internal investigation, subsequent restatement, certain one-time regulatory, litigation and legal matters, as well as fees related to the resolution of the U.S. Federal Trade Commission investigation, net of estimated insurance recoveries. Adjusted gross profit and adjusted gross margin exclude stock-based compensation expense, amortization of capitalized stock-based compensation, and one-time inventory charges, which management believes provides a more meaningful representation of contribution margin. Adjusted operating loss is defined as operating loss, excluding stock-based compensation expense, amortization of capitalized stock-based compensation, one-time employee separation costs, one-time inventory charges, and one-time legal and regulatory costs, which management believes provides a more meaningful

[0001628280-25-026833:8k_2_02:27]
representation of operating results. Adjusted EBITDA and Adjusted EBITDA margin is defined as net income (loss) plus depreciation and amortization, stock-based compensation, interest expense (income), provision for income taxes, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, one-time employee separation costs, one-time inventory charges, and one-time legal and regulatory costs. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, amortization of capitalized stock-based compensation, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, one-time employee separation costs, one-time inventory charges, and one-time legal and regulatory costs. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operating performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release. The Company is unable to provide a reconciliation of Adjusted EBITDA to Net Income (Loss) and Adjusted EBITDA Margin to Net Profit Margin, each measure's most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact these GAAP financial measures are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of derivative liabilities, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001628280-25-026833:8k_2_02:28]
2 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001628280-25-026833:8k_2_02:29]
3 Recurring revenue includes the recurring portion of revenue associated with pure subscription contracts and hardware purchase subscription contracts. Non-recurring revenue includes revenue that is one-time in nature, such as product revenue, shipping revenue, and revenue from installation, training, and professional services.

[0001628280-25-026833:8k_2_02:30]
Forward-Looking Statements

[0001628280-25-026833:8k_2_02:31]
Technology under the Homeland Security SAFETY Act; risks related to our business model, which is predicated, in part, on building a customer base that will generate a recurring stream of revenues through the sale of our subscription contracts; the ability for the Company to obtain, maintain, protect and enforce the Company’s intellectual property rights and use of “open source” software; the concentration of the Company’s revenues on a single solution; the Company’s ability to timely design, produce and launch its solutions, the Company’s ability to invest in growth initiatives and pursue acquisition opportunities; the limited liquidity and trading of the Company’s securities; risks related to existing and changing tax laws; geopolitical risk and changes in applicable laws or regulations; the possibility that the Company may be adversely affected by other economic, business, and/or competitive factors; operational risk; risks related to material weaknesses in our internal control over financial reporting and our remediation plans; risks related to increasing attention to and evolving expectations for, environmental, social, and governance initiatives; the impact of fluctuating general economic and market conditions and reductions in spending; the need for additional capital to support business growth, which might not be available on acceptable terms, if at all; and litigation and regulatory enforcement risks, including the diversion of management time and attention and the additional costs and demands on resources. These and other important factors discussed under the caption “Risk Factors” in our Annual Report on Form 10-K for the year ended December 31, 2024 filed with the Securities and Exchange Commission ("SEC") on April 28, 2025 and the Quarterly Report on Form 10-Q for the quarter ended March 31, 2025, could cause actual results to differ materially from those indicated by the forward-looking statements made in this press release. The forward-looking statements in this press release and related presentation materials are based upon information available to us as of the date hereof, and while we believe such information forms a reasonable basis for such statements, it may be limited or incomplete, and our statements should not be read to indicate that we have conducted an exhaustive inquiry into, or review of, all potentially available relevant information. These statements are inherently uncertain and investors are cautioned not to unduly rely upon these statements.

[0001628280-25-026833:8k_2_02:32]
You should review this press release and the documents that we reference in this press release and related presentation materials with the understanding that our actual future results, levels of activity, performance and achievements may be materially different from what we expect. We qualify all of our forward-looking statements by these cautionary statements. Except as required by applicable law, we do not plan to publicly update or revise any forward-looking statements contained in this press release and related presentation materials, whether as a result of any new information, future events or otherwise.

[0001628280-25-026833:8k_2_02:33]
Investor Relations:

[0001628280-25-026833:8k_2_02:34]
Brian Norris

[0001628280-25-026833:8k_2_02:35]
Senior Vice President of Finance and Investor Relations

[0001628280-25-026833:8k_2_02:36]
bnorris@evolvtechnology.com

[0001628280-25-026833:8k_2_02:37]
EVOLV TECHNOLOGY

[0001628280-25-026833:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001628280-25-026833:8k_2_02:39]
(In thousands, except share and per share data)

[0001628280-25-026833:8k_2_02:40]
(Unaudited)

[0001628280-25-026833:8k_2_02:41]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue |  |  |  |  | $ | 2,322 |  |  | $ | 1,491 |  |
| Subscription revenue |  |  |  |  | 19,237 |  |  | 14,219 |  |
| Service revenue |  |  |  |  | 6,730 |  |  | 5,252 |  |
| License fee and other revenue |  |  |  |  | 3,718 |  |  | 1,219 |  |
| Total revenue |  |  |  |  | 32,007 |  |  | 22,181 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue |  |  |  |  | 3,184 |  |  | 3,114 |  |
| Cost of subscription revenue |  |  |  |  | 7,896 |  |  | 5,585 |  |
| Cost of service revenue |  |  |  |  | 1,705 |  |  | 1,198 |  |
| Cost of license fee and other revenue |  |  |  |  | 72 |  |  | 129 |  |
| Total cost of revenue |  |  |  |  | 12,857 |  |  | 10,026 |  |
| Gross profit |  |  |  |  | 19,150 |  |  | 12,155 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development |  |  |  |  | 4,862 |  |  | 6,396 |  |
| Sales and marketing |  |  |  |  | 11,043 |  |  | 15,859 |  |
| General and administrative |  |  |  |  | 14,972 |  |  | 11,806 |  |
| Restructuring costs |  |  |  |  | 2,662 |  |  | — |  |
| Total operating expenses |  |  |  |  | 33,539 |  |  | 34,061 |  |
| Loss from operations |  |  |  |  | (14,389) |  |  | (21,906) |  |
| Other income, net: |  |  |  |  |  |  |  |
| Interest expense |  |  |  |  | (1) |  |  | — |  |
| Interest income |  |  |  |  | 389 |  |  | 1,085 |  |
| Other income (expense), net |  |  |  |  | 25 |  |  | (28) |  |
| Change in fair value of contingent earn-out liability |  |  |  |  | 8,976 |  |  | 6,899 |  |
| Change in fair value of contingently issuable common stock liability |  |  |  |  | 1,653 |  |  | 527 |  |
| Change in fair value of public warrant liability |  |  |  |  | 1,721 |  |  | 2,151 |  |
| Total other income, net |  |  |  |  | 12,763 |  |  | 10,634 |  |
| Loss before income taxes |  |  |  |  | (1,626) |  |  | (11,272) |  |
| Provision for income taxes |  |  |  |  | $ | (63) |  |  | $ | — |  |
| Net loss |  |  |  |  | $ | (1,689) |  |  | $ | (11,272) |  |
| Weighted average common shares outstanding – basic and diluted |  |  |  |  | 160,808,391 |  |  | 153,076,719 |  |
| Net loss per share - basic and diluted |  |  |  |  | $ | (0.01) |  |  | $ | (0.07) |  |
| Net loss |  |  |  |  | $ | (1,689) |  |  | $ | (11,272) |  |
| Other comprehensive (loss) income |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  |  |  | (46) |  |  | 3 |  |
| Total other comprehensive (loss) income |  |  |  |  | (46) |  |  | 3 |  |
| Total comprehensive loss |  |  |  |  | $ | (1,735) |  |  | $ | (11,269) |  |

[0001628280-25-026833:8k_2_02:42]
EVOLV TECHNOLOGY

[0001628280-25-026833:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-25-026833:8k_2_02:44]
(In thousands, except share and per share data)

[0001628280-25-026833:8k_2_02:45]
(Unaudited)

[0001628280-25-026833:8k_2_02:46]
|  | March 31, 2025 |  | December 31, 2024 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 25,089 |  |  | $ | 37,015 |  |
| Marketable securities | 9,931 |  |  | 14,927 |  |
| Accounts receivable, net | 34,475 |  |  | 28,392 |  |
| Inventory | 10,056 |  |  | 16,963 |  |
| Current portion of contract assets | 905 |  |  | 799 |  |
| Current portion of commission asset | 5,355 |  |  | 5,429 |  |
| Prepaid expenses and other current assets | 17,958 |  |  | 17,921 |  |
| Total current assets | 103,769 |  |  | 121,446 |  |
| Contract assets, noncurrent | 872 |  |  | 657 |  |
| Commission asset, noncurrent | 7,438 |  |  | 7,567 |  |
| Property and equipment, net | 129,681 |  |  | 123,661 |  |
| Operating lease right-of-use assets | 13,569 |  |  | 13,993 |  |
| Other assets | 653 |  |  | 735 |  |
| Total assets | $ | 255,982 |  |  | $ | 268,059 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 7,115 |  |  | $ | 10,492 |  |
| Accrued expenses and other current liabilities | 19,378 |  |  | 19,508 |  |
| Current portion of deferred revenue | 65,489 |  |  | 64,506 |  |
| Current portion of operating lease liabilities | 2,416 |  |  | 2,203 |  |
| Total current liabilities | 94,398 |  |  | 96,709 |  |
| Deferred revenue, noncurrent | 19,783 |  |  | 20,266 |  |
| Operating lease liabilities, noncurrent | 11,983 |  |  | 12,326 |  |
| Contingent earn-out liability | 3,833 |  |  | 12,809 |  |
| Contingently issuable common stock liability | 2,348 |  |  | 4,001 |  |
| Public warrant liability | 2,576 |  |  | 4,297 |  |
| Total liabilities | 134,921 |  |  | 150,408 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at March 31, 2025 and December 31, 2024; no shares issued and outstanding at March 31, 2025 and December 31, 2024 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at March 31, 2025 and December 31, 2024; 163,273,142 and 159,602,069 shares issued and outstanding at March 31, 2025 and December 31, 2024, respectively | 16 |  |  | 16 |  |
| Additional paid-in capital | 477,476 |  |  | 472,331 |  |
| Accumulated other comprehensive loss | (78) |  |  | (32) |  |
| Accumulated deficit | (356,353) |  |  | (354,664) |  |
| Stockholders’ equity | 121,061 |  |  | 117,651 |  |
| Total liabilities and stockholders’ equity | $ | 255,982 |  |  | $ | 268,059 |  |

[0001628280-25-026833:8k_2_02:47]
EVOLV TECHNOLOGY

[0001628280-25-026833:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-25-026833:8k_2_02:49]
(In thousands)

[0001628280-25-026833:8k_2_02:50]
(Unaudited)

[0001628280-25-026833:8k_2_02:51]
|  | Three Months EndedMarch 31, |
|  | 2025 |  | 2024 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (1,689) |  |  | $ | (11,272) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 5,530 |  |  | 3,457 |  |
| Write-off of inventory and change in inventory reserve | 2 |  |  | 1,059 |  |
| Loss on disposal of property and equipment | 321 |  |  | — |  |
| Stock-based compensation | 4,879 |  |  | 6,430 |  |
| Amortization of premium on marketable securities, net of change in accrued interest | 71 |  |  | 200 |  |
| Non-cash lease expense | 424 |  |  | 354 |  |
| Change in allowance for expected credit losses | 41 |  |  | (267) |  |
| Change in fair value of earn-out liability | (8,976) |  |  | (6,899) |  |
| Change in fair value of contingently issuable common stock | (1,653) |  |  | (527) |  |
| Change in fair value of public warrant liability | (1,721) |  |  | (2,151) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (6,124) |  |  | 2,157 |  |
| Inventory | 7,172 |  |  | (1,760) |  |
| Commission assets | 203 |  |  | (89) |  |
| Contract assets | (321) |  |  | 280 |  |
| Other assets | 82 |  |  | 203 |  |
| Prepaid expenses and other current assets | (3,859) |  |  | (3,738) |  |
| Accounts payable | 2,780 |  |  | (695) |  |
| Deferred revenue | 500 |  |  | (558) |  |
| Accrued expenses and other current liabilities | (71) |  |  | (1,943) |  |
| Operating lease liability | (130) |  |  | (392) |  |
| Net cash used in operating activities | (2,539) |  |  | (16,151) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (1,556) |  |  | (1,567) |  |
| Purchases of property and equipment | (12,730) |  |  | (19,827) |  |
| Purchases of marketable securities | (9,875) |  |  | (14,567) |  |
| Proceeds from maturities of marketable securities | 14,800 |  |  | 29,241 |  |
| Net cash used in investing activities | (9,361) |  |  | (6,720) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 20 |  |  | 302 |  |
| Net cash provided by financing activities | 20 |  |  | 302 |  |
| Effect of exchange rate changes on cash and cash equivalents | (46) |  |  | 3 |  |
| Net decrease in cash, cash equivalents and restricted cash | (11,926) |  |  | (22,566) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 37,015 |  |  | 67,437 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 25,089 |  |  | $ | 44,871 |  |

[0001628280-25-026833:8k_2_02:52]
EVOLV TECHNOLOGY

[0001628280-25-026833:8k_2_02:53]
SUMMARY OF KEY OPERATING STATISTICS

[0001628280-25-026833:8k_2_02:54]
(Unaudited)

[0001628280-25-026833:8k_2_02:55]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  |  |  |  |  |  |
| New customers |  | 53 |  |  | 84 |  |  | 52 |  |  | 60 |  |  | 54 |  |  |  |  |  |  |  |
| Annual recurring revenue |  | $ | 79,192 |  |  | $ | 87,011 |  |  | $ | 93,676 |  |  | $ | 99,351 |  |  | $ | 105,990 |  |  |  |  |  |  |  |
| Recurring revenue |  | $ | 18,961 |  |  | $ | 21,016 |  |  | $ | 23,764 |  |  | $ | 23,678 |  |  | $ | 25,753 |  |  |  |  |  |  |  |
| Total net units shipped* |  | 375 |  |  | 447 |  |  | 468 |  |  | 458 |  |  | 465 |  |  |  |  |  |  |  |

[0001628280-25-026833:8k_2_02:56]
*Net Units Shipped reflects total units shipped (excluding rental units, upgrade units, etc.) less units churned.

[0001628280-25-026833:8k_2_02:57]
EVOLV TECHNOLOGY

[0001628280-25-026833:8k_2_02:58]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001628280-25-026833:8k_2_02:59]
(In thousands)

[0001628280-25-026833:8k_2_02:60]
(Unaudited)

[0001628280-25-026833:8k_2_02:61]
|  | Three Months Ended, |
|  |  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  |  |  |  |  |  |
|  |  | (Restated) |  | (Restated) |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses, GAAP |  | $ | 34,061 |  |  | $ | 36,954 |  |  | $ | 34,961 |  |  | $ | 35,619 |  |  | $ | 33,539 |  |  |  |  |  |  |  |
| Stock-based compensation |  | (6,292) |  |  | (7,254) |  |  | (7,263) |  |  | (3,159) |  |  | (4,660) |  |  |  |  |  |  |  |
| Loss on impairment of lease equipment |  | — |  |  | — |  |  | (209) |  |  | (15) |  |  | — |  |  |  |  |  |  |  |
| One-time employee separation costs |  | — |  |  | (826) |  |  | — |  |  | (2,060) |  |  | (2,137) |  |  |  |  |  |  |  |
| Other one-time legal and regulatory costs |  | (476) |  |  | (2,185) |  |  | (2,339) |  |  | (7,284) |  |  | (3,561) |  |  |  |  |  |  |  |
| Adjusted operating expenses |  | $ | 27,293 |  |  | $ | 26,689 |  |  | $ | 25,150 |  |  | $ | 23,101 |  |  | $ | 23,181 |  |  |  |  |  |  |  |

[0001628280-25-026833:8k_2_02:62]
EVOLV TECHNOLOGY

[0001628280-25-026833:8k_2_02:63]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT, GAAP GROSS MARGIN TO ADJUSTED GROSS MARGIN AND GAAP OPERATING INCOME (LOSS) TO ADJUSTED OPERATING INCOME (LOSS)

[0001628280-25-026833:8k_2_02:64]
(In thousands)

[0001628280-25-026833:8k_2_02:65]
(Unaudited)

[0001628280-25-026833:8k_2_02:66]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Revenue |  |  |  |  | $ | 32,007 |  |  | $ | 22,181 |  |
| Cost of revenue |  |  |  |  | 12,857 |  |  | 10,026 |  |
| Gross profit, GAAP |  |  |  |  | 19,150 |  |  | 12,155 |  |
| Stock-based compensation |  |  |  |  | 219 |  |  | 138 |  |
| Amortization of capitalized stock-based compensation |  |  |  |  | 103 |  |  | 14 |  |
| One-time inventory charges |  |  |  |  | — |  |  | 1,204 |  |
| Adjusted gross profit |  |  |  |  | $ | 19,472 |  |  | $ | 13,511 |  |
| Gross margin % |  |  |  |  | 59.8 | % |  | 54.8 | % |
| Adjusted gross margin % |  |  |  |  | 60.8 | % |  | 60.9 | % |

[0001628280-25-026833:8k_2_02:67]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Operating loss, GAAP |  |  |  |  | $ | (14,389) |  |  | $ | (21,906) |  |
| Stock-based compensation |  |  |  |  | 4,879 |  |  | 6,430 |  |
| Amortization of capitalized stock-based compensation |  |  |  |  | 103 |  |  | 14 |  |
| One-time employee separation costs |  |  |  |  | 2,137 |  |  | — |  |
| One-time inventory charges |  |  |  |  | — |  |  | 1,204 |  |
| Other one-time legal and regulatory costs |  |  |  |  | 3,561 |  |  | 476 |  |
| Adjusted operating loss |  |  |  |  | $ | (3,709) |  |  | $ | (13,782) |  |

[0001628280-25-026833:8k_2_02:68]
EVOLV TECHNOLOGY

[0001628280-25-026833:8k_2_02:69]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA AND NET PROFIT MARGIN TO ADJUSTED EBITDA MARGIN

[0001628280-25-026833:8k_2_02:70]
(In thousands)

[0001628280-25-026833:8k_2_02:71]
(Unaudited)

[0001628280-25-026833:8k_2_02:72]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Net loss |  |  |  |  | $ | (1,689) |  |  | $ | (11,272) |  |
| Depreciation & amortization |  |  |  |  | 5,530 |  |  | 3,457 |  |
| Stock-based compensation |  |  |  |  | 4,879 |  |  | 6,430 |  |
| Interest expense (income) |  |  |  |  | (388) |  |  | (1,085) |  |
| Provision for income taxes |  |  |  |  | 63 |  |  | — |  |
| Change in fair value of contingent earn-out liability |  |  |  |  | (8,976) |  |  | (6,899) |  |
| Change in fair value of contingently issuable common stock liability |  |  |  |  | (1,653) |  |  | (527) |  |
| Change in fair value of public warrant liability |  |  |  |  | (1,721) |  |  | (2,151) |  |
| One-time employee separation costs |  |  |  |  | 2,137 |  |  | — |  |
| One-time inventory charges |  |  |  |  | — |  |  | 1,204 |  |
| Other one-time legal and regulatory costs |  |  |  |  | 3,561 |  |  | 476 |  |
| Adjusted EBITDA |  |  |  |  | $ | 1,743 |  |  | $ | (10,367) |  |
| Net profit margin % |  |  |  |  | (5.3) | % |  | (50.8) | % |
| Impact of adjustments from Net loss to Adjusted EBITDA |  |  |  |  | 10.7 | % |  | 4.1 | % |
| Adjusted EBITDA margin % |  |  |  |  | 5.4 | % |  | (46.7) | % |

[0001628280-25-026833:8k_2_02:73]
EVOLV TECHNOLOGY

[0001628280-25-026833:8k_2_02:74]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001628280-25-026833:8k_2_02:75]
(In thousands, except share and per share data)

[0001628280-25-026833:8k_2_02:76]
(Unaudited)

[0001628280-25-026833:8k_2_02:77]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Net loss |  |  |  |  | $ | (1,689) |  |  | $ | (11,272) |  |
| Stock-based compensation |  |  |  |  | 4,879 |  |  | 6,430 |  |
| Amortization of capitalized stock-based compensation |  |  |  |  | 103 |  |  | 14 |  |
| Change in fair value of contingent earn-out liability |  |  |  |  | (8,976) |  |  | (6,899) |  |
| Change in fair value of contingently issuable common stock liability |  |  |  |  | (1,653) |  |  | (527) |  |
| Change in fair value of public warrant liability |  |  |  |  | (1,721) |  |  | (2,151) |  |
| One-time employee separation costs |  |  |  |  | 2,137 |  |  | — |  |
| One-time inventory charges |  |  |  |  | — |  |  | 1,204 |  |
| Other one-time legal and regulatory costs |  |  |  |  | 3,561 |  |  | 476 |  |
| Adjusted loss |  |  |  |  | $ | (3,359) |  |  | $ | (12,725) |  |
| Weighted average common shares outstanding – diluted |  |  |  |  | 160,808,391 |  |  | 153,076,719 |  |
| Adjusted loss per share – diluted |  |  |  |  | $ | (0.02) |  |  | $ | (0.08) |  |

[0001628280-25-026833:8k_2_02:78]
*Stock-based compensation, amortization of capitalized stock-based compensation, and one-time employee separation costs were recorded in the condensed consolidated statements of operations and comprehensive loss (income) as follows. Prior period amounts are being shown for comparative purposes:

[0001628280-25-026833:8k_2_02:79]
|  | Three Months Ended, |
|  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  |  |  |  |  |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | $ | — |  |  | $ | 5 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |  |  |  |  |  |  |
| Cost of subscription revenue | 91 |  |  | 110 |  |  | 169 |  |  | 154 |  |  | 137 |  |  |  |  |  |  |  |
| Cost of service revenue | 44 |  |  | 51 |  |  | 63 |  |  | 61 |  |  | 67 |  |  |  |  |  |  |  |
| Cost of license fee and other revenue | 3 |  |  | 7 |  |  | 8 |  |  | 10 |  |  | 7 |  |  |  |  |  |  |  |
| Research and development | 902 |  |  | 1,222 |  |  | 1,243 |  |  | 1,153 |  |  | 1,115 |  |  |  |  |  |  |  |
| Sales and marketing | 2,959 |  |  | 2,724 |  |  | 2,516 |  |  | 2,747 |  |  | 1,048 |  |  |  |  |  |  |  |
| General and administrative | 2,431 |  |  | 3,308 |  |  | 3,504 |  |  | (741) |  |  | 1,972 |  |  |  |  |  |  |  |
| Restructuring costs | — |  |  | — |  |  | — |  |  | — |  |  | 525 |  |  |  |  |  |  |  |
| Total stock-based compensation | $ | 6,430 |  |  | $ | 7,427 |  |  | $ | 7,507 |  |  | $ | 3,392 |  |  | $ | 4,879 |  |  |  |  |  |  |  |
| Amortization of capitalized stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of subscription revenue | $ | 8 |  |  | $ | 8 |  |  | $ | 13 |  |  | $ | 47 |  |  | $ | 59 |  |  |  |  |  |  |  |
| Cost of service revenue | 6 |  |  | 7 |  |  | 10 |  |  | 38 |  |  | 44 |  |  |  |  |  |  |  |
| Total amortization of capitalized stock-based compensation | $ | 14 |  |  | $ | 15 |  |  | $ | 23 |  |  | $ | 85 |  |  | $ | 103 |  |  |  |  |  |  |  |
| One-time employee separation costs: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing | $ | — |  |  | $ | 140 |  |  | $ | — |  |  | $ | 63 |  |  | $ | — |  |  |  |  |  |  |  |
| General and administrative | — |  |  | — |  |  | — |  |  | 1,997 |  |  | — |  |  |  |  |  |  |  |
| Restructuring costs | — |  |  | 860 |  |  | — |  |  | — |  |  | 2,137 |  |  |  |  |  |  |  |
| Total restructuring expenses | $ | — |  |  | $ | 1,000 |  |  | $ | — |  |  | $ | 2,060 |  |  | $ | 2,137 |  |  |  |  |  |  |  |
