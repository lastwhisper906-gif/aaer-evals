# EVLV MD&A — 0001628280-25-026845


## mdna

[0001628280-25-026845:mdna:1]
[same as prior period, unchanged from 0001628280-25-020353:mdna:1]

[0001628280-25-026845:mdna:2]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of our business combination (the “Merger”) and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001628280-25-026845:mdna:3]
Restatement of Prior Period Financial Statements

[0001628280-25-026845:mdna:4]
We have restated our previously issued condensed consolidated financial statements contained in this Quarterly Report on Form 10-Q. In addition, we have restated certain previously reported financial information for the quarterly period ended March 31, 2024 in this Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations, including but not limited to information within the Results of Operations section. See Note 2 in the notes to the condensed consolidated financial statements in this Quarterly Report on Form 10-Q, for additional information related to the restatement, including descriptions of the misstatements and the impacts on our condensed consolidated financial statements.

[0001628280-25-026845:mdna:5]
[same as prior period, unchanged from 0001628280-25-020353:mdna:5]

[0001628280-25-026845:mdna:6]
[same as prior period, unchanged from 0001628280-25-020353:mdna:6]

[0001628280-25-026845:mdna:7]
[same as prior period, unchanged from 0001628280-25-020353:mdna:7]

[0001628280-25-026845:mdna:8]
Our flagship product, Evolv Express, uses advanced sensors, AI-powered software, and cloud services to not only consistently detect firearms, improvised explosives, and certain types of knives and distinguish them from many harmless items such as cell phones and keys, but also visualize the location of the potential threat helping to enable security personnel to conduct targeted, minimally intrusive secondary screenings. Evolv eXpedite, our high speed autonomous X-ray bag scanning solution, works with Evolv Express to provide a layered approach to security for concealed weapons detection in high clutter environments. Using eXpedite with Express aims to allow the checkpoint to operate at heightened sensitivity while potentially reducing the burden on security staff and optimizing the visitor experience.

[0001628280-25-026845:mdna:9]
Our innovative technology is designed to enhance security and provide an efficient, positive visitor and customer security experience. In addition to screening capabilities, our solution includes Evolv Insights®, a powerful software analytics dashboard that allows customers to comprehensively review, analyze, and gather insights from the Evolv Express screening systems at their various venue or facility locations.  Available data includes visitor arrival patterns, throughput volumes, system detection performance, alarm statistics, weapons detected and detection settings.  Our customers can leverage this data to inform their security operations, while providing end-users with an approachable security experience.

[0001628280-25-026845:mdna:10]
Our products, which are offered to our customers primarily under a multi-year subscription model, provide predictable revenue streams for us in addition to value for our customers.

[0001628280-25-026845:mdna:11]
[same as prior period, unchanged from 0001628280-25-020353:mdna:12]

[0001628280-25-026845:mdna:12]
[same as prior period, unchanged from 0001628280-25-020353:mdna:15]

[0001628280-25-026845:mdna:13]
[same as prior period, unchanged from 0001628280-25-020353:mdna:16]

[0001628280-25-026845:mdna:14]
[same as prior period, unchanged from 0001628280-25-020353:mdna:17]

[0001628280-25-026845:mdna:15]
We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of rising inflation and interest rates on business spending; supply chain issues and the impacts on our manufacturing capabilities; public health emergencies; geopolitical conflicts and war, including the conflicts in Europe and the Middle East; and recessionary trends. See the risk factor titled “Our operating results may fluctuate for a variety of reasons, including our failure to close large volume opportunity customer sales” in the “Risk Factors” section in this Quarterly Report on Form 10-Q. While these factors continue to evolve, we plan to remain flexible and optimize our business as appropriate and allocate resources, as necessary.

[0001628280-25-026845:mdna:16]
[same as prior period, unchanged from 0001628280-25-020353:mdna:19]

[0001628280-25-026845:mdna:17]
[same as prior period, unchanged from 0001628280-25-020353:mdna:20]

[0001628280-25-026845:mdna:18]
[same as prior period, unchanged from 0001628280-25-020353:mdna:21]

[0001628280-25-026845:mdna:19]
We sell our solutions under two primary sales models. We offer a “pure subscription” model, where the customer leases hardware from us and we provide a multi-year security-as-a-service subscription. For end-user customers that prefer to purchase our hardware outright, we offer our “distributor licensing” model based on the Distribution and License Agreement we entered into with Columbia Tech in March of 2023. Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, currently serves as our primary contract manufacturer. Under this arrangement, we have granted a license of our intellectual property to Columbia Tech, which contracts directly with certain of our resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment. Columbia Tech pays us a hardware license fee for each system it manufactures and sells under this agreement. In these instances, we still contract directly with the reseller to provide a multi-year security-as-a-service subscription to the end-users. We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our revenue, gross profit, gross margin, and overall profitability in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments. We have been experiencing a growing mix of customers adopting our full subscription model, which reduces upfront revenue recognition in favor of building a more predictable recurring revenue base.

[0001628280-25-026845:mdna:20]
Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions, primarily within the United States. Pricing may vary by region or vertical market due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales, bookings, and business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will

[0001628280-25-026845:mdna:21]
2

[0001628280-25-026845:mdna:22]
depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products to our customers.

[0001628280-25-026845:mdna:23]
[same as prior period, unchanged from 0001628280-25-020353:mdna:25]

[0001628280-25-026845:mdna:24]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $32.0 million and $22.2 million for the three months ended March 31, 2025 and 2024, respectively. We generated a net loss of $1.7 million and $11.3 million for the three months ended March 31, 2025 and 2024, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-25-026845:mdna:25]
[same as prior period, unchanged from 0001628280-25-020353:mdna:27]

[0001628280-25-026845:mdna:26]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations, and if necessary, debt financings. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources” for more information. Additionally, as discussed in Note 14 (Commitments and Contingencies) to our condensed consolidated financial statements for the three months ended March 31, 2025, we are involved in certain legal proceedings, including government investigations. Given the uncertainty of such matters, no assurance can be given regarding the final outcome of such matters. However, the ultimate amount or range of potential loss, which might result to the Company, may differ materially from our current estimates.

[0001628280-25-026845:mdna:27]
[same as prior period, unchanged from 0001628280-25-020353:mdna:29]

[0001628280-25-026845:mdna:28]
[same as prior period, unchanged from 0001628280-25-020353:mdna:30]

[0001628280-25-026845:mdna:29]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement, (4) license fees related to the Distribution and License Agreement, and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax. We have been experiencing a growing mix of customers adopting our full subscription model, which reduces upfront revenue recognition in favor of building a more predictable recurring revenue base.

[0001628280-25-026845:mdna:30]
[same as prior period, unchanged from 0001628280-25-020353:mdna:32]

[0001628280-25-026845:mdna:31]
[same as prior period, unchanged from 0001628280-25-020353:mdna:33]

[0001628280-25-026845:mdna:32]
[same as prior period, unchanged from 0001628280-25-020353:mdna:35]

[0001628280-25-026845:mdna:33]
[same as prior period, unchanged from 0001628280-25-020353:mdna:36]

[0001628280-25-026845:mdna:34]
[same as prior period, unchanged from 0001628280-25-020353:mdna:34]

[0001628280-25-026845:mdna:35]
Lease arrangements generally include both lease and non-lease components. The non-lease components relate to (1) distinct services, including professional services, SaaS, and maintenance, and (2) any add-on accessories. Professional services are included in license fees and other revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our condensed consolidated statements of operations and comprehensive loss.

[0001628280-25-026845:mdna:36]
[same as prior period, unchanged from 0001628280-25-020353:mdna:38]

[0001628280-25-026845:mdna:37]
[same as prior period, unchanged from 0001628280-25-020353:mdna:39]

[0001628280-25-026845:mdna:38]
[same as prior period, unchanged from 0001628280-25-020353:mdna:40]

[0001628280-25-026845:mdna:39]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from Columbia Tech to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration. Revenue for professional services and other one-time revenue, which had previously been included in service revenue, has been reclassified for prior periods to License fee and other revenue on the condensed consolidated statements of operations and comprehensive loss. We anticipate changes in license fee and other revenue to be driven by underlying demand for our solutions as well as any changes in demand for our distributor licensing model.

[0001628280-25-026845:mdna:40]
[same as prior period, unchanged from 0001628280-25-020353:mdna:42]

[0001628280-25-026845:mdna:41]
[same as prior period, unchanged from 0001628280-25-020353:mdna:43]

[0001628280-25-026845:mdna:42]
[same as prior period, unchanged from 0001628280-25-020353:mdna:44]

[0001628280-25-026845:mdna:43]
[same as prior period, unchanged from 0001628280-25-020353:mdna:45]

[0001628280-25-026845:mdna:44]
[same as prior period, unchanged from 0001628280-25-020353:mdna:46]

[0001628280-25-026845:mdna:45]
[same as prior period, unchanged from 0001628280-25-020353:mdna:47]

[0001628280-25-026845:mdna:46]
[same as prior period, unchanged from 0001628280-25-020353:mdna:48]

[0001628280-25-026845:mdna:47]
[same as prior period, unchanged from 0001628280-25-020353:mdna:49]

[0001628280-25-026845:mdna:48]
[same as prior period, unchanged from 0001628280-25-020353:mdna:50]

[0001628280-25-026845:mdna:49]
Cost of license fees and other revenue consists primarily of internal and third-party costs related to professional services, such as installation, training, and event support. License fee revenue earned under our Distribution and License Agreement with Columbia Tech has no associated cost of revenue.

[0001628280-25-026845:mdna:50]
[same as prior period, unchanged from 0001628280-25-020353:mdna:53]

[0001628280-25-026845:mdna:51]
[same as prior period, unchanged from 0001628280-25-020353:mdna:52]

[0001628280-25-026845:mdna:52]
[same as prior period, unchanged from 0001628280-25-020353:mdna:54]

[0001628280-25-026845:mdna:53]
[same as prior period, unchanged from 0001628280-25-020353:mdna:55]

[0001628280-25-026845:mdna:54]
[same as prior period, unchanged from 0001628280-25-020353:mdna:56]

[0001628280-25-026845:mdna:55]
[same as prior period, unchanged from 0001628280-25-020353:mdna:57]

[0001628280-25-026845:mdna:56]
[same as prior period, unchanged from 0001628280-25-020353:mdna:58]

[0001628280-25-026845:mdna:57]
[same as prior period, unchanged from 0001628280-25-020353:mdna:59]

[0001628280-25-026845:mdna:58]
[same as prior period, unchanged from 0001628280-25-020353:mdna:60]

[0001628280-25-026845:mdna:59]
[same as prior period, unchanged from 0001628280-25-020353:mdna:61]

[0001628280-25-026845:mdna:60]
[same as prior period, unchanged from 0001628280-25-020353:mdna:62]

[0001628280-25-026845:mdna:61]
[same as prior period, unchanged from 0001628280-25-020353:mdna:63]

[0001628280-25-026845:mdna:62]
[same as prior period, unchanged from 0001628280-25-020353:mdna:64]

[0001628280-25-026845:mdna:63]
[same as prior period, unchanged from 0001628280-25-020353:mdna:65]

[0001628280-25-026845:mdna:64]
[same as prior period, unchanged from 0001628280-25-020353:mdna:66]

[0001628280-25-026845:mdna:65]
[same as prior period, unchanged from 0001628280-25-020353:mdna:67]

[0001628280-25-026845:mdna:66]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and insurance, net of any probable and reasonably estimable insurance recoveries or received insurance recoveries. During the year ended 2024, we experienced a significant increase in general and administrative expenses, primarily for legal fees and consulting expenses, as a result of the Investigation and related actions, as described in Note 2, Restatement of Previously Issued Condensed Consolidated Financial Statements. We expect this increased level of expenses to continue through the second quarter of 2025. As such actions become completed, we expect our general and administrative expenses to decrease in the second half of 2025 and to remain consistent at more normalized levels thereafter.

[0001628280-25-026845:mdna:67]
Restructuring Costs

[0001628280-25-026845:mdna:68]
Restructuring costs consists of termination charges arising from severance obligations, incremental non-cash expense related to extended eligibility for the vesting of certain equity awards, and other customary employee benefit payments in connection with a reduction in force. See Note 16 for additional information.

[0001628280-25-026845:mdna:69]
[same as prior period, unchanged from 0001628280-25-020353:mdna:72]

[0001628280-25-026845:mdna:70]
[same as prior period, unchanged from 0001628280-25-020353:mdna:73]

[0001628280-25-026845:mdna:71]
[same as prior period, unchanged from 0001628280-25-020353:mdna:74]

[0001628280-25-026845:mdna:72]
[same as prior period, unchanged from 0001628280-25-020353:mdna:75]

[0001628280-25-026845:mdna:73]
[same as prior period, unchanged from 0001628280-25-020353:mdna:78]

[0001628280-25-026845:mdna:74]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders are entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss.

[0001628280-25-026845:mdna:75]
[same as prior period, unchanged from 0001628280-25-020353:mdna:80]

[0001628280-25-026845:mdna:76]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock, referred to as Founder Shares. Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company's common stock. 1,897,500 Founder Shares vested at the closing of the Merger, 1,897,500 Founder Shares are contingently issuable and shall vest upon the Company achieving certain milestones, and 517,500 Founder Shares were contributed to Give Evolv LLC. The 1,897,500 outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss.

[0001628280-25-026845:mdna:77]
[same as prior period, unchanged from 0001628280-25-020353:mdna:82]

[0001628280-25-026845:mdna:78]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are currently exercisable and expire in July 2026. We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss with the offset to additional paid-in capital.

[0001628280-25-026845:mdna:79]
[same as prior period, unchanged from 0001628280-25-020353:mdna:84]

[0001628280-25-026845:mdna:80]
[same as prior period, unchanged from 0001628280-25-020353:mdna:85]

[0001628280-25-026845:mdna:81]
[same as prior period, unchanged from 0001628280-25-020353:mdna:89]

[0001628280-25-026845:mdna:82]
Comparison of the Three Months Ended March 31, 2025 and 2024

[0001628280-25-026845:mdna:83]
The following table summarizes our results of operations for the three months ended March 31, 2025 and 2024 (in thousands):

[0001628280-25-026845:mdna:84]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 2,322 |  |  | $ | 1,491 |  |  | $ | 831 |  |  | 56 | % |
| Subscription revenue | 19,237 |  |  | 14,219 |  |  | 5,018 |  |  | 35 |  |
| Service revenue | 6,730 |  |  | 5,252 |  |  | 1,478 |  |  | 28 |  |
| License fee and other revenue | 3,718 |  |  | 1,219 |  |  | 2,499 |  |  | 205 |  |
| Total revenue | 32,007 |  |  | 22,181 |  |  | 9,826 |  |  | 44 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 3,184 |  |  | 3,114 |  |  | 70 |  |  | 2 |  |
| Cost of subscription revenue | 7,896 |  |  | 5,585 |  |  | 2,311 |  |  | 41 |  |
| Cost of service revenue | 1,705 |  |  | 1,198 |  |  | 507 |  |  | 42 |  |
| Cost of license fee and other revenue | 72 |  |  | 129 |  |  | (57) |  |  | (44) |  |
| Total cost of revenue | 12,857 |  |  | 10,026 |  |  | 2,831 |  |  | 28 |  |
| Gross profit | 19,150 |  |  | 12,155 |  |  | 6,995 |  |  | 58 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 4,862 |  |  | 6,396 |  |  | (1,534) |  |  | (24) |  |
| Sales and marketing | 11,043 |  |  | 15,859 |  |  | (4,816) |  |  | (30) |  |
| General and administrative | 14,972 |  |  | 11,806 |  |  | 3,166 |  |  | 27 |  |
| Restructuring costs | 2,662 |  |  | — |  |  | 2,662 |  |  | * |
| Total operating expenses | 33,539 |  |  | 34,061 |  |  | (522) |  |  | (2) |  |
| Loss from operations | (14,389) |  |  | (21,906) |  |  | 7,517 |  |  | 34 |  |
| Other income, net: |  |  |  |  |  |  |  |
| Interest expense | (1) |  |  | — |  |  | (1) |  |  | * |
| Interest income | 389 |  |  | 1,085 |  |  | (696) |  |  | (64) |  |
| Other income (expense), net | 25 |  |  | (28) |  |  | 53 |  |  | 189 |  |
| Change in fair value of contingent earn-out liability | 8,976 |  |  | 6,899 |  |  | 2,077 |  |  | 30 |  |
| Change in fair value of contingently issuable common stock liability | 1,653 |  |  | 527 |  |  | 1,126 |  |  | 214 |  |
| Change in fair value of public warrant liability | 1,721 |  |  | 2,151 |  |  | (430) |  |  | (20) |  |
| Total other income, net | 12,763 |  |  | 10,634 |  |  | 2,129 |  |  | 20 |  |
| Loss before income taxes | $ | (1,626) |  |  | $ | (11,272) |  |  | $ | 9,646 |  |  | 86 | % |
| Provision for income taxes | $ | (63) |  |  | $ | — |  |  | $ | (63) |  |  | * |
| Net loss | $ | (1,689) |  |  | $ | (11,272) |  |  | $ | 9,583 |  |  | 85 | % |

[0001628280-25-026845:mdna:85]
[same as prior period, unchanged from 0001628280-25-020353:mdna:93]

[0001628280-25-026845:mdna:86]
[same as prior period, unchanged from 0001628280-25-020353:mdna:94]

[0001628280-25-026845:mdna:87]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 54 new customers during the three months ended March 31, 2025, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations as well as expanding their fleet with our Evolv eXpedite offering, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-25-026845:mdna:88]
[same as prior period, unchanged from 0001628280-25-020353:mdna:96]

[0001628280-25-026845:mdna:89]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Product revenue | $ | 2,322 |  |  | $ | 1,491 |  |  | $ | 831 |  |  | 56 | % |
| Cost of product revenue | $ | 3,184 |  |  | $ | 3,114 |  |  | $ | 70 |  |  | 2 | % |
| Gross profit - Product revenue | $ | (862) |  |  | $ | (1,623) |  |  | $ | 761 |  |  | 47 | % |
| Gross profit margin - Product revenue | (37) | % |  | (109) | % |  | N/A |  | 72 | % |

[0001628280-25-026845:mdna:90]
The increases in product revenue and gross profit are primarily due to an increase in product sales of Evolv Express and Evolv eXpedite units for the three months ended  March 31, 2025 compared to the prior year period. In addition, the change in cost of product revenue and improved product gross profit margin was impacted by a $0.7 million of expense related to an increase to our inventory reserve and $1.2 million of expense associated with adverse non-cancellable inventory purchase commitments during the three months ended March 31, 2024, both of which related primarily to the transition of our manufacturing operations to the next generation of Evolv Express systems. Product gross profit for the three months ended March 31, 2025 included the initial deployments of our Evolv eXpedite systems, which reflected a higher initial cost to produce than we expect on future production.

[0001628280-25-026845:mdna:91]
[same as prior period, unchanged from 0001628280-25-020353:mdna:99]

[0001628280-25-026845:mdna:92]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Subscription revenue | $ | 19,237 |  |  | $ | 14,219 |  |  | $ | 5,018 |  |  | 35 | % |
| Cost of subscription revenue | $ | 7,896 |  |  | $ | 5,585 |  |  | $ | 2,311 |  |  | 41 | % |
| Gross profit - Subscription revenue | $ | 11,341 |  |  | $ | 8,634 |  |  | $ | 2,707 |  |  | 31 | % |
| Gross profit margin - Subscription revenue | 59 | % |  | 61 | % |  | N/A |  | (2) | % |

[0001628280-25-026845:mdna:93]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to continued growth in our customer base as of March 31, 2025 compared to the prior year, which was due to a higher number of active Evolv Express units deployed under our pure subscription model. The decrease in gross profit margin is due to increased amortization of capitalized software costs during the three months ended March 31, 2025 of $0.4 million due to the release of Evolv eXpedite and our second generation of Evolv Express.

[0001628280-25-026845:mdna:94]
[same as prior period, unchanged from 0001628280-25-020353:mdna:103]

[0001628280-25-026845:mdna:95]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Service revenue | $ | 6,730 |  |  | $ | 5,252 |  |  | $ | 1,478 |  |  | 28 | % |
| Cost of service revenue | $ | 1,705 |  |  | $ | 1,198 |  |  | $ | 507 |  |  | 42 | % |
| Gross profit - Service revenue | $ | 5,025 |  |  | $ | 4,054 |  |  | $ | 971 |  |  | 24 | % |
| Gross profit margin - Service revenue | 75 | % |  | 77 | % |  | N/A |  | (3) | % |

[0001628280-25-026845:mdna:96]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech under our distributor model, for the three months ended March 31, 2025 compared to the prior year period.

[0001628280-25-026845:mdna:97]
[same as prior period, unchanged from 0001628280-25-020353:mdna:106]

[0001628280-25-026845:mdna:98]
|  | Three Months EndedMarch 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| License fee and other revenue | $ | 3,718 |  |  | $ | 1,219 |  |  | $ | 2,499 |  |  | 205 | % |
| Cost of license fee and other revenue | $ | 72 |  |  | $ | 129 |  |  | $ | (57) |  |  | (44) | % |
| Gross profit - License fee and other revenue | $ | 3,646 |  |  | $ | 1,090 |  |  | $ | 2,556 |  |  | 234 | % |
| Gross profit margin - License fee and other revenue | 98 | % |  | 89 | % |  | N/A |  | 9 | % |

[0001628280-25-026845:mdna:99]
The increases in license fee and other revenue and gross profit are primarily driven by $3.2 million of license fee revenue earned during the three months ended March 31, 2025 compared to $0.7 million earned during the prior year period under the Distribution and License Agreement with Columbia Tech. License fee revenue earned under the agreement have no associated cost of revenue.

[0001628280-25-026845:mdna:100]
[same as prior period, unchanged from 0001628280-25-020353:mdna:109]

[0001628280-25-026845:mdna:101]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 3,850 |  |  | $ | 4,178 |  |  | $ | (328) |  |  | (8) | % |
| Materials and prototypes | 67 |  |  | 839 |  |  | (772) |  |  | (92) | % |
| Professional fees | 672 |  |  | 917 |  |  | (245) |  |  | (27) | % |
| Other | 273 |  |  | 462 |  |  | (189) |  |  | (41) | % |
|  | $ | 4,862 |  |  | $ | 6,396 |  |  | $ | (1,534) |  |  | (24) | % |

[0001628280-25-026845:mdna:102]
The decrease in personnel related expenses is due to a decrease in payroll costs of $0.2 million and a higher amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $0.3 million, partially offset by a $0.2 million increase in stock-based compensation resulting primarily from new hires in our research and development function during the past twelve months. The decrease in materials and prototypes expense is due to a decrease of $0.4 million in design and engineering costs related to the development of the next generation of our Evolv Express system and new product offerings and a $0.4 million decrease in inventory reserve charges during the prior year period, which also relate primarily to the development of the next generation of our Evolv Express system. The decrease in professional fees primarily relates to a decrease in consulting costs incurred for product development and engineering of $0.5 million, partially offset by lower amount of costs capitalized related to internal-use software and

[0001628280-25-026845:mdna:103]
[same as prior period, unchanged from 0001628280-25-020353:mdna:112]

[0001628280-25-026845:mdna:104]
software embedded in products to be sold or leased of $0.2 million. The decrease in other expense primarily relates to a decrease in supplies and IT and software subscription costs of $0.2 million.

[0001628280-25-026845:mdna:105]
[same as prior period, unchanged from 0001628280-25-020353:mdna:113]

[0001628280-25-026845:mdna:106]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 8,504 |  |  | $ | 11,846 |  |  | $ | (3,342) |  |  | (28) | % |
| Advertising and direct marketing | 583 |  |  | 810 |  |  | (227) |  |  | (28) | % |
| Travel and entertainment | 544 |  |  | 1,270 |  |  | (726) |  |  | (57) | % |
| Professional fees | 645 |  |  | 959 |  |  | (314) |  |  | (33) | % |
| Other | 767 |  |  | 974 |  |  | (207) |  |  | (21) | % |
|  | $ | 11,043 |  |  | $ | 15,859 |  |  | $ | (4,816) |  |  | (30) | % |

[0001628280-25-026845:mdna:107]
The decrease in personnel related expenses is due to a decrease in payroll costs and stock-based compensation of $3.2 million, which resulted primarily from the reductions in force in May 2024 and January 2025. Stock compensation expense included in sales and marketing expenses was $1.0 million for the three months ended March 31, 2025 compared to $3.0 million for the three months ended March 31, 2024. The decrease in advertising and direct marketing expense is primarily due to a decrease in sponsorship fees of $0.2 million. The decrease in travel and entertainment expense of $0.7 million is due to a decrease in travel costs for in-person sales personnel meetings as our sales and marketing headcount decreased as a result of our reductions in force. Professional fees decreased due to a decrease in marketing consulting costs of $0.3 million.

[0001628280-25-026845:mdna:108]
[same as prior period, unchanged from 0001628280-25-020353:mdna:116]

[0001628280-25-026845:mdna:109]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 5,304 |  |  | $ | 6,192 |  |  | $ | (888) |  |  | (14) | % |
| Professional fees | 2,658 |  |  | 2,558 |  |  | 100 |  |  | 4 | % |
| Insurance costs | 731 |  |  | 742 |  |  | (11) |  |  | (1) | % |
| Non-recurring professional and other expense | 6,279 |  |  | 2,314 |  |  | 3,965 |  |  | 171 | % |
|  | $ | 14,972 |  |  | $ | 11,806 |  |  | $ | 3,166 |  |  | 27 | % |

[0001628280-25-026845:mdna:110]
The decrease in personnel related expenses is due to an decrease in payroll costs and stock-based compensation of $0.8 million, which resulted primarily from the reduction in force in January 2025. Stock compensation expense included in general and administrative expenses was $2.0 million for the three months ended March 31, 2025 compared to $2.4 million for the three months ended March 31, 2024. Non-recurring professional fees and other expense increased primarily due to a $6.9 million increase in consulting and legal fees related to the Investigation (as defined in Note 2 in the notes to the condensed consolidated financial statements in this Quarterly Report on Form 10-Q) and related matters, partially offset by estimated insurance recoveries of $3.9 million, as well as additional audit fees incurred in connection with the restatement of prior period financial statements, an increase in rent of $0.4 million for additional leased space, and an increase in expected credit loss expense of $0.3 million.

[0001628280-25-026845:mdna:111]
Restructuring Costs

[0001628280-25-026845:mdna:112]
Restructuring costs of $2.7 million for the three months ended March 31, 2025 resulted from the reduction in force in January 2025. Stock compensation expense included in restructuring costs was $0.5 million for the three months ended March 31, 2025.

[0001628280-25-026845:mdna:113]
[same as prior period, unchanged from 0001628280-25-020353:mdna:121]

[0001628280-25-026845:mdna:114]
Interest income of $0.4 million for the three months ended March 31, 2025 and $1.1 million for the three months ended March 31, 2024 related primarily to interest earned on money market funds and the accretion of discounts on treasury bills.

[0001628280-25-026845:mdna:115]
[same as prior period, unchanged from 0001628280-25-020353:mdna:124]

[0001628280-25-026845:mdna:116]
Change in the fair value of the contingent earn-out liability resulted in gains of $9.0 million and $6.9 million for the three months ended March 31, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001628280-25-026845:mdna:117]
[same as prior period, unchanged from 0001628280-25-020353:mdna:126]

[0001628280-25-026845:mdna:118]
Change in the fair value of the contingently issuable common stock liability resulted in gains of $1.7 million and $0.5 million for the three months ended March 31, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001628280-25-026845:mdna:119]
[same as prior period, unchanged from 0001628280-25-020353:mdna:128]

[0001628280-25-026845:mdna:120]
Change in the fair value of the public warrant liability resulted in gains of $1.7 million and $2.2 million for the three months ended March 31, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001628280-25-026845:mdna:121]
[same as prior period, unchanged from 0001628280-25-020353:mdna:172]

[0001628280-25-026845:mdna:122]
Our financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. As of March 31, 2025, we had $35.0 million in cash, cash equivalents, and marketable securities. We incurred a net loss of $1.7 million and a net income of $11.3 million for the three months ended March 31, 2025 and 2024, respectively. We incurred cash outflows from operating activities of $2.5 million and $16.2 million during the three months ended March 31, 2025 and 2024, respectively. We expect to continue to generate losses for the foreseeable future.

[0001628280-25-026845:mdna:123]
[same as prior period, unchanged from 0001628280-25-020353:mdna:174]

[0001628280-25-026845:mdna:124]
We expect our cash, cash equivalents, and marketable securities of $35.0 million as of March 31, 2025, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months and thereafter from the date of this Quarterly Report on Form 10-Q. As we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to strategically and carefully invest in various areas of the business to support that growth. We may require additional capital to respond to expected growth in the demand for equipment to support our “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances. To the extent that our projected revenue growth does not materialize, we have established plans to preserve existing cash liquidity, which includes additional reductions operating expenses and capital expenditures.

[0001628280-25-026845:mdna:125]
Although not required to fund ongoing operations, in an improving interest rate environment, we may choose to engage in debt financings or enter into credit facilities for prudent capital management purposes and to provide additional readily available capital for strategic and other purposes. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, tariffs, supply

[0001628280-25-026845:mdna:126]
chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001628280-25-026845:mdna:127]
[same as prior period, unchanged from 0001628280-25-020353:mdna:178]

[0001628280-25-026845:mdna:128]
[same as prior period, unchanged from 0001628280-25-020353:mdna:179]

[0001628280-25-026845:mdna:129]
The Company has no debt outstanding as of March 31, 2025.

[0001628280-25-026845:mdna:130]
[same as prior period, unchanged from 0001628280-25-020353:mdna:181]

[0001628280-25-026845:mdna:131]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of March 31, 2025. We anticipate fulfilling such commitments with our existing cash, cash equivalents, and marketable securities, as well as cash and cash equivalents obtained through operations and, if necessary, proceeds from long-term debt. Cash, cash equivalents, and marketable securities amounted to $35.0 million as of March 31, 2025.

[0001628280-25-026845:mdna:132]
We are party to a lease agreement for office space at our headquarters in Waltham, MA. During the three months ended March 31, 2024, we amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. Additionally, in August 2024, we amended the lease agreement again to expand our footprint in our headquarters and extend the term of the lease through May 2031. Per the second lease amendment, we are no longer required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space. This amount was previously classified as restricted cash, non-current, as shown in the condensed consolidated statement of cash flows as of March 31, 2024. Total future minimum lease payments under this noncancelable operating lease amount to $19.1 million as of March 31, 2025.

[0001628280-25-026845:mdna:133]
We generally contract with our contract manufacturer, Columbia Tech, on a cancellable, purchase-order basis. We have a contract in the normal course of business with Columbia Tech to provide manufacturing services for our equipment sold or leased to customers. While these contracts are cancellable by us upon prior notice, payments due upon cancellation consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. These payments are not determinable, but could result in a material purchase commitment if we were to cancel our open purchase orders.

[0001628280-25-026845:mdna:134]
[same as prior period, unchanged from 0001628280-25-020353:mdna:184]

[0001628280-25-026845:mdna:135]
[same as prior period, unchanged from 0001628280-25-020353:mdna:185]

[0001628280-25-026845:mdna:136]
|  | Three Months EndedMarch 31, |
|  | 2025 |  | 2024 |
|  |  |  | (Restated) |
| Net cash used in operating activities | $ | (2,539) |  |  | $ | (16,151) |  |
| Net cash used in investing activities | (9,361) |  |  | (6,720) |  |
| Net cash provided by financing activities | 20 |  |  | 302 |  |
| Effect of exchange rate changes on cash and cash equivalents | (46) |  |  | 3 |  |
| Net decrease in cash, cash equivalents and restricted cash | $ | (11,926) |  |  | $ | (22,566) |  |

[0001628280-25-026845:mdna:137]
[same as prior period, unchanged from 0001628280-25-020353:mdna:188]

[0001628280-25-026845:mdna:138]
|  | Three Months EndedMarch 31, |
|  | 2025 |  | 2024 |
|  |  |  | (Restated) |
| Net loss | $ | (1,689) |  |  | $ | (11,272) |  |
| Non-cash expense | (1,082) |  |  | 1,656 |  |
| Changes in operating assets and liabilities | 232 |  |  | (6,535) |  |
| Net cash used in operating activities | $ | (2,539) |  |  | $ | (16,151) |  |

[0001628280-25-026845:mdna:139]
Net loss decreased from $11.3 million (as restated) for the three months ended March 31, 2024 to $1.7 million for the three months ended March 31, 2025, as discussed in “Results of Operations” above.

[0001628280-25-026845:mdna:140]
Non-cash expense for the three months ended March 31, 2025 is primarily attributable to $12.4 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability, offset by $4.9 million of stock-based compensation expense and $5.5 million of depreciation and amortization. Non-cash expense for the three months ended March 31, 2024 is primarily attributable to $6.4 million of stock-based compensation expense, $3.5 million of depreciation and amortization, and $9.6 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability.

[0001628280-25-026845:mdna:141]
Changes in operating assets and liabilities for the three months ended March 31, 2025 are primarily related to the following:

[0001628280-25-026845:mdna:142]
•$7.2 million decrease in inventory primarily due to an increase in products expected to be leased to customers and an increased focus on efficient inventory management;

[0001628280-25-026845:mdna:143]
•$2.8 million increase in accounts payable (excluding the non-cash portion related to capital expenditures incurred but not yet paid from December 31, 2024 to March 31, 2025) due primarily to the timing of vendor payments; and

[0001628280-25-026845:mdna:144]
•$0.5 million increase in deferred revenue due to a higher volume of sales; partially offset by

[0001628280-25-026845:mdna:145]
•$6.1 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001628280-25-026845:mdna:146]
•$3.9 million increase in prepaid expenses and other current assets primarily due to estimated insurance recoveries; and

[0001628280-25-026845:mdna:147]
•$0.3 million increase in contract assets due to higher volume of sales.

[0001628280-25-026845:mdna:148]
Changes in operating assets and liabilities for the three months ended March 31, 2024 are primarily related to the following:

[0001628280-25-026845:mdna:149]
•$1.8 million decrease in inventory primarily due to increased production of units to meet customer demand, offset by a higher proportion of finished goods recorded as property and equipment based on our expectations of the future mix of Evolv Express units to be leased to customers versus sold to customers;

[0001628280-25-026845:mdna:150]
•$3.7 million increase in prepaid expenses and other current assets primarily due to prepaid deposits related to orders placed for Evolv Express units;

[0001628280-25-026845:mdna:151]
•$1.9 million decrease in accrued expenses and other current liabilities primarily due to the payment of 2023 bonuses and commissions during the three months ended March 31, 2024; partially offset by

[0001628280-25-026845:mdna:152]
•$2.2 million decrease in accounts receivable primarily due to increased collections and timing of billings to customers.

[0001628280-25-026845:mdna:153]
[same as prior period, unchanged from 0001628280-25-020353:mdna:203]

[0001628280-25-026845:mdna:154]
During the three months ended March 31, 2025, cash provided by investing activities was $9.4 million, consisting of $12.7 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers and $1.6 million for the development of internal-use software and software embedded in products to be sold or leased, offset by $4.9 million of net cash provided by purchases and redemptions of marketable securities.

[0001628280-25-026845:mdna:155]
During the three months ended March 31, 2024, cash used in investing activities was $6.7 million, consisting primarily of $19.8 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express units to be leased to customers and $1.6 million for the development of internal-use software and software embedded in products to be sold or leased, partially offset by a net $14.7 million inflow related to purchases and redemptions of marketable securities.

[0001628280-25-026845:mdna:156]
[same as prior period, unchanged from 0001628280-25-020353:mdna:207]

[0001628280-25-026845:mdna:157]
During the three months ended March 31, 2025, cash provided by financing activities was less than $0.1 million, consisting of proceeds from the exercise of stock options.

[0001628280-25-026845:mdna:158]
During the three months ended March 31, 2024, cash used in financing activities was $0.3 million, consisting of $0.3 million of proceeds from the exercise of stock options.

[0001628280-25-026845:mdna:159]
[same as prior period, unchanged from 0001628280-25-020353:mdna:210]

[0001628280-25-026845:mdna:160]
There were no new accounting pronouncements that were issued or became effective since the issuance of the 2024 Form 10-K that had, or are expected to have, a material impact on its consolidated financial position, results of operations or cash flows.

[0001628280-25-026845:mdna:161]
[same as prior period, unchanged from 0001628280-25-020353:mdna:212]

[0001628280-25-026845:mdna:162]
Our critical accounting estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” of our 2024 Form 10-K. Other than disclosures related to estimating the fair value of market-based stock units, as discussed in Note 3 Summary of Significant Accounting Policies, there have been no material changes to our critical accounting estimates during the three months ended March 31, 2025.
