# EVLV notes — 0001628280-25-026845


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-25-026845:notes:1]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a leading security technology company with products designed to transform human security to make a safer, faster, and better experience for the world's most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics.

[0001628280-25-026845:notes:2]
The Company recently launched a new product offering, Evolv eXpedite™, an autonomous AI-based weapons detection system for bags. This new offering, as well as existing products such as Evolv Express®, are designed to be integrated layers for detection as part of a unified Evolv Safer Experience System™. These products and their associated services are designed to capture valuable visitor data customers can leverage to inform their security operations, while providing end-users with an approachable and non-intrusive security experience. The Company is headquartered in Waltham, Massachusetts.

[0001628280-25-026845:notes:3]
[same as prior period, unchanged from 0001628280-25-020353:notes:3]

[0001628280-25-026845:notes:4]
[same as prior period, unchanged from 0001628280-25-020353:notes:4]

[0001628280-25-026845:notes:5]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001628280-25-026845:notes:6]
[same as prior period, unchanged from 0001628280-25-020353:notes:6]

[0001628280-25-026845:notes:7]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of March 31, 2025, the Company had $35.0 million in cash, cash equivalents, and marketable securities. The Company incurred a net loss of $1.7 million and $11.3 million for the three months ended March 31, 2025 and 2024, respectively. The Company incurred cash outflows from operating activities of $2.5 million and $16.2 million during the three months ended March 31, 2025 and 2024, respectively. The Company expects to continue to generate losses for the foreseeable future.

[0001628280-25-026845:notes:8]
[same as prior period, unchanged from 0001628280-25-020353:notes:8]

[0001628280-25-026845:notes:9]
The Company expects its cash, cash equivalents, and marketable securities of $35.0 million as of March 31, 2025, together with cash it expects to generate from future operations, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth. The Company may

[0001628280-25-026845:notes:10]
require additional capital to respond to expected growth in the demand for equipment to support its “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances. To the extent that the Company's projected revenue growth does not materialize, it has established plans to preserve existing cash liquidity, which includes additional reductions in operating expenses and capital expenditures.

[0001628280-25-026845:notes:11]
Although not required to fund ongoing operations, in an improving interest rate environment the Company may choose to engage in debt financings or enter into credit facilities for prudent capital management purposes and to provide additional readily available capital for strategic and other purposes. If the Company is unable to obtain adequate financing or financing on terms satisfactory to it, when it requires it, the Company's ability to continue to grow or support the business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, tariffs, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing the Company's ability to access capital. If the Company is unable to raise additional funds when or on the terms desired, its business, financial condition and results of operations could be adversely affected.

[0001628280-25-026845:notes:12]
[same as prior period, unchanged from 0001628280-25-020353:notes:12]

[0001628280-25-026845:notes:13]
[same as prior period, unchanged from 0001628280-25-020353:notes:13]

[0001628280-25-026845:notes:14]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2025, and for the three months ended March 31, 2025 and 2024 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2024 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2025, the results of its operations for the three months ended March 31, 2025 and 2024 and cash flows for the three months ended March 31, 2025 and 2024. The results for the three months ended March 31, 2025 are not necessarily indicative of results to be expected for the year ending December 31, 2025, any other interim periods, or any future year or period.


## us-gaap:ErrorCorrectionTextBlock

[0001628280-25-026845:notes:15]
Restatement of Previously Issued Condensed Consolidated Financial Statements
We have restated herein our condensed consolidated financial statements for the three months ended March 31, 2024. We have also restated impacted amounts within the accompanying notes to the condensed consolidated financial statements, as applicable. The restatement of our condensed consolidated financial statements for the three months ended March 31, 2024 was previously reported in our Annual Report on Form 10-K for the year ended December 31, 2024 (the "2024 Form 10-K").

[0001628280-25-026845:notes:16]
Restatement Background

[0001628280-25-026845:notes:17]
In September 2024, an ad hoc committee of independent directors (the “Committee”) of the Company's Board of Directors (the “Board”), under the direction of the Board, commenced an investigation (the “Investigation”) of the Company’s sales practices, including whether certain sales of products and subscriptions to channel partners and end users were subject to extra-contractual terms and conditions that impacted revenue recognition and other metrics, and if so, when senior Company personnel became aware of these issues.

[0001628280-25-026845:notes:18]
As a result of the Investigation, the Committee determined that certain sales, including sales to one of its largest channel partners, were subject to extra-contractual terms and conditions, some of which were not shared with the Company’s accounting personnel, and that certain Company personnel engaged in misconduct in connection with those transactions. Furthermore, these extra-contractual terms and conditions were withheld from the Company’s Audit Committee of the Board (the “Audit Committee”) and the Company’s independent registered public accounting firm,

[0001628280-25-026845:notes:19]
PricewaterhouseCoopers LLP (“PwC”). The Committee also determined that certain accounting personnel were aware of indications of these extra-contractual terms and conditions during affected periods, and that related allegations were raised internally in July 2024 and known to senior finance and accounting personnel, but that those allegations were not escalated to the Audit Committee or communicated to PwC prior to the filing of the Company’s second quarter 2024 financial statements. As a result of the Investigation, the Board determined that new leadership was critical to moving the Company forward. In November 2024, the Company’s Chief Financial Officer resigned. Additionally, four other employees, including personnel from its sales, finance and accounting departments were terminated or resigned as a result of the Investigation.

[0001628280-25-026845:notes:20]
In connection with the Investigation, the Committee determined that the accounting for certain sales transactions was materially inaccurate and that, among other things, revenue was prematurely or incorrectly recognized (the “Impacted Transactions”) in connection with financial statements prepared for the fiscal years ended December 31, 2022 and December 31, 2023 contained in its Annual Report on Form 10-K for the year-ended December 31, 2023, and its condensed consolidated financial statements for the quarters and year-to-date periods ended June 30, 2022, September 30, 2022, March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024 and June 30, 2024 contained in its Quarterly Reports on Form 10-Q.

[0001628280-25-026845:notes:21]
A review of the transactions identified in the Investigation determined that restatement changes were necessary due to:

[0001628280-25-026845:notes:22]
•an overstatement or understatement of revenue and cost of revenue depending on the changes to revenue recognition start dates in each period of the consolidated statement of operations; and

[0001628280-25-026845:notes:23]
•an overstatement or understatement of other accounts affected by changes to revenue recognition start dates, including accounts receivable, inventory, contract assets, commission assets, property and equipment, net, deferred revenue, and sales and marketing expense.

[0001628280-25-026845:notes:24]
Misstatements related to the Impacted Transactions identified in the Investigation

[0001628280-25-026845:notes:25]
Revenue

[0001628280-25-026845:notes:26]
As discussed above, the Company became aware of the presence of extra-contractual terms and conditions through the Investigation. The extra-contractual terms and conditions created ambiguity with regard to whether the Company and its customers had reached a mutual understanding of the terms of the contracts. Ultimately, the Company decided to honor the customers’ understanding of the contracts, including the terms and conditions granted outside the written contracts.

[0001628280-25-026845:notes:27]
The extra-contractual terms and conditions affected the dates on which it was appropriate for the Company to recognize revenue, or commence revenue recognition for the Impacted Transactions. In order to correct the revenue recognition start dates for each of the Impacted Transactions to be restated, the Company reviewed the terms and circumstances of each transaction, including the contractual and extra-contractual terms and conditions.

[0001628280-25-026845:notes:28]
As described above, the Company offers products for purchase or multi-year subscription leases.  All products are sold with an underlying subscription for software and services. Contracts may include multiple performance obligations when customers purchase a combination of products and services.  For equipment sales, revenue is recognized at a point in time, whereas for leased equipment and software, revenue is recognized ratably over the term (“over time”).

[0001628280-25-026845:notes:29]
GAAP requires that revenue is recognized when (or as) the entity satisfies a performance obligation by transferring the underlying asset to a customer. An asset is transferred when (or as) the customer obtains control of that asset. Further, GAAP defines control as “…the ability to direct the use of, and obtain substantially all of the remaining benefits from, the asset.”

[0001628280-25-026845:notes:30]
Historically, the Company has recognized revenue, or commenced revenue recognition, upon shipment or delivery of the product to the customer, or to the end-user as directed by the customer, if the customer is a reseller. The findings of

[0001628280-25-026845:notes:31]
the Investigation and Financial Statement Review, as defined below, impact the timing of when revenue recognition should begin on certain arrangements. The Company determined that it should recognize or begin to recognize revenue on the Impacted Transactions at the point in time that the Company has an enforceable contract with the customer and control transfers to the customer, which, for the Impacted Transactions, was often the installation date, which is later than the shipment or delivery date. The extra-contractual terms created in substance consignment arrangements with customers, which resulted in no revenue recognition until control of the product was transferred to the customer (i.e., the installation date).

[0001628280-25-026845:notes:32]
For most of the Impacted Transactions, the Company determined that the customer was only committed to the agreement and began to receive and consume the benefits provided by the Company’s performance on the date the security screening system(s) and Software as a Service (“SaaS”) portal were both installed and activated at the end user site.  Therefore, revenue recognition for over time performance obligations was determined to begin at the installation date and recognized over the period in which the benefits are consumed (e.g., the subscription term). Product sales were also restated to be recorded at the installation date where appropriate. For point-in-time performance obligations, revenue was recognized at the installation date.

[0001628280-25-026845:notes:33]
Property, and Equipment / Inventory

[0001628280-25-026845:notes:34]
As stated above, the Company offers products for purchase or multi-year subscription leases. For equipment for which the revenue recognition start date was moved to a later date due to the timing of the transfer of control, the equipment cost was reclassified from Leased equipment to Equipment held for lease within Property and Equipment (for leased equipment), or added back to finished goods Inventory  (for equipment sales) until the point in time that the Company transferred control of the equipment to the customer, corresponding to the revenue recognition start date.

[0001628280-25-026845:notes:35]
Cost of Product Revenue / Cost of Subscription Revenue

[0001628280-25-026845:notes:36]
For leased equipment reclassified to equipment held for lease, as described above, the Company adjusted the dates placed in service to correspond to the revised date upon which revenue recognition commenced, thus achieving appropriate alignment of revenue recognition with the recognition of depreciation expense (cost of revenue), consistent with the company’s accounting policies. For equipment added back to inventory related to sales of equipment, the Company added back the associated cost of revenue in the period it was originally recognized, and restated the cost of revenue to correspond with the revenue recognition start date.

[0001628280-25-026845:notes:37]
Commissions Asset / Commissions Expense

[0001628280-25-026845:notes:38]
Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract, which generally begins upon transfer of control. For the Impacted Transactions on which the Company adjusted the revenue recognition start date, the amortization of the corresponding commission expense was adjusted to conform to the adjusted revenue recognition start date.

[0001628280-25-026845:notes:39]
Accounts Receivable, Contract Assets, Deferred Revenue

[0001628280-25-026845:notes:40]
Deferred Revenue, Contract Assets and Accounts Receivable relating to affected customer arrangements were adjusted to reflect the corresponding changes in revenue recognition start dates.

[0001628280-25-026845:notes:41]
Additional errors identified through the Financial Statement Review

[0001628280-25-026845:notes:42]
Following the Investigation, the Company completed a comprehensive review of its previously issued financial statements (the “Financial Statement Review”), which resulted in the identification of additional errors. These adjustments included:

[0001628280-25-026845:notes:43]
•an understatement of research and development expense and overstatement of property, plant and equipment in certain periods due to an error in the calculation of internal-use software costs in the first and second quarters of 2024;

[0001628280-25-026845:notes:44]
•an overstatement of cost of revenue and understatement of inventory and property and equipment, net in the first and second quarters of 2024 related to the expensing of inbound freight costs that should have been capitalized into inventory or property and equipment, net; and

[0001628280-25-026845:notes:45]
•an overstatement of accounts receivable and contract assets and corresponding understatement of deferred revenue in each period related to the incorrect classification of amounts due to the Company resulting from its contracts with customers.

[0001628280-25-026845:notes:46]
The impact of the correction of the misstatements and errors resulting from the Investigation and Financial Statement Review on the condensed consolidated financial statements in this Quarterly Report on Form 10-Q, as well as previously identified immaterial errors which have now been corrected, are summarized below. The applicable accompanying notes to the condensed consolidated financial statements have also been updated.

[0001628280-25-026845:notes:47]
The impact of the correction of the misstatements on the condensed consolidated statements of stockholders' equity were solely within net loss for errors impacting accumulated deficit and within stock-based compensation cost for errors impacting accumulated paid in capital. Errors impacting accumulated paid in capital were limited to periods prior to December 31, 2023 and therefore only impact the opening balance in the condensed consolidated statements of stockholders' equity for the three months ended March 31, 2024.

[0001628280-25-026845:notes:48]
The impact of the correction of the misstatements and errors on the condensed consolidated statements of cash flows were driven by changes in the related condensed consolidated balance sheets and condensed consolidated statement of operations and comprehensive loss line items, except as noted by footnote under each applicable table below.

[0001628280-25-026845:notes:49]
Where adjustments in the below tables relate to multiple categories, the adjustment amounts of each category are noted below each table and sum to the total adjustment reflected. Restatement adjustments are reflected as follows:

[0001628280-25-026845:notes:50]
ADJ 1: related to revenue recognition misstatements identified as part of the Investigation.

[0001628280-25-026845:notes:51]
ADJ 2: related to errors in capitalized internal-use software costs.

[0001628280-25-026845:notes:52]
ADJ 3: related to errors in capitalized freight costs.

[0001628280-25-026845:notes:53]
ADJ 4: other immaterial errors previously identified in prior periods corrected as part of the restatement.

[0001628280-25-026845:notes:54]
For the Three Months Ended March 31, 2024

[0001628280-25-026845:notes:55]
Restated Condensed Consolidated Statement of Operations and Comprehensive Loss Data

[0001628280-25-026845:notes:56]
(In thousands, except share and per share amounts)

[0001628280-25-026845:notes:57]
|  |  |  | Three Months Ended March 31, 2024 |  |  |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | ADJ 1 |  | $ | 603 |  |  | $ | 888 |  |  | $ | 1,491 |  |  |  |  |  |  |  |
| Subscription revenue | ADJ1 |  | 14,503 |  |  | (284) |  |  | 14,219 |  |  |  |  |  |  |  |
| Service revenue | ADJ1 |  | 5,384 |  |  | (132) |  |  | 5,252 |  |  |  |  |  |  |  |
| License fee and other revenue | ADJ1 |  | 1,178 |  |  | 41 |  |  | 1,219 |  |  |  |  |  |  |  |
| Total revenue |  |  | 21,668 |  |  | 513 |  |  | 22,181 |  |  |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | ADJ 1, ADJ 3, ADJ 4 |  | 2,777 |  |  | 337 |  |  | 3,114 |  |  |  |  |  |  |  |
| Cost of subscription revenue | ADJ 1, ADJ 2, ADJ 3, ADJ 4 |  | 5,779 |  |  | (194) |  |  | 5,585 |  |  |  |  |  |  |  |
| Cost of service revenue | ADJ 2, ADJ 4 |  | 1,211 |  |  | (13) |  |  | 1,198 |  |  |  |  |  |  |  |
| Cost of license fee and other revenue |  |  | 129 |  |  | — |  |  | 129 |  |  |  |  |  |  |  |
| Total cost of revenue |  |  | 9,896 |  |  | 130 |  |  | 10,026 |  |  |  |  |  |  |  |
| Gross profit |  |  | 11,772 |  |  | 383 |  |  | 12,155 |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | ADJ 2, ADJ 4 |  | 6,205 |  |  | 191 |  |  | 6,396 |  |  |  |  |  |  |  |
| Sales and marketing | ADJ 1, ADJ 4 |  | 16,005 |  |  | (146) |  |  | 15,859 |  |  |  |  |  |  |  |
| General and administrative | ADJ 4 |  | 11,840 |  |  | (34) |  |  | 11,806 |  |  |  |  |  |  |  |
| Total operating expenses |  |  | 34,050 |  |  | 11 |  |  | 34,061 |  |  |  |  |  |  |  |
| Loss from operations |  |  | (22,278) |  |  | 372 |  |  | (21,906) |  |  |  |  |  |  |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 1,085 |  |  | — |  |  | 1,085 |  |  |  |  |  |  |  |
| Other expense, net |  |  | (28) |  |  | — |  |  | (28) |  |  |  |  |  |  |  |
| Change in fair value of contingent earn-out liability |  |  | 6,899 |  |  | — |  |  | 6,899 |  |  |  |  |  |  |  |
| Change in fair value of contingently issuable common stock liability |  |  | 527 |  |  | — |  |  | 527 |  |  |  |  |  |  |  |
| Change in fair value of public warrant liability |  |  | 2,151 |  |  | — |  |  | 2,151 |  |  |  |  |  |  |  |
| Total other income (expense), net |  |  | 10,634 |  |  | — |  |  | 10,634 |  |  |  |  |  |  |  |
| Loss before income taxes |  |  | (11,644) |  |  | 372 |  |  | (11,272) |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (11,644) |  |  | $ | 372 |  |  | $ | (11,272) |  |  |  |  |  |  |  |
| Weighted average common shares outstanding – basic and diluted |  |  | 153,076,719 |  |  | — |  |  | 153,076,719 |  |  |  |  |  |  |  |
| Net loss per share - basic and diluted |  |  | $ | (0.08) |  |  | $ | 0.01 |  |  | $ | (0.07) |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (11,644) |  |  | $ | 372 |  |  | $ | (11,272) |  |  |  |  |  |  |  |
| Other comprehensive loss |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  | 3 |  |  | — |  |  | 3 |  |  |  |  |  |  |  |
| Total other comprehensive loss |  |  | 3 |  |  | — |  |  | 3 |  |  |  |  |  |  |  |
| Total comprehensive loss |  |  | $ | (11,641) |  |  | $ | 372 |  |  | $ | (11,269) |  |  |  |  |  |  |  |

[0001628280-25-026845:notes:58]
(a) Category references are described above. Where adjustments relate to multiple categories, the adjustment amounts of each category are noted below and sum to the total adjustment reflected in the table above:

[0001628280-25-026845:notes:59]
Cost of product revenue: ADJ 1 = $385, ADJ 3 = ($44), ADJ 4 = ($4)

[0001628280-25-026845:notes:60]
Cost of subscription revenue: ADJ 1 = ($56), ADJ 2 = ($1), ADJ 3 = ($171), ADJ 4  = $34

[0001628280-25-026845:notes:61]
Cost of service revenue: ADJ 2 = ($1), ADJ 4 = ($12)

[0001628280-25-026845:notes:62]
Research and development: ADJ 2 = $249, ADJ 4 =  ($58)

[0001628280-25-026845:notes:63]
Sales and marketing: ADJ 1 = ($11), ADJ 4 = ($135)

[0001628280-25-026845:notes:64]
Restated Condensed Consolidated Statement of Cash Flows

[0001628280-25-026845:notes:65]
(In thousands)

[0001628280-25-026845:notes:66]
|  |  |  | Three Months Ended March 31, 2024 |
|  |  |  | As Reported |  | Adjustment |  | As Restated |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (11,644) |  |  | $ | 372 |  |  | $ | (11,272) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,474 |  |  | (17) |  |  | 3,457 |  |
| Write-off of inventory and change in inventory reserve |  |  | 1,059 |  |  | — |  |  | 1,059 |  |
| Stock-based compensation |  |  | 6,410 |  |  | 20 |  |  | 6,430 |  |
| Amortization (accretion) of premium (discount) on marketable securities, net of change in accrued interest |  |  | 200 |  |  | — |  |  | 200 |  |
| Non-cash lease expense |  |  | 354 |  |  | — |  |  | 354 |  |
| Change in allowance for expected credit losses |  |  | (267) |  |  | — |  |  | (267) |  |
| Change in fair value of earn-out liability |  |  | (6,899) |  |  | — |  |  | (6,899) |  |
| Change in fair value of contingently issuable common stock |  |  | (527) |  |  | — |  |  | (527) |  |
| Change in fair value of public warrant liability |  |  | (2,151) |  |  | — |  |  | (2,151) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 848 |  |  | 1,309 |  |  | 2,157 |  |
| Inventory |  |  | (2,091) |  |  | 331 |  |  | (1,760) |  |
| Commission assets |  |  | (70) |  |  | (19) |  |  | (89) |  |
| Contract assets |  |  | 1,313 |  |  | (1,033) |  |  | 280 |  |
| Other assets |  |  | 203 |  |  | — |  |  | 203 |  |
| Prepaid expenses and other current assets |  |  | (3,746) |  |  | 8 |  |  | (3,738) |  |
| Accounts payable |  |  | (760) |  |  | 65 |  |  | (695) |  |
| Deferred revenue |  |  | 231 |  |  | (789) |  |  | (558) |  |
| Accrued expenses and other current liabilities |  |  | (1,628) |  |  | (315) |  |  | (1,943) |  |
| Operating lease liability |  |  | (392) |  |  | — |  |  | (392) |  |
| Net cash used in operating activities |  |  | (16,083) |  |  | (68) |  |  | (16,151) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Development of internal-use software(1) |  |  | (1,797) |  |  | 230 |  |  | (1,567) |  |
| Purchases of property and equipment(2) |  |  | (19,665) |  |  | (162) |  |  | (19,827) |  |
| Purchases of marketable securities |  |  | (14,567) |  |  | — |  |  | (14,567) |  |
| Proceeds from maturities of marketable securities |  |  | 29,241 |  |  | — |  |  | 29,241 |  |
| Net cash used in investing activities |  |  | (6,788) |  |  | 68 |  |  | (6,720) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 302 |  |  | — |  |  | 302 |  |
| Net cash provided by financing activities |  |  | 302 |  |  | — |  |  | 302 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 3 |  |  | — |  |  | 3 |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (22,566) |  |  | — |  |  | (22,566) |  |
| Cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 67,437 |  |  | — |  |  | 67,437 |  |
| Cash, cash equivalents and restricted cash at end of period |  |  | $ | 44,871 |  |  | $ | — |  |  | $ | 44,871 |  |

[0001628280-25-026845:notes:67]
| Supplemental disclosure of non-cash activities |  |  |  |  |  |  |  |
| Transfer of property and equipment to inventory |  |  | $ | 468 |  |  | $ | — |  |  | $ | 468 |  |
| Capital expenditures incurred but not yet paid |  |  | 12,030 |  |  | — |  |  | 12,030 |  |
| Capitalization of stock compensation |  |  | 195 |  |  | (20) |  |  | 175 |  |
| Operating lease liabilities arising from obtaining right-of-use assets |  |  | 1,694 |  |  | — |  |  | 1,694 |  |
| Reconciliation of cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 44,596 |  |  | $ | — |  |  | $ | 44,596 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Total cash, cash equivalents and restricted cash shown in the statements of cash flows |  |  | $ | 44,871 |  |  | $ | — |  |  | $ | 44,871 |  |

[0001628280-25-026845:notes:68]
(1) Relates to adjustments related to ADJ 2.

[0001628280-25-026845:notes:69]
(2) Relates to adjustments related to ADJ 4.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-25-026845:notes:70]
[same as prior period, unchanged from 0001628280-25-020353:notes:82]

[0001628280-25-026845:notes:71]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2024, and the notes thereto, which are included in our 2024 Form 10-K. Except for the estimates used to determine the grant date valuation for certain market-based stock units (“MSUs”), as described below, which began being granted during the three months ended March 31, 2025, there have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2025.

[0001628280-25-026845:notes:72]
Market-based Stock Units

[0001628280-25-026845:notes:73]
The estimated grant date fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.

[0001628280-25-026845:notes:74]
Recently Issued Accounting Pronouncements

[0001628280-25-026845:notes:75]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity may apply the amendments in ASU 2023-09 either prospectively to all annual periods beginning after December 15, 2024, or retrospectively to prior periods. The Company determined that ASU 2023-09 is applicable and will be adopted in our Annual Report on Form 10-K for the year ended December 31, 2025. It addresses disclosures only, the Company expects it will not have any material effects on its financial condition, results of operations, or cash flows.

[0001628280-25-026845:notes:76]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses.”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-25-026845:notes:77]
Marketable Securities
Marketable securities as of March 31, 2025 and December 31, 2024 consisted of the following:

[0001628280-25-026845:notes:78]
|  | March 31, 2025 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 9,931 |  |  | $ | — |  |  | $ | 9,931 |  |
| Total marketable securities | $ | 9,931 |  |  | $ | — |  |  | $ | 9,931 |  |

[0001628280-25-026845:notes:79]
|  | December 31, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 14,927 |  |  | $ | — |  |  | $ | 14,927 |  |
| Total marketable securities | $ | 14,927 |  |  | $ | — |  |  | $ | 14,927 |  |

[0001628280-25-026845:notes:80]
Marketable securities at March 31, 2025 and December 31, 2024 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three months ended March 31, 2025 and 2024. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive loss.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-026845:notes:81]
[same as prior period, unchanged from 0001628280-25-020353:notes:99]

[0001628280-25-026845:notes:82]
|  | Fair Value Measurements at March 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 11,305 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,305 |  |
| Treasury bills | — |  |  | 14,923 |  |  | — |  |  | 14,923 |  |
|  | $ | 11,305 |  |  | $ | 14,923 |  |  | $ | — |  |  | $ | 26,228 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 3,833 |  |  | $ | 3,833 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 2,348 |  |  | 2,348 |  |
| Public Warrant liability | 2,576 |  |  | — |  |  | — |  |  | 2,576 |  |
|  | $ | 2,576 |  |  | $ | — |  |  | $ | 6,181 |  |  | $ | 8,757 |  |

[0001628280-25-026845:notes:83]
|  | Fair Value Measurements at December 31, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 28,946 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,946 |  |
| Treasury bills | — |  |  | 27,417 |  |  | — |  |  | 27,417 |  |
|  | $ | 28,946 |  |  | $ | 27,417 |  |  | $ | — |  |  | $ | 56,363 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 12,809 |  |  | $ | 12,809 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 4,001 |  |  | 4,001 |  |
| Public Warrant liability | 4,297 |  |  | — |  |  | — |  |  | 4,297 |  |
|  | $ | 4,297 |  |  | $ | — |  |  | $ | 16,810 |  |  | $ | 21,107 |  |

[0001628280-25-026845:notes:84]
Money market funds are included in cash and cash equivalents on the condensed consolidated balance sheets. As of March 31, 2025, U.S. treasury bills with maturities less than 3 months, which totaled $5.0 million, are included in cash and cash equivalents, while treasury bills with maturities greater than 3 months, which totaled $9.9 million, are reflected as marketable securities. As of December 31, 2024, U.S. treasury bills with maturities less than 3 months, which totaled $12.5 million, are included in cash and cash equivalents, while treasury bills with maturities greater than 3 months, which totaled $14.9 million, are reflected as marketable securities. The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources.

[0001628280-25-026845:notes:85]
[same as prior period, unchanged from 0001628280-25-020353:notes:103]

[0001628280-25-026845:notes:86]
The carrying amounts of cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, and other accrued expenses approximate fair value because of their short maturity.

[0001628280-25-026845:notes:87]
During each of the three months ended March 31, 2025 and 2024, there were no transfers between Level 1, Level 2 and Level 3.

[0001628280-25-026845:notes:88]
[same as prior period, unchanged from 0001628280-25-020353:notes:106]

[0001628280-25-026845:notes:89]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 3 of our consolidated financial statements of our 2024 Form 10-K. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of March 31, 2025, no milestones have been achieved.

[0001628280-25-026845:notes:90]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of March 31, 2025 were as follows: 90% expected stock price volatility, a risk-free rate of return of 4.1%, a 25% likelihood of change in control and a remaining term of 0.9 years.

[0001628280-25-026845:notes:91]
[same as prior period, unchanged from 0001628280-25-020353:notes:109]

[0001628280-25-026845:notes:92]
| Balance at December 31, 2024 | $ | 12,809 |  |
| Change in fair value | (8,976) |  |
| Balance at March 31, 2025 | $ | 3,833 |  |

[0001628280-25-026845:notes:93]
[same as prior period, unchanged from 0001628280-25-020353:notes:111]

[0001628280-25-026845:notes:94]
[same as prior period, unchanged from 0001628280-25-020353:notes:112]

[0001628280-25-026845:notes:95]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock which were converted into shares of the Company's stock in connection with the Merger (the “Founder Shares”). Of these shares, 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 outstanding shares will vest upon the Company achieving certain milestones as described in Note 3 of our consolidated financial statements of our 2024 Form 10-K. The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of March 31, 2025, no milestones have been achieved.

[0001628280-25-026845:notes:96]
The fair value of the contingently issued common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of March 31, 2025 were as follows: 90% expected stock price volatility, a risk-free rate of return of 4.0%, a 25% likelihood of change in control and a remaining term of 1.3 years.

[0001628280-25-026845:notes:97]
[same as prior period, unchanged from 0001628280-25-020353:notes:115]

[0001628280-25-026845:notes:98]
| Balance at December 31, 2024 | $ | 4,001 |  |
| Change in fair value | (1,653) |  |
| Balance at March 31, 2025 | $ | 2,348 |  |

[0001628280-25-026845:notes:99]
[same as prior period, unchanged from 0001628280-25-020353:notes:117]

[0001628280-25-026845:notes:100]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. As of March 31, 2025, 14,324,893 Public Warrants are outstanding.

[0001628280-25-026845:notes:101]
[same as prior period, unchanged from 0001628280-25-020353:notes:120]

[0001628280-25-026845:notes:102]
| Balance at December 31, 2024 | $ | 4,297 |  |
| Change in fair value | (1,721) |  |
| Balance at March 31, 2025 | $ | 2,576 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-25-026845:notes:103]
[same as prior period, unchanged from 0001628280-25-020353:notes:122]

[0001628280-25-026845:notes:104]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4)

[0001628280-25-026845:notes:105]
license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after control passes to the customer. Revenue is recognized net of sales tax.

[0001628280-25-026845:notes:106]
[same as prior period, unchanged from 0001628280-25-020353:notes:124]

[0001628280-25-026845:notes:107]
[same as prior period, unchanged from 0001628280-25-020353:notes:125]

[0001628280-25-026845:notes:108]
[same as prior period, unchanged from 0001628280-25-020353:notes:126]

[0001628280-25-026845:notes:109]
[same as prior period, unchanged from 0001628280-25-020353:notes:127]

[0001628280-25-026845:notes:110]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2025:

[0001628280-25-026845:notes:111]
|  | Less than 1 year |  | 1 - 2 years |  | More than 2 years |  | Total |
| Product revenue | $ | 1,969 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,969 |  |
| Subscription revenue | 77,031 |  |  | 63,006 |  |  | 54,491 |  |  | 194,528 |  |
| Service revenue | 27,706 |  |  | 21,173 |  |  | 15,473 |  |  | 64,352 |  |
| License fee and other revenue | 359 |  |  | 8 |  |  | 17 |  |  | 384 |  |
| Total revenue | $ | 107,065 |  |  | $ | 84,187 |  |  | $ | 69,981 |  |  | $ | 261,233 |  |

[0001628280-25-026845:notes:112]
Contract Balances from Contracts with Customers

[0001628280-25-026845:notes:113]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time.  As of March 31, 2025 and December 31, 2024, the Company had $0.9 million and $0.8 million in current portion of contract assets and $0.9 million and $0.7 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001628280-25-026845:notes:114]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $24.7 million during the three months ended March 31, 2025 that was included in the December 31, 2024 deferred revenue balance. The Company recognized revenue of $16.9 million

[0001628280-25-026845:notes:115]
(as restated) during the three months ended March 31, 2024 that was included in the December 31, 2023 deferred revenue balance.

[0001628280-25-026845:notes:116]
[same as prior period, unchanged from 0001628280-25-020353:notes:134]

[0001628280-25-026845:notes:117]
| Balance at December 31, 2024 | $ | 84,772 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (24,737) |  |
| Revenue deferred | 25,237 |  |
| Balance at March 31, 2025 | $ | 85,272 |  |

[0001628280-25-026845:notes:118]
[same as prior period, unchanged from 0001628280-25-020353:notes:136]

[0001628280-25-026845:notes:119]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Interest income on lease receivables |  |  |  |  | $ | 29 |  |  | $ | 42 |  |
| Lease income - operating leases |  |  |  |  | 19,237 |  |  | 14,219 |  |
| Total lease revenue |  |  |  |  | $ | 19,266 |  |  | $ | 14,261 |  |

[0001628280-25-026845:notes:120]
The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties was $0.3 million during the three months ended March 31, 2024. There was no revenue related to leases entered into with related parties during the three months ended March 31, 2025.

[0001628280-25-026845:notes:121]
[same as prior period, unchanged from 0001628280-25-020353:notes:139]

[0001628280-25-026845:notes:122]
The following table presents the Company’s revenue by revenue stream (in thousands):

[0001628280-25-026845:notes:123]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Product revenue |  |  |  |  | $ | 2,322 |  |  | $ | 1,491 |  |
| Subscription revenue |  |  |  |  | 19,237 |  |  | 14,219 |  |
| Service revenue |  |  |  |  | 6,730 |  |  | 5,252 |  |
| License fees |  |  |  |  | 3,203 |  |  | 724 |  |
| Professional services and other revenue |  |  |  |  | 515 |  |  | 495 |  |
| Total revenue |  |  |  |  | $ | 32,007 |  |  | $ | 22,181 |  |

[0001628280-25-026845:notes:124]
Commissions

[0001628280-25-026845:notes:125]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $12.8 million and $13.0 million as of March 31, 2025 and December 31, 2024, respectively. During the three months ended March 31, 2025 and 2024, the Company recognized commission expense of $1.5 million and $1.3 million (as restated), respectively.

[0001628280-25-026845:notes:126]
Leases

[0001628280-25-026845:notes:127]
As of March 31, 2025, future minimum noncancelable payments related to leases of the Company's equipment are as follows (in thousands):

[0001628280-25-026845:notes:128]
| Year Ending December 31: |  |
| 2025 (nine months remaining) | $ | 58,776 |  |
| 2026 | 67,180 |  |
| 2027 | 45,766 |  |
| 2028 | 20,471 |  |
| 2029 | 2,328 |  |
| Thereafter | 7 |  |
|  | $ | 194,528 |  |


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001628280-25-026845:notes:129]
[same as prior period, unchanged from 0001628280-25-020353:notes:149]

[0001628280-25-026845:notes:130]
[same as prior period, unchanged from 0001628280-25-020353:notes:150]

[0001628280-25-026845:notes:131]
|  | Allowance for Expected Credit Losses |
| Balance at December 31, 2024 | $ | (734) |  |
| Provisions | (41) |  |
| Write-offs, net of recoveries | — |  |
| Balance at March 31, 2025 | $ | (775) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001628280-25-026845:notes:132]
[same as prior period, unchanged from 0001628280-25-020353:notes:152]

[0001628280-25-026845:notes:133]
|  | March 31,2025 |  | December 31,2024 |
| Raw materials | $ | 3,811 |  |  | $ | 4,362 |  |
| Finished goods |  |  |  |
| Finished goods inventory | 6,071 |  |  | 12,153 |  |
| Uninstalled inventory | 174 |  |  | 448 |  |
| Total | $ | 10,056 |  |  | $ | 16,963 |  |

[0001628280-25-026845:notes:134]
As discussed in Note 2, Restatement of Previously Issued Condensed Consolidated Financial Statements, the Company offers products for purchase or multi-year subscription leases. For equipment for which the revenue recognition start date was moved to a later date due to the timing of the transfer of control, the equipment cost was added back to finished goods inventory (for equipment sales) until the point in time that the Company transferred control of the equipment to the customer, corresponding to the revenue recognition start date. Amounts added back to finished goods inventory are included in Uninstalled inventory in the table above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-25-026845:notes:135]
[same as prior period, unchanged from 0001628280-25-020353:notes:155]

[0001628280-25-026845:notes:136]
|  | March 31,2025 |  | December 31,2024 |
| Computers and telecom equipment | $ | 2,012 |  |  | $ | 2,064 |  |
| Lab equipment | 5,474 |  |  | 5,564 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 607 |  |  | 607 |  |
| Leased equipment | 118,975 |  |  | 112,078 |  |
| Capitalized software | 16,291 |  |  | 14,555 |  |
| Sales demo equipment | 3,394 |  |  | 3,649 |  |
| Vehicles | 604 |  |  | 604 |  |
| Equipment held for lease1 | 19,800 |  |  | 17,347 |  |
| Construction in progress | 802 |  |  | 477 |  |
|  | 168,070 |  |  | 157,056 |  |
| Less: Accumulated depreciation and amortization | (38,389) |  |  | (33,395) |  |
|  | $ | 129,681 |  |  | $ | 123,661 |  |

[0001628280-25-026845:notes:137]
[same as prior period, unchanged from 0001628280-25-020353:notes:157]

[0001628280-25-026845:notes:138]
As of March 31, 2025 and December 31, 2024, the net book value of capitalized software was $12.0 million and $11.1 million, respectively. These amounts include $1.9 million and $1.7 million of capitalized stock compensation costs, respectively. Depreciation and amortization expense related to property and equipment was $5.5 million and $3.5 million for the three months ended March 31, 2025 and 2024, respectively, which included amortization expense of capitalized software of $0.8 million and $0.3 million for the three months ended March 31, 2025 and 2024, respectively.

[0001628280-25-026845:notes:139]
[same as prior period, unchanged from 0001628280-25-020353:notes:159]

[0001628280-25-026845:notes:140]
|  | March 31,2025 |  | December 31,2024 |
| Leased equipment | $ | 118,975 |  |  | $ | 112,078 |  |
| Accumulated depreciation | (29,554) |  |  | (25,726) |  |
| Leased equipment, net | $ | 89,421 |  |  | $ | 86,352 |  |

[0001628280-25-026845:notes:141]
Depreciation expense related to leased units was $4.1 million and $2.8 million (as restated) during the three months ended March 31, 2025 and 2024, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.

[0001628280-25-026845:notes:142]
The Company recorded losses of $0.3 million from disposals of property and equipment during the three months ended March 31, 2025 primarily related to the disposal of leased Evolv Express units, which were recorded in cost of product revenue.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-25-026845:notes:143]
[same as prior period, unchanged from 0001628280-25-020353:notes:164]

[0001628280-25-026845:notes:144]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the three months ended March 31, 2024. No option grants were issued during the three months ended  March 31, 2025.

[0001628280-25-026845:notes:145]
|  |  |  | Three Months Ended March 31, |
|  |  |  | 2024 |
| Risk-free interest rate |  |  | 4.1% |
| Expected term (in years) |  |  | 6.1 |
| Expected volatility |  |  | 90.0% |
| Expected dividend yield |  |  | 0.0% |

[0001628280-25-026845:notes:146]
The following table summarizes the Company’s stock option activity since December 31, 2024 (in thousands, except for share and per share data):

[0001628280-25-026845:notes:147]
|  | Number ofShares |  | WeightedAverageExercise Price |
| Outstanding as of December 31, 2024 | 18,125,937 |  | $ | 1.18 |  |
| Granted | — |  |  | — |  |
| Exercised | (320,211) |  | 0.44 |  |
| Forfeited | (370,397) |  |  | 3.61 |  |
| Expired | — |  |  | — |  |
| Outstanding as of March 31, 2025 | 17,435,329 |  | $ | 1.14 |  |

[0001628280-25-026845:notes:148]
[same as prior period, unchanged from 0001628280-25-020353:notes:169]

[0001628280-25-026845:notes:149]
The following table summarizes the Company's restricted stock units activity since December 31, 2024:

[0001628280-25-026845:notes:150]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2024 | 12,115,657 |  |  | $ | 3.50 |  |
| Granted | 6,307,594 |  |  | 3.38 |  |
| Vested | (3,389,364) |  |  | 3.45 |  |
| Forfeited | (2,320,000) |  |  | 3.87 |  |
| Nonvested as of March 31, 2025 | 12,713,887 |  |  | $ | 3.39 |  |

[0001628280-25-026845:notes:151]
During the three months ended March 31, 2025, the Company granted MSUs for which the vesting conditions consist solely of market-based vesting conditions, determined by the Company's level of achievement of pre-established parameters relating to the performance of the Company's stock price as set by the Board. Vesting may range from 0% to

[0001628280-25-026845:notes:152]
200% of the target MSUs granted, based on the achievement of specified market conditions. The awards will be measured at each anniversary of the grant date and will ultimately vest at the end of a three-year period performance period.

[0001628280-25-026845:notes:153]
Compensation expense for MSUs is based on the estimated value of the awards on the grant date, and is recognized over the period from the grant date through the expected vest date. The fair value of the awards were estimated based on a Monte Carlo simulation model applying the following key assumptions, on a weighted average basis:

[0001628280-25-026845:notes:154]
|  | Three Months Ended March 31, |
|  | 2025 |  |  |
| Risk-free interest rate | 4.0% |  |  |
| Expected term (in years) | 3.0 |  |  |
| Expected volatility | 91.7% |  |  |
| Expected dividend yield | 0.0% |  |  |

[0001628280-25-026845:notes:155]
The following table summarizes the Company's market-based stock units activity since December 31, 2024:

[0001628280-25-026845:notes:156]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2024 | — |  |  | $ | — |  |
| Granted | 1,456,225 |  |  | 4.99 |  |
| Vested | — |  |  | — |  |
| Forfeited | — |  |  | — |  |
| Nonvested as of March 31, 2025 | 1,456,225 |  |  | $ | 4.99 |  |

[0001628280-25-026845:notes:157]
[same as prior period, unchanged from 0001628280-25-020353:notes:175]

[0001628280-25-026845:notes:158]
[same as prior period, unchanged from 0001628280-25-020353:notes:176]

[0001628280-25-026845:notes:159]
As of March 31, 2025, 117,423 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $0.3 million, and there were no Finback Common Stock Warrants that were unvested, given the expiration of the 1-year tail period on January 1, 2024. The Company recognized compensation expense for the Finback Common Stock Warrants when the warrants vested based on meeting the specified sales criteria. During the three months ended March 31,

[0001628280-25-026845:notes:160]
2025 and 2024, there was no stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants.

[0001628280-25-026845:notes:161]
[same as prior period, unchanged from 0001628280-25-020353:notes:179]

[0001628280-25-026845:notes:162]
[same as prior period, unchanged from 0001628280-25-020353:notes:180]

[0001628280-25-026845:notes:163]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Cost of revenue |  |  |  |  | $ | 219 |  | $ | 138 |
| Research and development |  |  |  |  | 1,115 |  | 902 |
| Sales and marketing |  |  |  |  | 1,048 |  | 2,959 |
| General and administrative |  |  |  |  | 1,972 |  | 2,431 |
| Restructuring costs |  |  |  |  | $ | 525 |  | $ | — |
| Total stock-based compensation expense |  |  |  |  | $ | 4,879 |  | $ | 6,430 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-026845:notes:164]
Income Taxes
The provision for income taxes for the three months ended March 31, 2025 and 2024 was immaterial. The Company continues to maintain a full valuation allowance against its deferred tax assets, as it is not more likely than not that these assets will be realized.

[0001628280-25-026845:notes:165]
The Company’s tax provision and resulting effective tax rate for interim periods are determined using the estimated annual effective tax rate (“AETR”), which is updated each quarter and adjusted for discrete items recognized in the period. The AETR is based on the forecasted full-year pre-tax income and anticipated tax expense. Variability in the effective tax rate between quarters may result from differences between actual and projected earnings or losses, as well as the timing and nature of discrete items. If the estimated AETR changes during a quarter, the Company records a cumulative adjustment to the tax provision in that period.

[0001628280-25-026845:notes:166]
The Company's income tax provision reflects an estimate of federal, state, and foreign income taxes based on enacted tax rates in the jurisdictions in which we operate. The provision is adjusted for the impact of allowable tax credits and deductions, uncertain tax positions, changes in deferred tax assets and liabilities, and changes in tax law. The Company has historically incurred net operating losses.


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-026845:notes:167]
Net Loss per Share
Basic and diluted net loss per share attributable to common stockholders are calculated as follows (in thousands, except share and per share amounts):

[0001628280-25-026845:notes:168]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Numerator: |  |  |  |  |  |  |  |
| Net loss attributable to common stockholders – basic and diluted |  |  |  |  | $ | (1,689) |  | $ | (11,272) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted |  |  |  |  | 160,808,391 |  |  | 153,076,719 |  |
| Net loss per share attributable to common stockholders – basic and diluted |  |  |  |  | $ | (0.01) |  |  | $ | (0.07) |  |

[0001628280-25-026845:notes:169]
[same as prior period, unchanged from 0001628280-25-020353:notes:188]

[0001628280-25-026845:notes:170]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
| Options issued and outstanding |  |  |  |  | 17,435,329 |  | 22,522,005 |  |
| Public Warrants to purchase common stock |  |  |  |  | 14,324,893 |  |  | 14,324,893 |  |
| Warrants to purchase common stock (Finback) |  |  |  |  | 117,423 |  |  | 117,423 |  |
| Unvested restricted stock units |  |  |  |  | 12,713,887 |  |  | 16,460,035 |  |
| Unvested market-based stock units* |  |  |  |  | 1,456,225 |  |  | — |  |
| Earn-out shares* |  |  |  |  | 15,000,000 |  |  | 15,000,000 |  |
| Contingently issuable common stock* |  |  |  |  | 1,897,500 |  |  | 1,897,500 |  |
|  |  |  |  |  | 62,945,257 |  |  | 70,321,856 |  |

[0001628280-25-026845:notes:171]
*Issuance of Market-based stock units, Earn-out shares and Contingently issuable common stock is contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-25-026845:notes:172]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. While the partnership agreement is still in effect, effective in the fourth quarter of 2024, Motorola is no longer considered a related party. During the three months ended March 31, 2024, revenue from Motorola's distributor services was $1.9 million.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-25-026845:notes:173]
Commitments and Contingencies
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. Below is a summary of the various types of matters subject to this guidance.

[0001628280-25-026845:notes:174]
Indemnification Agreements

[0001628280-25-026845:notes:175]
In the ordinary course of business, the Company provides indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. Based on historical experience and evaluation of the agreements, we do not believe that any payments related to our indemnities will have a material impact on our financial condition or results of operations.

[0001628280-25-026845:notes:176]
Legal Proceedings

[0001628280-25-026845:notes:177]
We are from time to time subject to various claims, lawsuits, government and regulatory examinations, inquiries, information requests and investigations, and other legal and administrative proceedings arising in the ordinary course of business. The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. Except for the regulatory matters discussed below, based upon information presently known to management, the Company has not accrued a loss for any other legal matters, as a loss is not probable and reasonably estimable. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

[0001628280-25-026845:notes:178]
General Litigation

[0001628280-25-026845:notes:179]
On March 25, 2024, a putative class action lawsuit was filed against the Company in the United States District Court for the District of Massachusetts (the “Class Action”). The Class Action is a consolidation of two lawsuits, the second of which was filed on November 1, 2024, filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees.

[0001628280-25-026845:notes:180]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the anticipated motion to dismiss in the Class Action. On March 28, 2025, the Company filed a motion to dismiss the claims.

[0001628280-25-026845:notes:181]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Delaware Derivative Action”). The Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. The Delaware Derivative Action is stayed pending the outcome of the anticipated motion to dismiss in the Class Action.

[0001628280-25-026845:notes:182]
The Company expects to incur legal and professional services expenses associated with this litigation in future periods. The Company will recognize these expenses as services are received. While a loss from this litigation is reasonably possible, we cannot reasonably estimate a range of possible losses at this time, as the proceedings remain in the early stages, alleged damages have not been specified, there is uncertainty as to the outcome of our anticipated motion to dismiss in the Class Action which was filed on March 28, 2025, there is uncertainty as to the likelihood of the proposed class in the Class Action being certified or the ultimate size of any class if certified, there is uncertainty as to the final complaint in the Massachusetts Derivative Action, as the plaintiff will not identify an operative complaint or file a consolidated complaint until disposition of our anticipated motion to dismiss in the Class Action, and there are significant factual and legal issues to be resolved in both the securities and derivative actions. For these reasons, the Company has not recorded a loss contingency liability for the above litigation as of March 31, 2025.

[0001628280-25-026845:notes:183]
Regulatory and Governmental Matters

[0001628280-25-026845:notes:184]
As previously disclosed, on October 12, 2023, the Company announced that the U.S. Federal Trade Commission (the “FTC”) had requested information about certain aspects of its marketing practices. The Company reached a settlement with the FTC and on December 5, 2024, a Stipulated Order for Permanent Injunction and Other Relief (the “Order”) was entered in the United States District Court for the District of Massachusetts Eastern Division. The Order (i) required that the Company permit a limited cohort of school customers to cancel their contracts, (ii) required that the Company take certain compliance actions and meet record keeping obligations, and (iii) enjoined the Company from making misleading or unsubstantiated marketing claims. The Order did not include any monetary relief. The period during which eligible customers may cancel closed on March 30, 2025. Any inability to adequately comply with the terms of the Order could result in enforcement actions or penalties imposed by the FTC.

[0001628280-25-026845:notes:185]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, 5 customers representing 24 Evolv Express units elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the year ended December 31, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three months ended March 31, 2025, as revenue will continue to be recognized on these deals through the cancellation dates of each contract, all of which are in June 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of the effective date of the Order were impacted by the cancellations, which has been excluded from the remaining performance obligations disclosed in Note 6 Revenue Recognition.

[0001628280-25-026845:notes:186]
As previously disclosed, in February 2024, the Company received a subpoena from the Division of Enforcement of the Securities and Exchange Commission (the “SEC”), requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation.

[0001628280-25-026845:notes:187]
As previously reported, the Company self-reported to the Division of Enforcement of the SEC the Investigation. The Company has since received requests for documents and information from the SEC relating to this matter. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("DOJ") relating to these same issues, and has since received additional requests for documents and information relating to this matter. The Company is cooperating with these investigations.

[0001628280-25-026845:notes:188]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of legal and regulatory matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.

[0001628280-25-026845:notes:189]
Any resolution or litigation with the SEC, DOJ, or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to SEC or DOJ matters. The Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matters, including certain expenses that have previously been paid, are expected to be reimbursed. As of March 31, 2025, the Company recognized an estimated loss recovery related to insurance coverage for these matters of $3.9 million, which was recorded in general and administrative expense in the condensed consolidated statements of

[0001628280-25-026845:notes:190]
operations and comprehensive loss and a related asset in prepaid and other current assets in the condensed consolidated balance sheets. This amount reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company expects realization of the claim for recovery is probable. As it relates to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement  action or litigation, which is necessarily uncertain.

[0001628280-25-026845:notes:191]
Contract manufacturers

[0001628280-25-026845:notes:192]
The Company generally contracts with its contract manufacturer, Columbia Tech, on a cancellable, purchase-order basis. The Company has a contract in the normal course of business with Columbia Tech to provide manufacturing services for the Company's equipment sold or leased to customers. While these contracts are cancellable by the Company upon prior notice, payments due upon cancellation consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. These payments are not determinable, but could result in a material purchase commitment if the Company were to cancel their open purchase orders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-25-026845:notes:193]
Segment Information
The Company determined that it has one operating and reporting segment after considering the Company’s organizational structure and the information regularly reviewed and evaluated by the Company’s CODM in deciding how to allocate resources and assess performance. The Company has determined that its CODM is its President and Chief Executive Officer. The CODM evaluates the performance of our segment based upon consolidated net income and considers budget-to-actual or forecast-to-actual variances to assess performance and make decisions about allocating resources. The CODM evaluates segment assets based on total assets on the condensed consolidated balance sheets. Asset information is not presented here because its presentation here would be duplicative of the condensed consolidated balance sheets. On the basis of these factors, the Company determined that it operates and manages its business as one operating and reporting segment, that develops, manufactures, markets and sells security screening products and specific services, and accordingly has one reportable segment for financial reporting purposes.

[0001628280-25-026845:notes:194]
Information by reportable segment is as follows (in thousands):

[0001628280-25-026845:notes:195]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (As Restated) |
| Segment revenue |  |  |  |  | $ | 32,007 |  |  | $ | 22,181 |  |
| Less: |  |  |  |  |  |  |  |
| Employee expense |  |  |  |  | 16,369 |  |  | 17,841 |  |
| Travel and expense |  |  |  |  | 791 |  |  | 1,514 |  |
| Capitalized R&D expense |  |  |  |  | (1,489) |  |  | (1,454) |  |
| Stock-based compensation expense1 |  |  |  |  | 4,354 |  |  | 6,430 |  |
| Other non-recurring expenses2 |  |  |  |  | 3,561 |  |  | 1,680 |  |
| Consulting and contract staffing |  |  |  |  | 3,277 |  |  | 3,316 |  |
| Software subscriptions |  |  |  |  | 1,535 |  |  | 1,458 |  |
| Depreciation and amortization |  |  |  |  | 5,529 |  |  | 3,457 |  |
| Restructuring costs |  |  |  |  | 2,662 |  |  | — |  |
| Other cost of revenue |  |  |  |  | 5,441 |  |  | 4,013 |  |
| Other operating expenses |  |  |  |  | 4,366 |  |  | 5,832 |  |
| Other segment items3 |  |  |  |  | (12,763) |  |  | (10,634) |  |
| Provision for income taxes |  |  |  |  | 63 |  |  | — |  |
| Segment net loss |  |  |  |  | $ | (1,689) |  |  | $ | (11,272) |  |

[0001628280-25-026845:notes:196]
1 Excludes incremental expense related to modified awards included in the Restructuring costs line. See Note 16 for additional information.

[0001628280-25-026845:notes:197]
2 For the three months ended March 31, 2025, includes consulting and legal fees related to the Investigation (as defined in Note 2) and related matters, additional audit fees incurred in connection with the restatement of prior period financial statements, net of estimated insurance recoveries. For the three months ended March 31, 2024, includes costs associated with adverse non-cancellable inventory purchase commitments and severance expense.

[0001628280-25-026845:notes:198]
3 Refer to Total other income, net in the condensed consolidated statements of operations and comprehensive loss.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-25-026845:notes:199]
Restructuring Charges
In January 2025, the Company implemented a Board-approved reduction in force affecting 41 members of its workforce. This action is part of the Company’s initiative to increase its profitability and cash flow as the Company seeks further flexibility to pursue its investment strategy with certain growth opportunities.

[0001628280-25-026845:notes:200]
The Company incurred charges of $2.7 million for the reduction in force during the three months ended March 31, 2025. These charges consisted of termination charges arising from severance obligations of approximately $2.0 million, extended eligibility for the vesting of certain equity awards originally scheduled to vest on or before March 1, 2025, resulting in incremental non-cash expense of $0.5 million, and other customary employee benefit payments in connection with a reduction in force of $0.2 million. All of these restructuring costs are reported within restructuring costs in our condensed consolidated statements of operations and comprehensive loss.

[0001628280-25-026845:notes:201]
All actions related to the reduction in force were completed by March 31, 2025, with the exception of payouts of severance obligations to certain employees who are subject to continuous payment through November 2025 under the Company's Severance And Change In Control Plan. The following table summarizes the liabilities recognized in relation to the cash obligations from reduction in force, which are included in accrued expenses and other current liabilities in our condensed consolidated balance sheets (in thousands):

[0001628280-25-026845:notes:202]
| Balance at December 31, 2024 | $ | — |  |
| Charges incurred | 2,137 |  |
| Cash payments | (1,471) |  |
| Balance at March 31, 2025 | $ | 666 |  |


## us-gaap:SubsequentEventsTextBlock

[0001628280-25-026845:notes:203]
Subsequent Events
Appointment of Chief Financial Officer

[0001628280-25-026845:notes:204]
On April 29, 2025, the Company appointed a new executive officer. In connection with this appointment, on May 1, 2025, the Board granted the officer (i) market-based restricted stock units with an aggregate grant date fair market value of $1,750,000, which will vest based on the achievement of certain Company stock price performance goals, as described in Note 3, Summary of Significant Accounting Policies and Estimates, and (ii) restricted stock units with an aggregate grant date fair market value of $1,750,000, which will vest based on the executive's continued service with the Company in three equal annual installments, pursuant to the Company’s 2021 Incentive Award Plan.
