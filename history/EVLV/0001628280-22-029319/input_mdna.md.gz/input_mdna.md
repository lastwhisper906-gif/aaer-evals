# EVLV MD&A — 0001628280-22-029319


## mdna

[0001628280-22-029319:mdna:1]
[same as prior period, unchanged from 0001628280-22-023253:mdna:1]

[0001628280-22-029319:mdna:2]
[same as prior period, unchanged from 0001628280-22-023253:mdna:2]

[0001628280-22-029319:mdna:3]
[same as prior period, unchanged from 0001628280-22-023253:mdna:3]

[0001628280-22-029319:mdna:4]
[same as prior period, unchanged from 0001628280-22-023253:mdna:4]

[0001628280-22-029319:mdna:5]
[same as prior period, unchanged from 0001628280-22-023253:mdna:5]

[0001628280-22-029319:mdna:6]
[same as prior period, unchanged from 0001628280-22-023253:mdna:6]

[0001628280-22-029319:mdna:7]
Our products have screened over 425 million visitors worldwide since our inception. We believe that we have screened more people through advanced systems than any organization other than the United States Transportation Security Administration (“TSA”). Our customers include many iconic venues across a wide variety of industries, including major sports stadiums and arenas, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, large industrial workplaces, schools in large districts, and prominent houses of worship. We offer our products for lease or purchase, and utilize a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue, and creates expansion and upsell opportunities.

[0001628280-22-029319:mdna:8]
[same as prior period, unchanged from 0001628280-22-023253:mdna:8]

[0001628280-22-029319:mdna:9]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $16.5 million and $8.4 million for the three months ended September 30, 2022 and 2021, respectively. We generated net income (loss) of $(18.6) million and $20.8 million for the

[0001628280-22-029319:mdna:10]
1

[0001628280-22-029319:mdna:11]
three months ended September 30, 2022 and 2021, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-22-029319:mdna:12]
[same as prior period, unchanged from 0001628280-22-023253:mdna:11]

[0001628280-22-029319:mdna:13]
[same as prior period, unchanged from 0001628280-22-023253:mdna:12]

[0001628280-22-029319:mdna:14]
[same as prior period, unchanged from 0001628280-22-023253:mdna:13]

[0001628280-22-029319:mdna:15]
[same as prior period, unchanged from 0001628280-22-023253:mdna:14]

[0001628280-22-029319:mdna:16]
[same as prior period, unchanged from 0001628280-22-023253:mdna:15]

[0001628280-22-029319:mdna:17]
Additional information regarding the Merger Agreement appears in Note 3 of our condensed consolidated financial statements for the three and nine months ended September 30, 2022.

[0001628280-22-029319:mdna:18]
[same as prior period, unchanged from 0001628280-22-023253:mdna:17]

[0001628280-22-029319:mdna:19]
We have taken, and will continue to take, actions to mitigate the impact of the COVID-19 pandemic on our cash flow and results of operations and financial condition. While we have experienced supply chain challenges during the three and nine months ended September 30, 2022, we have taken steps to prioritize product availability and diversify our supply partners. In the long-term, we believe that the COVID-19 pandemic may encourage organizations to continue to reassess their security screening processes and may continue to accelerate their adoption of solutions such as touchless security screening, which could create additional demand for our products.

[0001628280-22-029319:mdna:20]
Additional information regarding COVID-19 risks appear in the “Risk Factors” section of our 2021 Form 10-K.

[0001628280-22-029319:mdna:21]
[same as prior period, unchanged from 0001628280-22-023253:mdna:20]

[0001628280-22-029319:mdna:22]
We believe that our performance and future success depend on many factors that present significant opportunities for us but also pose risks and challenges, including those discussed below and in the "Risk Factors" section of our 2021 Form 10-K, as updated by the "Risk Factors" section in this Quarterly Report on Form 10-Q. We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of rising inflation rates on business spending; supply chain issues and the impacts on our manufacturing capabilities; the continued effects of the COVID-19 pandemic and other public health emergencies; the military conflict between Russia and Ukraine and related geopolitical impacts; and a possible economic recession. While these factors

[0001628280-22-029319:mdna:23]
continue to evolve, we plan to remain flexible and to optimize our business as appropriate and allocate resources as necessary.

[0001628280-22-029319:mdna:24]
[same as prior period, unchanged from 0001628280-22-023253:mdna:22]

[0001628280-22-029319:mdna:25]
We believe the world will continue to focus on the safety and security of people in the places where they gather. Many of these locations, such as professional sports venues, educational institutions, and healthcare facilities, are moving toward a more frictionless security screening experience. We believe that we are well-positioned to take advantage of this opportunity due to our proprietary technologies and global distribution capabilities. Our products are designed to empower venues and facilities to realize the full benefits of touchless security screening, including a rapid visitor throughput and minimal security staff to screened visitor physical contact. We expect that our results of operations, including revenue, will fluctuate for the foreseeable future as venues and facilities continue to shift away from conventional security screening processes towards touchless security screening or consider security screening processes for the first time. The degree to which potential and current customers recognize these benefits and invest in our products will affect our financial results.

[0001628280-22-029319:mdna:26]
[same as prior period, unchanged from 0001628280-22-023253:mdna:24]

[0001628280-22-029319:mdna:27]
Revenue generated by the sale of products represented 60% and 64% of our total revenue for the three months ended September 30, 2022 and 2021, respectively. The remaining revenue was generated from subscription sales and services for our products. Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions, primarily within the United States. With the further recent development, enhancement, and maintenance of our analytics platform, which we refer to as Evolv Insights, as well as our plan to lead increasingly with our subscription offering, we expect subscription revenue as a percentage of total revenue to increase in future periods.

[0001628280-22-029319:mdna:28]
Pricing may also vary by region due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales, bookings, and business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products to our customers.

[0001628280-22-029319:mdna:29]
[same as prior period, unchanged from 0001628280-22-023253:mdna:27]

[0001628280-22-029319:mdna:30]
[same as prior period, unchanged from 0001628280-22-023253:mdna:28]

[0001628280-22-029319:mdna:31]
[same as prior period, unchanged from 0001628280-22-023253:mdna:29]

[0001628280-22-029319:mdna:32]
[same as prior period, unchanged from 0001628280-22-023253:mdna:30]

[0001628280-22-029319:mdna:33]
[same as prior period, unchanged from 0001628280-22-023253:mdna:31]

[0001628280-22-029319:mdna:34]
[same as prior period, unchanged from 0001628280-22-023253:mdna:32]

[0001628280-22-029319:mdna:35]
[same as prior period, unchanged from 0001628280-22-023253:mdna:33]

[0001628280-22-029319:mdna:36]
[same as prior period, unchanged from 0001628280-22-023253:mdna:34]

[0001628280-22-029319:mdna:37]
[same as prior period, unchanged from 0001628280-22-023253:mdna:35]

[0001628280-22-029319:mdna:38]
[same as prior period, unchanged from 0001628280-22-023253:mdna:36]

[0001628280-22-029319:mdna:39]
[same as prior period, unchanged from 0001628280-22-023253:mdna:37]

[0001628280-22-029319:mdna:40]
[same as prior period, unchanged from 0001628280-22-023253:mdna:38]

[0001628280-22-029319:mdna:41]
[same as prior period, unchanged from 0001628280-22-023253:mdna:39]

[0001628280-22-029319:mdna:42]
[same as prior period, unchanged from 0001628280-22-023253:mdna:40]

[0001628280-22-029319:mdna:43]
We derive a portion of our revenue from the sale of our Express equipment (and prior to 2022, our Edge equipment) and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We expect product revenue to decline as a percentage of our overall revenue overtime as more and more customers enter full subscription transactions with us and as our subscription becomes more valuable to our business.

[0001628280-22-029319:mdna:44]
[same as prior period, unchanged from 0001628280-22-023253:mdna:42]

[0001628280-22-029319:mdna:45]
Subscription revenue is comprised of revenue derived from leasing Express and Edge units to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as they do not meet any of the sales-type lease criteria per ASC 842 and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001628280-22-029319:mdna:46]
[same as prior period, unchanged from 0001628280-22-023253:mdna:44]

[0001628280-22-029319:mdna:47]
[same as prior period, unchanged from 0001628280-22-023253:mdna:45]

[0001628280-22-029319:mdna:48]
[same as prior period, unchanged from 0001628280-22-023253:mdna:46]

[0001628280-22-029319:mdna:49]
4

[0001628280-22-029319:mdna:50]
[same as prior period, unchanged from 0001628280-22-023253:mdna:47]

[0001628280-22-029319:mdna:51]
[same as prior period, unchanged from 0001628280-22-023253:mdna:48]

[0001628280-22-029319:mdna:52]
[same as prior period, unchanged from 0001628280-22-023253:mdna:49]

[0001628280-22-029319:mdna:53]
[same as prior period, unchanged from 0001628280-22-023253:mdna:50]

[0001628280-22-029319:mdna:54]
[same as prior period, unchanged from 0001628280-22-023253:mdna:51]

[0001628280-22-029319:mdna:55]
[same as prior period, unchanged from 0001628280-22-023253:mdna:52]

[0001628280-22-029319:mdna:56]
[same as prior period, unchanged from 0001628280-22-023253:mdna:53]

[0001628280-22-029319:mdna:57]
[same as prior period, unchanged from 0001628280-22-023253:mdna:54]

[0001628280-22-029319:mdna:58]
A provision for the estimated cost related to warranty is recognized as necessary. Our estimate of costs to service the warranty obligations is based on historical experience and expectations of future conditions. As of September 30, 2022, the warranty accrual was less than $0.1 million.

[0001628280-22-029319:mdna:59]
[same as prior period, unchanged from 0001628280-22-023253:mdna:56]

[0001628280-22-029319:mdna:60]
[same as prior period, unchanged from 0001628280-22-023253:mdna:57]

[0001628280-22-029319:mdna:61]
[same as prior period, unchanged from 0001628280-22-023253:mdna:58]

[0001628280-22-029319:mdna:62]
[same as prior period, unchanged from 0001628280-22-023253:mdna:59]

[0001628280-22-029319:mdna:63]
[same as prior period, unchanged from 0001628280-22-023253:mdna:60]

[0001628280-22-029319:mdna:64]
[same as prior period, unchanged from 0001628280-22-023253:mdna:61]

[0001628280-22-029319:mdna:65]
[same as prior period, unchanged from 0001628280-22-023253:mdna:62]

[0001628280-22-029319:mdna:66]
[same as prior period, unchanged from 0001628280-22-023253:mdna:63]

[0001628280-22-029319:mdna:67]
[same as prior period, unchanged from 0001628280-22-023253:mdna:64]

[0001628280-22-029319:mdna:68]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, stock-based compensation, prototypes, design expenses, and consulting and contractor costs. We expect research and development costs will increase on an absolute dollar basis for the year ended December 31, 2022 compared to the year ended December 31, 2021 as we continue to invest in advancing our portfolio of security screening products.

[0001628280-22-029319:mdna:69]
[same as prior period, unchanged from 0001628280-22-023253:mdna:66]

[0001628280-22-029319:mdna:70]
[same as prior period, unchanged from 0001628280-22-023253:mdna:67]

[0001628280-22-029319:mdna:71]
[same as prior period, unchanged from 0001628280-22-023253:mdna:68]

[0001628280-22-029319:mdna:72]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and sales tax contingencies. We expect our general and administrative expenses will increase on an absolute dollar basis for the year ended December 31, 2022 compared to the year ended December 31, 2021 as a result of operating as a public company, including expenses necessary to comply with the rules and regulations applicable to companies listed on a national securities exchange and related to compliance and reporting obligations pursuant to the rules and regulations of the SEC, as well as increased expenses for general and director and officer insurance, and other administrative and professional services. In addition, we expect to incur additional costs as we hire additional personnel and enhance our infrastructure to support the anticipated growth of the business.

[0001628280-22-029319:mdna:73]
[same as prior period, unchanged from 0001628280-22-023253:mdna:70]

[0001628280-22-029319:mdna:74]
Impairment of property and equipment relates to Edge units and Express prototype units that are removed from service and retired as we transition our domestic customers to our most current Express units.

[0001628280-22-029319:mdna:75]
[same as prior period, unchanged from 0001628280-22-023253:mdna:72]

[0001628280-22-029319:mdna:76]
[same as prior period, unchanged from 0001628280-22-023253:mdna:73]

[0001628280-22-029319:mdna:77]
[same as prior period, unchanged from 0001628280-22-023253:mdna:74]

[0001628280-22-029319:mdna:78]
[same as prior period, unchanged from 0001628280-22-023253:mdna:75]

[0001628280-22-029319:mdna:79]
[same as prior period, unchanged from 0001628280-22-023253:mdna:76]

[0001628280-22-029319:mdna:80]
[same as prior period, unchanged from 0001628280-22-023253:mdna:77]

[0001628280-22-029319:mdna:81]
In January and February 2021, we entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability and included in long-term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the

[0001628280-22-029319:mdna:82]
stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method.

[0001628280-22-029319:mdna:83]
[same as prior period, unchanged from 0001628280-22-023253:mdna:80]

[0001628280-22-029319:mdna:84]
[same as prior period, unchanged from 0001628280-22-023253:mdna:81]

[0001628280-22-029319:mdna:85]
[same as prior period, unchanged from 0001628280-22-023253:mdna:82]

[0001628280-22-029319:mdna:86]
[same as prior period, unchanged from 0001628280-22-023253:mdna:83]

[0001628280-22-029319:mdna:87]
[same as prior period, unchanged from 0001628280-22-023253:mdna:84]

[0001628280-22-029319:mdna:88]
[same as prior period, unchanged from 0001628280-22-023253:mdna:85]

[0001628280-22-029319:mdna:89]
[same as prior period, unchanged from 0001628280-22-023253:mdna:86]

[0001628280-22-029319:mdna:90]
[same as prior period, unchanged from 0001628280-22-023253:mdna:87]

[0001628280-22-029319:mdna:91]
[same as prior period, unchanged from 0001628280-22-023253:mdna:88]

[0001628280-22-029319:mdna:92]
[same as prior period, unchanged from 0001628280-22-023253:mdna:89]

[0001628280-22-029319:mdna:93]
[same as prior period, unchanged from 0001628280-22-023253:mdna:90]

[0001628280-22-029319:mdna:94]
Our income tax provision consists of an estimate for U.S. federal and state income taxes based on enacted rates, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. There is no provision for income taxes for the three and nine months ended September 30, 2022 and 2021

[0001628280-22-029319:mdna:95]
because we have historically incurred net operating losses and maintain a full valuation allowance against its deferred tax assets.

[0001628280-22-029319:mdna:96]
[same as prior period, unchanged from 0001628280-22-023253:mdna:93]

[0001628280-22-029319:mdna:97]
Comparison of the Three Months Ended September 30, 2022 and 2021

[0001628280-22-029319:mdna:98]
The following table summarizes our results of operations for the three months ended September 30, 2022 and 2021, (in thousands):

[0001628280-22-029319:mdna:99]
|  | Three Months EndedSeptember 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 9,839 |  |  | $ | 5,395 |  |  | $ | 4,444 |  |  | 82 | % |
| Subscription revenue | 5,198 |  |  | 2,312 |  |  | 2,886 |  |  | 125 |  |
| Service revenue | 1,493 |  |  | 717 |  |  | 776 |  |  | 108 |  |
| Total revenue | 16,530 |  |  | 8,424 |  |  | 8,106 |  |  | 96 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 12,960 |  |  | 2,967 |  |  | 9,993 |  |  | 337 |  |
| Cost of subscription revenue | 2,207 |  |  | 1,277 |  |  | 930 |  |  | 73 |  |
| Cost of service revenue | 1,138 |  |  | 713 |  |  | 425 |  |  | 60 |  |
| Total cost of revenue | 16,305 |  |  | 4,957 |  |  | 11,348 |  |  | 229 |  |
| Gross profit | 225 |  |  | 3,467 |  |  | (3,242) |  |  | (94) |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,616 |  |  | 3,612 |  |  | 2,004 |  |  | 55 |  |
| Sales and marketing | 11,746 |  |  | 10,024 |  |  | 1,722 |  |  | 17 |  |
| General and administrative | 8,839 |  |  | 7,535 |  |  | 1,304 |  |  | 17 |  |
| Loss from impairment of property and equipment | 626 |  |  | 1,656 |  |  | (1,030) |  |  | (62) |  |
| Total operating expenses | 26,827 |  |  | 22,827 |  |  | 4,000 |  |  | 18 |  |
| Loss from operations | (26,602) |  |  | (19,360) |  |  | (7,242) |  |  | 37 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (188) |  |  | (295) |  |  | 107 |  |  | (36) |  |
| Interest income | 1,052 |  |  | — |  |  | 1,052 |  |  | * |
| Other expense, net | (57) |  |  | (669) |  |  | 612 |  |  | (91) |  |
| Loss on extinguishment of debt | — |  |  | (865) |  |  | 865 |  |  | * |
| Change in fair value of derivative liability | — |  |  | 475 |  |  | (475) |  |  | * |
| Change in fair value of contingent earn-out liability | 7,245 |  |  | 32,609 |  |  | (25,364) |  |  | (78) |  |
| Change in fair value of contingently issuable common stock liability | 1,081 |  |  | 5,718 |  |  | (4,637) |  |  | (81) |  |
| Change in fair value of public warrant liability | (1,146) |  |  | 3,152 |  |  | (4,298) |  |  | (136) |  |
| Change in fair value of common stock warrant liability | — |  |  | 42 |  |  | (42) |  |  | * |
| Total other income (expense), net | 7,987 |  |  | 40,167 |  |  | (32,180) |  |  | (80) |  |
| Net income (loss) attributable to common stockholders – basic | $ | (18,615) |  |  | $ | 20,807 |  |  | $ | (39,422) |  |  | (189) | % |

[0001628280-22-029319:mdna:100]
[same as prior period, unchanged from 0001628280-22-023253:mdna:97]

[0001628280-22-029319:mdna:101]
[same as prior period, unchanged from 0001628280-22-023253:mdna:98]

[0001628280-22-029319:mdna:102]
[same as prior period, unchanged from 0001628280-22-023253:mdna:99]

[0001628280-22-029319:mdna:103]
[same as prior period, unchanged from 0001628280-22-023253:mdna:100]

[0001628280-22-029319:mdna:104]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Product revenue | $ | 9,839 |  |  | $ | 5,395 |  |  | $ | 4,444 |  |  | 82 | % |
| Cost of product revenue | $ | 12,960 |  |  | $ | 2,967 |  |  | $ | 9,993 |  |  | 337 | % |
| Gross profit - Product revenue | $ | (3,121) |  |  | $ | 2,428 |  |  | $ | (5,549) |  |  | (229) | % |
| Gross profit margin - Product revenue | (32) | % |  | 45 | % |  | N/A |  | (77) | % |

[0001628280-22-029319:mdna:105]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which include the significant increase in the adoption of Evolv Express units by schools, healthcare facilities, hotels, casinos, and professional sports arenas. We believe there are several key trends driving increased adoption of our solutions and growth in our product sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition of 92 new customers during the three months ended September 30, 2022 compared to 23 new customers during the three months ended September 30, 2021, (iii) the expansion of our customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-22-029319:mdna:106]
The decrease in gross profit and gross profit margin during the three months ended September 30, 2022 compared to the prior year period is attributable to several factors. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, and therefore a lower gross margin, during the three months ended September 30, 2022 compared to the prior year period. Gross profit and gross profit margin were also adversely impacted by marketing and sponsorship arrangements with certain customers, increases in shipping costs, and the costs associated with the write-off of scrap inventory incurred without corresponding revenue. We expect to see improvement in our gross margins as we continue to engineer our product with lower cost components. We also expect to see improvements in gross margin to the extent shipping costs and high demand materials costs decline when global supply chain disruptions ease.

[0001628280-22-029319:mdna:107]
[same as prior period, unchanged from 0001628280-22-023253:mdna:103]

[0001628280-22-029319:mdna:108]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Subscription revenue | $ | 5,198 |  |  | $ | 2,312 |  |  | $ | 2,886 |  |  | 125 | % |
| Cost of subscription revenue | $ | 2,207 |  |  | $ | 1,277 |  |  | $ | 930 |  |  | 73 | % |
| Gross profit - Subscription revenue | $ | 2,991 |  |  | $ | 1,035 |  |  | $ | 1,956 |  |  | 189 | % |
| Gross profit margin - Subscription revenue | 58 | % |  | 45 | % |  | N/A |  | 13 | % |

[0001628280-22-029319:mdna:109]
The increases in subscription revenue and cost of subscription revenue are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed in the preceding twelve months. The increase in

[0001628280-22-029319:mdna:110]
gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin is primarily driven by increased recurring revenue from increased active subscriptions and customer growth.

[0001628280-22-029319:mdna:111]
[same as prior period, unchanged from 0001628280-22-023253:mdna:106]

[0001628280-22-029319:mdna:112]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Service revenue | $ | 1,493 |  |  | $ | 717 |  |  | $ | 776 |  |  | 108 | % |
| Cost of service revenue | $ | 1,138 |  |  | $ | 713 |  |  | $ | 425 |  |  | 60 | % |
| Gross profit - Service revenue | $ | 355 |  |  | $ | 4 |  |  | $ | 351 |  |  | 8775 | % |
| Gross profit margin - Service revenue | 24 | % |  | 1 | % |  | N/A |  | 23 | % |

[0001628280-22-029319:mdna:113]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding twelve months and increased installation and training related to the Evolv Express units. Gross profit and gross profit margin increased for the three months ended September 30, 2022 compared to the prior year period due primarily to a larger mix of service revenue being derived from purchase subscriptions, which typically generate a higher gross profit margin compared to installation and training services.

[0001628280-22-029319:mdna:114]
[same as prior period, unchanged from 0001628280-22-023253:mdna:109]

[0001628280-22-029319:mdna:115]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 4,306 |  |  | $ | 2,992 |  |  | $ | 1,314 |  |  | 44 | % |
| Materials and prototypes | 203 |  |  | 93 |  |  | 110 |  |  | 118 | % |
| Professional fees | 974 |  |  | 443 |  |  | 531 |  |  | 120 | % |
| Other | 133 |  |  | 84 |  |  | 49 |  |  | 58 | % |
|  | $ | 5,616 |  |  | $ | 3,612 |  |  | $ | 2,004 |  |  | 55 | % |

[0001628280-22-029319:mdna:116]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation primarily resulting from new hires in our research and development function during the past twelve months. The increase in professional fees primarily relates to consulting costs incurred for product development and engineering.

[0001628280-22-029319:mdna:117]
[same as prior period, unchanged from 0001628280-22-023253:mdna:112]

[0001628280-22-029319:mdna:118]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 7,820 |  |  | $ | 7,067 |  |  | $ | 753 |  |  | 11 | % |
| Direct marketing | 1,613 |  |  | 1,702 |  |  | (89) |  |  | (5) | % |
| Travel and entertainment | 992 |  |  | 519 |  |  | 473 |  |  | 91 | % |
| Professional fees | 421 |  |  | 252 |  |  | 169 |  |  | 67 | % |
| Other | 900 |  |  | 484 |  |  | 416 |  |  | 86 | % |
|  | $ | 11,746 |  |  | $ | 10,024 |  |  | $ | 1,722 |  |  | 17 | % |

[0001628280-22-029319:mdna:119]
The increase in personnel related expenses is due to an increase in payroll costs, commissions and stock-based compensation resulting from new hires in our sales and marketing functions during the past twelve months, which includes functions such as partner development, customer success, and other business development. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings and events. The increase in other expenses is primarily due to an increase in shipping costs related to demo units.

[0001628280-22-029319:mdna:120]
[same as prior period, unchanged from 0001628280-22-023253:mdna:115]

[0001628280-22-029319:mdna:121]
|  | Three Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 4,548 |  |  | $ | 2,657 |  |  | $ | 1,891 |  |  | 71 | % |
| Professional fees | 1,896 |  |  | 1,874 |  |  | 22 |  |  | 1 | % |
| Director and officer insurance | 894 |  |  | 995 |  |  | (101) |  |  | (10) | % |
| Non-income taxes | 214 |  |  | 67 |  |  | 147 |  |  | 219 | % |
| Other | 1,287 |  |  | 1,942 |  |  | (655) |  |  | (34) | % |
|  | $ | 8,839 |  |  | $ | 7,535 |  |  | $ | 1,304 |  |  | 17 | % |

[0001628280-22-029319:mdna:122]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team during the past twelve months. The decrease in other expenses is primarily due to $0.7 million of non-capitalizable transaction costs incurred during the three months ended September 30, 2021 related to the Merger.

[0001628280-22-029319:mdna:123]
[same as prior period, unchanged from 0001628280-22-023253:mdna:119]

[0001628280-22-029319:mdna:124]
Impairment of property and equipment was $0.6 million and $1.7 million for the three months ended September 30, 2022 and 2021, respectively. As we transition existing domestic customers to our current Express model, we are removing Edge units and Express prototype units from service, resulting in the impairment of the remaining economic value of such units.

[0001628280-22-029319:mdna:125]
[same as prior period, unchanged from 0001628280-22-023253:mdna:121]

[0001628280-22-029319:mdna:126]
Interest expense was $0.2 million for the three months ended September 30, 2022, compared to $0.3 million for the three months ended September 30, 2021. The decrease was primarily due to interest expense and debt discount amortization related to the Convertible Notes during the three months ended September 30, 2021. The Convertible Notes converted to the Company’s stock upon closing of the Merger in July 2021.

[0001628280-22-029319:mdna:127]
[same as prior period, unchanged from 0001628280-22-023253:mdna:123]

[0001628280-22-029319:mdna:128]
Interest income of $1.1 million for the three months ended September 30, 2022 related primarily to interest earned on money market funds. No interest income was earned for the three months ended September 30, 2021.

[0001628280-22-029319:mdna:129]
[same as prior period, unchanged from 0001628280-22-023253:mdna:125]

[0001628280-22-029319:mdna:130]
Loss on extinguishment of debt of $0.9 million for the three months ended September 30, 2021 related to a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes.

[0001628280-22-029319:mdna:131]
[same as prior period, unchanged from 0001628280-22-023253:mdna:127]

[0001628280-22-029319:mdna:132]
Change in fair value of the derivative liability was $0.5 million for the three months ended September 30, 2021, resulting from the settlement of the derivative liability upon the closing of the Merger.

[0001628280-22-029319:mdna:133]
[same as prior period, unchanged from 0001628280-22-023253:mdna:129]

[0001628280-22-029319:mdna:134]
Change in fair value of the contingent earn-out liability was $7.2 million and $32.6 million for the three months ended September 30, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-029319:mdna:135]
[same as prior period, unchanged from 0001628280-22-023253:mdna:131]

[0001628280-22-029319:mdna:136]
Change in the fair value of the contingently issuable common stock liability was $1.1 million and $5.7 million for the three months ended September 30, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments.

[0001628280-22-029319:mdna:137]
11

[0001628280-22-029319:mdna:138]
The contingently issuable common stock liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-029319:mdna:139]
[same as prior period, unchanged from 0001628280-22-023253:mdna:133]

[0001628280-22-029319:mdna:140]
Change in the fair value of the public warrant liability was $(1.1) million and $3.2 million for the three months ended September 30, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-029319:mdna:141]
[same as prior period, unchanged from 0001628280-22-023253:mdna:135]

[0001628280-22-029319:mdna:142]
Change in the fair value of the common stock warrant liability was less than $0.1 million for the three months ended September 30, 2021, resulting from the conversion of the common stock warrant liability upon the closing of the Merger in July 2021 and mark-to-market adjustments prior to the closing of the Merger.

[0001628280-22-029319:mdna:143]
[same as prior period, unchanged from 0001628280-22-023253:mdna:144]

[0001628280-22-029319:mdna:144]
Comparison of the Nine Months ended September 30, 2022 and 2021

[0001628280-22-029319:mdna:145]
The following table summarizes our results of operations for the nine months ended September 30, 2022 and 2021, (in thousands):

[0001628280-22-029319:mdna:146]
|  | Nine Months EndedSeptember 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 19,179 |  |  | $ | 10,279 |  |  | $ | 8,900 |  |  | 87 | % |
| Subscription revenue | 12,208 |  |  | 5,060 |  |  | 7,148 |  |  | 141 |  |
| Service revenue | 2,923 |  |  | 1,456 |  |  | 1,467 |  |  | 101 |  |
| Total revenue | 34,310 |  |  | 16,795 |  |  | 17,515 |  |  | 104 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 23,513 |  |  | 7,386 |  |  | 16,127 |  |  | 218 |  |
| Cost of subscription revenue | 5,730 |  |  | 3,080 |  |  | 2,650 |  |  | 86 |  |
| Cost of service revenue | 3,392 |  |  | 1,685 |  |  | 1,707 |  |  | 101 |  |
| Total cost of revenue | 32,635 |  |  | 12,151 |  |  | 20,484 |  |  | 169 |  |
| Gross profit | 1,675 |  |  | 4,644 |  |  | (2,969) |  |  | (64) |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 13,947 |  |  | 8,399 |  |  | 5,548 |  |  | 66 |  |
| Sales and marketing | 33,169 |  |  | 17,756 |  |  | 15,413 |  |  | 87 |  |
| General and administrative | 29,268 |  |  | 12,058 |  |  | 17,210 |  |  | 143 |  |
| Loss from impairment of property and equipment | 1,038 |  |  | 1,656 |  |  | (618) |  |  | (37) |  |
| Total operating expenses | 77,422 |  |  | 39,869 |  |  | 37,553 |  |  | 94 |  |
| Loss from operations | (75,747) |  |  | (35,225) |  |  | (40,522) |  |  | 115 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (489) |  |  | (5,952) |  |  | 5,463 |  |  | (92) |  |
| Interest income | 1,611 |  |  | — |  |  | 1,611 |  |  | * |
| Other expense, net | (57) |  |  | (669) |  |  | 612 |  |  | (91) | % |
| Loss on extinguishment of debt | — |  |  | (12,685) |  |  | 12,685 |  |  | * |
| Change in fair value of derivative liability | — |  |  | (1,745) |  |  | 1,745 |  |  | * |
| Change in fair value of contingent earn-out liability | 9,754 |  |  | 32,609 |  |  | (22,855) |  |  | (70) | % |
| Change in fair value of contingently issuable common stock liability | 2,529 |  |  | 5,718 |  |  | (3,189) |  |  | (56) | % |
| Change in fair value of public warrant liability | 4,297 |  |  | 3,152 |  |  | 1,145 |  |  | 36 | % |
| Change in fair value of common stock warrant liability | — |  |  | (879) |  |  | 879 |  |  | * |
| Total other income (expense), net | 17,645 |  |  | 19,549 |  |  | (1,904) |  |  | (10) |  |
| Net income (loss) attributable to common stockholders – basic | $ | (58,102) |  |  | $ | (15,676) |  |  | $ | (42,426) |  |  | 271 | % |

[0001628280-22-029319:mdna:147]
[same as prior period, unchanged from 0001628280-22-023253:mdna:140]

[0001628280-22-029319:mdna:148]
[same as prior period, unchanged from 0001628280-22-023253:mdna:155]

[0001628280-22-029319:mdna:149]
[same as prior period, unchanged from 0001628280-22-023253:mdna:141]

[0001628280-22-029319:mdna:150]
[same as prior period, unchanged from 0001628280-22-023253:mdna:142]

[0001628280-22-029319:mdna:151]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Product revenue | $ | 19,179 |  |  | $ | 10,279 |  |  | $ | 8,900 |  |  | 87 | % |
| Cost of product revenue | $ | 23,513 |  |  | $ | 7,386 |  |  | $ | 16,127 |  |  | 218 | % |
| Gross profit - Product revenue | $ | (4,334) |  |  | $ | 2,893 |  |  | $ | (7,227) |  |  | (250) | % |
| Gross profit margin - Product revenue | (23) | % |  | 28 | % |  | N/A |  | (51) | % |

[0001628280-22-029319:mdna:152]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which include the significant increase in the adoption of Evolv Express units by schools, healthcare facilities, hotels, casinos, and professional sports arenas. We believe there are several key trends driving increased adoption of our solutions and growth in our product sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition of 189 new customers during the nine months ended September 30, 2022 compared to 57 new customers during the nine months ended September 30, 2021, (iii) the expansion of our customers' initial Evolv Express deployments to other venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-22-029319:mdna:153]
The decrease in gross profit and gross profit margin during the nine months ended September 30, 2022 compared to the prior year period is attributable to several factors. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, and therefore a lower gross margin, during the nine months ended September 30, 2022 compared to the prior year period. Gross profit and gross profit margin were also adversely impacted by marketing and sponsorship arrangements with certain customers, increases in shipping costs, and the costs associated with the write-off of scrap inventory incurred without corresponding revenue. We expect to see improvement in our gross margins as we continue to engineer our product with lower cost components. We also expect to see improvements in gross margin to the extent shipping costs and high demand materials costs decline when global supply chain disruptions ease.

[0001628280-22-029319:mdna:154]
[same as prior period, unchanged from 0001628280-22-023253:mdna:146]

[0001628280-22-029319:mdna:155]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Subscription revenue | $ | 12,208 |  |  | $ | 5,060 |  |  | $ | 7,148 |  |  | 141 | % |
| Cost of subscription revenue | $ | 5,730 |  |  | $ | 3,080 |  |  | $ | 2,650 |  |  | 86 | % |
| Gross profit - Subscription revenue | $ | 6,478 |  |  | $ | 1,980 |  |  | $ | 4,498 |  |  | 227 | % |
| Gross profit margin - Subscription revenue | 53 | % |  | 39 | % |  | N/A |  | 14 | % |

[0001628280-22-029319:mdna:156]
The increases in subscription revenue and cost of subscription revenue are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed in the preceding twelve months. The increase in

[0001628280-22-029319:mdna:157]
14

[0001628280-22-029319:mdna:158]
gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin is primarily driven by increased recurring revenue from increased active subscriptions and customer growth.

[0001628280-22-029319:mdna:159]
[same as prior period, unchanged from 0001628280-22-023253:mdna:149]

[0001628280-22-029319:mdna:160]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Service revenue | $ | 2,923 |  |  | $ | 1,456 |  |  | $ | 1,467 |  |  | 101 | % |
| Cost of service revenue | $ | 3,392 |  |  | $ | 1,685 |  |  | $ | 1,707 |  |  | 101 | % |
| Gross profit - Service revenue | $ | (469) |  |  | $ | (229) |  |  | $ | (240) |  |  | 105 | % |
| Gross profit margin - Service revenue | (16) | % |  | (16) | % |  | N/A |  | — | % |

[0001628280-22-029319:mdna:161]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding twelve months and increased installation and training related to the Evolv Express units. The negative gross profit and gross profit margin in each period are due primarily to field services costs associated with the Evolv Express units. We expect we will see leverage in these expense investments as we work to achieve further levels of scale.

[0001628280-22-029319:mdna:162]
[same as prior period, unchanged from 0001628280-22-023253:mdna:152]

[0001628280-22-029319:mdna:163]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 11,268 |  |  | $ | 5,424 |  |  | $ | 5,844 |  |  | 108 | % |
| Materials and prototypes | 439 |  |  | 1,537 |  |  | (1,098) |  |  | (71) | % |
| Professional fees | 1,706 |  |  | 1,023 |  |  | 683 |  |  | 67 | % |
| Other | 534 |  |  | 415 |  |  | 119 |  |  | 29 | % |
|  | $ | 13,947 |  |  | $ | 8,399 |  |  | $ | 5,548 |  |  | 66 | % |

[0001628280-22-029319:mdna:164]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from new hires in our research and development function during the past twelve months. The decrease in materials and prototype costs is due to the transition from prototype production to standard manufacturing of the Evolv Express, which results in lower prototyping costs. The increase in professional fees primarily relates to consulting costs incurred for product development and engineering.

[0001628280-22-029319:mdna:165]
[same as prior period, unchanged from 0001628280-22-023253:mdna:157]

[0001628280-22-029319:mdna:166]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 21,433 |  |  | $ | 12,270 |  |  | $ | 9,163 |  |  | 75 | % |
| Direct marketing | 4,502 |  |  | 2,773 |  |  | 1,729 |  |  | 62 | % |
| Travel and entertainment | 2,530 |  |  | 1,011 |  |  | 1,519 |  |  | 150 | % |
| Professional fees | 973 |  |  | 624 |  |  | 349 |  |  | 56 | % |
| Other | 3,731 |  |  | 1,078 |  |  | 2,653 |  |  | 246 | % |
|  | $ | 33,169 |  |  | $ | 17,756 |  |  | $ | 15,413 |  |  | 87 | % |

[0001628280-22-029319:mdna:167]
The increase in personnel related expenses is due to an increase in payroll costs, commissions and stock-based compensation resulting from new hires in our sales and marketing functions during the past twelve months, which includes functions such as partner development, customer success, and other business development. The increase in direct marketing is due to an increase in trade shows and events, which have begun to return to pre-pandemic levels. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings and events. The increase in other expenses is primarily due to $1.0 million of certain one-time expenses as well as an increase in shipping costs related to demo units.

[0001628280-22-029319:mdna:168]
[same as prior period, unchanged from 0001628280-22-023253:mdna:160]

[0001628280-22-029319:mdna:169]
|  | Nine Months Ended September 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 12,513 |  |  | $ | 4,038 |  |  | $ | 8,475 |  |  | 210 | % |
| Professional fees | 7,235 |  |  | 3,548 |  |  | 3,687 |  |  | 104 | % |
| Insurance costs | 3,524 |  |  | 1,183 |  |  | 2,341 |  |  | 198 | % |
| Non-income taxes | 701 |  |  | 106 |  |  | 595 |  |  | 561 | % |
| Other | 5,295 |  |  | 3,183 |  |  | 2,112 |  |  | 66 | % |
|  | $ | 29,268 |  |  | $ | 12,058 |  |  | $ | 17,210 |  |  | 143 | % |

[0001628280-22-029319:mdna:170]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team during the past twelve months. The increase in professional fees is due to an increase in accounting, audit, tax, and legal services provided to the Company to support public company requirements. The increase in insurance costs is due primarily to director and officer insurance expense in relation to being a public company. The increase in non-income taxes is due to a sales tax contingency liability as we may owe additional sales and use taxes in various jurisdictions. The increase in other expenses is due primarily to $1.7 million of certain one-time expenses, a $0.4 million one-time payment to a former employee, and a $0.5 million increase in IT and software subscription costs, offset by $0.7 million of non-capitalizable transaction costs incurred during the nine months ended September 30, 2021 related to the Merger.

[0001628280-22-029319:mdna:171]
[same as prior period, unchanged from 0001628280-22-023253:mdna:163]

[0001628280-22-029319:mdna:172]
Impairment of property and equipment was $1.0 million and $1.7 million for the nine months ended September 30, 2022 and 2021 respectively. As we transition existing domestic customers to our current Express model, we are removing Edge units and Express prototype units from service, which results in the impairment of the remaining economic value of such units.

[0001628280-22-029319:mdna:173]
[same as prior period, unchanged from 0001628280-22-023253:mdna:165]

[0001628280-22-029319:mdna:174]
Interest expense was $0.5 million for the nine months ended September 30, 2022, compared to $6.0 million for the nine months ended September 30, 2021. The decrease was primarily due to interest expense on the Convertible Notes during the nine months ended September 30, 2021. The Convertible Notes converted to the Company’s common stock upon closing of the Merger in July 2021.

[0001628280-22-029319:mdna:175]
[same as prior period, unchanged from 0001628280-22-023253:mdna:168]

[0001628280-22-029319:mdna:176]
Interest income of $1.6 million for the nine months ended September 30, 2022 related primarily to interest earned on money market funds. No interest income was earned for the nine months ended September 30, 2021.

[0001628280-22-029319:mdna:177]
[same as prior period, unchanged from 0001628280-22-023253:mdna:170]

[0001628280-22-029319:mdna:178]
Loss on extinguishment of debt of $12.7 million for the nine months ended September 30, 2021 related to a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes.

[0001628280-22-029319:mdna:179]
[same as prior period, unchanged from 0001628280-22-023253:mdna:172]

[0001628280-22-029319:mdna:180]
Change in fair value of the derivative liability was $(1.7) million for the nine months ended September 30, 2021, resulting from an increase in the fair value of the Company's stock given the pending Merger. The derivative liability was derecognized in connection with the closing of the Merger in July 2021.

[0001628280-22-029319:mdna:181]
[same as prior period, unchanged from 0001628280-22-023253:mdna:174]

[0001628280-22-029319:mdna:182]
Change in fair value of the contingent earn-out liability was $9.8 million and $32.6 million for the nine months ended September 30, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-029319:mdna:183]
[same as prior period, unchanged from 0001628280-22-023253:mdna:176]

[0001628280-22-029319:mdna:184]
Change in the fair value of the contingently issuable common stock liability was $2.5 million and $5.7 million for the nine months ended September 30, 2022 and 2021, respectively, resulting from quarterly market-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-029319:mdna:185]
[same as prior period, unchanged from 0001628280-22-023253:mdna:178]

[0001628280-22-029319:mdna:186]
Change in the fair value of the public warrant liability was $4.3 million and $3.2 million for the nine months ended September 30, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-029319:mdna:187]
[same as prior period, unchanged from 0001628280-22-023253:mdna:180]

[0001628280-22-029319:mdna:188]
Change in the fair value of the common stock warrant liability was $(0.9) million for the nine months ended September 30, 2021, resulting from the conversion of the common stock warrant liability upon the closing of the Merger in July 2021 and mark-to-market adjustments prior to the closing of the Merger.

[0001628280-22-029319:mdna:189]
[same as prior period, unchanged from 0001628280-22-023253:mdna:182]

[0001628280-22-029319:mdna:190]
There is no provision for income taxes for the three and nine months ended September 30, 2022 and 2021 because we have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets. We have provided a valuation allowance for all of our deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001628280-22-029319:mdna:191]
[same as prior period, unchanged from 0001628280-22-023253:mdna:185]

[0001628280-22-029319:mdna:192]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. Prior to the Merger, as an early-stage company, we primarily obtained cash to fund our operations through preferred stock offerings and debt instruments. As of September 30, 2022, we had $218.5 million in cash and cash equivalents. We incurred a net loss of $18.6 million and net income of $20.8 million for the three months ended September 30, 2022 and 2021, respectively, and a net loss of $58.1 million and $15.7 million for the nine months ended September 30, 2022 and 2021, respectively. We incurred cash outflows from operating activities of $69.4 million and $42.6 million during the nine months ended September 30, 2022 and 2021, respectively.

[0001628280-22-029319:mdna:193]
We expect our cash and cash equivalents, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our sales and marketing teams worldwide. We are likely to require additional capital to respond to the expected growth in the demand for equipment purchases to support our "leased equipment" offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions or unforeseen circumstances and in either the short-term or long-term may determine to engage in equity or debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our

[0001628280-22-029319:mdna:194]
17

[0001628280-22-029319:mdna:195]
ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as the public health emergencies, including the COVID-19 pandemic and its variants, international political turmoil, including Russia's invasion of Ukraine, ongoing supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001628280-22-029319:mdna:196]
[same as prior period, unchanged from 0001628280-22-023253:mdna:188]

[0001628280-22-029319:mdna:197]
[same as prior period, unchanged from 0001628280-22-023253:mdna:189]

[0001628280-22-029319:mdna:198]
[same as prior period, unchanged from 0001628280-22-023253:mdna:190]

[0001628280-22-029319:mdna:199]
In December 2020, we entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024, and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022, which extinguished the 2020 Silicon Valley Bank Term Loan. Under the terms of the JPM Credit Agreement, we received proceeds of $10.0 million. As of September 30, 2022, we had $9.0 of debt outstanding. In September and December of 2020, we issued a total of $4.0 million of convertible notes (the “2020 Convertible Notes”). In January and February 2021, we issued a total of $30.0 million of convertible notes with a maturity date of September 2021.

[0001628280-22-029319:mdna:200]
[same as prior period, unchanged from 0001628280-22-023253:mdna:192]

[0001628280-22-029319:mdna:201]
[same as prior period, unchanged from 0001628280-22-023253:mdna:193]

[0001628280-22-029319:mdna:202]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of September 30, 2022. We anticipate fulfilling such commitments with our existing cash and cash equivalents obtained through operations, proceeds from long-term debt, closing of the Merger, and issuance of common stock in connection with the PIPE investment. Cash and cash equivalents amounted to $218.5 million as of September 30, 2022.

[0001628280-22-029319:mdna:203]
We entered into a lease agreement for additional office space starting May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. We are required to maintain a minimum cash balance of $0.7 million as a security deposit on the leased space which is classified as restricted cash, current and restricted cash, non-current on the condensed consolidated balance sheet as of September 30, 2022. Total future minimum lease payments under this noncancelable operating lease amount to $2.4 million. See Note 6 to our condensed consolidated financial statements for the three and nine months ended September 30, 2022.

[0001628280-22-029319:mdna:204]
[same as prior period, unchanged from 0001628280-22-023253:mdna:198]

[0001628280-22-029319:mdna:205]
[same as prior period, unchanged from 0001628280-22-023253:mdna:199]

[0001628280-22-029319:mdna:206]
|  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |
| Net cash used in operating activities | $ | (69,421) |  |  | $ | (42,565) |  |
| Net cash used in investing activities | (19,178) |  |  | (10,994) |  |
| Net cash provided by (used in) financing activities | (429) |  |  | 383,277 |  |
| Effect of exchange rate changes on cash and cash equivalents | 35 |  |  | — |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (88,993) |  |  | $ | 329,718 |  |

[0001628280-22-029319:mdna:207]
18

[0001628280-22-029319:mdna:208]
[same as prior period, unchanged from 0001628280-22-023253:mdna:201]

[0001628280-22-029319:mdna:209]
|  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |
| Net loss | $ | (58,102) |  |  | $ | (15,676) |  |
| Non-cash (income) expense | 4,403 |  |  | (9,977) |  |
| Changes in operating assets and liabilities | (15,722) |  |  | (16,912) |  |
| Net cash used in operating activities | $ | (69,421) |  |  | $ | (42,565) |  |

[0001628280-22-029319:mdna:210]
Net loss increased from $15.7 million for the nine months ended September 30, 2021 to $58.1 million for the nine months ended September 30, 2022, as a result of the factors described in "Results of Operations" above.

[0001628280-22-029319:mdna:211]
Non-cash expenses for the nine months ended September 30, 2022 are primarily attributable to $15.5 million of stock-based compensation expense, $3.8 million of depreciation and amortization, and $1.0 million of loss from impairment of property and equipment, offset by $16.6 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability. Non-cash expenses for the nine months ended September 30, 2021 are primarily attributable to a $12.7 million loss on debt extinguishment related to the 2021 Convertible Notes, $5.6 million of non-cash interest expense primarily related to the accretion of the debt discount associated with the 2021 Convertible Notes, $6.0 million of stock-based compensation expense, $1.9 million of depreciation and amortization, and $1.7 million of loss from impairment of property and equipment, offset by $38.9 million of an aggregate change in fair value of the derivative liability, common stock warrant liability, earn-out liability, contingently issuable common stock liability, and public warrant liability.

[0001628280-22-029319:mdna:212]
Changes in operating assets and liabilities for the nine months ended September 30, 2022 are primarily related to the following:

[0001628280-22-029319:mdna:213]
•$14.8 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001628280-22-029319:mdna:214]
•$4.4 million increase in inventory primarily due to increased production of units to meet customer demand;

[0001628280-22-029319:mdna:215]
•$9.0 million increase in prepaid expense and other current assets primarily due to deposits paid to the Company's contract manufacturer; offset by

[0001628280-22-029319:mdna:216]
•$16.0 million increase in deferred revenue due to a higher volume of sales.

[0001628280-22-029319:mdna:217]
Changes in operating assets and liabilities for the nine months ended September 30, 2021 are primarily related to the following:

[0001628280-22-029319:mdna:218]
•$5.9 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers; and

[0001628280-22-029319:mdna:219]
•$11.5 million increase in prepaid expense and other current assets primarily due to prepaid subscriptions and insurance.

[0001628280-22-029319:mdna:220]
[same as prior period, unchanged from 0001628280-22-023253:mdna:214]

[0001628280-22-029319:mdna:221]
During the nine months ended September 30, 2022, cash used in investing activities was $19.2 million, consisting of $17.6 million for the purchase of property and equipment, primarily related to the purchase of Express units to be leased to customers, and $1.9 million for the development of internal-use software, offset by $0.3 million of proceeds from the sale of property and equipment.

[0001628280-22-029319:mdna:222]
During the nine months ended September 30, 2021, cash used in investing activities was $11.0 million, consisting of the purchase of property and equipment, primarily related to the purchase of Express units to be leased to customers.

[0001628280-22-029319:mdna:223]
[same as prior period, unchanged from 0001628280-22-023253:mdna:217]

[0001628280-22-029319:mdna:224]
During the nine months ended September 30, 2022, cash used in financing activities was $0.4 million, consisting of $1.0 million of debt repayments offset by $0.6 million of proceeds from the exercise of stock options.

[0001628280-22-029319:mdna:225]
During the nine months ended September 30, 2021, cash provided by financing activities was $383.3, consisting of $300.0 million from the issuance of common stock from the PIPE investment, $84.9 million of proceeds from closing of

[0001628280-22-029319:mdna:226]
the Merger, $31.9 million from the issuance of long-term debt, net of issuance costs, and $0.8 million from the exercise of stock options, partially offset by $34.0 million of offering costs paid in relation to the closing of the Merger and $0.4 million in net cash outflows for the repayment of our finance obligations.

[0001628280-22-029319:mdna:227]
[same as prior period, unchanged from 0001628280-22-023253:mdna:220]

[0001628280-22-029319:mdna:228]
A description of recently issued accounting pronouncements that may potentially impact our financial position, results of operations or cash flows is disclosed in Note 2 to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001628280-22-029319:mdna:229]
[same as prior period, unchanged from 0001628280-22-023253:mdna:222]

[0001628280-22-029319:mdna:230]
Our critical accounting policies and estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” for the year ended December 31, 2021 in our Annual Report on Form 10-K. There have been no material changes to our critical accounting policies and estimates during the three months ended September 30, 2022 outside of our critical accounting policies and estimates described below.

[0001628280-22-029319:mdna:231]
[same as prior period, unchanged from 0001628280-22-023253:mdna:224]

[0001628280-22-029319:mdna:232]
[same as prior period, unchanged from 0001628280-22-023253:mdna:225]

[0001628280-22-029319:mdna:233]
[same as prior period, unchanged from 0001628280-22-023253:mdna:226]

[0001628280-22-029319:mdna:234]
[same as prior period, unchanged from 0001628280-22-023253:mdna:227]

[0001628280-22-029319:mdna:235]
[same as prior period, unchanged from 0001628280-22-023253:mdna:228]

[0001628280-22-029319:mdna:236]
The Jumpstart Our Business Startups Act of 2012, or the JOBS Act, permits an “emerging growth company” such as us to take advantage of an extended transition period to comply with new or revised accounting standards applicable to public companies until those standards would otherwise apply to private companies. We meet the definition of an “emerging growth company” and have elected to use this extended transition period for complying with new or revised accounting standards that have different effective dates for public and private companies until the earlier of the date we (1) are no longer an emerging growth company or (2) affirmatively and irrevocably opt out of the extended transition period provided in the JOBS Act. As a result of this election, we will not be subject to the same new or revised accounting standards as other public companies that are not emerging growth companies and our condensed consolidated financial statements may not be comparable to other public companies that comply with new or revised accounting pronouncements as of public company effective dates. We may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for private companies.

[0001628280-22-029319:mdna:237]
We will remain an emerging growth company until the earlier of (1) the last day of the fiscal year (a) following the fifth anniversary of the completion of the initial public offering, (b) in which we have total annual gross revenue of at least $1.235 billion or (c) in which we are deemed to be a large accelerated filer, and (2) the date on which we have issued more than $1.0 billion in non-convertible debt during the prior three-year period.

[0001628280-22-029319:mdna:238]
Further, even after we no longer qualify as an emerging growth company, we may still qualify as a “smaller reporting company,” which would allow us to take advantage of many of the same exemptions from disclosure

[0001628280-22-029319:mdna:239]
requirements, including reduced disclosure obligations regarding executive compensation in our periodic reports and proxy statements. We cannot predict if investors will find our common shares less attractive because we may rely on these exemptions. If some investors find our common shares less attractive as a result, there may be a less active trading market for our common shares and our share price may be more volatile.
