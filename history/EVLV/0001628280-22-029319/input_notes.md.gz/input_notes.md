# EVLV notes — 0001628280-22-029319


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-22-029319:notes:1]
[same as prior period, unchanged from 0001628280-22-023253:notes:1]

[0001628280-22-029319:notes:2]
[same as prior period, unchanged from 0001628280-22-023253:notes:2]

[0001628280-22-029319:notes:3]
[same as prior period, unchanged from 0001628280-22-023253:notes:3]

[0001628280-22-029319:notes:4]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001628280-22-029319:notes:5]
[same as prior period, unchanged from 0001628280-22-023253:notes:5]

[0001628280-22-029319:notes:6]
[same as prior period, unchanged from 0001628280-22-023253:notes:6]

[0001628280-22-029319:notes:7]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2022, and for the three and nine months ended September 30, 2022 and 2021 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2021 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2022 and the results of its operations for the three and nine months ended September 30, 2022 and 2021 and cash flows for the nine months ended September 30, 2022 and 2021. The results for the three and nine months ended September 30, 2022 are not necessarily indicative of results to be expected for the year ending December 31, 2022, any other interim periods, or any future year or period.

[0001628280-22-029319:notes:8]
[same as prior period, unchanged from 0001628280-22-023253:notes:8]

[0001628280-22-029319:notes:9]
[same as prior period, unchanged from 0001628280-22-023253:notes:9]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-22-029319:notes:10]
[same as prior period, unchanged from 0001628280-22-023253:notes:10]

[0001628280-22-029319:notes:11]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2021, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2021. There have been no material changes to the Company’s significant accounting policies during the three months ended September 30, 2022 outside of the items as described below.

[0001628280-22-029319:notes:12]
[same as prior period, unchanged from 0001628280-22-023253:notes:12]

[0001628280-22-029319:notes:13]
[same as prior period, unchanged from 0001628280-22-023253:notes:13]

[0001628280-22-029319:notes:14]
[same as prior period, unchanged from 0001628280-22-023253:notes:14]

[0001628280-22-029319:notes:15]
[same as prior period, unchanged from 0001628280-22-023253:notes:15]

[0001628280-22-029319:notes:16]
[same as prior period, unchanged from 0001628280-22-023253:notes:16]

[0001628280-22-029319:notes:17]
[same as prior period, unchanged from 0001628280-22-023253:notes:17]

[0001628280-22-029319:notes:18]
[same as prior period, unchanged from 0001628280-22-023253:notes:18]

[0001628280-22-029319:notes:19]
[same as prior period, unchanged from 0001628280-22-023253:notes:19]

[0001628280-22-029319:notes:20]
[same as prior period, unchanged from 0001628280-22-023253:notes:20]

[0001628280-22-029319:notes:21]
[same as prior period, unchanged from 0001628280-22-023253:notes:21]

[0001628280-22-029319:notes:22]
[same as prior period, unchanged from 0001628280-22-023253:notes:22]

[0001628280-22-029319:notes:23]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party. Revenue related to leases entered into with related parties were $0.2 million and $0.4 million during the three and nine months ended September 30, 2022, respectively.

[0001628280-22-029319:notes:24]
[same as prior period, unchanged from 0001628280-22-023253:notes:24]

[0001628280-22-029319:notes:25]
Recently Adopted Accounting Pronouncements

[0001628280-22-029319:notes:26]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), as subsequently amended (collectively “ASC 842”). The guidance amends the existing accounting standards for lease accounting, including requirements for lessees to recognize assets and liabilities related to long-term leases on the balance sheet and expanding disclosure requirements regarding leasing arrangements. For lessees, leases will be classified as finance or operating, with classification affecting the pattern and classification of expense recognition in the income statement. Lessors are required to classify leases as a sales-type, direct financing, or operating lease. A lease is a sales-type lease if it effectively transfers control of the underlying asset to the lessee as indicated by any one of five criteria being met. All leases that are not sales-type or direct financing leases will be classified as operating leases. In July 2018, the FASB issued additional guidance, which offers a transition option to entities adopting ASC 842 in which entities can elect to apply the new guidance using a modified retrospective approach at the beginning of the year in which the new lease standard is adopted. The Company utilized this transition option whereby financial information for prior periods presented before the ASC 842 effective date will not be updated. In November 2019, the FASB issued ASU 2019-10 deferring the effective date for private entities (also applicable for public companies that qualify as emerging growth companies) for fiscal years beginning after December 15, 2020, and interim periods within fiscal years beginning after December 15, 2021. In June 2020, the FASB issued ASU 2020-05 which further defers the effective date for private entities for fiscal years beginning after December 15, 2021, and interim periods within fiscal years beginning after December 15, 2022.

[0001628280-22-029319:notes:27]
[same as prior period, unchanged from 0001628280-22-023253:notes:27]

[0001628280-22-029319:notes:28]
[same as prior period, unchanged from 0001628280-22-023253:notes:28]

[0001628280-22-029319:notes:29]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.

[0001628280-22-029319:notes:30]
In August 2020, the FASB issued ASU 2020-06, Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies and clarifies certain calculation and presentation matters related to convertible and equity and debt instruments. Specifically, ASU 2020-06 removes requirements to separately account for conversion features as a derivative under ASC Topic 815 and removing the requirement to account for beneficial conversion features on such instruments. ASU 2020-06 also provides clearer guidance surrounding disclosure of such instruments and provides specific guidance for how such instruments are to be incorporated in the calculation of Diluted EPS. The guidance under ASU 2020-06 is effective for fiscal years beginning after December 15, 2021, including interim periods within those fiscal

[0001628280-22-029319:notes:31]
[same as prior period, unchanged from 0001628280-22-023253:notes:31]

[0001628280-22-029319:notes:32]
Recently Issued Accounting Pronouncements

[0001628280-22-029319:notes:33]
[same as prior period, unchanged from 0001628280-22-023253:notes:33]

[0001628280-22-029319:notes:34]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and does not expect that adoption of the guidance will have a material impact on its condensed consolidated financial statements.

[0001628280-22-029319:notes:35]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company expects to adopt this guidance effective January 1, 2023, and does not expect that adoption of the guidance will have a material impact on its condensed consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-22-029319:notes:36]
[same as prior period, unchanged from 0001628280-22-023253:notes:36]

[0001628280-22-029319:notes:37]
[same as prior period, unchanged from 0001628280-22-023253:notes:37]

[0001628280-22-029319:notes:38]
[same as prior period, unchanged from 0001628280-22-023253:notes:38]

[0001628280-22-029319:notes:39]
[same as prior period, unchanged from 0001628280-22-023253:notes:39]

[0001628280-22-029319:notes:40]
[same as prior period, unchanged from 0001628280-22-023253:notes:40]

[0001628280-22-029319:notes:41]
[same as prior period, unchanged from 0001628280-22-023253:notes:41]

[0001628280-22-029319:notes:42]
[same as prior period, unchanged from 0001628280-22-023253:notes:42]

[0001628280-22-029319:notes:43]
[same as prior period, unchanged from 0001628280-22-023253:notes:43]

[0001628280-22-029319:notes:44]
[same as prior period, unchanged from 0001628280-22-023253:notes:44]

[0001628280-22-029319:notes:45]
[same as prior period, unchanged from 0001628280-22-023253:notes:45]

[0001628280-22-029319:notes:46]
[same as prior period, unchanged from 0001628280-22-023253:notes:46]

[0001628280-22-029319:notes:47]
[same as prior period, unchanged from 0001628280-22-023253:notes:47]

[0001628280-22-029319:notes:48]
[same as prior period, unchanged from 0001628280-22-023253:notes:48]

[0001628280-22-029319:notes:49]
[same as prior period, unchanged from 0001628280-22-023253:notes:49]

[0001628280-22-029319:notes:50]
[same as prior period, unchanged from 0001628280-22-023253:notes:50]

[0001628280-22-029319:notes:51]
which the Subscribers agreed to purchase. Pursuant to the PIPE Investment, the Company issued 30,000,000 shares of common stock for a purchase price of $10.00 per share with gross proceeds of $300.0 million.

[0001628280-22-029319:notes:52]
[same as prior period, unchanged from 0001628280-22-023253:notes:52]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-22-029319:notes:53]
[same as prior period, unchanged from 0001628280-22-023253:notes:53]

[0001628280-22-029319:notes:54]
|  | Fair Value Measurements at September 30, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 198,610 |  |  | $ | — |  |  | $ | — |  |  | $ | 198,610 |  |
|  | $ | 198,610 |  |  | $ | — |  |  | $ | — |  |  | $ | 198,610 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 11,452 |  |  | $ | 11,452 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 2,735 |  |  | 2,735 |  |
| Public Warrant liability | 6,733 |  |  | — |  |  | — |  |  | 6,733 |  |
|  | $ | 6,733 |  |  | $ | — |  |  | $ | 14,187 |  |  | $ | 20,920 |  |

[0001628280-22-029319:notes:55]
|  | Fair Value Measurements as of December 31, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 297,536 |  |  | $ | — |  |  | $ | — |  |  | $ | 297,536 |  |
|  | $ | 297,536 |  |  | $ | — |  |  | $ | — |  |  | $ | 297,536 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | 21,206 |  |  | $ | 21,206 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 5,264 |  |  | 5,264 |  |
| Public Warrant liability | 11,030 |  |  | — |  |  | — |  |  | 11,030 |  |
|  | $ | 11,030 |  |  | $ | — |  |  | $ | 26,470 |  |  | $ | 37,500 |  |

[0001628280-22-029319:notes:56]
As of September 30, 2022 and December 31, 2021, money market funds are included in cash and cash equivalents on the condensed consolidated balance sheets.

[0001628280-22-029319:notes:57]
The fair value classification of the public warrant liability as of December 31, 2021 and September 30, 2022 has been updated to Level 1. During each of the three and nine months ended September 30, 2022 and 2021, there were no transfers between Level 1, Level 2 and Level 3.

[0001628280-22-029319:notes:58]
[same as prior period, unchanged from 0001628280-22-023253:notes:58]

[0001628280-22-029319:notes:59]
[same as prior period, unchanged from 0001628280-22-023253:notes:59]

[0001628280-22-029319:notes:60]
2021. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of September 30, 2022, no milestones have been achieved.

[0001628280-22-029319:notes:61]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of September 30, 2022 were as follows: 90% expected stock price volatility, a risk-free rate of return of 4.2%, a 25% likelihood of change in control and a remaining term of 3.4 years.

[0001628280-22-029319:notes:62]
[same as prior period, unchanged from 0001628280-22-023253:notes:62]

[0001628280-22-029319:notes:63]
| December 31, 2021 | $ | 21,206 |
| Change in fair value | (9,754) |
| September 30, 2022 | $ | 11,452 |

[0001628280-22-029319:notes:64]
[same as prior period, unchanged from 0001628280-22-023253:notes:64]

[0001628280-22-029319:notes:65]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 Founder Shares. 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 outstanding shares shall vest upon the Company achieving certain milestones as described in Note 2 of our consolidated financial statements of our Annual Report on Form 10-K for the year ended December 31, 2021. The Company’s contingently issuable common stock was recorded at fair value as contingent shares on the closing of the Merger and are remeasured each reporting period. As of September 30, 2022, no milestones have been achieved.

[0001628280-22-029319:notes:66]
The fair value of the contingently issued common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of September 30, 2022 were as follows: 90% expected stock price volatility, a risk-free rate of return of 4.2%, a 25% likelihood of change in control and a remaining term of 3.8 years.

[0001628280-22-029319:notes:67]
[same as prior period, unchanged from 0001628280-22-023253:notes:67]

[0001628280-22-029319:notes:68]
| December 31, 2021 | $ | 5,264 |  |
| Change in fair value | (2,529) |  |
| September 30, 2022 | $ | 2,735 |  |

[0001628280-22-029319:notes:69]
[same as prior period, unchanged from 0001628280-22-023253:notes:69]

[0001628280-22-029319:notes:70]
Upon the closing of the Merger, the Company assumed the Public Warrants to purchase shares of the Company’s common stock (see Note 13). The Public Warrants are publicly traded and the fair value is remeasured each reporting period based on the closing price as reported by Nasdaq on the last date of the reporting period.

[0001628280-22-029319:notes:71]
[same as prior period, unchanged from 0001628280-22-023253:notes:71]

[0001628280-22-029319:notes:72]
| December 31, 2021 | $ | 11,030 |
| Change in fair value | (4,297) |  |
| September 30, 2022 | $ | 6,733 |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-22-029319:notes:73]
[same as prior period, unchanged from 0001628280-22-023253:notes:73]

[0001628280-22-029319:notes:74]
[same as prior period, unchanged from 0001628280-22-023253:notes:74]

[0001628280-22-029319:notes:75]
[same as prior period, unchanged from 0001628280-22-023253:notes:75]

[0001628280-22-029319:notes:76]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2022.

[0001628280-22-029319:notes:77]
|  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue | $ | 4,087 |  |  | $ | — |  |  | $ | 4,087 |  |
| Subscription revenue | 22,682 |  |  | 49,935 |  |  | 72,617 |  |
| Service revenue | 9,061 |  |  | 23,642 |  |  | 32,703 |  |
| Total revenue | $ | 35,830 |  |  | $ | 73,577 |  |  | $ | 109,407 |  |

[0001628280-22-029319:notes:78]
The amount of minimum future leases is based on expected income recognition. As of September 30, 2022, future minimum payments on noncancelable leases are as follows (in thousands):

[0001628280-22-029319:notes:79]
| Year Ending December 31: |  |
| 2022 (three months remaining) | $ | 5,734 |  |
| 2023 | 22,403 |  |
| 2024 | 20,956 |  |
| 2025 | 17,067 |  |
| 2026 | 6,377 |  |
| Thereafter | 80 |  |
|  | $ | 72,617 |  |

[0001628280-22-029319:notes:80]
[same as prior period, unchanged from 0001628280-22-023253:notes:80]

[0001628280-22-029319:notes:81]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2022 and December 31, 2021, the Company had $5.3 million and $1.5 million in current portion of contract assets and $1.5 million and $3.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001628280-22-029319:notes:82]
[same as prior period, unchanged from 0001628280-22-023253:notes:82]

[0001628280-22-029319:notes:83]
and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $1.3 million and $6.0 million during the three and nine months ended September 30, 2022, respectively, that was included in the 2021 deferred revenue balance. The Company recognized revenue of $0.5 million and $2.3 million during the three and nine months ended September 30, 2021, respectively, that was included in the 2020 deferred revenue balance.

[0001628280-22-029319:notes:84]
[same as prior period, unchanged from 0001628280-22-023253:notes:84]

[0001628280-22-029319:notes:85]
| Balance at December 31, 2021 | $ | 9,074 |  |
| Revenue recognized | 5,995 |  |
| Revenue deferred | 10,017 |  |
| Balance at September 30, 2022 | $ | 25,086 |  |

[0001628280-22-029319:notes:86]
[same as prior period, unchanged from 0001628280-22-023253:notes:86]

[0001628280-22-029319:notes:87]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue from sales-type leases | $ | 29 |  |  | $ | — |  |  | $ | 1,341 |  |  | $ | — |  |
| Interest income on lease receivables | 60 |  |  | — |  |  | 170 |  |  | — |  |
| Lease income - operating leases | 5,198 |  |  | 2,312 |  |  | 12,208 |  |  | 5,060 |  |
| Total lease revenue | $ | 5,287 |  |  | $ | 2,312 |  |  | $ | 13,719 |  |  | $ | 5,060 |  |

[0001628280-22-029319:notes:88]
[same as prior period, unchanged from 0001628280-22-023253:notes:88]

[0001628280-22-029319:notes:89]
[same as prior period, unchanged from 0001628280-22-023253:notes:89]

[0001628280-22-029319:notes:90]
[same as prior period, unchanged from 0001628280-22-023253:notes:90]

[0001628280-22-029319:notes:91]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Product revenue | $ | 9,839 |  |  | $ | 5,395 |  |  | $ | 19,179 |  |  | $ | 10,279 |  |
| Leased equipment | 5,198 |  |  | 2,312 |  |  | 12,208 |  |  | 5,060 |  |
| SaaS and Maintenance revenue | 1,180 |  |  | 300 |  |  | 2,277 |  |  | 662 |  |
| Professional services and other revenue | 313 |  |  | 417 |  |  | 646 |  |  | 794 |  |
| Total revenue | $ | 16,530 |  |  | $ | 8,424 |  |  | $ | 34,310 |  |  | $ | 16,795 |  |

[0001628280-22-029319:notes:92]
[same as prior period, unchanged from 0001628280-22-023253:notes:92]

[0001628280-22-029319:notes:93]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $7.0 million and $5.4 million as of September 30, 2022 and December 31, 2021,

[0001628280-22-029319:notes:94]
respectively. During the three months ended September 30, 2022 and 2021, the Company amortized commission expense of $1.2 million and $1.4 million, respectively. During the nine months ended September 30, 2022 and 2021, the Company amortized commission expense of $2.4 million and $2.0 million, respectively.

[0001628280-22-029319:notes:95]
[same as prior period, unchanged from 0001628280-22-023253:notes:95]

[0001628280-22-029319:notes:96]
[same as prior period, unchanged from 0001628280-22-023253:notes:96]

[0001628280-22-029319:notes:97]
[same as prior period, unchanged from 0001628280-22-023253:notes:97]

[0001628280-22-029319:notes:98]
During the nine months ended September 30, 2022, the Company donated six Evolv Express units to schools, resulting in $0.2 million in general and administrative expense in the Company’s condensed consolidated statements of operations and comprehensive loss. No Evolv Express units were donated during the nine months ended September 30, 2021.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-22-029319:notes:99]
[same as prior period, unchanged from 0001628280-22-023253:notes:99]

[0001628280-22-029319:notes:100]
In April 2021, the Company entered a sublease agreement for office and storage space for its corporate headquarters located at 500 Totten Pond Road in Waltham, MA. The sublease has an initial term of 42 months beginning on May 1, 2021 and expiring on October 31, 2024. The Company is required to maintain a minimum cash balance of $0.7 million as a security deposit on the space which is classified as restricted cash, current and restricted cash, non-current on the condensed consolidated balance sheets. The Company pays for its proportionate share of building operating expenses and taxes that are treated as variable costs and excluded from the measurement of the lease. The sublease grants the Company an option to extend the term for an additional three years at the then fair market rent by giving the landlord nine months’ written notice. The Company was not reasonably certain to exercise the option to extend the lease and therefore the extension term was excluded from the measurement of the lease.

[0001628280-22-029319:notes:101]
[same as prior period, unchanged from 0001628280-22-023253:notes:101]

[0001628280-22-029319:notes:102]
[same as prior period, unchanged from 0001628280-22-023253:notes:102]

[0001628280-22-029319:notes:103]
Operating lease cost recognized during the three and nine months ended September 30, 2022 was $0.3 million and $0.7 million, respectively. Cash paid for amounts included in the measurement of lease liabilities for the nine months ended September 30, 2022 was $0.8 million.

[0001628280-22-029319:notes:104]
The weighted-average remaining lease term and discount rate as of September 30, 2022 were as follows:

[0001628280-22-029319:notes:105]
| Weighted average remaining lease term | 2.1 years |
| Weighted average discount rate | 6.95 | % |

[0001628280-22-029319:notes:106]
Future annual lease payments under non-cancelable operating leases as of September 30, 2022 were as follows (in thousands):

[0001628280-22-029319:notes:107]
| Year Ended December 31: |  |
| 2022 (remaining three months) | $ | 283 |  |
| 2023 | 1,149 |  |
| 2024 | 981 |  |
| Total future lease payments | 2,413 |  |
| Less: imputed interest | (160) |  |
| Present value of operating lease liability | $ | 2,253 |  |

[0001628280-22-029319:notes:108]
Rent expense recognized in accordance with ASC 840 for the three and nine months ended September 30, 2021 was approximately $0.3 million and $0.7 million, respectively.

[0001628280-22-029319:notes:109]
[same as prior period, unchanged from 0001628280-22-023253:notes:109]

[0001628280-22-029319:notes:110]
[same as prior period, unchanged from 0001628280-22-023253:notes:110]


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001628280-22-029319:notes:111]
[same as prior period, unchanged from 0001628280-22-023253:notes:111]

[0001628280-22-029319:notes:112]
[same as prior period, unchanged from 0001628280-22-023253:notes:112]

[0001628280-22-029319:notes:113]
|  | Allowance for Doubtful Accounts |
| Balance at December 31, 2021 | $ | (50) |  |
| Provisions | (100) |  |
| Write-offs, net of recoveries | — |  |
| Balance at September 30, 2022 | $ | (150) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001628280-22-029319:notes:114]
[same as prior period, unchanged from 0001628280-22-023253:notes:114]

[0001628280-22-029319:notes:115]
|  | September 30,2022 |  | December 31,2021 |
| Raw materials | $ | 2,617 |  |  | $ | 1,050 |  |
| Finished goods | 4,115 |  |  | 1,840 |  |
| Total | $ | 6,732 |  |  | $ | 2,890 |  |


## nhic:PrepaidExpenseAndOtherAssetsCurrentTextBlock

[0001628280-22-029319:notes:116]
[same as prior period, unchanged from 0001628280-22-023253:notes:116]

[0001628280-22-029319:notes:117]
|  | September 30,2022 |  | December 31,2021 |
| Prepaid deposits | $ | 15,397 |  |  | $ | 7,273 |  |
| Prepaid subscriptions | 573 |  |  | 411 |  |
| Current portion of net investment in sales-type leases | 340 |  |  | 206 |  |
| Prepaid insurance | 2,771 |  |  | 2,625 |  |
| Other | 1,142 |  |  | 242 |  |
| Total | $ | 20,223 |  |  | $ | 10,757 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-22-029319:notes:118]
[same as prior period, unchanged from 0001628280-22-023253:notes:118]

[0001628280-22-029319:notes:119]
|  | September 30,2022 |  | December 31,2021 |
| Computers and telecom equipment | $ | 466 |  |  | $ | 40 |  |
| Lab equipment | 690 |  |  | 568 |  |
| Furniture and fixtures | 87 |  |  | 37 |  |
| Leasehold improvements | 542 |  |  | 491 |  |
| Leased equipment | 34,888 |  |  | 20,797 |  |
| Internal-use software | 3,255 |  |  | 1,146 |  |
| Sales demo equipment | 2,085 |  |  | 1,938 |  |
| Equipment held for lease1 | 4,847 |  |  | 2,250 |  |
| Construction in progress | 180 |  |  | — |  |
|  | 47,040 |  |  | 27,267 |  |
| Less: Accumulated depreciation and amortization | (6,508) |  |  | (3,484) |  |
|  | $ | 40,532 |  |  | $ | 23,783 |  |

[0001628280-22-029319:notes:120]
[same as prior period, unchanged from 0001628280-22-023253:notes:120]

[0001628280-22-029319:notes:121]
Depreciation and amortization expense related to property and equipment was $1.4 million and $0.8 million for the three months ended September 30, 2022 and 2021, and $3.8 million and $1.9 million for the nine months ended September 30, 2022, and 2021, respectively.

[0001628280-22-029319:notes:122]
[same as prior period, unchanged from 0001628280-22-023253:notes:122]

[0001628280-22-029319:notes:123]
|  | September 30,2022 |  | December 31,2021 |
| Leased equipment | $ | 34,888 |  |  | $ | 20,797 |  |
| Accumulated depreciation | (4,868) |  |  | (2,631) |  |
| Leased equipment, net | $ | 30,020 |  |  | $ | 18,166 |  |

[0001628280-22-029319:notes:124]
Depreciation related to leased units was $1.1 million and $0.8 million during the three months ended September 30, 2022 and 2021, respectively. Depreciation expense related to leased units was $3.0 million and $1.8 million during the nine months ended September 30, 2022 and 2021, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.

[0001628280-22-029319:notes:125]
Impairment of property and equipment was $0.6 million and $1.0 million for the three and nine months ended September 30, 2022, respectively. This impairment related to Edge units and prototype versions of Express that were removed from service and retired. The Company is transitioning domestic customers to current model Express units which decreased the economic value of Edge units and Express prototypes and resulted in impairment. Impairment of property and equipment was $1.7 million and $1.7 million for the three and nine months ended September 30, 2021.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001628280-22-029319:notes:126]
[same as prior period, unchanged from 0001628280-22-023253:notes:126]

[0001628280-22-029319:notes:127]
|  | September 30,2022 |  | December 31,2021 |
| Accrued employee compensation and benefits expense | $ | 4,240 |  |  | $ | 5,692 |  |
| Accrued professional services and consulting | 1,011 |  |  | 1,114 |  |
| Accrued sales tax | 1,671 |  |  | 1,204 |  |
| Accrued property tax | 604 |  |  | 302 |  |
| Other | 1,358 |  |  | 1,239 |  |
|  | $ | 8,884 |  |  | $ | 9,551 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-22-029319:notes:128]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001628280-22-029319:notes:129]
|  | September 30,2022 |  | December 31,2021 |
| Term loans payable | $ | 9,000 |  |  | $ | 10,000 |  |
| Less: Unamortized discount | (41) |  |  | (55) |  |
|  | 8,959 |  |  | 9,945 |  |
| Less: Current portion of long-term debt | 4,000 |  |  | 2,000 |  |
| Long-term debt, net of discount | $ | 4,959 |  |  | $ | 7,945 |  |

[0001628280-22-029319:notes:130]
Term Loan Agreements

[0001628280-22-029319:notes:131]
JPMorgan Chase Bank, N.A.(“JPM”) Credit Agreement

[0001628280-22-029319:notes:132]
In December 2020, the Company entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024 and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022.

[0001628280-22-029319:notes:133]
Principal and interest on the JPM Credit Agreement is payable monthly commencing on July 1, 2022. The JPM Credit Agreement accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 2.25% or (B) 5.5%. The revolving line of credit accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 1.25% or (B) 4.5%. Upon closing, the Company issued warrants to purchase 377,837 shares of common stock to the lender with an exercise price of $0.42 per share with a fair value of $0.1 million on the date of issuance. The Company incurred debt issuance costs of $0.1 million equal to the fair value of the warrants in connection with the JPM Credit Agreement. These costs were recorded as debt discount and are amortized to interest expense, using the effective interest method, over the term of the loan. Upon the closing of the Merger, the warrants were converted into shares of the Company's common stock.

[0001628280-22-029319:notes:134]
As of September 30, 2022, the unamortized debt discount was less than $0.1 million. As of September 30, 2022, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the condensed consolidated balance sheet. Interest expense related to the JPM Credit Agreement totaled $0.2 million and $0.2 million for the three months ended September 30, 2022 and September 30, 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million in each period. Interest expense related to the JPM Credit Agreement totaled $0.5 million and $0.6 million for the nine months ended September 30, 2022 and September 30, 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million in each period. The interest rate in effect as of September 30, 2022 was 8.50% for the JPM Credit Agreement.

[0001628280-22-029319:notes:135]
The Company’s obligations under the JPM Credit Agreement are secured by a first-priority security interest in all of its assets, including intellectual property.

[0001628280-22-029319:notes:136]
As of September 30, 2022, future principal payments on long-term debt are as follows (in thousands):

[0001628280-22-029319:notes:137]
| December 31, |  |
| 2022 (remaining three months) | $ | 1,000 |  |
| 2023 | 4,000 |  |
| 2024 | 4,000 |  |
|  | $ | 9,000 |  |

[0001628280-22-029319:notes:138]
Convertible Note

[0001628280-22-029319:notes:139]
In September 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) with an investor for gross proceeds of $2.0 million with a stated interest rate of 6.0% per annum. An additional $2.0 million in gross proceeds were made available in December 31, 2020 upon achievement of the integration milestone, whereby the Company successfully created software utilizing the investor’s application programming interface. The 2020 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds of the issuance of preferred stock totaled at least $10.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2020 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $1.0 million, and the notes, with an initial carrying value of $3.0 million, and included in long-term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the

[0001628280-22-029319:notes:140]
effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the merger.

[0001628280-22-029319:notes:141]
Interest expense related to the 2020 Convertible Notes totaled less than $0.1 million and $0.3 million for the three and nine months ended September 30, 2021, respectively. No interest expense was recognized related to the 2020 Convertible Notes for the three and nine months ended September 30, 2022.

[0001628280-22-029319:notes:142]
In January and February 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80.0% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $7.0 million, and the notes, with an initial carrying value of $23.0 million, and included in long-term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the Merger.

[0001628280-22-029319:notes:143]
In June 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. This modification of the notes resulted in an extinguishment and the Company recognized a loss on extinguishment of the 2021 Convertible Notes of $11.8 million. The $26.7 million carrying value of the notes at June 21, 2021 was derecognized and replacement notes with an initial carrying value of $29.6 million were recorded. Additionally, in the extinguishment accounting, a derivative liability of $19.2 million was recognized, which represents the value of the 1,000,000 NHIC shares as well as a bifurcated embedded derivative for the conversion option.

[0001628280-22-029319:notes:144]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense).

[0001628280-22-029319:notes:145]
Interest expense related to the 2021 Convertible Notes totaled $0.1 million and $4.9 million for the three and nine months ended September 30, 2021, respectively. No interest expense was recognized related to the 2021 Convertible Notes for the three and nine months ended September 30, 2022.


## nhic:WarrantsAndRightsNoteDisclosureTextBlock

[0001628280-22-029319:notes:146]
Warrants
In January 2021, the Company granted warrants (the "Finback Common Stock Warrants") for the purchase of 2,552,913 shares of the Company's common stock at an exercise price of $0.42 per share to Finback Evolv II, LLC ("Finback"), a consulting group affiliated with one of the Company's shareholders. The Finback Common Stock Warrants vest upon meeting certain sales criteria as defined in a business development agreement (the "Finback BDA") and expire in January 2031. The Finback Common Stock Warrants are accounted for under ASC 718 Compensation – Stock Compensation as the warrants vest upon certain performance conditions being met (see Note 16).

[0001628280-22-029319:notes:147]
In connection with the closing of the Merger, the Company assumed the Public Warrants for the purchase of 14,325,000 shares of common stock at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and recorded at their fair value of $23.6 million on the date of closing of the Merger with an offset to additional paid-in-capital and are subsequently remeasured to fair value at each reporting date based on the publicly available trading price. The change in fair value of the public warrant liability of

[0001628280-22-029319:notes:148]
$(1.1) million and $4.3 million for the three and nine months ended September 30, 2022, respectively, was recognized as a component of other income (expense), net in the condensed consolidated statements of operations and comprehensive loss.

[0001628280-22-029319:notes:149]
As of September 30, 2022 and December 31, 2021, warrants to purchase the following classes of Common Stock outstanding consisted of the following in the table below:

[0001628280-22-029319:notes:150]
| September 30, 2022 |
| Issuance Date |  | ContractualTerm(in years) |  | Underlying EquityInstrument |  | Balance SheetClassification |  | Shares IssuableUpon Exerciseof Warrant |  | WeightedAverageExercise Price |
| January 13, 2021 |  | 10 |  | Common stock |  | Equity |  | 2,552,913 |  | $ | 0.42 |
| July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,994 |  | $ | 11.50 |
|  |  |  |  |  |  |  |  | 16,877,907 |  |  |

[0001628280-22-029319:notes:151]
[same as prior period, unchanged from 0001628280-22-023253:notes:150]


## nhic:TemporaryEquityDisclosureTextBlock

[0001628280-22-029319:notes:152]
[same as prior period, unchanged from 0001628280-22-023253:notes:151]

[0001628280-22-029319:notes:153]
[same as prior period, unchanged from 0001628280-22-023253:notes:152]


## nhic:CommonStockDisclosureTextBlock

[0001628280-22-029319:notes:154]
Common StockAs of September 30, 2022 and December 31, 2021, the Company had reserved 74,315,885 and 76,008,377 shares of common stock, respectively, for exercise of outstanding stock options, granting of awards under the Company’s 2021 Equity Incentive Plan and 2013 Equity Incentive Plan (see Note 16) and the exercise of outstanding warrants (see Note 13).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-22-029319:notes:155]
Stock-Based Compensation
2021 Incentive Award Plan

[0001628280-22-029319:notes:156]
The Company’s 2021 Incentive Award Plan (the “2021 Plan”) provides for the Company to grant incentive stock options or nonqualified stock options, restricted stock awards, restricted stock units, performance stock units, and other stock-based awards to employees, officers, directors and non-employees of the Company. A total of 21,177,295 shares of common stock may be issued under the 2021 Plan. As of September 30, 2022 and December 31, 2021, 11,287,459 and 19,511,916 shares, respectively, remained available for future grant under the 2021 Plan. Shares, units, and options that are

[0001628280-22-029319:notes:157]
expired, forfeited, canceled or otherwise terminated without having been fully exercised will be available for future grant under the 2021 Plan. In addition, shares of common stock that are tendered to the Company by a participant to exercise an award are added to the number of shares of common stock available for future grants.

[0001628280-22-029319:notes:158]
[same as prior period, unchanged from 0001628280-22-023253:notes:157]

[0001628280-22-029319:notes:159]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the nine months ended September 30, 2022 and 2021:

[0001628280-22-029319:notes:160]
|  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |
| Risk-free interest rate | 1.6 | % |  | 0.7 | % |
| Expected term (in years) | 6.1 |  | 6.0 |
| Expected volatility | 75.0 | % |  | 31.4 | % |
| Expected dividend yield | 0.0 | % |  | 0.0 | % |

[0001628280-22-029319:notes:161]
[same as prior period, unchanged from 0001628280-22-023253:notes:160]

[0001628280-22-029319:notes:162]
|  | Number ofShares |  | WeightedAverageExercise Price |  | WeightedAverageRemainingContractual Term |  | AggregateIntrinsic Value |
|  |  |  |  |  | (in years) |  |  |
| Outstanding as of December 31, 2021 | 20,769,130 |  | $ | 0.39 |  |  |  |  |  |
| Granted | 2,262,925 |  | 3.49 |  |  |  |  |  |
| Exercised | (1,278,014) |  | 0.43 |  |  |  |  |  |
| Forfeited | (726,201) |  | 0.42 |  |  |  |  |  |
| Outstanding as of September 30, 2022 | 21,027,840 |  | 0.72 |  |  | 7.3 |  | $ | 32,445 |  |
| Vested and expected to vest as of September 30, 2022 | 21,027,840 |  | $ | 0.72 |  |  | 7.3 |  | $ | 32,445 |  |
| Options exercisable as of September 30, 2022 | 13,190,147 |  | $ | 0.38 |  |  | 6.7 |  | $ | 22,981 |  |

[0001628280-22-029319:notes:163]
The weighted average exercise price of the stock options granted in 2022 in the table above has been updated to align with the terms of the stock option awards.

[0001628280-22-029319:notes:164]
[same as prior period, unchanged from 0001628280-22-023253:notes:162]

[0001628280-22-029319:notes:165]
[same as prior period, unchanged from 0001628280-22-023253:notes:163]

[0001628280-22-029319:notes:166]
[same as prior period, unchanged from 0001628280-22-023253:notes:164]

[0001628280-22-029319:notes:167]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2021 | 1,951,924 |  |  | $ | 6.76 |  |
| Granted | 7,136,963 |  |  | 3.30 |  |
| Vested | (414,478) |  |  | 7.02 |  |
| Cancelled | (1,338,230) |  |  | 5.24 |  |
| Outstanding as of September 30, 2022 | 7,336,179 |  |  | $ | 3.65 |  |

[0001628280-22-029319:notes:168]
During the three and nine months ended September 30, 2022, the aggregate grant-date fair value of restricted stock units issued under the 2021 Plan was $0.6 million and $23.5 million, respectively. Restricted stock units generally vest ratably over a three year period subject to the grantee's continued service through the applicable vesting date.

[0001628280-22-029319:notes:169]
[same as prior period, unchanged from 0001628280-22-023253:notes:167]

[0001628280-22-029319:notes:170]
[same as prior period, unchanged from 0001628280-22-023253:notes:168]

[0001628280-22-029319:notes:171]
|  | Number ofShares |  | Grant Date FairValue |
| December 31, 2021 | — |  |  | $ | — |  |
| Granted | 947,000 |  |  | 2.65 |  |
| Vested | — |  |  | — |  |
| Canceled | (58,000) |  |  | 2.65 |  |
| September 30, 2022 | 889,000 |  |  | $ | 2.65 |  |

[0001628280-22-029319:notes:172]
During the three and nine months ended September 30, 2022, the aggregate grant-date value of performance stock units issued under the 2021 Plan was less than $0.1 million and $2.5 million, respectively. Based upon the terms of the award agreements, 50% of the applicable units shall vest on January 1, 2023 and 50% on January 1, 2024, provided that the Company has achieved its annual bookings goal for fiscal year 2022 and subject to the grantee’s continued service through the applicable vesting date.

[0001628280-22-029319:notes:173]
[same as prior period, unchanged from 0001628280-22-023253:notes:171]

[0001628280-22-029319:notes:174]
As of September 30, 2022 and December 31, 2021, 3,435,748 shares of the Company’s common stock remained available for future issuance under the 2021 Employee Stock Purchase Plan. The Company’s board of directors may from time to time grant or provide for the grant to eligible employees of options to purchase common stock under the 2021 Employee Stock Purchase Plan during a specific offering period. As of September 30, 2022, no offerings have been approved.

[0001628280-22-029319:notes:175]
Finback Common Stock Warrants

[0001628280-22-029319:notes:176]
The Company utilized a Black-Scholes pricing model to determine the grant-date fair value of the Finback Common Stock Warrants. The assumptions used are presented in the following table:

[0001628280-22-029319:notes:177]
[same as prior period, unchanged from 0001628280-22-023253:notes:176]

[0001628280-22-029319:notes:178]
On the date of issuance, the total value of the Finback Common Stock Warrants was $19.5 million.

[0001628280-22-029319:notes:179]
As of September 30, 2022, 700,575 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $1.2 million. The remaining 1,852,338 Finback Common Stock Warrants are unvested and have a total unrecognized grant date fair value of $14.1 million. As of September 30, 2022, none of the Finback Common Stock Warrants had been exercised. The Company recognizes compensation expense for the Finback Common Stock Warrants when the warrants become vested based on meeting the certain sales criteria. During the three and nine months ended September 30, 2022, the Company recorded $1.3 million and $2.1 million, respectively, of stock-based compensation expense within sales and marketing expense related to the 2021 Finback common stock warrants.

[0001628280-22-029319:notes:180]
[same as prior period, unchanged from 0001628280-22-023253:notes:179]

[0001628280-22-029319:notes:181]
[same as prior period, unchanged from 0001628280-22-023253:notes:180]

[0001628280-22-029319:notes:182]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of revenue | $ | 227 |  | $ | 66 |  | $ | 615 |  | $ | 91 |
| Research and development | 1,664 |  | 319 |  | 3,143 |  | 396 |
| Sales and marketing | 2,482 |  | 3,226 |  | 6,310 |  | 4,305 |
| General and administrative | 2,152 |  | 1,044 |  | 5,445 |  | 1,240 |
| Total stock-based compensation expense | $ | 6,525 |  | $ | 4,655 |  | $ | 15,513 |  | $ | 6,032 |

[0001628280-22-029319:notes:183]
[same as prior period, unchanged from 0001628280-22-023253:notes:182]

[0001628280-22-029319:notes:184]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Stock options | $ | 458 |  | $ | 123 |  | $ | 1,151 |  | $ | 565 |
| Earn-out shares | 1,832 |  | 3,269 |  | 5,435 |  | 3,269 |
| Warrants | 1,285 |  | 1,012 |  | 2,126 |  | 1,806 |
| RSUs and PSUs | 2,950 |  | 251 |  | 6,801 |  | 392 |
| Total stock-based compensation expense | $ | 6,525 |  | $ | 4,655 |  | $ | 15,513 |  | $ | 6,032 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-22-029319:notes:185]
Income TaxesDuring the three and nine months ended September 30, 2022 and 2021, the Company did not record income tax provisions or income tax benefits due to the net loss before income taxes expected to be incurred for the year ending 
December 31, 2022, as well as the Company’s continued maintenance of a full valuation allowance against its net deferred tax assets, and the net loss before income taxes incurred for the year ended December 31, 2021.

[0001628280-22-029319:notes:186]
The Company’s tax provision and the resulting effective tax rate for interim periods is determined based upon its estimated annual effective tax rate (“AETR”), adjusted for the effect of discrete items arising in that quarter. The impact of such inclusions could result in a higher or lower effective tax rate during a particular quarter, based upon the mix and timing of actual earnings or losses versus annual projections. In each quarter, the Company updates its estimate of the annual effective tax rate, and if the estimated annual tax rate changes, a cumulative adjustment is made in that quarter.


## us-gaap:EarningsPerShareTextBlock

[0001628280-22-029319:notes:187]
[same as prior period, unchanged from 0001628280-22-023253:notes:185]

[0001628280-22-029319:notes:188]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) attributable to common stockholders – basic | $ | (18,615) |  | $ | 20,807 |  |  | $ | (58,102) |  |  | $ | (15,676) |  |
| Change in fair value for warrant liability | — |  | (42) |  | — |  | — |
| Interest to convertible notes | — |  | 123 |  | — |  | — |
| Loss on extinguishment of debt | — |  | 865 |  | — |  | — |
| Change in fair value of derivative liability | — |  | (475) |  | — |  | — |
| Net income (loss) attributable to common stockholders – diluted | $ | (18,615) |  | $ | 21,278 |  |  | $ | (58,102) |  |  | $ | (15,676) |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding – basic | 144,117,273 |  | 119,745,196 |  | 143,522,555 |  | 47,772,253 |
| Weighted average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Effect of potentially dilutive convertible preferred stock | — |  | 14,065,012 |  | — |  | — |
| Effect of potentially dilutive warrants | — |  | 423,271 |  | — |  | — |
| Effect of potentially dilutive stock options | — |  | 19,696,440 |  | — |  | — |
| Effect of potentially dilutive restricted stock units | — |  | 6,517 |  | — |  | — |
| Total potentially dilutive securities | — |  | 34,191,240 |  | — |  | — |
| Weighted average common shares outstanding — diluted | 144,117,273 |  | 153,936,436 |  | 143,522,555 |  | 47,772,253 |
| Net income (loss) per share attributable to common stockholders - basic | $ | (0.13) |  | $ | 0.17 |  | $ | (0.40) |  | $ | (0.33) |
| Net income (loss) per share attributable to common stockholders - diluted | $ | (0.13) |  | $ | 0.14 |  | $ | (0.40) |  | $ | (0.33) |

[0001628280-22-029319:notes:189]
[same as prior period, unchanged from 0001628280-22-023253:notes:187]

[0001628280-22-029319:notes:190]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Options issued and outstanding | 21,027,840 |  | 1,589,357 |  |  | 21,027,840 |  | 21,285,797 |  |
| Public Warrants to purchase common stock | 14,324,994 |  |  | 14,325,000 |  |  | 14,324,994 |  |  | 14,325,000 |  |
| Warrants to purchase common stock (Finback)*** | 2,552,913 |  |  | 2,214,879 |  |  | 2,552,913 |  |  | 2,552,913 |  |
| Unvested restricted stock units | 7,336,179 |  |  | 1,664,567 |  |  | 7,336,179 |  |  | 1,671,084 |  |
| Unvested performance stock units | 889,000 |  |  | — |  |  | 889,000 |  |  | — |  |
| Earn-out shares** | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |
| Contingently issuable common stock** | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |
| Convertible notes (as converted to common stock)* | — |  |  | 5,408,672 |  |  | — |  |  | 5,408,672 |  |
|  | 63,028,426 |  |  | 42,099,975 |  |  | 63,028,426 |  |  | 62,140,966 |  |

[0001628280-22-029319:notes:191]
[same as prior period, unchanged from 0001628280-22-023253:notes:189]

[0001628280-22-029319:notes:192]
**Issuance of Earn-out shares and Contingently issuable common stock are contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period
***Includes 700,575 vested warrants and 1,852,338 unvested warrants as of September 30, 2022


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-22-029319:notes:193]
Related Party Transactions
Nonrecourse Promissory Note with Officer

[0001628280-22-029319:notes:194]
In August 2020, the Company entered into a $0.4 million promissory note with an officer with the proceeds being used to exercise options for 1,469,366 shares of common stock at a price of $0.24 per share. The promissory note bore interest at the Wall Street Journal Prime Rate and was secured by the underlying shares of common stock that were issued upon the exercise of the stock options. The promissory note was treated as nonrecourse as the loan was only secured by the common stock issued from the exercise of the stock options. As such, (i) the underlying stock option grant was still considered to be outstanding and the shares of common stock were not considered issued and outstanding for accounting purposes until the loan was repaid in full or otherwise forgiven and (ii) no receivable was recorded for the promissory note on the Company’s condensed consolidated balance sheets. As such, the promissory note effectively extended the maturity date of the option grant for the life of the loan, this change is treated as a stock option modification. The incremental fair value from the stock option modification was deemed immaterial. The interest on this nonrecourse loan is also considered nonrecourse. As the Company has no intent to collect interest, no accrued interest was recorded.

[0001628280-22-029319:notes:195]
In June 2021, the Company agreed to repurchase 43,665 shares of common stock valued at $8.05 per share of common stock held by the officer of the Company. In exchange for the repurchase of the common stock by the Company, the $0.4 million promissory note held by the officer was considered repaid in full.

[0001628280-22-029319:notes:196]
Business Development Agreement with Finback

[0001628280-22-029319:notes:197]
In January 2021, the Company granted the Finback Common Stock Warrants. During the three months ended September 30, 2022 and 2021, the Company recorded $1.3 million and $1.0 million, respectively, of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants. During the nine months ended September 30, 2022 and 2021, the Company recorded $2.1 million and $1.8 million, respectively, of stock-based compensation expense within sales and marketing expense for the Finback Common Stock Warrants.

[0001628280-22-029319:notes:198]
In connection with the Merger and pursuant to the Merger Agreement, Finback is entitled to receive a proportional share of earn-out shares as an earn-out service provider, based upon the remaining unvested warrants as of the Merger

[0001628280-22-029319:notes:199]
Date. As of September 30, 2022, Finback can earn 284,511 earn-out shares subject to stock-based compensation, based on the achievement of certain milestones. During the three and nine months ended September 30, 2021, $1.5 million stock-based compensation expense was recorded within sales and marketing expense for the earn-out shares allocated to Finback. During the three and nine months ended September 30, 2022, no stock-based compensation expense was recorded within sales and marketing expense for the earn-out shares allocated to Finback.

[0001628280-22-029319:notes:200]
Original Equipment Manufacturer Partnership Agreement with Motorola

[0001628280-22-029319:notes:201]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement (the “Distribution Agreement”) with Motorola, an investor in the Company. In June 2021, the partnership agreement was amended by the Amended and Restated Distribution Agreement (the “Amended and Restated Distribution Agreement”). Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended September 30, 2022 and 2021, revenue from sales to Motorola was  $2.3 million and less than $0.1 million, respectively. During the nine months ended September 30, 2022 and 2021, revenue from sales to Motorola was $5.0 million and less than $0.1 million, respectively. As of September 30, 2022 and December 31, 2021, accounts receivable related to Motorola’s distributor services was $4.1 million and $1.2 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-22-029319:notes:202]
Commitments and Contingencies
Indemnification Agreements

[0001628280-22-029319:notes:203]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of September 30, 2022 or December 31, 2021.

[0001628280-22-029319:notes:204]
Legal Proceedings

[0001628280-22-029319:notes:205]
The Company is not a party to any litigation and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.


## us-gaap:ErrorCorrectionTextBlock

[0001628280-22-029319:notes:206]
Revision of Prior Period Financial StatementsAs discussed in Note 1, in preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified errors in its previously issued financial statements whereby (a) certain expenses that were cost of subscription revenue related and cost of service revenue related were inaccurately classified as sales and marketing expenses on the consolidated statements of operations and comprehensive loss, (b) certain equipment under lease or held for lease was inaccurately classified as inventory on the consolidated balance sheets and a portion of the cash outflows related to the equipment under lease or held for lease were misclassified between operating and investing cash flows on the consolidated statements of cash flows, and (c) the vesting of warrants related to the Business Development Agreement disclosed in Note 16 were not accounted for accurately. The identified errors impacted the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022. The Company has made adjustments to the prior period amounts presented in these financial statements accordingly. Additionally, the Company has made adjustments to correct for other previously identified immaterial errors. The Company evaluated the errors and determined that the related impacts were not material to any previously issued annual or interim financial statements. The impact of the revisions is as follows (in thousands):
Revised Condensed Consolidated Balance Sheets

[0001628280-22-029319:notes:207]
|  | December 31, 2021 |
|  | As Previously Reported | Adjustment | As Revised |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 307,492 |  | $ | — |  | $ | 307,492 |  |
| Restricted cash | 400 |  | — |  | 400 |  |
| Accounts receivable, net | 6,477 |  | — |  | 6,477 |  |
| Inventory | 5,140 |  | (2,250) |  | 2,890 |  |
| Current portion of contract assets | 1,459 |  | — |  | 1,459 |  |
| Current portion of commission asset | 1,645 |  | — |  | 1,645 |  |
| Prepaid expenses and other current assets | 11,047 |  | (290) |  | 10,757 |  |
| Total current assets | 333,660 |  | (2,540) |  | 331,120 |  |
| Restricted cash, noncurrent | 275 |  | — |  | 275 |  |
| Contract assets, noncurrent | 3,418 |  | — |  | 3,418 |  |
| Commission asset, noncurrent | 3,719 |  | — |  | 3,719 |  |
| Property and equipment, net | 21,592 |  | 2,191 |  | 23,783 |  |
| Other assets | 401 |  | 141 |  | 542 |  |
| Total assets | $ | 363,065 |  | $ | (208) |  | $ | 362,857 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 6,363 |  | $ | (318) |  | $ | 6,045 |  |
| Accrued expenses and other current liabilities | 9,183 |  | 368 |  | 9,551 |  |
| Current portion of deferred revenue | 6,690 |  | (91) |  | 6,599 |  |
| Current portion of deferred rent | 135 |  | — |  | 135 |  |
| Current portion of long-term debt | 2,000 |  | — |  | 2,000 |  |
| Total current liabilities | 24,371 |  | (41) |  | 24,330 |  |
| Deferred revenue, noncurrent | 2,475 |  | — |  | 2,475 |  |
| Deferred rent, noncurrent | 333 |  | — |  | 333 |  |
| Long-term debt, noncurrent | 7,945 |  | — |  | 7,945 |  |
| Contingent earn-out liability | 20,809 |  | 397 |  | 21,206 |  |
| Contingently issuable common stock liability | 5,264 |  | — |  | 5,264 |  |
| Public warrant liability | 11,030 |  | — |  | 11,030 |  |
| Total liabilities | 72,227 |  | 356 |  | 72,583 |  |
| Stockholders’ equity: |  |  |  |
| Convertible preferred stock | — |  | — |  | — |  |
| Common stock | 14 |  | — |  | 14 |  |
| Additional paid-in capital | 395,563 |  | 501 |  | 396,064 |  |
| Accumulated deficit | (104,739) |  | (1,065) |  | (105,804) |  |
| Stockholders’ equity | 290,838 |  | (564) |  | 290,274 |  |
| Total liabilities and stockholders’ equity | $ | 363,065 |  | $ | (208) |  | $ | 362,857 |  |

[0001628280-22-029319:notes:208]
|  | December 31, 2020 |
|  | As Previously Reported | Adjustment | As Revised |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 4,704 |  | $ | — |  | $ | 4,704 |  |
| Accounts receivable, net | 1,401 |  | — |  | 1,401 |  |
| Inventory | 2,742 |  | (1,156) |  | 1,586 |  |
| Current portion of commission asset | 562 |  | — |  | 562 |  |
| Prepaid expenses and other current assets | 900 |  | 641 |  | 1,541 |  |
| Total current assets | 10,309 |  | (515) |  | 9,794 |  |
| Commission asset, noncurrent | 1,730 |  | — |  | 1,730 |  |
| Property and equipment, net | 9,316 |  | 752 |  | 10,068 |  |
| Other assets | — |  | 173 |  | 173 |  |
| Total assets | $ | 21,355 |  | $ | 410 |  | $ | 21,765 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 4,437 |  | $ | — |  | $ | 4,437 |  |
| Accrued expenses and other current liabilities | 3,727 |  | 484 |  | 4,211 |  |
| Current portion of deferred revenue | 3,717 |  | 45 |  | 3,762 |  |
| Current portion of deferred rent | 11 |  | — |  | 11 |  |
| Current portion of financing obligations | 227 |  | — |  | 227 |  |
| Total current liabilities | 12,119 |  | 529 |  | 12,648 |  |
| Deferred revenue, noncurrent | 480 |  | — |  | 480 |  |
| Financing obligation, noncurrent | 132 |  | — |  | 132 |  |
| Long-term debt, noncurrent | 16,432 |  | — |  | 16,432 |  |
| Derivative Liability | 1,000 |  | — |  | 1,000 |  |
| Common stock warrant liability | 1 |  | — |  | 1 |  |
| Total liabilities | 30,164 |  | 529 |  | 30,693 |  |
| Stockholders’ equity: |  |  |  |
| Convertible preferred stock | 75,877 |  | — |  | 75,877 |  |
| Common stock | 1 |  | — |  | 1 |  |
| Additional paid-in capital | 9,194 |  | 916 |  | 10,110 |  |
| Accumulated deficit | (93,881) |  | (1,035) |  | (94,916) |  |
| Stockholders’ equity | (84,686) |  | (119) |  | (84,805) |  |
| Total liabilities and stockholders’ equity | $ | 21,355 |  | $ | 410 |  | $ | 21,765 |  |

[0001628280-22-029319:notes:209]
Revised Condensed Consolidated Statements of Operations and Comprehensive Loss

[0001628280-22-029319:notes:210]
|  | Three Months EndedMarch 31, 2022 |
|  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |
| Product revenue | $ | 5,194 |  |  | $ | — |  |  | $ | 5,194 |  |
| Subscription revenue | 3,020 |  |  | (16) |  |  | 3,004 |  |
| Service revenue | 501 |  |  | 11 |  |  | 512 |  |
| Total revenue | 8,715 |  |  | (5) |  |  | 8,710 |  |
| Cost of revenue: |  |  |  |  |  |
| Cost of product revenue | 5,576 |  |  | (370) |  |  | 5,206 |  |
| Cost of subscription revenue | 1,065 |  |  | 477 |  |  | 1,542 |  |
| Cost of service revenue | 448 |  |  | 617 |  |  | 1,065 |  |
| Total cost of revenue | 7,089 |  |  | 724 |  |  | 7,813 |  |
| Gross profit | 1,626 |  |  | (729) |  |  | 897 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 4,286 |  |  | (111) |  |  | 4,175 |  |
| Sales and marketing expense | 12,053 |  |  | (2,381) |  |  | 9,672 |  |
| General and administrative | 11,093 |  |  | (276) |  |  | 10,817 |  |
| Loss from impairment of property and equipment | 96 |  |  | — |  |  | 96 |  |
| Total operating expenses | 27,528 |  |  | (2,768) |  |  | 24,760 |  |
| Loss from operations | (25,902) |  |  | 2,039 |  |  | (23,863) |  |
| Other income (expense), net: |  |  |  |  |  |
| Interest expense | (142) |  |  | — |  |  | (142) |  |
| Interest income | 209 |  |  | (141) |  |  | 68 |  |
| Change in fair value of contingent earn-out liability | 4,226 |  |  | (1,148) |  |  | 3,078 |  |
| Change in fair value of contingently issuable common stock liability | 1,472 |  |  | — |  |  | 1,472 |  |
| Change in fair value of public warrant liability | 5,586 |  |  | — |  |  | 5,586 |  |
| Total other income (expense), net | 11,351 |  |  | (1,289) |  |  | 10,062 |  |
| Net loss | $ | (14,551) |  |  | $ | 750 |  |  | $ | (13,801) |  |
| Weighted average common shares outstanding - basic and diluted | 142,878,406 |  |  | — |  |  | 142,878,406 |  |
| Net loss per share - basic and diluted | $ | (0.10) |  |  | $ | — |  |  | $ | (0.10) |  |

[0001628280-22-029319:notes:211]
|  | Year EndedDecember 31, 2021 |
|  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |
| Product revenue | $ | 13,917 |  |  | $ | (286) |  |  | $ | 13,631 |  |
| Subscription revenue | 7,855 |  |  | (52) |  |  | 7,803 |  |
| Service revenue | 1,920 |  |  | 39 |  |  | 1,959 |  |
| Total revenue | 23,692 |  |  | (299) |  |  | 23,393 |  |
| Cost of revenue: |  |  |  |  |  |
| Cost of product revenue | 12,471 |  |  | (192) |  |  | 12,279 |  |
| Cost of subscription revenue | 3,644 |  |  | 857 |  |  | 4,501 |  |
| Cost of service revenue | 936 |  |  | 1,648 |  |  | 2,584 |  |
| Total cost of revenue | 17,051 |  |  | 2,313 |  |  | 19,364 |  |
| Gross profit | 6,641 |  |  | (2,612) |  |  | 4,029 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 11,416 |  |  | 42 |  |  | 11,458 |  |
| Sales and marketing expense | 27,404 |  |  | (1,305) |  |  | 26,099 |  |
| General and administrative | 20,013 |  |  | (144) |  |  | 19,869 |  |
| Loss from impairment of property and equipment | 1,869 |  |  | — |  |  | 1,869 |  |
| Total operating expenses | 60,702 |  |  | (1,407) |  |  | 59,295 |  |
| Loss from operations | (54,061) |  |  | (1,205) |  |  | (55,266) |  |
| Other income (expense), net: |  |  |  |  |  |
| Interest expense, net | (6,095) |  |  | 27 |  |  | (6,068) |  |
| Interest income | — |  |  | — |  |  | — |  |
| Loss on disposal of property and equipment | (617) |  |  | — |  |  | (617) |  |
| Loss on extinguishment of debt | (12,685) |  |  | — |  |  | (12,685) |  |
| Change in fair value of derivative liability | (1,745) |  |  | — |  |  | (1,745) |  |
| Change in fair value of contingent earn-out liability | 46,212 |  |  | 1,148 |  |  | 47,360 |  |
| Change in fair value of contingently issuable common stock liability | 6,406 |  |  | — |  |  | 6,406 |  |
| Change in fair value of public warrant liability | 12,606 |  |  | — |  |  | 12,606 |  |
| Change in fair value of common stock warrant liability | (879) |  |  | — |  |  | (879) |  |
| Total other income (expense), net | 43,203 |  |  | 1,175 |  |  | 44,378 |  |
| Net loss | $ | (10,858) |  |  | $ | (30) |  |  | $ | (10,888) |  |
| Weighted average common shares outstanding - basic and diluted | 71,662,694 |  |  | — |  |  | 71,662,694 |  |
| Net loss per share - basic and diluted | $ | (0.15) |  |  | $ | — |  |  | $ | (0.15) |  |

[0001628280-22-029319:notes:212]
|  | Three Months EndedSeptember 30, 2021 |  | Nine Months EndedSeptember 30, 2021 |
|  | As Previously Reported |  | Adjustment |  | As Revised |  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 5,345 |  |  | $ | 50 |  |  | $ | 5,395 |  |  | $ | 10,299 |  |  | $ | (20) |  |  | $ | 10,279 |  |
| Subscription revenue | 2,305 |  |  | 7 |  |  | 2,312 |  |  | 5,118 |  |  | (58) |  |  | 5,060 |  |
| Service revenue | 717 |  |  | — |  |  | 717 |  |  | 1,429 |  |  | 27 |  |  | 1,456 |  |
| Total revenue | 8,367 |  |  | 57 |  |  | 8,424 |  |  | 16,846 |  |  | (51) |  |  | 16,795 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | 2,933 |  |  | 34 |  |  | 2,967 |  |  | 7,237 |  |  | 149 |  |  | 7,386 |  |
| Cost of subscription revenue | 1,086 |  |  | 191 |  |  | 1,277 |  |  | 2,542 |  |  | 538 |  |  | 3,080 |  |
| Cost of service revenue | 192 |  |  | 521 |  |  | 713 |  |  | 732 |  |  | 953 |  |  | 1,685 |  |
| Total cost of revenue | 4,211 |  |  | 746 |  |  | 4,957 |  |  | 10,511 |  |  | 1,640 |  |  | 12,151 |  |
| Gross profit | 4,156 |  |  | (689) |  |  | 3,467 |  |  | 6,335 |  |  | (1,691) |  |  | 4,644 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 3,641 |  |  | (29) |  |  | 3,612 |  |  | 8,330 |  |  | 69 |  |  | 8,399 |  |
| Sales and marketing expense | 8,510 |  |  | 1,514 |  |  | 10,024 |  |  | 17,284 |  |  | 472 |  |  | 17,756 |  |
| General and administrative | 6,983 |  |  | 552 |  |  | 7,535 |  |  | 11,162 |  |  | 896 |  |  | 12,058 |  |
| Loss from impairment of property and equipment | 1,656 |  |  | — |  |  | 1,656 |  |  | 1,656 |  |  | — |  |  | 1,656 |  |
| Total operating expenses | 20,790 |  |  | 2,037 |  |  | 22,827 |  |  | 38,432 |  |  | 1,437 |  |  | 39,869 |  |
| Loss from operations | (16,634) |  |  | (2,726) |  |  | (19,360) |  |  | (32,097) |  |  | (3,128) |  |  | (35,225) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (286) |  |  | (9) |  |  | (295) |  |  | (5,988) |  |  | 36 |  |  | (5,952) |  |
| Other expense, net | (669) |  |  | — |  |  | (669) |  |  | (669) |  |  | — |  |  | (669) |  |
| Loss on extinguishment of debt | (865) |  |  | — |  |  | (865) |  |  | (12,685) |  |  | — |  |  | (12,685) |  |
| Change in fair value of derivative liability | 475 |  |  | — |  |  | 475 |  |  | (1,745) |  |  | — |  |  | (1,745) |  |
| Change in fair value of contingent earn-out liability | 31,818 |  |  | 791 |  |  | 32,609 |  |  | 31,818 |  |  | 791 |  |  | 32,609 |  |
| Change in fair value of contingently issuable common stock liability | 5,718 |  |  | — |  |  | 5,718 |  |  | 5,718 |  |  | — |  |  | 5,718 |  |
| Change in fair value of public warrant liability | 3,152 |  |  | — |  |  | 3,152 |  |  | 3,152 |  |  | — |  |  | 3,152 |  |
| Change in fair value of common stock warrant liability | 42 |  |  | — |  |  | 42 |  |  | (879) |  |  | — |  |  | (879) |  |
| Total other income (expense), net | 39,385 |  |  | 782 |  |  | 40,167 |  |  | 18,722 |  |  | 827 |  |  | 19,549 |  |
| Net income (loss) attributable to common stockholders - basic | $ | 22,751 |  |  | $ | (1,944) |  |  | $ | 20,807 |  |  | $ | (13,375) |  |  | $ | (2,301) |  |  | $ | (15,676) |  |
| Net income (loss) attributable to common stockholders - diluted | $ | 23,222 |  |  | $ | (1,944) |  |  | $ | 21,278 |  |  | $ | (13,375) |  |  | $ | (2,301) |  |  | $ | (15,676) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 119,745,196 |  |  | — |  |  | 119,745,196 |  |  | 47,772,253 |  |  | — |  |  | 47,772,253 |  |
| Diluted | 153,867,300 |  |  | 69,136 |  |  | 153,936,436 |  |  | 47,772,253 |  |  | — |  |  | 47,772,253 |  |
| Net income (loss) per share |
| Basic | $ | 0.19 |  |  | $ | (0.02) |  |  | $ | 0.17 |  |  | $ | (0.28) |  |  | $ | (0.05) |  |  | $ | (0.33) |  |
| Diluted | $ | 0.15 |  |  | $ | (0.01) |  |  | $ | 0.14 |  |  | $ | (0.28) |  |  | $ | (0.05) |  |  | $ | (0.33) |  |

[0001628280-22-029319:notes:213]
|  | Three Months EndedJune 30, 2021 |  | Six Months EndedJune 30, 2021 |
|  | As Previously Reported |  | Adjustment |  | As Revised |  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 2,452 |  |  | $ | 165 |  |  | $ | 2,617 |  |  | $ | 4,954 |  |  | $ | (70) |  |  | $ | 4,884 |  |
| Subscription revenue | 1,513 |  |  | 8 |  |  | 1,521 |  |  | 2,813 |  |  | (65) |  |  | 2,748 |  |
| Service revenue | 515 |  |  | 25 |  |  | 540 |  |  | 712 |  |  | 27 |  |  | 739 |  |
| Total revenue | 4,480 |  |  | 198 |  |  | 4,678 |  |  | 8,479 |  |  | (108) |  |  | 8,371 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | 2,075 |  |  | 128 |  |  | 2,203 |  |  | 4,304 |  |  | 115 |  |  | 4,419 |  |
| Cost of subscription revenue | 861 |  |  | 199 |  |  | 1,060 |  |  | 1,456 |  |  | 347 |  |  | 1,803 |  |
| Cost of service revenue | 413 |  |  | 274 |  |  | 687 |  |  | 540 |  |  | 432 |  |  | 972 |  |
| Total cost of revenue | 3,349 |  |  | 601 |  |  | 3,950 |  |  | 6,300 |  |  | 894 |  |  | 7,194 |  |
| Gross profit | 1,131 |  |  | (403) |  |  | 728 |  |  | 2,179 |  |  | (1,002) |  |  | 1,177 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,077 |  |  | (30) |  |  | 1,047 |  |  | 4,689 |  |  | 98 |  |  | 4,787 |  |
| Sales and marketing expense | 5,090 |  |  | 34 |  |  | 5,124 |  |  | 8,774 |  |  | (1,042) |  |  | 7,732 |  |
| General and administrative | 1,280 |  |  | 191 |  |  | 1,471 |  |  | 4,179 |  |  | 344 |  |  | 4,523 |  |
| Total operating expenses | 7,447 |  |  | 195 |  |  | 7,642 |  |  | 17,642 |  |  | (600) |  |  | 17,042 |  |
| Loss from operations | (6,316) |  |  | (598) |  |  | (6,914) |  |  | (15,463) |  |  | (402) |  |  | (15,865) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (3,255) |  |  | (8) |  |  | (3,263) |  |  | (5,702) |  |  | 45 |  |  | (5,657) |  |
| Interest income | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Loss on extinguishment of debt | (11,820) |  |  | — |  |  | (11,820) |  |  | (11,820) |  |  | — |  |  | (11,820) |  |
| Change in fair value of derivative liability | (795) |  |  | — |  |  | (795) |  |  | (2,220) |  |  | — |  |  | (2,220) |  |
| Change in fair value of common stock warrant liability | (185) |  |  | — |  |  | (185) |  |  | (921) |  |  | — |  |  | (921) |  |
| Total other income (expense), net | (16,055) |  |  | (8) |  |  | (16,063) |  |  | (20,663) |  |  | 45 |  |  | (20,618) |  |
| Net loss | $ | (22,371) |  |  | $ | (606) |  |  | $ | (22,977) |  |  | $ | (36,126) |  |  | $ | (357) |  |  | $ | (36,483) |  |
| Weighted average common shares outstanding - basic and diluted | 11,922,270 |  |  | — |  |  | 11,922,270 |  |  | 11,186,204 |  |  | — |  |  | 11,186,204 |  |
| Net loss per share - basic and diluted | $ | (1.88) |  |  | $ | (0.05) |  |  | $ | (1.93) |  |  | $ | (3.23) |  |  | $ | (0.03) |  |  | $ | (3.26) |  |

[0001628280-22-029319:notes:214]
|  | Three Months EndedMarch 31, 2021 |
|  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |
| Product revenue | $ | 2,502 |  |  | $ | (235) |  |  | $ | 2,267 |  |
| Subscription revenue | 1,300 |  |  | (73) |  |  | 1,227 |  |
| Service revenue | 197 |  |  | 2 |  |  | 199 |  |
| Total revenue | 3,999 |  |  | (306) |  |  | 3,693 |  |
| Cost of revenue: |  |  |  |  |  |
| Cost of product revenue | 2,229 |  |  | (13) |  |  | 2,216 |  |
| Cost of subscription revenue | 595 |  |  | 148 |  |  | 743 |  |
| Cost of service revenue | 127 |  |  | 158 |  |  | 285 |  |
| Total cost of revenue | 2,951 |  |  | 293 |  |  | 3,244 |  |
| Gross profit | 1,048 |  |  | (599) |  |  | 449 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 3,612 |  |  | 128 |  |  | 3,740 |  |
| Sales and marketing expense | 3,684 |  |  | (1,076) |  |  | 2,608 |  |
| General and administrative | 2,899 |  |  | 153 |  |  | 3,052 |  |
| Total operating expenses | 10,195 |  |  | (795) |  |  | 9,400 |  |
| Loss from operations | (9,147) |  |  | 196 |  |  | (8,951) |  |
| Other income (expense), net: |  |  |  |  |  |
| Interest expense, net | (2,447) |  |  | 53 |  |  | (2,394) |  |
| Change in fair value of derivative liability | (1,425) |  |  | — |  |  | (1,425) |  |
| Change in fair value of common stock warrant liability | (736) |  |  | — |  |  | (736) |  |
| Total other income (expense), net | (4,608) |  |  | 53 |  |  | (4,555) |  |
| Net loss | $ | (13,755) |  |  | $ | 249 |  |  | $ | (13,506) |  |
| Weighted average common shares outstanding - basic and diluted | 10,443,323 |  |  | — |  |  | 10,443,323 |  |
| Net loss per share - basic and diluted | $ | (1.32) |  |  | $ | 0.03 |  |  | $ | (1.29) |  |

[0001628280-22-029319:notes:215]
|  | Year EndedDecember 31, 2020 |
|  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |
| Product revenue | $ | 1,279 |  |  | $ | 503 |  |  | $ | 1,782 |  |
| Subscription revenue | 2,637 |  |  | 93 |  |  | 2,730 |  |
| Service revenue | 869 |  |  | — |  |  | 869 |  |
| Total revenue | 4,785 |  |  | 596 |  |  | 5,381 |  |
| Cost of revenue: |  |  |  |  |  |
| Cost of product revenue | 1,177 |  |  | 562 |  |  | 1,739 |  |
| Cost of subscription revenue | 1,824 |  |  | — |  |  | 1,824 |  |
| Cost of service revenue | 495 |  |  | 1 |  |  | 496 |  |
| Total cost of revenue | 3,496 |  |  | 563 |  |  | 4,059 |  |
| Gross profit | 1,289 |  |  | 33 |  |  | 1,322 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 15,710 |  |  | (157) |  |  | 15,553 |  |
| Sales and marketing expense | 7,365 |  |  | 919 |  |  | 8,284 |  |
| General and administrative | 5,110 |  |  | 420 |  |  | 5,530 |  |
| Total operating expenses | 28,185 |  |  | 1,182 |  |  | 29,367 |  |
| Loss from operations | (26,896) |  |  | (1,149) |  |  | (28,045) |  |
| Other income (expense), net: |  |  |  |  |  |
| Interest expense, net | (430) |  |  | 114 |  |  | (316) |  |
| Loss on extinguishment of debt | (66) |  |  | — |  |  | (66) |  |
| Total other income (expense), net | (496) |  |  | 114 |  |  | (382) |  |
| Net loss | $ | (27,392) |  |  | $ | (1,035) |  |  | $ | (28,427) |  |
| Weighted average common shares outstanding - basic and diluted | 8,932,404 |  |  | — |  |  | 8,932,404 |  |
| Net loss per share - basic and diluted | $ | (3.07) |  |  | $ | (0.11) |  |  | $ | (3.18) |  |

[0001628280-22-029319:notes:216]
Revised Condensed Consolidated Statements of Cash Flows

[0001628280-22-029319:notes:217]
|  | Three Months EndedMarch 31, 2022 |
|  | As Previously Reported | Adjustment | As Revised |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (14,551) |  | $ | 750 |  | $ | (13,801) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 948 |  | 138 |  | 1,086 |  |
| Write-off of inventory | 324 |  | — |  | 324 |  |
| Adjustment to property and equipment for sales type leases | (321) |  | (304) |  | (625) |  |
| Loss from impairment of property and equipment | 96 |  | — |  | 96 |  |
| Stock-based compensation | 5,190 |  | (1,263) |  | 3,927 |  |
| Non-cash interest expense | 5 |  | — |  | 5 |  |
| Non-cash lease expense | 197 |  | — |  | 197 |  |
| Change in fair value of earn-out liability | (4,226) |  | 1,148 |  | (3,078) |  |
| Change in fair value of contingently issuable common stock | (1,472) |  | — |  | (1,472) |  |
| Change in fair value of public warrant liability | (5,586) |  | — |  | (5,586) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (2,112) |  | — |  | (2,112) |  |
| Inventory | (6,985) |  | 5,675 |  | (1,310) |  |
| Commission assets | (351) |  | — |  | (351) |  |
| Contract assets | 108 |  | — |  | 108 |  |
| Other assets | — |  | 141 |  | 141 |  |
| Prepaid expenses and other current assets | (5,280) |  | (291) |  | (5,571) |  |
| Accounts payable | (1,867) |  | 1,012 |  | (855) |  |
| Deferred revenue | 2,778 |  | (201) |  | 2,577 |  |
| Deferred rent | (468) |  | 468 |  | — |  |
| Accrued expenses and other current liabilities | (2,065) |  | (368) |  | (2,433) |  |
| Operating lease liability | (229) |  | (468) |  | (697) |  |
| Net cash used in operating activities | (35,867) |  | 6,437 |  | (29,430) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (646) |  | (82) |  | (728) |  |
| Purchases of property and equipment | (323) |  | (6,366) |  | (6,689) |  |
| Net cash used in investing activities | (969) |  | (6,448) |  | (7,417) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 216 |  | 11 |  | 227 |  |
| Net cash provided by financing activities | 216 |  | 11 |  | 227 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (36,620) |  | — |  | (36,620) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 308,167 |  | — |  | 308,167 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 271,547 |  | $ | — |  | $ | 271,547 |  |
| Supplemental disclosure of non-cash activities |  |  |  |
| Transfer of inventory to property and equipment | $ | 4,620 |  | $ | (4,620) |  | $ | — |  |
| Capital expenditures incurred but not yet paid | 1,693 |  | 698 |  | 2,391 |  |

[0001628280-22-029319:notes:218]
|  | Year EndedDecember 31, 2021 |
|  | As Previously Reported | Adjustment | As Revised |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (10,858) |  | $ | (30) |  | $ | (10,888) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 2,895 |  | — |  | 2,895 |  |
| Write-off of inventory | 2,132 |  | — |  | 2,132 |  |
| Adjustment to property and equipment for sales type leases | (91) |  | — |  | (91) |  |
| Loss from impairment of property and equipment | 1,869 |  | — |  | 1,869 |  |
| Loss on disposal of property and equipment | 617 |  | — |  | 617 |  |
| Stock-based compensation | 8,511 |  | 1,085 |  | 9,596 |  |
| Non-cash interest expense | 5,245 |  | — |  | 5,245 |  |
| Provision recorded for allowance for doubtful accounts | (13) |  | — |  | (13) |  |
| Loss on extinguishment of debt | 12,685 |  | — |  | 12,685 |  |
| Change in fair value of derivative liability | 1,745 |  | — |  | 1,745 |  |
| Change in fair value of common stock warrant liability | 879 |  | — |  | 879 |  |
| Change in fair value of earn-out liability | (46,212) |  | (1,148) |  | (47,360) |  |
| Change in fair value of contingently issuable common stock | (6,406) |  | — |  | (6,406) |  |
| Change in fair value of public warrant liability | (12,606) |  | — |  | (12,606) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (5,063) |  | — |  | (5,063) |  |
| Inventory | (17,479) |  | 14,043 |  | (3,436) |  |
| Commission assets | (3,072) |  | — |  | (3,072) |  |
| Contract assets | (4,877) |  | — |  | (4,877) |  |
| Other assets | — |  | 32 |  | 32 |  |
| Prepaid expenses and other current assets | (10,079) |  | 931 |  | (9,148) |  |
| Accounts payable | (7) |  | 772 |  | 765 |  |
| Deferred revenue | 4,968 |  | (136) |  | 4,832 |  |
| Deferred rent | 457 |  | — |  | 457 |  |
| Warranty reserve | (42) |  | — |  | (42) |  |
| Accrued expenses and other current liabilities | 5,174 |  | (2,702) |  | 2,472 |  |
| Net cash used in operating activities | (69,628) |  | 12,847 |  | (56,781) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (1,028) |  | — |  | (1,028) |  |
| Purchases of property and equipment | (3,710) |  | (12,847) |  | (16,557) |  |
| Net cash used in investing activities | (4,738) |  | (12,847) |  | (17,585) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 915 |  | — |  | 915 |  |
| Proceeds from issuance of common stock from the PIPE Investment | 300,000 |  | — |  | 300,000 |  |
| Proceeds from the closing of the Merger | 84,945 |  | — |  | 84,945 |  |
| Payment of offering costs from the closing of the Merger and PIPE Investment | (34,132) |  | — |  | (34,132) |  |
| Repayment of financing obligations | (359) |  | — |  | (359) |  |
| Proceeds from long-term debt, net of issuance costs | 31,882 |  | — |  | 31,882 |  |
| Repayment of principal on long-term debt | (5,422) |  | — |  | (5,422) |  |
| Net cash provided by financing activities | 377,829 |  | — |  | 377,829 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 303,463 |  | — |  | 303,463 |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 4,704 |  | — |  | 4,704 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 308,167 |  | $ | — |  | $ | 308,167 |  |
| Supplemental disclosure of non-cash activities |  |  |  |
| Transfer of inventory to property and equipment | $ | 12,949 |  | $ | (12,949) |  | $ | — |  |
| Capital expenditures incurred but not yet paid | 347 |  | 2,589 |  | 2,936 |  |
| Issuance of equity classified warrants | 1 |  | (1) |  | — |  |

[0001628280-22-029319:notes:219]
| Deferred offering costs included in accounts payable | 1,932 |  | 11 |  | 1,943 |  |
| Conversion of convertible preferred stock to common stock | 75,877 |  | — |  | 75,877 |  |
| Initial fair value of contingent earn-out liability recognized in connection with the closing of the Merger | 67,021 |  | — |  | 67,021 |  |
| Initial fair value of contingently issuable common stock liability recognized in connection with the closing of the Merger | 11,670 |  | — |  | 11,670 |  |
| Conversion of common stock warrants to common stock in connection with the closing of the Merger | 880 |  | — |  | 880 |  |
| Initial fair value of public warrants in connection with the closing of the Merger | 23,636 |  | — |  | 23,636 |  |

[0001628280-22-029319:notes:220]
|  | Nine Months EndedSeptember 30, 2021 |
|  | As Previously Reported | Adjustment | As Revised |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (13,375) |  | $ | (2,301) |  | $ | (15,676) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 1,948 |  | — |  | 1,948 |  |
| Write-off of inventory | 400 |  | — |  | 400 |  |
| Loss from impairment of property and equipment | 1,656 |  | — |  | 1,656 |  |
| Loss on disposal of property and equipment | 659 |  | — |  | 659 |  |
| Stock-based compensation | 4,013 |  | 2,019 |  | 6,032 |  |
| Non-cash interest expense | 5,561 |  | — |  | 5,561 |  |
| Provision recorded for allowance for doubtful accounts | (63) |  | — |  | (63) |  |
| Loss on extinguishment of debt | 12,685 |  | — |  | 12,685 |  |
| Change in fair value of derivative liability | 1,745 |  | — |  | 1,745 |  |
| Change in fair value of common stock warrant liability | 879 |  | — |  | 879 |  |
| Change in fair value of earn-out liability | (31,818) |  | (791) |  | (32,609) |  |
| Change in fair value of contingently issuable common stock | (5,718) |  | — |  | (5,718) |  |
| Change in fair value of public warrant liability | (3,152) |  | — |  | (3,152) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (5,866) |  | — |  | (5,866) |  |
| Inventory | (10,836) |  | 10,100 |  | (736) |  |
| Commission assets | (1,102) |  | — |  | (1,102) |  |
| Contract assets | (2,582) |  | (895) |  | (3,477) |  |
| Other assets | — |  | 23 |  | 23 |  |
| Prepaid expenses and other current assets | (12,772) |  | 1,237 |  | (11,535) |  |
| Accounts payable | 2,264 |  | (2,024) |  | 240 |  |
| Deferred revenue | 2,459 |  | (107) |  | 2,352 |  |
| Deferred rent | 397 |  | — |  | 397 |  |
| Warranty reserve | (42) |  | — |  | (42) |  |
| Accrued expenses and other current liabilities | 2,183 |  | 651 |  | 2,834 |  |
| Net cash used in operating activities | (50,477) |  | 7,912 |  | (42,565) |  |
| Cash flows from investing activities: |  |  |  |
| Purchases of property and equipment | (3,082) |  | (7,912) |  | (10,994) |  |
| Net cash used in investing activities | (3,082) |  | (7,912) |  | (10,994) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 777 |  | — |  | 777 |  |
| Proceeds from issuance of common stock from the PIPE Investment | 300,000 |  | — |  | 300,000 |  |
| Proceeds from the closing of the Merger | 84,945 |  | — |  | 84,945 |  |
| Payment of offering costs from the closing of the Merger and PIPE Investment | (33,968) |  | — |  | (33,968) |  |
| Repayment of financing obligations | (359) |  | — |  | (359) |  |
| Proceeds from long-term debt, net of issuance costs | 31,882 |  | — |  | 31,882 |  |
| Net cash provided by financing activities | 383,277 |  | — |  | 383,277 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 329,718 |  | — |  | 329,718 |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 4,704 |  | — |  | 4,704 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 334,422 |  | $ | — |  | $ | 334,422 |  |
| Supplemental disclosure of non-cash activities |  |  |  |
| Transfer of inventory to property and equipment | $ | 9,648 |  | $ | (9,648) |  | $ | — |  |
| Capital expenditures incurred but not yet paid | — |  | 3,123 |  | 3,123 |  |
| Deferred offering costs included in accounts payable | 1,760 |  | 10 |  | 1,770 |  |
| Conversion of convertible preferred stock to common stock | 75,877 |  | — |  | 75,877 |  |
| Initial fair value of contingent earn-out liability recognized in connection with the closing of the Merger | 66,845 |  | 176 |  | 67,021 |  |

[0001628280-22-029319:notes:221]
| Initial fair value of contingently issuable common stock liability recognized in connection with the closing of the Merger | 11,670 |  | — |  | 11,670 |  |
| Conversion of common stock warrants to common stock in connection with the closing of the Merger | 880 |  | — |  | 880 |  |
| Initial fair value of public warrants in connection with the closing of the Merger | 23,636 |  | — |  | 23,636 |  |

[0001628280-22-029319:notes:222]
|  | Six Months EndedJune 30, 2021 |
|  | As Previously Reported | Adjustment | As Revised |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (36,126) |  | $ | (357) |  | $ | (36,483) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 1,102 |  | — |  | 1,102 |  |
| Stock-based compensation | 1,617 |  | (241) |  | 1,376 |  |
| Non-cash interest expense | 5,455 |  | — |  | 5,455 |  |
| Provision recorded for allowance for doubtful accounts | (63) |  | — |  | (63) |  |
| Loss on extinguishment of debt | 11,820 |  | — |  | 11,820 |  |
| Change in fair value of derivative liability | 2,220 |  | — |  | 2,220 |  |
| Change in fair value of common stock warrant liability | 921 |  | — |  | 921 |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (1,335) |  | — |  | (1,335) |  |
| Inventory | (1,173) |  | 720 |  | (453) |  |
| Commission assets | (742) |  | — |  | (742) |  |
| Contract assets | (239) |  | — |  | (239) |  |
| Other assets | — |  | 13 |  | 13 |  |
| Prepaid expenses and other current assets | (7,495) |  | 208 |  | (7,287) |  |
| Accounts payable | 5,361 |  | (1,862) |  | 3,499 |  |
| Deferred revenue | 253 |  | (100) |  | 153 |  |
| Deferred rent | 152 |  | — |  | 152 |  |
| Warranty reserve | (42) |  | — |  | (42) |  |
| Accrued expenses and other current liabilities | 1,360 |  | 281 |  | 1,641 |  |
| Net cash used in operating activities | (16,954) |  | (1,338) |  | (18,292) |  |
| Cash flows from investing activities: |  |  |  |
| Purchases of property and equipment | (9,292) |  | 1,338 |  | (7,954) |  |
| Net cash used in investing activities | (9,292) |  | 1,338 |  | (7,954) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 657 |  | — |  | 657 |  |
| Repayment of financing obligations | (359) |  | — |  | (359) |  |
| Proceeds from long-term debt, net of issuance costs | 31,882 |  | — |  | 31,882 |  |
| Net cash provided by financing activities | 32,180 |  | — |  | 32,180 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 5,934 |  | — |  | 5,934 |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 4,704 |  | — |  | 4,704 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 10,638 |  | $ | — |  | $ | 10,638 |  |
| Supplemental disclosure of non-cash activities |  |  |  |
| Transfer of inventory to property and equipment | $ | 46 |  | $ | — |  | $ | 46 |  |
| Capital expenditures incurred but not yet paid | — |  | 2,962 |  | 2,962 |  |
| Capitalization of stock compensation | — |  | 27 |  | 27 |  |

[0001628280-22-029319:notes:223]
|  | Three Months EndedMarch 31, 2021 |
|  | As Previously Reported | Adjustment | As Revised |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (13,755) |  | $ | 249 |  | $ | (13,506) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 452 |  | — |  | 452 |  |
| Stock-based compensation | 1,082 |  | (773) |  | 309 |  |
| Non-cash interest expense | 2,344 |  | — |  | 2,344 |  |
| Provision recorded for allowance for doubtful accounts | (63) |  | — |  | (63) |  |
| Change in fair value of derivative liability | 1,425 |  | — |  | 1,425 |  |
| Change in fair value of common stock warrant liability | 736 |  | — |  | 736 |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (874) |  | — |  | (874) |  |
| Inventory | (433) |  | (47) |  | (480) |  |
| Commission assets | (391) |  | — |  | (391) |  |
| Contract assets | (119) |  | — |  | (119) |  |
| Other assets | — |  | 7 |  | 7 |  |
| Prepaid expenses and other current assets | (4,104) |  | 377 |  | (3,727) |  |
| Accounts payable | 1,194 |  | (235) |  | 959 |  |
| Deferred revenue | (621) |  | (185) |  | (806) |  |
| Deferred rent | (11) |  | — |  | (11) |  |
| Accrued expenses and other current liabilities | 1,100 |  | 206 |  | 1,306 |  |
| Net cash used in operating activities | (12,038) |  | (401) |  | (12,439) |  |
| Cash flows from investing activities: |  |  |  |
| Purchases of property and equipment | (2,522) |  | 401 |  | (2,121) |  |
| Net cash used in investing activities | (2,522) |  | 401 |  | (2,121) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 455 |  | — |  | 455 |  |
| Repayment of financing obligations | (359) |  | — |  | (359) |  |
| Proceeds from long-term debt, net of issuance costs | 31,882 |  | — |  | 31,882 |  |
| Net cash provided by financing activities | 31,978 |  | — |  | 31,978 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 17,418 |  | — |  | 17,418 |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 4,704 |  | — |  | 4,704 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 22,122 |  | $ | — |  | $ | 22,122 |  |
| Supplemental disclosure of non-cash activities |  |  |  |
| Capital expenditures incurred but not yet paid | — |  | 1,335 |  | 1,335 |  |
| Issuance of equity classified warrants | 1 |  | — |  | 1 |  |

[0001628280-22-029319:notes:224]
|  | Year EndedDecember 31, 2020 |
|  | As Previously Reported | Adjustment | As Revised |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (27,392) |  | $ | (1,035) |  | $ | (28,427) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 1,065 |  | — |  | 1,065 |  |
| Stock-based compensation | 662 |  | 917 |  | 1,579 |  |
| Non-cash interest expense | 25 |  | — |  | 25 |  |
| Provision recorded for allowance for doubtful accounts | 47 |  | — |  | 47 |  |
| Loss on extinguishment of debt | 66 |  | — |  | 66 |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (464) |  | — |  | (464) |  |
| Inventory | (1,471) |  | 1,156 |  | (315) |  |
| Commission assets | (1,785) |  | — |  | (1,785) |  |
| Other assets | — |  | (173) |  | (173) |  |
| Prepaid expenses and other current assets | (375) |  | (641) |  | (1,016) |  |
| Accounts payable | 1,915 |  | (1,100) |  | 815 |  |
| Deferred revenue | 2,341 |  | 45 |  | 2,386 |  |
| Deferred rent | (34) |  | — |  | (34) |  |
| Warranty reserve | (14) |  | — |  | (14) |  |
| Accrued expenses and other current liabilities | 2,160 |  | 483 |  | 2,643 |  |
| Operating lease liability | — |  | — |  | — |  |
| Net cash used in operating activities | (23,254) |  | (348) |  | (23,602) |  |
| Cash flows from investing activities: |  |  |  |
| Purchases of property and equipment | (6,609) |  | 348 |  | (6,261) |  |
| Net cash used in investing activities | (6,609) |  | 348 |  | (6,261) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from issuance of Series B-1 convertible preferred stock, net of issuance costs | 2,994 |  | — |  | 2,994 |  |
| Proceeds from exercise of stock options | 442 |  | — |  | 442 |  |
| Repayment of financing obligations | (244) |  | — |  | (244) |  |
| Proceeds from long-term debt, net of issuance costs | 22,438 |  | — |  | 22,438 |  |
| Repayment of principal on long-term debt | (8,404) |  | — |  | (8,404) |  |
| Net cash provided by financing activities | 17,226 |  | — |  | 17,226 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (12,637) |  | — |  | (12,637) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 17,341 |  | — |  | 17,341 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 4,704 |  | $ | — |  | $ | 4,704 |  |
| Supplemental disclosure of non-cash activities |  |  |  |
| Transfer of inventory to property and equipment | $ | 86 |  | $ | — |  | $ | 86 |  |
| Capital expenditures incurred but not yet paid | — |  | 1,100 |  | 1,100 |  |
| Issuance of equity classified warrants | 112 |  | — |  | 112 |  |
| Issuance of a nonrecourse promissory note with officer | 350 |  | — |  | 350 |  |
