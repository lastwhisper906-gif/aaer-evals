# EVLV note change history — 0001628280-22-023253 → 0001628280-22-029319


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-09):
[0001628280-22-029319:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of September 30, 2022 or December 31, 2021.
  (was, 2022-08-18, similarity 0.9943):
[0001628280-22-023253:note_history:1]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of June 30, 2022 or December 31, 2021.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-11-09):
[0001628280-22-029319:note_history:2]
The accompanying unaudited condensed consolidated financial statements as of September 30, 2022, and for the three and nine months ended September 30, 2022 and 2021 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2021 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2022 and the results of its operations for the three and nine months ended September 30, 2022 and 2021 and cash flows for the nine months ended September 30, 2022 and 2021. The results for the three and nine months ended September 30, 2022 are not necessarily indicative of results to be expected for the year ending December 31, 2022, any other interim periods, or any future year or period.

- removed (2022-11-09):
[0001628280-22-023253:note_history:3]
The accompanying unaudited condensed consolidated financial statements as of June 30, 2022, and for the three and six months ended June 30, 2022 and 2021 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2021 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of June 30, 2022 and the results of its operations for the three and six months ended June 30, 2022 and 2021 and cash flows for the six months ended June 30, 2022 and 2021. The results for the three and six months ended June 30, 2022 are not necessarily indicative of results to be expected for the year ending December 31, 2022, any other interim periods, or any future year or period.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-09):
[0001628280-22-029319:note_history:4]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2021, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2021. There have been no material changes to the Company’s significant accounting policies during the three months ended September 30, 2022 outside of the items as described below.
  (was, 2022-08-18, similarity 0.9875):
[0001628280-22-023253:note_history:4]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2021, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2021. There have been no material changes to the Company’s significant accounting policies during the three months ended June 30, 2022 outside of the items as described below.

- changed (2022-11-09):
[0001628280-22-029319:note_history:5]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party. Revenue related to leases entered into with related parties were $0.2 million and $0.4 million during the three and nine months ended September 30, 2022, respectively.
  (was, 2022-08-18, similarity 0.9221):
[0001628280-22-023253:note_history:5]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party. Revenue related to leases entered into with related parties were $0.2 million and $0.3 million during the three and six months ended June 30, 2022, respectively.

- added (2022-11-09):
[0001628280-22-029319:note_history:6]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.

- changed (2022-11-09):
[0001628280-22-029319:note_history:7]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and does not expect that adoption of the guidance will have a material impact on its condensed consolidated financial statements.
  (was, 2022-08-18, similarity 0.9075):
[0001628280-22-023253:note_history:7]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its condensed consolidated financial statements and related disclosures.

- changed (2022-11-09):
[0001628280-22-029319:note_history:8]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company expects to adopt this guidance effective January 1, 2023, and does not expect that adoption of the guidance will have a material impact on its condensed consolidated financial statements.
  (was, 2022-08-18, similarity 0.8877):
[0001628280-22-023253:note_history:8]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its condensed consolidated financial statements and related disclosures.

- removed (2022-11-09):
[0001628280-22-023253:note_history:9]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019 12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-09):
[0001628280-22-029319:note_history:10]
|  | September 30,2022 |  | December 31,2021 |
| Term loans payable | $ | 9,000 |  |  | $ | 10,000 |  |
| Less: Unamortized discount | (41) |  |  | (55) |  |
|  | 8,959 |  |  | 9,945 |  |
| Less: Current portion of long-term debt | 4,000 |  |  | 2,000 |  |
| Long-term debt, net of discount | $ | 4,959 |  |  | $ | 7,945 |  |
  (was, 2022-08-18, similarity 0.9748):
[0001628280-22-023253:note_history:10]
|  | June 30,2022 |  | December 31,2021 |
| Term loans payable | $ | 10,000 |  |  | $ | 10,000 |  |
| Less: Unamortized discount | (45) |  |  | (55) |  |
|  | 9,955 |  |  | 9,945 |  |
| Less: Current portion of long-term debt | 4,000 |  |  | 2,000 |  |
| Long-term debt, net of discount | $ | 5,955 |  |  | $ | 7,945 |  |

- added (2022-11-09):
[0001628280-22-029319:note_history:11]
As of September 30, 2022, the unamortized debt discount was less than $0.1 million. As of September 30, 2022, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the condensed consolidated balance sheet. Interest expense related to the JPM Credit Agreement totaled $0.2 million and $0.2 million for the three months ended September 30, 2022 and September 30, 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million in each period. Interest expense related to the JPM Credit Agreement totaled $0.5 million and $0.6 million for the nine months ended September 30, 2022 and September 30, 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million in each period. The interest rate in effect as of September 30, 2022 was 8.50% for the JPM Credit Agreement.

- changed (2022-11-09):
[0001628280-22-029319:note_history:12]
As of September 30, 2022, future principal payments on long-term debt are as follows (in thousands):
  (was, 2022-08-18, similarity 0.9399):
[0001628280-22-023253:note_history:12]
As of June 30, 2022, future principal payments on long-term debt are as follows (in thousands):

- changed (2022-11-09):
[0001628280-22-029319:note_history:13]
| December 31, |  |
| 2022 (remaining three months) | $ | 1,000 |  |
| 2023 | 4,000 |  |
| 2024 | 4,000 |  |
|  | $ | 9,000 |  |
  (was, 2022-08-18, similarity 0.9574):
[0001628280-22-023253:note_history:13]
| December 31, |  |
| 2022 (remaining six months) | $ | 2,000 |  |
| 2023 | 4,000 |  |
| 2024 | 4,000 |  |
|  | $ | 10,000 |  |

- changed (2022-11-09):
[0001628280-22-029319:note_history:14]
Interest expense related to the 2020 Convertible Notes totaled less than $0.1 million and $0.3 million for the three and nine months ended September 30, 2021, respectively. No interest expense was recognized related to the 2020 Convertible Notes for the three and nine months ended September 30, 2022.
  (was, 2022-08-18, similarity 0.7873):
[0001628280-22-023253:note_history:14]
Interest expense related to the 2020 Convertible Notes totaled $0.1 million and $0.3 million for the three and six months ended June 30, 2021, respectively. No interest expense was recognized related to the 2020 Convertible Notes for the three and six months ended June 30, 2022.

- changed (2022-11-09):
[0001628280-22-029319:note_history:15]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense).
  (was, 2022-08-18, similarity 0.9926):
[0001628280-22-023253:note_history:15]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 recorded in other income (expense).

- changed (2022-11-09):
[0001628280-22-029319:note_history:16]
Interest expense related to the 2021 Convertible Notes totaled $0.1 million and $4.9 million for the three and nine months ended September 30, 2021, respectively. No interest expense was recognized related to the 2021 Convertible Notes for the three and nine months ended September 30, 2022.
  (was, 2022-08-18, similarity 0.8023):
[0001628280-22-023253:note_history:16]
Interest expense related to the 2021 Convertible Notes totaled $2.8 million and $4.7 million for the three and six months ended June 30, 2021, respectively. No interest expense was recognized related to the 2021 Convertible Notes for the three and six months ended June 30, 2022.

- removed (2022-11-09):
[0001628280-22-023253:note_history:17]
As of June 30, 2022, the unamortized debt discount was less than $0.1 million. As of June 30, 2022, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the condensed consolidated balance sheet. Interest expense related to the JPM Credit Agreement totaled $0.2 million and $0.2 million for the three months ended June 30, 2022 and June 30, 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million in each period. Interest expense related to the JPM Credit Agreement totaled $0.3 million and $0.3 million for the six months ended June 30, 2022 and June 30, 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million in each period. The interest rate in effect as of June 30, 2022 was 5.75% for the JPM Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-09):
[0001628280-22-029319:note_history:18]
|  | September 30,2022 |  | December 31,2021 |
| Term loans payable | $ | 9,000 |  |  | $ | 10,000 |  |
| Less: Unamortized discount | (41) |  |  | (55) |  |
|  | 8,959 |  |  | 9,945 |  |
| Less: Current portion of long-term debt | 4,000 |  |  | 2,000 |  |
| Long-term debt, net of discount | $ | 4,959 |  |  | $ | 7,945 |  |
  (was, 2022-08-18, similarity 0.9748):
[0001628280-22-023253:note_history:18]
|  | June 30,2022 |  | December 31,2021 |
| Term loans payable | $ | 10,000 |  |  | $ | 10,000 |  |
| Less: Unamortized discount | (45) |  |  | (55) |  |
|  | 9,955 |  |  | 9,945 |  |
| Less: Current portion of long-term debt | 4,000 |  |  | 2,000 |  |
| Long-term debt, net of discount | $ | 5,955 |  |  | $ | 7,945 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-09):
[0001628280-22-029319:note_history:19]
As of September 30, 2022, future principal payments on long-term debt are as follows (in thousands):
  (was, 2022-08-18, similarity 0.9399):
[0001628280-22-023253:note_history:19]
As of June 30, 2022, future principal payments on long-term debt are as follows (in thousands):

- changed (2022-11-09):
[0001628280-22-029319:note_history:20]
| December 31, |  |
| 2022 (remaining three months) | $ | 1,000 |  |
| 2023 | 4,000 |  |
| 2024 | 4,000 |  |
|  | $ | 9,000 |  |
  (was, 2022-08-18, similarity 0.9574):
[0001628280-22-023253:note_history:20]
| December 31, |  |
| 2022 (remaining six months) | $ | 2,000 |  |
| 2023 | 4,000 |  |
| 2024 | 4,000 |  |
|  | $ | 10,000 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-11-09):
[0001628280-22-029319:note_history:21]
In January 2021, the Company granted the Finback Common Stock Warrants. During the three months ended September 30, 2022 and 2021, the Company recorded $1.3 million and $1.0 million, respectively, of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants. During the nine months ended September 30, 2022 and 2021, the Company recorded $2.1 million and $1.8 million, respectively, of stock-based compensation expense within sales and marketing expense for the Finback Common Stock Warrants.
  (was, 2022-08-18, similarity 0.6802):
[0001628280-22-023253:note_history:21]
In January 2021, the Company granted a warrant exercisable for 2,552,913 shares of common stock to Finback, a consulting group who is an affiliate of one of the Company’s shareholders, with performance-based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years. During the three months ended June 30, 2022 and 2021, the Company recorded $0.6 million and $0.7 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants. During the six months ended June 30, 2022 and 2021, the Company recorded $0.8 million and $0.8 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.

- added (2022-11-09):
[0001628280-22-029319:note_history:22]
In connection with the Merger and pursuant to the Merger Agreement, Finback is entitled to receive a proportional share of earn-out shares as an earn-out service provider, based upon the remaining unvested warrants as of the Merger

- added (2022-11-09):
[0001628280-22-029319:note_history:23]
Date. As of September 30, 2022, Finback can earn 284,511 earn-out shares subject to stock-based compensation, based on the achievement of certain milestones. During the three and nine months ended September 30, 2021, $1.5 million stock-based compensation expense was recorded within sales and marketing expense for the earn-out shares allocated to Finback. During the three and nine months ended September 30, 2022, no stock-based compensation expense was recorded within sales and marketing expense for the earn-out shares allocated to Finback.

- changed (2022-11-09):
[0001628280-22-029319:note_history:24]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement (the “Distribution Agreement”) with Motorola, an investor in the Company. In June 2021, the partnership agreement was amended by the Amended and Restated Distribution Agreement (the “Amended and Restated Distribution Agreement”). Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended September 30, 2022 and 2021, revenue from sales to Motorola was  $2.3 million and less than $0.1 million, respectively. During the nine months ended September 30, 2022 and 2021, revenue from sales to Motorola was $5.0 million and less than $0.1 million, respectively. As of September 30, 2022 and December 31, 2021, accounts receivable related to Motorola’s distributor services was $4.1 million and $1.2 million, respectively.
  (was, 2022-08-18, similarity 0.8913):
[0001628280-22-023253:note_history:24]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement (the “Distribution Agreement”) with Motorola, an investor in the Company. In June 2021, the partnership agreement was amended by the Amended and Restated Distribution Agreement (the “Amended and Restated Distribution Agreement”). Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended June 30, 2022 and 2021, revenue from Motorola’s distributor services was $1.9 million and $0, respectively. During the six months ended June 30, 2022 and 2021, revenue from Motorola’s distributor services was $2.8 million and $0, respectively. As of June 30, 2022 and December 31, 2021, accounts receivable related to Motorola’s distributor services was $3.0 million and $1.2 million, respectively.

- removed (2022-11-09):
[0001628280-22-023253:note_history:25]
In connection with the Merger and pursuant to the Merger Agreement, Finback is entitled to receive a proportional share of earn-out shares as an earn-out service provider, based upon the remaining unvested warrants as of the Merger Date. As of June 30, 2022, Finback can earn 283,926 earn-out shares subject to stock-based compensation, based on the achievement of certain milestones. During the three months ended June 30, 2022 and 2021, no stock-based compensation expense within sales and marketing expense for the earn-out shares allocated to Finback was recorded. During the six months ended June 30, 2022 and 2021, no stock-based compensation expense within sales and marketing expense for the earn-out shares allocated to Finback was recorded.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-09):
[0001628280-22-029319:note_history:26]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Product revenue | $ | 9,839 |  |  | $ | 5,395 |  |  | $ | 19,179 |  |  | $ | 10,279 |  |
| Leased equipment | 5,198 |  |  | 2,312 |  |  | 12,208 |  |  | 5,060 |  |
| SaaS and Maintenance revenue | 1,180 |  |  | 300 |  |  | 2,277 |  |  | 662 |  |
| Professional services and other revenue | 313 |  |  | 417 |  |  | 646 |  |  | 794 |  |
| Total revenue | $ | 16,530 |  |  | $ | 8,424 |  |  | $ | 34,310 |  |  | $ | 16,795 |  |
  (was, 2022-08-18, similarity 0.9265):
[0001628280-22-023253:note_history:26]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Product revenue | $ | 4,146 |  |  | $ | 2,617 |  |  | $ | 9,340 |  |  | $ | 4,884 |  |
| Leased equipment | 4,006 |  |  | 1,521 |  |  | 7,010 |  |  | 2,748 |  |
| SaaS and Maintenance revenue | 729 |  |  | 230 |  |  | 1,097 |  |  | 362 |  |
| Professional services revenue | 189 |  |  | 310 |  |  | 333 |  |  | 377 |  |
| Total revenue | $ | 9,070 |  |  | $ | 4,678 |  |  | $ | 17,780 |  |  | $ | 8,371 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-09):
[0001628280-22-029319:note_history:27]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2022.
  (was, 2022-08-18, similarity 0.9704):
[0001628280-22-023253:note_history:27]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of June 30, 2022.

- changed (2022-11-09):
[0001628280-22-029319:note_history:28]
|  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue | $ | 4,087 |  |  | $ | — |  |  | $ | 4,087 |  |
| Subscription revenue | 22,682 |  |  | 49,935 |  |  | 72,617 |  |
| Service revenue | 9,061 |  |  | 23,642 |  |  | 32,703 |  |
| Total revenue | $ | 35,830 |  |  | $ | 73,577 |  |  | $ | 109,407 |  |
  (was, 2022-08-18, similarity 0.996):
[0001628280-22-023253:note_history:28]
|  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue | $ | 220 |  |  | $ | 79 |  |  | $ | 299 |  |
| Subscription revenue | 16,992 |  |  | 37,615 |  |  | 54,607 |  |
| Service revenue | 3,423 |  |  | 7,909 |  |  | 11,332 |  |
| Total revenue | $ | 20,635 |  |  | $ | 45,603 |  |  | $ | 66,238 |  |

- changed (2022-11-09):
[0001628280-22-029319:note_history:29]
The amount of minimum future leases is based on expected income recognition. As of September 30, 2022, future minimum payments on noncancelable leases are as follows (in thousands):
  (was, 2022-08-18, similarity 0.9681):
[0001628280-22-023253:note_history:29]
The amount of minimum future leases is based on expected income recognition. As of June 30, 2022, future minimum payments on noncancelable leases are as follows (in thousands):

- changed (2022-11-09):
[0001628280-22-029319:note_history:30]
| Year Ending December 31: |  |
| 2022 (three months remaining) | $ | 5,734 |  |
| 2023 | 22,403 |  |
| 2024 | 20,956 |  |
| 2025 | 17,067 |  |
| 2026 | 6,377 |  |
| Thereafter | 80 |  |
|  | $ | 72,617 |  |
  (was, 2022-08-18, similarity 0.9737):
[0001628280-22-023253:note_history:30]
| Year Ending December 31: |  |
| 2022 (six months remaining) | $ | 8,556 |  |
| 2023 | 16,649 |  |
| 2024 | 15,380 |  |
| 2025 | 11,424 |  |
| 2026 | 2,505 |  |
| Thereafter | 93 |  |
|  | $ | 54,607 |  |

- changed (2022-11-09):
[0001628280-22-029319:note_history:31]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2022 and December 31, 2021, the Company had $5.3 million and $1.5 million in current portion of contract assets and $1.5 million and $3.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2022-08-18, similarity 0.986):
[0001628280-22-023253:note_history:31]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of June 30, 2022 and December 31, 2021, the Company had $3.1 million and $1.5 million in current portion of contract assets and $3.2 million and $3.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2022-11-09):
[0001628280-22-029319:note_history:32]
and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $1.3 million and $6.0 million during the three and nine months ended September 30, 2022, respectively, that was included in the 2021 deferred revenue balance. The Company recognized revenue of $0.5 million and $2.3 million during the three and nine months ended September 30, 2021, respectively, that was included in the 2020 deferred revenue balance.
  (was, 2022-08-18, similarity 0.9024):
[0001628280-22-023253:note_history:32]
and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $2.2 million and $4.7 million during the three and six months ended June 30, 2022, respectively, that was included in the 2021 deferred revenue balance. The Company recognized revenue of $0.6 million and $1.8 million during the three and six months ended June 30, 2021, respectively, that was included in the 2020 deferred revenue balance.

- changed (2022-11-09):
[0001628280-22-029319:note_history:33]
| Balance at December 31, 2021 | $ | 9,074 |  |
| Revenue recognized | 5,995 |  |
| Revenue deferred | 10,017 |  |
| Balance at September 30, 2022 | $ | 25,086 |  |
  (was, 2022-08-18, similarity 0.9502):
[0001628280-22-023253:note_history:33]
| Balance at December 31, 2021 | $ | 9,074 |  |
| Revenue recognized | (4,658) |  |
| Revenue deferred | 10,696 |  |
| Balance at June 30, 2022 | $ | 15,112 |  |

- changed (2022-11-09):
[0001628280-22-029319:note_history:34]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue from sales-type leases | $ | 29 |  |  | $ | — |  |  | $ | 1,341 |  |  | $ | — |  |
| Interest income on lease receivables | 60 |  |  | — |  |  | 170 |  |  | — |  |
| Lease income - operating leases | 5,198 |  |  | 2,312 |  |  | 12,208 |  |  | 5,060 |  |
| Total lease revenue | $ | 5,287 |  |  | $ | 2,312 |  |  | $ | 13,719 |  |  | $ | 5,060 |  |
  (was, 2022-08-18, similarity 0.9349):
[0001628280-22-023253:note_history:34]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue from sales-type leases | $ | — |  |  | $ | — |  |  | $ | 1,312 |  |  | $ | — |  |
| Interest income on lease receivables | 61 |  |  | — |  |  | 110 |  |  | — |  |
| Lease income - operating leases | 4,006 |  |  | 1,521 |  |  | 7,010 |  |  | 2,748 |  |
| Total lease revenue | $ | 4,067 |  |  | $ | 1,521 |  |  | $ | 8,432 |  |  | $ | 2,748 |  |

- changed (2022-11-09):
[0001628280-22-029319:note_history:35]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Product revenue | $ | 9,839 |  |  | $ | 5,395 |  |  | $ | 19,179 |  |  | $ | 10,279 |  |
| Leased equipment | 5,198 |  |  | 2,312 |  |  | 12,208 |  |  | 5,060 |  |
| SaaS and Maintenance revenue | 1,180 |  |  | 300 |  |  | 2,277 |  |  | 662 |  |
| Professional services and other revenue | 313 |  |  | 417 |  |  | 646 |  |  | 794 |  |
| Total revenue | $ | 16,530 |  |  | $ | 8,424 |  |  | $ | 34,310 |  |  | $ | 16,795 |  |
  (was, 2022-08-18, similarity 0.9265):
[0001628280-22-023253:note_history:35]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Product revenue | $ | 4,146 |  |  | $ | 2,617 |  |  | $ | 9,340 |  |  | $ | 4,884 |  |
| Leased equipment | 4,006 |  |  | 1,521 |  |  | 7,010 |  |  | 2,748 |  |
| SaaS and Maintenance revenue | 729 |  |  | 230 |  |  | 1,097 |  |  | 362 |  |
| Professional services revenue | 189 |  |  | 310 |  |  | 333 |  |  | 377 |  |
| Total revenue | $ | 9,070 |  |  | $ | 4,678 |  |  | $ | 17,780 |  |  | $ | 8,371 |  |

- changed (2022-11-09):
[0001628280-22-029319:note_history:36]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $7.0 million and $5.4 million as of September 30, 2022 and December 31, 2021,
  (was, 2022-08-18, similarity 0.9561):
[0001628280-22-023253:note_history:36]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $5.7 million and $5.4 million as of June 30, 2022 and December 31, 2021, respectively.

- added (2022-11-09):
[0001628280-22-029319:note_history:37]
respectively. During the three months ended September 30, 2022 and 2021, the Company amortized commission expense of $1.2 million and $1.4 million, respectively. During the nine months ended September 30, 2022 and 2021, the Company amortized commission expense of $2.4 million and $2.0 million, respectively.

- changed (2022-11-09):
[0001628280-22-029319:note_history:38]
During the nine months ended September 30, 2022, the Company donated six Evolv Express units to schools, resulting in $0.2 million in general and administrative expense in the Company’s condensed consolidated statements of operations and comprehensive loss. No Evolv Express units were donated during the nine months ended September 30, 2021.
  (was, 2022-08-18, similarity 0.7449):
[0001628280-22-023253:note_history:38]
During the six months ended June 30, 2022, the Company donated three Evolv Express units to schools, resulting in $0.2 million in general and administrative expense, respectively, in the Company’s condensed consolidated statements of operations and comprehensive loss.

- removed (2022-11-09):
[0001628280-22-023253:note_history:39]
During the three months ended June 30, 2022 and 2021, the Company amortized commission expense of $0.9 million and $0.5 million, respectively. During the six months ended June 30, 2022 and 2021, the Company amortized commission expense of $1.2 million and $0.6 million, respectively.
