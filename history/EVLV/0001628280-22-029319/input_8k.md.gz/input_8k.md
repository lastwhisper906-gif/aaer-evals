# EVLV 8-K — 0001628280-22-029266 filed 2022-11-09

## item codes, every 8-K on or before 2022-11-09

- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2022-11-09

- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-22-029266:8k_2_02:1]
EX-99.1
2
evlv-20221109exx991.htm
EX-99.1

[0001628280-22-029266:8k_2_02:2]
Document

[0001628280-22-029266:8k_2_02:3]
Exhibit 99.1

[0001628280-22-029266:8k_2_02:4]
Investor Relations:

[0001628280-22-029266:8k_2_02:5]
Brian Norris

[0001628280-22-029266:8k_2_02:6]
Vice President of Finance and Investor Relations

[0001628280-22-029266:8k_2_02:7]
bnorris@evolvtechnology.com

[0001628280-22-029266:8k_2_02:8]
Evolv Technology Reports Record Third Quarter Financial Results

[0001628280-22-029266:8k_2_02:9]
– Company Raises Outlook for 2022 –

[0001628280-22-029266:8k_2_02:10]
•Q3 Revenue of $16.5 million, up 96% year-over-year

[0001628280-22-029266:8k_2_02:11]
•Q3 Ending ARR of $28.7 million, up 189% year-over-year

[0001628280-22-029266:8k_2_02:12]
•Q3 Ending RPO of $109.4 million, up 220% year-over-year

[0001628280-22-029266:8k_2_02:13]
•Q3 Ending Evolv Express® subscriptions of 1,692, up 198% year-over-year

[0001628280-22-029266:8k_2_02:14]
Waltham, Massachusetts – November 9, 2022 – Evolv Technology (NASDAQ: EVLV), the leader in AI-based weapons detection security screening, today announced financial results for its third quarter ended September 30, 20221 and raised its business outlook for 2022.

[0001628280-22-029266:8k_2_02:15]
“We’re pleased to be reporting record third quarter results which were highlighted by strong growth in revenues and continued market expansion,” said Peter George, President and Chief Executive Officer of Evolv Technology. “We experienced particularly robust market adoption with 92 new customers including five of the largest school districts in the United States, over a dozen new hospitals across the nation, as well as the home stadiums of five additional professional sports teams. Our results and momentum position us well to deliver full year growth above our previous outlook for 2022.”

[0001628280-22-029266:8k_2_02:16]
Results for the Third Quarter of 2022

[0001628280-22-029266:8k_2_02:17]
Total revenue for the third quarter of 2022 was $16.5 million, an increase of 96% compared to $8.4 million for the third quarter of 2021. Total Contract Value (“TCV”)2 of orders booked for the third quarter of 2022 was $45.4 million, an increase of 167% compared to $17.0 million in the third quarter of 2021. Annual Recurring Revenue (“ARR”)3 was $28.7 million at the end of third quarter of 2022, an increase of 189% compared to $9.9 million at the end of the third quarter of 2021. Net loss for the third quarter of 2022 was $(18.6) million, or $(0.13) per basic and diluted share, compared to net income attributable to common stockholders for basic and diluted shares of $20.8 million and $21.3 million, respectively, or $0.17 per basic share and $0.14 per diluted share, in the third quarter of 2021. Adjusted earnings (loss)4 for the third quarter of 2022 was $(18.6) million, or $(0.13) per diluted share, compared to adjusted earnings (loss)4 of  $(12.9) million, or $(0.08) per diluted share, for the third quarter of 2021. Adjusted EBITDA4 for the third quarter of 2022 was $(18.0) million compared to $(11.5) million in the third quarter of 2021.

[0001628280-22-029266:8k_2_02:18]
Results for the First Nine Months of 2022

[0001628280-22-029266:8k_2_02:19]
Total revenue for the nine months ended September 30, 2022 was $34.3 million, an increase of 104% compared to $16.8 million for the nine months ended September 30, 2021. TCV2 of orders booked for the nine months ended September 30, 2022 was $86.6 million, an increase of 141% compared to $35.9 million for the nine months ended September 30, 2021. Net loss for the nine months ended September 30, 2022 was $(58.1) million, or $(0.40) per basic and diluted share, compared to net loss of $(15.7) million, or $(0.33) per basic and diluted share, for the nine months ended September 30, 2021. Adjusted earnings (loss)4 for the nine months ended September 30, 2022 was $(54.3) million, or $(0.38) per diluted

[0001628280-22-029266:8k_2_02:20]
share, compared to $(33.5) million, or $(0.70) per diluted share, for the nine months ended September 30, 2021. Adjusted EBITDA4 for the nine months ended September 30, 2022 was $(51.7) million, compared to $(24.9) million for the nine months ended September 30, 2021.

[0001628280-22-029266:8k_2_02:21]
Company Raises Outlook for 2022

[0001628280-22-029266:8k_2_02:22]
The Company today commented on its business outlook for 2022. The Company's outlook is based on the current indications for its business, which may change at any time.

[0001628280-22-029266:8k_2_02:23]
|  |  | 2022 Business Outlook |
| Estimate (In millions) |  | Issued August 10, 2022 |  | Issued November 9, 2022 |
| Total Revenue |  | $29-$31 |  | $46-$48 |
| Annual Recurring Revenue3 (ARR) at 12/31 |  | $27-$28 |  | $31-$32 |
| Adjusted EBITDA4 |  | ($65-$67) |  | No change |
| Cash and Cash Equivalents |  | $220-$230 |  | No change |

[0001628280-22-029266:8k_2_02:24]
“We believe we are well positioned to deliver strong top line growth above our previously issued guidance in 2022,” said Mark Donohue, Chief Financial Officer of Evolv Technology. “Our preliminary estimates for 2023 call for exiting ARR in the range of $65 million and $70 million – reflecting growth of more than 100% – and full year revenues in the range of $55 million to $60 million, reflecting our transition towards a subscription model.  We also expect to significantly reduce our full year operating cash usage in 2023. We will provide formal detailed guidance for 2023 when we release results for the fourth quarter of 2022.”

[0001628280-22-029266:8k_2_02:25]
Company to Host Live Conference Call and Webcast

[0001628280-22-029266:8k_2_02:26]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business and other matters.  The conference call may be accessed in the United States by dialing +1.877.692.8955 and using access code 774298.  The conference call may be accessed outside of the United States by dialing +1.234.720.6979 and using the same access code. The conference call will be simultaneously webcast on the Company’s investor relations website, which can be accessed at http://ir.evolvtechnology.com.  A replay of the conference call will be available for a period of 30 days by dialing +1.866.207.1041 or +1.402.970.0847 and using access code 4430069 or by accessing the webcast replay on the Company’s investor relations website at http://ir.evolvtechnology.com.

[0001628280-22-029266:8k_2_02:27]
About Evolv Technology

[0001628280-22-029266:8k_2_02:28]
Evolv Technology (NASDAQ: EVLV) is transforming human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered weapons detection and analytics.  Its mission is to transform security to create a safer world to work, learn, and play. Evolv has digitally transformed the gateways in places where people gather by enabling seamless integration combined with powerful analytics and insights.  Evolv’s advanced systems have scanned more than 425 million people, second only to the Department of Homeland Security’s Transportation Security Administration (TSA) in the United States.  Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category. Evolv Technology®, Evolv Express®, Evolv Insights®, and Evolv Cortex AI® are registered trademarks or trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit https://evolvtechnology.com.

[0001628280-22-029266:8k_2_02:29]
1 Amounts herein pertaining to September 30, 2022 represent a preliminary estimate as of the date of this earnings release. More information on our results of operations for the three and nine months ended September 30, 2022 will be provided upon filing our Quarterly Report on Form 10-Q with the Securities and Exchange Commission.

[0001628280-22-029266:8k_2_02:30]
2 We define Total Contract Value, or TCV, of orders booked as the total value of the contract over the specified term. Our calculation of TCV is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases). TCV should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of TCV may differ from similarly titled metrics presented by other companies.  The fourth quarter of the fiscal year ended December 31, 2022 is the final quarter that we will be reporting TCV.

[0001628280-22-029266:8k_2_02:31]
3 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001628280-22-029266:8k_2_02:32]
4 Non-GAAP Financial Measures In this press release, the Company’s adjusted operating expenses, adjusted gross profit, adjusted gross margin, adjusted operating income (loss), adjusted EBITDA, adjusted earnings (loss), and adjusted earnings per share-diluted are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit and adjusted gross margin exclude one-time items which management believes provides a more meaningful representation of contribution margin. Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, share-based compensation, and certain other one-time expenses. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, change in fair value of derivative liability, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, change in fair value of common stock warrant liability, restructuring expenses, loss on impairment of lease equipment, and certain other one-time expenses. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release.

[0001628280-22-029266:8k_2_02:33]
Forward-Looking Statements

[0001628280-22-029266:8k_2_02:34]
These statements reflect management’s current expectations regarding future events and operating performance and speak only as of the date of this press release. You should not put undue reliance on any forward-looking statements. Although we believe that the

[0001628280-22-029266:8k_2_02:35]
EVOLV TECHNOLOGY

[0001628280-22-029266:8k_2_02:36]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001628280-22-029266:8k_2_02:37]
(In thousands, except share and per share data)

[0001628280-22-029266:8k_2_02:38]
(Unaudited)

[0001628280-22-029266:8k_2_02:39]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 9,839 |  |  | $ | 5,395 |  |  | $ | 19,179 |  |  | $ | 10,279 |  |
| Subscription revenue | 5,198 |  |  | 2,312 |  |  | 12,208 |  |  | 5,060 |  |
| Service revenue | 1,493 |  |  | 717 |  |  | 2,923 |  |  | 1,456 |  |
| Total revenue | 16,530 |  |  | 8,424 |  |  | 34,310 |  |  | 16,795 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 12,960 |  |  | 2,967 |  |  | 23,513 |  |  | 7,386 |  |
| Cost of subscription revenue | 2,207 |  |  | 1,277 |  |  | 5,730 |  |  | 3,080 |  |
| Cost of service revenue | 1,138 |  |  | 713 |  |  | 3,392 |  |  | 1,685 |  |
| Total cost of revenue | 16,305 |  |  | 4,957 |  |  | 32,635 |  |  | 12,151 |  |
| Gross profit | 225 |  |  | 3,467 |  |  | 1,675 |  |  | 4,644 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 5,616 |  |  | 3,612 |  |  | 13,947 |  |  | 8,399 |  |
| Sales and marketing | 11,746 |  |  | 10,024 |  |  | 33,169 |  |  | 17,756 |  |
| General and administrative | 8,839 |  |  | 7,535 |  |  | 29,268 |  |  | 12,058 |  |
| Loss from impairment of property and equipment | 626 |  |  | 1,656 |  |  | 1,038 |  |  | 1,656 |  |
| Total operating expenses | 26,827 |  |  | 22,827 |  |  | 77,422 |  |  | 39,869 |  |
| Loss from operations | (26,602) |  |  | (19,360) |  |  | (75,747) |  |  | (35,225) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (188) |  |  | (295) |  |  | (489) |  |  | (5,952) |  |
| Interest income | 1,052 |  |  | — |  |  | 1,611 |  |  | — |  |
| Other expense, net | (57) |  |  | (669) |  |  | (57) |  |  | (669) |  |
| Loss on extinguishment of debt | — |  |  | (865) |  |  | — |  |  | (12,685) |  |
| Change in fair value of derivative liability | — |  |  | 475 |  |  | — |  |  | (1,745) |  |
| Change in fair value of contingent earn-out liability | 7,245 |  |  | 32,609 |  |  | 9,754 |  |  | 32,609 |  |
| Change in fair value of contingently issuable common stock liability | 1,081 |  |  | 5,718 |  |  | 2,529 |  |  | 5,718 |  |
| Change in fair value of public warrant liability | (1,146) |  |  | 3,152 |  |  | 4,297 |  |  | 3,152 |  |
| Change in fair value of common stock warrant liability | — |  |  | 42 |  |  | — |  |  | (879) |  |
| Total other income (expense), net | $ | 7,987 |  |  | $ | 40,167 |  |  | $ | 17,645 |  |  | $ | 19,549 |  |
| Net income (loss) attributable to common stockholders – basic | $ | (18,615) |  |  | $ | 20,807 |  |  | $ | (58,102) |  |  | $ | (15,676) |  |
| Net income (loss) attributable to common stockholders – diluted | $ | (18,615) |  |  | $ | 21,278 |  |  | $ | (58,102) |  |  | $ | (15,676) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |
| Basic | 144,117,273 |  | 119,745,196 |  | 143,522,555 |  | 47,772,253 |
| Diluted | 144,117,273 |  | 153,936,436 |  | 143,522,555 |  | 47,772,253 |
| Net income (loss) per share |  |  |  |  |  |  |  |
| Basic | $ | (0.13) |  |  | $ | 0.17 |  |  | $ | (0.40) |  |  | $ | (0.33) |  |
| Diluted | $ | (0.13) |  |  | $ | 0.14 |  |  | $ | (0.40) |  |  | $ | (0.33) |  |
| Net income (loss) | $ | (18,615) |  |  | $ | 20,807 |  |  | $ | (58,102) |  |  | $ | (15,676) |  |
| Other comprehensive income (loss) |  |  |  |  |  |  |  |
| Cumulative translation adjustment | 45 |  |  | — |  |  | 35 |  |  | — |  |
| Total other comprehensive income | 45 |  |  | — |  |  | 35 |  |  | — |  |
| Total comprehensive income (loss) | $ | (18,570) |  |  | $ | 20,807 |  |  | $ | (58,067) |  |  | $ | (15,676) |  |

[0001628280-22-029266:8k_2_02:40]
EVOLV TECHNOLOGY

[0001628280-22-029266:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-22-029266:8k_2_02:42]
(In thousands, except share and per share data)

[0001628280-22-029266:8k_2_02:43]
(Unaudited)

[0001628280-22-029266:8k_2_02:44]
|  | September 30, 2022 |  | December 31, 2021 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 218,499 |  |  | $ | 307,492 |  |
| Restricted cash | 400 |  |  | 400 |  |
| Accounts receivable, net | 21,199 |  |  | 6,477 |  |
| Inventory | 6,732 |  |  | 2,890 |  |
| Current portion of contract assets | 5,291 |  |  | 1,459 |  |
| Current portion of commission asset | 2,413 |  |  | 1,645 |  |
| Prepaid expenses and other current assets | 20,223 |  |  | 10,757 |  |
| Total current assets | 274,757 |  |  | 331,120 |  |
| Restricted cash, noncurrent | 275 |  |  | 275 |  |
| Contract assets, noncurrent | 1,524 |  |  | 3,418 |  |
| Commission asset, noncurrent | 4,607 |  |  | 3,719 |  |
| Property and equipment, net | 40,532 |  |  | 23,783 |  |
| Operating lease right-of-use assets | 1,882 |  |  | — |  |
| Other assets | 2,045 |  |  | 542 |  |
| Total assets | $ | 325,622 |  |  | $ | 362,857 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 11,139 |  |  | $ | 6,045 |  |
| Accrued expenses and other current liabilities | 8,884 |  |  | 9,551 |  |
| Current portion of deferred revenue | 15,852 |  |  | 6,599 |  |
| Current portion of deferred rent | — |  |  | 135 |  |
| Current portion of long-term debt | 4,000 |  |  | 2,000 |  |
| Current portion of operating lease liabilities | 1,106 |  |  | — |  |
| Total current liabilities | 40,981 |  |  | 24,330 |  |
| Deferred revenue, noncurrent | 9,234 |  |  | 2,475 |  |
| Deferred rent, noncurrent | — |  |  | 333 |  |
| Long-term debt, noncurrent | 4,959 |  |  | 7,945 |  |
| Operating lease liabilities, noncurrent | 1,147 |  |  | — |  |
| Contingent earn-out liability | 11,452 |  |  | 21,206 |  |
| Contingently issuable common stock liability | 2,735 |  |  | 5,264 |  |
| Public warrant liability | 6,733 |  |  | 11,030 |  |
| Total liabilities | 77,241 |  |  | 72,583 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at September 30, 2022 and December 31, 2021; no shares issued and outstanding at September 30, 2022 and December 31, 2021 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at September 30, 2022 and December 31, 2021; 144,434,717 and 142,745,021 shares issued and outstanding at September 30, 2022 and December 31, 2021, respectively | 14 |  |  | 14 |  |
| Additional paid-in capital | 412,238 |  |  | 396,064 |  |
| Accumulated other comprehensive income | 35 |  |  | — |  |
| Accumulated deficit | (163,906) |  |  | (105,804) |  |
| Stockholders’ equity | 248,381 |  |  | 290,274 |  |
| Total liabilities and stockholders’ equity | $ | 325,622 |  |  | $ | 362,857 |  |

[0001628280-22-029266:8k_2_02:45]
EVOLV TECHNOLOGY

[0001628280-22-029266:8k_2_02:46]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-22-029266:8k_2_02:47]
(In thousands)

[0001628280-22-029266:8k_2_02:48]
(Unaudited)

[0001628280-22-029266:8k_2_02:49]
|  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (58,102) |  |  | $ | (15,676) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 3,782 |  |  | 1,948 |  |
| Write-off of inventory | 559 |  |  | 400 |  |
| Adjustment to property and equipment for sales type leases | (625) |  |  | — |  |
| Loss from impairment of property and equipment | 1,038 |  |  | 1,656 |  |
| Loss on disposal of property and equipment | — |  |  | 659 |  |
| Stock-based compensation | 15,513 |  |  | 6,032 |  |
| Non-cash interest expense | 14 |  |  | 5,561 |  |
| Non-cash lease expense | 602 |  |  | — |  |
| Provision recorded for allowance for doubtful accounts | 100 |  |  | (63) |  |
| Loss on extinguishment of debt | — |  |  | 12,685 |  |
| Change in fair value of derivative liability | — |  |  | 1,745 |  |
| Change in fair value of common stock warrant liability | — |  |  | 879 |  |
| Change in fair value of earn-out liability | (9,754) |  |  | (32,609) |  |
| Change in fair value of contingently issuable common stock | (2,529) |  |  | (5,718) |  |
| Change in fair value of public warrant liability | (4,297) |  |  | (3,152) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (14,822) |  |  | (5,866) |  |
| Inventory | (4,401) |  |  | (736) |  |
| Commission assets | (1,656) |  |  | (1,102) |  |
| Contract assets | (1,938) |  |  | (3,477) |  |
| Other assets | (629) |  |  | 23 |  |
| Prepaid expenses and other current assets | (9,009) |  |  | (11,535) |  |
| Accounts payable | 2,177 |  |  | 240 |  |
| Deferred revenue | 16,005 |  |  | 2,352 |  |
| Deferred rent | — |  |  | 397 |  |
| Warranty Reserve | — |  |  | (42) |  |
| Accrued expenses and other current liabilities | (750) |  |  | 2,834 |  |
| Operating lease liability | (699) |  |  | — |  |
| Net cash used in operating activities | (69,421) |  |  | (42,565) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (1,936) |  |  | — |  |
| Purchases of property and equipment | (17,554) |  |  | (10,994) |  |
| Proceeds from sale of property and equipment | 312 |  |  | — |  |
| Net cash used in investing activities | (19,178) |  |  | (10,994) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 571 |  |  | 777 |  |
| Proceeds from issuance of common stock from the PIPE Investment | — |  |  | 300,000 |  |
| Proceeds from the closing of the Merger | — |  |  | 84,945 |  |
| Payment of offering costs from the closing of the Merger and PIPE Investment | — |  |  | (33,968) |  |
| Repayment of financing obligations | — |  |  | (359) |  |
| Proceeds from long-term debt, net of issuance costs | — |  |  | 31,882 |  |
| Repayment of principal on long-term debt | (1,000) |  |  | — |  |
| Net cash provided by (used in) financing activities | (429) |  |  | 383,277 |  |
| Effect of exchange rate changes on cash and cash equivalents | 35 |  |  | — |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (88,993) |  |  | 329,718 |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 308,167 |  |  | 4,704 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 219,174 |  |  | $ | 334,422 |  |

[0001628280-22-029266:8k_2_02:50]
EVOLV TECHNOLOGY

[0001628280-22-029266:8k_2_02:51]
REVISION OF PRIOR PERIOD FINANCIAL STATEMENTS

[0001628280-22-029266:8k_2_02:52]
(In thousands)

[0001628280-22-029266:8k_2_02:53]
(Unaudited)

[0001628280-22-029266:8k_2_02:54]
In preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified various errors in its previously issued financial statements. The identified errors impacted the Company's previously issued 2021 quarterly and annual financial statements and its quarterly financial statements for the three months ended March 31, 2022, and accordingly the Company has made adjustments to the prior period amounts presented herein. A summary of the revisions to certain previously reported financial information impacting amounts presented in this earnings release is as follows (in thousands):

[0001628280-22-029266:8k_2_02:55]
|  | Three Months EndedSeptember 30, 2021 |  | Nine Months EndedSeptember 30, 2021 |
|  | As Previously Reported |  | Adjustment |  | As Revised |  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 5,345 |  |  | $ | 50 |  |  | $ | 5,395 |  |  | $ | 10,299 |  |  | $ | (20) |  |  | $ | 10,279 |  |
| Subscription revenue | 2,305 |  |  | 7 |  |  | 2,312 |  |  | 5,118 |  |  | (58) |  |  | 5,060 |  |
| Service revenue | 717 |  |  | — |  |  | 717 |  |  | 1,429 |  |  | 27 |  |  | 1,456 |  |
| Total revenue | 8,367 |  |  | 57 |  |  | 8,424 |  |  | 16,846 |  |  | (51) |  |  | 16,795 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | 2,933 |  |  | 34 |  |  | 2,967 |  |  | 7,237 |  |  | 149 |  |  | 7,386 |  |
| Cost of subscription revenue | 1,086 |  |  | 191 |  |  | 1,277 |  |  | 2,542 |  |  | 538 |  |  | 3,080 |  |
| Cost of service revenue | 192 |  |  | 521 |  |  | 713 |  |  | 732 |  |  | 953 |  |  | 1,685 |  |
| Total cost of revenue | 4,211 |  |  | 746 |  |  | 4,957 |  |  | 10,511 |  |  | 1,640 |  |  | 12,151 |  |
| Gross profit | 4,156 |  |  | (689) |  |  | 3,467 |  |  | 6,335 |  |  | (1,691) |  |  | 4,644 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 3,641 |  |  | (29) |  |  | 3,612 |  |  | 8,330 |  |  | 69 |  |  | 8,399 |  |
| Sales and marketing expense | 8,510 |  |  | 1,514 |  |  | 10,024 |  |  | 17,284 |  |  | 472 |  |  | 17,756 |  |
| General and administrative | 6,983 |  |  | 552 |  |  | 7,535 |  |  | 11,162 |  |  | 896 |  |  | 12,058 |  |
| Loss from impairment of property and equipment | 1,656 |  |  | — |  |  | 1,656 |  |  | 1,656 |  |  | — |  |  | 1,656 |  |
| Total operating expenses | 20,790 |  |  | 2,037 |  |  | 22,827 |  |  | 38,432 |  |  | 1,437 |  |  | 39,869 |  |
| Loss from operations | (16,634) |  |  | (2,726) |  |  | (19,360) |  |  | (32,097) |  |  | (3,128) |  |  | (35,225) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (286) |  |  | (9) |  |  | (295) |  |  | (5,988) |  |  | 36 |  |  | (5,952) |  |
| Other expense, net | (669) |  |  | — |  |  | (669) |  |  | (669) |  |  | — |  |  | (669) |  |
| Loss on extinguishment of debt | (865) |  |  | — |  |  | (865) |  |  | (12,685) |  |  | — |  |  | (12,685) |  |
| Change in fair value of derivative liability | 475 |  |  | — |  |  | 475 |  |  | (1,745) |  |  | — |  |  | (1,745) |  |
| Change in fair value of contingent earn-out liability | 31,818 |  |  | 791 |  |  | 32,609 |  |  | 31,818 |  |  | 791 |  |  | 32,609 |  |
| Change in fair value of contingently issuable common stock liability | 5,718 |  |  | — |  |  | 5,718 |  |  | 5,718 |  |  | — |  |  | 5,718 |  |
| Change in fair value of public warrant liability | 3,152 |  |  | — |  |  | 3,152 |  |  | 3,152 |  |  | — |  |  | 3,152 |  |
| Change in fair value of common stock warrant liability | 42 |  |  | — |  |  | 42 |  |  | (879) |  |  | — |  |  | (879) |  |
| Total other income (expense), net | 39,385 |  |  | 782 |  |  | 40,167 |  |  | 18,722 |  |  | 827 |  |  | 19,549 |  |
| Net income (loss) attributable to common stockholders - basic | $ | 22,751 |  |  | $ | (1,944) |  |  | $ | 20,807 |  |  | $ | (13,375) |  |  | $ | (2,301) |  |  | $ | (15,676) |  |
| Net income (loss) attributable to common stockholders - diluted | $ | 23,222 |  |  | $ | (1,944) |  |  | $ | 21,278 |  |  | $ | (13,375) |  |  | $ | (2,301) |  |  | $ | (15,676) |  |

[0001628280-22-029266:8k_2_02:56]
|  | December 31, 2021 |
|  | As Previously Reported | Adjustment | As Revised |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 307,492 |  | $ | — |  | $ | 307,492 |  |
| Restricted cash | 400 |  | — |  | 400 |  |
| Accounts receivable, net | 6,477 |  | — |  | 6,477 |  |
| Inventory | 5,140 |  | (2,250) |  | 2,890 |  |
| Current portion of contract assets | 1,459 |  | — |  | 1,459 |  |
| Current portion of commission asset | 1,645 |  | — |  | 1,645 |  |
| Prepaid expenses and other current assets | 11,047 |  | (290) |  | 10,757 |  |
| Total current assets | 333,660 |  | (2,540) |  | 331,120 |  |
| Restricted cash, noncurrent | 275 |  | — |  | 275 |  |
| Contract assets, noncurrent | 3,418 |  | — |  | 3,418 |  |
| Commission asset, noncurrent | 3,719 |  | — |  | 3,719 |  |
| Property and equipment, net | 21,592 |  | 2,191 |  | 23,783 |  |
| Other assets | 401 |  | 141 |  | 542 |  |
| Total assets | $ | 363,065 |  | $ | (208) |  | $ | 362,857 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 6,363 |  | $ | (318) |  | $ | 6,045 |  |
| Accrued expenses and other current liabilities | 9,183 |  | 368 |  | 9,551 |  |
| Current portion of deferred revenue | 6,690 |  | (91) |  | 6,599 |  |
| Current portion of deferred rent | 135 |  | — |  | 135 |  |
| Current portion of long-term debt | 2,000 |  | — |  | 2,000 |  |
| Total current liabilities | 24,371 |  | (41) |  | 24,330 |  |
| Deferred revenue, noncurrent | 2,475 |  | — |  | 2,475 |  |
| Deferred rent, noncurrent | 333 |  | — |  | 333 |  |
| Long-term debt, noncurrent | 7,945 |  | — |  | 7,945 |  |
| Contingent earn-out liability | 20,809 |  | 397 |  | 21,206 |  |
| Contingently issuable common stock liability | 5,264 |  | — |  | 5,264 |  |
| Public warrant liability | 11,030 |  | — |  | 11,030 |  |
| Total liabilities | 72,227 |  | 356 |  | 72,583 |  |
| Stockholders’ equity: |  |  |  |
| Convertible preferred stock | — |  | — |  | — |  |
| Common stock | 14 |  | — |  | 14 |  |
| Additional paid-in capital | 395,563 |  | 501 |  | 396,064 |  |
| Accumulated deficit | (104,739) |  | (1,065) |  | (105,804) |  |
| Stockholders’ equity | 290,838 |  | (564) |  | 290,274 |  |
| Total liabilities and stockholders’ equity | $ | 363,065 |  | $ | (208) |  | $ | 362,857 |  |

[0001628280-22-029266:8k_2_02:57]
EVOLV TECHNOLOGY

[0001628280-22-029266:8k_2_02:58]
RECONCILIATION OF FORECASTED 2022 NET LOSS TO ADJUSTED EBITDA

[0001628280-22-029266:8k_2_02:59]
(In thousands)

[0001628280-22-029266:8k_2_02:60]
(Unaudited)

[0001628280-22-029266:8k_2_02:61]
|  | Twelve Months EndedDecember 31, 2022 |
|  | High |  | Low |
| Net income (loss) | $ | (76,000) |  |  | $ | (78,000) |  |
| Adjustments to reconcile net income (loss) to Adjusted EBITDA: |  |  |  |
| Depreciation and amortization | 5,000 |  |  | 5,000 |  |
| Stock-based compensation | 19,000 |  |  | 19,000 |  |
| Other one-time expenses | 5,000 |  |  | 5,000 |  |
| Other (income) expense | (18,000) |  |  | (18,000) |  |
| Adjusted EBITDA | $ | (65,000) |  |  | $ | (67,000) |  |

[0001628280-22-029266:8k_2_02:62]
EVOLV TECHNOLOGY

[0001628280-22-029266:8k_2_02:63]
SUMMARY OF KEY OPERATING STATISTICS

[0001628280-22-029266:8k_2_02:64]
(Unaudited)

[0001628280-22-029266:8k_2_02:65]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2021 |  | June 30,2021 |  | September 30,2021 |  | December 31,2021 |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |
| New customers |  | 13 |  |  | 21 |  |  | 23 |  |  | 27 |  |  | 44 |  |  | 53 |  |  | 92 |  |
| Total contract value of orders booked |  | $ | 8,424 |  |  | $ | 10,476 |  |  | $ | 16,995 |  |  | $ | 17,916 |  |  | $ | 19,167 |  |  | $ | 22,066 |  |  | $ | 45,353 |  |
| Annual recurring revenue |  | $ | 5,424 |  |  | $ | 7,423 |  |  | $ | 9,932 |  |  | $ | 12,907 |  |  | $ | 16,641 |  |  | $ | 20,865 |  |  | $ | 28,741 |  |
| Remaining performance obligation |  | $ | 17,658 |  |  | $ | 24,930 |  |  | $ | 34,152 |  |  | $ | 51,430 |  |  | $ | 63,750 |  |  | $ | 80,978 |  |  | $ | 109,407 |  |
| Net additions |  | 64 |  |  | 113 |  |  | 176 |  |  | 136 |  |  | 207 |  |  | 237 |  |  | 545 |  |
| Ending deployed units |  | 278 |  |  | 391 |  |  | 567 |  |  | 703 |  |  | 910 |  |  | 1,147 |  |  | 1,692 |  |

[0001628280-22-029266:8k_2_02:66]
EVOLV TECHNOLOGY

[0001628280-22-029266:8k_2_02:67]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001628280-22-029266:8k_2_02:68]
(In thousands)

[0001628280-22-029266:8k_2_02:69]
(Unaudited)

[0001628280-22-029266:8k_2_02:70]
|  | Three Months Ended, |
|  |  | March 31,2021 |  | June 30,2021 |  | September 30,2021 |  | December 31,2021 |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |
| Operating expenses, GAAP |  | $ | 9,400 |  |  | $ | 7,642 |  |  | $ | 22,826 |  |  | $ | 19,429 |  |  | $ | 24,760 |  |  | $ | 25,835 |  |  | $ | 26,827 |  |
| Stock-based compensation(1) |  | (300) |  |  | (1,052) |  |  | (4,589) |  |  | (3,513) |  |  | (3,819) |  |  | (4,781) |  |  | (6,298) |  |
| Restructuring expenses |  | — |  |  | — |  |  | — |  |  | — |  |  | (324) |  |  | 13 |  |  | — |  |
| Loss on impairment of lease equipment |  | — |  |  | — |  |  | (1,656) |  |  | (213) |  |  | (96) |  |  | (316) |  |  | (626) |  |
| Other one-time expenses |  | — |  |  | — |  |  | (685) |  |  | — |  |  | (1,107) |  |  | (2,298) |  |  | (69) |  |
| Adjusted Operating Expenses |  | $ | 9,100 |  |  | $ | 6,590 |  |  | $ | 15,896 |  |  | $ | 15,703 |  |  | $ | 19,414 |  |  | $ | 18,453 |  |  | $ | 19,834 |  |

[0001628280-22-029266:8k_2_02:71]
(1) Reflects immaterial adjustments to previously reported stock-based compensation amounts.

[0001628280-22-029266:8k_2_02:72]
EVOLV TECHNOLOGY

[0001628280-22-029266:8k_2_02:73]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT AND GAAP OPERATING INCOME (LOSS) TO ADJUSTED OPERATING INCOME (LOSS)

[0001628280-22-029266:8k_2_02:74]
(In thousands)

[0001628280-22-029266:8k_2_02:75]
(Unaudited)

[0001628280-22-029266:8k_2_02:76]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue | $ | 16,530 |  |  | $ | 8,424 |  |  | $ | 34,310 |  |  | $ | 16,795 |  |
| Cost of revenue | 16,305 |  |  | 4,957 |  |  | 32,635 |  |  | 12,151 |  |
| Gross Profit, GAAP | 225 |  |  | 3,467 |  |  | 1,675 |  |  | 4,644 |  |
| Stock-based compensation(2) | 227 |  |  | 66 |  |  | 615 |  |  | 91 |  |
| Amortization of capitalized stock-based compensation | 6 |  |  | — |  |  | 15 |  |  | — |  |
| Adjusted Gross Profit | $ | 458 |  |  | $ | 3,533 |  |  | $ | 2,305 |  |  | $ | 4,735 |  |
| Gross Margin % | 1.4 | % |  | 41.2 | % |  | 4.9 | % |  | 27.7 | % |
| Adjusted Gross Margin % | 2.8 | % |  | 41.9 | % |  | 6.7 | % |  | 28.2 | % |

[0001628280-22-029266:8k_2_02:77]
(2) Reflects immaterial adjustments to previously reported stock-based compensation amounts.

[0001628280-22-029266:8k_2_02:78]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Operating income (loss), GAAP | $ | (26,602) |  |  | $ | (19,360) |  |  | $ | (75,747) |  |  | $ | (35,225) |  |
| Stock-based compensation | 6,525 |  |  | 4,655 |  |  | 15,513 |  |  | 6,032 |  |
| Amortization of capitalized stock-based compensation | 6 |  |  | — |  |  | 15 |  |  | — |  |
| Restructuring expenses | — |  |  | — |  |  | 311 |  |  | — |  |
| Loss on impairment of lease equipment | 626 |  |  | 1,656 |  |  | 1,038 |  |  | 1,656 |  |
| Other one-time expenses | 69 |  |  | 685 |  |  | 3,474 |  |  | 685 |  |
| Adjusted Operating Income (loss) | $ | (19,376) |  |  | $ | (12,364) |  |  | $ | (55,396) |  |  | $ | (26,852) |  |

[0001628280-22-029266:8k_2_02:79]
EVOLV TECHNOLOGY

[0001628280-22-029266:8k_2_02:80]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-22-029266:8k_2_02:81]
(In thousands)

[0001628280-22-029266:8k_2_02:82]
(Unaudited)

[0001628280-22-029266:8k_2_02:83]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income (loss) | $ | (18,615) |  |  | $ | 20,807 |  |  | $ | (58,102) |  |  | $ | (15,676) |  |
| Depreciation & amortization | 1,432 |  |  | 846 |  |  | 3,782 |  |  | 1,948 |  |
| Stock-based compensation | 6,525 |  |  | 4,655 |  |  | 15,513 |  |  | 6,032 |  |
| Interest expense (income) | (864) |  |  | 295 |  |  | (1,122) |  |  | 5,952 |  |
| Loss on disposal of property & equipment | — |  |  | 659 |  |  | — |  |  | 659 |  |
| Loss on extinguishment of debt | — |  |  | 865 |  |  | — |  |  | 12,685 |  |
| Change in fair value of derivative liability | — |  |  | (475) |  |  | — |  |  | 1,745 |  |
| Change in fair value of contingent earn-out liability | (7,245) |  |  | (32,609) |  |  | (9,754) |  |  | (32,609) |  |
| Change in fair value of contingently issuable common stock liability | (1,081) |  |  | (5,718) |  |  | (2,529) |  |  | (5,718) |  |
| Change in fair value of public warrant liability | 1,146 |  |  | (3,152) |  |  | (4,297) |  |  | (3,152) |  |
| Change in fair value of common stock warrant liability | — |  |  | (42) |  |  | — |  |  | 879 |  |
| Restructuring expenses | — |  |  | — |  |  | 311 |  |  | — |  |
| Loss on impairment of lease equipment | 626 |  |  | 1,656 |  |  | 1,038 |  |  | 1,656 |  |
| Other one-time expenses | 69 |  |  | 685 |  |  | 3,474 |  |  | 685 |  |
| Adjusted EBITDA | $ | (18,007) |  |  | $ | (11,528) |  |  | $ | (51,686) |  |  | $ | (24,914) |  |

[0001628280-22-029266:8k_2_02:84]
EVOLV TECHNOLOGY

[0001628280-22-029266:8k_2_02:85]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001628280-22-029266:8k_2_02:86]
(In thousands, except share and per share data)

[0001628280-22-029266:8k_2_02:87]
(Unaudited)

[0001628280-22-029266:8k_2_02:88]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income (loss) attributable to common stockholders – diluted | $ | (18,615) |  |  | $ | 21,278 |  |  | $ | (58,102) |  |  | $ | (15,676) |  |
| Stock-based compensation | 6,525 |  |  | 4,655 |  |  | 15,513 |  |  | 6,032 |  |
| Amortization of capitalized stock-based compensation | 6 |  |  | — |  |  | 15 |  |  | — |  |
| Loss on extinguishment of debt | — |  |  | 865 |  |  | — |  |  | 12,685 |  |
| Change in fair value of derivative liability | — |  |  | (475) |  |  | — |  |  | 1,745 |  |
| Change in fair value of contingent earn-out liability | (7,245) |  |  | (32,609) |  |  | (9,754) |  |  | (32,609) |  |
| Change in fair value of contingently issuable common stock liability | (1,081) |  |  | (5,718) |  |  | (2,529) |  |  | (5,718) |  |
| Change in fair value of public warrant liability | 1,146 |  |  | (3,152) |  |  | (4,297) |  |  | (3,152) |  |
| Change in fair value of common stock warrant liability | — |  |  | (42) |  |  | — |  |  | 879 |  |
| Restructuring expenses | — |  |  | — |  |  | 311 |  |  | — |  |
| Loss on impairment of lease equipment | 626 |  |  | 1,656 |  |  | 1,038 |  |  | 1,656 |  |
| Other one-time expenses | 69 |  |  | 685 |  |  | 3,474 |  |  | 685 |  |
| Adjusted earnings (loss) attributable to common stockholders - diluted | $ | (18,569) |  |  | $ | (12,857) |  |  | $ | (54,331) |  |  | $ | (33,473) |  |
| Weighted average common shares outstanding – diluted | 144,117,273 |  |  | 153,936,436 |  |  | 143,522,555 |  |  | 47,772,253 |  |
| Adjusted Earnings Per Share – diluted | $ | (0.13) |  |  | $ | (0.08) |  |  | $ | (0.38) |  |  | $ | (0.70) |  |
