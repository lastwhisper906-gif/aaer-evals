# EVLV 10-Q controls and the auditor's report


## item_4_controls

[0001628280-22-023253:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001628280-22-023253:item_4_controls:2]
Evaluation of disclosure controls and procedures

[0001628280-22-023253:item_4_controls:3]
We maintain disclosure controls and procedures (as that term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) that are designed to ensure that information required to be disclosed in our reports under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms, and that such information is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate, to allow timely decisions regarding required disclosures. In designing and evaluating our disclosure controls and procedures, management recognizes that any controls and procedures, no matter how

[0001628280-22-023253:item_4_controls:4]
well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply judgment in evaluating the benefits of our controls and procedures relative to their costs.

[0001628280-22-023253:item_4_controls:5]
Our management, with the participation of our principal executive officer and principal financial officer, evaluated, as of the end of the period covered by this Quarterly Report on Form 10-Q, the effectiveness of our disclosure controls and procedures (as that term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act). Based on that evaluation, our principal executive officer and principal financial officer concluded that our disclosure controls and procedures were not effective at the reasonable assurance level as of June 30, 2022, due to the material weaknesses in our internal control over financial reporting as described below.

[0001628280-22-023253:item_4_controls:6]
Material Weaknesses in Internal Control over Financial Reporting

[0001628280-22-023253:item_4_controls:7]
We have identified material weaknesses in our internal control over financial reporting. A material weakness is a deficiency, or combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis.

[0001628280-22-023253:item_4_controls:8]
We did not design and maintain an effective control environment commensurate with our financial reporting requirements. Specifically, we lacked a sufficient complement of personnel with an appropriate level of internal controls and accounting knowledge, training and experience commensurate with our financial reporting requirements. Additionally, the limited personnel resulted in our inability to consistently establish appropriate authorities and responsibilities in pursuit of our financial reporting objectives, as demonstrated by, among other things, insufficient segregation of duties in our finance and accounting functions. This material weakness contributed to the following additional material weaknesses:

[0001628280-22-023253:item_4_controls:9]
•We did not design and maintain effective controls over the period-end financial reporting process to achieve complete, accurate and timely financial accounting, reporting and disclosures, including the classification of various accounts in the consolidated financial statements and the presentation and disclosure of items in the consolidated statements of cash flows.

[0001628280-22-023253:item_4_controls:10]
•We did not design and maintain processes and controls to analyze, account for and disclose non-routine, unusual or complex transactions.  Specifically, we did not design and maintain controls to timely analyze and account for debt modifications and extinguishments, convertible notes, warrant instruments, non-routine complex revenue transactions including the leasing of products and transfer of inventory for leased assets into property plant and equipment, merger transactions, and the accounting and valuation of earn out liabilities.

[0001628280-22-023253:item_4_controls:11]
•We did not design and maintain formal accounting policies, procedures and controls to achieve complete, accurate and timely financial accounting, reporting and disclosures, including segregation of duties and controls over the preparation and review of account reconciliations and journal entries.

[0001628280-22-023253:item_4_controls:12]
•We did not design and maintain effective controls to ensure the recording of revenue transactions in the appropriate period.

[0001628280-22-023253:item_4_controls:13]
•We did not design and maintain effective controls over the completeness and accuracy of accounts payable and accrued liabilities.

[0001628280-22-023253:item_4_controls:14]
These material weaknesses resulted in audit adjustments and certain immaterial misstatements in the Evolv financial statements to prepaid and other current assets, accounts payable and accrued liabilities, long-term and short-term debt, convertible notes, contingent earnout liabilities, change in fair value of contingent earn-out liability, equity, commission assets, contract asset, revenue, deferred revenue, accounts receivable, inventory, property plant and equipment, cost of sales and various expense line items and related financial statement disclosures as of and for the years ended December 31, 2019, 2020 and 2021. The material weakness related to accounting for warrant instruments, the classification of various accounts in the consolidated financial statements and the presentation and disclosure of items in the consolidated statements of cash flows also resulted in the revision of the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022. See Note 1 to our condensed consolidated financial statements for the three and six months ended June 30, 2022. Additionally, these material weaknesses could result in a misstatement of substantially all of our accounts or disclosures that would result in a material misstatement to the annual or interim financial statements that would not be prevented or detected.

[0001628280-22-023253:item_4_controls:15]
•In addition to the foregoing, we did not design and maintain effective controls over information technology (“IT”) general controls for information systems that are relevant to the preparation of our consolidated financial statements, specifically, with respect to: (i) program change management controls for financial systems to ensure that IT program and data changes affecting financial IT applications and underlying accounting records are identified, tested, authorized and implemented appropriately; (ii) user access controls to ensure appropriate segregation of duties and that adequately restrict user and privileged access to financial applications, programs, and data to appropriate company personnel; (iii) computer operations controls to ensure that critical batch jobs are monitored and data backups are authorized and monitored, and (iv) testing and approval controls for program development to ensure that new software development is aligned with business and IT requirements. These IT deficiencies did not result in a misstatement to the consolidated financial statements, however, the deficiencies, when aggregated, could impact maintaining effective segregation of duties, as well as the effectiveness of IT-dependent controls (such as automated controls that address the risk of material misstatement to one or more assertions, along with the IT controls and underlying data that support the effectiveness of system-generated data and reports) that could result in misstatements potentially impacting all financial statement accounts and disclosures that would not be prevented or detected. Accordingly, management has determined these deficiencies in the aggregate constitute a material weakness.

[0001628280-22-023253:item_4_controls:16]
Remediation Plan for the Material Weaknesses

[0001628280-22-023253:item_4_controls:17]
We continue to be focused on designing and implementing effective internal controls to improve our internal control over financial reporting and remediate the material weaknesses. Our efforts include a number of actions:

[0001628280-22-023253:item_4_controls:18]
•We have hired additional accounting, internal audit and IT personnel, to bolster our reporting, technical accounting, internal control and IT capabilities. Additionally, we are in the process of designing and implementing controls to formalize roles and review responsibilities to align with our team’s skills and experience and designing and implementing controls over segregation of duties and have engaged outside consultants to assist us in these efforts.

[0001628280-22-023253:item_4_controls:19]
•We added finance personnel, including a Chief Financial Officer and Chief Accounting Officer and Corporate Controller, to the organization to strengthen our internal accounting team, to provide oversight, structure and reporting lines, and to provide additional review over our disclosures.

[0001628280-22-023253:item_4_controls:20]
•We are in the process of designing and implementing controls related to the period-end financial reporting process and controls over the classification of various accounts in our consolidated financial statements, including the  presentation and disclosure of items in the consolidated statements of cash flows.

[0001628280-22-023253:item_4_controls:21]
•We are in the process of designing and implementing controls to timely identify and account for non-routine, unusual or complex transactions, including controls over the preparation and review of accounting memorandum addressing these matters.

[0001628280-22-023253:item_4_controls:22]
•We are in the process of designing and implementing controls related to revenue recognition, including non-routine complex revenue transactions that may also include the leasing of products and the recording of revenue transactions in the appropriate period.

[0001628280-22-023253:item_4_controls:23]
•We are in the process of designing and implementing controls over the completeness and accuracy of accounts payable and accrued liabilities.

[0001628280-22-023253:item_4_controls:24]
•We are in the process of designing and maintaining formal accounting policies, procedures and controls to achieve complete, accurate and timely financial accounting, reporting and disclosures, including controls over the preparation and review of account reconciliations and journal entries.

[0001628280-22-023253:item_4_controls:25]
•We are in the process of designing and implementing information technology general controls, including controls over program change management, the review and update of user access rights and privileges, controls over batch jobs and data backups, and program development approvals and testing. During the three months ended June 30, 2022, we went live on a new ERP system and have implemented, and continue to implement, IT general controls related to the new system.

[0001628280-22-023253:item_4_controls:26]
The process of designing and maintaining effective internal control over financial reporting is a continuous effort that requires management to anticipate and react to changes in our business, economic and regulatory environments and to expend significant resources. As we continue to evaluate our internal control over financial reporting, we may take additional actions to remediate the material weaknesses or modify the remediation actions described above.

[0001628280-22-023253:item_4_controls:27]
While we continue to devote significant time and attention to these remediation efforts, the material weaknesses will not be considered remediated until management completes the design and implementation of the actions described above and the controls operate for a sufficient period of time, and management has concluded, through testing, that these controls are effective.

[0001628280-22-023253:item_4_controls:28]
Changes in Internal Control over Financial Reporting

[0001628280-22-023253:item_4_controls:29]
Other than changes to our internal control over financial reporting described in “Material Weaknesses in Internal Control over Financial Reporting” and “Remediation Plan for the Material Weakness” above, there were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended June 30, 2022 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
