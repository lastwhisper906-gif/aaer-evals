# EVLV 8-K — 0001628280-22-022221 filed 2022-08-10

## item codes, every 8-K on or before 2022-08-18

- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2022-08-18

- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-22-022221:8k_2_02:1]
EX-99.1
2
evlv-20220810exx991.htm
EX-99.1

[0001628280-22-022221:8k_2_02:2]
Document

[0001628280-22-022221:8k_2_02:3]
Exhibit 99.1

[0001628280-22-022221:8k_2_02:4]
Investor Relations:

[0001628280-22-022221:8k_2_02:5]
Brian Norris

[0001628280-22-022221:8k_2_02:6]
Vice President of Finance and Investor Relations

[0001628280-22-022221:8k_2_02:7]
bnorris@evolvtechnology.com

[0001628280-22-022221:8k_2_02:8]
Evolv Technology Reports Strong Second Quarter Financial Results

[0001628280-22-022221:8k_2_02:9]
– Company Reaffirms Outlook for 2022 –

[0001628280-22-022221:8k_2_02:10]
•Q2 Revenue of $9.1 million, up 94% year-over-year

[0001628280-22-022221:8k_2_02:11]
•Q2 Ending ARR of $20.9 million, up 181% year-over-year

[0001628280-22-022221:8k_2_02:12]
•Q2 Ending RPO of $66.2 million, up 166% year-over-year

[0001628280-22-022221:8k_2_02:13]
•Q2 Ending Evolv Express® subscriptions of 1,147, up 193% year-over-year

[0001628280-22-022221:8k_2_02:14]
Waltham, Massachusetts – August 10, 2022 – Evolv Technology (NASDAQ: EVLV), a global leader in weapons detection security screening, today announced financial results for its second quarter ended June 30, 20221 and reaffirmed its business outlook for 2022.

[0001628280-22-022221:8k_2_02:15]
“We are pleased to be reporting strong second quarter results highlighted by the addition of over 50 new customers, continued expansion in our key vertical and geographic markets and important traction with our key channel partners,” said Peter George, President and Chief Executive Officer of Evolv Technology. “We’re particularly pleased to have surpassed 1,100 Evolv Express systems deployed and $100 million in cumulative TCV bookings this quarter.  Based on the strength of our first half results and our growing market momentum, we remain confident in our full year growth plans for 2022.”

[0001628280-22-022221:8k_2_02:16]
Results for the Second Quarter of 2022

[0001628280-22-022221:8k_2_02:17]
Total revenue for the second quarter of 2022 was $9.1 million, an increase of 94% compared to $4.7 million for the second quarter of 2021. Total Contract Value (“TCV”)2 of orders booked for the second quarter of 2022 was $22.1 million, an increase of 111% compared to $10.5 million in the second quarter of 2021. Annual Recurring Revenue (“ARR”)3 was $20.9 million at the end of second quarter of 2022, an increase of 181% compared to $7.4 million at the end of the second quarter of 2021. Net loss for the second quarter of 2022 was $(25.7) million, or $(0.18) per basic and diluted share, compared to net loss of $(23.0) million, or $(1.93) per basic and diluted share, in the second quarter of 2021. Adjusted earnings (loss)4 for the second quarter of 2022 was $(17.3) million, or $(0.12) per basic and diluted share, compared to $(9.1) million, or $(0.76) per basic and diluted share, for the second quarter of 2021. Adjusted EBITDA4 for the second quarter of 2022 was $(16.4) million compared to $(5.2) million in the second quarter of 2021. As of June 30, 2022, the Company had cash and cash equivalents of $242.7 million compared to $270.9 million as of March 31, 2022.

[0001628280-22-022221:8k_2_02:18]
Results for the First Six Months of 2022

[0001628280-22-022221:8k_2_02:19]
Total revenue for the six months ended June 30, 2022 was $17.8 million, an increase of 112% compared to $8.4 million for the six months ended June 30, 2021. TCV2 of orders booked for the six months ended June 30, 2022 was $41.2 million, an increase of 118% compared to $18.9 million in the six months ended June 30, 2021. Net loss for the six months ended June 30, 2022 was $(39.5) million, or $(0.28) per basic and diluted share, compared to net loss of $(36.5) million, or $(3.26) per basic and diluted share, for the six months ended June 30, 2021. Adjusted earnings (loss)4 for the six months ended June 30, 2022 was $(35.8) million, or $(0.25) per basic and diluted share, compared to $(20.1) million, or $(1.80) per basic and

[0001628280-22-022221:8k_2_02:20]
diluted share, for the six months ended June 30, 2021. Adjusted EBITDA4 for the six months ended June 30, 2022 was $(33.7) million, compared to $(13.4) million for the six months ended June 30, 2021.

[0001628280-22-022221:8k_2_02:21]
Company Reaffirms Outlook for 2022

[0001628280-22-022221:8k_2_02:22]
The Company today commented on its business outlook for 2022. The Company's outlook is based on the current indications for its business, which may change at any time.

[0001628280-22-022221:8k_2_02:23]
|  |  | 2022 Business Outlook |
| Estimate (In millions) |  | Issued May 11, 2022 |  | Issued August 10, 2022 |
| Total Revenue |  | $29-$31 |  | No change |
| Annual Recurring Revenue3 (ARR) at 12/31 |  | $27-$28 |  | No change |
| Adjusted EBITDA4 |  | ($65-$67) |  | No change |
| Cash and Cash Equivalents |  | $220-$230 |  | No change |

[0001628280-22-022221:8k_2_02:24]
Company to Host Live Conference Call and Webcast

[0001628280-22-022221:8k_2_02:25]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business and other matters.  The conference call may be accessed in the United States by dialing +1.877.692.8955 and using access code 774298.  The conference call may be accessed outside of the United States by dialing +1.234.720.6979 and using the same access code. The conference call will be simultaneously webcast on the Company’s investor relations website, which can be accessed at http://ir.evolvtechnology.com.  A replay of the conference call will be available for a period of 30 days by dialing +1.866.207.1041 or +1.402.970.0847 and using access code 7860978 or by accessing the webcast replay on the Company’s investor relations website at http://ir.evolvtechnology.com.

[0001628280-22-022221:8k_2_02:26]
About Evolv Technology

[0001628280-22-022221:8k_2_02:27]
Evolv Technology (NASDAQ: EVLV) is transforming human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered weapons detection and analytics.  Its mission is to transform security to create a safer world to work, learn, and play. Evolv has digitally transformed the gateways in places where people gather by enabling seamless integration combined with powerful analytics and insights.  Evolv’s advanced systems have scanned more than 350 million people, second only to the Department of Homeland Security’s Transportation Security Administration (TSA) in the United States.  Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category. For more information, visit https://evolvtechnology.com.

[0001628280-22-022221:8k_2_02:28]
1 Amounts herein pertaining to June 30, 2022 represent a preliminary estimate as of the date of this earnings release. More information on our results of operations for the three and six months ended June 30, 2022 will be provided upon filing our Quarterly Report on Form 10-Q with the Securities and Exchange Commission.

[0001628280-22-022221:8k_2_02:29]
2 We define Total Contract Value, or TCV, of orders booked as the total value of the contract over the specified term. Our calculation of TCV is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases). TCV should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of TCV may differ from similarly titled metrics presented by other companies.

[0001628280-22-022221:8k_2_02:30]
3 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001628280-22-022221:8k_2_02:31]
4 Non-GAAP Financial Measures In this press release, the Company’s adjusted gross profit, adjusted gross margin, adjusted EBITDA, adjusted earnings (loss) and adjusted earnings per share are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit and adjusted gross margin exclude one-time items which management believes provides a more meaningful representation of contribution margin. Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, share-based compensation, and certain other one-time expenses. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, change in fair value of derivative liability, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, change in fair value of common stock warrant liability, restructuring expenses, loss on impairment of lease equipment, and certain other one-time expenses. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release.

[0001628280-22-022221:8k_2_02:32]
Forward-Looking Statements

[0001628280-22-022221:8k_2_02:33]
EVOLV TECHNOLOGY

[0001628280-22-022221:8k_2_02:34]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001628280-22-022221:8k_2_02:35]
(In thousands, except share and per share data)

[0001628280-22-022221:8k_2_02:36]
(Unaudited)

[0001628280-22-022221:8k_2_02:37]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 4,146 |  |  | $ | 2,617 |  |  | $ | 9,340 |  |  | $ | 4,884 |  |
| Subscription revenue | 4,006 |  |  | 1,521 |  |  | 7,010 |  |  | 2,748 |  |
| Service revenue | 918 |  |  | 540 |  |  | 1,430 |  |  | 739 |  |
| Total revenue | 9,070 |  |  | 4,678 |  |  | 17,780 |  |  | 8,371 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 5,347 |  |  | 2,203 |  |  | 10,553 |  |  | 4,419 |  |
| Cost of subscription revenue | 1,981 |  |  | 1,060 |  |  | 3,523 |  |  | 1,803 |  |
| Cost of service revenue | 1,189 |  |  | 687 |  |  | 2,254 |  |  | 972 |  |
| Total cost of revenue | 8,517 |  |  | 3,950 |  |  | 16,330 |  |  | 7,194 |  |
| Gross profit | 553 |  |  | 728 |  |  | 1,450 |  |  | 1,177 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 4,156 |  |  | 1,047 |  |  | 8,331 |  |  | 4,787 |  |
| Sales and marketing | 11,751 |  |  | 5,124 |  |  | 21,423 |  |  | 7,732 |  |
| General and administrative | 9,612 |  |  | 1,471 |  |  | 20,429 |  |  | 4,523 |  |
| Loss from impairment of property and equipment | 316 |  |  | — |  |  | 412 |  |  | — |  |
| Total operating expenses | 25,835 |  |  | 7,642 |  |  | 50,595 |  |  | 17,042 |  |
| Loss from operations | (25,282) |  |  | (6,914) |  |  | (49,145) |  |  | (15,865) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (159) |  |  | (3,263) |  |  | (301) |  |  | (5,657) |  |
| Interest income | 491 |  |  | — |  |  | 559 |  |  | — |  |
| Loss on extinguishment of debt | — |  |  | (11,820) |  |  | — |  |  | (11,820) |  |
| Change in fair value of derivative liability | — |  |  | (795) |  |  | — |  |  | (2,220) |  |
| Change in fair value of contingent earn-out liability | (569) |  |  | — |  |  | 2,509 |  |  | — |  |
| Change in fair value of contingently issuable common stock liability | (24) |  |  | — |  |  | 1,448 |  |  | — |  |
| Change in fair value of public warrant liability | (143) |  |  | — |  |  | 5,443 |  |  | — |  |
| Change in fair value of common stock warrant liability | — |  |  | (185) |  |  | — |  |  | (921) |  |
| Total other income (expense), net | (404) |  |  | (16,063) |  |  | 9,658 |  |  | (20,618) |  |
| Net loss | $ | (25,686) |  |  | $ | (22,977) |  |  | $ | (39,487) |  |  | $ | (36,483) |  |
| Weighted average common shares outstanding - basic and diluted | 143,552,032 |  | 11,922,270 |  | 143,220,268 |  | 11,186,204 |
| Net loss per share - basic and diluted | $ | (0.18) |  |  | $ | (1.93) |  |  | $ | (0.28) |  |  | $ | (3.26) |  |
| Net loss | $ | (25,686) |  |  | $ | (22,977) |  |  | $ | (39,487) |  |  | $ | (36,483) |  |
| Other comprehensive loss |  |  |  |  |  |  |  |
| Cumulative translation adjustment | (10) |  |  | — |  |  | (10) |  |  | — |  |
| Total other comprehensive loss | (10) |  |  | — |  |  | (10) |  |  | — |  |
| Total comprehensive loss | $ | (25,696) |  |  | $ | (22,977) |  |  | $ | (39,497) |  |  | $ | (36,483) |  |

[0001628280-22-022221:8k_2_02:38]
EVOLV TECHNOLOGY

[0001628280-22-022221:8k_2_02:39]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-22-022221:8k_2_02:40]
(In thousands, except share and per share data)

[0001628280-22-022221:8k_2_02:41]
(Unaudited)

[0001628280-22-022221:8k_2_02:42]
|  | June 30, 2022 |  | December 31, 2021 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 242,691 |  |  | $ | 307,492 |  |
| Restricted cash | 400 |  |  | 400 |  |
| Accounts receivable, net | 12,183 |  |  | 6,477 |  |
| Inventory | 6,010 |  |  | 2,890 |  |
| Current portion of contract assets | 6,180 |  |  | 1,459 |  |
| Current portion of commission asset | 2,079 |  |  | 1,645 |  |
| Prepaid expenses and other current assets | 20,920 |  |  | 10,757 |  |
| Total current assets | 290,463 |  |  | 331,120 |  |
| Restricted cash, noncurrent | 275 |  |  | 275 |  |
| Contract assets, noncurrent | 3,159 |  |  | 3,418 |  |
| Commission asset, noncurrent | 3,624 |  |  | 3,719 |  |
| Property and equipment, net | 34,379 |  |  | 23,783 |  |
| Operating lease right-of-use assets | 2,092 |  |  | — |  |
| Other assets | 2,172 |  |  | 542 |  |
| Total assets | $ | 336,164 |  |  | $ | 362,857 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 9,427 |  |  | $ | 6,045 |  |
| Accrued expenses and other current liabilities | 7,759 |  |  | 9,551 |  |
| Current portion of deferred revenue | 13,892 |  |  | 6,599 |  |
| Current portion of deferred rent | — |  |  | 135 |  |
| Current portion of long-term debt | 4,000 |  |  | 2,000 |  |
| Current portion of operating lease liabilities | 1,097 |  |  | — |  |
| Total current liabilities | 36,175 |  |  | 24,330 |  |
| Deferred revenue, noncurrent | 4,330 |  |  | 2,475 |  |
| Deferred rent, noncurrent | — |  |  | 333 |  |
| Long-term debt, noncurrent | 5,955 |  |  | 7,945 |  |
| Operating lease liabilities, noncurrent | 1,398 |  |  | — |  |
| Contingent earn-out liability | 18,697 |  |  | 21,206 |  |
| Contingently issuable common stock liability | 3,816 |  |  | 5,264 |  |
| Public warrant liability | 5,587 |  |  | 11,030 |  |
| Total liabilities | 75,958 |  |  | 72,583 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at June 30, 2022 and December 31, 2021; no shares issued and outstanding at June 30, 2022 and December 31, 2021 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at June 30, 2022 and December 31, 2021; 143,829,995 and 142,745,021 shares issued and outstanding at June 30, 2022 and December 31, 2021, respectively | 14 |  |  | 14 |  |
| Additional paid-in capital | 405,493 |  |  | 396,064 |  |
| Accumulated other comprehensive loss | (10) |  |  | — |  |
| Accumulated deficit | (145,291) |  |  | (105,804) |  |
| Stockholders’ equity | 260,206 |  |  | 290,274 |  |
| Total liabilities and stockholders’ equity | $ | 336,164 |  |  | $ | 362,857 |  |

[0001628280-22-022221:8k_2_02:43]
EVOLV TECHNOLOGY

[0001628280-22-022221:8k_2_02:44]
REVISION OF PRIOR PERIOD FINANCIAL STATEMENTS

[0001628280-22-022221:8k_2_02:45]
(In thousands)

[0001628280-22-022221:8k_2_02:46]
(Unaudited)

[0001628280-22-022221:8k_2_02:47]
In preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified various errors in its previously issued financial statements. The identified errors impacted the Company's previously issued 2021 quarterly and annual financial statements and its quarterly financial statements for the three months ended March 31, 2022, and accordingly the Company has made adjustments to the prior period amounts presented herein. A summary of the revisions to certain previously reported financial information impacting amounts presented in this earnings release is as follows (in thousands):

[0001628280-22-022221:8k_2_02:48]
|  | Three Months EndedJune 30, 2021 |  | Six Months EndedJune 30, 2021 |
|  | As Previously Reported |  | Adjustment |  | Revised |  | As Previously Reported |  | Adjustment |  | Revised |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 2,452 |  |  | $ | 165 |  |  | $ | 2,617 |  |  | $ | 4,954 |  |  | $ | (70) |  |  | $ | 4,884 |  |
| Subscription revenue | 1,513 |  |  | 8 |  |  | 1,521 |  |  | 2,813 |  |  | (65) |  |  | 2,748 |  |
| Service revenue | 515 |  |  | 25 |  |  | 540 |  |  | 712 |  |  | 27 |  |  | 739 |  |
| Total revenue | 4,480 |  |  | 198 |  |  | 4,678 |  |  | 8,479 |  |  | (108) |  |  | 8,371 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | 2,075 |  |  | 128 |  |  | 2,203 |  |  | 4,304 |  |  | 115 |  |  | 4,419 |  |
| Cost of subscription revenue | 861 |  |  | 199 |  |  | 1,060 |  |  | 1,456 |  |  | 347 |  |  | 1,803 |  |
| Cost of service revenue | 413 |  |  | 274 |  |  | 687 |  |  | 540 |  |  | 432 |  |  | 972 |  |
| Total cost of revenue | 3,349 |  |  | 601 |  |  | 3,950 |  |  | 6,300 |  |  | 894 |  |  | 7,194 |  |
| Gross profit | 1,131 |  |  | (403) |  |  | 728 |  |  | 2,179 |  |  | (1,002) |  |  | 1,177 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,077 |  |  | (30) |  |  | 1,047 |  |  | 4,689 |  |  | 98 |  |  | 4,787 |  |
| Sales and marketing expense | 5,090 |  |  | 34 |  |  | 5,124 |  |  | 8,774 |  |  | (1,042) |  |  | 7,732 |  |
| General and administrative | 1,280 |  |  | 191 |  |  | 1,471 |  |  | 4,179 |  |  | 344 |  |  | 4,523 |  |
| Loss from impairment of property and equipment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | 7,447 |  |  | 195 |  |  | 7,642 |  |  | 17,642 |  |  | (600) |  |  | 17,042 |  |
| Loss from operations | (6,316) |  |  | (598) |  |  | (6,914) |  |  | (15,463) |  |  | (402) |  |  | (15,865) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (3,255) |  |  | (8) |  |  | (3,263) |  |  | (5,702) |  |  | 45 |  |  | (5,657) |  |
| Interest income | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Loss on extinguishment of debt | (11,820) |  |  | — |  |  | (11,820) |  |  | (11,820) |  |  | — |  |  | (11,820) |  |
| Change in fair value of derivative liability | (795) |  |  | — |  |  | (795) |  |  | (2,220) |  |  | — |  |  | (2,220) |  |
| Change in fair value of contingent earn-out liability | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Change in fair value of contingently issuable common stock liability | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Change in fair value of public warrant liability | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Change in fair value of common stock warrant liability | (185) |  |  | — |  |  | (185) |  |  | (921) |  |  | — |  |  | (921) |  |
| Total other income (expense), net | (16,055) |  |  | (8) |  |  | (16,063) |  |  | (20,663) |  |  | 45 |  |  | (20,618) |  |
| Net loss | $ | (22,371) |  |  | $ | (606) |  |  | $ | (22,977) |  |  | $ | (36,126) |  |  | $ | (357) |  |  | $ | (36,483) |  |

[0001628280-22-022221:8k_2_02:49]
|  | December 31, 2021 |
|  | As Previously Reported | Adjustment | Revised |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 307,492 |  | $ | — |  | $ | 307,492 |  |
| Restricted cash | 400 |  | — |  | 400 |  |
| Accounts receivable, net | 6,477 |  | — |  | 6,477 |  |
| Inventory | 5,140 |  | (2,250) |  | 2,890 |  |
| Current portion of contract assets | 1,459 |  | — |  | 1,459 |  |
| Current portion of commission asset | 1,645 |  | — |  | 1,645 |  |
| Prepaid expenses and other current assets | 11,047 |  | (290) |  | 10,757 |  |
| Total current assets | 333,660 |  | (2,540) |  | 331,120 |  |
| Restricted cash, noncurrent | 275 |  | — |  | 275 |  |
| Contract assets, noncurrent | 3,418 |  | — |  | 3,418 |  |
| Commission asset, noncurrent | 3,719 |  | — |  | 3,719 |  |
| Property and equipment, net | 21,592 |  | 2,191 |  | 23,783 |  |
| Operating lease right-of-use assets | — |  | — |  | — |  |
| Other assets | 401 |  | 141 |  | 542 |  |
| Total assets | $ | 363,065 |  | $ | (208) |  | $ | 362,857 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 6,363 |  | $ | (318) |  | $ | 6,045 |  |
| Accrued expenses and other current liabilities | 9,183 |  | 368 |  | 9,551 |  |
| Current portion of deferred revenue | 6,690 |  | (91) |  | 6,599 |  |
| Current portion of deferred rent | 135 |  | — |  | 135 |  |
| Current portion of long-term debt | 2,000 |  | — |  | 2,000 |  |
| Current portion of operating lease liabilities | — |  | — |  | — |  |
| Total current liabilities | 24,371 |  | (41) |  | 24,330 |  |
| Deferred revenue, noncurrent | 2,475 |  | — |  | 2,475 |  |
| Deferred rent, noncurrent | 333 |  | — |  | 333 |  |
| Long-term debt, noncurrent | 7,945 |  | — |  | 7,945 |  |
| Operating lease liabilities, noncurrent | — |  | — |  | — |  |
| Contingent earn-out liability | 20,809 |  | 397 |  | 21,206 |  |
| Contingently issuable common stock liability | 5,264 |  | — |  | 5,264 |  |
| Public warrant liability | 11,030 |  | — |  | 11,030 |  |
| Total liabilities | 72,227 |  | 356 |  | 72,583 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at December 31, 2021; no shares issued and outstanding at December 31, 2021 | — |  | — |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at December 31, 2021; 142,745,021 shares issued and outstanding at December 31, 2021 | 14 |  | — |  | 14 |  |
| Additional paid-in capital | 395,563 |  | 501 |  | 396,064 |  |
| Accumulated other comprehensive loss | — |  | — |  | — |  |
| Accumulated deficit | (104,739) |  | (1,065) |  | (105,804) |  |
| Stockholders’ equity | 290,838 |  | (564) |  | 290,274 |  |
| Total liabilities and stockholders’ equity | $ | 363,065 |  | $ | (208) |  | $ | 362,857 |  |

[0001628280-22-022221:8k_2_02:50]
EVOLV TECHNOLOGY

[0001628280-22-022221:8k_2_02:51]
RECONCILIATION OF FORECASTED 2022 NET LOSS TO ADJUSTED EBITDA

[0001628280-22-022221:8k_2_02:52]
(In thousands)

[0001628280-22-022221:8k_2_02:53]
(Unaudited)

[0001628280-22-022221:8k_2_02:54]
|  | Twelve Months EndedDecember 31, 2022 |
|  | High |  | Low |
| Net income (loss) | $ | (81,000) |  |  | $ | (83,000) |  |
| Adjustments to reconcile net income (loss) to Adjusted EBITDA: |  |  |  |
| Depreciation and amortization | 6,000 |  |  | 6,000 |  |
| Stock-based compensation | 17,000 |  |  | 17,000 |  |
| Other one-time expenses | 5,000 |  |  | 5,000 |  |
| Other (income) expense | (12,000) |  |  | (12,000) |  |
| Adjusted EBITDA | $ | (65,000) |  |  | $ | (67,000) |  |

[0001628280-22-022221:8k_2_02:55]
EVOLV TECHNOLOGY

[0001628280-22-022221:8k_2_02:56]
SUMMARY OF KEY OPERATING STATISTICS

[0001628280-22-022221:8k_2_02:57]
(Unaudited)

[0001628280-22-022221:8k_2_02:58]
|  | Three Months Ended, |
| ($ in thousands) |  | March 31,2021 |  | June 30,2021 |  | September 30,2021 |  | December 31,2021 |  | March 31,2022 |  | June 30,2022 |
| New customers |  | 13 |  |  | 21 |  |  | 23 |  |  | 27 |  |  | 44 |  |  | 53 |  |
| Total contract value of orders booked |  | $ | 8,424 |  |  | $ | 10,476 |  |  | $ | 16,995 |  |  | $ | 17,916 |  |  | $ | 19,167 |  |  | $ | 22,066 |  |
| Annual recurring revenue |  | $ | 5,424 |  |  | $ | 7,423 |  |  | $ | 9,932 |  |  | $ | 12,907 |  |  | $ | 16,641 |  |  | $ | 20,865 |  |
| Remaining performance obligation |  | $ | 17,658 |  |  | $ | 24,930 |  |  | $ | 34,152 |  |  | $ | 40,160 |  |  | $ | 50,537 |  |  | $ | 66,238 |  |
| Contract value for units in backlog |  | n/a |  | n/a |  | n/a |  | $ | 11,270 |  |  | $ | 13,213 |  |  | $ | 14,740 |  |
| Net additions |  | 64 |  |  | 113 |  |  | 176 |  |  | 136 |  |  | 207 |  |  | 237 |  |
| Ending deployed units |  | 278 |  |  | 391 |  |  | 567 |  |  | 703 |  |  | 910 |  |  | 1,147 |  |

[0001628280-22-022221:8k_2_02:59]
EVOLV TECHNOLOGY

[0001628280-22-022221:8k_2_02:60]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001628280-22-022221:8k_2_02:61]
(In thousands)

[0001628280-22-022221:8k_2_02:62]
(Unaudited)

[0001628280-22-022221:8k_2_02:63]
|  | Three Months Ended, |
|  |  | March 31,2021 |  | June 30,2021 |  | September 30,2021 |  | December 31,2021 |  | March 31,2022 |  | June 30,2022 |
| Operating expenses, GAAP |  | $ | 9,400 |  |  | $ | 7,642 |  |  | $ | 22,826 |  |  | $ | 19,429 |  |  | $ | 24,760 |  |  | $ | 25,835 |  |
| Stock-based compensation |  | (304) |  |  | (1,062) |  |  | (4,626) |  |  | (3,546) |  |  | (3,867) |  |  | (5,010) |  |
| Restructuring expenses |  | — |  |  | — |  |  | — |  |  | — |  |  | (324) |  |  | 14 |  |
| Loss on impairment of lease equipment |  | — |  |  | — |  |  | (1,656) |  |  | (213) |  |  | (96) |  |  | (316) |  |
| Other one-time expenses |  | — |  |  | — |  |  | (685) |  |  | — |  |  | (1,107) |  |  | (2,298) |  |
| Adjusted Operating Expenses |  | $ | 9,096 |  |  | $ | 6,580 |  |  | $ | 15,859 |  |  | $ | 15,670 |  |  | $ | 19,366 |  |  | $ | 18,225 |  |

[0001628280-22-022221:8k_2_02:64]
EVOLV TECHNOLOGY

[0001628280-22-022221:8k_2_02:65]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT AND GAAP OPERATING INCOME (LOSS) TO ADJUSTED OPERATING INCOME (LOSS)

[0001628280-22-022221:8k_2_02:66]
(In thousands)

[0001628280-22-022221:8k_2_02:67]
(Unaudited)

[0001628280-22-022221:8k_2_02:68]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue | $ | 9,070 |  |  | $ | 4,678 |  |  | $ | 17,780 |  |  | $ | 8,371 |  |
| Cost of revenue | 8,517 |  |  | 3,950 |  |  | 16,330 |  |  | 7,194 |  |
| Gross Profit, GAAP | 553 |  |  | 728 |  |  | 1,450 |  |  | 1,177 |  |
| Stock-based compensation | 52 |  |  | 5 |  |  | 112 |  |  | 10 |  |
| Amortization of capitalized stock-based compensation | 5 |  |  | — |  |  | 9 |  |  | — |  |
| Adjusted Gross Profit | $ | 610 |  |  | $ | 733 |  |  | $ | 1,571 |  |  | $ | 1,187 |  |
| Gross Margin % | 6.1 | % |  | 15.6 | % |  | 8.2 | % |  | 14.1 | % |
| Adjusted Gross Margin % | 6.7 | % |  | 15.7 | % |  | 8.8 | % |  | 14.2 | % |

[0001628280-22-022221:8k_2_02:69]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Operating income (loss), GAAP | $ | (25,282) |  |  | $ | (6,914) |  |  | $ | (49,145) |  |  | $ | (15,865) |  |
| Stock-based compensation | 5,061 |  |  | 1,069 |  |  | 8,988 |  |  | 1,376 |  |
| Amortization of capitalized stock-based compensation | 5 |  |  | — |  |  | 9 |  |  | — |  |
| Restructuring expenses | (13) |  |  | — |  |  | 311 |  |  | — |  |
| Loss on impairment of lease equipment | 316 |  |  | — |  |  | 412 |  |  | — |  |
| Other one-time expenses | 2,298 |  |  | — |  |  | 3,405 |  |  | — |  |
| Adjusted Operating Income (loss) | $ | (17,615) |  |  | $ | (5,845) |  |  | $ | (36,020) |  |  | $ | (14,489) |  |

[0001628280-22-022221:8k_2_02:70]
EVOLV TECHNOLOGY

[0001628280-22-022221:8k_2_02:71]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-22-022221:8k_2_02:72]
(In thousands)

[0001628280-22-022221:8k_2_02:73]
(Unaudited)

[0001628280-22-022221:8k_2_02:74]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income (loss) | $ | (25,686) |  |  | $ | (22,977) |  |  | $ | (39,487) |  |  | $ | (36,483) |  |
| Depreciation & amortization | 1,264 |  |  | 611 |  |  | 2,350 |  |  | 1,053 |  |
| Stock-based compensation | 5,061 |  |  | 1,069 |  |  | 8,988 |  |  | 1,376 |  |
| Interest and other expense (income) | (332) |  |  | 3,263 |  |  | (258) |  |  | 5,657 |  |
| Loss on extinguishment of debt | — |  |  | 11,820 |  |  | — |  |  | 11,820 |  |
| Change in fair value of derivative liability | — |  |  | 795 |  |  | — |  |  | 2,220 |  |
| Change in fair value of contingent earn-out liability | 569 |  |  | — |  |  | (2,509) |  |  | — |  |
| Change in fair value of contingently issuable common stock liability | 24 |  |  | — |  |  | (1,448) |  |  | — |  |
| Change in fair value of public warrant liability | 143 |  |  | — |  |  | (5,443) |  |  | — |  |
| Change in fair value of common stock warrant liability | — |  |  | 185 |  |  | — |  |  | 921 |  |
| Restructuring expenses | (13) |  |  | — |  |  | 311 |  |  | — |  |
| Loss on impairment of lease equipment | 316 |  |  | — |  |  | 412 |  |  | — |  |
| Other one-time expenses | 2,298 |  |  | — |  |  | 3,405 |  |  | — |  |
| Adjusted EBITDA | $ | (16,356) |  |  | $ | (5,234) |  |  | $ | (33,679) |  |  | $ | (13,436) |  |

[0001628280-22-022221:8k_2_02:75]
EVOLV TECHNOLOGY

[0001628280-22-022221:8k_2_02:76]
RECONCILIATION OF GAAP NET INCOME (LOSS) AND EARNINGS PER SHARE TO ADJUSTED EARNINGS (LOSS) AND ADJUSTED EARNINGS PER SHARE

[0001628280-22-022221:8k_2_02:77]
(In thousands, except share and per share data)

[0001628280-22-022221:8k_2_02:78]
(Unaudited)

[0001628280-22-022221:8k_2_02:79]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income (loss) | $ | (25,686) |  |  | $ | (22,977) |  |  | $ | (39,487) |  |  | $ | (36,483) |  |
| Stock-based compensation | 5,061 |  |  | 1,069 |  |  | 8,988 |  |  | 1,376 |  |
| Amortization of capitalized stock-based compensation | 5 |  |  | — |  |  | 9 |  |  | — |  |
| Loss on extinguishment of debt | — |  |  | 11,820 |  |  | — |  |  | 11,820 |  |
| Change in fair value of derivative liability | — |  |  | 795 |  |  | — |  |  | 2,220 |  |
| Change in fair value of contingent earn-out liability | 569 |  |  | — |  |  | (2,509) |  |  | — |  |
| Change in fair value of contingently issuable common stock liability | 24 |  |  | — |  |  | (1,448) |  |  | — |  |
| Change in fair value of public warrant liability | 143 |  |  | — |  |  | (5,443) |  |  | — |  |
| Change in fair value of common stock warrant liability | — |  |  | 185 |  |  | — |  |  | 921 |  |
| Restructuring expenses | (13) |  |  | — |  |  | 311 |  |  | — |  |
| Loss on impairment of lease equipment | 316 |  |  | — |  |  | 412 |  |  | — |  |
| Other one-time expenses | 2,298 |  |  | — |  |  | 3,405 |  |  | — |  |
| Adjusted earnings (loss) | $ | (17,283) |  |  | $ | (9,108) |  |  | $ | (35,762) |  |  | $ | (20,146) |  |
| Weighted average common shares outstanding – basic and diluted | 143,552,032 |  |  | 11,922,270 |  |  | 143,220,268 |  |  | 11,186,204 |  |
| Adjusted EPS | $ | (0.12) |  |  | $ | (0.76) |  |  | $ | (0.25) |  |  | $ | (1.80) |  |
