# EVLV MD&A — 0001628280-22-023253


## mdna

[0001628280-22-023253:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001628280-22-023253:mdna:2]
In preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, we identified immaterial errors in our previously issued financial statements. We have corrected the amounts as presented in this Item 2 accordingly. Please refer to Notes 1 and 21 to the financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional information.

[0001628280-22-023253:mdna:3]
[same as prior period, unchanged from 0001558370-22-008639:mdna:2]

[0001628280-22-023253:mdna:4]
[same as prior period, unchanged from 0001558370-22-008639:mdna:3]

[0001628280-22-023253:mdna:5]
[same as prior period, unchanged from 0001558370-22-008639:mdna:4]

[0001628280-22-023253:mdna:6]
[same as prior period, unchanged from 0001558370-22-008639:mdna:5]

[0001628280-22-023253:mdna:7]
Our products have screened over 350 million visitors worldwide. We believe that we have screened more people through advanced systems than any organization other than the United States Transportation Security Administration (“TSA”). Our customers include many iconic venues across a wide variety of industries, including major sports stadiums and arenas, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, large industrial workplaces, schools in large districts, and prominent houses of worship. We offer our products for purchase and primarily under a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue and creates expansion and upsell opportunities.

[0001628280-22-023253:mdna:8]
[same as prior period, unchanged from 0001558370-22-008639:mdna:7]

[0001628280-22-023253:mdna:9]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $9.1 million and $4.7 million for the three months ended

[0001628280-22-023253:mdna:10]
June 30, 2022 and 2021, respectively. We generated a net loss of $25.7 million and $23.0 million for the three months ended June 30, 2022 and 2021, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products in both the United States and international markets, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-22-023253:mdna:11]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through a combination of equity offerings and debt financings. In July 2021, we received gross proceeds of $300.0 million from our PIPE Investment as well as $84.9 million in proceeds, net of redemptions received from the closing of the Merger. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources.”

[0001628280-22-023253:mdna:12]
[same as prior period, unchanged from 0001558370-22-008639:mdna:12]

[0001628280-22-023253:mdna:13]
[same as prior period, unchanged from 0001558370-22-008639:mdna:13]

[0001628280-22-023253:mdna:14]
[same as prior period, unchanged from 0001558370-22-008639:mdna:14]

[0001628280-22-023253:mdna:15]
[same as prior period, unchanged from 0001558370-22-008639:mdna:15]

[0001628280-22-023253:mdna:16]
Additional information regarding the Merger Agreement appears in Note 3 of our condensed consolidated financial statements for the three and six months ended June 30, 2022.

[0001628280-22-023253:mdna:17]
[same as prior period, unchanged from 0001558370-22-008639:mdna:17]

[0001628280-22-023253:mdna:18]
We have taken, and will continue to take, actions to mitigate the impact of the COVID-19 pandemic on our cash flow and results of operations and financial condition. While we have experienced supply chain challenges during the three and six months ended June 30, 2022, we do see this being overcome in the near future. In the long-term, we believe that the COVID-19 pandemic may encourage organizations to continue to reassess their security screening processes and may continue to accelerate their adoption of solutions such as touchless security screening, which could create additional demand for our products.

[0001628280-22-023253:mdna:19]
[same as prior period, unchanged from 0001558370-22-008639:mdna:19]

[0001628280-22-023253:mdna:20]
[same as prior period, unchanged from 0001558370-22-008639:mdna:20]

[0001628280-22-023253:mdna:21]
[same as prior period, unchanged from 0001558370-22-008639:mdna:21]

[0001628280-22-023253:mdna:22]
[same as prior period, unchanged from 0001558370-22-008639:mdna:22]

[0001628280-22-023253:mdna:23]
[same as prior period, unchanged from 0001558370-22-008639:mdna:23]

[0001628280-22-023253:mdna:24]
[same as prior period, unchanged from 0001558370-22-008639:mdna:24]

[0001628280-22-023253:mdna:25]
Revenue generated by the sale of products represented 46% and 56% of our total revenue for the three months ended June 30, 2022 and 2021, respectively. The remaining revenue was generated from subscription sales and services for our products. Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions. Subscription revenue was $4.0 million and $1.5 million for the three months ended June 30, 2022 and 2021, respectively. With the further recent development, enhancement, and maintenance of Evolv Insights and its analytical platform, as well as our plan to lead increasingly with our subscription offering, we expect subscription revenue as a percentage of total revenue to increase in future periods.

[0001628280-22-023253:mdna:26]
Pricing may also vary by region due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales/bookings/business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products to our customers.

[0001628280-22-023253:mdna:27]
[same as prior period, unchanged from 0001558370-22-008639:mdna:27]

[0001628280-22-023253:mdna:28]
[same as prior period, unchanged from 0001558370-22-008639:mdna:28]

[0001628280-22-023253:mdna:29]
[same as prior period, unchanged from 0001558370-22-008639:mdna:29]

[0001628280-22-023253:mdna:30]
[same as prior period, unchanged from 0001558370-22-008639:mdna:30]

[0001628280-22-023253:mdna:31]
The Earn-Out Shares are classified as liabilities in our condensed consolidated balance sheets and were initially measured at fair value. Each reporting period, the Earn-Out Shares are remeasured and changes in the fair value of the contingent earn-out are recorded in other income (expense), net in our condensed consolidated statements of operations and comprehensive loss. When the Triggering Events have been achieved and the Earn-Out Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001628280-22-023253:mdna:32]
[same as prior period, unchanged from 0001558370-22-008639:mdna:33]

[0001628280-22-023253:mdna:33]
[same as prior period, unchanged from 0001558370-22-008639:mdna:34]

[0001628280-22-023253:mdna:34]
[same as prior period, unchanged from 0001558370-22-008639:mdna:35]

[0001628280-22-023253:mdna:35]
[same as prior period, unchanged from 0001558370-22-008639:mdna:36]

[0001628280-22-023253:mdna:36]
[same as prior period, unchanged from 0001558370-22-008639:mdna:37]

[0001628280-22-023253:mdna:37]
[same as prior period, unchanged from 0001558370-22-008639:mdna:38]

[0001628280-22-023253:mdna:38]
[same as prior period, unchanged from 0001558370-22-008639:mdna:39]

[0001628280-22-023253:mdna:39]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, (2) from the sale of products, inclusive of SaaS and maintenance, and (3) professional services. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer for product sales and upon installation for subscriptions. Revenue is recognized net of sales tax.

[0001628280-22-023253:mdna:40]
[same as prior period, unchanged from 0001558370-22-008639:mdna:41]

[0001628280-22-023253:mdna:41]
[same as prior period, unchanged from 0001558370-22-008639:mdna:42]

[0001628280-22-023253:mdna:42]
[same as prior period, unchanged from 0001558370-22-008639:mdna:43]

[0001628280-22-023253:mdna:43]
[same as prior period, unchanged from 0001558370-22-008639:mdna:44]

[0001628280-22-023253:mdna:44]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (1) distinct services, such as SaaS, maintenance, installation and training, and (2) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our condensed consolidated statements of operations and comprehensive loss.

[0001628280-22-023253:mdna:45]
[same as prior period, unchanged from 0001558370-22-008639:mdna:47]

[0001628280-22-023253:mdna:46]
We provide SaaS, maintenance, installation and training services for our products. Revenue for installation and training are recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes and when-and-if available threat updates. SaaS and maintenance revenue is recognized ratably over the period of the arrangement.

[0001628280-22-023253:mdna:47]
[same as prior period, unchanged from 0001558370-22-008639:mdna:49]

[0001628280-22-023253:mdna:48]
[same as prior period, unchanged from 0001558370-22-008639:mdna:50]

[0001628280-22-023253:mdna:49]
[same as prior period, unchanged from 0001558370-22-008639:mdna:51]

[0001628280-22-023253:mdna:50]
Cost of product revenue consists primarily of costs paid to third party manufacturers, labor costs (including stock-based compensation), and shipping costs.

[0001628280-22-023253:mdna:51]
[same as prior period, unchanged from 0001558370-22-008639:mdna:53]

[0001628280-22-023253:mdna:52]
Cost of subscription revenue consists primarily of shipping costs, an allocated portion of internal-use software amortization expense related to the Evolv cloud portal, depreciation expense related to leased units, and maintenance costs related to leased units. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001628280-22-023253:mdna:53]
[same as prior period, unchanged from 0001558370-22-008639:mdna:55]

[0001628280-22-023253:mdna:54]
Cost of services revenue consists of costs related to installation and training services, an allocated portion of internal-use software amortization expense related to the Evolv cloud portal, and maintenance costs related to units purchased by customers. Maintenance costs consists primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001628280-22-023253:mdna:55]
A provision for the estimated cost related to warranty is recognized as necessary. Our estimate of costs to service the warranty obligations is based on historical experience and expectations of future conditions. As of June 30, 2022, the warranty accrual was less than $0.1 million.

[0001628280-22-023253:mdna:56]
[same as prior period, unchanged from 0001558370-22-008639:mdna:58]

[0001628280-22-023253:mdna:57]
Our gross profit is calculated based on the difference between our revenues and cost of revenues. Gross margin is the percentage obtained by dividing gross profit by our revenue. Our gross profit and gross margin are, or may be, influenced by a number of factors, including:

[0001628280-22-023253:mdna:58]
•Market conditions that may impact our pricing;

[0001628280-22-023253:mdna:59]
•Product mix changes between established products and new products;

[0001628280-22-023253:mdna:60]
•Our cost structure for manufacturing operations, including contract manufacturers, relative to volume, and our product support obligations;

[0001628280-22-023253:mdna:61]
•Our ability to maintain our costs on the components that go into the manufacture of our product; and

[0001628280-22-023253:mdna:62]
•Write-offs of inventory.

[0001628280-22-023253:mdna:63]
[same as prior period, unchanged from 0001558370-22-008639:mdna:65]

[0001628280-22-023253:mdna:64]
[same as prior period, unchanged from 0001558370-22-008639:mdna:66]

[0001628280-22-023253:mdna:65]
[same as prior period, unchanged from 0001558370-22-008639:mdna:67]

[0001628280-22-023253:mdna:66]
[same as prior period, unchanged from 0001558370-22-008639:mdna:68]

[0001628280-22-023253:mdna:67]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will increase on an absolute dollar basis for the year ended December 31, 2022 compared to the year ended December 31, 2021 as we expand our headcount and initiate new marketing campaigns.

[0001628280-22-023253:mdna:68]
[same as prior period, unchanged from 0001558370-22-008639:mdna:70]

[0001628280-22-023253:mdna:69]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and sales tax contingencies. We expect our general and administrative expenses will increase on an absolute dollar basis for the year ended December 31, 2022 compared to the year ended December 31, 2021 as a result of operating as a public company, including expenses necessary to comply with the rules and regulations applicable to companies listed on a national securities exchange and related to compliance and reporting obligations pursuant to the rules and regulations of the SEC, as well as increased expenses for general and director and officer insurance, and other administrative and professional services. In addition, we expect to incur additional costs as we hire additional personnel and enhance our infrastructure to support the anticipated growth of the business.

[0001628280-22-023253:mdna:70]
[same as prior period, unchanged from 0001558370-22-008639:mdna:72]

[0001628280-22-023253:mdna:71]
[same as prior period, unchanged from 0001558370-22-008639:mdna:73]

[0001628280-22-023253:mdna:72]
[same as prior period, unchanged from 0001558370-22-008639:mdna:74]

[0001628280-22-023253:mdna:73]
[same as prior period, unchanged from 0001558370-22-008639:mdna:75]

[0001628280-22-023253:mdna:74]
[same as prior period, unchanged from 0001558370-22-008639:mdna:76]

[0001628280-22-023253:mdna:75]
Interest income relates to interest earned on money market funds and interest earned on our lease receivables for our Evolv Express units.

[0001628280-22-023253:mdna:76]
[same as prior period, unchanged from 0001558370-22-008639:mdna:78]

[0001628280-22-023253:mdna:77]
In August through September 2019 and in September 2020, we issued Convertible Notes to several investors (the “2020 Convertible Notes”) that provided a conversion option whereby upon the closing of a specified financing event the notes would automatically convert into shares of the same class and series of our capital stock issued to other investors in the financing at a conversion price equal to 85% and 80%, respectively, of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative that was required to be bifurcated and accounted for separately from the notes. The derivative liability was initially recorded at fair value upon issuance of the notes and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the derivative liability are recognized in the condensed consolidated statements of operations and comprehensive loss. In October 2019, the specified financing event was consummated, as such the 2020 Convertible Notes issued August through September 2019 were converted into shares of Series B-1 Preferred Stock and the derivative liability was extinguished.

[0001628280-22-023253:mdna:78]
In January and February 2021, we entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability and included in long-term liabilities on the

[0001628280-22-023253:mdna:79]
Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method.

[0001628280-22-023253:mdna:80]
In June 2021, we modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. The modification of the 2021 Convertible Notes resulted in the recognition of a derivative liability for the fair value of the 1,000,000 NHIC shares as of June 21, 2021 as well as a bifurcated embedded derivative for conversion feature into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors.

[0001628280-22-023253:mdna:81]
[same as prior period, unchanged from 0001558370-22-008639:mdna:84]

[0001628280-22-023253:mdna:82]
[same as prior period, unchanged from 0001558370-22-008639:mdna:85]

[0001628280-22-023253:mdna:83]
[same as prior period, unchanged from 0001558370-22-008639:mdna:86]

[0001628280-22-023253:mdna:84]
[same as prior period, unchanged from 0001558370-22-008639:mdna:87]

[0001628280-22-023253:mdna:85]
[same as prior period, unchanged from 0001558370-22-008639:mdna:88]

[0001628280-22-023253:mdna:86]
[same as prior period, unchanged from 0001558370-22-008639:mdna:89]

[0001628280-22-023253:mdna:87]
[same as prior period, unchanged from 0001558370-22-008639:mdna:90]

[0001628280-22-023253:mdna:88]
[same as prior period, unchanged from 0001558370-22-008639:mdna:91]

[0001628280-22-023253:mdna:89]
[same as prior period, unchanged from 0001558370-22-008639:mdna:92]

[0001628280-22-023253:mdna:90]
[same as prior period, unchanged from 0001558370-22-008639:mdna:93]

[0001628280-22-023253:mdna:91]
Our income tax provision consists of an estimate for U.S. federal and state income taxes based on enacted rates, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes

[0001628280-22-023253:mdna:92]
in tax law. There is no provision for income taxes for the three and six months ended June 30, 2022 and 2021 because we have historically incurred net operating losses and maintain a full valuation allowance against its deferred tax assets.

[0001628280-22-023253:mdna:93]
[same as prior period, unchanged from 0001558370-22-008639:mdna:96]

[0001628280-22-023253:mdna:94]
Comparison of the Three Months Ended June 30, 2022 and 2021

[0001628280-22-023253:mdna:95]
The following table summarizes our results of operations for the three months ended June 30, 2022 and 2021, (in thousands):

[0001628280-22-023253:mdna:96]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 4,146 |  |  | $ | 2,617 |  |  | $ | 1,529 |  |  | 58 | % |
| Subscription revenue | 4,006 |  |  | 1,521 |  |  | 2,485 |  |  | 163 |  |
| Service revenue | 918 |  |  | 540 |  |  | 378 |  |  | 70 |  |
| Total revenue | 9,070 |  |  | 4,678 |  |  | 4,392 |  |  | 94 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 5,347 |  |  | 2,203 |  |  | 3,144 |  |  | 143 |  |
| Cost of subscription revenue | 1,981 |  |  | 1,060 |  |  | 921 |  |  | 87 |  |
| Cost of service revenue | 1,189 |  |  | 687 |  |  | 502 |  |  | 73 |  |
| Total cost of revenue | 8,517 |  |  | 3,950 |  |  | 4,567 |  |  | 116 |  |
| Gross profit | 553 |  |  | 728 |  |  | (175) |  |  | (24) |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 4,156 |  |  | 1,047 |  |  | 3,109 |  |  | 297 |  |
| Sales and marketing | 11,751 |  |  | 5,124 |  |  | 6,627 |  |  | 129 |  |
| General and administrative | 9,612 |  |  | 1,471 |  |  | 8,141 |  |  | 553 |  |
| Loss from impairment of property and equipment | 316 |  |  | — |  |  | 316 |  |  | * |
| Total operating expenses | 25,835 |  |  | 7,642 |  |  | 18,193 |  |  | 238 |  |
| Loss from operations | (25,282) |  |  | (6,914) |  |  | (18,368) |  |  | 266 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (159) |  |  | (3,263) |  |  | 3,104 |  |  | (95) |  |
| Interest income | 491 |  |  | — |  |  | 491 |  |  | * |
| Loss on extinguishment of debt | — |  |  | (11,820) |  |  | 11,820 |  |  | * |
| Change in fair value of derivative liability | — |  |  | (795) |  |  | 795 |  |  | * |
| Change in fair value of contingent earn-out liability | (569) |  |  | — |  |  | (569) |  |  | * |
| Change in fair value of contingently issuable common stock liability | (24) |  |  | — |  |  | (24) |  |  | * |
| Change in fair value of public warrant liability | (143) |  |  | — |  |  | (143) |  |  | * |
| Change in fair value of common stock warrant liability | — |  |  | (185) |  |  | 185 |  |  | * |
| Total other income (expense), net | (404) |  |  | (16,063) |  |  | 15,659 |  |  | (97) |  |
| Net loss | $ | (25,686) |  |  | $ | (22,977) |  |  | $ | (2,709) |  |  | 12 | % |

[0001628280-22-023253:mdna:97]
[same as prior period, unchanged from 0001558370-22-008639:mdna:100]

[0001628280-22-023253:mdna:98]
[same as prior period, unchanged from 0001558370-22-008639:mdna:95]

[0001628280-22-023253:mdna:99]
[same as prior period, unchanged from 0001558370-22-008639:mdna:101]

[0001628280-22-023253:mdna:100]
[same as prior period, unchanged from 0001558370-22-008639:mdna:102]

[0001628280-22-023253:mdna:101]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Product revenue | $ | 4,146 |  |  | $ | 2,617 |  |  | $ | 1,529 |  |  | 58 | % |
| Cost of product revenue | $ | 5,347 |  |  | $ | 2,203 |  |  | $ | 3,144 |  |  | 143 | % |
| Gross profit - Product revenue | $ | (1,201) |  |  | $ | 414 |  |  | $ | (1,615) |  |  | (390) | % |
| Gross profit margin - Product revenue | (29) | % |  | 16 | % |  | N/A |  | (45) | % |

[0001628280-22-023253:mdna:102]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which include the significant increase in the adoption of Evolv Express units by schools, hotels and casinos, and professional sports arenas. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, during the three months ended June 30, 2022 compared to the prior year period. Gross profit and gross profit margin were also adversely impacted by purchase price variances recorded on raw materials and the costs associated with the write-off of scrap inventory incurred without corresponding revenue. We expect to see improvement in our gross margins as we continue to engineer our product with lower cost components. We also expect to see improvements in gross margin to the extent shipping costs and high demand materials costs decline when global supply chain disruptions ease.

[0001628280-22-023253:mdna:103]
[same as prior period, unchanged from 0001558370-22-008639:mdna:105]

[0001628280-22-023253:mdna:104]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Subscription revenue | $ | 4,006 |  |  | $ | 1,521 |  |  | $ | 2,485 |  |  | 163 | % |
| Cost of subscription revenue | $ | 1,981 |  |  | $ | 1,060 |  |  | $ | 921 |  |  | 87 | % |
| Gross profit - Subscription revenue | $ | 2,025 |  |  | $ | 461 |  |  | $ | 1,564 |  |  | 339 | % |
| Gross profit margin - Subscription revenue | 51 | % |  | 30 | % |  | N/A |  | 20 | % |

[0001628280-22-023253:mdna:105]
The increases in subscription revenue and cost of subscription revenue are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed in the preceding twelve months. The increase in gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin was primarily driven by increased recurring revenue from increased active subscriptions and customer growth, which we expect to continue.

[0001628280-22-023253:mdna:106]
[same as prior period, unchanged from 0001558370-22-008639:mdna:108]

[0001628280-22-023253:mdna:107]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Service revenue | $ | 918 |  |  | $ | 540 |  |  | $ | 378 |  |  | 70 | % |
| Cost of service revenue | $ | 1,189 |  |  | $ | 687 |  |  | $ | 502 |  |  | 73 | % |
| Gross profit - Service revenue | $ | (271) |  |  | $ | (147) |  |  | $ | (124) |  |  | 84 | % |
| Gross profit margin - Service revenue | (30) | % |  | (27) | % |  | N/A |  | (2) | % |

[0001628280-22-023253:mdna:108]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding twelve months and increased installation and training related to the Evolv Express units. The negative gross profit and gross profit margin in each period are due primarily to field services costs associated with the Evolv Express units. We expect we would see leverage in these expense investments as we work to achieve further levels of scale.

[0001628280-22-023253:mdna:109]
[same as prior period, unchanged from 0001558370-22-008639:mdna:111]

[0001628280-22-023253:mdna:110]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 3,596 |  |  | $ | 1,457 |  |  | $ | 2,139 |  |  | 147 | % |
| Materials and prototypes | (109) |  |  | (832) |  |  | 723 |  |  | (87) | % |
| Professional fees | 423 |  |  | 321 |  |  | 102 |  |  | 32 | % |
| Facilities related and other | 246 |  |  | 101 |  |  | 145 |  |  | 144 | % |
|  | $ | 4,156 |  |  | $ | 1,047 |  |  | $ | 3,109 |  |  | 297 | % |

[0001628280-22-023253:mdna:111]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from new hires in our research and development function during the second half of 2021 and the first half of 2022. The $0.8 million of income recognized during the three months ended June 30, 2021 related to materials and prototypes is due to capitalization of prototypes during the period which had been expensed in prior periods.

[0001628280-22-023253:mdna:112]
[same as prior period, unchanged from 0001558370-22-008639:mdna:114]

[0001628280-22-023253:mdna:113]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 7,583 |  |  | $ | 3,512 |  |  | $ | 4,071 |  |  | 116 | % |
| Direct marketing | 1,045 |  |  | 671 |  |  | 374 |  |  | 56 | % |
| Travel and entertainment | 852 |  |  | 341 |  |  | 511 |  |  | 150 | % |
| Professional fees | 280 |  |  | 187 |  |  | 93 |  |  | 50 | % |
| Facilities related and other | 1,991 |  |  | 413 |  |  | 1,578 |  |  | 382 | % |
|  | $ | 11,751 |  |  | $ | 5,124 |  |  | $ | 6,627 |  |  | 129 | % |

[0001628280-22-023253:mdna:114]
The increase in personnel related expenses is due to an increase in payroll costs, commissions and stock-based compensation resulting from new hires in our sales and marketing functions, which includes functions such as partner development, customer success, and other business development, during the second half of 2021 and the first six months of 2022. The increase in direct marketing is due to an increase in trade shows and events, which have begun to return to pre-pandemic levels, and an increase in sales volume. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings and events. The increase in facilities related and other expenses is primarily due to $1.0 million of certain one-time expenses as well as an increase in shipping costs related to demo units.

[0001628280-22-023253:mdna:115]
[same as prior period, unchanged from 0001558370-22-008639:mdna:118]

[0001628280-22-023253:mdna:116]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 4,019 |  |  | $ | 805 |  |  | $ | 3,214 |  |  | 399 | % |
| Professional fees | 2,042 |  |  | (294) |  |  | 2,336 |  |  | (795) | % |
| Director and officer insurance | 1,380 |  |  | 96 |  |  | 1,284 |  |  | 1338 | % |
| Non-income taxes | 13 |  |  | 30 |  |  | (17) |  |  | (57) | % |
| Facilities related and other | 2,158 |  |  | 834 |  |  | 1,324 |  |  | 159 | % |
|  | $ | 9,612 |  |  | $ | 1,471 |  |  | $ | 8,141 |  |  | 553 | % |

[0001628280-22-023253:mdna:117]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team. The increase in professional fees is due to an increase in accounting, audit, tax, and legal services provided to the Company to support public company requirements. The increase in insurance costs is due primarily to director and officer insurance expense in relation to the Merger. The increase in facilities related and other expenses is due primarily to $1.2 million of certain one-time expenses, as well as increases in software subscriptions and rent expense.

[0001628280-22-023253:mdna:118]
10

[0001628280-22-023253:mdna:119]
[same as prior period, unchanged from 0001558370-22-008639:mdna:122]

[0001628280-22-023253:mdna:120]
Impairment of property and equipment was $0.3 million for the three months ended June 30, 2022. This related to Edge units and Express prototype units that were removed from service and retired. We are transitioning our domestic customers from the Edge units to our most current Express units, which also resulted in an impairment of the remaining economic value of such assets. There was no impairment for the three months ended June 30, 2021.

[0001628280-22-023253:mdna:121]
[same as prior period, unchanged from 0001558370-22-008639:mdna:124]

[0001628280-22-023253:mdna:122]
Interest expense was $0.2 million for the three months ended June 30, 2022, compared to $3.3 million for the three months ended June 30, 2021. The decrease was primarily due to interest expense on the Convertible Notes during the three months ended June 30, 2021. The Convertible Notes converted to the Company’s stock upon closing of the Merger in July 2021.

[0001628280-22-023253:mdna:123]
[same as prior period, unchanged from 0001558370-22-008639:mdna:126]

[0001628280-22-023253:mdna:124]
Interest income of $0.5 million for the three months ended June 30, 2022 related primarily to interest earned on money market funds. No interest income was earned for the three months ended June 30, 2021.

[0001628280-22-023253:mdna:125]
Loss on Extinguishment of Debt

[0001628280-22-023253:mdna:126]
Loss on extinguishment of debt of $11.8 million for the three months ended June 30, 2021 related to a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes.

[0001628280-22-023253:mdna:127]
[same as prior period, unchanged from 0001558370-22-008639:mdna:128]

[0001628280-22-023253:mdna:128]
Change in fair value of the derivative liability was $(0.8) million for the three months ended June 30, 2021, resulting from an increase in the fair value of the Company's stock given the pending Merger. The derivative liability was derecognized in connection with the closing of the Merger.

[0001628280-22-023253:mdna:129]
[same as prior period, unchanged from 0001558370-22-008639:mdna:130]

[0001628280-22-023253:mdna:130]
Change in fair value of the contingent earn-out liability was $(0.6) million for the three months ended June 30, 2022, resulting from a quarterly mark-to-market adjustment. The contingent earn-out liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-023253:mdna:131]
[same as prior period, unchanged from 0001558370-22-008639:mdna:133]

[0001628280-22-023253:mdna:132]
Change in the fair value of the contingently issuable common stock liability was less than $(0.1) million for the three months ended June 30, 2022, resulting from a quarterly mark-to-market adjustment. The contingently issuable common stock liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-023253:mdna:133]
[same as prior period, unchanged from 0001558370-22-008639:mdna:135]

[0001628280-22-023253:mdna:134]
Change in the fair value of the public warrant liability was $(0.1) million for the three months ended June 30, 2022, resulting from a quarterly mark-to-market adjustment. The public warrant liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-023253:mdna:135]
[same as prior period, unchanged from 0001558370-22-008639:mdna:137]

[0001628280-22-023253:mdna:136]
Change in the fair value of the common stock warrant liability was $(0.2) million for the three months ended June 30, 2021, resulting from a quarterly mark-to-market adjustment. The common stock warrant liability was derecognized in connection with the closing of the Merger in July 2021.

[0001628280-22-023253:mdna:137]
Comparison of the Six Months ended June 30, 2022 and 2021

[0001628280-22-023253:mdna:138]
The following table summarizes our results of operations for the six months ended June 30, 2022 and 2021, (in thousands):

[0001628280-22-023253:mdna:139]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 9,340 |  |  | $ | 4,884 |  |  | $ | 4,456 |  |  | 91 | % |
| Subscription revenue | 7,010 |  |  | 2,748 |  |  | 4,262 |  |  | 155 |  |
| Service revenue | 1,430 |  |  | 739 |  |  | 691 |  |  | 94 |  |
| Total revenue | 17,780 |  |  | 8,371 |  |  | 9,409 |  |  | 112 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 10,553 |  |  | 4,419 |  |  | 6,134 |  |  | 139 |  |
| Cost of subscription revenue | 3,523 |  |  | 1,803 |  |  | 1,720 |  |  | 95 |  |
| Cost of service revenue | 2,254 |  |  | 972 |  |  | 1,282 |  |  | 132 |  |
| Total cost of revenue | 16,330 |  |  | 7,194 |  |  | 9,136 |  |  | 127 |  |
| Gross profit | 1,450 |  |  | 1,177 |  |  | 273 |  |  | 23 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 8,331 |  |  | 4,787 |  |  | 3,544 |  |  | 74 |  |
| Sales and marketing | 21,423 |  |  | 7,732 |  |  | 13,691 |  |  | 177 |  |
| General and administrative | 20,429 |  |  | 4,523 |  |  | 15,906 |  |  | 352 |  |
| Loss from impairment of property and equipment | 412 |  |  | — |  |  | 412 |  |  | * |
| Total operating expenses | 50,595 |  |  | 17,042 |  |  | 33,553 |  |  | 197 |  |
| Loss from operations | (49,145) |  |  | (15,865) |  |  | (33,280) |  |  | 210 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (301) |  |  | (5,657) |  |  | 5,356 |  |  | (95) |  |
| Interest income | 559 |  |  | — |  |  | 559 |  |  | * |
| Loss on extinguishment of debt | — |  |  | (11,820) |  |  | 11,820 |  |  | * |
| Change in fair value of derivative liability | — |  |  | (2,220) |  |  | 2,220 |  |  | * |
| Change in fair value of contingent earn-out liability | 2,509 |  |  | — |  |  | 2,509 |  |  | * |
| Change in fair value of contingently issuable common stock liability | 1,448 |  |  | — |  |  | 1,448 |  |  | * |
| Change in fair value of public warrant liability | 5,443 |  |  | — |  |  | 5,443 |  |  | * |
| Change in fair value of common stock warrant liability | — |  |  | (921) |  |  | 921 |  |  | * |
| Total other income (expense), net | 9,658 |  |  | (20,618) |  |  | 30,276 |  |  | (147) |  |
| Net loss | $ | (39,487) |  |  | $ | (36,483) |  |  | $ | (3,004) |  |  | 8 | % |

[0001628280-22-023253:mdna:140]
[same as prior period, unchanged from 0001558370-22-008639:mdna:120]

[0001628280-22-023253:mdna:141]
Revenue, Cost of Revenue and Gross Profit

[0001628280-22-023253:mdna:142]
Product Revenue

[0001628280-22-023253:mdna:143]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Product revenue | $ | 9,340 |  |  | $ | 4,884 |  |  | $ | 4,456 |  |  | 91 | % |
| Cost of product revenue | $ | 10,553 |  |  | $ | 4,419 |  |  | $ | 6,134 |  |  | 139 | % |
| Gross profit - Product revenue | $ | (1,213) |  |  | $ | 465 |  |  | $ | (1,678) |  |  | (361) | % |
| Gross profit margin - Product revenue | (13) | % |  | 10 | % |  | N/A |  | (23) | % |

[0001628280-22-023253:mdna:144]
12

[0001628280-22-023253:mdna:145]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which included the significant increase in the adoption of Evolv Express units by schools, hotels and casinos, and professional sports arenas. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, during the six months ended June 30, 2022 compared to the prior year period. Gross profit and gross profit margin were also adversely impacted by purchase price variances recorded on raw materials and the costs associated with the write-off of scrap inventory incurred without corresponding revenue. We expect to see improvement in our gross margins as we continue to engineer our product with lower cost components. We also expect to see improvements in gross margin to the extent shipping costs and high demand materials costs decline when global supply chain disruptions ease.

[0001628280-22-023253:mdna:146]
Subscription Revenue

[0001628280-22-023253:mdna:147]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Subscription revenue | $ | 7,010 |  |  | $ | 2,748 |  |  | $ | 4,262 |  |  | 155 | % |
| Cost of subscription revenue | $ | 3,523 |  |  | $ | 1,803 |  |  | $ | 1,720 |  |  | 95 | % |
| Gross profit - Subscription revenue | $ | 3,487 |  |  | $ | 945 |  |  | $ | 2,542 |  |  | 269 | % |
| Gross profit margin - Subscription revenue | 50 | % |  | 34 | % |  | N/A |  | 15 | % |

[0001628280-22-023253:mdna:148]
The increases in subscription revenue and cost of subscription revenue are primarily due to growth in our customer base and a higher number of active Evolv Express units deployed in the preceding twelve months. The increase in gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin was primarily driven by increased recurring revenue from increased active subscriptions and customer growth, which we expect to continue.

[0001628280-22-023253:mdna:149]
Service Revenue

[0001628280-22-023253:mdna:150]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Service revenue | $ | 1,430 |  |  | $ | 739 |  |  | $ | 691 |  |  | 94 | % |
| Cost of service revenue | $ | 2,254 |  |  | $ | 972 |  |  | $ | 1,282 |  |  | 132 | % |
| Gross profit - Service revenue | $ | (824) |  |  | $ | (233) |  |  | $ | (591) |  |  | 254 | % |
| Gross profit margin - Service revenue | (58) | % |  | (32) | % |  | N/A |  | (26) | % |

[0001628280-22-023253:mdna:151]
The increase in service revenue is primarily due to the increased number of purchase subscription units deployed in the preceding twelve months and increased installation and training related to the Evolv Express units. The negative gross profit and gross profit margin in each period are due primarily to field services costs associated with the Evolv Express units. We expect we would see leverage in these expense investments as we work to achieve further levels of scale.

[0001628280-22-023253:mdna:152]
Research and Development Expenses

[0001628280-22-023253:mdna:153]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 6,962 |  |  | $ | 2,432 |  |  | $ | 4,530 |  |  | 186 | % |
| Materials and prototypes | 236 |  |  | 1,444 |  |  | (1,208) |  |  | (84) | % |
| Professional fees | 732 |  |  | 580 |  |  | 152 |  |  | 26 | % |
| Facilities related and other | 401 |  |  | 331 |  |  | 70 |  |  | 21 | % |
|  | $ | 8,331 |  |  | $ | 4,787 |  |  | $ | 3,544 |  |  | 74 | % |

[0001628280-22-023253:mdna:154]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from new hires in our research and development function during the second half of 2021 and the first half of

[0001628280-22-023253:mdna:155]
13

[0001628280-22-023253:mdna:156]
2022. The decrease in materials and prototype costs is due to the transition from prototype production to standard manufacturing of the Evolv Express, which results in lower prototyping costs.

[0001628280-22-023253:mdna:157]
Sales and Marketing Expenses

[0001628280-22-023253:mdna:158]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 13,613 |  |  | $ | 5,203 |  |  | $ | 8,410 |  |  | 162 | % |
| Direct marketing | 2,889 |  |  | 1,071 |  |  | 1,818 |  |  | 170 | % |
| Travel and entertainment | 1,538 |  |  | 492 |  |  | 1,046 |  |  | 213 | % |
| Professional fees | 552 |  |  | 372 |  |  | 180 |  |  | 48 | % |
| Facilities related and other | 2,831 |  |  | 594 |  |  | 2,237 |  |  | 377 | % |
|  | $ | 21,423 |  |  | $ | 7,732 |  |  | $ | 13,691 |  |  | 177 | % |

[0001628280-22-023253:mdna:159]
The increase in personnel related expenses is due to an increase in payroll costs, commissions and stock-based compensation resulting from new hires in our sales and marketing functions, which includes functions such as partner development, customer success, and other business development, during the second half of 2021 and the first six months in 2022. The increase in direct marketing is due to an increase in trade shows and events, which have begun to return to pre-pandemic levels, and an increase in sales volume. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings and events. The increase in facilities related and other expenses is primarily due to $1.0 million of certain one-time expenses as well as an increase in shipping costs related to demo units.

[0001628280-22-023253:mdna:160]
General and Administrative Expenses

[0001628280-22-023253:mdna:161]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 7,965 |  |  | $ | 1,381 |  |  | $ | 6,584 |  |  | 477 | % |
| Professional fees | 5,339 |  |  | 1,674 |  |  | 3,665 |  |  | 219 | % |
| Insurance costs | 2,630 |  |  | 188 |  |  | 2,442 |  |  | 1299 | % |
| Non-income taxes | 487 |  |  | 39 |  |  | 448 |  |  | 1149 | % |
| Facilities related and other | 4,008 |  |  | 1,241 |  |  | 2,767 |  |  | 223 | % |
|  | $ | 20,429 |  |  | $ | 4,523 |  |  | $ | 15,906 |  |  | 352 | % |

[0001628280-22-023253:mdna:162]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team. The increase in professional fees is due to an increase in accounting, audit, tax, and legal services provided to the Company to support public company requirements. The increase in insurance costs is due primarily to director and officer insurance expense in relation to the Merger. The increase in non-income taxes is due to a sales tax contingency liability as we may owe additional sales and use taxes in various jurisdictions. The increase in facilities related and other expenses is due primarily to $1.3 million of certain one-time expenses, a $0.4 million one-time payment to a former employee, and increases in software subscription fees, board of director compensation and facility-related costs.

[0001628280-22-023253:mdna:163]
Loss From Impairment of Property and Equipment

[0001628280-22-023253:mdna:164]
Impairment of property and equipment was $0.4 million for the six months ended June 30, 2022. This related to Edge units and Express prototype units that were removed from service and retired. We are transitioning our domestic customers from the Edge units to our most current Express units, which also resulted in an impairment of the remaining economic value of such assets. There was no impairment for the six months ended June 30, 2021.

[0001628280-22-023253:mdna:165]
Interest Expense

[0001628280-22-023253:mdna:166]
Interest expense was $0.3 million for the six months ended June 30, 2022, compared to $5.7 million for the six months ended June 30, 2021. The decrease was primarily due to interest expense on the Convertible Notes during the six

[0001628280-22-023253:mdna:167]
months ended June 30, 2021. The Convertible Notes converted to the Company’s common stock upon closing of the Merger in July 2021.

[0001628280-22-023253:mdna:168]
Interest Income

[0001628280-22-023253:mdna:169]
Interest income of $0.6 million for the six months ended June 30, 2022 related primarily to interest earned on money market funds. No interest income was earned for the six months ended June 30, 2021.

[0001628280-22-023253:mdna:170]
Loss on Extinguishment of Debt

[0001628280-22-023253:mdna:171]
Loss on extinguishment of debt of $11.8 million for the six months ended June 30, 2021 related to a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes.

[0001628280-22-023253:mdna:172]
Change in Fair Value of Derivative Liability

[0001628280-22-023253:mdna:173]
Change in fair value of the derivative liability was $(2.2) million for the six months ended June 30, 2021, resulting from an increase in the fair value of the Company's stock given the pending Merger. The derivative liability was derecognized in connection with the closing of the Merger.

[0001628280-22-023253:mdna:174]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-22-023253:mdna:175]
Change in fair value of the contingent earn-out liability was $2.5 million for the six months ended June 30, 2022, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-023253:mdna:176]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-22-023253:mdna:177]
Change in the fair value of the contingently issuable common stock liability was $1.4 million for the six months ended June 30, 2022, resulting from quarterly market-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-023253:mdna:178]
Change in Fair Value of Public Warrant Liability

[0001628280-22-023253:mdna:179]
Change in the fair value of the public warrant liability was $5.4 million for the six months ended June 30, 2022, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger in July 2021.

[0001628280-22-023253:mdna:180]
Change in Fair Value of Common Stock Warrant Liability

[0001628280-22-023253:mdna:181]
Change in the fair value of the common stock warrant liability was $(0.9) million for the six months ended June 30, 2021, resulting from quarterly mark-to-market adjustments. The common stock warrant liability was derecognized in connection with the closing of the Merger in July 2021.

[0001628280-22-023253:mdna:182]
[same as prior period, unchanged from 0001558370-22-008639:mdna:139]

[0001628280-22-023253:mdna:183]
There is no provision for income taxes for the three and six months ended June 30, 2022 and 2021 because we have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets. We have provided a valuation allowance for all of our deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001628280-22-023253:mdna:184]
15

[0001628280-22-023253:mdna:185]
[same as prior period, unchanged from 0001558370-22-008639:mdna:141]

[0001628280-22-023253:mdna:186]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. Prior to the Merger, as an early-stage company, we primarily obtained cash to fund our operations through preferred stock offerings and debt instruments. As of June 30, 2022, we had $242.7 million in cash and cash equivalents. We incurred a net loss of $25.7 million and $23.0 million for the three months ended June 30, 2022 and 2021, respectively, and a net loss of $39.5 million and $36.5 million for the six months ended June 30, 2022 and 2021, respectively. We incurred cash outflows from operating activities of $52.5 million and $18.3 million during the six months ended June 30, 2022 and 2021, respectively.

[0001628280-22-023253:mdna:187]
We expect our cash and cash equivalents, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our sales and marketing teams worldwide. We are likely to require additional capital to respond to the expected growth in the demand for equipment purchases to support our "leased equipment" offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions or unforeseen circumstances and in either the short-term or long-term may determine to engage in equity or debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as the ongoing COVID-19 pandemic, including variants, international political turmoil, including Russia's invasion of Ukraine, ongoing supply chain disruptions, and increases in inflation and interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001628280-22-023253:mdna:188]
[same as prior period, unchanged from 0001558370-22-008639:mdna:145]

[0001628280-22-023253:mdna:189]
[same as prior period, unchanged from 0001558370-22-008639:mdna:146]

[0001628280-22-023253:mdna:190]
[same as prior period, unchanged from 0001558370-22-008639:mdna:147]

[0001628280-22-023253:mdna:191]
In December 2020, we entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024, and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022, which extinguished the 2020 Silicon Valley Bank Term Loan. Under the terms of the JPM Credit Agreement, we received proceeds of $10.0 million. As of June 30, 2022, we had $10.0 of debt outstanding. In September and December of 2020, we issued a total of $4.0 million of convertible notes (the “2020 Convertible Notes”). In January and February 2021, we issued a total of $30.0 million of convertible notes with a maturity date of September 2021.

[0001628280-22-023253:mdna:192]
[same as prior period, unchanged from 0001558370-22-008639:mdna:149]

[0001628280-22-023253:mdna:193]
[same as prior period, unchanged from 0001558370-22-008639:mdna:150]

[0001628280-22-023253:mdna:194]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of June 30, 2022. We anticipate fulfilling such commitments with our existing cash and cash equivalents obtained through operations, proceeds from long-term debt, closing of the Merger, and issuance of common stock in connection with the PIPE investment. Cash and cash equivalents amounted to $242.7 million as of June 30, 2022.

[0001628280-22-023253:mdna:195]
We entered into a lease agreement for additional office space starting May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. We are required to maintain a minimum cash balance of $0.7 million as a security deposit on the leased space which is classified as restricted cash, current and restricted cash, non-current on the condensed consolidated balance sheet as of June 30, 2022. Total future minimum lease payments under this

[0001628280-22-023253:mdna:196]
16

[0001628280-22-023253:mdna:197]
noncancelable operating lease amount to $2.7. See Note 6 to our condensed consolidated financial statements for the six months ended June 30, 2022.

[0001628280-22-023253:mdna:198]
[same as prior period, unchanged from 0001558370-22-008639:mdna:153]

[0001628280-22-023253:mdna:199]
[same as prior period, unchanged from 0001558370-22-008639:mdna:154]

[0001628280-22-023253:mdna:200]
|  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |
| Net cash used in operating activities | $ | (52,495) |  |  | $ | (18,292) |  |
| Net cash used in investing activities | (12,680) |  |  | (7,954) |  |
| Net cash provided by financing activities | 384 |  |  | 32,180 |  |
| Effect of exchange rate changes on cash and cash equivalents | (10) |  |  | — |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (64,801) |  |  | $ | 5,934 |  |

[0001628280-22-023253:mdna:201]
[same as prior period, unchanged from 0001558370-22-008639:mdna:156]

[0001628280-22-023253:mdna:202]
|  | Six Months Ended June 30, |
|  | 2022 |  | 2021 |
| Net loss | $ | (39,487) |  |  | $ | (36,483) |  |
| Noncash (income) expense | 2,632 |  |  | 22,831 |  |
| Changes in operating assets and liabilities | (15,640) |  |  | (4,640) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (52,495) |  |  | $ | (18,292) |  |

[0001628280-22-023253:mdna:203]
Net loss increased from $36.5 million for the six months ended June 30, 2021 to $39.5 million for the six months ended June 30, 2022, as a result of the factors described in "Results of Operations" above.

[0001628280-22-023253:mdna:204]
Noncash expenses for the six months ended June 30, 2022 are primarily attributable to $9.0 million of stock-based compensation expense and $2.4 million of depreciation and amortization, offset by $9.4 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock and public warrant liability. Noncash expenses for the six months ended June 30, 2021 are primarily attributable to an $11.8 million loss on debt extinguishment related to the 2021 Convertible Notes, $5.5 million of noncash interest expense primarily related to the accretion of the debt discount associated with the 2021 Convertible Notes, $1.4 million of stock-based compensation expense, $1.1 million of depreciation and amortization, and $3.1 million of an aggregate change in fair value of the derivative liability and common stock warrant liability.

[0001628280-22-023253:mdna:205]
Changes in operating assets and liabilities for the six months ended June 30, 2022 are primarily related to the following:

[0001628280-22-023253:mdna:206]
•$5.8 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001628280-22-023253:mdna:207]
•$3.5 million increase in inventory primarily due to increased production of units to meet customer demand;

[0001628280-22-023253:mdna:208]
•$9.7 million increase in prepaid expense and other current assets primarily due to deposits paid to the Company's contract manufacturer, offset by

[0001628280-22-023253:mdna:209]
•$6.0 million increase in deferred revenue due to a higher volume of sales.

[0001628280-22-023253:mdna:210]
Changes in operating assets and liabilities for the six months ended June 30, 2021 are primarily related to the following:

[0001628280-22-023253:mdna:211]
•$1.3 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001628280-22-023253:mdna:212]
•$7.3 million increase in prepaid expense and other current assets primarily due to prepaid subscriptions and insurance, offset by

[0001628280-22-023253:mdna:213]
•$3.5 million increase in accounts payable due to increased sales and marketing and general and administrative expenses due to the growth in business and anticipation of the Merger, as well as timing of vendor payments.

[0001628280-22-023253:mdna:214]
[same as prior period, unchanged from 0001558370-22-008639:mdna:176]

[0001628280-22-023253:mdna:215]
During the six months ended June 30, 2022, cash used in investing activities was $12.7 million, consisting of $11.4 million for the purchases of property and equipment and $1.3 million for the development of internal-use software.

[0001628280-22-023253:mdna:216]
During the six months ended June 30, 2021, cash used in investing activities was $8.0 million, consisting of the purchases of property and equipment.

[0001628280-22-023253:mdna:217]
[same as prior period, unchanged from 0001558370-22-008639:mdna:179]

[0001628280-22-023253:mdna:218]
During the six months ended June 30, 2022, cash provided by financing activities was $0.4 million, consisting of proceeds from the exercise of stock options.

[0001628280-22-023253:mdna:219]
During the six months ended June 30, 2021, cash provided by financing activities was $32.2, consisting of $31.9 million from the issuance of long-term debt, net of issuance costs, and $0.7 million from the exercise of stock options, partially offset by $0.4 million in net cash out flows for the repayment of our finance obligations.

[0001628280-22-023253:mdna:220]
[same as prior period, unchanged from 0001558370-22-008639:mdna:182]

[0001628280-22-023253:mdna:221]
A description of recently issued accounting pronouncements that may potentially impact our financial position, results of operations or cash flows is disclosed in Note 2 to our condensed consolidated financial statements included elsewhere in this Quarterly Report on Form 10-Q.

[0001628280-22-023253:mdna:222]
[same as prior period, unchanged from 0001558370-22-008639:mdna:184]

[0001628280-22-023253:mdna:223]
Our critical accounting policies and estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” for the year ended December 31, 2021 in our Annual Report on Form 10-K. There have been no material changes to our critical accounting policies and estimates during the three months ended June 30, 2022 outside of our critical accounting policies and estimates described below.

[0001628280-22-023253:mdna:224]
[same as prior period, unchanged from 0001558370-22-008639:mdna:186]

[0001628280-22-023253:mdna:225]
We lease our corporate headquarters under a non-cancelable operating lease that expires in October 2024. We determine if our arrangement contains a lease at inception. We do not separate lease and non-lease components of our arrangement determined to contain a lease.

[0001628280-22-023253:mdna:226]
[same as prior period, unchanged from 0001558370-22-008639:mdna:188]

[0001628280-22-023253:mdna:227]
[same as prior period, unchanged from 0001558370-22-008639:mdna:189]

[0001628280-22-023253:mdna:228]
[same as prior period, unchanged from 0001558370-22-008639:mdna:190]

[0001628280-22-023253:mdna:229]
The Jumpstart Our Business Startups Act of 2012, or the JOBS Act, permits an “emerging growth company” such as us to take advantage of an extended transition period to comply with new or revised accounting standards applicable to public companies until those standards would otherwise apply to private companies. We meet the definition of an “emerging growth company” and have elected to use this extended transition period for complying with new or revised accounting standards that have different effective dates for public and private companies until the earlier of the date we (1) are no longer an emerging growth company or (2) affirmatively and irrevocably opt out of the extended transition period

[0001628280-22-023253:mdna:230]
provided in the JOBS Act. As a result of this election, we will not be subject to the same new or revised accounting standards as other public companies that are not emerging growth companies and our condensed consolidated financial statements may not be comparable to other public companies that comply with new or revised accounting pronouncements as of public company effective dates. We may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for private companies.

[0001628280-22-023253:mdna:231]
[same as prior period, unchanged from 0001558370-22-008639:mdna:192]

[0001628280-22-023253:mdna:232]
[same as prior period, unchanged from 0001558370-22-008639:mdna:193]
