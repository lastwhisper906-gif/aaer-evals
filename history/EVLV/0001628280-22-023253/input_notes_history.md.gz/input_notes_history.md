# EVLV note change history — 0001558370-22-008639 → 0001628280-22-023253


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-18):
[0001628280-22-023253:note_history:1]
Commitments and Contingencies
Indemnification Agreements
  (was, 2022-05-13, similarity 0.6667):
[0001558370-22-008639:note_history:1]
20. Commitments and Contingencies

- changed (2022-08-18):
[0001628280-22-023253:note_history:2]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of June 30, 2022 or December 31, 2021.
  (was, 2022-05-13, similarity 0.9961):
[0001558370-22-008639:note_history:2]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its condensed consolidated financial statements as of March 31, 2022 or December 31, 2021.

- removed (2022-08-18):
[0001558370-22-008639:note_history:3]
Indemnification Agreements


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-18):
[0001628280-22-023253:note_history:4]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a global leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks in a cost-effective manner while improving the visitor experience. The Company is headquartered in Waltham, Massachusetts.
  (was, 2022-05-13, similarity 0.9574):
[0001558370-22-008639:note_history:4]
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a global leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks in a cost-effective manner while improving the visitor experience. The Company is headquartered in Waltham, Massachusetts.

- added (2022-08-18):
[0001628280-22-023253:note_history:5]
The accompanying unaudited condensed consolidated financial statements as of June 30, 2022, and for the three and six months ended June 30, 2022 and 2021 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2021 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of June 30, 2022 and the results of its operations for the three and six months ended June 30, 2022 and 2021 and cash flows for the six months ended June 30, 2022 and 2021. The results for the three and six months ended June 30, 2022 are not necessarily indicative of results to be expected for the year ending December 31, 2022, any other interim periods, or any future year or period.

- added (2022-08-18):
[0001628280-22-023253:note_history:6]
Revision of Prior Period Financial Statements

- added (2022-08-18):
[0001628280-22-023253:note_history:7]
In preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified errors in its previously issued financial statements whereby (a) certain expenses that were cost of subscription revenue related and cost of service revenue related were inaccurately classified as sales and marketing expenses on the consolidated statements of operations and comprehensive loss, (b) certain equipment under lease or held for lease was inaccurately classified as inventory on the consolidated balance sheets and a portion of the cash outflows related to the equipment under lease or held for lease were misclassified between operating and investing cash flows on the consolidated statements of cash flows, and (c) the vesting of warrants related to the Business Development Agreement disclosed in Note 16 were not accounted for accurately. The identified errors impacted the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022. The Company has made adjustments to the prior period amounts presented in these financial statements accordingly. Additionally, the Company has made adjustments to correct for other previously identified immaterial errors. The Company evaluated the errors and determined that the related impacts were not material 
to any previously issued annual or interim financial statements. A summary of the revisions to the previously reported financial information is included in Note 21.

- removed (2022-08-18):
[0001558370-22-008639:note_history:8]
1. Nature of the Business and Basis of Presentation

- removed (2022-08-18):
[0001558370-22-008639:note_history:9]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2022, and for the three months ended March 31, 2022 and 2021 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2021 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2022 and the results of its operations for the three months ended March 31, 2022 and 2021 and cash flows for the three months ended March 31, 2022 and 2021. The results for the three months ended March 31, 2022 are not necessarily indicative of results to be expected for the year ending December 31, 2022, any other interim periods, or any future year or period.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-18):
[0001628280-22-023253:note_history:10]
Summary of Significant Accounting Policies
Significant Accounting Policies
  (was, 2022-05-13, similarity 0.7119):
[0001558370-22-008639:note_history:10]
2. Summary of Significant Accounting Policies

- changed (2022-08-18):
[0001628280-22-023253:note_history:11]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2021, and the notes thereto, which are included in our Annual Report on Form 10-K for the year ended December 31, 2021. There have been no material changes to the Company’s significant accounting policies during the three months ended June 30, 2022 outside of the items as described below.
  (was, 2022-05-13, similarity 0.9582):
[0001558370-22-008639:note_history:11]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2021, and the notes thereto, which are included in our Annual Report on Form 10-K. There have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2022 outside of the items as described below.

- added (2022-08-18):
[0001628280-22-023253:note_history:12]
In addition to selling our products directly to customers, we also derive revenue from leasing our equipment, which we classify as subscription revenue. Lease terms are typically four years, generally do not include unilateral options by either the Company or our customer to extend, terminate or to purchase the underlying asset, and customers generally pay either a quarterly or annual fixed payment for the lease and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as they do not meet any of the sales-type lease criteria per ASC 842 and recognized ratably over the duration of the lease. There are no variable lease payments as a part of these arrangements.

- added (2022-08-18):
[0001628280-22-023253:note_history:13]
The accounting provisions we use to classify transactions as sales-type are: (i) whether the lease transfers ownership of the equipment by the end of the lease term, (ii) whether the lease grants the customer an option to purchase the equipment and the customer is reasonably certain to do so, (iii) whether the lease term is for the major part of the economic life of the underlying equipment, (iv) whether the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (v) whether the equipment is specific to the customer and of such a specialized nature that it is expected to have no alternative use to the Company at the end of the lease term. Leasing arrangements meeting any of these conditions are accounted for as sales-type leases and revenue attributable to the lease component is recognized in a manner consistent with product revenue and the related equipment is derecognized with the associated expense presented as a cost of revenue. Leasing arrangements that do not meet the criteria for classification as a sales-type lease will be accounted for as a direct-financing lease if the following two conditions are met: (i) the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments and any other third party unrelated to the Company, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (ii) it is probable that the Company will collect the lease payments and amounts necessary to satisfy a residual value guarantee. Leasing arrangements that do not meet any of the sales-type lease or direct-financing lease classification criteria are accounted for as operating leases and revenue is recognized straight-line over the term of the lease.

- changed (2022-08-18):
[0001628280-22-023253:note_history:14]
Generally, lease arrangements include both lease and non-lease components. The lease component relates to the customer’s right-to-use the equipment over the lease term. The non-lease components relate to (1) distinct services, such as SaaS and maintenance, (2) any add-on accessories, and (3) installation and training. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the Company elected the practical expedient to aggregate non-lease components with the associated lease component and account for the combined component as an operating lease for all underlying asset classes. In the evaluation of whether the lease component (equipment) or the non-lease components associated with the lease component (SaaS and maintenance) is the predominant component, the Company determined that the lease component is predominant as we believe the customer would ascribe more value to the use of the security equipment than that of the SaaS and maintenance services. Therefore, the Company will account for the combined lease component under ASC 842. The equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in the condensed consolidated statements of operations and comprehensive loss. The installation and training services represent distinct services provided to customers. These activities are considered separate performance obligations to the customer and therefore are considered non-lease components. As installation and training services are performed prior to lease commencement, the timing and pattern of transfer for these services differ from that of the lease component (i.e., security hardware) and are not eligible to be combined.
  (was, 2022-05-13, similarity 0.9849):
[0001558370-22-008639:note_history:14]
Generally, lease arrangements include both lease and non-lease components. The lease component relates to the customer’s right-to-use the equipment over the lease term. The non-lease components relate to (1) distinct services, such as SaaS and maintenance, (2) any add-on accessories, and (3) installation and training. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the Company elected the practical expedient to aggregate non-lease components with the associated lease component and account for the combined component as an operating lease for all underlying asset classes. In the evaluation of whether the lease component (equipment) or the non-lease components associated with the lease component (SaaS and maintenance) is the predominant  component, the Company determined that the lease component is predominant as customers would clearly be expected to ascribe more value to the use of the security equipment than that of the SaaS and maintenance services. Therefore, the Company will account for the combined lease component under ASC 842. The equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in the condensed consolidated statements of operations and comprehensive loss. The installation and training services represent distinct services provided to customers. These activities are considered separate performance obligations to the customer and therefore are considered non-lease components. As installation and training services are performed prior to lease commencement, the timing and pattern of transfer for these services differ from that of the lease component (i.e., security hardware) and are not eligible to be combined.

- changed (2022-08-18):
[0001628280-22-023253:note_history:15]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party. Revenue related to leases entered into with related parties were $0.2 million and $0.3 million during the three and six months ended June 30, 2022, respectively.
  (was, 2022-05-13, similarity 0.8118):
[0001558370-22-008639:note_history:15]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party. Revenue related to leases entered into with related parties were $0.1 million during the three months ended March 31, 2022.

- changed (2022-08-18):
[0001628280-22-023253:note_history:16]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), as subsequently amended (collectively “ASC 842”). The guidance amends the existing accounting standards for lease accounting, including requirements for lessees to recognize assets and liabilities related to long-term leases on the balance sheet and expanding disclosure requirements regarding leasing arrangements. For lessees, leases will be classified as finance or operating, with classification affecting the pattern and classification of expense recognition in the income statement. Lessors are required to classify leases as a sales-type, direct financing, or operating lease. A lease is a sales-type lease if it effectively transfers control of the underlying asset to the lessee as indicated by any one of five criteria being met. All leases that are not sales-type or direct financing leases will be classified as operating leases. In July 2018, the FASB issued additional guidance, which offers a transition option to entities adopting ASC 842 in which entities can elect to apply the new guidance using a modified retrospective approach at the beginning of the year in which the new lease standard is adopted. The Company utilized this transition option whereby financial information for prior periods presented before the ASC 842 effective date will not be updated. In November 2019, the FASB issued ASU 2019-10 deferring the effective date for private entities (also applicable for public companies that qualify as emerging growth companies) for fiscal years beginning after December 15, 2020, and interim periods within fiscal years beginning after December 15, 2021. In June 2020, the FASB issued ASU 2020-05 which further defers the effective date for private entities for fiscal years beginning after December 15, 2021, and interim periods within fiscal years beginning after December 15, 2022.
  (was, 2022-05-13, similarity 0.7277):
[0001558370-22-008639:note_history:16]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), as subsequently amended (collectively “ASC 842”). The guidance amends the existing accounting standards for lease accounting, including requirements for lessees to recognize assets and liabilities related to long-term leases on the balance sheet and expanding disclosure requirements regarding leasing arrangements. For lessees, leases will be classified as finance or operating, with classification affecting the pattern and classification of expense recognition in the income statement. Lessors are required to classify leases as a sales-type, direct financing, or operating lease. A lease is a sales-type lease if it effectively transfers control of the underlying asset to the lessee as indicated by any one of five criteria being met. All leases that are not sales-type or direct financing leases will be classified as operating leases. In July 2018, the FASB issued additional guidance, which offers a transition option to entities adopting ASC 842 in which entities can elect to

- changed (2022-08-18):
[0001628280-22-023253:note_history:17]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019 12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.
  (was, 2022-05-13, similarity 0.9989):
[0001558370-22-008639:note_history:17]
In December 2019, the FASB issued ASU 2019 12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019 12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.

- changed (2022-08-18):
[0001628280-22-023253:note_history:18]
In August 2020, the FASB issued ASU 2020-06, Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies and clarifies certain calculation and presentation matters related to convertible and equity and debt instruments. Specifically, ASU 2020-06 removes requirements to separately account for conversion features as a derivative under ASC Topic 815 and removing the requirement to account for beneficial conversion features on such instruments. ASU 2020-06 also provides clearer guidance surrounding disclosure of such instruments and provides specific guidance for how such instruments are to be incorporated in the calculation of Diluted EPS. The guidance under ASU 2020-06 is effective for fiscal years beginning after December 15, 2021, including interim periods within those fiscal
  (was, 2022-05-13, similarity 0.8424):
[0001558370-22-008639:note_history:18]
In August 2020, the FASB issued ASU 2020-06, “Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity,” which simplifies and clarifies certain calculation and presentation matters related to convertible and equity and debt instruments. Specifically, ASU 2020-06 removes requirements to separately account for conversion features as a derivative under ASC Topic 815 and removing the requirement to account for beneficial conversion features on such instruments. ASU 2020-06 also provides clearer guidance surrounding disclosure of such instruments and provides specific guidance for how such instruments are to be incorporated in the calculation of Diluted EPS. The guidance under ASU 2020-06 is effective for fiscal years beginning after December 15, 2021, including interim periods within those fiscal years. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.

- added (2022-08-18):
[0001628280-22-023253:note_history:19]
years. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its condensed consolidated financial statements and related disclosures.

- changed (2022-08-18):
[0001628280-22-023253:note_history:20]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its condensed consolidated financial statements and related disclosures.
  (was, 2022-05-13, similarity 0.987):
[0001558370-22-008639:note_history:20]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its condensed consolidated financial statements and related disclosures.

- removed (2022-08-18):
[0001558370-22-008639:note_history:21]
Significant Accounting Policies

- removed (2022-08-18):
[0001558370-22-008639:note_history:22]
In addition to selling our products directly to customers, we also derive revenue from leasing our equipment, which we classify as subscription revenue. Lease terms are typically four years, do not include options to extend, terminate or to purchase the underlying asset, and customers generally pay either a quarterly or annual fixed payment for the lease and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as they do not meet any of the sales-type lease criteria per ASC 842 and recognized ratably over the duration of the lease. There are no variable lease payments as a part of these arrangements.

- removed (2022-08-18):
[0001558370-22-008639:note_history:23]
The accounting provisions we use to classify transactions as sales-type are: (i) whether the lease transfers ownership of the equipment by the end of the lease term, (ii) whether the lease grants the customer an option to purchase the equipment and the customer is reasonably certain to do so, (iii) whether the lease term is for the major part of the economic life of the underlying equipment,  (iv) whether the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments,  is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (v) whether the equipment is specific to the customer and of such a specialized nature that it is expected to have no alternative use to the Company at the end of

- removed (2022-08-18):
[0001558370-22-008639:note_history:24]
the lease term. Leasing arrangements meeting any of these conditions are accounted for as sales-type leases and revenue attributable to the lease component is recognized in a manner consistent with the equipment sales and the related equipment is derecognized with the associated expense presented as a cost of revenue. Leasing arrangements that do not meet the criteria for classification as a sales-type lease will be accounted for as a direct-financing lease if the following two conditions are met: (i) the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments and any other third party unrelated to the Company, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (ii) it is probable that the Company will collect the lease payments and amounts necessary to satisfy a residual value guarantee. Leasing arrangements that do not meet any of the sales-type lease classification criteria are accounted for as operating leases and revenue is recognized straight-line over the term of the lease.

- removed (2022-08-18):
[0001558370-22-008639:note_history:25]
apply the new guidance using a modified retrospective approach at the beginning of the year in which the new lease standard is adopted. The Company utilized this transition option whereby financial information for prior periods presented before the ASC 842 effective date will not be updated. In November 2019, the FASB issued ASU 2019-10 deferring the effective date for private entities (also applicable for public companies that qualify as emerging growth companies) for fiscal years beginning after December 15, 2020, and interim periods within fiscal years beginning after December 15, 2021. In June 2020, the FASB issued ASU 2020-05 which further defers the effective date for private entities for fiscal years beginning after December 15, 2021, and interim periods within fiscal years beginning after December 15, 2022.

- removed (2022-08-18):
[0001558370-22-008639:note_history:26]
Out-of-Period Adjustment

- removed (2022-08-18):
[0001558370-22-008639:note_history:27]
During the three months ended March 31, 2022, the Company recorded an immaterial out-of-period adjustment that resulted in a $1.0 million increase of stock-based compensation expense within sales and marketing expense in the condensed statements of operations and comprehensive loss, a $1.0 million increase to change in fair value of contingent earn-out liability in the condensed statements of operations and comprehensive loss, a $0.5 million decrease to additional paid-in capital in the condensed balance sheets, and a $0.5 million increase to contingent earn-out liability in the condensed balance sheets. The out-of-period adjustment related to an error in the Company’s accounting for the contingent earn-out liability for the third and fourth quarters of fiscal year 2021. The Company has determined the adjustment is not material to the current period or any previously issued financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-18):
[0001628280-22-023253:note_history:28]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):
  (was, 2022-05-13, similarity 0.9223):
[0001558370-22-008639:note_history:28]
The components of the Company’s long-term debt consisted of the following (in thousands):

- changed (2022-08-18):
[0001628280-22-023253:note_history:29]
|  | June 30,2022 |  | December 31,2021 |
| Term loans payable | $ | 10,000 |  |  | $ | 10,000 |  |
| Less: Unamortized discount | (45) |  |  | (55) |  |
|  | 9,955 |  |  | 9,945 |  |
| Less: Current portion of long-term debt | 4,000 |  |  | 2,000 |  |
| Long-term debt, net of discount | $ | 5,955 |  |  | $ | 7,945 |  |
  (was, 2022-05-13, similarity 0.7567):
[0001558370-22-008639:note_history:29]
| ​ | ​ | March 31, | ​ | December 31, |
| ​ | ​ | 2022 |  | 2021 |
| Term loans payable | ​ | $ | 10,000 | ​ | $ | 10,000 |
| Less: Unamortized discount | ​ |  | (50) | ​ |  | (55) |
| ​ | ​ |  | 9,950 | ​ |  | 9,945 |
| Less: Current portion of long-term debt | ​ |  | 3,000 | ​ |  | 2,000 |
| Long-term debt, net of discount | ​ | $ | 6,950 | ​ | $ | 7,945 |

- changed (2022-08-18):
[0001628280-22-023253:note_history:30]
Principal and interest on the JPM Credit Agreement is payable monthly commencing on July 1, 2022. The JPM Credit Agreement accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 2.25% or (B) 5.5%. The revolving line of credit accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 1.25% or (B) 4.5%. Upon closing, the Company issued warrants to purchase 377,837 shares of common stock to the lender with an exercise price of $0.42 per share with a fair value of $0.1 million on the date of issuance. The Company incurred debt issuance costs of $0.1 million equal to the fair value of the warrants in connection with the JPM Credit Agreement. These costs were recorded as debt discount and are amortized to interest expense, using the effective interest method, over the term of the loan. Upon the closing of the Merger, the warrants were converted into shares of the Company's common stock.
  (was, 2022-05-13, similarity 0.999):
[0001558370-22-008639:note_history:30]
Principal and interest on the JPM Credit Agreement is payable monthly commencing on July 1, 2022. The JPM Credit Agreement accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 2.25% or (B) 5.5%. The revolving line of credit accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 1.25% or (B) 4.5%. Upon closing, the Company issued warrants to purchase 377,837 shares of common stock to the lender with an exercise price of $0.42 per share with a fair value of $0.1 million on the date of issuance. The Company incurred debt issuance costs of $0.1 million equal to the fair value of the warrants in connection with the JPM Credit Agreement. These costs were recorded as debt discount and are amortized to interest expense, using the effective interest method, over the term of the loan. Upon the closing of the Merger, the warrants were converted into shares of the Company’s common stock.

- added (2022-08-18):
[0001628280-22-023253:note_history:31]
As of June 30, 2022, the unamortized debt discount was less than $0.1 million. As of June 30, 2022, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the condensed consolidated balance sheet. Interest expense related to the JPM Credit Agreement totaled $0.2 million and $0.2 million for the three months ended June 30, 2022 and June 30, 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million in each period. Interest expense related to the JPM Credit Agreement totaled $0.3 million and $0.3 million for the six months ended June 30, 2022 and June 30, 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million in each period. The interest rate in effect as of June 30, 2022 was 5.75% for the JPM Credit Agreement.

- changed (2022-08-18):
[0001628280-22-023253:note_history:32]
As of June 30, 2022, future principal payments on long-term debt are as follows (in thousands):
  (was, 2022-05-13, similarity 0.9497):
[0001558370-22-008639:note_history:32]
As of March 31, 2022, future principal payments on long-term debt are as follows (in thousands):

- changed (2022-08-18):
[0001628280-22-023253:note_history:33]
| December 31, |  |
| 2022 (remaining six months) | $ | 2,000 |  |
| 2023 | 4,000 |  |
| 2024 | 4,000 |  |
|  | $ | 10,000 |  |
  (was, 2022-05-13, similarity 0.7873):
[0001558370-22-008639:note_history:33]
| Year Ending December 31, |  | ​ | ​ |
| 2022 (remaining nine months) | ​ | $ | 2,000 |
| 2023 | ​ |  | 4,000 |
| 2024 | ​ |  | 4,000 |
| ​ | ​ | $ | 10,000 |

- changed (2022-08-18):
[0001628280-22-023253:note_history:34]
In September 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) with an investor for gross proceeds of $2.0 million with a stated interest rate of 6.0% per annum. An additional $2.0 million in gross proceeds were made available in December 31, 2020 upon achievement of the integration milestone, whereby the Company successfully created software utilizing the investor’s application programming interface. The 2020 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds of the issuance of preferred stock totaled at least $10.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2020 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $1.0 million, and the notes, with an initial carrying value of $3.0 million, and included in long-term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the
  (was, 2022-05-13, similarity 0.8994):
[0001558370-22-008639:note_history:34]
In September 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) with an investor for gross proceeds of $2.0 million with a stated interest rate of 6.0% per annum. An additional $2.0 million in gross proceeds were made available in December 2020 upon achievement of the integration milestone, whereby the Company successfully created software utilizing the investor’s application programming interface. The 2020 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds of the issuance of preferred stock totaled at least $10.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2020 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $1.0 million, and the notes, with an initial carrying value of $3.0 million, and included in long-

- added (2022-08-18):
[0001628280-22-023253:note_history:35]
effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the merger.

- added (2022-08-18):
[0001628280-22-023253:note_history:36]
Interest expense related to the 2020 Convertible Notes totaled $0.1 million and $0.3 million for the three and six months ended June 30, 2021, respectively. No interest expense was recognized related to the 2020 Convertible Notes for the three and six months ended June 30, 2022.

- changed (2022-08-18):
[0001628280-22-023253:note_history:37]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 recorded in other income (expense).
  (was, 2022-05-13, similarity 0.9926):
[0001558370-22-008639:note_history:37]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense).

- added (2022-08-18):
[0001628280-22-023253:note_history:38]
Interest expense related to the 2021 Convertible Notes totaled $2.8 million and $4.7 million for the three and six months ended June 30, 2021, respectively. No interest expense was recognized related to the 2021 Convertible Notes for the three and six months ended June 30, 2022.

- removed (2022-08-18):
[0001558370-22-008639:note_history:39]
12. Long-term Debt

- removed (2022-08-18):
[0001558370-22-008639:note_history:40]
As of March 31, 2022, the unamortized debt discount was $0.1 million. As of March 31, 2022, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the condensed consolidated balance sheet. Interest expense related to the JPM Credit Agreement totaled $0.1 million and $0.2 million for the three months ended March 31, 2022 and 2021, respectively, which includes the amortization of the debt discount which totaled less than $0.1 million and $0.1 million for the three months ended March 31, 2022 and 2021, respectively. The interest rate in effect as of March 31, 2022 was 5.75% for the JPM Credit Agreement. During the year ended December 31, 2021, the Company fully repaid the $5.4 million drawn down on the revolving line of credit.

- removed (2022-08-18):
[0001558370-22-008639:note_history:41]
term liabilities on the Company’s condensed consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the Merger.

- removed (2022-08-18):
[0001558370-22-008639:note_history:42]
Interest expense for the 2020 Convertible Notes totaled $0 and $0.1 million for the three months ended March 31, 2022 and 2021, respectively.

- removed (2022-08-18):
[0001558370-22-008639:note_history:43]
Interest expense for the 2021 Convertible Notes totaled $0 and $1.9 million for the three months ended March 31, 2022 and 2021, respectively.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-18):
[0001628280-22-023253:note_history:44]
|  | June 30,2022 |  | December 31,2021 |
| Term loans payable | $ | 10,000 |  |  | $ | 10,000 |  |
| Less: Unamortized discount | (45) |  |  | (55) |  |
|  | 9,955 |  |  | 9,945 |  |
| Less: Current portion of long-term debt | 4,000 |  |  | 2,000 |  |
| Long-term debt, net of discount | $ | 5,955 |  |  | $ | 7,945 |  |
  (was, 2022-05-13, similarity 0.7567):
[0001558370-22-008639:note_history:44]
| ​ | ​ | March 31, | ​ | December 31, |
| ​ | ​ | 2022 |  | 2021 |
| Term loans payable | ​ | $ | 10,000 | ​ | $ | 10,000 |
| Less: Unamortized discount | ​ |  | (50) | ​ |  | (55) |
| ​ | ​ |  | 9,950 | ​ |  | 9,945 |
| Less: Current portion of long-term debt | ​ |  | 3,000 | ​ |  | 2,000 |
| Long-term debt, net of discount | ​ | $ | 6,950 | ​ | $ | 7,945 |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-18):
[0001628280-22-023253:note_history:45]
As of June 30, 2022, future principal payments on long-term debt are as follows (in thousands):
  (was, 2022-05-13, similarity 0.9497):
[0001558370-22-008639:note_history:45]
As of March 31, 2022, future principal payments on long-term debt are as follows (in thousands):

- changed (2022-08-18):
[0001628280-22-023253:note_history:46]
| December 31, |  |
| 2022 (remaining six months) | $ | 2,000 |  |
| 2023 | 4,000 |  |
| 2024 | 4,000 |  |
|  | $ | 10,000 |  |
  (was, 2022-05-13, similarity 0.7873):
[0001558370-22-008639:note_history:46]
| Year Ending December 31, |  | ​ | ​ |
| 2022 (remaining nine months) | ​ | $ | 2,000 |
| 2023 | ​ |  | 4,000 |
| 2024 | ​ |  | 4,000 |
| ​ | ​ | $ | 10,000 |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-08-18):
[0001628280-22-023253:note_history:47]
Related Party Transactions
Nonrecourse Promissory Note with Officer
  (was, 2022-05-13, similarity 0.7477):
[0001558370-22-008639:note_history:47]
Nonrecourse Promissory Note with Officer

- changed (2022-08-18):
[0001628280-22-023253:note_history:48]
In January 2021, the Company granted a warrant exercisable for 2,552,913 shares of common stock to Finback, a consulting group who is an affiliate of one of the Company’s shareholders, with performance-based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years. During the three months ended June 30, 2022 and 2021, the Company recorded $0.6 million and $0.7 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants. During the six months ended June 30, 2022 and 2021, the Company recorded $0.8 million and $0.8 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.
  (was, 2022-05-13, similarity 0.8178):
[0001558370-22-008639:note_history:48]
In March 2021, the Company granted a warrant exercisable for 2,552,913 shares of common stock to Finback, a consulting group who is an affiliate of one of the Company’s shareholders, with performance-based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years. During the three months ended March 31, 2022 and 2021, the Company recorded $0.4 million and $0.8 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.

- changed (2022-08-18):
[0001628280-22-023253:note_history:49]
In connection with the Merger and pursuant to the Merger Agreement, Finback is entitled to receive a proportional share of earn-out shares as an earn-out service provider, based upon the remaining unvested warrants as of the Merger Date. As of June 30, 2022, Finback can earn 283,926 earn-out shares subject to stock-based compensation, based on the achievement of certain milestones. During the three months ended June 30, 2022 and 2021, no stock-based compensation expense within sales and marketing expense for the earn-out shares allocated to Finback was recorded. During the six months ended June 30, 2022 and 2021, no stock-based compensation expense within sales and marketing expense for the earn-out shares allocated to Finback was recorded.
  (was, 2022-05-13, similarity 0.7838):
[0001558370-22-008639:note_history:49]
In connection with the Merger and pursuant to the Merger Agreement, Finback is entitled to receive a proportional share of earn-out shares as an earn-out service provider, based upon the remaining unvested warrants as of the Merger Date. As of March 31, 2022 Finback can earn 280,410 earn-out shares subject to stock-based compensation, based on the achievement of certain milestones. During the three months ended March 31, 2022 and 2021, the Company recorded $1.5 million and $0, respectively, of stock-based compensation expense within sales and marketing expense for the earn-out shares allocated to Finback.

- changed (2022-08-18):
[0001628280-22-023253:note_history:50]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement (the “Distribution Agreement”) with Motorola, an investor in the Company. In June 2021, the partnership agreement was amended by the Amended and Restated Distribution Agreement (the “Amended and Restated Distribution Agreement”). Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended June 30, 2022 and 2021, revenue from Motorola’s distributor services was $1.9 million and $0, respectively. During the six months ended June 30, 2022 and 2021, revenue from Motorola’s distributor services was $2.8 million and $0, respectively. As of June 30, 2022 and December 31, 2021, accounts receivable related to Motorola’s distributor services was $3.0 million and $1.2 million, respectively.
  (was, 2022-05-13, similarity 0.8448):
[0001558370-22-008639:note_history:50]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement (the “Distribution Agreement”) with Motorola, an investor in the Company. In June 2021, the partnership agreement was amended by the Amended and Restated Distribution Agreement (the “Amended and Restated Distribution Agreement”). Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the three months ended March 31, 2022 and 2021, revenue from Motorola’s distributor services was $0.8 million and $0, respectively. As of March 31, 2022 and December 31, 2021, accounts receivable related to Motorola’s distributor services was $1.6 million and $1.2 million, respectively.

- removed (2022-08-18):
[0001558370-22-008639:note_history:51]
19. Related Party Transactions


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-08-18):
[0001628280-22-023253:note_history:52]
The following table presents the Company’s revenue by revenue stream (in thousands):

- added (2022-08-18):
[0001628280-22-023253:note_history:53]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Product revenue | $ | 4,146 |  |  | $ | 2,617 |  |  | $ | 9,340 |  |  | $ | 4,884 |  |
| Leased equipment | 4,006 |  |  | 1,521 |  |  | 7,010 |  |  | 2,748 |  |
| SaaS and Maintenance revenue | 729 |  |  | 230 |  |  | 1,097 |  |  | 362 |  |
| Professional services revenue | 189 |  |  | 310 |  |  | 333 |  |  | 377 |  |
| Total revenue | $ | 9,070 |  |  | $ | 4,678 |  |  | $ | 17,780 |  |  | $ | 8,371 |  |

- removed (2022-08-18):
[0001558370-22-008639:note_history:54]
| ​ | ​ | Three Months Ended March 31, |
| ​ | ​ | 2022 |  | 2021 |
| Product revenue | ​ | ​ | 5,194 |  | ​ | 2,502 |
| Leased equipment | ​ | ​ | 3,020 |  | ​ | 1,300 |
| SaaS and Maintenance revenue | ​ | ​ | 353 |  | ​ | 132 |
| Professional services revenue | ​ | ​ | 148 | ​ | ​ | 65 |
| Total revenue | ​ | $ | 8,715 | ​ | $ | 3,999 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-18):
[0001628280-22-023253:note_history:55]
Revenue Recognition
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.
  (was, 2022-05-13, similarity 0.9873):
[0001558370-22-008639:note_history:55]
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

- changed (2022-08-18):
[0001628280-22-023253:note_history:56]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of June 30, 2022.
  (was, 2022-05-13, similarity 0.9755):
[0001558370-22-008639:note_history:56]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2022.

- added (2022-08-18):
[0001628280-22-023253:note_history:57]
|  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue | $ | 220 |  |  | $ | 79 |  |  | $ | 299 |  |
| Subscription revenue | 16,992 |  |  | 37,615 |  |  | 54,607 |  |
| Service revenue | 3,423 |  |  | 7,909 |  |  | 11,332 |  |
| Total revenue | $ | 20,635 |  |  | $ | 45,603 |  |  | $ | 66,238 |  |

- changed (2022-08-18):
[0001628280-22-023253:note_history:58]
The amount of minimum future leases is based on expected income recognition. As of June 30, 2022, future minimum payments on noncancelable leases are as follows (in thousands):
  (was, 2022-05-13, similarity 0.9736):
[0001558370-22-008639:note_history:58]
The amount of minimum future leases is based on expected income recognition. As of March 31, 2022, future minimum payments on noncancelable leases are as follows (in thousands):

- added (2022-08-18):
[0001628280-22-023253:note_history:59]
| Year Ending December 31: |  |
| 2022 (six months remaining) | $ | 8,556 |  |
| 2023 | 16,649 |  |
| 2024 | 15,380 |  |
| 2025 | 11,424 |  |
| 2026 | 2,505 |  |
| Thereafter | 93 |  |
|  | $ | 54,607 |  |

- changed (2022-08-18):
[0001628280-22-023253:note_history:60]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of June 30, 2022 and December 31, 2021, the Company had $3.1 million and $1.5 million in current portion of contract assets and $3.2 million and $3.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2022-05-13, similarity 0.6511):
[0001558370-22-008639:note_history:60]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of

- changed (2022-08-18):
[0001628280-22-023253:note_history:61]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue
  (was, 2022-05-13, similarity 0.688):
[0001558370-22-008639:note_history:61]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized $2.5 million during the three months ended March 31, 2022 of revenue that was previously included in the 2021 deferred revenue balance and recognized $0.9 million during the three months ended March 31, 2021 of revenue that was previously included in the 2020 deferred revenue balance.

- added (2022-08-18):
[0001628280-22-023253:note_history:62]
and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $2.2 million and $4.7 million during the three and six months ended June 30, 2022, respectively, that was included in the 2021 deferred revenue balance. The Company recognized revenue of $0.6 million and $1.8 million during the three and six months ended June 30, 2021, respectively, that was included in the 2020 deferred revenue balance.

- changed (2022-08-18):
[0001628280-22-023253:note_history:63]
| Balance at December 31, 2021 | $ | 9,074 |  |
| Revenue recognized | (4,658) |  |
| Revenue deferred | 10,696 |  |
| Balance at June 30, 2022 | $ | 15,112 |  |
  (was, 2022-05-13, similarity 0.8708):
[0001558370-22-008639:note_history:63]
| Balance at December 31, 2021 | ​ | $ | 9,165 |
| Revenue recognized | ​ |  | (6,409) |
| Revenue deferred | ​ |  | 9,194 |
| Balance at March 31, 2022 | ​ | $ | 11,950 |

- added (2022-08-18):
[0001628280-22-023253:note_history:64]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue from sales-type leases | $ | — |  |  | $ | — |  |  | $ | 1,312 |  |  | $ | — |  |
| Interest income on lease receivables | 61 |  |  | — |  |  | 110 |  |  | — |  |
| Lease income - operating leases | 4,006 |  |  | 1,521 |  |  | 7,010 |  |  | 2,748 |  |
| Total lease revenue | $ | 4,067 |  |  | $ | 1,521 |  |  | $ | 8,432 |  |  | $ | 2,748 |  |

- added (2022-08-18):
[0001628280-22-023253:note_history:65]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Product revenue | $ | 4,146 |  |  | $ | 2,617 |  |  | $ | 9,340 |  |  | $ | 4,884 |  |
| Leased equipment | 4,006 |  |  | 1,521 |  |  | 7,010 |  |  | 2,748 |  |
| SaaS and Maintenance revenue | 729 |  |  | 230 |  |  | 1,097 |  |  | 362 |  |
| Professional services revenue | 189 |  |  | 310 |  |  | 333 |  |  | 377 |  |
| Total revenue | $ | 9,070 |  |  | $ | 4,678 |  |  | $ | 17,780 |  |  | $ | 8,371 |  |

- changed (2022-08-18):
[0001628280-22-023253:note_history:66]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $5.7 million and $5.4 million as of June 30, 2022 and December 31, 2021, respectively.
  (was, 2022-05-13, similarity 0.8133):
[0001558370-22-008639:note_history:66]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $5.7 million and $5.4 million as of March 31, 2022 and December 31, 2021, respectively. The Company amortized commissions of $0.1 million during the three months ended March 31, 2022 which related to 2022 commissions and $0.3 million which related to 2021 commissions.

- added (2022-08-18):
[0001628280-22-023253:note_history:67]
During the three months ended June 30, 2022 and 2021, the Company amortized commission expense of $0.9 million and $0.5 million, respectively. During the six months ended June 30, 2022 and 2021, the Company amortized commission expense of $1.2 million and $0.6 million, respectively.

- changed (2022-08-18):
[0001628280-22-023253:note_history:68]
During the six months ended June 30, 2022, the Company donated three Evolv Express units to schools, resulting in $0.2 million in general and administrative expense, respectively, in the Company’s condensed consolidated statements of operations and comprehensive loss.
  (was, 2022-05-13, similarity 0.8819):
[0001558370-22-008639:note_history:68]
During the three months ended March 31, 2022, the Company donated three Evolv Express units to schools, resulting in $0.2 million in general and administrative expense in the Company’s condensed consolidated statements of operations and comprehensive loss.

- removed (2022-08-18):
[0001558370-22-008639:note_history:69]
5. Revenue Recognition

- removed (2022-08-18):
[0001558370-22-008639:note_history:70]
| ​ |  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue |  | $ | 166 |  | $ | 39 |  | $ | 205 |
| Subscription revenue |  | ​ | 12,784 |  | ​ | 29,041 |  | ​ | 41,825 |
| Service revenue |  | ​ | 6 | ​ | ​ | — | ​ | ​ | 6 |
| Maintenance revenue | ​ | ​ | 2,415 | ​ | ​ | 6,086 | ​ | ​ | 8,501 |
| Total revenue | ​ | $ | 15,371 | ​ | $ | 35,166 | ​ | $ | 50,537 |

- removed (2022-08-18):
[0001558370-22-008639:note_history:71]
| Future operating lease component: |  | ​ |  |
| Year Ending December 31: | ​ | ​ | ​ |
| 2022 (nine months remaining) | ​ | $ | 9,677 |
| 2023 | ​ |  | 12,330 |
| 2024 | ​ |  | 11,137 |
| 2025 | ​ |  | 7,438 |
| 2026 | ​ | ​ | 1,131 |
| Thereafter | ​ |  | 112 |
| ​ | ​ | $ | 41,825 |

- removed (2022-08-18):
[0001558370-22-008639:note_history:72]
time. As of March 31, 2022 and December 31, 2021, the Company had $1.4 million and $1.5 million in current portion of contract assets and $3.3 million and $3.4 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- removed (2022-08-18):
[0001558370-22-008639:note_history:73]
| ​ | ​ | Three Months Ended March 31, |
| ​ | ​ | 2022 | ​ | ​ | 2021 |
| Revenue from sales-type leases | $ | 1,312 | ​ | $ | — |
| Interest income on lease receivables | ​ | 190 | ​ |  | — |
| Lease income - operating leases | ​ | 3,020 | ​ | ​ | 1,300 |
| Total lease revenue | $ | 4,522 | ​ | $ | 1,300 |

- removed (2022-08-18):
[0001558370-22-008639:note_history:74]
| ​ | ​ | Three Months Ended March 31, |
| ​ | ​ | 2022 |  | 2021 |
| Product revenue | ​ | ​ | 5,194 |  | ​ | 2,502 |
| Leased equipment | ​ | ​ | 3,020 |  | ​ | 1,300 |
| SaaS and Maintenance revenue | ​ | ​ | 353 |  | ​ | 132 |
| Professional services revenue | ​ | ​ | 148 | ​ | ​ | 65 |
| Total revenue | ​ | $ | 8,715 | ​ | $ | 3,999 |
