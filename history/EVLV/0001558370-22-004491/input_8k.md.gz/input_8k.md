# EVLV 8-K — 0001104659-22-033306 filed 2022-03-14

## item codes, every 8-K on or before 2022-03-28

- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2022-03-28

- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-22-033306:8k_2_02:1]
EX-99.1
2
tm229128d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-22-033306:8k_2_02:2]
Exhibit 99.1

[0001104659-22-033306:8k_2_02:3]
| Investor Relations: Brian Norris Vice President of Investor Relations bnorris@evolvtechnology.com | Public Relations: Fitz Barth Director of Communications fbarth@evolvtechnology.com |

[0001104659-22-033306:8k_2_02:4]
Evolv Technology Reports Strong Fourth Quarter
and Full Year Financial Results

[0001104659-22-033306:8k_2_02:5]
– Company Issues Outlook for 2022
–

[0001104659-22-033306:8k_2_02:6]
|  | · | Q4 Total Contract Value (“TCV”)1 of $17.9 million, up 201% year-over-year |

[0001104659-22-033306:8k_2_02:7]
|  | · | Q4 Revenue of $6.8 million, up 236% year-over-year |

[0001104659-22-033306:8k_2_02:8]
|  | · | Full Year TCV1 of $53.8 million, up 148% year-over-year |

[0001104659-22-033306:8k_2_02:9]
|  | · | Full Year Revenue of $23.7 million, up 395% year-over-year |

[0001104659-22-033306:8k_2_02:10]
Waltham, Massachusetts – March 14,
2022 – Evolv Technology (NASDAQ: EVLV), the global leader in AI-based weapons detection security screening, today announced
financial results for its fourth quarter and year ended December 31, 20212 and issued its business outlook for 2022.

[0001104659-22-033306:8k_2_02:11]
“We’re pleased to be reporting strong
fourth quarter results highlighted by a record number of new customers across our key vertical markets, the launch of several demand-driven
offerings, and continuing momentum with our channel-centric go to market strategy,” said Peter George, Chief Executive Officer of
Evolv Technology. “Looking ahead to 2022, we plan to continue focusing on the opportunities we see to leverage our solutions to
democratize security for facilities and venues in all of our target markets. We believe we enter the new year well-positioned and highly
motivated to extend our leadership position in the rapidly growing market for AI-based weapons detection.”

[0001104659-22-033306:8k_2_02:12]
Results for the Fourth Quarter of 2021

[0001104659-22-033306:8k_2_02:13]
Total revenue for the fourth quarter of 2021
was $6.8 million, an increase of 236% compared to $2.0 million for the fourth quarter of 2020. Total Contract Value
(“TCV”)1 of orders booked for the fourth quarter of 2021 was $17.9 million, an increase of 201% compared to
$6.0 million in the fourth quarter of 2020. Annual Recurring Revenue (“ARR”)3 was $12.9 million at the end of
fourth quarter of 2021, an increase of 220% compared to $4.0 million in the fourth quarter of 2020. Net income for the fourth
quarter of 2021 was $2.5 million, or $0.02 per basic and diluted share, compared to net loss of $9.6 million, or $1.06 per basic and
diluted share, for the fourth quarter of 2020. As of December 31, 2021, the Company had cash and cash equivalents of $307.5
million compared to $4.7 million as of December 31, 2020.

[0001104659-22-033306:8k_2_02:14]
Results for 2021

[0001104659-22-033306:8k_2_02:15]
Total revenue in 2021 was $23.7 million, an increase
of 395% compared to $4.8 million in 2020. TCV of orders booked in 2021 was $53.8 million, an increase of 148% compared to $21.7 million
in 2020. Net loss in 2021 was $10.9 million, or $0.15 per basic and diluted share, compared to net loss of $27.4 million, or $3.07 per
basic and diluted share, in 2020.

[0001104659-22-033306:8k_2_02:16]
Company Issues Outlook for 2022

[0001104659-22-033306:8k_2_02:17]
The Company today issued its business outlook
for 2022. The Company's outlook is based on the current indications for its business, which may change at any time.

[0001104659-22-033306:8k_2_02:18]
| Estimate (In millions) |  | 2021 Actual |  |  | 2022 Business Outlook |
| Total Revenue |  | $ | 23.7 |  |  | $29-$31 |
| Annual Recurring Revenue3 at 12/31 |  | $ | 12.9 |  |  | $27-$28 |
| Operating Expenses |  | $ | 60.7 |  |  | $94-$96 |
| Operating Loss |  | $ | (54.0 | ) |  | ($82-$84) |
| Adjusted EBITDA4 |  |  | n/m |  |  | ($65-$67) |
| Cash and Cash Equivalents |  | $ | 307.5 |  |  | $220-$230 |

[0001104659-22-033306:8k_2_02:19]
Company to Host Live Conference Call and Webcast

[0001104659-22-033306:8k_2_02:20]
The Company’s management team plans to
host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s
outlook for the business and other matters. The conference call may be accessed in the United States by dialing +1.844.867.6169 and using
access code 1400696. The conference call may be accessed outside of the United States by dialing +1.409.207.6975 and using access code
1400696. The conference call will be simultaneously webcast on the Company’s Investor Relations website, which can be accessed
at http://ir.evolvtechnology.com. A replay of the conference call will be available for a period of 30 days by dialing +1.866.207.1041
or +1.402.970.0847 and using access code 1987557 or by accessing the webcast replay on the Company’s investor relations website
at http://ir.evolvtechnology.com. The Company has used, and intends to continue to use, the investor relations portion of its
website as a means of disclosing material non-public information and for complying with disclosure obligations under Regulation FD.

[0001104659-22-033306:8k_2_02:21]
About Evolv Technology

[0001104659-22-033306:8k_2_02:22]
Evolv Technology (NASDAQ: EVLV) is the global
leader in weapons detection security screening. Our mission is enabling a better experience and better security for venues, creating
a safer world to work, learn, and play by transforming physical security to make everywhere safer. This enhances the visitor experience
and improves weapons detection. We give sports fans, theme park visitors, concert goers, shoppers, employees, students, and others peace
of mind so that they can gather without fear of violence. Our security system, delivered as a SaaS-based offering, has scanned more than
200 million people, second only to the Department of Homeland Security’s Transportation Security Administration in the United States,
and our technology combines powerful, advanced sensors with proven artificial intelligence (AI), security ecosystem integrations, and
comprehensive venue analytics to reliably detect threats 10 times faster than traditional metal detectors. Evolv Technology, Evolv Express®,
Evolv Insights™, and Evolv Cortex AI™ are registered trademarks or trademarks of Evolv Technologies, Inc. in the United
States and other jurisdictions. For more information, visit https://evolvtechnology.com.

[0001104659-22-033306:8k_2_02:23]
1 We define Total Contract Value,
or TCV, of orders booked as the total value of the contract over the specified term. Our calculation of TCV is not adjusted for the impact
of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases). TCV
should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of TCV may
differ from similarly titled metrics presented by other companies.

[0001104659-22-033306:8k_2_02:24]
2 Amounts herein pertaining to December 31,
2021 represent a preliminary estimate as of the date of this earnings release. More information on our results of operations for the three
and twelve months ended December 31, 2021 will be provided upon filing our Annual Report on Form 10-K with the Securities and
Exchange Commission.

[0001104659-22-033306:8k_2_02:25]
3 We define Annual Recurring Revenue,
or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter
normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as
customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on
its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR
at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other
changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR
should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may
differ from similarly titled metrics presented by other companies.

[0001104659-22-033306:8k_2_02:26]
4 Non-GAAP Financial Measures
In this press release, the Company’s adjusted gross profit, adjusted gross margin, and adjusted EBITDA are not presented in accordance
with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations.
Adjusted gross profit and adjusted gross margin exclude one-time items and depreciation and amortization which management believes provides
a more meaningful representation of contribution margin. Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization,
share-based compensation and other expense. Management presents non-GAAP financial measures because it considers them to be important
supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's
performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments.
Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's
financial and operational performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended
to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part
of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial
reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial
measures. A reconciliation of our non-GAAP financial measures to their most directly comparable GAAP measures has been provided in this
press release.

[0001104659-22-033306:8k_2_02:27]
Forward-Looking Statements

[0001104659-22-033306:8k_2_02:28]
Evolv
Technology

[0001104659-22-033306:8k_2_02:29]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE
LOSS

[0001104659-22-033306:8k_2_02:30]
(In thousands, except share and per share data)

[0001104659-22-033306:8k_2_02:31]
(Unaudited)

[0001104659-22-033306:8k_2_02:32]
|  |  | Three Months Ended December 31, |  |  | Twelve Months Ended December 31 |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue |  | $ | 3,618 |  |  | $ | 857 |  |  | $ | 13,917 |  |  | $ | 1,279 |  |
| Subscription revenue |  |  | 2,737 |  |  |  | 894 |  |  |  | 7,855 |  |  |  | 2,637 |  |
| Service revenue |  |  | 491 |  |  |  | 284 |  |  |  | 1,920 |  |  |  | 869 |  |
| Total revenue |  |  | 6,846 |  |  |  | 2,035 |  |  |  | 23,692 |  |  |  | 4,785 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue |  |  | 5,234 |  |  |  | 816 |  |  |  | 12,471 |  |  |  | 1,177 |  |
| Subscription revenue |  |  | 1,102 |  |  |  | 632 |  |  |  | 3,644 |  |  |  | 1,824 |  |
| Service revenue |  |  | 204 |  |  |  | 119 |  |  |  | 936 |  |  |  | 495 |  |
| Total cost of revenue |  |  | 6,540 |  |  |  | 1,567 |  |  |  | 17,051 |  |  |  | 3,496 |  |
| Gross profit |  |  | 306 |  |  |  | 468 |  |  |  | 6,641 |  |  |  | 1,289 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 3,086 |  |  |  | 5,081 |  |  |  | 11,416 |  |  |  | 15,710 |  |
| Sales and marketing |  |  | 10,120 |  |  |  | 2,260 |  |  |  | 27,404 |  |  |  | 7,365 |  |
| General and administrative |  |  | 8,851 |  |  |  | 2,434 |  |  |  | 20,013 |  |  |  | 5,110 |  |
| Loss from impairment of leased equipment |  |  | 213 |  |  |  | - |  |  |  | 1,869 |  |  |  | - |  |
| Total operating expenses |  |  | 22,270 |  |  |  | 9,775 |  |  |  | 60,702 |  |  |  | 28,185 |  |
| Loss from operations |  |  | (21,964 | ) |  |  | (9,307 | ) |  |  | (54,061 | ) |  |  | (26,896 | ) |
| Interest and other expense |  |  | (55 | ) |  |  | (223 | ) |  |  | (6,712 | ) |  |  | (430 | ) |
| Loss on extinguishment of debt |  |  | - |  |  |  | (66 | ) |  |  | (12,685 | ) |  |  | (66 | ) |
| Change in fair value of derivative liability |  |  | - |  |  |  | - |  |  |  | (1,745 | ) |  |  | - |  |
| Change in fair value of contingent earn-out liability |  |  | 14,394 |  |  |  | - |  |  |  | 46,212 |  |  |  | - |  |
| Change in fair value of contingently issuable common stock liability |  |  | 688 |  |  |  | - |  |  |  | 6,406 |  |  |  | - |  |
| Change in fair value of public warrant liability |  |  | 9,454 |  |  |  | - |  |  |  | 12,606 |  |  |  | - |  |
| Change in fair value of common stock warrant liability |  |  | - |  |  |  | - |  |  |  | (879 | ) |  |  | - |  |
| Total other income (expense) |  | $ | 24,481 |  |  | $ | (289 | ) |  | $ | 43,203 |  |  | $ | (496 | ) |
|  |  |  |  |  |  |  |  |  |  |  | 6 |  |  |  |  |  |
| Net income (loss) and comprehensive income (loss) attributable to common stockholders – basic and diluted |  | $ | 2,517 |  |  | $ | (9,596 | ) |  | $ | (10,858 | ) |  | $ | (27,392 | ) |
| Net income (loss) per share – basic and diluted |  | $ | 0.02 |  |  | $ | (1.06 | ) |  | $ | (0.15 | ) |  | $ | (3.07 | ) |
| Weighted average ordinary shares outstanding – basic |  |  | 142,403,779 |  |  |  | 9,044,968 |  |  |  | 71,662,694 |  |  |  | 8,932,404 |  |
| Weighted average ordinary shares outstanding – diluted |  |  | 161,906,393 |  |  |  | 9,044,968 |  |  |  | 71,662,694 |  |  |  | 8,932,404 |  |

[0001104659-22-033306:8k_2_02:33]
Evolv
Technology

[0001104659-22-033306:8k_2_02:34]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001104659-22-033306:8k_2_02:35]
(In thousands, except share and per share data)

[0001104659-22-033306:8k_2_02:36]
(Unaudited)

[0001104659-22-033306:8k_2_02:37]
|  |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Assets |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 307,492 |  |  | $ | 4,704 |  |
| Restricted Cash |  |  | 400 |  |  |  | - |  |
| Accounts receivable, net |  |  | 6,477 |  |  |  | 1,401 |  |
| Inventory |  |  | 5,140 |  |  |  | 2,742 |  |
| Prepaid expenses and other current assets |  |  | 14,151 |  |  |  | 1,462 |  |
| Total current assets |  |  | 333,660 |  |  |  | 10,309 |  |
| Commission asset, noncurrent |  |  | 3,719 |  |  |  | 1,730 |  |
| Property and equipment, net |  |  | 21,592 |  |  |  | 9,316 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  |  | - |  |
| Other long-term assets |  |  | 3,819 |  |  |  | - |  |
| Total assets |  | $ | 363,065 |  |  | $ | 21,355 |  |
| Liabilities and Shareholders’ Equity (Deficit) |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 6,363 |  |  | $ | 4,437 |  |
| Accrued expenses and other current liabilities |  |  | 9,183 |  |  |  | 3,727 |  |
| Current portion of deferred revenue |  |  | 6,690 |  |  |  | 3,717 |  |
| Current portion of long-term debt |  |  | 2,000 |  |  |  | - |  |
| Other current liabilities |  |  | 135 |  |  |  | 238 |  |
| Total current liabilities |  |  | 24,371 |  |  |  | 12,119 |  |
| Deferred revenue, noncurrent |  |  | 2,475 |  |  |  | 480 |  |
| Noncurrent portion of deferred rent |  |  | 333 |  |  |  | - |  |
| Common stock warrant liability |  |  | - |  |  |  | 1 |  |
| Public warrant liability |  |  | 11,030 |  |  |  | - |  |
| Derivative liability |  |  | - |  |  |  | 1,000 |  |
| Contingent earn-out liability |  |  | 20,809 |  |  |  | - |  |
| Contingently issuable common stock liability |  |  | 5,264 |  |  |  | - |  |
| Financing obligation, noncurrent |  |  | - |  |  |  | 132 |  |
| Long-term debt, noncurrent |  |  | 7,945 |  |  |  | 16,432 |  |
| Total liabilities |  |  | 72,227 |  |  |  | 30,164 |  |
| Convertible preferred stock and shareholders’ equity |  |  |  |  |  |  |  |  |
| Convertible preferred stock |  |  | - |  |  |  | 75,877 |  |
| Common stock |  |  | 14 |  |  |  | 1 |  |
| Additional paid-in capital |  |  | 395,563 |  |  |  | 9,194 |  |
| Accumulated deficit |  |  | (104,739 | ) |  |  | (93,881 | ) |
| Total shareholders’ equity (deficit) |  |  | 290,838 |  |  |  | (84,686 | ) |
| Total liabilities and shareholders’ equity |  | $ | 363,065 |  |  | $ | 21,355 |  |

[0001104659-22-033306:8k_2_02:38]
EVOlv
TECHNOLOGY

[0001104659-22-033306:8k_2_02:39]
Consolidated
Statements Of Cash Flows

[0001104659-22-033306:8k_2_02:40]
(In thousands)

[0001104659-22-033306:8k_2_02:41]
(Unaudited)

[0001104659-22-033306:8k_2_02:42]
|  |  | Twelve Months Ended December 31, |  |
|  |  | 2021 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (10,858 | ) |  | $ | (27,392 | ) |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 2,895 |  |  |  | 1,065 |  |
| Write-off of inventory |  |  | 2,041 |  |  |  | - |  |
| Loss from impairment of leased equipment |  |  | 1,869 |  |  |  | - |  |
| Loss on disposal of fixed assets |  |  | 617 |  |  |  | - |  |
| Stock-based compensation |  |  | 8,511 |  |  |  | 662 |  |
| Noncash interest expense |  |  | 5,245 |  |  |  | 25 |  |
| Provision recorded for allowance for doubtful accounts |  |  | (13 | ) |  |  | 47 |  |
| Loss on extinguishment of debt |  |  | 12,685 |  |  |  | 66 |  |
| Change in fair value of derivative liability |  |  | 1,745 |  |  |  | - |  |
| Change in fair value of common stock warrant liability |  |  | 879 |  |  |  | - |  |
| Change in fair value of earn-out liability |  |  | (46,212 | ) |  |  | - |  |
| Change in fair value of contingently issuable common stock |  |  | (6,406 | ) |  |  | - |  |
| Change in fair value of public warrant liability |  |  | (12,606 | ) |  |  | - |  |
| Changes in operating assets and liabilities |  |  | (29,673 | ) |  |  | 2,273 |  |
| Net cash used in operating activities |  |  | (69,281 | ) |  |  | (23,254 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property and equipment |  |  | (4,057 | ) |  |  | (6,609 | ) |
| Development of internal-use software |  |  | (1,028 | ) |  |  | - |  |
| Net cash used in investing activities |  |  | (5,085 | ) |  |  | (6,609 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from issuance of Series B-1 convertible preferred stock, net of issuance costs |  |  | - |  |  |  | 2,994 |  |
| Proceeds from exercise of stock options |  |  | 915 |  |  |  | 442 |  |
| Proceeds from issuance of common stock from the PIPE Investment |  |  | 300,000 |  |  |  | - |  |
| Proceeds from the closing of the Merger |  |  | 84,945 |  |  |  | - |  |
| Payment of offering costs from the closing of the Merger and PIPE Investment |  |  | (34,132 | ) |  |  | - |  |
| Repayment of financing obligations |  |  | (359 | ) |  |  | (244 | ) |
| Proceeds from long-term debt, net of issuance costs |  |  | 31,882 |  |  |  | 22,438 |  |
| Repayment of principal on long term debt |  |  | (5,422 | ) |  |  | (8,404 | ) |
| Net cash provided by financing activities |  |  | 377,829 |  |  |  | 17,226 |  |
| Net increase (decrease) in Cash, cash equivalents and restricted cash |  |  | 303,463 |  |  |  | (12,637 | ) |
| Cash, cash equivalents and restricted cash, beginning of period |  |  | 4,704 |  |  |  | 17,341 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 308,167 |  |  | $ | 4,704 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 860 |  |  | $ | 405 |  |

[0001104659-22-033306:8k_2_02:43]
EVOlv
TECHNOLOGY

[0001104659-22-033306:8k_2_02:44]
Reconciliation
of 2022 NET Loss to Adjusted EBITDA

[0001104659-22-033306:8k_2_02:45]
(In thousands)

[0001104659-22-033306:8k_2_02:46]
(Unaudited)

[0001104659-22-033306:8k_2_02:47]
|  |  | Twelve Months Ended December 31, 2022 |  |
|  |  | High |  |  | Low |  |
| Net income (loss) |  | $ | (83,000 | ) |  | $ | (85,000 | ) |
| Adjustments to reconcile net income (loss) to Adjusted EBITDA: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 6,000 |  |  |  | 6,000 |  |
| Stock-based compensation |  |  | 11,000 |  |  |  | 11,000 |  |
| Other expense |  |  | 1,000 |  |  |  | 1,000 |  |
| Adjusted EBITDA |  | $ | (65,000 | ) |  | $ | (67,000 | ) |

[0001104659-22-033306:8k_2_02:48]
EVOlv
TECHNOLOGY

[0001104659-22-033306:8k_2_02:49]
SuMMARY
OF KEY OPERATING STATISTICS

[0001104659-22-033306:8k_2_02:50]
(Unaudited)

[0001104659-22-033306:8k_2_02:51]
| ($ in thousands) |  | December 31, 2020 |  |  | March 31, 2021 |  |  | June 30, 2021 |  |  | September 30, 2021 |  |  | December 31, 2021 |  |
| New customers |  |  | 6 |  |  |  | 13 |  |  |  | 21 |  |  |  | 23 |  |  |  | 27 |  |
| Total contract value of orders booked |  | $ | 5,956 |  |  | $ | 8,424 |  |  | $ | 10,476 |  |  | $ | 16,995 |  |  | $ | 17,916 |  |
| Annual recurring revenue |  | $ | 4,034 |  |  | $ | 5,424 |  |  | $ | 7,423 |  |  | $ | 9,932 |  |  | $ | 12,907 |  |
| Remaining performance obligation |  | $ | 13,381 |  |  | $ | 17,658 |  |  | $ | 24,930 |  |  | $ | 34,152 |  |  | $ | 40,160 |  |
| Contract value for units in backlog |  |  | n/a |  |  |  | n/a |  |  |  | n/a |  |  |  | n/a |  |  | $ | 10,599 |  |
| Net additions |  |  | 32 |  |  |  | 64 |  |  |  | 113 |  |  |  | 176 |  |  |  | 136 |  |
| Ending deployed units |  |  | 214 |  |  |  | 278 |  |  |  | 391 |  |  |  | 567 |  |  |  | 703 |  |

[0001104659-22-033306:8k_2_02:52]
# # #
