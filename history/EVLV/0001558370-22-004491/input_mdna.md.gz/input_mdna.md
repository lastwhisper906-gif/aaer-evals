# EVLV MD&A — 0001558370-22-004491


## mdna

[0001558370-22-004491:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001558370-22-004491:mdna:2]
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the merger as a wholly owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001558370-22-004491:mdna:3]
As used in this Annual Report on Form 10-K, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of the Merger and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001558370-22-004491:mdna:4]
Business Overview

[0001558370-22-004491:mdna:5]
We are a global leader in AI-based weapons detection for security screening. Unlike conventional walk-through metal detectors, our products use advanced sensors, artificial intelligence software, and cloud services to reliably detect guns, improvised explosives, and large knives while ignoring harmless items like phones and keys. This not only enhances security at venues and facilities but also improves the visitor experience by making screening up to ten times faster than alternatives at up to 70% lower total cost.

[0001558370-22-004491:mdna:6]
Our products have screened over 200 million visitors worldwide. We believe that we have screened more people through advanced systems than any organization other than the United States Transportation Security Administration (“TSA”). Our customers include many iconic venues across a wide variety of industries including major sports teams, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, large industrial workplaces, large school districts, and prominent houses of worship. We offer our products for purchase and primarily under a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue and creates expansion and upsell opportunities.

[0001558370-22-004491:mdna:7]
Our mission is to make the world a safer and more enjoyable place to live, work, study, and play. We are focused on delivering value in the spaces in and around the physical threshold of large venues and facilities. We believe that digitally transforming the threshold experience is one of the most exciting innovation opportunities of our time. We believe that our ongoing innovations will not only make venues and facilities safer and more enjoyable, but also more efficient and profitable.

[0001558370-22-004491:mdna:8]
Touchless security screening represents a paradigm shift for the security screening market which, according to our estimates, is currently a $20 billion market opportunity on an annual basis. Touchless security screening is a radical change from conventional security screening processes that primarily rely on walk-through metal detectors based on core

[0001558370-22-004491:mdna:9]
technology that was invented in the nineteenth century. This conventional approach presents numerous operational problems and hidden costs including a high number of nuisance alarms due to the inability to distinguish weapons from harmless items. These frequent nuisance alarms require resolution using manual bag checks and pat downs that are error-prone, labor cost-intensive, and unpleasant for visitors. This creates long wait times, dangerous crowding, and numerous opportunities for weapons to slip into venues undetected. The result is reduced security, frustrated visitors, and acutely stressful working conditions for employees.

[0001558370-22-004491:mdna:10]
By allowing visitors to walk through at a normal pace with their bags in hand and without emptying their pockets, our products significantly accelerate the security screening process while also reducing the number of nuisance alarms to a level that allows security guards to focus their attention on real threats. We believe there is significant demand for touchless security screening in venues and facilities that currently use slower, more invasive conventional metal detector screening. We also believe there is additional opportunity in venues and facilities that have not previously adopted weapon screening because of the limitations of conventional screening. Our technology is designed to allow these venues and facilities to successfully deploy security screening for the first time.

[0001558370-22-004491:mdna:11]
Our potential to develop this significant opportunity is rooted in our deep domain experience and commitment to research and development. Our engineering efforts are led by a team of seasoned experts in software development, physical security, and cybersecurity. Since our founding in July 2013, we have invested significant resources in developing an extensive portfolio of proprietary and differentiated technologies, with a focus on making security screening more precise, much faster, and far less labor intensive.

[0001558370-22-004491:mdna:12]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $23.7 million and $4.8 million for the years ended December 31, 2021 and 2020, respectively. We generated a net loss of $10.9 million and $27.4 million for the years ended December 31, 2021 and 2020, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products in both the United States and international markets, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001558370-22-004491:mdna:13]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through a combination of equity offerings and debt financings. In July 2021, we received gross proceeds of $300.0 million from our PIPE Investment as well as $84.9 million in proceeds, net of redemptions received from the closing of the Merger. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources.”

[0001558370-22-004491:mdna:14]
Merger Agreement

[0001558370-22-004491:mdna:15]
NewHold Investment Corporation Merger

[0001558370-22-004491:mdna:16]
On July 16, 2021, we completed the previously announced Merger, pursuant to the Agreement and Plan of Merger, dated as of March 5, 2021, and amended by the First Amendment to Agreement and Plan of Merger (the “Merger Agreement”), dated as of June 5, 2021. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. and the officers of NHIC, the legal predecessor company, resigned. The officers of Legacy Evolv became the officers of the Company, and the Company listed its shares of common stock, par value $0.0001 per share, on Nasdaq under the symbol “EVLV”.

[0001558370-22-004491:mdna:17]
Prior to the completion of the Merger, we entered into subscription agreements (collectively, the “PIPE Investment”) with certain parties subscribing for shares of our common stock (the “Subscribers”). Pursuant to the PIPE

[0001558370-22-004491:mdna:18]
Investment, we issued 30,000,000 shares of common stock for a purchase price of $10.00 per share with gross proceeds of $300.0 million. The purpose of the PIPE Investment was to fund general corporate expenses.

[0001558370-22-004491:mdna:19]
Upon the closing of the Merger, each share of NHIC Class B common stock issued and outstanding immediately prior to the effective time of the Merger, which totaled 10,391,513 shares held by the NHIC Initial Shareholders (“Initial Shareholders”), was automatically converted into one validly-issued share of our common stock.

[0001558370-22-004491:mdna:20]
Additional information regarding the Merger Agreement appears in Note 3 of our consolidated financial statements for the year ended December 31, 2021.

[0001558370-22-004491:mdna:21]
COVID-19

[0001558370-22-004491:mdna:22]
In March 2020, the World Health Organization declared the outbreak of the COVID-19 pandemic. The COVID-19 pandemic initially caused us to experience several adverse impacts, including extended sales cycles to close new orders for our products because many of our customers were required to shut down facilities completely or partially, delays in shipping and installing orders due to closed facilities and travel limitations, and delays in collecting accounts receivable.

[0001558370-22-004491:mdna:23]
The rapid development and uncertainty of the impacts of the COVID-19 pandemic precludes any prediction as to the ultimate impact of the COVID-19 pandemic on our business. However, the COVID-19 pandemic, and the measures taken to contain it, continue to present material uncertainty and risk with respect to our performance and financial results. In particular, venues and facilities across an array of vertical markets are temporarily reducing capital expenditure budgets globally as they seek to preserve liquidity to ensure the longevity of their own operations, which in turn may lead to reductions in purchases of our security screening products. Further, office closures may prevent organizations from reaching typical utilizations of our security screening products, resulting in reductions in purchases of add-on products and expansion units. Additionally, the COVID-19 pandemic may contribute to facility closures at our third-party contract manufacturer and key suppliers, causing delays and disruptions in product manufacturing, which could affect our ability to ship products purchased by our customers in a timely manner. Disruptions in the capital markets as a result of the COVID-19 pandemic may also adversely affect our business if these impacts continue for a prolonged period and we need additional liquidity.

[0001558370-22-004491:mdna:24]
In the short-term, we have taken, and will continue to take, actions to mitigate the impact of the COVID-19 pandemic on our cash flow and results of operations and financial condition. While we are experiencing supply chain challenges, we do see this being overcome in the near future. In the long-term, we believe that the COVID-19 pandemic will encourage organizations to reassess their security screening processes and may continue to accelerate their adoption of solutions such as touchless security screening, which could create additional demand for our products.

[0001558370-22-004491:mdna:25]
Additional information regarding COVID-19 risks appear in the “Risk Factors” section of this Annual Report.

[0001558370-22-004491:mdna:26]
Key Factors Affecting Our Operating Results

[0001558370-22-004491:mdna:27]
We believe that our performance and future success depend on many factors that present significant opportunities for us but also pose risks and challenges, including the following:

[0001558370-22-004491:mdna:28]
Adoption of our Security Screening Products

[0001558370-22-004491:mdna:29]
We believe the world will continue to focus on the safety and security of people in the places where they gather. Many of these locations are moving toward a more frictionless security screening experience. We believe that we are well-positioned to take advantage of this opportunity due to our proprietary technologies and global distribution capabilities. Our products are designed to empower venues and facilities to realize the full benefits of touchless security screening, including a rapid visitor throughput and minimal security staff to screened visitor physical contact. We expect that our results of operations, including revenue, will fluctuate for the foreseeable future as venues and facilities continue to shift away from conventional security screening processes towards touchless security screening. The degree to which potential and current customers recognize these benefits and invest in our products will affect our financial results.

[0001558370-22-004491:mdna:30]
Pricing, Product Cost and Margins

[0001558370-22-004491:mdna:31]
To date, most of our revenue has been generated by sales of products which represented 58.7% and 26.7% of our total revenue for the years ended December 31, 2021 and 2020, respectively. The remaining revenue was generated from subscription sales and services for our products. Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions. Subscription revenue was $7.9 million and $2.6 million for the years ended December 31, 2021 and 2020, respectively. With the further development, enhancement, and maintenance of Evolv Insights and its analytical platform during the three months ended December 31, 2021, we expect this source of subscription revenue to become a more significant portion of our total revenue in the year ended December 31, 2022, given its new features, functions and capabilities.

[0001558370-22-004491:mdna:32]
Pricing may also vary by region due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales/bookings/business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products to our customers.

[0001558370-22-004491:mdna:33]
Continued Investment and Innovation

[0001558370-22-004491:mdna:34]
We believe that we are a leader in AI-based weapons detection for security screening, offering transformative technologies that enable higher throughput, a more frictionless visitor experience, and substantial cost savings through our product innovations. Our performance is significantly dependent on the investment we make in our research and development efforts and on our ability to be at the forefront of the security screening industry. It is essential that we continually identify and respond to rapidly evolving customer requirements, develop and introduce innovative new products, enhance existing products and generate customer demand for our products. We believe that investment in our security screening products will contribute to long-term revenue growth, but it may adversely affect our near-term profitability.

[0001558370-22-004491:mdna:35]
Contingent Earn-out Shares

[0001558370-22-004491:mdna:36]
In connection with the Merger and pursuant to the Merger Agreement, certain of the Legacy Evolv shareholders and Legacy Evolv Service Providers are entitled to receive additional shares of the Company’s common stock (the “Earn-Out Shares”) upon the Company achieving certain milestones.

[0001558370-22-004491:mdna:37]
The Earn-Out Shares are classified as liabilities in our consolidated balance sheets and were initially measured at fair value. Each reporting period, the Earn-Out Shares are remeasured and changes in the fair value of the contingent earn-out are recorded in other income (expense), net in our consolidated statements of operations and comprehensive loss. When the Triggering Events have been achieved and the Earn-Out Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001558370-22-004491:mdna:38]
Additional information regarding Contingent Earn-out Shares vesting provisions and accounting treatment appear in Note 2 of our consolidated financial statements for the year ended December 31, 2021.

[0001558370-22-004491:mdna:39]
Contingently Issuable Common Stock

[0001558370-22-004491:mdna:40]
Prior to the Merger, NewHold Industrial Technology Holdings, LLC, the sponsor of the NHIC special purpose acquisition company owned 4,312,500 shares of NHIC Class B common stock (the “Founder Shares”). Upon the closing of the Merger, NHIC Class A and Class B common stock became the Company’s common stock. The Founder Shares are subject to certain share-performance-based vesting provisions. As of December 31, 2021, 1,897,500 Founder Shares have vested and are no longer subject to forfeiture.

[0001558370-22-004491:mdna:41]
The Founders Shares are classified as liabilities in our consolidated balance sheets and were initially measured at fair value. Each reporting period, the Founders Shares are remeasured and changes in the fair value of the contingently

[0001558370-22-004491:mdna:42]
issuable common stock are recorded in other income (expense), net in our consolidated statements of operations and comprehensive loss. When the Triggering Events have been achieved and the Founders Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001558370-22-004491:mdna:43]
Additional information regarding Contingently Issuable Common Stock vesting provisions and accounting treatment appear in Note 2 of our consolidated financial statements for the year ended December 31, 2021.

[0001558370-22-004491:mdna:44]
Components of Results of Operations

[0001558370-22-004491:mdna:45]
Revenue

[0001558370-22-004491:mdna:46]
We derive revenue from (1) subscription arrangements accounted for as operating leases, (2) from the sale of products, inclusive of SaaS and maintenance, and (3) professional services. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001558370-22-004491:mdna:47]
Product Revenue

[0001558370-22-004491:mdna:48]
We derive a portion of our revenue from the sale of our Express and Edge equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We expect product revenue to decline as a percentage of our overall revenue overtime as more and more customers enter full subscription transactions with us and as our subscription become more valuable to our business.

[0001558370-22-004491:mdna:49]
Subscription Revenue

[0001558370-22-004491:mdna:50]
In addition to selling our products directly to customers, we also lease our Express and Edge equipment which we classify as subscription revenue. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as they do not meet any of the capital lease criteria per ASC 840 and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001558370-22-004491:mdna:51]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (1) distinct services, such as installation, training, SaaS, and maintenance, and (2) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:mdna:52]
Services Revenue

[0001558370-22-004491:mdna:53]
We provide installation, training, SaaS, and maintenance services for our products. Revenue for installation and training are recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes and when-and-if available threat updates. SaaS and maintenance revenue is recognized ratably over the period of the arrangement. We sell separately priced extended or nonstandard warranty services and preventative maintenance plans, which are recognized ratably over the associated service period.

[0001558370-22-004491:mdna:54]
Cost of Revenue

[0001558370-22-004491:mdna:55]
We recognize cost of revenue in the same manner that the related revenue is recognized.

[0001558370-22-004491:mdna:56]
Cost of Product Revenue

[0001558370-22-004491:mdna:57]
Cost of product revenue consists primarily of costs paid to third party manufacturers, labor costs, shipping costs, amortization expense related to internal-use software, and write-offs of Edge units from inventory as we are no longer selling this product.

[0001558370-22-004491:mdna:58]
Cost of Subscription Revenue

[0001558370-22-004491:mdna:59]
Cost of subscription revenue consists primarily of labor costs, shipping costs, amortization expense related to internal-use software, and depreciation expense related to leased units.

[0001558370-22-004491:mdna:60]
Cost of Services Revenue

[0001558370-22-004491:mdna:61]
Cost of services revenue consists of costs related to SaaS and maintenance services. Costs of services revenue related to SaaS consists of costs of maintaining the Evolv Cloud Portal and our internal-use software, associated with our Evolv Express units. Cost of services revenue related to maintenance consists primarily of labor, spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001558370-22-004491:mdna:62]
A provision for the estimated cost related to warranty is recorded to cost of product, subscription, or services revenue at the time the associated revenue is recognized as necessary. Our estimate of costs to service the warranty obligations is based on historical experience and expectations of future conditions. As of December 31, 2021, we recorded a warranty accrual of less than $0.1 million.

[0001558370-22-004491:mdna:63]
Gross Profit and Gross Margin

[0001558370-22-004491:mdna:64]
Our gross profit is calculated based on the difference between our revenues and cost of revenues. Gross margin is the percentage obtained by dividing gross profit by our revenue. Our gross profit and gross margin are, or may be, influenced by a number of factors, including:

[0001558370-22-004491:mdna:65]
|  | • | Market conditions that may impact our pricing; |

[0001558370-22-004491:mdna:66]
|  | • | Product mix changes between established products and new products; |

[0001558370-22-004491:mdna:67]
|  | • | Our cost structure for manufacturing operations, including contract manufacturers, relative to volume, and our product support obligations; |

[0001558370-22-004491:mdna:68]
|  | • | Our ability to maintain our costs on the components that go into the manufacture of our product; and |

[0001558370-22-004491:mdna:69]
|  | • | Write-offs of inventory. |

[0001558370-22-004491:mdna:70]
We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001558370-22-004491:mdna:71]
Research and Development

[0001558370-22-004491:mdna:72]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, stock-based compensation, prototypes, design expenses, consulting and contractor costs, and the impact of the capitalization of costs associated with developing the Evolv Cloud Portal, our internal-use software. We expect research and development costs will increase on an absolute dollar basis over time as we continue to invest in advancing our portfolio of security screening products.

[0001558370-22-004491:mdna:73]
Sales and Marketing

[0001558370-22-004491:mdna:74]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success and global service, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will increase on an absolute dollar basis as we expand our headcount and initiate new marketing campaigns.

[0001558370-22-004491:mdna:75]
General and Administrative

[0001558370-22-004491:mdna:76]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and sales tax contingencies. We expect our general and administrative expenses will increase on an absolute dollar basis as a result of operating as a public company, including expenses necessary to comply with the rules and regulations applicable to companies listed on a national securities exchange and related to compliance and reporting obligations pursuant to the rules and regulations of the SEC, as well as increased expenses for general and director and officer insurance, and other administrative and professional services. In addition, we expect to incur additional costs as we hire additional personnel and enhance our infrastructure to support the anticipated growth of the business.

[0001558370-22-004491:mdna:77]
Loss From Impairment of Property and Equipment

[0001558370-22-004491:mdna:78]
Impairment of property and equipment relates to any units that are removed from service and retired. This is related to Edge units and Express prototype units that were taken out of service and retired. We are transitioning our domestic customers from the Legacy Evolv Edge units to our most current Evolv Express units, which also resulted in an impairment of the remaining economic value of such assets.

[0001558370-22-004491:mdna:79]
Interest Expense

[0001558370-22-004491:mdna:80]
Interest expense includes cash interest paid on our long-term debt as well as amortization of deferred financing fees and costs.

[0001558370-22-004491:mdna:81]
Other Expense

[0001558370-22-004491:mdna:82]
Other expense includes loss on disposals of our non-leased assets, primarily related to demo units.

[0001558370-22-004491:mdna:83]
Loss on Extinguishment of Debt

[0001558370-22-004491:mdna:84]
There was a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes consistent with the terms thereof, and interest due to each investor would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. This modification of the 2021 Convertible Notes was accounted for as an extinguishment.

[0001558370-22-004491:mdna:85]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the Convertible Notes also received the right to receive 1,000,000 shares of NHIC common stock. Upon the conversion of the Convertible Notes, the carrying value of the debt, including unamortized debt discount, and the related derivative liability and accrued interest were derecognized. The shares of common stock issued upon conversion of Convertible Notes were recorded at implied fair value of the Company’s common stock with the resulting difference being accounted for as a loss on extinguishment.

[0001558370-22-004491:mdna:86]
Change in Fair Value of Derivative Liability

[0001558370-22-004491:mdna:87]
In August through September 2019 and in September 2020, we issued Convertible Notes to several investors (the “2020 Convertible Notes”) that provided a conversion option whereby upon the closing of a specified financing event the notes would automatically convert into shares of the same class and series of our capital stock issued to other investors in the financing at a conversion price equal to 85% and 80%, respectively, of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative that was required to be bifurcated and accounted for separately from the notes. The derivative liability was initially recorded at fair value upon issuance of the notes and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the derivative liability are recognized in the consolidated statements of operations and comprehensive loss. In October 2019, the specified financing event was consummated, as such the 2020 Convertible Notes issued August through September 2019 were converted into shares of Series B-1 Preferred Stock and the derivative liability was extinguished.

[0001558370-22-004491:mdna:88]
In January and February 2021, we entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method.

[0001558370-22-004491:mdna:89]
In June 2021, we modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. The modification of the 2021 Convertible Notes resulted in the recognition of a derivative liability for the fair value of the 1,000,000 NHIC shares as of June 21, 2021 as well as a bifurcated embedded derivative for conversion feature into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors.

[0001558370-22-004491:mdna:90]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:mdna:91]
Change in Fair Value of Contingent Earn-out Liability

[0001558370-22-004491:mdna:92]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders are entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:mdna:93]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001558370-22-004491:mdna:94]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 shares of Founder Shares. 1,897,500 shares vested at the closing of the Merger, 1,897,500 shares shall vest upon us achieving certain milestones and 517,500 shares were contributed to Give Evolv LLC. Those 1,897,500 outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:mdna:95]
51

[0001558370-22-004491:mdna:96]
Change in Fair Value of Public Warrant Liability

[0001558370-22-004491:mdna:97]
In connection with the closing of the Merger, the Company assumed a warrant to purchase shares of common stock (the “Public Warrants”). As of December 31, 2021, the Public Warrants are outstanding. We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger with the offset to additional paid-in capital.

[0001558370-22-004491:mdna:98]
Change in Fair Value of Common Stock Warrant Liability

[0001558370-22-004491:mdna:99]
We classify certain warrants for the purchase of shares of our common stock as a liability on our consolidated balance sheets as these warrants are freestanding financial instruments that may require us to adjust the exercise price and number of shares that is not consistent with a fixed-for-fixed option pricing model. The warrant liability is initially recorded at fair value on the issuance date of each warrant and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the common stock warrant liability are recognized as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss. Changes in fair value of the common stock warrant liability will continue to be recognized until the warrants are exercised, expire or qualify for equity classification. In connection with the closing of the Merger, all common stock warrants that were issued prior to the closing of the Merger were converted into shares of the Company’s common stock.

[0001558370-22-004491:mdna:100]
Income Taxes

[0001558370-22-004491:mdna:101]
Our income tax provision consists of an estimate for U.S. federal and state income taxes based on enacted rates, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. There is no provision for income taxes for the years ended December 31, 2021, and 2020 because we have historically incurred net operating losses and maintain a full valuation allowance against its deferred tax assets.

[0001558370-22-004491:mdna:102]
Results of Operations

[0001558370-22-004491:mdna:103]
Comparison of the Year Ended December 31, 2021 and 2020

[0001558370-22-004491:mdna:104]
The following table summarizes our results of operations for the year ended December 31, 2021 and 2020 (in thousands):

[0001558370-22-004491:mdna:105]
| ​ | ​ | Year Ended December 31, | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 | ​ | $ Change |  | % Change |
| Revenue: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ | ​ |
| Product revenue | ​ | $ | 13,917 | ​ | $ | 1,279 | ​ | $ | 12,638 | ​ | 988 | % |
| Subscription revenue | ​ |  | 7,855 | ​ |  | 2,637 | ​ |  | 5,218 | ​ | 198 | ​ |
| Service revenue | ​ |  | 1,920 | ​ |  | 869 | ​ |  | 1,051 | ​ | 121 | ​ |
| Total revenue | ​ |  | 23,692 | ​ |  | 4,785 | ​ |  | 18,907 | ​ | 395 | ​ |
| Cost of revenue: | ​ |  |  | ​ |  |  | ​ |  | ​ | ​ | ​ | ​ |
| Cost of product revenue | ​ |  | 12,471 | ​ |  | 1,177 | ​ |  | 11,294 | ​ | 960 | ​ |
| Cost of subscription revenue | ​ |  | 3,644 | ​ |  | 1,824 | ​ |  | 1,820 | ​ | 100 | ​ |
| Cost of service revenue | ​ |  | 936 | ​ |  | 495 | ​ |  | 441 | ​ | 89 | ​ |
| Total cost of revenue | ​ |  | 17,051 | ​ |  | 3,496 | ​ |  | 13,555 | ​ | 388 | ​ |
| Gross profit | ​ |  | 6,641 | ​ |  | 1,289 | ​ |  | 5,352 | ​ | 415 | ​ |
| Operating expenses: | ​ |  |  | ​ |  |  | ​ |  | ​ | ​ | ​ | ​ |
| Research and development | ​ |  | 11,416 | ​ |  | 15,710 | ​ |  | (4,294) | ​ | (27) | ​ |
| Sales and marketing | ​ |  | 27,404 | ​ |  | 7,365 | ​ |  | 20,039 | ​ | 272 | ​ |
| General and administrative | ​ |  | 20,013 | ​ |  | 5,110 | ​ |  | 14,903 | ​ | 292 | ​ |
| Loss from impairment of property and equipment | ​ | ​ | 1,869 | ​ | ​ | — | ​ | ​ | 1,869 | ​ | * | ​ |
| Total operating expenses | ​ |  | 60,702 | ​ |  | 28,185 | ​ |  | 32,517 | ​ | 115 | ​ |
| Loss from operations | ​ |  | (54,061) | ​ |  | (26,896) | ​ |  | (27,165) | ​ | 101 | ​ |
| Other income (expense), net: | ​ |  |  | ​ |  |  | ​ |  | ​ | ​ | ​ | ​ |
| Interest expense, net | ​ |  | (6,095) | ​ |  | (430) | ​ |  | (5,665) | ​ | 1,317 | ​ |
| Loss on disposal of property and equipment | ​ |  | (617) | ​ |  | — | ​ |  | (617) | ​ | * | ​ |
| Loss on extinguishment of debt | ​ |  | (12,685) | ​ |  | (66) | ​ |  | (12,619) | ​ | 19,120 | ​ |
| Change in fair value of derivative liability | ​ | ​ | (1,745) | ​ | ​ | — | ​ | ​ | (1,745) | ​ | * | ​ |
| Change in fair value of contingent earn-out liability | ​ |  | 46,212 | ​ |  | — | ​ |  | 46,212 | ​ | * | ​ |
| Change in fair value of contingently issuable common stock liability | ​ |  | 6,406 | ​ |  | — | ​ |  | 6,406 | ​ | * | ​ |
| Change in fair value of public warrant liability | ​ | ​ | 12,606 | ​ | ​ | — | ​ | ​ | 12,606 | ​ | * | ​ |
| Change in fair value of common stock warrant liability | ​ | ​ | (879) | ​ | ​ | — | ​ | ​ | (879) | ​ | * | ​ |
| Total other income (expense), net | ​ |  | 43,203 | ​ |  | (496) | ​ |  | 43,699 | ​ | (8,810) | ​ |
| Net loss | ​ | $ | (10,858) | ​ | $ | (27,392) | ​ | $ | 16,534 | ​ | (60) | % |

[0001558370-22-004491:mdna:106]
*N/A – Not meaningful

[0001558370-22-004491:mdna:107]
53

[0001558370-22-004491:mdna:108]
Revenue, Cost of Revenue and Gross Profit

[0001558370-22-004491:mdna:109]
Product Revenue

[0001558370-22-004491:mdna:110]
| ​ | ​ | Year Ended December 31, | ​ | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 | ​ | ​ | $ Change |  | % Change |
| Product revenue | ​ | $ | 13,917 | ​ | $ | 1,279 | ​ | ​ | $ | 12,638 | ​ | 988 | % |
| Cost of product revenue | ​ | $ | 12,471 | ​ | $ | 1,177 | ​ | ​ | $ | 11,294 | ​ | 960 | % |
| Gross profit - Product revenue | ​ | $ | 1,446 | ​ | $ | 102 | ​ | ​ | $ | 1,344 | ​ | 1,318 | % |
| Gross profit margin - Product revenue | ​ |  | 10 | % |  | 8 | % | ​ | ​ | N/A | ​ | 2 | % |

[0001558370-22-004491:mdna:111]
The increase in product revenue and increase in cost of product revenue are primarily due to the increases in direct product sales of Evolv Express units, which included the significant increase in the adoption of Evolv Express units by professional sports teams. The increase in gross profit is primarily driven by our increased product sales volume, which was partially offset by an increase in shipping costs and one-time charges including write-offs of Evolv Edge units in inventory as we are no longer selling this product and purchase price variances recorded on raw materials. The increase in gross profit margin is primarily driven by our continued efforts to streamline the manufacturing process and reduce costs by introducing standardized parts into our product. We expect to continue to see improvement in our gross margins as we continue to engineer our product with lower cost components. As we continue to gain leverage in the marketplace with increased sales, we expect higher discounts from suppliers. We also expect to see improvement in gross margin to the extent shipping costs and high demand materials costs decline when global supply chain disruptions ease.

[0001558370-22-004491:mdna:112]
Subscription Revenue

[0001558370-22-004491:mdna:113]
| ​ | ​ | Year Ended December 31, | ​ | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 | ​ | ​ | $ Change |  | % Change |
| Subscription revenue | ​ | $ | 7,855 | ​ | $ | 2,637 | ​ | ​ | $ | 5,218 | ​ | 198 | % |
| Cost of subscription revenue | ​ | $ | 3,644 | ​ | $ | 1,824 | ​ | ​ | $ | 1,820 | ​ | 100 | % |
| Gross profit - Subscription revenue | ​ | $ | 4,211 | ​ | $ | 813 | ​ | ​ | $ | 3,398 | ​ | 418 | % |
| Gross profit margin - Subscription revenue | ​ |  | 54 | % |  | 31 | % | ​ | ​ | N/A | ​ | 23 | % |

[0001558370-22-004491:mdna:114]
The increase in subscription revenue and increase in cost of subscription revenue are primarily due to a larger number of active Evolv Express units installed during the period, growth in our customer base and contribution from our channel partners. The increase in gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin was primarily driven by increased recurring revenue from increased active subscriptions and customer growth, which we expect to continue.

[0001558370-22-004491:mdna:115]
Service Revenue

[0001558370-22-004491:mdna:116]
| ​ | ​ | Year Ended December 31, | ​ | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 | ​ | ​ | $ Change |  | % Change |
| Service revenue | ​ | $ | 1,920 | ​ | $ | 869 | ​ | ​ | $ | 1,051 | ​ | 121 | % |
| Cost of service revenue | ​ | $ | 936 | ​ | $ | 495 | ​ | ​ | $ | 441 | ​ | 89 | % |
| Gross profit - Service revenue | ​ | $ | 984 | ​ | $ | 374 | ​ | ​ | $ | 610 | ​ | 163 | % |
| Gross profit margin - Service revenue | ​ |  | 51 | % |  | 43 | % | ​ | ​ | N/A | ​ | 8 | % |

[0001558370-22-004491:mdna:117]
The increase in service revenue and increase in cost of service revenue are primarily due to increased installation and training related to the Evolv Express units and SaaS and maintenance services associated with increased subscriptions. The increase in gross profit is due to increased installations and trainings associated with greater sales. The increase in gross profit margin is primarily driven by standardization of the installation and training process, which results in overall lower costs, and increased margins related to SaaS and maintenance services provided for product sales. We expect to see continued increases in gross margin due to continued growth in active subscriptions and our customer base.

[0001558370-22-004491:mdna:118]
54

[0001558370-22-004491:mdna:119]
Research and Development Expenses

[0001558370-22-004491:mdna:120]
| ​ | ​ | Year Ended December 31, | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 | ​ | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | ​ | $ | 8,091 | ​ | $ | 3,737 | ​ | $ | 4,354 | ​ | 117 | % |
| Materials and prototypes | ​ | ​ | 2,153 | ​ | ​ | 8,907 | ​ | ​ | (6,754) | ​ | (76) | ​ |
| Professional fees | ​ | ​ | 861 | ​ | ​ | 2,642 | ​ | ​ | (1,781) | ​ | (67) | ​ |
| Facilities related and other | ​ |  | 311 | ​ | ​ | 424 | ​ |  | (113) | ​ | (27) | ​ |
| Total research and development expenses | ​ | $ | 11,416 | ​ | $ | 15,710 | ​ | $ | (4,294) | ​ | (27) | % |

[0001558370-22-004491:mdna:121]
The increase in personnel related expenses is due to an increase in additional personnel costs resulting from new hires in our research and development function in 2021, an increase in bonuses and commissions, an increase in stock-based compensation and an increase in recruiting costs, partially offset by of $0.3 million of wages capitalized in association with the development of internal-use software. The decrease in materials and prototype costs is due to the transition from prototype production to standard manufacturing of the Evolv Express, which results in lower prototyping costs. The decrease in professional fees is due to a decrease in consulting related to research and development efforts for prototype units and $0.7 million of external consulting costs capitalized in association with the development of internal-use software. The capitalization of the development of internal-use software is due to internal and external costs associated with further developing the Evolv Cloud Portal associated with our Evolv Express units.

[0001558370-22-004491:mdna:122]
Sales and Marketing Expenses

[0001558370-22-004491:mdna:123]
| ​ | ​ | Year Ended December 31, | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 | ​ | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | ​ | $ | 18,717 | ​ | $ | 5,347 | ​ | $ | 13,370 | ​ | 250 | % |
| Direct marketing and customer field services | ​ | ​ | 4,292 | ​ | ​ | 590 | ​ | ​ | 3,702 | ​ | 627 | ​ |
| Travel and entertainment | ​ | ​ | 1,652 | ​ | ​ | 554 | ​ | ​ | 1,098 | ​ | 198 | ​ |
| Professional fees | ​ | ​ | 874 | ​ | ​ | 461 | ​ | ​ | 413 | ​ | 90 | ​ |
| Facilities related and other | ​ |  | 1,869 | ​ | ​ | 413 | ​ |  | 1,456 | ​ | 353 | ​ |
| Total sales and marketing expenses | ​ | $ | 27,404 | ​ | $ | 7,365 | ​ | $ | 20,039 | ​ | 272 | % |

[0001558370-22-004491:mdna:124]
The increase in personnel related expenses is due to an increase in additional personnel costs resulting from new hires in our sales and marketing functions in 2021, an increase in bonuses and commissions, and an increase in stock-based compensation. The increase in direct marketing and customer field services is due to an increase in trade shows and events and an increase in sales volume. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings and events. The increase in professional fees is due to an increase in consulting fees related to business development and marketing as part of efforts to drive sales growth. The increase in facilities related and other expenses is primarily due to an increase in office supplies and an increase in subscriptions related to gathering market research.

[0001558370-22-004491:mdna:125]
55

[0001558370-22-004491:mdna:126]
General and Administrative Expenses

[0001558370-22-004491:mdna:127]
| ​ | ​ | Year Ended December 31, | ​ | ​ | ​ |  | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 | ​ | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | ​ | $ | 7,731 | ​ | $ | 1,967 | ​ | $ | 5,764 | ​ | 293 | % |
| Professional fees | ​ | ​ | 6,241 | ​ | ​ | 1,879 | ​ | ​ | 4,362 | ​ | 232 | ​ |
| Director and officer insurance | ​ | ​ | 2,187 | ​ | ​ | 566 | ​ | ​ | 1,621 | ​ | 286 | ​ |
| Sales tax contingencies | ​ | ​ | 1,091 | ​ | ​ | — | ​ | ​ | 1,091 | ​ | * | ​ |
| Facilities related and other | ​ |  | 2,763 | ​ | ​ | 698 | ​ |  | 2,065 | ​ | 296 | ​ |
| Total general and administrative expenses | ​ | $ | 20,013 | ​ | $ | 5,110 | ​ | $ | 14,903 | ​ | 292 | % |

[0001558370-22-004491:mdna:128]
*N/A – Not meaningful

[0001558370-22-004491:mdna:129]
The increase in personnel related expenses is due to an increase in salaries and related costs resulting from expanding our administrative team and an increase in stock-based compensation. The increase in professional fees is due to an increase in audit, tax, and legal services provided to the Company related to the Merger and to support public company requirements. The increase in director and officer insurance expense is due to us operating as a public company. The increase in sales tax contingencies is due to an increase in our sales tax contingency liability as we may owe additional sales and use taxes in various jurisdictions.  The increase in facilities related and other expenses is due to us relocating to our new corporate headquarters with a larger office space to accommodate our growth and increase in personnel.

[0001558370-22-004491:mdna:130]
Loss From Impairment of Property and Equipment

[0001558370-22-004491:mdna:131]
Impairment of property and equipment was $1.9 million for the year ended December 31, 2021. There was no impairment for the year ended December 31, 2020. This related to Edge units and Express prototype units that were removed from service and retired. We are transitioning our domestic customers from the Legacy Evolv Edge units to our most current Evolv Express units, which also resulted in an impairment of the remaining economic value of such assets.

[0001558370-22-004491:mdna:132]
Interest Expense

[0001558370-22-004491:mdna:133]
Interest expense was $6.1 million for the year ended December 31, 2021, compared to $0.4 million for the year ended December 31, 2020. The increase of $5.7 million was primarily due to the issuance of $30.0 million of convertible notes during the year ended December 31, 2021. The Convertible Notes and corresponding accrued interest were converted into the Company’s common stock upon closing of the Merger.

[0001558370-22-004491:mdna:134]
Loss on Disposal of Property and Equipment

[0001558370-22-004491:mdna:135]
Other expense was $0.6 million for the year ended December 31, 2021, compared to $0 for the year ended December 31, 2020. The increase of $0.6 million was primarily due to loss on disposal of non-leased assets, primarily related to demo units, during the year ended December 31, 2021.

[0001558370-22-004491:mdna:136]
Loss on Extinguishment of Debt

[0001558370-22-004491:mdna:137]
Loss on extinguishment of debt was $12.7 million for the year ended December 31, 2021, compared to $0.1 million for the year ended December 31, 2020. This was due to the modification of the 2021 Convertible Notes and then the conversion of the 2021 Convertible Notes into shares of the Company’s stock upon closing of the Merger.

[0001558370-22-004491:mdna:138]
Change in Fair Value of Derivative Liability

[0001558370-22-004491:mdna:139]
Change in fair value of the derivative liability was $1.7 million for the year ended December 31, 2021. There was no change in fair value of derivative liability for the year ended December 31, 2020. This was due to entering into

[0001558370-22-004491:mdna:140]
additional convertible notes during 2021 and changes in the fair value of corresponding embedded derivatives given the pending Merger.

[0001558370-22-004491:mdna:141]
Change in Fair Value of Contingent Earn-out Liability

[0001558370-22-004491:mdna:142]
Change in fair value of the contingent earn-out liability was $46.2 million for the year ended December 31, 2021, compared to $0 for the year ended December 31, 2020. This was due to establishing the contingent earn-out liability in connection with the closing of the Merger. The change in fair value of the contingent earn-out liability from issuance through period end is due to mark to market fluctuations driven by a decrease in stock price, resulting in significant income recognized in other income (expense), net in our consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:mdna:143]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001558370-22-004491:mdna:144]
Change in fair value of the contingently issuable common stock liability was $6.4 million for the year ended December 31, 2021, compared to $0 for the year ended December 31, 2020. This was due to establishing the contingently issuable common stock liability in connection with the closing of the Merger. The change in fair value of the contingently issuable common stock liability from issuance through period end is due to mark to market fluctuations driven by a decrease in stock price, resulting in significant income recognized in other income (expense), net in our consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:mdna:145]
Change in Fair Value of Public Warrant Liability

[0001558370-22-004491:mdna:146]
Change in fair value of the public warrant liability was $12.6 million for the year ended December 31, 2021, compared to $0 for the year ended December 31, 2020. This was due to establishing the public warrant liability in connection with the closing of the Merger. The change in fair value of the public warrant liability from issuance through period end is due to mark to market fluctuations driven by a decrease in the publicly traded warrant price, resulting in significant income recognized in other income (expense), net in our consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:mdna:147]
Change in Fair Value of Common Stock Warrant Liability

[0001558370-22-004491:mdna:148]
Change in fair value of the common stock warrant liability was $0.9 million for the year ended December 31, 2021, compared to $0 for the year ended December 31, 2020. The change in fair value of the common stock warrant liability was due mark to market fluctuations prior to the conversion of the common stock warrant liability upon the closing of the Merger.

[0001558370-22-004491:mdna:149]
Income Taxes

[0001558370-22-004491:mdna:150]
There is no provision for income taxes for the years ended December 31, 2021 and 2020 because we have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets. We have provided a valuation allowance for all of our deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001558370-22-004491:mdna:151]
Liquidity and Capital Resources

[0001558370-22-004491:mdna:152]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. Prior to the Merger, as an early-stage company, we primarily obtained cash to fund our operations through preferred stock

[0001558370-22-004491:mdna:153]
offerings and debt instruments. As of December 31, 2021, we had $307.5 million in cash and cash equivalents. We incurred a net loss of $10.9 million and $27.4 million for the year ended December 31, 2021 and 2020, respectively. We incurred cash outflows from operating activities of $69.6 million and $23.3 million during the year ended December 31, 2021 and 2020, respectively.

[0001558370-22-004491:mdna:154]
We expect our cash and cash equivalents, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Annual Report on Form 10-K. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our sales and marketing teams worldwide. We are likely to require additional capital to respond to technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions or unforeseen circumstances and in either the short-term or long-term may determine to engage in equity or debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, the widespread COVID-19 pandemic, including variants, has resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001558370-22-004491:mdna:155]
PIPE Investment and Proceeds from the closing of the Merger

[0001558370-22-004491:mdna:156]
In July 2021, we received gross proceeds of $300.0 million from our PIPE Investment, as well as $84.9 million in proceeds, net of redemptions received in connection with the closing of the Merger.

[0001558370-22-004491:mdna:157]
Financing Arrangements

[0001558370-22-004491:mdna:158]
In December 2020, we entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024, and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022, which extinguished the 2020 Silicon Valley Bank Term Loan. Under the terms of the JPM Credit Agreement, we received proceeds of $10.0 million. As of December 31, 2021, we had $9.9 million of debt outstanding. In September and December of 2020, we issued a total of $4.0 million of convertible notes (the “2020 Convertible Notes”). In January and February 2021, we issued a total of $30.0 million of convertible notes with a maturity date of September 2021.

[0001558370-22-004491:mdna:159]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense), net.

[0001558370-22-004491:mdna:160]
Material Cash Requirements for Known Contractual and Other Obligations

[0001558370-22-004491:mdna:161]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as December 31, 2021 and December 31, 2020. We anticipate fulfilling such commitments with our existing cash and cash equivalents obtained through operations, proceeds from long-term debt, closing of the Merger, and issuance of common stock in connection with the PIPE investment. Cash and cash equivalents amounted to $307.5 million and $4.7 million as of December 31, 2021 and 2020, respectively.

[0001558370-22-004491:mdna:162]
We entered into a new lease agreement for additional office space starting May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. We are required to maintain a minimum cash balance of $0.7 million as a security deposit on the leased space which is classified as restricted cash, current and restricted cash, non-current on the consolidated balance sheet as of December 31, 2021. Total future minimum lease payments under this noncancelable operating lease amount to $3.2 million. See Note 17 to our consolidated financial statements for the year ended December 31, 2021.

[0001558370-22-004491:mdna:163]
Cash Flows

[0001558370-22-004491:mdna:164]
The following table sets forth a summary of cash flows for the periods presented:

[0001558370-22-004491:mdna:165]
| ​ |  | Year Ended |
| ​ | ​ | December 31, |
| ​ | ​ | 2021 | ​ | 2020 |
| Net cash used in operating activities | ​ | $ | (69,628) | ​ | $ | (23,254) |
| Net cash used in investing activities |  | ​ | (4,738) |  | ​ | (6,609) |
| Net cash provided by financing activities |  | ​ | 377,829 |  | ​ | 17,226 |
| Net increase (decrease) in cash, cash equivalents and restricted cash | ​ | $ | 303,463 | ​ | $ | (12,637) |

[0001558370-22-004491:mdna:166]
Operating Activities

[0001558370-22-004491:mdna:167]
During the year ended December 31, 2021, operating activities used $69.6 million resulting from a net loss of $10.9 million, $30.0 million of cash used by changes in operating assets and liabilities, and non-cash adjustments of $28.8 million. The non-cash adjustments consisted of a $46.2 million of change in the fair value of contingent earn-out liability, $6.4 million of change in the fair value of contingently issuable common stock liability and $12.6 million of change in the fair value of public warrant liability, partially offset by $12.7 million on loss of extinguishment of debt, $5.2 million in noncash interest expense, $8.5 million in stock-based compensation expense, $2.9 million in depreciation and amortization expense, $2.1 million on write-off of inventory, $1.9 million from loss from impairment of property and equipment, $1.7 million of change in the fair value of derivative liability, $0.9 million of change in fair value of common stock warrant liability, and $0.6 million on loss of disposal of property and equipment. The changes in operating assets and liabilities consisted primarily of cash used by an increase of $17.5 million in inventory, $10.1 million in prepaid expenses and other current assets, an increase of $5.1 million in accounts receivable, an increase of $4.9 million in contract assets, and an increase of $3.1 million in commission assets, partially offset by an increase in deferred revenue of $5.0 million, an increase of $5.2 million in accrued expenses and other current liabilities, and an increase of $0.6 million in deferred rent.

[0001558370-22-004491:mdna:168]
The changes in commission assets and deferred revenue were primarily due to a continued shift towards a subscription-based model. The increase in accounts receivable is primarily due to higher sales driven by an increase in customers and the timing of billings to customers. The increase in accrued expenses and other current liabilities is primarily due to an increase in sales and marketing and general and administrative expenses due to the growth in our business and operating as a public company, the timing of vendor invoicing and payments, and the increase in sales tax contingency liability as we may owe additional sales and use taxes in various jurisdictions. The increase in prepaid expenses and other current assets is primarily due to an increase in prepaid insurance related to an increase in director and officer insurance premiums as a result of becoming a public company and an increase in prepaid deposits related to orders placed for Express units. The increase in inventory is primarily due to an increase in the production of Express units to meet customer demand. The increase in contract assets is primarily due to an increase in purchase subscriptions.

[0001558370-22-004491:mdna:169]
During the year ended December 31, 2020, cash used from operating activities was $23.3 million, primarily resulting from a net loss of $27.4 million, partially offset by $2.3 million of cash provided by changes in operating assets and liabilities and non-cash adjustments of $1.8 million. The non-cash adjustments consisted primarily of $1.1 million of depreciation and $0.7 million in stock-based compensation. The changes in operating assets and liabilities consisted primarily of cash used by increases of $0.5 million in accounts receivable, $1.8 million in commission assets, $1.5 million in inventory and $0.4 million in prepaid expenses and other current assets, which were partially offset by increases of $2.3 million in deferred revenue, $2.3 million in accrued expenses and other current liabilities and $1.9 million in accounts payable.

[0001558370-22-004491:mdna:170]
The changes in commission assets and deferred revenue were primarily due to a shift towards a subscription-based model. The increase in accrued expenses and other current liabilities and accounts payable is primarily due to an increase in sales and marketing and general and administrative expenses due to the growth in our business and the anticipation of the Merger, as well as the timing of vendor invoicing and payments. The increase in prepaid expenses and other current assets is primarily due to the increase in prepaid subscriptions due to the increase in purchased subscriptions.

[0001558370-22-004491:mdna:171]
The increase in accounts receivable is primarily due to higher sales and the timing of payments from customers. The increase in inventory is primarily due to Express units now being held in inventory.

[0001558370-22-004491:mdna:172]
Investing Activities

[0001558370-22-004491:mdna:173]
During the year ended December 31, 2021, cash used in investing activities was $4.7 million, primarily consisting of $3.7 million for the purchases of property and equipment and $1.0 million for the development of internal-use software.

[0001558370-22-004491:mdna:174]
During the year ended December 31, 2020, cash used in investing activities was $6.6 million, primarily consisting of the purchases of property and equipment.

[0001558370-22-004491:mdna:175]
Financing Activities

[0001558370-22-004491:mdna:176]
During the year ended December 31, 2021, cash provided by financing activities was $377.8 million, primarily consisting of $300.0 million from the issuance of common stock in connection with the PIPE investment, $84.9 million of proceeds, net of redemptions, from the closing of the Merger, $31.9 million from the issuance of long-term debt, net of issuance costs, and $0.9 million from the exercise of stock options, partially offset by $34.1 million in net cash outflows from the payment of offering costs in connection with the Merger, $5.4 million for the repayment of principal on long term debt and $0.4 million for the repayment of financing obligations.

[0001558370-22-004491:mdna:177]
During the year ended December 31, 2020, cash provided by financing activities was $17.2 million primarily consisting of $25.5 million from the issuance of long-term debt, net of issuance costs, $3.0 million from the issuance of Series B-1 convertible preferred stock, net of issuance costs, and $0.4 million from the exercise of stock options, partially offset by $11.5 million in net cash outflows for the repayment of long-term debt.

[0001558370-22-004491:mdna:178]
Recent Accounting Pronouncements

[0001558370-22-004491:mdna:179]
A description of recently issued accounting pronouncements that may potentially impact our financial position, results of operations or cash flows is disclosed in Note 2 to our consolidated financial statements included elsewhere in this Annual Report on Form 10-K.

[0001558370-22-004491:mdna:180]
Critical Accounting Policies and Estimates

[0001558370-22-004491:mdna:181]
Our consolidated financial statements are prepared in accordance with generally accepted accounting principles in the United States. The preparation of our consolidated financial statements and related disclosures requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, costs and expenses, and the disclosure of contingent assets and liabilities in our consolidated financial statements. We base our estimates on historical experience, known trends and events and various other factors that we believe are reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. We evaluate our estimates and assumptions on an ongoing basis. Our actual results may differ from these estimates under different assumptions or conditions.

[0001558370-22-004491:mdna:182]
While our significant accounting policies are described in more detail in Note 2 to our consolidated financial statements, we believe that the following accounting policies are those most critical to the judgments and estimates used in the preparation of our consolidated financial statements.

[0001558370-22-004491:mdna:183]
Revenue Recognition

[0001558370-22-004491:mdna:184]
We derive revenue from (1) subscription arrangements accounted for as operating leases and (2) from the sale of products, inclusive of services and maintenance, and (3) professional services. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001558370-22-004491:mdna:185]
Product Revenue

[0001558370-22-004491:mdna:186]
We derive revenue from the sale of our Express and Edge equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each customer contract. Products are predominately sold with distinct services, which are described in the services section below.

[0001558370-22-004491:mdna:187]
Subscription Revenue

[0001558370-22-004491:mdna:188]
In addition to selling products directly to customers, we also lease Express and Edge equipment. These arrangements convey the right to use the equipment for a period of time (generally 48 months) in exchange for consideration and therefore are accounted for under ASC 840 due to the scope exception of ASC 606-10-15-2. Lease terms are typically four years and customers pay quarterly or annual fixed payments for the lease and maintenance elements over the contractual lease term.

[0001558370-22-004491:mdna:189]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (1) distinct services, such as installation, training, SaaS, and maintenance, and (2) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:mdna:190]
As our leases with customers are generally classified as operating leases, lease revenue is recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001558370-22-004491:mdna:191]
Services Revenue

[0001558370-22-004491:mdna:192]
We provide installation, training, SaaS, and maintenance services for our products. Revenue for installation and training are recognized upon transfer of control of these services, which are normally rendered over a short duration. SaaS include data-driven security information and analytics insights. Maintenance consists of technical support, bug fixes, and when-and-if-available threat updates. Maintenance revenue is recognized ratably over the period of the arrangement. We sell separately priced extended or nonstandard warranty services and preventative maintenance plans, which are recognized ratably over the associated service period.

[0001558370-22-004491:mdna:193]
Revenue from Channel Partners

[0001558370-22-004491:mdna:194]
A portion of our revenue is generated by sales in conjunction with our channel partners. When we transact with a channel partner, our contractual arrangement is with the channel partner and not with the end-use customer. Whether we transact with a channel partner and receive the order from a channel partner or directly from an end-use customer, our revenue recognition policy and resulting pattern of revenue recognition is the same.

[0001558370-22-004491:mdna:195]
Standalone Selling Price

[0001558370-22-004491:mdna:196]
We allocate the transaction price to each distinct performance obligation based on the standalone selling price (“SSP”) of each product or service. Our contracts may include multiple performance obligations when customers purchase a combination of products and services. When our customer arrangements have multiple performance obligations that contain a lease for Express or Edge equipment for the customer’s use at our site as well as distinct services that are delivered simultaneously, we allocate the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, we allocate the contract’s transaction price to each performance obligation on a relative SSP basis.

[0001558370-22-004491:mdna:197]
Stock-Based Compensation

[0001558370-22-004491:mdna:198]
We measure stock-based option awards granted to employees, consultants and directors based on their fair value on the date of grant using the Black-Scholes option-pricing model. Compensation expense for those awards is recognized, net of estimated forfeitures, over the requisite service period, which is generally the vesting period of the respective award.

[0001558370-22-004491:mdna:199]
Prior to the closing of the Merger, the fair value of each stock option grant was estimated on the date of grant using the Black-Scholes option-pricing model, which uses the following inputs: (1) the fair value per share of the common stock issuable upon exercise of the option, (2) the expected term of the option, (3) expected volatility of the price of the common stock, (4) the risk-free interest rate, and (5) the expected dividend yield.

[0001558370-22-004491:mdna:200]
After the closing of the Merger, our board of directors determined the fair value of each share of common stock underlying stock-based awards based on the closing price of our common stock as reported by Nasdaq on the date of grant.

[0001558370-22-004491:mdna:201]
The Black-Scholes option-pricing model uses as inputs the fair value of our common shares and assumptions we make for the volatility of our common shares, the expected term of our stock options, the risk-free interest rate for a period that approximates the expected term of our stock options and our expected dividend yield. The Company has historically been a private company and continues to lack sufficient company-specific historical and implied volatility information. Therefore, we estimate our expected share volatility based on the historical volatility of a publicly traded set of peer companies and expect to continue to do so until such time as we have adequate historical data regarding the volatility of our own traded share price.

[0001558370-22-004491:mdna:202]
Valuation of Contingent Earn-out Liability

[0001558370-22-004491:mdna:203]
The estimated fair value of the contingent earn-out shares are determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, drift rate, and a percentage of change in control and expected term. For potential common stock issuances related to a stock price milestones, the fair value was determined based on our expectations of achieving such a milestone and the simulated estimated stock price on the expected date of achievement.

[0001558370-22-004491:mdna:204]
We believe our assumptions are reasonable based on available information, our experience, knowledge, and judgments. These estimates can be affected by factors that are difficult to predict including future (1) EVLV closing price per share on the Nasdaq, (2) estimated stock price volatility over the earn-out period, and (3) risk free rates. Changes in assumptions and estimates used in our analysis, or future results that vary from assumptions used in the analysis, could affect the fair value of the contingent earn-out and could result in material changes in future periods.

[0001558370-22-004491:mdna:205]
Valuation of Contingently Issuable Common Stock Liability

[0001558370-22-004491:mdna:206]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the vesting period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, and risk-free rate.

[0001558370-22-004491:mdna:207]
We believe our assumptions are reasonable based on available information, our experience, knowledge, and judgments. These estimates can be affected by factors that are difficult to predict including future (1) EVLV closing price per share on the Nasdaq, (2) estimated stock price volatility over the contingently issuable common shares period, and (3) risk free rates. Changes in assumptions and estimates used in our analysis, or future results that vary from assumptions used in the analysis, could affect the fair value of the contingently issuable common stock and could result in material changes in future periods.

[0001558370-22-004491:mdna:208]
Valuation of Common Stock Warrant Liability and Public Warrant Liability

[0001558370-22-004491:mdna:209]
We classify certain warrants to purchase shares of our common stock (the “Common Stock Warrant”) as liabilities on our consolidated balance sheets as these warrants are free-standing financial instruments that may require us to adjust the exercise price and number of shares that is not consistent with a fixed-for-fixed option pricing model. The warrant liability associated with each of these warrants was initially recorded at fair value on the issuance date of each warrant and is subsequently remeasured to fair value at each balance sheet date. Changes in fair value of the warrants are recognized as a component of other income (expense), net in our statements of operations and comprehensive loss. We will continue to adjust the liability for changes in fair value until the warrants are exercised, expire or qualify for equity classification.

[0001558370-22-004491:mdna:210]
For the common stock warrant, we utilized the Black-Scholes option-pricing model, which incorporates assumptions and estimates to value the warrant liability. Key estimates and assumptions impacting the fair value measurement include (1) the fair value per share of the underlying shares of applicable series of stock issuable upon exercise of the Warrants, (2) the remaining contractual term of the Warrants, (3) the risk-free interest rate, (4) the expected dividend yield and (5) the expected volatility of the price of the underlying applicable common stock. Prior to the closing of the Merger, we assessed these assumptions and estimates on a quarterly basis as additional information impacting the assumptions is obtained. We estimate the fair value per share of the underlying stock based in part on the results of third-party valuations and additional factors deemed relevant. Upon the closing of the Merger, the common stock warrant net settled and converted to common stock. As of December 31, 2021, we no longer have common stock warrants classified as liabilities.

[0001558370-22-004491:mdna:211]
In connection with the closing of the Merger, we assumed the Public Warrants to purchase shares of common stock, which were classified as a liability, as the Public Warrants do not meet the criteria to be indexed to our common stock. As of December 31, 2021, the Public Warrants remain outstanding. Accordingly, we recorded the warrants at fair value upon the closing of the Merger with a corresponding adjustment to additional paid-in capital. After the initial measurement, the fair value of the Public Warrants is subsequently remeasured quarterly based on the listed market price on the Nasdaq of such Public Warrants.

[0001558370-22-004491:mdna:212]
Valuation of Inventory

[0001558370-22-004491:mdna:213]
Inventory is valued at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. We regularly review inventory quantities on-hand for excess and obsolete inventory and, when circumstances indicate, record charges to write down inventories to their estimated net realizable value, after evaluating historical sales, future demand, our estimates of forecasted net revenue, market conditions and expected product life cycles. A significant change in the timing or level of demand for our products as compared to forecasted amounts may result in recording additional write-offs. Such charges are classified as cost of product revenue in the statements of operations and comprehensive loss. Any write-down of inventory to net realizable value creates a new cost basis. We recorded $1.6 million in write-offs of Edge units during the year ended December 31, 2021 as the Company is no longer selling this product. We did not record any write-offs on inventory during the year ended December 31, 2020.

[0001558370-22-004491:mdna:214]
Capitalized Internal-Use Software

[0001558370-22-004491:mdna:215]
Software development costs consist of certain consulting costs and compensation expenses for employees who devote time to the development projects of our internal-use software, as well as certain upgrades and enhancements that are expected to result in enhanced functionality. We amortize these development costs over the estimated useful life of four years. We determined that a four year life is appropriate for our internal-use software based on our best estimate of the useful life of the internal-use software after considering factors such as continuous developments in the technology, obsolescence, and anticipated life of the service offering before significant upgrades. Management evaluates the useful lives of these assets on a quarterly basis and test for impairment whenever events or changes in circumstances occur that could impact the recoverability of these assets.

[0001558370-22-004491:mdna:216]
We determine the amount of internal software costs to be capitalized based on the amount of time spent by our developments on projects in the application stage of development. There is judgment in estimating the time allocated to a

[0001558370-22-004491:mdna:217]
particular project in the application stage. A significant change in the time spent on each project could have a material impact on the amount capitalized and related amortization expense in subsequent periods.

[0001558370-22-004491:mdna:218]
Emerging Growth Company Status

[0001558370-22-004491:mdna:219]
The Jumpstart Our Business Startups Act of 2012, or the JOBS Act, permits an “emerging growth company” such as us to take advantage of an extended transition period to comply with new or revised accounting standards applicable to public companies until those standards would otherwise apply to private companies. We meet the definition of an “emerging growth company” and have elected to use this extended transition period for complying with new or revised accounting standards that have different effective dates for public and private companies until the earlier of the date we (1) are no longer an emerging growth company or (2) affirmatively and irrevocably opt out of the extended transition period provided in the JOBS Act. As a result of this election, we will not be subject to the same new or revised accounting standards as other public companies that are not emerging growth companies and our consolidated financial statements may not be comparable to other public companies that comply with new or revised accounting pronouncements as of public company effective dates. We may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for private companies.

[0001558370-22-004491:mdna:220]
We will remain an emerging growth company until the earlier of (1) the last day of the fiscal year (a) following the fifth anniversary of the completion of the initial public offering, (b) in which we have total annual gross revenue of at least $1.07 billion or (c) in which we are deemed to be a large accelerated filer, and (2) the date on which we have issued more than $1.0 billion in non-convertible debt during the prior three-year period.

[0001558370-22-004491:mdna:221]
Further, even after we no longer qualify as an emerging growth company, we may still qualify as a “smaller reporting company,” which would allow us to take advantage of many of the same exemptions from disclosure requirements, including reduced disclosure obligations regarding executive compensation in our periodic reports and proxy statements. We cannot predict if investors will find our common shares less attractive because we may rely on these exemptions. If some investors find our common shares less attractive as a result, there may be a less active trading market for our common shares and our share price may be more volatile.
