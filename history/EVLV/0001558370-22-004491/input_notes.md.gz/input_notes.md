# EVLV notes — 0001558370-22-004491


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001558370-22-004491:notes:1]
1. Nature of the Business and Basis of Presentation

[0001558370-22-004491:notes:2]
As used in this Annual Report on Form 10-K, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of the Merger and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001558370-22-004491:notes:3]
Legacy Evolv was incorporated under the laws of the State of Delaware on July 8, 2013. The Company is the global leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks in a cost-effective manner while improving the visitor experience. The Company is headquartered in Waltham, Massachusetts.

[0001558370-22-004491:notes:4]
Merger with NewHold Investment Corp.

[0001558370-22-004491:notes:5]
On July 16, 2021 (the “Closing Date”), NHIC, the legal predecessor company, consummated the previously announced Merger with Legacy Evolv, pursuant to the Agreement and Plan of Merger dated as of March 5, 2021, and amended by the First Amendment to Agreement and Plan of Merger (the “Merger Agreement”), dated as of June 5, 2021. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. and the officers of NHIC, the legal predecessor company, resigned. The officers of Legacy Evolv became the officers of the Company, and the Company listed its shares of common stock, par value $0.0001 per share, on Nasdaq under the symbol “EVLV” (see Note 3).

[0001558370-22-004491:notes:6]
Subscription Agreement

[0001558370-22-004491:notes:7]
Prior to the completion of the Merger, the Company entered into subscription agreements (collectively, the “PIPE Investment”) with certain parties subscribing for shares of the Company’s common stock (the “Subscribers”) pursuant to which the Subscribers agreed to purchase. Pursuant to the PIPE Investment, the Company issued 30,000,000 shares of common stock for a purchase price of $10.00 per share with gross proceeds of $300.0 million.

[0001558370-22-004491:notes:8]
Risks and uncertainties

[0001558370-22-004491:notes:9]
The Company is subject to risks and uncertainties common to early-stage companies in the human security industry including, but not limited to, the successful development, commercialization, marketing and sale of existing and new products, fluctuations in operating results and financial risks, protection of proprietary knowledge and patent risks, dependence on key personnel, competition, technological risks, cybersecurity risks, customer demand, and management of growth. Potential risks and uncertainties also include, without limitation, uncertainties regarding the duration and magnitude of the impact of the COVID-19 pandemic, including variants, on the Company’s business and the economy in general.

[0001558370-22-004491:notes:10]
In March 2020, the World Health Organization declared the global novel coronavirus disease 2019 (“COVID-19”) outbreak a pandemic. The impact of this pandemic has been and will likely continue to be extensive in many aspects of society, which has resulted in and will likely continue to result in significant disruptions to the global economy, as well as businesses and capital markets around the world. The Company cannot at this time predict the ultimate extent, duration, or full impact that the COVID-19 pandemic will have on its future financial condition and operations. The impact of the COVID-19 pandemic on the Company’s financial performance will depend on future developments, including the duration and spread of the pandemic, including variants, and related governmental advisories and restrictions, the progression and effectiveness of vaccination roll-outs, vaccine hesitancy, and the actions

[0001558370-22-004491:notes:11]
taken to contain or treat COVID-19, as well as the economic impact on local, regional, national and international customers and markets. The situation surrounding COVID-19 remains fluid and the potential for a material impact on the Company increases the longer the virus impacts the level of economic activity in the United States and globally. Given the ongoing evolution of COVID-19 and the global responses to curb its spread, the Company is not able to estimate the effects of COVID-19 on our results of operations, financial condition, or liquidity for the year ending December 31, 2021. If the financial markets and/or the overall economy are impacted for an extended period, the Company’s results may be materially adversely affected.

[0001558370-22-004491:notes:12]
Future impacts to the Company’s business as a result of COVID-19 could include disruptions to the Company’s revenue caused by closures of customer operations, manufacturing operations and supply chain caused by facility closures, reductions in operating hours, staggered shifts and other social distancing efforts, labor shortages, decreased productivity and unavailability of materials or components, limitations on our employees’ and customers’ ability to travel, and delays in shipments to and from affected countries and within the United States. While the Company maintains an inventory of finished products and raw materials used in its products, a prolonged pandemic could lead to shortages in the raw materials necessary to manufacture its products.

[0001558370-22-004491:notes:13]
Basis of presentation

[0001558370-22-004491:notes:14]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company, its holding company, Evolv Technologies, Inc., its wholly owned subsidiary in the United Kingdom, Evolv Technologies UK Ltd. and its wholly owned subsidiary, Give Evolv LLC. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001558370-22-004491:notes:15]
2. Summary of Significant Accounting Policies

[0001558370-22-004491:notes:16]
Use of Estimates

[0001558370-22-004491:notes:17]
The preparation of the Company’s consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the reporting periods. Significant estimates and assumptions reflected in these consolidated financial statements include but are not limited to calculating the standalone selling price for revenue recognition, the valuation of inventory, the accrual of sales tax contingencies, the expensing and capitalization of costs associated with internal-use software, stock-based awards, the valuation of the contingent earn-out liability, the valuation of the contingently issuable common stock, the valuation of common stock for the periods prior to the Company listing its shares on Nasdaq, the valuation of the derivative liability, the valuation of the common stock warrant liability and the valuation of the preferred stock warrant liability. The Company bases its estimates on historical experience, known trends and other market-specific or other relevant factors that it believes to be reasonable under the circumstances. On an ongoing basis, management evaluates its estimates when there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results could differ from those estimates.

[0001558370-22-004491:notes:18]
Due to the COVID-19 pandemic, there has been uncertainty and disruption in the global economy and financial markets. The full extent to which the COVID-19 pandemic will directly or indirectly impact the Company’s business, results of operations and financial condition, including revenues and expenses, will depend on future developments that are highly uncertain, including as a result of new information that may emerge concerning COVID-19 and the actions taken to contain it or treat COVID-19. Management has made estimates of the impact of COVID-19 within the Company’s consolidated financial statements and there may be changes to those estimates in future periods. These

[0001558370-22-004491:notes:19]
estimates may change, as new events occur, and additional information is obtained. On an ongoing basis, management evaluates its estimates as there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results may differ from those estimates or assumptions.

[0001558370-22-004491:notes:20]
Risk of Concentrations of Credit, Significant Customers and Significant Suppliers

[0001558370-22-004491:notes:21]
Financial instruments that potentially expose the Company to concentrations of credit risk consist primarily of cash equivalents, restricted cash, and accounts receivable, net. The Company maintains deposits in accredited financial institutions in excess of federally insured limits. The Company maintains its cash, cash equivalents and restricted cash with financial institutions that management believes to be of high credit quality. The Company has not experienced any losses on such accounts and does not believe it is exposed to any unusual credit risk beyond the normal credit risk associated with commercial banking relationships.

[0001558370-22-004491:notes:22]
Significant customers are those which represent more than 10% of the Company’s total revenue or accounts receivable, net balance at each respective balance sheet date. The following table presents customers that represent 10% or more of the Company’s total revenue:

[0001558370-22-004491:notes:23]
| ​ | ​ | Year Ended December 31, | ​ |
| ​ | ​ | 2021 | ​ | 2020 |  |
| Customer A | ​ | ​ | % | 10.7 | % |
| ​ | ​ | — | % | 10.7 | % |

[0001558370-22-004491:notes:24]
Customer A revenue is from subscriptions.

[0001558370-22-004491:notes:25]
The following table presents customers that represent 10% or more of the Company’s accounts receivable, net:

[0001558370-22-004491:notes:26]
| ​ |  | December 31, | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 |  | ​ |
| Customer C |  | ​ | ​ | 23.8 | % | ​ |
| Customer D |  | ​ | ​ | 23.4 | % | ​ |
| Customer E | ​ | 18.2 | % | ​ | ​ | ​ |
| Customer F |  | 11.8 | % | ​ | ​ | ​ |
| ​ |  | 30.0 | % | 47.2 | % | ​ |

[0001558370-22-004491:notes:27]
The Company relies on third parties for the supply and manufacture of its products as well as third-party logistics providers. In instances where these parties fail to perform their obligations, the Company may be unable to find alternative suppliers to satisfactorily deliver its products to its customers on time, if at all, which could have a material adverse effect on the Company’s operating results, financial condition and cash flows and damage its customer relationships.

[0001558370-22-004491:notes:28]
Debt Issuance Costs

[0001558370-22-004491:notes:29]
The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated debt on the consolidated balance sheet and amortized as interest expense on the consolidated statement of operations and comprehensive loss using the effective interest method. As of December 31, 2021 and 2020, debt issuance costs totaled $0.1 million and $0.1 million, respectively, and were recorded as a reduction in the carrying amount of long-term debt in the consolidated balance sheets. During the years ended December 31, 2021 and 2020, the Company recorded $0.1 million and less than $0.1 million, respectively, in amortization of the debt issuance costs recorded within interest expense in the consolidated statement of operations and comprehensive loss.

[0001558370-22-004491:notes:30]
Cash, Cash Equivalents, and Restricted Cash

[0001558370-22-004491:notes:31]
Cash, cash equivalents, and restricted cash as reported on the consolidated statement of cash flows consists of the following (in thousands):

[0001558370-22-004491:notes:32]
| ​ |  | December 31, |
| ​ | ​ | 2021 | ​ | 2020 |
| Cash and cash equivalents |  | $ | 307,492 | ​ | $ | 4,704 |
| Restricted cash |  | ​ | 675 | ​ | ​ | — |
| Total cash, cash equivalents, and restricted cash |  | $ | 308,167 | ​ | $ | 4,704 |

[0001558370-22-004491:notes:33]
The Company considers all short-term, highly liquid investments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents. Restricted cash consists of a letter of credit on the Company’s office lease in Waltham, Massachusetts, with $0.4 million included in the current portion of restricted cash which will be returned during the first half of 2022, and $0.3 million included in restricted cash, noncurrent in the consolidated balance sheet as of December 31, 2021. As the letter of credit is reduced restricted cash is reclassified to cash and cash equivalents.

[0001558370-22-004491:notes:34]
Inventory

[0001558370-22-004491:notes:35]
Inventory is stated at the lower of cost or net realizable value with cost being determined using the first-in, first-out method. The Company regularly reviews inventory quantities on-hand for excess and obsolete inventory and, when circumstances indicate, records charges to write down inventories to their estimated net realizable value, after evaluating historical sales, future demand, market conditions and expected product life cycles. Such charges are classified as product cost of revenues in the consolidated statement of operations and comprehensive loss. Any write-down of inventory to net realizable value creates a new cost basis.  The Company recorded $1.6 million in write-offs of Edge units during the year ended December 31, 2021 as the Company is no longer selling this product. The Company did not record any write-offs on inventory during the year ended December 31, 2020.

[0001558370-22-004491:notes:36]
Property and Equipment

[0001558370-22-004491:notes:37]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization expense are recognized using the straight-line method over the estimated useful life of each asset, as follows:

[0001558370-22-004491:notes:38]
| ​ |  | Estimated Useful Life |
| Computers and telecommunications equipment |  | 3 years |
| Lab equipment |  | 5 years |
| Purchased software |  | 4 years |
| Furniture and fixtures |  | 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |
| Leased equipment |  | 4-7 years |
| Internal-use software |  | 4 years |

[0001558370-22-004491:notes:39]
Estimated useful lives are periodically assessed to determine if changes are appropriate. Leasehold improvements are depreciated using the straight-line method over the lesser of the lease term or its estimated economic useful life. Lease terms are used based upon the initial lease agreement and do not consider potential renewals or extensions until such time that the renewals or extensions are contracted. Maintenance and repairs are charged to expense as incurred. When assets are retired or otherwise disposed of, the cost of these assets and related accumulated depreciation are eliminated from the consolidated balance sheet and any resulting gains or losses are included in the

[0001558370-22-004491:notes:40]
consolidated statements of operations and comprehensive loss in the period of disposal. Costs for capital assets not yet placed into service are capitalized as construction-in-progress and depreciated once placed into service.

[0001558370-22-004491:notes:41]
The Company’s leases for leased equipment generally are 48 months. The Company’s subscription contracts are classified as operating leases because title does not transfer and they do not meet any of the other criteria per Accounting Standards Codification 840 – Leases (“ASC 840”). To date, the Company has not had any subscription arrangements come up for renewal and will reassess the classification of any such leases upon renewal.

[0001558370-22-004491:notes:42]
The Company evaluates leased equipment for obsolescence and impairment whenever circumstances indicate that the carrying value of such equipment is not recoverable by considering any (1) reduced demand in the markets in which the Company operate, (2) technological obsolescence due to developments of new products and improvements, or (3) changes in economic or other events and conditions that impact the market price for the Company’s products. Based on the Company’s evaluations, an impairment loss on property and equipment of $1.9 million was recorded during the year ended December 31, 2021. This was related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning its domestic customers from the Legacy Edge units to its most current Evolv Express units, which resulted in an impairment of the remaining economic value of such assets.

[0001558370-22-004491:notes:43]
The Company capitalizes certain costs, including consulting costs and compensation expenses for employees who devote time to the development projects, related to the development of internal-use software after the preliminary project stage is complete and until the software is ready for its intended use. The Company records software development costs in property and equipment, net. Costs incurred in the preliminary stages of development activities and post implementation are expensed in the period incurred and are recorded in research and development expense in the consolidated statements of operations and comprehensive loss. The Company also capitalizes costs related to specific upgrades and enhancements when it is probable the expenditures will result in additional functionality.

[0001558370-22-004491:notes:44]
Once the project is available for general release, capitalization ceases, and the asset can begin amortization. Capitalized costs associated with internal-use software are amortized on a straight-line basis over their estimated useful life, which is generally four years, and are recorded in cost of product revenue and cost of subscription revenue in the consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:notes:45]
Contingent Earn-out

[0001558370-22-004491:notes:46]
In connection with the Merger and pursuant to the Merger Agreement, certain of the Legacy Evolv’s shareholders and Legacy Evolv Service Providers are entitled to receive additional shares of the Company’s common stock (the “Earn-Out Shares”) upon the Company achieving certain milestones:

[0001558370-22-004491:notes:47]
|  | ● | Triggering Event I – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s common stock is greater than $12.50 per share for any 20 trading days within any 30 trading day period. |

[0001558370-22-004491:notes:48]
|  | ● | Triggering Event II – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s common stock is greater than $15.00 per share for any 20 trading days within any 30 trading day period. |

[0001558370-22-004491:notes:49]
|  | ● | Triggering Event III – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s common stock is greater than $17.50 per share for any 20 trading days within any 30 trading day period. |

[0001558370-22-004491:notes:50]
In accordance with ASC 815 – Derivatives and Hedging, the earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a change in fair value of contingent earn-out liability in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Triggering Events have been achieved and the Earn-Out Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital

[0001558370-22-004491:notes:51]
and common stock at par value of $0.0001 per share. Of the total 15,000,000 earn-out shares, 12,150,413 earn-out shares can be earned by the Legacy Evolv shareholders.

[0001558370-22-004491:notes:52]
The estimated fair value of the contingent earn-out shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, drift rate, percentage of change in control and expected term.

[0001558370-22-004491:notes:53]
The contingent earn-out liability is categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingent earn-out payments involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001558370-22-004491:notes:54]
The Earn-Out Shares issued to employees, officers, directors, and non-employees are based on achievement of certain target share price contingencies and for the employees and officers, subject to continued employment, (the “Earn-Out Service Providers”) represents share-based compensation and is included in additional paid-in capital on the Company’s balance sheet. Corresponding stock-based compensation expense is recorded in the consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. Of the total 15,000,000 earn-out shares, 2,849,587 earn-out shares can be earned by the Legacy Evolv Service Providers and subject to share-based compensation. As a condition to being issued Earn-Out Shares to Earn-Out Service Providers the service provider must be still providing services to the Company on the date of the issuance of the shares. If the relationship with the service provider is terminated prior to the issuance of the Earn-Out Shares the shares will be redistributed to the remaining participants in the Earn-Out Shares.

[0001558370-22-004491:notes:55]
Contingently Issuable Common Stock

[0001558370-22-004491:notes:56]
Prior to the Merger, NewHold Industrial Technology Holdings, LLC, the sponsor of the NHIC special purpose acquisition company owned 4,312,500 shares of NHIC Class B common stock (the “Founder Shares). Upon the closing of the merger, NHIC Class A and Class B common stock became the Company’s common stock. The Founder Shares outstanding were subject to certain share-performance-based vesting provisions as follows:

[0001558370-22-004491:notes:57]
|  | ● | Vesting Provision I – 1,897,500 shares of the Company’s common stock shall vest and no longer be subject to forfeiture as of the Merger; |

[0001558370-22-004491:notes:58]
|  | ● | Vesting Provision II – if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $12.50 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30 trading day period, then 948,750 shares of the Company’s common stock shall vest and no longer be subject to forfeiture and |

[0001558370-22-004491:notes:59]
|  | ● | Vesting Provision III – if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $15.00 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30-trading day period, then 948,750 shares of the Company’s common stock) shall vest and no longer be subject to forfeiture. |

[0001558370-22-004491:notes:60]
The remaining 517,500 Founder Shares were contributed to Give Evolv LLC.

[0001558370-22-004491:notes:61]
If Vesting Provision II and/or Vesting Provision III are not satisfied, the corresponding number of shares specified shall be forfeited and no longer issued and outstanding. If there is a Change of Control event prior to Vesting

[0001558370-22-004491:notes:62]
Provision II and/or Vesting Provision III are satisfied, the Founder shares are no longer subject to forfeiture and shall vest immediately upon the occurrence of a Change of Control event.

[0001558370-22-004491:notes:63]
In accordance with ASC 815 – Derivatives and Hedging, the contingently issuable common stock is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as change in fair value of contingently issuable common stock liability in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Vesting Provisions have been achieved and the contingently issuable common shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001558370-22-004491:notes:64]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, and risk-free rate.

[0001558370-22-004491:notes:65]
The contingently issuable common shares are categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingently issuable shares involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001558370-22-004491:notes:66]
Impairment of Long-Lived Assets

[0001558370-22-004491:notes:67]
Long-lived assets consist of property and equipment. Long-lived assets to be held and used are tested for recoverability whenever events or changes in business circumstances indicate that the carrying amount of the assets may

[0001558370-22-004491:notes:68]
not be fully recoverable. Factors that the Company considers in deciding when to perform an impairment review include significant underperformance of the business in relation to expectations, significant negative industry or economic trends and significant changes or planned changes in the use of the assets. If an impairment review is performed to evaluate a long-lived asset group for recoverability, the Company compares forecasts of undiscounted cash flows expected to result from the use and eventual disposition of the long-lived asset group to its carrying value. An impairment loss would be recognized in loss from operations and comprehensive loss when estimated undiscounted future cash flows expected to result from the use of an asset group are less than its carrying amount. The impairment loss is based on the excess of the carrying value of the impaired asset group over its fair value, determined based on discounted cash flows. The Company recorded a $1.9 million impairment loss on long-lived assets during the year ended December 31, 2021. This was related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning its domestic customers from the Legacy Edge units to its most current Evolv Express units, which resulted in an impairment of the remaining economic value of such assets. The Company did not record any impairment losses on long-lived assets during the year ended December 31, 2020.

[0001558370-22-004491:notes:69]
Fair Value Measurements of Financial Instruments

[0001558370-22-004491:notes:70]
Certain assets and liabilities of the Company are carried at fair value under GAAP. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. Valuation techniques used to measure fair value must maximize the use of observable inputs and minimize the use of unobservable inputs. Financial assets and liabilities carried at fair value are to be classified and disclosed in one of the following three levels of the fair value hierarchy, of which the first two are considered observable and the last is considered unobservable:

[0001558370-22-004491:notes:71]
|  | ● | Level 1 — Quoted prices in active markets for identical assets or liabilities. |

[0001558370-22-004491:notes:72]
|  | ● | Level 2 — Observable inputs (other than Level 1 quoted prices), such as quoted prices in active markets for similar assets or liabilities, quoted prices in markets that are not active for identical or similar assets or liabilities, or other inputs that are observable or can be corroborated by observable market data. |

[0001558370-22-004491:notes:73]
|  | ● | Level 3 — Unobservable inputs that are supported by little or no market activity that are significant to determining the fair value of the assets or liabilities, including pricing models, discounted cash flow methodologies and similar techniques. |

[0001558370-22-004491:notes:74]
The Company’s cash equivalents, restricted cash, derivative liability, contingent earn-out liability, contingently issuable common stock liability and its common stock warrant liability are carried at fair value, determined according to the fair value hierarchy described above (see Note 4). The carrying values of the Company’s accounts receivable, net, accounts payable and accrued expenses approximate their fair values due to the short-term nature of these assets and liabilities. The carrying value of the Company’s long-term debt approximates its fair value (a Level 2 measurement) at each balance sheet date due to its variable interest rate, which approximates a market interest rate.

[0001558370-22-004491:notes:75]
Assets that are measured at fair value on a nonrecurring basis primarily relate to property and equipment. We do not periodically adjust carrying value to fair value for property and equipment. Rather, the carrying value of the asset is reduced to its fair value when we determine that impairment has occurred. During the year ended December 31, 2021, impairment of property and equipment was $1.9 million. There was no impairment recognized during the year ended December 31, 2020.

[0001558370-22-004491:notes:76]
Derivative Liability Related to Convertible Notes

[0001558370-22-004491:notes:77]
In August through September 2019 and in September through December 2020, the Company issued Convertible Notes to several investors (see Note 9) that provided a conversion option whereby upon the closing of a specified financing event the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 85% and 80%, respectively, of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative that was required to be bifurcated and accounted for separately from the notes. The derivative liability was initially recorded at fair value upon issuance of the notes and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the derivative liability are recognized in the consolidated statements of operations and comprehensive loss. In October 2019, the specified financing event was consummated, as such the Convertible Notes issued August through September 2019 were converted into shares of Series B-1 Preferred Stock (see Note 10), and the derivative liability was extinguished. The derivative liability related to the 2020 convertible note is outstanding as of December 31, 2020 and is included as a derivative liability in the consolidated balance sheets.

[0001558370-22-004491:notes:78]
In January and February 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes,” and together with the 2020 Convertible Notes, the “Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability and current portion of long-term debt on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method.

[0001558370-22-004491:notes:79]
In June 2021, the Company and the holders of the 2021 Convertible Notes agreed that, in connection with the Merger, such holders would receive an additional 1,000,000 shares of NHIC common stock as further consideration for the automatic conversion of such notes upon closing of the Merger. This modification of the 2021 Convertible Notes

[0001558370-22-004491:notes:80]
resulted in an extinguishment, and recognition of a derivative liability, which represents both the value of the 1,000,000 NHIC shares as of June 21, 2021 as well as a bifurcated embedded derivative for conversion into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors.

[0001558370-22-004491:notes:81]
Upon the closing of the Merger, the September through December 2020 Convertible Notes and the 2021 Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:notes:82]
Classification of Convertible Preferred Stock

[0001558370-22-004491:notes:83]
Prior to the closing of the Merger, the holders of Legacy Evolv Series A, Series A-1, Series B and Series B-1 convertible preferred stock had certain liquidation rights in the event of a deemed liquidation event that, in certain situations, is not solely within the control of the Company and would call for the redemption of the then outstanding Series A, Series A-1, Series B and Series B-1 convertible preferred stock (see Note 10). Therefore, the Legacy Evolv Series A, Series A-1, Series B and Series B-1 convertible preferred stock were classified outside of stockholders’ equity (deficit) on the consolidated balance sheets.

[0001558370-22-004491:notes:84]
In connection with the closing of the Merger, all shares of convertible Preferred Stock were converted into shares of the Company’s common stock. Accordingly, there was no convertible preferred stock outstanding as of December 31, 2021. As of December 31, 2020, the carrying value of the convertible Preferred Stock was $75.9 million (see Note 10).

[0001558370-22-004491:notes:85]
Common Stock Warrant Liability and Public Warrant Liability

[0001558370-22-004491:notes:86]
The Company classifies certain warrants for the purchase of shares of its common stock (see Note 11) as a liability on its consolidated balance sheets as these warrants are freestanding financial instruments that may require the Company to adjust the exercise price and number of shares that is not consistent with a fixed-for-fixed option pricing model. The warrant liability is initially recorded at fair value on the issuance date of each warrant and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the common stock warrant liability are recognized as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss. Changes in the fair value of the common stock warrant liability are recognized until the warrants are exercised, expire or qualify for equity classification.

[0001558370-22-004491:notes:87]
In connection with the closing of the Merger, the Company assumed warrants to purchase shares of common stock (the “Public Warrants”) and are classified as a liability pursuant to ASC 815 – Derivatives and Hedging as the equity derivative scope exception was not met. As of December 31, 2021, the Public Warrants are outstanding (see Note 11). All other warrants that were issued prior to the closing of the Merger were converted into shares of the Company’s common stock upon the closing of the Merger. Accordingly, the Company remeasured the common stock warrants to fair value upon the closing of Merger with the offset to additional paid-in capital (see Note 11).

[0001558370-22-004491:notes:88]
Equity Classified Preferred Stock Warrants

[0001558370-22-004491:notes:89]
The Company classifies warrants for the purchase of shares of its preferred stock (see Note 11) as temporary equity on its consolidated balance sheets. In connection with a customer development agreement, the Company issued preferred stock warrants to a customer to purchase shares of its Legacy Evolv Series A-1 Preferred Stock. Upon adoption of ASU No. 2018-07 and ASU No. 2019-08 on January 1, 2019, any liability classified warrants issued to non-employees for goods or services were reclassified to temporary equity.

[0001558370-22-004491:notes:90]
In connection with the closing of the Merger, all preferred stock warrants to purchase shares of common stock were converted into shares of the Company’s common stock. Accordingly, there were no preferred stock warrants outstanding as of December 31, 2021. The Company assessed the features of these warrants and determined that they qualify for classification as permanent equity.

[0001558370-22-004491:notes:91]
Equity Classified Common Stock Warrants

[0001558370-22-004491:notes:92]
The Company classifies certain warrants for the purchase of shares of its common stock (see Note 11) as additional paid in capital on its consolidated balance sheets as these warrants are considered to meet the derivative scope exception for freestanding equity contracts. For these warrants that are classified on the Company’s consolidated balance sheets as equity instruments, the Company uses the Black-Scholes model to measure the value of the warrants at issuance.

[0001558370-22-004491:notes:93]
In connection with the closing of the Merger, all vested equity classified common stock warrants to purchase shares of common stock were converted into shares of the Company’s common stock.

[0001558370-22-004491:notes:94]
Segment Information

[0001558370-22-004491:notes:95]
The Company determined that it has one operating segment after considering the Company’s organizational structure and the information regularly reviewed and evaluated by the Company’s chief operating decision maker (“CODM”) in deciding how to allocate resources and assess performance. The Company has determined that its CODM is collectively the President and Chief Executive Officer, Head of Corporate Development and Founder, Head of Advanced Technology and Founder, Chief Financial Officer and Chief Risk Officer, and General Counsel. The CODM reviews the financial information on a consolidated basis for purposes of evaluating financial performance and allocating resources. On the basis of these factors, the Company determined that it operates and manages its business as one operating segment, that develops, manufactures, markets and sells security screening products and specific services, and accordingly has one reportable segment for financial reporting purposes.

[0001558370-22-004491:notes:96]
Revenue Recognition

[0001558370-22-004491:notes:97]
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

[0001558370-22-004491:notes:98]
The Company derives revenue from (1) subscription arrangements accounted for as operating leases under ASC 840 and (2) from the sale of products, inclusive of SaaS and maintenance and (3) professional services. The Company’s arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001558370-22-004491:notes:99]
Product Revenue

[0001558370-22-004491:notes:100]
The Company derives revenue from the sale of its Express and Edge equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer. Transfer of control occurs when the Company has transferred title and risk of loss and has a present right to payment for the equipment, which follows the terms of each customer contract . Products are predominately sold with distinct services, which are described in the services section below.

[0001558370-22-004491:notes:101]
Subscription Revenue

[0001558370-22-004491:notes:102]
In addition to selling its products directly to customers, the Company also leases Express equipment. These arrangements convey the right to use the equipment for a period of time (generally 48 months) in exchange for consideration and therefore are accounted for under ASC 840 due to the scope exception of ASC 606-10-15-2. Revenue recognition begins when the unit is installed at the customer’s location. Lease terms are typically four years and customers pay quarterly or annual fixed payments for the lease and maintenance elements over the contractual lease term. In accordance with ASC 840, the Company considers only the fixed payments for purposes of allocating between the lease and non-lease deliverables on a relative fair value basis. Equipment leases are generally classified as operating leases as they do not meet any of the capital lease criteria per ASC 840.

[0001558370-22-004491:notes:103]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (1) distinct services, such as installation, training, SaaS, and maintenance, and (2) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern and because revenue allocated to maintenance components is not material, the equipment lease and maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:notes:104]
As leases with customers are generally classified as operating leases, lease revenue is recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001558370-22-004491:notes:105]
Services Revenue

[0001558370-22-004491:notes:106]
The Company provides installation, training, SaaS, and maintenance services for its products. Revenue for installation and training is recognized upon transfer of control of these services, which are normally rendered over a shorter duration. SaaS include data-driven security information and analytics insights. Maintenance consists of technical support, bug fixes, and when-and-if-available threat updates. Maintenance revenue and SaaS revenue are recognized ratably over the period of the arrangement, beginning upon installation of the equipment. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are recognized ratably over the associated service period and also begin upon installation of the equipment.

[0001558370-22-004491:notes:107]
Revenue from Channel Partners

[0001558370-22-004491:notes:108]
A portion of the Company’s revenue is also generated by sales in conjunction with its channel partners. When the Company transacts with a channel partner, its contractual arrangement is with the channel partner and not with the end-use customer. In these transactions, the channel partner is considered the customer; the Company has discretion over the pricing to the channel partner and maintains overall control of the inventory and sales process to the channel partner. Revenue is recognized upon delivery to the channel partners. Right of return does not generally exist. Whether the Company transacts with a channel partner and receives the order from a channel partner or directly from an end-use customer, its revenue recognition policy and resulting pattern of revenue recognition is the same.

[0001558370-22-004491:notes:109]
Transaction Price

[0001558370-22-004491:notes:110]
The transaction price is the amount of consideration that the Company expects to be entitled for providing goods and services under a contract. It includes not only fixed consideration, such as the stated amount in a contract, but also several other types of variable consideration or adjustments (generally discounts or incentives which are included as a part of the standalone selling price (“SSP”) estimation process). The Company provides discounts to customers which reduces the transaction price. From time-to-time, the Company may offer customers the option to purchase additional goods and services at a fixed price. In these limited circumstances, the Company assesses whether these offers constitute a material right, and if so, the Company would account for the material right as a separate performance obligation. Other

[0001558370-22-004491:notes:111]
types of variable consideration are not considered significant. The Company does not normally provide for rights of returns to customers on product sales and, therefore, does not record a provision for returns.

[0001558370-22-004491:notes:112]
Performance Obligations

[0001558370-22-004491:notes:113]
A performance obligation is a promise in a contract to transfer a distinct product or service to a customer that is both capable of being distinct, whereby the customer can benefit from the product or service either on its own or together with other resources that are readily available, and is distinct in the context of the contract, whereby the transfer of the product or service is separately identifiable from other promises in the contract.

[0001558370-22-004491:notes:114]
For both Express and Edge units, equipment is sold or leased with embedded software, which is considered a single performance obligation. Maintenance, which includes future updates, security threat updates, and minor bug fixes on a when-and-if available basis, is considered a single performance obligation. SaaS, which include data-driven security information and analytics insights, are also considered a performance obligation. As a part of reported subscription sales, certain non-lease components, such as SaaS and maintenance, are included within the subscription revenue amount. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are accounted for as separate performance obligations. Installation and training are considered separate performance obligations and are included within services revenue. Any add-on accessories are also considered separate performance obligations and are included in product revenue in the consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:notes:115]
Payment terms

[0001558370-22-004491:notes:116]
Payment terms for customer orders are typically 30 days after the shipment or installation of the product. For certain products, services and customer types, the Company requires payment before the products or services are delivered to, or performed for, the customer. Generally, the Company’s contracts do not contain a significant financing component.

[0001558370-22-004491:notes:117]
Multiple Performance Obligations within an Arrangement

[0001558370-22-004491:notes:118]
The Company’s contracts may include multiple performance obligations when customers purchase a combination of products and services. When the Company’s customer arrangements have multiple performance obligations that contain a lease for Express or Edge equipment for the customer’s use at its site as well as distinct services that are delivered simultaneously, the Company allocates the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, the Company allocates the contract’s transaction price to each performance obligation on a relative SSP basis. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company estimates the SSP taking into account available information such as market conditions, internally approved pricing guidelines, and observable pricing data such as standard cost metrics related to the performance obligation.

[0001558370-22-004491:notes:119]
Remaining Performance Obligations

[0001558370-22-004491:notes:120]
ASC 606 requires that the Company disclose the aggregate amount of transaction price that is allocated to performance obligations that have not yet been satisfied as of December 31, 2021. The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or

[0001558370-22-004491:notes:121]
partially satisfied) as of December 31, 2021. Note that with respect to ASC 840, Subscription revenue includes maintenance in addition to the operating lease components of these transactions (in thousands).

[0001558370-22-004491:notes:122]
| ​ |  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue |  | $ | 187 |  | $ | 68 |  | $ | 255 |
| Subscription revenue |  | ​ | 11,183 |  | ​ | 25,065 |  | ​ | 36,248 |
| Service revenue |  | ​ | 22 |  | ​ | — |  | ​ | 22 |
| Maintenance revenue |  | ​ | 1,128 |  | ​ | 2,507 |  | ​ | 3,635 |
| Total revenue | ​ | $ | 12,520 | ​ | $ | 27,640 | ​ | $ | 40,160 |

[0001558370-22-004491:notes:123]
The amount of minimum future leases is based on expected income recognition. As of December 31, 2021, future minimum payments on noncancelable leases are as follows (in thousands):

[0001558370-22-004491:notes:124]
| Future operating lease component (in thousands): |  | ​ |  |
| Year Ending December 31, 2021: | ​ | ​ | ​ |
| 2022 | ​ | $ | 11,183 |
| 2023 | ​ |  | 10,573 |
| 2024 | ​ |  | 9,165 |
| 2025 | ​ |  | 4,852 |
| Thereafter | ​ |  | 475 |
| ​ | ​ | $ | 36,248 |

[0001558370-22-004491:notes:125]
Contract Balances from Contracts with Customers

[0001558370-22-004491:notes:126]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of December 31, 2021 and 2020, the Company had $1.5 million and $0 in current portion of contract assets and $3.4 million and $0 in contract assets, noncurrent on the consolidated balance sheets, respectively. The increase in contract assets is primarily related to the increase in direct equipment sales during the year ended December 31, 2021.

[0001558370-22-004491:notes:127]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as noncurrent deferred revenue. The Company recognized $2.3 million during the year ended December 31, 2021 of revenue that was previously included in the 2020 deferred revenue balance, respectively. The following table provides a rollforward of deferred revenue (in thousands):

[0001558370-22-004491:notes:128]
| ​ | ​ | (in thousands) |
| Balance at December 31, 2020 | ​ | $ | 4,197 |
| Revenue recognized | ​ |  | (10,877) |
| Revenue deferred | ​ |  | 15,845 |
| Balance at December 31, 2021 | ​ | $ | 9,165 |

[0001558370-22-004491:notes:129]
Disaggregated Revenue

[0001558370-22-004491:notes:130]
The following table presents the Company’s revenue by revenue stream (in thousands):

[0001558370-22-004491:notes:131]
| ​ | ​ | Year Ended December 31, |
| (in thousands) | ​ | 2021 |  | 2020 |
| Product revenue | ​ | ​ | 13,917 |  | ​ | 1,279 |
| Leased Equipment | ​ | ​ | 6,130 |  | ​ | 2,073 |
| SaaS and Maintenance Services(1) | ​ | ​ | 2,568 |  | ​ | 1,083 |
| Professional Services | ​ | ​ | 1,077 |  | ​ | 350 |
| Total revenue | ​ | $ | 23,692 | ​ | $ | 4,785 |

[0001558370-22-004491:notes:132]
| (1) | SaaS and Maintenance Services revenue is inclusive of $1.7 million and $0.6 million of revenue related to equipment that is leased to customers during the years ended December 31, 2021 and 2020, respectively, determined based on a relative fair value allocation as prescribed by ASC 606. This has been broken out from the leased equipment and combined with SaaS and Maintenance services from product sales within this line item. |

[0001558370-22-004491:notes:133]
Contract Acquisition Costs

[0001558370-22-004491:notes:134]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the sale occurs and the services are provided. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $5.4 million and $2.3 million as of December 31, 2021 and 2020, respectively. The increase in deferred assets related to commissions is due to an increase of subscription revenue in 2020 and 2021 for which the related revenue and commissions are recognized over the contract term. The Company amortized commissions of $1.9 million during the year ended December 31, 2021 which related to 2021 commissions, $0.5 million which related to 2020 commissions and $0.2 million which related to 2019 commissions.

[0001558370-22-004491:notes:135]
Accounts Receivable

[0001558370-22-004491:notes:136]
Accounts receivable, net was $6.5 million and $1.4 million as of December 31, 2021 and 2020, respectively.

[0001558370-22-004491:notes:137]
As of December 31, 2021 and 2020, the Company recorded an allowance for doubtful accounts of $0.1 million and $0.1 million, respectively. Changes in the allowance for doubtful accounts were as follows (in thousands):

[0001558370-22-004491:notes:138]
| ​ | ​ | Allowance for Doubtful Accounts |
| Balance at December 31, 2019 | ​ | $ | (16) |
| Provisions | ​ | ​ | (63) |
| Write-offs, net of recoveries | ​ | ​ | 16 |
| Balance at December 31, 2020 | ​ | $ | (63) |
| Provisions | ​ |  | (50) |
| Write-offs, net of recoveries | ​ |  | 63 |
| Balance at December 31, 2021 | ​ | $ | (50) |

[0001558370-22-004491:notes:139]
Stock-Based Compensation

[0001558370-22-004491:notes:140]
The Company measures all stock-based awards granted to employees, officers, directors and non-employees based on their fair value on the date of the grant and recognizes compensation expense for those awards over the requisite service period, which is generally the vesting period of the respective award. The Company classifies stock-

[0001558370-22-004491:notes:141]
based compensation expense in its consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. The Company issues stock-based awards with service-based vesting conditions and records the expense for these awards using the straight-line method. Forfeitures are accounted for as they occur. In August 2020, the Company granted an officer 559,947 stock options with a performance-based milestone vesting condition which vested immediately upon achievement of a certain sales milestone. The milestone was achieved in December 2020, and the Company recorded $0.1 million in stock compensation expense upon vesting during the year ended December 31, 2020.

[0001558370-22-004491:notes:142]
In March 2021, the Company granted a warrant exercisable for 2,552,913 shares of common stock to a consulting group (“2021 Finback common stock warrants”) with performance-based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years.

[0001558370-22-004491:notes:143]
Prior to the closing of the Merger, there was not a public market for the shares of the Company’s common stock. The Company’s determination of the fair value of stock options on the date of grant utilized the Black-Scholes option-pricing model and was impacted by its common stock price, as determined by the Board of Directors with input from the Company’s management, as well as changes in assumptions regarding a number of subjective variables. These variables included, but were not limited to, the expected term that options remained outstanding, the expected common stock price volatility over the term of the option awards, risk-free interest rates, and expected dividends. The Company values its common stock taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the Company determined the fair value of each share of common stock underlying stock-based awards based on the closing price of the Company’s common stock as reported by Nasdaq on the date of grant.

[0001558370-22-004491:notes:144]
Pursuant to the Merger Agreement, the Company will issue 15,000,000 earn-out shares of the Company’s common stock to Legacy Evolv shareholders and Legacy Evolv Service Providers including employees, officers, directors and non-employees based on the achievement of certain target share price contingencies and subject to continued employment. The company classifies the share-based compensation arrangement with Legacy Evolv Service Providers as equity on its balance sheet and corresponding stock-based compensation expense in its consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. Of the total 15,000,000 earn-out shares of the Company’s common stock, 2,849,587 earn-out shares can be earned by the Legacy Evolv Service Providers and subject to the stock-based compensation. Stock-based compensation expense attributable to Legacy Evolv Service Providers was $4.3 million for the year ended December 31, 2021. As a condition for Earn-Out Shares being issued to Earn-Out Service Providers the service provider must be providing services to the Company on the date of the issuance of the shares. If the relationship with the service provider is terminated prior to the issuance of the Earn-Out Shares the shares will be redistributed to the remaining participants in the Earn-Out Shares.

[0001558370-22-004491:notes:145]
Income Taxes

[0001558370-22-004491:notes:146]
The Company accounts for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in the consolidated financial statements or in the Company’s tax returns. Deferred tax assets and liabilities are determined on the basis of the differences between the consolidated financial statements and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. Changes in deferred tax assets and liabilities are recorded in the provision for income taxes.

[0001558370-22-004491:notes:147]
The Company assesses the likelihood that its deferred tax assets will be recovered from future sources of income and, to the extent it believes, based upon the weight of available evidence, that it is more likely than not that all or a portion of the deferred tax assets will not be realized, a valuation allowance is established through a charge to income tax expense. Potential for recovery of deferred tax assets is evaluated by analyzing past operating results, estimating the future taxable profits expected and considering prudent and feasible tax planning strategies.

[0001558370-22-004491:notes:148]
The Company accounts for uncertainty in income taxes recognized in the consolidated financial statements by applying a two-step process to determine the amount of tax benefit to be recognized. First, the tax position must be evaluated to determine the likelihood that it will be sustained upon external examination by the taxing authorities. If the tax position is deemed more-likely-than-not to be sustained, the tax position is then assessed to determine the amount of benefit to recognize in the consolidated financial statements. The amount of the benefit that may be recognized is the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. The provision for income taxes includes the effects of any resulting tax reserves, or unrecognized tax benefits, that are considered appropriate as well as the related net interest and penalties.

[0001558370-22-004491:notes:149]
The Company evaluates at the end of each reporting period whether some or all the undistributed earnings of its foreign subsidiaries are permanently reinvested. The Company would recognize deferred income tax liabilities to the extent that management asserts that undistributed earnings of its foreign subsidiaries are not permanently reinvested and will not be permanently reinvested in the future. As of December 31, 2021 and 2020, the Company had no foreign earnings in any foreign jurisdictions.

[0001558370-22-004491:notes:150]
Net Loss per Share Attributable to Common Stockholders

[0001558370-22-004491:notes:151]
Basic net loss per share attributable to common stockholders is computed by dividing the net loss attributable to common stockholders by the weighted average number of common shares outstanding for the period. Diluted net loss attributable to common stockholders is computed by adjusting net loss attributable to common stockholders for the impact to the extent a denominator adjustment is required. Diluted net loss per share attributable to common stockholders is computed by dividing the diluted net loss attributable to common stockholders by the weighted average number of common shares outstanding for the period, including potential dilutive common shares. For purposes of this calculation, outstanding stock options, convertible preferred stock, convertible notes, warrants to purchase common stock, and warrants to purchase preferred stock are considered potential dilutive common shares.

[0001558370-22-004491:notes:152]
In periods in which the Company reported a net loss attributable to common stockholders, diluted net loss per share attributable to common stockholders is the same as basic net loss per share attributable to common stockholders, since dilutive common shares are not assumed to have been issued if their effect is anti-dilutive. The Company reported a net loss attributable to common stockholders for the years ended December 31, 2021 and 2020.

[0001558370-22-004491:notes:153]
Recently Adopted Accounting Pronouncements

[0001558370-22-004491:notes:154]
In August 2018, the FASB issued ASU 2018-15, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40). The update is associated with customer accounting for implementation costs incurred in a cloud computing arrangement that is a service contract. The amendments align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. The guidance is effective for fiscal years and interim periods beginning after December 15, 2019 for public companies, and for fiscal years beginning after December 15, 2020, and interim periods within annual periods beginning after December 15, 2021, for all other entities. The Company adopted this standard on January 1, 2021. In connection with the adoption, the Company recorded $1.0 million in capitalized costs related to internal-use software in property and equipment, net on the consolidated balance sheets as of December 31, 2021.

[0001558370-22-004491:notes:155]
Recently Issued Accounting Pronouncements

[0001558370-22-004491:notes:156]
The Company qualifies as an “emerging growth company” as defined in the Jumpstart Our Business Startups Act of 2012 and has elected not to “opt out” to the extended transition related to complying with new or revised accounting standards, which means that when a standard is issued or revised and it has different application dates for public and nonpublic companies, the Company will adopt the new or revised standard at the time nonpublic companies adopt the new or revised standard and will do so until such time that the Company either (1) irrevocably elects to “opt out” of such extended transition period or (2) no longer qualifies as an emerging growth company. The Company may

[0001558370-22-004491:notes:157]
choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for nonpublic companies.

[0001558370-22-004491:notes:158]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

[0001558370-22-004491:notes:159]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), as subsequently amended (collectively “ASC 842”). The guidance amends the existing accounting standards for lease accounting, including requirements for lessees to recognize assets and liabilities related to long-term leases on the balance sheet and expanding disclosure requirements regarding leasing arrangements. For lessees, leases will be classified as finance or operating, with classification affecting the pattern and classification of expense recognition in the income statement. Lessors are required to classify leases as a sales-type, direct financing, or operating lease. A lease is a sales-type lease if it effectively transfers control of the underlying asset to the lessee as indicated by any one of five criteria being met. If none of the five prescriptive criteria are met, the lease will be classified as either a direct financing lease or operating lease. If two additional criteria addressing whether the lessor has transferred substantially all of the risks and benefits of the underlying asset to the lessee and a third party, the lease will be classified as a direct financing lease. All leases that are not sales-type or direct financing leases will be classified as operating leases. In July 2018, the FASB issued additional guidance, which offers a transition option to entities adopting ASC 842 in which entities can elect to apply the new guidance using a modified retrospective approach at the beginning of the year in which the new lease standard is adopted. The Company currently expects to utilize this transition option whereby financial information for prior periods presented before the ASC 842 effective date will not be updated. In November 2019, the FASB issued ASU 2019-10 deferring the effective date for private entities (also applicable for public companies that qualify as emerging growth companies) for fiscal years beginning after December 15, 2020, and interim periods within fiscal years beginning after December 15, 2021. In June 2020, the FASB issued ASU 2020-05 which further defers the effective date for private entities for fiscal years beginning after December 15, 2021, and interim periods within fiscal years beginning after December 15, 2022.

[0001558370-22-004491:notes:160]
As an Emerging Growth Company, the Company will adopt ASC 842 on January 1, 2022 and is currently evaluating the effect ASC 842 will have on its consolidated financial statements and related disclosures. ASC 842 provides several optional practical expedients in transition. The Company expects to apply the ‘package of practical expedients’ which allow the Company to not reassess whether existing or expired arrangements contain a lease, the lease classification of existing or expired leases, or whether previous initial direct costs would qualify for capitalization under ASC 842. The Company, as the lessor to a significant number of lease contracts that will continue to be operating classified, expects to apply the practical expedient to account for those operating leases and the associated services as a combined component when certain criteria are met. In order to be eligible to apply this lessor expedient to combine one or more nonlease components, representing a good or service, with the associated lease component, the timing and pattern of transfer of the nonlease component must be the same as that of the lease component, which is over time, and the associated lease component, if accounted for separately, must meet the criteria to be classified as an operating lease. If an arrangement contains an operating lease component and one or more nonlease components, the nonlease components that have the same timing and pattern of transfer will be combined with the associated lease component and the nonlease components that do not have the same timing and pattern of transfer will be accounted for separately. The lease components in these arrangements are expected to be the predominant component and those arrangements will be accounted for under ASC 842. The revenue for leases and associated services for these operating leases will be presented

[0001558370-22-004491:notes:161]
together in the Company’s consolidated statements of operations and comprehensive loss. Additionally, the Company expects to elect the accounting policy for lessors to exclude sales taxes and other similar taxes assessed by a governmental authority that the Company collects from lessees from lease revenue.

[0001558370-22-004491:notes:162]
The Company currently expects the adoption of ASC 842 to result in the recognition of operating lease liabilities of approximately $3.0 million and operating right-of-use assets of approximately $2.5 million, along with the write-off of certain deferred rent balances of $0.5 million within the Company’s consolidated balance sheets as of January 1, 2022. The Company also expects to provide significant new disclosures about our leasing activities. The Company does not currently expect the adoption of ASC 842 to have a material impact on its consolidated statements of operations and comprehensive loss or consolidated statements of cash flows.

[0001558370-22-004491:notes:163]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company expects to adopt this guidance effective January 1, 2022 and the adoption of this guidance will not have a material impact on its consolidated financial statements and related disclosures.

[0001558370-22-004491:notes:164]
In August 2020, the FASB issued ASU 2020-06, “Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity,” which simplifies and clarifies certain calculation and presentation matters related to convertible and equity and debt instruments. Specifically, ASU 2020-06 removes requirements to separately account for conversion features as a derivative under ASC Topic 815 and removing the requirement to account for beneficial conversion features on such instruments. ASU 2020-06 also provides clearer guidance surrounding disclosure of such instruments and provides specific guidance for how such instruments are to be incorporated in the calculation of Diluted EPS. The guidance under ASU 2020-06 is effective for fiscal years beginning after December 15, 2021, including interim periods within those fiscal years. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020. The Company expects to adopt this guidance effective January 1, 2022 and does not expect the adoption this guidance to have a material impact on its consolidated financial statements and related disclosures.

[0001558370-22-004491:notes:165]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001558370-22-004491:notes:166]
3. Merger with NHIC

[0001558370-22-004491:notes:167]
On July 16, 2021, we completed the previously announced Merger pursuant to the Agreement and Plan of Merger, dated as of March 5, 2021, and amended by the First Amendment to Agreement and Plan of Merger (the “Merger Agreement”), dated as of June 5, 2021. Upon closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. and the officers of NHIC, the legal predecessor company, resigned. The officers of Legacy

[0001558370-22-004491:notes:168]
Evolv became the officers of the Company, and the Company listed its shares of common stock, par value $0.0001 per share, on Nasdaq under the symbol “EVLV”.

[0001558370-22-004491:notes:169]
The transaction was accounted for as a “reverse recapitalization” in accordance with GAAP. Under this method of accounting, NHIC was treated as the “acquired” company for financial reporting purposes. This determination was primarily because subsequent to the Merger, Legacy Evolv’s shareholders have a majority of the voting power of the combined company, Legacy Evolv comprises all of the ongoing operations of the combined entity, Legacy Evolv comprises a majority of the governing body of the combined company, and Legacy Evolv’s senior management comprises all of the senior management of the combined company. Accordingly, for accounting purposes, this transaction was treated as the equivalent of Legacy Evolv issuing shares for the net assets of NHIC, accompanied by a recapitalization. The shares and net loss per common share, prior to the Merger, have been retroactively restated as shares reflecting the Exchange Ratio established in the Merger. The net assets of NHIC were recorded at historical costs, with no goodwill or other intangible assets recorded. Operations prior to the Reverse Recapitalization are those of Legacy Evolv.

[0001558370-22-004491:notes:170]
Evolv had previously indicated that it would list units (consisting of one share of common stock and one-half of one warrant) on Nasdaq under the ticker symbol EVLVU, in continuation of the listing of the units NHIC sold in its initial public offering on August 4, 2020 under the ticker symbol NHICU. In September 2021, our transfer agent separated the units into the component shares and warrants at the closing of the Merger, and as a result the Evolv units were not made eligible to settle through the facilities of The Depositary Trust Company. Accordingly, all trades in the units from July 19, 2021 (the first trading day after the completion of the Merger) until August 24, 2021 were settled between brokers in the shares and warrants underlying the units. Trading in ticker symbol EVLVU was halted on August 24, 2021, and no trades in the units were permitted or occurred since that date. The units were delisted from Nasdaq effective September 10, 2021.

[0001558370-22-004491:notes:171]
Upon closing of the Merger each share of NHIC Class B common stock issued and outstanding immediately prior to the effective time of the Merger, which totaled 10,391,513 shares held by the NHIC Initial Shareholders (“Initial Shareholders”), was automatically converted into one validly-issued share of our common stock.

[0001558370-22-004491:notes:172]
In addition, pursuant to the Merger Agreement, certain Legacy Evolv Shareholders became entitled to receive up to 15,000,000 shares of common stock as earn-out shares.

[0001558370-22-004491:notes:173]
Upon closing of the Merger:

[0001558370-22-004491:notes:174]
|  | ● | all of 24,359,107 shares of Legacy Evolv’s Series A-1 convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis; |

[0001558370-22-004491:notes:175]
|  | ● | all of 3,484,240 shares of Legacy Evolv’s Series A convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a two-to-one basis; |

[0001558370-22-004491:notes:176]
|  | ● | all of 34,129,398 shares of Legacy Evolv’s Series B-1 convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis; and |

[0001558370-22-004491:notes:177]
|  | ● | all of 15,367,312 shares of Legacy Evolv’s Series B convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis. |

[0001558370-22-004491:notes:178]
On the closing date of the Merger, each share of Legacy Evolv common stock then issued and outstanding was canceled and the holders thereof in exchange received 94,192,534 shares of the Company’s common stock, which is equal to 0.378 newly-issued shares of the Company’s common stock for each share of Legacy Evolv common stock (the “Exchange Ratio”).

[0001558370-22-004491:notes:179]
All outstanding warrants exercisable for common stock in Legacy Evolv (other than warrants that expired, were exercised or were deemed automatically net exercised immediately prior to the Merger) were exchanged for warrants

[0001558370-22-004491:notes:180]
exercisable for the Company’s common stock with the same terms and conditions except adjusted by the Exchange Ratio.

[0001558370-22-004491:notes:181]
All outstanding stock options of Legacy Evolv common stock, totaling 57,938,375 stock options, were canceled and the holders thereof in exchange received options to receive 0.378 shares of the Company’s common stock for a total of 21,891,254 stock options. The modification of the stock options to reflect the exchange ratio did not result in an incremental compensation expense upon closing of the Merger.

[0001558370-22-004491:notes:182]
The proceeds, net of redemptions, received from the Merger were $84.9 million and gross proceeds received from the PIPE investment were $300.0 million. Based on the number of shares of common stock outstanding on July 16, 2021 (in each case, not giving effect to any shares issuable upon exercise of warrants, options, or earn-out shares), Legacy Evolv shareholders owned approximately 92.7% of the common stock of the Company and NHIC shareholders owned approximately 7.3%.

[0001558370-22-004491:notes:183]
During the year ended December 31, 2021, the Company recorded $36.1 million of offering costs related to third-party legal, accounting, and other professional services to consummate the Merger. These offering costs are recorded as a reduction of additional paid-in capital upon the close of the Merger in the Company’s consolidated balance sheets. The Company expensed $0.7 million of offering costs related to the issuance of the Company’s contingently issuable common stock.


## us-gaap:FairValueDisclosuresTextBlock

[0001558370-22-004491:notes:184]
4. Fair Value Measurements

[0001558370-22-004491:notes:185]
The following tables present information about the Company’s financial assets and liabilities measured at fair value on a recurring basis and indicate the level of the fair value hierarchy used to determine such fair values (in thousands):

[0001558370-22-004491:notes:186]
| ​ | ​ | Fair Value Measurements at December 31, 2021 |
| ​ |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Money market funds | ​ | $ | 297,536 | ​ | $ | — | ​ | $ | — | ​ | $ | 297,536 |
| ​ | ​ | $ | 297,536 | ​ | $ | — | ​ | $ | — | ​ | $ | 297,536 |
| Liabilities: | ​ | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Contingent earn-out liability | ​ | $ | — | ​ | $ | — | ​ | $ | 20,809 | ​ | $ | 20,809 |
| Contingently issuable common stock liability | ​ | ​ | — | ​ | ​ | — | ​ | ​ | 5,264 | ​ | ​ | 5,264 |
| Public Warrant liability | ​ | ​ | — | ​ | ​ | — | ​ | ​ | 11,030 | ​ | ​ | 11,030 |
| ​ | ​ | $ | — | ​ | $ | — | ​ | $ | 37,103 | ​ | $ | 37,103 |

[0001558370-22-004491:notes:187]
| ​ | ​ | Fair Value Measurements as of December 31, 2020 |
| ​ |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Liabilities: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Common stock warrant liability | ​ | $ | — | ​ | $ | — | ​ | $ | 1 | ​ | $ | 1 |
| Derivative liability | ​ |  | — | ​ |  | — | ​ |  | 1,000 | ​ |  | 1,000 |
| ​ | ​ | $ | — | ​ | $ | — | ​ | $ | 1,001 | ​ | $ | 1,001 |

[0001558370-22-004491:notes:188]
As of December 31, 2021, money market funds are included in cash and cash equivalents on the consolidated balance sheets.

[0001558370-22-004491:notes:189]
The Company may also value its non-financial assets and liabilities, including items such as inventories and property and equipment, at fair value on a non-recurring basis if it is determined that impairment has occurred. Such fair

[0001558370-22-004491:notes:190]
value measurements use significant unobservable inputs and are classified as Level 3. The Company recorded $1.6 million in write-offs of inventory of Edge units during the year ended December 31, 2021 as the Company is no longer selling this product. The Company recorded $1.9 million of loss from impairment of property and equipment for the year ended December 31, 2021. This related to Edge units and Express prototype units that were removed from service and retired. The Company is transitioning its domestic customers from the Legacy Edge units to its most current Evolv Express units, which resulted in an impairment of the remaining economic value of such assets. There was no impairment recognized for the year ended December 31, 2020.

[0001558370-22-004491:notes:191]
During the years ended December 31, 2021 and 2020, respectively, there were no transfers between Level 1, Level 2 and Level 3.

[0001558370-22-004491:notes:192]
Valuation of Common Stock Warrant

[0001558370-22-004491:notes:193]
The warrant liability is related to the warrants (the “Warrants”) to purchase shares of Legacy Evolv’s common stock (see Note 11).

[0001558370-22-004491:notes:194]
The Company used the Black-Scholes option-pricing model, which incorporates assumptions and estimates, to value the warrant liability. Key estimates and assumptions impacting the fair value measurement include (1) the fair value per share of the underlying shares of applicable series of stock issuable upon exercise of the Warrants, (2) the remaining contractual term of the Warrants, (3) the risk-free interest rate, (4) the expected dividend yield and (5) expected volatility of the price of the underlying applicable common stock. The Company estimated the fair value per share of the underlying applicable series of stock based, in part, on the results of third-party valuations and additional factors deemed relevant. The risk-free interest rate was determined by reference to the U.S. Treasury yield curve for time periods approximately equal to the remaining contractual term of the Warrant. The Company estimated a zero expected dividend yield based on the fact that the Company has never paid or declared dividends and does not intend to do so in the foreseeable future. As the Company was a private company up until the closing of the Merger and lacked company-specific historical and implied volatility information of its stock, the expected stock volatility was based on the historical volatility of publicly traded peer companies for a term equal to the remaining contractual term of the Warrant.

[0001558370-22-004491:notes:195]
The following table provides a rollforward of the common stock warrant liability (in thousands):

[0001558370-22-004491:notes:196]
| Balance at December 31, 2020 | ​ | $ | 1 |
| Change in fair value | ​ |  | 879 |
| Conversion of common stock warrant to common stock upon the closing of the Merger | ​ | ​ | (880) |
| Balance at December 31, 2021 | ​ | $ | — |

[0001558370-22-004491:notes:197]
Valuation of Derivative Liability Related to Convertible Notes

[0001558370-22-004491:notes:198]
In September and December 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) (see Note 9). The 2020 Convertible Notes provided a conversion option whereby upon the closing of a specified financing event the Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative and was required to be bifurcated and accounted for separately from the 2020 Convertible Notes. The fair value of the derivative liability was determined based on inputs not observable in the market, which represents a Level 3 measurement within the fair value hierarchy.

[0001558370-22-004491:notes:199]
Upon the closing of the 2020 Convertible Notes, management determined that the probability of completing the specified financing event was 100%; thus, the value of the automatic conversion option was deemed to be 20% of the fair value of the capital stock to be issued upon conversion of the 2020 Convertible Notes, or $1.0 million. This amount represented the fair value of the embedded derivative at issuance.

[0001558370-22-004491:notes:200]
In January and February 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) (see Note 9). The 2021 Convertible Notes provided a conversion option whereby upon the closing of a specified financing event, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to lower of 80% of the price per share of the securities paid by the other investors or price per share at which shares are issued and sold in connection with the conversion or cancellation of convertible notes (other than the 2021 Convertible Notes) or simple agreements for future equity (“SAFEs”) of the Company in such Qualified Financing. This conversion option was determined to be an embedded derivative and was required to be bifurcated and accounted for separately from the 2021 Convertible Notes. The fair value of the derivative liability was determined based on inputs not observable in the market, which represents a Level 3 measurement within the fair value hierarchy.

[0001558370-22-004491:notes:201]
Upon the closing of the 2021 Convertible Notes, management determined that the probability of completing the specified financing event was 80%; thus, the value of the automatic conversion option was deemed to be 20% of the fair value of the capital stock to be issued upon conversion of the 2021 Convertible Notes, or $7.0 million. This amount represented the fair value of the embedded derivative at issuance. At the closing of the Merger, the fair value of the derivative liability was $9.2 million. On June 21, 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. The modification of the 2021 Convertible Notes resulted in the recognition of an additional $9.8 million derivative liability for the fair value of the 1,000,000 NHIC shares as of June 21, 2021 (see Note 9). Prior to the closing of the Merger, the change in fair value of the derivative liability was $0.5 million.

[0001558370-22-004491:notes:202]
The following table provides a rollforward of the derivative liability (in thousands):

[0001558370-22-004491:notes:203]
| Balance at December 31, 2020 | ​ | $ | 1,000 |
| Initial fair value of the embedded derivative | ​ | ​ | 16,986 |
| Change in fair value | ​ |  | 1,745 |
| Settlement of derivative liability upon the closing of the Merger | ​ | ​ | (19,731) |
| Balance at December 31, 2021 | ​ | $ | — |

[0001558370-22-004491:notes:204]
Valuation of Contingent Earn-out

[0001558370-22-004491:notes:205]
Pursuant to the Merger Agreement, the Legacy Evolv shareholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability on the closing of the Merger and are remeasured at each reporting period. As of December 31, 2021, no milestones have been achieved.

[0001558370-22-004491:notes:206]
The estimated fair value of the initial contingent earn-out is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. As of December 31, 2021, the contingent earn-out was revalued using a similar Monte Carlo analysis. The significant assumptions to the model as of the Merger Date were as follows: 30% of expected stock price volatility, a drift rate of 0.8%, 0% change in control and an expected term of 5 years. The significant assumptions to the model as of December 31, 2021 were as follows: 55% of expected stock price volatility, a drift rate of 1.2%, 25% of change in control and an expected term of 4.5 years.

[0001558370-22-004491:notes:207]
The following table provides a rollforward of the contingent earn-out liability (in thousands):

[0001558370-22-004491:notes:208]
| Balance at December 31, 2020 | ​ | $ | — |
| Initial fair value of the instrument | ​ | ​ | 67,021 |
| Change in fair value | ​ |  | (46,212) |
| Balance at December 31, 2021 | ​ | $ | 20,809 |

[0001558370-22-004491:notes:209]
Valuation of Contingently Issuable Common Stock

[0001558370-22-004491:notes:210]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 Founder Shares. 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC and the remaining 1,897,500 outstanding shares shall vest upon the Company achieving certain milestones (see Note 2). The Company’s contingently issuable common stock was recorded at fair value as contingent shares on the closing of the Merger and will be remeasured at each reporting period. As of December 31, 2021, no milestones have been achieved.

[0001558370-22-004491:notes:211]
The estimated fair value of the initial contingently issued common shares are determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. As of December 31, 2021, the contingently issuable common shares were revalued using a similar Monte Carlo analysis. The significant assumptions to the model as of the Merger Date were as follows: 30% of expected stock price volatility, a drift rate of 0.8%, 0% change in control and an expected term of 5 years. The significant assumptions to the model as of December 31, 2021 were as follows: 55% of expected stock price volatility, a drift rate of 1.2%, 25% of change in control and an expected term of 4.5 years.

[0001558370-22-004491:notes:212]
The following table provides a rollforward of the contingently issuable common shares (in thousands):

[0001558370-22-004491:notes:213]
| Balance at December 31, 2020 | ​ | $ | — |
| Initial fair value of the instrument | ​ | ​ | 11,670 |
| Change in fair value | ​ |  | (6,406) |
| Balance at December 31, 2021 | ​ | $ | 5,264 |

[0001558370-22-004491:notes:214]
Valuation of Public Warrant Liability

[0001558370-22-004491:notes:215]
Upon the closing of the Merger, the Company assumed the Public Warrants to purchase shares of the Company’s common stock (see Note 11). The Public Warrants are publicly traded and the initial fair value of the public warrants were based on the closing price as reported by Nasdaq on the date of the Merger and remeasured at each reporting period.

[0001558370-22-004491:notes:216]
The following table provides a rollforward of the public warrant liability (in thousands):

[0001558370-22-004491:notes:217]
| Balance at December 31, 2020 | ​ | $ | — |
| Initial fair value of the instrument | ​ | ​ | 23,636 |
| Change in fair value | ​ |  | (12,606) |
| Balance at December 31, 2021 | ​ | $ | 11,030 |


## us-gaap:InventoryDisclosureTextBlock

[0001558370-22-004491:notes:218]
5. Inventory

[0001558370-22-004491:notes:219]
Inventory consisted of the following (in thousands):

[0001558370-22-004491:notes:220]
| ​ | ​ | December 31, |
| ​ |  | 2021 |  | 2020 |
| Raw materials | ​ | $ | 1,050 | ​ | $ | 453 |
| Work in process | ​ |  | — | ​ |  | 188 |
| Finished goods | ​ |  | 4,090 | ​ |  | 2,101 |
| Total | ​ | $ | 5,140 | ​ | $ | 2,742 |


## nhic:PrepaidExpenseAndOtherAssetsCurrentTextBlock

[0001558370-22-004491:notes:221]
6. Prepaid expenses and other current assets

[0001558370-22-004491:notes:222]
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001558370-22-004491:notes:223]
| ​ |  | December 31, |
| ​ |  | 2021 |  | 2020 |
| Prepaid deposits | ​ | $ | 7,591 | ​ | $ | — |
| Prepaid insurance | ​ | ​ | 2,803 | ​ | ​ | 240 |
| Prepaid subscriptions | ​ | ​ | 411 | ​ | ​ | 594 |
| Other | ​ |  | 242 | ​ |  | 66 |
| Total | ​ | $ | 11,047 | ​ | $ | 900 |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001558370-22-004491:notes:224]
7. Property and Equipment, Net

[0001558370-22-004491:notes:225]
Property and equipment, net consisted of the following (in thousands):

[0001558370-22-004491:notes:226]
| ​ | ​ | December 31, |
| ​ | ​ | 2021 |  | 2020 |
| Computers and telecom equipment | ​ | $ | 40 | ​ | $ | 217 |
| Lab equipment | ​ |  | 568 | ​ |  | 487 |
| Purchased software | ​ |  | — | ​ |  | 59 |
| Furniture and fixtures | ​ |  | 37 | ​ |  | 37 |
| Leasehold improvements | ​ |  | 491 | ​ |  | 95 |
| Leased equipment | ​ | ​ | 21,100 | ​ | ​ | 10,124 |
| Internal-use software | ​ | ​ | 1,029 | ​ | ​ | — |
| Sales demo equipment | ​ |  | 1,938 | ​ |  | 824 |
| ​ | ​ |  | 25,203 | ​ |  | 11,843 |
| Less: Accumulated depreciation and amortization | ​ |  | (3,611) | ​ |  | (2,527) |
| ​ | ​ | $ | 21,592 | ​ | $ | 9,316 |

[0001558370-22-004491:notes:227]
As of December 31, 2021 and 2020, the net book value of internal-use software was $1.0 million and $0, respectively. Depreciation expense and amortization expense related to property and equipment was $2.9 million and $1.1 million for the years ended December 31, 2021 and 2020, respectively, which included amortization expense of internal-use software of less than $0.1 million and $0 for the years ended December 31, 2021 and 2020, respectively.

[0001558370-22-004491:notes:228]
Leased equipment and the related accumulated depreciation were as follows:

[0001558370-22-004491:notes:229]
| ​ | ​ | December 31, |
| ​ | ​ | 2021 |  | 2020 |
| Leased equipment | ​ | $ | 21,100 | ​ | $ | 10,124 |
| Accumulated depreciation | ​ |  | (2,761) | ​ |  | (1,385) |
| Leased equipment, net | ​ | $ | 18,339 | ​ | $ | 8,739 |

[0001558370-22-004491:notes:230]
Depreciation related to leased units was $2.5 million and $0.8 million during the years ended December 31, 2021 and 2020, respectively. Depreciable lives generally range from 4 to 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.

[0001558370-22-004491:notes:231]
Impairment of property and equipment was $1.9 million for the year ended December 31, 2021. There was no impairment recognized for the year ended December 31, 2020. This related to Edge units and Express prototype units that were removed from service and retired. The Company is transitioning its domestic customers from the Legacy Edge units to its most current Evolv Express units, which resulted in an impairment of the remaining economic value of such assets.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001558370-22-004491:notes:232]
8. Accrued Expenses and Other Current Liabilities

[0001558370-22-004491:notes:233]
Accrued expenses and other current liabilities consisted of the following (in thousands):

[0001558370-22-004491:notes:234]
| ​ | ​ | December 31, |
| ​ | ​ | 2021 |  | 2020 |
| Accrued employee compensation and benefits expense | ​ | $ | 5,536 | ​ | $ | 2,345 |
| Accrued professional services and consulting | ​ |  | 1,441 | ​ |  | 1,327 |
| Accrued sales tax | ​ | ​ | 1,091 | ​ | ​ | — |
| Accrued interest | ​ | ​ | 64 | ​ | ​ | — |
| Other | ​ |  | 1,051 | ​ |  | 55 |
| Total | ​ | $ | 9,183 | ​ | $ | 3,727 |


## us-gaap:DebtDisclosureTextBlock

[0001558370-22-004491:notes:235]
9. Long-term Debt

[0001558370-22-004491:notes:236]
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001558370-22-004491:notes:237]
| ​ | ​ | December 31, |
| ​ | ​ | 2021 |  | 2020 |
| Term loans payable | ​ | $ | 10,000 | ​ | $ | 10,000 |
| Revolving line of credit outstanding | ​ |  | — | ​ |  | 3,550 |
| Convertible note | ​ |  | — | ​ |  | 3,000 |
| Less: Unamortized discount | ​ |  | (55) | ​ |  | (118) |
| ​ | ​ |  | 9,945 | ​ |  | 16,432 |
| Less: Current portion of long-term debt | ​ |  | 2,000 | ​ |  | — |
| Long-term debt, net of discount | ​ | $ | 7,945 | ​ | $ | 16,432 |

[0001558370-22-004491:notes:238]
Term Loan Agreements

[0001558370-22-004491:notes:239]
Silicon Valley Bank (“SVB”) Term Loan

[0001558370-22-004491:notes:240]
In July 2017, the Company entered into a $5.0 million Loan and Security Agreement with Silicon Valley Bank (“2017 SVB Term Loan”), which provided the Company with a first term loan advance of $4.0 million which was drawn down on July 5, 2017 (“Term Loan A Advance”) and a second term loan advance of $1.0 million that was available to be drawn down until May 31, 2018 (“Term Loan B Advance”; collectively, “Term Loan Advances”). The agreement also provided the Company with a revolving line of credit of up to $1.0 million. Interest payments were due monthly and commenced upon receipt of principal. Principal was payable in 36 monthly payments and commenced on June 1, 2018. The 2017 SVB Term Loan accrued interest at an annual rate calculated as the Wall Street Journal Prime Rate plus 1.25%.

[0001558370-22-004491:notes:241]
In February 2019, the Company amended the 2017 SVB Term Loan (“2019 Term Loan Advance”) to change the interest rate to the greater of the (A) Wall Street Journal Prime Rate or (B) 5.25%. Additionally, the maturity date was extended to August 2022. Upon closing, the Company issued warrants to purchase 28,338 shares of common stock to SVB with an exercise price of $0.24 per share (see Note 11).

[0001558370-22-004491:notes:242]
As of December 31, 2019, the Company was not in compliance with certain reporting related covenants within the SVB Loan and Security Agreement.

[0001558370-22-004491:notes:243]
In March 2020, the Company entered into a Loan Modification Agreement with SVB (“2020 SVB Term Loan”), which provided a $5.0 million term loan and a revolving line of credit of up to $7.0 million. The Company repaid the outstanding balance owed on the 2017 SVB Term Loan of $3.1 million of principal and accrued interest with the proceeds from the 2020 SVB Term Loan. The Loan Modification Agreement with SVB resulted in the Company being in compliance with certain reporting related covenants.

[0001558370-22-004491:notes:244]
Additionally, upon closing, the Company issued warrants to purchase 279,974 shares of common stock to SVB with an exercise price of $0.40 per share with a fair value of less than $0.1 million on the date of issuance. The Company also paid debt issuance costs of less than $0.1 million and owed an end-of-term charge of $0.1 million to SVB. The debt issuance costs were recorded as debt discount and were being amortized to interest expense, using the effective interest method, over the term of the loan. The 2020 SVB Term Loan interest was payable monthly and the principal was payable in 36 monthly payments commencing on April 1, 2021. The 2020 SVB Term Loan accrued interest at an annual rate calculated as the greater of (A) Wall Street Journal Prime Rate plus 0.50% or (B) 5.0%. In December 2020, the Company repaid the outstanding balance on the 2020 SVB Term loan of $8.0 million.

[0001558370-22-004491:notes:245]
JPMorgan Chase Bank, N.A.(“JPM”) Credit Agreement

[0001558370-22-004491:notes:246]
In December 2020, the Company entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024 and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022. The Company repaid the outstanding balance on the 2020 SVB Term Loan Advance, including the $5.0 million in principal and $3.0 million outstanding on the revolving line of credit. Upon repayment of the outstanding amounts, the Company recorded a loss on extinguishment of debt of less than $0.1 million, which was included in interest expense in the December 31, 2020 consolidated statements of operations and comprehensive loss.

[0001558370-22-004491:notes:247]
Principal and interest on the JPM Credit Agreement is payable monthly commencing on July 1, 2022. The JPM Credit Agreement accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 2.25% or (B) 5.5%. The revolving line of credit accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 1.25% or (B) 4.5%. Upon closing, the Company issued warrants to purchase 377,837 shares of common stock to the lender with an exercise price of $0.42 per share with a fair value of $0.1 million on the date of issuance. The Company incurred debt issuance costs of $0.1 million equal to the fair value of the warrants in connection with the JPM Credit Agreement. These costs were recorded as debt discount and are amortized to interest expense, using the effective interest method, over the term of the loan.

[0001558370-22-004491:notes:248]
As of December 31, 2021, the unamortized debt discount was $0.1 million. As of December 31, 2021, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the consolidated balance sheet. Interest expense totaled $0.6 million for the year ended December 31, 2021, which includes the amortization of the debt discount which totaled less than $0.1 million. The interest rate in effect as of December 31, 2021 was 5.5% and 4.5% for the JPM Credit Agreement and revolving line of credit, respectively. During the year ended December 31, 2021, the Company fully repaid the $5.4 million drawn down on the revolving line of credit.

[0001558370-22-004491:notes:249]
The Company’s obligations under the JPM Credit Agreement are secured by a first-priority security interest in all of its assets, including intellectual property.

[0001558370-22-004491:notes:250]
As of December 31, 2021, future principal payments on long-term debt are as follows (in thousands):

[0001558370-22-004491:notes:251]
| Year Ending December 31, |  | ​ | ​ |
| 2022 | ​ | $ | 2,000 |
| 2023 | ​ |  | 4,000 |
| 2024 | ​ |  | 4,000 |
| ​ | ​ | $ | 10,000 |

[0001558370-22-004491:notes:252]
Convertible Note

[0001558370-22-004491:notes:253]
In September 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) with an investor for gross proceeds of $2.0 million with a stated interest rate of 6.0% per annum. An additional $2.0 million in gross proceeds were made available in December 2020 upon achievement of the integration milestone, whereby the Company successfully created software utilizing the investor’s application programming interface. The 2020 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds of the issuance of preferred stock totaled at least $10.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2020 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $1.0 million, and the notes, with an initial carrying value of $3.0 million, and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the

[0001558370-22-004491:notes:254]
notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the merger.

[0001558370-22-004491:notes:255]
As of December 31, 2021 and 2020, the accrued interest on the 2020 Convertible Notes was $0 and less than $0.1 million, respectively. Interest expense totaled $0.3 million and less than $0.1 million for the years ended December 31, 2021 and 2020, respectively.

[0001558370-22-004491:notes:256]
In January and February 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $7.0 million, and the notes, with an initial carrying value of $23.0 million, and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the merger.

[0001558370-22-004491:notes:257]
In June 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. This modification of the notes resulted in an extinguishment and the Company recognized a loss on extinguishment of the 2021 Convertible Notes of $11.8 million. The $26.7 million carrying value of the notes at June 21, 2021 was derecognized and replacement notes with an initial carrying value of $29.6 million were recorded. Additionally, in the extinguishment accounting, a derivative liability of $19.2 million was recognized, which represents the value of the 1,000,000 NHIC shares as well as a bifurcated embedded derivative for the conversion option.

[0001558370-22-004491:notes:258]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense).

[0001558370-22-004491:notes:259]
As of December 31, 2021, the accrued interest on the 2021 Convertible Notes was $0. Interest expense totaled $4.9 million for the year ended December 31, 2021.


## nhic:TemporaryEquityDisclosureTextBlock

[0001558370-22-004491:notes:260]
10. Convertible Preferred Stock and Preferred Stock

[0001558370-22-004491:notes:261]
Prior to the Merger, Legacy Evolv had issued Series A convertible preferred stock (“Series A Preferred Stock”), Series A-1 convertible preferred stock (“Series A-1 Preferred Stock”), Series B convertible preferred stock (“Series B Preferred Stock”), and Series B-1 convertible preferred stock (“Series B-1 Preferred Stock”), collectively referred to as the “Preferred Stock”.

[0001558370-22-004491:notes:262]
In February and March 2020, Legacy Evolv issued and sold an additional 3,206,390 shares of Series B-1 Preferred Stock at a price of $0.9668 per share for aggregate proceeds of $3.1 million, excluding issuance costs of $0.1 million.

[0001558370-22-004491:notes:263]
Pursuant to the Merger Agreement, immediately prior to the Merger, each share of Legacy Evolv’s Series A-1, Series B-1, and Series B preferred stock outstanding converted to Legacy Evolv common stock on a 1:1 conversion ratio. Pursuant to the Merger Agreement, immediately prior to the Merger, each share of Legacy Evolv’s Series A preferred stock outstanding converted to Legacy Evolv common stock on a 2:1 conversion ratio. On the closing date of the Merger, each share of Legacy Evolv common stock then issued and outstanding was canceled and the holders thereof in exchange received shares of Evolv Technologies Holdings, Inc. equal to 0.378 shares for each share of Legacy Evolv common stock. As of December 31, 2021, the Company has no preferred stock outstanding as all convertible preferred stock converted to common stock upon closing of the Merger. As of December 31, 2020, the Preferred Stock consisted of the following (in thousands, except share amounts):

[0001558370-22-004491:notes:264]
| ​ | ​ | December 31, 2020 |
| ​ |  | ​ |  | Preferred Stock |  | ​ | ​ |  | ​ | ​ |  | Common Stock |
| ​ | ​ | Preferred Stock | ​ | Issued and | ​ | Carrying | ​ | Liquidation | ​ | Issuable Upon |
| ​ | ​ | Authorized | ​ | Outstanding | ​ | Value | ​ | Preference | ​ | Conversion |
| Series A-1 Preferred Stock |  | 67,156,152 | ​ | 24,359,107 | ​ | $ | 18,394 | ​ | $ | 18,000 |  | 24,359,107 |
| Series A Preferred Stock |  | 9,233,677 | ​ | 3,484,240 | ​ |  | 11,321 | ​ |  | 11,819 |  | 6,977,190 |
| Series B-1 Preferred Stock |  | 90,328,396 | ​ | 34,129,398 | ​ |  | 31,953 | ​ |  | 32,997 |  | 34,129,398 |
| Series B Preferred Stock |  | 40,671,814 | ​ | 15,367,312 | ​ |  | 14,209 | ​ |  | 14,284 |  | 15,367,312 |
| ​ |  | 207,390,039 |  | 77,340,057 | ​ | $ | 75,877 | ​ | $ | 77,100 |  | 80,833,007 |

[0001558370-22-004491:notes:265]
As of December 31, 2021, the Company’s amended certificate of incorporation authorized the issuance of 100,000,000 shares of preferred stock at a $0.0001 par value common stock.


## nhic:WarrantsAndRightsNoteDisclosureTextBlock

[0001558370-22-004491:notes:266]
11. Warrants

[0001558370-22-004491:notes:267]
In February 2019, in connection with the 2019 Term Loan Advance, the Company issued a warrant to SVB for the purchase of 28,338 shares of common stock at an exercise price of $0.24 per share (the “2019 SVB common stock warrant”). The 2019 SVB common stock warrant was immediately exercisable and expires in February 2029. The warrant was classified as an equity instrument and recorded at its fair value of less than $0.1 million on the date of issuance through additional paid-in-capital. In connection with the closing of the Merger, all of the outstanding 2019 SVB common stock warrants were converted into shares of the Company’s common stock.

[0001558370-22-004491:notes:268]
In March 2020, in connection with the 2020 Term Loan Advance, the Company issued a warrant to SVB for the purchase of 279,974 shares of common stock at an exercise price of $0.40 per share (the “2020 SVB common stock warrant”). The 2020 SVB common stock warrant was immediately exercisable and expires in March 2030. The warrant was classified as an equity instrument and recorded at its fair value of less than $0.1 million on the date of issuance through additional paid-in-capital. In connection with the closing of the Merger, all of the outstanding 2020 SVB common stock warrants were converted into shares of the Company’s common stock.

[0001558370-22-004491:notes:269]
In December 2020, in connection with the JPM Term Loan, the Company issued a warrant to JPM for the purchase of 377,837 shares of common stock at an exercise price of $0.42 per share (the “2020 JPM common stock warrant”). The 2020 JPM common stock warrant was immediately exercisable and expires in December 2030. The warrant was classified as an equity instrument and recorded at its fair value of $0.1 million on the date of issuance through additional paid-in-capital. In connection with the closing of the Merger, all of the outstanding 2020 JPM common stock warrants were converted into shares of the Company’s common stock.

[0001558370-22-004491:notes:270]
In January 2021, in connection with a Business Development Agreement entered into with Finback Evolv II, LLC (“Finback BDA”), the Company issued a warrant to Finback for the purchase of 2,552,913 shares of common stock at an exercise price of $0.42 per share. The 2021 Finback common stock warrants vest upon meeting certain sales criteria as defined in the agreement and expires in January 2031. The warrants will be accounted for under ASC 718 Compensation – Stock Compensation as the warrants will vest upon certain performance conditions being met (see Note 11). As of December 31, 2021, none of the vested 2021 Finback common stock warrants were exercised.

[0001558370-22-004491:notes:271]
In connection with the closing of the Merger, the Company assumed the Public Warrants for the purchase of 14,325,000 shares of common stock at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and recorded at its fair value of $23.6 million on the date of the closing of the Merger with an offset to additional paid-in-capital and is subsequently remeasured to fair value at each reporting date based on the publicly available trading price. The change in fair value of the public warrant liability of $12.6 million was recognized as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss for the year ended December 31, 2021.

[0001558370-22-004491:notes:272]
As of December 31, 2021 and 2020, warrants to purchase the following classes of Preferred Stock and common stock outstanding consisted of the following in the tables below:

[0001558370-22-004491:notes:273]
| December 31, 2021 |
| ​ | ​ | Contractual | ​ | ​ | ​ | ​ | ​ | Shares Issuable | ​ | Weighted |
| ​ | ​ | Term | ​ | Underlying Equity | ​ | Balance Sheet | ​ | Upon Exercise | ​ | Average |
| Issuance Date |  | (in years) |  | Instrument |  | Classification |  | of Warrant |  | Exercise Price |
| January 13, 2021 |  | 10 |  | Common stock |  | Equity |  | 2,552,913 | ​ | $ | 0.42 |
| July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,994 | ​ | $ | 11.50 |
| ​ | ​ | ​ |  |  |  |  |  | 16,877,907 | ​ |  |  |

[0001558370-22-004491:notes:274]
| December 31, 2020 |
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Shares Issuable | ​ | Weighted |
| ​ | ​ | Contractual | ​ | Underlying Equity | ​ | Balance Sheet | ​ | Upon Exercise of | ​ | Average |
| Issuance Date |  | Term |  | Instrument |  | Classification |  | Warrant |  | Exercise Price |
| ​ | ​ | (in years) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| March 17, 2014 |  | 10 |  | Common stock |  | Liability |  | 94,459 | ​ | $ | 0.24 |
| September 28, 2016 |  | 10 |  | Preferred Stock |  | Temporary Equity |  | 1,014,963 | ​ | $ | 0.003 |
| July 5, 2017 |  | 10 |  | Common stock |  | Equity |  | 141,689 | ​ | $ | 0.24 |
| February 12, 2019 |  | 10 |  | Common stock |  | Equity |  | 28,338 | ​ | $ | 0.24 |
| March 30, 2020 |  | 10 |  | Common stock |  | Equity |  | 279,974 | ​ | $ | 0.40 |
| December 3, 2020 |  | 10 |  | Common stock |  | Equity |  | 377,837 | ​ | $ | 0.42 |
| ​ | ​ | ​ |  |  |  |  |  | 1,937,260 | ​ |  |  |


## nhic:CommonStockDisclosureTextBlock

[0001558370-22-004491:notes:275]
12. Common Stock

[0001558370-22-004491:notes:276]
As of December 31, 2021 and 2020, the Company’s amended certificate of incorporation authorized the issuance of 1,100,000,000 and 305,491,899 shares of $0.0001 par value common stock, respectively.

[0001558370-22-004491:notes:277]
Each share of common stock entitles the holder to one vote on all matters submitted to a vote of the Company’s stockholders. Common stockholders are entitled to receive dividends, as may be declared by the board of directors, subject to the preferential dividend rights of Preferred Stock. As of December 31, 2021 and 2020, no cash dividends had been declared or paid.

[0001558370-22-004491:notes:278]
On the closing of the Merger, the total 10,391,513 of the NHIC ordinary shares held by the NHIC Initial Shareholders and public shareholders were converted into the same number of the Company’s common stock.

[0001558370-22-004491:notes:279]
On July 16, 2021 and prior to the closing of the Merger, various PIPE investors purchased 30,000,000 shares of the Company’s common stock at a price of $10.00 per share for gross proceeds of $300.0 million.

[0001558370-22-004491:notes:280]
As of December 31, 2021 and 2020, the Company had reserved 75,724,481 and 103,712,932 shares, respectively, of common stock for the conversion of the outstanding Preferred Stock, exercise of outstanding stock options, granting of awards under the Company’s 2021 Equity Incentive Plan and 2013 Equity Incentive Plan (see Note 13) and the exercise of outstanding warrants (including warrants to purchase Preferred Stock as if converted to common stock) (see Note 11).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001558370-22-004491:notes:281]
13. Stock-Based Compensation

[0001558370-22-004491:notes:282]
2013 Equity Incentive Plan

[0001558370-22-004491:notes:283]
The Company’s 2013 Equity Incentive Plan (the “2013 Plan”) provides for the Company to grant incentive stock options or nonqualified stock options, restricted stock awards and other stock-based awards to employees, officers, directors and non-employees of the Company. Per the initial terms of the 2013 Plan, up to 1,077,704 shares of common stock may be issued.

[0001558370-22-004491:notes:284]
At December 31, 2021 and 2020, shares of common stock that may be issued under the 2013 Plan were 0 and 21,478,603, respectively. As of December 31, 2021 and 2020, 0 shares and 979,429 shares, respectively, remained available for future grant under the 2013 Plan. Shares that are expired, forfeited, canceled or otherwise terminated without having been fully exercised will be available for future grant under the 2013 Plan. In addition, shares of common stock that are tendered to the Company by a participant to exercise an award are added to the number of shares of common stock available for future grants.

[0001558370-22-004491:notes:285]
The 2013 Plan is administered by the Board of Directors or, at the discretion of the Board of Directors, by a committee of the Board of Directors. The exercise prices, vesting and other restrictions are determined at the discretion of the Board of Directors, or its committee if so delegated, except that the exercise price per share of stock options may not be less than 100% of the fair market value of a share of common stock on the date of grant and the term of the stock option may not be greater than ten years. Stock options granted to employees, officers, members of the Board of Directors and non-employees typically vest over a four-year period. The Company’s Board of Directors values the Company’s common stock, taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors which may have changed since the date of the most recent contemporaneous valuation through the date of grant.

[0001558370-22-004491:notes:286]
2021 Equity Incentive Plan

[0001558370-22-004491:notes:287]
The Company’s 2021 Equity Incentive Plan (the “2021 Plan”) provides for the Company to grant incentive stock options or nonqualified stock options, restricted stock awards and other stock-based awards to employees, officers, directors and non-employees of the Company. Per the initial terms of the 2021 Plan, up to 21,177,295 shares of common stock may be issued.

[0001558370-22-004491:notes:288]
At December 31, 2021, shares of common stock that may be issued under the 2021 Plan were 21,177,295. As of December 31, 2021, 19,511,916 shares remained available for future grant under the 2021 Plan. Shares that are expired, forfeited, canceled or otherwise terminated without having been fully exercised will be available for future grant under the 2021 Plan. In addition, shares of common stock that are tendered to the Company by a participant to exercise an award are added to the number of shares of common stock available for future grants.

[0001558370-22-004491:notes:289]
The 2021 Plan is administered by the Board of Directors or, at the discretion of the Board of Directors, by a committee of the Board of Directors. The exercise prices, vesting and other restrictions are determined at the discretion of the Board of Directors, or its committee if so delegated, except that the exercise price per share of stock options may not be less than 100% of the fair market value of a share of common stock on the date of grant and the term of the stock option may not be greater than ten years. Stock options granted to employees, officers, members of the Board of Directors and

[0001558370-22-004491:notes:290]
non-employees vesting terms are determined on an individual basis on the date of grant. Prior to the closing of the Merger, the Company’s Board of Directors valued the Company’s common stock, taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors which may have changed since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the Board of Directors determined the fair value of each share of common stock underlying stock-based awards based on the closing price of our common stock as reported by Nasdaq on the date of grant.

[0001558370-22-004491:notes:291]
2021 Employee Stock Purchase Plan

[0001558370-22-004491:notes:292]
In July 2021, the Company’s Board of Directors adopted the 2021 Employee Stock Purchase Plan (“2021 ESPP”), which was subsequently approved by the Company’s stockholders and became effective on July 16, 2021. The 2021 ESPP authorizes the initial issuance of up to 3,435,748 shares of the Company’s common stock to eligible employees of the Company or, as designated by the Company’s Board of Directors, employees of a related company. The 2021 ESPP provides that the number of shares reserved and available for issuance under the 2021 ESPP will automatically increase each January 1, beginning on January 1, 2022 and ending on (and including) January 1, 2032, by an amount equal to the lesser of (i) 1% of the outstanding number of shares of common stock on the immediately preceding December 31 and (ii) 3,435,748 or such lesser number of shares as determined by the Company’s Board of Directors. As of December 31, 2021, 3,435,748 shares of the Company’s common stock were available for future issuance. The Company’s Board of Directors may from time to time grant or provide for the grant to eligible employees of options to purchase common stock under the 2021 ESPP during a specific offering period. As of December 31, 2021, no offerings have been approved.

[0001558370-22-004491:notes:293]
During the year ended December 31, 2021, the Company granted 6,472,725 options.

[0001558370-22-004491:notes:294]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted:

[0001558370-22-004491:notes:295]
| ​ | ​ | Year Ended December 31, |  |
| ​ |  | 2021 |  | 2020 |  |
| Risk-free interest rate |  | 0.7 | % | 0.4 | % |
| Expected term (in years) |  | 6.0 | ​ | 5.7 | ​ |
| Expected volatility |  | 31.4 | % | 31.4 | % |
| Expected dividend yield |  | 0.0 | % | 0.0 | % |

[0001558370-22-004491:notes:296]
The following tables summarize the Company’s stock option activity since December 31, 2020 (in thousands, except for share and per share data):

[0001558370-22-004491:notes:297]
| ​ |  | ​ |  | ​ | ​ |  | Weighted |  | ​ | ​ |
| ​ | ​ | ​ | ​ | Weighted | ​ | Average | ​ | ​ | ​ |
| ​ | ​ | Number of | ​ | Average | ​ | Remaining | ​ | Aggregate |
| ​ | ​ | Shares | ​ | Exercise Price | ​ | Contractual Term | ​ | Intrinsic Value |
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | (in years) | ​ | ​ | ​ |
| Outstanding as of December 31, 2020 | ​ | 18,770,767 | ​ | $ | 0.36 | ​ | ​ | ​ | ​ | ​ |
| Granted |  | 6,472,725 |  | ​ | 0.42 |  | ​ |  | ​ | ​ |
| Exercised |  | (2,806,961) |  | ​ | 0.33 | ​ | ​ |  | ​ | ​ |
| Exercised upon settlement of related party note | ​ | (1,469,366) | ​ | ​ | 0.24 | ​ | ​ | ​ | ​ | ​ |
| Forfeited | ​ | (198,035) |  | ​ | 0.37 |  | ​ |  | ​ | ​ |
| Outstanding as of December 31, 2021 |  | 20,769,130 | ​ | ​ | 0.39 |  | 8.00 | ​ | $ | 84,430 |
| Vested and expected to vest as of December 31, 2021 |  | 20,769,130 | ​ | $ | 0.39 |  | 8.00 | ​ | $ | 84,430 |
| Options exercisable as of December 31, 2021 |  | 10,849,885 | ​ | $ | 0.37 |  | 7.33 | ​ | $ | 44,353 |

[0001558370-22-004491:notes:298]
The aggregate intrinsic value of options is calculated as the difference between the exercise price of the stock options and the fair value of the Company’s common stock for those options that had exercise prices lower than the fair value of the Company’s common stock.

[0001558370-22-004491:notes:299]
Restricted Stock Units

[0001558370-22-004491:notes:300]
The following table summarizes the Company’s restricted stock units activity since December 31, 2020 (in thousands, except for share and per share data):

[0001558370-22-004491:notes:301]
| ​ | ​ | Number of | ​ | Grant Date Fair |
| ​ | ​ | Shares | ​ | Value |
| Outstanding as of December 31, 2020 | ​ | — | ​ | ​ | — |
| Granted |  | 2,013,110 |  | $ | 6.76 |
| Vested |  | (2,625) |  | ​ | 7.01 |
| Canceled |  | (58,561) |  | ​ | 7.01 |
| Outstanding as of December 31, 2021 |  | 1,951,924 | ​ | $ | 6.76 |

[0001558370-22-004491:notes:302]
In March 2021, the Company issued 289,047 shares of restricted stock units at a grant date fair value of $8.04 under the 2013 Plan. In September 2021, the Company issued 751,914 shares of restricted stock units at a grant date fair value of $7.01 under the 2021 Plan. In October 2021, the Company issued 72,500 shares of restricted stock units at a grant date fair value of $5.53 under the 2021 Plan. In November 2021, the Company issued 677,966 shares of restricted stock units at a grant date fair value of $6.49 under the 2021 Plan. In December 2021, the Company issued 125,530 and 96,153 shares of restricted stock units at grant date fair values of $5.52 and $5.46 under the 2021 Plan. The terms of the RSU’s under the 2021 Plan allow for the following vesting periods, which are determined on an individual basis on the date of grant.

[0001558370-22-004491:notes:303]
(A) The restricted stock units will vest over four years from the Vesting Commencement Date, with 25% of the restricted stock units vesting on the first anniversary of the Vesting Commencement Date and the remaining restricted stock units vesting quarterly thereafter over the remaining three years, subject to the individual remaining a Service Provider (as defined in the 2021 Plan) through the applicable vesting date.

[0001558370-22-004491:notes:304]
(B) The restricted stock units will vest over three years from the Vesting Commencement Date, with one third of the restricted stock units vesting on the first anniversary of the Vesting Commencement Date and the remaining restricted stock units vesting annually thereafter over the remaining two years, subject to the individual remaining a Service Provider (as defined in the 2021 Plan) through the applicable vesting date.

[0001558370-22-004491:notes:305]
Warrants to Non-Employee Service Provider

[0001558370-22-004491:notes:306]
In January 2021, in connection with a Business Development Agreement entered into with Finback Evolv II, LLC, the Company issued a warrant to Finback for the purchase of 2,552,913 shares of common stock at an exercise price of $0.42 per share. The 2021 Finback common stock warrants vest upon meeting certain sales criteria as defined in the agreement and expires in January 2031. The warrants will be accounted for under ASC 718 Compensation – Stock Compensation as the warrants will vest upon certain performance conditions being met.

[0001558370-22-004491:notes:307]
The Company utilized a Black-Scholes pricing model to determine the grant-date fair value of the 2021 Finback common stock warrants granted. The assumptions used are presented in the following table:

[0001558370-22-004491:notes:308]
| Warrants - Black Scholes |  | ​ | ​ |
| Risk-free interest rate |  | 0.4 | % |
| Expected term (in years) |  | 3.00 | ​ |
| Expected volatility |  | 23.9 | % |
| Expected dividend yield |  | 0.0 | % |

[0001558370-22-004491:notes:309]
On the date of issuance, the total value of the 2021 Finback common stock warrants were valued as $19.5 million.

[0001558370-22-004491:notes:310]
As of December 31, 2021, 283,896 shares of the 2021 Finback common stock warrants were exercisable at a total aggregate intrinsic value of $2.2 million. The remaining 2,269,017 shares of the 2021 Finback common stock warrants are unvested and have a total aggregate intrinsic value of $17.3 million. As of December 31, 2021, none of the 2021 Finback common stock warrants were exercised. The Company will recognize compensation expense for the 2021 Finback common stock warrants when the warrants become vested based on meeting the certain sales criteria. During the year ended December 31, 2021, the Company recorded $2.2 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.

[0001558370-22-004491:notes:311]
Stock-based compensation expense was classified in the consolidated statements of operations and comprehensive loss as follows (in thousands):

[0001558370-22-004491:notes:312]
| ​ | ​ | Year Ended December 31, |
| ​ | ​ | 2021 |  | 2020 |
| Cost of revenue | ​ | $ | 58 | ​ | $ | 10 |
| Sales and marketing | ​ |  | 4,682 | ​ |  | 104 |
| General and administrative | ​ |  | 2,840 | ​ |  | 370 |
| Research and development | ​ |  | 931 | ​ |  | 178 |
| Total stock-based compensation expense | ​ | $ | 8,511 | ​ | $ | 662 |

[0001558370-22-004491:notes:313]
Stock-based compensation expense was classified by award type in the consolidated statements of operations and comprehensive loss as follows (in thousands):

[0001558370-22-004491:notes:314]
| ​ | ​ | ​ | Year Ended December 31, |
| ​ | ​ | ​ | 2021 | ​ | 2020 |
| Stock options | ​ | $ | 644 | ​ | $ | 662 |
| Earn-out shares | ​ | ​ | 4,338 | ​ | ​ | — |
| Warrants | ​ | ​ | 2,165 | ​ | ​ | — |
| Restricted stock units | ​ | ​ | 1,364 | ​ | ​ | — |
| Total stock-based compensation expense | ​ | $ | 8,511 | ​ | $ | 662 |

[0001558370-22-004491:notes:315]
Total unrecognized compensation expense related to unvested stock options and unvested restricted stock units as of December 31, 2021, was $13.1 million, which is expected to be recognized over a weighted average period of 1.7 years. Total unrecognized compensation expense related to earn-out shares associated with the share-based compensation arrangement as of December 31, 2021, was $11.5 million, which is expected to be recognized over a weighted average period of 1.5 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001558370-22-004491:notes:316]
14. Income Taxes

[0001558370-22-004491:notes:317]
The components of the Company’s loss before income tax expense are as follows (in thousands):

[0001558370-22-004491:notes:318]
| ​ | ​ | Year Ended December 31, |
| ​ |  | 2021 |  | 2020 |
| United States | ​ | $ | (10,400) | ​ | $ | (27,066) |
| Foreign | ​ |  | (458) | ​ |  | (326) |
| Loss before income tax provision | ​ | $ | (10,858) | ​ | $ | (27,392) |

[0001558370-22-004491:notes:319]
There is no provision for income taxes for the years ended December 31, 2021 and 2020 because the Company has historically incurred net operating losses and maintains a full valuation allowance against its deferred tax assets.

[0001558370-22-004491:notes:320]
The effective tax rate differs from the U.S. federal statutory rate primarily due to the full valuation allowance maintained on the Company’s net deferred tax assets for the years ended December 31, 2021 and 2020 and as a result of non-deductible items for the year ended December 31, 2021 related to the closing of the Merger. A reconciliation of the U.S. federal statutory income tax rate to the Company’s effective income tax rate is as follows:

[0001558370-22-004491:notes:321]
| ​ | ​ | Year Ended December 31, | ​ |
| ​ |  | 2021 | ​ |  | 2020 |  |
| Federal statutory income tax rate |  | 21.0 | % | ​ | 21.0 | % |
| State income taxes, net of federal benefit |  | 18.8 | ​ |  | 3.9 | ​ |
| Federal and state research and development tax credits |  | 9.7 | ​ |  | 7.3 | ​ |
| Loss on extinguishment of debt | ​ | (24.5) | ​ | ​ | — | ​ |
| Merger transaction costs | ​ | (1.3) | ​ | ​ | — | ​ |
| Change in fair value of contingent earn-out liability and contingently issuable common stock liability | ​ | 124.5 | ​ | ​ | — | ​ |
| Change in fair value of derivative liability | ​ | (3.4) | ​ | ​ | — | ​ |
| Non-deductible convertible notes interest | ​ | (10.2) | ​ | ​ | — | ​ |
| Change in valuation allowance |  | (138.1) | ​ |  | (33.7) | ​ |
| Change in tax rate |  | (0.5) | ​ |  | 1.3 | ​ |
| Stock-based compensation | ​ | 4.3 | ​ | ​ | — | ​ |
| Permanent differences |  | (0.4) | ​ |  | (0.3) | ​ |
| Other |  | 0.1 | ​ |  | 0.5 | ​ |
| Effective income tax rate |  | (0.0) | % | ​ | (0.0) | % |

[0001558370-22-004491:notes:322]
Net deferred tax assets consisted of the following (in thousands):

[0001558370-22-004491:notes:323]
| ​ | ​ | December 31, |
| ​ |  | 2021 |  | 2020 |
| Deferred tax assets: |  | ​ |  |  | ​ |  |
| Net operating loss carryforwards | ​ | $ | 25,357 | ​ | $ | 13,996 |
| Research and development tax credit carryforwards | ​ |  | 4,910 | ​ |  | 3,857 |
| Capitalized research and development costs | ​ |  | 8,473 | ​ |  | 7,274 |
| Accrued expenses | ​ |  | 3,211 | ​ |  | 334 |
| Deferred revenue | ​ |  | 2,293 | ​ |  | 1,049 |
| Other | ​ |  | 43 | ​ |  | 304 |
| Total deferred tax assets | ​ |  | 44,287 | ​ |  | 26,814 |
| Valuation allowance | ​ |  | (43,407) | ​ |  | (26,005) |
| Total deferred tax assets, net of valuation allowance | ​ |  | 880 | ​ |  | 809 |
| Deferred tax liabilities: | ​ |  |  | ​ |  |  |
| Depreciation and amortization | ​ |  | (864) | ​ |  | (542) |

[0001558370-22-004491:notes:324]
| Other | ​ |  | (16) | ​ |  | (267) |
| Total deferred tax liabilities | ​ |  | (880) | ​ |  | (809) |
| Net deferred tax assets | ​ | $ | — | ​ | $ | — |

[0001558370-22-004491:notes:325]
As of December 31, 2021 and December 31, 2020, the Company had gross federal net operating losses of $20.1 million and $20.1 million that are subject to expire at various dates through 2033 and 2033, respectively, and federal net operating losses of $79.3 million and $33.9 million, which have no expiration date and can be used to offset up to 80% of future taxable income in any one tax period, respectively. The Company also had gross state net operating loss carryforwards of $75.3 million and $42.6 million for the years ended December 31, 2021 and 2020, respectively, which may be available to offset future state taxable income and which begin to expire in 2033 and 2033, respectively. Additional gross net operating loss carryforwards of approximately $1.5 million are available in the United Kingdom and will not expire. As of December 31, 2021, the Company had gross U.S. federal and state research and development and other tax credit carryforwards of $3.3 million and $2.1 million, respectively, which may be available to offset future tax liabilities and the majority of which begin to expire in 2033 and 2028, respectively. As of December 31, 2020, the Company had gross U.S. federal and state research and development and other tax credit carryforwards of $2.5 million and $1.7 million, respectively, which may be available to offset future tax liabilities and the majority of which begin to expire in 2033 and 2028, respectively.

[0001558370-22-004491:notes:326]
Utilization of the U.S. federal and state net operating loss carryforwards and research and development tax credit carryforwards may be subject to a substantial annual limitation under Sections 382 and 383 of the Internal Revenue Code of 1986, and corresponding provisions of state law, due to ownership changes that have occurred previously or that could occur in the future. These ownership changes may limit the amount of carryforwards that can be utilized annually to offset future taxable income or tax liabilities. In general, an ownership change, as defined by Section 382, results from transactions increasing the ownership of certain stockholders or public groups in the stock of a corporation by more than 50% over a three-year period. The Company has not conducted a study to assess whether a change of control has occurred or whether there have been multiple changes of control since inception due to the significant complexity and cost associated with such a study. If the Company has experienced a change of control, as defined by Section 382, at any time since inception, utilization of the net operating loss carryforwards or research and development tax credit carryforwards would be subject to an annual limitation under Section 382, which is determined by first multiplying the value of the Company’s stock at the time of the ownership change by the applicable long-term tax-exempt rate, and then could be subject to additional adjustments, as required. Any limitation may result in expiration of a portion of the net operating loss carryforwards or research and development tax credit carryforwards before utilization. Further, until a study is completed by the Company and any limitation is known, no amounts are being presented as an uncertain tax position.

[0001558370-22-004491:notes:327]
The Company considered the significant negative evidence of its history of cumulative net operating losses incurred since inception, as well as other positive and negative evidence bearing upon its ability to realize the deferred tax assets, and has concluded that it is more likely than not that the Company will not realize the benefits of the deferred tax assets. Accordingly, a full valuation allowance has been established against the net deferred tax assets as of December 31, 2021 and 2020. If or when recognized, the tax benefits related to any reversal of the valuation allowance on deferred tax assets as of December 31, 2021, will be accounted for as follows: approximately $41.2 million will be recognized as a reduction of income tax expense and $2.2 million will be recorded as an increase in equity. The Company reevaluates the positive and negative evidence at each reporting period.

[0001558370-22-004491:notes:328]
Changes in the valuation allowance for deferred tax assets related primarily to the increase in net operating loss carryforwards, research and development tax credit carryforwards, and capitalized R&D costs and were as follows (in thousands):

[0001558370-22-004491:notes:329]
| ​ | ​ | December 31, |
| ​ |  | 2021 |  | 2020 |
| Valuation allowance as of beginning of year |  | $ | 26,005 | ​ | $ | 16,767 |
| Additions charged to provision for income taxes | ​ |  | 15,245 | ​ |  | 9,233 |
| Additions charged to equity | ​ | ​ | 2,155 | ​ | ​ | — |
| Currency translation and other | ​ |  | 2 | ​ |  | 5 |
| Valuation allowance as of end of year | ​ | $ | 43,407 | ​ | $ | 26,005 |

[0001558370-22-004491:notes:330]
As of December 31, 2021 and 2020, the Company had not recorded any amounts for unrecognized tax benefits. The Company’s policy is to record interest and penalties related to income taxes as part of its income tax provision. As of December 31, 2021 and 2020, the Company had no accrued interest or penalties related to uncertain tax positions and no amounts had been recognized in the Company’s consolidated statements of operations and comprehensive loss. The Company files income tax returns as prescribed by the tax laws of the jurisdictions in which it operates. In the normal course of business, the Company is subject to examination by federal, state and non-US jurisdictions, where applicable. The Company is open to future tax examinations in the US under statute from 2018 to the present; however, carryforward attributes that were generated prior to 2018 may still be adjusted upon examination by federal, state, or local tax authorities if they either have been or will be used in a future period. The Company is also open for future tax examinations under statute from 2019 to the present in the UK. The Company has not received notice of examination in any jurisdictions for any tax year open under statute.


## us-gaap:EarningsPerShareTextBlock

[0001558370-22-004491:notes:331]
15. Net Loss per Share

[0001558370-22-004491:notes:332]
Basic and diluted net loss per share attributable to common stockholders was calculated as follows (in thousands, except share and per share amounts):

[0001558370-22-004491:notes:333]
| ​ | ​ | Year Ended December 31, |
| ​ |  | 2021 |  | 2020 |
| Numerator: | ​ | ​ |  |  | ​ |  |
| Net loss attributable to common stockholders – basic and diluted | ​ | $ | (10,858) | ​ | $ | (27,392) |
| Denominator: | ​ |  | ​ | ​ |  | ​ |
| Weighted average common shares outstanding — basic and diluted | ​ | ​ | 71,662,694 | ​ | ​ | 8,932,404 |
| Net loss per share attributable to common stockholders - basic diluted | ​ | $ | (0.15) | ​ | $ | (3.07) |

[0001558370-22-004491:notes:334]
The following potentially dilutive outstanding securities were excluded from the computation of diluted net loss per share attributable to common stockholders because their effect would have been anti-dilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the period:

[0001558370-22-004491:notes:335]
| ​ | ​ | Year Ended December 31, | ​ |
| ​ |  | 2021 |  | 2020 |  |
| Options issued and outstanding | ​ | 20,769,130 | ​ | 18,770,767 | ​ |
| Public Warrants to purchase common stock | ​ | 14,324,994 | ​ | — | ​ |
| Convertible preferred stock (as converted to common stock) | ​ | — | ​ | 80,833,007 | ​ |
| Warrants to purchase preferred stock (as converted to warrants to purchase common stock) | ​ | — | ​ | 1,014,963 | ​ |
| Warrants to purchase common stock | ​ | — | ​ | 922,297 | ​ |
| Warrants to purchase common stock (Finback)** | ​ | 2,269,017 | ​ | — | ​ |
| Unvested restricted stock units | ​ | 1,951,924 | ​ | — | ​ |
| Earn-out shares** | ​ | 15,000,000 | ​ | — | ​ |
| Contingently issuable common stock** | ​ | 1,897,500 | ​ | — | ​ |
| Convertible notes (as converted to common stock)* | ​ | — | ​ | 1,192,469 | ​ |
| ​ | ​ | 56,212,565 |  | 102,733,503 | ​ |

[0001558370-22-004491:notes:336]
* Conversion feature is only triggered upon the closing of a Qualified Financing Event.

[0001558370-22-004491:notes:337]
** Issuance of Earn-out shares, Contingently issuable common stock and Finback warrants are contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001558370-22-004491:notes:338]
16. Related Party Transactions

[0001558370-22-004491:notes:339]
Nonrecourse Promissory Note with Officer

[0001558370-22-004491:notes:340]
In August 2020, the Company entered into a $0.4 million promissory note with an officer with the proceeds being used to exercise options for 1,469,366 shares of common stock at a price of $0.24 per share. The promissory note bore interest at the Wall Street Journal Prime Rate and was secured by the underlying shares of common stock that were issued upon the exercise of the stock options. The promissory note was treated as nonrecourse as the loan was only secured by the common stock issued from the exercise of the stock options. As such, (i) the underlying stock option grant was still considered to be outstanding and the shares of common stock were not considered issued and outstanding for accounting purposes until the loan was repaid in full or otherwise forgiven and (ii) no receivable was recorded for the promissory note on the Company’s consolidated balance sheets. As such, the promissory note effectively extended the maturity date of the option grant for the life of the loan, this change is treated as a stock option modification. The incremental fair value from the stock option modification was deemed immaterial. The interest on this nonrecourse loan is also considered nonrecourse. As the Company has no intent to collect interest, no accrued interest was recorded.

[0001558370-22-004491:notes:341]
In June 2021, the Company agreed to repurchase 43,665 shares of common stock valued at $8.05 per share of common stock held by the officer of the Company. In exchange for the repurchase of the common stock by the Company, the $0.4 million promissory note held by the officer was considered repaid in full.

[0001558370-22-004491:notes:342]
Business Development Agreement with Finback

[0001558370-22-004491:notes:343]
In March 2021, the Company granted a warrant exercisable for 2,552,913 shares of common stock to Finback, a consulting group who is an affiliate of one of the Company’s shareholders, with performance-based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years. During the year ended December 31, 2021, the Company recorded $2.2 million of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.

[0001558370-22-004491:notes:344]
In connection with the Merger and pursuant to the Merger Agreement, Finback is entitled to receive a proportional share of earn-out shares as an earn-out service provider, based upon the remaining unvested warrants as of the Merger Date. As of December 31, 2021 Finback can earn 280,410 earn-out shares subject to stock-based compensation, based on the achievement of certain milestones (See Note 1). During the year ended December 31, 2021, the Company recorded $0.4 million of stock-based compensation expense within sales and marketing expense for the earn-out shares allocated to Finback.

[0001558370-22-004491:notes:345]
Original Equipment Manufacturer Partnership Agreement with Motorola

[0001558370-22-004491:notes:346]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement (the “Distribution Agreement”) with Motorola, an investor in the Company. In June 2021, the partnership agreement was amended by the Amended and Restated Distribution Agreement (the “Amended and Restated Distribution Agreement”). Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products.  During the year ended December 31, 2021 and 2020, revenue from Motorola’s distributor services was $0.6 million and $0, respectively. As of December 31, 2021 and 2020, accounts receivable related to Motorola’s distributor services was $1.2 million and $0, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001558370-22-004491:notes:347]
17. Commitments and Contingencies

[0001558370-22-004491:notes:348]
Operating Leases

[0001558370-22-004491:notes:349]
The Company entered into a new lease agreement for additional office space starting May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. The Company is required to maintain a minimum cash balance of $0.7 million as a security deposit on the space which is classified as restricted cash, current and restricted cash, non-current on the consolidated balance sheet as of December 31, 2021. The Company is generally obligated for the cost of property taxes, insurance, and maintenance relating to this lease.

[0001558370-22-004491:notes:350]
Total future minimum lease payments under this noncancelable operating lease amount to $3.2 million. Rent expense for the years ended December 31, 2021 and 2020 was approximately $0.9 million and $0.4 million, respectively.

[0001558370-22-004491:notes:351]
Future minimum rental commitments to be paid by the Company at December 31, 2021 for this lease is as follows (in thousands):

[0001558370-22-004491:notes:352]
| Year Ending December 31: | ​ |  | ​ |
| 2022 | ​ | $ | 1,116 |
| 2023 | ​ |  | 1,150 |
| 2024 | ​ |  | 981 |
| Total future minimum lease payments | ​ | $ | 3,247 |

[0001558370-22-004491:notes:353]
Indemnification Agreements

[0001558370-22-004491:notes:354]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The

[0001558370-22-004491:notes:355]
Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its consolidated financial statements as of December 31, 2021 or 2020.

[0001558370-22-004491:notes:356]
Legal Proceedings

[0001558370-22-004491:notes:357]
The Company is not a party to any litigation and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001558370-22-004491:notes:358]
18. Benefit Plans

[0001558370-22-004491:notes:359]
The Company established a defined contribution savings plan under Section 401(k) of the Code. This plan covers all employees who meet minimum age and service requirements and allows participants to defer a portion of their annual compensation on a pre-tax basis. Matching contributions to the plan may be made at the discretion of the Company’s board of directors. The Company did not make contributions to the plan during the years ended December 31, 2021 or 2020.


## us-gaap:SubsequentEventsTextBlock

[0001558370-22-004491:notes:360]
19.   Subsequent Events

[0001558370-22-004491:notes:361]
In January, February, and March 2022, the Company granted an aggregate of 4,425,142 of restricted stock units to officers, directors, and employees of the Company. The aggregate grant-date fair value of the restricted stock units granted is $15.5 million, which is expected to be recognized as stock-based compensation expense over a period of 4.0 years. Additionally, in March 2022, the Company granted an aggregate of 934,000 performance stock units to officers, directors, and employees of the Company. Based upon the terms of the award agreements, 50% of the applicable units shall vest on January 1, 2023, provided that the Company has achieved its annual bookings goal for fiscal year 2022; and the remaining 50% of the units shall vest on January 1, 2024 if and only if the bookings goal was achieved and subject to the grantee’s continued service through the applicable vesting date.

[0001558370-22-004491:notes:362]
In March 2022, the Company granted an aggregate of 2,262,925 options to officers of the Company, at an exercise price of $2.32. The aggregate grant-date fair value of the options granted is $5.2 million, which is expected to be recognized as stock-based compensation expense over a  period of 4.0 years.
