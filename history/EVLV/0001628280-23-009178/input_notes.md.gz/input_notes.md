# EVLV notes — 0001628280-23-009178


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-23-009178:notes:1]
Certain portions of the information required to be furnished pursuant to Part III of this Annual Report on Form 10-K will be set forth in, and incorporated by reference from, the registrant’s definitive proxy statement for the annual meeting of stockholders which will be filed with the Securities and Exchange Commission no later than 120 days after the end of the fiscal year ended December 31, 2022.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-23-009178:notes:2]
Nature of the Business and Basis of Presentation
Evolv Technologies Holdings, Inc. (the “Company”), a Delaware corporation, is a global leader in AI-based weapons detection for security screening. The Company’s mission is to make the world a safer and more enjoyable place to work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to address the chronic epidemic of escalating gun violence, mass shootings and terrorist attacks in a cost-effective manner while improving the visitor experience. The Company is headquartered in Waltham, Massachusetts.

[0001628280-23-009178:notes:3]
As used in this Annual Report on Form 10-K, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC. References to “NHIC” refer to the company prior to the consummation of the Merger (as defined in Note 3) and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001628280-23-009178:notes:4]
Risks and uncertainties

[0001628280-23-009178:notes:5]
The Company is subject to risks and uncertainties common to early-stage companies in the human security industry including, but not limited to, the successful development, commercialization, marketing and sale of existing and new products, market fluctuations and the impact on operating results and financial risks, protection of proprietary knowledge and patent risks, dependence on key personnel, competition, technological challenges, cybersecurity risks, customer demand, and management of growth. Potential risks and uncertainties also include, without limitation, uncertainties regarding the duration and magnitude of the impact of the COVID-19 pandemic, including variants, on the Company’s business and the economy in general.

[0001628280-23-009178:notes:6]
COVID-19 has, and may continue to, disrupt third-party contract manufacturer and supply chain. We may also experience customer payment delays for our products which could negatively impact our results of operations. We may also experience some delays in installation of our products at customers’ facilities, which could lead to postponed revenue recognition for those transactions. We have experienced supply chain challenges due to the COVID-19 pandemic. The long-term effects of COVID-19 on the global economy and on us are difficult to assess or predict and may include a further decline in the market prices of our products, risks to employee health and safety, risks for the deployment of our products and services, and reduced sales in geographic locations impacted.

[0001628280-23-009178:notes:7]
Basis of presentation

[0001628280-23-009178:notes:8]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001628280-23-009178:notes:9]
All share and per share amounts contained herein for periods prior to the Merger have been retroactively adjusted to give effect to the Exchange Ratio (as defined in Note 3), unless otherwise indicated.

[0001628280-23-009178:notes:10]
Revision of Prior Period Financial Statements

[0001628280-23-009178:notes:11]
In preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified errors in its previously issued financial statements whereby (a) certain expenses that were cost of subscription revenue related and cost of service revenue related were inaccurately classified as sales and marketing expenses on the consolidated statements of operations and comprehensive loss, (b) certain equipment under lease or held for lease was inaccurately classified as inventory on the consolidated balance sheets and a portion of the cash outflows related to the equipment under lease or held for lease were misclassified between operating and investing cash flows on the consolidated statements of cash flows, and (c) the vesting of warrants related to the Business Development Agreement disclosed in Note 16 were not accounted for accurately. The identified errors impacted the Company's previously issued 
2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022. The Company has made adjustments to the prior period amounts presented in these financial statements accordingly. Additionally, the Company has made adjustments to correct for other previously identified immaterial errors. The Company evaluated the errors and determined that the related impacts were not material to any previously issued annual or interim financial statements. The impact of the revisions to the quarterly periods ending June 30, 2021 and September 30, 2021 are presented in the Company's Quarterly Reports on Form 10-Q for the periods ending June 30, 2022 and September 30, 2022, respectively. The impacts of the revisions to the periods presented in this Annual Report on Form 10-K are included in Note 21. The impact of the revisions to the quarterly periods ending March 31, 2022 and March 31, 2021 are presented in Note 22.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-23-009178:notes:12]
Summary of Significant Accounting Policies
Use of Estimates

[0001628280-23-009178:notes:13]
The preparation of the Company’s consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the reporting periods. Significant estimates and assumptions reflected in these consolidated financial statements include but are not limited to calculating the standalone selling price for revenue recognition, the valuation of inventory, the accrual of sales tax contingencies, the expensing and capitalization of costs associated with internal-use software, stock-based awards, the valuation of the contingent earn-out liability, the valuation of the contingently issuable common stock, the valuation of common stock for the periods prior to the Company listing its shares on Nasdaq, the valuation of the derivative liability, the valuation of the common stock warrant liability and the valuation of the preferred stock warrant liability. The Company bases its estimates on historical experience, known trends and other market-specific or other relevant factors that it believes to be reasonable under the circumstances. On an ongoing basis, management evaluates its estimates when there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results could differ from those estimates.

[0001628280-23-009178:notes:14]
Risk of Concentrations of Credit, Significant Customers and Significant Suppliers

[0001628280-23-009178:notes:15]
Financial instruments that potentially expose the Company to concentrations of credit risk consist primarily of cash equivalents, restricted cash, and accounts receivable, net. We maintain substantially all of our cash and cash equivalents with U.S. and multi-national financial institutions, including Silicon Valley Bank ("SVB"), and our deposits at these institutions are in excess of the Federal Deposit Insurance Corporation ("FDIC") insurance limit. On March 10, 2023, SVB was closed by the California Department of Financial Protection and Innovation, which appointed the FDIC as receiver. The FDIC created a successor bridge bank, Silicon Valley Bridge Bank, N.A. (“SVBB”), and all deposits of SVB were transferred to SVBB under a systemic risk exception approved by the Federal Reserve, the U.S. Treasury Department, and the FDIC. While the Federal Reserve, the U.S. Treasury Department, and the FDIC announced in a joint statement on March 12, 2023 that all SVB deposits, including both insured and uninsured amounts, would be available in full to account holders, a similar failure of a depository institution could impact access to our cash and cash equivalents and could adversely impact our operating liquidity and financial performance. Other than cash and cash equivalents held at SVB, the Company maintains its cash, cash equivalents and restricted cash with financial institutions that management believes to be of high credit quality.

[0001628280-23-009178:notes:16]
Significant customers are those which represent more than 10% of the Company’s total revenue or accounts receivable, net balance at each respective balance sheet date. No single customer represented more than 10% of the Company's total revenue for the year ended December 31, 2021. The following table presents customers that represent 10%

[0001628280-23-009178:notes:17]
or more of the Company’s total revenue for the year ended December 31, 2022. Both customers shown are channel partners of the Company.

[0001628280-23-009178:notes:18]
|  | Year Ended December 31, 2022 |
| Motorola Solutions, Inc. | 20.9 | % |
| Customer A | 10.1 | % |
|  | 31.0 | % |

[0001628280-23-009178:notes:19]
The following table presents customers that represent 10% or more of the Company’s accounts receivable, net. Each customer shown is a channel partner of the Company.

[0001628280-23-009178:notes:20]
|  | December 31, |
|  | 2022 |  | 2021 |
| Motorola Solutions, Inc. | 39.0 | % |  | 18.2 | % |
| Customer B |  |  | 11.8 | % |
| Customer C | 16.0 | % |  |  |
|  | 55.0 | % |  | 30.0 | % |

[0001628280-23-009178:notes:21]
The Company relies on third parties for the supply and manufacture of its products as well as third-party logistics providers. In instances where these parties fail to perform their obligations, the Company may be unable to find alternative suppliers to satisfactorily deliver its products to its customers on time, if at all, which could have a material adverse effect on the Company’s operating results, financial condition and cash flows and damage its customer relationships.

[0001628280-23-009178:notes:22]
Cash, Cash Equivalents, and Restricted Cash

[0001628280-23-009178:notes:23]
Cash, cash equivalents, and restricted cash as reported on the consolidated statement of cash flows consists of the following (in thousands):

[0001628280-23-009178:notes:24]
|  | December 31, |
|  | 2022 |  | 2021 |
| Cash and cash equivalents | $ | 229,783 |  | $ | 307,492 |
| Restricted cash | 275 |  | 675 |
| Total cash, cash equivalents, and restricted cash | $ | 230,058 |  | $ | 308,167 |

[0001628280-23-009178:notes:25]
The Company considers all short-term, highly liquid investments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents. Restricted cash relates to a letter of credit on the Company’s office lease in Waltham, Massachusetts, all of which is included in restricted cash, noncurrent in the consolidated balance sheet as of December 31, 2022. As the letter of credit is reduced restricted cash is reclassified to cash and cash equivalents.

[0001628280-23-009178:notes:26]
Fair Value Measurements of Financial Instruments

[0001628280-23-009178:notes:27]
Certain assets and liabilities of the Company are carried at fair value under GAAP. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. Valuation techniques used to measure fair value must maximize the use of observable inputs and minimize the use of unobservable inputs. Financial assets and liabilities carried at fair value are to be classified and disclosed in one of the following three levels of the fair value hierarchy, of which the first two are considered observable and the last is considered unobservable:

[0001628280-23-009178:notes:28]
•Level 1 — Quoted prices in active markets for identical assets or liabilities.

[0001628280-23-009178:notes:29]
•Level 2 — Observable inputs (other than Level 1 quoted prices), such as quoted prices in active markets for similar assets or liabilities, quoted prices in markets that are not active for identical or similar assets or liabilities, or other inputs that are observable or can be corroborated by observable market data.

[0001628280-23-009178:notes:30]
•Level 3 — Unobservable inputs that are supported by little or no market activity that are significant to determining the fair value of the assets or liabilities, including pricing models, discounted cash flow methodologies and similar techniques.

[0001628280-23-009178:notes:31]
The Company’s cash equivalents, restricted cash, derivative liability, contingent earn-out liability, contingently issuable common stock liability and its common stock warrant liability are carried at fair value, determined according to the fair value hierarchy described above (see Note 4). The carrying values of the Company’s accounts receivable, net, accounts payable and accrued expenses approximate their fair values due to the short-term nature of these assets and liabilities. The carrying value of the Company’s long-term debt approximates its fair value (a Level 2 measurement) at each balance sheet date due to its variable interest rate, which approximates a market interest rate.

[0001628280-23-009178:notes:32]
Assets that are measured at fair value on a nonrecurring basis primarily relate to property and equipment. We do not periodically adjust carrying value to fair value for property and equipment. Rather, the carrying value of the asset is reduced to its fair value when we determine that impairment has occurred.

[0001628280-23-009178:notes:33]
Contingent Earn-out

[0001628280-23-009178:notes:34]
In connection with the Merger and pursuant to the Merger Agreement, certain of the Legacy Evolv’s shareholders and Legacy Evolv Service Providers are entitled to receive additional shares of the Company’s common stock (the “Earn-Out Shares”) upon the Company achieving certain milestones:

[0001628280-23-009178:notes:35]
•Triggering Event I – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock is greater than $12.50 per share for any 20 trading days within any 30 trading day period.

[0001628280-23-009178:notes:36]
•Triggering Event II – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock is greater than $15.00 per share for any 20 trading days within any 30 trading day period.

[0001628280-23-009178:notes:37]
•Triggering Event III – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, by March 8, 2026, the price of the Company’s common stock is greater than $17.50 per share for any 20 trading days within any 30 trading day period.

[0001628280-23-009178:notes:38]
In accordance with ASC 815 – Derivatives and Hedging, the earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a change in fair value of contingent earn-out liability in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Triggering Events have been achieved and the Earn-Out Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001628280-23-009178:notes:39]
The estimated fair value of the contingent earn-out shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, drift rate, percentage of change in control and expected term.

[0001628280-23-009178:notes:40]
The contingent earn-out liability is categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingent earn-out payments involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001628280-23-009178:notes:41]
The Earn-Out Shares issued to employees, officers, directors, and non-employees are based on achievement of certain target share price contingencies and for the employees and officers, subject to continued employment, (the “Earn-

[0001628280-23-009178:notes:42]
Out Service Providers”) represents share-based compensation and is included in additional paid-in capital on the Company’s balance sheet. Corresponding stock-based compensation expense is recorded in the consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. As a condition to being issued Earn-Out Shares, the Earn-Out Service Providers must still be providing services to the Company on the date of the issuance of the shares. If the relationship with the service provider is terminated prior to the issuance of the Earn-Out Shares, the shares will be redistributed to the remaining participants in the Earn-Out Shares.

[0001628280-23-009178:notes:43]
Contingently Issuable Common Stock

[0001628280-23-009178:notes:44]
Prior to the Merger, NewHold Industrial Technology Holdings, LLC, the sponsor of the NHIC special purpose acquisition company owned 4,312,500 shares of NHIC Class B common stock (the “Founder Shares). Upon the closing of the merger, NHIC Class A and Class B common stock became the Company’s common stock. The Founder Shares outstanding were subject to certain share-performance-based vesting provisions as follows:

[0001628280-23-009178:notes:45]
•Vesting Provision I – 1,897,500 shares of the Company’s common stock shall vest and no longer be subject to forfeiture as of the Merger;

[0001628280-23-009178:notes:46]
•Vesting Provision II – if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $12.50 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30 trading day period, then 948,750 shares of the Company’s common stock shall vest and no longer be subject to forfeiture and

[0001628280-23-009178:notes:47]
•Vesting Provision III – if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $15.00 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30-trading day period, then 948,750 shares of the Company’s common stock) shall vest and no longer be subject to forfeiture.

[0001628280-23-009178:notes:48]
The remaining 517,500 Founder Shares were contributed to Give Evolv LLC.

[0001628280-23-009178:notes:49]
If Vesting Provision II and/or Vesting Provision III are not satisfied, the corresponding number of shares specified shall be forfeited and no longer issued and outstanding. If there is a Change of Control event prior to Vesting Provision II and/or Vesting Provision III are satisfied, the Founder shares are no longer subject to forfeiture and shall vest immediately upon the occurrence of a Change of Control event.

[0001628280-23-009178:notes:50]
In accordance with ASC 815 – Derivatives and Hedging, the contingently issuable common stock is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as change in fair value of contingently issuable common stock liability in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Vesting Provisions have been achieved and the contingently issuable common shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001628280-23-009178:notes:51]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, likelihood of change in control, and remaining term.

[0001628280-23-009178:notes:52]
The contingently issuable common shares are categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingently issuable shares involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001628280-23-009178:notes:53]
Public Warrant Liability

[0001628280-23-009178:notes:54]
In connection with the closing of the Merger, the Company assumed warrants to purchase shares of common stock (the “Public Warrants”) and are classified as a liability pursuant to ASC 815 – Derivatives and Hedging as the equity derivative scope exception was not met.

[0001628280-23-009178:notes:55]
Leases as a Lessee

[0001628280-23-009178:notes:56]
Prior to January 1, 2022, the Company accounted for leases in accordance with ASC 840, Leases. At lease inception, the Company determined if an arrangement was an operating or capital lease. For operating leases, the Company recognized rent expense, inclusive of rent escalation, on a straight-line basis over the lease term.

[0001628280-23-009178:notes:57]
Effective on January 1, 2022, the Company accounts for leases in accordance with ASC 842, Leases. At contract inception, the Company determines if an arrangement is or contains a lease. A lease conveys the right to control the use of an identified asset for a period of time in exchange for consideration. If determined to be or contain a lease, the lease is assessed for classification as either an operating or finance lease at the lease commencement date, defined as the date on which the leased asset is made available for use by the Company (when the Company is the lessee). Where the Company is the lessee, for each lease with a term greater than twelve months, the Company records a right-of-use asset and lease liability.

[0001628280-23-009178:notes:58]
A right-of-use asset represents the economic benefit conveyed to the Company by the right to use the underlying asset over the lease term. A lease liability represents the obligation to make lease payments arising from the use of the asset over the lease term. Lease liabilities are measured at lease commencement and calculated as the present value of the future lease payments in the contract using the rate implicit in the contract, when available. If an implicit rate is not readily determinable, the Company uses an incremental borrowing rate measured as the rate at which the Company could borrow, on a fully collateralized basis, a commensurate loan in the same currency over a period consistent with the lease term at the commencement date. Right-of-use assets are measured as the amount of the initial lease liability plus initial direct costs and prepaid lease payments, less lease incentives granted by the lessor. The lease term is measured as the noncancelable period in the contract, adjusted for any options to extend or terminate when it is reasonably certain the Company will extend the lease term via such options based on an assessment of economic factors present as of the lease commencement date. The Company elected the practical expedient to not recognize leases with a lease term of twelve months or less.

[0001628280-23-009178:notes:59]
Components of a lease are split into three categories: lease components, non-lease components, and non-components. The fixed and in-substance fixed contract consideration (including any consideration related to non-components) are allocated, based on the respective relative fair values, to the lease components and non-lease components. The Company has elected the practical expedient to account for lease and non-lease components together as a single lease component for all underlying assets and allocate all of the contract consideration to the lease component only.

[0001628280-23-009178:notes:60]
The Company’s operating leases are presented in the consolidated balance sheet as operating lease right-of-use assets, classified as noncurrent assets, and operating lease liabilities, classified as current and noncurrent liabilities. Operating lease expense is recognized on a straight-line basis over the lease term. Variable costs associated with a lease, such as maintenance and utilities, are not included in the measurement of the lease liabilities and right-of-use assets but rather are expensed when the events determining the amount of variable consideration to be paid have occurred.

[0001628280-23-009178:notes:61]
Inventory

[0001628280-23-009178:notes:62]
Inventory is stated at the lower of cost or net realizable value with cost being determined using the weighted average method. The Company regularly reviews inventory quantities on-hand for excess and obsolete inventory and, when circumstances indicate, records charges to write down inventories to their estimated net realizable value, after evaluating historical sales, future demand, market conditions and expected product life cycles. Such charges are classified as product cost of revenues in the consolidated statement of operations and comprehensive loss. Any write-down of inventory to net realizable value creates a new cost basis. The Company recorded $1.6 million and $2.1 million in inventory write-offs during the years ended December 31, 2022 and 2021, respectively. These write-offs primarily relate to Edge units and prior generation Express units, as the Company is no longer selling these products, as well as other inventory that was determined to be obsolete or unsellable.

[0001628280-23-009178:notes:63]
Property and Equipment

[0001628280-23-009178:notes:64]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization expense are recognized using the straight-line method over the estimated useful life of each asset, as follows:

[0001628280-23-009178:notes:65]
|  | Estimated Useful Life |
| Computers and telecommunications equipment | 3 years |
| Lab equipment | 5 years |
| Software | 4 years |
| Furniture and fixtures | 5 years |
| Leasehold improvements | Shorter of remaining lease term or useful life |
| Leased equipment | 4-7 years |
| Internal-use software | 4 years |

[0001628280-23-009178:notes:66]
Estimated useful lives are periodically assessed to determine if changes are appropriate. Leasehold improvements are depreciated using the straight-line method over the lesser of the lease term or its estimated economic useful life. Lease terms are used based upon the initial lease agreement and do not consider potential renewals or extensions until such time that the renewals or extensions are contracted. Maintenance and repairs are charged to expense as incurred. When assets are retired or otherwise disposed of, the cost of these assets and related accumulated depreciation are eliminated from the consolidated balance sheet and any resulting gains or losses are included in the consolidated statements of operations and comprehensive loss in the period of disposal. Costs for capital assets not yet placed into service are capitalized as construction-in-progress and depreciated once placed into service.

[0001628280-23-009178:notes:67]
The Company’s leases for leased equipment generally are 48 months. The Company’s subscription contracts are generally classified as operating leases because title does not transfer and they do not meet any of the other criteria per Accounting Standards Codification 842 – Leases (“ASC 842”).

[0001628280-23-009178:notes:68]
The Company evaluates property and equipment for obsolescence and impairment whenever events or changes in business circumstances indicate that the carrying amount of the assets may not be fully recoverable. Factors that the Company considers in deciding when to perform an impairment review include significant underperformance of the business in relation to expectations, significant negative industry or economic trends and significant changes or planned changes in the use of the assets. If an impairment review is performed to evaluate a long-lived asset group for recoverability, the Company compares forecasts of undiscounted cash flows expected to result from the use and eventual disposition of the long-lived asset group to its carrying value. An impairment loss would be recognized in loss from operations and comprehensive loss when estimated undiscounted future cash flows expected to result from the use of an asset group are less than its carrying amount. The impairment loss is based on the excess of the carrying value of the impaired asset group over its fair value, determined based on discounted cash flows. The Company recorded impairment losses of $1.2 million and $1.9 million during the years ended December 31, 2022 and 2021, respectively. These impairment losses related primarily to Edge and Express prototype units that were taken out of service and retired.

[0001628280-23-009178:notes:69]
The Company capitalizes certain software development costs, including consulting costs and compensation expenses for employees who devote time to the development projects, beginning upon completion of the preliminary project stage (in relation to internal-use software) or upon establishment of technological feasibility (in relation to software embedded in products to be sold or leased), and through the date the software is ready for its intended use. The Company records software development costs in property and equipment, net. Costs incurred in the preliminary stages of development activities and post implementation are expensed in the period incurred and are recorded in research and development expense in the consolidated statements of operations and comprehensive loss. The Company also capitalizes costs related to specific upgrades and enhancements when it is probable the expenditures will result in additional functionality.

[0001628280-23-009178:notes:70]
Once the project is available for general release, capitalization ceases, and the asset can begin amortization. Capitalized software costs are amortized on a straight-line basis over their estimated useful life, which is generally four years, and are recorded in cost of subscription revenue and cost of service revenue in the consolidated statements of operations and comprehensive loss.

[0001628280-23-009178:notes:71]
Debt Issuance Costs

[0001628280-23-009178:notes:72]
The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated debt on the consolidated balance sheet and amortized as interest expense on the consolidated statement of operations and comprehensive loss using the effective interest method.

[0001628280-23-009178:notes:73]
Segment Information

[0001628280-23-009178:notes:74]
The Company determined that it has one operating segment after considering the Company’s organizational structure and the information regularly reviewed and evaluated by the Company’s chief operating decision maker (“CODM”) in deciding how to allocate resources and assess performance. The Company has determined that its CODM is its President and Chief Executive Officer. The CODM reviews the financial information on a consolidated basis for purposes of evaluating financial performance and allocating resources. On the basis of these factors, the Company determined that it operates and manages its business as one operating segment, that develops, manufactures, markets and sells security screening products and specific services, and accordingly has one reportable segment for financial reporting purposes.

[0001628280-23-009178:notes:75]
Revenue Recognition

[0001628280-23-009178:notes:76]
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

[0001628280-23-009178:notes:77]
The Company derives revenue from (1) subscription arrangements accounted for as operating leases under ASC 842 (and ASC 840, Leases ("ASC 840") prior to the adoption of ASC 842) and (2) from the sale of products, inclusive of SaaS and maintenance and (3) professional services. The Company’s arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001628280-23-009178:notes:78]
Product Revenue

[0001628280-23-009178:notes:79]
The Company derives revenue from the sale of its Express equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer. Transfer of control occurs when the Company has transferred title and risk of loss and has a present right to payment for the equipment, which follows the terms of each customer contract. Products are predominately sold with distinct services, which are described in the services section below.

[0001628280-23-009178:notes:80]
Subscription Revenue - Leases as Lessor

[0001628280-23-009178:notes:81]
In addition to selling our products directly to customers, we also derive revenue from leasing our equipment, which we classify as subscription revenue. Lease terms are typically four years, generally do not include unilateral options by either the Company or our customer to extend, terminate or to purchase the underlying asset, and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as they do not meet any of the sales-type lease criteria per ASC 842 and recognized ratably over the duration of the lease. There are no variable lease payments as a part of these arrangements.

[0001628280-23-009178:notes:82]
The accounting provisions we use to classify transactions as sales-type are: (i) whether the lease transfers ownership of the equipment by the end of the lease term, (ii) whether the lease grants the customer an option to purchase the equipment and the customer is reasonably certain to do so, (iii) whether the lease term is for the major part of the economic life of the underlying equipment, (iv) whether the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (v) whether the equipment is specific to the customer and of such a specialized nature that it is expected to have no alternative use to the Company at the end of the lease term. Leasing arrangements meeting any of these conditions are accounted for as sales-type leases and revenue attributable to the lease component is recognized in a manner consistent with product revenue and the related equipment is derecognized with the associated expense presented as a cost of revenue. Leasing arrangements that do not meet the criteria for classification as a sales-type lease will be accounted for as a direct-financing lease if the following two conditions are met: (i) the present value of the lease payments, and any residual value guaranteed by the customer that is not already reflected in the lease payments and any other third party unrelated to the Company, is equal to or greater than substantially all of the fair market value of the equipment at the commencement of the lease, and (ii) it is probable that the Company will collect the lease payments and amounts necessary to satisfy a residual value guarantee. Leasing arrangements that do not meet any of the sales-type lease or direct-financing lease classification criteria are accounted for as operating leases and revenue is recognized straight-line over the term of the lease.

[0001628280-23-009178:notes:83]
The Company considers the economic life of most of our products to be seven years. The Company believes seven years is representative of the period during which the equipment is expected to be economically usable by one or more users, with normal service, for the purpose for which it is intended. The unguaranteed residual value is estimated to be the value at the end of the lease term based on the anticipated fair market value of the units. The Company mitigates residual value risk of our leased equipment by performing regular management and maintenance, as necessary.

[0001628280-23-009178:notes:84]
Generally, lease arrangements include both lease and non-lease components. The lease component relates to the customer’s right-to-use the equipment over the lease term. The non-lease components relate to (1) distinct services, such as SaaS and maintenance, (2) any add-on accessories, and (3) installation and training. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue. Because the equipment, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the Company elected the practical expedient to aggregate non-lease components with the associated lease component and account for the combined component as an operating lease for all underlying asset classes. In the evaluation of whether the lease component (equipment) or the non-lease components associated with the lease component (SaaS and maintenance) is the predominant component, the Company determined that the lease component is predominant as we believe the customer would ascribe more value to the use of the security equipment than that of the SaaS and maintenance services. Therefore, the Company accounts for the combined lease component under ASC 842. The equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations and comprehensive loss. The installation and training services represent distinct services provided to customers. These activities are considered separate performance obligations to the customer and therefore are considered non-lease components. As installation and training services are performed prior to lease commencement, the timing and pattern of transfer for these services differ from that of the lease component and are not eligible to be combined.

[0001628280-23-009178:notes:85]
We exclude from variable payments all lessor costs that are explicitly required to be paid directly by a lessee on behalf of the lessor to a third party. Revenue related to leases entered into with related parties were $0.6 million and less than $0.1 million during the years ended December 31, 2022 and 2021, respectively.

[0001628280-23-009178:notes:86]
Installation and training are generally billed to the lessee as part of the lease contract billing, according to various contractual terms. The installation and training costs incurred by the Company are accounted for as a fulfillment cost and are included in the cost of services revenue in the consolidated statements of operations and comprehensive loss.

[0001628280-23-009178:notes:87]
Services Revenue

[0001628280-23-009178:notes:88]
The Company provides SaaS, maintenance, installation and training services for our products. Revenue for installation and training are recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes and when-and-if available threat updates. SaaS and maintenance revenue is recognized ratably over the period of the arrangement.

[0001628280-23-009178:notes:89]
Revenue from Channel Partners

[0001628280-23-009178:notes:90]
A portion of the Company’s revenue is also generated by sales to its channel partners. When the Company transacts with a channel partner, its contractual arrangement is with the channel partner and not with the end-use customer. In these transactions, the channel partner is considered the customer; the Company has discretion over the pricing to the channel partner and maintains overall control of the inventory and sales process to the channel partner. Right of return does not generally exist. Whether the Company transacts with a channel partner and receives the order from a channel partner or directly from an end-use customer, its revenue recognition policy and resulting pattern of revenue recognition is the same.

[0001628280-23-009178:notes:91]
Transaction Price

[0001628280-23-009178:notes:92]
The transaction price is the amount of consideration that the Company expects to be entitled for providing goods and services under a contract, which can include both fixed and variable consideration. The Company may also provide discounts to customers which reduce the transaction price. From time-to-time, the Company may offer customers the option to purchase additional goods and services at a fixed price. In these circumstances, the Company assesses whether these offers constitute a material right, and if so, the Company would account for the material right as a separate performance obligation. Other types of variable consideration are not considered significant. The Company does not normally provide for rights of returns to customers on product sales and, therefore, does not record a provision for returns. Amounts paid or payable to customers, including those related to sponsorship arrangements, are recognized as a reduction of the transaction price, and therefore, of revenue unless the payment is in exchange for a distinct good or service.

[0001628280-23-009178:notes:93]
Performance Obligations

[0001628280-23-009178:notes:94]
A performance obligation is a promise in a contract to transfer a distinct product or service to a customer that is both capable of being distinct, whereby the customer can benefit from the product or service either on its own or together with other resources that are readily available, and is distinct in the context of the contract, whereby the transfer of the product or service is separately identifiable from other promises in the contract.

[0001628280-23-009178:notes:95]
Equipment is sold or leased with embedded software, which is considered a single performance obligation. Maintenance, which includes future updates, security threat updates, and minor bug fixes on a when-and-if available basis, is considered a single performance obligation. SaaS, which include data-driven security information and analytics insights, is also considered a performance obligation. Installation and training are considered separate performance obligations and are included within service revenue. Any add-on accessories are also considered separate performance obligations and are included in product revenue.

[0001628280-23-009178:notes:96]
Payment terms

[0001628280-23-009178:notes:97]
Payment terms for customer orders are typically 30 days after the shipment or installation of the product. Generally, the Company’s contracts do not contain a significant financing component.

[0001628280-23-009178:notes:98]
Multiple Performance Obligations within an Arrangement

[0001628280-23-009178:notes:99]
The Company’s contracts may include multiple performance obligations when customers purchase a combination of products and services. When the Company’s customer arrangements have multiple performance obligations that contain an equipment lease for the customer’s use as well as distinct services that are delivered simultaneously, the Company allocates the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, the Company allocates the contract’s transaction price to each performance obligation on a relative SSP basis. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company estimates the SSP taking into account available information such as market conditions, internally approved pricing guidelines, and observable pricing data such as standard cost metrics related to the performance obligation.

[0001628280-23-009178:notes:100]
Stock-Based Compensation

[0001628280-23-009178:notes:101]
The Company measures all stock-based awards granted to employees, officers, directors and non-employees based on their fair value on the date of the grant and recognizes compensation expense for those awards over the requisite service period, which is generally the vesting period of the respective award. The Company classifies stock-based compensation expense in its consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. The Company issues stock-based awards with service-based vesting conditions and records the expense for these awards using the straight-line method. Forfeitures are accounted for as they occur.

[0001628280-23-009178:notes:102]
In January 2021, the Company granted warrants (the "Finback Common Stock Warrants") exercisable for 2,552,913 shares of common stock at an exercise price of $0.42 per share to Finback Evolv OBH, LLC ("Finback"), a consulting group affiliated with one of the Company's shareholders. The Finback Common Stock Warrants vest upon meeting certain sales criteria as defined in a business development agreement (the "Finback BDA") which has a term of   three years. The Finback Common Stock Warrants expire in January 2031. The Finback Common Stock Warrants are accounted for under ASC 718 Compensation - Stock Compensation as the warrants vest upon certain performance conditions being met.

[0001628280-23-009178:notes:103]
Prior to the closing of the Merger, there was not a public market for the shares of the Company’s common stock. The Company’s determination of the fair value of stock options on the date of grant utilized the Black-Scholes option-pricing model and was impacted by its common stock price, as determined by the Board of Directors with input from the Company’s management, as well as changes in assumptions regarding a number of subjective variables. These variables included, but were not limited to, the expected term that options remained outstanding, the expected common stock price volatility over the term of the option awards, risk-free interest rates, and expected dividends. The Company valued its common stock taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the Company determines the fair value of each share of common stock underlying stock-based awards based on the closing price of the Company’s common stock as reported by Nasdaq on the date of grant.

[0001628280-23-009178:notes:104]
Pursuant to the Merger Agreement, the Company will issue 15,000,000 earn-out shares of the Company’s common stock to Legacy Evolv shareholders and Legacy Evolv Service Providers including employees, officers, directors and non-employees based on the achievement of certain target share price contingencies and subject to continued employment. The company classifies the share-based compensation arrangement with Legacy Evolv Service Providers as equity on its balance sheet and corresponding stock-based compensation expense in its consolidated statements of operations and comprehensive loss in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. Of the total 15,000,000 earn-out shares of the Company’s common stock, 2,849,587 earn-out shares can be earned by the Legacy Evolv Service Providers and are subject to the stock-based compensation guidance. As a condition for Earn-Out Shares being issued to Earn-Out Service Providers, the service provider must be providing services to the Company on the date of the issuance of the shares. If the relationship with the service provider is terminated prior to the issuance of the Earn-Out Shares, the shares will be redistributed to the remaining participants in the Earn-Out Shares.

[0001628280-23-009178:notes:105]
Income Taxes

[0001628280-23-009178:notes:106]
The Company accounts for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in the consolidated financial statements or in the Company’s tax returns. Deferred tax assets and liabilities are determined on the basis of the differences between the consolidated financial statements and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. Changes in deferred tax assets and liabilities are recorded in the provision for income taxes.

[0001628280-23-009178:notes:107]
The Company assesses the likelihood that its deferred tax assets will be recovered from future sources of income and, to the extent it believes, based upon the weight of available evidence, that it is more likely than not that all or a portion of the deferred tax assets will not be realized, a valuation allowance is established through a charge to income tax expense. Potential for recovery of deferred tax assets is evaluated by analyzing past operating results, estimating the future taxable profits expected and considering prudent and feasible tax planning strategies.

[0001628280-23-009178:notes:108]
The Company accounts for uncertainty in income taxes recognized in the consolidated financial statements by applying a two-step process to determine the amount of tax benefit to be recognized. First, the tax position must be evaluated to determine the likelihood that it will be sustained upon external examination by the taxing authorities. If the tax position is deemed more-likely-than-not to be sustained, the tax position is then assessed to determine the amount of benefit to recognize in the consolidated financial statements. The amount of the benefit that may be recognized is the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. The provision for income taxes includes the effects of any resulting tax reserves, or unrecognized tax benefits, that are considered appropriate as well as the related net interest and penalties.

[0001628280-23-009178:notes:109]
The Company evaluates at the end of each reporting period whether some or all the undistributed earnings of its foreign subsidiaries are permanently reinvested. The Company would recognize deferred income tax liabilities to the extent that management asserts that undistributed earnings of its foreign subsidiaries are not permanently reinvested and will not be permanently reinvested in the future. As of December 31, 2022 and 2021, the Company had no foreign earnings in any foreign jurisdictions.

[0001628280-23-009178:notes:110]
Net Loss per Share Attributable to Common Stockholders

[0001628280-23-009178:notes:111]
Basic net loss per share attributable to common stockholders is computed by dividing the net loss attributable to common stockholders by the weighted average number of common shares outstanding for the period. Diluted net loss attributable to common stockholders is computed by adjusting net loss attributable to common stockholders for the impact to the extent a denominator adjustment is required. Diluted net loss per share attributable to common stockholders is computed by dividing the diluted net loss attributable to common stockholders by the weighted average number of common shares outstanding for the period, including potential dilutive common shares. For purposes of this calculation, outstanding stock options, convertible preferred stock, convertible notes, warrants to purchase common stock, and warrants to purchase preferred stock are considered potential dilutive common shares.

[0001628280-23-009178:notes:112]
In periods in which the Company reported a net loss attributable to common stockholders, diluted net loss per share attributable to common stockholders is the same as basic net loss per share attributable to common stockholders, since dilutive common shares are not assumed to have been issued if their effect is anti-dilutive. The Company reported a net loss attributable to common stockholders for the years ended December 31, 2022 and 2021.

[0001628280-23-009178:notes:113]
Recently Adopted Accounting Pronouncements

[0001628280-23-009178:notes:114]
The Company qualifies as an “emerging growth company” as defined in the Jumpstart Our Business Startups Act of 2012 and has elected not to “opt out” to the extended transition related to complying with new or revised accounting standards, which means that when a standard is issued or revised and it has different application dates for public and nonpublic companies, the Company will adopt the new or revised standard at the time nonpublic companies adopt the new or revised standard and will do so until such time that the Company either (1) irrevocably elects to “opt out” of such extended transition period or (2) no longer qualifies as an emerging growth company. The Company may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for nonpublic companies.

[0001628280-23-009178:notes:115]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), as subsequently amended (collectively “ASC 842”). The guidance amends the existing accounting standards for lease accounting, including requirements for lessees to recognize assets and liabilities related to long-term leases on the balance sheet and expanding disclosure requirements regarding leasing arrangements. For lessees, leases will be classified as finance or operating, with classification affecting the pattern and classification of expense recognition in the income statement. Lessors are required to classify leases as a sales-type, direct financing, or operating lease. A lease is a sales-type lease if it effectively transfers control of the underlying asset to the lessee as indicated by any one of five criteria being met. All leases that are not sales-type or direct financing leases will be classified as operating leases. In July 2018, the FASB issued additional guidance, which offers a transition option to entities adopting ASC 842 in which entities can elect to apply the new guidance using a modified retrospective approach at the beginning of the year in which the new lease standard is adopted. The Company utilized this transition option whereby financial information for prior periods presented before the ASC 842 effective date will not be updated. In November 2019, the FASB issued ASU 2019-10 deferring the effective date for private entities (also applicable for public companies that qualify as emerging growth companies) for fiscal years beginning after December 15, 2020, and interim periods within fiscal years beginning after December 15, 2021. In June 2020, the FASB

[0001628280-23-009178:notes:116]
issued ASU 2020-05 which further defers the effective date for private entities for fiscal years beginning after December 15, 2021, and interim periods within fiscal years beginning after December 15, 2022.

[0001628280-23-009178:notes:117]
The Company adopted this guidance effective January 1, 2022. ASC 842 provides several optional practical expedients in transition. The Company applied the ‘package of practical expedients’ which allow the Company to not reassess whether existing or expired arrangements contain a lease, the lease classification of existing or expired leases, or whether previous initial direct costs would qualify for capitalization under ASC 842.

[0001628280-23-009178:notes:118]
The adoption of ASC 842 resulted in the recognition of operating lease liabilities of $3.0 million and operating right-of-use assets of $2.5 million, along with the write-off of certain deferred rent balances of $0.5 million within the Company’s consolidated balance sheets as of January 1, 2022. The adoption did not have a significant impact on the Company’s consolidated statements of operations and comprehensive loss and consolidated statements of cash flows.

[0001628280-23-009178:notes:119]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in ASC 740 and clarifies and amends existing guidance to improve consistent application. For public entities, the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its consolidated financial statements and related disclosures.

[0001628280-23-009178:notes:120]
In August 2020, the FASB issued ASU 2020-06, Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies and clarifies certain calculation and presentation matters related to convertible and equity and debt instruments. Specifically, ASU 2020-06 removes requirements to separately account for conversion features as a derivative under ASC Topic 815 and removing the requirement to account for beneficial conversion features on such instruments. ASU 2020-06 also provides clearer guidance surrounding disclosure of such instruments and provides specific guidance for how such instruments are to be incorporated in the calculation of Diluted EPS. The guidance under ASU 2020-06 is effective for fiscal years beginning after December 15, 2021, including interim periods within those fiscal years. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020. The Company adopted this guidance effective January 1, 2022 and the adoption of this guidance did not have a material impact on its consolidated financial statements and related disclosures.

[0001628280-23-009178:notes:121]
Recently Issued Accounting Pronouncements

[0001628280-23-009178:notes:122]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities and smaller reporting companies to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company adopted this guidance effective January 1, 2023, and does not expect that adoption of the guidance will have a material impact on its consolidated financial statements.

[0001628280-23-009178:notes:123]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years, and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company adopted this guidance effective January 1, 2023, and does not expect that adoption of the guidance will have a material impact on its consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-23-009178:notes:124]
Merger with NHIC
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the Merger as a wholly owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001628280-23-009178:notes:125]
The transaction was accounted for as a “reverse recapitalization” in accordance with GAAP. Under this method of accounting, NHIC was treated as the “acquired” company for financial reporting purposes. This determination was primarily because subsequent to the Merger, Legacy Evolv’s shareholders have a majority of the voting power of the combined company, Legacy Evolv comprises all of the ongoing operations of the combined entity, Legacy Evolv comprises a majority of the governing body of the combined company, and Legacy Evolv’s senior management comprises all of the senior management of the combined company. Accordingly, for accounting purposes, this transaction was treated as the equivalent of Legacy Evolv issuing shares for the net assets of NHIC, accompanied by a recapitalization. The shares and net loss per common share, prior to the Merger, have been retroactively restated as shares reflecting the Exchange Ratio established in the Merger. The net assets of NHIC were recorded at historical costs, with no goodwill or other intangible assets recorded. Operations prior to the Reverse Recapitalization are those of Legacy Evolv.

[0001628280-23-009178:notes:126]
Evolv had previously indicated that it would list units (consisting of one share of common stock and one-half of one warrant) on Nasdaq under the ticker symbol EVLVU, in continuation of the listing of the units NHIC sold in its initial public offering on August 4, 2020 under the ticker symbol NHICU. In September 2021, our transfer agent separated the units into the component shares and warrants at the closing of the Merger, and as a result the Evolv units were not made eligible to settle through the facilities of The Depository Trust Company. Accordingly, all trades in the units from July 19, 2021 (the first trading day after the completion of the Merger) until August 24, 2021 were settled between brokers in the shares and warrants underlying the units. Trading in ticker symbol EVLVU was halted on August 24, 2021, and no trades in the units were permitted or occurred since that date. The units were delisted from Nasdaq effective September 10, 2021.

[0001628280-23-009178:notes:127]
Upon closing of the Merger each share of NHIC Class B common stock issued and outstanding immediately prior to the effective time of the Merger, which totaled 10,391,513 shares held by the NHIC Initial Shareholders (“Initial Shareholders”), was automatically converted into one validly-issued share of our common stock.

[0001628280-23-009178:notes:128]
In addition, pursuant to the Merger Agreement, certain Legacy Evolv Shareholders became entitled to receive up to 15,000,000 shares of common stock as earn-out shares.

[0001628280-23-009178:notes:129]
Upon closing of the Merger:

[0001628280-23-009178:notes:130]
•all of 24,359,107 shares of Legacy Evolv’s Series A-1 convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis;

[0001628280-23-009178:notes:131]
•all of 3,484,240 shares of Legacy Evolv’s Series A convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a two-to-one basis;

[0001628280-23-009178:notes:132]
•all of 34,129,398 shares of Legacy Evolv’s Series B-1 convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis; and

[0001628280-23-009178:notes:133]
•all of 15,367,312 shares of Legacy Evolv’s Series B convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis.

[0001628280-23-009178:notes:134]
On the closing date of the Merger, each share of Legacy Evolv common stock then issued and outstanding was canceled and the holders thereof in exchange received 94,192,534 shares of the Company’s common stock, which is equal

[0001628280-23-009178:notes:135]
to 0.378 newly-issued shares of the Company’s common stock for each share of Legacy Evolv common stock (the “Exchange Ratio”).

[0001628280-23-009178:notes:136]
All outstanding warrants exercisable for common stock in Legacy Evolv (other than warrants that expired, were exercised, or were deemed automatically net exercised immediately prior to the Merger) were exchanged for warrants exercisable for the Company’s common stock with the same terms and conditions except adjusted by the Exchange Ratio.

[0001628280-23-009178:notes:137]
All outstanding stock options of Legacy Evolv common stock, totaling 57,938,375 stock options, were canceled and the holders thereof in exchange received options to receive 0.378 shares of the Company’s common stock for a total of 21,891,254 stock options. The modification of the stock options to reflect the exchange ratio did not result in an incremental compensation expense upon closing of the Merger.

[0001628280-23-009178:notes:138]
Prior to the completion of the Merger, the Company entered into subscription agreements (collectively, the “PIPE Investment”) with certain parties subscribing for shares of the Company’s common stock (the “Subscribers”) pursuant to which the Subscribers agreed to purchase. Pursuant to the PIPE Investment, the Company issued 30,000,000 shares of common stock for a purchase price of $10.00 per share with gross proceeds of $300.0 million.

[0001628280-23-009178:notes:139]
The proceeds, net of redemptions, received from the Merger were $84.9 million and gross proceeds received from the PIPE investment were $300.0 million. Based on the number of shares of common stock outstanding on July 16, 2021 (in each case, not giving effect to any shares issuable upon exercise of warrants, options, or earn-out shares), Legacy Evolv shareholders owned approximately 92.7% of the common stock of the Company and NHIC shareholders owned approximately 7.3%.

[0001628280-23-009178:notes:140]
During the year ended December 31, 2021, the Company recorded $36.1 million of offering costs related to third-party legal, accounting, and other professional services to consummate the Merger. These offering costs are recorded as a reduction of additional paid-in capital upon the close of the Merger in the Company’s consolidated balance sheets. The Company expensed $0.7 million of offering costs related to the issuance of the Company’s contingently issuable common stock.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-23-009178:notes:141]
Fair Value Measurements
The following tables present information about the Company’s financial assets and liabilities measured at fair value on a recurring basis and indicate the level of the fair value hierarchy used to determine such fair values (in thousands):

[0001628280-23-009178:notes:142]
|  | Fair Value Measurements at December 31, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 149,971 |  |  | $ | — |  |  | $ | — |  |  | $ | 149,971 |  |
|  | $ | 149,971 |  |  | $ | — |  |  | $ | — |  |  | $ | 149,971 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Long-term debt including current portion | $ | — |  |  | $ | 29,683 |  |  | $ | — |  |  | $ | 29,683 |  |
| Contingent earn-out liability | — |  |  | — |  |  | 14,218 |  |  | 14,218 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 3,392 |  |  | 3,392 |  |
| Public Warrant liability | 6,124 |  |  | — |  |  | — |  |  | 6,124 |  |
|  | $ | 6,124 |  |  | $ | 29,683 |  |  | $ | 17,610 |  |  | $ | 53,417 |  |

[0001628280-23-009178:notes:143]
|  | Fair Value Measurements at December 31, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 297,536 |  |  | $ | — |  |  | $ | — |  |  | $ | 297,536 |  |
|  | $ | 297,536 |  |  | $ | — |  |  | $ | — |  |  | $ | 297,536 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Long-term debt including current portion | $ | — |  |  | $ | 9,945 |  |  | $ | — |  |  | $ | 9,945 |  |
| Contingent earn-out liability | — |  |  | — |  |  | 21,206 |  |  | 21,206 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 5,264 |  |  | 5,264 |  |
| Public Warrant liability | 11,030 |  |  | — |  |  | — |  |  | 11,030 |  |
|  | $ | 11,030 |  |  | $ | 9,945 |  |  | $ | 26,470 |  |  | $ | 47,445 |  |

[0001628280-23-009178:notes:144]
As of December 31, 2022 and December 31, 2021, money market funds are included in cash and cash equivalents on the consolidated balance sheets.

[0001628280-23-009178:notes:145]
The Company may also value its non-financial assets and liabilities, including items such as inventories and property and equipment, at fair value on a non-recurring basis if it is determined that impairment has occurred. Such fair value measurements use significant unobservable inputs and are classified as Level 3.

[0001628280-23-009178:notes:146]
The fair value classification of the public warrant liability as of December 31, 2021 has been updated to Level 1. During each of the years ended December 31, 2022 and 2021, there were no transfers between Level 1, Level 2, and Level 3.

[0001628280-23-009178:notes:147]
Valuation of Common Stock Warrant

[0001628280-23-009178:notes:148]
As defined and described in Note 13, the Company issued a 2019 SVB common stock warrant, a 2020 SVB common stock warrant, and a 2020 JPM common stock warrant (collectively the "Common Stock Warrants") for the purchase of Legacy Evolv's common stock. In connection with the closing of the Merger, all of the outstanding Common Stock Warrants were converted into shares of the Company's common stock.

[0001628280-23-009178:notes:149]
The Company used the Black-Scholes option-pricing model, which incorporates assumptions and estimates, to value the warrant liability. Key estimates and assumptions impacting the fair value measurement include (1) the fair value per share of the underlying shares of applicable series of stock issuable upon exercise of the Common Stock Warrants, (2) the remaining contractual term, (3) the risk-free interest rate, (4) the expected dividend yield and (5) expected volatility of the price of the underlying applicable common stock. The Company estimated the fair value per share of the underlying applicable series of stock based, in part, on the results of third-party valuations and additional factors deemed relevant. The risk-free interest rate was determined by reference to the U.S. Treasury yield curve for time periods approximately equal to the remaining contractual term of the Common Stock Warrants. The Company estimated a zero expected dividend yield based on the fact that the Company has never paid or declared dividends and does not intend to do so in the foreseeable future. As the Company was a private company up until the closing of the Merger and lacked company-specific historical and implied volatility information of its stock, the expected stock volatility was based on the historical volatility of publicly traded peer companies for a term equal to the remaining contractual term of the Common Stock Warrants.

[0001628280-23-009178:notes:150]
The following table provides a rollforward of the common stock warrant liability (in thousands):

[0001628280-23-009178:notes:151]
| Balance at December 31, 2020 | $ | 1 |  |
| Change in fair value | 879 |  |
| Conversion of common stock warrant to common stock upon the closing of the Merger | (880) |  |
| Balance at December 31, 2021 | $ | — |  |

[0001628280-23-009178:notes:152]
Valuation of Derivative Liability Related to Convertible Notes

[0001628280-23-009178:notes:153]
In September and December 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”). The 2020 Convertible Notes provided a conversion option whereby upon the closing of a specified financing event the Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative and was required to be bifurcated and accounted for separately from the 2020 Convertible Notes. The fair value of the derivative liability was determined based on inputs not observable in the market, which represents a Level 3 measurement within the fair value hierarchy.

[0001628280-23-009178:notes:154]
Upon the closing of the 2020 Convertible Notes, management determined that the probability of completing the specified financing event was 100%; thus, the value of the automatic conversion option was deemed to be 20% of the fair value of the capital stock to be issued upon conversion of the 2020 Convertible Notes, or $1.0 million. This amount represented the fair value of the embedded derivative at issuance.

[0001628280-23-009178:notes:155]
In January and February 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”). The 2021 Convertible Notes provided a conversion option whereby upon the closing of a specified financing event, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to lower of 80% of the price per share of the securities paid by the other investors or price per share at which shares are issued and sold in connection with the conversion or cancellation of convertible notes (other than the 2021 Convertible Notes) or simple agreements for future equity (“SAFEs”) of the Company in such Qualified Financing. This conversion option was determined to be an embedded derivative and was required to be bifurcated and accounted for separately from the 2021 Convertible Notes. The fair value of the derivative liability was determined based on inputs not observable in the market, which represents a Level 3 measurement within the fair value hierarchy.

[0001628280-23-009178:notes:156]
Upon the closing of the 2021 Convertible Notes, management determined that the probability of completing the specified financing event was 80%; thus, the value of the automatic conversion option was deemed to be 20% of the fair value of the capital stock to be issued upon conversion of the 2021 Convertible Notes, or $7.0 million. This amount represented the fair value of the embedded derivative at issuance. At the closing of the Merger, the fair value of the derivative liability was $9.2 million. On June 21, 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. The modification of the 2021 Convertible Notes resulted in the recognition of an additional $9.8 million derivative liability for the fair value of the 1,000,000 NHIC shares as of June 21, 2021. Prior to the closing of the Merger, the change in fair value of the derivative liability was $0.5 million.

[0001628280-23-009178:notes:157]
The following table provides a rollforward of the derivative liability (in thousands):

[0001628280-23-009178:notes:158]
| Balance at December 31, 2020 | $ | 1,000 |  |
| Initial fair value of the embedded derivative | 16,986 |  |
| Change in fair value | 1,745 |  |
| Settlement of derivative liability upon the closing of the Merger | (19,731) |  |
| Balance at December 31, 2021 | $ | — |  |

[0001628280-23-009178:notes:159]
Valuation of Contingent Earn-out

[0001628280-23-009178:notes:160]
Pursuant to the Merger Agreement, the Legacy Evolv shareholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability on the closing of the Merger and are remeasured at each reporting period. As of December 31, 2022, no milestones have been achieved.

[0001628280-23-009178:notes:161]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of December 31, 2022 were as follows: 90% expected stock price volatility, a risk-free rate of return of 4.2%, a 25% likelihood of change in control, and a remaining term of 3.2 years.

[0001628280-23-009178:notes:162]
The following table provides a rollforward of the contingent earn-out liability (in thousands):

[0001628280-23-009178:notes:163]
| Balance at December 31, 2020 | $ | — |  |
| Initial fair value of the instrument | 68,566 |  |
| Change in fair value | (47,360) |  |
| Balance at December 31, 2021 | $ | 21,206 |  |
| Change in fair value | (6,988) |  |
| Balance at December 31, 2022 | $ | 14,218 |  |

[0001628280-23-009178:notes:164]
Valuation of Contingently Issuable Common Stock

[0001628280-23-009178:notes:165]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 Founder Shares. 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC and the remaining 1,897,500 outstanding shares shall vest upon the Company achieving certain milestones (see Note 2). The Company’s contingently issuable common stock was recorded at fair value as contingent shares on the closing of the Merger and will be remeasured at each reporting period. As of December 31, 2022, no milestones have been achieved.

[0001628280-23-009178:notes:166]
The fair value of the contingently issued common shares are determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of December 31, 2022 were as follows: 90% expected stock price volatility, a risk-free rate of return of 4.2%, a 25% likelihood of change in control, and a remaining term of 3.6 years.

[0001628280-23-009178:notes:167]
The following table provides a rollforward of the contingently issuable common shares (in thousands):

[0001628280-23-009178:notes:168]
| Balance at December 31, 2020 | $ | — |  |
| Initial fair value of the instrument | 11,670 |  |
| Change in fair value | (6,406) |  |
| Balance at December 31, 2021 | $ | 5,264 |  |
| Change in fair value | (1,872) |  |
| Balance at December 31, 2022 | $ | 3,392 |  |

[0001628280-23-009178:notes:169]
Valuation of Public Warrant Liability

[0001628280-23-009178:notes:170]
Upon the closing of the Merger, the Company assumed the Public Warrants to purchase shares of the Company’s common stock. The Public Warrants are publicly traded and the initial fair value of the public warrants were based on the closing price as reported by Nasdaq on the date of the Merger and remeasured at each reporting period.

[0001628280-23-009178:notes:171]
The following table provides a rollforward of the public warrant liability (in thousands):

[0001628280-23-009178:notes:172]
| Balance at December 31, 2020 | $ | — |  |
| Initial fair value of the instrument | 23,636 |  |
| Change in fair value | (12,606) |  |
| Balance at December 31, 2021 | $ | 11,030 |  |
| Change in fair value | (4,906) |  |
| Balance at December 31, 2022 | $ | 6,124 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-23-009178:notes:173]
Revenue Recognition
The Company recognizes revenue in accordance with Accounting Standards Codification 606 – Revenue from Contracts with Customers (“ASC 606”). Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

[0001628280-23-009178:notes:174]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases under ASC 842 (and ASC 840 prior to adoption of ASC 842) and (2) from the sale of products, inclusive of SaaS and maintenance and (3) professional services. The Company’s arrangements are generally noncancelable and nonrefundable after ownership passes to the customer for product sales and upon installation or delivery for subscriptions. Revenue is recognized net of sales tax.

[0001628280-23-009178:notes:175]
Remaining Performance Obligations

[0001628280-23-009178:notes:176]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied or partially satisfied as of December 31, 2022.

[0001628280-23-009178:notes:177]
|  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue | $ | 8,686 |  |  | $ | — |  |  | $ | 8,686 |  |
| Subscription revenue | 26,763 |  |  | 57,602 |  |  | 84,365 |  |
| Service revenue | 13,969 |  |  | 37,541 |  |  | 51,510 |  |
| Total revenue | $ | 49,418 |  |  | $ | 95,143 |  |  | $ | 144,561 |  |

[0001628280-23-009178:notes:178]
The amount of minimum future leases is based on expected income recognition. As of December 31, 2022, future minimum payments on noncancelable leases are as follows (in thousands):

[0001628280-23-009178:notes:179]
| Year Ending December 31: |  |
| 2023 | 26,763 |  |
| 2024 | 25,412 |  |
| 2025 | 21,388 |  |
| 2026 | 10,689 |  |
| Thereafter | 113 |  |
|  | $ | 84,365 |  |

[0001628280-23-009178:notes:180]
Contract Balances from Contracts with Customers

[0001628280-23-009178:notes:181]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of December 31, 2022 and December 31, 2021, the Company had $2.9 million and $1.5 million in current portion of contract assets and $1.4 million and $3.4 million in contract assets, noncurrent on the consolidated balance sheets, respectively.

[0001628280-23-009178:notes:182]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $6.6 million during the year ended December 31, 2022 that was included in the 2021 deferred revenue balance. The Company recognized revenue of $2.3 million during the year ended December 31, 2021 that was included in the 2020 deferred revenue balance.

[0001628280-23-009178:notes:183]
The following table provides a rollforward of deferred revenue (in thousands):

[0001628280-23-009178:notes:184]
| Balance at December 31, 2020 | $ | 4,242 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (2,300) |  |
| Revenue deferred | 7,132 |  |
| Balance at December 31, 2021 | $ | 9,074 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (6,632) |  |
| Revenue deferred | 33,526 |  |
| Balance at December 31, 2022 | $ | 35,968 |  |

[0001628280-23-009178:notes:185]
The following table presents the Company’s components of lease revenue (in thousands):

[0001628280-23-009178:notes:186]
|  | Twelve Months EndedDecember 31, |
|  | 2022 |  | 2021 |
| Revenue from sales-type leases | $ | 1,123 |  |  | $ | — |  |
| Interest income on lease receivables | 224 |  |  | — |  |
| Lease income - operating leases | 17,569 |  |  | 7,803 |  |
| Total lease revenue | $ | 18,916 |  |  | $ | 7,803 |  |

[0001628280-23-009178:notes:187]
The revenue from sales-type leases is related to the Evolv Express units where the lease term is for the major part of the economic life of the underlying equipment and is classified as product revenue in the consolidated statements of operations and comprehensive loss. The interest income on lease receivables is classified as other income (expense), net in the consolidated statements of operations and comprehensive loss. The lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the consolidated statements of operations and comprehensive loss.

[0001628280-23-009178:notes:188]
Disaggregated Revenue

[0001628280-23-009178:notes:189]
The following table presents the Company’s revenue by revenue stream (in thousands):

[0001628280-23-009178:notes:190]
|  | Twelve Months EndedDecember 31, |
|  | 2022 |  | 2021 |
| Product revenue | $ | 31,985 |  |  | $ | 13,631 |  |
| Leased equipment | 17,569 |  |  | 7,803 |  |
| SaaS, maintenance, and other revenue | 4,665 |  |  | 846 |  |
| Professional services | 976 |  |  | 1,113 |  |
| Total revenue | $ | 55,195 |  |  | $ | 23,393 |  |

[0001628280-23-009178:notes:191]
The following table presents the Company's revenue by geographical region based on customer location (in thousands):

[0001628280-23-009178:notes:192]
|  | Twelve Months EndedDecember 31, |
|  | 2022 |  | 2021 |
| United States | $ | 53,815 |  |  | $ | 22,254 |  |
| Foreign | 1,380 |  |  | 1,139 |  |
| Total revenue | $ | 55,195 |  |  | $ | 23,393 |  |

[0001628280-23-009178:notes:193]
Contract Acquisition Costs

[0001628280-23-009178:notes:194]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $9.0 million and $5.4 million as of December 31, 2022 and December 31, 2021, respectively. During the years ended December 31, 2022 and 2021, the Company amortized commission expense of $4.1 million and $2.7 million, respectively.

[0001628280-23-009178:notes:195]
Give Evolv LLC

[0001628280-23-009178:notes:196]
Upon the closing of the Merger, the NHIC Founders transferred 517,500 shares of its common stock to Evolv NewHold Benefit LLC (“ENHB”), which represented the initial contribution to be used to pay for the donation of Evolv’s Express units to public venues and institutions, primarily schools in locations that might not otherwise be able to afford weapon detection security screening systems and related products and services. In September 2021, ENHB was renamed to Give Evolv LLC (“Give Evolv”). Give Evolv is deemed an entity under common control and a consolidating entity as it is under the same management as the Company. As such, the shares held by Give Evolv are not considered outstanding or issued.

[0001628280-23-009178:notes:197]
For such arrangements, Give Evolv generally purchases the related products and services from Evolv through an intercompany transaction using the available donated proceeds from the transfer of common stock upon the closing of the Merger. Evolv will be responsible for the delivery of the units, in addition to providing related services, such as installation, training, and maintenance. Consideration transferred to Evolv for the related products and services may be in the form of common stock or cash. Shares of common stock may be sold to generate funds for the purposes of paying for the donated goods and services. The sales transactions between Evolv and Give Evolv eliminate in consolidation.

[0001628280-23-009178:notes:198]
During the year ended December 31, 2022, the Company donated six Evolv Express units to schools, resulting in $0.2 million in general and administrative expense in the Company’s consolidated statements of operations and comprehensive loss. No Evolv Express units were donated during the year ended December 31, 2021.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-23-009178:notes:199]
Leases
Company Headquarters (Waltham, MA)

[0001628280-23-009178:notes:200]
In April 2021, the Company entered a sublease agreement for office and storage space for its corporate headquarters located at 500 Totten Pond Road in Waltham, MA. The sublease expires on October 31, 2024. The Company is required to maintain a minimum cash balance of $0.3 million as a security deposit on the space which is classified as restricted cash, non-current on the consolidated balance sheets. The Company pays for its proportionate share of building operating expenses and taxes that are treated as variable costs and excluded from the measurement of the lease. The sublease grants the Company an option to extend the term for an additional three years at the then fair market rent by giving the landlord nine months written notice. The Company was not reasonably certain to exercise the option to extend the lease and therefore the extension term was excluded from the measurement of the lease.

[0001628280-23-009178:notes:201]
Storage Facilities

[0001628280-23-009178:notes:202]
The Company additionally leases three storage spaces on a month-to-month basis that are classified as short-term leases.

[0001628280-23-009178:notes:203]
Operating lease cost recognized during the year ended December 31, 2022 was $1.0 million. Cash paid for amounts included in the measurement of lease liabilities for the year ended December 31, 2022 was $1.1 million.

[0001628280-23-009178:notes:204]
The weighted-average remaining lease term and discount rate as of December 31, 2022 were as follows:

[0001628280-23-009178:notes:205]
| Weighted average remaining lease term | 1.8 years |
| Weighted average discount rate | 6.95 | % |

[0001628280-23-009178:notes:206]
Future annual lease payments under non-cancelable operating leases as of December 31, 2022 were as follows (in thousands):

[0001628280-23-009178:notes:207]
| Year Ended December 31: |  |
| 2023 | 1,149 |  |
| 2024 | 981 |  |
| Total future lease payments | 2,130 |  |
| Less: imputed interest | (124) |  |
| Present value of operating lease liability | $ | 2,006 |  |

[0001628280-23-009178:notes:208]
Rent expense recognized in accordance with ASC 840 for the year ended December 31, 2021 was approximately $0.9 million.

[0001628280-23-009178:notes:209]
Future annual lease payments under non-cancelable operating leases as of December 31, 2021 under ASC 840 were as follows (in thousands):

[0001628280-23-009178:notes:210]
| Year Ended December 31: |  |
| 2022 | $ | 1,116 |  |
| 2023 | 1,150 |  |
| 2024 | 981 |  |
| Total | $ | 3,247 |  |


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001628280-23-009178:notes:211]
Accounts Receivable
Allowance for Doubtful Accounts

[0001628280-23-009178:notes:212]
Changes in the allowance for doubtful accounts were as follows (in thousands):

[0001628280-23-009178:notes:213]
|  | Allowance for Doubtful Accounts |
| Balance at December 31, 2020 | $ | (63) |  |
| Provisions | (50) |  |
| Write-offs, net of recoveries | 63 |
| Balance at December 31, 2021 | $ | (50) |  |
| Provisions | (150) |  |
| Write-offs, net of recoveries | — |
| Balance at December 31, 2022 | $ | (200) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001628280-23-009178:notes:214]
Inventory
Inventory consisted of the following (in thousands):

[0001628280-23-009178:notes:215]
|  | December 31, |
|  | 2022 |  | 2021 |
| Raw materials | $ | 2,334 |  |  | $ | 1,050 |  |
| Finished goods | 7,923 |  |  | 1,840 |  |
| Total | $ | 10,257 |  |  | $ | 2,890 |  |


## nhic:PrepaidExpenseAndOtherAssetsCurrentTextBlock

[0001628280-23-009178:notes:216]
Prepaid expenses and other current assets
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001628280-23-009178:notes:217]
|  | December 31, |
|  | 2022 |  | 2021 |
| Prepaid deposits | $ | 9,666 |  |  | $ | 7,273 |  |
| Prepaid subscriptions | 897 |  |  | 411 |  |
| Current portion of net investment in sales-type leases | 337 |  |  | 206 |  |
| Prepaid insurance | 2,374 |  |  | 2,625 |  |
| Other | 1,114 |  |  | 242 |  |
| Total | $ | 14,388 |  |  | $ | 10,757 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-23-009178:notes:218]
Property and Equipment, Net
Property and equipment, net consisted of the following (in thousands):

[0001628280-23-009178:notes:219]
|  | December 31, |
|  | 2022 |  | 2021 |
| Computers and telecom equipment | $ | 599 |  |  | $ | 40 |  |
| Lab equipment | 871 |  |  | 568 |  |
| Furniture and fixtures | 111 |  |  | 37 |  |
| Leasehold improvements | 542 |  |  | 491 |  |
| Leased equipment | 35,983 |  |  | 20,797 |  |
| Capitalized software | 4,150 |  |  | 1,146 |  |
| Sales demo equipment | 2,340 |  |  | 1,938 |  |
| Equipment held for lease1 | 7,826 |  |  | 2,250 |  |
| Construction in progress | 71 |  |  | — |  |
|  | 52,493 |  |  | 27,267 |  |
| Less: Accumulated depreciation and amortization | (7,786) |  |  | (3,484) |  |
|  | $ | 44,707 |  |  | $ | 23,783 |  |

[0001628280-23-009178:notes:220]
1Represents equipment that has not yet been deployed to a customer and, accordingly, is not being depreciated.

[0001628280-23-009178:notes:221]
As of December 31, 2022 and 2021, the net book value of capitalized software was $3.5 million and $1.1 million, respectively. These amounts include $0.2 million and less than $0.1 million of capitalized stock compensation costs. Depreciation expense and amortization expense related to property and equipment was $5.5 million and $2.9 million for the years ended December 31, 2022 and 2021, respectively, which included amortization expense of capitalized software of $0.6 million and less than $0.1 million for the years ended December 31, 2022 and 2021, respectively.

[0001628280-23-009178:notes:222]
Leased equipment and the related accumulated depreciation were as follows:

[0001628280-23-009178:notes:223]
|  | December 31, |
|  | 2022 |  | 2021 |
| Leased equipment | $ | 35,983 |  |  | $ | 20,797 |  |
| Accumulated depreciation | (5,802) |  |  | (2,631) |  |
| Leased equipment, net | $ | 30,181 |  |  | $ | 18,166 |  |

[0001628280-23-009178:notes:224]
Depreciation expense related to leased units was $4.3 million and $2.5 million during the years ended December 31, 2022 and 2021, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001628280-23-009178:notes:225]
Accrued Expenses and Other Current Liabilities
Accrued expenses and other current liabilities consisted of the following (in thousands):

[0001628280-23-009178:notes:226]
|  | December 31, |
|  | 2022 |  | 2021 |
| Accrued employee compensation and benefits expense | $ | 7,225 |  |  | $ | 5,692 |  |
| Accrued professional services and consulting | 722 |  |  | 1,114 |  |
| Accrued sales tax | 1,680 |  |  | 1,204 |  |
| Accrued property tax | 54 |  |  | 302 |  |
| Other | 1,864 |  |  | 1,239 |  |
|  | $ | 11,545 |  |  | $ | 9,551 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-23-009178:notes:227]
Long-term Debt
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001628280-23-009178:notes:228]
|  | December 31, |
|  | 2022 |  | 2021 |
| Term loans payable | $ | 30,000 |  |  | $ | 10,000 |  |
| Less: Unamortized discount | (317) |  |  | (55) |  |
|  | 29,683 |  |  | 9,945 |  |
| Less: Current portion of long-term debt | 10,000 |  |  | 2,000 |  |
| Long-term debt, net of discount | $ | 19,683 |  |  | $ | 7,945 |  |

[0001628280-23-009178:notes:229]
Term Loan Agreements

[0001628280-23-009178:notes:230]
JPMorgan Chase Bank, N.A.(“JPM”) Credit Agreement

[0001628280-23-009178:notes:231]
In December 2020, the Company entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024 and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022.

[0001628280-23-009178:notes:232]
Principal and interest on the JPM Credit Agreement was payable monthly commencing on July 1, 2022. The JPM Credit Agreement accrued interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 2.25% or (B) 5.5%. The revolving line of credit accrued interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 1.25% or (B) 4.5%. Upon closing, the Company issued warrants to purchase 377,837 shares of common stock to the lender with an exercise price of $0.42 per share with a fair value of $0.1 million on the date of issuance. The Company incurred debt issuance costs of $0.1 million equal to the fair value of the warrants in connection with the JPM Credit Agreement. These costs were recorded as debt discount and were amortized to interest expense, using the effective interest method, over the term of the loan. Upon the closing of the Merger, the warrants were converted into shares of the Company's common stock. The Company’s obligations under the JPM Credit Agreement are secured by a first-priority security interest in all of its assets, including intellectual property.

[0001628280-23-009178:notes:233]
We fully repaid all borrowings and accrued interest under the JPM Credit Agreement and terminated the JPM Credit Agreement in November 2022.

[0001628280-23-009178:notes:234]
Silicon Valley Bank Credit Agreement

[0001628280-23-009178:notes:235]
In December 2022, the Company entered into a loan and security agreement with Silicon Valley Bank (the "2022 SVB Credit Agreement") in order to finance purchases of hardware to be leased to customers. The 2022 SVB Credit Agreement provides for an initial term loan advance of $30.0 million, which is approximately equivalent to the value of all

[0001628280-23-009178:notes:236]
hardware purchases made to support leasing transactions with the Company's customers through December 21, 2022 (the "SVB Closing Date"), with the opportunity to obtain, within 18 months after the SVB Closing Date, additional term loan advances, subject to the satisfaction of certain conditions, in an aggregate principal amount equal to $20.0 million (subject to an increase of an additional $25.0 million upon the satisfaction of certain conditions and approval from SVB). Each 2022 SVB Term Loan will mature on the 36-month anniversary of the extension thereof. The obligations under the 2022 SVB Credit Agreement are secured by a perfected security interest in substantially all of the Company's assets, with the exception of intellectual property, pursuant to the terms of the 2022 SVB Credit Agreement. The interest rate applicable to the SVB Term Loans is the greater of (a) the Wall Street Journal Prime Rate plus 1.0% or (b) 7.25% per annum. Interest and principal under the SVB Credit Agreement are payable monthly. Each 2022 SVB Term Loan advance may be prepaid in full, subject to certain conditions, with payment of (calculated, in each case, based on the then-outstanding principal amount of such 2022 SVB Term Loan advance subject to prepayment) a prepayment premium equal to (i) 1.0% if prepaid on or prior to December 21, 2023; (ii) 0.75% if prepaid after December 21, 2023 but on or prior to December 21, 2024; (iii) 0.50% if prepaid after December 21, 2024 but on or prior to December 21, 2025; and (iv) 0% if prepaid after December 21, 2025.

[0001628280-23-009178:notes:237]
In connection with the closure of SVB on March 10, 2023 and the subsequent creation of SVBB (see Note 2), SVBB assumed all loans that were previously held by SVB. SVBB continues to hold the Company’s term loans under the same existing terms and covenants which were in place with SVB.

[0001628280-23-009178:notes:238]
As of December 31, 2022, the unamortized debt discount and debt issuance costs were $0.3 million. As of December 31, 2022, the accrued interest on the 2022 SVB Credit Agreement was less than $0.1 million, which is included in accrued expenses and other current liabilities in the consolidated balance sheet. Interest expense related to the 2022 SVB Credit Agreement totaled less than $0.1 million for the year ended December 31, 2022. The interest rate in effect as of December 31, 2022 was 8.50% for the 2022 SVB Credit Agreement.

[0001628280-23-009178:notes:239]
As of December 31, 2022, future principal payments on long-term debt are as follows (in thousands):

[0001628280-23-009178:notes:240]
| Year Ending December 31, |  |
| 2023 | $ | 10,000 |  |
| 2024 | 10,000 |  |
| 2025 | 10,000 |  |
|  | $ | 30,000 |  |

[0001628280-23-009178:notes:241]
Convertible Note

[0001628280-23-009178:notes:242]
In September 2020, the Company entered into the 2020 Convertible Notes with an investor for gross proceeds of $2.0 million with a stated interest rate of 6.0% per annum. An additional $2.0 million in gross proceeds were made available in December 2020 upon achievement of the integration milestone, whereby the Company successfully created software utilizing the investor’s application programming interface. The 2020 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds of the issuance of preferred stock totaled at least $10.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2020 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $1.0 million, and the notes, with an initial carrying value of $3.0 million, and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the merger. Interest expense related to the 2020 Convertible Notes totaled $0.3 million for the year ended December 31, 2021.

[0001628280-23-009178:notes:243]
In January and February 2021, the Company entered into the 2021 Convertible Notes with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled

[0001628280-23-009178:notes:244]
at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $7.0 million, and the notes, with an initial carrying value of $23.0 million, and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of December 31, 2021 as the liability was settled pursuant to the closing of the merger.

[0001628280-23-009178:notes:245]
In June 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. This modification of the notes resulted in an extinguishment and the Company recognized a loss on extinguishment of the 2021 Convertible Notes of $11.8 million. The $26.7 million carrying value of the notes at June 21, 2021 was derecognized and replacement notes with an initial carrying value of $29.6 million were recorded. Additionally, in the extinguishment accounting, a derivative liability of $19.2 million was recognized, which represents the value of the 1,000,000 NHIC shares as well as a bifurcated embedded derivative for the conversion option.

[0001628280-23-009178:notes:246]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense). Interest expense related to the 2021 Convertible Notes totaled $4.9 million for the year ended December 31, 2021.


## nhic:WarrantsAndRightsNoteDisclosureTextBlock

[0001628280-23-009178:notes:247]
Warrants
In February 2019, in connection with the 2019 Term Loan Advance, the Company issued a warrant to SVB for the purchase of 28,338 shares of common stock at an exercise price of $0.24 per share (the “2019 SVB common stock warrant”). The 2019 SVB common stock warrant was immediately exercisable and expires in February 2029. The warrant was classified as an equity instrument and recorded at its fair value of less than $0.1 million on the date of issuance through additional paid-in-capital. In connection with the closing of the Merger, all of the outstanding 2019 SVB common stock warrants were converted into shares of the Company’s common stock.

[0001628280-23-009178:notes:248]
In March 2020, in connection with the 2020 Term Loan Advance, the Company issued a warrant to SVB for the purchase of 279,974 shares of common stock at an exercise price of $0.40 per share (the “2020 SVB common stock warrant”). The 2020 SVB common stock warrant was immediately exercisable and expires in March 2030. The warrant was classified as an equity instrument and recorded at its fair value of less than $0.1 million on the date of issuance through additional paid-in-capital. In connection with the closing of the Merger, all of the outstanding 2020 SVB common stock warrants were converted into shares of the Company’s common stock.

[0001628280-23-009178:notes:249]
In December 2020, in connection with the JPM Term Loan, the Company issued a warrant to JPM for the purchase of 377,837 shares of common stock at an exercise price of $0.42 per share (the “2020 JPM common stock warrant”). The 2020 JPM common stock warrant was immediately exercisable and expires in December 2030. The warrant was classified as an equity instrument and recorded at its fair value of $0.1 million on the date of issuance through additional paid-in-capital. In connection with the closing of the Merger, all of the outstanding 2020 JPM common stock warrants were converted into shares of the Company’s common stock.

[0001628280-23-009178:notes:250]
In January 2021, the Company granted the Finback Common Stock Warrants. Upon the closing of the Merger, the vested Finback Common Stock Warrants automatically converted into 131,713 shares of the Company’s common stock. As of December 31, 2022, none of the vested Finback Common Stock Warrants were exercised.

[0001628280-23-009178:notes:251]
In connection with the closing of the Merger, the Company assumed the Public Warrants for the purchase of 14,325,000 shares of common stock at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and recorded at its fair value of $23.6 million on the date of the closing of the Merger with an offset to additional paid-in-capital and are subsequently remeasured to fair value

[0001628280-23-009178:notes:252]
at each reporting date based on the publicly available trading price. The change in fair value of the public warrant liability of $4.9 million was recognized for the year ended December 31, 2022 as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001628280-23-009178:notes:253]
As of December 31, 2022 and 2021, warrants to purchase the following classes of Preferred Stock and common stock outstanding consisted of the following in the tables below. The warrants outstanding as of December 31, 2021 have been updated to reflect the vested Finback Common Stock Warrants automatically converted to the Company's common stock upon the closing of the Merger:

[0001628280-23-009178:notes:254]
| December 31, 2022 |
| Issuance Date |  | ContractualTerm(in years) |  | Underlying EquityInstrument |  | Balance SheetClassification |  | Shares IssuableUpon Exerciseof Warrant |  | WeightedAverageExercise Price |
| January 13, 2021 |  | 10 |  | Common stock |  | Equity |  | 2,421,200 |  |  | $ | 0.42 |  |
| July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,994 |  |  | $ | 11.50 |  |
|  |  |  |  |  |  |  |  | 16,746,194 |  |  |  |

[0001628280-23-009178:notes:255]
| December 31, 2021 |
| Issuance Date |  | ContractualTerm(in years) |  | Underlying EquityInstrument |  | Balance SheetClassification |  | Shares IssuableUpon Exerciseof Warrant |  | WeightedAverageExercise Price |
| January 13, 2021 |  | 10 |  | Common stock |  | Equity |  | 2,421,200 |  |  | $ | 0.42 |  |
| July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,324,994 |  |  | $ | 11.50 |  |
|  |  |  |  |  |  |  |  | 16,746,194 |  |  |  |


## nhic:TemporaryEquityDisclosureTextBlock

[0001628280-23-009178:notes:256]
Convertible Preferred Stock and Preferred Stock
Prior to the Merger, Legacy Evolv had issued Series A convertible preferred stock (“Series A Preferred Stock”), Series A-1 convertible preferred stock (“Series A-1 Preferred Stock”), Series B convertible preferred stock (“Series B Preferred Stock”), and Series B-1 convertible preferred stock (“Series B-1 Preferred Stock”), collectively referred to as the “Preferred Stock”.

[0001628280-23-009178:notes:257]
Pursuant to the Merger Agreement, immediately prior to the Merger, each share of Legacy Evolv’s Series A-1, Series B-1, and Series B preferred stock outstanding converted to Legacy Evolv common stock on a 1:1 conversion ratio. Pursuant to the Merger Agreement, immediately prior to the Merger, each share of Legacy Evolv’s Series A preferred stock outstanding converted to Legacy Evolv common stock on a 2:1 conversion ratio. On the closing date of the Merger, each share of Legacy Evolv common stock then issued and outstanding was canceled and the holders thereof in exchange received shares of Evolv Technologies Holdings, Inc. equal to 0.378 shares for each share of Legacy Evolv common stock. As of December 31, 2022 and 2021, the Company had no preferred stock outstanding as all convertible preferred stock converted to common stock upon closing of the Merger.


## nhic:CommonStockDisclosureTextBlock

[0001628280-23-009178:notes:258]
Common Stock
Each share of common stock entitles the holder to one vote on all matters submitted to a vote of the Company’s stockholders. Common stockholders are entitled to receive dividends, as may be declared by the board of directors, subject to the preferential dividend rights of Preferred Stock. As of December 31, 2022 and 2021, no cash dividends had been declared or paid.

[0001628280-23-009178:notes:259]
As of December 31, 2022 and 2021, the Company had reserved 79,795,376 and 75,876,664 shares, respectively, of common stock for the conversion of the outstanding Preferred Stock, exercise of outstanding stock options, vesting of outstanding restricted stock units and performance stock units, vesting of contingent earn-out shares, vesting of contingently issuable common stock, granting of awards under the Company’s 2021 Equity Incentive Plan (see Note 16),  issuance of shares under the 2021 Employee Stock Purchase Plan (see Note 16), and the exercise of outstanding warrants (see Note 13).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-23-009178:notes:260]
Stock-Based Compensation
2013 Equity Incentive Plan

[0001628280-23-009178:notes:261]
The Company’s 2013 Equity Incentive Plan (the “2013 Plan”) provides for the Company to grant incentive stock options or nonqualified stock options, restricted stock awards and other stock-based awards to employees, officers, directors, and non-employees of the Company. Per the initial terms of the 2013 Plan, up to 1,077,704 shares of common stock may be issued. The Company does not intend to issue any additional awards under the 2013 Plan.

[0001628280-23-009178:notes:262]
2021 Equity Incentive Plan

[0001628280-23-009178:notes:263]
The Company’s 2021 Equity Incentive Plan (the “2021 Plan”) provides for the Company to grant incentive stock options or nonqualified stock options, restricted stock awards, restricted stock units, performance stock units, and other stock-based awards to employees, officers, directors, and non-employees of the Company. A total of 21,177,295 shares of common stock were initially authorized under the 2021 Plan, subject to annual evergreen increases of up to 5% of total common shares outstanding as of the end of the prior year. As of December 31, 2022, 17,388,913 shares were available for future grant under the 2021 Plan. Shares, units, and options that are expired, forfeited, canceled, or otherwise terminated without having been fully exercised will be available for future grant under the 2021 Plan. In addition, shares of common stock that are tendered to the Company by a participant to exercise an award are added to the number of shares of common stock available for future grants.

[0001628280-23-009178:notes:264]
The 2021 Plan is administered by the Board of Directors or, at the discretion of the Board of Directors, by a committee of the Board of Directors. The exercise prices, vesting and other restrictions are determined at the discretion of the Board of Directors, or its committee if so delegated, except that the exercise price per share of stock options may not be less than 100% of the fair market value of a share of common stock on the date of grant and the term of the stock option may not be greater than ten years. Stock options granted to employees, officers, members of the Board of Directors and non-employees vesting terms are determined on an individual basis on the date of grant. Prior to the closing of the Merger, the Company’s Board of Directors valued the Company’s common stock, taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors which may have changed since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the fair value of each share of common stock underlying stock-based awards is based on the closing price of our common stock as reported by Nasdaq on the date of grant.

[0001628280-23-009178:notes:265]
Stock Options

[0001628280-23-009178:notes:266]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the years ended December 31, 2022 and 2021:

[0001628280-23-009178:notes:267]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |
| Risk-free interest rate | 1.6 | % |  | 0.7 | % |
| Expected term (in years) | 6.1 |  | 6.0 |
| Expected volatility | 75.0 | % |  | 31.4 | % |
| Expected dividend yield | 0.0 | % |  | 0.0 | % |

[0001628280-23-009178:notes:268]
The following tables summarize the Company’s stock option activity since December 31, 2020 (in thousands, except for share and per share data):

[0001628280-23-009178:notes:269]
|  | Number ofShares |  | WeightedAverageExercise Price |  | WeightedAverageRemainingContractual Term |  | AggregateIntrinsic Value |
|  |  |  |  |  | (in years) |  |  |
| Outstanding as of December 31, 2020 | 18,770,767 |  | $ | 0.36 |  |  |  |  |  |
| Granted | 6,472,725 |  | 0.42 |  |  |  |  |  |
| Exercised | (2,806,961) |  | 0.33 |  |  |  |  |  |
| Exercised upon settlement of related party note | (1,469,366) |  | 0.24 |  |  |  |  |  |
| Forfeited | (198,035) |  | 0.37 |  |  |  |  |  |
| Outstanding as of December 31, 2021 | 20,769,130 |  | $ | 0.39 |  |  |  |  |  |
| Granted | 2,262,925 |  | 3.49 |  |  |  |  |  |
| Exercised | (1,896,975) |  | 0.43 |  |  |  |  |  |
| Forfeited | (738,256) |  | 0.42 |  |  |  |  |  |
| Outstanding as of December 31, 2022 | 20,396,824 |  | 0.73 |  |  | 7.18 |  | $ | 39,891 |  |
| Vested and expected to vest as of December 31, 2022 | 20,396,824 |  | $ | 0.73 |  |  | 7.18 |  | $ | 39,891 |  |
| Options exercisable as of December 31, 2022 | 13,510,205 |  | $ | 0.38 |  |  | 6.61 |  | $ | 29,872 |  |

[0001628280-23-009178:notes:270]
The aggregate intrinsic value of options is calculated as the difference between the exercise price of the stock options and the fair value of the Company’s common stock for those options that had exercise prices lower than the fair value of the Company’s common stock.

[0001628280-23-009178:notes:271]
The weighted average grant date fair value of stock options granted was $2.32 and $0.14 during the years ended December 31, 2022 and 2021, respectively. The aggregate intrinsic value of the stock options exercised was $4.4 million and $18.5 million during the years ended December 31, 2022 and 2021, respectively.

[0001628280-23-009178:notes:272]
Restricted Stock Units

[0001628280-23-009178:notes:273]
The following table summarizes the Company’s restricted stock units activity since December 31, 2020:

[0001628280-23-009178:notes:274]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2020 | — |  | — |  |
| Granted | 2,013,110 |  | 6.76 |  |
| Vested | (2,625) |  | 7.01 |  |
| Forfeited | (58,561) |  | 7.01 |  |
| Outstanding as of December 31, 2021 | 1,951,924 |  | 6.76 |  |
| Granted | 7,613,472 |  | $ | 3.26 |  |
| Vested | (565,774) |  | 6.72 |  |
| Forfeited | (1,497,677) |  | 5.15 |  |
| Outstanding as of December 31, 2022 | 7,501,945 |  | $ | 3.54 |  |

[0001628280-23-009178:notes:275]
During the year ended December 31, 2022, the aggregate grant-date fair value of restricted stock units issued under the 2021 Plan was $24.9 million. Restricted stock units generally vest ratably over a three year period subject to the

[0001628280-23-009178:notes:276]
grantee's continued service through the applicable vesting date. During the year ended December 31, 2022, the total fair value of shares vested was $3.8 million.

[0001628280-23-009178:notes:277]
Performance Stock Units

[0001628280-23-009178:notes:278]
The following table summarizes the Company's performance stock units activity since December 31, 2021:

[0001628280-23-009178:notes:279]
|  | Number ofShares |  | Grant Date FairValue |
| Outstanding as of December 31, 2021 | — |  |  | $ | — |  |
| Granted | 947,000 |  |  | 2.65 |  |
| Vested | — |  |  | — |  |
| Forfeited | (83,000) |  |  | 2.65 |  |
| Outstanding as of December 31, 2022 | 864,000 |  |  | $ | 2.65 |  |

[0001628280-23-009178:notes:280]
During the year ended December 31, 2022, the aggregate grant-date value of performance stock units issued under the 2021 Plan was $2.5 million. Based upon the terms of the award agreements, 50% of the applicable units shall vest on January 1, 2023 and 50% on January 1, 2024, provided that the Company has achieved a certain performance goal for fiscal year 2022 and subject to the grantee’s continued service through the applicable vesting date.

[0001628280-23-009178:notes:281]
2021 Employee Stock Purchase Plan

[0001628280-23-009178:notes:282]
In July 2021, the Company’s Board of Directors adopted the 2021 Employee Stock Purchase Plan (“2021 ESPP”), which was subsequently approved by the Company’s stockholders and became effective on July 16, 2021. The 2021 ESPP authorizes the initial issuance of up to 3,435,748 shares of the Company’s common stock to eligible employees of the Company or, as designated by the Company’s Board of Directors, employees of a related company. The 2021 ESPP provides that the number of shares reserved and available for issuance under the 2021 ESPP will automatically increase each January 1, beginning on January 1, 2022 and ending on (and including) January 1, 2032, by an amount equal to the lesser of (i) 1% of the outstanding number of shares of common stock on the immediately preceding December 31 and (ii) such smaller number of shares as determined by the Company’s Board of Directors. As of December 31, 2022, 4,863,198 shares of the Company’s common stock were available for future issuance. The Company’s Board of Directors may from time to time grant or provide for the grant to eligible employees of options to purchase common stock under the 2021 ESPP during a specific offering period. As of December 31, 2022, no offerings have been approved.

[0001628280-23-009178:notes:283]
Finback Common Stock Warrants

[0001628280-23-009178:notes:284]
The Company utilized a Black-Scholes pricing model to determine the grant-date fair value of the Finback Common Stock Warrants. The assumptions used are presented in the following table:

[0001628280-23-009178:notes:285]
| Warrants - Black Scholes |  |
| Risk-free interest rate | 0.4 | % |
| Expected term (in years) | 3.0 |
| Expected volatility | 23.9 | % |
| Expected dividend yield | — | % |

[0001628280-23-009178:notes:286]
On the date of issuance, the Finback Common Stock Warrants were valued at $19.5 million.

[0001628280-23-009178:notes:287]
Upon the closing of the Merger, vested Finback Common Stock Warrants automatically converted into 131,713 shares of the Company’s common stock. As of December 31, 2022, 830,216 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $1.8 million. The remaining 1,590,984 Finback Common Stock Warrants are unvested and have a total unrecognized grant date fair value of $12.1 million. As of December 31, 2022, none of the Finback common stock warrants were exercised. The Company recognizes compensation expense for the Finback

[0001628280-23-009178:notes:288]
Common Stock Warrants when the warrants become vested based on meeting the certain sales criteria. During the years ended December 31, 2022 and 2021, the Company recorded $4.5 million and $2.3 million, respectively, of stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants.

[0001628280-23-009178:notes:289]
Stock-based compensation expense was classified in the consolidated statements of operations and comprehensive loss as follows (in thousands):

[0001628280-23-009178:notes:290]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |
| Cost of revenue | $ | 829 |  | $ | 143 |
| Research and development | 4,009 |  | 878 |
| Sales and marketing | 10,038 |  | 5,735 |
| General and administrative | 7,622 |  | 2,840 |
| Total stock-based compensation expense | $ | 22,498 |  | $ | 9,596 |

[0001628280-23-009178:notes:291]
Stock-based compensation expense by award type recognized in the consolidated statements of operations and comprehensive loss was as follows (in thousands):

[0001628280-23-009178:notes:292]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |
| Stock options | $ | 1,594 |  | $ | 628 |
| Earn-out shares | 6,499 |  | 5,334 |
| Warrants | 4,523 |  | 2,297 |
| RSUs and PSUs | 9,882 |  | 1,337 |
| Total stock-based compensation expense | $ | 22,498 |  | $ | 9,596 |

[0001628280-23-009178:notes:293]
Total unrecognized compensation expense related to stock options and restricted stock units as of December 31, 2022, was $25.9 million, which is expected to be recognized over a weighted average period of 2.3 years. Total unrecognized compensation expense related to earn-out shares associated with the share-based compensation arrangement as of December 31, 2022, was $2.6 million, which is expected to be recognized over a weighted average period of 0.8 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-23-009178:notes:294]
Income Taxes
The components of the Company’s loss before income tax expense are as follows (in thousands):

[0001628280-23-009178:notes:295]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |
| United States | $ | (85,760) |  |  | $ | (10,430) |  |
| Foreign | (646) |  |  | (458) |  |
| Loss before income tax provision | $ | (86,406) |  |  | $ | (10,888) |  |

[0001628280-23-009178:notes:296]
There is no provision for income taxes for the years ended December 31, 2022 and 2021 because the Company has historically incurred net operating losses and maintains a full valuation allowance against its deferred tax assets.

[0001628280-23-009178:notes:297]
The effective tax rate differs from the U.S. federal statutory rate primarily due to the full valuation allowance maintained on the Company’s net deferred tax assets for the years ended December 31, 2022 and 2021 and as a result of non-deductible items for the year ended December 31, 2022 related to the closing of the Merger. A reconciliation of the U.S. federal statutory income tax rate to the Company’s effective income tax rate is as follows:

[0001628280-23-009178:notes:298]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |
| Federal statutory income tax rate | 21.0 % |  | 21.0 % |
| State income taxes, net of federal benefit | 3.5 |  |  | 19.2 |  |
| Federal and state research and development tax credits | (1.2) |  |  | 9.7 |  |
| Loss on extinguishment of debt | — |  |  | (24.5) |  |
| Merger transaction costs | — |  |  | (1.3) |  |
| Change in fair value of contingent earn-out liability and contingently issuable common stock liability | 3.4 |  |  | 126.7 |  |
| Change in fair value of derivative liability | — |  |  | (3.4) |  |
| Non-deductible convertible notes interest | — |  |  | (10.2) |  |
| Change in valuation allowance | (23.6) |  |  | (140.7) |  |
| Change in tax rate | (0.1) |  |  | (0.5) |  |
| Stock-based compensation | (0.2) |  |  | 4.3 |  |
| Non-deductible compensation | (2.6) |  |  | — |  |
| Permanent differences | (0.2) |  |  | (0.4) |  |
| Other | — |  |  | 0.1 |  |
| Effective income tax rate | 0.0 | % |  | 0.0 | % |

[0001628280-23-009178:notes:299]
Net deferred tax assets consisted of the following (in thousands):

[0001628280-23-009178:notes:300]
|  | December 31, |
|  | 2022 |  | 2021 |
| Deferred tax assets: |  |  |  |
| Net operating loss carryforwards | $ | 36,518 |  | $ | 25,461 |
| Research and development tax credit carryforwards | 3,836 |  | 4,910 |
| Capitalized research and development costs | 9,965 |  | 8,436 |
| Accrued expenses | 6,660 |  | 3,722 |
| Deferred revenue | 8,884 |  | 2,270 |
| Lease liability | 490 |  | — |
| Other | 106 |  | 43 |
| Total deferred tax assets | 66,459 |  | 44,842 |
| Valuation allowance | (64,570) |  |  | (43,966) |  |
| Total deferred tax assets, net of valuation allowance | 1,889 |  | 876 |
| Deferred tax liabilities: |  |  |  |
| Depreciation and amortization | (1,464) |  |  | (860) |  |
| Right of use lease asset | (409) |  | — |
| Other | (16) |  | (16) |
| Total deferred tax liabilities | (1,889) |  | (876) |
| Net deferred tax assets | $ | — |  | $ | — |

[0001628280-23-009178:notes:301]
As of December 31, 2022 and December 31, 2021, the Company had gross federal net operating losses of $20.1 million and $20.1 million that are subject to expire at various dates beginning in 2033, and federal net operating losses of $124.3 million and $79.7 million, which have no expiration date and can be used to offset up to 80% of future taxable income in any one tax period, respectively. The Company also had gross state net operating loss carryforwards of $103.8 million and $75.8 million for the years ended December 31, 2022 and 2021, respectively, which may be available to offset future state taxable income and which begin to expire in 2033. Additionally, as of December 31, 2022 and December 31, 2021, the Company had gross United Kingdom net operating loss carryforwards of approximately $2.3 million and $1.5 million, respectively, that will not expire. As of December 31, 2022, the Company had gross U.S. federal and state research and development and other tax credit carryforwards of $2.5 million and $1.6 million, respectively, which may be available to offset future tax liabilities and the majority of which begin to expire in 2033 and 2029, respectively. As of December 31, 2021, the Company had gross U.S. federal and state research and development and other tax credit carryforwards of $3.3 million and $2.1 million, respectively, which may be available to offset future tax liabilities and the majority of which begin to expire in 2033 and 2029, respectively.

[0001628280-23-009178:notes:302]
Utilization of the U.S. federal and state net operating loss carryforwards and research and development tax credit carryforwards may be subject to a substantial annual limitation under Sections 382 and 383 of the Internal Revenue Code of 1986, and corresponding provisions of state law, due to ownership changes that have occurred previously or that could occur in the future. These ownership changes may limit the amount of carryforwards that can be utilized annually to offset future taxable income or tax liabilities. In general, an ownership change, as defined by Section 382, results from transactions increasing the ownership of certain stockholders or public groups in the stock of a corporation by more than 50% over a three-year period. The Company has not conducted a study to assess whether a change of control has occurred or whether there have been multiple changes of control since inception due to the significant complexity and cost associated with such a study. If the Company has experienced a change of control, as defined by Section 382, at any time since inception, utilization of the net operating loss carryforwards or research and development tax credit carryforwards would be subject to an annual limitation under Section 382, which is determined by first multiplying the value of the Company’s stock at the time of the ownership change by the applicable long-term tax-exempt rate, and then could be subject to additional adjustments, as required. Any limitation may result in expiration of a portion of the net operating loss carryforwards or research and development tax credit carryforwards before utilization.

[0001628280-23-009178:notes:303]
The Company considered the significant negative evidence of its history of cumulative net operating losses incurred since inception, as well as other positive and negative evidence bearing upon its ability to realize the deferred tax assets, and has concluded that it is more likely than not that the Company will not realize the benefits of the deferred tax assets. Accordingly, a full valuation allowance has been established against the net deferred tax assets as of December 31, 2022 and 2021. If or when recognized, the tax benefits related to any reversal of the valuation allowance on deferred tax assets as of December 31, 2022, will be accounted for as follows: approximately $62.1 million will be recognized as a reduction of income tax expense and $2.5 million will be recorded as an increase in equity. The Company reevaluates the positive and negative evidence at each reporting period.

[0001628280-23-009178:notes:304]
Changes in the valuation allowance for deferred tax assets related primarily to the increase in net operating loss carryforwards and capitalized R&D costs and were as follows (in thousands):

[0001628280-23-009178:notes:305]
|  | December 31, |
|  | 2022 |  | 2021 |
| Valuation allowance as of beginning of year | $ | 43,966 |  | $ | 26,275 |
| Additions charged to provision for income taxes | 20,320 |  | 15,534 |
| Additions charged to equity | 332 |  | 2,155 |
| Currency translation and other | (48) |  | 2 |
| Valuation allowance as of end of year | $ | 64,570 |  | $ | 43,966 |

[0001628280-23-009178:notes:306]
As of December 31, 2022 and 2021, the Company had not recorded any amounts for unrecognized tax benefits. The Company’s policy is to record interest and penalties related to income taxes as part of its income tax provision. As of December 31, 2022 and 2021, the Company had no accrued interest or penalties related to uncertain tax positions and no amounts had been recognized in the Company’s consolidated statements of operations and comprehensive loss. The Company files income tax returns as prescribed by the tax laws of the jurisdictions in which it operates. In the normal 
course of business, the Company is subject to examination by federal, state, and non-US jurisdictions, where applicable. The Company is open to future tax examinations in the US under statute from 2019 to the present; however, carryforward attributes that were generated prior to 2019 may still be adjusted upon examination by federal, state, or local tax authorities if they either have been or will be used in a future period. The Company is also open for future tax examinations under statute from 2020 to the present in the UK. The Company has not received notice of examination in any jurisdictions for any tax year open under statute.


## us-gaap:EarningsPerShareTextBlock

[0001628280-23-009178:notes:307]
Net Loss per Share
Basic and diluted net loss per share attributable to common stockholders was calculated as follows (in thousands, except share and per share amounts):

[0001628280-23-009178:notes:308]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |
| Numerator: |  |  |  |
| Net income (loss) attributable to common stockholders – basic and diluted | $ | (86,406) |  |  | $ | (10,888) |  |
| Denominator: |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 143,858,668 |  | 71,662,694 |
| Net loss per share attributable to common stockholders – basic and diluted | $ | (0.60) |  |  | $ | (0.15) |  |

[0001628280-23-009178:notes:309]
The following potentially dilutive outstanding securities were excluded from the computation of diluted net loss per share attributable to common stockholders because their effect would have been anti-dilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the period:

[0001628280-23-009178:notes:310]
|  | Year Ended December 31, |
|  | 2022 |  | 2021 |
| Options issued and outstanding | 20,396,824 |  |  | 20,769,130 |  |
| Public Warrants to purchase common stock | 14,324,994 |  |  | 14,324,994 |  |
| Warrants to purchase common stock (Finback)** | 2,421,200 |  |  | 2,421,200 |  |
| Unvested restricted stock units | 7,501,945 |  |  | 1,951,924 |  |
| Unvested performance stock units | 864,000 |  |  | — |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |
| Contingently issuable common stock* | 1,897,500 |  |  | 1,897,500 |  |
|  | 62,406,463 |  |  | 56,364,748 |  |

[0001628280-23-009178:notes:311]
*Issuance of Earn-out shares and Contingently issuable common stock are contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period

[0001628280-23-009178:notes:312]
**Includes 830,216 vested warrants and 1,590,984 unvested warrants as of December 31, 2022.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-23-009178:notes:313]
Related Party Transactions
Nonrecourse Promissory Note with Officer

[0001628280-23-009178:notes:314]
In August 2020, the Company entered into a $0.4 million promissory note with an officer with the proceeds being used to exercise options for 1,469,366 shares of common stock at a price of $0.24 per share. The promissory note bore interest at the Wall Street Journal Prime Rate and was secured by the underlying shares of common stock that were issued upon the exercise of the stock options. The promissory note was treated as nonrecourse as the loan was only secured by the common stock issued from the exercise of the stock options. As such, (i) the underlying stock option grant was still considered to be outstanding and the shares of common stock were not considered issued and outstanding for accounting purposes until the loan was repaid in full or otherwise forgiven and (ii) no receivable was recorded for the promissory note

[0001628280-23-009178:notes:315]
on the Company’s consolidated balance sheets. As such, the promissory note effectively extended the maturity date of the option grant for the life of the loan, this change is treated as a stock option modification. The incremental fair value from the stock option modification was deemed immaterial. The interest on this nonrecourse loan is also considered nonrecourse. As the Company has no intent to collect interest, no accrued interest was recorded.

[0001628280-23-009178:notes:316]
In June 2021, the Company agreed to repurchase 43,665 shares of common stock valued at $8.05 per share of common stock held by the officer of the Company. In exchange for the repurchase of the common stock by the Company, the $0.4 million promissory note held by the officer was considered repaid in full.

[0001628280-23-009178:notes:317]
Business Development Agreement with Finback

[0001628280-23-009178:notes:318]
In January 2021, the Company granted the Finback Common Stock Warrants. During the year ended December 31, 2022 and 2021, the Company recorded $4.5 million and $2.3 million, respectively, of stock-based compensation expense within sales and marketing expense for the Finback Common Stock Warrants.

[0001628280-23-009178:notes:319]
In connection with the Merger and pursuant to the Merger Agreement, in addition to earn-out shares allocated to Finback based on its common stock ownership percentage as of the Merger date, Finback is entitled to receive a proportional share of earn-out shares based upon its remaining unvested warrants as of the Merger Date. During the year ended December 2021, $1.5 million stock-based compensation expense was recorded within sales and marketing expense for the earn-out shares allocated to Finback related to the unvested warrants. During the year ended December 31, 2022, no stock-based compensation expense was recorded within sales and marketing expense for the earn-out shares allocated to Finback.

[0001628280-23-009178:notes:320]
Original Equipment Manufacturer Partnership Agreement with Motorola Solutions, Inc.

[0001628280-23-009178:notes:321]
In December 2020, the Company entered into an original equipment manufacturer partnership agreement (the “Distribution Agreement”) with Motorola Solutions, Inc. ("Motorola"), an investor in the Company. In June 2021, the partnership agreement was amended by the Amended and Restated Distribution Agreement (the “Amended and Restated Distribution Agreement”). Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. During the year ended December 31, 2022 and 2021, revenue from Motorola’s distributor services was $11.6 million and $0.6 million, respectively. As of December 31, 2022 and 2021, accounts receivable related to Motorola’s distributor services was $12.5 million and $1.2 million, respectively.

[0001628280-23-009178:notes:322]
Reseller Agreement with Stanley Black & Decker

[0001628280-23-009178:notes:323]
In June 2020, the Company entered into a reseller agreement (the “Reseller Agreement”) with Stanley Black & Decker whereby Stanley Black & Decker, directly or through its affiliates, resells the Company's products. During the year ended December 31, 2022 and 2021, revenue from Stanley Black & Decker’s reseller services was $1.9 million and less than $0.1 million, respectively. As of December 31, 2022 and 2021, accounts receivable related to Stanley Black & Decker’s reseller services was $2.2 million and less than $0.1 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-23-009178:notes:324]
Commitments and Contingencies
Indemnification Agreements

[0001628280-23-009178:notes:325]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its consolidated financial statements as of December 31, 2022 or 2021.

[0001628280-23-009178:notes:326]
Legal Proceedings

[0001628280-23-009178:notes:327]
The Company is not a party to any litigation and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred.


## us-gaap:ErrorCorrectionTextBlock

[0001628280-23-009178:notes:328]
Revision of Prior Period Financial StatementsAs discussed in Note 1, in preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified errors in its previously issued financial statements whereby (a) certain expenses that were cost of subscription revenue related and cost of service revenue related were inaccurately classified as sales and marketing expenses on the consolidated statements of operations and comprehensive loss, (b) certain equipment under lease or held for lease was inaccurately classified as inventory on the consolidated balance sheets and a portion of the cash outflows related to the equipment under lease or held for lease were misclassified between operating and investing cash flows on the consolidated statements of cash flows, and (c) the vesting of warrants related to the Business Development Agreement disclosed in Note 16 were not accounted for accurately. The identified errors impacted the Company's previously issued 2020 annual financial statements, 2021 quarterly and annual financial statements, and quarterly financial statements for the three months ended March 31, 2022. The Company has made adjustments to the prior period amounts presented in these financial statements accordingly. Additionally, the Company has made adjustments to correct for other previously identified immaterial errors. The Company evaluated the errors and determined that the related impacts were not material to any previously issued annual or interim financial statements. The impacts of the revisions to the quarterly periods ending June 30, 2021 and September 30, 2021 are presented in the Company's Quarterly Reports on Form 10-Q for the periods ending June 30, 2022 and September 30, 2022, respectively. The impact of the revisions to the quarterly periods ending March 31, 2022 and March 31, 2021 are presented in Note 22. The impact of the revisions to the periods presented in this Annual Report on Form 10-K are as follows (in thousands):
Revised Consolidated Balance Sheets

[0001628280-23-009178:notes:329]
|  | December 31, 2021 |
|  | As Previously Reported | Adjustment | As Revised |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 307,492 |  | $ | — |  | $ | 307,492 |  |
| Restricted cash | 400 |  | — |  | 400 |  |
| Accounts receivable, net | 6,477 |  | — |  | 6,477 |  |
| Inventory | 5,140 |  | (2,250) |  | 2,890 |  |
| Current portion of contract assets | 1,459 |  | — |  | 1,459 |  |
| Current portion of commission asset | 1,645 |  | — |  | 1,645 |  |
| Prepaid expenses and other current assets | 11,047 |  | (290) |  | 10,757 |  |
| Total current assets | 333,660 |  | (2,540) |  | 331,120 |  |
| Restricted cash, noncurrent | 275 |  | — |  | 275 |  |
| Contract assets, noncurrent | 3,418 |  | — |  | 3,418 |  |
| Commission asset, noncurrent | 3,719 |  | — |  | 3,719 |  |
| Property and equipment, net | 21,592 |  | 2,191 |  | 23,783 |  |
| Other assets | 401 |  | 141 |  | 542 |  |
| Total assets | $ | 363,065 |  | $ | (208) |  | $ | 362,857 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 6,363 |  | $ | (318) |  | $ | 6,045 |  |
| Accrued expenses and other current liabilities | 9,183 |  | 368 |  | 9,551 |  |
| Current portion of deferred revenue | 6,690 |  | (91) |  | 6,599 |  |
| Current portion of deferred rent | 135 |  | — |  | 135 |  |
| Current portion of long-term debt | 2,000 |  | — |  | 2,000 |  |
| Total current liabilities | 24,371 |  | (41) |  | 24,330 |  |
| Deferred revenue, noncurrent | 2,475 |  | — |  | 2,475 |  |
| Deferred rent, noncurrent | 333 |  | — |  | 333 |  |
| Long-term debt, noncurrent | 7,945 |  | — |  | 7,945 |  |
| Contingent earn-out liability | 20,809 |  | 397 |  | 21,206 |  |
| Contingently issuable common stock liability | 5,264 |  | — |  | 5,264 |  |
| Public warrant liability | 11,030 |  | — |  | 11,030 |  |
| Total liabilities | 72,227 |  | 356 |  | 72,583 |  |
| Stockholders’ equity: |  |  |  |
| Convertible preferred stock | — |  | — |  | — |  |
| Common stock | 14 |  | — |  | 14 |  |
| Additional paid-in capital | 395,563 |  | 501 |  | 396,064 |  |
| Accumulated deficit | (104,739) |  | (1,065) |  | (105,804) |  |
| Stockholders’ equity | 290,838 |  | (564) |  | 290,274 |  |
| Total liabilities and stockholders’ equity | $ | 363,065 |  | $ | (208) |  | $ | 362,857 |  |

[0001628280-23-009178:notes:330]
|  | December 31, 2020 |
|  | As Previously Reported | Adjustment | As Revised |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 4,704 |  | $ | — |  | $ | 4,704 |  |
| Accounts receivable, net | 1,401 |  | — |  | 1,401 |  |
| Inventory | 2,742 |  | (1,156) |  | 1,586 |  |
| Current portion of commission asset | 562 |  | — |  | 562 |  |
| Prepaid expenses and other current assets | 900 |  | 641 |  | 1,541 |  |
| Total current assets | 10,309 |  | (515) |  | 9,794 |  |
| Commission asset, noncurrent | 1,730 |  | — |  | 1,730 |  |
| Property and equipment, net | 9,316 |  | 752 |  | 10,068 |  |
| Other assets | — |  | 173 |  | 173 |  |
| Total assets | $ | 21,355 |  | $ | 410 |  | $ | 21,765 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 4,437 |  | $ | — |  | $ | 4,437 |  |
| Accrued expenses and other current liabilities | 3,727 |  | 484 |  | 4,211 |  |
| Current portion of deferred revenue | 3,717 |  | 45 |  | 3,762 |  |
| Current portion of deferred rent | 11 |  | — |  | 11 |  |
| Current portion of financing obligations | 227 |  | — |  | 227 |  |
| Total current liabilities | 12,119 |  | 529 |  | 12,648 |  |
| Deferred revenue, noncurrent | 480 |  | — |  | 480 |  |
| Financing obligation, noncurrent | 132 |  | — |  | 132 |  |
| Long-term debt, noncurrent | 16,432 |  | — |  | 16,432 |  |
| Derivative Liability | 1,000 |  | — |  | 1,000 |  |
| Common stock warrant liability | 1 |  | — |  | 1 |  |
| Total liabilities | 30,164 |  | 529 |  | 30,693 |  |
| Stockholders’ equity: |  |  |  |
| Convertible preferred stock | 75,877 |  | — |  | 75,877 |  |
| Common stock | 1 |  | — |  | 1 |  |
| Additional paid-in capital | 9,194 |  | 916 |  | 10,110 |  |
| Accumulated deficit | (93,881) |  | (1,035) |  | (94,916) |  |
| Stockholders’ equity | (84,686) |  | (119) |  | (84,805) |  |
| Total liabilities and stockholders’ equity | $ | 21,355 |  | $ | 410 |  | $ | 21,765 |  |

[0001628280-23-009178:notes:331]
Revised Consolidated Statements of Operations and Comprehensive Loss

[0001628280-23-009178:notes:332]
|  | Year EndedDecember 31, 2021 |
|  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |
| Product revenue | $ | 13,917 |  |  | $ | (286) |  |  | $ | 13,631 |  |
| Subscription revenue | 7,855 |  |  | (52) |  |  | 7,803 |  |
| Service revenue | 1,920 |  |  | 39 |  |  | 1,959 |  |
| Total revenue | 23,692 |  |  | (299) |  |  | 23,393 |  |
| Cost of revenue: |  |  |  |  |  |
| Cost of product revenue | 12,471 |  |  | (192) |  |  | 12,279 |  |
| Cost of subscription revenue | 3,644 |  |  | 857 |  |  | 4,501 |  |
| Cost of service revenue | 936 |  |  | 1,648 |  |  | 2,584 |  |
| Total cost of revenue | 17,051 |  |  | 2,313 |  |  | 19,364 |  |
| Gross profit | 6,641 |  |  | (2,612) |  |  | 4,029 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 11,416 |  |  | 42 |  |  | 11,458 |  |
| Sales and marketing expense | 27,404 |  |  | (1,305) |  |  | 26,099 |  |
| General and administrative | 20,013 |  |  | (144) |  |  | 19,869 |  |
| Loss from impairment of property and equipment | 1,869 |  |  | — |  |  | 1,869 |  |
| Total operating expenses | 60,702 |  |  | (1,407) |  |  | 59,295 |  |
| Loss from operations | (54,061) |  |  | (1,205) |  |  | (55,266) |  |
| Other income (expense), net: |  |  |  |  |  |
| Interest expense, net | (6,095) |  |  | 27 |  |  | (6,068) |  |
| Interest income | — |  |  | — |  |  | — |  |
| Loss on disposal of property and equipment | (617) |  |  | — |  |  | (617) |  |
| Loss on extinguishment of debt | (12,685) |  |  | — |  |  | (12,685) |  |
| Change in fair value of derivative liability | (1,745) |  |  | — |  |  | (1,745) |  |
| Change in fair value of contingent earn-out liability | 46,212 |  |  | 1,148 |  |  | 47,360 |  |
| Change in fair value of contingently issuable common stock liability | 6,406 |  |  | — |  |  | 6,406 |  |
| Change in fair value of public warrant liability | 12,606 |  |  | — |  |  | 12,606 |  |
| Change in fair value of common stock warrant liability | (879) |  |  | — |  |  | (879) |  |
| Total other income (expense), net | 43,203 |  |  | 1,175 |  |  | 44,378 |  |
| Net loss | $ | (10,858) |  |  | $ | (30) |  |  | $ | (10,888) |  |
| Weighted average common shares outstanding - basic and diluted | 71,662,694 |  |  | — |  |  | 71,662,694 |  |
| Net loss per share - basic and diluted | $ | (0.15) |  |  | $ | — |  |  | $ | (0.15) |  |

[0001628280-23-009178:notes:333]
Revised Consolidated Statements of Cash Flows

[0001628280-23-009178:notes:334]
|  | Year EndedDecember 31, 2021 |
|  | As Previously Reported | Adjustment | As Revised |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (10,858) |  | $ | (30) |  | $ | (10,888) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 2,895 |  | — |  | 2,895 |  |
| Write-off of inventory | 2,132 |  | — |  | 2,132 |  |
| Adjustment to property and equipment for sales type leases | (91) |  | — |  | (91) |  |
| Loss from impairment of property and equipment | 1,869 |  | — |  | 1,869 |  |
| Loss on disposal of property and equipment | 617 |  | — |  | 617 |  |
| Stock-based compensation | 8,511 |  | 1,085 |  | 9,596 |  |
| Non-cash interest expense | 5,245 |  | — |  | 5,245 |  |
| Provision recorded for allowance for doubtful accounts | (13) |  | — |  | (13) |  |
| Loss on extinguishment of debt | 12,685 |  | — |  | 12,685 |  |
| Change in fair value of derivative liability | 1,745 |  | — |  | 1,745 |  |
| Change in fair value of common stock warrant liability | 879 |  | — |  | 879 |  |
| Change in fair value of earn-out liability | (46,212) |  | (1,148) |  | (47,360) |  |
| Change in fair value of contingently issuable common stock | (6,406) |  | — |  | (6,406) |  |
| Change in fair value of public warrant liability | (12,606) |  | — |  | (12,606) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (5,063) |  | — |  | (5,063) |  |
| Inventory | (17,479) |  | 14,043 |  | (3,436) |  |
| Commission assets | (3,072) |  | — |  | (3,072) |  |
| Contract assets | (4,877) |  | — |  | (4,877) |  |
| Other assets | — |  | 32 |  | 32 |  |
| Prepaid expenses and other current assets | (10,079) |  | 931 |  | (9,148) |  |
| Accounts payable | (7) |  | 772 |  | 765 |  |
| Deferred revenue | 4,968 |  | (136) |  | 4,832 |  |
| Deferred rent | 457 |  | — |  | 457 |  |
| Warranty reserve | (42) |  | — |  | (42) |  |
| Accrued expenses and other current liabilities | 5,174 |  | (2,702) |  | 2,472 |  |
| Net cash used in operating activities | (69,628) |  | 12,847 |  | (56,781) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (1,028) |  | — |  | (1,028) |  |
| Purchases of property and equipment | (3,710) |  | (12,847) |  | (16,557) |  |
| Net cash used in investing activities | (4,738) |  | (12,847) |  | (17,585) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 915 |  | — |  | 915 |  |
| Proceeds from issuance of common stock from the PIPE Investment | 300,000 |  | — |  | 300,000 |  |
| Proceeds from the closing of the Merger | 84,945 |  | — |  | 84,945 |  |
| Payment of offering costs from the closing of the Merger and PIPE Investment | (34,132) |  | — |  | (34,132) |  |
| Repayment of financing obligations | (359) |  | — |  | (359) |  |
| Proceeds from long-term debt, net of issuance costs | 31,882 |  | — |  | 31,882 |  |
| Repayment of principal on long-term debt | (5,422) |  | — |  | (5,422) |  |
| Net cash provided by financing activities | 377,829 |  | — |  | 377,829 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 303,463 |  | — |  | 303,463 |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 4,704 |  | — |  | 4,704 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 308,167 |  | $ | — |  | $ | 308,167 |  |
| Supplemental disclosure of non-cash activities |  |  |  |
| Transfer of inventory to property and equipment | $ | 12,949 |  | $ | (12,949) |  | $ | — |  |
| Capital expenditures incurred but not yet paid | 347 |  | 2,589 |  | 2,936 |  |

[0001628280-23-009178:notes:335]
| Issuance of equity classified warrants | 1 |  | (1) |  | — |  |
| Deferred offering costs included in accounts payable | 1,932 |  | 11 |  | 1,943 |  |
| Conversion of convertible preferred stock to common stock | 75,877 |  | — |  | 75,877 |  |
| Initial fair value of contingent earn-out liability recognized in connection with the closing of the Merger | 67,021 |  | — |  | 67,021 |  |
| Initial fair value of contingently issuable common stock liability recognized in connection with the closing of the Merger | 11,670 |  | — |  | 11,670 |  |
| Conversion of common stock warrants to common stock in connection with the closing of the Merger | 880 |  | — |  | 880 |  |
| Initial fair value of public warrants in connection with the closing of the Merger | 23,636 |  | — |  | 23,636 |  |


## us-gaap:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsTextBlock

[0001628280-23-009178:notes:336]
The impact of the revisions to the periods presented in this Annual Report on Form 10-K are as follows (in thousands):
Revised Consolidated Balance Sheets

[0001628280-23-009178:notes:337]
The following tables summarize the consolidated quarterly results of operations for 2022 and 2021:

[0001628280-23-009178:notes:338]
|  |  | 2022 |
|  |  | First Quarter |  | Second Quarter |  | Third Quarter |  | Fourth Quarter |
| Total revenue |  | $ | 8,710 |  |  | $ | 9,070 |  |  | $ | 16,530 |  |  | $ | 20,885 |  |
| Gross profit |  | 897 |  |  | 553 |  |  | 225 |  |  | 54 |  |
| Net loss |  | (13,801) |  |  | (25,686) |  |  | (18,615) |  |  | (28,304) |  |
| Net loss per share - basic and diluted |  | $ | (0.10) |  |  | $ | (0.18) |  |  | $ | (0.13) |  |  | $ | (0.20) |  |

[0001628280-23-009178:notes:339]
|  |  | 2021 |
|  |  | First Quarter |  | Second Quarter |  | Third Quarter |  | Fourth Quarter |
| Total revenue |  | $ | 3,693 |  |  | $ | 4,678 |  |  | $ | 8,424 |  |  | $ | 6,598 |  |
| Gross profit |  | 449 |  |  | 728 |  |  | 3,467 |  |  | (615) |  |
| Net income (loss) |  | (13,506) |  |  | (22,977) |  |  | 20,807 |  |  | 4,788 |  |
| Net income (loss) per share - basic |  | $ | (1.29) |  |  | $ | (1.93) |  |  | $ | 0.17 |  |  | $ | 0.03 |  |
| Net income (loss) per share - diluted |  | (1.29) |  |  | (1.93) |  |  | 0.14 |  |  | 0.03 |  |

[0001628280-23-009178:notes:340]
The following tables summarize the impact of the revisions described in Note 21 to the periods ending March 31, 2022 and 2021:

[0001628280-23-009178:notes:341]
|  | Three Months EndedMarch 31, 2022 |
|  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |
| Product revenue | $ | 5,194 |  |  | $ | — |  |  | $ | 5,194 |  |
| Subscription revenue | 3,020 |  |  | (16) |  |  | 3,004 |  |
| Service revenue | 501 |  |  | 11 |  |  | 512 |  |
| Total revenue | 8,715 |  |  | (5) |  |  | 8,710 |  |
| Cost of revenue: |  |  |  |  |  |
| Cost of product revenue | 5,576 |  |  | (370) |  |  | 5,206 |  |
| Cost of subscription revenue | 1,065 |  |  | 477 |  |  | 1,542 |  |
| Cost of service revenue | 448 |  |  | 617 |  |  | 1,065 |  |
| Total cost of revenue | 7,089 |  |  | 724 |  |  | 7,813 |  |
| Gross profit | 1,626 |  |  | (729) |  |  | 897 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 4,286 |  |  | (111) |  |  | 4,175 |  |
| Sales and marketing expense | 12,053 |  |  | (2,381) |  |  | 9,672 |  |
| General and administrative | 11,093 |  |  | (276) |  |  | 10,817 |  |
| Loss from impairment of property and equipment | 96 |  |  | — |  |  | 96 |  |
| Total operating expenses | 27,528 |  |  | (2,768) |  |  | 24,760 |  |
| Loss from operations | (25,902) |  |  | 2,039 |  |  | (23,863) |  |
| Other income (expense), net: |  |  |  |  |  |
| Interest expense | (142) |  |  | — |  |  | (142) |  |
| Interest income | 209 |  |  | (141) |  |  | 68 |  |
| Change in fair value of contingent earn-out liability | 4,226 |  |  | (1,148) |  |  | 3,078 |  |
| Change in fair value of contingently issuable common stock liability | 1,472 |  |  | — |  |  | 1,472 |  |
| Change in fair value of public warrant liability | 5,586 |  |  | — |  |  | 5,586 |  |
| Total other income (expense), net | 11,351 |  |  | (1,289) |  |  | 10,062 |  |
| Net loss | $ | (14,551) |  |  | $ | 750 |  |  | $ | (13,801) |  |
| Weighted average common shares outstanding - basic and diluted | 142,878,406 |  |  | — |  |  | 142,878,406 |  |
| Net loss per share - basic and diluted | $ | (0.10) |  |  | $ | — |  |  | $ | (0.10) |  |

[0001628280-23-009178:notes:342]
|  | Three Months EndedMarch 31, 2021 |
|  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |
| Product revenue | $ | 2,502 |  |  | $ | (235) |  |  | $ | 2,267 |  |
| Subscription revenue | 1,300 |  |  | (73) |  |  | 1,227 |  |
| Service revenue | 197 |  |  | 2 |  |  | 199 |  |
| Total revenue | 3,999 |  |  | (306) |  |  | 3,693 |  |
| Cost of revenue: |  |  |  |  |  |
| Cost of product revenue | 2,229 |  |  | (13) |  |  | 2,216 |  |
| Cost of subscription revenue | 595 |  |  | 148 |  |  | 743 |  |
| Cost of service revenue | 127 |  |  | 158 |  |  | 285 |  |
| Total cost of revenue | 2,951 |  |  | 293 |  |  | 3,244 |  |
| Gross profit | 1,048 |  |  | (599) |  |  | 449 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 3,612 |  |  | 128 |  |  | 3,740 |  |
| Sales and marketing expense | 3,684 |  |  | (1,076) |  |  | 2,608 |  |
| General and administrative | 2,899 |  |  | 153 |  |  | 3,052 |  |
| Total operating expenses | 10,195 |  |  | (795) |  |  | 9,400 |  |
| Loss from operations | (9,147) |  |  | 196 |  |  | (8,951) |  |
| Other income (expense), net: |  |  |  |  |  |
| Interest expense, net | (2,447) |  |  | 53 |  |  | (2,394) |  |
| Change in fair value of derivative liability | (1,425) |  |  | — |  |  | (1,425) |  |
| Change in fair value of common stock warrant liability | (736) |  |  | — |  |  | (736) |  |
| Total other income (expense), net | (4,608) |  |  | 53 |  |  | (4,555) |  |
| Net loss | $ | (13,755) |  |  | $ | 249 |  |  | $ | (13,506) |  |
| Weighted average common shares outstanding - basic and diluted | 10,443,323 |  |  | — |  |  | 10,443,323 |  |
| Net loss per share - basic and diluted | $ | (1.32) |  |  | $ | 0.03 |  |  | $ | (1.29) |  |

[0001628280-23-009178:notes:343]
|  | Three Months EndedMarch 31, 2022 |
|  | As Previously Reported | Adjustment | As Revised |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (14,551) |  | $ | 750 |  | $ | (13,801) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 948 |  | 138 |  | 1,086 |  |
| Write-off of inventory | 324 |  | — |  | 324 |  |
| Adjustment to property and equipment for sales type leases | (321) |  | (304) |  | (625) |  |
| Loss from impairment of property and equipment | 96 |  | — |  | 96 |  |
| Stock-based compensation | 5,190 |  | (1,263) |  | 3,927 |  |
| Non-cash interest expense | 5 |  | — |  | 5 |  |
| Non-cash lease expense | 197 |  | — |  | 197 |  |
| Change in fair value of earn-out liability | (4,226) |  | 1,148 |  | (3,078) |  |
| Change in fair value of contingently issuable common stock | (1,472) |  | — |  | (1,472) |  |
| Change in fair value of public warrant liability | (5,586) |  | — |  | (5,586) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (2,112) |  | — |  | (2,112) |  |
| Inventory | (6,985) |  | 5,675 |  | (1,310) |  |
| Commission assets | (351) |  | — |  | (351) |  |
| Contract assets | 108 |  | — |  | 108 |  |
| Other assets | — |  | 141 |  | 141 |  |
| Prepaid expenses and other current assets | (5,280) |  | (291) |  | (5,571) |  |
| Accounts payable | (1,867) |  | 1,012 |  | (855) |  |
| Deferred revenue | 2,778 |  | (201) |  | 2,577 |  |
| Deferred rent | (468) |  | 468 |  | — |  |
| Accrued expenses and other current liabilities | (2,065) |  | (368) |  | (2,433) |  |
| Operating lease liability | (229) |  | (468) |  | (697) |  |
| Net cash used in operating activities | (35,867) |  | 6,437 |  | (29,430) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (646) |  | (82) |  | (728) |  |
| Purchases of property and equipment | (323) |  | (6,366) |  | (6,689) |  |
| Net cash used in investing activities | (969) |  | (6,448) |  | (7,417) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 216 |  | 11 |  | 227 |  |
| Net cash provided by financing activities | 216 |  | 11 |  | 227 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (36,620) |  | — |  | (36,620) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 308,167 |  | — |  | 308,167 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 271,547 |  | $ | — |  | $ | 271,547 |  |
| Supplemental disclosure of non-cash activities |  |  |  |
| Transfer of inventory to property and equipment | $ | 4,620 |  | $ | (4,620) |  | $ | — |  |
| Capital expenditures incurred but not yet paid | 1,693 |  | 698 |  | 2,391 |  |

[0001628280-23-009178:notes:344]
|  | Three Months EndedMarch 31, 2021 |
|  | As Previously Reported | Adjustment | As Revised |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (13,755) |  | $ | 249 |  | $ | (13,506) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 452 |  | — |  | 452 |  |
| Stock-based compensation | 1,082 |  | (773) |  | 309 |  |
| Non-cash interest expense | 2,344 |  | — |  | 2,344 |  |
| Provision recorded for allowance for doubtful accounts | (63) |  | — |  | (63) |  |
| Change in fair value of derivative liability | 1,425 |  | — |  | 1,425 |  |
| Change in fair value of common stock warrant liability | 736 |  | — |  | 736 |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (874) |  | — |  | (874) |  |
| Inventory | (433) |  | (47) |  | (480) |  |
| Commission assets | (391) |  | — |  | (391) |  |
| Contract assets | (119) |  | — |  | (119) |  |
| Other assets | — |  | 7 |  | 7 |  |
| Prepaid expenses and other current assets | (4,104) |  | 377 |  | (3,727) |  |
| Accounts payable | 1,194 |  | (235) |  | 959 |  |
| Deferred revenue | (621) |  | (185) |  | (806) |  |
| Deferred rent | (11) |  | — |  | (11) |  |
| Accrued expenses and other current liabilities | 1,100 |  | 206 |  | 1,306 |  |
| Net cash used in operating activities | (12,038) |  | (401) |  | (12,439) |  |
| Cash flows from investing activities: |  |  |  |
| Purchases of property and equipment | (2,522) |  | 401 |  | (2,121) |  |
| Net cash used in investing activities | (2,522) |  | 401 |  | (2,121) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 455 |  | — |  | 455 |  |
| Repayment of financing obligations | (359) |  | — |  | (359) |  |
| Proceeds from long-term debt, net of issuance costs | 31,882 |  | — |  | 31,882 |  |
| Net cash provided by financing activities | 31,978 |  | — |  | 31,978 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 17,418 |  | — |  | 17,418 |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 4,704 |  | — |  | 4,704 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 22,122 |  | $ | — |  | $ | 22,122 |  |
| Supplemental disclosure of non-cash activities |  |  |  |
| Capital expenditures incurred but not yet paid | — |  | 1,335 |  | 1,335 |  |
| Issuance of equity classified warrants | 1 |  | — |  | 1 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001628280-23-009178:notes:345]
Unaudited Quarterly Financial Information
The following tables summarize the consolidated quarterly results of operations for 2022 and 2021:


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001628280-23-009178:notes:346]
Benefit PlansThe Company established a defined contribution savings plan under Section 401(k) of the Code. This plan covers all employees who meet minimum age and service requirements and allows participants to defer a portion of their annual compensation on a pre-tax basis. The Company did not make any matching contributions to the plan during the years ended December 31, 2022 or 2021.
