# EVLV MD&A — 0001628280-23-009178


## mdna

[0001628280-23-009178:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001628280-23-009178:mdna:2]
During the year ended December 31, 2022, we identified immaterial errors in our previously issued financial statements. We have corrected the amounts as presented in this Item 7 accordingly. Please refer to Notes 1 and 21 to the financial statements included in Part II, Item 8 of this Annual Report on Form 10-K for additional information.

[0001628280-23-009178:mdna:3]
On July 16, 2021, we consummated the business combination (the “Merger”), contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of NewHold Investment Corp. (“NHIC”), a special purpose acquisition company, which is our legal predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among NHIC, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the merger as a wholly owned subsidiary of NHIC. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. Evolv Technologies Holdings, Inc. became the successor entity to NHIC pursuant to Rule 12g-3(a) promulgated under the Securities Exchange Act of 1934, as amended (the “Exchange Act”).

[0001628280-23-009178:mdna:4]
As used in this Annual Report on Form 10-K, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of the Merger and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001628280-23-009178:mdna:5]
Business Overview

[0001628280-23-009178:mdna:6]
We are a global leader in AI-based weapons detection for security screening. Unlike conventional walk-through metal detectors, our products use advanced sensors, artificial intelligence software, and cloud services to reliably detect guns, improvised explosives, and large knives while ignoring harmless items like phones and keys. This not only enhances security at venues and facilities but also improves the visitor experience by making screening up to ten times faster than alternatives at up to 70% lower total cost.

[0001628280-23-009178:mdna:7]
Our products have screened over 500 million visitors worldwide since our inception. We believe that we have screened more people through advanced systems than any organization other than the United States Transportation Security Administration (“TSA”). Our customers include many iconic venues across a wide variety of industries including major sports stadiums and arenas, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, hospitals, large industrial workplaces, schools, and prominent houses of worship. We offer our products for purchase and primarily under a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue and creates expansion and upsell opportunities.

[0001628280-23-009178:mdna:8]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $55.2 million and $23.4 million for the years ended December 31, 2022 and 2021, respectively. We generated a net loss of $86.4 million and $10.9 million for the years ended December 31, 2022 and 2021, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001628280-23-009178:mdna:9]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or

[0001628280-23-009178:mdna:10]
maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations and debt financings. In July 2021, we received gross proceeds of $300.0 million from our PIPE Investment as well as $84.9 million in proceeds, net of redemptions received from the closing of the Merger. In December 2022, we entered into a debt facility with Silicon Valley Bank which will allow us to borrow up to $75 million. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources.”

[0001628280-23-009178:mdna:11]
NewHold Investment Corporation Merger

[0001628280-23-009178:mdna:12]
On July 16, 2021, we completed the Merger, pursuant to the Agreement and Plan of Merger, dated as of March 5, 2021, and amended by the First Amendment to Agreement and Plan of Merger (the “Merger Agreement”), dated as of June 5, 2021. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. and the officers of NHIC, the legal predecessor company, resigned. The officers of Legacy Evolv became the officers of the Company, and the Company listed its shares of common stock, par value $0.0001 per share, on Nasdaq under the symbol “EVLV”.

[0001628280-23-009178:mdna:13]
Additional information regarding the Merger Agreement appears in Note 3 of our consolidated financial statements for the year ended December 31, 2022.

[0001628280-23-009178:mdna:14]
Key Factors Affecting Our Operating Results

[0001628280-23-009178:mdna:15]
We believe that our performance and future success depend on many factors that present significant opportunities for us but also pose risks and challenges, including those discussed below and in the "Risk Factors" section of this Annual Report on Form 10-K.

[0001628280-23-009178:mdna:16]
General Economic and Market Conditions

[0001628280-23-009178:mdna:17]
We expect that our results of operations, including our revenue and cost of revenue, may fluctuate or continue to fluctuate based on, among other things, the impact of rising inflation and interest rates on business spending; supply chain issues and the impacts on our manufacturing capabilities; the continued effects of the COVID-19 pandemic and other public health emergencies; the Russian invasion of Ukraine and related geopolitical impacts; and a possible economic recession. While these factors continue to evolve, we plan to remain flexible and to optimize our business as appropriate and allocate resources, as necessary.

[0001628280-23-009178:mdna:18]
Adoption of our Security Screening Products

[0001628280-23-009178:mdna:19]
We believe the world will continue to focus on the safety and security of people in the places where they gather. Many of these locations, such as professional sports venues, educational institutions, and healthcare facilities, are moving toward a more frictionless security screening experience. We believe that we are well-positioned to take advantage of this opportunity due to our proprietary technologies and global distribution capabilities. Our products are designed to empower venues and facilities to realize the full benefits of touchless security screening, including a rapid visitor throughput and minimal security staff to screened visitor physical contact. We expect that our results of operations, including revenue, will fluctuate for the foreseeable future as venues and facilities continue to shift away from conventional security screening processes towards touchless security screening or consider security screening processes for the first time. The degree to which potential and current customers recognize these benefits and invest in our products will affect our financial results.

[0001628280-23-009178:mdna:20]
Pricing, Product Cost and Margins

[0001628280-23-009178:mdna:21]
To date, most of our revenue has been generated by sales of products which represented approximately 58% of our total revenue for each of the years ended December 31, 2022 and 2021. The remaining revenue was generated from subscription sales and services for our products. Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions, primarily within the United States. With the further development, enhancement, and maintenance of our analytics platform, which we refer to as Evolv Insights, as well as our plan to lead increasingly with our subscription offering, we expect subscription revenue as a percentage of total revenue to increase in future periods.

[0001628280-23-009178:mdna:22]
Pricing may also vary by region due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales/bookings/business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products to our customers.

[0001628280-23-009178:mdna:23]
Continued Investment and Innovation

[0001628280-23-009178:mdna:24]
We believe that we are a global leader in AI-based weapons detection for security screening, offering transformative technologies that enable higher throughput, a more frictionless visitor experience, and substantial cost savings through our product innovations. Our performance is significantly dependent on the investment we make in our research and development efforts and on our ability to be at the forefront of the security screening industry. It is essential that we continually identify and respond to rapidly evolving customer requirements, develop, and introduce innovative new products, enhance existing products and generate customer demand for our products. We believe that investment in our security screening products will contribute to long-term revenue growth, but it may adversely affect our near-term profitability.

[0001628280-23-009178:mdna:25]
Components of Results of Operations

[0001628280-23-009178:mdna:26]
Revenue

[0001628280-23-009178:mdna:27]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, (2) the sale of products, inclusive of SaaS and maintenance, and (3) professional services. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer for product sales and upon installation or delivery for subscriptions. Revenue is recognized net of sales tax.

[0001628280-23-009178:mdna:28]
Product Revenue

[0001628280-23-009178:mdna:29]
We derive a portion of our revenue from the sale of our Express equipment (and prior to 2022, our Edge equipment) and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We expect product revenue to decline as a percentage of our overall revenue over time as more customers enter full subscription transactions with us and as the subscription becomes more valuable to our business.

[0001628280-23-009178:mdna:30]
Subscription Revenue

[0001628280-23-009178:mdna:31]
Subscription revenue is comprised of revenue derived from leasing Express and Edge units to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as they do not meet any of the sales-type lease criteria per ASC 842 and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001628280-23-009178:mdna:32]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (1) distinct services, such as installation, training, SaaS, and maintenance, and (2) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive loss.

[0001628280-23-009178:mdna:33]
Services Revenue

[0001628280-23-009178:mdna:34]
Services revenue includes subscription-based SaaS and maintenance revenue related to products sold to customers, as well as installation and training services. Revenue for installation and training are recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes, and when-and-if available threat updates. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically four years.

[0001628280-23-009178:mdna:35]
Cost of Revenue

[0001628280-23-009178:mdna:36]
We recognize cost of revenue in the same manner that the related revenue is recognized.

[0001628280-23-009178:mdna:37]
Cost of Product Revenue

[0001628280-23-009178:mdna:38]
Cost of product revenue consists primarily of costs paid to our third party manufacturer and other suppliers, labor costs (including stock-based compensation), and shipping costs.

[0001628280-23-009178:mdna:39]
Cost of Subscription Revenue

[0001628280-23-009178:mdna:40]
Cost of subscription revenue consists primarily of shipping costs, an allocated portion of internal-use software amortization expense, depreciation expense related to leased units, and maintenance costs related to leased units. Maintenance costs consist primarily of labor (including stock-based compensation), spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001628280-23-009178:mdna:41]
Cost of Services Revenue

[0001628280-23-009178:mdna:42]
Cost of services revenue consists of costs related to installation and training services, an allocated portion of internal-use software amortization expense, and maintenance costs related to units purchased by customers. Maintenance costs consists primarily of labor (including stock-based compensation), spare parts, field service repair costs, equipment, and supplies.

[0001628280-23-009178:mdna:43]
Our estimate of costs to service the warranty obligations is based on historical experience and expectations of future conditions. As of December 31, 2022, the warranty reserve was less than $0.1 million.

[0001628280-23-009178:mdna:44]
Gross Profit and Gross Margin

[0001628280-23-009178:mdna:45]
Our gross profit is calculated based on the difference between our revenues and cost of revenues. Gross margin is the percentage obtained by dividing gross profit by our revenue. Our gross profit and gross margin are, or may be, influenced by a number of factors, including:

[0001628280-23-009178:mdna:46]
•Market conditions that may impact our pricing;

[0001628280-23-009178:mdna:47]
•Product mix changes between established products and new products;

[0001628280-23-009178:mdna:48]
•Mix between purchase subscription sales and pure subscription sales;

[0001628280-23-009178:mdna:49]
•Our cost structure for manufacturing operations, including contract manufacturers, relative to volume, and our product support obligations;

[0001628280-23-009178:mdna:50]
•Our ability to maintain our costs on the components that go into the manufacture of our product; and

[0001628280-23-009178:mdna:51]
•Write-offs of inventory.

[0001628280-23-009178:mdna:52]
We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001628280-23-009178:mdna:53]
Research and Development

[0001628280-23-009178:mdna:54]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, stock-based compensation, prototypes, design expenses, and consulting and contractor costs. We expect research and development costs will increase for the year ending December 31, 2023 compared to the year ended December 31, 2022 primarily due to incremental investments in headcount and programs we are making to support our new product development efforts.

[0001628280-23-009178:mdna:55]
Sales and Marketing

[0001628280-23-009178:mdna:56]
Sales and marketing expenses consist primarily of personnel-related expenses associated with our sales and marketing, customer success, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will increase for the year ending December 31, 2023 compared to the year ended December 31, 2022 due to an expected increase in customer facing headcount as we build out our sales, business development, and customer support capabilities.

[0001628280-23-009178:mdna:57]
General and Administrative

[0001628280-23-009178:mdna:58]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and sales tax contingencies. We expect our general and administrative expenses will remain relatively consistent for the year ending December 31, 2023 compared to the year ended December 31, 2022 as we look to leverage previous investments made in people and processes.

[0001628280-23-009178:mdna:59]
Loss From Impairment of Property and Equipment

[0001628280-23-009178:mdna:60]
Impairment of property and equipment relates to Edge units and Express prototype units that are removed from service and retired as we transition our domestic customers to our most current Express units.

[0001628280-23-009178:mdna:61]
Interest Expense

[0001628280-23-009178:mdna:62]
Interest expense includes cash interest paid on our debt and amortization of deferred financing fees and costs.

[0001628280-23-009178:mdna:63]
Interest Income

[0001628280-23-009178:mdna:64]
Interest income relates to interest earned on money market funds and interest earned on our lease receivables for our Evolv Express units recognized as sales type leases.

[0001628280-23-009178:mdna:65]
Loss on Extinguishment of Debt

[0001628280-23-009178:mdna:66]
Loss on extinguishment of debt relates to a modification of the 2021 Convertible Notes (as defined below) due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes consistent with the terms thereof, and interest due to each investor would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. This modification of the 2021 Convertible Notes was accounted for as an extinguishment.

[0001628280-23-009178:mdna:67]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the Convertible Notes also received the right to receive 1,000,000 shares of NHIC common stock. Upon the conversion of the Convertible Notes, the carrying value of the debt, including unamortized debt discount, and the related derivative liability and accrued interest were derecognized. The shares of common stock issued upon conversion of Convertible Notes were recorded at implied fair value of the Company’s common stock with the resulting difference being accounted for as a loss on extinguishment.

[0001628280-23-009178:mdna:68]
Change in Fair Value of Derivative Liability

[0001628280-23-009178:mdna:69]
In August through September 2019 and in September 2020, we issued Convertible Notes to several investors (the “2020 Convertible Notes”) that provided a conversion option whereby upon the closing of a specified financing event the notes would automatically convert into shares of the same class and series of our capital stock issued to other investors in the financing at a conversion price equal to 85% and 80%, respectively, of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative that was required to be bifurcated and accounted for separately from the notes. The derivative liability was initially recorded at fair value upon issuance of the notes and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the derivative liability are recognized in the consolidated statements of operations and comprehensive loss. In October 2019, the specified financing event was consummated, as such the 2020 Convertible Notes issued August through September 2019 were converted into shares of Series B-1 Preferred Stock and the derivative liability was extinguished.

[0001628280-23-009178:mdna:70]
In January and February 2021, we entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method.

[0001628280-23-009178:mdna:71]
In June 2021, we modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. The modification of the 2021 Convertible Notes resulted in the recognition of a derivative liability for the fair value of the 1,000,000 NHIC shares as of June 21, 2021 as well as a bifurcated embedded derivative for conversion feature into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors.

[0001628280-23-009178:mdna:72]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001628280-23-009178:mdna:73]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-23-009178:mdna:74]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders are entitled to receive additional shares of our common stock upon us achieving certain milestones. The earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001628280-23-009178:mdna:75]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-23-009178:mdna:76]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 shares of Founder Shares. 1,897,500 shares vested at the closing of the Merger, 1,897,500 shares shall vest upon us achieving certain milestones and 517,500 shares were contributed to Give Evolv LLC. Those 1,897,500 outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss.

[0001628280-23-009178:mdna:77]
Change in Fair Value of Public Warrant Liability

[0001628280-23-009178:mdna:78]
In connection with the closing of the Merger, the Company assumed a warrant to purchase shares of common stock (the “Public Warrants”). We assessed the features of these warrants and determined that they qualify for classification as a liability. Accordingly, we recorded the warrants at fair value upon the closing of the Merger with the offset to additional paid-in capital.

[0001628280-23-009178:mdna:79]
Change in Fair Value of Common Stock Warrant Liability

[0001628280-23-009178:mdna:80]
We classify certain warrants for the purchase of shares of our common stock as a liability on our consolidated balance sheets as these warrants are freestanding financial instruments that may require us to adjust the exercise price and number of shares that is not consistent with a fixed-for-fixed option pricing model. The warrant liability is initially recorded at fair value on the issuance date of each warrant and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the common stock warrant liability are recognized as a component of other income (expense), net in the consolidated statements of operations and comprehensive loss. Changes in fair value of the common stock warrant liability will continue to be recognized until the warrants are exercised, expire, or qualify for equity

[0001628280-23-009178:mdna:81]
classification. In connection with the closing of the Merger, all common stock warrants that were issued prior to the closing of the Merger were converted into shares of the Company’s common stock.

[0001628280-23-009178:mdna:82]
Income Taxes

[0001628280-23-009178:mdna:83]
Our income tax provision consists of an estimate for U.S. federal and state income taxes based on enacted rates, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. There is no provision for income taxes for the years ended December 31, 2022 and 2021 because we have historically incurred net operating losses and maintain a full valuation allowance against its deferred tax assets.

[0001628280-23-009178:mdna:84]
Results of Operations

[0001628280-23-009178:mdna:85]
Comparison of the Years Ended December 31, 2022 and 2021

[0001628280-23-009178:mdna:86]
The following table summarizes our results of operations for the years ended December 31, 2022 and 2021 (in thousands):

[0001628280-23-009178:mdna:87]
|  | Year Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 31,985 |  |  | $ | 13,631 |  |  | $ | 18,354 |  |  | 135 | % |
| Subscription revenue | 17,569 |  |  | 7,803 |  |  | 9,766 |  |  | 125 |  |
| Service revenue | 5,641 |  |  | 1,959 |  |  | 3,682 |  |  | 188 |  |
| Total revenue | 55,195 |  |  | 23,393 |  |  | 31,802 |  |  | 136 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 41,575 |  |  | 12,279 |  |  | 29,296 |  |  | 239 |  |
| Cost of subscription revenue | 7,469 |  |  | 4,501 |  |  | 2,968 |  |  | 66 |  |
| Cost of service revenue | 4,422 |  |  | 2,584 |  |  | 1,838 |  |  | 71 |  |
| Total cost of revenue | 53,466 |  |  | 19,364 |  |  | 34,102 |  |  | 176 |  |
| Gross profit | 1,729 |  |  | 4,029 |  |  | (2,300) |  |  | (57) |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 18,771 |  |  | 11,458 |  |  | 7,313 |  |  | 64 |  |
| Sales and marketing | 46,639 |  |  | 26,099 |  |  | 20,540 |  |  | 79 |  |
| General and administrative | 37,719 |  |  | 19,869 |  |  | 17,850 |  |  | 90 |  |
| Loss from impairment of property and equipment | 1,161 |  |  | 1,869 |  |  | (708) |  |  | (38) |  |
| Total operating expenses | 104,290 |  |  | 59,295 |  |  | 44,995 |  |  | 76 |  |
| Loss from operations | (102,561) |  |  | (55,266) |  |  | (47,295) |  |  | 86 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (712) |  |  | (6,068) |  |  | 5,356 |  |  | (88) |  |
| Interest income | 3,165 |  |  | — |  |  | 3,165 |  |  | * |
| Other expense, net | (64) |  |  | (617) |  |  | 553 |  |  | (90) |  |
| Loss on extinguishment of debt | — |  |  | (12,685) |  |  | 12,685 |  |  | * |
| Change in fair value of derivative liability | — |  |  | (1,745) |  |  | 1,745 |  |  | * |
| Change in fair value of contingent earn-out liability | 6,988 |  |  | 47,360 |  |  | (40,372) |  |  | (85) |  |
| Change in fair value of contingently issuable common stock liability | 1,872 |  |  | 6,406 |  |  | (4,534) |  |  | (71) |  |
| Change in fair value of public warrant liability | 4,906 |  |  | 12,606 |  |  | (7,700) |  |  | (61) |  |
| Change in fair value of common stock warrant liability | — |  |  | (879) |  |  | 879 |  |  | * |
| Total other income (expense), net | 16,155 |  |  | 44,378 |  |  | (28,223) |  |  | (64) |  |
| Net loss | $ | (86,406) |  |  | $ | (10,888) |  |  | $ | (75,518) |  |  | 694 | % |

[0001628280-23-009178:mdna:88]
*N/A – Not meaningful

[0001628280-23-009178:mdna:89]
Revenue, Cost of Revenue and Gross Profit

[0001628280-23-009178:mdna:90]
Product Revenue

[0001628280-23-009178:mdna:91]
|  | Year Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Product revenue | $ | 31,985 |  | $ | 13,631 |  | $ | 18,354 |  | 135 % |
| Cost of product revenue | $ | 41,575 |  | $ | 12,279 |  | $ | 29,296 |  | 239 % |
| Gross profit - Product revenue | $ | (9,590) |  | $ | 1,352 |  | $ | (10,942) |  | (809) % |
| Gross profit margin - Product revenue | (30) % |  | 10 % |  | N/A |  | (40) % |

[0001628280-23-009178:mdna:92]
The increases in product revenue and cost of product revenue are primarily due to the increase in product sales of Evolv Express units, which include the significant increase in the adoption of Evolv Express units by schools, healthcare facilities, hotels, casinos, and professional sports arenas. Further, during the year ended December 31, 2022, a higher relative mix of sales contracts were in the form of purchase subscription sales compared to leases.

[0001628280-23-009178:mdna:93]
We believe there are several key trends driving increased adoption of our solutions and growth in our product sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) acceleration in our customer acquisition activities as highlighted by the addition of 295 new customers during the year ended December 31, 2022 compared to 84 new customers during the year ended December 31, 2021, (iii) the expansion of our existing customers' initial Evolv Express deployments to their other owned venues and locations, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001628280-23-009178:mdna:94]
The decrease in product gross profit and gross profit margin during the year ended December 31, 2022 compared to the year ended December 31, 2021 is attributable to several factors. We experienced strong demand across our education and healthcare customers for single lane configurations of Evolv Express due to limitations in the lobby size typical of customers in those markets. These configurations generate lower gross profit than our dual lane configurations of Evolv Express due to a lower average sale price. Further, a higher percentage of sales were made through our channel partners, which are generally at a lower average sale price, and therefore a lower gross margin, during the year ended December 31, 2022 compared to the prior year. Product gross profit and gross profit margin were also adversely impacted by marketing and sponsorship arrangements with certain customers (which are reflected as an offset to revenue), increases in shipping costs, and the costs associated with the write-off of scrap inventory incurred without corresponding revenue. We expect to see improvement in our product gross profit margins as we continue to engineer our product with lower cost components. We also expect to see improvements in product gross margin to the extent shipping costs and high demand materials costs decline when global supply chain disruptions ease.

[0001628280-23-009178:mdna:95]
Subscription Revenue

[0001628280-23-009178:mdna:96]
|  | Year Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Subscription revenue | $ | 17,569 |  | $ | 7,803 |  | $ | 9,766 |  | 125 % |
| Cost of subscription revenue | $ | 7,469 |  | $ | 4,501 |  | $ | 2,968 |  | 66 % |
| Gross profit - Subscription revenue | $ | 10,100 |  | $ | 3,302 |  | $ | 6,798 |  | 206 % |
| Gross profit margin - Subscription revenue | 57 % |  | 42 % |  | N/A |  | 15 % |

[0001628280-23-009178:mdna:97]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to growth in our customer base and a higher number of leased Evolv Express units deployed under our pure subscription

[0001628280-23-009178:mdna:98]
contract model during the year ended December 31, 2022 compared to the year ended December 31, 2021. Subscription gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-23-009178:mdna:99]
Service Revenue

[0001628280-23-009178:mdna:100]
|  | Year Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Service revenue | $ | 5,641 |  | $ | 1,959 |  | $ | 3,682 |  | 188 % |
| Cost of service revenue | $ | 4,422 |  | $ | 2,584 |  | $ | 1,838 |  | 71 % |
| Gross profit - Service revenue | $ | 1,219 |  | $ | (625) |  | $ | 1,844 |  | (295) % |
| Gross profit margin - Service revenue | 22 % |  | (32) % |  | N/A |  | 54 % |

[0001628280-23-009178:mdna:101]
The increase in service revenue, cost of service revenue, and service gross profit are primarily due to the increased number of purchase subscription units deployed during the year ended December 31, 2022 compared to the year ended December 31, 2021, as well as an increase in the number of installation and training services performed. Service gross profit margin increased primarily as the result of our ability to leverage our fixed costs over a higher revenue base.

[0001628280-23-009178:mdna:102]
Research and Development Expenses

[0001628280-23-009178:mdna:103]
|  | Year Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 14,568 |  | $ | 7,345 |  | $ | 7,223 |  | 98 % |
| Materials and prototypes | 652 |  | 1,837 |  | (1,185) |  |  | (65) |  |
| Professional fees | 2,806 |  | 1,562 |  | 1,244 |  |  | 80 |  |
| Other | 745 |  | 714 |  | 31 |  |  | 4 |  |
|  | $ | 18,771 |  | $ | 11,458 |  | $ | 7,313 |  |  | 64 | % |

[0001628280-23-009178:mdna:104]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting primarily from a full year of expense related to new employees hired in our research and development function during the year ended December 31, 2021 and, to a lesser extent, new hires during the year ended December 31, 2022. Stock compensation expense included in research and development expenses was $4.0 million for the year ended December 31, 2022 compared to $0.9 million for the year ended December 31, 2021. The decrease in materials and prototype costs is due to the transition from prototype production to standard manufacturing of the Evolv Express. The increase in professional fees primarily relates to consulting costs incurred for product development and engineering.

[0001628280-23-009178:mdna:105]
Sales and Marketing Expenses

[0001628280-23-009178:mdna:106]
|  | Year Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 31,591 |  |  | $ | 17,382 |  |  | $ | 14,209 |  |  | 82 | % |
| Direct marketing | 5,457 |  |  | 4,292 |  |  | 1,165 |  | 27 |  |
| Travel and entertainment | 3,327 |  |  | 1,652 |  |  | 1,675 |  | 101 |  |
| Professional fees | 1,446 |  |  | 874 |  |  | 572 |  | 65 |  |
| Other | 4,818 |  |  | 1,899 |  |  | 2,919 |  | 154 |  |
|  | $ | 46,639 |  |  | $ | 26,099 |  |  | $ | 20,540 |  |  | 79 | % |

[0001628280-23-009178:mdna:107]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting primarily from a full year of expense related to new employees hired in our sales and marketing functions during the year ended December 31, 2021, and to a lesser extent, new hires during the year ended December 31, 2022, as well as

[0001628280-23-009178:mdna:108]
an increase in commission expense related to higher sales during the year ended December 31, 2022 compared to the prior year. Stock compensation expense included in sales and marketing expenses was $10.0 million for the year ended December 31, 2022 compared to $5.7 million for the year ended December 31, 2021. The increase in direct marketing is primarily due to an increase in trade shows and events, which have begun to return to pre-pandemic levels. The increase in travel and entertainment expense is due to an increase in travel costs for in-person sales personnel meetings and events. The increase in professional fees primarily relates to consulting costs incurred for training and website development. The increase in other expenses is primarily due to $1.4 million of increased shipping costs related to demo units and $1.0 million of certain one-time expenses, including a $0.4 million one-time payment to a former employee.

[0001628280-23-009178:mdna:109]
General and Administrative Expenses

[0001628280-23-009178:mdna:110]
|  | Year Ended December 31, |  |  |  |  |
|  | 2022 |  | 2021 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 17,369 |  |  | $ | 7,213 |  |  | $ | 10,156 |  |  | 141 | % |
| Professional fees | 8,715 |  |  | 5,527 |  |  | 3,188 |  |  | 58 |  |
| Insurance costs | 4,514 |  |  | 2,365 |  |  | 2,149 |  |  | 91 |  |
| Non-income taxes | 540 |  |  | 1,316 |  |  | (776) |  |  | (59) |  |
| Other | 6,581 |  |  | 3,448 |  |  | 3,133 |  |  | 91 |  |
|  | $ | 37,719 |  |  | $ | 19,869 |  |  | $ | 17,850 |  |  | 90 | % |

[0001628280-23-009178:mdna:111]
The increase in personnel related expenses is due to an increase in payroll costs and stock-based compensation resulting from expanding our administrative team during the years ended December 31, 2022 and 2021. Stock compensation expense included in general and administrative expenses was $7.6 million for the year ended December 31, 2022 compared to $2.8 million for the year ended December 31, 2021. The increase in professional fees is due to an increase in accounting, audit, tax, and legal services provided to the Company to support public company requirements. The increase in insurance costs is due primarily to director and officer insurance expense in relation to being a public company. The increase in non-income taxes is due to a sales tax contingency liability as we may owe additional sales and use taxes in various jurisdictions. The increase in other expenses is due primarily to $2.1 million increase of certain one-time expenses, a $0.5 million increase in IT and software subscription costs, a $0.3 million increase in depreciation and amortization expense, and $0.2 million of expense related to Express units donated through Give Evolv, offset by $0.7 million of non-capitalizable transaction costs incurred during the year ended December 31, 2021 related to the Merger.

[0001628280-23-009178:mdna:112]
Loss From Impairment of Property and Equipment

[0001628280-23-009178:mdna:113]
Impairment of property and equipment was $1.2 million and $1.9 million for the years ended December 31, 2022 and 2021, respectively. As we transition existing domestic customers to our current Express model, we are removing Edge units and Express prototype units from service, which results in the impairment of the remaining economic value of such units.

[0001628280-23-009178:mdna:114]
Interest Expense

[0001628280-23-009178:mdna:115]
Interest expense was $0.7 million for the year ended December 31, 2022, compared to $6.1 million for the year ended December 31, 2021. The decrease was primarily due to interest expense on the Convertible Notes during the year ended December 31, 2021. The Convertible Notes converted to the Company’s common stock upon closing of the Merger in July 2021.

[0001628280-23-009178:mdna:116]
Interest Income

[0001628280-23-009178:mdna:117]
Interest income of $3.2 million for the year ended December 31, 2022 related primarily to interest earned on money market funds. No interest income was earned for the year ended December 31, 2021.

[0001628280-23-009178:mdna:118]
Loss on Extinguishment of Debt

[0001628280-23-009178:mdna:119]
Loss on extinguishment of debt of $12.7 million for the year ended December 31, 2021 related to a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes.

[0001628280-23-009178:mdna:120]
Change in Fair Value of Derivative Liability

[0001628280-23-009178:mdna:121]
Change in fair value of the derivative liability was $(1.7) million for the year ended December 31, 2021, resulting from an increase in the fair value of the Company's stock given the pending Merger. The derivative liability was derecognized in connection with the closing of the Merger in July 2021.

[0001628280-23-009178:mdna:122]
Change in Fair Value of Contingent Earn-out Liability

[0001628280-23-009178:mdna:123]
Change in fair value of the contingent earn-out liability was $7.0 million and $47.4 million for the years ended December 31, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger in July 2021.

[0001628280-23-009178:mdna:124]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001628280-23-009178:mdna:125]
Change in the fair value of the contingently issuable common stock liability was $1.9 million and $6.4 million for the years ended December 31, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger in July 2021.

[0001628280-23-009178:mdna:126]
Change in Fair Value of Public Warrant Liability

[0001628280-23-009178:mdna:127]
Change in the fair value of the public warrant liability was $4.9 million and $12.6 million for the years ended December 31, 2022 and 2021, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger in July 2021.

[0001628280-23-009178:mdna:128]
Change in Fair Value of Common Stock Warrant Liability

[0001628280-23-009178:mdna:129]
Change in the fair value of the common stock warrant liability was $(0.9) million for the year ended December 31, 2021, resulting from the conversion of the common stock warrant liability upon the closing of the Merger in July 2021 and mark-to-market adjustments prior to the closing of the Merger.

[0001628280-23-009178:mdna:130]
Income Taxes

[0001628280-23-009178:mdna:131]
There is no provision for income taxes for the years ended December 31, 2022 and 2021 because we have historically incurred net operating losses and maintain a full valuation allowance against our deferred tax assets. We have provided a valuation allowance for all of our deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecasted results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001628280-23-009178:mdna:132]
Liquidity and Capital Resources

[0001628280-23-009178:mdna:133]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. As of December 31, 2022, we had $229.8 million in cash and cash equivalents. We incurred a net loss of $86.4 million and $10.9 million for the years ended December 31, 2022 and 2021, respectively. We incurred cash outflows from operating activities of $74.7 million and $56.8 million during the years ended December 31, 2022 and 2021, respectively.

[0001628280-23-009178:mdna:134]
We maintain substantially all of our cash and cash equivalents in accounts with U.S. and multi-national financial institutions, including SVB, and our deposits at these institutions exceed insured limits. On March 10, 2023, SVB was closed by the California Department of Financial Protection and Innovation, which appointed the FDIC as receiver. The FDIC created a successor bridge bank, SVBB, and all deposits of SVB were transferred to SVBB under a systemic risk exception approved by the Federal Reserve, the U.S. Treasury Department, and the FDIC. On March 12, 2023, the Federal Reserve, the U.S. Treasury Department, and the FDIC announced in a joint statement that all SVB deposits, including both insured and uninsured amounts, would be available in full to account holders. The Company does not believe it is exposed to any unusual credit risk beyond the normal credit risk associated with commercial banking relationships. However, we are currently assessing our banking relationships and the related concentration of deposits at any single financial institution, and are considering options available to reduce concentration risk.

[0001628280-23-009178:mdna:135]
We expect our cash and cash equivalents, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Annual Report on Form 10-K. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our sales and marketing teams worldwide. We may require additional capital to respond to the expected growth in the demand for equipment purchases to support our "leased equipment" offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances and in either the short-term or long-term may determine to engage in debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, including the COVID-19 pandemic and its variants, international political turmoil, including Russia's invasion of Ukraine, ongoing supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001628280-23-009178:mdna:136]
PIPE Investment and Proceeds from the closing of the Merger

[0001628280-23-009178:mdna:137]
In March 2021, prior to the completion of the Merger, we entered into subscription agreements (collectively, the "PIPE Investment") with certain parties subscribing for shares of our common stock. In July 2021, we received gross proceeds of $300.0 million from the PIPE Investment, as well as $84.9 million in proceeds, net of redemptions received in connection with the closing of the Merger.

[0001628280-23-009178:mdna:138]
Financing Arrangements

[0001628280-23-009178:mdna:139]
In September and December of 2020, we issued a total of $4.0 million of convertible notes (the “2020 Convertible Notes”). In January and February 2021, we issued a total of $30.0 million of convertible notes with a maturity date of September 2021 (the "2021 Convertible Notes").

[0001628280-23-009178:mdna:140]
In December 2020, we entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024, and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022. Under the terms of the JPM Credit Agreement, we received proceeds of $10.0 million. We fully repaid all borrowings under the JPM Credit Agreement and terminated the JPM Credit Agreement in November 2022.

[0001628280-23-009178:mdna:141]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense), net, which was recorded during the year ended December 31, 2021.

[0001628280-23-009178:mdna:142]
On December 21, 2022 (the “SVB Closing Date”), we entered into a loan and security agreement by and among the Company, Legacy Evolv, and SVB (the "2022 SVB Credit Agreement") in order to finance purchases of hardware to be leased to customers. The 2022 SVB Credit Agreement provides for an initial term loan advance of $30.0 million, which is approximately equivalent to the value of all hardware purchases made to support leasing transactions with our customers through the SVB Closing Date, with the opportunity to obtain, within 18 months after the SVB Closing Date, additional

[0001628280-23-009178:mdna:143]
58

[0001628280-23-009178:mdna:144]
term loan advances, subject to the satisfaction of certain conditions, in an aggregate principal amount equal to $20.0 million, (subject to an increase of an additional $25.0 million upon the satisfaction of certain conditions and approval from SVB) (collectively, the "2022 SVB Term Loans" and each a "2022 SVB Term Loan"). Each 2022 SVB Term Loan will mature on the 36-month anniversary of the extension thereof. The obligations under the 2022 SVB Credit Agreement are secured by a perfected security interest in substantially all of the Company's assets, with the exception of intellectual property, pursuant to the terms of the 2022 SVB Credit Agreement. The interest rate applicable to the SVB Term Loans is the greater of (a) the Wall Street Journal Prime Rate plus 1.0% or (b) 7.25% per annum. Interest and principal under the SVB Credit Agreement are payable monthly. Each 2022 SVB Term Loan advance may be prepaid in full, subject to certain conditions, with payment of (calculated, in each case, based on the then-outstanding principal amount of such 2022 SVB Term Loan advance subject to prepayment) a prepayment premium equal to (i) 1.0% if prepaid on or prior to December 21, 2023; (ii) 0.75% if prepaid after December 21, 2023 but on or prior to December 21, 2024; (iii) 0.50% if prepaid after December 21, 2024 but on or prior to December 21, 2025; and (iv) 0.0% if prepaid after December 21, 2025.

[0001628280-23-009178:mdna:145]
The 2022 SVB Credit Agreement includes certain customary covenants, including a covenant that requires the Company to maintain all of its operating accounts, depository accounts and excess cash with SVB. Upon the occurrence of an event of default, SVB may, among other remedies, declare all obligations under the 2022 SVB Credit Agreement immediately due and payable. The Company has sufficient liquidity to repay all obligations under the 2022 SVB Credit Agreement, if necessary.

[0001628280-23-009178:mdna:146]
In connection with the closure of SVB on March 10, 2023 and the creation of SVBB, SVBB assumed all loans that were previously held by SVB. SVBB continues to hold the Company’s term loans under the same existing terms and covenants which were in place with SVB.

[0001628280-23-009178:mdna:147]
Material Cash Requirements for Known Contractual and Other Obligations

[0001628280-23-009178:mdna:148]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of December 31, 2022. We anticipate fulfilling such commitments with our existing cash and cash equivalents, as well as cash and cash equivalents obtained through operations and proceeds from long-term debt. Cash and cash equivalents amounted to $229.8 million as of December 31, 2022.

[0001628280-23-009178:mdna:149]
We entered into a lease agreement for additional office space starting May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. We are required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space which is classified as restricted cash, non-current on the consolidated balance sheet as of December 31, 2022. Total future minimum lease payments under this noncancelable operating lease amount to $2.1 million. See Note 6 to our consolidated financial statements for the year ended December 31, 2022.

[0001628280-23-009178:mdna:150]
Cash Flows

[0001628280-23-009178:mdna:151]
The following table sets forth a summary of cash flows for the periods presented:

[0001628280-23-009178:mdna:152]
|  | Year EndedDecember 31, |
|  | 2022 |  | 2021 |
| Net cash used in operating activities | $ | (74,728) |  |  | $ | (56,781) |  |
| Net cash used in investing activities | (23,881) |  |  | (17,585) |  |
| Net cash provided by (used in) financing activities | 20,510 |  |  | 377,829 |  |
| Effect of exchange rate changes on cash and cash equivalents | (10) |  |  | — |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (78,109) |  |  | $ | 303,463 |  |

[0001628280-23-009178:mdna:153]
Operating Activities

[0001628280-23-009178:mdna:154]
|  | Year EndedDecember 31, |
|  | 2022 |  | 2021 |
| Net loss | $ | (86,406) |  |  | $ | (10,888) |  |
| Non-cash (income) expense | 17,331 |  |  | (28,813) |  |
| Changes in operating assets and liabilities | (5,653) |  |  | (17,080) |  |
| Net cash used in operating activities | $ | (74,728) |  |  | $ | (56,781) |  |

[0001628280-23-009178:mdna:155]
Net loss increased from $10.9 million for the year ended December 31, 2021 to $86.4 million for the year ended December 31, 2022 as a result of the factors described in "Results of Operations" above.

[0001628280-23-009178:mdna:156]
Non-cash expenses for the year ended December 31, 2022 are primarily attributable to $22.5 million of stock-based compensation expense, $5.5 million of depreciation and amortization, $1.6 million of write-off of inventory, and $1.2 million of loss from impairment of property and equipment, offset by $13.8 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability. Non-cash expenses for the year ended December 31, 2021 are primarily attributable to a $12.7 million loss on debt extinguishment related to the 2021 Convertible Notes, $5.2 million of non-cash interest expense primarily related to the accretion of the debt discount associated with the 2021 Convertible Notes, $9.6 million of stock-based compensation expense, $2.9 million of depreciation and amortization, and $4.0 million of loss from impairment of property and equipment and inventory, offset by $63.7 million of an aggregate change in fair value of the derivative liability, common stock warrant liability, earn-out liability, contingently issuable common stock liability, and public warrant liability.

[0001628280-23-009178:mdna:157]
Changes in operating assets and liabilities for the year ended December 31, 2022 are primarily related to the following:

[0001628280-23-009178:mdna:158]
•$25.6 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001628280-23-009178:mdna:159]
•$8.5 million increase in inventory primarily due to increased production of units to meet customer demand;

[0001628280-23-009178:mdna:160]
•$3.7 million increase in commission assets due to a higher volume of sales;

[0001628280-23-009178:mdna:161]
•$3.2 million increase in prepaid expense and other current assets primarily due to deposits paid to the Company's contract manufacturer; offset by

[0001628280-23-009178:mdna:162]
•$26.9 million increase in deferred revenue due to a higher volume of sales; and

[0001628280-23-009178:mdna:163]
•$7.7 million increase in accounts payable primarily due to amounts payable to the Company's contract manufacturer.

[0001628280-23-009178:mdna:164]
Changes in operating assets and liabilities for the year ended December 31, 2021 are primarily related to the following:

[0001628280-23-009178:mdna:165]
•$5.1 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers;

[0001628280-23-009178:mdna:166]
•$3.4 million increase in inventory primarily due to increased production of units to meet customer demand;

[0001628280-23-009178:mdna:167]
•$9.1 million increase in prepaid expense and other current assets primarily due to an increase in director and officer insurance premiums as a result of becoming a public company and an increase in deposits paid to the Company's contract manufacturer;

[0001628280-23-009178:mdna:168]
•$4.9 million increase in contract assets due to a higher volume of sales;

[0001628280-23-009178:mdna:169]
•$3.1 million increase in commission assets due to a higher volume of sales; offset by

[0001628280-23-009178:mdna:170]
•$4.8 million increase in deferred revenue due to a higher volume of sales; and

[0001628280-23-009178:mdna:171]
•$2.5 million increase in accrued expenses and other current liabilities due to an increase in sales and marketing and general and administrative expenses due to the growth in our business and operating as a public company, the timing of vendor invoicing and payments, and the increase in our sales tax contingency liability.

[0001628280-23-009178:mdna:172]
Investing Activities

[0001628280-23-009178:mdna:173]
During the year ended December 31, 2022, cash used in investing activities was $23.9 million, consisting of $21.5 million for the purchase of property and equipment, primarily related to the purchase of Express units to be leased to customers, and $2.7 million for the development of internal-use software, offset by $0.3 million of proceeds from the sale of property and equipment.

[0001628280-23-009178:mdna:174]
During the year ended December 31, 2021, cash used in investing activities was $17.6 million, primarily consisting of $16.6 million for the purchases of property and equipment and $1.0 million for the development of internal-use software.

[0001628280-23-009178:mdna:175]
Financing Activities

[0001628280-23-009178:mdna:176]
During the year ended December 31, 2022, cash provided by financing activities was $20.5 million, consisting of $29.7 million of proceeds from long-term debt, net of issuance costs, and $0.8 million of proceeds from the exercise of stock options, offset by $10.0 million of debt repayments.

[0001628280-23-009178:mdna:177]
During the year ended December 31, 2021, cash provided by financing activities was $377.8 million, primarily consisting of $300.0 million from the issuance of common stock in connection with the PIPE investment, $84.9 million of proceeds, net of redemptions, from the closing of the Merger, $31.9 million from the issuance of long-term debt, net of issuance costs, and $0.9 million from the exercise of stock options, partially offset by $34.1 million in net cash outflows from the payment of offering costs in connection with the Merger, $5.4 million for the repayment of principal on long term debt and $0.4 million for the repayment of financing obligations.

[0001628280-23-009178:mdna:178]
Recent Accounting Pronouncements

[0001628280-23-009178:mdna:179]
A description of recently issued accounting pronouncements that may potentially impact our financial position, results of operations or cash flows is disclosed in Note 2 to our consolidated financial statements included elsewhere in this Annual Report on Form 10-K.

[0001628280-23-009178:mdna:180]
Critical Accounting Policies and Estimates

[0001628280-23-009178:mdna:181]
Our consolidated financial statements are prepared in accordance with generally accepted accounting principles in the United States. The preparation of our consolidated financial statements and related disclosures requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, costs and expenses, and the disclosure of contingent assets and liabilities in our consolidated financial statements. We base our estimates on historical experience, known trends and events and various other factors that we believe are reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. We evaluate our estimates and assumptions on an ongoing basis. Our actual results may differ from these estimates under different assumptions or conditions.

[0001628280-23-009178:mdna:182]
While our significant accounting policies are described in more detail in Note 2 to our consolidated financial statements, we believe that the following accounting policies are those most critical to the judgments and estimates used in the preparation of our consolidated financial statements.

[0001628280-23-009178:mdna:183]
Revenue Recognition

[0001628280-23-009178:mdna:184]
We derive revenue from (1) subscription arrangements accounted for as operating leases, (2) from the sale of products, inclusive of SaaS and maintenance, and (3) professional services. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001628280-23-009178:mdna:185]
Product Revenue

[0001628280-23-009178:mdna:186]
We derive a portion of our revenue from the sale of our Express equipment (and prior to 2022, our Edge equipment) and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We expect product revenue to decline as a percentage of our overall revenue over time as more customers enter full subscription transactions with us and as our subscription becomes more valuable to our business.

[0001628280-23-009178:mdna:187]
Subscription Revenue

[0001628280-23-009178:mdna:188]
Subscription revenue is comprised of revenue derived from leasing Express and Edge units to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease and maintenance elements over the contractual lease term. Equipment leases are generally classified as operating leases as

[0001628280-23-009178:mdna:189]
they do not meet any of the sales-type lease criteria per ASC 842 and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001628280-23-009178:mdna:190]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (1) distinct services, such as SaaS, maintenance, installation and training, and (2) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment lease, SaaS, and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern, the equipment lease and SaaS/maintenance performance obligations are classified as a single category of subscription revenue in our consolidated statements of operations and comprehensive loss.

[0001628280-23-009178:mdna:191]
Services Revenue

[0001628280-23-009178:mdna:192]
We provide SaaS, maintenance, installation and training services for our products. Revenue for installation and training are recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes and when-and-if available threat updates. SaaS and maintenance revenue is recognized ratably over the period of the arrangement.

[0001628280-23-009178:mdna:193]
Revenue from Channel Partners

[0001628280-23-009178:mdna:194]
A portion of our revenue is generated by sales in conjunction with our channel partners. When we transact with a channel partner, our contractual arrangement is with the channel partner and not with the end-use customer. Whether we transact with a channel partner and receive the order from a channel partner or directly from an end-use customer, our revenue recognition policy and resulting pattern of revenue recognition is the same.

[0001628280-23-009178:mdna:195]
Standalone Selling Price

[0001628280-23-009178:mdna:196]
We allocate the transaction price to each distinct performance obligation based on the standalone selling price (“SSP”) of each product or service. Our contracts may include multiple performance obligations when customers purchase a combination of products and services. When our customer arrangements have multiple performance obligations that contain a lease as well as distinct services that are delivered simultaneously, we allocate the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, we allocate the contract’s transaction price to each performance obligation on a relative SSP basis.

[0001628280-23-009178:mdna:197]
Stock-Based Compensation

[0001628280-23-009178:mdna:198]
We measure stock-based option awards granted to employees, consultants and directors based on their fair value on the date of grant using the Black-Scholes option-pricing model. Compensation expense for those awards is recognized, net of estimated forfeitures, over the requisite service period, which is generally the vesting period of the respective award.

[0001628280-23-009178:mdna:199]
Prior to the closing of the Merger, the fair value of each stock option grant was estimated on the date of grant using the Black-Scholes option-pricing model, which uses the following inputs: (1) the fair value per share of the common stock issuable upon exercise of the option, (2) the expected term of the option, (3) expected volatility of the price of the common stock, (4) the risk-free interest rate, and (5) the expected dividend yield.

[0001628280-23-009178:mdna:200]
After the closing of the Merger, we determine the fair value of each share of common stock underlying stock-based awards based on the closing price of our common stock as reported by Nasdaq on the date of grant.

[0001628280-23-009178:mdna:201]
The Black-Scholes option-pricing model uses as inputs the fair value of our common shares and assumptions we make for the volatility of our common shares, the expected term of our stock options, the risk-free interest rate for a period that approximates the expected term of our stock options and our expected dividend yield. The Company has historically been a private company and continues to lack sufficient company-specific historical and implied volatility information. Therefore, we estimate our expected share volatility based on the historical volatility of a publicly traded set of peer companies and expect to continue to do so until such time as we have adequate historical data regarding the volatility of our own traded share price.

[0001628280-23-009178:mdna:202]
Valuation of Contingent Earn-out Liability

[0001628280-23-009178:mdna:203]
The estimated fair value of the contingent earn-out shares is determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including volatility, risk-free rate of return, likelihood of a change in control, and expected remaining term. For potential common stock issuances related to a stock price milestones, the fair value was determined based on our expectations of achieving such a milestone and the simulated estimated stock price on the expected date of achievement.

[0001628280-23-009178:mdna:204]
We believe our assumptions are reasonable based on available information, our experience, knowledge, and judgments. These estimates can be affected by factors that are difficult to predict including future (1) EVLV closing price per share on the Nasdaq, (2) estimated stock price volatility over the earn-out period, and (3) risk free rates. Changes in assumptions and estimates used in our analysis, or future results that vary from assumptions used in the analysis, could affect the fair value of the contingent earn-out and could result in material changes in future periods.

[0001628280-23-009178:mdna:205]
Valuation of Contingently Issuable Common Stock Liability

[0001628280-23-009178:mdna:206]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the vesting period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including volatility, risk-free rate of return, likelihood of a change in control, and expected remaining term.

[0001628280-23-009178:mdna:207]
We believe our assumptions are reasonable based on available information, our experience, knowledge, and judgments. These estimates can be affected by factors that are difficult to predict including future (1) EVLV closing price per share on the Nasdaq, (2) estimated stock price volatility over the contingently issuable common shares period, and (3) risk free rates. Changes in assumptions and estimates used in our analysis, or future results that vary from assumptions used in the analysis, could affect the fair value of the contingently issuable common stock and could result in material changes in future periods.

[0001628280-23-009178:mdna:208]
Valuation of Common Stock Warrant Liability and Public Warrant Liability

[0001628280-23-009178:mdna:209]
We classify certain warrants to purchase shares of our common stock (the “Common Stock Warrant”) as liabilities on our consolidated balance sheets as these warrants are free-standing financial instruments that may require us to adjust the exercise price and number of shares that is not consistent with a fixed-for-fixed option pricing model. The warrant liability associated with each of these warrants was initially recorded at fair value on the issuance date of each warrant and is subsequently remeasured to fair value at each balance sheet date. Changes in fair value of the warrants are recognized as a component of other income (expense), net in our statements of operations and comprehensive loss. We will continue to adjust the liability for changes in fair value until the warrants are exercised, expire or qualify for equity classification.

[0001628280-23-009178:mdna:210]
For the common stock warrant, we utilized the Black-Scholes option-pricing model, which incorporates assumptions and estimates to value the warrant liability. Key estimates and assumptions impacting the fair value measurement include (1) the fair value per share of the underlying shares of applicable series of stock issuable upon exercise of the Warrants, (2) the remaining contractual term of the Warrants, (3) the risk-free interest rate, (4) the expected dividend yield and (5) the expected volatility of the price of the underlying applicable common stock. Prior to the closing of the Merger, we assessed these assumptions and estimates on a quarterly basis as additional information impacting the assumptions is obtained. We estimate the fair value per share of the underlying stock based in part on the results of third-party valuations and additional factors deemed relevant. Upon the closing of the Merger, the common stock warrant net settled and converted to common stock. As of December 31, 2021, we no longer have common stock warrants classified as liabilities.

[0001628280-23-009178:mdna:211]
In connection with the closing of the Merger, we assumed the Public Warrants to purchase shares of common stock, which were classified as a liability, as the Public Warrants do not meet the criteria to be indexed to our common stock. Accordingly, we recorded the Public Warrants at fair value upon the closing of the Merger with a corresponding adjustment to additional paid-in capital. After the initial measurement, the fair value of the Public Warrants is subsequently remeasured quarterly based on the listed market price on the Nasdaq of such Public Warrants.

[0001628280-23-009178:mdna:212]
Valuation of Inventory

[0001628280-23-009178:mdna:213]
Inventory is valued at the lower of cost or net realizable value. Cost is computed using the weighted average method. We regularly review inventory quantities on-hand for excess and obsolete inventory and, when circumstances indicate, record charges to write down inventories to their estimated net realizable value, after evaluating historical sales, future demand, our estimates of forecasted net revenue, market conditions and expected product life cycles. A significant change in the timing or level of demand for our products as compared to forecasted amounts may result in recording additional write-offs. Such charges are classified as cost of product revenue in the statements of operations and comprehensive loss. Any write-down of inventory to net realizable value creates a new cost basis.

[0001628280-23-009178:mdna:214]
Capitalized Software

[0001628280-23-009178:mdna:215]
Software development costs consist of certain consulting costs and compensation expenses for employees who devote time to the development of our internal-use software and software embedded in products to be sold or leased, as well as certain upgrades and enhancements that are expected to result in enhanced functionality. We amortize these development costs over the estimated useful life of four years. We determined that a four year life is appropriate for our capitalized software based on our best estimate of the useful life of the software after considering factors such as continuous developments in the technology, obsolescence, and anticipated life of the service offering before significant upgrades. Management evaluates the useful lives of these assets on a quarterly basis and tests for impairment whenever events or changes in circumstances occur that could impact the recoverability of these assets.

[0001628280-23-009178:mdna:216]
We determine the amount of software costs to be capitalized based on the amount of time spent by our developers and consultants on projects in the application stage of development. There is judgment in estimating the time allocated to a particular project in the application stage. A significant change in the time spent on each project could have a material impact on the amount capitalized and related amortization expense in subsequent periods.

[0001628280-23-009178:mdna:217]
Leases

[0001628280-23-009178:mdna:218]
To determine the residual value estimates and useful life of equipment that we lease to our customers, we are required to make judgments about future events that are subject to risks and uncertainties outside of their control, such as inventory levels of new equipment, changing consumer preferences, new technology and mandatory regulations. We have disciplines related to the management and maintenance of our leased equipment designed to manage the risk associated with the residual values of our revenue generating equipment. We periodically review and adjust, as appropriate, the estimated residual values and useful lives of existing revenue generating equipment for the purposes of recording depreciation expense. Based on the results of our analysis, we may adjust the estimated residual values and useful lives of individual assets of our revenue generating equipment each year.

[0001628280-23-009178:mdna:219]
Emerging Growth Company Status

[0001628280-23-009178:mdna:220]
The Jumpstart Our Business Startups Act of 2012, or the JOBS Act, permits an “emerging growth company” such as us to take advantage of an extended transition period to comply with new or revised accounting standards applicable to public companies until those standards would otherwise apply to private companies. We meet the definition of an “emerging growth company” and have elected to use this extended transition period for complying with new or revised accounting standards that have different effective dates for public and private companies until the earlier of the date we (1) are no longer an emerging growth company or (2) affirmatively and irrevocably opt out of the extended transition period provided in the JOBS Act. As a result of this election, we will not be subject to the same new or revised accounting standards as other public companies that are not emerging growth companies and our consolidated financial statements may not be comparable to other public companies that comply with new or revised accounting pronouncements as of public company effective dates. We may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for private companies.
