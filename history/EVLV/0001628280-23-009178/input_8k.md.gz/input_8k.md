# EVLV 8-K — 0001628280-23-005844 filed 2023-03-01

## item codes, every 8-K on or before 2023-03-24

- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2023-03-24

- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001628280-23-005844:8k_2_02:1]
EX-99.1
2
evlv-20230301exx991.htm
EX-99.1

[0001628280-23-005844:8k_2_02:2]
Document

[0001628280-23-005844:8k_2_02:3]
Exhibit 99.1

[0001628280-23-005844:8k_2_02:4]
Investor Relations:

[0001628280-23-005844:8k_2_02:5]
Brian Norris

[0001628280-23-005844:8k_2_02:6]
Vice President of Finance and Investor Relations

[0001628280-23-005844:8k_2_02:7]
bnorris@evolvtechnology.com

[0001628280-23-005844:8k_2_02:8]
Evolv Technology Reports Record Fourth Quarter and Full Year Financial Results

[0001628280-23-005844:8k_2_02:9]
•Q4 Revenue of $20.9 million, up 217% year-over-year

[0001628280-23-005844:8k_2_02:10]
•Q4 Ending ARR1 of $34.1 million, up 164% year-over-year

[0001628280-23-005844:8k_2_02:11]
•Q4 Ending RPO2 of $144.6 million, up 181% year-over-year

[0001628280-23-005844:8k_2_02:12]
•Q4 Ending Evolv Express® subscriptions of 2,267, up 222% year-over-year

[0001628280-23-005844:8k_2_02:13]
Waltham, Massachusetts – March 1, 2023 – Evolv Technology (NASDAQ: EVLV), the leader in AI-based weapons detection security screening, today announced financial results for its fourth quarter and year ended December 31, 20223 and issued its business outlook for 2023.

[0001628280-23-005844:8k_2_02:14]
“We’re pleased to be reporting strong fourth quarter results which capped a historic year of accelerated growth for the Company,” said Peter George, President and Chief Executive Officer of Evolv Technology. “Our results were highlighted by the addition of over 100 new customers in the fourth quarter including the Buffalo School District, the Duval County Schools, the Stony Brook University Hospital, the Honolulu Museum of Art, the Ocean Casino Resort, the Seabreeze Amusement Park, the Philadelphia Phillies, the Houston Astros, and the Tampa Bay Lightning.  Looking ahead, we believe we are well positioned to achieve our goal of doubling our Annual Recurring Revenue in 2023 and further extending our market leadership.”

[0001628280-23-005844:8k_2_02:15]
Results for the Fourth Quarter of 2022

[0001628280-23-005844:8k_2_02:16]
Total revenue for the three months ended December 31, 2022 was $20.9 million, an increase of 217% compared to $6.6 million for the three months ended December 31, 2021. Total Contract Value (“TCV”)4 of orders booked for the three months ended December 31, 2022 was $57.6 million, an increase of 222% compared to $17.9 million in the three months ended December 31, 2021. Annual Recurring Revenue (“ARR”)1 was $34.1 million as of December 31, 2022, an increase of 164% compared to $12.9 million as of December 31, 2021. Net loss for the three months ended December 31, 2022 was $(28.1) million, or $(0.19) per basic and diluted share, compared to net income of $4.8 million or $0.03 per basic and diluted share in the three months ended December 31, 2021. Adjusted earnings (loss)5 for the three months ended December 31, 2022 was $(18.1) million, or $(0.12) per diluted share, compared to adjusted earnings (loss)5 of  $(16.3) million, or $(0.10) per diluted share, for three months ended December 31, 2021. Adjusted EBITDA5 for the three months ended December 31, 2022 was $(17.8) million compared to $(15.2) million in the three months ended December 31, 2021.

[0001628280-23-005844:8k_2_02:17]
Results for 2022

[0001628280-23-005844:8k_2_02:18]
Total revenue in 2022 was $55.2 million, an increase of 136% compared to $23.4 million in 2021. TCV4 of orders booked in 2022 was $144.1 million, an increase of 168% compared to $53.8 million in 2021. Net loss in 2022 was $(86.2) million, or $(0.60) per basic and diluted share, compared to net loss of $(10.9) million, or $(0.15) per basic and diluted share, in 2021. Adjusted earnings (loss)5 in 2022 was $(72.4) million, or $(0.50) per diluted share, compared to $(49.8) million, or $(0.69) per diluted share, in 2021. Adjusted EBITDA5 in 2022 was $(69.4) million, compared to $(40.2) million in 2021.

[0001628280-23-005844:8k_2_02:19]
Company Issues Outlook for 2023

[0001628280-23-005844:8k_2_02:20]
The Company today commented on its business outlook for 2023. The Company's outlook is based on the current indications for its business, which may change at any time.

[0001628280-23-005844:8k_2_02:21]
|  |  | 2023 Business Outlook |
| Estimate (In millions) |  | Issued March 1, 2023 |  |
| Total Revenue |  | $55-$60 |  |
| Annual Recurring Revenue1 (ARR) at 12/31/23 |  | $65-$70 |  |
| Adjusted EBITDA5 |  | ($55-$60) |  |
| Cash and Cash Equivalents |  | $165-$175 |  |

[0001628280-23-005844:8k_2_02:22]
Company to Host Live Conference Call and Webcast

[0001628280-23-005844:8k_2_02:23]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business and other matters.  The conference call may be accessed in the United States by dialing +1.877.692.8955 and using access code 3784749.  The conference call may be accessed outside of the United States by dialing +1.234.720.6979 and using the same access code. The conference call will be simultaneously webcast on the Company’s investor relations website, which can be accessed at http://ir.evolvtechnology.com.  The press release with the financial results as well as the accompanying investor presentation materials will be accessible from the Company’s website prior to the conference call.  A replay of the conference call will be available for a period of 30 days by dialing +1.866.207.1041 or +1.402.970.0847 and using access code 9681780 or by accessing the webcast replay on the Company’s investor relations website at http://ir.evolvtechnology.com

[0001628280-23-005844:8k_2_02:24]
About Evolv Technology

[0001628280-23-005844:8k_2_02:25]
Evolv Technology (NASDAQ: EVLV) is transforming human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered weapons detection and analytics.  Its mission is to transform security to create a safer world to live, work, learn, and play. Evolv has digitally transformed the gateways in places where people gather by enabling seamless integration combined with powerful analytics and insights.  Evolv’s advanced systems have scanned more than 500 million people, second only to the Department of Homeland Security’s Transportation Security Administration (TSA) in the United States.  Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category. Evolv Technology®, Evolv Express®, Evolv Insights®, and Evolv Cortex AI® are registered trademarks or trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit https://evolvtechnology.com.

[0001628280-23-005844:8k_2_02:26]
1 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001628280-23-005844:8k_2_02:27]
2 We define Remaining Performance Obligation, or RPO, as estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied or partially satisfied as of the end of the quarter.

[0001628280-23-005844:8k_2_02:28]
3 Amounts herein pertaining to December 31, 2022 represent a preliminary estimate as of the date of this earnings release. More information on our results of operations for the twelve months ended December 31, 2022 will be provided upon filing our Annual Report on Form 10-K with the Securities and Exchange Commission.

[0001628280-23-005844:8k_2_02:29]
4 We define Total Contract Value, or TCV, of orders booked as the total value of the contract over the specified term. Our calculation of TCV is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases). TCV should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of TCV may differ from similarly titled metrics presented by other companies.  The fourth quarter of the fiscal year ended December 31, 2022 is the final quarter that we will be reporting TCV.

[0001628280-23-005844:8k_2_02:30]
5 Non-GAAP Financial Measures

[0001628280-23-005844:8k_2_02:31]
In this press release, the Company’s adjusted operating expenses, adjusted gross profit (loss), adjusted gross margin, adjusted operating income (loss), adjusted EBITDA, adjusted earnings (loss), and adjusted earnings per share-diluted are not presented in accordance with

[0001628280-23-005844:8k_2_02:32]
generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted gross profit and adjusted gross margin exclude one-time items including stock-based compensation expense which management believes provides a more meaningful representation of contribution margin. Adjusted operating expenses is defined as operating expenses less one-time items including stock-based compensation expense, restructuring expenses, and loss on impairment of lease equipment which management believes provides a more meaningful representation of on-going operating expense levels.  Adjusted EBITDA is defined as net income (loss) plus depreciation and amortization, share-based compensation, and certain other one-time expenses. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, change in fair value of derivative liability, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, change in fair value of common stock warrant liability, restructuring expenses, loss on impairment of lease equipment, and certain other one-time expenses. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release. The Company is unable to provide a reconciliation of non-GAAP Adjusted EBITDA to Net Income (Loss), its most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact this GAAP financial measure are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of derivative liabilities, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001628280-23-005844:8k_2_02:33]
Forward-Looking Statements

[0001628280-23-005844:8k_2_02:34]
EVOLV TECHNOLOGY

[0001628280-23-005844:8k_2_02:35]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001628280-23-005844:8k_2_02:36]
(In thousands, except share and per share data)

[0001628280-23-005844:8k_2_02:37]
(Unaudited)

[0001628280-23-005844:8k_2_02:38]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 12,806 |  |  | $ | 3,352 |  |  | $ | 31,985 |  |  | $ | 13,631 |  |
| Subscription revenue | 5,361 |  |  | 2,743 |  |  | 17,569 |  |  | 7,803 |  |
| Service revenue | 2,718 |  |  | 503 |  |  | 5,641 |  |  | 1,959 |  |
| Total revenue | 20,885 |  |  | 6,598 |  |  | 55,195 |  |  | 23,393 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 18,062 |  |  | 4,893 |  |  | 41,575 |  |  | 12,279 |  |
| Cost of subscription revenue | 1,739 |  |  | 1,421 |  |  | 7,469 |  |  | 4,501 |  |
| Cost of service revenue | 1,030 |  |  | 899 |  |  | 4,422 |  |  | 2,584 |  |
| Total cost of revenue | 20,831 |  |  | 7,213 |  |  | 53,466 |  |  | 19,364 |  |
| Gross profit | 54 |  |  | (615) |  |  | 1,729 |  |  | 4,029 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 4,824 |  |  | 3,059 |  |  | 18,771 |  |  | 11,458 |  |
| Sales and marketing | 13,243 |  |  | 8,343 |  |  | 46,412 |  |  | 26,099 |  |
| General and administrative | 8,451 |  |  | 7,811 |  |  | 37,719 |  |  | 19,869 |  |
| Loss from impairment of property and equipment | 123 |  |  | 213 |  |  | 1,161 |  |  | 1,869 |  |
| Total operating expenses | 26,641 |  |  | 19,426 |  |  | 104,063 |  |  | 59,295 |  |
| Loss from operations | (26,587) |  |  | (20,041) |  |  | (102,334) |  |  | (55,266) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (223) |  |  | (116) |  |  | (712) |  |  | (6,068) |  |
| Interest income | 1,554 |  |  | — |  |  | 3,165 |  |  | — |  |
| Other expense, net | (7) |  |  | 52 |  |  | (64) |  |  | (617) |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | (12,685) |  |
| Change in fair value of derivative liability | — |  |  | — |  |  | — |  |  | (1,745) |  |
| Change in fair value of contingent earn-out liability | (2,766) |  |  | 14,751 |  |  | 6,988 |  |  | 47,360 |  |
| Change in fair value of contingently issuable common stock liability | (657) |  |  | 688 |  |  | 1,872 |  |  | 6,406 |  |
| Change in fair value of public warrant liability | 609 |  |  | 9,454 |  |  | 4,906 |  |  | 12,606 |  |
| Change in fair value of common stock warrant liability | — |  |  | — |  |  | — |  |  | (879) |  |
| Total other income (expense), net | $ | (1,490) |  |  | $ | 24,829 |  |  | $ | 16,155 |  |  | $ | 44,378 |  |
| Net income (loss) | $ | (28,077) |  |  | $ | 4,788 |  |  | $ | (86,179) |  |  | $ | (10,888) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |
| Basic | 144,856,047 |  | 142,403,779 |  | 143,858,668 |  | 71,662,694 |
| Diluted | 144,856,047 |  | 161,906,393 |  | 143,858,668 |  | 71,662,694 |
| Net income (loss) per share |  |  |  |  |  |  |  |
| Basic | $ | (0.19) |  |  | $ | 0.03 |  |  | $ | (0.60) |  |  | $ | (0.15) |  |
| Diluted | $ | (0.19) |  |  | $ | 0.03 |  |  | $ | (0.60) |  |  | $ | (0.15) |  |
| Net income (loss) | $ | (28,077) |  |  | $ | 4,788 |  |  | $ | (86,179) |  |  | $ | (10,888) |  |
| Other comprehensive income (loss) |  |  |  |  |  |  |  |
| Cumulative translation adjustment | (45) |  |  | — |  |  | (10) |  |  | — |  |
| Total other comprehensive income | (45) |  |  | — |  |  | (10) |  |  | — |  |
| Total comprehensive income (loss) | $ | (28,122) |  |  | $ | 4,788 |  |  | $ | (86,189) |  |  | $ | (10,888) |  |

[0001628280-23-005844:8k_2_02:39]
EVOLV TECHNOLOGY

[0001628280-23-005844:8k_2_02:40]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-23-005844:8k_2_02:41]
(In thousands, except share and per share data)

[0001628280-23-005844:8k_2_02:42]
(Unaudited)

[0001628280-23-005844:8k_2_02:43]
|  | December 31, 2022 |  | December 31, 2021 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 229,783 |  |  | $ | 307,492 |  |
| Restricted cash | — |  |  | 400 |  |
| Accounts receivable, net | 31,920 |  |  | 6,477 |  |
| Inventory | 10,257 |  |  | 2,890 |  |
| Current portion of contract assets | 2,852 |  |  | 1,459 |  |
| Current portion of commission asset | 3,232 |  |  | 1,645 |  |
| Prepaid expenses and other current assets | 14,388 |  |  | 10,757 |  |
| Total current assets | 292,432 |  |  | 331,120 |  |
| Restricted cash, noncurrent | 275 |  |  | 275 |  |
| Contract assets, noncurrent | 1,386 |  |  | 3,418 |  |
| Commission asset, noncurrent | 6,034 |  |  | 3,719 |  |
| Property and equipment, net | 44,707 |  |  | 23,783 |  |
| Operating lease right-of-use assets | 1,673 |  |  | — |  |
| Other assets | 1,835 |  |  | 542 |  |
| Total assets | $ | 348,342 |  |  | $ | 362,857 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 18,194 |  |  | $ | 6,045 |  |
| Accrued expenses and other current liabilities | 11,545 |  |  | 9,551 |  |
| Current portion of deferred revenue | 18,273 |  |  | 6,599 |  |
| Current portion of deferred rent | — |  |  | 135 |  |
| Current portion of long-term debt | 10,000 |  |  | 2,000 |  |
| Current portion of operating lease liabilities | 1,114 |  |  | — |  |
| Total current liabilities | 59,126 |  |  | 24,330 |  |
| Deferred revenue, noncurrent | 17,695 |  |  | 2,475 |  |
| Deferred rent, noncurrent | — |  |  | 333 |  |
| Long-term debt, noncurrent | 19,683 |  |  | 7,945 |  |
| Operating lease liabilities, noncurrent | 892 |  |  | — |  |
| Contingent earn-out liability | 14,218 |  |  | 21,206 |  |
| Contingently issuable common stock liability | 3,392 |  |  | 5,264 |  |
| Public warrant liability | 6,124 |  |  | 11,030 |  |
| Total liabilities | 121,130 |  |  | 72,583 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at December 31, 2022 and December 31, 2021; no shares issued and outstanding at December 31, 2022 and December 31, 2021 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at December 31, 2022 and December 31, 2021, respectively; 145,204,974 and 142,745,021 shares issued and outstanding at December 31, 2022 and December 31, 2021, respectively | 15 |  |  | 14 |  |
| Additional paid-in capital | 419,190 |  |  | 396,064 |  |
| Accumulated other comprehensive income | (10) |  |  | — |  |
| Accumulated deficit | (191,983) |  |  | (105,804) |  |
| Stockholders’ equity | 227,212 |  |  | 290,274 |  |
| Total liabilities and stockholders’ equity | $ | 348,342 |  |  | $ | 362,857 |  |

[0001628280-23-005844:8k_2_02:44]
EVOLV TECHNOLOGY

[0001628280-23-005844:8k_2_02:45]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-23-005844:8k_2_02:46]
(In thousands)

[0001628280-23-005844:8k_2_02:47]
(Unaudited)

[0001628280-23-005844:8k_2_02:48]
|  | Twelve Months EndedDecember 31, |
|  | 2022 |  | 2021 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (86,179) |  |  | $ | (10,888) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 5,465 |  |  | 2,895 |  |
| Write-off of inventory | 1,582 |  |  | 2,132 |  |
| Adjustment to property and equipment for sales type leases | (625) |  |  | (91) |  |
| Loss from impairment of property and equipment | 1,161 |  |  | 1,869 |  |
| Loss on disposal of property and equipment | — |  |  | 617 |  |
| Stock-based compensation | 22,498 |  |  | 9,596 |  |
| Non-cash interest expense | 55 |  |  | 5,245 |  |
| Non-cash lease expense | 811 |  |  | — |  |
| Provision recorded for allowance for doubtful accounts | 150 |  |  | (13) |  |
| Loss on extinguishment of debt | — |  |  | 12,685 |  |
| Change in fair value of derivative liability | — |  |  | 1,745 |  |
| Change in fair value of common stock warrant liability | — |  |  | 879 |  |
| Change in fair value of earn-out liability | (6,988) |  |  | (47,360) |  |
| Change in fair value of contingently issuable common stock | (1,872) |  |  | (6,406) |  |
| Change in fair value of public warrant liability | (4,906) |  |  | (12,606) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (25,593) |  |  | (5,063) |  |
| Inventory | (8,495) |  |  | (3,436) |  |
| Commission assets | (3,902) |  |  | (3,072) |  |
| Contract assets | 639 |  |  | (4,877) |  |
| Other assets | (419) |  |  | 32 |  |
| Prepaid expenses and other current assets | (3,174) |  |  | (9,148) |  |
| Accounts payable | 7,661 |  |  | 765 |  |
| Deferred revenue | 26,887 |  |  | 4,832 |  |
| Deferred rent | — |  |  | 457 |  |
| Warranty Reserve | — |  |  | (42) |  |
| Accrued expenses and other current liabilities | 1,462 |  |  | 2,472 |  |
| Operating lease liability | (946) |  |  | — |  |
| Net cash used in operating activities | (74,728) |  |  | (56,781) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (2,720) |  |  | (1,028) |  |
| Purchases of property and equipment | (21,473) |  |  | (16,557) |  |
| Proceeds from sale of property and equipment | 312 |  |  | — |  |
| Net cash used in investing activities | (23,881) |  |  | (17,585) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 827 |  |  | 915 |  |
| Proceeds from issuance of common stock from the PIPE Investment | — |  |  | 300,000 |  |
| Proceeds from the closing of the Merger | — |  |  | 84,945 |  |
| Payment of offering costs from the closing of the Merger and PIPE Investment | — |  |  | (34,132) |  |
| Repayment of financing obligations | — |  |  | (359) |  |
| Proceeds from long-term debt, net of issuance costs | 29,683 |  |  | 31,882 |  |
| Repayment of principal on long-term debt | (10,000) |  |  | (5,422) |  |
| Net cash provided by (used in) financing activities | 20,510 |  |  | 377,829 |  |
| Effect of exchange rate changes on cash and cash equivalents | (10) |  |  | — |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (78,109) |  |  | 303,463 |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 308,167 |  |  | 4,704 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 230,058 |  |  | $ | 308,167 |  |

[0001628280-23-005844:8k_2_02:49]
EVOLV TECHNOLOGY

[0001628280-23-005844:8k_2_02:50]
REVISION OF PRIOR PERIOD FINANCIAL STATEMENTS

[0001628280-23-005844:8k_2_02:51]
(In thousands)

[0001628280-23-005844:8k_2_02:52]
(Unaudited)

[0001628280-23-005844:8k_2_02:53]
In preparing the condensed consolidated financial statements as of and for the three and six months ended June 30, 2022, the Company identified various errors in its previously issued financial statements. The identified errors impacted the Company's previously issued 2021 quarterly and annual financial statements and its quarterly financial statements for the three months ended March 31, 2022, and accordingly the Company has made adjustments to the prior period amounts presented herein. A summary of the revisions to certain previously reported financial information impacting amounts presented in this earnings release is as follows (in thousands):

[0001628280-23-005844:8k_2_02:54]
|  | Year EndedDecember 31, 2021 |
|  | As Previously Reported |  | Adjustment |  | As Revised |
| Revenue: |  |  |  |  |  |
| Product revenue | $ | 13,917 |  |  | $ | (286) |  |  | $ | 13,631 |  |
| Subscription revenue | 7,855 |  |  | (52) |  |  | 7,803 |  |
| Service revenue | 1,920 |  |  | 39 |  |  | 1,959 |  |
| Total revenue | 23,692 |  |  | (299) |  |  | 23,393 |  |
| Cost of revenue: |  |  |  |  |  |
| Cost of product revenue | 12,471 |  |  | (192) |  |  | 12,279 |  |
| Cost of subscription revenue | 3,644 |  |  | 857 |  |  | 4,501 |  |
| Cost of service revenue | 936 |  |  | 1,648 |  |  | 2,584 |  |
| Total cost of revenue | 17,051 |  |  | 2,313 |  |  | 19,364 |  |
| Gross profit | 6,641 |  |  | (2,612) |  |  | 4,029 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 11,416 |  |  | 42 |  |  | 11,458 |  |
| Sales and marketing expense | 27,404 |  |  | (1,305) |  |  | 26,099 |  |
| General and administrative | 20,013 |  |  | (144) |  |  | 19,869 |  |
| Loss from impairment of property and equipment | 1,869 |  |  | — |  |  | 1,869 |  |
| Total operating expenses | 60,702 |  |  | (1,407) |  |  | 59,295 |  |
| Loss from operations | (54,061) |  |  | (1,205) |  |  | (55,266) |  |
| Other income (expense), net: |  |  |  |  |  |
| Interest expense, net | (6,095) |  |  | 27 |  |  | (6,068) |  |
| Interest income | — |  |  | — |  |  | — |  |
| Loss on disposal of property and equipment | (617) |  |  | — |  |  | (617) |  |
| Loss on extinguishment of debt | (12,685) |  |  | — |  |  | (12,685) |  |
| Change in fair value of derivative liability | (1,745) |  |  | — |  |  | (1,745) |  |
| Change in fair value of contingent earn-out liability | 46,212 |  |  | 1,148 |  |  | 47,360 |  |
| Change in fair value of contingently issuable common stock liability | 6,406 |  |  | — |  |  | 6,406 |  |
| Change in fair value of public warrant liability | 12,606 |  |  | — |  |  | 12,606 |  |
| Change in fair value of common stock warrant liability | (879) |  |  | — |  |  | (879) |  |
| Total other income (expense), net | 43,203 |  |  | 1,175 |  |  | 44,378 |  |
| Net loss | $ | (10,858) |  |  | $ | (30) |  |  | $ | (10,888) |  |

[0001628280-23-005844:8k_2_02:55]
|  | December 31, 2021 |
|  | As Previously Reported | Adjustment | As Revised |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 307,492 |  | $ | — |  | $ | 307,492 |  |
| Restricted cash | 400 |  | — |  | 400 |  |
| Accounts receivable, net | 6,477 |  | — |  | 6,477 |  |
| Inventory | 5,140 |  | (2,250) |  | 2,890 |  |
| Current portion of contract assets | 1,459 |  | — |  | 1,459 |  |
| Current portion of commission asset | 1,645 |  | — |  | 1,645 |  |
| Prepaid expenses and other current assets | 11,047 |  | (290) |  | 10,757 |  |
| Total current assets | 333,660 |  | (2,540) |  | 331,120 |  |
| Restricted cash, noncurrent | 275 |  | — |  | 275 |  |
| Contract assets, noncurrent | 3,418 |  | — |  | 3,418 |  |
| Commission asset, noncurrent | 3,719 |  | — |  | 3,719 |  |
| Property and equipment, net | 21,592 |  | 2,191 |  | 23,783 |  |
| Other assets | 401 |  | 141 |  | 542 |  |
| Total assets | $ | 363,065 |  | $ | (208) |  | $ | 362,857 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 6,363 |  | $ | (318) |  | $ | 6,045 |  |
| Accrued expenses and other current liabilities | 9,183 |  | 368 |  | 9,551 |  |
| Current portion of deferred revenue | 6,690 |  | (91) |  | 6,599 |  |
| Current portion of deferred rent | 135 |  | — |  | 135 |  |
| Current portion of long-term debt | 2,000 |  | — |  | 2,000 |  |
| Total current liabilities | 24,371 |  | (41) |  | 24,330 |  |
| Deferred revenue, noncurrent | 2,475 |  | — |  | 2,475 |  |
| Deferred rent, noncurrent | 333 |  | — |  | 333 |  |
| Long-term debt, noncurrent | 7,945 |  | — |  | 7,945 |  |
| Contingent earn-out liability | 20,809 |  | 397 |  | 21,206 |  |
| Contingently issuable common stock liability | 5,264 |  | — |  | 5,264 |  |
| Public warrant liability | 11,030 |  | — |  | 11,030 |  |
| Total liabilities | 72,227 |  | 356 |  | 72,583 |  |
| Stockholders’ equity: |  |  |  |
| Convertible preferred stock | — |  | — |  | — |  |
| Common stock | 14 |  | — |  | 14 |  |
| Additional paid-in capital | 395,563 |  | 501 |  | 396,064 |  |
| Accumulated deficit | (104,739) |  | (1,065) |  | (105,804) |  |
| Stockholders’ equity | 290,838 |  | (564) |  | 290,274 |  |
| Total liabilities and stockholders’ equity | $ | 363,065 |  | $ | (208) |  | $ | 362,857 |  |

[0001628280-23-005844:8k_2_02:56]
EVOLV TECHNOLOGY

[0001628280-23-005844:8k_2_02:57]
SUMMARY OF KEY OPERATING STATISTICS

[0001628280-23-005844:8k_2_02:58]
(Unaudited)

[0001628280-23-005844:8k_2_02:59]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2021 |  | June 30,2021 |  | September 30,2021 |  | December 31,2021 |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |  | December 31,2022 |
| New customers |  | 13 |  |  | 21 |  |  | 23 |  |  | 27 |  |  | 44 |  |  | 53 |  |  | 92 |  |  | 106 |  |
| Total contract value of orders booked |  | $ | 8,424 |  |  | $ | 10,476 |  |  | $ | 16,995 |  |  | $ | 17,916 |  |  | $ | 19,167 |  |  | $ | 22,066 |  |  | $ | 45,285 |  |  | $ | 57,625 |  |
| Annual recurring revenue |  | $ | 5,424 |  |  | $ | 7,423 |  |  | $ | 9,932 |  |  | $ | 12,907 |  |  | $ | 16,641 |  |  | $ | 20,865 |  |  | $ | 28,741 |  |  | $ | 34,120 |  |
| Remaining performance obligation |  | $ | 17,658 |  |  | $ | 24,930 |  |  | $ | 34,152 |  |  | $ | 51,430 |  |  | $ | 63,750 |  |  | $ | 80,978 |  |  | $ | 109,407 |  |  | $ | 144,561 |  |
| Net additions |  | 64 |  |  | 113 |  |  | 176 |  |  | 136 |  |  | 207 |  |  | 237 |  |  | 545 |  |  | 575 |  |
| Ending deployed units |  | 278 |  |  | 391 |  |  | 567 |  |  | 703 |  |  | 910 |  |  | 1,147 |  |  | 1,692 |  |  | 2,267 |  |

[0001628280-23-005844:8k_2_02:60]
EVOLV TECHNOLOGY

[0001628280-23-005844:8k_2_02:61]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001628280-23-005844:8k_2_02:62]
(In thousands)

[0001628280-23-005844:8k_2_02:63]
(Unaudited)

[0001628280-23-005844:8k_2_02:64]
|  | Three Months Ended, |
|  |  | March 31,2021 |  | June 30,2021 |  | September 30,2021 |  | December 31,2021 |  | March 31,2022 |  | June 30,2022 |  | September 30,2022 |  | December 31,2022 |
| Operating expenses, GAAP |  | $ | 9,400 |  |  | $ | 7,642 |  |  | $ | 22,826 |  |  | $ | 19,429 |  |  | $ | 24,760 |  |  | $ | 25,835 |  |  | $ | 26,827 |  |  | $ | 26,641 |  |
| Stock-based compensation(1) |  | (300) |  |  | (1,052) |  |  | (4,589) |  |  | (3,513) |  |  | (3,819) |  |  | (4,781) |  |  | (6,298) |  |  | (6,771) |  |
| Restructuring expenses |  | — |  |  | — |  |  | — |  |  | — |  |  | (324) |  |  | 13 |  |  | — |  |  | — |  |
| Loss on impairment of lease equipment |  | — |  |  | — |  |  | (1,656) |  |  | (213) |  |  | (96) |  |  | (316) |  |  | (626) |  |  | (123) |  |
| Other one-time expenses |  | — |  |  | — |  |  | (685) |  |  | — |  |  | (1,107) |  |  | (2,298) |  |  | (69) |  |  | (41) |  |
| Adjusted Operating Expenses |  | $ | 9,100 |  |  | $ | 6,590 |  |  | $ | 15,896 |  |  | $ | 15,703 |  |  | $ | 19,414 |  |  | $ | 18,453 |  |  | $ | 19,834 |  |  | $ | 19,706 |  |

[0001628280-23-005844:8k_2_02:65]
(1) Reflects immaterial adjustments to previously reported stock-based compensation amounts.

[0001628280-23-005844:8k_2_02:66]
EVOLV TECHNOLOGY

[0001628280-23-005844:8k_2_02:67]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT AND GAAP OPERATING INCOME (LOSS) TO ADJUSTED OPERATING INCOME (LOSS)

[0001628280-23-005844:8k_2_02:68]
(In thousands)

[0001628280-23-005844:8k_2_02:69]
(Unaudited)

[0001628280-23-005844:8k_2_02:70]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue | $ | 20,885 |  |  | $ | 6,598 |  |  | $ | 55,195 |  |  | $ | 23,393 |  |
| Cost of revenue | 20,831 |  |  | 7,213 |  |  | 53,466 |  |  | 19,364 |  |
| Gross Profit, GAAP | 54 |  |  | (615) |  |  | 1,729 |  |  | 4,029 |  |
| Stock-based compensation(2) | 214 |  |  | 51 |  |  | 829 |  |  | 142 |  |
| Amortization of capitalized stock-based compensation | 9 |  |  | 2 |  |  | 24 |  |  | 2 |  |
| Adjusted Gross Profit | $ | 277 |  |  | $ | (562) |  |  | $ | 2,582 |  |  | $ | 4,173 |  |
| Gross Margin % | 0.3 | % |  | (9.3) | % |  | 3.1 | % |  | 17.2 | % |
| Adjusted Gross Margin % | 1.3 | % |  | (8.5) | % |  | 4.7 | % |  | 17.8 | % |

[0001628280-23-005844:8k_2_02:71]
(2) Reflects immaterial adjustments to previously reported stock-based compensation amounts.

[0001628280-23-005844:8k_2_02:72]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Operating income (loss), GAAP | $ | (26,587) |  |  | $ | (20,041) |  |  | $ | (102,334) |  |  | $ | (55,266) |  |
| Stock-based compensation | 6,985 |  |  | 3,564 |  |  | 22,498 |  |  | 9,596 |  |
| Amortization of capitalized stock-based compensation | 9 |  |  | 2 |  |  | 24 |  |  | 2 |  |
| Restructuring expenses | — |  |  | — |  |  | 311 |  |  | — |  |
| Loss on impairment of lease equipment | 123 |  |  | 213 |  |  | 1,161 |  |  | 1,869 |  |
| Other one-time expenses | 41 |  |  | — |  |  | 3,515 |  |  | 685 |  |
| Adjusted Operating Income (loss) | $ | (19,429) |  |  | $ | (16,262) |  |  | $ | (74,825) |  |  | $ | (43,114) |  |

[0001628280-23-005844:8k_2_02:73]
EVOLV TECHNOLOGY

[0001628280-23-005844:8k_2_02:74]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-23-005844:8k_2_02:75]
(In thousands)

[0001628280-23-005844:8k_2_02:76]
(Unaudited)

[0001628280-23-005844:8k_2_02:77]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income (loss) | $ | (28,077) |  |  | $ | 4,788 |  |  | $ | (86,179) |  |  | $ | (10,888) |  |
| Depreciation & amortization(3) | 1,683 |  |  | 1,041 |  |  | 5,465 |  |  | 2,895 |  |
| Stock-based compensation | 6,985 |  |  | 3,564 |  |  | 22,498 |  |  | 9,596 |  |
| Interest expense (income) | (1,331) |  |  | 116 |  |  | (2,453) |  |  | 6,068 |  |
| Loss on disposal of property & equipment | — |  |  | (42) |  |  | — |  |  | 617 |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | 12,685 |  |
| Change in fair value of derivative liability | — |  |  | — |  |  | — |  |  | 1,745 |  |
| Change in fair value of contingent earn-out liability | 2,766 |  |  | (14,751) |  |  | (6,988) |  |  | (47,360) |  |
| Change in fair value of contingently issuable common stock liability | 657 |  |  | (688) |  |  | (1,872) |  |  | (6,406) |  |
| Change in fair value of public warrant liability | (609) |  |  | (9,454) |  |  | (4,906) |  |  | (12,606) |  |
| Change in fair value of common stock warrant liability | — |  |  | — |  |  | — |  |  | 879 |  |
| Restructuring expenses | — |  |  | — |  |  | 311 |  |  | — |  |
| Loss on impairment of lease equipment | 123 |  |  | 213 |  |  | 1,161 |  |  | 1,869 |  |
| Other one-time expenses | 41 |  |  | — |  |  | 3,515 |  |  | 685 |  |
| Adjusted EBITDA | $ | (17,762) |  |  | $ | (15,213) |  |  | $ | (69,448) |  |  | $ | (40,221) |  |

[0001628280-23-005844:8k_2_02:78]
(3) Reflects immaterial adjustments to previously reported depreciation and amortization amounts.

[0001628280-23-005844:8k_2_02:79]
EVOLV TECHNOLOGY

[0001628280-23-005844:8k_2_02:80]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001628280-23-005844:8k_2_02:81]
(In thousands, except share and per share data)

[0001628280-23-005844:8k_2_02:82]
(Unaudited)

[0001628280-23-005844:8k_2_02:83]
|  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income (loss) | $ | (28,077) |  |  | $ | 4,788 |  |  | $ | (86,179) |  |  | $ | (10,888) |  |
| Stock-based compensation | 6,985 |  |  | 3,564 |  |  | 22,498 |  |  | 9,596 |  |
| Amortization of capitalized stock-based compensation | 9 |  |  | 2 |  |  | 24 |  |  | 2 |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | 12,685 |  |
| Change in fair value of derivative liability | — |  |  | — |  |  | — |  |  | 1,745 |  |
| Change in fair value of contingent earn-out liability | 2,766 |  |  | (14,751) |  |  | (6,988) |  |  | (47,360) |  |
| Change in fair value of contingently issuable common stock liability | 657 |  |  | (688) |  |  | (1,872) |  |  | (6,406) |  |
| Change in fair value of public warrant liability | (609) |  |  | (9,454) |  |  | (4,906) |  |  | (12,606) |  |
| Change in fair value of common stock warrant liability | — |  |  | — |  |  | — |  |  | 879 |  |
| Restructuring expenses | — |  |  | — |  |  | 311 |  |  | — |  |
| Loss on impairment of lease equipment | 123 |  |  | 213 |  |  | 1,161 |  |  | 1,869 |  |
| Other one-time expenses | 41 |  |  | — |  |  | 3,515 |  |  | 685 |  |
| Adjusted earnings (loss) | $ | (18,105) |  |  | $ | (16,326) |  |  | $ | (72,436) |  |  | $ | (49,799) |  |
| Weighted average common shares outstanding – diluted | 144,856,047 |  |  | 161,906,393 |  |  | 143,858,668 |  |  | 71,662,694 |  |
| Adjusted Earnings Per Share – diluted | $ | (0.12) |  |  | $ | (0.10) |  |  | $ | (0.50) |  |  | $ | (0.69) |  |
