# EVLV note change history — 0001104659-21-106340 → 0001558370-21-015999


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-15):
[0001558370-21-015999:note_history:1]
17. Commitments and Contingencies
  (was, 2021-08-16, similarity 0.8986):
[0001104659-21-106340:note_history:1]
NOTE 8 – COMMITMENTS AND CONTINGENCIES

- added (2021-11-15):
[0001558370-21-015999:note_history:2]
Operating Leases

- added (2021-11-15):
[0001558370-21-015999:note_history:3]
The Company entered into a new lease agreement for additional office space starting May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. In May 2021, the Company leased the space. The Company is required to maintain a minimum cash balance of $0.7 million as a security deposit on the space which is classified as restricted cash, current and restricted cash, non-current on the consolidated balance sheet as of September 30, 2021. The Company is generally obligated for the cost of property taxes, insurance, and maintenance relating to this lease.

- added (2021-11-15):
[0001558370-21-015999:note_history:4]
Total future minimum lease payments under this noncancelable operating lease amount to $3.4 million. Rent expense for the three months ended September 30, 2021 and 2020 was approximately $0.3 million and $0.1 million, respectively. Rent expense for the nine months ended September 30, 2021 and 2020 was approximately $0.7 million and $0.3 million, respectively.

- added (2021-11-15):
[0001558370-21-015999:note_history:5]
Future minimum rental commitments to be paid by the Company at September 30, 2021 for this lease is as follows (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:6]
| Year Ending December 31: | ​ |  | ​ |
| 2021 (remaining three months) | ​ | $ | 185 |
| 2022 | ​ | ​ | 1,116 |
| 2023 | ​ |  | 1,150 |
| 2024 | ​ |  | 981 |
| Total future minimum lease payments | ​ | $ | 3,432 |

- added (2021-11-15):
[0001558370-21-015999:note_history:7]
Indemnification Agreements

- added (2021-11-15):
[0001558370-21-015999:note_history:8]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its consolidated financial statements as of September 30, 2021 or December 31, 2020.

- added (2021-11-15):
[0001558370-21-015999:note_history:9]
Legal Proceedings

- added (2021-11-15):
[0001558370-21-015999:note_history:10]
The Company is not a party to any litigation and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses as incurred the costs related to such legal proceedings.

- removed (2021-11-15):
[0001104659-21-106340:note_history:11]
Business Combination Costs

- removed (2021-11-15):
[0001104659-21-106340:note_history:12]
In connection with identifying an initial Business Combination candidate and negotiating an initial Business Combination, the Company has entered into and expects to enter into additional engagement letters or agreements with various consultants, advisors, professionals and others. The services under these engagement letters and agreements are material in amount and in some instances include contingent or success fees. Contingent or success fees (but not deferred underwriting compensation) would be charged to operations in the quarter that an initial Business Combination is consummated. In most instances (except with respect to our independent registered public accounting firm), these engagement letters and agreements are expected to specifically provide that such counterparties waive their rights to seek repayment from the funds in the Trust Account.

- removed (2021-11-15):
[0001104659-21-106340:note_history:13]
Risks and Uncertainties – COVID-19

- removed (2021-11-15):
[0001104659-21-106340:note_history:14]
Management continues to evaluate the impact of the COVID-19 pandemic on the industry and has concluded that while it is reasonably possible that the virus could have a negative effect on the Company’s financial position, results of its operations and/or search for a target company and/or a target company’s financial position and results of its operations, the specific impact is not readily determinable as of the date of these financial statements.  The financial statements do not include any adjustments that might result from the outcome of this uncertainty.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2021-11-15):
[0001104659-21-106340:note_history:15]
Basis of Presentation:

- removed (2021-11-15):
[0001104659-21-106340:note_history:16]
The accompanying unaudited condensed consolidated interim financial statements of the Company are presented in U.S. dollars and in conformity with accounting principles generally accepted in the United States of America (“GAAP”) pursuant to the rules and regulations of the SEC and reflect all adjustments, consisting only of normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the financial position as of June 30, 2021, and the results of operations and cash flows for the periods presented. Certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted pursuant to such rules and regulations. Interim results are not necessarily indicative of results for a full year or any later period.  Certain reclassifications have been made to the December 31, 2020 balance sheet to conform to the current presentation.

- removed (2021-11-15):
[0001104659-21-106340:note_history:17]
The accompanying unaudited condensed consolidated interim financial statements should be read in conjunction with the Company’s audited financial statements and notes thereto included in the Company’s final prospectus dated July 28, 2020, as well as the Company’s Annual Report, Amendment #1 on Form 10-K/A filed with the SEC on May 14, 2021.

- removed (2021-11-15):
[0001104659-21-106340:note_history:18]
At June 30, 2021, the Company has approximately $181,000 in cash, approximately $7,706,000 of current liabilities and approximately $7,380,000 in negative working capital.  The preponderance of the current liabilities (approximately $7,300,000) results from amounts accrued as payable to professional service firms who have agreed to deferred payment terms, or success fees, that are payable at the closing of a Business Combination.  Such accrued fees were paid upon the closing of the Business Combination on July 16, 2020.  Therefore, in connection with the Company’s assessment of going concern considerations in accordance with FASB Accounting Standards Update (“ASU”) 2014-15, “Disclosures of Uncertainties about an Entity’s Ability to Continue as a Going Concern,” as of June 30, 2021, management has determined that the Company’s current liquidity is sufficient to fund the working capital needs of the Company until the earlier of the consummation of the Business Combination or one year from the date of issuance of these financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-11-15):
[0001558370-21-015999:note_history:19]
1. Nature of the Business and Basis of Presentation

- added (2021-11-15):
[0001558370-21-015999:note_history:20]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of the Merger and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

- added (2021-11-15):
[0001558370-21-015999:note_history:21]
Legacy Evolv was incorporated under the laws of the State of Delaware on July 8, 2013. The Company is the global leader in AI-based touchless security screening. The Company’s mission is to make the world a safer and more enjoyable place to live, work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to address the chronic epidemic of mass shootings and terrorist attacks in a cost-effective manner while improving the visitor experience. The Company is headquartered in Waltham, Massachusetts.

- changed (2021-11-15):
[0001558370-21-015999:note_history:22]
Merger with NewHold Investment Corp.
  (was, 2021-08-16, similarity 0.64):
[0001104659-21-106340:note_history:22]
NEWHOLD INVESTMENT CORP AND SUBSIDIARY.

- added (2021-11-15):
[0001558370-21-015999:note_history:23]
On July 16, 2021 (the “Closing Date”), the predecessor company, consummated the previously announced Merger with Legacy Evolv, pursuant to the Agreement and Plan of Merger dated as of March 5, 2021, and amended by the First Amendment to Agreement and Plan of Merger (the “Merger Agreement”), dated as of June 5, 2021. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. and the officers of NHIC, the predecessor company resigned. The officers of Legacy Evolv became the officers of the Company, and the Company listed its shares of common stock, par value $0.0001 per share, on Nasdaq under the symbol “EVLV” (see Note 3).

- added (2021-11-15):
[0001558370-21-015999:note_history:24]
Subscription Agreement

- added (2021-11-15):
[0001558370-21-015999:note_history:25]
Prior to the completion of the Merger, the Company entered into subscription agreements (collectively, the “PIPE Investment”) with certain parties subscribing for shares of the Company’s common stock (the “Subscribers”) pursuant to which the Subscribers agreed to purchase. Pursuant to the PIPE Investment, the Company issued 30,000,000 shares of Class A common stock for a purchase price of $10.00 per share with gross proceeds of $300.0 million.

- added (2021-11-15):
[0001558370-21-015999:note_history:26]
Risks and uncertainties

- added (2021-11-15):
[0001558370-21-015999:note_history:27]
The Company is subject to risks and uncertainties common to early-stage companies in the human security industry including, but not limited to, the successful development, commercialization, marketing and sale of existing and new products, fluctuations in operating results and financial risks, protection of proprietary knowledge and patent risks, dependence on key personnel, competition, technological risks, cybersecurity risks, customer demand and management of growth. Potential risks and uncertainties also include, without limitation, uncertainties regarding the duration and magnitude of the impact of the COVID-19 pandemic, including variants, on the Company’s business and the economy in general.

- added (2021-11-15):
[0001558370-21-015999:note_history:28]
In March 2020, the World Health Organization declared the global novel coronavirus disease 2019 (“COVID-19”) outbreak a pandemic. The impact of this pandemic has been and will likely continue to be extensive in many aspects of society, which has resulted in and will likely continue to result in significant disruptions to the global economy, as well as businesses and capital markets around the world. The Company cannot at this time predict the ultimate extent, duration, or full impact that the COVID-19 pandemic will have on its future financial condition and operations. The impact of the COVID-19 pandemic  on the Company’s financial performance will depend on future developments, including the duration and spread of the pandemic, including variants, and related governmental advisories and restrictions, the progression and effectiveness of vaccination roll-outs, vaccine hesitancy, and the actions

- added (2021-11-15):
[0001558370-21-015999:note_history:29]
taken to contain or treat COVID-19, as well as the economic impact on local, regional, national and international customers and markets. The situation surrounding COVID-19 remains fluid and the potential for a material impact on the Company increases the longer the virus impacts the level of economic activity in the United States and globally. Given the ongoing evolution of the COVID-19 and the global responses to curb its spread, the Company is not able to estimate the effects of the COVID-19 on its results of operations, financial condition, or liquidity for the year ending December 31, 2021 and beyond. If the financial markets and/or the overall economy are impacted for an extended period, the Company’s results may be materially adversely affected.

- added (2021-11-15):
[0001558370-21-015999:note_history:30]
Future impacts to the Company’s business as a result of COVID-19 could include disruptions to the Company’s revenue caused by closures of customer operations, manufacturing operations and supply chain caused by facility closures, reductions in operating hours, staggered shifts and other social distancing efforts; labor shortages; decreased productivity and unavailability of materials or components; limitations on its employees’ and customers’ ability to travel, and delays in shipments to and from affected countries and within the United States. While the Company maintains an inventory of finished products and raw materials used in its products, a prolonged pandemic could lead to shortages in the raw materials necessary to manufacture its products.

- added (2021-11-15):
[0001558370-21-015999:note_history:31]
Basis of presentation

- added (2021-11-15):
[0001558370-21-015999:note_history:32]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly owned subsidiary in the United Kingdom, Evolv Technologies UK Ltd. and its wholly owned subsidiary Give Evolv LLC. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

- changed (2021-11-15):
[0001558370-21-015999:note_history:33]
Revision of Prior Period Financial Statements
  (was, 2021-08-16, similarity 0.6186):
[0001104659-21-106340:note_history:33]
Notes to Condensed Consolidated Financial Statements

- added (2021-11-15):
[0001558370-21-015999:note_history:34]
During the year ended December 31, 2020, an error was identified by the Company related to the preferred stock warrant classification in prior periods. Specifically, the Company had misclassified these warrants for the purchase of shares of its preferred stock as equity for the period from September 2016 through December 2018 when these warrants should have been liability classified and changes to fair value recorded in the Statement of Operations, therefore retained earnings were understated for changes in fair value of the warrant over that period of time of liability classification. Upon the modified retrospective adoption of ASU No. 2018-07 Compensation - Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting and ASU No. 2019-08 Codification Improvements-Share-Based Consideration Payable to a Customer, on January 1, 2019, the warrants were classified within temporary equity. The Company concluded that the impacts of the error were not material to the consolidated financial statements as of and for the years ended December 31, 2020 and 2019. While not material, the Company has elected to revise the previously issued consolidated financial statements as of and for the years ended December 31, 2020 and 2019 for the impacts of the error. In addition, the applicable notes to the accompanying financial statements have also been revised to correct for these misstatements.

- added (2021-11-15):
[0001558370-21-015999:note_history:35]
The following table (in thousands) reflects the impacts of the error on the consolidated financial statements and gives effect to the retrospective restatement to reflect the exchange ratio of 0.378 established in the Merger as described in Note 3.

- added (2021-11-15):
[0001558370-21-015999:note_history:36]
| ​ |  | As of December 31, 2020 |  | As of December 31, 2019 |
| ​ | ​ | As previously | ​ | ​ | ​ | ​ | ​ | ​ | ​ | As previously | ​ | ​ | ​ | ​ | ​ | ​ |
| ​ | ​ | reported |  | Adjustment |  | Revised |  | reported |  | Adjustment |  | Revised |
| Convertible preferred stock | ​ | $ | 75,393 | ​ | $ | 484 | ​ | $ | 75,877 | ​ | $ | 72,399 | ​ | $ | 484 | ​ | $ | 72,883 |
| Additional paid-in capital | ​ | $ | 9,946 | ​ | $ | (752) | ​ | $ | 9,194 | ​ | $ | 8,730 | ​ | $ | (752) | ​ | $ | 7,978 |
| Accumulated deficit | ​ | $ | (94,149) | ​ | $ | 268 | ​ | $ | (93,881) | ​ | $ | (66,757) | ​ | $ | 268 | ​ | $ | (66,489) |
| Stockholders’ deficit | ​ | $ | (84,202) | ​ | $ | (484) | ​ | $ | (84,686) | ​ | $ | (58,026) | ​ | $ | (484) | ​ | $ | (58,510) |

- added (2021-11-15):
[0001558370-21-015999:note_history:37]
Unaudited Interim Financial Information

- added (2021-11-15):
[0001558370-21-015999:note_history:38]
The accompanying unaudited consolidated financial statements as of September 30, 2021, and for the three and nine months ended September 30, 2021 and 2020 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2020 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2021 and the results of its operations for the three and nine months ended September 30, 2021 and 2020 and cash flows for the nine months ended September 30, 2021 and 2020. The results for the three and nine months ended September 30, 2021 are not necessarily indicative of results to be expected for the year ending December 31, 2021, any other interim periods, or any future year or period.

- added (2021-11-15):
[0001558370-21-015999:note_history:39]
Accordingly, these unaudited interim consolidated financial statements should be read in conjunction with the audited annual consolidated financial statements and notes thereto for the years ended December 31, 2020 and 2019 included in the Prospectus filed with the SEC on September 3, 2021 (the “Prospectus”).

- removed (2021-11-15):
[0001104659-21-106340:note_history:40]
(unaudited)

- removed (2021-11-15):
[0001104659-21-106340:note_history:41]
NOTE 1 – DESCRIPTION OF ORGANIZATION AND BUSINESS OPERATIONS

- removed (2021-11-15):
[0001104659-21-106340:note_history:42]
Organization and General:

- removed (2021-11-15):
[0001104659-21-106340:note_history:43]
NewHold Investment Corp. (the “Company”) was incorporated in Delaware on January 24, 2020 as NewHold Industrial Corp. and on February 14, 2020 changed its name to NewHold Investment Corp. The Company was formed for the purpose of effecting a merger, capital stock exchange, asset acquisition, stock purchase, reorganization or similar business combination with one or more businesses (a “Business Combination”). The Company is an “emerging growth company,” as defined in Section 2(a) of the Securities Act of 1933, as amended, or the “Securities Act,” as modified by the Jumpstart Our Business Startups Act of 2012 (the “JOBS Act”).  On July 16, 2021 in connection with the Company’s initial Business Combination (See Note 9), the Company changed its name to Evolv Technologies Holdings, Inc.

- removed (2021-11-15):
[0001104659-21-106340:note_history:44]
At June 30, 2021, the Company had not commenced any operations.  All activity for the period from January 24, 2020 (date of inception) to June 30, 2021 relates to the Company’s formation and the initial public offering (“Public Offering”) described below, and subsequent to the Public Offering, searching for a potential business combination. The Company will not generate any operating revenues until after completion of its initial Business Combination, at the earliest. The Company expects to generate non-operating income in the form of interest income on the proceeds derived from the Public Offering.

- removed (2021-11-15):
[0001104659-21-106340:note_history:45]
All dollar amounts are rounded to the nearest thousand dollars.

- removed (2021-11-15):
[0001104659-21-106340:note_history:46]
Sponsor and Financing:

- removed (2021-11-15):
[0001104659-21-106340:note_history:47]
The Company’s sponsor is NewHold Industrial Technology Holdings LLC, a Delaware limited liability company (the “Sponsor”).   The registration statement for the Public Offering (as described in Note 3) was declared effective by the United States Securities and Exchange Commission (the “SEC”) on July 30, 2020.  The Company intends to finance a Business Combination with proceeds from the $172,500,000 Public Offering (Note 3) and a $5,700,000 Private Placement (as defined in Note 4), net of expenses. Upon the closing of the Public Offering and the Private Placement, $172,500,000 was deposited in a trust account (the “Trust Account”).

- removed (2021-11-15):
[0001104659-21-106340:note_history:48]
The Trust Account:

- removed (2021-11-15):
[0001104659-21-106340:note_history:49]
The funds in the Trust Account can be invested only in U.S. government treasury bills with a maturity of one hundred and eighty five (185) days or less or in money market funds meeting certain conditions under Rule 2a-7 under the Investment Company Act of 1940 which invest only in direct U.S. government obligations. Funds will remain in the Trust Account until the earlier of (i) the consummation of its initial Business Combination or (ii) the distribution of the Trust Account as described below. The remaining funds outside the Trust Account may be used to pay for business, legal and accounting due diligence on prospective acquisition targets and continuing general and administrative expenses.

- removed (2021-11-15):
[0001104659-21-106340:note_history:50]
The Company’s amended and restated certificate of incorporation provides that, other than the withdrawal of interest to pay tax obligations and up to $250,000 per year for working capital purposes, if any, (less up to $100,000 of interest to pay dissolution expenses), none of the funds held in the Trust Account will be released until the earliest of: (a) the completion of the initial Business Combination, (b) the redemption of any public shares properly submitted in connection with a stockholder vote to amend the Company’s amended and restated certificate of incorporation (i) to modify the substance or timing of the ability of holders of the public shares to seek redemption in connection with our initial business combination or the Company’s obligation to redeem 100% of the public shares if the Company does not complete the initial Business Combination within 24 months from the closing of the Public Offering, August 4, 2022, or (ii) with respect to any other provision relating to stockholders’ rights or pre-Business Combination activity, and (c) the redemption of the public shares if the Company is unable to complete the initial Business Combination within 24 months from the closing of the Public Offering, subject to applicable law. The proceeds deposited in the Trust Account could become subject to the claims of creditors, if any, which could have priority over the claims of the Company’s public stockholders.

- removed (2021-11-15):
[0001104659-21-106340:note_history:51]
Business Combination:

- removed (2021-11-15):
[0001104659-21-106340:note_history:52]
The Company’s management has broad discretion with respect to the specific application of the net proceeds of the Public Offering, although substantially all of the net proceeds of the Public Offering are intended to be generally applied toward consummating a Business Combination with a Target Business. As used herein, “Target Business” is one or more target businesses that together have a fair market value equal to at least 80% of the balance in the Trust Account (less deferred underwriting commissions and any taxes payable on interest earned) at the time of signing a definitive agreement in connection with the Company’s initial Business Combination.  See Note 9.

- removed (2021-11-15):
[0001104659-21-106340:note_history:53]
The Company, after signing a definitive agreement for a Business Combination, will either (i) seek stockholder approval of the Business Combination at a meeting called for such purpose in connection with which stockholders may seek to redeem their shares, regardless of whether they vote for or against the Business Combination, for cash equal to their pro rata share of the aggregate amount then on deposit in the Trust Account as of two business days prior to the consummation of the initial Business Combination, including interest but less taxes payable and amounts released for working capital, or (ii) provide stockholders with the opportunity to have their shares redeemed by the Company by means of a tender offer (and thereby avoid the need for a stockholder vote) for an amount in cash equal to their pro rata share of the aggregate amount then on deposit in the Trust Account as of two business days prior to the consummation of the initial Business Combination, including interest but less taxes payable and amounts released to the Company for working capital. The decision as to whether the Company will seek stockholder approval of the Business Combination or will allow stockholders to sell their shares in a tender offer will be made by the Company, solely in its discretion, and will be based on a variety of factors such as the timing of the transaction and whether the terms of the transaction would otherwise require the Company to seek stockholder approval unless a vote is required by the rules of the Nasdaq Capital Market. If the Company seeks stockholder approval, it will complete its Business Combination only if a majority of the outstanding shares of Class A and Class B common stock voted are voted in favor of the Business Combination. However, in no event will the Company redeem its public shares in an amount that would cause its net tangible assets to be less than $5,000,001 upon consummation of a Business Combination. In such case, the Company would not proceed with the redemption of its public shares and the related Business Combination, and instead may search for an alternate Business Combination.

- removed (2021-11-15):
[0001104659-21-106340:note_history:54]
If the Company holds a stockholder vote or there is a tender offer for shares in connection with a Business Combination, a public stockholder will have the right to redeem its shares for an amount in cash equal to its pro rata share of the aggregate amount then on deposit in the Trust Account as of two business days prior to the consummation of the initial Business Combination, including interest but less taxes payable and amounts released to the Company for working capital. As a result, such shares of Class A common stock will be recorded at redemption amount and classified as temporary equity upon the completion of the Public Offering, in accordance with Financial Accounting Standards Board (“FASB”) ASC 480, “Distinguishing Liabilities from Equity.”  In August 2020, the Company deposited an aggregate of $172,500,000 from the proceeds of the Public Offering, including the underwriters’ exercise of their overallotment option and the sale of $5,700,000 for the Private Placement Warrants, net of expenses.

- removed (2021-11-15):
[0001104659-21-106340:note_history:55]
The Company will have 24 months (until August 4, 2022) from the closing date of the Public Offering to complete its initial Business Combination. If the Company does not complete a Business Combination within this period of time, it shall (i) cease all operations except for the purposes of winding up; (ii) as promptly as reasonably possible, but not more than ten business days thereafter subject to lawfully available funds therefor, redeem 100% of the public shares of Class A common stock for a per share pro rata portion of the Trust Account, including interest, but less taxes payable and amounts released for working capital (less up to $100,000 of such net interest to pay dissolution expenses) and (iii) as promptly as possible following such redemption, dissolve and liquidate the balance of the Company’s net assets to its creditors and remaining stockholders, as part of its plan of dissolution and liquidation. The initial stockholders have entered into letter agreements with us, pursuant to which they have waived their rights to participate in any redemption with respect to their initial shares; however, if the initial stockholders or any of the Company’s officers, directors or affiliates acquire shares of Class A common stock in or after the Public Offering, they will be entitled to a pro rata share of the Trust Account upon the Company’s redemption or liquidation in the event the Company does not complete a Business Combination within 24 months from the closing of the Public Offering.

- removed (2021-11-15):
[0001104659-21-106340:note_history:56]
In the event of such distribution, it is possible that the per share value of the residual assets remaining available for distribution (including Trust Account assets) will be less than the price per Unit in the Public Offering.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-15):
[0001558370-21-015999:note_history:57]
2. Summary of Significant Accounting Policies
  (was, 2021-08-16, similarity 0.9263):
[0001104659-21-106340:note_history:57]
NOTE 2 – SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

- changed (2021-11-15):
[0001558370-21-015999:note_history:58]
Use of Estimates
  (was, 2021-08-16, similarity 0.9697):
[0001104659-21-106340:note_history:58]
Use of Estimates:

- added (2021-11-15):
[0001558370-21-015999:note_history:59]
The preparation of the Company’s consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the reporting periods. Significant estimates and assumptions reflected in these consolidated financial statements include but are not limited to calculating the standalone selling price for revenue recognition, the valuation of inventory, the valuation of derivative liability, the valuation of common stock for the periods prior to the Company listing its shares on Nasdaq, stock-based awards, the valuation of the preferred stock warrant liability, the valuation of the contingent earn-out liability and the valuation of the contingently issuable common stock. The Company bases its estimates on historical experience, known trends and other market-specific or other relevant factors that it believes to be reasonable under the circumstances. On an ongoing basis, management evaluates its estimates when there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results could differ from those estimates.

- added (2021-11-15):
[0001558370-21-015999:note_history:60]
Due to the COVID-19 pandemic, there has been uncertainty and disruption in the global economy and financial markets. The full extent to which the COVID-19 pandemic will directly or indirectly impact the Company’s business, results of operations and financial condition, including revenues and expenses, will depend on future developments that are highly uncertain, including as a result of new information that may emerge concerning COVID-19 and the actions taken to contain it or treat COVID-19. Management has made estimates of the impact of COVID-19 within the Company’s consolidated financial statements and there may be changes to those estimates in future periods. These

- added (2021-11-15):
[0001558370-21-015999:note_history:61]
estimates may change, as new events occur, and additional information is obtained. On an ongoing basis, management evaluates its estimates as there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results may differ from those estimates or assumptions.

- added (2021-11-15):
[0001558370-21-015999:note_history:62]
Risk of Concentrations of Credit, Significant Customers and Significant Suppliers

- added (2021-11-15):
[0001558370-21-015999:note_history:63]
Financial instruments that potentially expose the Company to concentrations of credit risk consist primarily of cash and cash equivalents, restricted cash, and accounts receivable, net. Periodically, the Company maintains deposits in accredited financial institutions in excess of federally insured limits. The Company maintains its cash, cash equivalents and restricted cash with financial institutions that management believes to be of high credit quality. The Company has not experienced any losses on such accounts and does not believe it is exposed to any unusual credit risk beyond the normal credit risk associated with commercial banking relationships.

- added (2021-11-15):
[0001558370-21-015999:note_history:64]
Significant customers are those which represent more than 10% of the Company’s total revenue or accounts receivable, net balance at each respective balance sheet date. The following table presents customers that represent 10% or more of the Company’s total revenue:

- added (2021-11-15):
[0001558370-21-015999:note_history:65]
| ​ |  | Three Months Ended |  | ​ | Nine Months Ended |  | ​ |
| ​ | ​ | September 30, | ​ | ​ | September 30, | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 |  | ​ | 2021 | ​ | 2020 |  | ​ |
| Customer A |  | — | ​ | 20.0 | % | ​ | — | ​ | 11.0 | % | ​ |
| Customer B |  | 21.2 | % | — | ​ | ​ | 10.0 | % | — | ​ | ​ |
| ​ |  | 21.2 | % | 20.0 | % | ​ | 10.0 | % | 11.0 | % | ​ |

- added (2021-11-15):
[0001558370-21-015999:note_history:66]
Customer A revenue is from subscriptions and Customer B revenue is from product revenue.

- added (2021-11-15):
[0001558370-21-015999:note_history:67]
The following table presents customers that represent 10% or more of the Company’s accounts receivable, net:

- added (2021-11-15):
[0001558370-21-015999:note_history:68]
| ​ |  | September 30, | ​ | December 31, |  | ​ |
| ​ | ​ | 2021 | ​ | 2020 |  | ​ |
| Customer B |  | 16.0 | % | — | ​ | ​ |
| Customer C |  | — | ​ | 28.3 | % | ​ |
| Customer D |  | — | ​ | 23.4 | % | ​ |
| ​ |  | 16.0 | % | 51.7 | % | ​ |

- added (2021-11-15):
[0001558370-21-015999:note_history:69]
The Company relies on third parties for the supply and manufacture of its products as well as third-party logistics providers. In instances where these parties fail to perform their obligations, the Company may be unable to find alternative suppliers to satisfactorily deliver its products to its customers on time, if at all, which could have a material adverse effect on the Company’s operating results, financial condition and cash flows and damage its customer relationships.

- added (2021-11-15):
[0001558370-21-015999:note_history:70]
Debt Issuance Costs

- added (2021-11-15):
[0001558370-21-015999:note_history:71]
The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated debt on the consolidated balance sheet and amortized as interest expense on the consolidated statement of operations and comprehensive loss using the effective interest method. As of September 30, 2021, and December 31, 2020, debt issuance costs totaled $0.1 million and $0.1 million, respectively, and were recorded as a reduction in the carrying amount of long-term debt in the consolidated balance sheets. During the three months ended September 30, 2021 and 2020, and nine months ended September 30, 2021 and 2020, the Company recorded less than $0.1 million in

- added (2021-11-15):
[0001558370-21-015999:note_history:72]
amortization of the debt issuance costs recorded within interest expense in the consolidated statement of operations and comprehensive income (loss).

- changed (2021-11-15):
[0001558370-21-015999:note_history:73]
Cash, Cash Equivalents, and Restricted Cash
  (was, 2021-08-16, similarity 0.6087):
[0001104659-21-106340:note_history:73]
Cash and Cash Equivalents:

- added (2021-11-15):
[0001558370-21-015999:note_history:74]
Cash, cash equivalents, and restricted cash as reported on the consolidated statement of cash flows consists of the following (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:75]
| ​ |  | September 30, | ​ | December 31, |
| ​ | ​ | 2021 | ​ | 2020 |
| Cash and cash equivalents |  | $ | 333,747 | ​ | $ | 4,704 |
| Restricted cash |  | ​ | 675 | ​ | ​ | — |
| Total cash, cash equivalents, and restricted cash |  | $ | 334,422 | ​ | $ | 4,704 |

- added (2021-11-15):
[0001558370-21-015999:note_history:76]
The Company considers all short-term, highly liquid investments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents. Restricted cash consists of a security deposit on the Company’s new office lease in Waltham, Massachusetts, with $0.4 million included in the current portion of restricted cash which will be returned during the first half of 2022, and $0.3 million included in restricted cash, noncurrent in the consolidated balance sheets.

- added (2021-11-15):
[0001558370-21-015999:note_history:77]
Property and Equipment

- added (2021-11-15):
[0001558370-21-015999:note_history:78]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization expense is recognized using the straight-line method over the estimated useful life of each asset, as follows:

- added (2021-11-15):
[0001558370-21-015999:note_history:79]
| ​ |  | Estimated Useful Life |
| Computers and telecommunications equipment |  | 3 years |
| Lab equipment |  | 5 years |
| Software |  | 4 years |
| Furniture and fixtures |  | 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |
| Leased equipment |  | 4-7 years |

- added (2021-11-15):
[0001558370-21-015999:note_history:80]
Estimated useful lives are periodically assessed to determine if changes are appropriate. Leasehold improvements are amortized using the straight-line method over the lesser of the lease term or its estimated economic useful life. Lease terms are used based upon the initial lease agreement and do not consider potential renewals or extensions until such time that the renewals or extensions are contracted. Maintenance and repairs are charged to expense as incurred. When assets are retired or otherwise disposed of, the cost of these assets and related accumulated depreciation or amortization are eliminated from the consolidated balance sheet and any resulting gains or losses are included in the consolidated statement of operations and comprehensive income (loss) in the period of disposal. Costs for capital assets not yet placed into service are capitalized as construction-in-progress and depreciated once placed into service.

- added (2021-11-15):
[0001558370-21-015999:note_history:81]
The Company’s leases for leased equipment generally are 48 months. The Company’s subscription contracts are classified as operating leases because title does not transfer and they do not meet any of the other criteria per ASC 840. To date, the Company has not had any subscription arrangements come up for renewal and will reassess the classification of any such leases upon renewal.

- added (2021-11-15):
[0001558370-21-015999:note_history:82]
The Company evaluates leased equipment for obsolescence and impairment whenever circumstances indicate that the carrying value of such equipment is not recoverable by considering any (1) reduced demand in the markets in

- added (2021-11-15):
[0001558370-21-015999:note_history:83]
which the Company operate, (2) technological obsolescence due to developments of new products and improvements, or (3) changes in economic or other events and conditions that impact the market price for the Company’s products. Based on the Company’s evaluations, an impairment loss on property and equipment of $1.7 million was recorded during the three and nine months ended September 30, 2021. This was related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of these assets and resulted in impairment.

- added (2021-11-15):
[0001558370-21-015999:note_history:84]
Contingent Earn-out

- added (2021-11-15):
[0001558370-21-015999:note_history:85]
In connection with the Merger and pursuant to the Merger Agreement, certain of the Legacy Evolv’s shareholders and Legacy Evolv service providers are entitled to receive additional shares of the Company’s Class A common stock (the “Earn-Out Shares”) upon the Company achieving certain milestones:

- added (2021-11-15):
[0001558370-21-015999:note_history:86]
|  | ● | Triggering Event I – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s Class A common stock is greater than $12.50 per share for any 20 trading days within any 30 trading day period. |

- added (2021-11-15):
[0001558370-21-015999:note_history:87]
|  | ● | Triggering Event II – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s Class A common stock is greater than $15.00 per share for any 20 trading days within any 30 trading day period. |

- added (2021-11-15):
[0001558370-21-015999:note_history:88]
|  | ● | Triggering Event III – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s Class A common stock is greater than $17.50 per share for any 20 trading days within any 30 trading day period. |

- added (2021-11-15):
[0001558370-21-015999:note_history:89]
In accordance with ASC 815 – Derivatives and Hedging, the earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a change in fair value of contingent earn-out liability in other income (expense), net in the consolidated statements of operations and comprehensive income (loss). When the Triggering Events have been achieved and the Earn-Out Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share. Of the total 15,000,000 earn-out shares, 12,137,397 earn-out shares are with the Legacy Evolv shareholders.

- added (2021-11-15):
[0001558370-21-015999:note_history:90]
The estimated fair value of the contingent earn-out shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, drift rate, percentage of change in control and expected term.

- added (2021-11-15):
[0001558370-21-015999:note_history:91]
The contingent earn-out liability is categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingent earn-out payments involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

- added (2021-11-15):
[0001558370-21-015999:note_history:92]
The Earn-Out Shares issued to employees, officers, directors, and non-employees are based achievement of certain target share price contingencies and for the employees and officers, subject to continued employment, (the “Earn-Out Service Providers”) represents share-based compensation and is classified as equity on the Company’s balance

- added (2021-11-15):
[0001558370-21-015999:note_history:93]
sheet. Corresponding stock-based compensation expense is recorded in the consolidated statements of operations and comprehensive income (loss) in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. Of the total 15,000,000 earn-out shares, 2,862,603 earn-out shares are with the Legacy Evolv service providers and subject to share-based compensation.

- changed (2021-11-15):
[0001558370-21-015999:note_history:94]
Contingently Issuable Common Stock
  (was, 2021-08-16, similarity 0.6207):
[0001104659-21-106340:note_history:94]
Redeemable Common Stock:

- added (2021-11-15):
[0001558370-21-015999:note_history:95]
Prior to the Merger, NewHold Industrial Technology Holdings, LLC, the sponsor of the NHIC special purpose acquisition company owned 4,312,500 shares of NHIC Class B common stock (the “Founder Shares). Upon the closing of the merger, NHIC Class A and Class B common stock became the Company’s common stock. The Founder Shares outstanding were subject to certain share-performance-based vesting provisions as follows:

- added (2021-11-15):
[0001558370-21-015999:note_history:96]
|  | ● | Vesting Provision I - 1,897,500 shares of the Company’s common stock shall vest and no longer be subject to forfeiture as of the Merger; |

- added (2021-11-15):
[0001558370-21-015999:note_history:97]
|  | ● | Vesting Provision II - if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $12.50 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30 trading day period, then 948,750 shares of the Company’s common stock shall vest and no longer be subject to forfeiture; |

- added (2021-11-15):
[0001558370-21-015999:note_history:98]
|  | ● | Vesting Provision III - if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $15.00 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30-trading day period, then 948,750 shares of the Company’s common stock) shall vest and no longer be subject to forfeiture; |

- added (2021-11-15):
[0001558370-21-015999:note_history:99]
The remaining 517,500 Founder Shares were contributed to Give Evolv LLC.

- added (2021-11-15):
[0001558370-21-015999:note_history:100]
If Vesting Provision II and/or Vesting Provision III are not satisfied, the corresponding number of shares specified shall be forfeited and no longer issued and outstanding. If there is a Change of Control event prior to Vesting Provision II and/or Vesting Provision III are satisfied, the Founder shares are no longer subject to forfeiture and shall vest immediately upon the occurrence of a Change of Control event.

- added (2021-11-15):
[0001558370-21-015999:note_history:101]
In accordance with ASC 815 – Derivatives and Hedging, the contingently issuable common stock is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as change in fair value of contingently issuable common stock liability in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Vesting Provisions have been achieved and the contingently issuable common shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

- added (2021-11-15):
[0001558370-21-015999:note_history:102]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, and risk-free rate.

- added (2021-11-15):
[0001558370-21-015999:note_history:103]
The contingently issuable common shares are categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various

- added (2021-11-15):
[0001558370-21-015999:note_history:104]
potential pay-out scenarios. Contingently issuable shares involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

- added (2021-11-15):
[0001558370-21-015999:note_history:105]
Impairment of Long-Lived Assets

- added (2021-11-15):
[0001558370-21-015999:note_history:106]
Long-lived assets consist of property and equipment. Long-lived assets to be held and used are tested for recoverability whenever events or changes in business circumstances indicate that the carrying amount of the assets may not be fully recoverable. Factors that the Company considers in deciding when to perform an impairment review include significant underperformance of the business in relation to expectations, significant negative industry or economic trends and significant changes or planned changes in the use of the assets. If an impairment review is performed to evaluate a long-lived asset group for recoverability, the Company compares forecasts of undiscounted cash flows expected to result from the use and eventual disposition of the long-lived asset group to its carrying value. An impairment loss would be recognized in loss from operations when estimated undiscounted future cash flows expected to result from the use of an asset group are less than its carrying amount. The impairment loss is based on the excess of the carrying value of the impaired asset group over its fair value, determined based on discounted cash flows. The Company recorded a $1.7 million impairment loss on long-lived assets during the three and nine months ended September 30, 2021. This was related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of these assets and resulted in impairment. The Company did not record any impairment losses on long-lived assets during the three and nine months ended September 30, 2020.

- changed (2021-11-15):
[0001558370-21-015999:note_history:107]
Fair Value Measurements of Financial Instruments
  (was, 2021-08-16, similarity 0.6):
[0001104659-21-106340:note_history:107]
Financial Instruments:

- added (2021-11-15):
[0001558370-21-015999:note_history:108]
Certain assets and liabilities of the Company are carried at fair value under GAAP. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. Valuation techniques used to measure fair value must maximize the use of observable inputs and minimize the use of unobservable inputs. Financial assets and liabilities carried at fair value are to be classified and disclosed in one of the following three levels of the fair value hierarchy, of which the first two are considered observable and the last is considered unobservable:

- added (2021-11-15):
[0001558370-21-015999:note_history:109]
|  | ● | Level 1 — Quoted prices in active markets for identical assets or liabilities. |

- added (2021-11-15):
[0001558370-21-015999:note_history:110]
|  | ● | Level 2 — Observable inputs (other than Level 1 quoted prices), such as quoted prices in active markets for similar assets or liabilities, quoted prices in markets that are not active for identical or similar assets or liabilities, or other inputs that are observable or can be corroborated by observable market data. |

- added (2021-11-15):
[0001558370-21-015999:note_history:111]
|  | ● | Level 3 — Unobservable inputs that are supported by little or no market activity that are significant to determining the fair value of the assets or liabilities, including pricing models, discounted cash flow methodologies and similar techniques. |

- added (2021-11-15):
[0001558370-21-015999:note_history:112]
The Company’s cash equivalents, derivative liability, contingent earn-out liability, contingently issuable common stock liability and its common stock warrant liability are carried at fair value, determined according to the fair value hierarchy described above (see Note 4). The carrying values of the Company’s accounts receivable, net, accounts payable and accrued expenses approximate their fair values due to the short-term nature of these assets and liabilities. The carrying value of the Company’s long-term debt approximates its fair value (a Level 2 measurement) at each balance sheet date due to its variable interest rate, which approximates a market interest rate.

- added (2021-11-15):
[0001558370-21-015999:note_history:113]
Assets that are measured at fair value on a nonrecurring basis primarily relate to property and equipment. We do not periodically adjust carrying value to fair value for property and equipment. Rather, the carrying value of the asset is reduced to its fair value when we determine that impairment has occurred. During the three and nine months ended September 30, 2021, impairment of property and equipment was $1.7 million, respectively. This was related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of these assets and resulted in impairment. There was no impairment for the three and nine months ended September 30, 2020.

- added (2021-11-15):
[0001558370-21-015999:note_history:114]
Derivative Liability Related to Convertible Notes

- added (2021-11-15):
[0001558370-21-015999:note_history:115]
In August through September 2019 and in September through December 2020, the Company issued Convertible Notes to several investors (see Note 9) that provided a conversion option whereby upon the closing of a specified financing event the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 85% and 80%, respectively, of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative that was required to be bifurcated and accounted for separately from the notes. The derivative liability was initially recorded at fair value upon issuance of the notes and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the derivative liability are recognized in the consolidated statements of operations and comprehensive income (loss). In October 2019, the specified financing event was consummated, as such the Convertible Notes issued August through September 2019 were converted into shares of Series B-1 Preferred Stock (see Note 10), and the derivative liability was extinguished. The derivative liability related to the 2020 convertible note is outstanding as of December 31, 2020 and is included as a derivative liability in the consolidated balance sheets.

- added (2021-11-15):
[0001558370-21-015999:note_history:116]
Between January 21, 2021 and February 4, 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes,” and together with the 2020 Convertible Notes, the “Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability and current portion of long-term debt on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method.

- added (2021-11-15):
[0001558370-21-015999:note_history:117]
On June 21, 2021, the Company and the holders of the 2021 Convertible Notes agreed that, in connection with the Merger, such holders would receive an additional 1,000,000 shares of NHIC common stock as further consideration for the automatic conversion of such notes upon closing of the Merger. This modification of the 2021 Convertible Notes resulted in an extinguishment, and recognition of a derivative liability, which represents both the value of the 1,000,000 NHIC shares as of June 21, 2021 as well as a bifurcated embedded derivative for conversion into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors.

- added (2021-11-15):
[0001558370-21-015999:note_history:118]
Upon the closing of the Merger, the September through December 2020 Convertible Notes and the 2021 Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on

- added (2021-11-15):
[0001558370-21-015999:note_history:119]
extinguishment of debt of $0.9 million recorded in other income (expense) in the consolidated statements of operations and comprehensive income (loss).

- added (2021-11-15):
[0001558370-21-015999:note_history:120]
Classification of Convertible Preferred Stock

- added (2021-11-15):
[0001558370-21-015999:note_history:121]
Prior to the closing of the Merger, the holders of Legacy Evolv Series A, Series A-1, Series B and Series B-1 convertible preferred stock had certain liquidation rights in the event of a deemed liquidation event that, in certain situations, is not solely within the control of the Company and would call for the redemption of the then outstanding Series A, Series A-1, Series B and Series B-1 convertible preferred stock (see Note 10). Therefore, the Legacy Evolv Series A, Series A-1, Series B and Series B-1 convertible preferred stock were classified outside of stockholders’ equity (deficit) on the consolidated balance sheets.

- added (2021-11-15):
[0001558370-21-015999:note_history:122]
In connection with the closing of the Merger, all shares of redeemable convertible Preferred Stock were converted into shares of the Company’s common stock. Accordingly, there was no redeemable convertible preferred stock outstanding as of September 30, 2021. As of December 31, 2020, the carrying value of the redeemable convertible Preferred Stock was $75.9 million (see Note 10).

- added (2021-11-15):
[0001558370-21-015999:note_history:123]
Common Stock Warrant Liability and Public Warrant Liability

- added (2021-11-15):
[0001558370-21-015999:note_history:124]
The Company classifies certain warrants for the purchase of shares of its common stock (see Note 11) as a liability on its consolidated balance sheets as these warrants are freestanding financial instruments that may require the Company to adjust the exercise price and number of shares that is not consistent with a fixed-for-fixed option pricing model. The warrant liability is initially recorded at fair value on the issuance date of each warrant and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the common stock warrant liability are recognized as a component of other income (expense), net in the consolidated statements of operations and comprehensive income (loss). Changes in the fair value of the common stock warrant liability are recognized until the warrants are exercised, expire or qualify for equity classification.

- added (2021-11-15):
[0001558370-21-015999:note_history:125]
In connection with the closing of the Merger, the Company assumed warrants to purchase shares of common stock (the “Public Warrant”) and are classified as a liability pursuant to ASC 815 – Derivatives and Hedging as the equity derivative scope exception was not met. As of September 30, 2021, the Public Warrant is outstanding (see Note 11). All other warrants that were issued prior to the closing of the Merger were converted into shares of the Company’s common stock (the “common stock warrant”) upon the closing of the Merger. Accordingly, the Company remeasured the warrants to fair value upon the closing of Merger with the offset to additional paid-in capital (see Note 11).

- added (2021-11-15):
[0001558370-21-015999:note_history:126]
Equity Classified Preferred Stock Warrants

- added (2021-11-15):
[0001558370-21-015999:note_history:127]
The Company classifies warrants for the purchase of shares of its preferred stock (see Note 11) as temporary equity on its consolidated balance sheets. In connection with a customer development agreement, the Company issued preferred stock warrants to a customer to purchase shares of its Legacy Evolv Series A-1 Preferred Stock. Upon adoption of ASU No. 2018-07 and ASU No. 2019-08 on January 1, 2019, any liability classified warrants issued to non-employees for goods or services were reclassified to temporary equity.

- added (2021-11-15):
[0001558370-21-015999:note_history:128]
In connection with the closing of the Merger, all preferred stock warrants to purchase shares of common stock were converted into shares of the Company’s common stock. Accordingly, there were no preferred stock warrants outstanding as of September 30, 2021. The Company assessed the features of these warrants and determined that they qualify for classification as permanent equity.

- added (2021-11-15):
[0001558370-21-015999:note_history:129]
Equity Classified Common Stock Warrants

- added (2021-11-15):
[0001558370-21-015999:note_history:130]
The Company classifies certain warrants for the purchase of shares of its common stock (see Note 11) as equity on its consolidated balance sheets as these warrants are considered to meet the derivative scope exception for freestanding equity contracts. For these warrants that are classified on the Company’s consolidated balance sheets as equity instruments, the Company uses the Black-Scholes model to measure the value of the warrants at issuance.

- added (2021-11-15):
[0001558370-21-015999:note_history:131]
In connection with the closing of the Merger, all outstanding Legacy Evolv vested warrants to purchase shares of common stock were converted into shares of the Company’s common stock.

- added (2021-11-15):
[0001558370-21-015999:note_history:132]
Revenue Recognition

- added (2021-11-15):
[0001558370-21-015999:note_history:133]
The Company recognizes revenue in accordance with ASC 606. Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

- added (2021-11-15):
[0001558370-21-015999:note_history:134]
The Company derives revenue from (1) subscription arrangements accounted for as operating leases under ASC 840 and (2) from the sale of products, inclusive of maintenance and services. The Company’s arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

- added (2021-11-15):
[0001558370-21-015999:note_history:135]
Product Revenue

- added (2021-11-15):
[0001558370-21-015999:note_history:136]
The Company derives revenue from the sale of its Express and Edge equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer. Transfer of control occurs when the Company has transferred title and risk of loss and has a present right to payment for the equipment, which is generally upon delivery as the Company’s normal terms of sale are freight on board destination. Products are predominately sold with distinct services, which are described in the services section below.

- added (2021-11-15):
[0001558370-21-015999:note_history:137]
Subscription Revenue

- added (2021-11-15):
[0001558370-21-015999:note_history:138]
In addition to selling its products directly to customers, the Company also leases Express and Edge equipment. These arrangements convey the right to use the equipment for a period of time in exchange for consideration and therefore are accounted for under ASC 840 due to the scope exception of ASC 606-10-15-2. Lease terms are typically four years and customers pay quarterly or annual fixed payments for the lease and maintenance elements over the contractual lease term. In accordance with ASC 840, Leases, the Company considers only the fixed payments for purposes of allocating between the lease and non-lease deliverables on a relative fair value basis. Equipment leases are generally classified as operating leases as they do not meet any of the capital lease criteria per ASC 840.

- added (2021-11-15):
[0001558370-21-015999:note_history:139]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (i) distinct services, such as installation, training and maintenance, and (ii) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern and because revenue allocated to maintenance components is not material, the equipment lease and maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations.

- added (2021-11-15):
[0001558370-21-015999:note_history:140]
As leases with customers are classified as operating leases, lease revenue is recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

- added (2021-11-15):
[0001558370-21-015999:note_history:141]
Services Revenue

- added (2021-11-15):
[0001558370-21-015999:note_history:142]
The Company provides installation, training and maintenance services for its products. Revenue for installation and training is recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes, and when-and-if-available threat updates. Maintenance revenue is recognized ratably over the period of the arrangement. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are recognized ratably over the associated service period.

- added (2021-11-15):
[0001558370-21-015999:note_history:143]
Revenue from Distributors

- added (2021-11-15):
[0001558370-21-015999:note_history:144]
A portion of the Company’s revenue is also generated by sales in conjunction with its distributors. When the Company transacts with a distributor, its contractual arrangement is with the distributor and not with the end-use customer. In these transactions, the distributor is considered the customer; the Company has discretion over the pricing to the distributor and maintains overall control of the inventory and sales process to the distributor. Revenue is recognized upon delivery to the distributors. Right of return does not generally exist. Whether the Company transacts with a distributor and receives the order from a distributor or directly from an end-use customer, its revenue recognition policy and resulting pattern of revenue recognition is the same upon delivery.

- added (2021-11-15):
[0001558370-21-015999:note_history:145]
Transaction Price

- added (2021-11-15):
[0001558370-21-015999:note_history:146]
The transaction price is the amount of consideration that the Company expects to be entitled for providing goods and services under a contract. It includes not only fixed consideration, such as the stated amount in a contract, but also several other types of variable consideration or adjustments (generally discounts or incentives which are included as a part of the standalone selling price (“SSP”) estimation process). The Company provides discounts to customers which reduces the transaction price. From time-to-time, the Company may offer customers the option to purchase additional goods and services at a fixed price. In these limited circumstances, the Company assesses whether these offers constitute a material right, and if so, the Company would account for the material right as a separate performance obligation. Other types of variable consideration are not considered significant. The Company does not normally provide for rights of returns to customers on product sales and, therefore, does not record a provision for returns.

- added (2021-11-15):
[0001558370-21-015999:note_history:147]
Performance Obligations

- added (2021-11-15):
[0001558370-21-015999:note_history:148]
A performance obligation is a promise in a contract to transfer a distinct product or service to a customer that is both capable of being distinct, whereby the customer can benefit from the product or service either on its own or together with other resources that are readily available, and is distinct in the context of the contract, whereby the transfer of the product or service is separately identifiable from other promises in the contract.

- added (2021-11-15):
[0001558370-21-015999:note_history:149]
For both Express and Edge units, equipment is sold or leased with embedded software, which is considered a single performance obligation. Maintenance, which includes future updates, security threat updates, and minor bug fixes on a when-and-if available basis, is considered a single performance obligation. As a part of reported subscription sales, certain non-lease components, such as maintenance, are included within the subscription revenue amount. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are accounted for as separate performance obligations. Installation and training are considered separate performance obligations and are included within services revenue. Any add-on accessories are also considered separate performance obligations.

- added (2021-11-15):
[0001558370-21-015999:note_history:150]
Payment terms

- added (2021-11-15):
[0001558370-21-015999:note_history:151]
Payment terms for customer orders are typically 30 days after the shipment or delivery of the product. For certain products, services and customer types, the Company requires payment before the products or services are delivered to, or performed for, the customer. Generally, the Company’s contracts do not contain a significant financing component.

- added (2021-11-15):
[0001558370-21-015999:note_history:152]
Multiple Performance Obligations within an Arrangement

- added (2021-11-15):
[0001558370-21-015999:note_history:153]
The Company’s contracts may include multiple performance obligations when customers purchase a combination of products and services. When the Company’s customer arrangements have multiple performance obligations that contain a lease for Express or Edge equipment for the customer’s use at its site as well as distinct services that are delivered simultaneously, the Company allocates the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, the Company allocates the contract’s transaction price to each performance obligation on a relative SSP basis. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company estimates the SSP taking into account available information such as market conditions and internally approved pricing guidelines related to the performance obligation.

- added (2021-11-15):
[0001558370-21-015999:note_history:154]
Remaining Performance Obligations

- added (2021-11-15):
[0001558370-21-015999:note_history:155]
ASC 606 requires that the Company disclose the aggregate amount of transaction price that is allocated to performance obligations that have not yet been satisfied as of September 30, 2021. The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2021. Note that with respect to ASC 840, Subscription revenue includes maintenance in addition to the operating lease components of these transactions (in thousands).

- added (2021-11-15):
[0001558370-21-015999:note_history:156]
| ​ |  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue |  | $ | 111 |  | $ | 36 |  | $ | 147 |
| Subscription revenue |  | ​ | 9,304 |  | ​ | 21,802 |  | ​ | 31,106 |
| Service revenue |  | ​ | 24 |  | ​ | — |  | ​ | 24 |
| Maintenance revenue |  | ​ | 903 |  | ​ | 1,972 |  | ​ | 2,875 |
| Total revenue | ​ | $ | 10,342 | ​ | $ | 23,810 | ​ | $ | 34,152 |

- added (2021-11-15):
[0001558370-21-015999:note_history:157]
The amount of minimum future leases is based on expected income recognition. As of September 30, 2021, future minimum payments on noncancelable leases are as follows (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:158]
| Future operating lease component (in thousands): |  | ​ |  |
| Quarter Ending September 30, 2021: | ​ | ​ | ​ |
| 2021 | ​ | $ | 2,355 |
| 2022 | ​ |  | 9,262 |
| 2023 | ​ |  | 8,800 |
| 2024 | ​ |  | 7,054 |
| 2025 | ​ |  | 3,166 |
| Thereafter | ​ |  | 469 |
| ​ | ​ | $ | 31,106 |

- added (2021-11-15):
[0001558370-21-015999:note_history:159]
Contract Balances from Contracts with Customers

- added (2021-11-15):
[0001558370-21-015999:note_history:160]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2021 and December 31, 2020, the Company had $0.9 million and $0 of contract assets included within prepaid expenses and other current assets and $2.6 million and $0 in long-term contract assets on the consolidated balance sheets, respectively.

- added (2021-11-15):
[0001558370-21-015999:note_history:161]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as noncurrent deferred revenue. The Company recognized $0.5 million and $2.3 million during the three months and nine months ended September 30, 2021 of revenue that was previously included in the 2020 deferred revenue balance, respectively. The following table provides a rollforward of deferred revenue (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:162]
| ​ | ​ | (in thousands) |
| Balance at December 31, 2020 | ​ | $ | 4,197 |
| Revenue recognized | ​ |  | (6,356) |
| Revenue deferred | ​ |  | 8,815 |
| Balance at September 30, 2021 | ​ | $ | 6,656 |

- added (2021-11-15):
[0001558370-21-015999:note_history:163]
Disaggregated Revenue

- added (2021-11-15):
[0001558370-21-015999:note_history:164]
The following table presents the Company’s revenue by revenue stream (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:165]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended | ​ |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| (in thousands) |  | 2021 |  | 2020 | ​ | 2021 |  | 2020 | ​ |
| Product revenue |  | $ | 5,345 |  | $ | 349 | ​ | ​ | 10,299 |  | $ | 422 | ​ |
| Subscription revenue(1) |  | ​ | 2,305 |  | ​ | 794 | ​ | ​ | 5,118 |  | ​ | 1,743 | ​ |
| Service revenue |  | ​ | 417 |  | ​ | 165 | ​ | ​ | 773 |  | ​ | 170 | ​ |
| Maintenance revenue |  | ​ | 300 |  | ​ | 153 | ​ | ​ | 656 |  | ​ | 415 | ​ |
| Total revenue | ​ | $ | 8,367 | ​ | $ | 1,461 | ​ | $ | 16,846 | ​ | $ | 2,750 | ​ |

- added (2021-11-15):
[0001558370-21-015999:note_history:166]
| (1) | Subscription revenue is inclusive of $0.5 million and $0.2 million of maintenance revenue during the three months ended September 30, 2021 and 2020, respectively, and of $1.0 million and $0.4 million of maintenance revenue during the nine months ended September 30, 2021 and 2020, respectively, determined based on a relative fair value allocation as prescribed by ASC 606. |

- added (2021-11-15):
[0001558370-21-015999:note_history:167]
Contract Acquisition Costs

- added (2021-11-15):
[0001558370-21-015999:note_history:168]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the sale occurs and the services are provided. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $3.4 million at September 30, 2021 and $2.3 million at December 31, 2020. The increase in deferred assets is due to an increase of subscription revenue in 2020 and 2021 for which the related revenue and commissions are recognized over the contract term. The Company amortized commissions of $1.3 million during the three months ended September 30, 2021 which related to 2021 commissions, $0.1 million which related to 2020

- added (2021-11-15):
[0001558370-21-015999:note_history:169]
commissions and less than $0.1 million which related to 2019 commissions. The Company amortized commissions of $1.6 million during the nine months ended September 30, 2021 which related to 2021 commissions, $0.3 million which related to 2020 commissions and $0.1 million which related to 2019 commissions.

- added (2021-11-15):
[0001558370-21-015999:note_history:170]
Stock-Based Compensation

- added (2021-11-15):
[0001558370-21-015999:note_history:171]
The Company measures all stock-based awards granted to employees, officers, directors and non-employees based on their fair value on the date of the grant and recognizes compensation expense for those awards over the requisite service period, which is generally the vesting period of the respective award. The Company classifies stock-based compensation expense in its consolidated statements of operations and comprehensive income (loss) in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified.

- added (2021-11-15):
[0001558370-21-015999:note_history:172]
The Company issues stock-based awards with service-based vesting conditions and records the expense for these awards using the straight-line method. Forfeitures are accounted for as they occur. The Company has issued stock-based awards with performance-based vesting conditions. In August 2020, the Company granted an officer 560,189 stock options with a performance-based milestone vesting condition which vested immediately upon achievement of a certain sales milestone. The milestone was achieved in December 2020, and the Company recorded $0.1 million in stock compensation expense upon vesting during the year ended December 31, 2020.

- added (2021-11-15):
[0001558370-21-015999:note_history:173]
In March 2021, the Company granted a warrant exercisable for 2,554,015 shares of common stock to a consulting group (“2021 Finback common stock warrants”) with performance based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years.

- added (2021-11-15):
[0001558370-21-015999:note_history:174]
Prior to the closing of the Merger, there was not a public market for the shares of the Company’s common stock. The Company’s determination of the fair value of stock options on the date of grant utilized the Black-Scholes option-pricing model and was impacted by its common stock price, as determined by the Board of Directors with input from the Company’s management, as well as changes in assumptions regarding a number of subjective variables. These variables included, but were not limited to, the expected term that options remained outstanding, the expected common stock price volatility over the term of the option awards, risk-free interest rates, and expected dividends. The Company values its common stock taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the Company determined the fair value of each share of common stock underlying stock-based awards based on the closing price of the Company’s common stock as reported by Nasdaq on the date of grant.

- added (2021-11-15):
[0001558370-21-015999:note_history:175]
Pursuant to the Merger Agreement, the Company will issue 15,000,000 earn-out shares of the Company’s common stock to Legacy Evolv shareholders and Legacy Evolv service providers including employees, officers, directors and non-employees based on the achievement of certain target share price contingencies and for the employees and officers subject to continued employment. The company classifies the share-based compensation arrangement with Legacy Evolv service providers as equity on its balance sheet and corresponding stock-based compensation expense in its consolidated statements of operations and comprehensive income (loss) in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. Of the total 15,000,000 earn-out shares of the Company’s common stock, 2,862,603 earn-out shares are with the Legacy Evolv service providers and subject to the share-based compensation. Stock-based compensation expense attributable to Legacy Evolv service providers is $2.0 million for the three and nine months ended September 30, 2021.

- changed (2021-11-15):
[0001558370-21-015999:note_history:176]
Income Taxes
  (was, 2021-08-16, similarity 0.96):
[0001104659-21-106340:note_history:176]
Income Taxes:

- added (2021-11-15):
[0001558370-21-015999:note_history:177]
The Company accounts for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in the consolidated financial statements or in the Company’s tax returns. Deferred tax assets and liabilities are determined on the basis of the differences between the consolidated financial statements and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. Changes in deferred tax assets and liabilities are recorded in the provision for income taxes.

- added (2021-11-15):
[0001558370-21-015999:note_history:178]
The Company assesses the likelihood that its deferred tax assets will be recovered from future sources of income and, to the extent it believes, based upon the weight of available evidence, that it is more likely than not that all or a portion of the deferred tax assets will not be realized, a valuation allowance is established through a charge to income tax expense. Potential for recovery of deferred tax assets is evaluated by analyzing past operating results, estimating the future taxable profits expected and considering prudent and feasible tax planning strategies.

- added (2021-11-15):
[0001558370-21-015999:note_history:179]
The Company accounts for uncertainty in income taxes recognized in the consolidated financial statements by applying a two-step process to determine the amount of tax benefit to be recognized. First, the tax position must be evaluated to determine the likelihood that it will be sustained upon external examination by the taxing authorities. If the tax position is deemed more-likely-than-not to be sustained, the tax position is then assessed to determine the amount of benefit to recognize in the consolidated financial statements. The amount of the benefit that may be recognized is the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. The provision for income taxes includes the effects of any resulting tax reserves, or unrecognized tax benefits, that are considered appropriate as well as the related net interest and penalties.

- added (2021-11-15):
[0001558370-21-015999:note_history:180]
The Company evaluates at the end of each reporting period whether some or all of the undistributed earnings of its foreign subsidiaries are permanently reinvested. The Company would recognize deferred income tax liabilities to the extent that management asserts that undistributed earnings of its foreign subsidiaries are not permanently reinvested and will not be permanently reinvested in the future. As of September 30, 2021 and December 31, 2020 the Company had no foreign earnings in any foreign jurisdictions.

- changed (2021-11-15):
[0001558370-21-015999:note_history:181]
Net Income (Loss) per Share Attributable to Common Stockholders
  (was, 2021-08-16, similarity 0.6):
[0001104659-21-106340:note_history:181]
Net Income (Loss) per Share

- added (2021-11-15):
[0001558370-21-015999:note_history:182]
Basic net income (loss) per share attributable to common stockholders is computed by dividing the net income (loss) attributable to common stockholders by the weighted average number of common shares outstanding for the period. Diluted net income (loss) attributable to common stockholders is computed by adjusting net income (loss) attributable to common stockholders for the profit or loss impact to the extent a denominator adjustment is required.  Diluted net income (loss) per share attributable to common stockholders is computed by dividing the diluted net income (loss) attributable to common stockholders by the weighted average number of common shares outstanding for the period, including potential dilutive common shares. For purposes of this calculation, outstanding stock options, convertible preferred stock, convertible notes, warrants to purchase common stock, and warrants to purchase preferred stock are considered potential dilutive common shares.

- added (2021-11-15):
[0001558370-21-015999:note_history:183]
In periods in which the Company reported a net loss attributable to common stockholders, diluted net loss per share attributable to common stockholders is the same as basic net loss per share attributable to common stockholders, since dilutive common shares are not assumed to have been issued if their effect is anti-dilutive. The Company reported net income and a net loss attributable to common stockholders for the three months ended September 30, 2021 and 2020, respectively. For the three months ended September 30, 2021, no undistributed earnings were attributed to the convertible preferred shares which converted into common stock upon closing of the merger and have no contractual right to participate in the gains resulting from the change in fair value of earnouts and warrants that occurred after

- added (2021-11-15):
[0001558370-21-015999:note_history:184]
conversion. The Company reported a net loss attributable to common stockholders for the nine months ended September 30, 2021 and 2020.

- changed (2021-11-15):
[0001558370-21-015999:note_history:185]
Recently Issued Accounting Pronouncements
  (was, 2021-08-16, similarity 0.8649):
[0001104659-21-106340:note_history:185]
Recent Accounting Pronouncements:

- added (2021-11-15):
[0001558370-21-015999:note_history:186]
The Company qualifies as an “emerging growth company” as defined in the Jumpstart Our Business Startups Act of 2012 and has elected not to “opt out” to the extended transition related to complying with new or revised accounting standards, which means that when a standard is issued or revised and it has different application dates for public and nonpublic companies, the Company will adopt the new or revised standard at the time nonpublic companies adopt the new or revised standard and will do so until such time that the Company either (i) irrevocably elects to “opt out” of such extended transition period or (ii) no longer qualifies as an emerging growth company. The Company may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for nonpublic companies.

- added (2021-11-15):
[0001558370-21-015999:note_history:187]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

- added (2021-11-15):
[0001558370-21-015999:note_history:188]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which sets out the principles for the recognition, measurement, presentation and disclosure of leases for both parties to a contract (i.e., lessees and lessors). The new standard requires lessees to apply a dual approach, classifying leases as either finance or operating leases based on the principle of whether or not the lease is effectively a financed purchase by the lessee. This classification will determine whether lease expense is recognized based on an effective interest method or on a straight-line basis over the term of the lease. A lessee is also required to record a right-of-use asset and a lease liability for all leases with a term of greater than 12 months regardless of their classification. Leases with a term of 12 months or less may be accounted for similar to existing guidance for operating leases today. For nonpublic entities, this guidance is effective for annual periods beginning after December 15, 2021. In July 2018, the FASB issued ASU No. 2018-11, Leases (Topic 842), which added an optional transition method under which financial statements may be prepared under the revised guidance for the year of adoption, but not for prior years. Under the latter method, entities will recognize a cumulative catch-up adjustment to the opening balance of retained earnings in the period of adoption. The Company expects to adopt this guidance effective January 1, 2022, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

- added (2021-11-15):
[0001558370-21-015999:note_history:189]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company expects to adopt this guidance effective January 1, 2022, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

- added (2021-11-15):
[0001558370-21-015999:note_history:190]
In August 2020, the FASB issued ASU 2020-06, “Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity,” which simplifies and clarifies certain calculation and presentation matters related to convertible and equity and debt instruments. Specifically, ASU 2020-06 removes requirements to separately account for conversion features as a derivative under ASC Topic 815 and removing the requirement to account for beneficial conversion features on such instruments. ASU 2020-06 also provides clearer guidance surrounding disclosure of such instruments and provides specific guidance for how such instruments are to be incorporated in the calculation of Diluted EPS. The guidance under ASU 2020-06 is effective for fiscal years beginning after December 15, 2021, including interim periods within those fiscal years. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020. The Company expects to adopt this guidance effective January 1, 2022, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

- added (2021-11-15):
[0001558370-21-015999:note_history:191]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

- removed (2021-11-15):
[0001104659-21-106340:note_history:192]
Principles of Consolidation:

- removed (2021-11-15):
[0001104659-21-106340:note_history:193]
The condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiary, NHIC Sub Inc., a wholly owned subsidiary of the Company, incorporated in Delaware, formed to facilitate the acquisition of Evolv (Note 9). All significant intercompany balances and transactions have been eliminated in consolidation.

- removed (2021-11-15):
[0001104659-21-106340:note_history:194]
Basis of Presentation:

- removed (2021-11-15):
[0001104659-21-106340:note_history:195]
The accompanying unaudited condensed consolidated interim financial statements of the Company are presented in U.S. dollars and in conformity with accounting principles generally accepted in the United States of America (“GAAP”) pursuant to the rules and regulations of the SEC and reflect all adjustments, consisting only of normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the financial position as of June 30, 2021, and the results of operations and cash flows for the periods presented. Certain information and disclosures normally included in financial statements prepared in accordance with GAAP have been omitted pursuant to such rules and regulations. Interim results are not necessarily indicative of results for a full year or any later period.  Certain reclassifications have been made to the December 31, 2020 balance sheet to conform to the current presentation.

- removed (2021-11-15):
[0001104659-21-106340:note_history:196]
The accompanying unaudited condensed consolidated interim financial statements should be read in conjunction with the Company’s audited financial statements and notes thereto included in the Company’s final prospectus dated July 28, 2020, as well as the Company’s Annual Report, Amendment #1 on Form 10-K/A filed with the SEC on May 14, 2021.

- removed (2021-11-15):
[0001104659-21-106340:note_history:197]
At June 30, 2021, the Company has approximately $181,000 in cash, approximately $7,706,000 of current liabilities and approximately $7,380,000 in negative working capital.  The preponderance of the current liabilities (approximately $7,300,000) results from amounts accrued as payable to professional service firms who have agreed to deferred payment terms, or success fees, that are payable at the closing of a Business Combination.  Such accrued fees were paid upon the closing of the Business Combination on July 16, 2020.  Therefore, in connection with the Company’s assessment of going concern considerations in accordance with FASB Accounting Standards Update (“ASU”) 2014-15, “Disclosures of Uncertainties about an Entity’s Ability to Continue as a Going Concern,” as of June 30, 2021, management has determined that the Company’s current liquidity is sufficient to fund the working capital needs of the Company until the earlier of the consummation of the Business Combination or one year from the date of issuance of these financial statements.

- removed (2021-11-15):
[0001104659-21-106340:note_history:198]
Emerging Growth Company

- removed (2021-11-15):
[0001104659-21-106340:note_history:199]
Section 102(b)(1) of the JOBS Act exempts emerging growth companies from being required to comply with new or revised financial accounting standards until private companies (that is, those that have not had a Securities Act registration statement declared effective or do not have a class of securities registered under the Exchange Act) are required to comply with the new or revised financial accounting standards. The JOBS Act provides that a company can elect to opt out of the extended transition period and comply with the requirements that apply to non-emerging growth companies but any such an election to opt out is irrevocable. The Company has elected not to opt out of such extended transition period which means that when an accounting standard is issued or revised and it has different application dates for public or private companies, the Company, as an emerging growth company, can adopt the new or revised standard at the time private companies adopt the new or revised standard.  This may make comparison of the Company’s financial statements with another public company which is neither an emerging growth company nor an emerging growth company which has opted out of using the extended transition period difficult or impossible because of the potential differences in accounting standards used.

- removed (2021-11-15):
[0001104659-21-106340:note_history:200]
The Company considers all highly liquid instruments with original maturities of three months or less when acquired, to be cash equivalents.  The Company had no cash equivalents at June 30, 2021 and December 31, 2020.

- removed (2021-11-15):
[0001104659-21-106340:note_history:201]
Deferred Offering Costs:

- removed (2021-11-15):
[0001104659-21-106340:note_history:202]
The Company complies with the requirements of the FASB ASC 340-10-S99-1 and SEC Staff Accounting Bulletin (SAB) Topic 5A — “Expenses of Offering.”  Costs incurred in connection with preparation for the Offering were approximately $9,986,000, including underwriters’ discount paid and deferred of approximately $9,488,000.  Such costs were allocated among the equity and warrant liability components based on the relative fair value of the warrants and approximately $9,596,000 has been charged to equity for the equity components and approximately $390,000 has been charged to other expense for the warrant liability components upon completion of the Public Offering.

- removed (2021-11-15):
[0001104659-21-106340:note_history:203]
As discussed in Note 3, all of the 17,250,000 public shares sold as part of Units in the Public Offering contain a redemption feature which allows for the redemption of public shares if the Company holds a stockholder vote or there is a tender offer for shares in connection with a Business Combination. In accordance with FASB ASC 480, redemption provisions not solely within the control of the Company require the security to be classified outside of permanent equity. Ordinary liquidation events, which involve the redemption and liquidation of all of the entity’s equity instruments, are excluded from the provisions of FASB ASC 480. Although the Company did not specify a maximum redemption threshold, its charter provides that in no event will it redeem its public shares in an amount that would cause its net tangible assets (stockholders’ equity) to be less than $5,000,001 upon the closing of a Business Combination.

- removed (2021-11-15):
[0001104659-21-106340:note_history:204]
The Company recognizes changes in redemption value immediately as they occur and adjusts the carrying value of the securities at the end of each reporting period. Increases or decreases in the carrying amount of redeemable common stock are affected by adjustments to additional paid-in capital. Accordingly, at June 30, 2021 and December 31, 2020, 12,906,585 and 14,077,350, respectively, of the 17,250,000 public shares were classified outside of permanent equity.

- removed (2021-11-15):
[0001104659-21-106340:note_history:205]
Net income (loss) per common share is computed by dividing net income (loss) applicable to common stockholders by the weighted average number of shares of common stock outstanding for the period. The Company has not considered the effect of the warrants sold in the Public Offering and Private Placement to purchase an aggregate of 14,325,000 shares of Class A common stock in the calculation of diluted income (loss) per share, since their inclusion would be anti-dilutive under the treasury stock method. As a result, diluted income (loss) per common share is the same as basic loss per common share for the periods presented.

- removed (2021-11-15):
[0001104659-21-106340:note_history:206]
The Company’s statement of operations includes a presentation of income (loss) per share for common stock subject to redemption in a manner similar to the two-class method of income (loss) per share. Net income (loss) per share, basic and diluted for Class A common stock is calculated by dividing the interest income earned on the funds in the Trust Account, net of income tax expense and franchise tax expense, by the weighted average number of shares of Class A common stock outstanding since their original issuance. Net income (loss) per common share, basic and diluted, for shares of Class B common stock is calculated by dividing the net income (loss), less income attributable to Class A common stock, by the weighted average number of shares of Class B common stock outstanding for the period. Net income (loss) available to each class of common stockholders is as follows for the

- removed (2021-11-15):
[0001104659-21-106340:note_history:207]
three and six months ended June 30, 2021 and for the three months ended June 30, 2020 and for the period from January 24, 2020 (date of inception) to June 30, 2020:

- removed (2021-11-15):
[0001104659-21-106340:note_history:208]
| ​ | ​ | ​ | ​ | For the Period | ​ | ​ | ​ | For the Period |
| ​ | ​ | ​ | ​ | From January | ​ | ​ | ​ | From January |
| ​ | ​ | Three months | ​ | 24, 2020 (date | ​ | Six months | ​ | 24, 2020 (date |
| ​ | ​ | Ended | ​ | of inception) to | ​ | Ended | ​ | of inception) to |
| ​ | ​ | June 30, | ​ | June 30, | ​ | June 30, | ​ | June 30, |
| ​ |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net income available to Class A common stockholders: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Interest income | ​ | $ | 9,000 | ​ | $ | — | ​ | $ | 29,000 | ​ | $ | — |
| Less: Income and franchise taxes | ​ |  | (9,000) | ​ |  | — | ​ |  | (29,000) | ​ |  | — |
| Net income attributable to Class A common stockholders | ​ | $ | — | ​ | $ | — | ​ | $ | — | ​ | $ | — |
| Net income available to Class B common stockholders: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Net loss | ​ | $ | (7,626,000) | ​ | $ | (2,000) | ​ | $ | (11,708,000) | ​ | $ | (2,000) |
| Less: amount attributable to Class A common stockholders | ​ |  | — | ​ |  | — | ​ |  | — | ​ |  | — |
| Net (loss) attributable to Class B common stockholders | ​ | $ | (7,626,000) | ​ | $ | (2,000) | ​ | $ | (11,708,000) | ​ | $ | (2,000) |

- removed (2021-11-15):
[0001104659-21-106340:note_history:209]
Concentration of Credit Risk:

- removed (2021-11-15):
[0001104659-21-106340:note_history:210]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash accounts in a financial institution, which at times, may exceed the Federal depository insurance coverage of $250,000. The Company has not experienced losses on these accounts and management believes the Company is not exposed to significant risks on such accounts.

- removed (2021-11-15):
[0001104659-21-106340:note_history:211]
The fair value of the Company’s assets and liabilities, which qualify as financial instruments under FASB Accounting Standards Codification (“ASC 820”), “Fair Value Measurements and Disclosures,” approximates the carrying amounts represented in the financial statements.

- removed (2021-11-15):
[0001104659-21-106340:note_history:212]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires the Company’s management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements. Making estimates requires management to exercise significant judgment. It is at least reasonably possible that the estimate of the effect of a condition, situation or set of circumstances that existed at the date of the financial statement, which management considered in formulating its estimate, could change in the near term due to one or more future confirming events.  One of the more significant accounting estimates included in these financial statements is the determination of the fair value of the warrant liability. Such estimates may be subject to change as more current information becomes available and accordingly the actual results could differ significantly from those estimates.

- removed (2021-11-15):
[0001104659-21-106340:note_history:213]
The Company follows the asset and liability method of accounting for income taxes under FASB ASC, 740, “Income Taxes.” Deferred tax assets and liabilities are recognized for the estimated future tax consequences attributable to differences between the financial statements carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that included the enactment date. Valuation allowances are established, when necessary, to reduce deferred tax assets to the amount expected to be realized.

- removed (2021-11-15):
[0001104659-21-106340:note_history:214]
The Company’s currently taxable income consists of interest income on the Trust Account net of taxes. The Company’s general and administrative costs are generally considered start-up costs and are not currently deductible. During the three and six months ended June 30, 2021 and the three months ended June 30, 2021 and the period from January 24, 2020 (date of inception) to June 30, 2021, the Company recorded income tax expense of approximately $-0-and $-0-, respectively, related to interest income earned on the Trust Account net of taxes. The Company’s effective tax rate for the three and six months ended June 30, 2021 and the three months ended June 30, 2021 and the period from January 24, 2020 (date of inception) to June 30, 2021  was approximately -0-% and -0-%, and -0-% and -0-%, respectively, which differs from the expected income tax rate due to the start-up costs (discussed above) which are not currently deductible as well as business combination and warrant liability charges or credits which may not be deductible, and the low level of interest income.  At June 30, 2021 and December 31, 2020, the Company has a deferred tax asset of approximately $575,000 and $200,000, respectively. The Company records a full allowance reducing such deferred tax assets to zero since they are not reasonably assured of realizabilty due to the Company’s lack of operations, losses and pending change of control.

- removed (2021-11-15):
[0001104659-21-106340:note_history:215]
FASB ASC 740 prescribes a recognition threshold and a measurement attribute for the financial statement recognition and measurement of tax positions taken or expected to be taken in a tax return. For those benefits to be recognized, a tax position must be more-likely-than-not to be sustained upon examination by taxing authorities. There were no unrecognized tax benefits as of June 30, 2021. The Company recognizes accrued interest and penalties related to unrecognized tax benefits as income tax expense. No amounts were accrued for the payment of interest and penalties at June 30, 2021. The Company is currently not aware of any issues under review that could result in significant payments, accruals or material deviation from its position. The Company is subject to income tax examinations by major taxing authorities since inception.

- removed (2021-11-15):
[0001104659-21-106340:note_history:216]
Warrant Liability

- removed (2021-11-15):
[0001104659-21-106340:note_history:217]
The Company accounts for warrants as either equity-classified or liability-classified instruments based on an assessment of the warrant’s specific terms and applicable authoritative guidance FASB ASC 480, Distinguishing Liabilities from Equity (“ASC 480”) and ASC 815, Derivatives and Hedging (“ASC 815”). The assessment considers whether the warrants are freestanding financial instruments pursuant to ASC 480, meet the definition of a liability pursuant to ASC 480, and whether the warrants meet all of the requirements for equity classification under ASC 815, including whether the warrants are indexed to the Company’s own shares, among other conditions for equity classification. This assessment, which requires the use of professional judgment, is conducted at the time of warrant issuance and as of each subsequent quarterly period end date while the warrants are outstanding.

- removed (2021-11-15):
[0001104659-21-106340:note_history:218]
For issued or modified warrants that meet all of the criteria for equity classification, the warrants are required to be recorded as a component of additional paid-in capital at the time of issuance. For issued or modified warrants that do not meet all the criteria for equity classification, the warrants are required to be recorded as liabilities at their initial fair value on the date of issuance, and at fair value in each balance sheet date thereafter. Changes in the estimated fair value of the warrants are recognized as a non-cash gain or loss on the statements of operations. Costs associated with issuing the warrants accounted for as liabilities are charged to operations when the warrants are issued.  The fair value of the public warrants and the private placement warrants were initially estimated using a Monte Carlo simulation approach.  Following the separate trading of the Company’s common stock and public warrants, the private placement warrants fair values were estimated using a Black-Scholes-Merton approach.

- removed (2021-11-15):
[0001104659-21-106340:note_history:219]
In August 2020, the FASB issued Accounting Standards Update (“ASU”) 2020-06, Debt — Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging — Contracts in Entity’s Own Equity (Subtopic 815-40) (“ASU 2020-06”) to simplify accounting for certain financial instruments. ASU 2020-06 eliminates the current models that require separation of beneficial conversion and cash conversion features from convertible instruments and simplifies the derivative scope exception guidance pertaining to equity classification of contracts in an entity’s own equity. The new standard also introduces additional disclosures for convertible debt and freestanding instruments that are indexed to and settled in an entity’s own equity. ASU 2020-06 amends the diluted earnings per share guidance, including the requirement to use the if-converted method for all convertible instruments. ASU 2020-06 is effective January 1, 2022 and should be applied on a full or modified retrospective basis, with early adoption permitted beginning on January 1, 2021. The Company is currently evaluating the impact that the pronouncement will have on the financial statements.

- removed (2021-11-15):
[0001104659-21-106340:note_history:220]
Management does not believe that any other recently issued, but not yet effective, accounting pronouncements, if currently adopted, would have a material effect on the Company’s financial statements.

- removed (2021-11-15):
[0001104659-21-106340:note_history:221]
Subsequent Events:

- removed (2021-11-15):
[0001104659-21-106340:note_history:222]
Management has evaluated subsequent events to determine if events or transactions occurring after the date of the condensed consolidated balance sheet but before the condensed financial statements were available to be issued require potential adjustment to or disclosure in the condensed consolidated financial statements and has concluded that all such events that would require adjustment or disclosure have been recognized or disclosed, see Note 9.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-11-15):
[0001558370-21-015999:note_history:223]
9. Long-term Debt

- added (2021-11-15):
[0001558370-21-015999:note_history:224]
The components of the Company’s long-term debt consisted of the following (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:225]
| ​ | ​ | September 30, | ​ | December 31, | ​ |
| ​ |  | 2021 |  | 2020 | ​ |
| Term loans payable | ​ | $ | 10,000 | ​ | $ | 10,000 | ​ |
| Revolving line of credit outstanding | ​ |  | 5,422 | ​ |  | 3,550 | ​ |
| Convertible note | ​ |  | — | ​ |  | 3,000 | ​ |
| Less: Unamortized discount | ​ |  | (63) | ​ |  | (118) | ​ |
| ​ | ​ |  | 15,359 | ​ |  | 16,432 | ​ |
| Less: Current portion of long-term debt | ​ |  | 1,000 | ​ |  | — | ​ |
| Long-term debt, net of discount | ​ | $ | 14,359 | ​ | $ | 16,432 | ​ |

- added (2021-11-15):
[0001558370-21-015999:note_history:226]
Term Loan Agreements

- added (2021-11-15):
[0001558370-21-015999:note_history:227]
Silicon Valley Bank (“SVB”) Term Loan

- added (2021-11-15):
[0001558370-21-015999:note_history:228]
On July 5, 2017, the Company entered into a $5.0 million Loan and Security Agreement with Silicon Valley Bank (“2017 SVB Term Loan”), which provided the Company with a first term loan advance of $4.0 million which was drawn down on July 5, 2017 (“Term Loan A Advance”) and a second term loan advance of $1.0 million that was available to be drawn down until May 31, 2018 (“Term Loan B Advance”; collectively, “Term Loan Advances”). The agreement also provided the Company with a revolving line of credit of up to $1.0 million. Interest payments were due monthly and commenced upon receipt of principal. Principal was payable in 36 monthly payments and commenced on June 1, 2018. The 2017 SVB Term Loan accrued interest at an annual rate calculated as the Wall Street Journal Prime Rate plus 1.25%.

- added (2021-11-15):
[0001558370-21-015999:note_history:229]
On February 12, 2019, the Company amended the 2017 SVB Term Loan (“2019 Term Loan Advance”) to change the interest rate to the greater of the (A) Wall Street Journal Prime Rate or (B) 5.25%. Additionally, the maturity date was extended to August 2022. Upon closing, the Company issued warrants to purchase 28,350 shares of common stock to SVB with an exercise price of $0.24 per share (see Note 11).

- added (2021-11-15):
[0001558370-21-015999:note_history:230]
As of December 31, 2019, the Company was not in compliance with certain reporting related covenants within the SVB Loan and Security Agreement. As a result, SVB had the right to call for prepayment of the debt and it was therefore considered current as of December 31, 2019.

- added (2021-11-15):
[0001558370-21-015999:note_history:231]
In March 2020, the Company entered into a Loan Modification Agreement with SVB (“2020 SVB Term Loan”), which provided a $5.0 million term loan and a revolving line of credit of up to $7.0 million. The Company repaid the outstanding balance owed on the 2017 SVB Term Loan of $3.1 million of principal and accrued interest with the proceeds from the 2020 SVB Term Loan. The Loan Modification Agreement with SVB resulted in the Company being in compliance with certain reporting related covenants.

- added (2021-11-15):
[0001558370-21-015999:note_history:232]
Additionally, upon closing, the Company issued warrants to purchase 280,095 shares of common stock to SVB with an exercise price of $0.40 per share with a fair value of less than $0.1 million on the date of issuance. The Company also paid debt issuance costs of less than $0.1 million and owed an end-of-term charge of $0.1 million to SVB. The debt issuance costs were recorded as debt discount and were being amortized to interest expense, using the effective interest method, over the term of the loan. The 2020 SVB Term Loan interest was payable monthly and the principal was payable in 36 monthly payments commencing on April 1, 2021. The 2020 SVB Term Loan accrued interest at an annual

- added (2021-11-15):
[0001558370-21-015999:note_history:233]
rate calculated as the greater of (A) Wall Street Journal Prime Rate plus 0.50% or (B) 5.0%. In December 2020, the Company repaid the outstanding balance on the 2020 SVB Term loan of $8.0 million.

- added (2021-11-15):
[0001558370-21-015999:note_history:234]
JPMorgan Chase Bank, N.A.(“JPM”) Credit Agreement

- added (2021-11-15):
[0001558370-21-015999:note_history:235]
In December 2020, the Company entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024 and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022. The Company repaid the outstanding balance on the 2020 SVB Term Loan Advance, including the $5.0 million in principal and $3.0 million outstanding on the revolving line of credit. Upon repayment of the outstanding amounts, the Company recorded a loss on extinguishment of debt of less than $0.1 million, which was included in interest expense in the December 31, 2020 consolidated statements of operations and comprehensive income (loss).

- added (2021-11-15):
[0001558370-21-015999:note_history:236]
Principal and interest on the JPM Credit Agreement is payable monthly commencing on July 1, 2022. The JPM Credit Agreement accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 2.25% or (B) 5.5%. The revolving line of credit accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 1.25% or (B) 4.5%. Upon closing, the Company issued warrants to purchase 378,000 shares of common stock to the lender with an exercise price of $0.42 per share with a fair value of $0.1 million on the date of issuance. The Company incurred debt issuance costs of $0.1 million equal to the fair value of the warrants in connection with the JPM Credit Agreement. These costs were recorded as debt discount and are amortized to interest expense, using the effective interest method, over the term of the loan.

- added (2021-11-15):
[0001558370-21-015999:note_history:237]
As of September 30, 2021, the unamortized debt discount was $0.1 million. As of September 30, 2021, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the consolidated balance sheet. Interest expense totaled $0.2 million for the three months ended September 30, 2021, which includes the amortization of the debt discount which totaled less than $0.1 million. Interest expense totaled $0.6 million for the nine months ended September 30, 2021, which includes the amortization of the debt discount which totaled less than $0.1 million. The interest rate in effect as of September 30, 2021 was 5.5% and 4.5% for the JPM Credit Agreement and revolving line of credit, respectively. As of September 30, 2021, the Company has drawn down $5.4 million on the revolving line of credit.

- added (2021-11-15):
[0001558370-21-015999:note_history:238]
The Company’s obligations under the JPM Credit Agreement are secured by a first-priority security interest in all of its assets, including intellectual property.

- added (2021-11-15):
[0001558370-21-015999:note_history:239]
As of September 30, 2021, future principal payments on long-term debt are as follows (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:240]
| Year Ending December 31, |  | ​ | ​ |
| 2021 (remaining three months) | ​ | $ | — |
| 2022 | ​ |  | 7,422 |
| 2023 | ​ |  | 4,000 |
| 2024 | ​ |  | 4,000 |
| 2025 | ​ | ​ | — |
| ​ | ​ | $ | 15,422 |

- added (2021-11-15):
[0001558370-21-015999:note_history:241]
Convertible Note

- added (2021-11-15):
[0001558370-21-015999:note_history:242]
In September 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) with an investor for gross proceeds of $2.0 million with a stated interest rate of 6.0% per annum. An additional $2.0 million in gross proceeds were made available in December 2020 upon achievement of the integration milestone,

- added (2021-11-15):
[0001558370-21-015999:note_history:243]
whereby the Company successfully created software utilizing the investor’s application programming interface. The 2020 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds of the issuance of preferred stock totaled at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2020 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $1.0 million, and the notes, with an initial carrying value of $3.0 million, and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of September 30, 2021 as the liability was settled pursuant to the closing of the merger.

- added (2021-11-15):
[0001558370-21-015999:note_history:244]
As of September 30, 2021 and December 31, 2020, the accrued interest on the 2020 Convertible Notes was $0 and less than $0.1 million, respectively. Interest expense totaled less than $0.1 million and $0.3 million for the three and nine months ended September 30, 2021, respectively. Interest expense totaled less than $0.1 million for the three and nine months ended September 30, 2020, respectively.

- added (2021-11-15):
[0001558370-21-015999:note_history:245]
Between January 21, 2021 and February 4, 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $7.0 million, and the notes, with an initial carrying value of $23.0 million, and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of September 30, 2021 as the liability was settled pursuant to the closing of the merger.

- added (2021-11-15):
[0001558370-21-015999:note_history:246]
On June 21, 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. This modification of the notes resulted in an extinguishment and the Company recognized a loss on extinguishment of the 2021 Convertible Notes of $11.8 million. The $26.7 million carrying value of the notes at June 21, 2021 was derecognized and replacement notes with an initial carrying value of $29.6 million were recorded. Additionally, in the extinguishment accounting, a derivative liability of $19.2 million was recognized, which represents the value of the 1,000,000 NHIC shares as well as a bifurcated embedded derivative for the conversion option.

- added (2021-11-15):
[0001558370-21-015999:note_history:247]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense).

- added (2021-11-15):
[0001558370-21-015999:note_history:248]
As of September 30, 2021 and December 31, 2020, the accrued interest on the 2021 Convertible Notes was $0. Interest expense totaled less than $0.1 million and $4.9 million for the three and nine months ended September 30, 2021, respectively.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-11-15):
[0001558370-21-015999:note_history:249]
Debt Issuance Costs

- added (2021-11-15):
[0001558370-21-015999:note_history:250]
The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated debt on the consolidated balance sheet and amortized as interest expense on the consolidated statement of operations and comprehensive loss using the effective interest method. As of September 30, 2021, and December 31, 2020, debt issuance costs totaled $0.1 million and $0.1 million, respectively, and were recorded as a reduction in the carrying amount of long-term debt in the consolidated balance sheets. During the three months ended September 30, 2021 and 2020, and nine months ended September 30, 2021 and 2020, the Company recorded less than $0.1 million in

- added (2021-11-15):
[0001558370-21-015999:note_history:251]
amortization of the debt issuance costs recorded within interest expense in the consolidated statement of operations and comprehensive income (loss).


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-11-15):
[0001558370-21-015999:note_history:252]
The components of the Company’s long-term debt consisted of the following (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:253]
| ​ | ​ | September 30, | ​ | December 31, | ​ |
| ​ |  | 2021 |  | 2020 | ​ |
| Term loans payable | ​ | $ | 10,000 | ​ | $ | 10,000 | ​ |
| Revolving line of credit outstanding | ​ |  | 5,422 | ​ |  | 3,550 | ​ |
| Convertible note | ​ |  | — | ​ |  | 3,000 | ​ |
| Less: Unamortized discount | ​ |  | (63) | ​ |  | (118) | ​ |
| ​ | ​ |  | 15,359 | ​ |  | 16,432 | ​ |
| Less: Current portion of long-term debt | ​ |  | 1,000 | ​ |  | — | ​ |
| Long-term debt, net of discount | ​ | $ | 14,359 | ​ | $ | 16,432 | ​ |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-11-15):
[0001558370-21-015999:note_history:254]
As of September 30, 2021, future principal payments on long-term debt are as follows (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:255]
| Year Ending December 31, |  | ​ | ​ |
| 2021 (remaining three months) | ​ | $ | — |
| 2022 | ​ |  | 7,422 |
| 2023 | ​ |  | 4,000 |
| 2024 | ​ |  | 4,000 |
| 2025 | ​ | ​ | — |
| ​ | ​ | $ | 15,422 |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-11-15):
[0001558370-21-015999:note_history:256]
16. Related Party Transactions
  (was, 2021-08-16, similarity 0.8889):
[0001104659-21-106340:note_history:256]
NOTE 4 – RELATED PARTY TRANSACTIONS

- added (2021-11-15):
[0001558370-21-015999:note_history:257]
Nonrecourse Promissory Note with Officer

- added (2021-11-15):
[0001558370-21-015999:note_history:258]
In August 2020, the Company entered into a $0.4 million promissory note with an officer with the proceeds being used to exercise options for 1,469,999 shares of common stock at a price of $0.24 per share. The promissory note bore interest at the Wall Street Journal Prime Rate and was secured by the underlying shares of common stock that were issued upon the exercise of the stock options. The promissory note was treated as nonrecourse as the loan was only secured by the common stock issued from the exercise of the stock options. As such, (i) the underlying stock option grant was still considered to be outstanding and the shares of common stock were not considered issued and outstanding for accounting purposes until the loan was repaid in full or otherwise forgiven and (ii) no receivable was recorded for the promissory note on the Company’s consolidated balance sheets. As such, the promissory note effectively extended the maturity date of the option grant for the life of the loan, this change is treated as a stock option modification. The incremental fair value from the stock option modification was deemed immaterial. The interest on this nonrecourse loan is also considered nonrecourse. As the Company has no intent to collect interest, no accrued interest was recorded.

- added (2021-11-15):
[0001558370-21-015999:note_history:259]
In June 2021, the Company agreed to repurchase 43,684 shares of common stock valued at $8.04 per share of common stock held by the officer of the Company. In exchange for the repurchase of the common stock by the Company, the $0.4 million promissory note held by the officer was considered repaid in full.

- added (2021-11-15):
[0001558370-21-015999:note_history:260]
Business Development Agreement with Finback

- added (2021-11-15):
[0001558370-21-015999:note_history:261]
In March 2021, the Company granted a warrant exercisable for 2,554,015 shares of common stock to Finback, a consulting group who is an affiliate of one of the Company’s shareholders, with performance-based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years.

- added (2021-11-15):
[0001558370-21-015999:note_history:262]
During the three and nine months ended September 30, 2021, the Company recorded less than $0.1 million and $1.0 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.

- removed (2021-11-15):
[0001104659-21-106340:note_history:263]
Founder Shares

- removed (2021-11-15):
[0001104659-21-106340:note_history:264]
In February 2020, the Sponsor purchased 4,312,500 shares of Class B common stock (the “Founder Shares”) for $25,000, or approximately $0.006 per share. In July 2020, the Sponsor transferred an aggregate of 867,500 founder shares, including to the following persons: (1) 32,500 founder shares to each of Marc Saiontz and Suzy Taherian, two of the Company’s independent director nominees, (ii) 35,000 founder shares to each of Neil Glat and Brian Mathis, two of the Company’s independent director nominees, (iii) 40,000 founder shares to Kathleen Harris, one of the Company’s independent director nominees, (iv) 50,000 founder shares to Thomas Sullivan, one of the Company’s independent director nominees, (v) 67,500 founder shares to Adam Deutsch, the Company’s Chief Financial Officer, (vi) 100,000 founder shares to Charlie Baynes-Reid, the Company’s Chief Operating Officer, (vii) 135,000 founder shares to each of Kevin Charlton and Charles Goldman, the Company’s Chief Executive Officer and director, respectively, and (viii)

- removed (2021-11-15):
[0001104659-21-106340:note_history:265]
200,000 founder shares to Nick Petruska, the Company’s special advisor; and (ii) the Sponsor forfeited 920,000 shares of Class B common stock and certain funds and accounts managed by Magnetar Financial LLC, UBS O’Connor LLC, and Mint Tower Capital Management B.V (collectively, the “Anchor Investor”) purchased 920,000 shares of Class B common stock from the Company for an aggregate purchase price of approximately $5,333, or approximately $0.006 per share resulting in the Company’s initial stockholders holding an aggregate of 4,312,500 Founder Shares. The Founder Shares are identical to the Class A common stock included in the Units being sold in the Public Offering except that the Founder Shares automatically convert into shares of Class A common stock at the time of the initial Business Combination and are subject to certain transfer restrictions, as described in more detail below.

- removed (2021-11-15):
[0001104659-21-106340:note_history:266]
The Company’s initial stockholders and Anchor Investors have agreed not to transfer, assign or sell any of its Founder Shares until the earlier of (A) one year after the completion of the Company’s initial Business Combination, or (B), subsequent to the Company’s initial Business Combination, if (x) the last sale price of the Company’s Class A common stock equals or exceeds $12.00 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30-trading day period commencing at least 150 days after the Company’s initial Business Combination or (y) the date on which the Company completes a liquidation, merger, stock exchange or other similar transaction after the initial Business Combination that results in all of the Company’s stockholders having the right to exchange their shares of Class A common stock for cash, securities or other property.

- removed (2021-11-15):
[0001104659-21-106340:note_history:267]
Private Placement Warrants

- removed (2021-11-15):
[0001104659-21-106340:note_history:268]
The Sponsor and the Anchor Investors purchased from the Company an aggregate of 5,700,000 warrants at a price of $1.00 per warrant, a purchase price of $5,700,000 in a private placement that occurred simultaneously with the completion of the Public Offering (the “Private Placement Warrants”), including the underwriters’ full exercise of their overallotment option. Each Private Placement Warrant entitles the holder to purchase one share of Class A common stock at $11.50 per share. A portion of the purchase price of the Private Placement Warrants was added to the proceeds from the Public Offering held in the Trust Account pending completion of the Company’s initial Business Combination. The Private Placement Warrants (including the Class A common stock issuable upon exercise of the Private Placement Warrants) are not transferable, assignable or salable until 30 days after the completion of the initial Business Combination and they will be non-redeemable so long as they are held by the Sponsor or the Anchor Investors or their permitted transferees. If the Private Placement Warrants are held by someone other than the Sponsor or the Anchor Investors or their permitted transferees, the Private Placement Warrants will be redeemable by the Company and exercisable by such holders on the same basis as the warrants included in the Units being sold in the Public Offering. Otherwise, the Private Placement Warrants have terms and provisions that are identical to those of the Warrants being sold as part of the Units in the Public Offering and have no net cash settlement provisions.

- removed (2021-11-15):
[0001104659-21-106340:note_history:269]
If the Company does not complete a Business Combination, then the proceeds from the sale of the Private Placement Warrants will be part of the liquidating distribution to the public stockholders and the Private Placement Warrants issued to the Sponsor will expire worthless.

- removed (2021-11-15):
[0001104659-21-106340:note_history:270]
Registration Rights

- removed (2021-11-15):
[0001104659-21-106340:note_history:271]
The Company’s initial stockholders and the holders of the Private Placement Warrants will be entitled to registration rights pursuant to a registration rights agreement to be signed on or before the date of the prospectus for the Public Offering. These holders will be entitled to make up to three demands, excluding short form registration demands, that the Company register such securities for sale under the Securities Act. In addition, these holders will have “piggy-back” registration rights to include their securities in other registration statements filed by the Company. The Company will bear the expenses incurred in connection with the filing of any such registration statements. There will be no penalties associated with delays in registering the securities under the proposed registration rights agreement.

- removed (2021-11-15):
[0001104659-21-106340:note_history:272]
Related Party Loans

- removed (2021-11-15):
[0001104659-21-106340:note_history:273]
In February 2020, the Sponsor agreed to loan the Company an aggregate of $300,000 by drawdowns of not less than $10,000 each against the issuance of an unsecured promissory note (the “Note”) to cover expenses related to the Public Offering. The Note was non-interest bearing and payable promptly after the earlier of the date on which the Company consummates the Public Offering and the date on which the Company determines not to conduct the Public Offering. The Company drew down a total of approximately $47,000 under the Note, including approximately $3,000 for costs paid directly by the Sponsor.  On August 4, 2020, the approximately $47,000 outstanding under the Note was fully repaid in connection with the closing of the IPO.

- removed (2021-11-15):
[0001104659-21-106340:note_history:274]
Working Capital Loans

- removed (2021-11-15):
[0001104659-21-106340:note_history:275]
In order to finance transaction costs in connection with a Business Combination, the Sponsor, an affiliate of the Sponsor, or certain of the Company’s officers and directors or their affiliates may, but are not obligated to, loan the Company funds as may be required (“Working Capital Loans”). If the Company completes a Business Combination, the Company would repay the Working Capital Loans out of the proceeds of the Trust Account released to the Company. Otherwise, the Working Capital Loans would be repaid only out of funds held outside the Trust Account. In the event that a Business Combination does not close, the Company may use a portion of proceeds held outside the Trust Account to repay the Working Capital Loans but no proceeds held in the Trust Account would be used to repay the Working Capital Loans. The Working Capital Loans would either be repaid upon consummation of a Business Combination, without interest, or, at the lender’s discretion, up to $1,500,000 of such Working Capital Loans may be convertible into warrants of the post Business Combination entity. The warrants would be identical to the Private Placement Warrants. Except for the foregoing, the terms of such Working Capital Loans, if any, have not been determined and no written agreements exist with respect to such loans. As of June 30, 2021 and December 31, 2020, no Working Capital Loans were outstanding.

- removed (2021-11-15):
[0001104659-21-106340:note_history:276]
Administrative Support Agreement

- removed (2021-11-15):
[0001104659-21-106340:note_history:277]
The Company has agreed to pay $15,000 a month for office space, utilities and secretarial and administrative support to an affiliate of the Sponsor. Services commenced on the date the securities were first listed on the Nasdaq Capital Market and will terminate upon the earlier of the consummation by the Company of an initial Business Combination or the liquidation of the Company.  During the three and six months ended June 30, 2021, approximately $45,000 and $90,000, respectively, was included in general and administrative expenses for the administrative support fee.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2021-11-15):
[0001558370-21-015999:note_history:278]
The following table presents the Company’s revenue by revenue stream (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:279]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended | ​ |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| (in thousands) |  | 2021 |  | 2020 | ​ | 2021 |  | 2020 | ​ |
| Product revenue |  | $ | 5,345 |  | $ | 349 | ​ | ​ | 10,299 |  | $ | 422 | ​ |
| Subscription revenue(1) |  | ​ | 2,305 |  | ​ | 794 | ​ | ​ | 5,118 |  | ​ | 1,743 | ​ |
| Service revenue |  | ​ | 417 |  | ​ | 165 | ​ | ​ | 773 |  | ​ | 170 | ​ |
| Maintenance revenue |  | ​ | 300 |  | ​ | 153 | ​ | ​ | 656 |  | ​ | 415 | ​ |
| Total revenue | ​ | $ | 8,367 | ​ | $ | 1,461 | ​ | $ | 16,846 | ​ | $ | 2,750 | ​ |

- added (2021-11-15):
[0001558370-21-015999:note_history:280]
| (1) | Subscription revenue is inclusive of $0.5 million and $0.2 million of maintenance revenue during the three months ended September 30, 2021 and 2020, respectively, and of $1.0 million and $0.4 million of maintenance revenue during the nine months ended September 30, 2021 and 2020, respectively, determined based on a relative fair value allocation as prescribed by ASC 606. |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2021-11-15):
[0001558370-21-015999:note_history:281]
Revenue Recognition

- added (2021-11-15):
[0001558370-21-015999:note_history:282]
The Company recognizes revenue in accordance with ASC 606. Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

- added (2021-11-15):
[0001558370-21-015999:note_history:283]
The Company derives revenue from (1) subscription arrangements accounted for as operating leases under ASC 840 and (2) from the sale of products, inclusive of maintenance and services. The Company’s arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

- added (2021-11-15):
[0001558370-21-015999:note_history:284]
Product Revenue

- added (2021-11-15):
[0001558370-21-015999:note_history:285]
The Company derives revenue from the sale of its Express and Edge equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer. Transfer of control occurs when the Company has transferred title and risk of loss and has a present right to payment for the equipment, which is generally upon delivery as the Company’s normal terms of sale are freight on board destination. Products are predominately sold with distinct services, which are described in the services section below.

- added (2021-11-15):
[0001558370-21-015999:note_history:286]
Subscription Revenue

- added (2021-11-15):
[0001558370-21-015999:note_history:287]
In addition to selling its products directly to customers, the Company also leases Express and Edge equipment. These arrangements convey the right to use the equipment for a period of time in exchange for consideration and therefore are accounted for under ASC 840 due to the scope exception of ASC 606-10-15-2. Lease terms are typically four years and customers pay quarterly or annual fixed payments for the lease and maintenance elements over the contractual lease term. In accordance with ASC 840, Leases, the Company considers only the fixed payments for purposes of allocating between the lease and non-lease deliverables on a relative fair value basis. Equipment leases are generally classified as operating leases as they do not meet any of the capital lease criteria per ASC 840.

- added (2021-11-15):
[0001558370-21-015999:note_history:288]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (i) distinct services, such as installation, training and maintenance, and (ii) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern and because revenue allocated to maintenance components is not material, the equipment lease and maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations.

- added (2021-11-15):
[0001558370-21-015999:note_history:289]
As leases with customers are classified as operating leases, lease revenue is recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

- added (2021-11-15):
[0001558370-21-015999:note_history:290]
Services Revenue

- added (2021-11-15):
[0001558370-21-015999:note_history:291]
The Company provides installation, training and maintenance services for its products. Revenue for installation and training is recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes, and when-and-if-available threat updates. Maintenance revenue is recognized ratably over the period of the arrangement. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are recognized ratably over the associated service period.

- added (2021-11-15):
[0001558370-21-015999:note_history:292]
Revenue from Distributors

- added (2021-11-15):
[0001558370-21-015999:note_history:293]
A portion of the Company’s revenue is also generated by sales in conjunction with its distributors. When the Company transacts with a distributor, its contractual arrangement is with the distributor and not with the end-use customer. In these transactions, the distributor is considered the customer; the Company has discretion over the pricing to the distributor and maintains overall control of the inventory and sales process to the distributor. Revenue is recognized upon delivery to the distributors. Right of return does not generally exist. Whether the Company transacts with a distributor and receives the order from a distributor or directly from an end-use customer, its revenue recognition policy and resulting pattern of revenue recognition is the same upon delivery.

- added (2021-11-15):
[0001558370-21-015999:note_history:294]
Transaction Price

- added (2021-11-15):
[0001558370-21-015999:note_history:295]
The transaction price is the amount of consideration that the Company expects to be entitled for providing goods and services under a contract. It includes not only fixed consideration, such as the stated amount in a contract, but also several other types of variable consideration or adjustments (generally discounts or incentives which are included as a part of the standalone selling price (“SSP”) estimation process). The Company provides discounts to customers which reduces the transaction price. From time-to-time, the Company may offer customers the option to purchase additional goods and services at a fixed price. In these limited circumstances, the Company assesses whether these offers constitute a material right, and if so, the Company would account for the material right as a separate performance obligation. Other types of variable consideration are not considered significant. The Company does not normally provide for rights of returns to customers on product sales and, therefore, does not record a provision for returns.

- added (2021-11-15):
[0001558370-21-015999:note_history:296]
Performance Obligations

- added (2021-11-15):
[0001558370-21-015999:note_history:297]
A performance obligation is a promise in a contract to transfer a distinct product or service to a customer that is both capable of being distinct, whereby the customer can benefit from the product or service either on its own or together with other resources that are readily available, and is distinct in the context of the contract, whereby the transfer of the product or service is separately identifiable from other promises in the contract.

- added (2021-11-15):
[0001558370-21-015999:note_history:298]
For both Express and Edge units, equipment is sold or leased with embedded software, which is considered a single performance obligation. Maintenance, which includes future updates, security threat updates, and minor bug fixes on a when-and-if available basis, is considered a single performance obligation. As a part of reported subscription sales, certain non-lease components, such as maintenance, are included within the subscription revenue amount. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are accounted for as separate performance obligations. Installation and training are considered separate performance obligations and are included within services revenue. Any add-on accessories are also considered separate performance obligations.

- added (2021-11-15):
[0001558370-21-015999:note_history:299]
Payment terms

- added (2021-11-15):
[0001558370-21-015999:note_history:300]
Payment terms for customer orders are typically 30 days after the shipment or delivery of the product. For certain products, services and customer types, the Company requires payment before the products or services are delivered to, or performed for, the customer. Generally, the Company’s contracts do not contain a significant financing component.

- added (2021-11-15):
[0001558370-21-015999:note_history:301]
Multiple Performance Obligations within an Arrangement

- added (2021-11-15):
[0001558370-21-015999:note_history:302]
The Company’s contracts may include multiple performance obligations when customers purchase a combination of products and services. When the Company’s customer arrangements have multiple performance obligations that contain a lease for Express or Edge equipment for the customer’s use at its site as well as distinct services that are delivered simultaneously, the Company allocates the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, the Company allocates the contract’s transaction price to each performance obligation on a relative SSP basis. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company estimates the SSP taking into account available information such as market conditions and internally approved pricing guidelines related to the performance obligation.

- added (2021-11-15):
[0001558370-21-015999:note_history:303]
Remaining Performance Obligations

- added (2021-11-15):
[0001558370-21-015999:note_history:304]
ASC 606 requires that the Company disclose the aggregate amount of transaction price that is allocated to performance obligations that have not yet been satisfied as of September 30, 2021. The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2021. Note that with respect to ASC 840, Subscription revenue includes maintenance in addition to the operating lease components of these transactions (in thousands).

- added (2021-11-15):
[0001558370-21-015999:note_history:305]
| ​ |  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue |  | $ | 111 |  | $ | 36 |  | $ | 147 |
| Subscription revenue |  | ​ | 9,304 |  | ​ | 21,802 |  | ​ | 31,106 |
| Service revenue |  | ​ | 24 |  | ​ | — |  | ​ | 24 |
| Maintenance revenue |  | ​ | 903 |  | ​ | 1,972 |  | ​ | 2,875 |
| Total revenue | ​ | $ | 10,342 | ​ | $ | 23,810 | ​ | $ | 34,152 |

- added (2021-11-15):
[0001558370-21-015999:note_history:306]
The amount of minimum future leases is based on expected income recognition. As of September 30, 2021, future minimum payments on noncancelable leases are as follows (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:307]
| Future operating lease component (in thousands): |  | ​ |  |
| Quarter Ending September 30, 2021: | ​ | ​ | ​ |
| 2021 | ​ | $ | 2,355 |
| 2022 | ​ |  | 9,262 |
| 2023 | ​ |  | 8,800 |
| 2024 | ​ |  | 7,054 |
| 2025 | ​ |  | 3,166 |
| Thereafter | ​ |  | 469 |
| ​ | ​ | $ | 31,106 |

- added (2021-11-15):
[0001558370-21-015999:note_history:308]
Contract Balances from Contracts with Customers

- added (2021-11-15):
[0001558370-21-015999:note_history:309]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2021 and December 31, 2020, the Company had $0.9 million and $0 of contract assets included within prepaid expenses and other current assets and $2.6 million and $0 in long-term contract assets on the consolidated balance sheets, respectively.

- added (2021-11-15):
[0001558370-21-015999:note_history:310]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as noncurrent deferred revenue. The Company recognized $0.5 million and $2.3 million during the three months and nine months ended September 30, 2021 of revenue that was previously included in the 2020 deferred revenue balance, respectively. The following table provides a rollforward of deferred revenue (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:311]
| ​ | ​ | (in thousands) |
| Balance at December 31, 2020 | ​ | $ | 4,197 |
| Revenue recognized | ​ |  | (6,356) |
| Revenue deferred | ​ |  | 8,815 |
| Balance at September 30, 2021 | ​ | $ | 6,656 |

- added (2021-11-15):
[0001558370-21-015999:note_history:312]
Disaggregated Revenue

- added (2021-11-15):
[0001558370-21-015999:note_history:313]
The following table presents the Company’s revenue by revenue stream (in thousands):

- added (2021-11-15):
[0001558370-21-015999:note_history:314]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended | ​ |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| (in thousands) |  | 2021 |  | 2020 | ​ | 2021 |  | 2020 | ​ |
| Product revenue |  | $ | 5,345 |  | $ | 349 | ​ | ​ | 10,299 |  | $ | 422 | ​ |
| Subscription revenue(1) |  | ​ | 2,305 |  | ​ | 794 | ​ | ​ | 5,118 |  | ​ | 1,743 | ​ |
| Service revenue |  | ​ | 417 |  | ​ | 165 | ​ | ​ | 773 |  | ​ | 170 | ​ |
| Maintenance revenue |  | ​ | 300 |  | ​ | 153 | ​ | ​ | 656 |  | ​ | 415 | ​ |
| Total revenue | ​ | $ | 8,367 | ​ | $ | 1,461 | ​ | $ | 16,846 | ​ | $ | 2,750 | ​ |

- added (2021-11-15):
[0001558370-21-015999:note_history:315]
| (1) | Subscription revenue is inclusive of $0.5 million and $0.2 million of maintenance revenue during the three months ended September 30, 2021 and 2020, respectively, and of $1.0 million and $0.4 million of maintenance revenue during the nine months ended September 30, 2021 and 2020, respectively, determined based on a relative fair value allocation as prescribed by ASC 606. |

- added (2021-11-15):
[0001558370-21-015999:note_history:316]
Contract Acquisition Costs

- added (2021-11-15):
[0001558370-21-015999:note_history:317]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the sale occurs and the services are provided. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $3.4 million at September 30, 2021 and $2.3 million at December 31, 2020. The increase in deferred assets is due to an increase of subscription revenue in 2020 and 2021 for which the related revenue and commissions are recognized over the contract term. The Company amortized commissions of $1.3 million during the three months ended September 30, 2021 which related to 2021 commissions, $0.1 million which related to 2020

- added (2021-11-15):
[0001558370-21-015999:note_history:318]
commissions and less than $0.1 million which related to 2019 commissions. The Company amortized commissions of $1.6 million during the nine months ended September 30, 2021 which related to 2021 commissions, $0.3 million which related to 2020 commissions and $0.1 million which related to 2019 commissions.


## us-gaap:SubsequentEventsPolicyPolicyTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-11-15):
[0001104659-21-106340:note_history:319]
Subsequent Events:

- removed (2021-11-15):
[0001104659-21-106340:note_history:320]
Management has evaluated subsequent events to determine if events or transactions occurring after the date of the condensed consolidated balance sheet but before the condensed financial statements were available to be issued require potential adjustment to or disclosure in the condensed consolidated financial statements and has concluded that all such events that would require adjustment or disclosure have been recognized or disclosed, see Note 9.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-11-15):
[0001104659-21-106340:note_history:321]
NOTE 9 – SUBSEQUENT EVENT – MERGER

- removed (2021-11-15):
[0001104659-21-106340:note_history:322]
On July 16, 2021, subsequent to the fiscal quarter ended June 30, 2021, the fiscal quarter to which this Quarterly Report on Form 10-Q relates, we consummated the business combination, or the Business Combination, contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc. (“Merger Sub”), a wholly-owned subsidiary of the Company a special purpose acquisition company, which is our predecessor, and Evolv Technologies, Inc. dba Evolv Technology, Inc. (“Legacy Evolv”), as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 by and among the Company, Merger Sub and Legacy Evolv (the “Amendment” and as amended, the “Merger Agreement”). Pursuant to the Merger Agreement, Merger Sub was merged with and into Legacy Evolv, with Legacy Evolv surviving the merger as a wholly owned subsidiary of the Company (the “Business Combination”). Upon the closing of the Business Combination, the Company changed its name to Evolv Technologies Holdings, Inc. and the officers of NewHold Investments Corp resigned and the officers of Evolv became the officers of the Company.  Evolv is engaged in the business of providing artificial intelligence touchless security screening.  Evolv is based in Waltham, Massachusetts.

- removed (2021-11-15):
[0001104659-21-106340:note_history:323]
Holders of 8,755,987 shares of the Company Class A common stock sold in its initial public offering properly exercised their right to have such shares redeemed for a full pro rata portion of the trust account holding the proceeds from Comapny public offering, calculated as of two business days prior to the consummation of the Business Combination, which was approximately $10.00 per share, or $87,564,196.77 in the aggregate. As a result of the Business Combination, each share of Legacy Evolv preferred stock and common stock was converted into the right to receive approximately 0.378 shares of Evolv Technologies Holdings, Inc’s Class A common stock. Additionally, the 4,312,500 shares of Company Class B common stock held by NewHold Industrial Technology Holdings LLC, automatically converted to 4,312,500 shares of Evolv Technologies Holdings, Inc’s Class A common stock.

- removed (2021-11-15):
[0001104659-21-106340:note_history:324]
Cash proceeds of the Business Combination were funded through a combination of Company cash held in trust, net of redemptions, and $300.0 million in aggregate gross proceeds to Evolv from the Private Investment in Public Equity (“PIPE”).
