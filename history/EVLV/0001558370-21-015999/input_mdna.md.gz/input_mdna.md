# EVLV MD&A — 0001558370-21-015999


## mdna

[0001558370-21-015999:mdna:1]
[same as prior period, unchanged from 0001104659-21-106340:mdna:1]

[0001558370-21-015999:mdna:2]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of the Merger and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001558370-21-015999:mdna:3]
Business Overview

[0001558370-21-015999:mdna:4]
The Company is a global leader in SaaS-based weapons detection security screening. Unlike conventional walk-through metal detectors, our products use advanced sensors, artificial intelligence software, and cloud services to reliably detect guns, improvised explosives, and large knives while ignoring harmless items like phones and keys. This not only enhances security at venues and facilities but also improves the visitor experience by making screening up to ten times faster than alternatives at up to 70% lower total cost.

[0001558370-21-015999:mdna:5]
Our products have screened over 75 million people worldwide. We believe that we have screened more people through advanced systems than any organization other than the United States Transportation Security Administration (“TSA”). Our customers include many iconic venues across a wide variety of industries including major sports teams, notable performing arts and entertainment venues, major tourist destinations and cultural attractions, large industrial workplaces, large school districts, and prominent houses of worship. We offer our products for purchase or under a multi-year security-as-a-service subscription pricing model that delivers ongoing value to customers, generates predictable revenue and creates expansion and upsell opportunities.

[0001558370-21-015999:mdna:6]
Our mission is to make the world a safer and more enjoyable place to live, work, study, and play. We are focused on delivering value in the spaces in and around the physical threshold of large venues and facilities. We believe that digitally transforming the threshold experience is one of the most exciting innovation opportunities of our time. We believe that our ongoing innovations will not only make venues and facilities safer and more enjoyable, but also more efficient and profitable.

[0001558370-21-015999:mdna:7]
Touchless security screening represents a paradigm shift for the security screening market which, according to our estimates, is currently a $20 billion market opportunity. Touchless security screening is a radical change from conventional security screening processes that primarily rely on walk-through metal detectors based on core technology that was invented in the nineteenth century. This conventional approach presents numerous operational problems and hidden costs including a high number of nuisance alarms due to the inability to distinguish weapons from harmless items. These frequent nuisance alarms require resolution using manual bag checks and pat downs that are error-prone, labor cost-intensive, and unpleasant for visitors. This creates long wait times, dangerous crowding, and numerous opportunities for weapons to slip through. The result is reduced security, frustrated visitors, and acutely stressful working conditions for employees.

[0001558370-21-015999:mdna:8]
By allowing visitors to walk through at a normal pace with their bags in hand and without emptying their pockets, Evolv products significantly accelerate the security screening process while also reducing the number of nuisance alarms to a level that allows guards to focus their attention on real threats. We believe there is significant demand for touchless

[0001558370-21-015999:mdna:9]
security screening in venues and facilities that currently use slower, more invasive conventional metal detector screening. We also believe there is additional opportunity in venues and facilities that have not previously adopted weapon screening because of the limitations of conventional screening. Our technology is designed to allow these venues and facilities to successfully deploy security screening for the first time.

[0001558370-21-015999:mdna:10]
Our potential to develop this significant opportunity is rooted in our deep domain experience and commitment to research and development. Our engineering efforts are led by a team of seasoned experts in physics, electronics, and software development. Since our founding in July 2013, we have invested significant resources in developing an extensive portfolio of proprietary and differentiated technologies, with a focus on making security screening more precise, much faster, and far less labor intensive. Our products, which incorporate these technologies, offer several key advantages over conventional alternatives.

[0001558370-21-015999:mdna:11]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $8.4 million and $1.5 million for the three months ended September 30, 2021, and 2020, and $16.8 million and $2.8 million for the nine months ended September 30, 2021, and 2020, respectively. We generated net income of $22.8 million and a net loss of $6.3 million for three months ended September 30, 2021, and 2020. We generated a net loss of $13.4 million and of $17.8 million for nine months ended September 30, 2021, and 2020. We expect to continue to incur net losses as we focus on growing commercial sales of our products in both the United States and international markets, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products. Further, with the closing of the Merger, we expect to incur additional costs associated with operating as a public company.

[0001558370-21-015999:mdna:12]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through a combination of equity offerings and debt financings. In July 2021, the Company received gross proceeds of $300.0 million from its PIPE Investment, as well as $84.9 million in proceeds received from the closing of the Merger. However, we may be unable to raise additional funds or enter into such other agreements or arrangements when needed on favorable terms, or at all. If we are unable to raise capital or enter into such agreements as, and when, needed, we may have to significantly delay, scale back or discontinue the further development and commercialization efforts of one or more of our products, or may be forced to reduce or terminate our operations. See “Liquidity and Capital Resources.”

[0001558370-21-015999:mdna:13]
Recent Developments

[0001558370-21-015999:mdna:14]
NewHold Investment Corporation Merger

[0001558370-21-015999:mdna:15]
On July 16, 2021, we completed the previously announced Merger, pursuant to the Agreement and Plan of Merger, dated as of March 5, 2021, and amended by the First Amendment to Agreement and Plan of Merger (the “Merger Agreement”), dated as of June 5, 2021. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. and the officers of NHIC, the predecessor company, resigned. The officers of Legacy Evolv became the officers of the Company, and the Company listed its shares of common stock, par value $0.0001 per share, on Nasdaq under the symbol “EVLV”.

[0001558370-21-015999:mdna:16]
Prior to the completion of the Merger, we entered into subscription agreements (collectively, the “PIPE Investment”) with certain parties subscribing for shares of our common stock (the “Subscribers”) pursuant to which the Subscribers agreed to purchase. Pursuant to the PIPE Investment, we issued 30,000,000 shares of Class A common stock for a purchase price of $10.00 per share with gross proceeds of $300.0 million. The purpose of the PIPE Investment was to fund general corporate expenses.

[0001558370-21-015999:mdna:17]
Upon the closing of the Merger, each share of NHIC Class B common stock issued and outstanding immediately prior to the effective time of the Merger, which totaled 10,391,513 shares held by the NHIC Initial Shareholders (“Initial Shareholders”), was automatically converted into one validly-issued share of our Class A common stock.

[0001558370-21-015999:mdna:18]
In addition, pursuant to the Merger Agreement, certain Legacy Evolv Shareholders became entitled to receive up to 15,000,000 shares of Class A common stock as earn-out shares.

[0001558370-21-015999:mdna:19]
Upon the closing of the Merger:

[0001558370-21-015999:mdna:20]
|  | ● | all of 24,369,613 shares of Legacy Evolv’s Series A-1 convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis; |

[0001558370-21-015999:mdna:21]
|  | ● | all of 3,490,328 shares of Legacy Evolv’s Series A convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a two-to-one basis; |

[0001558370-21-015999:mdna:22]
|  | ● | all of 34,144,109 shares of Legacy Evolv’s Series B-1 convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis; and |

[0001558370-21-015999:mdna:23]
|  | ● | all of 15,373,937 shares of Legacy Evolv’s Series B convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis. |

[0001558370-21-015999:mdna:24]
On the closing date of the Merger, each share of Legacy Evolv common stock then issued and outstanding was cancelled and the holders thereof in exchange received 94,276,850 shares of the Company’s Class A common stock, which is equal to 0.378 newly-issued shares of the Company’s Class A common stock for each share of Legacy Evolv common stock (the “Exchange Ratio”).

[0001558370-21-015999:mdna:25]
All outstanding warrants exercisable for common stock in Legacy Evolv (other than warrants that expired, were exercised or were deemed automatically net exercised immediately prior to the Merger) were exchanged for warrants exercisable for the Company’s Class A common stock with the same terms and conditions except adjusted by the Exchange Ratio.

[0001558370-21-015999:mdna:26]
All outstanding stock options of Legacy Evolv common stock, totaling 58,828,853 stock options, were cancelled and the holders thereof in exchange received options to receive 0.378 newly issued stock options of the Company’s Class A common stock for a total of 22,227,710 shares. The modification of the stock options to reflect the Exchange Ratio did not result in a material incremental compensation expense upon closing of the Merger.

[0001558370-21-015999:mdna:27]
The gross proceeds received from the Merger were $84.9 million and gross proceeds received from the PIPE investment were $300.0 million. Based on the number of shares of common stock outstanding on July 16, 2021 (in each case, not giving effect to any shares issuable upon exercise of warrants, options, or earn-out shares), Legacy Evolv shareholders owned approximately 92.7% of the common stock of the Company and NHIC shareholders owned approximately 7.3%.

[0001558370-21-015999:mdna:28]
The transaction was accounted for as a “reverse recapitalization” and NHIC was treated as the “acquired” company for accounting purposes. Accordingly, for accounting purposes, the Merger was treated as the equivalent of Legacy Evolv issuing shares for the net assets of NHIC, accompanied by a recapitalization. The net assets of NHIC were recorded at historical costs, with no goodwill or other intangible assets recorded. Reported amounts from operations included herein prior to the Merger are those of Legacy Evolv.

[0001558370-21-015999:mdna:29]
Evolv had previously indicated that it would list units (consisting of one share of common stock and one-half of one warrant) on Nasdaq under the ticker symbol EVLVU, in continuation of the listing of the units NHIC sold in its initial public offering on August 4, 2020 under the ticker symbol NHICU. In September 2021, the Company was informed that its transfer agent separated the units into the component shares and warrants at the closing of the Merger, and as a result the Evolv units were not made eligible to settle through the facilities of The Depositary Trust Company. Accordingly, all

[0001558370-21-015999:mdna:30]
trades in the units from July 19, 2021 (the first trading day after the completion of the Merger) until August 24, 2021 were settled between brokers in the shares and warrants underlying the units. Trading in ticker symbol EVLVU was halted on August 24, 2021, and no trades in the units were permitted or occurred since that date. The units were delisted from Nasdaq effective September 10, 2021.

[0001558370-21-015999:mdna:31]
COVID-19

[0001558370-21-015999:mdna:32]
In March 2020, the World Health Organization declared the outbreak of COVID-19 pandemic. It is not possible to accurately predict the full impact of the ongoing COVID-19 pandemic on our business, financial condition and results of operations due to the evolving nature of the COVID-19 pandemic, including variants, and the extent of its impact across industries and geographies and numerous other uncertainties. For example, we face uncertainties about the duration and spread of the outbreak, related governmental advisories and restrictions, the progression and effectiveness of vaccination roll-outs, vaccine hesitancy, and the impact the foregoing may have on the ability of us, our customers, our suppliers, our manufacturers and our other business partners to conduct business. Governments in affected regions have implemented, and may continue to implement, safety precautions which include quarantines, travel restrictions, business closures, cancellations of public gatherings and other measures as they deem necessary. Many organizations and individuals, including our company and employees, are taking additional steps to avoid or reduce infections, including limiting travel and staying home from work. These measures are disrupting normal business operations and have had significant negative impacts on businesses and financial markets worldwide. We continue to monitor our operations and government recommendations and have made modifications to our normal operations because of the COVID-19 pandemic, including requiring most non-engineering or operations-related team members to work remotely, utilizing heightened cleaning and sanitization procedures, implementing new health and safety protocols and reducing non-essential travel.

[0001558370-21-015999:mdna:33]
The COVID-19 pandemic initially caused us to experience several adverse impacts, including extended sales cycles to close new orders for our products because many of our customers were required to completely or partially shut down facilities, delays in shipping and installing orders due to closed facilities and travel limitations and delays in collecting accounts receivable.

[0001558370-21-015999:mdna:34]
As the pandemic shutdown orders began to be relaxed and some segments of our prospective customer set began to formulate and execute their reopening plans, we began to see increased demand for touchless security screening processes of the kind enabled by our products. We also experienced new demand for rapid body temperature screening as part of the pandemic security screening process. In response to customer requests, we brought to market the Evolv Thermal Imaging Package™ for Evolv Express®™, a new add-on product developed in approximately 90 days during the pandemic lockdown. While ongoing demand for this product is uncertain, we believe our ability to integrate thermal screening into our product in a compressed time frame is an indicator of our innovation capabilities and of the potential for new future add-on products based on additional sensors and data types.

[0001558370-21-015999:mdna:35]
The rapid development and uncertainty of the impacts of the COVID-19 pandemic precludes any prediction as to the ultimate impact of the COVID-19 pandemic on our business. However, the COVID-19 pandemic, and the measures taken to contain it, continue to present material uncertainty and risk with respect to our performance and financial results. In particular, venues and facilities across an array of vertical markets are temporarily reducing capital expenditure budgets globally as they seek to preserve liquidity to ensure the longevity of their own operations, which in turn may lead to reductions in purchases of our security screening products. Further, office closures may prevent organizations from reaching typical utilizations of our security screening products, resulting in reductions in purchases of add-on products and expansion units. Additionally, the COVID-19 pandemic may contribute to facility closures at our third-party contract manufacturer and key suppliers, causing delays and disruptions in product manufacturing, which could affect our ability to ship products purchased by our customers in a timely manner. Disruptions in the capital markets as a result of the COVID-19 pandemic may also adversely affect our business if these impacts continue for a prolonged period and we need additional liquidity.

[0001558370-21-015999:mdna:36]
In the short-term, we have taken, and will continue to take, actions to mitigate the impact of the COVID-19 pandemic on our cash flow and results of operations and financial condition. While we are experiencing supply chain challenges, we do see this being overcome in the near future. In the long-term, we believe that the COVID-19 pandemic

[0001558370-21-015999:mdna:37]
will encourage organizations to reassess their security screening processes and may continue to accelerate their adoption of solutions such as touchless security screening, which could create additional demand for our products.

[0001558370-21-015999:mdna:38]
Additional information regarding COVID-19 risks appears in the “Risk Factors” section of our Prospectus.

[0001558370-21-015999:mdna:39]
Key Factors Affecting Our Operating Results

[0001558370-21-015999:mdna:40]
We believe that our performance and future success depend on many factors that present significant opportunities for us but also pose risks and challenges, including the following:

[0001558370-21-015999:mdna:41]
Contingent Earn-out Shares

[0001558370-21-015999:mdna:42]
In connection with the Merger and pursuant to the Merger Agreement, certain of the Legacy Evolv’s shareholders and Legacy Evolv service providers are entitled to receive additional shares of the Company’s Class A common stock (the “Earn-Out Shares”) upon the Company achieving certain milestones:

[0001558370-21-015999:mdna:43]
|  | ● | Triggering Event I – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within the Earn-Out Period, the price of the Company’s Class A common stock is greater than $12.50 per share for any 20 trading days within any 30 trading day period. |

[0001558370-21-015999:mdna:44]
|  | ● | Triggering Event II – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within the Earn-Out Period, the price of the Company’s Class A common stock is greater than $15.00 per share for any 20 trading days within any 30 trading day period. |

[0001558370-21-015999:mdna:45]
|  | ● | Triggering Event III – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within the Earn-Out Period, the price of the Company’s Class A common stock is greater than $17.50 per share for any 20 trading days within any 30 trading day period. |

[0001558370-21-015999:mdna:46]
The Earn-Out Shares issued to Legacy Evolv (“Contingent Earn-out”) shareholders have been classified as liabilities in the consolidated balance sheets as of September 30, 2021 and will be initially measured at fair value and remeasured subsequently in each reporting period. The change in fair value of the contingent earn-out will be recorded in other income (expense), net in the consolidated statements of operations and comprehensive income (loss). When the Triggering Events have been achieved and the Earn-Out Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001558370-21-015999:mdna:47]
The Earn-Out Shares issued to employees, officers, directors, and non-employees subject to continued employment and achievement of certain target share price contingencies (the “Earn-Out Service Providers”) represents share-based compensation and is classified as equity on the Company’s balance sheet. Corresponding stock-based compensation expense is recorded in the consolidated statements of operations and comprehensive income (loss) in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified.

[0001558370-21-015999:mdna:48]
The estimated fair value of the contingent earn-out shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, drift rate, percentage of change in control and expected term.

[0001558370-21-015999:mdna:49]
Contingent earn-out payments involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001558370-21-015999:mdna:50]
Contingently Issuable Common Stock

[0001558370-21-015999:mdna:51]
Prior to the Merger, NewHold Industrial Technology Holdings, LLC, the sponsor of the NHIC special purpose acquisition company  owned 4,312,500 shares of NHIC Class B common stock (the “Founder Shares”). Upon the closing of the Merger, NHIC Class A and Class B common stock became the company’s common stock. The Founder Shares outstanding were subject to certain share-performance-based vesting provisions as follows:

[0001558370-21-015999:mdna:52]
|  | ● | Vesting Provision I - 1,897,500 shares of the Company’s common stock shall vest and no longer be subject to forfeiture as of the Merger; |

[0001558370-21-015999:mdna:53]
|  | ● | Vesting Provision II - if within 5 years after the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $12.50 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30 trading day period, then 948,750 shares of the Company’s Class B common stock shall vest and no longer be subject to forfeiture; |

[0001558370-21-015999:mdna:54]
|  | ● | Vesting Provision III - if within 5 years after the closing of the Merger, the last reported sale price of the common stock equals or exceeds $15.00 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30-trading day period, then 948,750 shares of the Company’s Class B common stock) shall vest and no longer be subject to forfeiture. |

[0001558370-21-015999:mdna:55]
If Vesting Provision II and/or Vesting Provision III are not satisfied, the corresponding number of shares specified shall be forfeited and no longer issued and outstanding. If there is a Change of Control event prior to Vesting Provision II and/or Vesting Provision III are satisfied, the Founder shares are no longer subject to forfeiture and shall vest immediately upon the occurrence of a Change of Control event.

[0001558370-21-015999:mdna:56]
The contingently issuable common shares with the NHIC shareholders have been classified as liabilities in the consolidated balance sheets as of September 30, 2021 and will be initially measured at fair value and remeasured subsequently in each reporting period. The change in fair value of the contingently issuable common shares will be recorded in other income (expense), net in the consolidated statements of operations and comprehensive income (loss).

[0001558370-21-015999:mdna:57]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, and risk-free rate.

[0001558370-21-015999:mdna:58]
Contingently issuable common shares involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001558370-21-015999:mdna:59]
Adoption of our Security Screening Products

[0001558370-21-015999:mdna:60]
We believe the world will continue to focus on the safety and security of people in the places where they gather. Many of these locations are moving toward a more frictionless security screening experience. We believe that we are well-positioned to take advantage of this opportunity due to our proprietary technologies and global distribution capabilities. Our products are designed to empower venues and facilities to realize the full benefits of touchless security screening, including a rapid visitor throughput and minimal security staff to screened visitor physical contact. We expect that our results of operations, including revenue, will fluctuate for the foreseeable future as venues and facilities continue to shift away from conventional security screening processes towards touchless security screening. The degree to which potential and current customers recognize these benefits and invest in our products will affect our financial results.

[0001558370-21-015999:mdna:61]
Pricing, Product Cost and Margins

[0001558370-21-015999:mdna:62]
To date, most of our revenue has been generated by sales of products which represented 63.9 % and 23.9% in the three months ended September 30, 2021 and 2020, respectively, and 61.1% and 15.3% in the nine months ended September 30, 2021 and 2020, respectively. The remaining revenue was generated from subscription sales and service for

[0001558370-21-015999:mdna:63]
our products. Going forward, we expect to sell our products in a variety of vertical industry markets and geographic regions. We also expect sales of subscriptions to become a greater portion of our revenue. Pricing may vary by region due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales/bookings/business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce cost-effective touchless security screening products for our customers.

[0001558370-21-015999:mdna:64]
Continued Investment and Innovation

[0001558370-21-015999:mdna:65]
We believe that we are a leader in touchless security screening products, offering transformative technologies that enable higher throughput, a more frictionless visitor experience, and substantial cost savings through our product innovations. Our performance is significantly dependent on the investment we make in our research and development efforts and on our ability to be at the forefront of the security screening industry. It is essential that we continually identify and respond to rapidly evolving customer requirements, develop and introduce innovative new products, enhance existing products and generate customer demand for our products. We believe that investment in our security screening products will contribute to long-term revenue growth, but it may adversely affect our near-term profitability.

[0001558370-21-015999:mdna:66]
Components of Results of Operations

[0001558370-21-015999:mdna:67]
Revenue

[0001558370-21-015999:mdna:68]
We derive revenue from (1) subscription arrangements accounted for as operating leases under ASC 840 and (2) from the sale of products, inclusive of maintenance and services. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001558370-21-015999:mdna:69]
Product Revenue

[0001558370-21-015999:mdna:70]
We derive revenue from the sale of our Express and Edge equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer. Transfer of control occurs when we have transferred title and risk of loss and have a present right to payment for the equipment, which is generally upon delivery as our normal terms of sale are freight on board destination. Products are predominately sold with distinct services which are described in the services section below.

[0001558370-21-015999:mdna:71]
Subscription Revenue

[0001558370-21-015999:mdna:72]
In addition to selling our products directly to customers, we also lease our Express and Edge equipment. These arrangements convey the right to use the equipment for a period of time in exchange for consideration and therefore are accounted for under ASC 840 due to the scope exception of ASC 606-10-15-2. Lease terms are typically four years and customers pay either a quarterly or annual fixed payment for the lease and maintenance elements over the contractual lease term. In accordance with ASC 840, Leases, we consider only the fixed payments for purposes of allocating between the lease and non-lease deliverables on a relative fair value basis. Equipment leases are classified as operating leases as they do not meet any of the capital lease criteria per ASC 840.

[0001558370-21-015999:mdna:73]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (i) distinct services, such as installation, training and maintenance, and (ii) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern and because revenue allocated to maintenance components is not material, the equipment lease and maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations.

[0001558370-21-015999:mdna:74]
As our leases with customers are classified as operating leases, lease revenue is recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001558370-21-015999:mdna:75]
Services Revenue

[0001558370-21-015999:mdna:76]
We provide installation, training and maintenance services for our products. Revenue for installation and training are recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes and when-and-if available threat updates. Maintenance revenue is recognized ratably over the period of the arrangement. We sell separately priced extended or nonstandard warranty services and preventative maintenance plans, which are recognized ratably over the associated service period.

[0001558370-21-015999:mdna:77]
Cost of Revenue

[0001558370-21-015999:mdna:78]
We recognize cost of revenues in the same manner that the related revenue is recognized.

[0001558370-21-015999:mdna:79]
Cost of Product Revenue

[0001558370-21-015999:mdna:80]
Cost of product revenue consists primarily of costs paid to third party manufacturers, labor costs, and shipping costs.

[0001558370-21-015999:mdna:81]
Cost of Subscription Revenue

[0001558370-21-015999:mdna:82]
Cost of subscription revenue consists primarily of labor costs, shipping costs, and depreciation related to leased units.

[0001558370-21-015999:mdna:83]
Cost of Services Revenue

[0001558370-21-015999:mdna:84]
Cost of services revenue consists primarily of labor, spare parts, shipping costs, and field service repair costs. Cost of services revenue related to maintenance consists primarily of labor, spare parts, shipping costs, field service repair costs, equipment, and supplies.

[0001558370-21-015999:mdna:85]
A provision for the estimated cost related to warranty is recorded to cost of revenue at the time revenue is recognized as necessary. Our estimate of costs to service the warranty obligations is based on historical experience and expectations of future conditions. As of September 30, 2021, and December 31, 2020, we recorded a warranty accrual of less than $0.1 million.

[0001558370-21-015999:mdna:86]
Gross Profit and Gross Margin

[0001558370-21-015999:mdna:87]
Our gross profit is calculated based on the difference between our revenues and cost of revenues. Gross margin is the percentage obtained by dividing gross profit by our revenue. Our gross profit and gross margin are, or may be, influenced by a number of factors, including:

[0001558370-21-015999:mdna:88]
|  | ● | Market conditions that may impact our pricing; |

[0001558370-21-015999:mdna:89]
|  | ● | Product mix changes between established products and new products; |

[0001558370-21-015999:mdna:90]
|  | ● | Our cost structure for manufacturing operations, including contract manufacturers, relative to volume, and our product support obligations; and |

[0001558370-21-015999:mdna:91]
|  | ● | Our ability to maintain our costs on the components that go into the manufacture of our product. |

[0001558370-21-015999:mdna:92]
We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001558370-21-015999:mdna:93]
Research and Development

[0001558370-21-015999:mdna:94]
Our research and development expenses represent costs incurred to support activities that advance the development of innovative security screening technologies, new product platforms, as well as activities that enhance the capabilities of our existing product platforms. Our research and development expenses consist primarily of salaries and bonuses, employee benefits, prototypes, design expenses, consulting and contractor costs and an allocated portion of overhead costs. We expect research and development costs will increase on an absolute dollar basis over time as we continue to invest in advancing our portfolio of security screening products.

[0001558370-21-015999:mdna:95]
Sales and Marketing

[0001558370-21-015999:mdna:96]
Sales and marketing expenses consist primarily of employee-related costs for individuals working in our sales and marketing departments, costs related to trade shows and events and an allocated portion of overhead costs. We expect our sales and marketing costs will increase on an absolute dollar basis as we expand our headcount and initiate new marketing campaigns.

[0001558370-21-015999:mdna:97]
General and Administrative

[0001558370-21-015999:mdna:98]
General and administrative expenses consist primarily of personnel-related expenses associated with our executive, finance, legal, information technology and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, and an allocated portion of overhead costs. We expect our general and administrative expenses will increase on an absolute dollar basis as a result of operating as a public company, including expenses necessary to comply with the rules and regulations applicable to companies listed on a national securities exchange and related to compliance and reporting obligations pursuant to the rules and regulations of the SEC, as well as increased expenses for general and director and officer insurance, investor relations, and other administrative and professional services. In addition, we expect to incur additional costs as we hire additional personnel and enhance our infrastructure to support the anticipated growth of the business.

[0001558370-21-015999:mdna:99]
Loss From Impairment of Property and Equipment

[0001558370-21-015999:mdna:100]
Impairment of property and equipment relates to any units that are removed from service and retired. This is related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of these assets and resulted in impairment.

[0001558370-21-015999:mdna:101]
Interest Expense

[0001558370-21-015999:mdna:102]
Interest expense includes cash interest paid on our long-term debt as well as amortization of deferred financing fees and costs.

[0001558370-21-015999:mdna:103]
Other Expense

[0001558370-21-015999:mdna:104]
Other expense includes loss on disposals of our property and equipment.

[0001558370-21-015999:mdna:105]
Loss on Extinguishment of Debt

[0001558370-21-015999:mdna:106]
There was a modification of the 2021 Convertible Notes due to an agreement with noteholders to receive an additional 1,000,000 shares of NHIC common stock as further consideration for the conversion of such notes consistent with the terms thereof, and interest due to each investor would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. This modification of the 2021 Convertible Notes was accounted for as an extinguishment.

[0001558370-21-015999:mdna:107]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the Convertible Notes also received the right to receive 1,000,000 shares of

[0001558370-21-015999:mdna:108]
NHIC common stock. Upon the conversion of the Convertible Notes, the carrying value of the debt, including unamortized debt discount, and the related derivative liability and accrued interest were derecognized. The shares of common stock issued upon conversion of Convertible Notes were recorded at implied fair value of the Company’s common stock with the resulting difference being accounted for as a loss on extinguishment.

[0001558370-21-015999:mdna:109]
Change in Fair Value of Derivative Liability

[0001558370-21-015999:mdna:110]
In August through September 2019 and in September 2020, the Company issued Convertible Notes to several investors (the “2020 Convertible Notes”) that provided a conversion option whereby upon the closing of a specified financing event the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 85% and 80%, respectively, of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative that was required to be bifurcated and accounted for separately from the notes. The derivative liability was initially recorded at fair value upon issuance of the notes and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the derivative liability are recognized in the consolidated statements of operations and comprehensive loss. In October 2019, the specified financing event was consummated, as such the 2020 Convertible Notes issued August through September 2019 were converted into shares of Series B-1 Preferred Stock and the derivative liability was extinguished. The derivative liability related to the 2020 Convertible Notes convertible note is outstanding as of September 30, 2021 and is included as a derivative liability in the consolidated balance sheet.

[0001558370-21-015999:mdna:111]
Between January 21, 2021 and February 4, 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method.

[0001558370-21-015999:mdna:112]
On June 21, 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. The modification of the 2021 Convertible Notes resulted in the recognition of a derivative liability for the fair value of the 1,000,000 NHIC shares as of June 21, 2021 as well as a bifurcated embedded derivative for conversion feature into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors.

[0001558370-21-015999:mdna:113]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense) in the consolidated statements of operations and comprehensive income (loss).

[0001558370-21-015999:mdna:114]
Change in Fair Value of Contingent Earn-out Liability

[0001558370-21-015999:mdna:115]
In connection with the Merger and pursuant to the Merger Agreement, certain of Legacy Evolv’s initial shareholders are entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones. The earn-out arrangement with the Legacy Evolv Shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive income (loss).

[0001558370-21-015999:mdna:116]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001558370-21-015999:mdna:117]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 shares of Founder Shares. 1,897,500 shares vested at the closing of the Merger and the remaining 1,897,500 outstanding shares shall vest upon the Company achieving certain milestones. Those outstanding contingently issuable common shares are accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a component of other income (expense), net in the consolidated statements of operations and comprehensive income (loss).

[0001558370-21-015999:mdna:118]
Change in Fair Value of Public Warrant Liability

[0001558370-21-015999:mdna:119]
In connection with the closing of the Merger, the Company assumed a warrant to purchase shares of common stock (the “Public Warrant”) and is classified as a liability. As of September 30, 2021, the Public Warrant is outstanding. The Company assessed the features of these warrants and determined that they qualify for classification as permanent equity. Accordingly, the Company recorded the warrants to fair value upon the closing of Merger with the offset to additional paid-in capital.

[0001558370-21-015999:mdna:120]
Change in Fair Value of Common Stock Warrant Liability

[0001558370-21-015999:mdna:121]
The Company classifies certain warrants for the purchase of shares of its common stock as a liability on its consolidated balance sheets as these warrants are freestanding financial instruments that may require the Company to adjust the exercise price and number of shares that is not consistent with a fixed-for-fixed option pricing model. The warrant liability is initially recorded at fair value on the issuance date of each warrant and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the common stock warrant liability are recognized as a component of other income (expense) in the consolidated statements of operations and comprehensive income (loss). Changes in the fair value of the common stock warrant liability will continue to be recognized until the warrants are exercised, expire or qualify for equity classification.

[0001558370-21-015999:mdna:122]
Income Taxes

[0001558370-21-015999:mdna:123]
Our income tax provision consists of an estimate for U.S. federal and state income taxes based on enacted rates, as adjusted for allowable credits, deductions, uncertain tax positions, changes in deferred tax assets and liabilities and changes in tax law. There is no provision for income taxes for the three months ended September 30, 2021, and 2020, and for the nine months ended September 30, 2021, and 2020 because Evolv has historically incurred net operating losses and maintains a full valuation allowance against its deferred tax assets.

[0001558370-21-015999:mdna:124]
Results of Operations

[0001558370-21-015999:mdna:125]
Comparison of the Three Months ended September 30, 2021 and 2020

[0001558370-21-015999:mdna:126]
The following table summarizes our results of operations for the three months ended September 30, 2021 and 2020, (in thousands):

[0001558370-21-015999:mdna:127]
| ​ | ​ | Three Months Ended September 30, | ​ | ​ | ​ |
| ​ | ​ | 2021 |  | 2020 | ​ | Change |
| Revenue: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| Product revenue | ​ | $ | 5,345 | ​ | $ | 349 | ​ | $ | 4,996 |
| Subscription revenue | ​ |  | 2,305 | ​ |  | 794 | ​ |  | 1,511 |
| Service revenue | ​ |  | 717 | ​ |  | 318 | ​ |  | 399 |
| Total revenue | ​ |  | 8,367 | ​ |  | 1,461 | ​ |  | 6,906 |
| Cost of revenues: | ​ |  |  | ​ |  |  | ​ |  | ​ |
| Cost of product revenue | ​ |  | 2,933 | ​ |  | 163 | ​ |  | 2,770 |
| Cost of subscription revenue | ​ |  | 1,086 | ​ |  | 490 | ​ |  | 596 |
| Cost of service revenue | ​ |  | 192 | ​ |  | 169 | ​ |  | 23 |
| Total cost of revenue | ​ |  | 4,211 | ​ |  | 822 | ​ |  | 3,389 |
| Gross profit | ​ |  | 4,156 | ​ |  | 639 | ​ |  | 3,517 |
| Operating expenses: | ​ |  |  | ​ |  |  | ​ |  | ​ |
| Research and development | ​ |  | 3,641 | ​ |  | 4,088 | ​ |  | (447) |
| Sales and marketing | ​ |  | 8,510 | ​ |  | 1,552 | ​ |  | 6,958 |
| General and administrative | ​ |  | 6,983 | ​ |  | 1,177 | ​ |  | 5,806 |
| Loss from impairment of property and equipment | ​ | ​ | 1,656 | ​ | ​ | — | ​ | ​ | 1,656 |
| Total operating expenses | ​ |  | 20,790 | ​ |  | 6,817 | ​ |  | 13,973 |
| Loss from operations | ​ |  | (16,634) | ​ |  | (6,178) | ​ |  | (10,456) |
| Other income (expense), net: | ​ |  |  | ​ |  |  | ​ |  | ​ |
| Interest expense | ​ |  | (286) | ​ |  | (84) | ​ |  | (202) |
| Other expense, net | ​ |  | (669) | ​ |  | — | ​ |  | (669) |
| Loss on extinguishment of debt | ​ |  | (865) | ​ |  | — | ​ |  | (865) |
| Change in fair value of derivative liability | ​ | ​ | 475 | ​ | ​ | — | ​ | ​ | 475 |
| Change in fair value of contingent earn-out liability | ​ |  | 31,818 | ​ |  | — | ​ |  | 31,818 |
| Change in fair value of contingently issuable common stock liability | ​ |  | 5,718 | ​ |  | — | ​ |  | 5,718 |
| Change in fair value of public warrant liability | ​ | ​ | 3,152 | ​ | ​ | — | ​ | ​ | 3,152 |
| Change in fair value of common stock warrant liability | ​ | ​ | 42 | ​ | ​ | — | ​ | ​ | 42 |
| Total other income (expense), net | ​ |  | 39,385 | ​ |  | (84) | ​ |  | 39,469 |
| Net income (loss) | ​ | $ | 22,751 | ​ | $ | (6,262) | ​ | $ | 29,013 |

[0001558370-21-015999:mdna:128]
Revenue, Cost of Revenue and Gross Profit

[0001558370-21-015999:mdna:129]
Product

[0001558370-21-015999:mdna:130]
Product revenue was $5.3 million for the three months ended September 30, 2021, compared to $0.3 million for the three months ended September 30, 2020. Cost of product revenue was $3.0 million for the three months ended September 30, 2021, compared to $0.2 million for the three months ended September 30, 2020. The increase of $5.0 million in revenue and increase of $2.8 million in cost of revenue for the three months ended September 30, 2021 compared to 2020 was primarily due to increases in direct product sales of Evolv Express and Evolv Edge. Gross profit increased by $2.2 million for the three months ended September 30, 2021 compared to 2020, or 1,196%, and gross profit margin decreased by 8%.

[0001558370-21-015999:mdna:131]
The increase in gross profit is primarily driven by our increased product revenue. The decrease in gross profit margin is primarily driven by an increase of $0.4 million of shipping costs as well as a write-off of unused Edge materials

[0001558370-21-015999:mdna:132]
of $0.4 million. We will see improvement in our gross margins as we continue to engineer our product with lower cost components and as we continue to gain leverage in the marketplace with increased sales, we expect higher discounts from suppliers.

[0001558370-21-015999:mdna:133]
Subscription

[0001558370-21-015999:mdna:134]
Subscription revenue was $2.3 million for the three months ended September 30, 2021, compared to $0.8 million for the three months ended September 30, 2020. Cost of subscription revenue was $1.1 million for the three months ended September 30, 2021, compared to $0.5 million for the three months ended September 30, 2020. The increase of $1.5 million in revenue and increase of $0.6 million in cost of revenue for the three months ended September 30, 2021 compared to 2020 was primarily due to a larger install base of Evolv Express units during the period. Gross profit increased by $0.9 million, or 301%, and gross profit margin increased by 15%.

[0001558370-21-015999:mdna:135]
The increase in gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin was primarily driven by our continued efforts to streamline the manufacturing process and reduce costs by introducing standardized parts into our units.

[0001558370-21-015999:mdna:136]
Services

[0001558370-21-015999:mdna:137]
Service revenue was $0.7 million for the three months ended September 30, 2021, compared to $0.3 million for the three months ended September 30, 2020. Cost of service revenue was $0.2 million for the three months ended September 30, 2021, compared to $0.2 million for the three months ended September 30, 2020. The increase of $0.4 million in service revenue for three months ended September 30, 2021 was primarily due to increased installation and training related to the Evolv Express product. Gross profit increased by $0.4 million, or 252%, and gross profit margin increased by 26%. The increase in gross profit is due to an increase in installations and training services from an increase in units sold or leased. The increase in gross profit margin is primarily driven by standardization of the installation and training process, which results in overall lower costs.

[0001558370-21-015999:mdna:138]
Research and Development Expenses

[0001558370-21-015999:mdna:139]
Research and development expenses were $3.6 million for the three months ended September 30, 2021, compared to $4.1 million for the three months ended September 30, 2020. The decrease of $0.5 million was primarily due to a decrease in research and development and prototype costs of $2.3 million and a decrease in professional fees of $0.2 million, partially offset by an increase in employee-related expenses of $2.1 million. The decrease in research and development and prototype costs is due to the transition from prototype production to standard manufacturing of the Evolv Express, which results in lower prototyping costs. The decrease in professional fees is due to a decrease in consulting fees during the three months ended September 30, 2021. The increase in employee-related expenses is due to increased wages and benefits expenses due to additional headcount and stock compensation.

[0001558370-21-015999:mdna:140]
Sales and Marketing Expenses

[0001558370-21-015999:mdna:141]
Sales and marketing expenses were $8.5 million for the three months ended September 30, 2021, compared to $1.6 million for the three months ended September 30, 2020. The increase of $6.9 million was primarily due to an increase of $4.3 million in employee-related expenses, $1.4 million in direct marketing, $0.4 million of travel expenses, $0.2 million in customer field services, and $0.2 million in professional fees. The increase in employee-related expenses is due to additional commissions and personnel costs resulting from additional headcount in our sales function and stock compensation. The increase in direct marketing is due to increased trade shows and events. The increase in travel expenses in 2021 is due an increase in travel costs for sales personnel meetings and events. The increase in customer field services is due to increased sales volume. The increase in professional fees is related to increased consulting on ways to maximize sales and business development.

[0001558370-21-015999:mdna:142]
General and Administrative Expenses

[0001558370-21-015999:mdna:143]
General and administrative expenses were $7.0 million for the three months ended September 30, 2021, compared to $1.2 million for the three months ended September 30, 2020. The increase of $5.8 million was primarily due to an increase in employee-related expenses of $2.7 million, $2.0 million in professional fees, and an increase in miscellaneous expense of $0.9 million. The increase in employee-related expenses is due to an increase in salaries and related costs as a result of expanding our administrative team and stock compensation. The increase in professional fees is primarily due to an increase in audit, tax, and legal services to the Company. The increase in miscellaneous expense is primarily due to an increase in business insurance.

[0001558370-21-015999:mdna:144]
Loss From Impairment of Property and Equipment

[0001558370-21-015999:mdna:145]
Impairment of property and equipment was $1.7 million for the three months ended September 30, 2021. There was no impairment for the three months ended September 30, 2020. This is related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of the Edge assets and resulted in impairment.

[0001558370-21-015999:mdna:146]
Interest Expense

[0001558370-21-015999:mdna:147]
Interest expense was $0.3 million for the three months ended September 30, 2021, compared to $0.1 million for the three months ended September 30, 2020. The increase of $0.2 million was primarily due to the interest on the Convertible Notes during the three months ended September 30, 2021 which did not exist in 2020. The Convertible Notes converted to the Company’s stock upon closing of the Merger.

[0001558370-21-015999:mdna:148]
Other Expense

[0001558370-21-015999:mdna:149]
Other expense was $0.7 million for the three months ended September 30, 2021, compared to $0 for the three months ended September 30, 2020. The increase of $0.7 million was primarily due to the loss on disposal of non-leased assets, primarily related to demo units, during the three months ended September 30, 2021.

[0001558370-21-015999:mdna:150]
Loss on Extinguishment of Debt

[0001558370-21-015999:mdna:151]
Loss on extinguishment of debt was $0.9 million for the three months ended September 30, 2021. This was due to the conversion of the 2021 Convertible Notes into shares of the Company’s stock upon closing of the Merger.

[0001558370-21-015999:mdna:152]
Change in Fair Value of Derivative Liability

[0001558370-21-015999:mdna:153]
Change in the fair value of the derivative liability was $0.5 million for the three months ended September 30, 2021. This was primarily due the settlement of the derivative liability upon the closing of the Merger.

[0001558370-21-015999:mdna:154]
Change in Fair Value of Contingent Earn-out Liability

[0001558370-21-015999:mdna:155]
Change in the fair value of the contingent earn-out liability was $31.8 million for the three months ended September 30, 2021. This was primarily due to the issuance of the contingent earn-out liability upon the closing of the Merger and mark to market fluctuations during the period driven by a decrease in stock price.

[0001558370-21-015999:mdna:156]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001558370-21-015999:mdna:157]
Change in the fair value of the contingently issuable common stock liability was $5.7 million for the three months ended September 30, 2021. This was primarily due to the issuance of the contingently issuable common stock liability upon the closing of the Merger and mark to market fluctuations during the period driven by a decrease in stock price.

[0001558370-21-015999:mdna:158]
Change in Fair Value of Public Warrant Liability

[0001558370-21-015999:mdna:159]
Change in the fair value of the public warrant liability was $3.2 million for the three months ended September 30, 2021. This was primarily due to the issuance of the public warrant liability upon the closing of the Merger and mark to market fluctuations during the period driven by a decrease in the publicly traded warrant price.

[0001558370-21-015999:mdna:160]
Change in Fair Value of Common Stock Warrant Liability

[0001558370-21-015999:mdna:161]
Change in the fair value of the common stock warrant liability was less than $0.1 million for the three months ended September 30, 2021. This was primarily due to the conversion of the common stock warrant liability upon the closing of the Merger and mark to market fluctuations prior to the closing of the Merger.

[0001558370-21-015999:mdna:162]
Comparison of the Nine Months Ended September 30, 2021 and 2020

[0001558370-21-015999:mdna:163]
The following table summarizes our results of operations for the nine months ended September 30, 2021 and 2020 (in thousands):

[0001558370-21-015999:mdna:164]
| ​ | ​ | Nine Months Ended September 30, | ​ | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 | ​ | Change |
| Revenue: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| Product revenue | ​ | $ | 10,299 | ​ | $ | 422 | ​ | $ | 9,877 |
| Subscription revenue | ​ |  | 5,118 | ​ |  | 1,743 | ​ |  | 3,375 |
| Service revenue | ​ |  | 1,429 | ​ |  | 585 | ​ |  | 844 |
| Total revenue | ​ |  | 16,846 | ​ |  | 2,750 | ​ |  | 14,096 |
| Cost of revenues: | ​ |  |  | ​ |  |  | ​ |  | ​ |
| Cost of product revenue | ​ |  | 7,237 | ​ |  | 361 | ​ |  | 6,876 |
| Cost of subscription revenue | ​ |  | 2,542 | ​ |  | 1,192 | ​ |  | 1,350 |
| Cost of service revenue | ​ |  | 732 | ​ |  | 376 | ​ |  | 356 |
| Total cost of revenue | ​ |  | 10,511 | ​ |  | 1,929 | ​ |  | 8,582 |
| Gross profit | ​ |  | 6,335 | ​ |  | 821 | ​ |  | 5,514 |
| Operating expenses: | ​ |  |  | ​ |  |  | ​ |  | ​ |
| Research and development | ​ |  | 8,330 | ​ |  | 10,629 | ​ |  | (2,299) |
| Sales and marketing | ​ |  | 17,284 | ​ |  | 5,105 | ​ |  | 12,179 |
| General and administrative | ​ |  | 11,162 | ​ |  | 2,676 | ​ |  | 8,486 |
| Loss from impairment of property and equipment | ​ | ​ | 1,656 | ​ | ​ | — | ​ | ​ | 1,656 |
| Total operating expenses | ​ |  | 38,432 | ​ |  | 18,410 | ​ |  | 20,022 |
| Loss from operations | ​ |  | (32,097) | ​ |  | (17,589) | ​ |  | (14,508) |
| Other income (expense), net: | ​ |  |  | ​ |  |  | ​ |  | ​ |
| Interest expense | ​ |  | (5,988) | ​ |  | (207) | ​ |  | (5,781) |
| Other expense, net | ​ |  | (669) | ​ |  | — | ​ |  | (669) |
| Loss on extinguishment of debt | ​ |  | (12,685) | ​ |  | — | ​ |  | (12,685) |
| Change in fair value of derivative liability | ​ | ​ | (1,745) | ​ | ​ | — | ​ | ​ | (1,745) |
| Change in fair value of contingent earn-out liability | ​ |  | 31,818 | ​ |  | — | ​ |  | 31,818 |
| Change in fair value of contingently issuable common stock liability | ​ |  | 5,718 | ​ |  | — | ​ |  | 5,718 |
| Change in fair value of public warrant liability | ​ | ​ | 3,152 | ​ | ​ | — | ​ | ​ | 3,152 |
| Change in fair value of common stock warrant liability | ​ | ​ | (879) | ​ | ​ | — | ​ | ​ | (879) |
| Total other income (expense), net | ​ |  | 18,722 | ​ |  | (207) | ​ |  | 18,929 |
| Net loss | ​ | $ | (13,375) | ​ | $ | (17,796) | ​ | $ | 4,421 |

[0001558370-21-015999:mdna:165]
Revenue, Cost of Revenue and Gross Profit

[0001558370-21-015999:mdna:166]
Product

[0001558370-21-015999:mdna:167]
Product revenue was $10.3 million for the nine months ended September 30, 2021, compared to $0.4 million for the nine months ended September 30, 2020. Cost of product revenue was $7.2 million for the nine months ended September 30, 2021, compared to $0.4 million for the nine months ended September 30, 2020. The increase of $9.9 million in revenue and increase of $6.8 million in cost of revenue for the nine months ended September 30, 2021 compared to 2020 was primarily due to increases in direct product sales of Evolv Edge and Express Units. Gross profit increased by $3.0 million for the nine months ended September 2021, compared to 2020, or 4,920%, and gross profit margin increased by 15%.

[0001558370-21-015999:mdna:168]
The increase in gross profit is primarily driven by our increased product sales and our continued efforts to streamline the manufacturing process and reduce costs by introducing standardized parts into our product, which was partially offset by an increase of $0.6 million in shipping costs. We expect to continue to see improvement in our gross margins as we continue to engineer our product with lower cost components. As we continue to gain leverage in the marketplace with increased sales, we expect higher discounts from suppliers.

[0001558370-21-015999:mdna:169]
Subscription

[0001558370-21-015999:mdna:170]
Subscription revenue was $5.1 million for the nine months ended September 30, 2021, compared to $1.7 million for the nine months ended September 30, 2020. Cost of subscription revenue was $2.5 million for the nine months ended September 30, 2021, compared to $1.2 million for the nine months ended September 30, 2020. The increase of $3.4 million in revenue and increase of $1.4 million in cost of revenue for the nine months ended September 30, 2021 compared to 2020 was primarily due to a larger install base of Evolv Express units during the period. Gross profit increased by $2.0 million, or 368%, and gross profit margin increased by 19% for the nine months ended September 30, 2021 compared to 2020.

[0001558370-21-015999:mdna:171]
The increase in gross profit is primarily driven by our increased subscription revenue. The increase in gross profit margin was primarily driven by our continued efforts to streamline the manufacturing process and reduce costs by introducing standardized parts into our units.

[0001558370-21-015999:mdna:172]
Service

[0001558370-21-015999:mdna:173]
Service revenue was $1.4 million for the nine months ended September 30, 2021, compared to $0.6 million for the nine months ended September 30, 2020. Cost of service revenue was $0.7 million for the nine months ended September 30, 2021, compared to $0.4 million for the nine months ended September 30, 2020. The increase of $0.8 million in service revenue and increase of $0.4 million in cost of revenue for the nine months ended September 30, 2021 compared to 2020 was primarily due to increased installation and training related to the Evolv Express product. Gross profit increased by $0.5 million, or 233%, and gross profit margin increased by 13% for the nine months ended September 30, 2021 compared to September 30, 2020. The increase in gross profit is primarily driven by standardization of the installation and training process, which results in overall lower costs.

[0001558370-21-015999:mdna:174]
Research and Development Expenses

[0001558370-21-015999:mdna:175]
Research and development expenses were $8.3 million for the nine months ended September 30, 2021, compared to $10.6 million for the nine months ended September 30, 2020. The decrease of $2.3 million was primarily due to a decrease in research and development and prototype cost of $3.8 million and a decrease in professional fees of $1.4 million, partially offset by an increase in employee-related expenses of $2.9 million during nine months ended September 30, 2021 compared to 2020. The decrease in research and development prototype cost is due to Evolv Express units being manufactured by a third-party manufacturer. The decrease in professional fees is due to a decrease in consulting fees related to research and development efforts for prototype units. The increase in employee-related expenses is due to increased wages and benefits expense due to additional headcount and stock compensation.

[0001558370-21-015999:mdna:176]
Sales and Marketing Expenses

[0001558370-21-015999:mdna:177]
Sales and marketing expenses were $17.3 million for the nine months ended September 30, 2021, compared to $5.1 million for the nine months ended September 30, 2020. The increase of $12.2 million was primarily due to an increase of $7.9 million in employee-related expenses, an increase of $2.2 million in direct marketing, an increase of $0.6 million of travel and entertainment, an increase of $0.7 million in other expenses, an increase in professional fees of $0.3 million, and an increase of $0.2 million in customer field services. The increase in employee-related expenses is due to additional personnel costs resulting from new hires in our sales function and stock compensation. The increase in direct marketing is due to an increase in trade shows and events. The increase in travel and expense in 2021 is due an increase in travel costs for sales personnel meetings and events. The increase in other miscellaneous expenses is primarily due to an increase in subscriptions. The increase in professional fees is related to increased consulting on ways to maximize sales and business development. The increase in customer field services is due to increased sales volume.

[0001558370-21-015999:mdna:178]
General and Administrative Expenses

[0001558370-21-015999:mdna:179]
General and administrative expenses were $11.2 million for the nine months ended September 30, 2021, compared to $2.7 million for the nine months ended September 30, 2020. The increase of $8.5 million was primarily due to an increase of $3.1 million in professional fees, an increase of $3.4 million in employee-related expenses, an increase of $0.7 million in facility expense, an increase of $0.7 million in insurance expense, and an increase of $0.3 million in computer and IT expenses. The increase in professional fees is due to an increase in audit, tax, and legal services to the company. The increase in employee-related expenses is due to an increase in salaries and related costs as a result of expanding our administrative team and stock compensation. The increase in facility expense is due to increased rent expense. The increase in miscellaneous expense is due to an increase in business insurance. The increase in computer and IT expenses is due to the purchase of new computer equipment and software subscriptions for new employees.

[0001558370-21-015999:mdna:180]
Loss From Impairment of Property and Equipment

[0001558370-21-015999:mdna:181]
Impairment of property and equipment was $1.7 million for the nine months ended September 30, 2021. There was no impairment for the nine months ended September 30, 2020. This related to Edge units and prototype versions of Express that were removed from service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of the Edge assets and resulted in impairment.

[0001558370-21-015999:mdna:182]
Interest Expense

[0001558370-21-015999:mdna:183]
Interest expense was $6.0 million for the nine months ended September 30, 2021, compared to $0.2 million for the nine months ended September 30, 2020. The increase of $5.8 million was primarily due to the issuance of $30.0 million of convertible notes during the nine months ended September 30, 2021. The Convertible Notes converted to the Company’s stock upon closing of the Merger.

[0001558370-21-015999:mdna:184]
Other Expense

[0001558370-21-015999:mdna:185]
Other expense was $0.7 million for the nine months ended September 30, 2021, compared to $0 for the nine months ended September 30, 2020. The increase of $0.7 million was primarily due to the loss on the disposal of non-leased assets, primarily related to demo units, during the nine months ended September 30, 2021.

[0001558370-21-015999:mdna:186]
Loss on Extinguishment of Debt

[0001558370-21-015999:mdna:187]
Loss on extinguishment of debt was $12.7 million for the nine months ended September 30, 2021, compared to $0 for the nine months ended September 30, 2020. This was due to the modification of the 2021 Convertible Notes and then the conversion of the 2021 Convertible Notes into shares of the Company’s stock upon closing of the Merger.

[0001558370-21-015999:mdna:188]
Change in Fair Value of Derivative Liability

[0001558370-21-015999:mdna:189]
Change in the fair value of the derivative liability was $1.7 million for the nine months ended September 30, 2021, compared to $0 for the nine months ended September 30, 2020. This was primarily due to an increase in the fair value of the company stock price given the pending Merger.

[0001558370-21-015999:mdna:190]
Change in Fair Value of Contingent Earn-out Liability

[0001558370-21-015999:mdna:191]
Change in the fair value of the contingent earn-out liability was $31.8 million for the nine months ended September 30, 2021, compared to $0 for the nine months ended September 30, 2020. This was primarily due to the issuance of the contingent earn-out liability upon the closing of the Merger and mark to market fluctuations during the period driven by a decrease in stock price.

[0001558370-21-015999:mdna:192]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001558370-21-015999:mdna:193]
Change in the fair value of the contingently issuable common stock liability was $5.7 million for the nine months ended September 30, 2021, compared to $0 for the nine months ended September 30, 2020. This was primarily due to the issuance of the contingently issuable common stock liability upon the closing of the Merger and mark to market fluctuations during the period driven by a decrease in stock price.

[0001558370-21-015999:mdna:194]
Change in Fair Value of Public Warrant Liability

[0001558370-21-015999:mdna:195]
Change in the fair value of the public warrant liability was $3.2 million for the nine months ended September 30, 2021, compared to $0 for the nine months ended September 30, 2020. This was primarily due to the issuance of the public warrant liability upon the closing of the Merger and mark to market fluctuations during the period driven by a decrease in the publicly traded warrant price.

[0001558370-21-015999:mdna:196]
Change in Fair Value of Common Stock Warrant Liability

[0001558370-21-015999:mdna:197]
Change in the fair value of the common stock warrant liability was $0.9 million for the nine months ended September 30, 2021, compared to $0 for the nine months ended September 30, 2020. This was primarily due to the conversion of the common stock warrant liability upon the closing of the Merger and mark to market fluctuations prior to the closing of the Merger.

[0001558370-21-015999:mdna:198]
Income Taxes

[0001558370-21-015999:mdna:199]
There is no provision for income taxes for the three and nine months ended September 30, 2021 and 2020 because Evolv has historically incurred net operating losses and maintains a full valuation allowance against its deferred tax assets. We have provided a valuation allowance for all of our deferred tax assets as a result of our historical net losses in the jurisdictions in which we operate. We continue to assess all positive and negative evidence, including our future taxable income by jurisdiction based on our recent historical operating results, the expected timing of reversal of temporary differences, various tax planning strategies that we may be able to enact in future periods, the impact of potential operating changes on our business and our forecast results from operations in future periods based on available information at the end of each reporting period. To the extent that we are able to reach the conclusion that deferred tax assets are realizable based on any combination of the above factors in any given tax jurisdiction, a reversal of all or some related portion of our existing valuation allowances may occur.

[0001558370-21-015999:mdna:200]
[same as prior period, unchanged from 0001104659-21-106340:mdna:38]

[0001558370-21-015999:mdna:201]
Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures, public company costs and general corporate needs. We expect these needs to continue as we develop and grow our business. Prior to the Merger, as an early-stage company, we have primarily obtained cash to fund our operations through preferred stock offerings and debt instruments. Subsequent to the Merger, our principal sources of liquidity have been and are expected to be our cash and cash equivalents and product revenues.

[0001558370-21-015999:mdna:202]
As of September 30, 2021, we had $334.4 million in cash and cash equivalents. We incurred net income of $22.8 million and a net loss of $6.3 million for the three months ended September 30, 2021 and 2020, respectively. We incurred a net loss of $13.4 million and $17.8 million for the nine months ended September 30, 2021 and 2020, respectively. We incurred cash outflows from operating activities of $50.5 million and $18.4 million during the nine months ended September 30, 2021 and 2020, respectively.

[0001558370-21-015999:mdna:203]
We expect our cash and cash equivalents, together with cash we expect to generate from future operations, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. However, because we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to invest in research and development and expand our sales and marketing teams worldwide. We are likely to require additional capital to respond to technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions or unforeseen circumstances and in either the short-term or long-term may determine to engage in equity or debt financings or enter into credit facilities for other reasons. If we are unable to obtain adequate financing or financing on terms satisfactory to us, when we require it, our ability to continue to grow or support our business and to respond to business challenges could be significantly limited. In particular, the widespread COVID-19 pandemic, including variants, has resulted in, and may continue to result in, significant disruption of global financial markets, reducing our ability to access capital. If we are unable to raise additional funds when or on the terms desired, our business, financial condition and results of operations could be adversely affected.

[0001558370-21-015999:mdna:204]
PIPE Investment

[0001558370-21-015999:mdna:205]
In July 2021, the Company received gross proceeds of $300.0 million from its PIPE Investment, as well as $84.9 million in proceeds received from the closing of Merger.

[0001558370-21-015999:mdna:206]
Financing Arrangements

[0001558370-21-015999:mdna:207]
In December 2020, we entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024 and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022., which extinguished all previous debt. Under the terms of the JPM Credit Agreement, we received proceeds of $10.0 million. As of September 30, 2021, we had $15.4 million of debt outstanding. In September and December of 2020, we issued a total of $4.0 million of convertible notes (the “2020 Convertible Notes”). Between January 21, 2021 and February 4, 2021, we issued a total of $30.0 million of convertible notes with a maturity date of September 2021.

[0001558370-21-015999:mdna:208]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense).

[0001558370-21-015999:mdna:209]
Cash Flows

[0001558370-21-015999:mdna:210]
The following table sets forth a summary of cash flows for the periods presented:

[0001558370-21-015999:mdna:211]
| ​ |  | Nine Months Ended |
| ​ | ​ | September 30, |
| ​ | ​ | 2021 | ​ | 2020 |
| Net cash used in operating activities | ​ | $ | (50,477) | ​ | $ | (18,397) |
| Net cash used in investing activities |  | ​ | (3,082) |  | ​ | (4,304) |
| Net cash provided by financing activities |  | ​ | 383,277 |  | ​ | 8,471 |
| Net increase (decrease) in cash, cash equivalents and restricted cash | ​ | $ | 329,718 | ​ | $ | (14,230) |

[0001558370-21-015999:mdna:212]
Operating Activities

[0001558370-21-015999:mdna:213]
During the nine months ended September 30, 2021, operating activities used $50.5 million resulting from a net loss of $13.4 million, $25.9 million of cash used by changes in operating assets and liabilities, and non-cash adjustments of $11.2 million. The non-cash adjustments consisted primarily of a $31.8 million of change in the fair value of contingent earn-out liability, $5.7 million of change in the fair value of contingently issuable common stock liability and $3.2 million of change in the fair value of public warrant liability, partially offset by $12.7 million on loss of extinguishment of debt, $5.6 million in noncash interest expense, $4.0 million in stock-based compensation expense, $1.9 million in depreciation and amortization expense, $1.7 million from loss from impairment of property and equipment, $1.7 million of change in the fair value of derivative liability, $0.9 million of change in fair value of common stock warrant liability and $0.4 million on write-off of inventory. The changes in operating assets and liabilities consisted primarily of cash used by an increase of $12.8 million in prepaid expenses and other current assets, an increase of $10.8 million in inventory, an increase of $5.9 million in accounts receivable, an increase of $2.6 million in contract assets, an increase of $1.1 million in commission assets, and an increase of $0.4 million in deferred rent, partially offset by an increase in deferred revenue of $2.5 million, an increase of $2.2 million in accrued expenses and other current liabilities, and an increase of $2.3 million in accounts payable.

[0001558370-21-015999:mdna:214]
The changes in commission assets and deferred revenue were primarily due to a shift towards a subscription-based model. The increase in accounts receivable is primarily due to higher sales and the timing of payments from customers. The increase in accrued expenses and other current liabilities and accounts payable is primarily due to an increase in sales and marketing and general and administrative expenses due to the growth in our business and the closing of the Merger, as well as the timing of vendor invoicing and payments. The increase in prepaid expenses and other current assets is primarily due to prepaid subscriptions and insurance. The increase in inventory is primarily due to lower shipments to customers for Edge units, as well as an increase due to Express units now being held in inventory, in the first three quarters of 2021. The increase in contract assets is primarily due to an increase in purchase subscriptions.

[0001558370-21-015999:mdna:215]
During the nine months ended September 30, 2020, cash used from operating activities was $18.4 million, primarily resulting from a net loss of $17.8 million and $1.8 million of cash used by changes in operating assets and liabilities, partially offset by non-cash adjustments of $1.2 million. The non-cash adjustments consisted primarily of $0.7 million of depreciation and amortization and $0.5 million in stock-based compensation. The changes in operating assets and liabilities consisted primarily of cash used by an increase of $2.0 million in accounts receivable, an increase of $1.3 million in commission assets, and an increase of $1.1 million in inventory, partially offset by an increase of $1.9 million in deferred revenue, an increase of $1.0 million in accounts payable, and an increase of $0.1 million in accrued expenses and other current liabilities.

[0001558370-21-015999:mdna:216]
The increase in accounts receivable is primarily due to the timing of payments from customers. The increase in accounts payable and accrued expenses is primarily due to increase in research and development and general and administrative expenses due to the growth in our business as well as the timing of vendor invoicing and payments. The increase in inventory is primarily due to lower shipments to customers in the first three quarters of 2020.

[0001558370-21-015999:mdna:217]
Investing Activities

[0001558370-21-015999:mdna:218]
During the nine months ended September 30, 2021 and 2020, cash used in investing activities was $3.1 million and $4.3 million, respectively for the purchases of property and equipment.

[0001558370-21-015999:mdna:219]
Financing Activities

[0001558370-21-015999:mdna:220]
During the nine months ended September 30, 2021, cash provided by financing activities was $383.3 million primarily consisting of $300.0 million from the issuance of common stock from the PIPE investment, $84.9 million of proceeds from closing of the Merger, $31.9 million from the issuance of long-term debt, net of issuance costs, and $0.8 million from the exercise of stock options, partially offset by $0.4 million in net cash outflows for the repayment of our finance obligations and $34.0 million in net cash outflow of offering costs paid from the closing of the Merger.

[0001558370-21-015999:mdna:221]
During the nine months ended September 30, 2020, cash provided by financing activities was $8.5 million primarily consisting of $3.0 million from the issuance of Series B-1 convertible preferred stock, net of issuance costs, $5.6 million from the issuance of long-term debt, net of issuance costs, and $0.4 million from the exercise of stock options, partially offset by $0.3 million in net cash outflows for the repayment of long-term debt and $0.2 million in net cash outflows for the repayment of financing obligations.

[0001558370-21-015999:mdna:222]
Recent Accounting Pronouncements

[0001558370-21-015999:mdna:223]
Refer to Note 2 of our condensed consolidated financial statements for the three and nine months ended September 30, 2021.

[0001558370-21-015999:mdna:224]
Interest Rate Risk

[0001558370-21-015999:mdna:225]
We have exposure to interest rate risk from our variable rate debt. We do not hedge our exposure to changes in interest rates. At September 30, 2021, we had $15.4 million in variable rate debt outstanding. A hypothetical 10% change in interest rates would have an immaterial impact on annualized interest expense.

[0001558370-21-015999:mdna:226]
[same as prior period, unchanged from 0001104659-21-106340:mdna:57]

[0001558370-21-015999:mdna:227]
Our consolidated financial statements are prepared in accordance with generally accepted accounting principles in the United States. The preparation of our consolidated financial statements and related disclosures requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, costs and expenses, and the disclosure of contingent assets and liabilities in our condensed consolidated financial statements. We base our estimates on historical experience, known trends and events and various other factors that we believe are reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. We evaluate our estimates and assumptions on an ongoing basis. Our actual results may differ from these estimates under different assumptions or conditions.

[0001558370-21-015999:mdna:228]
While our significant accounting policies are described in more detail in Note 2 to our condensed consolidated financial statements, we believe that the following accounting policies are those most critical to the judgments and estimates used in the preparation of our condensed consolidated financial statements.

[0001558370-21-015999:mdna:229]
Revenue Recognition

[0001558370-21-015999:mdna:230]
We recognize revenue in accordance with ASC 606. Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, we apply the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

[0001558370-21-015999:mdna:231]
We derive revenue from (1) subscription arrangements accounted for as operating leases under ASC 840 and (2) from the sale of products, inclusive of maintenance and services. Our arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001558370-21-015999:mdna:232]
Product Revenue

[0001558370-21-015999:mdna:233]
We derive revenue from the sale of our Express and Edge equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer. Transfer of control occurs when we have transferred title and risk of loss and have a present right to payment for the equipment, which is generally upon delivery as our normal terms of sale are freight on board destination. Products are predominately sold with distinct services, which are described in the services section below.

[0001558370-21-015999:mdna:234]
Subscription Revenue

[0001558370-21-015999:mdna:235]
In addition to selling products directly to customers, we also lease Express and Edge equipment. These arrangements convey the right to use the equipment for a period of time in exchange for consideration and therefore are accounted for under ASC 840 due to the scope exception of ASC 606-10-15-2. Lease terms are typically four years and customers pay quarterly or annual fixed payments for the lease and maintenance elements over the contractual lease term. In accordance with ASC 840, Leases, we consider only the fixed payments for purposes of allocating between the lease and non-lease deliverables on a relative fair value basis. Equipment leases are generally classified as operating leases as they do not meet any of the capital lease criteria per ASC 840.

[0001558370-21-015999:mdna:236]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (i) distinct services, such as installation, training and maintenance, and (ii) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern and because revenue allocated to maintenance components is not material, the equipment lease and maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations.

[0001558370-21-015999:mdna:237]
As our leases with customers are classified as operating leases, lease revenue is recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001558370-21-015999:mdna:238]
Services Revenue

[0001558370-21-015999:mdna:239]
We provide installation, training, and maintenance services for our products. Revenue for installation and training are recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes, and when-and-if-available threat updates. Maintenance revenue is recognized ratably over the period of the arrangement. We sell separately priced extended or nonstandard warranty services and preventative maintenance plans, which are recognized ratably over the associated service period.

[0001558370-21-015999:mdna:240]
Revenue from Distributors

[0001558370-21-015999:mdna:241]
A portion of our revenue is generated by sales in conjunction with our distributors. When we transact with a distributor, our contractual arrangement is with the distributor and not with the end-use customer. In these transactions, the distributor is considered the customer; we have discretion over the pricing to the distributor and maintain overall control of the inventory and sales process to the distributor. Revenue is recognized upon delivery to the distributors. Right of return does not generally exist. Whether we transact with a distributor and receive the order from a distributor or directly from an end-use customer, our revenue recognition policy and resulting pattern of revenue recognition is the same (upon delivery).

[0001558370-21-015999:mdna:242]
Transaction Price

[0001558370-21-015999:mdna:243]
The transaction price is the amount of consideration that we expect to be entitled for providing goods and services under a contract. It includes not only fixed consideration, such as the stated amount in a contract, but also several other types of variable consideration or adjustments (generally discounts or incentives which are included as a part of the standalone selling price (“SSP”) estimation process). We provide discounts to customers which reduces the transaction price. From time-to-time, we may offer customers the option to purchase additional goods and services at a fixed price. In these limited circumstances, we assess whether these offers constitute a material right, and if so, we would account for the material right as a separate performance obligation. Other types of variable consideration are not considered significant. We do not normally provide for rights of returns to customers on product sales and, therefore, does not record a provision for returns.

[0001558370-21-015999:mdna:244]
Performance Obligations

[0001558370-21-015999:mdna:245]
A performance obligation is a promise in a contract to transfer a distinct product or service to a customer that is both capable of being distinct, whereby the customer can benefit from the product or service either on its own or together with other resources that are readily available, and is distinct in the context of the contract, whereby the transfer of the product or service is separately identifiable from other promises in the contract.

[0001558370-21-015999:mdna:246]
For both Edge and Express units, equipment is sold or leased with embedded software which is considered a single performance obligation. Maintenance, which includes future updates, security threat updates, and minor bug fixes on a when-and-if available basis, is considered a single performance obligation. As a part of reported subscription sales, certain non-lease components, such as maintenance, are included within the subscription revenue amount. We sell separately priced extended or nonstandard warranty services and preventative maintenance plans, which are accounted for as separate performance obligations. Installation and training are considered separate performance obligations and are included within services revenue. Any add-on accessories are also considered separate performance obligations.

[0001558370-21-015999:mdna:247]
Multiple Performance Obligations within an Arrangement

[0001558370-21-015999:mdna:248]
Our contracts may include multiple performance obligations when customers purchase a combination of products and services. When our customer arrangements have multiple performance obligations that contain a lease for Express or Edge equipment for the customer’s use at its site as well as distinct services that are delivered simultaneously, we allocate the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, we allocate the contract’s transaction price to each performance obligation on a relative SSP basis. We determine SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, we estimate the SSP taking into account available information such as market conditions and internally approved pricing guidelines related to the performance obligation.

[0001558370-21-015999:mdna:249]
Stock-Based Compensation

[0001558370-21-015999:mdna:250]
We measure stock-based option awards granted to employees, consultants and directors based on their fair value on the date of grant using the Black-Scholes option-pricing model. Compensation expense for those awards is recognized, net of estimated forfeitures, over the requisite service period, which is generally the vesting period of the respective award.

[0001558370-21-015999:mdna:251]
Prior to the closing of the Merger. the fair value of each stock option grant is estimated on the date of grant using the Black-Scholes option-pricing model, which uses the following inputs: (i) the fair value per share of the common stock issuable upon exercise of the option, (ii) the expected term of the option, (iii) expected volatility of the price of the common stock, (iv) the risk-free interest rate, and (v) the expected dividend yield.

[0001558370-21-015999:mdna:252]
After the closing of the Merger, our board of directors determined the fair value of each share of common stock underlying stock-based awards based on the closing price of our common stock as reported by Nasdaq on the date of grant.

[0001558370-21-015999:mdna:253]
23

[0001558370-21-015999:mdna:254]
We classify stock-based compensation expense in our consolidated statements of operations in the same manner in which the award recipient’s payroll costs are classified or in which the award recipient’s service payments are classified.

[0001558370-21-015999:mdna:255]
Valuation of Contingent Earn-out Liability

[0001558370-21-015999:mdna:256]
The estimated fair value of the contingent earn-out shares were determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, drift rate, percentage of change in control and expected term. For potential payments related to a product development milestone, the fair value was determined based on the Company’s expectations of achieving such a milestone and the simulated estimated stock price on the expected date of achievement.

[0001558370-21-015999:mdna:257]
Valuation of Contingently Issuable Common Stock Liability

[0001558370-21-015999:mdna:258]
The estimated fair value of the contingently issuable common shares were determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the vesting period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, and risk-free rate.

[0001558370-21-015999:mdna:259]
Valuation of Common Stock Warrant Liability and Public Warrant Liability

[0001558370-21-015999:mdna:260]
We classify certain warrants to purchase shares of our common stock as liabilities on our balance sheets as these warrants are free-standing financial instruments that may require the Company to adjust the exercise price and number of shares that is not consistent with a fixed-for-fixed option pricing model. The warrant liability associated with each of these warrants was initially recorded at fair value on the issuance date of each warrant and is subsequently remeasured to fair value at each balance sheet date. Changes in fair value of the warrants are recognized as a component of other income (expense) in our statements of operations and comprehensive income (loss). We will continue to adjust the liability for changes in fair value until the warrants are exercised, expire or qualify for equity classification.

[0001558370-21-015999:mdna:261]
We utilize the Black-Scholes option-pricing model, which incorporates assumptions and estimates to value the warrant liability. Key estimates and assumptions impacting the fair value measurement include (i) the fair value per share of the underlying shares of applicable series of stock issuable upon exercise of the Warrants, (ii) the remaining contractual term of the Warrants, (iii) the risk-free interest rate, (iv) the expected dividend yield and (v) expected volatility of the price of the underlying applicable common stock. We assess these assumptions and estimates on a quarterly basis as additional information impacting the assumptions is obtained. We estimate the fair value per share of the underlying stock based in part on the results of third-party valuations and additional factors deemed relevant. We have historically been a private company and lack company-specific historical and implied volatility information of our stock. Therefore, we estimate expected stock volatility based on the historical volatility of publicly traded peer companies for a term equal to the remaining contractual term of the warrants. The risk-free interest rate is determined by reference to the U.S. Treasury yield curve for time periods approximately equal to the remaining contractual term of the warrants.

[0001558370-21-015999:mdna:262]
Valuation of Inventory

[0001558370-21-015999:mdna:263]
Inventory is valued at the lower of cost or net realizable value. Cost is computed using the first-in, first-out method. We regularly review inventory quantities on-hand for excess and obsolete inventory and, when circumstances indicate, record charges to write down inventories to their estimated net realizable value, after evaluating historical sales, future demand, market conditions and expected product life cycles. Such charges are classified as cost of product revenue in the statements of operations and comprehensive income (loss). Any write-down of inventory to net realizable value creates a new cost basis.

[0001558370-21-015999:mdna:264]
Leases

[0001558370-21-015999:mdna:265]
At the inception of each operating lease, we determine a residual value for the leased equipment based on our estimate of the future value of the equipment at the end of the lease term. All of our leases are currently in their initial

[0001558370-21-015999:mdna:266]
lease term with our existing customers and we have not yet had any renewals of such leases with our current customers or leases of used equipment to new customers. We will continue to evaluate our estimates of the residual value of our leased equipment considering future lease extensions of such equipment with existing customers at the end of their lease terms as well as used equipment leased to new customers. The Company’s subscription contracts are classified as operating leases because title does not transfer, there are no bargain purchase options, the present value of the lease payments does not exceed 90% of the asset’s fair market value, and the lease term does not exceed 75% of the asset’s economic life. The Company has not had a contract renewal point and will reassess the classification of any such leases upon renewal. We evaluate leased equipment for obsolescence and impairment whenever circumstances indicate that the carrying value of such equipment is not recoverable by considering any (1) reduced demand in the markets in which we operate, (2) technological obsolescence due to developments of new products and improvements, or (3) changes in economic or other events and conditions that impact the market price for our products. Based on our evaluations, an impairment loss on property and equipment of $1.7 million during the three and nine months ended September 30, 2021 related to Edge units and prototype versions of Express removed from service and retired was recorded. The Company did not record any impairment losses on leased equipment during the three or nine months ended September 30, 2020.

[0001558370-21-015999:mdna:267]
Off-Balance Sheet Arrangements

[0001558370-21-015999:mdna:268]
We did not have during the periods presented, and we do not currently have, any off-balance sheet arrangements, as defined in the rules and regulations of the SEC.

[0001558370-21-015999:mdna:269]
Emerging Growth Company Status

[0001558370-21-015999:mdna:270]
The Jumpstart Our Business Startups Act of 2012, or the JOBS Act, permits an “emerging growth company” such as us to take advantage of an extended transition period to comply with new or revised accounting standards applicable to public companies until those standards would otherwise apply to private companies. The Combined Company has elected to use this extended transition period for complying with new or revised accounting standards that have different effective dates for public and private companies until the earlier of the date we (i) are no longer an emerging growth company or (ii) affirmatively and irrevocably opt out of the extended transition period provided in the JOBS Act. As a result, we will not be subject to the same new or revised accounting standards as other public companies that are not emerging growth companies and our financial statements may not be comparable to other public companies that comply with new or revised accounting pronouncements as of public company effective dates. We may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for private companies.

[0001558370-21-015999:mdna:271]
We will remain an emerging growth company until the earlier of (1) the last day of the fiscal year (a) following the fifth anniversary of the completion of the initial public offering, (b) in which we have total annual gross revenue of at least $1.07 billion or (c) in which we are deemed to be a large accelerated filer, which means the market value of shares of our Class A common stock that are held by non-affiliates equals or exceeds $700 million as of the prior June 30, and (2) the date on which we have issued more than $1.0 billion in non-convertible debt during the prior three-year  period.

[0001558370-21-015999:mdna:272]
Further, even after we no longer qualify as an emerging growth company, we may still qualify as a “smaller reporting company,” which would allow us to take advantage of many of the same exemptions from disclosure requirements, including reduced disclosure obligations regarding executive compensation in our periodic reports and proxy statements. We cannot predict if investors will find our common shares less attractive because we may rely on these exemptions. If some investors find our common shares less attractive as a result, there may be a less active trading market for our common shares and our share price may be more volatile.
