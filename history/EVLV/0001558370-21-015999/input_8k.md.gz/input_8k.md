# EVLV 8-K — 0001558370-21-015481 filed 2021-11-10

## item codes, every 8-K on or before 2021-11-15

- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2021-11-15

- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001558370-21-015481:8k_2_02:1]
EX-99.1
2
nhic-20211110xex99d1.htm
EX-99.1

[0001558370-21-015481:8k_2_02:2]
Exhibit 99.1

[0001558370-21-015481:8k_2_02:3]
| Investor Relations: | Public Relations: |
| Brian Norris | Fitz Barth |
| Vice President of Investor Relations | Director of Communications |
| bnorris@evolvtechnology.com | fbarth@evolvtechnology.com |

[0001558370-21-015481:8k_2_02:4]
Evolv Technology Reports Strong Third Quarter Financial Results

[0001558370-21-015481:8k_2_02:5]
– Company Raises Outlook for 2021 –

[0001558370-21-015481:8k_2_02:6]
|  | ● | Q3 Total Contract Value (TCV) of $16.9 million, up 365% year-over-year |

[0001558370-21-015481:8k_2_02:7]
|  | ● | Q3 Revenue of $8.4 million, up 473% year-over-year |

[0001558370-21-015481:8k_2_02:8]
Waltham, Massachusetts – November 10, 2021 – Evolv Technology (NASDAQ: EVLV), the global leader in weapons detection security screening, today announced financial results for its third quarter ended September 30, 2021 and raised its business outlook for 2021.

[0001558370-21-015481:8k_2_02:9]
“We are pleased to be reporting strong third quarter results highlighted by record revenues, accelerating channel activity and category defining new product innovations,” said Peter George, Chief Executive Officer of Evolv Technology. “We continued to extend our market leadership position with dozens of new customers including the Indianapolis Symphony Orchestra, the Nasdaq MarketSite and the National Football League’s Carolina Panthers and Tennessee Titans. Looking ahead, we are focused on a strong finish in 2021 and believe that we are well positioned for accelerated growth.”

[0001558370-21-015481:8k_2_02:10]
Results for the Third Quarter of 2021

[0001558370-21-015481:8k_2_02:11]
Total revenue for the third quarter of 2021 was $8.4 million, an increase of 473% compared to $1.5 million for the third quarter of 2020. Total Contract Value (“TCV”) of orders booked for the third quarter of 2021 was $16.9 million, an increase of 365% compared to $3.6 million in the third quarter of 2020. GAAP net income for the third quarter of 2021 was $23.2 million, or $0.15 per diluted share, compared to a GAAP net loss of $6.3 million, or $0.70 per basic and diluted share, for the third quarter of 2020.

[0001558370-21-015481:8k_2_02:12]
Results for the First Nine Months of 2021

[0001558370-21-015481:8k_2_02:13]
Total revenue for the first nine months of 2021 was $16.8 million, an increase of 513% compared to $2.8 million for the first nine months of 2020. TCV of orders booked for the first nine months of 2021 was $36.0 million, an increase of 280% compared to $9.5 million in the first nine months of 2020. GAAP net loss for the first nine months of 2021 was $13.4 million, or $0.28 per basic and diluted share, compared to a GAAP net loss of $17.8 million, or $2.00 per basic and diluted share, for the first nine months of 2020.

[0001558370-21-015481:8k_2_02:14]
Company Raises Outlook for 2021

[0001558370-21-015481:8k_2_02:15]
The Company today raised its business outlook for 2021. The Company’s outlook is based on the current indications for its business, which may change at any time.

[0001558370-21-015481:8k_2_02:16]
| ​ | Business Outlook for Year Ending December 31, 2021 |
| Estimate | Issued August 16, 2021 | Issued November 10, 2021 |
| TCV of orders booked (in millions) | $53-$55 | $53-$57 |
| Total Revenue (in millions) | $20-$21 | $20-$23 |

[0001558370-21-015481:8k_2_02:17]
Company to Host Live Conference Call and Webcast

[0001558370-21-015481:8k_2_02:18]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business and other matters. The conference call may be accessed in the United States by dialing +1.844.867.6169 and using access code 1400696. The conference call may be accessed outside of the United States by dialing +1.409.207.6975 and using access code 1400696. The conference call will be simultaneously webcast on the Company’s investor relations website, which can be accessed at http://ir.evolvtechnology.com. A replay of the conference call will be available for a period of 30 days by dialing 1.866.207.1041 or +1.402.970.0847 and using access code 3758262 or by accessing the webcast replay on the Company’s investor relations website at http://ir.evolvtechnology.com. The Company has used, and intends to continue to use, the investor relations portion of its website as a means of disclosing material non-public information and for complying with disclosure obligations under Regulation FD.

[0001558370-21-015481:8k_2_02:19]
About Evolv Technology

[0001558370-21-015481:8k_2_02:20]
Evolv Technology (NASDAQ: EVLV) is the global leader in weapons detection security screening. Our mission is enabling a better experience and better security for venues, creating a safer world to work, learn, and play by transforming physical security to make everywhere safer. This enhances the visitor experience and improves weapons detection. We give sports fans, theme park visitors, concertgoers, shoppers, employees, students, and others peace of mind so that they can gather without fear of violence. Our security system, delivered as a SaaS-based offering, has scanned more than 100 million people, second only to the Department of Homeland Security’s Transportation Security Administration in the United States, and our technology combines powerful, advanced sensors with proven artificial intelligence (AI), security ecosystem integrations, and comprehensive venue analytics to reliably detect threats 10 times faster than traditional metal detectors. Evolv Technology, Evolv Express®, Evolv Insights™, and Evolv Cortex AI™ are registered trademarks or trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit https://evolvtechnology.com.

[0001558370-21-015481:8k_2_02:21]
Forward-Looking Statements

[0001558370-21-015481:8k_2_02:22]
EVOLV TECHNOLOGY

[0001558370-21-015481:8k_2_02:23]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001558370-21-015481:8k_2_02:24]
(In thousands, except share and per share data)

[0001558370-21-015481:8k_2_02:25]
(Unaudited)

[0001558370-21-015481:8k_2_02:26]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended | ​ |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| ​ |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |
| Revenue: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Product revenue | ​ | $ | 5,345 | ​ | $ | 349 | ​ | $ | 10,299 | ​ | $ | 422 | ​ |
| Subscription revenue | ​ | ​ | 2,305 | ​ | ​ | 794 | ​ | ​ | 5,118 | ​ | ​ | 1,743 | ​ |
| Service revenue | ​ | ​ | 717 | ​ | ​ | 318 | ​ | ​ | 1,429 | ​ | ​ | 585 | ​ |
| Total revenue | ​ | ​ | 8,367 | ​ | ​ | 1,461 | ​ | ​ | 16,846 | ​ | ​ | 2,750 | ​ |
| Cost of revenue: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Product revenue | ​ | ​ | 2,933 | ​ | ​ | 163 | ​ | ​ | 7,237 | ​ | ​ | 361 | ​ |
| Subscription revenue | ​ | ​ | 1,086 | ​ | ​ | 490 | ​ | ​ | 2,542 | ​ | ​ | 1,192 | ​ |
| Service revenue | ​ | ​ | 192 | ​ | ​ | 169 | ​ | ​ | 732 | ​ | ​ | 376 | ​ |
| Total cost of revenue | ​ | ​ | 4,211 | ​ | ​ | 822 | ​ | ​ | 10,511 | ​ | ​ | 1,929 | ​ |
| Gross profit | ​ | ​ | 4,156 | ​ | ​ | 639 | ​ | ​ | 6,335 | ​ | ​ | 821 | ​ |
| Operating expenses: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Research and development | ​ | ​ | 3,641 | ​ | ​ | 4,088 | ​ | ​ | 8,330 | ​ | ​ | 10,629 | ​ |
| Sales and marketing | ​ | ​ | 8,510 | ​ | ​ | 1,552 | ​ | ​ | 17,284 | ​ | ​ | 5,105 | ​ |
| General and administrative | ​ | ​ | 6,983 | ​ | ​ | 1,177 | ​ | ​ | 11,162 | ​ | ​ | 2,676 | ​ |
| Loss from impairment of leased equipment | ​ | ​ | 1,656 | ​ | ​ | — | ​ | ​ | 1,656 | ​ | ​ | — | ​ |
| Total operating expenses | ​ | ​ | 20,790 | ​ | ​ | 6,817 | ​ | ​ | 38,432 | ​ | ​ | 18,410 | ​ |
| Loss from operations | ​ | ​ | (16,634) | ​ | ​ | (6,178) | ​ | ​ | (32,097) | ​ | ​ | (17,589) | ​ |
| Interest and other expense | ​ | ​ | (955) | ​ | ​ | (84) | ​ | ​ | (6,657) | ​ | ​ | (207) | ​ |
| Loss on extinguishment of debt | ​ | ​ | (865) | ​ | ​ | — | ​ | ​ | (12,685) | ​ | ​ | — | ​ |
| Change in fair value of derivative liability | ​ | ​ | 475 | ​ | ​ | — | ​ | ​ | (1,745) | ​ | ​ | — | ​ |
| Change in fair value of contingent earn-out liability | ​ | ​ | 31,818 | ​ | ​ | — | ​ | ​ | 31,818 | ​ | ​ | — | ​ |
| Change in fair value of contingently issuable common stock liability | ​ | ​ | 5,718 | ​ | ​ | — | ​ | ​ | 5,718 | ​ | ​ | — | ​ |
| Change in fair value of public warrant liability | ​ | ​ | 3,152 | ​ | ​ | — | ​ | ​ | 3,152 | ​ | ​ | — | ​ |
| Change in fair value of common stock warrant liability | ​ | ​ | 42 | ​ | ​ | — | ​ | ​ | (879) | ​ | ​ | — | ​ |
| Total other income (expense) | ​ | $ | 39,385 | ​ | $ | (84) | ​ | $ | 18,722 | ​ | $ | (207) | ​ |
| Net income (loss) and comprehensive loss attributable to common stockholders – basic | ​ | $ | 22,751 | ​ | $ | (6,262) | ​ | $ | (13,375) | ​ | $ | (17,796) | ​ |
| Net income (loss) and comprehensive loss attributable to common stockholders – diluted | ​ | $ | 23,222 | ​ | $ | (6,262) | ​ | $ | (13,375) | ​ | $ | (17,796) | ​ |
| Net income (loss) per share – basic | ​ | $ | 0.19 | ​ | $ | (0.70) | ​ | $ | (0.28) | ​ | $ | (2.00) | ​ |
| Net income (loss) per share – diluted | ​ | $ | 0.15 | ​ | $ | (0.70) | ​ | $ | (0.28) | ​ | $ | (2.00) | ​ |
| Weighted average ordinary shares outstanding – basic | ​ | ​ | 119,745,196 | ​ | ​ | 8,917,855 | ​ | ​ | 47,786,638 | ​ | ​ | 8,892,564 | ​ |
| Weighted average ordinary shares outstanding – diluted | ​ | ​ | 153,903,195 | ​ | ​ | 8,917,855 | ​ | ​ | 47,786,638 | ​ | ​ | 8,892,564 | ​ |

[0001558370-21-015481:8k_2_02:27]
EVOLV TECHNOLOGY

[0001558370-21-015481:8k_2_02:28]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001558370-21-015481:8k_2_02:29]
(In thousands, except share and per share data)

[0001558370-21-015481:8k_2_02:30]
(Unaudited)

[0001558370-21-015481:8k_2_02:31]
| ​ |  | September 30,2021 |  | December 31,2020 |  |
| Assets | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Current assets: | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Cash | ​ | ​ | 333,747 | ​ | ​ | 4,704 | ​ |
| Restricted Cash | ​ | ​ | 400 | ​ | ​ | — | ​ |
| Accounts receivable, net | ​ | ​ | 7,330 | ​ | ​ | 1,401 | ​ |
| Inventory | ​ | ​ | 3,530 | ​ | ​ | 2,742 | ​ |
| Prepaid expenses and other current assets | ​ | ​ | 14,756 | ​ | ​ | 1,462 | ​ |
| Total current assets | ​ | ​ | 359,763 | ​ | ​ | 10,309 | ​ |
| Commission asset, noncurrent | ​ | ​ | 2,310 | ​ | ​ | 1,730 | ​ |
| Property and equipment, net | ​ | ​ | 17,783 | ​ | ​ | 9,316 | ​ |
| Restricted cash, noncurrent | ​ | ​ | 275 | ​ | ​ | — | ​ |
| Other long-term assets | ​ | ​ | 2,582 | ​ | ​ | — | ​ |
| Total assets | ​ | $ | 382,713 | ​ | $ | 21,355 | ​ |
| Liabilities and Shareholders’ Equity (Deficit) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Current liabilities: | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Accounts payable | ​ | ​ | 8,460 | ​ | ​ | 4,437 | ​ |
| Accrued expenses and other current liabilities | ​ | ​ | 6,169 | ​ | ​ | 3,727 | ​ |
| Current portion of deferred revenue | ​ | ​ | 5,668 | ​ | ​ | 3,717 | ​ |
| Current portion of long-term debt | ​ | ​ | 1,000 | ​ | ​ | — | ​ |
| Other current liabilities | ​ | ​ | 37 | ​ | ​ | 238 | ​ |
| Total current liabilities | ​ | ​ | 21,334 | ​ | ​ | 12,119 | ​ |
| Deferred revenue | ​ | ​ | 988 | ​ | ​ | 480 | ​ |
| Noncurrent portion of deferred rent | ​ | ​ | 371 | ​ | ​ | — | ​ |
| Common stock warrant liability | ​ | ​ | — | ​ | ​ | 1 | ​ |
| Public warrant liability | ​ | ​ | 20,484 | ​ | ​ | — | ​ |
| Derivative liability | ​ | ​ | — | ​ | ​ | 1,000 | ​ |
| Contingent earn-out liability | ​ | ​ | 35,027 | ​ | ​ | — | ​ |
| Contingently issuable common stock liability | ​ | ​ | 5,952 | ​ | ​ | — | ​ |
| Financing obligation, noncurrent | ​ | ​ | — | ​ | ​ | 132 | ​ |
| Long-term debt, noncurrent | ​ | ​ | 14,359 | ​ | ​ | 16,432 | ​ |
| Total liabilities | ​ | ​ | 98,515 | ​ | ​ | 30,164 | ​ |
| Convertible preferred stock and shareholders’ equity | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Convertible preferred stock | ​ | ​ | — | ​ | ​ | 75,877 | ​ |
| Common stock | ​ | ​ | 14 | ​ | ​ | 1 | ​ |
| Additional paid-in capital | ​ | ​ | 391,440 | ​ | ​ | 9,194 | ​ |
| Accumulated deficit | ​ | ​ | (107,256) | ​ | ​ | (93,881) | ​ |
| Total shareholders’ equity (deficit) | ​ | ​ | 284,198 | ​ | ​ | (84,686) | ​ |
| Total liabilities and shareholders’ equity | ​ | ​ | 382,713 | ​ | ​ | 21,355 | ​ |

[0001558370-21-015481:8k_2_02:32]
EVOLV TECHNOLOGY

[0001558370-21-015481:8k_2_02:33]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001558370-21-015481:8k_2_02:34]
(In thousands)

[0001558370-21-015481:8k_2_02:35]
(Unaudited)

[0001558370-21-015481:8k_2_02:36]
| ​ |  | Nine Months EndedSeptember 30, |  |
| ​ | ​ | 2021 |  | 2020 | ​ |
| Cash flows from operating activities: | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net loss | ​ | $ | (13,375) | ​ | $ | (17,796) | ​ |
| Adjustments to reconcile net loss to net cash used in operating activities: | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Depreciation and amortization | ​ | ​ | 1,948 | ​ | ​ | 685 | ​ |
| Loss from impairment of leased equipment | ​ | ​ | 1,656 | ​ | ​ | — | ​ |
| Loss on disposal of fixed assets | ​ | ​ | 659 | ​ | ​ | — | ​ |
| Stock-based compensation | ​ | ​ | 4,013 | ​ | ​ | 525 | ​ |
| Noncash interest expense | ​ | ​ | 5,561 | ​ | ​ | — | ​ |
| Provision recorded for allowance for doubtful accounts | ​ | ​ | (63) | ​ | ​ | (16) | ​ |
| Loss on extinguishment of debt | ​ | ​ | 12,685 | ​ | ​ | — | ​ |
| Change in fair value of derivative liability | ​ | ​ | 1,745 | ​ | ​ | — | ​ |
| Change in fair value of common stock warrant liability | ​ | ​ | 879 | ​ | ​ | — | ​ |
| Change in fair value of earn-out liability | ​ | ​ | (31,818) | ​ | ​ | — | ​ |
| Change in fair value of contingently issuable common stock | ​ | ​ | (5,718) | ​ | ​ | — | ​ |
| Change in fair value of public warrant liability | ​ | ​ | (3,152) | ​ | ​ | — | ​ |
| Changes in operating assets and liabilities | ​ | ​ | (25,727) | ​ | ​ | (1,795) | ​ |
| Net cash used in operating activities | ​ | ​ | (50,707) | ​ | ​ | (18,397) | ​ |
| Cash flows from investing activities: | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Purchases of property and equipment | ​ | ​ | (3,082) | ​ | ​ | (4,304) | ​ |
| Net cash used in investing activities | ​ | ​ | (3,082) | ​ | ​ | (4,304) | ​ |
| Cash flows from financing activities: | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Proceeds from issuance of Series B-1 convertible preferred stock, net of issuance costs | ​ | ​ | — | ​ | ​ | 2,994 | ​ |
| Proceeds from exercise of stock options | ​ | ​ | 777 | ​ | ​ | 418 | ​ |
| Proceeds from issuance of common stock from the PIPE Investment | ​ | ​ | 300,000 | ​ | ​ | — | ​ |
| Proceeds from the closing of the Merger, net of offering costs | ​ | ​ | 51,207 | ​ | ​ | — | ​ |
| Repayment of financing obligations | ​ | ​ | (359) | ​ | ​ | (225) | ​ |
| Proceeds from long-term debt, net of issuance costs | ​ | ​ | 31,882 | ​ | ​ | 5,284 | ​ |
| Net cash provided by financing activities | ​ | ​ | 383,507 | ​ | ​ | 8,471 | ​ |
| Net increase (decrease) in cash | ​ | ​ | 329,718 | ​ | ​ | (14,230) | ​ |
| Cash, beginning of period | ​ | ​ | 4,704 | ​ | ​ | 17,341 | ​ |
| Cash, end of period | ​ | $ | 334,422 | ​ | $ | 3,111 | ​ |
| Supplemental disclosure of cash flow information: | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Cash paid for interest | ​ | $ | 427 | ​ | $ | 207 | ​ |
