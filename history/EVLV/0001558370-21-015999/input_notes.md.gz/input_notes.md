# EVLV notes — 0001558370-21-015999


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001558370-21-015999:notes:1]
1. Nature of the Business and Basis of Presentation

[0001558370-21-015999:notes:2]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its subsidiaries. References to “NHIC” refer to the company prior to the consummation of the Merger and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger.

[0001558370-21-015999:notes:3]
Legacy Evolv was incorporated under the laws of the State of Delaware on July 8, 2013. The Company is the global leader in AI-based touchless security screening. The Company’s mission is to make the world a safer and more enjoyable place to live, work, learn, and play. The Company is democratizing security by making it seamless for gathering spaces to address the chronic epidemic of mass shootings and terrorist attacks in a cost-effective manner while improving the visitor experience. The Company is headquartered in Waltham, Massachusetts.

[0001558370-21-015999:notes:4]
Merger with NewHold Investment Corp.

[0001558370-21-015999:notes:5]
On July 16, 2021 (the “Closing Date”), the predecessor company, consummated the previously announced Merger with Legacy Evolv, pursuant to the Agreement and Plan of Merger dated as of March 5, 2021, and amended by the First Amendment to Agreement and Plan of Merger (the “Merger Agreement”), dated as of June 5, 2021. Upon the closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. and the officers of NHIC, the predecessor company resigned. The officers of Legacy Evolv became the officers of the Company, and the Company listed its shares of common stock, par value $0.0001 per share, on Nasdaq under the symbol “EVLV” (see Note 3).

[0001558370-21-015999:notes:6]
Subscription Agreement

[0001558370-21-015999:notes:7]
Prior to the completion of the Merger, the Company entered into subscription agreements (collectively, the “PIPE Investment”) with certain parties subscribing for shares of the Company’s common stock (the “Subscribers”) pursuant to which the Subscribers agreed to purchase. Pursuant to the PIPE Investment, the Company issued 30,000,000 shares of Class A common stock for a purchase price of $10.00 per share with gross proceeds of $300.0 million.

[0001558370-21-015999:notes:8]
Risks and uncertainties

[0001558370-21-015999:notes:9]
The Company is subject to risks and uncertainties common to early-stage companies in the human security industry including, but not limited to, the successful development, commercialization, marketing and sale of existing and new products, fluctuations in operating results and financial risks, protection of proprietary knowledge and patent risks, dependence on key personnel, competition, technological risks, cybersecurity risks, customer demand and management of growth. Potential risks and uncertainties also include, without limitation, uncertainties regarding the duration and magnitude of the impact of the COVID-19 pandemic, including variants, on the Company’s business and the economy in general.

[0001558370-21-015999:notes:10]
In March 2020, the World Health Organization declared the global novel coronavirus disease 2019 (“COVID-19”) outbreak a pandemic. The impact of this pandemic has been and will likely continue to be extensive in many aspects of society, which has resulted in and will likely continue to result in significant disruptions to the global economy, as well as businesses and capital markets around the world. The Company cannot at this time predict the ultimate extent, duration, or full impact that the COVID-19 pandemic will have on its future financial condition and operations. The impact of the COVID-19 pandemic  on the Company’s financial performance will depend on future developments, including the duration and spread of the pandemic, including variants, and related governmental advisories and restrictions, the progression and effectiveness of vaccination roll-outs, vaccine hesitancy, and the actions

[0001558370-21-015999:notes:11]
taken to contain or treat COVID-19, as well as the economic impact on local, regional, national and international customers and markets. The situation surrounding COVID-19 remains fluid and the potential for a material impact on the Company increases the longer the virus impacts the level of economic activity in the United States and globally. Given the ongoing evolution of the COVID-19 and the global responses to curb its spread, the Company is not able to estimate the effects of the COVID-19 on its results of operations, financial condition, or liquidity for the year ending December 31, 2021 and beyond. If the financial markets and/or the overall economy are impacted for an extended period, the Company’s results may be materially adversely affected.

[0001558370-21-015999:notes:12]
Future impacts to the Company’s business as a result of COVID-19 could include disruptions to the Company’s revenue caused by closures of customer operations, manufacturing operations and supply chain caused by facility closures, reductions in operating hours, staggered shifts and other social distancing efforts; labor shortages; decreased productivity and unavailability of materials or components; limitations on its employees’ and customers’ ability to travel, and delays in shipments to and from affected countries and within the United States. While the Company maintains an inventory of finished products and raw materials used in its products, a prolonged pandemic could lead to shortages in the raw materials necessary to manufacture its products.

[0001558370-21-015999:notes:13]
Basis of presentation

[0001558370-21-015999:notes:14]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly owned subsidiary in the United Kingdom, Evolv Technologies UK Ltd. and its wholly owned subsidiary Give Evolv LLC. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001558370-21-015999:notes:15]
Revision of Prior Period Financial Statements

[0001558370-21-015999:notes:16]
During the year ended December 31, 2020, an error was identified by the Company related to the preferred stock warrant classification in prior periods. Specifically, the Company had misclassified these warrants for the purchase of shares of its preferred stock as equity for the period from September 2016 through December 2018 when these warrants should have been liability classified and changes to fair value recorded in the Statement of Operations, therefore retained earnings were understated for changes in fair value of the warrant over that period of time of liability classification. Upon the modified retrospective adoption of ASU No. 2018-07 Compensation - Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting and ASU No. 2019-08 Codification Improvements-Share-Based Consideration Payable to a Customer, on January 1, 2019, the warrants were classified within temporary equity. The Company concluded that the impacts of the error were not material to the consolidated financial statements as of and for the years ended December 31, 2020 and 2019. While not material, the Company has elected to revise the previously issued consolidated financial statements as of and for the years ended December 31, 2020 and 2019 for the impacts of the error. In addition, the applicable notes to the accompanying financial statements have also been revised to correct for these misstatements.

[0001558370-21-015999:notes:17]
The following table (in thousands) reflects the impacts of the error on the consolidated financial statements and gives effect to the retrospective restatement to reflect the exchange ratio of 0.378 established in the Merger as described in Note 3.

[0001558370-21-015999:notes:18]
| ​ |  | As of December 31, 2020 |  | As of December 31, 2019 |
| ​ | ​ | As previously | ​ | ​ | ​ | ​ | ​ | ​ | ​ | As previously | ​ | ​ | ​ | ​ | ​ | ​ |
| ​ | ​ | reported |  | Adjustment |  | Revised |  | reported |  | Adjustment |  | Revised |
| Convertible preferred stock | ​ | $ | 75,393 | ​ | $ | 484 | ​ | $ | 75,877 | ​ | $ | 72,399 | ​ | $ | 484 | ​ | $ | 72,883 |
| Additional paid-in capital | ​ | $ | 9,946 | ​ | $ | (752) | ​ | $ | 9,194 | ​ | $ | 8,730 | ​ | $ | (752) | ​ | $ | 7,978 |
| Accumulated deficit | ​ | $ | (94,149) | ​ | $ | 268 | ​ | $ | (93,881) | ​ | $ | (66,757) | ​ | $ | 268 | ​ | $ | (66,489) |
| Stockholders’ deficit | ​ | $ | (84,202) | ​ | $ | (484) | ​ | $ | (84,686) | ​ | $ | (58,026) | ​ | $ | (484) | ​ | $ | (58,510) |

[0001558370-21-015999:notes:19]
Unaudited Interim Financial Information

[0001558370-21-015999:notes:20]
The accompanying unaudited consolidated financial statements as of September 30, 2021, and for the three and nine months ended September 30, 2021 and 2020 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2020 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of September 30, 2021 and the results of its operations for the three and nine months ended September 30, 2021 and 2020 and cash flows for the nine months ended September 30, 2021 and 2020. The results for the three and nine months ended September 30, 2021 are not necessarily indicative of results to be expected for the year ending December 31, 2021, any other interim periods, or any future year or period.

[0001558370-21-015999:notes:21]
Accordingly, these unaudited interim consolidated financial statements should be read in conjunction with the audited annual consolidated financial statements and notes thereto for the years ended December 31, 2020 and 2019 included in the Prospectus filed with the SEC on September 3, 2021 (the “Prospectus”).


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001558370-21-015999:notes:22]
2. Summary of Significant Accounting Policies

[0001558370-21-015999:notes:23]
Use of Estimates

[0001558370-21-015999:notes:24]
The preparation of the Company’s consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the reporting periods. Significant estimates and assumptions reflected in these consolidated financial statements include but are not limited to calculating the standalone selling price for revenue recognition, the valuation of inventory, the valuation of derivative liability, the valuation of common stock for the periods prior to the Company listing its shares on Nasdaq, stock-based awards, the valuation of the preferred stock warrant liability, the valuation of the contingent earn-out liability and the valuation of the contingently issuable common stock. The Company bases its estimates on historical experience, known trends and other market-specific or other relevant factors that it believes to be reasonable under the circumstances. On an ongoing basis, management evaluates its estimates when there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results could differ from those estimates.

[0001558370-21-015999:notes:25]
Due to the COVID-19 pandemic, there has been uncertainty and disruption in the global economy and financial markets. The full extent to which the COVID-19 pandemic will directly or indirectly impact the Company’s business, results of operations and financial condition, including revenues and expenses, will depend on future developments that are highly uncertain, including as a result of new information that may emerge concerning COVID-19 and the actions taken to contain it or treat COVID-19. Management has made estimates of the impact of COVID-19 within the Company’s consolidated financial statements and there may be changes to those estimates in future periods. These

[0001558370-21-015999:notes:26]
estimates may change, as new events occur, and additional information is obtained. On an ongoing basis, management evaluates its estimates as there are changes in circumstances, facts, and experience. Changes in estimates are recorded in the period in which they become known. Actual results may differ from those estimates or assumptions.

[0001558370-21-015999:notes:27]
Risk of Concentrations of Credit, Significant Customers and Significant Suppliers

[0001558370-21-015999:notes:28]
Financial instruments that potentially expose the Company to concentrations of credit risk consist primarily of cash and cash equivalents, restricted cash, and accounts receivable, net. Periodically, the Company maintains deposits in accredited financial institutions in excess of federally insured limits. The Company maintains its cash, cash equivalents and restricted cash with financial institutions that management believes to be of high credit quality. The Company has not experienced any losses on such accounts and does not believe it is exposed to any unusual credit risk beyond the normal credit risk associated with commercial banking relationships.

[0001558370-21-015999:notes:29]
Significant customers are those which represent more than 10% of the Company’s total revenue or accounts receivable, net balance at each respective balance sheet date. The following table presents customers that represent 10% or more of the Company’s total revenue:

[0001558370-21-015999:notes:30]
| ​ |  | Three Months Ended |  | ​ | Nine Months Ended |  | ​ |
| ​ | ​ | September 30, | ​ | ​ | September 30, | ​ | ​ |
| ​ | ​ | 2021 | ​ | 2020 |  | ​ | 2021 | ​ | 2020 |  | ​ |
| Customer A |  | — | ​ | 20.0 | % | ​ | — | ​ | 11.0 | % | ​ |
| Customer B |  | 21.2 | % | — | ​ | ​ | 10.0 | % | — | ​ | ​ |
| ​ |  | 21.2 | % | 20.0 | % | ​ | 10.0 | % | 11.0 | % | ​ |

[0001558370-21-015999:notes:31]
Customer A revenue is from subscriptions and Customer B revenue is from product revenue.

[0001558370-21-015999:notes:32]
The following table presents customers that represent 10% or more of the Company’s accounts receivable, net:

[0001558370-21-015999:notes:33]
| ​ |  | September 30, | ​ | December 31, |  | ​ |
| ​ | ​ | 2021 | ​ | 2020 |  | ​ |
| Customer B |  | 16.0 | % | — | ​ | ​ |
| Customer C |  | — | ​ | 28.3 | % | ​ |
| Customer D |  | — | ​ | 23.4 | % | ​ |
| ​ |  | 16.0 | % | 51.7 | % | ​ |

[0001558370-21-015999:notes:34]
The Company relies on third parties for the supply and manufacture of its products as well as third-party logistics providers. In instances where these parties fail to perform their obligations, the Company may be unable to find alternative suppliers to satisfactorily deliver its products to its customers on time, if at all, which could have a material adverse effect on the Company’s operating results, financial condition and cash flows and damage its customer relationships.

[0001558370-21-015999:notes:35]
Debt Issuance Costs

[0001558370-21-015999:notes:36]
The Company capitalizes certain legal, accounting, and other third-party fees that are directly associated with the issuance of debt as debt issuance costs. Debt issuance costs are recorded as a direct reduction of the carrying amount of the associated debt on the consolidated balance sheet and amortized as interest expense on the consolidated statement of operations and comprehensive loss using the effective interest method. As of September 30, 2021, and December 31, 2020, debt issuance costs totaled $0.1 million and $0.1 million, respectively, and were recorded as a reduction in the carrying amount of long-term debt in the consolidated balance sheets. During the three months ended September 30, 2021 and 2020, and nine months ended September 30, 2021 and 2020, the Company recorded less than $0.1 million in

[0001558370-21-015999:notes:37]
amortization of the debt issuance costs recorded within interest expense in the consolidated statement of operations and comprehensive income (loss).

[0001558370-21-015999:notes:38]
Cash, Cash Equivalents, and Restricted Cash

[0001558370-21-015999:notes:39]
Cash, cash equivalents, and restricted cash as reported on the consolidated statement of cash flows consists of the following (in thousands):

[0001558370-21-015999:notes:40]
| ​ |  | September 30, | ​ | December 31, |
| ​ | ​ | 2021 | ​ | 2020 |
| Cash and cash equivalents |  | $ | 333,747 | ​ | $ | 4,704 |
| Restricted cash |  | ​ | 675 | ​ | ​ | — |
| Total cash, cash equivalents, and restricted cash |  | $ | 334,422 | ​ | $ | 4,704 |

[0001558370-21-015999:notes:41]
The Company considers all short-term, highly liquid investments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents. Restricted cash consists of a security deposit on the Company’s new office lease in Waltham, Massachusetts, with $0.4 million included in the current portion of restricted cash which will be returned during the first half of 2022, and $0.3 million included in restricted cash, noncurrent in the consolidated balance sheets.

[0001558370-21-015999:notes:42]
Property and Equipment

[0001558370-21-015999:notes:43]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization expense is recognized using the straight-line method over the estimated useful life of each asset, as follows:

[0001558370-21-015999:notes:44]
| ​ |  | Estimated Useful Life |
| Computers and telecommunications equipment |  | 3 years |
| Lab equipment |  | 5 years |
| Software |  | 4 years |
| Furniture and fixtures |  | 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |
| Leased equipment |  | 4-7 years |

[0001558370-21-015999:notes:45]
Estimated useful lives are periodically assessed to determine if changes are appropriate. Leasehold improvements are amortized using the straight-line method over the lesser of the lease term or its estimated economic useful life. Lease terms are used based upon the initial lease agreement and do not consider potential renewals or extensions until such time that the renewals or extensions are contracted. Maintenance and repairs are charged to expense as incurred. When assets are retired or otherwise disposed of, the cost of these assets and related accumulated depreciation or amortization are eliminated from the consolidated balance sheet and any resulting gains or losses are included in the consolidated statement of operations and comprehensive income (loss) in the period of disposal. Costs for capital assets not yet placed into service are capitalized as construction-in-progress and depreciated once placed into service.

[0001558370-21-015999:notes:46]
The Company’s leases for leased equipment generally are 48 months. The Company’s subscription contracts are classified as operating leases because title does not transfer and they do not meet any of the other criteria per ASC 840. To date, the Company has not had any subscription arrangements come up for renewal and will reassess the classification of any such leases upon renewal.

[0001558370-21-015999:notes:47]
The Company evaluates leased equipment for obsolescence and impairment whenever circumstances indicate that the carrying value of such equipment is not recoverable by considering any (1) reduced demand in the markets in

[0001558370-21-015999:notes:48]
which the Company operate, (2) technological obsolescence due to developments of new products and improvements, or (3) changes in economic or other events and conditions that impact the market price for the Company’s products. Based on the Company’s evaluations, an impairment loss on property and equipment of $1.7 million was recorded during the three and nine months ended September 30, 2021. This was related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of these assets and resulted in impairment.

[0001558370-21-015999:notes:49]
Contingent Earn-out

[0001558370-21-015999:notes:50]
In connection with the Merger and pursuant to the Merger Agreement, certain of the Legacy Evolv’s shareholders and Legacy Evolv service providers are entitled to receive additional shares of the Company’s Class A common stock (the “Earn-Out Shares”) upon the Company achieving certain milestones:

[0001558370-21-015999:notes:51]
|  | ● | Triggering Event I – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s Class A common stock is greater than $12.50 per share for any 20 trading days within any 30 trading day period. |

[0001558370-21-015999:notes:52]
|  | ● | Triggering Event II – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s Class A common stock is greater than $15.00 per share for any 20 trading days within any 30 trading day period. |

[0001558370-21-015999:notes:53]
|  | ● | Triggering Event III – a one-time issuance of a number of Earn-Out Shares equal to 5,000,000 shall occur if, within five years following the closing of the Merger, the price of the Company’s Class A common stock is greater than $17.50 per share for any 20 trading days within any 30 trading day period. |

[0001558370-21-015999:notes:54]
In accordance with ASC 815 – Derivatives and Hedging, the earn-out arrangement with the Legacy Evolv shareholders is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as a change in fair value of contingent earn-out liability in other income (expense), net in the consolidated statements of operations and comprehensive income (loss). When the Triggering Events have been achieved and the Earn-Out Shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share. Of the total 15,000,000 earn-out shares, 12,137,397 earn-out shares are with the Legacy Evolv shareholders.

[0001558370-21-015999:notes:55]
The estimated fair value of the contingent earn-out shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The significant assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, drift rate, percentage of change in control and expected term.

[0001558370-21-015999:notes:56]
The contingent earn-out liability is categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various potential pay-out scenarios. Contingent earn-out payments involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001558370-21-015999:notes:57]
The Earn-Out Shares issued to employees, officers, directors, and non-employees are based achievement of certain target share price contingencies and for the employees and officers, subject to continued employment, (the “Earn-Out Service Providers”) represents share-based compensation and is classified as equity on the Company’s balance

[0001558370-21-015999:notes:58]
sheet. Corresponding stock-based compensation expense is recorded in the consolidated statements of operations and comprehensive income (loss) in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. Of the total 15,000,000 earn-out shares, 2,862,603 earn-out shares are with the Legacy Evolv service providers and subject to share-based compensation.

[0001558370-21-015999:notes:59]
Contingently Issuable Common Stock

[0001558370-21-015999:notes:60]
Prior to the Merger, NewHold Industrial Technology Holdings, LLC, the sponsor of the NHIC special purpose acquisition company owned 4,312,500 shares of NHIC Class B common stock (the “Founder Shares). Upon the closing of the merger, NHIC Class A and Class B common stock became the Company’s common stock. The Founder Shares outstanding were subject to certain share-performance-based vesting provisions as follows:

[0001558370-21-015999:notes:61]
|  | ● | Vesting Provision I - 1,897,500 shares of the Company’s common stock shall vest and no longer be subject to forfeiture as of the Merger; |

[0001558370-21-015999:notes:62]
|  | ● | Vesting Provision II - if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $12.50 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30 trading day period, then 948,750 shares of the Company’s common stock shall vest and no longer be subject to forfeiture; |

[0001558370-21-015999:notes:63]
|  | ● | Vesting Provision III - if within five years following the closing of the Merger, the last reported sale price of the Company’s common stock equals or exceeds $15.00 per share (as adjusted for stock splits, stock dividends, reorganizations, recapitalizations and the like) for any 20 trading days within any 30-trading day period, then 948,750 shares of the Company’s common stock) shall vest and no longer be subject to forfeiture; |

[0001558370-21-015999:notes:64]
The remaining 517,500 Founder Shares were contributed to Give Evolv LLC.

[0001558370-21-015999:notes:65]
If Vesting Provision II and/or Vesting Provision III are not satisfied, the corresponding number of shares specified shall be forfeited and no longer issued and outstanding. If there is a Change of Control event prior to Vesting Provision II and/or Vesting Provision III are satisfied, the Founder shares are no longer subject to forfeiture and shall vest immediately upon the occurrence of a Change of Control event.

[0001558370-21-015999:notes:66]
In accordance with ASC 815 – Derivatives and Hedging, the contingently issuable common stock is accounted for as a liability and subsequently remeasured at each reporting date with changes in fair value recorded as change in fair value of contingently issuable common stock liability in other income (expense), net in the consolidated statements of operations and comprehensive loss. When the Vesting Provisions have been achieved and the contingently issuable common shares are issued, the Company will reclassify the corresponding amount from a liability to additional paid-in-capital and common stock at par value of $0.0001 per share.

[0001558370-21-015999:notes:67]
The estimated fair value of the contingently issuable common shares was determined using a Monte Carlo simulation that simulated the future path of the Company’s stock price over the earn-out period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including projected stock price, volatility, and risk-free rate.

[0001558370-21-015999:notes:68]
The contingently issuable common shares are categorized as a Level 3 fair value measurement (see Note 4) because the Company estimates projections during the earn-out period utilizing unobservable inputs, including various

[0001558370-21-015999:notes:69]
potential pay-out scenarios. Contingently issuable shares involve certain assumptions requiring significant judgment and actual results may differ from assumed and estimated amounts.

[0001558370-21-015999:notes:70]
Impairment of Long-Lived Assets

[0001558370-21-015999:notes:71]
Long-lived assets consist of property and equipment. Long-lived assets to be held and used are tested for recoverability whenever events or changes in business circumstances indicate that the carrying amount of the assets may not be fully recoverable. Factors that the Company considers in deciding when to perform an impairment review include significant underperformance of the business in relation to expectations, significant negative industry or economic trends and significant changes or planned changes in the use of the assets. If an impairment review is performed to evaluate a long-lived asset group for recoverability, the Company compares forecasts of undiscounted cash flows expected to result from the use and eventual disposition of the long-lived asset group to its carrying value. An impairment loss would be recognized in loss from operations when estimated undiscounted future cash flows expected to result from the use of an asset group are less than its carrying amount. The impairment loss is based on the excess of the carrying value of the impaired asset group over its fair value, determined based on discounted cash flows. The Company recorded a $1.7 million impairment loss on long-lived assets during the three and nine months ended September 30, 2021. This was related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of these assets and resulted in impairment. The Company did not record any impairment losses on long-lived assets during the three and nine months ended September 30, 2020.

[0001558370-21-015999:notes:72]
Fair Value Measurements of Financial Instruments

[0001558370-21-015999:notes:73]
Certain assets and liabilities of the Company are carried at fair value under GAAP. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. Valuation techniques used to measure fair value must maximize the use of observable inputs and minimize the use of unobservable inputs. Financial assets and liabilities carried at fair value are to be classified and disclosed in one of the following three levels of the fair value hierarchy, of which the first two are considered observable and the last is considered unobservable:

[0001558370-21-015999:notes:74]
|  | ● | Level 1 — Quoted prices in active markets for identical assets or liabilities. |

[0001558370-21-015999:notes:75]
|  | ● | Level 2 — Observable inputs (other than Level 1 quoted prices), such as quoted prices in active markets for similar assets or liabilities, quoted prices in markets that are not active for identical or similar assets or liabilities, or other inputs that are observable or can be corroborated by observable market data. |

[0001558370-21-015999:notes:76]
|  | ● | Level 3 — Unobservable inputs that are supported by little or no market activity that are significant to determining the fair value of the assets or liabilities, including pricing models, discounted cash flow methodologies and similar techniques. |

[0001558370-21-015999:notes:77]
The Company’s cash equivalents, derivative liability, contingent earn-out liability, contingently issuable common stock liability and its common stock warrant liability are carried at fair value, determined according to the fair value hierarchy described above (see Note 4). The carrying values of the Company’s accounts receivable, net, accounts payable and accrued expenses approximate their fair values due to the short-term nature of these assets and liabilities. The carrying value of the Company’s long-term debt approximates its fair value (a Level 2 measurement) at each balance sheet date due to its variable interest rate, which approximates a market interest rate.

[0001558370-21-015999:notes:78]
Assets that are measured at fair value on a nonrecurring basis primarily relate to property and equipment. We do not periodically adjust carrying value to fair value for property and equipment. Rather, the carrying value of the asset is reduced to its fair value when we determine that impairment has occurred. During the three and nine months ended September 30, 2021, impairment of property and equipment was $1.7 million, respectively. This was related to Edge and Express prototype units that were taken out of service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of these assets and resulted in impairment. There was no impairment for the three and nine months ended September 30, 2020.

[0001558370-21-015999:notes:79]
Derivative Liability Related to Convertible Notes

[0001558370-21-015999:notes:80]
In August through September 2019 and in September through December 2020, the Company issued Convertible Notes to several investors (see Note 9) that provided a conversion option whereby upon the closing of a specified financing event the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 85% and 80%, respectively, of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative that was required to be bifurcated and accounted for separately from the notes. The derivative liability was initially recorded at fair value upon issuance of the notes and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the derivative liability are recognized in the consolidated statements of operations and comprehensive income (loss). In October 2019, the specified financing event was consummated, as such the Convertible Notes issued August through September 2019 were converted into shares of Series B-1 Preferred Stock (see Note 10), and the derivative liability was extinguished. The derivative liability related to the 2020 convertible note is outstanding as of December 31, 2020 and is included as a derivative liability in the consolidated balance sheets.

[0001558370-21-015999:notes:81]
Between January 21, 2021 and February 4, 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes,” and together with the 2020 Convertible Notes, the “Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability and current portion of long-term debt on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method.

[0001558370-21-015999:notes:82]
On June 21, 2021, the Company and the holders of the 2021 Convertible Notes agreed that, in connection with the Merger, such holders would receive an additional 1,000,000 shares of NHIC common stock as further consideration for the automatic conversion of such notes upon closing of the Merger. This modification of the 2021 Convertible Notes resulted in an extinguishment, and recognition of a derivative liability, which represents both the value of the 1,000,000 NHIC shares as of June 21, 2021 as well as a bifurcated embedded derivative for conversion into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors.

[0001558370-21-015999:notes:83]
Upon the closing of the Merger, the September through December 2020 Convertible Notes and the 2021 Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on

[0001558370-21-015999:notes:84]
extinguishment of debt of $0.9 million recorded in other income (expense) in the consolidated statements of operations and comprehensive income (loss).

[0001558370-21-015999:notes:85]
Classification of Convertible Preferred Stock

[0001558370-21-015999:notes:86]
Prior to the closing of the Merger, the holders of Legacy Evolv Series A, Series A-1, Series B and Series B-1 convertible preferred stock had certain liquidation rights in the event of a deemed liquidation event that, in certain situations, is not solely within the control of the Company and would call for the redemption of the then outstanding Series A, Series A-1, Series B and Series B-1 convertible preferred stock (see Note 10). Therefore, the Legacy Evolv Series A, Series A-1, Series B and Series B-1 convertible preferred stock were classified outside of stockholders’ equity (deficit) on the consolidated balance sheets.

[0001558370-21-015999:notes:87]
In connection with the closing of the Merger, all shares of redeemable convertible Preferred Stock were converted into shares of the Company’s common stock. Accordingly, there was no redeemable convertible preferred stock outstanding as of September 30, 2021. As of December 31, 2020, the carrying value of the redeemable convertible Preferred Stock was $75.9 million (see Note 10).

[0001558370-21-015999:notes:88]
Common Stock Warrant Liability and Public Warrant Liability

[0001558370-21-015999:notes:89]
The Company classifies certain warrants for the purchase of shares of its common stock (see Note 11) as a liability on its consolidated balance sheets as these warrants are freestanding financial instruments that may require the Company to adjust the exercise price and number of shares that is not consistent with a fixed-for-fixed option pricing model. The warrant liability is initially recorded at fair value on the issuance date of each warrant and is subsequently remeasured to fair value at each reporting date. Changes in the fair value of the common stock warrant liability are recognized as a component of other income (expense), net in the consolidated statements of operations and comprehensive income (loss). Changes in the fair value of the common stock warrant liability are recognized until the warrants are exercised, expire or qualify for equity classification.

[0001558370-21-015999:notes:90]
In connection with the closing of the Merger, the Company assumed warrants to purchase shares of common stock (the “Public Warrant”) and are classified as a liability pursuant to ASC 815 – Derivatives and Hedging as the equity derivative scope exception was not met. As of September 30, 2021, the Public Warrant is outstanding (see Note 11). All other warrants that were issued prior to the closing of the Merger were converted into shares of the Company’s common stock (the “common stock warrant”) upon the closing of the Merger. Accordingly, the Company remeasured the warrants to fair value upon the closing of Merger with the offset to additional paid-in capital (see Note 11).

[0001558370-21-015999:notes:91]
Equity Classified Preferred Stock Warrants

[0001558370-21-015999:notes:92]
The Company classifies warrants for the purchase of shares of its preferred stock (see Note 11) as temporary equity on its consolidated balance sheets. In connection with a customer development agreement, the Company issued preferred stock warrants to a customer to purchase shares of its Legacy Evolv Series A-1 Preferred Stock. Upon adoption of ASU No. 2018-07 and ASU No. 2019-08 on January 1, 2019, any liability classified warrants issued to non-employees for goods or services were reclassified to temporary equity.

[0001558370-21-015999:notes:93]
In connection with the closing of the Merger, all preferred stock warrants to purchase shares of common stock were converted into shares of the Company’s common stock. Accordingly, there were no preferred stock warrants outstanding as of September 30, 2021. The Company assessed the features of these warrants and determined that they qualify for classification as permanent equity.

[0001558370-21-015999:notes:94]
Equity Classified Common Stock Warrants

[0001558370-21-015999:notes:95]
The Company classifies certain warrants for the purchase of shares of its common stock (see Note 11) as equity on its consolidated balance sheets as these warrants are considered to meet the derivative scope exception for freestanding equity contracts. For these warrants that are classified on the Company’s consolidated balance sheets as equity instruments, the Company uses the Black-Scholes model to measure the value of the warrants at issuance.

[0001558370-21-015999:notes:96]
In connection with the closing of the Merger, all outstanding Legacy Evolv vested warrants to purchase shares of common stock were converted into shares of the Company’s common stock.

[0001558370-21-015999:notes:97]
Revenue Recognition

[0001558370-21-015999:notes:98]
The Company recognizes revenue in accordance with ASC 606. Under ASC 606, revenue is recognized when a customer obtains control of promised goods or services, in an amount that reflects the consideration which the entity expects to receive in exchange for those goods or services. In order to achieve this core principle, the Company applies the following five steps when recording revenue: (1) identify the contract, or contracts, with the customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract and (5) recognize revenue when, or as, performance obligations are satisfied.

[0001558370-21-015999:notes:99]
The Company derives revenue from (1) subscription arrangements accounted for as operating leases under ASC 840 and (2) from the sale of products, inclusive of maintenance and services. The Company’s arrangements are generally noncancelable and nonrefundable after ownership passes to the customer. Revenue is recognized net of sales tax.

[0001558370-21-015999:notes:100]
Product Revenue

[0001558370-21-015999:notes:101]
The Company derives revenue from the sale of its Express and Edge equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer. Transfer of control occurs when the Company has transferred title and risk of loss and has a present right to payment for the equipment, which is generally upon delivery as the Company’s normal terms of sale are freight on board destination. Products are predominately sold with distinct services, which are described in the services section below.

[0001558370-21-015999:notes:102]
Subscription Revenue

[0001558370-21-015999:notes:103]
In addition to selling its products directly to customers, the Company also leases Express and Edge equipment. These arrangements convey the right to use the equipment for a period of time in exchange for consideration and therefore are accounted for under ASC 840 due to the scope exception of ASC 606-10-15-2. Lease terms are typically four years and customers pay quarterly or annual fixed payments for the lease and maintenance elements over the contractual lease term. In accordance with ASC 840, Leases, the Company considers only the fixed payments for purposes of allocating between the lease and non-lease deliverables on a relative fair value basis. Equipment leases are generally classified as operating leases as they do not meet any of the capital lease criteria per ASC 840.

[0001558370-21-015999:notes:104]
Generally, lease arrangements include both lease and non-lease components. The non-lease components relate to (i) distinct services, such as installation, training and maintenance, and (ii) any add-on accessories. Installation and training are included in service revenue as described below, and add-on accessories are included in product revenue as described above. Because the equipment and maintenance components of a subscription arrangement are recognized as revenue over the same time period and in the same pattern and because revenue allocated to maintenance components is not material, the equipment lease and maintenance performance obligations are classified as a single category of subscription revenue in the consolidated statements of operations.

[0001558370-21-015999:notes:105]
As leases with customers are classified as operating leases, lease revenue is recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001558370-21-015999:notes:106]
Services Revenue

[0001558370-21-015999:notes:107]
The Company provides installation, training and maintenance services for its products. Revenue for installation and training is recognized upon transfer of control of these services, which are normally rendered over a short duration. Maintenance consists of technical support, bug fixes, and when-and-if-available threat updates. Maintenance revenue is recognized ratably over the period of the arrangement. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are recognized ratably over the associated service period.

[0001558370-21-015999:notes:108]
Revenue from Distributors

[0001558370-21-015999:notes:109]
A portion of the Company’s revenue is also generated by sales in conjunction with its distributors. When the Company transacts with a distributor, its contractual arrangement is with the distributor and not with the end-use customer. In these transactions, the distributor is considered the customer; the Company has discretion over the pricing to the distributor and maintains overall control of the inventory and sales process to the distributor. Revenue is recognized upon delivery to the distributors. Right of return does not generally exist. Whether the Company transacts with a distributor and receives the order from a distributor or directly from an end-use customer, its revenue recognition policy and resulting pattern of revenue recognition is the same upon delivery.

[0001558370-21-015999:notes:110]
Transaction Price

[0001558370-21-015999:notes:111]
The transaction price is the amount of consideration that the Company expects to be entitled for providing goods and services under a contract. It includes not only fixed consideration, such as the stated amount in a contract, but also several other types of variable consideration or adjustments (generally discounts or incentives which are included as a part of the standalone selling price (“SSP”) estimation process). The Company provides discounts to customers which reduces the transaction price. From time-to-time, the Company may offer customers the option to purchase additional goods and services at a fixed price. In these limited circumstances, the Company assesses whether these offers constitute a material right, and if so, the Company would account for the material right as a separate performance obligation. Other types of variable consideration are not considered significant. The Company does not normally provide for rights of returns to customers on product sales and, therefore, does not record a provision for returns.

[0001558370-21-015999:notes:112]
Performance Obligations

[0001558370-21-015999:notes:113]
A performance obligation is a promise in a contract to transfer a distinct product or service to a customer that is both capable of being distinct, whereby the customer can benefit from the product or service either on its own or together with other resources that are readily available, and is distinct in the context of the contract, whereby the transfer of the product or service is separately identifiable from other promises in the contract.

[0001558370-21-015999:notes:114]
For both Express and Edge units, equipment is sold or leased with embedded software, which is considered a single performance obligation. Maintenance, which includes future updates, security threat updates, and minor bug fixes on a when-and-if available basis, is considered a single performance obligation. As a part of reported subscription sales, certain non-lease components, such as maintenance, are included within the subscription revenue amount. The Company sells separately priced extended or nonstandard warranty services and preventative maintenance plans, which are accounted for as separate performance obligations. Installation and training are considered separate performance obligations and are included within services revenue. Any add-on accessories are also considered separate performance obligations.

[0001558370-21-015999:notes:115]
Payment terms

[0001558370-21-015999:notes:116]
Payment terms for customer orders are typically 30 days after the shipment or delivery of the product. For certain products, services and customer types, the Company requires payment before the products or services are delivered to, or performed for, the customer. Generally, the Company’s contracts do not contain a significant financing component.

[0001558370-21-015999:notes:117]
Multiple Performance Obligations within an Arrangement

[0001558370-21-015999:notes:118]
The Company’s contracts may include multiple performance obligations when customers purchase a combination of products and services. When the Company’s customer arrangements have multiple performance obligations that contain a lease for Express or Edge equipment for the customer’s use at its site as well as distinct services that are delivered simultaneously, the Company allocates the arrangement consideration between the lease deliverables and non-lease deliverables based on the relative estimated SSP of each distinct performance obligation. For multiple performance obligation arrangements that do not contain a lease, the Company allocates the contract’s transaction price to each performance obligation on a relative SSP basis. The Company determines SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, the Company estimates the SSP taking into account available information such as market conditions and internally approved pricing guidelines related to the performance obligation.

[0001558370-21-015999:notes:119]
Remaining Performance Obligations

[0001558370-21-015999:notes:120]
ASC 606 requires that the Company disclose the aggregate amount of transaction price that is allocated to performance obligations that have not yet been satisfied as of September 30, 2021. The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of September 30, 2021. Note that with respect to ASC 840, Subscription revenue includes maintenance in addition to the operating lease components of these transactions (in thousands).

[0001558370-21-015999:notes:121]
| ​ |  | Less than 1 year |  | Greater than 1 year |  | Total |
| Product revenue |  | $ | 111 |  | $ | 36 |  | $ | 147 |
| Subscription revenue |  | ​ | 9,304 |  | ​ | 21,802 |  | ​ | 31,106 |
| Service revenue |  | ​ | 24 |  | ​ | — |  | ​ | 24 |
| Maintenance revenue |  | ​ | 903 |  | ​ | 1,972 |  | ​ | 2,875 |
| Total revenue | ​ | $ | 10,342 | ​ | $ | 23,810 | ​ | $ | 34,152 |

[0001558370-21-015999:notes:122]
The amount of minimum future leases is based on expected income recognition. As of September 30, 2021, future minimum payments on noncancelable leases are as follows (in thousands):

[0001558370-21-015999:notes:123]
| Future operating lease component (in thousands): |  | ​ |  |
| Quarter Ending September 30, 2021: | ​ | ​ | ​ |
| 2021 | ​ | $ | 2,355 |
| 2022 | ​ |  | 9,262 |
| 2023 | ​ |  | 8,800 |
| 2024 | ​ |  | 7,054 |
| 2025 | ​ |  | 3,166 |
| Thereafter | ​ |  | 469 |
| ​ | ​ | $ | 31,106 |

[0001558370-21-015999:notes:124]
Contract Balances from Contracts with Customers

[0001558370-21-015999:notes:125]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time. As of September 30, 2021 and December 31, 2020, the Company had $0.9 million and $0 of contract assets included within prepaid expenses and other current assets and $2.6 million and $0 in long-term contract assets on the consolidated balance sheets, respectively.

[0001558370-21-015999:notes:126]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as noncurrent deferred revenue. The Company recognized $0.5 million and $2.3 million during the three months and nine months ended September 30, 2021 of revenue that was previously included in the 2020 deferred revenue balance, respectively. The following table provides a rollforward of deferred revenue (in thousands):

[0001558370-21-015999:notes:127]
| ​ | ​ | (in thousands) |
| Balance at December 31, 2020 | ​ | $ | 4,197 |
| Revenue recognized | ​ |  | (6,356) |
| Revenue deferred | ​ |  | 8,815 |
| Balance at September 30, 2021 | ​ | $ | 6,656 |

[0001558370-21-015999:notes:128]
Disaggregated Revenue

[0001558370-21-015999:notes:129]
The following table presents the Company’s revenue by revenue stream (in thousands):

[0001558370-21-015999:notes:130]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended | ​ |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| (in thousands) |  | 2021 |  | 2020 | ​ | 2021 |  | 2020 | ​ |
| Product revenue |  | $ | 5,345 |  | $ | 349 | ​ | ​ | 10,299 |  | $ | 422 | ​ |
| Subscription revenue(1) |  | ​ | 2,305 |  | ​ | 794 | ​ | ​ | 5,118 |  | ​ | 1,743 | ​ |
| Service revenue |  | ​ | 417 |  | ​ | 165 | ​ | ​ | 773 |  | ​ | 170 | ​ |
| Maintenance revenue |  | ​ | 300 |  | ​ | 153 | ​ | ​ | 656 |  | ​ | 415 | ​ |
| Total revenue | ​ | $ | 8,367 | ​ | $ | 1,461 | ​ | $ | 16,846 | ​ | $ | 2,750 | ​ |

[0001558370-21-015999:notes:131]
| (1) | Subscription revenue is inclusive of $0.5 million and $0.2 million of maintenance revenue during the three months ended September 30, 2021 and 2020, respectively, and of $1.0 million and $0.4 million of maintenance revenue during the nine months ended September 30, 2021 and 2020, respectively, determined based on a relative fair value allocation as prescribed by ASC 606. |

[0001558370-21-015999:notes:132]
Contract Acquisition Costs

[0001558370-21-015999:notes:133]
The Company incurs and pays commissions on product sales. The Company applies the practical expedient for contracts less than one year to expense the costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the sale occurs and the services are provided. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $3.4 million at September 30, 2021 and $2.3 million at December 31, 2020. The increase in deferred assets is due to an increase of subscription revenue in 2020 and 2021 for which the related revenue and commissions are recognized over the contract term. The Company amortized commissions of $1.3 million during the three months ended September 30, 2021 which related to 2021 commissions, $0.1 million which related to 2020

[0001558370-21-015999:notes:134]
commissions and less than $0.1 million which related to 2019 commissions. The Company amortized commissions of $1.6 million during the nine months ended September 30, 2021 which related to 2021 commissions, $0.3 million which related to 2020 commissions and $0.1 million which related to 2019 commissions.

[0001558370-21-015999:notes:135]
Stock-Based Compensation

[0001558370-21-015999:notes:136]
The Company measures all stock-based awards granted to employees, officers, directors and non-employees based on their fair value on the date of the grant and recognizes compensation expense for those awards over the requisite service period, which is generally the vesting period of the respective award. The Company classifies stock-based compensation expense in its consolidated statements of operations and comprehensive income (loss) in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified.

[0001558370-21-015999:notes:137]
The Company issues stock-based awards with service-based vesting conditions and records the expense for these awards using the straight-line method. Forfeitures are accounted for as they occur. The Company has issued stock-based awards with performance-based vesting conditions. In August 2020, the Company granted an officer 560,189 stock options with a performance-based milestone vesting condition which vested immediately upon achievement of a certain sales milestone. The milestone was achieved in December 2020, and the Company recorded $0.1 million in stock compensation expense upon vesting during the year ended December 31, 2020.

[0001558370-21-015999:notes:138]
In March 2021, the Company granted a warrant exercisable for 2,554,015 shares of common stock to a consulting group (“2021 Finback common stock warrants”) with performance based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years.

[0001558370-21-015999:notes:139]
Prior to the closing of the Merger, there was not a public market for the shares of the Company’s common stock. The Company’s determination of the fair value of stock options on the date of grant utilized the Black-Scholes option-pricing model and was impacted by its common stock price, as determined by the Board of Directors with input from the Company’s management, as well as changes in assumptions regarding a number of subjective variables. These variables included, but were not limited to, the expected term that options remained outstanding, the expected common stock price volatility over the term of the option awards, risk-free interest rates, and expected dividends. The Company values its common stock taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors since the date of the most recent contemporaneous valuation through the date of grant. After the closing of the Merger, the Company determined the fair value of each share of common stock underlying stock-based awards based on the closing price of the Company’s common stock as reported by Nasdaq on the date of grant.

[0001558370-21-015999:notes:140]
Pursuant to the Merger Agreement, the Company will issue 15,000,000 earn-out shares of the Company’s common stock to Legacy Evolv shareholders and Legacy Evolv service providers including employees, officers, directors and non-employees based on the achievement of certain target share price contingencies and for the employees and officers subject to continued employment. The company classifies the share-based compensation arrangement with Legacy Evolv service providers as equity on its balance sheet and corresponding stock-based compensation expense in its consolidated statements of operations and comprehensive income (loss) in the same manner in which the award recipient’s payroll costs are classified or by the nature of the services provided by consultants are classified. Of the total 15,000,000 earn-out shares of the Company’s common stock, 2,862,603 earn-out shares are with the Legacy Evolv service providers and subject to the share-based compensation. Stock-based compensation expense attributable to Legacy Evolv service providers is $2.0 million for the three and nine months ended September 30, 2021.

[0001558370-21-015999:notes:141]
Income Taxes

[0001558370-21-015999:notes:142]
The Company accounts for income taxes using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been recognized in the consolidated financial statements or in the Company’s tax returns. Deferred tax assets and liabilities are determined on the basis of the differences between the consolidated financial statements and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. Changes in deferred tax assets and liabilities are recorded in the provision for income taxes.

[0001558370-21-015999:notes:143]
The Company assesses the likelihood that its deferred tax assets will be recovered from future sources of income and, to the extent it believes, based upon the weight of available evidence, that it is more likely than not that all or a portion of the deferred tax assets will not be realized, a valuation allowance is established through a charge to income tax expense. Potential for recovery of deferred tax assets is evaluated by analyzing past operating results, estimating the future taxable profits expected and considering prudent and feasible tax planning strategies.

[0001558370-21-015999:notes:144]
The Company accounts for uncertainty in income taxes recognized in the consolidated financial statements by applying a two-step process to determine the amount of tax benefit to be recognized. First, the tax position must be evaluated to determine the likelihood that it will be sustained upon external examination by the taxing authorities. If the tax position is deemed more-likely-than-not to be sustained, the tax position is then assessed to determine the amount of benefit to recognize in the consolidated financial statements. The amount of the benefit that may be recognized is the largest amount that has a greater than 50% likelihood of being realized upon ultimate settlement. The provision for income taxes includes the effects of any resulting tax reserves, or unrecognized tax benefits, that are considered appropriate as well as the related net interest and penalties.

[0001558370-21-015999:notes:145]
The Company evaluates at the end of each reporting period whether some or all of the undistributed earnings of its foreign subsidiaries are permanently reinvested. The Company would recognize deferred income tax liabilities to the extent that management asserts that undistributed earnings of its foreign subsidiaries are not permanently reinvested and will not be permanently reinvested in the future. As of September 30, 2021 and December 31, 2020 the Company had no foreign earnings in any foreign jurisdictions.

[0001558370-21-015999:notes:146]
Net Income (Loss) per Share Attributable to Common Stockholders

[0001558370-21-015999:notes:147]
Basic net income (loss) per share attributable to common stockholders is computed by dividing the net income (loss) attributable to common stockholders by the weighted average number of common shares outstanding for the period. Diluted net income (loss) attributable to common stockholders is computed by adjusting net income (loss) attributable to common stockholders for the profit or loss impact to the extent a denominator adjustment is required.  Diluted net income (loss) per share attributable to common stockholders is computed by dividing the diluted net income (loss) attributable to common stockholders by the weighted average number of common shares outstanding for the period, including potential dilutive common shares. For purposes of this calculation, outstanding stock options, convertible preferred stock, convertible notes, warrants to purchase common stock, and warrants to purchase preferred stock are considered potential dilutive common shares.

[0001558370-21-015999:notes:148]
In periods in which the Company reported a net loss attributable to common stockholders, diluted net loss per share attributable to common stockholders is the same as basic net loss per share attributable to common stockholders, since dilutive common shares are not assumed to have been issued if their effect is anti-dilutive. The Company reported net income and a net loss attributable to common stockholders for the three months ended September 30, 2021 and 2020, respectively. For the three months ended September 30, 2021, no undistributed earnings were attributed to the convertible preferred shares which converted into common stock upon closing of the merger and have no contractual right to participate in the gains resulting from the change in fair value of earnouts and warrants that occurred after

[0001558370-21-015999:notes:149]
conversion. The Company reported a net loss attributable to common stockholders for the nine months ended September 30, 2021 and 2020.

[0001558370-21-015999:notes:150]
Recently Issued Accounting Pronouncements

[0001558370-21-015999:notes:151]
The Company qualifies as an “emerging growth company” as defined in the Jumpstart Our Business Startups Act of 2012 and has elected not to “opt out” to the extended transition related to complying with new or revised accounting standards, which means that when a standard is issued or revised and it has different application dates for public and nonpublic companies, the Company will adopt the new or revised standard at the time nonpublic companies adopt the new or revised standard and will do so until such time that the Company either (i) irrevocably elects to “opt out” of such extended transition period or (ii) no longer qualifies as an emerging growth company. The Company may choose to early adopt any new or revised accounting standards whenever such early adoption is permitted for nonpublic companies.

[0001558370-21-015999:notes:152]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments — Credit Losses (Topic 326) (“ASU 2016-13”). The new standard adjusts the accounting for assets held at amortized cost basis, including marketable securities accounted for as available for sale, and trade receivables. The standard eliminates the probable initial recognition threshold and requires an entity to reflect its current estimate of all expected credit losses. The allowance for credit losses is a valuation account that is deducted from the amortized cost basis of the financial assets to present the net amount expected to be collected. For public entities except smaller reporting companies, the guidance is effective for annual reporting periods beginning after December 15, 2019 and for interim periods within those fiscal years. In November 2019, the FASB issued ASU No. 2019-10, which deferred the effective date for non-public entities to annual reporting periods beginning after December 15, 2022, including interim periods within those fiscal years. Early application is allowed. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

[0001558370-21-015999:notes:153]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) (“ASU 2016-02”), which sets out the principles for the recognition, measurement, presentation and disclosure of leases for both parties to a contract (i.e., lessees and lessors). The new standard requires lessees to apply a dual approach, classifying leases as either finance or operating leases based on the principle of whether or not the lease is effectively a financed purchase by the lessee. This classification will determine whether lease expense is recognized based on an effective interest method or on a straight-line basis over the term of the lease. A lessee is also required to record a right-of-use asset and a lease liability for all leases with a term of greater than 12 months regardless of their classification. Leases with a term of 12 months or less may be accounted for similar to existing guidance for operating leases today. For nonpublic entities, this guidance is effective for annual periods beginning after December 15, 2021. In July 2018, the FASB issued ASU No. 2018-11, Leases (Topic 842), which added an optional transition method under which financial statements may be prepared under the revised guidance for the year of adoption, but not for prior years. Under the latter method, entities will recognize a cumulative catch-up adjustment to the opening balance of retained earnings in the period of adoption. The Company expects to adopt this guidance effective January 1, 2022, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

[0001558370-21-015999:notes:154]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes (“ASU 2019-12”), which is intended to simplify various areas related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in ASC 740 and also clarifies and amends existing guidance to improve consistent application. For public entities the guidance is effective for annual reporting periods beginning after December 15, 2020 and for interim periods within those fiscal years. For non-public entities, the guidance is effective for annual reporting periods beginning after December 15, 2021 and for interim periods within years beginning after December 15, 2022, with early adoption permitted. The Company expects to adopt this guidance effective January 1, 2022, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

[0001558370-21-015999:notes:155]
In August 2020, the FASB issued ASU 2020-06, “Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity,” which simplifies and clarifies certain calculation and presentation matters related to convertible and equity and debt instruments. Specifically, ASU 2020-06 removes requirements to separately account for conversion features as a derivative under ASC Topic 815 and removing the requirement to account for beneficial conversion features on such instruments. ASU 2020-06 also provides clearer guidance surrounding disclosure of such instruments and provides specific guidance for how such instruments are to be incorporated in the calculation of Diluted EPS. The guidance under ASU 2020-06 is effective for fiscal years beginning after December 15, 2021, including interim periods within those fiscal years. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020. The Company expects to adopt this guidance effective January 1, 2022, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.

[0001558370-21-015999:notes:156]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which amends ASC 805 to add contract assets and contract liabilities to the list of exceptions to the recognition and measurement principles that apply to business combinations and to require that an entity (acquirer) recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Topic 606. The amendments in ASU 2021-08 are effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years and should be applied prospectively to business combinations occurring on or after the effective date of the amendments. Early adoption of the amendments is permitted, including adoption in an interim period. The Company expects to adopt this guidance effective January 1, 2023, and it is currently evaluating the impact on its consolidated financial statements and related disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001558370-21-015999:notes:157]
3. Merger with NHIC

[0001558370-21-015999:notes:158]
On July 16, 2021, we completed the previously announced Merger pursuant to the Agreement and Plan of Merger, dated as of March 5, 2021, and amended by the First Amendment to Agreement and Plan of Merger (the “Merger Agreement”), dated as of June 5, 2021. Upon closing of the Merger, NHIC changed its name to Evolv Technologies Holdings, Inc. and the officers of NHIC, the predecessor company, resigned.  The officers of Legacy Evolv became the officers of the Company, and the Company listed its shares of common stock, par value $0.0001 per share, on Nasdaq under the symbol “EVLV”.

[0001558370-21-015999:notes:159]
The transaction was accounted for as a “reverse recapitalization” in accordance with GAAP. Under this method of accounting, NHIC was treated as the “acquired” company for financial reporting purposes. This determination was primarily based on the fact that subsequent to the Merger, Legacy Evolv’s shareholders have a majority of the voting power of the combined company, Legacy Evolv comprises all of the ongoing operations of the combined entity, Legacy Evolv comprises a majority of the governing body of the combined company, and Legacy Evolv’s senior management comprises all of the senior management of the combined company. Accordingly, for accounting purposes, this transaction was treated as the equivalent of Legacy Evolv issuing shares for the net assets of NHIC, accompanied by a recapitalization. The shares and net loss per common share, prior to the Merger, have been retroactively restated as shares reflecting the Exchange Ratio established in the Merger. The net assets of NHIC were recorded at historical costs,

[0001558370-21-015999:notes:160]
with no goodwill or other intangible assets recorded. Operations prior to the Reverse Recapitalization are those of Legacy Evolv.

[0001558370-21-015999:notes:161]
Upon closing of the Merger each share of NHIC Class B common stock issued and outstanding immediately prior to the effective time of the Merger, which totaled 10,391,513 shares held by the NHIC Initial Shareholders (“Initial Shareholders”), was automatically converted into one validly-issued share of our Class A common stock.

[0001558370-21-015999:notes:162]
In addition, pursuant to the Merger Agreement, certain Legacy Evolv Shareholders became entitled to receive up to 15,000,000 shares of Class A common stock as earn-out shares.

[0001558370-21-015999:notes:163]
Upon closing of the Merger:

[0001558370-21-015999:notes:164]
|  | ● | all of 24,369,613 shares of Legacy Evolv’s Series A-1 convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis; |

[0001558370-21-015999:notes:165]
|  | ● | all of 3,490,328 shares of Legacy Evolv’s Series A convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a two-to-one basis; |

[0001558370-21-015999:notes:166]
|  | ● | all of 34,144,109 shares of Legacy Evolv’s Series B-1 convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis; and |

[0001558370-21-015999:notes:167]
|  | ● | all of 15,373,937 shares of Legacy Evolv’s Series B convertible preferred stock were converted into an equivalent number of shares of Legacy Evolv common stock on a one-to-one basis |

[0001558370-21-015999:notes:168]
On the closing date of the Merger, each share of Legacy Evolv common stock then issued and outstanding was cancelled and the holders thereof in exchange received 94,276,850 shares of the Company’s Class A common stock, which is equal to 0.378 newly-issued shares of the Company’s Class A common stock for each share of Legacy Evolv common stock (the “Exchange Ratio”).

[0001558370-21-015999:notes:169]
All outstanding warrants exercisable for common stock in Legacy Evolv (other than warrants that expired, were exercised or were deemed automatically net exercised immediately prior to the Merger) were exchanged for warrants exercisable for the Company’s Class A common stock with the same terms and conditions except adjusted by the Exchange Ratio.

[0001558370-21-015999:notes:170]
All outstanding stock options of Legacy Evolv common stock, totaling 58,828,853 stock options, were cancelled and the holders thereof in exchange received options to receive 0.378 shares of the Company’s Class A common stock for a total of 22,227,710 stock options. The modification of the stock options to reflect the exchange ratio did not result in an incremental compensation expense upon closing of the Merger.

[0001558370-21-015999:notes:171]
The gross proceeds received from the Merger were $84.9 million and gross proceeds received from the PIPE investment were $300.0 million. Based on the number of shares of common stock outstanding on July 16, 2021 (in each case, not giving effect to any shares issuable upon exercise of warrants, options, or earn-out shares), Legacy Evolv shareholders owned approximately 92.7% of the common stock of the Company and NHIC shareholders owned approximately 7.3%.

[0001558370-21-015999:notes:172]
During the nine months ended September 30, 2021, the Company recorded $35.7 million of offering costs related to third-party legal, accounting, and other professional services to consummate the Merger. These offering costs are recorded as a reduction of additional paid-in capital upon the close of the Merger in the Company’s consolidated

[0001558370-21-015999:notes:173]
balance sheets. The Company expensed $0.7 million of offering costs related to the issuance of the Company’s contingently issuable common stock.


## us-gaap:FairValueDisclosuresTextBlock

[0001558370-21-015999:notes:174]
4. Fair Value Measurements

[0001558370-21-015999:notes:175]
The following tables present information about the Company’s financial assets and liabilities measured at fair value on a recurring basis and indicate the level of the fair value hierarchy used to determine such fair values (in thousands):

[0001558370-21-015999:notes:176]
| ​ | ​ | Fair Value Measurements at September 30, 2021 |
| ​ |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Money market funds | ​ | $ | 326,515 | ​ | $ | — | ​ | $ | — | ​ | $ | 326,515 |
| ​ | ​ | $ | 326,515 | ​ | $ | — | ​ | $ | — | ​ | $ | 326,515 |
| Liabilities: | ​ | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Contingent earn-out liability | ​ | $ | — | ​ | $ | — | ​ | $ | 35,027 | ​ | $ | 35,027 |
| Contingently issuable common stock liability | ​ | ​ | — | ​ | ​ | — | ​ | ​ | 5,952 | ​ | ​ | 5,952 |
| Public Warrant liability | ​ | ​ | — | ​ | ​ | — | ​ | ​ | 20,484 | ​ | ​ | 20,484 |
| ​ | ​ | $ | — | ​ | $ | — | ​ | $ | 61,463 | ​ | $ | 61,463 |

[0001558370-21-015999:notes:177]
| ​ | ​ | Fair Value Measurements as of December 31, 2020 |
| ​ |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Liabilities: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Warrant liability | ​ | $ | — | ​ | $ | — | ​ | $ | 1 | ​ | $ | 1 |
| Derivative liability | ​ |  | — | ​ |  | — | ​ |  | 1,000 | ​ |  | 1,000 |
| ​ | ​ | $ | — | ​ | $ | — | ​ | $ | 1,001 | ​ | $ | 1,001 |

[0001558370-21-015999:notes:178]
During the nine months ended September 30, 2021 and year ended December 31, 2020, respectively, there were no transfers between Level 1, Level 2 and Level 3.

[0001558370-21-015999:notes:179]
Valuation of Common Stock Warrant

[0001558370-21-015999:notes:180]
The warrant liability is related to the warrants (the “Warrants”) to purchase shares of Legacy Evolv’s common stock (see Note 11).

[0001558370-21-015999:notes:181]
The Company used the Black-Scholes option-pricing model, which incorporates assumptions and estimates, to value the warrant liability. Key estimates and assumptions impacting the fair value measurement include (i) the fair value per share of the underlying shares of applicable series of stock issuable upon exercise of the Warrants, (ii) the remaining contractual term of the Warrants, (iii) the risk-free interest rate, (iv) the expected dividend yield and (v) expected volatility of the price of the underlying applicable common stock. The Company estimated the fair value per share of the underlying applicable series of stock based, in part, on the results of third-party valuations and additional factors deemed relevant. The risk-free interest rate was determined by reference to the U.S. Treasury yield curve for time periods approximately equal to the remaining contractual term of the Warrant. The Company estimated a zero expected dividend yield based on the fact that the Company has never paid or declared dividends and does not intend to do so in the foreseeable future. As the Company was a private company up until the closing of the Merger and lacked company-specific historical and implied volatility information of its stock, the expected stock volatility was based on the historical volatility of publicly traded peer companies for a term equal to the remaining contractual term of the Warrant.

[0001558370-21-015999:notes:182]
The following table provides a rollforward of the common stock warrant liability (in thousands):

[0001558370-21-015999:notes:183]
| Balance at December 31, 2020 | ​ | $ | 1 |
| Change in fair value | ​ |  | 879 |
| Conversion of common stock warrant to common stock upon the closing of the Merger | ​ | ​ | (880) |
| Balance at September 30, 2021 | ​ | $ | — |

[0001558370-21-015999:notes:184]
Valuation of Derivative Liability Related to Convertible Notes

[0001558370-21-015999:notes:185]
In September and December 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) (see Note 9). The 2020 Convertible Notes provided a conversion option whereby upon the closing of a specified financing event the Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share of the securities paid by the other investors. This conversion option was determined to be an embedded derivative and was required to be bifurcated and accounted for separately from the 2020 Convertible Notes. The fair value of the derivative liability was determined based on inputs not observable in the market, which represents a Level 3 measurement within the fair value hierarchy.

[0001558370-21-015999:notes:186]
Upon the closing of the 2020 Convertible Notes, management determined that the probability of completing the specified financing event was 100%; thus, the value of the automatic conversion option was deemed to be 20% of the fair value of the capital stock to be issued upon conversion of the 2020 Convertible Notes, or $1.0 million. This amount represented the fair value of the embedded derivative at issuance.

[0001558370-21-015999:notes:187]
Between January 21, 2021 and February 4, 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) (see Note 9). The 2021 Convertible Notes provided a conversion option whereby upon the closing of a specified financing event, the 2021 Convertible Notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to lower of 80% of the price per share of the securities paid by the other investors or price per share at which shares are issued and sold in connection with the conversion or cancellation of convertible notes (other than the 2021 Convertible Notes) or simple agreements for future equity ("SAFEs”) of the Company in such Qualified Financing. This conversion option was determined to be an embedded derivative and was required to be bifurcated and accounted for separately from the 2021 Convertible Notes. The fair value of the derivative liability was determined based on inputs not observable in the market, which represents a Level 3 measurement within the fair value hierarchy.

[0001558370-21-015999:notes:188]
Upon the closing of the 2021 Convertible Notes, management determined that the probability of completing the specified financing event was 80%; thus, the value of the automatic conversion option was deemed to be 20% of the fair value of the capital stock to be issued upon conversion of the 2021 Convertible Notes, or $7.0 million. This amount represented the fair value of the embedded derivative at issuance. At the closing of the Merger, the fair value of the derivative liability was $9.2 million. On June 21, 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. The modification of the 2021 Convertible Notes resulted in the recognition of an additional $9.8 million derivative liability for the fair value of the 1,000,000 NHIC shares as of June 21, 2021 (see Note 9). Prior to the closing of the Merger, the change in fair value of the derivative liability was $0.5 million.

[0001558370-21-015999:notes:189]
The following table provides a rollforward of the derivative liability (in thousands):

[0001558370-21-015999:notes:190]
| Balance at December 31, 2020 | ​ | $ | 1,000 |
| Initial fair value of the embedded derivative | ​ | ​ | 16,986 |
| Change in fair value | ​ |  | 1,745 |
| Settlement of derivative liability upon the closing of the Merger | ​ | ​ | (19,731) |
| Balance at September 30, 2021 | ​ | $ | — |

[0001558370-21-015999:notes:191]
Valuation of Contingent Earn-out

[0001558370-21-015999:notes:192]
Pursuant to the Merger Agreement, the Legacy Evolv shareholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 2. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability on the closing of the Merger and are remeasured at each reporting period. As of September 30, 2021, no milestones have been achieved.

[0001558370-21-015999:notes:193]
The estimated fair value of the initial contingent earn-out is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. As of September 30, 2021, the contingent earn-out was revalued using a similar Monte Carlo analysis. The significant assumptions to the model as of the Merger Date were as follows: 40% of expected stock price volatility, a drift rate of 0.9%, 0% change in control and an expected term of 5 years. The significant assumptions to the model as of September 30, 2021 were as follows: 45% of expected stock price volatility, a drift rate of 0.9%, 0% of change in control and an expected term of 4.8 years.

[0001558370-21-015999:notes:194]
The following table provides a rollforward of the contingent earn-out liability (in thousands):

[0001558370-21-015999:notes:195]
| Balance at December 31, 2020 | ​ | $ | — |
| Initial fair value of the instrument | ​ | ​ | 66,845 |
| Change in fair value | ​ |  | (31,818) |
| Balance at September 30, 2021 | ​ | $ | 35,027 |

[0001558370-21-015999:notes:196]
Valuation of Contingently Issuable Common Stock

[0001558370-21-015999:notes:197]
Prior to the Merger, certain NHIC shareholders owned 4,312,500 Founder Shares. 1,897,500 shares vested at the closing of the Merger and the remaining 1,897,500 outstanding shares shall vest upon the Company achieving certain milestones (see Note 2). The Company’s contingently issuable common stock was recorded at fair value as contingent shares on the closing of the Merger and will be remeasured at each reporting period. As of September 30, 2021, no milestones have been achieved.

[0001558370-21-015999:notes:198]
The estimated fair value of the initial contingently issued common shares are determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. As of September 30, 2021, the contingently issuable common shares were revalued using a similar Monte Carlo analysis. The significant assumptions to the model as of the Merger Date were as follows: 40% of expected stock price volatility, a drift rate of 0.9%, 0% change in control and an expected term of 5 years. The significant assumptions to the model as of September 30, 2021 were as follows: 45% of expected stock price volatility, a drift rate of 0.9%, 0% of change in control and an expected term of 4.8 years.

[0001558370-21-015999:notes:199]
The following table provides a rollforward of the contingently issuable common shares (in thousands):

[0001558370-21-015999:notes:200]
| Balance at December 31, 2020 | ​ | $ | — |
| Initial fair value of the instrument | ​ | ​ | 11,670 |
| Change in fair value | ​ |  | (5,718) |
| Balance at September 30, 2021 | ​ | $ | 5,952 |

[0001558370-21-015999:notes:201]
Valuation of Public Warrant Liability

[0001558370-21-015999:notes:202]
Upon the closing of the Merger, the Company assumed the Public Warrant to purchase shares of the Company’s common stock (see Note 11). The Public Warrants are publicly traded and the initial fair value of the public warrants were based on the closing price as reported by Nasdaq on the date of the Merger and remeasured at each reporting period.

[0001558370-21-015999:notes:203]
The following table provides a rollforward of the public warrant liability (in thousands):

[0001558370-21-015999:notes:204]
| Balance at December 31, 2020 | ​ | $ | — |
| Initial fair value of the instrument | ​ | ​ | 23,636 |
| Change in fair value | ​ |  | (3,152) |
| Balance at September 30, 2021 | ​ | $ | 20,484 |


## us-gaap:InventoryDisclosureTextBlock

[0001558370-21-015999:notes:205]
5. Inventory

[0001558370-21-015999:notes:206]
Inventory consisted of the following (in thousands):

[0001558370-21-015999:notes:207]
| ​ | ​ | September 30, | ​ | December 31, | ​ |
| ​ |  | 2021 |  | 2020 | ​ |
| Raw materials | ​ | $ | 606 | ​ | $ | 499 | ​ |
| Work in process | ​ |  | — | ​ |  | 188 | ​ |
| Finished goods | ​ |  | 2,924 | ​ |  | 2,055 | ​ |
| Total | ​ | $ | 3,530 | ​ | $ | 2,742 | ​ |


## nhic:PrepaidExpenseAndOtherAssetsCurrentTextBlock

[0001558370-21-015999:notes:208]
6. Prepaid expenses and other current assets

[0001558370-21-015999:notes:209]
Prepaid expenses and other current assets consisted of the following (in thousands):

[0001558370-21-015999:notes:210]
| ​ | ​ | September 30, | ​ | December 31, |
| ​ |  | 2021 |  | 2020 |
| Prepaid deposits | ​ | $ | 8,486 | ​ | $ | — |
| Prepaid insurance | ​ | ​ | 3,826 | ​ | ​ | 240 |
| Short-term contract assets | ​ | ​ | 895 | ​ | ​ | — |
| Prepaid subscriptions | ​ | ​ | 383 | ​ | ​ | 594 |
| Other | ​ |  | 82 | ​ |  | 66 |
| Total | ​ | $ | 13,672 | ​ | $ | 900 |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001558370-21-015999:notes:211]
7. Property and Equipment, Net

[0001558370-21-015999:notes:212]
Property and equipment, net consisted of the following (in thousands):

[0001558370-21-015999:notes:213]
| ​ | ​ | September 30, | ​ | December 31, | ​ |
| ​ |  | 2021 |  | 2020 | ​ |
| Computers and telecom equipment | ​ | $ | 216 | ​ | $ | 217 | ​ |
| Lab equipment | ​ |  | 568 | ​ |  | 487 | ​ |
| Software | ​ |  | 58 | ​ |  | 59 | ​ |
| Furniture and fixtures | ​ |  | 37 | ​ |  | 37 | ​ |
| Leasehold improvements | ​ |  | 553 | ​ |  | 95 | ​ |
| Leased equipment | ​ |  | 19,484 | ​ |  | 10,948 | ​ |
| ​ | ​ |  | 20,916 | ​ |  | 11,843 | ​ |
| Less: Accumulated depreciation and amortization | ​ |  | (3,133) | ​ |  | (2,527) | ​ |
| ​ | ​ | $ | 17,783 | ​ | $ | 9,316 | ​ |

[0001558370-21-015999:notes:214]
Depreciation and amortization expense related to property and equipment was $0.8 million and $0.3 million for the three months ended September 30, 2021 and 2020, and $1.9 million and $0.7 million for the nine months ended September 30, 2021, and 2020, respectively.

[0001558370-21-015999:notes:215]
Leased equipment and the related accumulated depreciation were as follows:

[0001558370-21-015999:notes:216]
| ​ | ​ | September 30, | ​ | December 31, | ​ |
| ​ |  | 2021 |  | 2020 | ​ |
| Leased equipment | ​ | $ | 19,484 | ​ | $ | 10,948 | ​ |
| Accumulated depreciation | ​ |  | (2,180) | ​ |  | (1,649) | ​ |
| Leased equipment, net | ​ | $ | 17,304 | ​ | $ | 9,299 | ​ |

[0001558370-21-015999:notes:217]
Depreciation related to leased units was $0.8 million and $0.2 million during the three months ended September 30, 2021 and 2020, respectively. Depreciation expense related to leased units was $1.8 million and $0.6 million during the nine months ended September 30, 2021 and 2020, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.

[0001558370-21-015999:notes:218]
Impairment of property and equipment was $1.7 million for the three and nine months ended September 30, 2021. There was no impairment for the three and nine months ended September 30, 2020. This related to Edge units and prototype versions of Express that were removed from service and retired. The Company is transitioning domestic customers to Express which decreased the economic value of these assets and resulted in impairment.


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0001558370-21-015999:notes:219]
8. Accrued Expenses and Other Current Liabilities

[0001558370-21-015999:notes:220]
Accrued expenses and other current liabilities consisted of the following (in thousands):

[0001558370-21-015999:notes:221]
| ​ | ​ | September 30, | ​ | December 31, | ​ |
| ​ |  | 2021 |  | 2020 | ​ |
| Accrued employee compensation and benefits expense | ​ | $ | 3,766 | ​ | $ | 2,345 | ​ |
| Accrued professional services and consulting | ​ |  | 1,487 | ​ |  | 1,327 | ​ |
| Accrued interest | ​ | ​ | 131 | ​ | ​ | — | ​ |
| Other | ​ |  | 785 | ​ |  | 55 | ​ |
| ​ | ​ | $ | 6,169 | ​ | $ | 3,727 | ​ |


## us-gaap:DebtDisclosureTextBlock

[0001558370-21-015999:notes:222]
9. Long-term Debt

[0001558370-21-015999:notes:223]
The components of the Company’s long-term debt consisted of the following (in thousands):

[0001558370-21-015999:notes:224]
| ​ | ​ | September 30, | ​ | December 31, | ​ |
| ​ |  | 2021 |  | 2020 | ​ |
| Term loans payable | ​ | $ | 10,000 | ​ | $ | 10,000 | ​ |
| Revolving line of credit outstanding | ​ |  | 5,422 | ​ |  | 3,550 | ​ |
| Convertible note | ​ |  | — | ​ |  | 3,000 | ​ |
| Less: Unamortized discount | ​ |  | (63) | ​ |  | (118) | ​ |
| ​ | ​ |  | 15,359 | ​ |  | 16,432 | ​ |
| Less: Current portion of long-term debt | ​ |  | 1,000 | ​ |  | — | ​ |
| Long-term debt, net of discount | ​ | $ | 14,359 | ​ | $ | 16,432 | ​ |

[0001558370-21-015999:notes:225]
Term Loan Agreements

[0001558370-21-015999:notes:226]
Silicon Valley Bank (“SVB”) Term Loan

[0001558370-21-015999:notes:227]
On July 5, 2017, the Company entered into a $5.0 million Loan and Security Agreement with Silicon Valley Bank (“2017 SVB Term Loan”), which provided the Company with a first term loan advance of $4.0 million which was drawn down on July 5, 2017 (“Term Loan A Advance”) and a second term loan advance of $1.0 million that was available to be drawn down until May 31, 2018 (“Term Loan B Advance”; collectively, “Term Loan Advances”). The agreement also provided the Company with a revolving line of credit of up to $1.0 million. Interest payments were due monthly and commenced upon receipt of principal. Principal was payable in 36 monthly payments and commenced on June 1, 2018. The 2017 SVB Term Loan accrued interest at an annual rate calculated as the Wall Street Journal Prime Rate plus 1.25%.

[0001558370-21-015999:notes:228]
On February 12, 2019, the Company amended the 2017 SVB Term Loan (“2019 Term Loan Advance”) to change the interest rate to the greater of the (A) Wall Street Journal Prime Rate or (B) 5.25%. Additionally, the maturity date was extended to August 2022. Upon closing, the Company issued warrants to purchase 28,350 shares of common stock to SVB with an exercise price of $0.24 per share (see Note 11).

[0001558370-21-015999:notes:229]
As of December 31, 2019, the Company was not in compliance with certain reporting related covenants within the SVB Loan and Security Agreement. As a result, SVB had the right to call for prepayment of the debt and it was therefore considered current as of December 31, 2019.

[0001558370-21-015999:notes:230]
In March 2020, the Company entered into a Loan Modification Agreement with SVB (“2020 SVB Term Loan”), which provided a $5.0 million term loan and a revolving line of credit of up to $7.0 million. The Company repaid the outstanding balance owed on the 2017 SVB Term Loan of $3.1 million of principal and accrued interest with the proceeds from the 2020 SVB Term Loan. The Loan Modification Agreement with SVB resulted in the Company being in compliance with certain reporting related covenants.

[0001558370-21-015999:notes:231]
Additionally, upon closing, the Company issued warrants to purchase 280,095 shares of common stock to SVB with an exercise price of $0.40 per share with a fair value of less than $0.1 million on the date of issuance. The Company also paid debt issuance costs of less than $0.1 million and owed an end-of-term charge of $0.1 million to SVB. The debt issuance costs were recorded as debt discount and were being amortized to interest expense, using the effective interest method, over the term of the loan. The 2020 SVB Term Loan interest was payable monthly and the principal was payable in 36 monthly payments commencing on April 1, 2021. The 2020 SVB Term Loan accrued interest at an annual

[0001558370-21-015999:notes:232]
rate calculated as the greater of (A) Wall Street Journal Prime Rate plus 0.50% or (B) 5.0%. In December 2020, the Company repaid the outstanding balance on the 2020 SVB Term loan of $8.0 million.

[0001558370-21-015999:notes:233]
JPMorgan Chase Bank, N.A.(“JPM”) Credit Agreement

[0001558370-21-015999:notes:234]
In December 2020, the Company entered into a $10.0 million credit agreement with JPMorgan Chase Bank, N.A. (“JPM Credit Agreement”) with a maturity date of December 3, 2024 and a revolving line of credit of up to $10.0 million with a maturity date of December 3, 2022. The Company repaid the outstanding balance on the 2020 SVB Term Loan Advance, including the $5.0 million in principal and $3.0 million outstanding on the revolving line of credit. Upon repayment of the outstanding amounts, the Company recorded a loss on extinguishment of debt of less than $0.1 million, which was included in interest expense in the December 31, 2020 consolidated statements of operations and comprehensive income (loss).

[0001558370-21-015999:notes:235]
Principal and interest on the JPM Credit Agreement is payable monthly commencing on July 1, 2022. The JPM Credit Agreement accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 2.25% or (B) 5.5%. The revolving line of credit accrues interest at an annual rate calculated as the greater of (A) the Wall Street Journal Prime Rate plus 1.25% or (B) 4.5%. Upon closing, the Company issued warrants to purchase 378,000 shares of common stock to the lender with an exercise price of $0.42 per share with a fair value of $0.1 million on the date of issuance. The Company incurred debt issuance costs of $0.1 million equal to the fair value of the warrants in connection with the JPM Credit Agreement. These costs were recorded as debt discount and are amortized to interest expense, using the effective interest method, over the term of the loan.

[0001558370-21-015999:notes:236]
As of September 30, 2021, the unamortized debt discount was $0.1 million. As of September 30, 2021, the accrued interest on the JPM Credit Agreement was $0.1 million, which is included in accrued expenses and other current liabilities in the consolidated balance sheet. Interest expense totaled $0.2 million for the three months ended September 30, 2021, which includes the amortization of the debt discount which totaled less than $0.1 million. Interest expense totaled $0.6 million for the nine months ended September 30, 2021, which includes the amortization of the debt discount which totaled less than $0.1 million. The interest rate in effect as of September 30, 2021 was 5.5% and 4.5% for the JPM Credit Agreement and revolving line of credit, respectively. As of September 30, 2021, the Company has drawn down $5.4 million on the revolving line of credit.

[0001558370-21-015999:notes:237]
The Company’s obligations under the JPM Credit Agreement are secured by a first-priority security interest in all of its assets, including intellectual property.

[0001558370-21-015999:notes:238]
As of September 30, 2021, future principal payments on long-term debt are as follows (in thousands):

[0001558370-21-015999:notes:239]
| Year Ending December 31, |  | ​ | ​ |
| 2021 (remaining three months) | ​ | $ | — |
| 2022 | ​ |  | 7,422 |
| 2023 | ​ |  | 4,000 |
| 2024 | ​ |  | 4,000 |
| 2025 | ​ | ​ | — |
| ​ | ​ | $ | 15,422 |

[0001558370-21-015999:notes:240]
Convertible Note

[0001558370-21-015999:notes:241]
In September 2020, the Company entered into a Convertible Note Purchase Agreement (the “2020 Convertible Notes”) with an investor for gross proceeds of $2.0 million with a stated interest rate of 6.0% per annum. An additional $2.0 million in gross proceeds were made available in December 2020 upon achievement of the integration milestone,

[0001558370-21-015999:notes:242]
whereby the Company successfully created software utilizing the investor’s application programming interface. The 2020 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds of the issuance of preferred stock totaled at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2020 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $1.0 million, and the notes, with an initial carrying value of $3.0 million, and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of September 30, 2021 as the liability was settled pursuant to the closing of the merger.

[0001558370-21-015999:notes:243]
As of September 30, 2021 and December 31, 2020, the accrued interest on the 2020 Convertible Notes was $0 and less than $0.1 million, respectively. Interest expense totaled less than $0.1 million and $0.3 million for the three and nine months ended September 30, 2021, respectively. Interest expense totaled less than $0.1 million for the three and nine months ended September 30, 2020, respectively.

[0001558370-21-015999:notes:244]
Between January 21, 2021 and February 4, 2021, the Company entered into a Convertible Note Purchase Agreement (the “2021 Convertible Notes”) with various investors for gross proceeds of $30.0 million with a stated interest rate of 8.0% per annum. The 2021 Convertible Notes provided a conversion option whereby upon the closing of a Qualified Financing event, in which the aggregate gross proceeds totaled at least $100.0 million, the notes would automatically convert into shares of the same class and series of capital stock of the Company issued to other investors in the financing at a conversion price equal to 80% of the price per share paid by the other investors. The conversion option met the definition of an embedded derivative and was required to be bifurcated and accounted for separately from the notes. The proceeds from the 2021 Convertible Notes were allocated between the derivative liability, with a fair value at issuance of $7.0 million, and the notes, with an initial carrying value of $23.0 million, and included in long-term liabilities on the Company’s consolidated balance sheet. The difference between the initial carrying value of the notes and the stated value of the notes represented a discount that was accreted to interest expense over the term of the Convertible Notes using the effective interest method. This derivative liability was derecognized as of September 30, 2021 as the liability was settled pursuant to the closing of the merger.

[0001558370-21-015999:notes:245]
On June 21, 2021, the Company modified the 2021 Convertible Notes to grant the holders an additional 1,000,000 shares of NHIC common stock as further consideration upon the automatic conversion of the notes upon closing of the Merger. This modification of the notes resulted in an extinguishment and the Company recognized a loss on extinguishment of the 2021 Convertible Notes of $11.8 million. The $26.7 million carrying value of the notes at June 21, 2021 was derecognized and replacement notes with an initial carrying value of $29.6 million were recorded. Additionally, in the extinguishment accounting, a derivative liability of $19.2 million was recognized, which represents the value of the 1,000,000 NHIC shares as well as a bifurcated embedded derivative for the conversion option.

[0001558370-21-015999:notes:246]
Upon the closing of the Merger, the Convertible Notes automatically converted into 4,408,672 shares of the Company’s common stock and the holders of the 2021 Convertible Notes also received the right to receive 1,000,000 shares of the Company’s common stock, as noted above. Upon the conversion of the Convertible Notes, the carrying value of the debt of $32.8 million, and the related derivative liability of $19.7 million and accrued interest of $0.2 million were derecognized resulting in a loss on extinguishment of debt of $0.9 million recorded in other income (expense).

[0001558370-21-015999:notes:247]
As of September 30, 2021 and December 31, 2020, the accrued interest on the 2021 Convertible Notes was $0. Interest expense totaled less than $0.1 million and $4.9 million for the three and nine months ended September 30, 2021, respectively.


## nhic:TemporaryEquityDisclosureTextBlock

[0001558370-21-015999:notes:248]
10. Convertible Preferred Stock

[0001558370-21-015999:notes:249]
Prior to the Merger, Legacy Evolv had issued Series A convertible preferred stock (“Series A Preferred Stock”), Series A-1 convertible preferred stock (“Series A-1 Preferred Stock”), Series B convertible preferred stock (“Series B Preferred Stock”), and Series B-1 convertible preferred stock (“Series B-1 Preferred Stock”), collectively referred to as the “Preferred Stock”.

[0001558370-21-015999:notes:250]
In February and March 2020, Legacy Evolv issued and sold an additional 3,207,773 shares of Series B-1 Preferred Stock at a price of $0.9664 per share for aggregate proceeds of $3.1 million, excluding issuance costs of $0.1 million.

[0001558370-21-015999:notes:251]
Pursuant to the Merger Agreement, immediately prior to the Merger, each share of Legacy Evolv’s preferred stock outstanding converted to Legacy Evolv common stock on a 1:1 conversion ratio. On the closing date of the Merger, each share of Legacy Evolv common stock then issued and outstanding was cancelled and the holders thereof in exchange received shares of Evolv Technologies Holdings, Inc. equal to 0.378 shares for each share of Legacy Evolv common stock. As of September 30, 2021, the Company’s amended certificate of incorporation authorized the issuance of 100,000,000 shares of preferred stock at a $0.0001 par value common stock. As of September 30, 2021, the Company has no preferred stock outstanding as all convertible preferred stock converted to common stock upon closing of the Merger. As of December 31, 2020, the Preferred Stock consisted of the following (in thousands, except share amounts):

[0001558370-21-015999:notes:252]
| ​ | ​ | December 31, 2020 |
| ​ |  | ​ |  | Preferred Stock |  | ​ | ​ |  | ​ | ​ |  | Common Stock |
| ​ | ​ | Preferred Stock | ​ | Issued and | ​ | Carrying | ​ | Liquidation | ​ | Issuable Upon |
| ​ | ​ | Authorized | ​ | Outstanding | ​ | Value | ​ | Preference | ​ | Conversion |
| Series A-1 Preferred Stock |  | 67,156,152 | ​ | 24,369,613 | ​ | $ | 18,394 | ​ | $ | 18,000 |  | 24,369,613 |
| Series A Preferred Stock |  | 9,233,677 | ​ | 3,490,328 | ​ |  | 11,321 | ​ |  | 11,819 |  | 6,986,113 |
| Series B-1 Preferred Stock |  | 90,328,396 | ​ | 34,144,109 | ​ |  | 31,953 | ​ |  | 32,997 |  | 34,144,109 |
| Series B Preferred Stock |  | 40,671,814 | ​ | 15,373,937 | ​ |  | 14,209 | ​ |  | 14,284 |  | 15,373,937 |
| ​ |  | 207,390,039 |  | 77,377,987 | ​ | $ | 75,877 | ​ | $ | 77,100 |  | 80,873,772 |


## nhic:WarrantsAndRightsNoteDisclosureTextBlock

[0001558370-21-015999:notes:253]
11. Warrants

[0001558370-21-015999:notes:254]
In February 2019, in connection with the 2019 Term Loan Advance, the Company issued a warrant to SVB for the purchase of 28,350 shares of common stock at an exercise price of $0.24 per share (the “2019 SVB common stock warrant”). The 2019 SVB common stock warrant was immediately exercisable and expires in February 2029. The warrant was classified as an equity instrument and recorded at its fair value of less than $0.1 million on the date of issuance through additional paid-in-capital. In connection with the closing of the Merger, all of the outstanding 2019 SVB common stock warrants were converted into shares of the Company’s common stock.

[0001558370-21-015999:notes:255]
In March 2020, in connection with the 2020 Term Loan Advance, the Company issued a warrant to SVB for the purchase of 280,095 shares of common stock at an exercise price of $0.40 per share (the “2020 SVB common stock warrant”). The 2020 SVB common stock warrant was immediately exercisable and expires in March 2030. The warrant was classified as an equity instrument and recorded at its fair value of less than $0.1 million on the date of issuance through additional paid-in-capital. In connection with the closing of the Merger, all of the outstanding 2020 SVB common stock warrants were converted into shares of the Company’s common stock.

[0001558370-21-015999:notes:256]
In December 2020, in connection with the JPM Term Loan, the Company issued a warrant to JPM for the purchase of 378,000 shares of common stock at an exercise price of $0.42 per share (the “2020 JPM common stock

[0001558370-21-015999:notes:257]
warrant”). The 2020 JPM common stock warrant was immediately exercisable and expires in December 2030. The warrant was classified as an equity instrument and recorded at its fair value of $0.1 million on the date of issuance through additional paid-in-capital. In connection with the closing of the Merger, all of the outstanding 2020 JPM common stock warrants were converted into shares of the Company’s common stock.

[0001558370-21-015999:notes:258]
In connection with the closing of the Merger, the Company assumed the Public Warrant for the purchase of 14,325,000 shares of common stock at an exercise price of $11.50. The public warrant is immediately exercisable and expires in July 2026. The Public Warrant is classified as a liability and recorded at its fair value of $23.6 million on the date of issuance of the Merger with an offset to additional paid-in-capital and is subsequently remeasured to fair value at each reporting date based on the publicly available trading price. The change in fair value of the public warrant liability of $3.2 million was recognized as a component of other income (expense), net in the consolidated statements of operations and comprehensive income (loss) for the three and nine months ended September 30, 2021.

[0001558370-21-015999:notes:259]
As of September 30, 2021 and December 31, 2020, warrants to purchase the following classes of Preferred Stock and common stock outstanding consisted of the following in the table below.

[0001558370-21-015999:notes:260]
| September 30, 2021 |
| ​ | ​ | Contractual | ​ | ​ | ​ | ​ | ​ | Shares Issuable | ​ | Weighted |
| ​ | ​ | Term | ​ | Underlying Equity | ​ | Balance Sheet | ​ | Upon Exercise | ​ | Average |
| Issuance Date |  | (in years) |  | Instrument |  | Classification |  | of Warrant |  | Exercise Price |
| July 16, 2021 |  | 5 |  | Common stock |  | Liability |  | 14,325,000 | ​ | $ | 11.50 |
| ​ | ​ | ​ |  |  |  |  |  | 14,325,000 | ​ |  |  |

[0001558370-21-015999:notes:261]
| December 31, 2020 |
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Shares Issuable | ​ | Weighted |
| ​ | ​ | Contractual | ​ | Underlying Equity | ​ | Balance Sheet | ​ | Upon Exercise of | ​ | Average |
| Issuance Date |  | Term |  | Instrument |  | Classification |  | Warrant |  | Exercise Price |
| ​ | ​ | (in years) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| March 17, 2014 |  | 10 |  | Common stock |  | Liability |  | 94,500 | ​ | $ | 0.24 |
| September 28, 2016 |  | 10 |  | Preferred Stock |  | Temporary Equity |  | 1,015,401 | ​ | $ | 0.003 |
| July 5, 2017 |  | 10 |  | Common stock |  | Equity |  | 141,750 | ​ | $ | 0.24 |
| February 12, 2019 |  | 10 |  | Common stock |  | Equity |  | 28,350 | ​ | $ | 0.24 |
| March 30, 2020 |  | 10 |  | Common stock |  | Equity |  | 280,095 | ​ | $ | 0.40 |
| December 3, 2020 |  | 10 |  | Common stock |  | Equity |  | 378,000 | ​ | $ | 0.42 |
| ​ | ​ | ​ |  |  |  |  |  | 1,938,096 | ​ |  |  |


## nhic:CommonStockDisclosureTextBlock

[0001558370-21-015999:notes:262]
12. Common Stock

[0001558370-21-015999:notes:263]
As of September 30, 2021 and December 31, 2020, the Company’s amended certificate of incorporation authorized the issuance of 1,100,000,000 and 305,491,899 shares of $0.0001 par value common stock, respectively.

[0001558370-21-015999:notes:264]
Each share of common stock entitles the holder to one vote on all matters submitted to a vote of the Company’s stockholders. Common stockholders are entitled to receive dividends, as may be declared by the board of directors, subject to the preferential dividend rights of Preferred Stock. As of September 30, 2021 and December 31, 2020, no cash dividends had been declared or paid.

[0001558370-21-015999:notes:265]
On the closing of the Merger, the total 10,391,513 of the NHIC ordinary shares held by the NHIC Initial Shareholders and public shareholders were converted into the same number of the Company’s common stock.

[0001558370-21-015999:notes:266]
On July 16, 2021 and prior to the closing of the Merger, various PIPE investors purchased 30,000,000 shares of the Company’s common stock at a price of $10.00 per share for gross proceeds of $300.0 million.

[0001558370-21-015999:notes:267]
As of September 30, 2021 and December 31, 2020, the Company had reserved 109,632,431 and 102,570,639 shares, respectively, of common stock for the conversion of the outstanding Preferred Stock, exercise of outstanding stock options, granting of awards under the Company’s 2021 Equity Incentive Plan and 2013 Equity Incentive Plan (see Note 13) and the exercise of outstanding warrants (including warrants to purchase Preferred Stock as if converted to common stock). (see Note 11)


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001558370-21-015999:notes:268]
13. Stock-Based Compensation

[0001558370-21-015999:notes:269]
2013 Equity Incentive Plan

[0001558370-21-015999:notes:270]
The Company’s 2013 Equity Incentive Plan (the “2013 Plan”) provides for the Company to grant incentive stock options or nonqualified stock options, restricted stock awards and other stock-based awards to employees, officers, directors and non-employees of the Company. Per the initial terms of the 2013 Plan, up to 1,078,169 shares of common stock may be issued.

[0001558370-21-015999:notes:271]
At September 30, 2021 and December 31, 2020, shares of common stock that may be issued under the 2013 Plan were 0 and 21,487,876, respectively. As of September 30, 2021 and December 31, 2020, 0 shares and 979,852 shares, respectively, remained available for future grant under the 2013 Plan. Shares that are expired, forfeited, canceled or otherwise terminated without having been fully exercised will be available for future grant under the 2013 Plan. In addition, shares of common stock that are tendered to the Company by a participant to exercise an award are added to the number of shares of common stock available for future grants.

[0001558370-21-015999:notes:272]
The 2013 Plan is administered by the Board of Directors or, at the discretion of the Board of Directors, by a committee of the Board of Directors. The exercise prices, vesting and other restrictions are determined at the discretion of the Board of Directors, or its committee if so delegated, except that the exercise price per share of stock options may not be less than 100% of the fair market value of a share of common stock on the date of grant and the term of the stock option may not be greater than ten years. Stock options granted to employees, officers, members of the Board of Directors and non-employees typically vest over a four-year period. The Company’s Board of Directors values the Company’s common stock, taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors which may have changed since the date of the most recent contemporaneous valuation through the date of grant.

[0001558370-21-015999:notes:273]
2021 Equity Incentive Plan

[0001558370-21-015999:notes:274]
The Company’s 2021 Equity Incentive Plan (the “2021 Plan”) provides for the Company to grant incentive stock options or nonqualified stock options, restricted stock awards and other stock-based awards to employees, officers, directors and non-employees of the Company. Per the initial terms of the 2021 Plan, up to 21,177,295 shares of common stock may be issued.

[0001558370-21-015999:notes:275]
At September 30, 2021, shares of common stock that may be issued under the 2021 Plan were 21,177,295. As of September 30, 2021, 19,795,381 shares remained available for future grant under the 2021 Plan. Shares that are expired, forfeited, canceled or otherwise terminated without having been fully exercised will be available for future grant under the 2021 Plan. In addition, shares of common stock that are tendered to the Company by a participant to exercise an award are added to the number of shares of common stock available for future grants.

[0001558370-21-015999:notes:276]
The 2021 Plan is administered by the Board of Directors or, at the discretion of the Board of Directors, by a committee of the Board of Directors. The exercise prices, vesting and other restrictions are determined at the discretion of the Board of Directors, or its committee if so delegated, except that the exercise price per share of stock options may not be less than 100% of the fair market value of a share of common stock on the date of grant and the term of the stock option may not be greater than ten years. Stock options granted to employees, officers, members of the Board of Directors and non-employees vesting terms are determined on an individual basis on the date of grant. The Company’s Board of Directors values the Company’s Common stock, taking into consideration its most recently available valuation of common stock performed by third parties as well as additional factors which may have changed since the date of the most recent contemporaneous valuation through the date of grant.

[0001558370-21-015999:notes:277]
During the three and nine months ended September 30, 2021, there were no options granted by the Company under the 2021 Plan.

[0001558370-21-015999:notes:278]
2021 Employee Stock Purchase Plan

[0001558370-21-015999:notes:279]
In July 2021, the Company’s board of directors adopted the 2021 Employee Stock Purchase Plan (“2021 ESPP”), which was subsequently approved by the Company’s stockholders and became effective on July 16, 2021. The 2021 ESPP authorizes the initial issuance of up to 3,289,632 shares of the Company’s common stock to eligible employees of the Company or, as designated by the Company’s board of directors, employees of a related company. The 2021 ESPP provides that the number of shares reserved and available for issuance under the 2021 ESPP will automatically increase each January 1, beginning on January 1, 2022 and ending on (and including) January 1, 2032, by an amount equal to the lesser of (i) 1% of the outstanding number of shares of common stock on the immediately preceding December 31 and (ii) 3,289,632 or such lesser number of shares as determined by the Company’s board of directors. As of September 30, 2021, 3,289,632 shares of the Company’s common stock were available for future issuance. The Company’s board of directors may from time to time grant or provide for the grant to eligible employees of options to purchase common stock under the 2021 ESPP during a specific offering period. As of September 30, 2021, no offerings have been approved.

[0001558370-21-015999:notes:280]
During the three months ended September 30, 2021, there were no options granted by the Company. During the nine months ended September 30, 2021, the Company granted 6,474,175 options.

[0001558370-21-015999:notes:281]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted:

[0001558370-21-015999:notes:282]
| ​ | ​ | Nine Months Ended September 30, |  |
| ​ |  | 2021 |  | 2020 |  |
| Risk-free interest rate |  | 0.7 | % | 0.4 | % |
| Expected term (in years) |  | 6.0 | ​ | 5.9 | ​ |
| Expected volatility |  | 31.4 | % | 32.4 | % |
| Expected dividend yield |  | 0.0 | % | 0.0 | % |

[0001558370-21-015999:notes:283]
The following tables summarize the Company’s stock option activity since December 31, 2020 (in thousands, except for share and per share data):

[0001558370-21-015999:notes:284]
| ​ |  | ​ |  | ​ | ​ |  | Weighted |  | ​ | ​ |
| ​ | ​ | ​ | ​ | Weighted | ​ | Average | ​ | ​ | ​ |
| ​ | ​ | Number of | ​ | Average | ​ | Remaining | ​ | Aggregate |
| ​ | ​ | Shares | ​ | Exercise Price | ​ | Contractual Term | ​ | Intrinsic Value |
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | (in years) | ​ | ​ | ​ |
| Outstanding as of December 31, 2020 | ​ | 18,804,634 | ​ | $ | 0.36 | ​ | 7.57 | ​ | $ | 1,054 |
| Granted |  | 6,474,175 |  | ​ | 0.43 |  | 9.28 |  | ​ | 49,284 |
| Exercised |  | (2,399,609) |  | ​ | 0.33 | ​ | 5.62 |  | ​ | 18,508 |
| Exercised upon settlement of related party note | ​ | (1,469,999) | ​ | ​ | 0.24 | ​ | 5.96 | ​ | ​ | 272 |
| Forfeited | ​ | (98,524) |  | ​ | 0.41 |  | — |  | ​ | 752 |
| Outstanding as of September 30, 2021 |  | 21,310,677 | ​ | ​ | 0.40 |  | 8.19 | ​ | $ | 162,662 |
| Vested and expected to vest as of September 30, 2021 |  | 21,310,677 | ​ | $ | 0.40 |  | 8.19 | ​ | $ | 162,662 |
| Options exercisable as of September 30, 2021 |  | 9,615,616 | ​ | $ | 0.37 |  | 7.24 | ​ | $ | 73,813 |

[0001558370-21-015999:notes:285]
The aggregate intrinsic value of options is calculated as the difference between the exercise price of the stock options and the fair value of the Company’s common stock for those options that had exercise prices lower than the fair value of the Company’s common stock.

[0001558370-21-015999:notes:286]
The intrinsic value of stock options exercised during the three months ended September 30, 2021 and 2020 was $2.4 million and less than $0.1 million, respectively, and $18.5 million and $0.1 million for the nine months ended September 30, 2021 and 2020, respectively.

[0001558370-21-015999:notes:287]
There were no options granted during the three months ended September 30, 2021. The weighted average grant-date fair value per share of stock options granted during the three months ended September 30, 2020 was $0.16. The weighted average grant-date fair value per share of stock options granted during the nine months ended September 30, 2021 and 2020 was $0.16 and $0.16, respectively.

[0001558370-21-015999:notes:288]
Restricted Stock Units

[0001558370-21-015999:notes:289]
The following table summarize the Company's restricted stock units activity since December 31, 2020 (in thousands, except for share and per share data):

[0001558370-21-015999:notes:290]
| ​ | ​ | Number of | ​ | Grant Date Fair |
| ​ | ​ | Shares | ​ | Value |
| Outstanding as of December 31, 2020 | ​ | — | ​ | ​ | — |
| Granted |  | 1,670,961 |  | $ | 7.19 |
| Vested |  | — |  | ​ | — |
| Cancelled |  | — |  | ​ | — |
| Outstanding as of September 30, 2021 |  | 1,670,961 | ​ | $ | 7.19 |

[0001558370-21-015999:notes:291]
In March 2021, the Company issued 289,047 shares of RSU’s at a grant date fair value of $8.04 under the 2013 Plan. In September 2021, the Company issued 1,381,914 shares of RSU’s at a grant date fair value of $7.01 under the

[0001558370-21-015999:notes:292]
2021 Plan. The terms of the RSU’s under the 2021 Plan allow for the following vesting periods, which are determined on an individual basis on the date of grant.

[0001558370-21-015999:notes:293]
(A) The RSUs will vest over four years from the Vesting Commencement Date, with 25% of the RSUs vesting on the first anniversary of the Vesting Commencement Date and the remaining RSUs vesting quarterly thereafter over the remaining three years, subject to the individual remaining a Service Provider (as defined in the 2021 Plan) through the applicable vesting date.

[0001558370-21-015999:notes:294]
(B) The RSUs will vest over three years from the Vesting Commencement Date, with one third of the RSUs vesting on the first anniversary of the Vesting Commencement Date and the remaining RSUs vesting annually thereafter over the remaining two years, subject to the individual remaining a Service Provider (as defined in the 2021 Plan) through the applicable vesting date.

[0001558370-21-015999:notes:295]
Warrants to Non-Employee Service Provider

[0001558370-21-015999:notes:296]
In January 2021, in connection with a Business Development Agreement entered into with Finback Evolv II, LLC (“Finback BDA”), the Company issued a warrant to Finback for the purchase of 2,554,014 shares of common stock at an exercise price of $0.42 per share (the “2021 Finback common stock warrants”). The 2021 Finback common stock warrants vest upon meeting certain sales criteria as defined in the agreement and expires in January 2030. The warrants will be accounted for under ASC 718 Compensation – Stock Compensation as the warrants will vest upon certain performance conditions being met.

[0001558370-21-015999:notes:297]
The Company utilized a Black-Scholes pricing model to determine the grant-date fair value of the 2021 Finback common stock warrants granted. The assumptions used are presented in the following table:

[0001558370-21-015999:notes:298]
| Warrants - Black Scholes |  | ​ | ​ |
| Risk-free interest rate |  | 0.4 | % |
| Expected term (in years) |  | 3.0 | ​ |
| Expected volatility |  | 23.9 | % |
| Expected dividend yield |  | 0.0 | % |

[0001558370-21-015999:notes:299]
On the date of issuance, the total value of the 2021 Finback common stock warrants were valued as $19.6 million.

[0001558370-21-015999:notes:300]
As of September 30, 2021, 131,028 shares of the 2021 Finback common stock warrants were exercisable at a total aggregate intrinsic value of $1.0 million. The remaining 2,417,138 shares of the 2021 Finback common stock warrants are unvested and have a total aggregate intrinsic value of $18.4 million. As of September 30, 2021, none of the 2021 Finback common stock warrants were exercised. The Company will recognize compensation expense for the 2021 Finback common stock warrants when the warrants become vested based on meeting the certain sales criteria. During the three and nine months ended September 30, 2021, the Company recorded less than $0.1 million and $1.0 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.

[0001558370-21-015999:notes:301]
Stock-based compensation expense was classified in the consolidated statements of operations and comprehensive income (loss) as follows (in thousands):

[0001558370-21-015999:notes:302]
| ​ | ​ | Three Months Ended September 30, | ​ | Nine Months Ended September 30, |
| ​ |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of revenue | ​ | $ | 29 | ​ | $ | 3 | ​ | $ | 39 | ​ | $ | 7 |
| Sales and marketing | ​ |  | 990 | ​ |  | 41 | ​ |  | 2,298 | ​ |  | 81 |
| General and administrative | ​ |  | 1,045 | ​ |  | 260 | ​ |  | 1,241 | ​ |  | 298 |
| Research and development | ​ |  | 332 | ​ |  | 99 | ​ |  | 435 | ​ |  | 139 |
| Total stock-based compensation expense | ​ | $ | 2,396 | ​ | $ | 403 | ​ | $ | 4,013 | ​ | $ | 525 |

[0001558370-21-015999:notes:303]
Stock-based compensation expense was classified by award type in the consolidated statements of operations and comprehensive loss as follows (in thousands):

[0001558370-21-015999:notes:304]
| ​ | ​ | Three Months Ended September 30, | ​ | ​ | Nine Months Ended September 30, |
| ​ | ​ | 2021 | ​ | 2020 | ​ | ​ | 2021 | ​ | 2020 |
| Stock options | $ | 128 | ​ | $ | 403 | ​ | $ | 595 | ​ | $ | 525 |
| Earn-out shares | ​ | 1,970 | ​ | ​ | — | ​ | ​ | 1,970 | ​ | ​ | — |
| Warrants | ​ | 39 | ​ | ​ | — | ​ | ​ | 1,043 | ​ | ​ | — |
| RSU's | ​ | 259 | ​ | ​ | — | ​ | ​ | 405 | ​ | ​ | — |
| Total stock-based compensation expense | $ | 2,396 | ​ | $ | 403 | ​ | $ | 4,013 | ​ | $ | 525 |

[0001558370-21-015999:notes:305]
Total unrecognized compensation expense related to unvested stock options and unvested restricted stock units as of September 30, 2021, was $3.3 million, which is expected to be recognized over weighted average period of 1.2 years. Total unrecognized compensation expense related to earn-out shares associated with the share-based compensation arrangement as of September 30, 2021, was $13.8 million, which is expected to be recognized over a weighted average period of 1.7 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001558370-21-015999:notes:306]
14. Income Taxes

[0001558370-21-015999:notes:307]
During the three and nine months ended September 30, 2021 and 2020, the Company did not record income tax provisions or income tax benefits due to net operating losses and research and development tax credits not being benefited due to the establishment of the full valuation allowance.

[0001558370-21-015999:notes:308]
The Company’s tax provision and the resulting effective tax rate for interim periods is determined based upon its estimated annual effective tax rate (“AETR”), adjusted for the effect of discrete items arising in that quarter. The impact of such inclusions could result in a higher or lower effective tax rate during a particular quarter, based upon the mix and timing of actual earnings or losses versus annual projections. In each quarter, the Company updates its estimate of the annual effective tax rate, and if the estimated annual tax rate changes, a cumulative adjustment is made in that quarter.

[0001558370-21-015999:notes:309]
The Company has evaluated the positive and negative evidence bearing upon its ability to realize its deferred tax assets, which primarily consist of net operating loss carryforwards. The Company has considered its history of cumulative net losses, estimated future taxable income and prudent and feasible tax planning strategies and has concluded that it is more likely than not that the Company will not realize the benefits of its deferred tax assets. As a result, as of September 30, 2021 and December 31, 2020 the Company has recorded a full valuation allowance against its net deferred tax assets.

[0001558370-21-015999:notes:310]
The Company files U.S. income tax returns as prescribed by the tax laws of the jurisdictions in which it operates. In the normal course of business, the Company is subject to examination by federal and state jurisdictions, where applicable. There are currently no pending tax examinations in the U.S. The Company has not received notice of examination by any jurisdictions in the U.S.


## us-gaap:EarningsPerShareTextBlock

[0001558370-21-015999:notes:311]
15. Net Income (Loss) per Share

[0001558370-21-015999:notes:312]
Basic and diluted net loss per share attributable to common stockholders was calculated as follows (in thousands, except share and per share amounts):

[0001558370-21-015999:notes:313]
| ​ | ​ | Three Months Ended September 30, | ​ | Nine Months Ended September 30, |
| ​ |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Numerator: |  | ​ |  |  | ​ |  | ​ | ​ |  |  | ​ |  |
| Net income (loss) attributable to common stockholders – basic | ​ | $ | 22,751 | ​ | $ | (6,262) | ​ | $ | (13,375) | ​ | $ | (17,796) |
| Change in fair value for warrant liability | ​ | ​ | (42) | ​ | ​ | — | ​ | ​ | — | ​ | ​ | — |
| Interest to convertible notes | ​ | ​ | 123 | ​ | ​ | — | ​ | ​ | — | ​ | ​ | — |
| Loss on extinguishment of debt | ​ | ​ | 865 | ​ | ​ | — | ​ | ​ | — | ​ | ​ | — |
| Change in fair value of derivative liability | ​ | ​ | (475) | ​ | ​ | — | ​ | ​ | — | ​ | ​ | — |
| Net income (loss) attributable to common stockholders – diluted | ​ | $ | 23,222 | ​ | $ | (6,262) | ​ | $ | (13,375) | ​ | $ | (17,796) |
| Denominator: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Weighted average common shares outstanding – basic | ​ |  | 119,745,196 | ​ |  | 8,917,855 | ​ |  | 47,772,253 | ​ |  | 8,892,564 |
| Weighted average effect of potentially dilutive securities: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Effect of potentially dilutive convertible preferred stock | ​ | ​ | 14,065,012 | ​ | ​ | — | ​ | ​ | — | ​ | ​ | — |
| Effect of potentially dilutive warrants | ​ | ​ | 354,135 | ​ | ​ | — | ​ | ​ | — | ​ | ​ | — |
| Effect of potentially dilutive stock options | ​ | ​ | 19,696,440 | ​ | ​ | — | ​ | ​ | — | ​ | ​ | — |
| Effect of potentially dilutive restricted stock units | ​ | ​ | 6,517 | ​ | ​ | — | ​ | ​ | — | ​ | ​ | — |
| Total potentially dilutive securities | ​ | ​ | 34,122,104 | ​ | ​ | — | ​ | ​ | — | ​ | ​ | — |
| Weighted average common shares outstanding — diluted | ​ | ​ | 153,867,300 | ​ | ​ | 8,917,855 | ​ | ​ | 47,772,253 | ​ | ​ | 8,892,564 |
| Net income (loss) per share attributable to common stockholders - basic | ​ | $ | 0.19 | ​ | $ | (0.70) | ​ | $ | (0.28) | ​ | $ | (2.00) |
| Net income (loss) per share attributable to common stockholders - diluted | ​ | $ | 0.15 | ​ | $ | (0.70) | ​ | $ | (0.28) | ​ | $ | (2.00) |

[0001558370-21-015999:notes:314]
The following potentially dilutive outstanding securities were excluded from the computation of diluted net loss per share attributable to common stockholders because their effect would have been anti-dilutive or issuance of such shares is contingent upon the satisfaction of certain conditions which were not satisfied by the end of the period:

[0001558370-21-015999:notes:315]
| ​ | ​ | Three Months Ended September 30, | ​ | Nine Months Ended September 30, | ​ |
| ​ |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |
| Options issued and outstanding |  | 1,589,357 |  | 18,224,891 | ​ | 21,285,797 |  | 18,224,891 | ​ |
| Public Warrants to purchase common stock |  | 14,325,000 |  | — | ​ | 14,325,000 |  | — | ​ |
| Convertible preferred stock (as converted to common stock) |  | — |  | 80,873,820 | ​ | — |  | 80,873,820 | ​ |
| Warrants to purchase preferred stock (as converted to warrants to purchase common stock) |  | — |  | 1,015,401 | ​ | — |  | 1,015,401 | ​ |
| Warrants to purchase common stock | ​ | — | ​ | 544,695 | ​ | ​ | ​ | 544,695 | ​ |
| Warrants to purchase common stock (Finback)** | ​ | 2,417,138 | ​ | — | ​ | 2,421,976 | ​ | ​ | ​ |
| Unvested restricted stock units | ​ | 1,664,567 | ​ | — | ​ | 1,671,084 | ​ | — | ​ |
| Earn-out shares** | ​ | 15,000,000 | ​ | — | ​ | 15,000,000 | ​ | — | ​ |
| Contingently issuable common stock** | ​ | 1,897,500 | ​ | — | ​ | 1,897,500 | ​ | — | ​ |
| Convertible notes (as converted to common stock)* |  | 5,408,672 |  | 590,625 | ​ | 5,408,672 |  | 590,625 | ​ |
| ​ |  | 42,302,234 |  | 101,249,432 | ​ | 62,010,029 |  | 101,249,432 | ​ |

[0001558370-21-015999:notes:316]
* Conversion feature is only triggered upon the closing of a Qualified Financing Event

[0001558370-21-015999:notes:317]
** Issuance of Earn-out shares, Contingently issuable common stock and Finback warrants are contingent upon the satisfaction of certain conditions, which were not satisfied by the end of the period


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001558370-21-015999:notes:318]
16. Related Party Transactions

[0001558370-21-015999:notes:319]
Nonrecourse Promissory Note with Officer

[0001558370-21-015999:notes:320]
In August 2020, the Company entered into a $0.4 million promissory note with an officer with the proceeds being used to exercise options for 1,469,999 shares of common stock at a price of $0.24 per share. The promissory note bore interest at the Wall Street Journal Prime Rate and was secured by the underlying shares of common stock that were issued upon the exercise of the stock options. The promissory note was treated as nonrecourse as the loan was only secured by the common stock issued from the exercise of the stock options. As such, (i) the underlying stock option grant was still considered to be outstanding and the shares of common stock were not considered issued and outstanding for accounting purposes until the loan was repaid in full or otherwise forgiven and (ii) no receivable was recorded for the promissory note on the Company’s consolidated balance sheets. As such, the promissory note effectively extended the maturity date of the option grant for the life of the loan, this change is treated as a stock option modification. The incremental fair value from the stock option modification was deemed immaterial. The interest on this nonrecourse loan is also considered nonrecourse. As the Company has no intent to collect interest, no accrued interest was recorded.

[0001558370-21-015999:notes:321]
In June 2021, the Company agreed to repurchase 43,684 shares of common stock valued at $8.04 per share of common stock held by the officer of the Company. In exchange for the repurchase of the common stock by the Company, the $0.4 million promissory note held by the officer was considered repaid in full.

[0001558370-21-015999:notes:322]
Business Development Agreement with Finback

[0001558370-21-015999:notes:323]
In March 2021, the Company granted a warrant exercisable for 2,554,015 shares of common stock to Finback, a consulting group who is an affiliate of one of the Company’s shareholders, with performance-based vesting conditions which vest upon certain sales being met under a Business Development agreement which has a term of three years.

[0001558370-21-015999:notes:324]
During the three and nine months ended September 30, 2021, the Company recorded less than $0.1 million and $1.0 million, respectively, of stock-based compensation expense within sales and marketing expense for the 2021 Finback common stock warrants.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001558370-21-015999:notes:325]
17. Commitments and Contingencies

[0001558370-21-015999:notes:326]
Operating Leases

[0001558370-21-015999:notes:327]
The Company entered into a new lease agreement for additional office space starting May 1, 2021 through October 31, 2024, with the option to extend through October 31, 2027 with written notice. In May 2021, the Company leased the space. The Company is required to maintain a minimum cash balance of $0.7 million as a security deposit on the space which is classified as restricted cash, current and restricted cash, non-current on the consolidated balance sheet as of September 30, 2021. The Company is generally obligated for the cost of property taxes, insurance, and maintenance relating to this lease.

[0001558370-21-015999:notes:328]
Total future minimum lease payments under this noncancelable operating lease amount to $3.4 million. Rent expense for the three months ended September 30, 2021 and 2020 was approximately $0.3 million and $0.1 million, respectively. Rent expense for the nine months ended September 30, 2021 and 2020 was approximately $0.7 million and $0.3 million, respectively.

[0001558370-21-015999:notes:329]
Future minimum rental commitments to be paid by the Company at September 30, 2021 for this lease is as follows (in thousands):

[0001558370-21-015999:notes:330]
| Year Ending December 31: | ​ |  | ​ |
| 2021 (remaining three months) | ​ | $ | 185 |
| 2022 | ​ | ​ | 1,116 |
| 2023 | ​ |  | 1,150 |
| 2024 | ​ |  | 981 |
| Total future minimum lease payments | ​ | $ | 3,432 |

[0001558370-21-015999:notes:331]
Indemnification Agreements

[0001558370-21-015999:notes:332]
In the ordinary course of business, the Company may provide indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that will require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. To date, the Company has not incurred any material costs as a result of such indemnifications. The Company is not currently aware of any indemnification claims and has not accrued any liabilities related to such obligations in its consolidated financial statements as of September 30, 2021 or December 31, 2020.

[0001558370-21-015999:notes:333]
Legal Proceedings

[0001558370-21-015999:notes:334]
The Company is not a party to any litigation and does not have contingency reserves established for any litigation liabilities. At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses as incurred the costs related to such legal proceedings.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001558370-21-015999:notes:335]
18. Benefit Plans

[0001558370-21-015999:notes:336]
The Company established a defined contribution savings plan under Section 401(k) of the Code. This plan covers all employees who meet minimum age and service requirements and allows participants to defer a portion of their annual compensation on a pre-tax basis. Matching contributions to the plan may be made at the discretion of the Company’s board of directors. The Company did not make contributions to the plan during the three months and nine months ended September 30, 2021 or 2020.
