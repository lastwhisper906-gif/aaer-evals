# EVLV 10-Q controls and the auditor's report


## item_4_controls

[0001558370-21-015999:item_4_controls:1]
Item 4. Controls and Procedures

[0001558370-21-015999:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001558370-21-015999:item_4_controls:3]
Disclosure controls and procedures, as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, means controls and other procedures that are designed to ensure that information required to be disclosed by the issuer in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the Commission’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that such information is accumulated and communicated to management, including its Chief Executive Officer and Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosure.

[0001558370-21-015999:item_4_controls:4]
In designing and evaluating our disclosure controls and procedures, management recognizes that disclosure controls and procedures, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the disclosure controls and procedures are met. Additionally, in designing disclosure controls and procedures, our management necessarily was required to apply its judgment in evaluating the cost-benefit relationship of possible disclosure controls and procedures. The design of any system of controls also is based in part upon certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions; over time, controls may become inadequate because of changes in conditions, or the degree of compliance with policies or procedures may deteriorate. Because of the inherent limitations in a control system, misstatements due to error or fraud may occur and not be detected.

[0001558370-21-015999:item_4_controls:5]
Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, we conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, as of the end of the period covered by this Quarterly Report. Based on this evaluation, because of the material weaknesses in internal control over financial reporting described below, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were not effective at the reasonable assurance level as of September 30, 2021. Notwithstanding these material weaknesses, our Chief Executive Officer and Chief Financial Officer concluded that the financial statements included elsewhere in this Quarterly Report on Form 10-Q present fairly, in all material respects, our financial position, results of operations and cash flows in conformity with generally accepted accounting principles, or GAAP.

[0001558370-21-015999:item_4_controls:6]
Material Weaknesses in Internal Control over Financial Reporting

[0001558370-21-015999:item_4_controls:7]
A material weakness is a deficiency, or combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. We identified the following material weaknesses in our internal control over financial reporting as of December 31, 2020 that continue to exist as of September 30, 2021:

[0001558370-21-015999:item_4_controls:8]
|  | ● | We did not design and maintain an effective control environment commensurate with our financial reporting requirements. Specifically, we lacked a sufficient complement of personnel with an appropriate level of internal controls and accounting knowledge, training and experience commensurate with our financial reporting requirements. Additionally, the limited personnel resulted in our inability to consistently establish appropriate authorities and responsibilities in pursuit of our financial reporting objectives, as demonstrated by, among other things, insufficient segregation of duties in our finance and accounting function. This material weakness contributed to the following material weaknesses. |

[0001558370-21-015999:item_4_controls:9]
26

[0001558370-21-015999:item_4_controls:10]
|  | ● | We did not design and maintain effective controls over the period-end financial reporting process to achieve complete, accurate and timely financial accounting, reporting and disclosures, including the classification of various accounts in the financial statements. |

[0001558370-21-015999:item_4_controls:11]
|  | ● | We did not design and maintain processes and controls to analyze, account for and disclose non-routine, unusual or complex transactions. Specifically, we did not design and maintain controls to timely analyze and account for debt modifications and extinguishments, convertible notes, warrant instruments, and non-routine complex revenue transactions including the leasing of products. |

[0001558370-21-015999:item_4_controls:12]
|  | ● | We did not design and maintain formal accounting policies, procedures and controls to achieve complete, accurate and timely financial accounting, reporting and disclosures, including segregation of duties and controls over the preparation and review of account reconciliations and journal entries. |

[0001558370-21-015999:item_4_controls:13]
These material weaknesses resulted in audit adjustments in historical Evolv financial statements to accounts payable and accrued liabilities, long-term and short-term debt, convertible notes, equity, commission assets, revenue, deferred revenue and various expense line items and related financial statement disclosures, which were recorded prior to the issuance of our consolidated financial statements as of and for the years ended December 31, 2019 and 2020. The material weakness related to accounting for warrant instruments resulted in the restatement of the previously issued financial statements of the entity acquired as part of the July 16, 2021 Merger Agreement related to warrant liabilities and equity. Additionally, these material weaknesses could result in a misstatement of substantially all of our accounts or disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0001558370-21-015999:item_4_controls:14]
|  | ● | We did not design and maintain effective controls over information technology (“IT”) general controls for information systems that are relevant to the preparation of our financial statements, specifically, with respect to: (i) program change management controls for financial systems to ensure that IT program and data changes affecting financial IT applications and underlying accounting records are identified, tested, authorized and implemented appropriately; (ii) user access controls to ensure appropriate segregation of duties and that adequately restrict user and privileged access to financial applications, programs, and data to appropriate company personnel; (iii) computer operations controls to ensure that critical batch jobs are monitored and data backups are authorized and monitored; and (iv) testing and approval controls for program development to ensure that new software development is aligned with business and IT requirements. These IT deficiencies did not result in a misstatement to the financial statements, however, the deficiencies, when aggregated, could impact maintaining effective segregation of duties, as well as the effectiveness of IT-dependent controls (such as automated controls that address the risk of material misstatement to one or more assertions, along with the IT controls and underlying data that support the effectiveness of system-generated data and reports) that could result in misstatements potentially impacting all financial statement accounts and disclosures that would not be prevented or detected. Accordingly, management has determined these deficiencies in the aggregate constitute a material weakness. |

[0001558370-21-015999:item_4_controls:15]
Remediation of Material Weaknesses

[0001558370-21-015999:item_4_controls:16]
We are in the process of designing and implementing controls and taking other actions to remediate the material weaknesses in internal control over financial reporting, including the following:

[0001558370-21-015999:item_4_controls:17]
|  | ● | We are in the process of hiring additional accounting and IT personnel, to bolster our reporting, technical accounting and IT capabilities. Additionally, we are in the process of designing and implementing controls to formalize roles and review responsibilities to align with our team’s skills and experience and designing and implementing controls over segregation of duties. During the three months ended September 30, 2021, we hired a new Vice President of Finance, Controller with an appropriate level of experience and reallocated responsibilities within the accounting organization. |

[0001558370-21-015999:item_4_controls:18]
27

[0001558370-21-015999:item_4_controls:19]
|  | ● | We are in the process of designing and implementing controls related to the period-end financial reporting process and controls over the classification of various accounts in our financial statements. |

[0001558370-21-015999:item_4_controls:20]
|  | ● | We are in the process of designing and implementing controls to timely identify and account for non-routine, unusual or complex transactions, including controls over the preparation and review of accounting memoranda addressing these matters. |

[0001558370-21-015999:item_4_controls:21]
|  | ● | We are in the process of designing and maintaining formal accounting policies, procedures and controls to achieve complete, accurate and timely financial accounting, reporting and disclosures, including controls over the preparation and review of account reconciliations and journal entries. |

[0001558370-21-015999:item_4_controls:22]
|  | ● | We are in the process of designing and implementing information technology general controls, including controls over program change management, the review and update of user access rights and privileges, controls over batch jobs and data backups, and program development approvals and testing. During the three months ended September 30, 2021, we engaged outside consultants to assist us in the evaluation and implementation of a new Enterprise Resource Planning (“ERP”) system. |

[0001558370-21-015999:item_4_controls:23]
As we continue to evaluate our internal control over financial reporting, we may take additional actions to address material weaknesses or modify the remediation actions described above.

[0001558370-21-015999:item_4_controls:24]
While we continue to devote significant time and attention to these efforts, the material weaknesses will not be considered remediated until management completes the design and implementation of the actions described above and the controls operate for a sufficient period of time, and management has concluded, through testing, that these controls are effective.

[0001558370-21-015999:item_4_controls:25]
Changes in Internal Control over Financial Reporting

[0001558370-21-015999:item_4_controls:26]
As described in the Remediation of Material Weaknesses, there were changes in our internal control over financial reporting during the three months ended September 30, 2021 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
