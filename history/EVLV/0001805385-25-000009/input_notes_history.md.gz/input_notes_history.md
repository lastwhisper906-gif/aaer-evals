# EVLV note change history — 0001628280-25-026845 → 0001805385-25-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-08-14):
[0001805385-25-000009:note_history:1]
We are from time to time subject to various claims, lawsuits, government and regulatory examinations, inquiries, information requests and investigations, and other legal and administrative proceedings arising in the ordinary course of business. The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.
  (was, 2025-05-20, similarity 0.9048):
[0001628280-25-026845:note_history:1]
We are from time to time subject to various claims, lawsuits, government and regulatory examinations, inquiries, information requests and investigations, and other legal and administrative proceedings arising in the ordinary course of business. The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. Except for the regulatory matters discussed below, based upon information presently known to management, the Company has not accrued a loss for any other legal matters, as a loss is not probable and reasonably estimable. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

- changed (2025-08-14):
[0001805385-25-000009:note_history:2]
On March 25, 2024 and November 1, 2024, putative class action lawsuits were filed against the Company in the United States District Court for the District of Massachusetts. On December 13, 2024, the Court consolidated the two lawsuits into one action (the “Class Action”), pursuant to which a consolidated amended complaint was filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees. The
  (was, 2025-05-20, similarity 0.8266):
[0001628280-25-026845:note_history:2]
On March 25, 2024, a putative class action lawsuit was filed against the Company in the United States District Court for the District of Massachusetts (the “Class Action”). The Class Action is a consolidation of two lawsuits, the second of which was filed on November 1, 2024, filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees.

- added (2025-08-14):
[0001805385-25-000009:note_history:3]
Company filed its motion to dismiss the Class Action on March 28, 2025, and the Class Action Plaintiffs filed their opposition to the motion to dismiss on June 24, 2025. On June 30, 2025, the Court issued an order staying the Class Action, including disposition on the motion to dismiss, pending settlement negotiations.

- changed (2025-08-14):
[0001805385-25-000009:note_history:4]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.
  (was, 2025-05-20, similarity 0.9008):
[0001628280-25-026845:note_history:4]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the anticipated motion to dismiss in the Class Action. On March 28, 2025, the Company filed a motion to dismiss the claims.

- changed (2025-08-14):
[0001805385-25-000009:note_history:5]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Delaware Derivative Action”). The Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. The Delaware Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.
  (was, 2025-05-20, similarity 0.9035):
[0001628280-25-026845:note_history:5]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Delaware Derivative Action”). The Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. The Delaware Derivative Action is stayed pending the outcome of the anticipated motion to dismiss in the Class Action.

- added (2025-08-14):
[0001805385-25-000009:note_history:6]
The Company expects to incur legal and professional services expenses associated with this litigation in future periods. The Company will recognize these expenses as services are received. We cannot reasonably estimate a range of possible losses at this time for the derivative lawsuits, as the proceedings remain in the early stages, alleged damages have not been specified, and the derivative actions are stayed. For these reasons, the Company has not recorded a loss contingency liability for the derivative lawsuits as of June 30, 2025. On August 5, 2025, the parties to the Class Action engaged in mediation and reached a settlement in principle in the amount of $15.0 million, which is subject to negotiation of definitive documentation and court approval, of which the Company estimated that $14.0 million would be funded by D&O insurance. As of June 30, 2025, the Company recognized a settlement accrual of $15.0 million and an estimated insurance recovery of $14.0 million, which are included in accrued expenses and other current liabilities and prepaid and other current assets in the condensed consolidated balance sheets, respectively. The Company recognized the net $1.0 million as an estimated loss in general and administrative expense in the condensed consolidated statements of operations and comprehensive loss for both the three and six months ended June 30, 2025.

- changed (2025-08-14):
[0001805385-25-000009:note_history:7]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, 5 customers representing 24 Evolv Express systems elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the year ended December 31, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and six months ended June 30, 2025, as revenue continued to be
  (was, 2025-05-20, similarity 0.7253):
[0001628280-25-026845:note_history:7]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, 5 customers representing 24 Evolv Express units elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the year ended December 31, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three months ended March 31, 2025, as revenue will continue to be recognized on these deals through the cancellation dates of each contract, all of which are in June 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of the effective date of the Order were impacted by the cancellations, which has been excluded from the remaining performance obligations disclosed in Note 6 Revenue Recognition.

- added (2025-08-14):
[0001805385-25-000009:note_history:8]
recognized on these deals through the cancellation dates of each contract, all of which were in June 2025, and all systems have been removed from our subscription base as of June 30, 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of the effective date of the Order were impacted by the cancellations, which has been excluded from the remaining performance obligations disclosed in Note 6 Revenue Recognition.

- changed (2025-08-14):
[0001805385-25-000009:note_history:9]
As previously reported, the Company self-reported the Investigation to the Division of Enforcement of the SEC. The Company has since received requests for documents and information from the SEC relating to this matter. The Company is cooperating with this investigation. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("DOJ") relating to these same issues, and has since received additional requests for documents and information relating to this matter. By letter dated August 7, 2025, the DOJ informed the Company that the Company is no longer the subject of a DOJ investigation.
  (was, 2025-05-20, similarity 0.7483):
[0001628280-25-026845:note_history:9]
As previously reported, the Company self-reported to the Division of Enforcement of the SEC the Investigation. The Company has since received requests for documents and information from the SEC relating to this matter. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("DOJ") relating to these same issues, and has since received additional requests for documents and information relating to this matter. The Company is cooperating with these investigations.

- added (2025-08-14):
[0001805385-25-000009:note_history:10]
Any resolution or litigation with the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to SEC matter. In addition to the expected insurance recovery discussed above related to the Class Action litigation, the Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matter, including certain expenses that have previously been paid, are also expected to be reimbursed. As of June 30, 2025, the Company recognized an estimated loss recovery related to insurance coverage for these matters of $1.7 million and $5.6 million for the three and six months ended June 30, 2025, respectively, which was recorded as a reduction of general and administrative expense in the condensed consolidated statements of operations and comprehensive loss. As of June 30, 2025, $0.9 million of these recoveries have been paid out by the Company's insurance provider. The $4.7 million remaining estimated recovery is included in prepaid and other current assets in the condensed consolidated balance sheets as of June 30, 2025. This amount reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company has determined are probable of recovery. $4.1 million of recoveries were paid out in July 2025. As it relates to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.

- removed (2025-08-14):
[0001628280-25-026845:note_history:11]
The Company expects to incur legal and professional services expenses associated with this litigation in future periods. The Company will recognize these expenses as services are received. While a loss from this litigation is reasonably possible, we cannot reasonably estimate a range of possible losses at this time, as the proceedings remain in the early stages, alleged damages have not been specified, there is uncertainty as to the outcome of our anticipated motion to dismiss in the Class Action which was filed on March 28, 2025, there is uncertainty as to the likelihood of the proposed class in the Class Action being certified or the ultimate size of any class if certified, there is uncertainty as to the final complaint in the Massachusetts Derivative Action, as the plaintiff will not identify an operative complaint or file a consolidated complaint until disposition of our anticipated motion to dismiss in the Class Action, and there are significant factual and legal issues to be resolved in both the securities and derivative actions. For these reasons, the Company has not recorded a loss contingency liability for the above litigation as of March 31, 2025.

- removed (2025-08-14):
[0001628280-25-026845:note_history:12]
Any resolution or litigation with the SEC, DOJ, or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to SEC or DOJ matters. The Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matters, including certain expenses that have previously been paid, are expected to be reimbursed. As of March 31, 2025, the Company recognized an estimated loss recovery related to insurance coverage for these matters of $3.9 million, which was recorded in general and administrative expense in the condensed consolidated statements of

- removed (2025-08-14):
[0001628280-25-026845:note_history:13]
operations and comprehensive loss and a related asset in prepaid and other current assets in the condensed consolidated balance sheets. This amount reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company expects realization of the claim for recovery is probable. As it relates to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement  action or litigation, which is necessarily uncertain.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-08-14):
[0001805385-25-000009:note_history:14]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. (“Evolv UK”) and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).
  (was, 2025-05-20, similarity 0.993):
[0001628280-25-026845:note_history:14]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).

- changed (2025-08-14):
[0001805385-25-000009:note_history:15]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of June 30, 2025, the Company had $36.9 million in cash, cash equivalents, and marketable securities. The Company incurred a net loss of $42.2 million and $7.9 million for the six months ended June 30, 2025 and 2024, respectively. The Company incurred cash outflows from operating activities of $0.4 million and $37.7 million during the six months ended June 30, 2025 and 2024, respectively. The Company expects to continue to generate losses for the foreseeable future.
  (was, 2025-05-20, similarity 0.6809):
[0001628280-25-026845:note_history:15]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of March 31, 2025, the Company had $35.0 million in cash, cash equivalents, and marketable securities. The Company incurred a net loss of $1.7 million and $11.3 million for the three months ended March 31, 2025 and 2024, respectively. The Company incurred cash outflows from operating activities of $2.5 million and $16.2 million during the three months ended March 31, 2025 and 2024, respectively. The Company expects to continue to generate losses for the foreseeable future.

- added (2025-08-14):
[0001805385-25-000009:note_history:16]
On July 29, 2025, the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's subscription sales model. The MidCap Credit Agreement provides for an initial $30.0 million term loan facility, a $30.0 million delayed draw facility (available for drawdown during the two-year period following the closing date), and a $15.0 million revolving line

- added (2025-08-14):
[0001805385-25-000009:note_history:17]
of credit, each with a term of five years (collectively, the "Senior Secured Credit Facilities"). At closing, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs incurred in connection with the closing of MidCap Credit Agreement. See Note 17, Subsequent Events for additional information.

- changed (2025-08-14):
[0001805385-25-000009:note_history:18]
The Company expects its cash, cash equivalents, and marketable securities of $36.9 million as of June 30, 2025, together with cash it expects to generate from future operations and borrowing availability under the Senior Secured Credit Facilities, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth.
  (was, 2025-05-20, similarity 0.9233):
[0001628280-25-026845:note_history:18]
The Company expects its cash, cash equivalents, and marketable securities of $35.0 million as of March 31, 2025, together with cash it expects to generate from future operations, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth. The Company may

- added (2025-08-14):
[0001805385-25-000009:note_history:19]
The accompanying unaudited condensed consolidated financial statements as of June 30, 2025, and for the three and six months ended June 30, 2025 and 2024 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2024 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of June 30, 2025, the results of its operations for the three and six months ended June 30, 2025 and 2024 and cash flows for the six months ended June 30, 2025 and 2024. The results for the three and six months ended June 30, 2025 are not necessarily indicative of results to be expected for the year ending December 31, 2025, any other interim periods, or any future year or period. These interim unaudited condensed consolidated financial statements should be read in conjunction with the financial statements included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024.

- added (2025-08-14):
[0001805385-25-000009:note_history:20]
Reclassifications

- added (2025-08-14):
[0001805385-25-000009:note_history:21]
During the three months ended March 31, 2025, the Company began classifying restructuring charges, which includes termination charges arising from severance obligations, incremental non-cash expense, and other customary employee benefit payments in connection with a reduction in force, within restructuring costs on the condensed consolidated statements of operations and comprehensive loss, whereas the restructuring costs for these services had previously been included in cost of service revenue, research and development expenses, sales and marketing expenses, and general and administrative expenses. These reclassifications were made to align the presentation of restructuring charges with the Company's internal reporting and analysis. The reclassifications increased gross profit by $0.2 million for both the three and six months ended June 30, 2024 and did not impact total loss from operations or total net loss for any period. Prior year amounts included in this Quarterly Report on Form 10-Q have been reclassified to conform to the current presentation.

- added (2025-08-14):
[0001805385-25-000009:note_history:22]
For both the three and six months ended June 30, 2024, the reclassifications resulted in an increase in restructuring costs of $0.9 million, and a corresponding decrease in cost of service revenue, sales and marketing expenses, and general and administrative expenses of $0.2 million, $0.7 million, and less than $0.1 million, respectively.

- removed (2025-08-14):
[0001628280-25-026845:note_history:23]
require additional capital to respond to expected growth in the demand for equipment to support its “leased equipment” offering, technological advancements, competitive dynamics or technologies, customer demands, business opportunities, challenges, acquisitions, or unforeseen circumstances. To the extent that the Company's projected revenue growth does not materialize, it has established plans to preserve existing cash liquidity, which includes additional reductions in operating expenses and capital expenditures.

- removed (2025-08-14):
[0001628280-25-026845:note_history:24]
Although not required to fund ongoing operations, in an improving interest rate environment the Company may choose to engage in debt financings or enter into credit facilities for prudent capital management purposes and to provide additional readily available capital for strategic and other purposes. If the Company is unable to obtain adequate financing or financing on terms satisfactory to it, when it requires it, the Company's ability to continue to grow or support the business and to respond to business challenges could be significantly limited. In particular, global events such as public health emergencies, international political turmoil, including in Europe and the Middle East, and related international sanctions, tariffs, supply chain disruptions, and prolonged inflation and rising interest rates have resulted in, and may continue to result in, significant disruption of global financial markets, reducing the Company's ability to access capital. If the Company is unable to raise additional funds when or on the terms desired, its business, financial condition and results of operations could be adversely affected.

- removed (2025-08-14):
[0001628280-25-026845:note_history:25]
The accompanying unaudited condensed consolidated financial statements as of March 31, 2025, and for the three months ended March 31, 2025 and 2024 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2024 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of March 31, 2025, the results of its operations for the three months ended March 31, 2025 and 2024 and cash flows for the three months ended March 31, 2025 and 2024. The results for the three months ended March 31, 2025 are not necessarily indicative of results to be expected for the year ending December 31, 2025, any other interim periods, or any future year or period.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-08-14):
[0001805385-25-000009:note_history:26]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2024, and the notes thereto, which are included in our 2024 Form 10-K. Except for the partner rebate program and the estimates used to determine the grant date valuation for certain market-based stock units (“MSUs”), as described below, there have been no material changes to the Company’s significant accounting policies during the six months ended June 30, 2025.
  (was, 2025-05-20, similarity 0.8777):
[0001628280-25-026845:note_history:26]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2024, and the notes thereto, which are included in our 2024 Form 10-K. Except for the estimates used to determine the grant date valuation for certain market-based stock units (“MSUs”), as described below, which began being granted during the three months ended March 31, 2025, there have been no material changes to the Company’s significant accounting policies during the three months ended March 31, 2025.

- added (2025-08-14):
[0001805385-25-000009:note_history:27]
Partner Rebate Program

- added (2025-08-14):
[0001805385-25-000009:note_history:28]
For the fiscal year 2025, the Company implemented a channel partner rebate program (the “Rebate Program”) for eligible resellers. Under the Rebate Program, eligible resellers that attain at least 25% of their current fiscal year total contract value (“TCV”) target (“Annual Target”) in a given quarter are eligible for a rebate based upon a percentage of their TCV for that quarter. In addition, resellers that meet their Annual Target are eligible for a one-time rebate based upon a percentage of their total fiscal year TCV, applied as a credit in the subsequent fiscal year. All rebates are issued as credits against future purchases, and no cash rebates are paid. Unused rebate credits are forfeited in the event of a reseller agreement termination.

- added (2025-08-14):
[0001805385-25-000009:note_history:29]
The Company recognizes an accrued liability related to the Rebate Program in accrued expenses and other current liabilities in our condensed consolidated balance sheets and recognizes the rebates as reduction of revenue.

- changed (2025-08-14):
[0001805385-25-000009:note_history:30]
The estimated grant date fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The
  (was, 2025-05-20, similarity 0.6863):
[0001628280-25-026845:note_history:30]
The estimated grant date fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.

- added (2025-08-14):
[0001805385-25-000009:note_history:31]
assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.

- added (2025-08-14):
[0001805385-25-000009:note_history:32]
In July 2025, the FASB issued ASU 2025-05, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets.” The amendment in ASU 2025-05 provides entities with a practical expedient to simplify the estimation of expected credit losses by assuming that the current conditions as of the balance sheet date will not change for the remaining life of the asset. Early adoption is permitted, and this amendment is applied prospectively. ASU 2025-05 is effective for all annual periods beginning after December 15, 2025 and interim periods within those annual periods. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-14):
[0001805385-25-000009:note_history:33]
Marketable Securities
All marketable securities fully matured as of June 30, 2025. Marketable securities as of December 31, 2024 consisted of the following:
  (was, 2025-05-20, similarity 0.7229):
[0001628280-25-026845:note_history:33]
Marketable Securities
Marketable securities as of March 31, 2025 and December 31, 2024 consisted of the following:

- changed (2025-08-14):
[0001805385-25-000009:note_history:34]
Marketable securities at December 31, 2024 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and six months ended June 30, 2025 and 2024. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive loss.
  (was, 2025-05-20, similarity 0.9417):
[0001628280-25-026845:note_history:34]
Marketable securities at March 31, 2025 and December 31, 2024 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three months ended March 31, 2025 and 2024. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive loss.

- removed (2025-08-14):
[0001628280-25-026845:note_history:35]
|  | March 31, 2025 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 9,931 |  |  | $ | — |  |  | $ | 9,931 |  |
| Total marketable securities | $ | 9,931 |  |  | $ | — |  |  | $ | 9,931 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2025-08-14):
[0001805385-25-000009:note_history:36]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. While the partnership agreement is still in effect, effective in the fourth quarter of 2024, Motorola is no longer considered a related party. During the three and six months ended June 30, 2024, revenue from Motorola's distributor services was $1.9 million (as restated) and $3.9 million (as restated), respectively.
  (was, 2025-05-20, similarity 0.9398):
[0001628280-25-026845:note_history:36]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. While the partnership agreement is still in effect, effective in the fourth quarter of 2024, Motorola is no longer considered a related party. During the three months ended March 31, 2024, revenue from Motorola's distributor services was $1.9 million.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-08-14):
[0001805385-25-000009:note_history:37]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Product revenue | $ | 2,528 |  |  | $ | 1,954 |  |  | $ | 4,850 |  |  | $ | 3,445 |  |
| Subscription revenue | 20,200 |  |  | 15,655 |  |  | 39,437 |  |  | 29,874 |  |
| Service revenue | 6,686 |  |  | 5,566 |  |  | 13,416 |  |  | 10,818 |  |
| License fees | 2,291 |  |  | 1,717 |  |  | 5,494 |  |  | 2,441 |  |
| Professional services and other revenue | 839 |  |  | 332 |  |  | 1,354 |  |  | 827 |  |
| Total revenue | $ | 32,544 |  |  | $ | 25,224 |  |  | $ | 64,551 |  |  | $ | 47,405 |  |

- removed (2025-08-14):
[0001628280-25-026845:note_history:38]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Product revenue |  |  |  |  | $ | 2,322 |  |  | $ | 1,491 |  |
| Subscription revenue |  |  |  |  | 19,237 |  |  | 14,219 |  |
| Service revenue |  |  |  |  | 6,730 |  |  | 5,252 |  |
| License fees |  |  |  |  | 3,203 |  |  | 724 |  |
| Professional services and other revenue |  |  |  |  | 515 |  |  | 495 |  |
| Total revenue |  |  |  |  | $ | 32,007 |  |  | $ | 22,181 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-14):
[0001805385-25-000009:note_history:39]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after control passes to the customer. Revenue is recognized net of sales tax.
  (was, 2025-05-20, similarity 0.6161):
[0001628280-25-026845:note_history:39]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4)

- changed (2025-08-14):
[0001805385-25-000009:note_history:40]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of June 30, 2025:
  (was, 2025-05-20, similarity 0.9756):
[0001628280-25-026845:note_history:40]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of March 31, 2025:

- changed (2025-08-14):
[0001805385-25-000009:note_history:41]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time.  As of June 30, 2025 and December 31, 2024, the Company had $0.8 million and $0.8 million in current portion of contract assets and $0.8 million and $0.7 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.
  (was, 2025-05-20, similarity 0.9903):
[0001628280-25-026845:note_history:41]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time.  As of March 31, 2025 and December 31, 2024, the Company had $0.9 million and $0.8 million in current portion of contract assets and $0.9 million and $0.7 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

- changed (2025-08-14):
[0001805385-25-000009:note_history:42]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $19.4 million and $44.1 million during the three and six months ended June 30, 2025, respectively, that was included in the December 31, 2024 deferred revenue balance. The Company recognized revenue of $13.8 million (as restated) and $30.7 million (as restated) during the three and six months ended June 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance.
  (was, 2025-05-20, similarity 0.7365):
[0001628280-25-026845:note_history:42]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $24.7 million during the three months ended March 31, 2025 that was included in the December 31, 2024 deferred revenue balance. The Company recognized revenue of $16.9 million

- changed (2025-08-14):
[0001805385-25-000009:note_history:43]
| Balance at December 31, 2024 | $ | 84,772 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (44,110) |  |
| Revenue deferred | 50,710 |  |
| Balance at June 30, 2025 | $ | 91,372 |  |
  (was, 2025-05-20, similarity 0.9772):
[0001628280-25-026845:note_history:43]
| Balance at December 31, 2024 | $ | 84,772 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (24,737) |  |
| Revenue deferred | 25,237 |  |
| Balance at March 31, 2025 | $ | 85,272 |  |

- changed (2025-08-14):
[0001805385-25-000009:note_history:44]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Interest income on lease receivables | $ | 27 |  |  | $ | 41 |  |  | $ | 56 |  |  | $ | 83 |  |
| Lease income - operating leases | 20,200 |  |  | 15,655 |  |  | 39,437 |  |  | 29,874 |  |
| Total lease revenue | $ | 20,227 |  |  | $ | 15,696 |  |  | $ | 39,493 |  |  | $ | 29,957 |  |
  (was, 2025-05-20, similarity 0.6439):
[0001628280-25-026845:note_history:44]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Interest income on lease receivables |  |  |  |  | $ | 29 |  |  | $ | 42 |  |
| Lease income - operating leases |  |  |  |  | 19,237 |  |  | 14,219 |  |
| Total lease revenue |  |  |  |  | $ | 19,266 |  |  | $ | 14,261 |  |

- added (2025-08-14):
[0001805385-25-000009:note_history:45]
The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment

- added (2025-08-14):
[0001805385-25-000009:note_history:46]
under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties was $0.3 million and $0.6 million during the three and six months ended June 30, 2024, respectively. There was no revenue related to leases entered into with related parties during the three and six months ended June 30, 2025.

- added (2025-08-14):
[0001805385-25-000009:note_history:47]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Product revenue | $ | 2,528 |  |  | $ | 1,954 |  |  | $ | 4,850 |  |  | $ | 3,445 |  |
| Subscription revenue | 20,200 |  |  | 15,655 |  |  | 39,437 |  |  | 29,874 |  |
| Service revenue | 6,686 |  |  | 5,566 |  |  | 13,416 |  |  | 10,818 |  |
| License fees | 2,291 |  |  | 1,717 |  |  | 5,494 |  |  | 2,441 |  |
| Professional services and other revenue | 839 |  |  | 332 |  |  | 1,354 |  |  | 827 |  |
| Total revenue | $ | 32,544 |  |  | $ | 25,224 |  |  | $ | 64,551 |  |  | $ | 47,405 |  |

- added (2025-08-14):
[0001805385-25-000009:note_history:48]
Partner Rebate Program

- added (2025-08-14):
[0001805385-25-000009:note_history:49]
As discussed in Note 3, Summary of Significant Accounting Policies, the Company implemented a new Rebate Program for eligible resellers. As of June 30, 2025, the Company has accrued $0.4 million related to the Rebate Program, which is included in accrued expenses and other current liabilities in our condensed consolidated balance sheets. As a substantial amount of the Company's revenue with eligible resellers is recognized over-time, the Company recognized less than $0.1 million and $0.2 million of current portion of contract asset and contract asset, noncurrent in our condensed consolidated balance sheets, respectively, as of June 30, 2025 and recognized $0.1 million and $0.2 million as reduction of revenue for the three and six months ended June 30, 2025, respectively.

- changed (2025-08-14):
[0001805385-25-000009:note_history:50]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $12.9 million and $13.0 million as of June 30, 2025 and December 31, 2024, respectively. During the three months ended June 30, 2025 and 2024, the Company recognized commission expense of $1.8 million and $1.6 million (as restated), respectively. During the six months ended June 30, 2025 and 2024, the Company recognized commission expense of $3.3 million and $2.9 million (as restated), respectively.
  (was, 2025-05-20, similarity 0.8554):
[0001628280-25-026845:note_history:50]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $12.8 million and $13.0 million as of March 31, 2025 and December 31, 2024, respectively. During the three months ended March 31, 2025 and 2024, the Company recognized commission expense of $1.5 million and $1.3 million (as restated), respectively.

- changed (2025-08-14):
[0001805385-25-000009:note_history:51]
As of June 30, 2025, future minimum noncancelable payments related to leases of the Company's equipment are as follows (in thousands):
  (was, 2025-05-20, similarity 0.965):
[0001628280-25-026845:note_history:51]
As of March 31, 2025, future minimum noncancelable payments related to leases of the Company's equipment are as follows (in thousands):

- changed (2025-08-14):
[0001805385-25-000009:note_history:52]
| Year Ending December 31: |  |
| 2025 (six months remaining) | $ | 41,984 |  |
| 2026 | 74,372 |  |
| 2027 | 53,103 |  |
| 2028 | 26,720 |  |
| 2029 | 5,872 |  |
| Thereafter | 260 |  |
|  | $ | 202,311 |  |
  (was, 2025-05-20, similarity 0.9835):
[0001628280-25-026845:note_history:52]
| Year Ending December 31: |  |
| 2025 (nine months remaining) | $ | 58,776 |  |
| 2026 | 67,180 |  |
| 2027 | 45,766 |  |
| 2028 | 20,471 |  |
| 2029 | 2,328 |  |
| Thereafter | 7 |  |
|  | $ | 194,528 |  |

- removed (2025-08-14):
[0001628280-25-026845:note_history:53]
license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after control passes to the customer. Revenue is recognized net of sales tax.

- removed (2025-08-14):
[0001628280-25-026845:note_history:54]
(as restated) during the three months ended March 31, 2024 that was included in the December 31, 2023 deferred revenue balance.

- removed (2025-08-14):
[0001628280-25-026845:note_history:55]
The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties was $0.3 million during the three months ended March 31, 2024. There was no revenue related to leases entered into with related parties during the three months ended March 31, 2025.

- removed (2025-08-14):
[0001628280-25-026845:note_history:56]
|  |  |  | Three Months EndedMarch 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Product revenue |  |  |  |  | $ | 2,322 |  |  | $ | 1,491 |  |
| Subscription revenue |  |  |  |  | 19,237 |  |  | 14,219 |  |
| Service revenue |  |  |  |  | 6,730 |  |  | 5,252 |  |
| License fees |  |  |  |  | 3,203 |  |  | 724 |  |
| Professional services and other revenue |  |  |  |  | 515 |  |  | 495 |  |
| Total revenue |  |  |  |  | $ | 32,007 |  |  | $ | 22,181 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-08-14):
[0001805385-25-000009:note_history:57]
Subsequent Events
Senior Secured Credit Facilities
  (was, 2025-05-20, similarity 0.6038):
[0001628280-25-026845:note_history:57]
Subsequent Events
Appointment of Chief Financial Officer

- added (2025-08-14):
[0001805385-25-000009:note_history:58]
As described in Note 2, on July 29, 2025, the Company entered into the $75.0 million MidCap Credit Agreement, the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the

- added (2025-08-14):
[0001805385-25-000009:note_history:59]
Company's subscription sales model. The MidCap Credit Agreement provides for the Senior Secured Credit Facilities, which include an initial $30.0 million term loan facility, a $30.0 million delayed draw facility (available for drawdown during the two-year period following the closing date), and a $15.0 million revolving line of credit, each with a term of five years. At closing, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs incurred in connection with the closing of MidCap Credit Agreement.

- added (2025-08-14):
[0001805385-25-000009:note_history:60]
The Senior Secured Credit Facilities are guaranteed by the Company, and in the future, may be guaranteed by certain material subsidiaries. The Senior Secured Credit Facilities are secured by a first lien on substantially all of the assets of the Company. The borrowings under the Senior Secured Credit Facilities bear interest at a fluctuating rate per annum equal to (x) a base rate determined by reference to the higher of (1) the prime rate of Wells Fargo and (2) 2.00% or (y) Term Secured Overnight Financing Rate (“Term SOFR”), in each case, plus an applicable margin calculated based on earnings before interest, taxes, depreciation, and amortization (“EBITDA”). At closing, the applicable margin on Term SOFR loans was 5.25%. Interest and principal are payable monthly. The term loan facilities require interest-only payments during the initial 48-month period, with principal repayment amortized on a straight-line basis over the remaining 12 months of the term.

- added (2025-08-14):
[0001805385-25-000009:note_history:61]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary affirmative and negative covenants, including a minimum annual recurring revenue covenant, a minimum EBITDA covenant that takes effect on the second anniversary of the closing date, and a minimum liquidity covenant that would cease to apply following the resolution of certain litigation and regulatory matters, in addition to customary reporting requirements of periodic financial results.

- added (2025-08-14):
[0001805385-25-000009:note_history:62]
Departure of Officer

- added (2025-08-14):
[0001805385-25-000009:note_history:63]
On August 13, 2025, Mr. Michael Ellenbogen, Chief Innovation Officer and a member of the Board of Directors (the “Board”) of the Company, informed the Company that he would be resigning as Chief Innovation Officer, effective as of September 5, 2025, citing new time commitments. Mr. Ellenbogen’s decision to resign is not due any disagreements with the Company. Mr. Ellenbogen will continue to serve as a member of the Board and will be eligible to receive compensation as a non-employee director pursuant to the Company's Director Compensation Policy.

- removed (2025-08-14):
[0001628280-25-026845:note_history:64]
On April 29, 2025, the Company appointed a new executive officer. In connection with this appointment, on May 1, 2025, the Board granted the officer (i) market-based restricted stock units with an aggregate grant date fair market value of $1,750,000, which will vest based on the achievement of certain Company stock price performance goals, as described in Note 3, Summary of Significant Accounting Policies and Estimates, and (ii) restricted stock units with an aggregate grant date fair market value of $1,750,000, which will vest based on the executive's continued service with the Company in three equal annual installments, pursuant to the Company’s 2021 Incentive Award Plan.
