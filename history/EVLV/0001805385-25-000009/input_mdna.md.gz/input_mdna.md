# EVLV MD&A — 0001805385-25-000009


## mdna

[0001805385-25-000009:mdna:1]
[same as prior period, unchanged from 0001628280-25-026845:mdna:1]

[0001805385-25-000009:mdna:2]
[same as prior period, unchanged from 0001628280-25-026845:mdna:2]

[0001805385-25-000009:mdna:3]
Restatement of Prior Period Financial Statements

[0001805385-25-000009:mdna:4]
We have restated our previously issued condensed consolidated financial statements contained in this Quarterly Report on Form 10-Q. In addition, we have restated certain previously reported financial information for the three and six months ended June 30, 2024 in this Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations, including but not limited to information within the Results of Operations section. See Note 2, Restatement of Previously Issued Condensed Consolidated Financial Statements in the notes to the condensed consolidated financial statements in this Quarterly Report on Form 10-Q, for additional information related to the restatement, including descriptions of the misstatements and the impacts on our condensed consolidated financial statements.

[0001805385-25-000009:mdna:5]
[same as prior period, unchanged from 0001628280-25-026845:mdna:5]

[0001805385-25-000009:mdna:6]
[same as prior period, unchanged from 0001628280-25-026845:mdna:6]

[0001805385-25-000009:mdna:7]
[same as prior period, unchanged from 0001628280-25-026845:mdna:7]

[0001805385-25-000009:mdna:8]
Our flagship product, Evolv Express, uses advanced sensors, AI-powered software, and cloud services to not only consistently detect firearms, improvised explosives, and certain types of knives and distinguish them from many harmless items such as cell phones and keys, but also visualize the location of the potential threat helping to enable security personnel to conduct targeted, minimally intrusive secondary screenings. Evolv eXpedite, our high-speed autonomous X-ray bag scanning solution, works with Evolv Express to provide a layered approach to security for concealed weapons detection in high clutter environments. Using eXpedite with Express aims to allow the checkpoint to operate at heightened sensitivity while potentially reducing the burden on security staff and optimizing the visitor experience.

[0001805385-25-000009:mdna:9]
Our innovative technology is designed to enhance security and provide an efficient, positive visitor and customer security experience. In addition to screening capabilities, our solution includes Evolv Insights®, a powerful software analytics dashboard that allows customers to comprehensively review, analyze, and gather insights from the Evolv Express screening systems at their various venues or facility locations.  Available data includes visitor arrival patterns, throughput volumes, system detection performance, alarm statistics, weapons detected and detection settings.  Our customers can leverage this data to inform their security operations, while providing end-users with an approachable security experience.

[0001805385-25-000009:mdna:10]
1

[0001805385-25-000009:mdna:11]
[same as prior period, unchanged from 0001628280-25-026845:mdna:10]

[0001805385-25-000009:mdna:12]
We are focused on delivering value in the spaces in and around the physical threshold of venues and facilities while offering the ability for connected layers of security. We believe that digitally transforming the visitor experience at the entry point to venues and facilities will be a critically important innovation in physical security. We believe that our solutions will not only help make venues and facilities safer and more enjoyable, but also more efficient, and more informed about their visitors’ and security team needs.

[0001805385-25-000009:mdna:13]
[same as prior period, unchanged from 0001628280-25-026845:mdna:12]

[0001805385-25-000009:mdna:14]
[same as prior period, unchanged from 0001628280-25-026845:mdna:13]

[0001805385-25-000009:mdna:15]
[same as prior period, unchanged from 0001628280-25-026845:mdna:14]

[0001805385-25-000009:mdna:16]
[same as prior period, unchanged from 0001628280-25-026845:mdna:15]

[0001805385-25-000009:mdna:17]
[same as prior period, unchanged from 0001628280-25-026845:mdna:16]

[0001805385-25-000009:mdna:18]
[same as prior period, unchanged from 0001628280-25-026845:mdna:17]

[0001805385-25-000009:mdna:19]
[same as prior period, unchanged from 0001628280-25-026845:mdna:18]

[0001805385-25-000009:mdna:20]
We sell our solutions under two primary sales models. We offer a “pure subscription” model, where the customer leases hardware from us and we provide a multi-year security-as-a-service subscription. For end-user customers that prefer to purchase our hardware outright, we offer our “distributor licensing” model based on the Distribution and License Agreement we entered into with Columbia Tech in March of 2023. Columbia Tech, a wholly-owned subsidiary of Coghlin Companies, currently serves as our primary contract manufacturer. Under this arrangement, we have granted a license of our intellectual property to Columbia Tech, which contracts directly with certain of our resellers to fulfill sales demand where the end-user customer prefers to purchase the hardware equipment. Columbia Tech pays us a hardware license fee for each system it manufactures and sells under this agreement. In these instances, we still contract directly with the reseller to provide a multi-year security-as-a-service subscription to the end-users. In addition to our two primary sales models, end-user customers also have the option of purchasing our hardware outright directly from us through our “purchase subscription” model, and we expect this will displace much of the "distributor licensing" model in the coming months. We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our revenue, gross profit, gross margin, and overall profitability in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments. We have been experiencing a growing mix of customers adopting our pure subscription model, which reduces upfront revenue recognition in favor of building a more predictable recurring revenue base and our purchase subscription model, which has more product revenue and no license fee revenue.

[0001805385-25-000009:mdna:21]
Going forward, we expect our products to be adopted in a variety of vertical industry markets and geographic regions. While adoption of our products has primarily been within the United States to date, we expect increased adoption of our products in foreign markets in the near future as we explore expansion into international markets. Pricing may vary by region or vertical market due to market-specific dynamics. As a result, our financial performance depends, in part, on the mix of sales, bookings, and business in different markets during a given period. In addition, we are subject to price competition, and our ability to compete in key markets will depend on the success of our investments in new technologies and cost improvements as well as our ability to efficiently and reliably introduce AI-powered security screening solutions to our customers.

[0001805385-25-000009:mdna:22]
[same as prior period, unchanged from 0001628280-25-026845:mdna:23]

[0001805385-25-000009:mdna:23]
Since our inception, we have incurred significant operating losses. Our ability to generate revenue and achieve cost improvements sufficient to achieve profitability will depend on the successful further development and commercialization of our products. We generated revenue of $64.6 million and $47.4 million for the six months ended June 30, 2025 and 2024, respectively. We generated a net loss of $42.2 million and $7.9 million for the six months ended June 30, 2025 and 2024, respectively. We expect to continue to incur operating losses as we focus on growing and establishing recurring commercial sales of our products, including growing our sales and marketing teams, scaling our manufacturing operations, and continuing research and development efforts to develop new products and further enhance our existing products.

[0001805385-25-000009:mdna:24]
[same as prior period, unchanged from 0001628280-25-026845:mdna:25]

[0001805385-25-000009:mdna:25]
Because of the numerous risks and uncertainties associated with product development and commercialization, we are unable to accurately predict the timing or amount of increased expenses or when, or if, we will be able to achieve or maintain profitability. Until such time, if ever, as we can generate substantial revenue sufficient to achieve profitability, we expect to finance our operations through cash generated from operations and our Senior Secured Credit Facilities. See “Liquidity and Capital Resources” as well as “Risks Related to Our Financial Condition and Liquidity” for more information. Additionally, as discussed in Note 14, Commitments and Contingencies, to our condensed consolidated financial statements for the three and six months ended June 30, 2025, we are involved in certain legal proceedings, including government investigations. Given the uncertainty of such matters, no assurance can be given regarding the final outcome of such matters. However, the ultimate amount or range of potential loss, which might result to the Company, may differ materially from our current estimates.

[0001805385-25-000009:mdna:26]
[same as prior period, unchanged from 0001628280-25-026845:mdna:27]

[0001805385-25-000009:mdna:27]
[same as prior period, unchanged from 0001628280-25-026845:mdna:28]

[0001805385-25-000009:mdna:28]
We derive revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by Evolv or by Columbia Tech pursuant to the Distribution and License Agreement, (4) license fees related to the Distribution and License Agreement, and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after shipment to the customer. Revenue is recognized net of sales tax. We have been experiencing a growing mix of customers adopting our pure subscription model, which reduces upfront revenue recognition in favor of building a more predictable recurring revenue base.

[0001805385-25-000009:mdna:29]
[same as prior period, unchanged from 0001628280-25-026845:mdna:30]

[0001805385-25-000009:mdna:30]
We derive a portion of our revenue from the sale of our Evolv Express and eXpedite equipment and related add-on accessories to customers. Revenue is recognized when control of the product has transferred to the customer, which follows the terms of each contract. We anticipate future growth in product revenue as more customers purchase systems through our direct purchase subscription model.

[0001805385-25-000009:mdna:31]
[same as prior period, unchanged from 0001628280-25-026845:mdna:32]

[0001805385-25-000009:mdna:32]
Subscription revenue consists of revenue derived from leasing Evolv Express and eXpedite systems to our customers. Lease terms are typically four years and customers generally pay either a quarterly or annual fixed payment for the lease, SaaS, and maintenance elements over the contractual lease term. Equipment leases are generally classified as

[0001805385-25-000009:mdna:33]
[same as prior period, unchanged from 0001628280-25-026845:mdna:34]

[0001805385-25-000009:mdna:34]
operating leases and recognized ratably over the duration of the lease. There are no contingent lease payments as a part of these arrangements.

[0001805385-25-000009:mdna:35]
[same as prior period, unchanged from 0001628280-25-026845:mdna:35]

[0001805385-25-000009:mdna:36]
[same as prior period, unchanged from 0001628280-25-026845:mdna:36]

[0001805385-25-000009:mdna:37]
Service revenue consists of subscription-based SaaS and maintenance revenue related to Evolv Express and eXpedite systems sold to customers. Customers generally pay either a quarterly or annual fixed payment for SaaS and maintenance. SaaS and maintenance revenue is recognized ratably over the period of the arrangement, which is typically four years.

[0001805385-25-000009:mdna:38]
[same as prior period, unchanged from 0001628280-25-026845:mdna:38]

[0001805385-25-000009:mdna:39]
License fee and other revenue includes license fee revenue from the Distribution and License Agreement, revenue from professional services, and other one-time revenue. License fee revenue is recognized upon the shipment of product from Columbia Tech to the reseller. Revenue for professional services is recognized upon transfer of control of these services, which are normally rendered over a short duration. Revenue for professional services and other one-time revenue, which had previously been included in service revenue, has been reclassified for prior periods to License fee and other revenue on the condensed consolidated statements of operations and comprehensive loss. We anticipate license fee and other revenue to decrease going forward as more customers purchase systems through our purchase subscription model.

[0001805385-25-000009:mdna:40]
[same as prior period, unchanged from 0001628280-25-026845:mdna:40]

[0001805385-25-000009:mdna:41]
[same as prior period, unchanged from 0001628280-25-026845:mdna:41]

[0001805385-25-000009:mdna:42]
[same as prior period, unchanged from 0001628280-25-026845:mdna:42]

[0001805385-25-000009:mdna:43]
[same as prior period, unchanged from 0001628280-25-026845:mdna:43]

[0001805385-25-000009:mdna:44]
[same as prior period, unchanged from 0001628280-25-026845:mdna:44]

[0001805385-25-000009:mdna:45]
[same as prior period, unchanged from 0001628280-25-026845:mdna:45]

[0001805385-25-000009:mdna:46]
[same as prior period, unchanged from 0001628280-25-026845:mdna:46]

[0001805385-25-000009:mdna:47]
[same as prior period, unchanged from 0001628280-25-026845:mdna:47]

[0001805385-25-000009:mdna:48]
[same as prior period, unchanged from 0001628280-25-026845:mdna:48]

[0001805385-25-000009:mdna:49]
[same as prior period, unchanged from 0001628280-25-026845:mdna:49]

[0001805385-25-000009:mdna:50]
[same as prior period, unchanged from 0001628280-25-026845:mdna:50]

[0001805385-25-000009:mdna:51]
[same as prior period, unchanged from 0001628280-25-026845:mdna:52]

[0001805385-25-000009:mdna:52]
[same as prior period, unchanged from 0001628280-25-026845:mdna:53]

[0001805385-25-000009:mdna:53]
•Mix of sales between our pure subscription, purchase subscription, and distributor licensing models;

[0001805385-25-000009:mdna:54]
[same as prior period, unchanged from 0001628280-25-026845:mdna:55]

[0001805385-25-000009:mdna:55]
[same as prior period, unchanged from 0001628280-25-026845:mdna:56]

[0001805385-25-000009:mdna:56]
[same as prior period, unchanged from 0001628280-25-026845:mdna:57]

[0001805385-25-000009:mdna:57]
[same as prior period, unchanged from 0001628280-25-026845:mdna:58]

[0001805385-25-000009:mdna:58]
[same as prior period, unchanged from 0001628280-25-026845:mdna:59]

[0001805385-25-000009:mdna:59]
We regularly assess our sales and fulfillment models to ensure they align with customer preferences, operational scalability, and our long-term business objectives. We expect our gross profit and gross margin in any given fiscal period to be influenced by customer demand for our various sales and fulfillment models, as well as any future strategic management decisions affecting our sales and fulfillment models that may result from such assessments. We currently expect gross margins in the near term to decrease due to certain significant opportunities in our pipeline that are expected to be fulfilled through our purchase subscription model.

[0001805385-25-000009:mdna:60]
[same as prior period, unchanged from 0001628280-25-026845:mdna:61]

[0001805385-25-000009:mdna:61]
[same as prior period, unchanged from 0001628280-25-026845:mdna:62]

[0001805385-25-000009:mdna:62]
[same as prior period, unchanged from 0001628280-25-026845:mdna:63]

[0001805385-25-000009:mdna:63]
Sales and marketing expenses consist primarily of personnel related expenses associated with our sales and marketing, customer success, business development, and strategy functions, as well as costs related to trade shows and events, and stock-based compensation. We expect our sales and marketing costs will decrease for the year ending December 31, 2025 compared to the year ended December 31, 2024 as a result of certain cost cutting measures we have taken, including the reduction in force implemented in January 2025.

[0001805385-25-000009:mdna:64]
[same as prior period, unchanged from 0001628280-25-026845:mdna:65]

[0001805385-25-000009:mdna:65]
General and administrative expenses consist primarily of personnel related expenses associated with our executive, finance, investor relations, legal, information technology, and human resources functions, as well as professional fees for legal, audit, accounting and other consulting services, stock-based compensation, and insurance, net of any probable and reasonably estimable insurance recoveries or received insurance recoveries. During the year ended 2024, we experienced a significant increase in general and administrative expenses, primarily for legal fees and consulting expenses, as a result of the Investigation and related actions, as described in Note 2, Restatement of Previously Issued Condensed Consolidated Financial Statements. This increased level of expenses continued through the second quarter of 2025. As such actions have been completed, we expect our general and administrative expenses to decrease in the second half of 2025 and to remain consistent at more normalized levels thereafter.

[0001805385-25-000009:mdna:66]
5

[0001805385-25-000009:mdna:67]
[same as prior period, unchanged from 0001628280-25-026845:mdna:67]

[0001805385-25-000009:mdna:68]
Restructuring costs consists of termination charges arising from severance obligations, incremental non-cash expense related to extended eligibility for the vesting of certain equity awards, and other customary employee benefit payments in connection with a reduction in force. See Note 16, Restructuring Charges for additional information.

[0001805385-25-000009:mdna:69]
The restructuring charges, which had previously been included in cost of service revenue, research and development expenses, sales and marketing expenses, and general and administrative expenses, has been reclassified for prior periods to restructuring costs on the condensed consolidated statements of operations and comprehensive loss. See “Reclassifications” below and Note 1 for additional information.

[0001805385-25-000009:mdna:70]
[same as prior period, unchanged from 0001628280-25-026845:mdna:69]

[0001805385-25-000009:mdna:71]
[same as prior period, unchanged from 0001628280-25-026845:mdna:70]

[0001805385-25-000009:mdna:72]
[same as prior period, unchanged from 0001628280-25-026845:mdna:71]

[0001805385-25-000009:mdna:73]
Interest income relates to interest earned on money market funds and treasury bills, and interest earned on our lease receivables for our Evolv Express systems recognized as sales-type leases.

[0001805385-25-000009:mdna:74]
[same as prior period, unchanged from 0001628280-25-026845:mdna:73]

[0001805385-25-000009:mdna:75]
[same as prior period, unchanged from 0001628280-25-026845:mdna:74]

[0001805385-25-000009:mdna:76]
[same as prior period, unchanged from 0001628280-25-026845:mdna:75]

[0001805385-25-000009:mdna:77]
[same as prior period, unchanged from 0001628280-25-026845:mdna:76]

[0001805385-25-000009:mdna:78]
[same as prior period, unchanged from 0001628280-25-026845:mdna:77]

[0001805385-25-000009:mdna:79]
[same as prior period, unchanged from 0001628280-25-026845:mdna:78]

[0001805385-25-000009:mdna:80]
[same as prior period, unchanged from 0001628280-25-026845:mdna:79]

[0001805385-25-000009:mdna:81]
[same as prior period, unchanged from 0001628280-25-026845:mdna:80]

[0001805385-25-000009:mdna:82]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was signed into law in the United States. The OBBBA introduces various corporate and international tax law changes with staggered effective dates through 2027. Key provisions include immediate R&D expensing, permanent bonus depreciation, modifications to interest expense

[0001805385-25-000009:mdna:83]
limitations, and changes to certain international tax rules. While we continue to evaluate the potential impact of the OBBBA on our consolidated financial statements, due to our full valuation allowance position on U.S. deferred tax assets, immaterial current tax liabilities, and insignificant foreign earnings from Evolv Technologies UK Ltd., we do not expect the OBBBA to have a material impact on our financial position, results of operations, or effective tax rate.

[0001805385-25-000009:mdna:84]
Reclassifications

[0001805385-25-000009:mdna:85]
During the three months ended March 31, 2025, the Company began classifying restructuring charges, which includes termination charges arising from severance obligations, incremental non-cash expense, and other customary employee benefit payments in connection with a reduction in force, within restructuring costs on the condensed consolidated statements of operations and comprehensive loss, whereas the restructuring costs for these services has previously been included in cost of service revenue, research and development expenses, sales and marketing expenses, and general and administrative expenses. These reclassifications were made to align the presentation of restructuring charges with the Company's internal reporting and analysis. See Note 1, Nature of the Business and Basis of Presentation for additional information.

[0001805385-25-000009:mdna:86]
[same as prior period, unchanged from 0001628280-25-026845:mdna:85]

[0001805385-25-000009:mdna:87]
[same as prior period, unchanged from 0001628280-25-026845:mdna:81]

[0001805385-25-000009:mdna:88]
Comparison of the Three Months Ended June 30, 2025 and 2024

[0001805385-25-000009:mdna:89]
The following table summarizes our results of operations for the three months ended June 30, 2025 and 2024 (in thousands):

[0001805385-25-000009:mdna:90]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 2,528 |  |  | $ | 1,954 |  |  | $ | 574 |  |  | 29 | % |
| Subscription revenue | 20,200 |  |  | 15,655 |  |  | 4,545 |  |  | 29 |  |
| Service revenue | 6,686 |  |  | 5,566 |  |  | 1,120 |  |  | 20 |  |
| License fee and other revenue | 3,130 |  |  | 2,049 |  |  | 1,081 |  |  | 53 |  |
| Total revenue | 32,544 |  |  | 25,224 |  |  | 7,320 |  |  | 29 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 5,351 |  |  | 2,839 |  |  | 2,512 |  |  | 88 |  |
| Cost of subscription revenue | 8,894 |  |  | 6,309 |  |  | 2,585 |  |  | 41 |  |
| Cost of service revenue | 1,710 |  |  | 1,147 |  |  | 563 |  |  | 49 |  |
| Cost of license fee and other revenue | 371 |  |  | 172 |  |  | 199 |  |  | 116 |  |
| Total cost of revenue | 16,326 |  |  | 10,467 |  |  | 5,859 |  |  | 56 |  |
| Gross profit | 16,218 |  |  | 14,757 |  |  | 1,461 |  |  | 10 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 4,737 |  |  | 5,850 |  |  | (1,113) |  |  | (19) |  |
| Sales and marketing | 11,736 |  |  | 16,357 |  |  | (4,621) |  |  | (28) |  |
| General and administrative | 17,238 |  |  | 14,061 |  |  | 3,177 |  |  | 23 |  |
| Restructuring costs | — |  |  | 860 |  |  | (860) |  |  | (100) |  |
| Total operating expenses | 33,711 |  |  | 37,128 |  |  | (3,417) |  |  | (9) |  |
| Loss from operations | (17,493) |  |  | (22,371) |  |  | 4,878 |  |  | 22 |  |
| Other (expense) income, net: |  |  |  |  |  |  |  |
| Interest income | 224 |  |  | 681 |  |  | (457) |  |  | (67) |  |
| Other income (expense), net | 136 |  |  | (39) |  |  | 175 |  |  | 449 |  |
| Change in fair value of contingent earn-out liability | (14,200) |  |  | 16,514 |  |  | (30,714) |  |  | (186) |  |
| Change in fair value of contingently issuable common stock liability | (3,900) |  |  | 3,747 |  |  | (7,647) |  |  | (204) |  |
| Change in fair value of public warrant liability | (5,303) |  |  | 4,886 |  |  | (10,189) |  |  | (209) |  |
| Total other (expense) income, net | (23,043) |  |  | 25,789 |  |  | (48,832) |  |  | (189) |  |
| (Loss) income before income taxes | $ | (40,536) |  |  | $ | 3,418 |  |  | $ | (43,954) |  |  | (1286) | % |
| Benefit for income taxes | $ | (1) |  |  | $ | — |  |  | $ | (1) |  |  | * |
| Net (loss) income | $ | (40,535) |  |  | $ | 3,418 |  |  | $ | (43,953) |  |  | (1286) | % |

[0001805385-25-000009:mdna:91]
[same as prior period, unchanged from 0001628280-25-026845:mdna:86]

[0001805385-25-000009:mdna:92]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 63 new customers during the three months ended June 30, 2025, (iii) the expansion of our existing customers' initial Evolv Express deployments to other venues and locations as well as expanding their fleet with our Evolv eXpedite offering, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001805385-25-000009:mdna:93]
[same as prior period, unchanged from 0001628280-25-026845:mdna:88]

[0001805385-25-000009:mdna:94]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Product revenue | $ | 2,528 |  |  | $ | 1,954 |  |  | $ | 574 |  |  | 29 | % |
| Cost of product revenue | $ | 5,351 |  |  | $ | 2,839 |  |  | $ | 2,512 |  |  | 88 | % |
| Gross loss - Product revenue | $ | (2,823) |  |  | $ | (885) |  |  | $ | (1,938) |  |  | (219) | % |
| Gross profit margin - Product revenue | (112) | % |  | (45) | % |  | N/A |  | (66) | % |

[0001805385-25-000009:mdna:95]
The increases in product revenue and cost of product revenue are primarily due to an increased utilization of our purchase subscription model, in which the customers purchase Evolv Express and Evolv eXpedite systems directly from us, for the three months ended June 30, 2025 compared to the prior year period. The decrease in product gross profit margin was due to a $1.4 million increase in inventory reserves on first generation Evolv Express parts during the three months ended June 30, 2025, as well as the initial deployments of our Evolv eXpedite systems, which as a new product offering reflect a higher initial cost to produce that we expect to gradually decline in the future.

[0001805385-25-000009:mdna:96]
[same as prior period, unchanged from 0001628280-25-026845:mdna:91]

[0001805385-25-000009:mdna:97]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Subscription revenue | $ | 20,200 |  |  | $ | 15,655 |  |  | $ | 4,545 |  |  | 29 | % |
| Cost of subscription revenue | $ | 8,894 |  |  | $ | 6,309 |  |  | $ | 2,585 |  |  | 41 | % |
| Gross profit - Subscription revenue | $ | 11,306 |  |  | $ | 9,346 |  |  | $ | 1,960 |  |  | 21 | % |
| Gross profit margin - Subscription revenue | 56 | % |  | 60 | % |  | N/A |  | (4) | % |

[0001805385-25-000009:mdna:98]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to continued growth in our customer base as of June 30, 2025 compared to the prior year, with a higher number of active Evolv Express systems deployed under our pure subscription model and an increase in short term rental subscription revenue during the three months ended June 30, 2025. Gross profit margin decreased primarily due to an increase of $1.3 million of expense related to disposals of certain first generation Evolv Express systems, partially offset by our ability to leverage our fixed costs over a higher revenue base and lower costs related to our second generation of Evolv Express systems.

[0001805385-25-000009:mdna:99]
[same as prior period, unchanged from 0001628280-25-026845:mdna:103]

[0001805385-25-000009:mdna:100]
[same as prior period, unchanged from 0001628280-25-026845:mdna:94]

[0001805385-25-000009:mdna:101]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Service revenue | $ | 6,686 |  |  | $ | 5,566 |  |  | $ | 1,120 |  |  | 20 | % |
| Cost of service revenue | $ | 1,710 |  |  | $ | 1,147 |  |  | $ | 563 |  |  | 49 | % |
| Gross profit - Service revenue | $ | 4,976 |  |  | $ | 4,419 |  |  | $ | 557 |  |  | 13 | % |
| Gross profit margin - Service revenue | 74 | % |  | 79 | % |  | N/A |  | (5) | % |

[0001805385-25-000009:mdna:102]
The increases in service revenue, cost of service revenue, and service gross profit are primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech under our distributor licensing model, for the three months ended June 30, 2025 compared to the prior year period. The decrease in gross profit margin is primarily due to a $0.2 million expense related to certain accrued service fees and a $0.2 million increase in amortization of capitalized software costs during the three months ended June 30, 2025 due to the release of Evolv eXpedite and our second generation of Evolv Express systems.

[0001805385-25-000009:mdna:103]
[same as prior period, unchanged from 0001628280-25-026845:mdna:97]

[0001805385-25-000009:mdna:104]
|  | Three Months EndedJune 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| License fee and other revenue | $ | 3,130 |  |  | $ | 2,049 |  |  | $ | 1,081 |  |  | 53 | % |
| Cost of license fee and other revenue | $ | 371 |  |  | $ | 172 |  |  | $ | 199 |  |  | 116 | % |
| Gross profit - License fee and other revenue | $ | 2,759 |  |  | $ | 1,877 |  |  | $ | 882 |  |  | 47 | % |
| Gross profit margin - License fee and other revenue | 88 | % |  | 92 | % |  | N/A |  | (3) | % |

[0001805385-25-000009:mdna:105]
The increases in license fee and other revenue and gross profit are primarily driven by $2.3 million of license fee revenue earned during the three months ended June 30, 2025 compared to $1.7 million earned during the prior year period under the Distribution and License Agreement with Columbia Tech. Although the unit sales through our distributor licensing model declined, the license fee and other revenue increased due to an increase in per-unit license fees for our second generation of Evolv Express systems. Product gross profit margin decreased for the three months ended June 30, 2025 as compared to the three months ended June 30, 2024 due to an increase in personnel and overhead costs of $0.3 million.

[0001805385-25-000009:mdna:106]
[same as prior period, unchanged from 0001628280-25-026845:mdna:100]

[0001805385-25-000009:mdna:107]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 3,544 |  |  | $ | 4,071 |  |  | $ | (527) |  |  | (13) | % |
| Materials and prototypes | 173 |  |  | 504 |  |  | (331) |  |  | (66) | % |
| Professional fees | 658 |  |  | 929 |  |  | (271) |  |  | (29) | % |
| Other | 362 |  |  | 346 |  |  | 16 |  |  | 5 | % |
|  | $ | 4,737 |  |  | $ | 5,850 |  |  | $ | (1,113) |  |  | (19) | % |

[0001805385-25-000009:mdna:108]
The decrease in personnel related expenses is due to the January 2025 reductions in force, which resulted in a decrease in payroll costs of $0.6 million, partially offset by a lower amount of payroll costs capitalized related to internal-use software and software embedded in products to be sold or leased of $0.2 million. The decrease in materials and prototypes expense is due to a decrease of $0.2 million in design and engineering costs related to the development of the

[0001805385-25-000009:mdna:109]
10

[0001805385-25-000009:mdna:110]
next generation of our Evolv Express system and new product offerings in the prior year. The decrease in professional fees primarily relates to a decrease in consulting costs incurred for product development and engineering of $0.3 million.

[0001805385-25-000009:mdna:111]
[same as prior period, unchanged from 0001628280-25-026845:mdna:105]

[0001805385-25-000009:mdna:112]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 9,134 |  |  | $ | 11,979 |  |  | $ | (2,845) |  |  | (24) | % |
| Advertising and direct marketing | 693 |  |  | 1,044 |  |  | (351) |  |  | (34) | % |
| Travel and entertainment | 656 |  |  | 1,388 |  |  | (732) |  |  | (53) | % |
| Professional fees | 584 |  |  | 880 |  |  | (296) |  |  | (34) | % |
| Other | 669 |  |  | 1,066 |  |  | (397) |  |  | (37) | % |
|  | $ | 11,736 |  |  | $ | 16,357 |  |  | $ | (4,621) |  |  | (28) | % |

[0001805385-25-000009:mdna:113]
The decrease in personnel related expenses is due to a decrease in payroll costs and stock-based compensation of $3.3 million, which resulted primarily from the reductions in force in May 2024 and January 2025, partially offset by an increase in severance cost of $0.5 million. Stock compensation expense included in sales and marketing expenses was $1.7 million for the three months ended June 30, 2025 compared to $2.7 million for the three months ended June 30, 2024. The decrease in advertising and direct marketing expense is primarily due to a decrease in sponsorship fees of $0.2 million. The decrease in travel and entertainment expense of $0.7 million is due to a decrease in travel costs for in-person sales meetings as a result of our reductions in force. Professional fees decreased due to a decrease in marketing consulting costs. Other expense decreased primarily due to reduction in shipping costs related to demo units of $0.2 million.

[0001805385-25-000009:mdna:114]
[same as prior period, unchanged from 0001628280-25-026845:mdna:108]

[0001805385-25-000009:mdna:115]
|  | Three Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
|  |  |  | (Restated) |  |  |  |  |
| Personnel related (including stock-based compensation) | $ | 6,206 |  |  | $ | 6,931 |  |  | $ | (725) |  |  | (10) | % |
| Professional fees | 2,191 |  |  | 1,654 |  |  | 537 |  |  | 32 | % |
| Insurance costs | 775 |  |  | 766 |  |  | 9 |  |  | 1 | % |
| Non-recurring professional and other expense | 8,066 |  |  | 4,710 |  |  | 3,356 |  |  | 71 | % |
|  | $ | 17,238 |  |  | $ | 14,061 |  |  | $ | 3,177 |  |  | 23 | % |

[0001805385-25-000009:mdna:116]
The decrease in personnel related expenses is due to a decrease in stock-based compensation of $0.9 million, which resulted primarily from the termination of certain executives as well as the reduction in force in January 2025, partially offset by an increase in severance costs of $0.2 million. Stock compensation expense included in general and administrative expenses was $2.4 million for the three months ended June 30, 2025 compared to $3.3 million for the three months ended June 30, 2024. Professional fees increased primarily due to an increase in outsourced accounting consultancy of $0.6 million. Non-recurring professional fees and other expense increased primarily due to a $4.5 million increase in consulting and legal fees related to the Investigation (as defined in Note 2 in the notes to the condensed consolidated financial statements in this Quarterly Report on Form 10-Q) and related matters, as well as additional audit fees incurred in connection with the restatement of prior period financial statements, partially offset by insurance recoveries of $1.7 million, $1.0 million of estimated net losses related to ongoing legal matters, and an increase in rent of $0.3 million for additional leased space, partially offset by a decrease in expected credit loss expense of $0.3 million.

[0001805385-25-000009:mdna:117]
[same as prior period, unchanged from 0001628280-25-026845:mdna:111]

[0001805385-25-000009:mdna:118]
Restructuring costs of $0.9 million for the three months ended June 30, 2024 resulted from the reduction in force in May 2024. No restructuring cost was recognized for the three months ended June 30, 2025.

[0001805385-25-000009:mdna:119]
11

[0001805385-25-000009:mdna:120]
[same as prior period, unchanged from 0001628280-25-026845:mdna:113]

[0001805385-25-000009:mdna:121]
Interest income of $0.2 million for the three months ended June 30, 2025 and $0.7 million for the three months ended June 30, 2024 related primarily to interest earned on money market funds and the accretion of discounts on treasury bills. The interest earned decreased primarily due to lower average balances in interest-bearing accounts during the three months ended June 30, 2025 compared to during  the three months ended June 30, 2024.

[0001805385-25-000009:mdna:122]
[same as prior period, unchanged from 0001628280-25-026845:mdna:115]

[0001805385-25-000009:mdna:123]
Change in the fair value of the contingent earn-out liability resulted in a $14.2 million loss and $16.5 million gain for the three months ended June 30, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001805385-25-000009:mdna:124]
[same as prior period, unchanged from 0001628280-25-026845:mdna:117]

[0001805385-25-000009:mdna:125]
Change in the fair value of the contingently issuable common stock liability resulted in a $3.9 million loss and $3.7 million gain for the three months ended June 30, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001805385-25-000009:mdna:126]
[same as prior period, unchanged from 0001628280-25-026845:mdna:119]

[0001805385-25-000009:mdna:127]
Change in the fair value of the public warrant liability resulted in a $5.3 million loss and $4.9 million gain for the three months ended June 30, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001805385-25-000009:mdna:128]
Comparison of the Six Months Ended June 30, 2025 and 2024

[0001805385-25-000009:mdna:129]
The following table summarizes our results of operations for the six months ended June 30, 2025 and 2024 (in thousands):

[0001805385-25-000009:mdna:130]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 4,850 |  |  | $ | 3,445 |  |  | $ | 1,405 |  |  | 41 | % |
| Subscription revenue | 39,437 |  |  | 29,874 |  |  | 9,563 |  |  | 32 |  |
| Service revenue | 13,416 |  |  | 10,818 |  |  | 2,598 |  |  | 24 |  |
| License fee and other revenue | 6,848 |  |  | 3,268 |  |  | 3,580 |  |  | 110 |  |
| Total revenue | 64,551 |  |  | 47,405 |  |  | 17,146 |  |  | 36 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 8,535 |  |  | 5,953 |  |  | 2,582 |  |  | 43 |  |
| Cost of subscription revenue | 16,790 |  |  | 11,894 |  |  | 4,896 |  |  | 41 |  |
| Cost of service revenue | 3,415 |  |  | 2,345 |  |  | 1,070 |  |  | 46 |  |
| Cost of license fee and other revenue | 443 |  |  | 301 |  |  | 142 |  |  | 47 |  |
| Total cost of revenue | 29,183 |  |  | 20,493 |  |  | 8,690 |  |  | 42 |  |
| Gross profit | 35,368 |  |  | 26,912 |  |  | 8,456 |  |  | 31 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 9,599 |  |  | 12,246 |  |  | (2,647) |  |  | (22) |  |
| Sales and marketing | 22,779 |  |  | 32,216 |  |  | (9,437) |  |  | (29) |  |
| General and administrative | 32,210 |  |  | 25,867 |  |  | 6,343 |  |  | 25 |  |
| Restructuring costs | 2,662 |  |  | 860 |  |  | 1,802 |  |  | 210 |  |
| Total operating expenses | 67,250 |  |  | 71,189 |  |  | (3,939) |  |  | (6) |  |
| Loss from operations | (31,882) |  |  | (44,277) |  |  | 12,395 |  |  | 28 |  |
| Other (expense) income, net: |  |  |  |  |  |  |  |
| Interest expense | (1) |  |  | — |  |  | (1) |  |  | * |
| Interest income | 613 |  |  | 1,766 |  |  | (1,153) |  |  | (65) |  |
| Other income (expense), net | 161 |  |  | (67) |  |  | 228 |  |  | 340 |  |
| Change in fair value of contingent earn-out liability | (5,224) |  |  | 23,413 |  |  | (28,637) |  |  | (122) |  |
| Change in fair value of contingently issuable common stock liability | (2,247) |  |  | 4,274 |  |  | (6,521) |  |  | (153) |  |
| Change in fair value of public warrant liability | (3,582) |  |  | 7,037 |  |  | (10,619) |  |  | (151) |  |
| Total other (expense) income, net | (10,280) |  |  | 36,423 |  |  | (46,703) |  |  | (128) |  |
| Loss before income taxes | $ | (42,162) |  |  | $ | (7,854) |  |  | $ | (34,308) |  |  | (437) | % |
| Provision for income taxes | $ | 62 |  |  | $ | — |  |  | $ | 62 |  |  | * |
| Net loss | $ | (42,224) |  |  | $ | (7,854) |  |  | $ | (34,370) |  |  | (438) | % |

[0001805385-25-000009:mdna:131]
13

[0001805385-25-000009:mdna:132]
Revenue, Cost of Revenue and Gross Profit

[0001805385-25-000009:mdna:133]
We believe there are several key trends that are continuing to drive increased adoption of our solutions and growth in our sales, including (i) escalating gun violence, which has created stronger demand for security screening solutions for customers and prospects in our key vertical markets, (ii) customer acquisition activities which led to the addition of 117 new customers during the six months ended June 30, 2025, (iii) the expansion of our existing customers’ initial Evolv Express deployments to other venues and locations as well as expanding their fleet with our Evolv eXpedite offering, and (iv) growing momentum with our channel partners which helps us extend our reach in certain geographies or vertical markets.

[0001805385-25-000009:mdna:134]
Product Revenue

[0001805385-25-000009:mdna:135]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Product revenue | $ | 4,850 |  |  | $ | 3,445 |  |  | $ | 1,405 |  |  | 41 | % |
| Cost of product revenue | $ | 8,535 |  |  | $ | 5,953 |  |  | $ | 2,582 |  |  | 43 | % |
| Gross loss - Product revenue | $ | (3,685) |  |  | $ | (2,508) |  |  | $ | (1,177) |  |  | (47) | % |
| Gross profit margin - Product revenue | (76) | % |  | (73) | % |  | N/A |  | (3) | % |

[0001805385-25-000009:mdna:136]
The increases in product revenue and cost of product revenue are primarily due to an increased utilization of our purchase subscription model, in which the customers purchase Evolv Express and Evolv eXpedite systems directly from us, for the six months ended June 30, 2025 compared to the prior year period. The decrease in product gross profit margin for the six months ended June 30, 2025 compared to the six months ended June 30, 2024 is primarily due to a $0.8 million increase in inventory reserves during the six months ended June 30, 2025, partially offset by a $1.1 million expense associated with adverse non-cancellable inventory purchase commitments recognized during the six months ended June 30, 2024, and a net $0.6 million decrease in manufacturing expense during the six months ended June 30, 2025, primarily related to the deployments of second generation of Evolv Express systems, which provide improved gross margins as compared to the first generation products, partially offset by the initial deployments of Evolv eXpedite systems, which, as a new product offering, reflect a higher initial cost to produce that we expect to gradually decline in the future.

[0001805385-25-000009:mdna:137]
Subscription Revenue

[0001805385-25-000009:mdna:138]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Subscription revenue | $ | 39,437 |  |  | $ | 29,874 |  |  | $ | 9,563 |  |  | 32 | % |
| Cost of subscription revenue | $ | 16,790 |  |  | $ | 11,894 |  |  | $ | 4,896 |  |  | 41 | % |
| Gross profit - Subscription revenue | $ | 22,647 |  |  | $ | 17,980 |  |  | $ | 4,667 |  |  | 26 | % |
| Gross profit margin - Subscription revenue | 57 | % |  | 60 | % |  | N/A |  | (3) | % |

[0001805385-25-000009:mdna:139]
The increases in subscription revenue, cost of subscription revenue, and subscription gross profit are primarily due to continued growth in our customer base as of June 30, 2025 compared to the prior year, with a higher number of active Evolv Express systems deployed under our pure subscription model and an increase in short term rental subscription revenue during the six months ended June 30, 2025. Gross profit margin decreased primarily due to a $1.3 million of loss on disposals of certain first generation Evolv Express systems, partially offset by our ability to leverage our fixed costs over a higher revenue base and lower costs related to our second generation of Evolv Express systems.

[0001805385-25-000009:mdna:140]
Service Revenue

[0001805385-25-000009:mdna:141]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Service revenue | $ | 13,416 |  |  | $ | 10,818 |  |  | $ | 2,598 |  |  | 24 | % |
| Cost of service revenue | $ | 3,415 |  |  | $ | 2,345 |  |  | $ | 1,070 |  |  | 46 | % |
| Gross profit - Service revenue | $ | 10,001 |  |  | $ | 8,473 |  |  | $ | 1,528 |  |  | 18 | % |
| Gross profit margin - Service revenue | 75 | % |  | 78 | % |  | N/A |  | (4) | % |

[0001805385-25-000009:mdna:142]
The increases in service revenue, cost of service revenue, and gross profit are primarily due to an increased number of active revenue-generating purchase subscription units, as well as active revenue-generating units purchased by customers directly from Columbia Tech under our distributor licensing model, for the six months ended June 30, 2025 compared to the six months ended June 30, 2024. The decrease in gross profit margin is primarily due to a $0.2 million expense related to certain accrued service fees and increased amortization of capitalized software costs during the six months ended June 30, 2025 of $0.4 million due to the release of Evolv eXpedite and our second generation of Evolv Express systems.

[0001805385-25-000009:mdna:143]
License fee and other revenue

[0001805385-25-000009:mdna:144]
|  | Six Months EndedJune 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| License fee and other revenue | $ | 6,848 |  |  | $ | 3,268 |  |  | $ | 3,580 |  |  | 110 | % |
| Cost of license fee and other revenue | $ | 443 |  |  | $ | 301 |  |  | $ | 142 |  |  | 47 | % |
| Gross profit - License fee and other revenue | $ | 6,405 |  |  | $ | 2,967 |  |  | $ | 3,438 |  |  | 116 | % |
| Gross profit margin - License fee and other revenue | 94 | % |  | 91 | % |  | N/A |  | 3 | % |

[0001805385-25-000009:mdna:145]
The increase in license fee and other revenue and gross profit was primarily driven by $5.5 million of license fees earned during the six months ended June 30, 2025 compared to $2.4 million earned during the six months ended June 30, 2024 under the Distribution and License Agreement which was executed in March 2023. In addition to the increase in the unit sales through our distributor licensing model, per-unit license fees also increased for our second generation of Evolv Express systems. License fee revenue earned under the agreement has no associated cost of revenue.

[0001805385-25-000009:mdna:146]
Research and Development Expenses

[0001805385-25-000009:mdna:147]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 7,394 |  |  | $ | 8,249 |  |  | $ | (855) |  |  | (10) | % |
| Materials and prototypes | 240 |  |  | 1,343 |  |  | (1,103) |  |  | (82) | % |
| Professional fees | 1,330 |  |  | 1,846 |  |  | (516) |  |  | (28) | % |
| Other | 635 |  |  | 808 |  |  | (173) |  |  | (21) | % |
|  | $ | 9,599 |  |  | $ | 12,246 |  |  | $ | (2,647) |  |  | (22) | % |

[0001805385-25-000009:mdna:148]
The decrease in personnel related expenses is primarily due to the January 2025 reductions in force, which resulted in a decrease in payroll costs of $0.8 million, partially offset by a $0.2 million increase in stock-based compensation. The decrease in materials and prototypes expense is primarily due to a decrease of $0.5 million in design and engineering costs and $0.4 million inventory reserve on unused components recognized in the prior year, both of which relate primarily to the development of the next generation of our Evolv Express system and new product offerings. The decrease in professional fees primarily relates to a decrease in consulting costs incurred for product development and engineering of $0.5 million. The decrease in other expense is primarily due to a decrease in IT and software subscription and supplies costs of $0.2 million.

[0001805385-25-000009:mdna:149]
15

[0001805385-25-000009:mdna:150]
Sales and Marketing Expenses

[0001805385-25-000009:mdna:151]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 17,638 |  |  | $ | 23,825 |  |  | $ | (6,187) |  |  | (26) | % |
| Advertising and direct marketing | 1,276 |  |  | 1,854 |  |  | (578) |  |  | (31) | % |
| Travel and entertainment | 1,200 |  |  | 2,658 |  |  | (1,458) |  |  | (55) | % |
| Professional fees | 1,229 |  |  | 1,839 |  |  | (610) |  |  | (33) | % |
| Other | 1,436 |  |  | 2,040 |  |  | (604) |  |  | (30) | % |
|  | $ | 22,779 |  |  | $ | 32,216 |  |  | $ | (9,437) |  |  | (29) | % |

[0001805385-25-000009:mdna:152]
The decrease in personnel related expenses is due to a decrease in payroll costs and stock-based compensation of $6.5 million, which resulted primarily from the reductions in force in May 2024 and January 2025, partially offset by an increase in severance cost of $0.5 million. Stock compensation expense included in sales and marketing expenses was $2.8 million for the six months ended June 30, 2025 compared to $5.7 million for the six months ended June 30, 2024. The decrease in advertising and direct marketing expense is primarily due to a decrease in sponsorship fees of $0.4 million. The decrease in travel and entertainment expense of $1.5 million is due to a decrease in travel costs for in-person sales meetings as a result of our reductions in force. Professional fees decreased due to a decrease in marketing consulting costs of $0.6 million. Other expense decreased primarily due to reduction in shipping costs related to demo units of $0.3 million and supplies costs of $0.2 million.

[0001805385-25-000009:mdna:153]
General and Administrative Expenses

[0001805385-25-000009:mdna:154]
|  | Six Months Ended June 30, |  |  |  |  |
|  | 2025 |  | 2024 |  | $ Change |  | % Change |
| Personnel related (including stock-based compensation) | $ | 11,510 |  |  | $ | 13,123 |  |  | $ | (1,613) |  |  | (12) | % |
| Professional fees | 4,849 |  |  | 4,212 |  |  | 637 |  |  | 15 | % |
| Insurance costs | 1,506 |  |  | 1,508 |  |  | (2) |  |  | — | % |
| Non-recurring professional and other expense | 14,345 |  |  | 7,024 |  |  | 7,321 |  |  | 104 | % |
|  | $ | 32,210 |  |  | $ | 25,867 |  |  | $ | 6,343 |  |  | 25 | % |

[0001805385-25-000009:mdna:155]
The decrease in personnel related expenses is due to a decrease in payroll costs and stock-based compensation of $1.7 million, which resulted primarily from the termination of certain executives and the reduction in force in January 2025, partially offset by an increase in severance costs of $0.2 million. Stock compensation expense included in general and administrative expenses was $4.4 million for the six months ended June 30, 2025 compared to $5.7 million for the six months ended June 30, 2024. Professional fees increased primarily due to an increase in outsourced accounting consultancy of $1.3 million, partially offset by a decrease in audit and tax fees of $0.7 million. Non-recurring professional fees and other expense increased primarily due to a $11.5 million increase in consulting and legal fees related to the Investigation (as defined in Note 2 in the notes to the condensed consolidated financial statements in this Quarterly Report on Form 10-Q) and related matters, as well as additional audit fees incurred in connection with the restatement of prior period financial statements, $1.0 million of estimated net losses related to ongoing legal matters, and an increase in rent of $0.7 million for additional leased space, partially offset by insurance recoveries of $5.6 million.

[0001805385-25-000009:mdna:156]
Restructuring Costs

[0001805385-25-000009:mdna:157]
Restructuring costs of $2.7 million for the six months ended June 30, 2025 resulted from the reduction in force in January 2025. Stock compensation expense included in restructuring costs was $0.5 million for the six months ended June 30, 2025. Smaller restructuring costs of $0.9 million for the six months ended June 30, 2024 resulted from the reduction in force in May 2024.

[0001805385-25-000009:mdna:158]
16

[0001805385-25-000009:mdna:159]
Interest Income

[0001805385-25-000009:mdna:160]
Interest income of $0.6 million and $1.8 million for the six months ended June 30, 2025 and 2024, respectively, related primarily to interest earned on money market funds and the accretion of discounts on treasury bills. The interest earned decreased primarily due to lower average balances in interest-bearing accounts during the six months ended June 30, 2025 compared to during  the six months ended June 30, 2024.

[0001805385-25-000009:mdna:161]
Change in Fair Value of Contingent Earn-out Liability

[0001805385-25-000009:mdna:162]
Change in the fair value of the contingent earn-out liability resulted in a $5.2 million loss and $23.4 million gain for the six months ended June 30, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments. The contingent earn-out liability was established in connection with the closing of the Merger.

[0001805385-25-000009:mdna:163]
Change in Fair Value of Contingently Issuable Common Stock Liability

[0001805385-25-000009:mdna:164]
Change in the fair value of the contingently issuable common stock liability resulted in a $2.2 million loss and $4.3 million gain for the six months ended June 30, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments. The contingently issuable common stock liability was established in connection with the closing of the Merger.

[0001805385-25-000009:mdna:165]
Change in Fair Value of Public Warrant Liability

[0001805385-25-000009:mdna:166]
Change in the fair value of the public warrant liability resulted in a $3.6 million loss and a $7.0 million gain for the six months ended June 30, 2025 and 2024, respectively, resulting from quarterly mark-to-market adjustments. The public warrant liability was established in connection with the closing of the Merger.

[0001805385-25-000009:mdna:167]
[same as prior period, unchanged from 0001628280-25-026845:mdna:121]

[0001805385-25-000009:mdna:168]
Our financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. Our primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. We expect these needs to continue as we develop and grow our business. As of June 30, 2025, we had $36.9 million in cash, cash equivalents, and marketable securities. We incurred a net loss of $40.5 million and a net income of $3.4 million (as restated) for the three months ended June 30, 2025 and 2024, respectively, and incurred a net loss of $42.2 million and $7.9 million (as restated) for the six months ended June 30, 2025 and 2024, respectively. We incurred cash outflows from operating activities of $0.4 million and $37.7 million (as restated) during the six months ended June 30, 2025 and 2024, respectively. We expect to continue to generate net losses for the foreseeable future.

[0001805385-25-000009:mdna:169]
[same as prior period, unchanged from 0001628280-25-026845:mdna:123]

[0001805385-25-000009:mdna:170]
As described below in the Financing Agreement sub-section, on July 29, 2025, Evolv Technologies, Inc. entered into the $75.0 million MidCap Credit Agreement (as defined below), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's subscription sales model. The MidCap Credit Agreement provides for an initial $30.0 million term loan facility, a $30.0 million delayed draw facility (available for drawdown during the two-year period following the closing date), and a $15.0 million revolving line of credit. At closing, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs incurred in connection with the closing of MidCap Credit Agreement.

[0001805385-25-000009:mdna:171]
We expect our cash, cash equivalents, and marketable securities of $36.9 million as of June 30, 2025, together with cash we expect to generate from future operations and our borrowing availability under our Senior Secured Credit Facilities, will be sufficient to fund our operating expenses and capital expenditure requirements for a period of at least twelve months and thereafter from the date of this Quarterly Report on Form 10-Q. As we are in the growth stage of our business and operate in an emerging field of technology, we expect to continue to strategically and carefully invest in various areas of the business to support that growth.

[0001805385-25-000009:mdna:172]
[same as prior period, unchanged from 0001628280-25-026845:mdna:127]

[0001805385-25-000009:mdna:173]
Financing Arrangement

[0001805385-25-000009:mdna:174]
On July 29, 2025, the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's subscription sales model. The MidCap Credit Agreement provides for an initial $30.0 million term loan facility, a $30.0 million delayed draw facility (available for drawdown during the two-year period following the closing date), and a $15.0 million revolving line of credit, each with a term of five years (collectively, the "Senior Secured Credit Facilities").

[0001805385-25-000009:mdna:175]
The Senior Secured Credit Facilities are guaranteed by the Company, and in the future, may be guaranteed by certain material subsidiaries. The Senior Secured Credit Facilities are secured by a first lien on substantially all of the assets of the Company. The borrowings under the Senior Secured Credit Facilities bear interest at a fluctuating rate per annum equal to (x) a base rate determined by reference to the higher of (1) the prime rate of Wells Fargo and (2) 2.00% or (y) Term Secured Overnight Financing Rate ("Term SOFR"), in each case, plus an applicable margin calculated depending on earnings before interest, taxes, depreciation, and amortization ("EBITDA"). At closing, the applicable margin on Term SOFR loans was 5.25%. Interest and principal are payable monthly. Principal is repaid on a straight-line basis over the remaining 12 months of the term.

[0001805385-25-000009:mdna:176]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary affirmative and negative covenants, including a minimum annual recurring revenue covenant, a minimum EBITDA covenant that takes effect on the second anniversary of the closing date, and a minimum liquidity covenant that would cease to apply following the resolution of certain litigation and regulatory matters, in addition to customary reporting requirements of periodic financial results. See Note 17, Subsequent Events for additional information related to the Senior Secured Credit Facilities.

[0001805385-25-000009:mdna:177]
[same as prior period, unchanged from 0001628280-25-026845:mdna:130]

[0001805385-25-000009:mdna:178]
The following is a description of commitments for capital expenditures and other known and reasonably likely cash requirements as of June 30, 2025. We anticipate fulfilling such commitments with our existing cash, cash equivalents, and marketable securities, as well as cash and cash equivalents obtained through operations and the proceeds from our Senior Secured Credit Facilities. Cash, cash equivalents, and marketable securities amounted to $36.9 million as of June 30, 2025.

[0001805385-25-000009:mdna:179]
We are party to a lease agreement for office space at our headquarters in Waltham, MA. During the three months ended March 31, 2024, we amended the lease agreement to extend the term through October 31, 2025, with the option to further extend through June 30, 2031 with written notice. Additionally, in August 2024, we amended the lease agreement again to expand our footprint in our headquarters and extend the term of the lease through May 2031. Per the second lease amendment, we are no longer required to maintain a minimum cash balance of $0.3 million as a security deposit on the leased space. This amount was previously classified as restricted cash, non-current, as shown in the condensed consolidated statement of cash flows as of March 31, 2024. Total future minimum lease payments under this noncancelable operating lease amount to $18.6 million as of June 30, 2025.

[0001805385-25-000009:mdna:180]
[same as prior period, unchanged from 0001628280-25-026845:mdna:133]

[0001805385-25-000009:mdna:181]
18

[0001805385-25-000009:mdna:182]
[same as prior period, unchanged from 0001628280-25-026845:mdna:134]

[0001805385-25-000009:mdna:183]
[same as prior period, unchanged from 0001628280-25-026845:mdna:135]

[0001805385-25-000009:mdna:184]
|  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |
|  |  |  | (Restated) |
| Net cash used in operating activities | $ | (426) |  |  | $ | (37,732) |  |
| Net cash (used in) provided by investing activities | (3,611) |  |  | 5,621 |  |
| Net cash provided by financing activities | 4,095 |  |  | 636 |  |
| Effect of exchange rate changes on cash and cash equivalents | (131) |  |  | 11 |  |
| Net decrease in cash, cash equivalents and restricted cash | $ | (73) |  |  | $ | (31,464) |  |

[0001805385-25-000009:mdna:185]
[same as prior period, unchanged from 0001628280-25-026845:mdna:137]

[0001805385-25-000009:mdna:186]
|  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |
|  |  |  | (Restated) |
| Net loss | $ | (42,224) |  |  | $ | (7,854) |  |
| Adjustments to reconcile net loss to net cash provided by (used in) operating activities | 37,361 |  |  | (10,672) |  |
| Changes in operating assets and liabilities | 4,437 |  |  | (19,206) |  |
| Net cash used in operating activities | $ | (426) |  |  | $ | (37,732) |  |

[0001805385-25-000009:mdna:187]
Net loss increased from $7.9 million (as restated) for the six months ended June 30, 2024 to $42.2 million for the six months ended June 30, 2025, as discussed in “Results of Operations” above.

[0001805385-25-000009:mdna:188]
Adjustments to reconcile net loss to net cash used in operating activities for the six months ended June 30, 2025 include $11.1 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock warrant liability, and public warrant liability, $10.4 million of stock-based compensation expense, and $11.3 million of depreciation and amortization. For the six months ended June 30, 2024, such adjustments included $13.9 million (as restated) of stock-based compensation expense, $7.4 million of depreciation and amortization, and $34.7 million of an aggregate change in fair value of the earn-out liability, contingently issuable common stock liability, and public warrant liability.

[0001805385-25-000009:mdna:189]
Changes in operating assets and liabilities for the six months ended June 30, 2025 are primarily related to the following:

[0001805385-25-000009:mdna:190]
•$6.1 million increase in accounts payable (excluding the non-cash portion related to capital expenditures incurred but not yet paid from December 31, 2024 to June 30, 2025) due primarily to the timing of vendor payments;

[0001805385-25-000009:mdna:191]
•$6.2 million increase in deferred revenue due to a higher volume of sales;

[0001805385-25-000009:mdna:192]
•$6.1 million decrease in inventory primarily due to an increased focus on efficient inventory management, partially offset by a decrease in products expected to be leased to customers; and

[0001805385-25-000009:mdna:193]
•$18.4 million increase in accrued expenses and other current liabilities primarily due to a legal settlement offer accrual and the timing of accrued payroll tax, partially offset by decrease in accrued vendor payables; partially offset by

[0001805385-25-000009:mdna:194]
•$13.3 million increase in accounts receivable primarily due to higher sales and the timing of billings to customers; and

[0001805385-25-000009:mdna:195]
•$18.8 million increase in prepaid expenses and other current assets primarily due to estimated outstanding insurance recoveries and unsettled options exercises due to timing, partially offset by decrease in vendor deposits.

[0001805385-25-000009:mdna:196]
Changes in operating assets and liabilities for the six months ended June 30, 2024 are primarily related to the following:

[0001805385-25-000009:mdna:197]
•$14.1 million (as restated) increase in accounts receivable primarily due to the timing of customer billings;

[0001805385-25-000009:mdna:198]
•$10.0 million (as restated) increase in inventory primarily due to increased purchases to satisfy future expected demand and for the ongoing transition to the next generation of Evolv Express systems;

[0001805385-25-000009:mdna:199]
•$3.0 million increase in prepaid expenses and other current assets primarily due to prepaid deposits related to orders placed for Evolv Express systems;

[0001805385-25-000009:mdna:200]
•$1.7 million decrease in accounts payable (excluding the non-cash portion related to capital expenditures incurred but not yet paid) due primarily to the timing of vendor payments; partially offset by

[0001805385-25-000009:mdna:201]
•$10.3 million increase in deferred revenue due to a higher volume of sales.

[0001805385-25-000009:mdna:202]
[same as prior period, unchanged from 0001628280-25-026845:mdna:153]

[0001805385-25-000009:mdna:203]
During the six months ended June 30, 2025, cash used in investing activities was $3.6 million, consisting of $15.3 million for the purchase of property and equipment, primarily related to the purchase of Evolv Express systems to be leased to customers and $3.1 million for the development of internal-use software and software embedded in products to be sold or leased, offset by $14.8 million of net cash provided by purchases and redemptions of marketable securities.

[0001805385-25-000009:mdna:204]
During the six months ended June 30, 2024, cash provided by investing activities was $5.6 million (as restated), consisting primarily of a net $30.4 million inflow related to purchases and redemptions of marketable securities, offset by $21.6 million (as restated) for the purchase of property and equipment, primarily related to the purchase of Evolv Express systems to be leased to customers, and $3.1 million (as restated) for the development of internal-use software and software embedded in products to be sold or leased.

[0001805385-25-000009:mdna:205]
[same as prior period, unchanged from 0001628280-25-026845:mdna:156]

[0001805385-25-000009:mdna:206]
During the six months ended June 30, 2025 and June 30, 2024, cash provided by financing activities was $4.1 million and  $0.6 million, respectively, consisting primarily of proceeds from the exercise of stock options.

[0001805385-25-000009:mdna:207]
[same as prior period, unchanged from 0001628280-25-026845:mdna:159]

[0001805385-25-000009:mdna:208]
[same as prior period, unchanged from 0001628280-25-026845:mdna:160]

[0001805385-25-000009:mdna:209]
[same as prior period, unchanged from 0001628280-25-026845:mdna:161]

[0001805385-25-000009:mdna:210]
Our critical accounting estimates are described in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition” of our 2024 Form 10-K. Other than disclosures related to estimating the fair value of market-based stock units and for estimating rebate liabilities, as discussed below, there have been no material changes to our critical accounting estimates during the six months ended June 30, 2025.

[0001805385-25-000009:mdna:211]
Market-based Stock Units

[0001805385-25-000009:mdna:212]
The estimated fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.

[0001805385-25-000009:mdna:213]
Partner Rebate Program

[0001805385-25-000009:mdna:214]
For the fiscal year 2025, the Company implemented a channel partner rebate program (the “Rebate Program”) for eligible resellers. Under the Rebate Program, eligible resellers that attain at least 25% of their current fiscal year total contract value (“TCV”) target (“Annual Target”) in a given quarter are eligible for a rebate based upon a percentage of their TCV for that quarter. In addition, resellers that meet their Annual Target are eligible for a one-time rebate based upon a percentage of their total fiscal year TCV, applied as a credit in the subsequent fiscal year. All rebates are issued as credits

[0001805385-25-000009:mdna:215]
20

[0001805385-25-000009:mdna:216]
against future purchases, and no cash rebates are paid. Unused rebate credits are forfeited in the event of a reseller agreement termination.
