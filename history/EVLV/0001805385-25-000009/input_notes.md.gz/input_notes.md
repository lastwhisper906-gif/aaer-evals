# EVLV notes — 0001805385-25-000009


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001805385-25-000009:notes:1]
[same as prior period, unchanged from 0001628280-25-026845:notes:1]

[0001805385-25-000009:notes:2]
[same as prior period, unchanged from 0001628280-25-026845:notes:2]

[0001805385-25-000009:notes:3]
As used in this Quarterly Report on Form 10-Q, unless otherwise indicated or the context otherwise requires, references to “we,” “us,” “our,” the “Company” and “Evolv” refer to the consolidated operations of Evolv Technologies Holdings, Inc. and its wholly owned subsidiaries, which include Evolv Technologies, Inc., Evolv Technologies UK Ltd. (“Evolv UK”) and Give Evolv LLC. References to “NHIC” refer to our legal predecessor, a special-purpose acquisition company, prior to the consummation of our business combination on July 16, 2021 (the “Merger”), and references to “Legacy Evolv” refer to Evolv Technologies, Inc. dba Evolv Technology, Inc. prior to the consummation of the Merger. The Merger was contemplated by the Agreement and Plan of Merger, dated March 5, 2021, with NHIC Sub Inc., NHIC, and Legacy Evolv, as amended by that certain First Amendment to Agreement and Plan of Merger dated June 5, 2021 (as amended, the “Merger Agreement”).

[0001805385-25-000009:notes:4]
[same as prior period, unchanged from 0001628280-25-026845:notes:4]

[0001805385-25-000009:notes:5]
The condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) and include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. Any reference in these notes to applicable guidance is meant to refer to the authoritative GAAP as found in the Accounting Standards Codification (“ASC”) and Accounting Standards Update (“ASU”) of the Financial Accounting Standards Board (“FASB”).

[0001805385-25-000009:notes:6]
[same as prior period, unchanged from 0001628280-25-026845:notes:6]

[0001805385-25-000009:notes:7]
The Company’s financial statements have been prepared on the basis of continuity of operations, realization of assets and the satisfaction of liabilities in the ordinary course of business. The Company's primary requirements for liquidity and capital are working capital, inventory management, capital expenditures and general corporate needs. The Company expects these needs to continue as it develops and grows its business. As of June 30, 2025, the Company had $36.9 million in cash, cash equivalents, and marketable securities. The Company incurred a net loss of $42.2 million and $7.9 million for the six months ended June 30, 2025 and 2024, respectively. The Company incurred cash outflows from operating activities of $0.4 million and $37.7 million during the six months ended June 30, 2025 and 2024, respectively. The Company expects to continue to generate losses for the foreseeable future.

[0001805385-25-000009:notes:8]
[same as prior period, unchanged from 0001628280-25-026845:notes:8]

[0001805385-25-000009:notes:9]
On July 29, 2025, the Company entered into a $75.0 million credit, security, and guaranty agreement with MidCap Financial Trust and the other lenders party thereto (the “MidCap Credit Agreement”), the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the Company's subscription sales model. The MidCap Credit Agreement provides for an initial $30.0 million term loan facility, a $30.0 million delayed draw facility (available for drawdown during the two-year period following the closing date), and a $15.0 million revolving line

[0001805385-25-000009:notes:10]
of credit, each with a term of five years (collectively, the "Senior Secured Credit Facilities"). At closing, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs incurred in connection with the closing of MidCap Credit Agreement. See Note 17, Subsequent Events for additional information.

[0001805385-25-000009:notes:11]
The Company expects its cash, cash equivalents, and marketable securities of $36.9 million as of June 30, 2025, together with cash it expects to generate from future operations and borrowing availability under the Senior Secured Credit Facilities, will be sufficient to fund its operating expenses and capital expenditure requirements for a period of at least twelve months from the date of this Quarterly Report on Form 10-Q. As the Company is in the growth stage of its business and operates in an emerging field of technology, the Company expects to continue to strategically and carefully invest in various areas of the business to support that growth.

[0001805385-25-000009:notes:12]
[same as prior period, unchanged from 0001628280-25-026845:notes:12]

[0001805385-25-000009:notes:13]
[same as prior period, unchanged from 0001628280-25-026845:notes:13]

[0001805385-25-000009:notes:14]
The accompanying unaudited condensed consolidated financial statements as of June 30, 2025, and for the three and six months ended June 30, 2025 and 2024 have been prepared on the same basis as the audited annual consolidated financial statements as of December 31, 2024 and, in the opinion of management, reflect all adjustments, which include only normal recurring adjustments, necessary for the fair statement of the Company’s financial position as of June 30, 2025, the results of its operations for the three and six months ended June 30, 2025 and 2024 and cash flows for the six months ended June 30, 2025 and 2024. The results for the three and six months ended June 30, 2025 are not necessarily indicative of results to be expected for the year ending December 31, 2025, any other interim periods, or any future year or period. These interim unaudited condensed consolidated financial statements should be read in conjunction with the financial statements included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024.

[0001805385-25-000009:notes:15]
Reclassifications

[0001805385-25-000009:notes:16]
During the three months ended March 31, 2025, the Company began classifying restructuring charges, which includes termination charges arising from severance obligations, incremental non-cash expense, and other customary employee benefit payments in connection with a reduction in force, within restructuring costs on the condensed consolidated statements of operations and comprehensive loss, whereas the restructuring costs for these services had previously been included in cost of service revenue, research and development expenses, sales and marketing expenses, and general and administrative expenses. These reclassifications were made to align the presentation of restructuring charges with the Company's internal reporting and analysis. The reclassifications increased gross profit by $0.2 million for both the three and six months ended June 30, 2024 and did not impact total loss from operations or total net loss for any period. Prior year amounts included in this Quarterly Report on Form 10-Q have been reclassified to conform to the current presentation.

[0001805385-25-000009:notes:17]
For both the three and six months ended June 30, 2024, the reclassifications resulted in an increase in restructuring costs of $0.9 million, and a corresponding decrease in cost of service revenue, sales and marketing expenses, and general and administrative expenses of $0.2 million, $0.7 million, and less than $0.1 million, respectively.


## us-gaap:ErrorCorrectionTextBlock

[0001805385-25-000009:notes:18]
Restatement of Previously Issued Condensed Consolidated Financial Statements
We have restated herein our condensed consolidated financial statements for the three and six months ended June 30, 2024. We have also restated impacted amounts within the accompanying notes to the condensed consolidated financial statements, as applicable. The restatement of our condensed consolidated financial statements for the three and six

[0001805385-25-000009:notes:19]
months ended June 30, 2024 was previously reported in our Annual Report on Form 10-K for the year ended December 31, 2024 (the “2024 Form 10-K”).

[0001805385-25-000009:notes:20]
Restatement Background

[0001805385-25-000009:notes:21]
In September 2024, an ad hoc committee of independent directors (the “Committee”) of the Company's Board of Directors (the “Board”), under the direction of the Board, commenced an investigation (the “Investigation”) of the Company’s sales practices, including whether certain sales of products and subscriptions to channel partners and end users were subject to extra-contractual terms and conditions that impacted revenue recognition and other metrics, and if so, when senior Company personnel became aware of these issues.

[0001805385-25-000009:notes:22]
As a result of the Investigation, the Committee determined that certain sales, including sales to one of its largest channel partners, were subject to extra-contractual terms and conditions, some of which were not shared with the Company’s accounting personnel, and that certain Company personnel engaged in misconduct in connection with those transactions. Furthermore, these extra-contractual terms and conditions were withheld from the Company’s Audit Committee of the Board (the “Audit Committee”) and the Company’s independent registered public accounting firm, PricewaterhouseCoopers LLP (“PwC”). The Committee also determined that certain accounting personnel were aware of indications of these extra-contractual terms and conditions during affected periods, and that related allegations were raised internally in July 2024 and known to senior finance and accounting personnel, but that those allegations were not escalated to the Audit Committee or communicated to PwC prior to the filing of the Company’s second quarter 2024 financial statements. As a result of the Investigation, the Board determined that new leadership was critical to moving the Company forward. In November 2024, the Company’s Chief Financial Officer resigned. Additionally, four other employees, including personnel from its sales, finance and accounting departments were terminated or resigned as a result of the Investigation.

[0001805385-25-000009:notes:23]
In connection with the Investigation, the Committee determined that the accounting for certain sales transactions was materially inaccurate and that, among other things, revenue was prematurely or incorrectly recognized (the “Impacted Transactions”) in connection with financial statements prepared for the fiscal years ended December 31, 2022 and December 31, 2023 contained in its Annual Report on Form 10-K for the year-ended December 31, 2023, and its condensed consolidated financial statements for the quarters and year-to-date periods ended June 30, 2022, September 30, 2022, March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024 and June 30, 2024 contained in its Quarterly Reports on Form 10-Q.

[0001805385-25-000009:notes:24]
A review of the transactions identified in the Investigation determined that restatement changes were necessary due to:

[0001805385-25-000009:notes:25]
•an overstatement or understatement of revenue and cost of revenue depending on the changes to revenue recognition start dates in each period of the consolidated statement of operations; and

[0001805385-25-000009:notes:26]
•an overstatement or understatement of other accounts affected by changes to revenue recognition start dates, including accounts receivable, inventory, contract assets, commission assets, property and equipment, net, deferred revenue, and sales and marketing expense.

[0001805385-25-000009:notes:27]
Misstatements related to the Impacted Transactions identified in the Investigation

[0001805385-25-000009:notes:28]
Revenue

[0001805385-25-000009:notes:29]
As discussed above, the Company became aware of the presence of extra-contractual terms and conditions through the Investigation. The extra-contractual terms and conditions created ambiguity with regard to whether the Company and its customers had reached a mutual understanding of the terms of the contracts. Ultimately, the Company decided to honor the customers’ understanding of the contracts, including the terms and conditions granted outside the written contracts.

[0001805385-25-000009:notes:30]
The extra-contractual terms and conditions affected the dates on which it was appropriate for the Company to recognize revenue, or commence revenue recognition for the Impacted Transactions. In order to correct the revenue recognition start dates for each of the Impacted Transactions to be restated, the Company reviewed the terms and circumstances of each transaction, including the contractual and extra-contractual terms and conditions.

[0001805385-25-000009:notes:31]
As described above, the Company offers products for purchase or multi-year subscription leases.  All products are sold with an underlying subscription for software and services. Contracts may include multiple performance obligations when customers purchase a combination of products and services.  For equipment sales, revenue is recognized at a point in time, whereas for leased equipment and software, revenue is recognized ratably over the term (“over time”).

[0001805385-25-000009:notes:32]
GAAP requires that revenue is recognized when (or as) the entity satisfies a performance obligation by transferring the underlying asset to a customer. An asset is transferred when (or as) the customer obtains control of that asset. Further, GAAP defines control as “…the ability to direct the use of, and obtain substantially all of the remaining benefits from, the asset.”

[0001805385-25-000009:notes:33]
Historically, the Company has recognized revenue, or commenced revenue recognition, upon shipment or delivery of the product to the customer, or to the end-user as directed by the customer, if the customer is a reseller. The findings of the Investigation and Financial Statement Review, as defined below, impact the timing of when revenue recognition should begin on certain arrangements. The Company determined that it should recognize or begin to recognize revenue on the Impacted Transactions at the point in time that the Company has an enforceable contract with the customer and control transfers to the customer, which, for the Impacted Transactions, was often the installation date, which is later than the shipment or delivery date. The extra-contractual terms created in substance consignment arrangements with customers, which resulted in no revenue recognition until control of the product was transferred to the customer (i.e., the installation date).

[0001805385-25-000009:notes:34]
For most of the Impacted Transactions, the Company determined that the customer was only committed to the agreement and began to receive and consume the benefits provided by the Company’s performance on the date the security screening system(s) and Software as a Service (“SaaS”) portal were both installed and activated at the end user site.  Therefore, revenue recognition for over time performance obligations was determined to begin at the installation date and recognized over the period in which the benefits are consumed (e.g., the subscription term). Product sales were also restated to be recorded at the installation date where appropriate. For point-in-time performance obligations, revenue was recognized at the installation date.

[0001805385-25-000009:notes:35]
Property, and Equipment / Inventory

[0001805385-25-000009:notes:36]
As stated above, the Company offers products for purchase or multi-year subscription leases. For equipment for which the revenue recognition start date was moved to a later date due to the timing of the transfer of control, the equipment cost was reclassified from Leased equipment to Equipment held for lease within Property and Equipment (for leased equipment), or added back to finished goods Inventory  (for equipment sales) until the point in time that the Company transferred control of the equipment to the customer, corresponding to the revenue recognition start date.

[0001805385-25-000009:notes:37]
Cost of Product Revenue / Cost of Subscription Revenue

[0001805385-25-000009:notes:38]
For leased equipment reclassified to equipment held for lease, as described above, the Company adjusted the dates placed in service to correspond to the revised date upon which revenue recognition commenced, thus achieving appropriate alignment of revenue recognition with the recognition of depreciation expense (cost of revenue), consistent with the company’s accounting policies. For equipment added back to inventory related to sales of equipment, the Company added back the associated cost of revenue in the period it was originally recognized, and restated the cost of revenue to correspond with the revenue recognition start date.

[0001805385-25-000009:notes:39]
Commissions Asset / Commissions Expense

[0001805385-25-000009:notes:40]
Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract, which

[0001805385-25-000009:notes:41]
generally begins upon transfer of control. For the Impacted Transactions on which the Company adjusted the revenue recognition start date, the amortization of the corresponding commission expense was adjusted to conform to the adjusted revenue recognition start date.

[0001805385-25-000009:notes:42]
Accounts Receivable, Contract Assets, Deferred Revenue

[0001805385-25-000009:notes:43]
Deferred Revenue, Contract Assets and Accounts Receivable relating to affected customer arrangements were adjusted to reflect the corresponding changes in revenue recognition start dates.

[0001805385-25-000009:notes:44]
Additional errors identified through the Financial Statement Review

[0001805385-25-000009:notes:45]
Following the Investigation, the Company completed a comprehensive review of its previously issued financial statements (the “Financial Statement Review”), which resulted in the identification of additional errors. These adjustments included:

[0001805385-25-000009:notes:46]
•an understatement of research and development expense and overstatement of property, plant and equipment in certain periods due to an error in the calculation of internal-use software costs in the first and second quarters of 2024;

[0001805385-25-000009:notes:47]
•an overstatement of cost of revenue and understatement of inventory and property and equipment, net in the first and second quarters of 2024 related to the expensing of inbound freight costs that should have been capitalized into inventory or property and equipment, net; and

[0001805385-25-000009:notes:48]
•an overstatement of accounts receivable and contract assets and corresponding understatement of deferred revenue in each period related to the incorrect classification of amounts due to the Company resulting from its contracts with customers.

[0001805385-25-000009:notes:49]
The impact of the correction of the misstatements and errors resulting from the Investigation and Financial Statement Review on the condensed consolidated financial statements in this Quarterly Report on Form 10-Q, as well as previously identified immaterial errors which have now been corrected, are summarized below. The applicable accompanying notes to the condensed consolidated financial statements have also been updated.

[0001805385-25-000009:notes:50]
The impact of the correction of the misstatements on the condensed consolidated statements of stockholders' equity were solely within net loss for errors impacting accumulated deficit. Errors impacting accumulated paid in capital were limited to periods prior to December 31, 2023 and therefore only impact the opening balance in the condensed consolidated statements of stockholders' equity for the periods ended March 31, 2024 and June 30, 2024.

[0001805385-25-000009:notes:51]
The impact of the correction of the misstatements and errors on the condensed consolidated statements of cash flows were driven by changes in the related condensed consolidated balance sheets and condensed consolidated statement of operations and comprehensive loss line items, except as noted by footnote under each applicable table below.

[0001805385-25-000009:notes:52]
Where adjustments in the below tables relate to multiple categories, the adjustment amounts of each category are noted below each table and sum to the total adjustment reflected. Restatement adjustments are reflected as follows:

[0001805385-25-000009:notes:53]
ADJ 1: related to revenue recognition misstatements identified as part of the Investigation.

[0001805385-25-000009:notes:54]
ADJ 2: related to errors in capitalized internal-use software costs.

[0001805385-25-000009:notes:55]
ADJ 3: related to errors in capitalized freight costs.

[0001805385-25-000009:notes:56]
ADJ 4: other immaterial errors previously identified in prior periods corrected as part of the restatement.

[0001805385-25-000009:notes:57]
For the Three and Six Months Ended June 30, 2024

[0001805385-25-000009:notes:58]
Restated Condensed Consolidated Statements of Operations and Comprehensive Income (Loss) Data

[0001805385-25-000009:notes:59]
(In thousands, except share and per share amounts)

[0001805385-25-000009:notes:60]
|  |  |  | Three Months Ended June 30, 2024 |  | Six Months Ended June 30, 2024 |
|  | Adj. Reference(a) |  | As Reported |  | Adjustment |  | As Restated |  | As Reported |  | Adjustment |  | As Restated |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | ADJ 1 |  | $ | 2,044 |  |  | $ | (90) |  |  | $ | 1,954 |  |  | $ | 2,647 |  |  | $ | 798 |  |  | $ | 3,445 |  |
| Subscription revenue | ADJ 1 |  | 15,903 |  |  | (248) |  |  | 15,655 |  |  | 30,406 |  |  | (532) |  |  | 29,874 |  |
| Service revenue | ADJ 1 |  | 5,553 |  |  | 13 |  |  | 5,566 |  |  | 10,937 |  |  | (119) |  |  | 10,818 |  |
| License fee and other revenue | ADJ 1 |  | 2,040 |  |  | 9 |  |  | 2,049 |  |  | 3,218 |  |  | 50 |  |  | 3,268 |  |
| Total revenue |  |  | 25,540 |  |  | (316) |  |  | 25,224 |  |  | 47,208 |  |  | 197 |  |  | 47,405 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | ADJ 1, ADJ 3, ADJ 4 |  | 3,149 |  |  | (310) |  |  | 2,839 |  |  | 5,926 |  |  | 27 |  |  | 5,953 |  |
| Cost of subscription revenue | ADJ 1, ADJ 2, ADJ 3, ADJ 4 |  | 6,436 |  |  | (127) |  |  | 6,309 |  |  | 12,215 |  |  | (321) |  |  | 11,894 |  |
| Cost of service revenue | ADJ 1, ADJ 2, ADJ 4 |  | 1,311 |  |  | 10 |  |  | 1,321 |  |  | 2,522 |  |  | (3) |  |  | 2,519 |  |
| Cost of license fee and other revenue |  |  | 172 |  |  | — |  |  | 172 |  |  | 301 |  |  | — |  |  | 301 |  |
| Total cost of revenue |  |  | 11,068 |  |  | (427) |  |  | 10,641 |  |  | 20,964 |  |  | (297) |  |  | 20,667 |  |
| Gross profit |  |  | 14,472 |  |  | 111 |  |  | 14,583 |  |  | 26,244 |  |  | 494 |  |  | 26,738 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | ADJ 2, ADJ 4 |  | 5,722 |  |  | 128 |  |  | 5,850 |  |  | 11,927 |  |  | 319 |  |  | 12,246 |  |
| Sales and marketing | ADJ 1, ADJ 4 |  | 16,892 |  |  | 119 |  |  | 17,011 |  |  | 32,897 |  |  | (27) |  |  | 32,870 |  |
| General and administrative | ADJ 4 |  | 14,185 |  |  | (92) |  |  | 14,093 |  |  | 26,025 |  |  | (126) |  |  | 25,899 |  |
| Total operating expenses |  |  | 36,799 |  |  | 155 |  |  | 36,954 |  |  | 70,849 |  |  | 166 |  |  | 71,015 |  |
| Loss from operations |  |  | (22,327) |  |  | (44) |  |  | (22,371) |  |  | (44,605) |  |  | 328 |  |  | (44,277) |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 681 |  |  | — |  |  | 681 |  |  | 1,766 |  |  | — |  |  | 1,766 |  |
| Other expense, net |  |  | (39) |  |  | — |  |  | (39) |  |  | (67) |  |  | — |  |  | (67) |  |
| Change in fair value of contingent earn-out liability |  |  | 16,514 |  |  | — |  |  | 16,514 |  |  | 23,413 |  |  | — |  |  | 23,413 |  |
| Change in fair value of contingently issuable common stock liability |  |  | 3,747 |  |  | — |  |  | 3,747 |  |  | 4,274 |  |  | — |  |  | 4,274 |  |
| Change in fair value of public warrant liability |  |  | 4,886 |  |  | — |  |  | 4,886 |  |  | 7,037 |  |  | — |  |  | 7,037 |  |
| Total other income (expense), net |  |  | 25,789 |  |  | — |  |  | 25,789 |  |  | 36,423 |  |  | — |  |  | 36,423 |  |
| Loss before income taxes |  |  | 3,462 |  |  | (44) |  |  | 3,418 |  |  | (8,182) |  |  | 328 |  |  | (7,854) |  |
| Net income (loss) |  |  | $ | 3,462 |  |  | $ | (44) |  |  | $ | 3,418 |  |  | $ | (8,182) |  |  | $ | 328 |  |  | $ | (7,854) |  |
| Net income (loss) attributable to common stockholders - basic and diluted |  |  | $ | 3,421 |  |  | $ | (44) |  |  | $ | 3,377 |  |  | $ | (8,182) |  |  | $ | 328 |  |  | $ | (7,854) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 156,473,080 |  |  | — |  |  | 156,473,080 |  |  | 154,774,899 |  |  | — |  |  | 154,774,899 |  |
| Diluted |  |  | 171,563,943 |  |  | — |  |  | 171,563,943 |  |  | 154,774,899 |  |  | — |  |  | 154,774,899 |  |
| Net income (loss) per share |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | $ | 0.02 |  |  | $ | — |  |  | $ | 0.02 |  |  | $ | (0.05) |  |  | $ | — |  |  | $ | (0.05) |  |
| Diluted |  |  | $ | 0.02 |  |  | $ | — |  |  | $ | 0.02 |  |  | $ | (0.05) |  |  | $ | — |  |  | $ | (0.05) |  |
| Net income (loss) |  |  | $ | 3,462 |  |  | $ | (44) |  |  | $ | 3,418 |  |  | $ | (8,182) |  |  | $ | 328 |  |  | $ | (7,854) |  |
| Other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cumulative translation adjustment |  |  | 8 |  |  | — |  |  | 8 |  |  | 11 |  |  | — |  |  | 11 |  |
| Total other comprehensive income (loss) |  |  | 8 |  |  | — |  |  | 8 |  |  | 11 |  |  | — |  |  | 11 |  |
| Total comprehensive income (loss) |  |  | $ | 3,470 |  |  | $ | (44) |  |  | $ | 3,426 |  |  | $ | (8,171) |  |  | $ | 328 |  |  | $ | (7,843) |  |

[0001805385-25-000009:notes:61]
(a) Category references are described in Note 2. Restatement of Financial Statements. Where adjustments relate to multiple categories, the adjustment amounts of each category are noted below and sum to the total adjustment reflected in the table above:

[0001805385-25-000009:notes:62]
Three months ended:

[0001805385-25-000009:notes:63]
Cost of product revenue: ADJ 1 = $12, ADJ 3 = ($270), ADJ 4 = ($52)

[0001805385-25-000009:notes:64]
Cost of subscription revenue: ADJ 1 = ($60), ADJ 2 = ($2), ADJ 3 = ($64), ADJ 4 = ($1)

[0001805385-25-000009:notes:65]
Cost of service revenue: ADJ 1 = $1, ADJ 2 = ($2), ADJ 4 = $11

[0001805385-25-000009:notes:66]
Research and development: ADJ 2 = $70, ADJ 4 =  $58

[0001805385-25-000009:notes:67]
Sales and marketing: ADJ 1 = ($16), ADJ 4 = $135

[0001805385-25-000009:notes:68]
Six months ended:

[0001805385-25-000009:notes:69]
Cost of product revenue: ADJ 1 = $397, ADJ 3 = ($314), ADJ 4 = ($56)

[0001805385-25-000009:notes:70]
Cost of subscription revenue: ADJ 1 = ($116), ADJ 2 = ($3), ADJ 3 = ($235), ADJ 4 = $33

[0001805385-25-000009:notes:71]
Cost of service revenue: ADJ 2 = ($2), ADJ 4 = ($1)

[0001805385-25-000009:notes:72]
Research and development: ADJ 2 = $319

[0001805385-25-000009:notes:73]
Sales and marketing: ADJ 1 = ($27)

[0001805385-25-000009:notes:74]
Restated Condensed Consolidated Statement of Cash Flows

[0001805385-25-000009:notes:75]
(In thousands)

[0001805385-25-000009:notes:76]
|  |  |  | Six Months Ended June 30, 2024 |
|  |  |  | As Reported |  | Adjustment |  | As Restated |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss |  |  | $ | (8,182) |  |  | $ | 328 |  |  | $ | (7,854) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 7,442 |  |  | (84) |  |  | 7,358 |  |
| Write-off of inventory and change in inventory reserve |  |  | 1,725 |  |  | — |  |  | 1,725 |  |
| Stock-based compensation |  |  | 13,834 |  |  | 23 |  |  | 13,857 |  |
| Amortization (accretion) of premium (discount) on marketable securities, net of change in accrued interest |  |  | 181 |  |  | — |  |  | 181 |  |
| Non-cash lease expense |  |  | 728 |  |  | — |  |  | 728 |  |
| Change in allowance for expected credit losses |  |  | 203 |  |  | — |  |  | 203 |  |
| Change in fair value of earn-out liability |  |  | (23,413) |  |  | — |  |  | (23,413) |  |
| Change in fair value of contingently issuable common stock |  |  | (4,274) |  |  | — |  |  | (4,274) |  |
| Change in fair value of public warrant liability |  |  | (7,037) |  |  | — |  |  | (7,037) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (14,020) |  |  | (47) |  |  | (14,067) |  |
| Inventory |  |  | (10,354) |  |  | 312 |  |  | (10,042) |  |
| Commission assets |  |  | (492) |  |  | (29) |  |  | (521) |  |
| Contract assets |  |  | 2,324 |  |  | (2,087) |  |  | 237 |  |
| Other assets |  |  | 337 |  |  | — |  |  | 337 |  |
| Prepaid expenses and other current assets |  |  | (2,958) |  |  | 1 |  |  | (2,957) |  |
| Accounts payable |  |  | (1,653) |  |  | — |  |  | (1,653) |  |
| Deferred revenue |  |  | 8,333 |  |  | 1,938 |  |  | 10,271 |  |
| Accrued expenses and other current liabilities |  |  | 79 |  |  | (125) |  |  | (46) |  |
| Operating lease liability |  |  | (765) |  |  | — |  |  | (765) |  |
| Net cash used in operating activities |  |  | (37,962) |  |  | 230 |  |  | (37,732) |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Development of internal-use software(1) |  |  | (3,408) |  |  | 296 |  |  | (3,112) |  |
| Purchases of property and equipment(2) |  |  | (21,092) |  |  | (526) |  |  | (21,618) |  |
| Purchases of marketable securities |  |  | (14,567) |  |  | — |  |  | (14,567) |  |
| Proceeds from maturities of marketable securities |  |  | 44,918 |  |  | — |  |  | 44,918 |  |

[0001805385-25-000009:notes:77]
| Net cash provided by investing activities |  |  | 5,851 |  |  | (230) |  |  | 5,621 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from exercise of stock options |  |  | 636 |  |  | — |  |  | 636 |  |
| Net cash provided by financing activities |  |  | 636 |  |  | — |  |  | 636 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 11 |  |  | — |  |  | 11 |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (31,464) |  |  | — |  |  | (31,464) |  |
| Cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 67,437 |  |  | — |  |  | 67,437 |  |
| Cash, cash equivalents and restricted cash at end of period |  |  | $ | 35,973 |  |  | $ | — |  |  | $ | 35,973 |  |
| Supplemental disclosure of non-cash activities |  |  |  |  |  |  |  |
| Transfer of property and equipment to inventory |  |  | $ | 468 |  |  | $ | — |  |  | $ | 468 |  |
| Capital expenditures incurred but not yet paid |  |  | 3,407 |  |  | — |  |  | 3,407 |  |
| Capitalization of stock compensation |  |  | 450 |  |  | (23) |  |  | 427 |  |
| Operating lease liabilities arising from obtaining right-of-use assets |  |  | 1,694 |  |  | — |  |  | 1,694 |  |
| Reconciliation of cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 35,698 |  |  | $ | — |  |  | $ | 35,698 |  |
| Restricted cash, noncurrent |  |  | 275 |  |  | — |  |  | 275 |  |
| Total cash, cash equivalents and restricted cash shown in the statements of cash flows |  |  | $ | 35,973 |  |  | $ | — |  |  | $ | 35,973 |  |

[0001805385-25-000009:notes:78]
(1) Relates to adjustments related to ADJ 2.

[0001805385-25-000009:notes:79]
(2) Relates to the following adjustments: ADJ 3 = ($464), ADJ 4 = ($62)


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001805385-25-000009:notes:80]
[same as prior period, unchanged from 0001628280-25-026845:notes:70]

[0001805385-25-000009:notes:81]
The significant accounting policies and estimates used in preparation of the unaudited condensed consolidated financial statements are described in the Company’s audited consolidated financial statements as of and for the year ended December 31, 2024, and the notes thereto, which are included in our 2024 Form 10-K. Except for the partner rebate program and the estimates used to determine the grant date valuation for certain market-based stock units (“MSUs”), as described below, there have been no material changes to the Company’s significant accounting policies during the six months ended June 30, 2025.

[0001805385-25-000009:notes:82]
Partner Rebate Program

[0001805385-25-000009:notes:83]
For the fiscal year 2025, the Company implemented a channel partner rebate program (the “Rebate Program”) for eligible resellers. Under the Rebate Program, eligible resellers that attain at least 25% of their current fiscal year total contract value (“TCV”) target (“Annual Target”) in a given quarter are eligible for a rebate based upon a percentage of their TCV for that quarter. In addition, resellers that meet their Annual Target are eligible for a one-time rebate based upon a percentage of their total fiscal year TCV, applied as a credit in the subsequent fiscal year. All rebates are issued as credits against future purchases, and no cash rebates are paid. Unused rebate credits are forfeited in the event of a reseller agreement termination.

[0001805385-25-000009:notes:84]
The Company recognizes an accrued liability related to the Rebate Program in accrued expenses and other current liabilities in our condensed consolidated balance sheets and recognizes the rebates as reduction of revenue.

[0001805385-25-000009:notes:85]
[same as prior period, unchanged from 0001628280-25-026845:notes:72]

[0001805385-25-000009:notes:86]
The estimated grant date fair value of MSUs granted by the Company is determined using a Monte Carlo simulation that simulates the future path of the Company’s stock price throughout the performance period. The

[0001805385-25-000009:notes:87]
assumptions utilized in the calculation are based on the achievement of certain stock price milestones including expected stock price volatility, risk-free rate of return, and remaining term.

[0001805385-25-000009:notes:88]
Recently Issued Accounting Pronouncements

[0001805385-25-000009:notes:89]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures.” ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. The amendments in ASU 2023-09 address investor requests for enhanced income tax information primarily through changes to the rate reconciliation and income taxes paid information. Early adoption is permitted. A public entity may apply the amendments in ASU 2023-09 either prospectively to all annual periods beginning after December 15, 2024, or retrospectively to prior periods. The Company determined that ASU 2023-09 is applicable and will be adopted in our Annual Report on Form 10-K for the year ended December 31, 2025. It addresses disclosures only, the Company expects it will not have any material effects on its financial condition, results of operations, or cash flows.

[0001805385-25-000009:notes:90]
In November 2024, the FASB issued ASU 2024-03, “Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses.”, which includes amendments to require the disclosure of certain specific costs and expenses that are included in a relevant expense caption on the face of the income statement. Specific costs and expenses that would be required to be disclosed include: purchases of inventory, employee compensation, depreciation, and intangible asset amortization. Additionally, a qualitative description of other items is required, equal to the difference between the relevant expense caption and the separately disclosed specific costs. Early adoption is permitted. A public entity should apply the amendments in ASU 2024-03 prospectively to all annual periods beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.

[0001805385-25-000009:notes:91]
In July 2025, the FASB issued ASU 2025-05, “Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets.” The amendment in ASU 2025-05 provides entities with a practical expedient to simplify the estimation of expected credit losses by assuming that the current conditions as of the balance sheet date will not change for the remaining life of the asset. Early adoption is permitted, and this amendment is applied prospectively. ASU 2025-05 is effective for all annual periods beginning after December 15, 2025 and interim periods within those annual periods. The Company is currently evaluating the impact of this standard on the disclosures within the consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001805385-25-000009:notes:92]
Marketable Securities
All marketable securities fully matured as of June 30, 2025. Marketable securities as of December 31, 2024 consisted of the following:

[0001805385-25-000009:notes:93]
|  | December 31, 2024 |
|  | Amortized Cost |  | Unrealized Gain/(Loss) |  | Fair Value |
| U.S. Treasury bills | $ | 14,927 |  |  | $ | — |  |  | $ | 14,927 |  |
| Total marketable securities | $ | 14,927 |  |  | $ | — |  |  | $ | 14,927 |  |

[0001805385-25-000009:notes:94]
Marketable securities at December 31, 2024 are comprised solely of zero coupon U.S. treasury bills with maturities of greater than three months but less than one year that are classified as available-for-sale debt securities. Unrealized gains or losses were not material for each of the three and six months ended June 30, 2025 and 2024. The accretion of discounts on marketable securities is included in interest income on the condensed consolidated statements of operations and comprehensive loss.


## us-gaap:FairValueDisclosuresTextBlock

[0001805385-25-000009:notes:95]
[same as prior period, unchanged from 0001628280-25-026845:notes:81]

[0001805385-25-000009:notes:96]
|  | Fair Value Measurements at June 30, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 15,422 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,422 |  |
| Treasury bills | — |  |  | 2,999 |  |  | — |  |  | 2,999 |  |
|  | $ | 15,422 |  |  | $ | 2,999 |  |  | $ | — |  |  | $ | 18,421 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Contingent earn-out liability | $ | — |  |  | $ | — |  |  | $ | 18,033 |  |  | $ | 18,033 |  |
| Contingently issuable common stock liability | — |  |  | — |  |  | 6,248 |  |  | 6,248 |  |
| Public Warrant liability | 7,879 |  |  | — |  |  | — |  |  | 7,879 |  |
|  | $ | 7,879 |  |  | $ | — |  |  | $ | 24,281 |  |  | $ | 32,160 |  |

[0001805385-25-000009:notes:97]
[same as prior period, unchanged from 0001628280-25-026845:notes:83]

[0001805385-25-000009:notes:98]
Money market funds are included in cash and cash equivalents on the condensed consolidated balance sheets. As of June 30, 2025, U.S. treasury bills with maturities less than 3 months, which totaled $3.0 million, are included in cash and cash equivalents. As of December 31, 2024, U.S. treasury bills with maturities less than 3 months, which totaled $12.5 million, are included in cash and cash equivalents, while treasury bills with maturities greater than 3 months, which totaled $14.9 million, are reflected as marketable securities. The fair value of the treasury bills, which are classified as Level 2 securities, is calculated by a third-party pricing service and is based on estimates obtained from various sources.

[0001805385-25-000009:notes:99]
[same as prior period, unchanged from 0001628280-25-026845:notes:85]

[0001805385-25-000009:notes:100]
[same as prior period, unchanged from 0001628280-25-026845:notes:86]

[0001805385-25-000009:notes:101]
During each of the six months ended June 30, 2025 and 2024, there were no transfers between Level 1, Level 2 and Level 3.

[0001805385-25-000009:notes:102]
[same as prior period, unchanged from 0001628280-25-026845:notes:88]

[0001805385-25-000009:notes:103]
Pursuant to the Merger Agreement, the Legacy Evolv stockholders, immediately prior to the Merger, were entitled to receive additional shares of the Company’s common stock upon the Company achieving certain milestones as described in Note 3 of our consolidated financial statements of our 2024 Form 10-K. The Company’s contingent earn-out shares were recorded at fair value as contingent earn-out liability upon the closing of the Merger and are remeasured each reporting period. As of June 30, 2025, no milestones have been achieved.

[0001805385-25-000009:notes:104]
The fair value of the contingent earn-out is calculated using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the earn-out period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of June 30, 2025 were as follows: 85% expected stock price volatility, a risk-free rate of return of 4.2%, a 15% likelihood of change in control and a remaining term of 0.7 years. The assumed likelihood of change in control was reduced to 15% as of June 30, 2025 from 25% as of March 31, 2025, reflecting the shortened remaining term of less than one year.

[0001805385-25-000009:notes:105]
[same as prior period, unchanged from 0001628280-25-026845:notes:91]

[0001805385-25-000009:notes:106]
| Balance at December 31, 2024 | $ | 12,809 |  |
| Change in fair value | 5,224 |  |
| Balance at June 30, 2025 | $ | 18,033 |  |

[0001805385-25-000009:notes:107]
The increase in fair value of the contingent earn-out liability is primarily due to the increase in the Company's current stock price.

[0001805385-25-000009:notes:108]
[same as prior period, unchanged from 0001628280-25-026845:notes:94]

[0001805385-25-000009:notes:109]
Prior to the Merger, certain NHIC stockholders owned 4,312,500 shares of NHIC Class B common stock which were converted into shares of the Company's stock in connection with the Merger (the “Founder Shares”). Of these shares, 1,897,500 shares vested at the closing of the Merger, 517,500 shares were transferred back to NHIC and then contributed to Give Evolv LLC, and the remaining 1,897,500 outstanding shares will vest upon the Company achieving certain milestones as described in Note 3 of our consolidated financial statements of our 2024 Form 10-K. The Company’s contingently issuable common shares were recorded at fair value on the closing of the Merger and are remeasured each reporting period. As of June 30, 2025, no milestones have been achieved.

[0001805385-25-000009:notes:110]
The fair value of the contingently issued common shares is determined using a Monte Carlo analysis in order to simulate the future path of the Company’s stock price over the vesting period. The carrying amount of the liability may fluctuate significantly and actual amounts paid may be materially different from the liability’s estimated value. The significant assumptions used in the Monte Carlo model as of June 30, 2025 were as follows: 82.5% expected stock price volatility, a risk-free rate of return of 3.9%, a 25% likelihood of change in control and a remaining term of 1.0 years.

[0001805385-25-000009:notes:111]
[same as prior period, unchanged from 0001628280-25-026845:notes:97]

[0001805385-25-000009:notes:112]
| Balance at December 31, 2024 | $ | 4,001 |  |
| Change in fair value | 2,247 |  |
| Balance at June 30, 2025 | $ | 6,248 |  |

[0001805385-25-000009:notes:113]
[same as prior period, unchanged from 0001628280-25-026845:notes:99]

[0001805385-25-000009:notes:114]
In connection with the closing of the Merger, the Company assumed warrants to purchase 14,325,000 shares of common stock (the “Public Warrants”) at an exercise price of $11.50. The Public Warrants are immediately exercisable and expire in July 2026. The Public Warrants are classified as a liability and are subsequently remeasured to fair value at

[0001805385-25-000009:notes:115]
each reporting date based on the closing price as reported by Nasdaq on the last date of the reporting period. As of June 30, 2025, 14,324,893 Public Warrants are outstanding.

[0001805385-25-000009:notes:116]
[same as prior period, unchanged from 0001628280-25-026845:notes:101]

[0001805385-25-000009:notes:117]
| Balance at December 31, 2024 | $ | 4,297 |  |
| Change in fair value | 3,582 |  |
| Balance at June 30, 2025 | $ | 7,879 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001805385-25-000009:notes:118]
[same as prior period, unchanged from 0001628280-25-026845:notes:103]

[0001805385-25-000009:notes:119]
The Company derives revenue from (1) subscription arrangements generally accounted for as operating leases, including SaaS and maintenance, (2) the sale of products, (3) SaaS and maintenance related to products sold to customers either by the Company or by Columbia Tech pursuant to the Distribution and License Agreement (as defined below), (4) license fees related to the Distribution and License Agreement (as defined below), and (5) professional services, including installation, training, and event support. Maintenance consists of preventative maintenance, technical support, bug fixes, and when-and-if available threat updates. Our arrangements are generally noncancelable and nonrefundable after control passes to the customer. Revenue is recognized net of sales tax.

[0001805385-25-000009:notes:120]
[same as prior period, unchanged from 0001628280-25-026845:notes:106]

[0001805385-25-000009:notes:121]
[same as prior period, unchanged from 0001628280-25-026845:notes:107]

[0001805385-25-000009:notes:122]
[same as prior period, unchanged from 0001628280-25-026845:notes:108]

[0001805385-25-000009:notes:123]
[same as prior period, unchanged from 0001628280-25-026845:notes:109]

[0001805385-25-000009:notes:124]
The following table includes estimated revenues expected to be recognized in the future related to performance obligations that are unsatisfied (or partially satisfied) as of June 30, 2025:

[0001805385-25-000009:notes:125]
|  | Less than 1 year |  | 1 - 2 years |  | More than 2 years |  | Total |
| Product revenue | $ | 5,193 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,193 |  |
| Subscription revenue | 81,278 |  |  | 65,764 |  |  | 55,269 |  |  | 202,311 |  |
| Service revenue | 29,277 |  |  | 20,787 |  |  | 17,148 |  |  | 67,212 |  |
| License fee and other revenue | 440 |  |  | 99 |  |  | 196 |  |  | 735 |  |
| Total revenue | $ | 116,188 |  |  | $ | 86,650 |  |  | $ | 72,613 |  |  | $ | 275,451 |  |

[0001805385-25-000009:notes:126]
[same as prior period, unchanged from 0001628280-25-026845:notes:112]

[0001805385-25-000009:notes:127]
Contract assets arise from unbilled amounts in customer arrangements when revenue recognized exceeds the amount billed to the customer and the Company’s right to payment is conditional and not only subject to the passage of time.  As of June 30, 2025 and December 31, 2024, the Company had $0.8 million and $0.8 million in current portion of contract assets and $0.8 million and $0.7 million in contract assets, noncurrent on the condensed consolidated balance sheets, respectively.

[0001805385-25-000009:notes:128]
Contract liabilities represent the Company’s obligation to transfer goods or services to a customer for which it has received consideration (or the amount is due) from the customer. The Company has a contract liability related to service revenue, which consists of amounts that have been invoiced but that have not been recognized as revenue. Amounts expected to be recognized as revenue within 12 months of the balance sheet date are classified as current deferred revenue and amounts expected to be recognized as revenue beyond 12 months of the balance sheet date are classified as deferred revenue, noncurrent. The Company recognized revenue of $19.4 million and $44.1 million during the three and six months ended June 30, 2025, respectively, that was included in the December 31, 2024 deferred revenue balance. The Company recognized revenue of $13.8 million (as restated) and $30.7 million (as restated) during the three and six months ended June 30, 2024, respectively, that was included in the December 31, 2023 deferred revenue balance.

[0001805385-25-000009:notes:129]
[same as prior period, unchanged from 0001628280-25-026845:notes:116]

[0001805385-25-000009:notes:130]
| Balance at December 31, 2024 | $ | 84,772 |  |
| Revenue recognized in relation to the beginning of the year contract liability balance | (44,110) |  |
| Revenue deferred | 50,710 |  |
| Balance at June 30, 2025 | $ | 91,372 |  |

[0001805385-25-000009:notes:131]
[same as prior period, unchanged from 0001628280-25-026845:notes:118]

[0001805385-25-000009:notes:132]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Interest income on lease receivables | $ | 27 |  |  | $ | 41 |  |  | $ | 56 |  |  | $ | 83 |  |
| Lease income - operating leases | 20,200 |  |  | 15,655 |  |  | 39,437 |  |  | 29,874 |  |
| Total lease revenue | $ | 20,227 |  |  | $ | 15,696 |  |  | $ | 39,493 |  |  | $ | 29,957 |  |

[0001805385-25-000009:notes:133]
The interest income on lease receivables is classified under interest income in the condensed consolidated statements of operations and comprehensive loss. Lease income from operating leases is related to the leased equipment

[0001805385-25-000009:notes:134]
under subscription arrangements and is classified as subscription revenue in the condensed consolidated statements of operations and comprehensive loss. Revenue related to leases entered into with related parties was $0.3 million and $0.6 million during the three and six months ended June 30, 2024, respectively. There was no revenue related to leases entered into with related parties during the three and six months ended June 30, 2025.

[0001805385-25-000009:notes:135]
[same as prior period, unchanged from 0001628280-25-026845:notes:121]

[0001805385-25-000009:notes:136]
[same as prior period, unchanged from 0001628280-25-026845:notes:122]

[0001805385-25-000009:notes:137]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Product revenue | $ | 2,528 |  |  | $ | 1,954 |  |  | $ | 4,850 |  |  | $ | 3,445 |  |
| Subscription revenue | 20,200 |  |  | 15,655 |  |  | 39,437 |  |  | 29,874 |  |
| Service revenue | 6,686 |  |  | 5,566 |  |  | 13,416 |  |  | 10,818 |  |
| License fees | 2,291 |  |  | 1,717 |  |  | 5,494 |  |  | 2,441 |  |
| Professional services and other revenue | 839 |  |  | 332 |  |  | 1,354 |  |  | 827 |  |
| Total revenue | $ | 32,544 |  |  | $ | 25,224 |  |  | $ | 64,551 |  |  | $ | 47,405 |  |

[0001805385-25-000009:notes:138]
As discussed in Note 3, Summary of Significant Accounting Policies, the Company implemented a new Rebate Program for eligible resellers. As of June 30, 2025, the Company has accrued $0.4 million related to the Rebate Program, which is included in accrued expenses and other current liabilities in our condensed consolidated balance sheets. As a substantial amount of the Company's revenue with eligible resellers is recognized over-time, the Company recognized less than $0.1 million and $0.2 million of current portion of contract asset and contract asset, noncurrent in our condensed consolidated balance sheets, respectively, as of June 30, 2025 and recognized $0.1 million and $0.2 million as reduction of revenue for the three and six months ended June 30, 2025, respectively.

[0001805385-25-000009:notes:139]
[same as prior period, unchanged from 0001628280-25-026845:notes:124]

[0001805385-25-000009:notes:140]
The Company incurs and pays commissions on sales of its products and services. The Company applies the practical expedient for contracts less than one year in duration to expense the commission costs in the period in which they were incurred. Commissions on product sales and services are expensed in the period in which the related revenue is recognized. Commissions on subscription arrangements and maintenance are expensed ratably over the life of the contract. The Company had a deferred asset related to commissions of $12.9 million and $13.0 million as of June 30, 2025 and December 31, 2024, respectively. During the three months ended June 30, 2025 and 2024, the Company recognized commission expense of $1.8 million and $1.6 million (as restated), respectively. During the six months ended June 30, 2025 and 2024, the Company recognized commission expense of $3.3 million and $2.9 million (as restated), respectively.

[0001805385-25-000009:notes:141]
[same as prior period, unchanged from 0001628280-25-026845:notes:126]

[0001805385-25-000009:notes:142]
As of June 30, 2025, future minimum noncancelable payments related to leases of the Company's equipment are as follows (in thousands):

[0001805385-25-000009:notes:143]
| Year Ending December 31: |  |
| 2025 (six months remaining) | $ | 41,984 |  |
| 2026 | 74,372 |  |
| 2027 | 53,103 |  |
| 2028 | 26,720 |  |
| 2029 | 5,872 |  |
| Thereafter | 260 |  |
|  | $ | 202,311 |  |


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001805385-25-000009:notes:144]
[same as prior period, unchanged from 0001628280-25-026845:notes:129]

[0001805385-25-000009:notes:145]
[same as prior period, unchanged from 0001628280-25-026845:notes:130]

[0001805385-25-000009:notes:146]
|  | Allowance for Expected Credit Losses |
| Balance at December 31, 2024 | $ | (734) |  |
| Provisions | (166) |  |
| Write-offs, net of recoveries | — |  |
| Balance at June 30, 2025 | $ | (900) |  |


## us-gaap:InventoryDisclosureTextBlock

[0001805385-25-000009:notes:147]
[same as prior period, unchanged from 0001628280-25-026845:notes:132]

[0001805385-25-000009:notes:148]
|  | June 30,2025 |  | December 31,2024 |
| Raw materials | $ | 7,170 |  |  | $ | 4,362 |  |
| Finished goods |  |  |  |
| Finished goods inventory | 4,798 |  |  | 12,153 |  |
| Uninstalled inventory | 174 |  |  | 448 |  |
| Total | $ | 12,142 |  |  | $ | 16,963 |  |

[0001805385-25-000009:notes:149]
As discussed in Note 2, Restatement of Previously Issued Condensed Consolidated Financial Statements, the Company offers products for purchase or multi-year subscription leases. For equipment for which the revenue recognition start date was moved to a later date due to the timing of the transfer of control, the equipment cost was added back to finished goods inventory (for equipment sales) until the point in time that the Company transferred control of the equipment to the customer, corresponding to the revenue recognition start date. Amounts added back to finished goods inventory are included in Uninstalled inventory in the table above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001805385-25-000009:notes:150]
[same as prior period, unchanged from 0001628280-25-026845:notes:135]

[0001805385-25-000009:notes:151]
|  | June 30,2025 |  | December 31,2024 |
| Computers and telecom equipment | $ | 2,094 |  |  | $ | 2,064 |  |
| Lab equipment | 5,531 |  |  | 5,564 |  |
| Furniture and fixtures | 111 |  |  | 111 |  |
| Leasehold improvements | 607 |  |  | 607 |  |
| Leased equipment | 125,781 |  |  | 112,078 |  |
| Capitalized software | 17,885 |  |  | 14,555 |  |
| Sales demo equipment | 2,989 |  |  | 3,649 |  |
| Vehicles | 604 |  |  | 604 |  |
| Equipment held for lease1 | 11,252 |  |  | 17,347 |  |
| Construction in progress | 668 |  |  | 477 |  |
|  | 167,522 |  |  | 157,056 |  |
| Less: Accumulated depreciation and amortization | (42,044) |  |  | (33,395) |  |
|  | $ | 125,478 |  |  | $ | 123,661 |  |

[0001805385-25-000009:notes:152]
[same as prior period, unchanged from 0001628280-25-026845:notes:137]

[0001805385-25-000009:notes:153]
As of June 30, 2025 and December 31, 2024, the net book value of capitalized software was $12.7 million and $11.1 million, respectively. These amounts include $2.1 million and $1.7 million of capitalized stock compensation costs, respectively. Depreciation and amortization expense related to property and equipment was $5.8 million and $3.9 million (as restated) for the three months ended June 30, 2025 and 2024, respectively, which included amortization expense of capitalized software of $0.9 million and $0.3 million for the three months ended June 30, 2025 and 2024, respectively. Depreciation and amortization expense related to property and equipment was $11.3 million and $7.4 million for the six months ended June 30, 2025 and 2024, respectively, which included amortization expense of capitalized software of $1.8 million and $0.6 million for the six months ended June 30, 2025 and 2024, respectively.

[0001805385-25-000009:notes:154]
[same as prior period, unchanged from 0001628280-25-026845:notes:139]

[0001805385-25-000009:notes:155]
|  | June 30,2025 |  | December 31,2024 |
| Leased equipment | $ | 125,781 |  |  | $ | 112,078 |  |
| Accumulated depreciation | (31,862) |  |  | (25,726) |  |
| Leased equipment, net | $ | 93,919 |  |  | $ | 86,352 |  |

[0001805385-25-000009:notes:156]
Depreciation expense related to leased equipment was $4.3 million and $3.2 million during the three months ended June 30, 2025 and 2024, respectively. Depreciation expense related to leased equipment was $8.4 million and $6.0 million (as restated) during the six months ended June 30, 2025 and 2024, respectively. Depreciable lives are generally 7 years, consistent with the Company’s planned and historical usage of the equipment subject to operating leases.

[0001805385-25-000009:notes:157]
The Company recorded losses of $1.3 million and $1.6 million from disposals of property and equipment during the three and six months ended June 30, 2025, respectively, primarily related to the disposal of previously leased Evolv Express systems, which were recorded in cost of subscription revenue. The Company did not record any loss from disposal of property and equipment during the three and six months ended June 30, 2024.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001805385-25-000009:notes:158]
[same as prior period, unchanged from 0001628280-25-026845:notes:143]

[0001805385-25-000009:notes:159]
The following table presents, on a weighted average basis, the assumptions used in the Black-Scholes option-pricing model to determine the grant-date fair value of stock options granted during the six months ended June 30, 2024. No option grants were issued during the six months ended  June 30, 2025.

[0001805385-25-000009:notes:160]
|  |  |  | Six Months Ended June 30, |
|  |  |  | 2024 |
| Risk-free interest rate |  |  | 4.1% |
| Expected term (in years) |  |  | 6.1 |
| Expected volatility |  |  | 90.0% |
| Expected dividend yield |  |  | 0.0% |

[0001805385-25-000009:notes:161]
[same as prior period, unchanged from 0001628280-25-026845:notes:146]

[0001805385-25-000009:notes:162]
|  | Number ofShares |  | WeightedAverageExercise Price |
| Outstanding as of December 31, 2024 | 18,125,937 |  | $ | 1.18 |  |
| Granted | — |  |  | — |  |
| Exercised | (5,948,881) |  | 1.10 |  |
| Forfeited | (525,981) |  |  | 3.61 |  |
| Expired | (20,306) |  |  | 3.63 |  |
| Outstanding as of June 30, 2025 | 11,630,769 |  | $ | 1.11 |  |

[0001805385-25-000009:notes:163]
[same as prior period, unchanged from 0001628280-25-026845:notes:148]

[0001805385-25-000009:notes:164]
[same as prior period, unchanged from 0001628280-25-026845:notes:149]

[0001805385-25-000009:notes:165]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2024 | 12,115,657 |  |  | $ | 3.50 |  |
| Granted | 7,120,531 |  |  | 3.53 |  |
| Vested | (5,113,914) |  |  | 3.31 |  |
| Forfeited | (3,539,790) |  |  | 3.73 |  |
| Nonvested as of June 30, 2025 | 10,582,484 |  |  | $ | 3.54 |  |

[0001805385-25-000009:notes:166]
During the six months ended June 30, 2025, the Company granted market-based stock units ("MSUs") for which the vesting conditions consist of market-based vesting conditions, determined by the Company's level of achievement of pre-established parameters relating to the performance of the Company's stock price as set by the Board as well as service-based vesting conditions. Vesting may range from 0% to 200% of the target MSUs granted, based on the achievement of specified market conditions. The awards will be measured at each anniversary of the grant date and will vest following the completion of a performance period, which is generally three years unless shortened in the event of a change in control.

[0001805385-25-000009:notes:167]
Compensation expense for MSUs is based on the estimated value of the awards on the grant date, and is recognized over the period from the grant date through the expected vest date, regardless of level of achievement of the market conditions. The fair value of the awards were estimated based on a Monte Carlo simulation model applying the following key assumptions, on a weighted average basis:

[0001805385-25-000009:notes:168]
|  | Six Months Ended June 30, |
|  | 2025 |  |  |
| Risk-free interest rate | 3.9% |  |  |
| Expected term (in years) | 3.0 |  |  |
| Expected volatility | 90.5% |  |  |
| Expected dividend yield | 0.0% |  |  |

[0001805385-25-000009:notes:169]
[same as prior period, unchanged from 0001628280-25-026845:notes:155]

[0001805385-25-000009:notes:170]
|  | Number ofShares |  | Grant Date FairValue |
| Nonvested as of December 31, 2024 | — |  |  | $ | — |  |
| Granted | 1,755,370 |  |  | 5.14 |  |
| Vested | — |  |  | — |  |
| Forfeited | (85,227) |  |  | 4.40 |  |
| Nonvested as of June 30, 2025 | 1,670,143 |  |  | $ | 5.17 |  |

[0001805385-25-000009:notes:171]
[same as prior period, unchanged from 0001628280-25-026845:notes:157]

[0001805385-25-000009:notes:172]
[same as prior period, unchanged from 0001628280-25-026845:notes:158]

[0001805385-25-000009:notes:173]
As of June 30, 2025, 117,423 Finback Common Stock Warrants were exercisable at a total aggregate intrinsic value of $0.7 million, and there were no Finback Common Stock Warrants that were unvested, given the expiration of the 1-year tail period on January 1, 2024. The Company recognized compensation expense for the Finback Common Stock Warrants when the warrants vested based on meeting the specified sales criteria. During the three and six months ended

[0001805385-25-000009:notes:174]
June 30, 2025 and 2024, there was no stock-based compensation expense within sales and marketing expense related to the Finback Common Stock Warrants.

[0001805385-25-000009:notes:175]
[same as prior period, unchanged from 0001628280-25-026845:notes:161]

[0001805385-25-000009:notes:176]
[same as prior period, unchanged from 0001628280-25-026845:notes:162]

[0001805385-25-000009:notes:177]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Cost of revenue | $ | 282 |  | $ | 173 |  | $ | 501 |  | $ | 311 |
| Research and development | 1,154 |  | 1,222 |  | 2,269 |  | 2,124 |
| Sales and marketing | 1,710 |  | 2,724 |  | 2,758 |  | 5,683 |
| General and administrative | 2,401 |  | 3,308 |  | 4,373 |  | 5,739 |
| Restructuring costs | $ | — |  | $ | — |  | $ | 525 |  | $ | — |
| Total stock-based compensation expense | $ | 5,547 |  | $ | 7,427 |  | $ | 10,426 |  | $ | 13,857 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001805385-25-000009:notes:178]
Income Taxes
The Company regularly evaluates the realizability of its deferred tax assets by considering all available positive and negative evidence, including consideration of future taxable income. Primarily due to the Company’s history of incurred net losses, the Company maintains a full valuation allowance against its deferred tax assets, as it is not more likely than not that these assets will be realized. Thus, the Company has not recognized material provisions or benefits for income taxes.

[0001805385-25-000009:notes:179]
The Company’s tax provision and resulting effective tax rate for interim periods are determined using the estimated annual effective tax rate (“AETR”), which is updated each quarter and adjusted for discrete items recognized in the period. For the three and six months ended June 30, 2025, the AETR reflects expected taxable income of Evolv UK, consistent with its intercompany transfer pricing policy. The forecast is consistent with year-to-date actual results through June 30, 2025, and excludes any mark-to-market adjustments. While the overall tax provision remains immaterial due to the Company's full valuation allowance, a portion of the prior-year net operating losses of Evolv UK expected to be utilized is subject to uncertainty. As a result, a corresponding unrecognized tax benefit has been included within the AETR.

[0001805385-25-000009:notes:180]
[same as prior period, unchanged from 0001628280-25-026845:notes:166]

[0001805385-25-000009:notes:181]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was signed into law in the United States. The OBBBA introduces various corporate and international tax law changes with staggered effective dates through 2027. Key provisions include immediate R&D expensing, permanent bonus depreciation, modifications to interest expense limitations, and changes to certain international tax rules. While the Company continues to evaluate the potential impact of the OBBBA on its consolidated financial statements, due to its full valuation allowance position on U.S. deferred tax assets, immaterial current tax liabilities, and insignificant foreign earnings from Evolv UK, the Company does not expect the OBBBA to have a material impact on its financial position, results of operations, or effective tax rate.


## us-gaap:EarningsPerShareTextBlock

[0001805385-25-000009:notes:182]
Net (Loss) Income per Share
Basic and diluted net (loss) income per share attributable to common stockholders are calculated as follows (in thousands, except share and per share amounts):

[0001805385-25-000009:notes:183]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Numerator: |  |  |  |  |  |  |  |
| Net (loss) income | $ | (40,535) |  | $ | 3,418 |  | $ | (42,224) |  | $ | (7,854) |
| Reallocation of net income attributable to participating securities | — |  | (41) |  | — |  | — |
| Net (loss) income attributable to common stockholders – basic and diluted | $ | (40,535) |  | $ | 3,377 |  | $ | (42,224) |  | $ | (7,854) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding – basic | 165,252,554 |  | 156,473,080 |  | 163,042,749 |  | 154,774,899 |
| Weighted average effect of potentially dilutive securities: |  |  |  |  |  |  |  |
| Stock options | — |  | 13,047,919 |  | — |  | — |
| Restricted stock units | — |  | 1,940,411 |  | — |  | — |
| Finback Common Stock Warrants | — |  | 102,533 |  | — |  | — |
| Total potentially dilutive securities | — |  | 15,090,863 |  | — |  | — |
| Weighted average common shares outstanding – diluted | 165,252,554 |  | 171,563,943 |  | 163,042,749 |  | 154,774,899 |
| Net (loss) income per share attributable to common stockholders - basic | $ | (0.25) |  | $ | 0.02 |  | $ | (0.26) |  | $ | (0.05) |
| Net (loss) income per share attributable to common stockholders - diluted | $ | (0.25) |  | $ | 0.02 |  | $ | (0.26) |  | $ | (0.05) |

[0001805385-25-000009:notes:184]
[same as prior period, unchanged from 0001628280-25-026845:notes:169]

[0001805385-25-000009:notes:185]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Options issued and outstanding | 11,630,769 |  |  | 7,237,746 |  |  | 11,630,769 |  | 21,681,791 |  |
| Public Warrants to purchase common stock | 14,324,893 |  |  | 14,324,893 |  |  | 14,324,893 |  |  | 14,324,893 |  |
| Warrants to purchase common stock (Finback) | 117,423 |  |  | — |  |  | 117,423 |  |  | 117,423 |  |
| Unvested restricted stock units | 10,582,484 |  |  | 8,843,186 |  |  | 10,582,484 |  |  | 16,117,388 |  |
| Unvested market-based stock units* | 1,670,143 |  |  | — |  |  | 1,670,143 |  |  | — |  |
| Earn-out shares* | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |  | 15,000,000 |  |
| Contingently issuable common stock* | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |  | 1,897,500 |  |
|  | 55,223,212 |  |  | 47,303,325 |  |  | 55,223,212 |  |  | 69,138,995 |  |

[0001805385-25-000009:notes:186]
[same as prior period, unchanged from 0001628280-25-026845:notes:171]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001805385-25-000009:notes:187]
Related Party Transactions
Original Equipment Manufacturer Partnership Agreement with Motorola
In December 2020, the Company entered into an original equipment manufacturer partnership agreement with Motorola Solutions, Inc. (“Motorola”), an investor in the Company. The partnership agreement has since been amended and restated. Motorola sells Motorola-branded premium products based on the Evolv Express platform through their worldwide network of over 2,000 resellers and integration partners, and has integrated the Evolv Express platform with Motorola products. While the partnership agreement is still in effect, effective in the fourth quarter of 2024, Motorola is no longer considered a related party. During the three and six months ended June 30, 2024, revenue from Motorola's distributor services was $1.9 million (as restated) and $3.9 million (as restated), respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001805385-25-000009:notes:188]
Commitments and Contingencies
At each reporting date, the Company evaluates whether or not a potential loss amount or a potential range of loss is probable and reasonably estimable under the provisions of the authoritative guidance that addresses accounting for contingencies. The Company expenses the costs related to such legal proceedings as incurred. Insurance proceeds, if any, will be recognized as reductions to the related expenses in the period the proceeds are probable. Below is a summary of the various types of matters subject to this guidance.

[0001805385-25-000009:notes:189]
Indemnification Agreements

[0001805385-25-000009:notes:190]
In the ordinary course of business, the Company provides indemnification of varying scope and terms to vendors, lessors, business partners and other parties with respect to certain matters including, but not limited to, losses arising out of breach of such agreements or from intellectual property infringement claims made by third parties. In addition, the Company has entered into indemnification agreements with members of its Board of Directors and certain of its executive officers and employees that require the Company, among other things, to indemnify them against certain liabilities that may arise by reason of their role, status or service as directors or officers. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is, in many cases, unlimited. Based on historical experience and evaluation of the agreements, we do not believe that any payments related to our indemnities will have a material impact on our financial condition or results of operations.

[0001805385-25-000009:notes:191]
Legal Proceedings

[0001805385-25-000009:notes:192]
We are from time to time subject to various claims, lawsuits, government and regulatory examinations, inquiries, information requests and investigations, and other legal and administrative proceedings arising in the ordinary course of business. The Company has identified certain claims as a result of which a loss may be incurred. This assessment is based on our current understanding of relevant facts and circumstances. As such, our view of these matters is subject to inherent uncertainties and may change in the future. Significant judgment is required in both the determination of probability and the determination as to whether an exposure is reasonably estimable. Actual outcomes of these legal and regulatory proceedings may materially differ from our current estimates. The pending proceedings involve complex questions of fact and law and may require the expenditure of significant funds and the diversion of other resources. The results of legal proceedings are inherently uncertain, and material adverse outcomes are reasonably possible.

[0001805385-25-000009:notes:193]
General Litigation

[0001805385-25-000009:notes:194]
On March 25, 2024 and November 1, 2024, putative class action lawsuits were filed against the Company in the United States District Court for the District of Massachusetts. On December 13, 2024, the Court consolidated the two lawsuits into one action (the “Class Action”), pursuant to which a consolidated amended complaint was filed against the Company, certain former executives, a current director, and individuals associated with NewHold Investment Corp. Lead Plaintiff Robert Falk and additional plaintiffs Chris Williams, Tim R. Carrillo and Chris Swanson (“Class Action Plaintiffs”) allege that the Company violated federal securities laws by making false or misleading statements relating to the effectiveness of certain products and the Company’s revenue recognition. The Class Action Plaintiffs seek various forms of relief, including compensatory damages, reasonable costs and expenses, attorneys’ fees, and expert fees. The

[0001805385-25-000009:notes:195]
Company filed its motion to dismiss the Class Action on March 28, 2025, and the Class Action Plaintiffs filed their opposition to the motion to dismiss on June 24, 2025. On June 30, 2025, the Court issued an order staying the Class Action, including disposition on the motion to dismiss, pending settlement negotiations.

[0001805385-25-000009:notes:196]
On November 12, 2024, a shareholder derivative lawsuit was filed in the United States District Court for the District of Massachusetts (the “Massachusetts Derivative Action”). The Massachusetts Derivative Action is a consolidation of two shareholder derivative lawsuits based on the same allegations in the Class Action, and filed against certain former and current officers and directors, and nominally against the Company. Plaintiff Bonnie Maas, derivatively on behalf of nominal defendant the Company, brought claims for breach of fiduciary duty, violation of federal securities law, unjust enrichment, waste of corporate assets, and gross mismanagement, seeking monetary damages, including restitution and fees, equitable relief, and an order directing the Company to take all necessary actions to reform and improve its corporate governance and internal procedures. The Massachusetts Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.

[0001805385-25-000009:notes:197]
On March 10, 2025, a shareholder derivative lawsuit was filed in the Delaware Court of Chancery (the “Delaware Derivative Action”). The Delaware Derivative Action is based on the same allegations in the Class Action, and was filed against certain former and current officers, and nominally against the Company. Plaintiff Steve Bersch, derivatively on behalf of nominal defendant Evolv, brought claims for breach of fiduciary duty, unjust enrichment, and insider trading, seeking various forms of relief, including equitable relief, monetary damages, including restitution and fees, and a declaratory judgment. The Delaware Derivative Action is stayed pending the outcome of the motion to dismiss in the Class Action or a final order dismissing the Class Action with prejudice.

[0001805385-25-000009:notes:198]
The Company expects to incur legal and professional services expenses associated with this litigation in future periods. The Company will recognize these expenses as services are received. We cannot reasonably estimate a range of possible losses at this time for the derivative lawsuits, as the proceedings remain in the early stages, alleged damages have not been specified, and the derivative actions are stayed. For these reasons, the Company has not recorded a loss contingency liability for the derivative lawsuits as of June 30, 2025. On August 5, 2025, the parties to the Class Action engaged in mediation and reached a settlement in principle in the amount of $15.0 million, which is subject to negotiation of definitive documentation and court approval, of which the Company estimated that $14.0 million would be funded by D&O insurance. As of June 30, 2025, the Company recognized a settlement accrual of $15.0 million and an estimated insurance recovery of $14.0 million, which are included in accrued expenses and other current liabilities and prepaid and other current assets in the condensed consolidated balance sheets, respectively. The Company recognized the net $1.0 million as an estimated loss in general and administrative expense in the condensed consolidated statements of operations and comprehensive loss for both the three and six months ended June 30, 2025.

[0001805385-25-000009:notes:199]
Regulatory and Governmental Matters

[0001805385-25-000009:notes:200]
As previously disclosed, on October 12, 2023, the Company announced that the U.S. Federal Trade Commission (the “FTC”) had requested information about certain aspects of its marketing practices. The Company reached a settlement with the FTC and on December 5, 2024, a Stipulated Order for Permanent Injunction and Other Relief (the “Order”) was entered in the United States District Court for the District of Massachusetts Eastern Division. The Order (i) required that the Company permit a limited cohort of school customers to cancel their contracts, (ii) required that the Company take certain compliance actions and meet record keeping obligations, and (iii) enjoined the Company from making misleading or unsubstantiated marketing claims. The Order did not include any monetary relief. The period during which eligible customers may cancel closed on March 30, 2025. Any inability to adequately comply with the terms of the Order could result in enforcement actions or penalties imposed by the FTC.

[0001805385-25-000009:notes:201]
As part of the Order, the Company agreed to offer a limited number of its K-12 education customers the option to cancel the remainder of their current contracts during a 60-day cancellation period. 65 education customers were offered the cancellation period, and of these, 5 customers representing 24 Evolv Express systems elected to cancel their contracts with the Company. Amounts that customers had paid to the Company related to portions of their contracts that were cancelled are required to be returned to the customer, but these amounts were immaterial for the year ended December 31, 2024 and therefore the Company did not book a liability in its consolidated financial statements. There is no impact to revenue or cost of revenue amounts for the three and six months ended June 30, 2025, as revenue continued to be

[0001805385-25-000009:notes:202]
recognized on these deals through the cancellation dates of each contract, all of which were in June 2025, and all systems have been removed from our subscription base as of June 30, 2025. The Company determined that $0.9 million of its revenues previously expected to be recognized over the next two years related to performance obligations that were unsatisfied (or partially satisfied) as of the effective date of the Order were impacted by the cancellations, which has been excluded from the remaining performance obligations disclosed in Note 6 Revenue Recognition.

[0001805385-25-000009:notes:203]
As previously disclosed, in February 2024, the Company received a subpoena from the Division of Enforcement of the Securities and Exchange Commission (the “SEC”), requesting documents and information relating to certain aspects of the Company’s marketing practices, and the Company has since received additional related requests. The Company is cooperating with the SEC’s investigation.

[0001805385-25-000009:notes:204]
As previously reported, the Company self-reported the Investigation to the Division of Enforcement of the SEC. The Company has since received requests for documents and information from the SEC relating to this matter. The Company is cooperating with this investigation. On November 1, 2024, the Company received a voluntary document request from the U.S. Attorney’s Office of the Southern District of New York ("DOJ") relating to these same issues, and has since received additional requests for documents and information relating to this matter. By letter dated August 7, 2025, the DOJ informed the Company that the Company is no longer the subject of a DOJ investigation.

[0001805385-25-000009:notes:205]
In view of the inherent unpredictability of such regulatory and governmental matters, the Company cannot determine with certainty the timing or ultimate resolution of legal and regulatory matters or the eventual loss, fines or penalties, if any, that may result from such matters. The Company establishes reserves for such matters when those matters present loss contingencies that are both probable and can be reasonably estimated. The actual costs of resolving such matters, however, may be substantially higher than the amounts reserved for those matters, and an adverse outcome in certain of these matters could have a material adverse effect on the consolidated financial statements in particular quarterly or annual periods. The Company accrues amounts for certain matters for which losses are considered to be probable of occurring based on its reasonable estimate of the most likely outcome. It is reasonably possible actual losses could be significantly different from the Company's current estimates. In addition, there are some matters for which it is reasonably possible that a loss will occur, however the Company cannot estimate a range of the potential losses for these matters.

[0001805385-25-000009:notes:206]
Any resolution or litigation with the SEC or other parties, could ultimately result in monetary and injunctive relief that may impose costs on the Company and/or require it to make changes to its business practices. These costs and requirements may be material both individually and in the aggregate, but we have not accrued a loss pertaining to SEC matter. In addition to the expected insurance recovery discussed above related to the Class Action litigation, the Company's defense costs for counsel and consultants in connection with the securities litigation and the related SEC and DOJ matter, including certain expenses that have previously been paid, are also expected to be reimbursed. As of June 30, 2025, the Company recognized an estimated loss recovery related to insurance coverage for these matters of $1.7 million and $5.6 million for the three and six months ended June 30, 2025, respectively, which was recorded as a reduction of general and administrative expense in the condensed consolidated statements of operations and comprehensive loss. As of June 30, 2025, $0.9 million of these recoveries have been paid out by the Company's insurance provider. The $4.7 million remaining estimated recovery is included in prepaid and other current assets in the condensed consolidated balance sheets as of June 30, 2025. This amount reflects costs that have been confirmed covered by the Company’s insurance providers, as well as an estimate of other claims the Company has determined are probable of recovery. $4.1 million of recoveries were paid out in July 2025. As it relates to these losses for which the Company has determined recovery to be probable, the Company cannot provide any assurance that additional costs related to these matters will not exceed the limits of its insurance policies, that other such claims, for which a loss recovery could not be estimated, are covered by the terms of its insurance policies or that its insurance carrier will be able to cover all related claims. There can be no assurance as to the timing or the terms of the ultimate outcome of these investigations or their potential effect, if any, on us or our results of operations. We expect to incur legal and professional services expenses associated with this litigation in future periods. We will recognize these expenses as services are received, net of estimated insurance recoveries. There can be no assurance whether there will be further information requests or potential enforcement action or litigation, which is necessarily uncertain.

[0001805385-25-000009:notes:207]
Contract manufacturers

[0001805385-25-000009:notes:208]
The Company generally contracts with its contract manufacturer, Columbia Tech, on a cancellable, purchase-order basis. The Company has a contract in the normal course of business with Columbia Tech to provide manufacturing services for the Company's equipment sold or leased to customers. While these contracts are cancellable by the Company upon prior notice, payments due upon cancellation consist of payments for services provided or expenses incurred, including noncancelable obligations of our service providers, up to the date of cancellation. These payments are not determinable, but could result in a material purchase commitment if the Company were to cancel their open purchase orders.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001805385-25-000009:notes:209]
Segment Information
The Company determined that it has one operating and reporting segment after considering the Company’s organizational structure and the information regularly reviewed and evaluated by the Company’s Chief Operating Decision Maker (“CODM”) in deciding how to allocate resources and assess performance. The Company has determined that its CODM is its President and Chief Executive Officer. The CODM evaluates the performance of our segment based upon consolidated net income and considers budget-to-actual or forecast-to-actual variances to assess performance and make decisions about allocating resources. The CODM evaluates segment assets based on total assets on the condensed consolidated balance sheets. Asset information is not presented here because its presentation here would be duplicative of the condensed consolidated balance sheets. On the basis of these factors, the Company determined that it operates and manages its business as one operating and reporting segment, that develops, manufactures, markets and sells security screening products and specific services, and accordingly has one reportable segment for financial reporting purposes.

[0001805385-25-000009:notes:210]
[same as prior period, unchanged from 0001628280-25-026845:notes:194]

[0001805385-25-000009:notes:211]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (As Restated) |  |  |  | (As Restated) |
| Segment revenue | $ | 32,544 |  |  | $ | 25,224 |  |  | $ | 64,551 |  |  | $ | 47,405 |  |
| Less: |  |  |  |  |  |  |  |
| Employee expense | 15,739 |  |  | 17,819 |  |  | 32,108 |  |  | 35,660 |  |
| Travel and expense | 1,101 |  |  | 1,674 |  |  | 1,892 |  |  | 3,188 |  |
| Capitalized R&D expense | (1,361) |  |  | (1,568) |  |  | (2,850) |  |  | (3,022) |  |
| Stock-based compensation expense1 | 5,547 |  |  | 7,427 |  |  | 9,901 |  |  | 13,857 |  |
| Other non-recurring expenses2 | 6,812 |  |  | 2,287 |  |  | 10,373 |  |  | 3,967 |  |
| Consulting and contract staffing | 3,046 |  |  | 3,120 |  |  | 6,323 |  |  | 6,436 |  |
| Software subscriptions | 1,569 |  |  | 1,637 |  |  | 3,104 |  |  | 3,095 |  |
| Depreciation and amortization | 5,790 |  |  | 3,901 |  |  | 11,319 |  |  | 7,358 |  |
| Restructuring costs | — |  |  | 860 |  |  | 2,662 |  |  | 860 |  |
| Disposal of property and equipment | 1,312 |  |  | — |  |  | 1,633 |  |  | — |  |
| Other cost of revenue | 6,894 |  |  | 5,261 |  |  | 12,014 |  |  | 9,274 |  |
| Other operating expenses | 3,588 |  |  | 5,177 |  |  | 7,954 |  |  | 11,009 |  |
| Other segment items3 | 23,042 |  |  | (25,789) |  |  | 10,342 |  |  | (36,423) |  |
| Segment net (loss) income | $ | (40,535) |  |  | $ | 3,418 |  |  | $ | (42,224) |  |  | $ | (7,854) |  |

[0001805385-25-000009:notes:212]
1 Excludes incremental expense related to modified awards included in the Restructuring costs line. See Note 16, Restructuring Charges for additional information.

[0001805385-25-000009:notes:213]
2 For the three and six months ended June 30, 2025, includes consulting and legal fees related to the Investigation (as defined in Note 2) and related matters, additional audit fees incurred in connection with the restatement of prior period financial statements, net of estimated insurance recoveries, as well as estimated net losses related to ongoing legal matters. For the three and six months ended June 30, 2024, includes costs associated with adverse non-cancellable inventory purchase commitments and severance expense.

[0001805385-25-000009:notes:214]
3 Refer to Total other (expense) income, net and (Benefit) provision for income taxes in the condensed consolidated statements of operations and comprehensive loss.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001805385-25-000009:notes:215]
[same as prior period, unchanged from 0001628280-25-026845:notes:199]

[0001805385-25-000009:notes:216]
[same as prior period, unchanged from 0001628280-25-026845:notes:200]

[0001805385-25-000009:notes:217]
All actions related to the reduction in force were completed by March 31, 2025, with the exception of certain severance obligations that are payable over various periods through November 2025 under the Company's Severance And Change In Control Plan.

[0001805385-25-000009:notes:218]
To align the presentation of restructuring charges, the Company reclassified the comparative financial statements for the three and six months ended June 30, 2024. For both the three and six months ended June 30, 2024, the reclassifications resulted in an increase in restructuring costs of $0.9 million, and a corresponding decrease in cost of service revenue, sales and marketing expenses, and general and administrative expenses of $0.2 million, $0.7 million, and less than $0.1 million, respectively. The prior year activity was limited in scope, and the reclassifications did not impact total loss from operations or total net income (loss). All actions related to the prior year reduction in force were completed by June 30, 2024.

[0001805385-25-000009:notes:219]
The following table summarizes the liabilities recognized in relation to the cash obligations from reduction in force, which are included in accrued expenses and other current liabilities in our condensed consolidated balance sheets (in thousands):

[0001805385-25-000009:notes:220]
| Balance at December 31, 2023 | $ | — |  |
| Charges incurred | 860 |  |
| Cash payments | (860) |  |
| Balance at December 31, 2024 | — |  |
| Charges incurred | 2,137 |  |
| Cash payments | (1,849) |  |
| Balance at June 30, 2025 | $ | 288 |  |


## us-gaap:SubsequentEventsTextBlock

[0001805385-25-000009:notes:221]
Subsequent Events
Senior Secured Credit Facilities

[0001805385-25-000009:notes:222]
As described in Note 2, on July 29, 2025, the Company entered into the $75.0 million MidCap Credit Agreement, the proceeds of which will be used for general corporate purposes, including to support growing long-term demand for the

[0001805385-25-000009:notes:223]
Company's subscription sales model. The MidCap Credit Agreement provides for the Senior Secured Credit Facilities, which include an initial $30.0 million term loan facility, a $30.0 million delayed draw facility (available for drawdown during the two-year period following the closing date), and a $15.0 million revolving line of credit, each with a term of five years. At closing, the Company received net proceeds of $26.6 million, after deducting $3.4 million in debt issuance costs incurred in connection with the closing of MidCap Credit Agreement.

[0001805385-25-000009:notes:224]
The Senior Secured Credit Facilities are guaranteed by the Company, and in the future, may be guaranteed by certain material subsidiaries. The Senior Secured Credit Facilities are secured by a first lien on substantially all of the assets of the Company. The borrowings under the Senior Secured Credit Facilities bear interest at a fluctuating rate per annum equal to (x) a base rate determined by reference to the higher of (1) the prime rate of Wells Fargo and (2) 2.00% or (y) Term Secured Overnight Financing Rate (“Term SOFR”), in each case, plus an applicable margin calculated based on earnings before interest, taxes, depreciation, and amortization (“EBITDA”). At closing, the applicable margin on Term SOFR loans was 5.25%. Interest and principal are payable monthly. The term loan facilities require interest-only payments during the initial 48-month period, with principal repayment amortized on a straight-line basis over the remaining 12 months of the term.

[0001805385-25-000009:notes:225]
Under the MidCap Credit Agreement, the Company is also required to comply with certain customary affirmative and negative covenants, including a minimum annual recurring revenue covenant, a minimum EBITDA covenant that takes effect on the second anniversary of the closing date, and a minimum liquidity covenant that would cease to apply following the resolution of certain litigation and regulatory matters, in addition to customary reporting requirements of periodic financial results.

[0001805385-25-000009:notes:226]
Departure of Officer

[0001805385-25-000009:notes:227]
On August 13, 2025, Mr. Michael Ellenbogen, Chief Innovation Officer and a member of the Board of Directors (the “Board”) of the Company, informed the Company that he would be resigning as Chief Innovation Officer, effective as of September 5, 2025, citing new time commitments. Mr. Ellenbogen’s decision to resign is not due any disagreements with the Company. Mr. Ellenbogen will continue to serve as a member of the Board and will be eligible to receive compensation as a non-employee director pursuant to the Company's Director Compensation Policy.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001805385-25-000009:notes:228]
On June 12, 2025, Anil Chitkara, Co-Founder and Chief Growth Officer, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the sale of 360,000 shares of the Company’s common stock underlying 360,000 stock options. The trading arrangement is scheduled to expire on the earlier of March 31, 2026 or the date that all transactions under the trading arrangement are completed.

[0001805385-25-000009:notes:229]
On June 12, 2025, Michael Ellenbogen, Co-Founder, Chief Innovation Officer, and Director, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the sale of 888,202 shares of the Company’s common stock underlying 888,202 stock options and net shares of the Company's common stock underlying 174,664 restricted stock units. The trading arrangement is scheduled to expire on the earlier of September 14, 2026 or the date that all transactions under the trading arrangement are completed.
