# EVLV 8-K — 0001805385-25-000008 filed 2025-08-14

## item codes, every 8-K on or before 2025-08-14

- 2025-08-14 0001805385-25-000008 — 2.02, 5.02, 9.01
- 2025-07-30 0001104659-25-071952 — 1.01, 9.01
- 2025-07-01 0001104659-25-064786 — 7.01
- 2025-06-23 0001628280-25-032646 — 5.07
- 2025-05-20 0001628280-25-026833 — 2.02, 9.01
- 2025-04-28 0001628280-25-020351 — 2.02, 9.01
- 2025-04-23 0001104659-25-037732 — 5.02, 7.01, 9.01
- 2025-04-22 0001104659-25-037530 — 3.01, 7.01, 9.01
- 2025-02-04 0001104659-25-008892 — 5.02, 7.01, 9.01
- 2025-01-24 0001104659-25-005796 — 5.02, 7.01, 8.01, 9.01
- 2025-01-23 0001628280-25-002293 — 2.02, 2.05, 7.01, 9.01
- 2024-12-23 0001104659-24-131278 — 5.02
- 2024-12-12 0001104659-24-128006 — 5.02
- 2024-12-09 0001104659-24-126542 — 5.02, 7.01, 9.01
- 2024-11-22 0001104659-24-122102 — 3.01, 7.01, 9.01
- 2024-11-21 0001104659-24-121349 — 5.02, 7.01, 8.01, 9.01
- 2024-10-31 0001104659-24-112868 — 5.02, 7.01, 9.01
- 2024-10-25 0001104659-24-111310 — 4.02, 7.01, 9.01
- 2024-08-08 0001628280-24-036115 — 2.02, 9.01
- 2024-06-04 0001628280-24-026572 — 5.07
- 2024-05-09 0001628280-24-022265 — 2.02, 9.01
- 2024-02-29 0001628280-24-007980 — 2.02, 9.01
- 2024-02-20 0001104659-24-025077 — 7.01, 9.01
- 2024-01-31 0001628280-24-002618 — 5.03, 9.01
- 2023-11-09 0001628280-23-038267 — 2.02, 9.01
- 2023-11-06 0001104659-23-114499 — 5.02
- 2023-10-25 0001628280-23-035145 — 4.02
- 2023-10-12 0001104659-23-108693 — 2.02, 7.01, 9.01
- 2023-08-10 0001628280-23-028861 — 2.02, 9.01
- 2023-06-02 0001628280-23-020680 — 5.07
- 2023-05-10 0001628280-23-017243 — 2.02, 9.01
- 2023-04-03 0001628280-23-010402 — 1.02, 2.04, 8.01, 9.01
- 2023-03-17 0001104659-23-033993 — 8.01, 9.01
- 2023-03-02 0001628280-23-006043 — 5.02, 9.01
- 2023-03-01 0001628280-23-005844 — 2.02, 9.01
- 2022-12-21 0001104659-22-128865 — 1.01, 2.03, 7.01, 9.01
- 2022-11-09 0001628280-22-029266 — 2.02, 9.01
- 2022-10-31 0001104659-22-112971 — 5.02, 9.01
- 2022-09-07 0001628280-22-024502 — 5.02
- 2022-08-10 0001628280-22-022221 — 2.02, 9.01
- 2022-05-27 0001104659-22-065966 — 5.07
- 2022-05-19 0001104659-22-062926 — 5.02, 7.01, 9.01
- 2022-05-11 0001104659-22-058798 — 2.02, 9.01
- 2022-04-14 0001104659-22-046075 — 5.02
- 2022-03-31 0001104659-22-040564 — 7.01, 9.01
- 2022-03-14 0001104659-22-033306 — 2.02, 9.01
- 2022-02-25 0001104659-22-027336 — 7.01
- 2022-02-04 0001104659-22-012021 — 5.02
- 2022-01-28 0001104659-22-009062 — 5.02, 9.01
- 2021-11-10 0001558370-21-015481 — 2.02, 9.01
- 2021-11-01 0001104659-21-132351 — 5.02, 7.01, 9.01
- 2021-09-09 0001104659-21-114263 — 8.01
- 2021-08-16 0001104659-21-106326 — 2.02, 4.01, 9.01
- 2021-08-16 0001104659-21-106282 — 9.01 — amendment, the index does not say of what
- 2021-08-06 0001104659-21-101433 — 5.02
- 2021-07-22 0001104659-21-094897 — 5.02, 5.06
- 2021-07-22 0001104659-21-094890 — 1.01, 2.01, 3.02, 3.03, 4.01, 5.01, 5.03, 8.01, 9.01
- 2021-07-21 0001104659-21-094408 — 5.07, 8.01, 9.01
- 2021-06-09 0001213900-21-031667 — 1.01, 9.01
- 2021-05-12 0001213900-21-025792 — 4.02
- 2021-03-08 0001213900-21-013856 — 1.01, 3.02, 7.01, 9.01
- 2020-09-22 0001213900-20-027802 — 8.01
- 2020-08-19 0001213900-20-022832 — 3.02, 8.01, 9.01
- 2020-08-10 0001213900-20-021160 — 8.01, 9.01
- 2020-08-05 0001213900-20-020417 — 1.01, 3.02, 5.03, 8.01, 9.01

## late-filing notifications on or before 2025-08-14

- 2025-05-15 0001104659-25-049608 — NT 10-Q, for the period ended 2025-03-31
- 2025-03-31 0001104659-25-029637 — NT 10-K, for the period ended 2024-12-31
- 2024-11-13 0001104659-24-117677 — NT 10-Q, for the period ended 2024-09-30
- 2022-08-16 0001628280-22-022957 — NT 10-Q, for the period ended 2022-06-30
- 2021-05-18 0001213900-21-027320 — NT 10-Q, for the period ended 2021-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001805385-25-000008:8k_2_02:1]
EX-99.1
2
evlv-20250814exx991.htm
EX-99.1

[0001805385-25-000008:8k_2_02:2]
Document

[0001805385-25-000008:8k_2_02:3]
Exhibit 99.1

[0001805385-25-000008:8k_2_02:4]
Evolv Technology Reports Second Quarter Financial Results

[0001805385-25-000008:8k_2_02:5]
—  Company Raises Revenue Growth Outlook for 2025 to 27%-30% —

[0001805385-25-000008:8k_2_02:6]
•Q2'25 Revenue of $32.5 million, up 29% year-over-year

[0001805385-25-000008:8k_2_02:7]
•Q2'25 Ending ARR1 of $110.5 million, up 27% year-over-year

[0001805385-25-000008:8k_2_02:8]
•Q2'25 Net Loss of $(40.5) million, with Net Profit Margin of (125)%

[0001805385-25-000008:8k_2_02:9]
•Q2'25 Adjusted EBITDA2 of $2.0 million, with Adjusted EBITDA Margin2 of 6%

[0001805385-25-000008:8k_2_02:10]
•Q2'25 Cash Flow from Operations of $2.1 million vs. $(21.6) million in Q2'24

[0001805385-25-000008:8k_2_02:11]
Waltham, Massachusetts – August 14, 2025 – Evolv Technologies Holdings, Inc (NASDAQ: EVLV), a leading security technology company pioneering AI-based solutions designed to help create safer experiences, today announced financial results for the quarter ended June 30, 2025.

[0001805385-25-000008:8k_2_02:12]
“Our second quarter results were marked by strong revenue growth, continued customer acquisition and expansion, and improved visibility that positions us well as we evolve into a more predictable and scalable business," said John Kedzierski, President and Chief Executive Officer of Evolv Technology. "We believe that surpassing 1,000 customers served—and having screened over 3 billion visitors to date—reflects the market’s growing trust in our solutions. Looking ahead, we’re encouraged by the opportunity in the AI-based security screening market and remain focused on delivering consistent, high-quality performance.”

[0001805385-25-000008:8k_2_02:13]
Results for the Second Quarter of 2025

[0001805385-25-000008:8k_2_02:14]
Total revenue for the second quarter of 2025 was $32.5 million, an increase of 29% compared to $25.2 million (as restated) for the second quarter of 2024. Annual Recurring Revenue (“ARR”)1 was $110.5 million at the end of second quarter of 2025, an increase of 27% compared to $87.0 million (as restated) at the end of the second quarter of 2024. Net loss for the second quarter of 2025 was $(40.5) million, or $(0.25) per basic and diluted share, compared to net income of $3.4 million (as restated), or $0.02 per basic and diluted share, in the second quarter of 2024. Adjusted earnings (loss)2 for the second quarter of 2025 was $(3.4) million, or $(0.02) per diluted share, compared to adjusted earnings (loss)2 of $(11.2) million (as restated), or $(0.07) per diluted share (as restated), for the second quarter of 2024. Adjusted EBITDA2 for the second quarter of 2025 was $2.0 million compared to $(8.0) million (as restated) in the second quarter of 2024. As of June 30, 2025, the Company had cash, cash equivalents and marketable securities of $36.9 million and no debt.

[0001805385-25-000008:8k_2_02:15]
Results for the First Six Months of 2025

[0001805385-25-000008:8k_2_02:16]
Total revenue for the six months ended June 30, 2025 was $64.6 million, an increase of 36% compared to $47.4 million (as restated) for the six months ended June 30, 2024. Net loss for the six months ended June 30, 2025 was $(42.2) million, or $(0.26) per basic and diluted share, compared to $(7.9) million (as restated), or $(0.05) per basic and diluted share, in the six months ended June 30, 2024. Adjusted earnings (loss)2 for the six months ended June 30, 2025 was $(6.8) million, or $(0.04) per diluted share, compared to adjusted earnings (loss)2 of $(23.9) million (as restated), or $(0.15) per diluted share (as restated), for the six months ended June 30, 2024. Adjusted EBITDA2 for the six months ended June 30, 2025 was $3.8 million compared to $(18.3) million (as restated) in the six months ended June 30, 2024.

[0001805385-25-000008:8k_2_02:17]
The following table summarizes the breakdown of recurring and non-recurring revenue3 for each period presented:

[0001805385-25-000008:8k_2_02:18]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | % Change |  | 2025 |  | 2024 |  | % Change |
|  |  |  | (Restated) |  |  |  |  |  | (Restated) |  |  |
| Recurring revenue | $ | 26,678 |  |  | $ | 21,016 |  |  | 27 | % |  | $ | 52,431 |  |  | $ | 39,977 |  |  | 31 | % |
| Non-recurring revenue | 5,866 |  |  | 4,208 |  |  | 39 | % |  | 12,120 |  |  | 7,428 |  |  | 63 | % |
| Total revenue | $ | 32,544 |  |  | $ | 25,224 |  |  | 29 | % |  | $ | 64,551 |  |  | $ | 47,405 |  |  | 36 | % |

[0001805385-25-000008:8k_2_02:19]
The following table summarizes operating cash flows for each period presented:

[0001805385-25-000008:8k_2_02:20]
|  |  |  | Six Months EndedJune 30, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  |  |  | (Restated) |
| Net loss |  |  |  |  | $ | (42,224) |  |  | $ | (7,854) |  |
| Adjustments to reconcile net loss to net cash provided by (used in) operating activities |  |  |  |  | 37,361 |  |  | (10,672) |  |
| Changes in operating assets and liabilities |  |  |  |  | 4,437 |  |  | (19,206) |  |
| Net cash used in operating activities |  |  |  |  | $ | (426) |  |  | $ | (37,732) |  |

[0001805385-25-000008:8k_2_02:21]
Company Comments on Outlook for 2025

[0001805385-25-000008:8k_2_02:22]
The Company today commented on its business outlook for 2025. The Company's outlook is based on the current indications for its business, which may change at any time.  The Company expects total revenues in 2025 to be between $132 to $135 million, reflecting growth of 27% to 30% compared to 2024.  The Company believes that this revenue growth, coupled with a focus on operational efficiency, will drive improved profitability and cash flow.  The Company expects to deliver positive full year Adjusted EBITDA1 in 2025 with Adjusted EBITDA1 margins in the mid-single digits.  The Company expects to be cash flow positive in the fourth quarter of 2025.

[0001805385-25-000008:8k_2_02:23]
| Estimate |  | Issued May 20, 2025 |  | Issued August 14, 2025 |
| Total Revenue (Millions) |  | $125-$130 |  | $132-$135 |
| Total Revenue Growth Rate |  | 20%-25% |  | 27%-30% |
| Adjusted EBITDA Margin2 |  | Low to Mid-Single Digits |  | Mid-Single Digits |

[0001805385-25-000008:8k_2_02:24]
Company to Host Live Conference Call and Webcast

[0001805385-25-000008:8k_2_02:25]
The Company’s management team plans to host a live conference call and webcast at 4:30 p.m. Eastern Time today to discuss the financial results as well as management’s outlook for the business.  The conference call will be webcast live at http://ir.evolvtechnology.com.

[0001805385-25-000008:8k_2_02:26]
About Evolv Technology

[0001805385-25-000008:8k_2_02:27]
Evolv Technologies Holdings, Inc (NASDAQ: EVLV) is designed to transform human security to make a safer, faster, and better experience for the world’s most iconic venues and companies as well as schools, hospitals, and public spaces, using industry leading artificial intelligence (AI)-powered screening and analytics. Its mission is to transform security to create a safer world to live, work, learn, and play. Evolv has digitally transformed the gateways in many places where people gather by enabling seamless integration combined with powerful analytics and insights. Evolv’s advanced systems have scanned more than three billion people since 2019. Evolv has been awarded the U.S. Department of Homeland Security (DHS) SAFETY Act Designation as a Qualified Anti-Terrorism Technology (QATT) as well as the Security Industry Association (SIA) 2024 New Products and Solutions (NPS) Award in the Law Enforcement/Public Safety/Guarding Systems category, as well as Sport Business Journal’s (SBJ) 2024 awards for “Best In Fan Experience Technology” and “Best In Sports Technology”. Evolv®, Evolv Express®, Evolv Insights®, Evolv Visual Gun Detection™, Evolv eXpedite™, and Evolv

[0001805385-25-000008:8k_2_02:28]
Eva™ are registered trademarks or trademarks of Evolv Technologies, Inc. in the United States and other jurisdictions. For more information, visit evolv.com.

[0001805385-25-000008:8k_2_02:29]
1 We define Annual Recurring Revenue, or ARR, as subscription revenue and the recurring service revenue related to purchase subscriptions for the final month of the quarter normalized to a one-year period. Our calculation of ARR is not adjusted for the impact of any known or projected future events (such as customer cancellations, upgrades or downgrades, or price increases or decreases) that may cause any such contract not to be renewed on its existing terms. In addition, the amount of actual revenue that we recognize over any 12-month period is likely to differ from ARR at the beginning of that period, sometimes significantly. This may occur due to new bookings, cancellations, upgrades, downgrades or other changes in pending renewals, as well as the effects of professional services revenue and acquisitions or divestitures. As a result, ARR should be viewed independently of, and not as a substitute for or forecast of, revenue and deferred revenue. Our calculation of ARR may differ from similarly titled metrics presented by other companies.

[0001805385-25-000008:8k_2_02:30]
2 Non-GAAP Financial Measures In this press release, the Company’s adjusted gross profit (loss), adjusted gross margin, adjusted operating expenses, adjusted operating income (loss), adjusted EBITDA, adjusted EBITDA margin, adjusted earnings (loss), and adjusted earnings per diluted share are not presented in accordance with generally accepted accounting principles (GAAP) and are not intended to be used in lieu of GAAP presentations of results of operations. Adjusted operating expenses is defined as operating expenses less stock-based compensation expense, loss on impairment of lease equipment, non-recurring restructuring and other employee separation costs, and non-recurring legal and regulatory costs, which management believes provides a more meaningful representation of on-going operating expense levels. Non-recurring legal and regulatory costs include non-recurring legal, accounting and professional fees related to the internal investigation, subsequent restatement, certain non-recurring regulatory, litigation and legal matters, as well as fees related to the resolution of the U.S. Federal Trade Commission investigation, net of estimated insurance recoveries. Adjusted gross profit and adjusted gross margin exclude stock-based compensation expense, amortization of capitalized stock-based compensation, loss on impairment of leased equipment, and non-recurring inventory charges, which management believes provides a more meaningful representation of contribution margin. Adjusted operating loss is defined as operating loss, excluding stock-based compensation expense, amortization of capitalized stock-based compensation, loss on impairment of leased equipment, non-recurring restructuring and other employee separation costs, non-recurring inventory charges, and non-recurring legal and regulatory costs, which management believes provides a more meaningful representation of operating results. Adjusted EBITDA and Adjusted EBITDA margin is defined as net income (loss) plus depreciation and amortization, stock-based compensation, interest expense (income), provision for income taxes, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of leased equipment, non-recurring restructuring and other employee separation costs, non-recurring inventory charges, and non-recurring legal and regulatory costs. Adjusted earnings (loss) is defined as net income (loss) plus stock-based compensation, amortization of capitalized stock-based compensation, change in fair value of contingent earn-out liability, change in fair value of contingently issuable common stock liability, change in fair value of public warrant liability, loss on impairment of leased equipment, non-recurring restructuring and other employee separation costs, non-recurring inventory charges, and non-recurring legal and regulatory costs. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operating performance. However, non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. We intend to provide non-GAAP financial measures as part of our future earnings discussions and, therefore, the inclusion of non-GAAP financial measures will provide consistency in our financial reporting. Investors are encouraged to review the reconciliation of these non-GAAP measures to their most directly comparable GAAP financial measures included in this press release. The Company is unable to provide a reconciliation of Adjusted EBITDA to Net Income (Loss) and Adjusted EBITDA Margin to Net Profit Margin, each measure's most directly comparable GAAP financial measure, on a forward-looking basis without unreasonable effort, because items that impact these GAAP financial measures are not within the Company’s control and/or cannot be reasonably predicted. These items may include, but are not limited to, predicting forward-looking share-based compensation, changes in the fair value of derivative liabilities, changes in the fair value of contingent earn out liabilities, changes in the fair value of contingently issuable common stock liabilities and changes in fair value of public warrant liabilities. Such information may have a significant, and potentially unpredictable, impact on the Company’s future financial results.

[0001805385-25-000008:8k_2_02:31]
3 Recurring revenue includes the recurring portion of revenue associated with pure subscription contracts and hardware purchase subscription contracts. Non-recurring revenue includes revenue that is non-recurring in nature, such as product revenue, shipping revenue, and revenue from installation, training, and professional services.

[0001805385-25-000008:8k_2_02:32]
Forward-Looking Statements

[0001805385-25-000008:8k_2_02:33]
not all forward-looking statements use these words or expressions. The forward-looking statements in this press release and related presentation materials are only predictions. We have based these forward-looking statements largely on our current expectations and projections about future events and financial trends that we believe may affect our business, financial condition and results of operations. Forward-looking statements involve known and unknown risks, uncertainties and other important factors that may cause our actual results, performance or achievements to be materially different from any future results, performance or achievements expressed or implied by the forward-looking statements, including, but not limited to, the amount of insurance reimbursements expected to be received for defense costs for counsel and consultants in connection with the securities litigation and related Securities and Exchange Commission (the “SEC”) and Department of Justice matters, and the following: our history of losses and ability to reach profitability; our reliance on reseller partners; expectations regarding the Company’s strategies and future financial performance, including its future business plans or objectives, prospective performance and opportunities and competitors, revenues, products and services, pricing, operating expenses, market trends, liquidity, cash flows and uses of cash, capital expenditures; the Company’s reliance on third party contract manufacturing and distribution, and a global supply chain; the Company recognizes a substantial portion of its revenue ratably over the term of its agreements, and, as a result, downturns or upturns in sales may not be immediately reflected in its operating results; the rate of innovation required to maintain competitiveness in the markets in which the Company competes; the competitiveness of the market in which the Company competes; the failure of our products to detect threats could result in injury or loss of life, which could harm our brand, reputation, and results of operations; the loss of designation of our Evolv Express® system as a Qualified Anti-Terrorism Technology under the Homeland Security SAFETY Act; risks related to our business model, which is predicated, in part, on building a customer base that will generate a recurring stream of revenues through the sale of our subscription contracts; the ability for the Company to obtain, maintain, protect and enforce the Company’s intellectual property rights and use of “open source” software; the concentration of the Company’s revenues on a single solution; the Company’s ability to timely design, produce and launch its solutions, the Company’s ability to invest in growth initiatives and pursue acquisition opportunities; the limited liquidity and trading of the Company’s securities; risks related to existing and changing tax laws; geopolitical risk and changes in applicable laws or regulations; the possibility that the Company may be adversely affected by other economic, business, and/or competitive factors; operational risk; risks related to material weaknesses in our internal control over financial reporting and our remediation plans; risks related to increasing attention to and evolving expectations for, environmental, social, and governance initiatives; the impact of fluctuating general economic and market conditions and reductions in spending; the need for additional capital to support business growth, which might not be available on acceptable terms, if at all; and litigation and regulatory enforcement risks, including the diversion of management time and attention and the additional costs and demands on resources. These and other important factors discussed in our most recent report on From 10-Q or 10-K filed with the SEC could cause actual results to differ materially from those indicated by the forward-looking statements made in this press release. The forward-looking statements in this press release and related presentation materials are based upon information available to us as of the date hereof, and while we believe such information forms a reasonable basis for such statements, it may be limited or incomplete, and our statements should not be read to indicate that we have conducted an exhaustive inquiry into, or review of, all potentially available relevant information. These statements are inherently uncertain and investors are cautioned not to unduly rely upon these statements.

[0001805385-25-000008:8k_2_02:34]
You should review this press release and the documents that we reference in this press release and related presentation materials with the understanding that our actual future results, levels of activity, performance and achievements may be materially different from what we expect. We qualify all of our forward-looking statements by these cautionary statements. Except as required by applicable law, we do not plan to publicly update or revise any forward-looking statements contained in this press release and related presentation materials, whether as a result of any new information, future events or otherwise.

[0001805385-25-000008:8k_2_02:35]
Investor Relations:

[0001805385-25-000008:8k_2_02:36]
Brian Norris

[0001805385-25-000008:8k_2_02:37]
Senior Vice President of Finance and Investor Relations

[0001805385-25-000008:8k_2_02:38]
bnorris@evolvtechnology.com

[0001805385-25-000008:8k_2_02:39]
EVOLV TECHNOLOGY

[0001805385-25-000008:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE LOSS

[0001805385-25-000008:8k_2_02:41]
(In thousands, except share and per share data)

[0001805385-25-000008:8k_2_02:42]
(Unaudited)

[0001805385-25-000008:8k_2_02:43]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Product revenue | $ | 2,528 |  |  | $ | 1,954 |  |  | $ | 4,850 |  |  | $ | 3,445 |  |
| Subscription revenue | 20,200 |  |  | 15,655 |  |  | 39,437 |  |  | 29,874 |  |
| Service revenue | 6,686 |  |  | 5,566 |  |  | 13,416 |  |  | 10,818 |  |
| License fee and other revenue | 3,130 |  |  | 2,049 |  |  | 6,848 |  |  | 3,268 |  |
| Total revenue | 32,544 |  |  | 25,224 |  |  | 64,551 |  |  | 47,405 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Cost of product revenue | 5,351 |  |  | 2,839 |  |  | 8,535 |  |  | 5,953 |  |
| Cost of subscription revenue | 8,894 |  |  | 6,309 |  |  | 16,790 |  |  | 11,894 |  |
| Cost of service revenue | 1,710 |  |  | 1,147 |  |  | 3,415 |  |  | 2,345 |  |
| Cost of license fee and other revenue | 371 |  |  | 172 |  |  | 443 |  |  | 301 |  |
| Total cost of revenue | 16,326 |  |  | 10,467 |  |  | 29,183 |  |  | 20,493 |  |
| Gross profit | 16,218 |  |  | 14,757 |  |  | 35,368 |  |  | 26,912 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 4,737 |  |  | 5,850 |  |  | 9,599 |  |  | 12,246 |  |
| Sales and marketing | 11,736 |  |  | 16,357 |  |  | 22,779 |  |  | 32,216 |  |
| General and administrative | 17,238 |  |  | 14,061 |  |  | 32,210 |  |  | 25,867 |  |
| Restructuring costs | — |  |  | 860 |  |  | 2,662 |  |  | 860 |  |
| Total operating expenses | 33,711 |  |  | 37,128 |  |  | 67,250 |  |  | 71,189 |  |
| Loss from operations | (17,493) |  |  | (22,371) |  |  | (31,882) |  |  | (44,277) |  |
| Other (expense) income, net: |  |  |  |  |  |  |  |
| Interest expense | — |  |  | — |  |  | (1) |  |  | — |  |
| Interest income | 224 |  |  | 681 |  |  | 613 |  |  | 1,766 |  |
| Other income (expense), net | 136 |  |  | (39) |  |  | 161 |  |  | (67) |  |
| Change in fair value of contingent earn-out liability | (14,200) |  |  | 16,514 |  |  | (5,224) |  |  | 23,413 |  |
| Change in fair value of contingently issuable common stock liability | (3,900) |  |  | 3,747 |  |  | (2,247) |  |  | 4,274 |  |
| Change in fair value of public warrant liability | (5,303) |  |  | 4,886 |  |  | (3,582) |  |  | 7,037 |  |
| Total other (expense) income, net | (23,043) |  |  | 25,789 |  |  | (10,280) |  |  | 36,423 |  |
| (Loss) income before income taxes | (40,536) |  |  | 3,418 |  |  | (42,162) |  |  | (7,854) |  |
| (Benefit) provision for income taxes | (1) |  |  | — |  |  | $ | 62 |  |  | $ | — |  |
| Net (loss) income | $ | (40,535) |  |  | $ | 3,418 |  |  | $ | (42,224) |  |  | $ | (7,854) |  |
| Net (loss) income attributable to common stockholders – basic and diluted | $ | (40,535) |  |  | $ | 3,377 |  |  | $ | (42,224) |  |  | $ | (7,854) |  |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |
| Basic | 165,252,554 |  | 156,473,080 |  | 163,042,749 |  | 154,774,899 |
| Diluted | 165,252,554 |  | 171,563,943 |  | 163,042,749 |  | 154,774,899 |
| Net loss per share |  |  |  |  |  |  |  |
| Basic | $ | (0.25) |  |  | $ | 0.02 |  |  | $ | (0.26) |  |  | $ | (0.05) |  |
| Diluted | $ | (0.25) |  |  | $ | 0.02 |  |  | $ | (0.26) |  |  | $ | (0.05) |  |
| Net (loss) income | $ | (40,535) |  |  | $ | 3,418 |  |  | $ | (42,224) |  |  | $ | (7,854) |  |
| Other comprehensive (loss) income |  |  |  |  |  |  |  |
| Cumulative translation adjustment | (85) |  |  | 8 |  |  | (131) |  |  | 11 |  |
| Total other comprehensive (loss) income | (85) |  |  | 8 |  |  | (131) |  |  | 11 |  |
| Total comprehensive (loss) income | $ | (40,620) |  |  | $ | 3,426 |  |  | $ | (42,355) |  |  | $ | (7,843) |  |

[0001805385-25-000008:8k_2_02:44]
EVOLV TECHNOLOGY

[0001805385-25-000008:8k_2_02:45]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001805385-25-000008:8k_2_02:46]
(In thousands, except share and per share data)

[0001805385-25-000008:8k_2_02:47]
(Unaudited)

[0001805385-25-000008:8k_2_02:48]
|  | June 30, 2025 |  | December 31, 2024 |
| Assets |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 36,942 |  |  | $ | 37,015 |  |
| Marketable securities | — |  |  | 14,927 |  |
| Accounts receivable, net | 41,802 |  |  | 28,392 |  |
| Inventory | 12,142 |  |  | 16,963 |  |
| Current portion of contract assets | 847 |  |  | 799 |  |
| Current portion of commission asset | 5,592 |  |  | 5,429 |  |
| Prepaid expenses and other current assets | 35,756 |  |  | 17,921 |  |
| Total current assets | 133,081 |  |  | 121,446 |  |
| Contract assets, noncurrent | 845 |  |  | 657 |  |
| Commission asset, noncurrent | 7,331 |  |  | 7,567 |  |
| Property and equipment, net | 125,478 |  |  | 123,661 |  |
| Operating lease right-of-use assets | 13,149 |  |  | 13,993 |  |
| Other assets | 538 |  |  | 735 |  |
| Total assets | $ | 280,422 |  |  | $ | 268,059 |  |
| Liabilities and Stockholders’ Equity |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 11,804 |  |  | $ | 10,492 |  |
| Accrued expenses and other current liabilities | 38,170 |  |  | 19,508 |  |
| Current portion of deferred revenue | 72,164 |  |  | 64,506 |  |
| Current portion of operating lease liabilities | 2,716 |  |  | 2,203 |  |
| Current portion of contingent earn-out liability | 18,033 |  |  | — |  |
| Total current liabilities | 142,887 |  |  | 96,709 |  |
| Deferred revenue, noncurrent | 19,208 |  |  | 20,266 |  |
| Operating lease liabilities, noncurrent | 11,550 |  |  | 12,326 |  |
| Contingent earn-out liability, non-current | — |  |  | 12,809 |  |
| Contingently issuable common stock liability | 6,248 |  |  | 4,001 |  |
| Public warrant liability | 7,879 |  |  | 4,297 |  |
| Total liabilities | 187,772 |  |  | 150,408 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 100,000,000 authorized at June 30, 2025 and December 31, 2024; no shares issued and outstanding at June 30, 2025 and December 31, 2024 | — |  |  | — |  |
| Common stock, $0.0001 par value; 1,100,000,000 shares authorized at June 30, 2025 and December 31, 2024; 170,626,362 and 159,602,069 shares issued and outstanding at June 30, 2025 and December 31, 2024, respectively | 17 |  |  | 16 |  |
| Additional paid-in capital | 489,684 |  |  | 472,331 |  |
| Accumulated other comprehensive loss | (163) |  |  | (32) |  |
| Accumulated deficit | (396,888) |  |  | (354,664) |  |
| Stockholders’ equity | 92,650 |  |  | 117,651 |  |
| Total liabilities and stockholders’ equity | $ | 280,422 |  |  | $ | 268,059 |  |

[0001805385-25-000008:8k_2_02:49]
EVOLV TECHNOLOGY

[0001805385-25-000008:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001805385-25-000008:8k_2_02:51]
(In thousands)

[0001805385-25-000008:8k_2_02:52]
(Unaudited)

[0001805385-25-000008:8k_2_02:53]
|  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (42,224) |  |  | $ | (7,854) |  |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |
| Depreciation and amortization | 11,318 |  |  | 7,358 |  |
| Write-off of inventory and change in inventory reserve | 1,794 |  |  | 1,725 |  |
| Loss on disposal of property and equipment | 1,633 |  |  | — |  |
| Stock-based compensation | 10,426 |  |  | 13,857 |  |
| Amortization of premium on marketable securities, net of change in accrued interest | 127 |  |  | 181 |  |
| Non-cash lease expense | 844 |  |  | 728 |  |
| Change in allowance for expected credit losses | 166 |  |  | 203 |  |
| Change in fair value of earn-out liability | 5,224 |  |  | (23,413) |  |
| Change in fair value of contingently issuable common stock | 2,247 |  |  | (4,274) |  |
| Change in fair value of public warrant liability | 3,582 |  |  | (7,037) |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable | (13,325) |  |  | (14,067) |  |
| Inventory | 6,141 |  |  | (10,042) |  |
| Commission assets | 73 |  |  | (521) |  |
| Contract assets | (236) |  |  | 237 |  |
| Other assets | 197 |  |  | 337 |  |
| Prepaid expenses and other current assets | (18,849) |  |  | (2,957) |  |
| Accounts payable | 6,120 |  |  | (1,653) |  |
| Deferred revenue | 6,205 |  |  | 10,271 |  |
| Accrued expenses and other current liabilities | 18,374 |  |  | (46) |  |
| Operating lease liability | (263) |  |  | (765) |  |
| Net cash used in operating activities | (426) |  |  | (37,732) |  |
| Cash flows from investing activities: |  |  |  |
| Development of internal-use software | (3,112) |  |  | (3,112) |  |
| Purchases of property and equipment | (15,299) |  |  | (21,618) |  |
| Purchases of marketable securities | (9,875) |  |  | (14,567) |  |
| Proceeds from maturities of marketable securities | 24,675 |  |  | 44,918 |  |
| Net cash (used in) provided by investing activities | (3,611) |  |  | 5,621 |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from exercise of stock options | 4,095 |  |  | 636 |  |
| Net cash provided by financing activities | 4,095 |  |  | 636 |  |
| Effect of exchange rate changes on cash and cash equivalents | (131) |  |  | 11 |  |
| Net decrease in cash, cash equivalents and restricted cash | (73) |  |  | (31,464) |  |
| Cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | 37,015 |  |  | 67,437 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 36,942 |  |  | $ | 35,973 |  |

[0001805385-25-000008:8k_2_02:54]
EVOLV TECHNOLOGY

[0001805385-25-000008:8k_2_02:55]
SUMMARY OF KEY OPERATING STATISTICS

[0001805385-25-000008:8k_2_02:56]
(Unaudited)

[0001805385-25-000008:8k_2_02:57]
|  | Three Months Ended or as of, |
| ($ in thousands) |  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  | June 30,2025 |  |  |  |  |
| New customers |  | 53 |  |  | 84 |  |  | 52 |  |  | 60 |  |  | 54 |  |  | 63 |  |  |  |  |  |
| Annual recurring revenue |  | $ | 79,192 |  |  | $ | 87,011 |  |  | $ | 93,676 |  |  | $ | 99,351 |  |  | $ | 105,990 |  |  | $ | 110,516 |  |  |  |  |  |
| Recurring revenue |  | $ | 18,961 |  |  | $ | 21,016 |  |  | $ | 23,764 |  |  | $ | 23,678 |  |  | $ | 25,753 |  |  | $ | 26,678 |  |  |  |  |  |

[0001805385-25-000008:8k_2_02:58]
.

[0001805385-25-000008:8k_2_02:59]
EVOLV TECHNOLOGY

[0001805385-25-000008:8k_2_02:60]
RECONCILIATION OF GAAP OPERATING EXPENSES TO ADJUSTED OPERATING EXPENSES

[0001805385-25-000008:8k_2_02:61]
(In thousands)

[0001805385-25-000008:8k_2_02:62]
(Unaudited)

[0001805385-25-000008:8k_2_02:63]
|  | Three Months Ended, |
|  |  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  | June 30,2025 |  |  |  |  |
|  |  | (Restated) |  | (Restated) |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses, GAAP |  | $ | 34,061 |  |  | $ | 37,128 |  |  | $ | 34,961 |  |  | $ | 35,619 |  |  | $ | 33,539 |  |  | $ | 33,711 |  |  |  |  |  |
| Stock-based compensation |  | (6,292) |  |  | (7,254) |  |  | (7,263) |  |  | (3,159) |  |  | (4,660) |  |  | (5,265) |  |  |  |  |  |
| Loss on impairment of leased equipment |  | — |  |  | — |  |  | (209) |  |  | (15) |  |  | — |  |  | — |  |  |  |  |  |
| Non-recurring restructuring and other employee separation costs |  | — |  |  | (1,000) |  |  | — |  |  | (2,060) |  |  | (2,137) |  |  | (827) |  |  |  |  |  |
| Other non-recurring legal and regulatory costs |  | (476) |  |  | (2,185) |  |  | (2,339) |  |  | (7,284) |  |  | (3,561) |  |  | (5,979) |  |  |  |  |  |
| Adjusted operating expenses |  | $ | 27,293 |  |  | $ | 26,689 |  |  | $ | 25,150 |  |  | $ | 23,101 |  |  | $ | 23,181 |  |  | $ | 21,640 |  |  |  |  |  |

[0001805385-25-000008:8k_2_02:64]
EVOLV TECHNOLOGY

[0001805385-25-000008:8k_2_02:65]
RECONCILIATION OF GAAP GROSS PROFIT TO ADJUSTED GROSS PROFIT, GAAP GROSS MARGIN TO ADJUSTED GROSS MARGIN AND GAAP INCOME (LOSS) FROM OPERATIONS TO ADJUSTED INCOME (LOSS) FROM OPERATIONS

[0001805385-25-000008:8k_2_02:66]
(In thousands)

[0001805385-25-000008:8k_2_02:67]
(Unaudited)

[0001805385-25-000008:8k_2_02:68]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Revenue | $ | 32,544 |  |  | $ | 25,224 |  |  | $ | 64,551 |  |  | $ | 47,405 |  |
| Cost of revenue | 16,326 |  |  | 10,467 |  |  | 29,183 |  |  | 20,493 |  |
| Gross profit, GAAP | 16,218 |  |  | 14,757 |  |  | 35,368 |  |  | 26,912 |  |
| Stock-based compensation | 282 |  |  | 173 |  |  | 501 |  |  | 311 |  |
| Amortization of capitalized stock-based compensation | 107 |  |  | 15 |  |  | 210 |  |  | 29 |  |
| Loss on disposal of leased equipment | 1,255 |  |  | — |  |  | 1,255 |  |  | — |  |
| Non-recurring restructuring and other employee separation costs | 6 |  |  | — |  |  | 6 |  |  | — |  |
| Non-recurring inventory charges | — |  |  | (68) |  |  | — |  |  | 1,136 |  |
| Adjusted gross profit | $ | 17,868 |  |  | $ | 14,877 |  |  | $ | 37,340 |  |  | $ | 28,388 |  |
| Gross margin % | 49.8 | % |  | 58.5 | % |  | 54.8 | % |  | 56.8 | % |
| Adjusted gross margin % | 54.9 | % |  | 59.0 | % |  | 57.8 | % |  | 59.9 | % |

[0001805385-25-000008:8k_2_02:69]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Loss from operations, GAAP | $ | (17,493) |  |  | $ | (22,371) |  |  | $ | (31,882) |  |  | $ | (44,277) |  |
| Stock-based compensation | 5,547 |  |  | 7,427 |  |  | 10,426 |  |  | 13,857 |  |
| Amortization of capitalized stock-based compensation | 107 |  |  | 15 |  |  | 210 |  |  | 29 |  |
| Loss on disposal of leased equipment | 1,255 |  |  | — |  |  | 1,255 |  |  | — |  |
| Non-recurring restructuring and other employee separation costs | 833 |  |  | 1,000 |  |  | 2,970 |  |  | 1,000 |  |
| Non-recurring inventory charges | — |  |  | (68) |  |  | — |  |  | 1,136 |  |
| Other non-recurring legal and regulatory costs | 5,979 |  |  | 2,185 |  |  | 9,540 |  |  | 2,661 |  |
| Adjusted loss from operations | $ | (3,772) |  |  | $ | (11,812) |  |  | $ | (7,481) |  |  | $ | (25,594) |  |

[0001805385-25-000008:8k_2_02:70]
EVOLV TECHNOLOGY

[0001805385-25-000008:8k_2_02:71]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA AND NET PROFIT MARGIN TO ADJUSTED EBITDA MARGIN

[0001805385-25-000008:8k_2_02:72]
(In thousands)

[0001805385-25-000008:8k_2_02:73]
(Unaudited)

[0001805385-25-000008:8k_2_02:74]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Net (loss) income | $ | (40,535) |  |  | $ | 3,418 |  |  | $ | (42,224) |  |  | $ | (7,854) |  |
| Depreciation & amortization | 5,788 |  |  | 3,901 |  |  | 11,318 |  |  | 7,358 |  |
| Stock-based compensation | 5,547 |  |  | 7,427 |  |  | 10,426 |  |  | 13,857 |  |
| Interest expense (income) | (224) |  |  | (681) |  |  | (612) |  |  | (1,766) |  |
| Provision for income taxes | (1) |  |  | — |  |  | 62 |  |  | — |  |
| Change in fair value of contingent earn-out liability | 14,200 |  |  | (16,514) |  |  | 5,224 |  |  | (23,413) |  |
| Change in fair value of contingently issuable common stock liability | 3,900 |  |  | (3,747) |  |  | 2,247 |  |  | (4,274) |  |
| Change in fair value of public warrant liability | 5,303 |  |  | (4,886) |  |  | 3,582 |  |  | (7,037) |  |
| Loss on disposal of leased equipment | 1,255 |  |  | — |  |  | 1,255 |  |  | — |  |
| Non-recurring restructuring and other employee separation costs | 833 |  |  | 1,000 |  |  | 2,970 |  |  | 1,000 |  |
| Non-recurring inventory charges | — |  |  | (68) |  |  | — |  |  | 1,136 |  |
| Other non-recurring legal and regulatory costs | 5,979 |  |  | 2,185 |  |  | 9,540 |  |  | 2,661 |  |
| Adjusted EBITDA | $ | 2,045 |  |  | $ | (7,965) |  |  | $ | 3,788 |  |  | $ | (18,332) |  |
| Net profit margin % | (124.6) | % |  | 13.6 | % |  | (65.4) | % |  | (16.6) | % |
| Impact of adjustments from Net loss to Adjusted EBITDA | 130.8 | % |  | (45.2) | % |  | 71.3 | % |  | (22.1) | % |
| Adjusted EBITDA margin % | 6.3 | % |  | (31.6) | % |  | 5.9 | % |  | (38.7) | % |

[0001805385-25-000008:8k_2_02:75]
EVOLV TECHNOLOGY

[0001805385-25-000008:8k_2_02:76]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EARNINGS (LOSS)

[0001805385-25-000008:8k_2_02:77]
(In thousands, except share and per share data)

[0001805385-25-000008:8k_2_02:78]
(Unaudited)

[0001805385-25-000008:8k_2_02:79]
|  | Three Months EndedJune 30, |  | Six Months EndedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  |  | (Restated) |  |  |  | (Restated) |
| Net (loss) income | $ | (40,535) |  |  | $ | 3,418 |  |  | $ | (42,224) |  |  | $ | (7,854) |  |
| Stock-based compensation | 5,547 |  |  | 7,427 |  |  | 10,426 |  |  | 13,857 |  |
| Amortization of capitalized stock-based compensation | 107 |  |  | 15 |  |  | 210 |  |  | 29 |  |
| Change in fair value of contingent earn-out liability | 14,200 |  |  | (16,514) |  |  | 5,224 |  |  | (23,413) |  |
| Change in fair value of contingently issuable common stock liability | 3,900 |  |  | (3,747) |  |  | 2,247 |  |  | (4,274) |  |
| Change in fair value of public warrant liability | 5,303 |  |  | (4,886) |  |  | 3,582 |  |  | (7,037) |  |
| Loss on disposal of leased equipment | 1,255 |  |  | — |  |  | 1,255 |  |  | — |  |
| Non-recurring restructuring and other employee separation costs | 833 |  |  | 1,000 |  |  | 2,970 |  |  | 1,000 |  |
| Non-recurring inventory charges | — |  |  | (68) |  |  | — |  |  | 1,136 |  |
| Other non-recurring legal and regulatory costs | 5,979 |  |  | 2,185 |  |  | 9,540 |  |  | 2,661 |  |
| Adjusted loss | $ | (3,411) |  |  | $ | (11,170) |  |  | $ | (6,770) |  |  | $ | (23,895) |  |
| Weighted average common shares outstanding – diluted | 165,252,554 |  |  | 171,563,943 |  |  | 163,042,749 |  |  | 154,774,899 |  |
| Adjusted loss per share – diluted | $ | (0.02) |  |  | $ | (0.07) |  |  | $ | (0.04) |  |  | $ | (0.15) |  |

[0001805385-25-000008:8k_2_02:80]
*Stock-based compensation, amortization of capitalized stock-based compensation, and non-recurring restructuring and other employee separation costs were recorded in the condensed consolidated statements of operations and comprehensive loss (income) as follows. Prior period amounts are being shown for comparative purposes:

[0001805385-25-000008:8k_2_02:81]
|  | Three Months Ended, |
|  | March 31,2024 |  | June 30,2024 |  | September 30,2024 |  | December 31,2024 |  | March 31,2025 |  | June 30,2025 |  |  |  |  |
| Stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenue | $ | — |  |  | $ | 5 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |  | $ | 17 |  |  |  |  |  |
| Cost of subscription revenue | 91 |  |  | 110 |  |  | 169 |  |  | 154 |  |  | 137 |  |  | 167 |  |  |  |  |  |
| Cost of service revenue | 44 |  |  | 51 |  |  | 63 |  |  | 61 |  |  | 67 |  |  | 74 |  |  |  |  |  |
| Cost of license fee and other revenue | 3 |  |  | 7 |  |  | 8 |  |  | 10 |  |  | 7 |  |  | 24 |  |  |  |  |  |
| Research and development | 902 |  |  | 1,222 |  |  | 1,243 |  |  | 1,153 |  |  | 1,115 |  |  | 1,154 |  |  |  |  |  |
| Sales and marketing | 2,959 |  |  | 2,724 |  |  | 2,516 |  |  | 2,747 |  |  | 1,048 |  |  | 1,710 |  |  |  |  |  |
| General and administrative | 2,431 |  |  | 3,308 |  |  | 3,504 |  |  | (741) |  |  | 1,972 |  |  | 2,401 |  |  |  |  |  |
| Restructuring costs | — |  |  | — |  |  | — |  |  | — |  |  | 525 |  |  | — |  |  |  |  |  |
| Total stock-based compensation | $ | 6,430 |  |  | $ | 7,427 |  |  | $ | 7,507 |  |  | $ | 3,392 |  |  | $ | 4,879 |  |  | $ | 5,547 |  |  |  |  |  |
| Amortization of capitalized stock-based compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of subscription revenue | $ | 8 |  |  | $ | 8 |  |  | $ | 13 |  |  | $ | 47 |  |  | $ | 59 |  |  | $ | 60 |  |  |  |  |  |
| Cost of service revenue | 6 |  |  | 7 |  |  | 10 |  |  | 38 |  |  | 44 |  |  | 47 |  |  |  |  |  |
| Total amortization of capitalized stock-based compensation | $ | 14 |  |  | $ | 15 |  |  | $ | 23 |  |  | $ | 85 |  |  | $ | 103 |  |  | $ | 107 |  |  |  |  |  |
| Non-recurring restructuring and other employee separation costs: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of service revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |  |  |  |  |
| Research and development | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 31 |  |  |  |  |  |
| Sales and marketing | — |  |  | 140 |  |  | — |  |  | 63 |  |  | — |  |  | 613 |  |  |  |  |  |
| General and administrative | — |  |  | — |  |  | — |  |  | 1,997 |  |  | — |  |  | 183 |  |  |  |  |  |
| Restructuring costs | — |  |  | 860 |  |  | — |  |  | — |  |  | 2,137 |  |  | — |  |  |  |  |  |
| Total non-recurring restructuring and other employee separation costs | $ | — |  |  | $ | 1,000 |  |  | $ | — |  |  | $ | 2,060 |  |  | $ | 2,137 |  |  | $ | 833 |  |  |  |  |  |

## item 5.02 — body, verbatim

[0001805385-25-000008:8k_body:1]
Item 5.02    Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001805385-25-000008:8k_body:2]
(b) On August 13, 2025, Mr. Michael Ellenbogen, Chief Innovation Officer and a member of the Board of Directors (the “Board”) of the Company, informed the Company that he would be resigning as Chief Innovation Officer, effective as of September 5, 2025, citing new time commitments. Mr. Ellenbogen’s decision to resign is not due any disagreements with the Company. Mr. Ellenbogen will continue to serve as a member of the Board and will be eligible to receive compensation as a non-employee director pursuant to the Company's Director Compensation Policy.
