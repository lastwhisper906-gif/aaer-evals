# NTAP notes — 0001193125-14-325455


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-14-325455:notes:1]
Basis of Presentation and Preparation

[0001193125-14-325455:notes:2]
Our
 fiscal year is reported on a 52- or 53-week year ending on the last
 Friday in April. The first quarters of fiscal 2015 and 2014 were
 each 13-week periods.

[0001193125-14-325455:notes:3]
The
 accompanying unaudited condensed consolidated financial statements
 have been prepared by the Company, and reflect all adjustments,
 consisting only of normal recurring adjustments, that are, in the
 opinion of management, necessary for the fair presentation of our
 financial position, results of operations, comprehensive income and
 cash flows for the interim periods presented. The statements have
 been prepared in accordance with accounting principles generally
 accepted in the United States of America (GAAP) for interim
 financial information and in accordance with the instructions to
 Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these
 statements do not include all information and footnotes required by
 GAAP for annual consolidated financial statements, and should be
 read in conjunction with our audited consolidated financial
 statements as of and for the fiscal year ended April 25, 2014
 contained in our Annual Report on Form 10-K filed with the
 Securities and Exchange Commission on June 17, 2014. The
 results of operations for the three months ended July 25, 2014
 are not necessarily indicative of the operating results to be
 expected for the full fiscal year or future operating
 periods.

[0001193125-14-325455:notes:4]
The
 preparation of the condensed consolidated financial statements in
 conformity with GAAP requires management to make estimates and
 assumptions that affect the reported amounts of assets and
 liabilities and disclosure of contingent assets and liabilities at
 the date of the financial statements and the reported amounts of
 revenues and expenses during the reporting periods. Such estimates
 include, but are not limited to, revenue recognition, reserves and
 allowances; inventory valuation and purchase order accruals;
 valuation of goodwill and intangibles; restructuring reserves;
 product warranties; employee benefit accruals; stock-based
 compensation; loss contingencies; investment impairments; income
 taxes and fair value measurements. Actual results could differ
 materially from those estimates.

[0001193125-14-325455:notes:5]
There
 have been no significant changes in our significant accounting
 policies as of and for the three months ended July 25, 2014,
 as compared to the significant accounting policies described in our
 Annual Report on Form 10-K for the fiscal year ended April 25,
 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-325455:notes:6]
14.  Commitments and Contingencies

[0001193125-14-325455:notes:7]
Operating Lease Commitments

[0001193125-14-325455:notes:8]
We lease various equipment, vehicles and office space in the
 U.S. and internationally. As of July 25, 2014, future annual
 minimum lease payments under non-cancelable operating leases with
 an initial term in excess of one year totaled $213.6
 million.

[0001193125-14-325455:notes:9]
Purchase Orders and Other Commitments

[0001193125-14-325455:notes:10]
In the ordinary course of business we make commitments to
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that product
 forecasts are not achieved, our commitments and associated accruals
 may change. As of July 25, 2014, we had $239.3 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product revenues. As of
 July 25, 2014 and April 25, 2014, such liability amounted
 to $10.4 million and $11.5 million, respectively, and is included
 in other current liabilities in our condensed consolidated balance
 sheets.

[0001193125-14-325455:notes:11]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course of business for
 which we have not received goods or services. As of July 25,
 2014, we had $36.4 million in capital purchase commitments and
 $180.2 million in other purchase commitments.

[0001193125-14-325455:notes:12]
Product Warranties

[0001193125-14-325455:notes:13]
We generally provide customers a warranty on software of ninety
 days and a warranty on hardware of three years. The following table
 summarizes the activity related to product warranty liabilities (in
 millions):

[0001193125-14-325455:notes:14]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Balance at beginning of period |  | $ | 110.0 |  |  | $ | 117.2 |  |
| Expense accrued during the period |  |  | 10.5 |  |  |  | 24.0 |  |
| Warranty costs incurred |  |  | (16.4 | ) |  |  | (21.4 | ) |
| Balance at end of period |  | $ | 104.1 |  |  | $ | 119.8 |  |
| Product warranty liabilities were reported in our condensed consolidated balance sheets as follows (in millions): |  |
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Other current liabilities |  | $ | 68.8 |  |  | $ | 73.0 |  |
| Other long-term liabilities |  |  | 35.3 |  |  |  | 37.0 |  |
| Total |  | $ | 104.1 |  |  | $ | 110.0 |  |

[0001193125-14-325455:notes:15]
Financing Guarantees

[0001193125-14-325455:notes:16]
Some of our customers have entered into recourse and
 non-recourse financing leasing arrangements using third-party
 financing companies, and in some situations, we enter into customer
 financing arrangements for our products and services that are
 contemporaneously sold on a recourse or non-recourse basis to
 third-party financing companies. Under the terms of recourse
 leases, which are generally three years or less, we remain liable
 for the aggregate unpaid remaining lease payments to the
 third-party leasing companies in the event of end-user customer
 default. These arrangements are generally collateralized by a
 security interest in the underlying assets. Under the terms of the
 non-recourse leases, we do not have any continuing obligations or
 liabilities to the third-party financing companies. Where we
 provide a guarantee for recourse leases, we defer revenues subject
 to the industry-specific software revenue recognition guidance, and
 recognize revenues for non-software deliverables in accordance with
 our multiple deliverable revenue arrangement policy. In connection
 with certain recourse financing arrangements, we receive advance
 payments associated with undelivered elements that are subject to
 customer refund rights. We defer revenue associated with these
 advance payments until the related refund rights expire and we
 perform the services.

[0001193125-14-325455:notes:17]
The following schedule of financing guarantees represents the
 total maximum potential future payments under financing
 arrangements with third parties and the related deferred revenue
 (in millions):

[0001193125-14-325455:notes:18]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Maximum guaranteed payment contingencies |  | $ | 213.2 |  |  | $ | 205.8 |  |
| Deferred revenue associated with financing guarantees |  |  | (196.8 | ) |  |  | (193.1 | ) |
| Net amount |  | $ | 16.4 |  |  | $ | 12.7 |  |

[0001193125-14-325455:notes:19]
To date, we have not experienced material losses under our
 lease financing programs or other financing
 arrangements.

[0001193125-14-325455:notes:20]
Legal Contingencies

[0001193125-14-325455:notes:21]
When a loss is considered probable and reasonably estimable, we
 record a liability in the amount of our best estimate for the
 ultimate loss. However, the likelihood of a loss with respect to a
 particular contingency is often difficult to predict, and
 determining a meaningful estimate of the loss or a range of loss
 may not be practicable based on the information available and the
 potential effect of future events and decisions by third parties
 that will determine the ultimate resolution of the
 contingency.

[0001193125-14-325455:notes:22]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of July 25, 2014 related to such matters as they
 are not probable and/or reasonably estimable.


## us-gaap:DebtDisclosureTextBlock

[0001193125-14-325455:notes:23]
7.  Financing
 Arrangements

[0001193125-14-325455:notes:24]
Long-term Debt

[0001193125-14-325455:notes:25]
The following table summarizes the carrying value of our
 long-term debt (in millions):

[0001193125-14-325455:notes:26]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.9 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,494.1 |  |  |  |  |  |  | $ | 995.5 |  |  |  |  |  |

[0001193125-14-325455:notes:27]
N/A - Not
 Applicable

[0001193125-14-325455:notes:28]
Senior Notes

[0001193125-14-325455:notes:29]
On June 5, 2014 we issued $500.0 million aggregate par
 value of 3.375% Senior Notes, with a maturity date of June 15,
 2021, and received proceeds of approximately $494.7 million, net of
 discount and issuance costs, which will be used for general
 corporate purposes, including possible stock repurchases,
 dividends, capital expenditures, working capital and potential
 acquisitions and strategic transactions. Our 2.00% Senior Notes and
 3.25% Senior Notes, with a par value of $750.0 million and $250.0
 million, respectively, were issued in December 2012. We
 collectively refer to such long-term debt as our Senior Notes.
 Interest on our Senior Notes is paid semi-annually on June 15
 and December 15. Our Senior Notes, which are unsecured,
 unsubordinated obligations, rank equally in right of payment with
 any future senior unsecured indebtedness.

[0001193125-14-325455:notes:30]
We may redeem the Senior Notes in whole or in part at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of July 25, 2014,
 we were in compliance with all covenants associated with the Senior
 Notes.

[0001193125-14-325455:notes:31]
As of July 25, 2014, our aggregate future principal debt
 maturities are as follows (in millions):

[0001193125-14-325455:notes:32]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750.0 |  |
| Thereafter |  |  | 750.0 |  |
| Total |  | $ | 1,500.0 |  |

[0001193125-14-325455:notes:33]
Credit Facility

[0001193125-14-325455:notes:34]
In December 2012, we entered into a credit agreement with a
 syndicated group of lenders that is scheduled to expire on
 December 21, 2017 and provides for an unsecured $250.0 million
 revolving credit facility that is comprised of revolving loans,
 Eurocurrency loans and/or swingline loans. The credit facility
 includes a $100.0 million foreign currency sub-facility, a $50.0
 million letter of credit sub-facility and a $10.0 million swingline
 sub-facility available on same-day notice. Available borrowings
 under the credit facility are reduced by the amount of any
 outstanding borrowings on the sub-facilities. We may also, subject
 to certain requirements, request an increase in the facility up
 to an additional $100.0 million and request two additional
 one-year extensions, subject to certain conditions. The proceeds
 from the facility may be used by us for general corporate
 purposes.

[0001193125-14-325455:notes:35]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility contains financial covenants requiring us to maintain a
 maximum leverage ratio of not more than 3.0:1.0 and a minimum
 interest coverage ratio of not less than 3.5:1.0. The facility
 contains customary affirmative and negative covenants, including
 covenants that limit our ability to incur debt secured by liens on
 assets or indebtedness of our subsidiaries and to consolidate,
 merge or sell all or substantially all of our assets. As of
 July 25, 2014, no borrowings were outstanding under the
 facility and we were in compliance with all covenants associated
 with the facility.

[0001193125-14-325455:notes:36]
Other Long-Term Financing Arrangements

[0001193125-14-325455:notes:37]
The following presents the amounts due under other long-term
 financing arrangements (in millions):

[0001193125-14-325455:notes:38]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 14.3 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (7.1 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 7.2 |  |  | $ | 6.5 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-325455:notes:39]
12. Net Income per
 Share

[0001193125-14-325455:notes:40]
The following
 is a calculation of basic and diluted net income per share (in
 millions, except per share amounts):

[0001193125-14-325455:notes:41]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 88.4 |  |  | $ | 81.6 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 323.5 |  |  |  | 350.9 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 5.6 |  |  |  | 6.9 |  |
| Dilutive impact of assumed conversion of Convertible Notes |  |  | 0.0 |  |  |  | 2.1 |  |
| Shares used in diluted computation |  |  | 329.1 |  |  |  | 359.9 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.27 |  |  | $ | 0.23 |  |
| Diluted |  | $ | 0.27 |  |  | $ | 0.23 |  |

[0001193125-14-325455:notes:42]
The following potential weighted-average shares of common stock
 have been excluded from the diluted net income per share
 calculations, as their effect would have been anti-dilutive (in
 millions):

[0001193125-14-325455:notes:43]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Employee equity award plans |  |  | 8.5 |  |  |  | 6.6 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-14-325455:notes:44]
[same as prior period, unchanged from 0001193125-14-069692:notes:114]

[0001193125-14-325455:notes:45]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| United States |  | $ | 1,005.3 |  |  | $ | 1,021.4 |  |
| International |  |  | 92.7 |  |  |  | 87.4 |  |
| Total |  | $ | 1,098.0 |  |  | $ | 1,108.8 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-14-325455:notes:46]
The following table summarizes our financial assets and
 liabilities measured at fair value on a recurring basis (in
 millions):

[0001193125-14-325455:notes:47]
|  |  | July 25, 2014 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 1,913.9 |  |  | $ | 0.0 |  |  | $ | 1,913.9 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 227.3 |  |  |  | 161.9 |  |  |  | 65.4 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 174.5 |  |  |  | 0.0 |  |  |  | 174.5 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 370.3 |  |  |  | 0.0 |  |  |  | 370.3 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 26.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 26.4 |  |
| Equity funds |  |  | 33.5 |  |  |  | 33.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 3.2 |  |  |  | 0.0 |  |  |  | 3.2 |  |  |  | 0.0 |  |
| Total |  | $ | 2,749.1 |  |  | $ | 195.4 |  |  | $ | 2,527.3 |  |  | $ | 26.4 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | (0.7 | ) |  | $ | 0.0 |  |  | $ | (0.7 | ) |  | $ | 0.0 |  |


## us-gaap:ScheduleOfShareBasedCompensationRestrictedStockUnitsAwardActivityTableTextBlock

[0001193125-14-325455:notes:48]
The following table summarizes activity related to our
 restricted stock units (RSUs) (in millions, except for fair
 value):

[0001193125-14-325455:notes:49]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 25, 2014 |  |  | 13.2 |  |  | $ | 38.35 |  |
| Granted |  |  | 5.3 |  |  |  | 34.93 |  |
| Vested |  |  | (2.9 | ) |  |  | 38.79 |  |
| Forfeited |  |  | (0.7 | ) |  |  | 38.14 |  |
| Outstanding as of July 25, 2014 |  |  | 14.9 |  |  |  | 37.06 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001193125-14-325455:notes:50]
|  |  | ESPP |  |
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Expected term in years |  |  | 1.3 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.2 | % |  |  | 0.2 | % |
| Volatility |  |  | 27 | % |  |  | 32 | % |
| Dividend yield |  |  | 1.8 | % |  |  | 1.6 | % |
| Weighted-average fair value per right granted |  | $ | 9.71 |  |  | $ | 10.53 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001193125-14-325455:notes:51]
The fair value of stock options and ESPP purchase rights is
 estimated on the grant date using the Black-Scholes option pricing
 model and the following underlying weighted-average
 assumptions:

[0001193125-14-325455:notes:52]
|  |  | Stock Options |  |
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  |  | 1.6 | % |  |  | 1.0 | % |
| Volatility |  |  | 29 | % |  |  | 34 | % |
| Dividend yield |  |  | 1.8 | % |  |  | 1.6 | % |
| Weighted-average fair value per share granted |  | $ | 8.19 |  |  | $ | 9.78 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-14-325455:notes:53]
The following is a summary of our investments (in
 millions):

[0001193125-14-325455:notes:54]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
|  |  |  |  |  | Gross Unrealized |  |  |  |  |  |  |  |  | Gross Unrealized |  |  |  |  |
|  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |
| Corporate bonds |  | $ | 1,905.8 |  |  | $ | 8.5 |  |  | $ | (0.4 | ) |  | $ | 1,913.9 |  |  | $ | 2,142.3 |  |  | $ | 10.5 |  |  | $ | (0.5 | ) |  | $ | 2,152.3 |  |
| U.S. Treasury and government debt securities |  |  | 227.1 |  |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 227.3 |  |  |  | 263.4 |  |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 263.6 |  |
| Commercial paper |  |  | 174.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 174.5 |  |  |  | 168.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 168.4 |  |
| Certificates of deposit |  |  | 370.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 370.3 |  |  |  | 245.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 245.0 |  |
| Auction rate securities |  |  | 26.9 |  |  |  | 0.0 |  |  |  | (0.5 | ) |  |  | 26.4 |  |  |  | 36.9 |  |  |  | 0.0 |  |  |  | (0.9 | ) |  |  | 36.0 |  |
| Equity funds |  |  | 33.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 33.5 |  |  |  | 32.7 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 32.7 |  |
| Total debt and equity securities |  | $ | 2,738.1 |  |  | $ | 8.8 |  |  | $ | (1.0 | ) |  | $ | 2,745.9 |  |  | $ | 2,888.7 |  |  | $ | 10.8 |  |  | $ | (1.5 | ) |  | $ | 2,898.0 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-325455:notes:55]
[same as prior period, unchanged from 0001193125-14-069692:notes:56]

[0001193125-14-325455:notes:56]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Purchased components |  | $ | 17.1 |  |  | $ | 17.6 |  |
| Finished goods |  |  | 87.1 |  |  |  | 104.8 |  |
| Inventories |  | $ | 104.2 |  |  | $ | 122.4 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0001193125-14-325455:notes:57]
Activities related to these plans are summarized as follows (in
 millions):

[0001193125-14-325455:notes:58]
|  |  | Three Months Ended July 25, 2014 |  |  | Three Months Ended July 26, 2013 |  |
|  |  | (March 2014 Plan) |  |  | (May 2013 Plan) |  |
| Balance at beginning of period |  | $ | 26.5 |  |  | $ | 0.0 |  |
| Net charges |  |  | 0.0 |  |  |  | 48.4 |  |
| Cash payments |  |  | (21.6 | ) |  |  | (24.6 | ) |
| Balance at end of period |  | $ | 4.9 |  |  | $ | 23.8 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-14-325455:notes:59]
[same as prior period, unchanged from 0001193125-14-069692:notes:50]

[0001193125-14-325455:notes:60]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 25, 2014 |  |  | 14.5 |  |  | $ | 34.10 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.0 |  |  |  | 36.29 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (0.5 | ) |  |  | 23.60 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (0.2 | ) |  |  | 41.43 |  |  |  |  |  |  |  |  |  |
| Outstanding as of July 25, 2014 |  |  | 15.8 |  |  |  | 34.68 |  |  |  | 3.75 |  |  | $ | 93.1 |  |
| Vested and expected to vest as of July 25, 2014 |  |  | 15.0 |  |  |  | 34.58 |  |  |  | 3.63 |  |  |  | 91.6 |  |
| Exercisable as of July 25, 2014 |  |  | 10.4 |  |  |  | 33.33 |  |  |  | 2.63 |  |  |  | 81.1 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-325455:notes:61]
13.  Segment,
 Geographic, and Significant Customer Information

[0001193125-14-325455:notes:62]
We operate in one industry segment: the design, manufacturing,
 marketing, and technical support of high-performance networked
 storage solutions. We conduct business globally, and our sales and
 support activities are managed on a geographic basis. Our
 management reviews financial information presented on a
 consolidated basis, accompanied by disaggregated information it
 receives from its internal management system about revenues by
 geographic region, based on the location from which the customer
 relationship is managed, for purposes of allocating resources and
 evaluating financial performance. We do not allocate costs of
 revenues, research and development, sales and marketing, or general
 and administrative expenses to our geographic regions in this
 internal management reporting because management does not review
 operations or operating results, or make planning decisions, below
 the consolidated entity level.

[0001193125-14-325455:notes:63]
Summarized revenues by geographic region based on information
 from our internal management system and utilized by our Chief
 Executive Officer, who is considered our Chief Operating Decision
 Maker, is as follows (in millions):

[0001193125-14-325455:notes:64]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Americas (United States, Canada and Latin America) |  | $ | 831.2 |  |  | $ | 858.5 |  |
| Europe, Middle East and Africa |  |  | 444.9 |  |  |  | 448.0 |  |
| Asia Pacific |  |  | 213.1 |  |  |  | 209.7 |  |
| Net revenues |  | $ | 1,489.2 |  |  | $ | 1,516.2 |  |

[0001193125-14-325455:notes:65]
Americas revenues consist of sales to Americas commercial and
 U.S. public sector markets. Sales to customers inside the United
 States comprised $746.2 million and $772.8 million of Americas net
 revenues during the three months ended July 25, 2014 and
 July 26, 2013, respectively. No single foreign country
 accounted for 10% or more of our net revenues for any period
 presented.

[0001193125-14-325455:notes:66]
[same as prior period, unchanged from 0001193125-14-069692:notes:179]

[0001193125-14-325455:notes:67]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| United States |  | $ | 1,089.6 |  |  | $ | 688.5 |  |
| International |  |  | 4,514.4 |  |  |  | 4,360.9 |  |
| Total |  | $ | 5,604.0 |  |  | $ | 5,049.4 |  |

[0001193125-14-325455:notes:68]
[same as prior period, unchanged from 0001193125-14-069692:notes:180]

[0001193125-14-325455:notes:69]
The following customers, each of which is a distributor,
 accounted for 10% or more of our net revenues:

[0001193125-14-325455:notes:70]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 21 | % |
| Avnet, Inc. |  |  | 16 | % |  |  | 16 | % |

[0001193125-14-325455:notes:71]
The following customers accounted for 10% or more of net
 accounts receivable:

[0001193125-14-325455:notes:72]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Arrow Electronics, Inc. |  |  | 12 | % |  |  | 14 | % |
| Avnet, Inc. |  |  | 11 | % |  |  | 16 | % |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001193125-14-325455:notes:73]
8.  Stockholders’ Equity

[0001193125-14-325455:notes:74]
[same as prior period, unchanged from 0001193125-14-069692:notes:126]

[0001193125-14-325455:notes:75]
[same as prior period, unchanged from 0001193125-14-069692:notes:127]

[0001193125-14-325455:notes:76]
Additional information related to our stock options is
 summarized below (in millions):

[0001193125-14-325455:notes:77]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Intrinsic value of exercises |  | $ | 7.2 |  |  | $ | 27.4 |  |
| Proceeds received from exercises |  | $ | 13.4 |  |  | $ | 56.8 |  |
| Fair value of options vested |  | $ | 8.7 |  |  | $ | 12.0 |  |

[0001193125-14-325455:notes:78]
[same as prior period, unchanged from 0001193125-14-069692:notes:128]

[0001193125-14-325455:notes:79]
[same as prior period, unchanged from 0001193125-14-069692:notes:131]

[0001193125-14-325455:notes:80]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Shares withheld for taxes |  |  | 0.9 |  |  |  | 0.9 |  |
| Fair value of shares withheld |  | $ | 33.9 |  |  | $ | 35.3 |  |

[0001193125-14-325455:notes:81]
[same as prior period, unchanged from 0001193125-14-069692:notes:133]

[0001193125-14-325455:notes:82]
The following table summarizes activity related to the purchase
 rights issued under the Employee Stock Purchase Plan (ESPP) (in
 millions):

[0001193125-14-325455:notes:83]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Shares issued under the ESPP |  |  | 1.9 |  |  |  | 2.0 |  |
| Proceeds from issuance of shares |  | $ | 48.9 |  |  | $ | 49.9 |  |

[0001193125-14-325455:notes:84]
[same as prior period, unchanged from 0001193125-14-069692:notes:136]

[0001193125-14-325455:notes:85]
[same as prior period, unchanged from 0001193125-14-069692:notes:137]

[0001193125-14-325455:notes:86]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Cost of product revenues |  | $ | 1.5 |  |  | $ | 1.3 |  |
| Cost of service revenues |  |  | 4.4 |  |  |  | 4.0 |  |
| Sales and marketing |  |  | 27.0 |  |  |  | 30.5 |  |
| Research and development |  |  | 21.5 |  |  |  | 21.4 |  |
| General and administrative |  |  | 7.9 |  |  |  | 9.1 |  |
| Total stock-based compensation expense |  | $ | 62.3 |  |  | $ | 66.3 |  |

[0001193125-14-325455:notes:87]
As of July 25, 2014, total unrecognized compensation
 expense related to our equity awards was $507.8 million, which is
 expected to be recognized on a straight-line basis over a
 weighted-average remaining service period of
 2.7 years.

[0001193125-14-325455:notes:88]
Total income tax benefit associated with employee stock
 transactions and recognized in stockholders’ equity were as
 follows (in millions):

[0001193125-14-325455:notes:89]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 43.4 |  |  | $ | 8.0 |  |

[0001193125-14-325455:notes:90]
[same as prior period, unchanged from 0001193125-14-069692:notes:142]

[0001193125-14-325455:notes:91]
[same as prior period, unchanged from 0001193125-14-069692:notes:145]

[0001193125-14-325455:notes:92]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Grant date fair value per share |  | $ | 34.93 |  |  | $ | 38.16 |  |
| Expected dividend |  |  | 1.8 | % |  |  | 1.6 | % |

[0001193125-14-325455:notes:93]
[same as prior period, unchanged from 0001193125-14-069692:notes:148]

[0001193125-14-325455:notes:94]
As of July 25, 2014, our Board of Directors has authorized
 the repurchase of up to $7.1 billion of our common stock. Under
 this program, which we may suspend or discontinue at any time, we
 may purchase shares of our outstanding common stock through open
 market and privately negotiated transactions at prices deemed
 appropriate by our management.

[0001193125-14-325455:notes:95]
The following table summarizes activity related to this program
 for the three months ended July 25, 2014 (in millions, except
 per share information):

[0001193125-14-325455:notes:96]
| Number of shares repurchased |  |  | 3.4 |  |
| Average price per share |  | $ | 34.82 |  |
| Aggregate purchase price |  | $ | 118.9 |  |
| Remaining authorization at end of period |  | $ | 1,005.9 |  |

[0001193125-14-325455:notes:97]
The aggregate purchase price of our stock repurchases for the
 three months ended July 25, 2014 consisted of $118.9 million
 of open market purchases, which was allocated to additional paid-in
 capital.

[0001193125-14-325455:notes:98]
[same as prior period, unchanged from 0001193125-14-069692:notes:156]

[0001193125-14-325455:notes:99]
The following is a summary of our activities related to
 dividends on our common stock (in millions, except per share
 amounts):

[0001193125-14-325455:notes:100]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Dividends per share declared and paid |  | $ | 0.165 |  |  | $ | 0.150 |  |
| Dividend payments allocated to retained earnings |  | $ | 53.4 |  |  | $ | 51.4 |  |

[0001193125-14-325455:notes:101]
On August 13, 2014, we declared a cash dividend of $0.165
 per share of common stock, payable on October 22, 2014 to
 holders of record as of the close of business on October 10,
 2014. The timing and amount of future dividends will depend on
 market conditions, corporate business and financial considerations
 and regulatory requirements. All dividends declared have been
 determined by the Company to be legally authorized under the laws
 of the state in which we are incorporated.

[0001193125-14-325455:notes:102]
[same as prior period, unchanged from 0001193125-14-069692:notes:158]

[0001193125-14-325455:notes:103]
A reconciliation of retained earnings for the three months
 ended July 25, 2014 is as follows (in millions):

[0001193125-14-325455:notes:104]
| Balance as of April 25, 2014 |  | $ | 1.1 |  |
| Net income |  |  | 88.4 |  |
| Dividends |  |  | (53.4 | ) |
| Balance as of July 25, 2014 |  | $ | 36.1 |  |

[0001193125-14-325455:notes:105]
[same as prior period, unchanged from 0001193125-14-069692:notes:159]

[0001193125-14-325455:notes:106]
Changes in accumulated other comprehensive income (AOCI) by
 component, net of tax, for the three months ended July 25,
 2014 are summarized below (in millions):

[0001193125-14-325455:notes:107]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains on Available- for-Sale Securities |  |  | Unrealized Gains on Derivative Instruments |  |  | Total |  |
| Balance as of April 25, 2014 |  | $ | 5.5 |  |  | $ | (4.8 | ) |  | $ | 8.9 |  |  | $ | (0.5 | ) |  | $ | 9.1 |  |
| Other comprehensive income (loss) (OCI) before reclassifications |  |  | (0.8 | ) |  |  | 1.0 |  |  |  | (1.6 | ) |  |  | (0.6 | ) |  |  | (2.0 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | 0.0 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 1.7 |  |  |  | 2.0 |  |
| Net OCI |  |  | (0.8 | ) |  |  | 1.1 |  |  |  | (1.4 | ) |  |  | 1.1 |  |  |  | 0.0 |  |
| Balance as of July 25, 2014 |  | $ | 4.7 |  |  | $ | (3.7 | ) |  | $ | 7.5 |  |  | $ | 0.6 |  |  | $ | 9.1 |  |

[0001193125-14-325455:notes:108]
The amounts reclassified out of AOCI are as follows (in
 millions):

[0001193125-14-325455:notes:109]
|  |  | Three Months Ended |  |  |  |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |  |  |  |
| OCI Components |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |  |
| Recognized losses on defined benefit obligations |  | $ | 0.1 |  |  | $ | 0.0 |  |  |  | Operating expenses |  |
| Realized (gains) losses on available-for-sale securities |  |  | 0.2 |  |  |  | (0.1 | ) |  |  | Other expense, net |  |
| Realized (gains) losses on cash flow hedges |  |  | 1.7 |  |  |  | (1.0 | ) |  |  | Net revenues |  |
| Total reclassifications |  | $ | 2.0 |  |  | $ | (1.1 | ) |  |  |  |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-14-325455:notes:110]
3.  Statements of Cash Flows

[0001193125-14-325455:notes:111]
[same as prior period, unchanged from 0001193125-14-069692:notes:103]

[0001193125-14-325455:notes:112]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 11.5 |  |  | $ | 17.7 |  |
| Acquisition of software through long-term financing |  | $ | 3.1 |  |  | $ | 10.6 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 68.2 |  |  | $ | 19.1 |  |
| Interest paid, net of capitalized interest |  | $ | 11.7 |  |  | $ | 23.0 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001193125-14-325455:notes:113]
The table below provides a reconciliation of the beginning and
 ending balance of our Level 3 ARSs measured at fair value on a
 recurring basis using significant unobservable inputs (in
 millions).

[0001193125-14-325455:notes:114]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Balance at beginning of period |  | $ | 36.0 |  |  | $ | 42.0 |  |
| Total unrealized gains, net included in other comprehensive income (loss) |  |  | 0.4 |  |  |  | 0.2 |  |
| Sales |  |  | (10.0 | ) |  |  | 0.0 |  |
| Balance at end of period |  | $ | 26.4 |  |  | $ | 42.2 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-14-325455:notes:115]
1.  Description
 of Business and Significant Accounting Policies

[0001193125-14-325455:notes:116]
NetApp, Inc. (we, us, or the Company) is a global provider of
 innovative storage and data management software, systems and
 services. Our storage solutions help customers create the flexible,
 efficient and highly available IT infrastructures they need to
 support their organizations. We are a storage and data management
 provider to enterprises of all sizes, service providers,
 governmental organizations and original equipment
 manufacturers.


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-14-325455:notes:117]
As of July 25, 2014, future amortization expense related
 to purchased intangible assets is as follows (in
 millions):

[0001193125-14-325455:notes:118]
| Fiscal Year |  | Amount |  |
| Remainder of 2015 |  | $ | 43.4 |  |
| 2016 |  |  | 53.6 |  |
| 2017 |  |  | 6.7 |  |
| 2018 |  |  | 3.3 |  |
| Total |  | $ | 107.0 |  |


## us-gaap:FairValueInputsAssetsQuantitativeInformationTableTextBlock

[0001193125-14-325455:notes:119]
Quantitative information about our Level 3 fair value
 measurements is as follows (fair value in millions):

[0001193125-14-325455:notes:120]
|  |  | Estimated Fair Value as of July 25, 2014 |  |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARSs |  | $ | 26.4 |  |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.7 yrs. – 9.4 yrs. (7.5 yrs.) |
|  |  |  |  |  |  |  |  | Illiquidity premium |  | 1.3% – 1.8% (1.5%) |
|  |  |  |  |  |  |  |  | Coupon rate |  | 1.1% – 1.8% (1.4%) |
|  |  |  |  |  |  | Market comparable securities |  | Discount rate |  | 1.0% – 2.0% (1.3%) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-14-325455:notes:121]
6.  Financial
 Instruments and Fair Value Measurements

[0001193125-14-325455:notes:122]
The accounting guidance for fair value measurements provides a
 framework for measuring fair value on either a recurring or
 nonrecurring basis, whereby the inputs used in valuation techniques
 are assigned a hierarchical level. The following are the three
 levels of inputs to measure fair value:

[0001193125-14-325455:notes:123]
[same as prior period, unchanged from 0001193125-14-069692:notes:71]

[0001193125-14-325455:notes:124]
[same as prior period, unchanged from 0001193125-14-069692:notes:72]

[0001193125-14-325455:notes:125]
[same as prior period, unchanged from 0001193125-14-069692:notes:73]

[0001193125-14-325455:notes:126]
[same as prior period, unchanged from 0001193125-14-069692:notes:74]

[0001193125-14-325455:notes:127]
[same as prior period, unchanged from 0001193125-14-069692:notes:75]

[0001193125-14-325455:notes:128]
The unrealized losses on our available-for-sale investments
 were caused by market value declines as a result of the economic
 environment, as well as fluctuations in market interest rates.
 Because the declines in market value are attributable to changes in
 market conditions and not credit quality, and because we have
 determined that (i) we do not have the intent to sell any of
 these investments and (ii) it is not more likely than not that
 we will be required to sell any of these investments before
 recovery of the entire amortized cost basis, we have concluded that
 no other-than-temporary impairments were required to be recognized
 on these investments as of July 25, 2014.

[0001193125-14-325455:notes:129]
The following table presents the contractual maturities of our
 debt investments as of July 25, 2014 (in millions):

[0001193125-14-325455:notes:130]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,413.8 |  |  | $ | 1,416.2 |  |
| Due in two through five years |  |  | 1,263.9 |  |  |  | 1,269.8 |  |
| Due after ten years* |  |  | 26.9 |  |  |  | 26.4 |  |
|  |  | $ | 2,704.6 |  |  | $ | 2,712.4 |  |

[0001193125-14-325455:notes:131]
| * | Consists of auction rate securities (ARSs) which have contractual maturities of greater than 10 years. |

[0001193125-14-325455:notes:132]
Actual maturities may differ from the contractual maturities
 because borrowers may have the right to call or prepay certain
 obligations.

[0001193125-14-325455:notes:133]
[same as prior period, unchanged from 0001193125-14-069692:notes:79]

[0001193125-14-325455:notes:134]
The following table summarizes the balance sheet
 classifications of our financial assets and liabilities measured at
 fair value on a recurring basis (in millions):

[0001193125-14-325455:notes:135]
|  |  | July 25, 2014 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 153.4 |  |  | $ | 0.0 |  |  | $ | 153.4 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 2,532.6 |  |  |  | 161.9 |  |  |  | 2,370.7 |  |  |  | 0.0 |  |
| Other current assets |  |  | 8.4 |  |  |  | 5.2 |  |  |  | 3.2 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 54.7 |  |  |  | 28.3 |  |  |  | 0.0 |  |  |  | 26.4 |  |
| Total |  | $ | 2,749.1 |  |  | $ | 195.4 |  |  | $ | 2,527.3 |  |  | $ | 26.4 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | (0.7 | ) |  | $ | 0.0 |  |  | $ | (0.7 | ) |  | $ | 0.0 |  |

[0001193125-14-325455:notes:136]
Level 2 investments are held by a custodian who prices some of
 the investments using standard inputs in various asset price models
 or obtains investment prices from a third-party pricing provider
 that incorporates standard inputs in various asset price models. We
 review Level 2 inputs and fair value for reasonableness and the
 values may be further validated by comparison to multiple
 independent pricing sources. In addition, we review third-party
 pricing provider models, key inputs and assumptions and understand
 the pricing processes at our third-party providers in determining
 the overall reasonableness of the fair value of our Level 2
 financial instruments. As of July 25, 2014, we have not made
 any adjustments to the prices obtained from our third-party pricing
 providers.

[0001193125-14-325455:notes:137]
All of our ARSs are classified as other non-current assets and
 are backed by pools of student loans guaranteed by the U.S.
 Department of Education. We estimate the fair value of each
 individual ARS using an income (discounted cash flow) and market
 approach that incorporate both observable and unobservable inputs.
 Key inputs into the discounted cash flow analysis include the
 time-to-economic maturity, illiquidity premium, (which factors in
 liquidity risk, market credit spread and other factors), and a
 coupon rate. The key input into the market approach is a discount
 rate. A significant increase (decrease) in the time-to-economic
 maturity, illiquidity premium, coupon rate, discount rate or other
 factors could result in a significantly lower (higher) fair value
 estimate. We review the fair value of our Level 3 financial
 instruments for overall reasonableness by reviewing service
 provider pricing methodologies, key inputs and assumptions and by
 understanding the processes used by our third-party service
 provider. We will continue to monitor our ARS investments in light
 of the asset-backed securities market environment and evaluate
 these investments for impairment and classification.

[0001193125-14-325455:notes:138]
[same as prior period, unchanged from 0001193125-14-069692:notes:88]

[0001193125-14-325455:notes:139]
As of July 25, 2014, the fair value of our long-term debt
 was approximately $1,506.4 million. The fair value of our debt was
 based on observable market prices in a less active market and
 discounted cash flow models that take into consideration variables
 such as credit-rating and interest rate changes. All of our debt
 obligations are categorized as Level 2 instruments.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001193125-14-325455:notes:140]
Purchased intangible assets, net are summarized below (in
 millions):

[0001193125-14-325455:notes:141]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
|  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |
| Developed technology |  | $ | 283.0 |  |  | $ | (176.9 | ) |  | $ | 106.1 |  |  | $ | 283.0 |  |  | $ | (162.6 | ) |  | $ | 120.4 |  |
| Customer contracts/relationships |  |  | 2.6 |  |  |  | (2.1 | ) |  |  | 0.5 |  |  |  | 9.6 |  |  |  | (9.0 | ) |  |  | 0.6 |  |
| Trademarks and trade names |  |  | 2.9 |  |  |  | (2.5 | ) |  |  | 0.4 |  |  |  | 2.9 |  |  |  | (2.4 | ) |  |  | 0.5 |  |
| Covenants not to compete |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.6 |  |  |  | (1.6 | ) |  |  | 0.0 |  |
| Total purchased intangible assets |  | $ | 288.5 |  |  | $ | (181.5 | ) |  | $ | 107.0 |  |  | $ | 297.1 |  |  | $ | (175.6 | ) |  | $ | 121.5 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001193125-14-325455:notes:142]
[same as prior period, unchanged from 0001193125-14-069692:notes:67]

[0001193125-14-325455:notes:143]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Auction rate securities |  | $ | 26.4 |  |  | $ | 36.0 |  |
| Deferred tax assets |  |  | 241.0 |  |  |  | 245.0 |  |
| Other assets |  |  | 263.8 |  |  |  | 248.5 |  |
| Other non-current assets |  | $ | 531.2 |  |  | $ | 529.5 |  |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-14-325455:notes:144]
The effect of derivative instruments not designated as hedging
 instruments recognized in other income, net on our condensed
 consolidated statements of operations was as follows (in
 millions):

[0001193125-14-325455:notes:145]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign exchange forward contracts |  | $ | (0.8 | ) |  | $ | 0.2 |  |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001193125-14-325455:notes:146]
Short-term and long-term deferred revenue (in
 millions):

[0001193125-14-325455:notes:147]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Product |  | $ | 31.9 |  |  | $ | 23.4 |  |
| Software entitlements and maintenance and service |  |  | 3,044.4 |  |  |  | 3,076.8 |  |
| Total |  | $ | 3,076.3 |  |  | $ | 3,100.2 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,656.4 |  |  | $ | 1,653.8 |  |
| Long-term |  |  | 1,419.9 |  |  |  | 1,446.4 |  |
| Total |  | $ | 3,076.3 |  |  | $ | 3,100.2 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-14-325455:notes:148]
9.  Derivatives and Hedging
 Activities

[0001193125-14-325455:notes:149]
[same as prior period, unchanged from 0001193125-14-069692:notes:62]

[0001193125-14-325455:notes:150]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 116.1 |  |  | $ | 122.6 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  |  | 167.6 |  |  |  | 155.5 |  |
| Forward contracts purchased |  |  | 270.6 |  |  |  | 389.9 |  |

[0001193125-14-325455:notes:151]
We have master netting arrangements in place to mitigate the
 credit risk of our counterparties and to potentially reduce our
 losses due to counterparty nonperformance. We present our
 derivative instruments as net amounts in our condensed consolidated
 balance sheets. The gross and net fair value amounts of such
 instruments were not material as of July 25, 2014 and
 April 25, 2014. We did not recognize any gains and losses in
 earnings due to hedge ineffectiveness for any period
 presented.

[0001193125-14-325455:notes:152]
The effect of derivative instruments designated as cash flow
 hedges recognized in net revenues on our condensed consolidated
 statements of operations is presented in the condensed consolidated
 statements of comprehensive income and Note 8.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001193125-14-325455:notes:153]
[same as prior period, unchanged from 0001193125-14-069692:notes:54]

[0001193125-14-325455:notes:154]
|  |  | Three Months Ended |  |  |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |  | Statements of Operations Classifications |
| Developed technology |  | $ | 14.3 |  |  | $ | 14.3 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 0.1 |  |  |  | 0.4 |  |  | Operating expenses |
| Trademarks and trade names |  |  | 0.1 |  |  |  | 0.1 |  |  | Operating expenses |
| Covenants not to compete |  |  | 0.0 |  |  |  | 0.1 |  |  | Operating expenses |
|  |  | $ | 14.5 |  |  | $ | 14.9 |  |  |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001193125-14-325455:notes:155]
Other current assets (in millions):

[0001193125-14-325455:notes:156]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Prepaid expenses and other current assets |  | $ | 240.7 |  |  | $ | 219.4 |  |
| Deferred tax assets |  |  | 253.6 |  |  |  | 270.3 |  |
| Other current assets |  | $ | 494.3 |  |  | $ | 489.7 |  |


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock

[0001193125-14-325455:notes:157]
A reconciliation of the beginning and ending amount of
 unrecognized tax benefits is as follows (in millions):

[0001193125-14-325455:notes:158]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Balance at beginning of period |  | $ | 235.9 |  |  | $ | 189.6 |  |
| Additions based on tax positions related to the current year |  |  | 6.8 |  |  |  | 7.2 |  |
| Additions for tax positions of prior years |  |  | 98.7 |  |  |  | 1.0 |  |
| Decreases for tax positions of prior years |  |  | (18.6 | ) |  |  | (3.5 | ) |
| Settlements |  |  | (45.5 | ) |  |  | 0.0 |  |
| Balance at end of period |  | $ | 277.3 |  |  | $ | 194.3 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-325455:notes:159]
11.  Income
 Taxes

[0001193125-14-325455:notes:160]
[same as prior period, unchanged from 0001193125-14-069692:notes:168]

[0001193125-14-325455:notes:161]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Effective tax rates |  |  | 44.6 | % |  |  | 11.6 | % |

[0001193125-14-325455:notes:162]
Our effective tax rates reflect the impact of a significant
 amount of our earnings being taxed in foreign jurisdictions at
 rates below the U.S. statutory tax rate. In addition, our effective
 tax rate for the three months ended July 25, 2014 was impacted
 by the settlement of an income tax audit as discussed
 below.

[0001193125-14-325455:notes:163]
In July 2014, the Internal Revenue Service (IRS) completed the
 examination of our fiscal 2005 to 2007 income tax returns upon
 approval by the Joint Committee of Taxation. We recorded a $47.4
 million income tax provision attributable to the audit settlement
 and related re-measurement of uncertain tax positions for tax years
 subject to future audits. The audit adjustments resulted in lower
 earnings in our foreign subsidiaries which reduced the taxability
 of dividends that were previously repatriated from such
 subsidiaries. As a result of this reduction in taxable dividends,
 we expect to receive a refund of $8.0 million, excluding interest,
 from the conclusion of the fiscal 2005 to 2007 income tax
 audit.

[0001193125-14-325455:notes:164]
As of July 25, 2014, we had $277.3 million of gross
 unrecognized tax benefits, of which $223.6 million has been
 recorded in other long-term liabilities. Unrecognized tax benefits
 of $172.9 million, including penalties, interest and indirect
 benefits, would affect our provision for income taxes if
 recognized.

[0001193125-14-325455:notes:165]
We are currently undergoing federal income tax audits in the
 United States and several foreign tax jurisdictions. Transfer
 pricing calculations are key issues under audits in various
 jurisdictions, and are often subject to dispute and appeals. The
 IRS is currently auditing our fiscal 2008 to 2010 income tax
 returns. We expect the IRS examination team to complete their field
 audit within the next twelve months. However, the resolution of the
 fiscal 2008 to 2010 income tax return audits may likely occur
 beyond the next twelve months should we choose to appeal the IRS
 examination team’s audit findings.

[0001193125-14-325455:notes:166]
[same as prior period, unchanged from 0001193125-14-069692:notes:173]

[0001193125-14-325455:notes:167]
[same as prior period, unchanged from 0001193125-14-069692:notes:175]


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-14-325455:notes:168]
[same as prior period, unchanged from 0001193125-14-069692:notes:65]

[0001193125-14-325455:notes:169]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Cash |  | $ | 2,878.2 |  |  | $ | 2,174.0 |  |
| Cash equivalents |  |  | 153.4 |  |  |  | 117.0 |  |
| Cash and cash equivalents |  | $ | 3,031.6 |  |  | $ | 2,291.0 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-14-325455:notes:170]
5.  Balance
 Sheet Details

[0001193125-14-325455:notes:171]
Property and equipment, net (in
 millions):

[0001193125-14-325455:notes:172]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Land |  | $ | 265.7 |  |  | $ | 265.7 |  |
| Buildings and building improvements |  |  | 605.7 |  |  |  | 541.7 |  |
| Leasehold improvements |  |  | 103.9 |  |  |  | 102.9 |  |
| Computer, production, engineering and other equipment |  |  | 768.3 |  |  |  | 753.8 |  |
| Software |  |  | 376.5 |  |  |  | 369.1 |  |
| Furniture and fixtures |  |  | 88.3 |  |  |  | 86.4 |  |
| Construction-in-progress |  |  | 14.0 |  |  |  | 72.9 |  |
|  |  |  | 2,222.4 |  |  |  | 2,192.5 |  |
| Accumulated depreciation and amortization |  |  | (1,124.4 | ) |  |  | (1,083.7 | ) |
| Property and equipment, net |  | $ | 1,098.0 |  |  | $ | 1,108.8 |  |

[0001193125-14-325455:notes:173]
The net book value of software, which includes capitalized
 internal-use software development costs, is summarized below (in
 millions):

[0001193125-14-325455:notes:174]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Computer software |  | $ | 96.6 |  |  | $ | 103.5 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-14-325455:notes:175]
4.  Purchased
 Intangible Assets, Net


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-14-325455:notes:176]
10.  Restructuring and Other
 Charges

[0001193125-14-325455:notes:177]
In May
 2013, we initiated a business restructuring plan under which we
 realigned internal resources, resulting in a reduction of our
 global workforce of approximately 7%. Such activities were
 completed in fiscal 2014. In March 2014, we initiated a business
 realignment plan designed to focus our resources on key strategic
 initiatives and streamline our business in light of the constrained
 IT spending environment, resulting in a reduction of our global
 workforce of approximately 4%. We expect such activities to be
 substantially completed in the second quarter of fiscal 2015.
 Restructuring and other charges consisted primarily of employee
 severance-related costs.

[0001193125-14-325455:notes:178]
The
 liability for our restructuring plans is included in accrued
 compensation and related benefits in our condensed consolidated
 balance sheets.
