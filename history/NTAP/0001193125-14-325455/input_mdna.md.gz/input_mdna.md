# NTAP MD&A — 0001193125-14-325455


## mdna

[0001193125-14-325455:mdna:1]
Item 2. Management’s Discussion and Analysis of
Financial Condition and Results of Operations.

[0001193125-14-325455:mdna:2]
Forward-Looking Statements

[0001193125-14-325455:mdna:3]
|  | • |  | our future financial and operating results; |

[0001193125-14-325455:mdna:4]
|  | • |  | our strategies; |

[0001193125-14-325455:mdna:5]
|  | • |  | our beliefs and objectives for future operations, research and development; |

[0001193125-14-325455:mdna:6]
|  | • |  | political, economic and industry trends; |

[0001193125-14-325455:mdna:7]
|  | • |  | expected timing of, customer acceptance of and benefits from, product introductions, developments and enhancements; |

[0001193125-14-325455:mdna:8]
|  | • |  | expected benefits from acquisitions and joint ventures, growth opportunities and investments; |

[0001193125-14-325455:mdna:9]
|  | • |  | expected outcomes from legal, regulatory and administrative proceedings; |

[0001193125-14-325455:mdna:10]
|  | • |  | our competitive position; |

[0001193125-14-325455:mdna:11]
|  | • |  | our short-term and long-term cash requirements, including without limitation, anticipated capital expenditures; |

[0001193125-14-325455:mdna:12]
|  | • |  | our anticipated tax rate; |

[0001193125-14-325455:mdna:13]
|  | • |  | the repayment of our 2.00% Senior Notes due on December 15, 2017, 3.375% Senior Notes due on June 15, 2021 and 3.25% Senior Notes due on December 15, 2022 (collectively referred to as the Senior Notes); |

[0001193125-14-325455:mdna:14]
|  | • |  | future uses of our cash, including, without limitation, the continuation of our stock repurchase and cash dividend programs. |

[0001193125-14-325455:mdna:15]
All forward-looking statements included in this document are inherently uncertain as they
are based on management’s current expectations and assumptions concerning future events, and are subject to numerous known and unknown risks and uncertainties. Therefore, actual events and results may differ materially from these
forward-looking statements. Factors that could cause actual results to differ materially from those described herein include, but are not limited to:

[0001193125-14-325455:mdna:16]
|  | • |  | the overall growth and structure of the data storage industry; |

[0001193125-14-325455:mdna:17]
|  | • |  | our ability to understand, and effectively respond to changes affecting, our market environment, products, technologies and customer requirements; |

[0001193125-14-325455:mdna:18]
|  | • |  | general global political, macroeconomic and market conditions; |

[0001193125-14-325455:mdna:19]
|  | • |  | our ability to accurately forecast demand for our products and services, and future financial performance; |

[0001193125-14-325455:mdna:20]
|  | • |  | our ability to successfully manage our backlog; |

[0001193125-14-325455:mdna:21]
|  | • |  | our ability to successfully execute on our strategy to generate profitable growth and stockholder return; |

[0001193125-14-325455:mdna:22]
|  | • |  | disruptions in our supply chain, which could limit our ability to ship products to our customers in the amounts and at the prices forecasted; |

[0001193125-14-325455:mdna:23]
22

[0001193125-14-325455:mdna:24]
|  | • |  | our ability to maintain our customer, partner, supplier and contract manufacturer relationships on favorable terms and conditions; |

[0001193125-14-325455:mdna:25]
|  | • |  | our ability to maintain our gross profit margins; |

[0001193125-14-325455:mdna:26]
|  | • |  | our ability to timely and successfully introduce and increase volumes of new products and services and to forecast demand and pricing for the same; |

[0001193125-14-325455:mdna:27]
|  | • |  | our ability to gain customer acceptance of new products; |

[0001193125-14-325455:mdna:28]
|  | • |  | the actions of our competitors, most of which are larger and have greater financial and other resources than we have, including, without limitation, their ability to introduce competitive products and to acquire businesses and technologies that negatively impact our strategy, operations or customer demand for our products; |

[0001193125-14-325455:mdna:29]
|  | • |  | the impact of industry consolidation affecting our suppliers, competitors, partners and customers; |

[0001193125-14-325455:mdna:30]
|  | • |  | our ability to grow direct and indirect sales and to efficiently provide global service and support; |

[0001193125-14-325455:mdna:31]
|  | • |  | our ability to design, manufacture and market products meeting global environmental standards; |

[0001193125-14-325455:mdna:32]
|  | • |  | failure of our products and services to meet our customers’ quality requirements, including, without limitation, any epidemic failure event relating to our systems installed by our customers in their IT infrastructures; |

[0001193125-14-325455:mdna:33]
|  | • |  | our ability to resolve ongoing litigation, tax audits, government audits, inquiries and investigations in line with our expectations; |

[0001193125-14-325455:mdna:34]
|  | • |  | the availability of acceptable financing to support our future cash requirements; |

[0001193125-14-325455:mdna:35]
|  | • |  | our ability to effectively integrate acquired businesses, products and technologies; |

[0001193125-14-325455:mdna:36]
|  | • |  | valuation and liquidity of our investment portfolio; |

[0001193125-14-325455:mdna:37]
|  | • |  | our ability to successfully recruit and retain critical employees and to manage our investment in people, process and systems; |

[0001193125-14-325455:mdna:38]
|  | • |  | our ability to anticipate techniques used to obtain unauthorized access or to sabotage systems and to implement adequate preventative measures against cybersecurity and other security breaches; and |

[0001193125-14-325455:mdna:39]
|  | • |  | those factors discussed under the heading “Risk Factors” elsewhere in this Quarterly Report on Form 10-Q. |

[0001193125-14-325455:mdna:40]
Readers are cautioned not to place undue reliance on these forward-looking statements, which speak only as of the date
hereof and are based upon information available to us at this time. These statements are not guarantees of future performance. We disclaim any obligation to update information in any forward-looking statement. Actual results could vary from our
forward-looking statements due to the foregoing factors as well as other important factors.

[0001193125-14-325455:mdna:41]
23

[0001193125-14-325455:mdna:42]
Overview

[0001193125-14-325455:mdna:43]
Financial Results and Key Performance Metrics Overview

[0001193125-14-325455:mdna:44]
The following table provides an overview of some of our key financial metrics (in millions, except per share amounts,
percentages and days sales outstanding):

[0001193125-14-325455:mdna:45]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |
| Net revenues |  | $ | 1,489.2 |  |  | $ | 1,516.2 |  |
| Gross profit |  | $ | 938.1 |  |  | $ | 909.6 |  |
| Gross profit margin percentage |  |  | 63.0 | % |  |  | 60.0 | % |
| Income from operations |  | $ | 159.9 |  |  | $ | 96.9 |  |
| Income from operations as a percentage of net revenues |  |  | 10.7 | % |  |  | 6.4 | % |
| Net income |  | $ | 88.4 |  |  | $ | 81.6 |  |
| Diluted net income per share |  | $ | 0.27 |  |  | $ | 0.23 |  |
| Operating cash flows |  | $ | 215.5 |  |  | $ | 285.8 |  |

[0001193125-14-325455:mdna:46]
|  |  | July 25,2014 |  |  | April 25,2014 |  |
| Deferred revenue |  | $ | 3,076.3 |  |  | $ | 3,100.2 |  |
| Days sales outstanding (DSO) |  |  | 36 |  |  |  | 47 |  |

[0001193125-14-325455:mdna:47]
3.375% Senior Notes due 2021

[0001193125-14-325455:mdna:48]
On June 5, 2014 we issued $500.0 million aggregate par value of 3.375% Senior Notes, with a maturity date of
June 15, 2021 and received proceeds of $494.7 million, net of discount and issuance costs, which will be used for general corporate purposes, including possible stock repurchases, dividends, capital expenditures, working capital and potential
acquisitions and strategic transactions.

[0001193125-14-325455:mdna:49]
Critical Accounting Policies and Estimates

[0001193125-14-325455:mdna:50]
Our condensed consolidated financial statements have been prepared in accordance with accounting principles generally
accepted in the United States of America, which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and
liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and
liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0001193125-14-325455:mdna:51]
The summary of significant accounting policies is included under Item 7, “Management’s Discussion and
Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended April 25, 2014. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on
assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial
statements. There have been no material changes to the critical accounting policies and estimates as filed in such report.

[0001193125-14-325455:mdna:52]
New Accounting Standards

[0001193125-14-325455:mdna:53]
See Note 2 of the accompanying condensed consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on
results of operations and financial condition.

[0001193125-14-325455:mdna:54]
Results of Operations

[0001193125-14-325455:mdna:55]
The following table sets forth certain Condensed Consolidated Statements of Operations data as a percentage of net
revenues for the periods indicated:

[0001193125-14-325455:mdna:56]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Product |  |  | 59.3 | % |  |  | 61.4 | % |
| Software entitlements and maintenance |  |  | 14.8 |  |  |  | 15.1 |  |
| Service |  |  | 25.9 |  |  |  | 23.5 |  |
| Net revenues |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 26.5 |  |  |  | 29.7 |  |
| Cost of software entitlements and maintenance |  |  | 0.5 |  |  |  | 0.5 |  |
| Cost of service |  |  | 10.0 |  |  |  | 9.8 |  |
| Gross profit |  |  | 63.0 |  |  |  | 60.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 32.3 |  |  |  | 30.9 |  |
| Research and development |  |  | 15.3 |  |  |  | 15.0 |  |
| General and administrative |  |  | 4.7 |  |  |  | 4.5 |  |
| Restructuring and other charges |  |  | — |  |  |  | 3.2 |  |
| Total operating expenses |  |  | 52.3 |  |  |  | 53.6 |  |
| Income from operations |  |  | 10.7 |  |  |  | 6.4 |  |
| Other expense, net |  |  | — |  |  |  | (0.3 | ) |
| Income before income taxes |  |  | 10.7 |  |  |  | 6.1 |  |
| Provision for income taxes |  |  | 4.8 |  |  |  | 0.7 |  |
| Net income |  |  | 5.9 | % |  |  | 5.4 | % |

[0001193125-14-325455:mdna:57]
Discussion and Analysis of Results of Operations

[0001193125-14-325455:mdna:58]
Overview

[0001193125-14-325455:mdna:59]
Net revenues for the three months ended July 25, 2014 were $1,489.2 million, down $27.0 million, or 2%, compared to the three months ended July 26, 2013, reflecting a decrease in product and
software entitlements and maintenance (SEM) revenues, partially offset by an increase in hardware maintenance contract revenues.

[0001193125-14-325455:mdna:60]
Gross profit as a percentage of net revenues increased 3% during the three months ended July 25, 2014, compared to the three months ended July 26, 2013, primarily due to lower average unit
materials costs due to product mix, partially offset by a lower average selling price (ASP) for all configured systems platforms. Additionally, gross profit was favorably impacted by lower OEM revenues and higher margins on service revenues.

[0001193125-14-325455:mdna:61]
Sales and marketing, research and development, and general and administrative expenses for the three months
ended July 25, 2014 totaled $778.2 million, up 2% as a percentage of net revenues, compared to the three months ended July 26, 2013, primarily due to increases in compensation costs.

[0001193125-14-325455:mdna:62]
Net Revenues (in millions, except percentages):

[0001193125-14-325455:mdna:63]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Net revenues |  | $ | 1,489.2 |  |  | $ | 1,516.2 |  |  |  | (2 | )% |

[0001193125-14-325455:mdna:64]
The decrease in net revenues for the three months ended July 25, 2014 was primarily
due to a decrease in product and SEM revenues of $48.2 million and $7.2 million, respectively, partially offset by an increase in service revenues of $28.4 million. Product revenues comprised 59% of net revenues for the three months ended
July 25, 2014 compared to 61% of net revenues for the three months ended July 26, 2013.

[0001193125-14-325455:mdna:65]
Sales through our indirect channels represented 79% of net revenues for the
three months ended July 25, 2014, compared to 80% of net revenues for the three months ended July 26, 2013. Included in indirect channel sales were $128.7 million and $166.5 million of OEM revenue during the three months ended
July 25, 2014 and July 26, 2013, respectively.

[0001193125-14-325455:mdna:66]
The following customers, each of which is a
distributor, accounted for 10% or more of net revenues:

[0001193125-14-325455:mdna:67]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 21 | % |
| Avnet, Inc. |  |  | 16 | % |  |  | 16 | % |

[0001193125-14-325455:mdna:68]
Product Revenues (in millions, except percentages):

[0001193125-14-325455:mdna:69]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Product revenues |  | $ | 882.6 |  |  | $ | 930.8 |  |  |  | (5 | )% |

[0001193125-14-325455:mdna:70]
Product revenues consist of configured systems, which include bundled hardware and
software products, and non-configured products, which consist primarily of add-on storage, OEM products and add-on hardware and software products.

[0001193125-14-325455:mdna:71]
Total configured system revenues of $526.2 million decreased by $10.8 million for the three months ended July 25, 2014 compared to the three months ended July 26, 2013. Revenues from FAS
mid-range, high-end systems and E-Series (which includes our all flash EF systems) increased, offset by decreases in FAS entry level systems. Total configured systems unit volume decreased 2% during the three months ended July 25, 2014,
compared to the three months ended July 26, 2013, primarily due to a unit volume decrease in the FAS entry level systems, partially offset by increases in unit volume of the FAS mid-range and high-end systems and E Series systems. These changes
in unit volume reflect a shift in customer demand to our newer FAS mid-range and high-end products and higher demand for our E-Series systems, and away from our older FAS entry level systems. The average selling prices (ASPs) decreased across all
FAS system and E Series platforms in the three months ended July 25, 2014, compared to the three months ended July 26, 2013, due to higher demand of newer lower priced products within their respective platform. However, overall ASPs of
configured systems were relatively flat during the three months ended July 25, 2014 compared to the corresponding period in the prior year due to favorable product mix towards higher priced platforms.

[0001193125-14-325455:mdna:72]
Non-configured product revenues of $356.4 million decreased $37.4 million, or 10%, during the three months ended
July 25, 2014 compared to the three months ended July 26, 2013. This decrease was primarily due to lower revenues from non-configured OEM products, which declined 23%, and add-on storage, which declined 13%, but was partially offset by a
82% increase in revenues from add-on software. The decrease in add-on storage and increase in add-on software are largely due to the change in our pricing strategy that was effective in the fourth quarter of fiscal 2014, whereby we now charge for
operating system software for storage capacity but have lowered prices on storage hardware.

[0001193125-14-325455:mdna:73]
Our systems are
highly configurable to respond to customer requirements in the open systems storage markets that we serve. This can cause a wide variation in product configurations that can significantly impact revenues, cost of revenues and gross profits. Pricing
changes, discounting practices, product competition, foreign currency, unit volumes, customer mix, natural disasters and product materials costs can also impact revenues, cost of revenues and/or gross profits. Disks are a significant component of
our storage systems. While our sales price per terabyte historically declines over time, improved system performance, increased capacity and software to manage this increased capacity have an offsetting favorable impact on product revenues.

[0001193125-14-325455:mdna:74]
Software Entitlements and Maintenance Revenues (in millions, except percentages):

[0001193125-14-325455:mdna:75]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Software entitlements and maintenance revenues |  | $ | 221.3 |  |  | $ | 228.5 |  |  |  | (3 | )% |

[0001193125-14-325455:mdna:76]
SEM revenues are associated with contracts which entitle customers to receive unspecified
product upgrades and enhancements on a when-and-if-available basis, as well as bug fixes and patch releases.

[0001193125-14-325455:mdna:77]
26

[0001193125-14-325455:mdna:78]
The decrease in SEM revenues for the three months ended July 25, 2014
was due to a decrease in the aggregate contract value of the installed base under SEM contracts.

[0001193125-14-325455:mdna:79]
Service Revenues (in millions, except percentages):

[0001193125-14-325455:mdna:80]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Service revenues |  | $ | 385.3 |  |  | $ | 356.9 |  |  |  | 8 | % |

[0001193125-14-325455:mdna:81]
Service revenues include hardware maintenance, professional services, and educational and
training services.

[0001193125-14-325455:mdna:82]
Hardware maintenance contract revenues comprised 79% of service revenues for the three
months ended July 25, 2014, compared to 77% for the three months ended July 26, 2013. These revenues increased $29.2 million, or 11%, during the three months ended July 25, 2014, compared to the corresponding period in the prior year,
as a result of increases in the installed base and aggregate contract values under service contracts. Professional services and educational and training services comprised 21% and 23% of service revenues for the three months ended July 25, 2014
and July 26, 2013, respectively.

[0001193125-14-325455:mdna:83]
Revenues by Geographic Area (in millions, except percentages):

[0001193125-14-325455:mdna:84]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Americas (United States, Canada and Latin America) |  | $ | 831.2 |  |  | $ | 858.5 |  |  |  | (3 | )% |
| Europe, Middle East and Africa |  |  | 444.9 |  |  |  | 448.0 |  |  |  | (1 | )% |
| Asia Pacific |  |  | 213.1 |  |  |  | 209.7 |  |  |  | 2 | % |
| Net revenues |  | $ | 1,489.2 |  |  | $ | 1,516.2 |  |  |  |  |  |

[0001193125-14-325455:mdna:85]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets.
Sales to customers inside the United States comprised 90% of Americas net revenues during each of the three months ended July 25, 2014 and July 26, 2013. No single foreign country accounted for 10% or more of our net revenues for any
period presented.

[0001193125-14-325455:mdna:86]
Cost of Revenues

[0001193125-14-325455:mdna:87]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of
manufacturing and shipping our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of SEM, which includes the costs of providing SEM and third-party royalty costs and (3) cost
of service revenues, which includes costs associated with providing support activities for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001193125-14-325455:mdna:88]
Our gross profit is impacted by a variety of factors, including pricing changes, discounting practices, foreign currency,
product configuration, unit volumes, customer mix, revenue mix, natural disasters and product material costs. Service gross profit is typically impacted by factors such as changes in the size of our installed base of products, as well as the timing
of support service initiations and renewals, and incremental investments in our customer support infrastructure. If any of these factors that impact our gross profit are adversely affected, whether by economic uncertainties or for other reasons, our
gross profit could decline.

[0001193125-14-325455:mdna:89]
Cost of Product Revenues (in millions, except percentages):

[0001193125-14-325455:mdna:90]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Cost of product revenues |  | $ | 394.2 |  |  | $ | 449.9 |  |  |  | (12 | )% |

[0001193125-14-325455:mdna:91]
The changes in cost of product revenues consisted of the following (in percentage points
of the total change):

[0001193125-14-325455:mdna:92]
|  |  | Three Months EndedFiscal 2015 to Fiscal 2014Percentage ChangePoints |  |
| Materials cost |  |  | (8 | ) |
| Warranty |  |  | (3 | ) |
| Excess and obsolete inventory |  |  | (1 | ) |
| Total change |  |  | (12 | ) |

[0001193125-14-325455:mdna:93]
Cost of product revenues represented 45% and 48% of product revenues for the three months
ended July 25, 2014 and July 26, 2013, respectively.

[0001193125-14-325455:mdna:94]
Materials cost represented 85% and 83% of
product costs for the three months ended July 25, 2014 and July 26, 2013, respectively.

[0001193125-14-325455:mdna:95]
Materials
cost decreased $36.7 million in the three months ended July 25, 2014 compared to the three months ended July 26, 2013. Material costs were favorably impacted by a 2% unit volume decrease in configured systems in the three months ended
July 25, 2014, compared to the corresponding period of the prior year. The average unit materials costs decreased for our FAS entry level and mid-range systems, but increased for our FAS high-end and E Series systems. Our overall materials unit
cost for configured systems decreased due to favorable changes in product mix. Additionally, materials cost was favorably impacted by lower OEM product volume compared to the corresponding period in the prior year and to lower materials cost of
add-on hardware, partially offset by higher materials cost of add-on storage. As a result of these factors, we experienced higher gross margins on products in the three months ended July 25, 2014 compared to the three months ended July 26,
2013. In addition, cost of product revenues in the three months ended July 25, 2014 was favorably impacted by a $13.4 million decrease in warranty expense and a $3.7 million decrease in excess and obsolete inventory write-downs compared to the
corresponding period in the prior year.

[0001193125-14-325455:mdna:96]
Cost of Software Entitlements and Maintenance Revenues (in
millions, except percentages):

[0001193125-14-325455:mdna:97]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Cost of software entitlements and maintenance revenues |  | $ | 8.2 |  |  | $ | 7.5 |  |  |  | 9 | % |

[0001193125-14-325455:mdna:98]
Cost of SEM revenues increased primarily due to higher royalty costs in the three months
ended July 25, 2014 compared to the three months ended July 26, 2013. Cost of SEM revenues represented 4% and 3% of SEM revenues for the three months ended July 25, 2014 and July 26, 2013, respectively.

[0001193125-14-325455:mdna:99]
Cost of Service Revenues (in millions, except percentages):

[0001193125-14-325455:mdna:100]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Cost of service revenues |  | $ | 148.7 |  |  | $ | 149.2 |  |  |  | — | % |

[0001193125-14-325455:mdna:101]
Cost of service revenues were relatively flat during the three months ended July 25,
2014 compared to the three months ended July 26, 2013, primarily due to an increase in spares materials costs, largely offset by lower logistics, materials rework and service delivery costs. Costs represented 39% and 42% of service revenues for
the three months ended July 25, 2014 and July 26, 2013, respectively.

[0001193125-14-325455:mdna:102]
Operating Expenses

[0001193125-14-325455:mdna:103]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0001193125-14-325455:mdna:104]
Compensation costs comprise the largest component of operating expenses. Included in compensation costs
are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0001193125-14-325455:mdna:105]
Total compensation costs included in operating expenses increased $1.7 million for the three months ended July 25, 2014 compared to the corresponding period in the prior year, reflecting relatively
flat headcount compared to the prior year period.

[0001193125-14-325455:mdna:106]
Sales and Marketing (in millions, except percentages):

[0001193125-14-325455:mdna:107]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 480.2 |  |  | $ | 467.8 |  |  |  | 3 | % |

[0001193125-14-325455:mdna:108]
Sales and marketing expenses consist primarily of compensation costs, commissions,
outside services, allocated facilities and information technology costs, advertising and marketing promotional expense, and travel and entertainment expense. Sales and marketing expenses increased due to the following:

[0001193125-14-325455:mdna:109]
|  |  | Three Months EndedFiscal 2015 to Fiscal 2014Percentage ChangePoints |  |
| Commissions |  |  | 1 |  |
| Sales events |  |  | 1 |  |
| Other |  |  | 1 |  |
| Total change |  |  | 3 |  |

[0001193125-14-325455:mdna:110]
Commissions expense increased during the three months ended July 25, 2014 reflecting
higher bookings achievement compared to the corresponding period in the prior year. The increase in sales events represents activities to communicate the corporate strategy to the world-wide sales force at the beginning of fiscal 2015.

[0001193125-14-325455:mdna:111]
Research and Development (in millions, except percentages):

[0001193125-14-325455:mdna:112]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Research and development expenses |  | $ | 228.0 |  |  | $ | 228.1 |  |  |  | — | % |

[0001193125-14-325455:mdna:113]
Research and development expenses consist primarily of compensation costs, allocated
facilities and IT costs, depreciation, equipment and software-related costs, prototypes, non-recurring engineering charges and other outside services costs. Research and development expense increased (decreased) due to the following:

[0001193125-14-325455:mdna:114]
|  |  | Three Months EndedFiscal 2015 to Fiscal 2014Percentage ChangePoints |  |
| Compensation costs |  |  | 1 |  |
| Outside services |  |  | 1 |  |
| Development projects |  |  | (2 | ) |
| Total change |  |  | — |  |

[0001193125-14-325455:mdna:115]
The increase in compensation costs during the three months ended July 25, 2014 is
primarily due to higher incentive compensation, reflecting stronger operating performance against goals. Outside services expense during the three months ended July 25, 2014 increased due to higher spending on contractors. The decrease in
development projects expense during the three months ended July 25, 2014 reflects lower spending on materials and services associated with engineering activities to develop new product lines and enhancements to existing products.

[0001193125-14-325455:mdna:116]
We believe that our future performance will depend in large part on our ability to maintain and enhance our current
product line, develop new products that achieve market acceptance, maintain technological competitiveness and meet an expanding range of customer requirements. We expect to continue to spend on current and future product development efforts, broaden
our existing product offerings and introduce new products that expand our solutions portfolio.

[0001193125-14-325455:mdna:117]
General and
Administrative (in millions, except percentages):

[0001193125-14-325455:mdna:118]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| General and administrative expenses |  | $ | 70.0 |  |  | $ | 68.4 |  |  |  | 2 | % |

[0001193125-14-325455:mdna:119]
General and administrative expenses consist primarily of compensation costs,
professional and corporate legal fees, outside services and allocated facilities and IT support costs. General and administrative expense increased (decreased) due to the following:

[0001193125-14-325455:mdna:120]
|  |  | Three Months EndedFiscal 2015 to Fiscal 2014Percentage ChangePoints |  |
| Compensation costs |  |  | (1 | ) |
| Professional and legal fees and outside services |  |  | 2 |  |
| Bad debt expense |  |  | 1 |  |
| Total change |  |  | 2 |  |

[0001193125-14-325455:mdna:121]
The decrease in compensation costs for the three months ended July 25, 2014 is
primarily due to lower payroll taxes and stock-based compensation expense, partially offset by higher salaries, reflecting an increase in headcount, and incentive compensation expense, reflecting stronger operating performance against goals. The
increase in professional and legal fees and outside services for the three months ended July 25, 2014 reflects higher spending levels on contractors and professional services. Bad debt expense for the three months ended July 25, 2014
increased $1.0 million compared to the corresponding period in the prior year.

[0001193125-14-325455:mdna:122]
Restructuring and other
charges:

[0001193125-14-325455:mdna:123]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Restructuring and other charges |  | $ | — |  |  | $ | 48.4 |  |  |  | (100 | )% |

[0001193125-14-325455:mdna:124]
In March 2014 and May 2013, we initiated business realignment plans designed to focus our
resources on key strategic initiatives and streamline our business in light of the constrained IT spending environment, resulting in a reduction of our global workforce. The charges for the three months ended July 26, 2013 represent employee
severance costs recognized in connection with the May 2013 restructuring plan. We incurred no additional costs in connection with either of our restructuring plans in the three months ended July 25, 2014. We completed all activities under the
May 2013 plan during fiscal 2014, and expect to complete activities under the March 2014 plan in the second quarter of fiscal 2015, with no significant additional charges.

[0001193125-14-325455:mdna:125]
Other Income (Expense), Net

[0001193125-14-325455:mdna:126]
Interest Income (in millions, except percentages):

[0001193125-14-325455:mdna:127]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Interest income |  | $ | 8.3 |  |  | $ | 10.0 |  |  |  | (17 | )% |

[0001193125-14-325455:mdna:128]
The decrease in interest income during the three months ended July 25, 2014 was
primarily due to a decrease in our average investment portfolio compared to the corresponding prior year period.

[0001193125-14-325455:mdna:129]
Interest Expense (in millions, except percentages):

[0001193125-14-325455:mdna:130]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Interest expense |  | $ | (9.0 | ) |  | $ | (16.5 | ) |  |  | (45 | )% |

[0001193125-14-325455:mdna:131]
Interest expense, including the amortization of debt discount and issuance
costs, is related to our Senior Notes and Convertible Notes as summarized below:

[0001193125-14-325455:mdna:132]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |
| Senior Notes |  | $ | 8.8 |  |  | $ | 6.3 |  |
| Convertible Notes |  |  | — |  |  |  | 10.2 |  |
| Total |  | $ | 8.8 |  |  | $ | 16.5 |  |

[0001193125-14-325455:mdna:133]
The increase in interest expense related to our Senior Notes reflects the issuance of our
3.375% Senior Notes due 2021 in June 2014, and the decrease in interest expense related to our Convertible Notes reflects their maturity in June 2013.

[0001193125-14-325455:mdna:134]
Other Income, Net (in millions, except percentages):

[0001193125-14-325455:mdna:135]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Other income, net |  | $ | 0.5 |  |  | $ | 1.9 |  |  |  | (74 | )% |

[0001193125-14-325455:mdna:136]
The decrease in other income, net for the three months ended July 25, 2014 compared
to the corresponding period in the prior year is primarily due to higher net foreign exchange losses.

[0001193125-14-325455:mdna:137]
Provision for Income Taxes (in millions, except percentages):

[0001193125-14-325455:mdna:138]
|  |  | Three Months Ended |  |
|  |  | July 25,2014 |  |  | July 26,2013 |  |  | % Change |  |
| Provision for income taxes |  | $ | 71.3 |  |  | $ | 10.7 |  |  |  | 566 | % |

[0001193125-14-325455:mdna:139]
Our effective tax rate for the three months ended July 25, 2014 was 44.6% compared
to an effective tax rate of 11.6% for the three months ended July 26, 2013. Our effective tax rates reflect our corporate legal entity structure and the global nature of our business with a significant amount of our profits generated and taxed
in foreign jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates during the three months ended July 25, 2014 and July 26, 2013, respectively, were favorably impacted by the geographic mix of profits. Our
effective tax rate increased for the three months ended July 25, 2014 compared to the corresponding period in the prior year primarily as a result of the discrete provision charge related to the Internal Revenue Service (IRS) audit settlement
as discussed below. Higher pre-tax profits and a lapse of the federal research credit statute also contributed to the increase in the effective tax rate.

[0001193125-14-325455:mdna:140]
In July 2014, the IRS completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. We recorded a $47.4 million tax provision attributable to
the audit settlement and related re-measurement of uncertain tax positions for tax years subject to future audits. We expect to receive a refund of $8.0 million, excluding interest, from the conclusion of the fiscal 2005 to 2007 income tax audit.

[0001193125-14-325455:mdna:141]
As of July 25, 2014, we had $277.3 million of gross unrecognized tax benefits, of which $223.6 million
has been recorded in other long-term liabilities. Unrecognized tax benefits of $172.9 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized. During the three months ended
July 25, 2014, there was an increase in our unrecognized tax benefits of $6.8 million for tax positions related to the current year, a gross increase of $98.7 million and a gross decrease, including statute lapses, of $18.6 million for tax
positions related to prior years. We also recorded a gross decrease of $45.5 million related to settlements with taxing authorities during the period.

[0001193125-14-325455:mdna:142]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions.

[0001193125-14-325455:mdna:143]
Liquidity and Capital Resources

[0001193125-14-325455:mdna:144]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash flows on our
liquidity and capital resources. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting
the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our
cash equivalents or investments from the values reported as of July 25, 2014.

[0001193125-14-325455:mdna:145]
Liquidity, Capital Resources and Cash Requirements

[0001193125-14-325455:mdna:146]
| ($ in Millions) |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Cash and cash equivalents and short-term investments |  | $ | 5,564.2 |  |  | $ | 5,003.3 |  |
| Principal amount of Senior Notes |  |  | 1,500.0 |  |  |  | 1,000.0 |  |
| Debt as a % of stockholders’ equity |  |  | 39 | % |  |  | 26 | % |
| The following is a summary of our cash flow activities: |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  |
| (In Millions) |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Net cash provided by operating activities |  | $ | 215.5 |  |  | $ | 285.8 |  |
| Net cash provided by investing activities |  |  | 133.0 |  |  |  | 325.9 |  |
| Net cash provided by (used in) financing activities |  |  | 391.6 |  |  |  | (2,084.7 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 0.5 |  |  |  | (7.3 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 740.6 |  |  | $ | (1,480.3 | ) |

[0001193125-14-325455:mdna:147]
Cash Flows

[0001193125-14-325455:mdna:148]
As of July 25, 2014, our cash, cash equivalents and short-term investments increased by $0.6 billion from
April 25, 2014 to $5.6 billion. The increase was primarily due to $494.7 million of net proceeds received from the issuance of long-term debt and $215.5 million of cash provided by operating activities, partially offset by $118.9 million
in cash paid for the repurchase of our common stock. We derive our liquidity and capital resources primarily from our operating cash flows and from working capital. Accounts receivable days sales outstanding as of July 25, 2014 decreased to
36 days from 47 days as of April 25, 2014, reflecting historical seasonality in shipment linearity. Working capital increased by $570.5 million to $4.3 billion as of July 25, 2014 primarily as a result of the $560.9 million
increase in cash, cash equivalents and short-term investments.

[0001193125-14-325455:mdna:149]
Cash Flows from Operating Activities

[0001193125-14-325455:mdna:150]
During the three months ended July 25, 2014, we generated cash from operating activities of
$215.5 million. The primary sources of cash from operating activities during the three months ended July 25, 2014 consisted of net income of $88.4 million, adjusted by depreciation and amortization of $77.5 million, stock-based
compensation of $62.3 million and other adjustments to net income of $45.1 million, partially offset by excess tax benefit from stock-based compensation of $42.6 million.

[0001193125-14-325455:mdna:151]
Changes in assets and liabilities as of July 25, 2014 included the following:

[0001193125-14-325455:mdna:152]
|  | • |  | Accounts receivable decreased $271.5 million in the three months ended July 25, 2014 and decreased $265.2 million in the three months ended July 26, 2013, reflecting seasonally high collections, as well as seasonal improvement of shipment linearity, in the first quarter of our fiscal years compared to the fourth quarter of our fiscal years. |

[0001193125-14-325455:mdna:153]
|  | • |  | Accrued compensation and related benefits decreased $227.1 million due to employee compensation payouts related to fiscal year 2014 commissions, incentive compensation plans and restructuring obligations, compared to $175.4 million for the corresponding period of the prior year, reflecting higher incentive compensation plan payouts in the current period. |

[0001193125-14-325455:mdna:154]
We expect that cash provided by operating activities may materially fluctuate in future
periods as a result of a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, tax benefits or charges from stock-based
compensation, and the timing and amount of compensation and other payments.

[0001193125-14-325455:mdna:155]
Cash Flows from Investing
Activities

[0001193125-14-325455:mdna:156]
During the three months ended July 25, 2014, we generated $191.2 million from maturities
and sales of investments, net of purchases, and paid $58.4 million for capital expenditures, compared to $390.0 million and $65.3 million, respectively, in the corresponding period of the prior year.

[0001193125-14-325455:mdna:157]
Cash Flows from Financing Activities

[0001193125-14-325455:mdna:158]
During the three months ended July 25, 2014, we generated $494.7 million, net, from the issuance of long-term debt
and used $118.9 million for the repurchase of 3.4 million shares of our common stock and $53.4 million for the payment of dividends, compared to $849.5 million used for the repurchase of common stock and $51.4 million for the payment of
dividends in the corresponding period of the prior year. In addition, we repaid $1,264.9 million of our Convertible Debt in the prior year.

[0001193125-14-325455:mdna:159]
Liquidity

[0001193125-14-325455:mdna:160]
Our principal sources of liquidity as of
July 25, 2014 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001193125-14-325455:mdna:161]
Cash, cash equivalents and short-term investments consist of the following (in millions):

[0001193125-14-325455:mdna:162]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Cash and cash equivalents |  | $ | 3,031.6 |  |  | $ | 2,291.0 |  |
| Short-term investments |  |  | 2,532.6 |  |  |  | 2,712.3 |  |
| Total |  | $ | 5,564.2 |  |  | $ | 5,003.3 |  |

[0001193125-14-325455:mdna:163]
As of July 25, 2014 and April 25, 2014, $4.5 billion and $4.3 billion,
respectively, of cash, cash equivalents and short-term investments was held by various foreign subsidiaries and was generally based in U.S. dollar-denominated holdings, while $1.1 billion and $0.7 billion, respectively, was available in the United
States. Most of the amounts held outside the United States can be repatriated to the United States but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings for
cash requirements in the United States, we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carry forwards. However, our intent is to keep these funds permanently reinvested
outside of the United States, and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities,
fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001193125-14-325455:mdna:164]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to
effectively manage our working capital, in particular, accounts receivable and inventories, the timing and amount of stock repurchases and payment of cash dividends, our ability to effectively integrate acquired products, businesses and technologies
and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including potential future issuances of debt, equity or other securities, will satisfy our working
capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet
our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new
financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001193125-14-325455:mdna:165]
Our investment portfolio, including auction rate securities, has been and will continue to be exposed to market risk due
to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We utilize a variety of planning and financing strategies in an effort to ensure
our worldwide cash is available when and where it is needed. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and
committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends,
contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and
counterparties.

[0001193125-14-325455:mdna:166]
Senior Notes

[0001193125-14-325455:mdna:167]
The following table summarizes the principal amount of our Senior Notes as of July 25, 2014 (in millions):

[0001193125-14-325455:mdna:168]
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |
| 3.375% Senior Notes Due 2021 |  |  | 500.0 |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |
| Total |  | $ | 1,500.0 |  |

[0001193125-14-325455:mdna:169]
Interest on the Senior Notes is payable semi-annually. For further information on the
underlying terms, see Note 7 of the accompanying condensed consolidated financial statements.

[0001193125-14-325455:mdna:170]
Credit
Facility

[0001193125-14-325455:mdna:171]
Our credit facility, under which we may borrow up to $250.0 million, provides another potential
source of liquidity. The credit facility is an unsecured five-year revolving credit facility that terminates on December 21, 2017 if no extensions have been requested at that time, and contains financial covenants requiring us to maintain a
maximum leverage ratio and a minimum interest coverage ratio. We may also, subject to certain requirements, request an increase in the facility up to an additional $100.0 million and request two additional one-year extensions, subject to
certain conditions. As of July 25, 2014, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001193125-14-325455:mdna:172]
We also have an automatic shelf registration statement on file with the SEC. We may in the future offer an additional
unspecified amount of debt, equity and other securities.

[0001193125-14-325455:mdna:173]
Capital Expenditure Requirements

[0001193125-14-325455:mdna:174]
We expect to fund our capital expenditures, including our commitments related to facilities,
equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be
precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. Our
capital expenditures were $58.4 million during the three months ended July 25, 2014. We anticipate capital expenditures for the remainder of fiscal 2015 to be between $125.0 million and $175.0 million.

[0001193125-14-325455:mdna:175]
Dividends and Stock Repurchase Program

[0001193125-14-325455:mdna:176]
On August 13, 2014, we declared a cash dividend of $0.165 per share of common stock, payable on October 22,
2014 to holders of record as of the close of business on October 10, 2014.

[0001193125-14-325455:mdna:177]
Our Board of Directors has
authorized the repurchase of up to $7.1 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices
deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through July 25, 2014, we repurchased a total of 187.7 million shares of
our common stock at an average price of $32.59 per share, for an aggregate purchase price of $6.1 billion. As of July 25, 2014, the remaining authorized amount for stock repurchases under this program was $1.0 billion with no termination date,
which we plan to complete by May 2015.

[0001193125-14-325455:mdna:178]
The timing and amount of stock repurchase transactions and future
dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements.

[0001193125-14-325455:mdna:179]
Contractual Obligations

[0001193125-14-325455:mdna:180]
Operating Lease
Commitments

[0001193125-14-325455:mdna:181]
As of July 25, 2014, future annual minimum lease payments under non-cancelable operating
leases with an initial term in excess of one year totaled $213.6 million.

[0001193125-14-325455:mdna:182]
Purchase Orders and Other Commitments

[0001193125-14-325455:mdna:183]
In the ordinary course of business we make commitments to our third-party contract manufacturers, to manage manufacturer
lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that
such components will not be utilized in future operations. To the extent that product forecasts are not achieved, our commitments and associated accruals may change. As of July 25, 2014, we had $239.3 million in non-cancelable purchase
commitments with our contract manufacturers. In addition, we recorded a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to
cost of product revenues. As of July 25, 2014 and April 25, 2014, such liability amounted to $10.4 million and $11.5 million, respectively, and is included in other current liabilities in our condensed consolidated balance sheets.

[0001193125-14-325455:mdna:184]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders
and contractual obligations associated with our ordinary course of business for which we have not received goods or services. As of July 25, 2014, we had $36.4 million in capital purchase commitments and $180.2 million in other purchase
commitments.

[0001193125-14-325455:mdna:185]
Unrecognized Tax Benefits

[0001193125-14-325455:mdna:186]
As of July 25, 2014, our liability for uncertain tax positions was $202.7 million, including penalties,
interest and indirect benefits. Due to the uncertainty of the timing of future cash payments, we cannot make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001193125-14-325455:mdna:187]
Legal Contingencies

[0001193125-14-325455:mdna:188]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details
on such matters in Note 14 to our condensed consolidated financial statements.

[0001193125-14-325455:mdna:189]
Off-Balance Sheet
Arrangements

[0001193125-14-325455:mdna:190]
In the ordinary course of business, we provide standby letters of credit or other
guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As of July 25, 2014, our financial guarantees of $11.0 million that were not recorded on our consolidated balance sheet
consisted of standby letters of credit and surety bonds.

[0001193125-14-325455:mdna:191]
In the ordinary course of business, some of our
customers have entered into recourse and non-recourse financing leasing arrangements using third-party financing companies, and in some situations, we enter into customer financing arrangements for our products and services that are
contemporaneously sold on a recourse or non-recourse basis to third-party financing companies. During the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the
third-party leasing companies in the event of end-user customer default. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for
non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to
customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of July 25, 2014, the maximum guaranteed payment contingencies under our financing
arrangements totaled $213.2 million and the related deferred revenue totaled $196.8 million.

[0001193125-14-325455:mdna:192]
We enter into
indemnification agreements with third parties in the ordinary course of business. Generally, these indemnification agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or
copyright infringement. These indemnification obligations are considered off-balance sheet arrangements under accounting guidance.
