# NTAP note change history — 0001193125-14-069692 → 0001193125-14-325455


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-08-28):
[0001193125-14-325455:note_history:1]
We lease various equipment, vehicles and office space in the
 U.S. and internationally. As of July 25, 2014, future annual
 minimum lease payments under non-cancelable operating leases with
 an initial term in excess of one year totaled $213.6
 million.
  (was, 2014-02-26, similarity 0.7665):
[0001193125-14-069692:note_history:1]
As of January 24, 2014, future annual minimum lease
 payments under non-cancelable operating leases with an initial term
 in excess of one year totaled $216.1 million.

- added (2014-08-28):
[0001193125-14-325455:note_history:2]
In the ordinary course of business we make commitments to
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that product
 forecasts are not achieved, our commitments and associated accruals
 may change. As of July 25, 2014, we had $239.3 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product revenues. As of
 July 25, 2014 and April 25, 2014, such liability amounted
 to $10.4 million and $11.5 million, respectively, and is included
 in other current liabilities in our condensed consolidated balance
 sheets.

- changed (2014-08-28):
[0001193125-14-325455:note_history:3]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course of business for
 which we have not received goods or services. As of July 25,
 2014, we had $36.4 million in capital purchase commitments and
 $180.2 million in other purchase commitments.
  (was, 2014-02-26, similarity 0.9899):
[0001193125-14-069692:note_history:3]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course of business for
 which we have not received goods or services. As of
 January 24, 2014, we had $44.1 million in capital purchase
 commitments and $203.2 million in other purchase
 commitments.

- changed (2014-08-28):
[0001193125-14-325455:note_history:4]
We generally provide customers a warranty on software of ninety
 days and a warranty on hardware of three years. The following table
 summarizes the activity related to product warranty liabilities (in
 millions):
  (was, 2014-02-26, similarity 0.792):
[0001193125-14-069692:note_history:4]
We provide customers a warranty on software of ninety days to
 five years and a warranty on hardware of one to five years. The
 following table summarizes our warranty reserves (in
 millions):

- added (2014-08-28):
[0001193125-14-325455:note_history:5]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Balance at beginning of period |  | $ | 110.0 |  |  | $ | 117.2 |  |
| Expense accrued during the period |  |  | 10.5 |  |  |  | 24.0 |  |
| Warranty costs incurred |  |  | (16.4 | ) |  |  | (21.4 | ) |
| Balance at end of period |  | $ | 104.1 |  |  | $ | 119.8 |  |
| Product warranty liabilities were reported in our condensed consolidated balance sheets as follows (in millions): |  |
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Other current liabilities |  | $ | 68.8 |  |  | $ | 73.0 |  |
| Other long-term liabilities |  |  | 35.3 |  |  |  | 37.0 |  |
| Total |  | $ | 104.1 |  |  | $ | 110.0 |  |

- changed (2014-08-28):
[0001193125-14-325455:note_history:6]
Some of our customers have entered into recourse and
 non-recourse financing leasing arrangements using third-party
 financing companies, and in some situations, we enter into customer
 financing arrangements for our products and services that are
 contemporaneously sold on a recourse or non-recourse basis to
 third-party financing companies. Under the terms of recourse
 leases, which are generally three years or less, we remain liable
 for the aggregate unpaid remaining lease payments to the
 third-party leasing companies in the event of end-user customer
 default. These arrangements are generally collateralized by a
 security interest in the underlying assets. Under the terms of the
 non-recourse leases, we do not have any continuing obligations or
 liabilities to the third-party financing companies. Where we
 provide a guarantee for recourse leases, we defer revenues subject
 to the industry-specific software revenue recognition guidance, and
 recognize revenues for non-software deliverables in accordance with
 our multiple deliverable revenue arrangement policy. In connection
 with certain recourse financing arrangements, we receive advance
 payments associated with undelivered elements that are subject to
 customer refund rights. We defer revenue associated with these
 advance payments until the related refund rights expire and we
 perform the services.
  (was, 2014-02-26, similarity 0.9996):
[0001193125-14-069692:note_history:6]
Some of our customers have entered into recourse and
 non-recourse financing leasing arrangements using third-party
 financing companies, and in some situations, we enter into customer
 financing arrangements for our products and services that are
 contemporaneously sold on a recourse or non-recourse basis to
 third-party financing companies. Under the terms of recourse
 leases, which are generally three years or less, we remain liable
 for the aggregate unpaid remaining lease payments to the
 third-party leasing companies in the event of end-user customer
 default. These arrangements are generally collateralized by a
 security interest in the underlying assets. Under the terms of the
 nonrecourse leases, we do not have any continuing obligations or
 liabilities to the third-party financing companies. Where we
 provide a guarantee for recourse leases, we defer revenues subject
 to the industry-specific software revenue recognition guidance, and
 recognize revenues for non-software deliverables in accordance with
 our multiple deliverable revenue arrangement policy. In connection
 with certain recourse financing arrangements, we receive advance
 payments associated with undelivered elements that are subject to
 customer refund rights. We defer revenue associated with these
 advance payments until the related refund rights expire and we
 perform the services.

- changed (2014-08-28):
[0001193125-14-325455:note_history:7]
The following schedule of financing guarantees represents the
 total maximum potential future payments under financing
 arrangements with third parties and the related deferred revenue
 (in millions):
  (was, 2014-02-26, similarity 0.9975):
[0001193125-14-069692:note_history:7]
The following schedule of financing guarantees represents the
 total maximum potential future payments under financing
 arrangements with third parties, and the related deferred revenue
 (in millions):

- changed (2014-08-28):
[0001193125-14-325455:note_history:8]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Maximum guaranteed payment contingencies |  | $ | 213.2 |  |  | $ | 205.8 |  |
| Deferred revenue associated with financing guarantees |  |  | (196.8 | ) |  |  | (193.1 | ) |
| Net amount |  | $ | 16.4 |  |  | $ | 12.7 |  |
  (was, 2014-02-26, similarity 0.6749):
[0001193125-14-069692:note_history:8]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Other current liabilities |  | $ | 79.8 |  |  | $ | 81.6 |  |
| Other long-term liabilities |  |  | 37.3 |  |  |  | 35.6 |  |
| Total |  | $ | 117.1 |  |  | $ | 117.2 |  |

- changed (2014-08-28):
[0001193125-14-325455:note_history:9]
When a loss is considered probable and reasonably estimable, we
 record a liability in the amount of our best estimate for the
 ultimate loss. However, the likelihood of a loss with respect to a
 particular contingency is often difficult to predict, and
 determining a meaningful estimate of the loss or a range of loss
 may not be practicable based on the information available and the
 potential effect of future events and decisions by third parties
 that will determine the ultimate resolution of the
 contingency.
  (was, 2014-02-26, similarity 0.999):
[0001193125-14-069692:note_history:9]
When a loss is considered probable and reasonably estimable, we
 record a liability in the amount of our best estimate for the
 ultimate loss. However, the likelihood of a loss with respect to a
 particular contingency is often difficult to predict and
 determining a meaningful estimate of the loss or a range of loss
 may not be practicable based on the information available and the
 potential effect of future events and decisions by third parties
 that will determine the ultimate resolution of the
 contingency.

- changed (2014-08-28):
[0001193125-14-325455:note_history:10]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of July 25, 2014 related to such matters as they
 are not probable and/or reasonably estimable.
  (was, 2014-02-26, similarity 0.9843):
[0001193125-14-069692:note_history:10]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of January 24, 2014 related to such matters as
 they are not probable and/or reasonably estimable.

- removed (2014-08-28):
[0001193125-14-069692:note_history:11]
In the normal course of business we make commitments to our
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that such forecasts
 are not achieved, our commitments and associated accruals may
 change. As of January 24, 2014, we had $240.2 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product revenues. As of
 January 24, 2014 and April 26, 2013, such liability
 amounted to $15.4 million and $9.5 million, respectively, and is
 included in other current liabilities in our condensed consolidated
 balance sheets.

- removed (2014-08-28):
[0001193125-14-069692:note_history:12]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Beginning balance |  | $ | 116.0 |  |  | $ | 111.8 |  |  | $ | 117.2 |  |  | $ | 83.1 |  |
| Expense accrued during the period |  |  | 21.1 |  |  |  | 23.5 |  |  |  | 59.4 |  |  |  | 74.3 |  |
| Warranty costs incurred |  |  | (20.0 | ) |  |  | (18.5 | ) |  |  | (59.5 | ) |  |  | (40.6 | ) |
| Ending balance |  | $ | 117.1 |  |  | $ | 116.8 |  |  | $ | 117.1 |  |  | $ | 116.8 |  |

- removed (2014-08-28):
[0001193125-14-069692:note_history:13]
Our warranty reserves were reported in our condensed
 consolidated balance sheets as follows (in millions):

- removed (2014-08-28):
[0001193125-14-069692:note_history:14]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Maximum guaranteed payment contingencies |  | $ | 218.0 |  |  | $ | 182.4 |  |
| Deferred revenue associated with financing guarantees |  |  | (203.8 | ) |  |  | (168.6 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 14.2 |  |  | $ | 13.8 |  |


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2014-08-28):
[0001193125-14-325455:note_history:15]
A reconciliation of the beginning and ending amount of
 unrecognized tax benefits is as follows (in millions):

- added (2014-08-28):
[0001193125-14-325455:note_history:16]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Balance at beginning of period |  | $ | 235.9 |  |  | $ | 189.6 |  |
| Additions based on tax positions related to the current year |  |  | 6.8 |  |  |  | 7.2 |  |
| Additions for tax positions of prior years |  |  | 98.7 |  |  |  | 1.0 |  |
| Decreases for tax positions of prior years |  |  | (18.6 | ) |  |  | (3.5 | ) |
| Settlements |  |  | (45.5 | ) |  |  | 0.0 |  |
| Balance at end of period |  | $ | 277.3 |  |  | $ | 194.3 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2014-08-28):
[0001193125-14-325455:note_history:17]
1.  Description
 of Business and Significant Accounting Policies

- added (2014-08-28):
[0001193125-14-325455:note_history:18]
NetApp, Inc. (we, us, or the Company) is a global provider of
 innovative storage and data management software, systems and
 services. Our storage solutions help customers create the flexible,
 efficient and highly available IT infrastructures they need to
 support their organizations. We are a storage and data management
 provider to enterprises of all sizes, service providers,
 governmental organizations and original equipment
 manufacturers.

- added (2014-08-28):
[0001193125-14-325455:note_history:19]
Basis of Presentation and Preparation

- added (2014-08-28):
[0001193125-14-325455:note_history:20]
Our
 fiscal year is reported on a 52- or 53-week year ending on the last
 Friday in April. The first quarters of fiscal 2015 and 2014 were
 each 13-week periods.

- added (2014-08-28):
[0001193125-14-325455:note_history:21]
The
 accompanying unaudited condensed consolidated financial statements
 have been prepared by the Company, and reflect all adjustments,
 consisting only of normal recurring adjustments, that are, in the
 opinion of management, necessary for the fair presentation of our
 financial position, results of operations, comprehensive income and
 cash flows for the interim periods presented. The statements have
 been prepared in accordance with accounting principles generally
 accepted in the United States of America (GAAP) for interim
 financial information and in accordance with the instructions to
 Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these
 statements do not include all information and footnotes required by
 GAAP for annual consolidated financial statements, and should be
 read in conjunction with our audited consolidated financial
 statements as of and for the fiscal year ended April 25, 2014
 contained in our Annual Report on Form 10-K filed with the
 Securities and Exchange Commission on June 17, 2014. The
 results of operations for the three months ended July 25, 2014
 are not necessarily indicative of the operating results to be
 expected for the full fiscal year or future operating
 periods.

- added (2014-08-28):
[0001193125-14-325455:note_history:22]
The
 preparation of the condensed consolidated financial statements in
 conformity with GAAP requires management to make estimates and
 assumptions that affect the reported amounts of assets and
 liabilities and disclosure of contingent assets and liabilities at
 the date of the financial statements and the reported amounts of
 revenues and expenses during the reporting periods. Such estimates
 include, but are not limited to, revenue recognition, reserves and
 allowances; inventory valuation and purchase order accruals;
 valuation of goodwill and intangibles; restructuring reserves;
 product warranties; employee benefit accruals; stock-based
 compensation; loss contingencies; investment impairments; income
 taxes and fair value measurements. Actual results could differ
 materially from those estimates.

- added (2014-08-28):
[0001193125-14-325455:note_history:23]
There
 have been no significant changes in our significant accounting
 policies as of and for the three months ended July 25, 2014,
 as compared to the significant accounting policies described in our
 Annual Report on Form 10-K for the fiscal year ended April 25,
 2014.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2014-08-28):
[0001193125-14-069692:note_history:24]
3.  Significant
 Accounting Policies

- removed (2014-08-28):
[0001193125-14-069692:note_history:25]
There
 have been no significant changes in our significant accounting
 policies as of and for the nine months ended January 24, 2014,
 as compared to the significant accounting policies described in our
 Annual Report on Form 10-K for the fiscal year ended April 26,
 2013.

- removed (2014-08-28):
[0001193125-14-069692:note_history:26]
Use
 of Estimates — The preparation of the condensed
 consolidated financial statements in conformity with GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent assets and liabilities at the date of the financial
 statements and the reported amounts of revenues and expenses during
 the reporting periods. Such estimates include, but are not limited
 to, revenue recognition, reserves and allowances; inventory
 valuation and purchase order accruals; valuation of goodwill and
 intangibles; restructuring reserves; product warranties; employee
 benefit accruals; stock-based compensation; loss contingencies;
 investment impairments; income taxes and fair value measurements.
 Actual results could differ materially from those
 estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-28):
[0001193125-14-325455:note_history:27]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.9 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,494.1 |  |  |  |  |  |  | $ | 995.5 |  |  |  |  |  |
  (was, 2014-02-26, similarity 0.6242):
[0001193125-14-069692:note_history:27]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total principal amount |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (4.8 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total debt |  |  | 995.2 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term portion |  | $ | 995.2 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |

- added (2014-08-28):
[0001193125-14-325455:note_history:28]
On June 5, 2014 we issued $500.0 million aggregate par
 value of 3.375% Senior Notes, with a maturity date of June 15,
 2021, and received proceeds of approximately $494.7 million, net of
 discount and issuance costs, which will be used for general
 corporate purposes, including possible stock repurchases,
 dividends, capital expenditures, working capital and potential
 acquisitions and strategic transactions. Our 2.00% Senior Notes and
 3.25% Senior Notes, with a par value of $750.0 million and $250.0
 million, respectively, were issued in December 2012. We
 collectively refer to such long-term debt as our Senior Notes.
 Interest on our Senior Notes is paid semi-annually on June 15
 and December 15. Our Senior Notes, which are unsecured,
 unsubordinated obligations, rank equally in right of payment with
 any future senior unsecured indebtedness.

- changed (2014-08-28):
[0001193125-14-325455:note_history:29]
We may redeem the Senior Notes in whole or in part at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of July 25, 2014,
 we were in compliance with all covenants associated with the Senior
 Notes.
  (was, 2014-02-26, similarity 0.9951):
[0001193125-14-069692:note_history:29]
We may redeem the Senior Notes in whole or in part at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of January 24,
 2014, we were in compliance with all covenants associated with the
 Senior Notes.

- changed (2014-08-28):
[0001193125-14-325455:note_history:30]
As of July 25, 2014, our aggregate future principal debt
 maturities are as follows (in millions):
  (was, 2014-02-26, similarity 0.973):
[0001193125-14-069692:note_history:30]
As of January 24, 2014, our aggregate future principal
 debt maturities are as follows (in millions):

- changed (2014-08-28):
[0001193125-14-325455:note_history:31]
In December 2012, we entered into a credit agreement with a
 syndicated group of lenders that is scheduled to expire on
 December 21, 2017 and provides for an unsecured $250.0 million
 revolving credit facility that is comprised of revolving loans,
 Eurocurrency loans and/or swingline loans. The credit facility
 includes a $100.0 million foreign currency sub-facility, a $50.0
 million letter of credit sub-facility and a $10.0 million swingline
 sub-facility available on same-day notice. Available borrowings
 under the credit facility are reduced by the amount of any
 outstanding borrowings on the sub-facilities. We may also, subject
 to certain requirements, request an increase in the facility up
 to an additional $100.0 million and request two additional
 one-year extensions, subject to certain conditions. The proceeds
 from the facility may be used by us for general corporate
 purposes.
  (was, 2014-02-26, similarity 0.9744):
[0001193125-14-069692:note_history:31]
In December 2012, we entered into a credit agreement with a
 syndicated group of lenders that provides for an unsecured $250.0
 million revolving credit facility that is comprised of revolving
 loans, Eurocurrency loans and/or swingline loans. The credit
 facility includes a $100.0 million foreign currency sub-facility, a
 $50.0 million letter of credit sub-facility and a $10.0 million
 swingline sub-facility available on same-day notice. Available
 borrowings under the credit facility are reduced by the amount of
 any outstanding borrowings on the sub-facilities. We may also,
 subject to certain requirements, request an increase in the
 facility up to an additional $100.0 million and request two
 additional one-year extensions, subject to certain conditions. The
 proceeds from the facility may be used by us for general corporate
 purposes.

- changed (2014-08-28):
[0001193125-14-325455:note_history:32]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility contains financial covenants requiring us to maintain a
 maximum leverage ratio of not more than 3.0:1.0 and a minimum
 interest coverage ratio of not less than 3.5:1.0. The facility
 contains customary affirmative and negative covenants, including
 covenants that limit our ability to incur debt secured by liens on
 assets or indebtedness of our subsidiaries and to consolidate,
 merge or sell all or substantially all of our assets. As of
 July 25, 2014, no borrowings were outstanding under the
 facility and we were in compliance with all covenants associated
 with the facility.
  (was, 2014-02-26, similarity 0.9664):
[0001193125-14-069692:note_history:32]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility terminates on December 21, 2017 if no extensions have
 been requested and contains financial covenants requiring us to
 maintain a maximum leverage ratio of not more than 3.0:1.0 and a
 minimum interest coverage ratio of not less than 3.5:1.0. The
 facility contains customary affirmative and negative covenants,
 including covenants that limit our ability to incur debt secured by
 liens on assets or indebtedness of our subsidiaries and to
 consolidate, merge or sell all or substantially all of our assets.
 As of January 24, 2014, no borrowings were outstanding under
 the facility and we were in compliance with all covenants
 associated with the facility.

- changed (2014-08-28):
[0001193125-14-325455:note_history:33]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 14.3 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (7.1 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 7.2 |  |  | $ | 6.5 |  |
  (was, 2014-02-26, similarity 0.9898):
[0001193125-14-069692:note_history:33]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Other long-term financing arrangements |  | $ | 14.8 |  |  | $ | 10.8 |  |
| Less: current portion |  |  | (6.9 | ) |  |  | (5.2 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 7.9 |  |  | $ | 5.6 |  |

- removed (2014-08-28):
[0001193125-14-069692:note_history:34]
Our Senior Notes, issued in December 2012, are unsecured,
 unsubordinated obligations, which pay interest semi-annually on
 June 15 and December 15 and rank equally in right of
 payment with any future senior unsecured indebtedness. Interest
 expense associated with the Senior Notes was $6.2 million and $18.7
 million for the three and nine months ended January 24, 2014,
 respectively, and was $3.1 million for each of the three and nine
 months ended January 25, 2013.

- removed (2014-08-28):
[0001193125-14-069692:note_history:35]
1.75% Convertible Senior Notes due 2013

- removed (2014-08-28):
[0001193125-14-069692:note_history:36]
On June 10, 2008, we issued $1,265.0 million
 aggregate principal amount of 1.75% Convertible Senior Notes
 (the Convertible Notes) with a maturity date of June 1, 2013.
 The Convertible Notes were unsecured, unsubordinated obligations of
 the Company and paid interest in cash semi-annually at a rate of
 1.75% per annum. Upon maturity, the Convertible Notes were
 converted into shares of common stock at a conversion rate of 31.40
 shares of common stock per $1,000 principal amount of the
 Convertible Notes (which represented the effective conversion price
 of $31.85 per share). Upon conversion in June 2013, the holders
 received cash for the principal amount of the Convertible Notes and
 an aggregate of 4.9 million shares of common stock for the
 $178.9 million excess of the conversion value over the principal
 amount.

- removed (2014-08-28):
[0001193125-14-069692:note_history:37]
We separately accounted for the liability and equity components
 of the Convertible Notes. The initial debt component of the
 Convertible Notes was valued at $1,017.0 million based on the
 contractual cash flows discounted at an appropriate comparable
 market non-convertible debt borrowing rate at the date of issuance
 of 6.31%, with the equity component representing the residual
 amount of the proceeds of $248.0 million which was recorded as
 a debt discount. Issuance costs were allocated pro-rata based on
 the relative initial carrying amounts of the debt and equity
 components. As a result, $5.2 million of the issuance costs
 was allocated to the equity component of the Convertible Notes, and
 $21.4 million of the issuance costs remained classified as
 other non-current assets. The debt discount and the issuance costs
 allocated to the debt component were amortized as additional
 interest expense over the term of the Convertible Notes using the
 effective interest method.

- removed (2014-08-28):
[0001193125-14-069692:note_history:38]
Convertible Note Hedges and Warrants

- removed (2014-08-28):
[0001193125-14-069692:note_history:39]
Concurrent with the issuance of the Convertible Notes, we
 purchased Convertible Note hedges and sold warrants. The separate
 Convertible Note hedge and warrant transactions were structured to
 reduce the potential future economic dilution associated with the
 conversion of the Convertible Notes.

- removed (2014-08-28):
[0001193125-14-069692:note_history:40]
• Convertible Note Hedges: As of April 26, 2013, we
 had arrangements with counterparties to buy up to approximately
 31.8 million shares of our common stock, at a price of $31.85
 per share. In June 2013, concurrent with the repayment and
 conversion of the Convertible Notes, we exercised the Convertible
 Note hedges that were net settled for an aggregate of
 3.9 million shares from the counterparties.

- removed (2014-08-28):
[0001193125-14-069692:note_history:41]
• Warrants: As of April 26, 2013, we had outstanding
 warrants for certain counterparties to acquire 39.7 million
 shares of our common stock at an exercise price of $41.28 per
 share. The warrants were exercisable on a series of days commencing
 on September 3, 2013 and ending on October 28, 2013. The
 number of warrants and exercise price were adjusted in July 2013 to
 39.9 million and $41.12 per share, respectively, to reflect
 our July 2013 dividend. On October 17, 2013, the exercise
 price of the warrants then outstanding was further adjusted to
 $40.97 per share to reflect our October 2013 dividend. Through
 October 28, 2013, 31.9 million warrants were exercised
 and net settled with 1.1 million shares of our common stock
 equal to the difference between the market price on the date of
 exercise and the exercise price of the warrants on the respective
 exercise dates. No warrants were exercised during the three months
 ended January 24, 2014 as their exercise price exceeded the
 market value of our stock prior to their expiration during the
 quarter.

- removed (2014-08-28):
[0001193125-14-069692:note_history:42]
Interest Expense on Convertible Notes

- removed (2014-08-28):
[0001193125-14-069692:note_history:43]
The following table presents the amount of interest expense
 related to the Convertible Notes (in millions):

- removed (2014-08-28):
[0001193125-14-069692:note_history:44]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 2.5 |  |  | $ | 16.5 |  |
| Amortization of debt discount |  |  | 13.9 |  |  |  | 7.1 |  |  |  | 41.0 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 0.6 |  |  |  | 3.6 |  |
| Less capitalized interest |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (1.1 | ) |
| Total interest expense related to Convertible Notes |  | $ | 20.6 |  |  | $ | 10.2 |  |  | $ | 60.0 |  |

- removed (2014-08-28):
[0001193125-14-069692:note_history:45]
No interest expense related to the Convertible Notes was
 recognized in the three months ended January 24, 2014 due to
 their maturity.

- removed (2014-08-28):
[0001193125-14-069692:note_history:46]
Debt Maturities


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-28):
[0001193125-14-325455:note_history:47]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 14.3 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (7.1 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 7.2 |  |  | $ | 6.5 |  |
  (was, 2014-02-26, similarity 0.9898):
[0001193125-14-069692:note_history:47]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Other long-term financing arrangements |  | $ | 14.8 |  |  | $ | 10.8 |  |
| Less: current portion |  |  | (6.9 | ) |  |  | (5.2 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 7.9 |  |  | $ | 5.6 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-28):
[0001193125-14-325455:note_history:48]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.9 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,494.1 |  |  |  |  |  |  | $ | 995.5 |  |  |  |  |  |
  (was, 2014-02-26, similarity 0.6242):
[0001193125-14-069692:note_history:48]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total principal amount |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (4.8 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total debt |  |  | 995.2 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term portion |  | $ | 995.2 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-28):
[0001193125-14-325455:note_history:49]
As of July 25, 2014, our aggregate future principal debt
 maturities are as follows (in millions):
  (was, 2014-02-26, similarity 0.973):
[0001193125-14-069692:note_history:49]
As of January 24, 2014, our aggregate future principal
 debt maturities are as follows (in millions):
