# NTAP 8-K — 0001102624-14-001312 filed 2014-08-13

## item codes, every 8-K on or before 2014-08-28

- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2014-08-28

- none on or before 2014-08-28

## item 2.02 — earnings release, exhibit 99.1

[0001102624-14-001312:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-14-001312:8k_2_02:2]
exh99_1.htm

[0001102624-14-001312:8k_2_02:3]
Exhibit 99.1

[0001102624-14-001312:8k_2_02:4]
|  | Press Contact: | Investor Contact: |
|  | Meghan Fintland | Kris Newton |
|  | NetApp | NetApp |
|  | 408-822-1389 | 408-822-3312 |
|  | Mehgan.Fintland@netapp.com | Kris.Newton@netapp.com |

[0001102624-14-001312:8k_2_02:5]
NETAPP REPORTS FIRST QUARTER FISCAL YEAR 2015 RESULTS

[0001102624-14-001312:8k_2_02:6]
Net Revenues of $1.49 Billion; Non-GAAP EPS of $0.60, Up 13% Year-over-Year

[0001102624-14-001312:8k_2_02:7]
| · | Completed refresh of FAS product line and introduced new all-flash products |

[0001102624-14-001312:8k_2_02:8]
| · | Clustered Data ONTAP® node shipments increased 177% year-over-year |

[0001102624-14-001312:8k_2_02:9]
| · | Flash capacity shipped more than doubled year-over-year |

[0001102624-14-001312:8k_2_02:10]
Sunnyvale, Calif.—August 13, 2014—NetApp (NASDAQ: NTAP) today reported financial results for the first quarter of fiscal year 2015 ended July 25, 2014.

[0001102624-14-001312:8k_2_02:11]
First Quarter Financial Results

[0001102624-14-001312:8k_2_02:12]
Net revenues for the first quarter of fiscal year 2015 were $1.49 billion. GAAP net income for the first quarter of fiscal year 2015 was $88 million, or $0.27 per share,1 compared to GAAP net income of $82 million, or $0.23 per share, for the comparable period of the prior year. Non-GAAP net income for the first quarter of fiscal year 2015 was $198 million, or $0.60 per share,2 compared to non-GAAP net income of $192 million, or $0.53 per share, for the comparable period of the prior year.

[0001102624-14-001312:8k_2_02:13]
Cash, Cash Equivalents and Investments

[0001102624-14-001312:8k_2_02:14]
NetApp ended the first quarter of fiscal year 2015 with $5.56 billion of total cash, cash equivalents and investments and during the quarter generated $216 million in cash from operations. The company returned $172 million to shareholders during the quarter through share repurchases and a cash dividend. The next dividend in the amount of $0.165 per share will be paid on October 22, 2014 to shareholders of record as of the close of business on October 10, 2014.

[0001102624-14-001312:8k_2_02:15]
“More large enterprises are relying on NetApp to help them bridge the on-premises architectures of today with the requirement to leverage multiple cloud services in the future,” said Tom Georgens, Chairman and CEO. “Our best-in-class portfolio is driving momentum, enabling us to invest in continued innovation while delivering shareholder value.”

[0001102624-14-001312:8k_2_02:16]
Q2 Fiscal Year 2015 Outlook

[0001102624-14-001312:8k_2_02:17]
The Company provided the following financial guidance for the second quarter of fiscal year 2015:

[0001102624-14-001312:8k_2_02:18]
| · | Net revenues are expected to be in the range of $1.49 billion to $1.59 billion |

[0001102624-14-001312:8k_2_02:19]
| · | GAAP earnings per share is expected to be in the range of $0.45 to $0.50 per share |

[0001102624-14-001312:8k_2_02:20]
| · | Non-GAAP earnings per share is expected to be in the range of $0.66 to $0.71 per share |

[0001102624-14-001312:8k_2_02:21]
Business Highlights

[0001102624-14-001312:8k_2_02:22]
| · | NetApp Delivers New Products: |

[0001102624-14-001312:8k_2_02:23]
|  | - | NetApp® FAS8080 EX. The unified FAS8080 EX array is purpose-built for the most demanding business-critical applications with advanced quality-of-service capabilities to enable predictable performance. |

[0001102624-14-001312:8k_2_02:24]
|  | - | NetApp FAS2500. The FAS2500 delivers optimal price/performance at an entry-level price point, while simplifying storage management operations. |

[0001102624-14-001312:8k_2_02:25]
|  | - | All-flash FAS Products. New NetApp all-flash FAS products combine the high performance and low latency of flash with the enterprise reliability and extensive data management of NetApp Data ONTAP® software. |

[0001102624-14-001312:8k_2_02:26]
|  | - | Updated OnCommand® Portfolio. OnCommand enables customers to better control clustered Data ONTAP and multivendor storage environments, driving down storage costs, improving service delivery through open integration, and maximizing investment by providing flexible reporting and cost analysis. |

[0001102624-14-001312:8k_2_02:27]
| · | NetApp Strengthens Partnerships: |

[0001102624-14-001312:8k_2_02:28]
|  | - | Delivered NetApp Private Storage (NPS) for Microsoft Azure. Building on its portfolio of Microsoft Cloud solutions, NetApp introduced NPS for Microsoft Azure, enabling customers to extend their IT infrastructure to Microsoft Azure to create a seamless, secure hybrid cloud environment. |

[0001102624-14-001312:8k_2_02:29]
|  | - | Deepened Equinix Hybrid Cloud Partnership. The Equinix Cloud Exchange can dynamically connect NetApp Private Storage customers to multiple public clouds so that they can confidently explore multi-cloud deployments to handle large, complex workflows more efficiently. |

[0001102624-14-001312:8k_2_02:30]
|  | - | Achieved $3 billion in FlexPod® Joint Sales for NetApp and Cisco. The industry’s leading integrated infrastructure solution has generated $3 billion in joint sales since its launch in 2010. |

[0001102624-14-001312:8k_2_02:31]
| · | NetApp Provides Cloud Service Architecture: |

[0001102624-14-001312:8k_2_02:32]
|  | - | State Government Agency Implements NetApp Private Cloud Architecture. The State of California Natural Resources Agency is a model for cloud service architectures deploying NetApp’s clustered Data ONTAP operating system, OnCommand System Manager, and FAS hybrid storage systems as part of its multitenant private cloud. |

[0001102624-14-001312:8k_2_02:33]
Webcast and Conference Call Information

[0001102624-14-001312:8k_2_02:34]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001102624-14-001312:8k_2_02:35]
About NetApp

[0001102624-14-001312:8k_2_02:36]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Our commitment to living our core values and consistently being recognized as a great place to work around the world are fundamental to our long-term growth and success, as well as the success of our pathway partners and customers. Discover our passion for helping companies around the world at www.netapp.com.

[0001102624-14-001312:8k_2_02:37]
###

[0001102624-14-001312:8k_2_02:38]
NetApp, the NetApp logo, Data ONTAP, Flex Pod, and OnCommand are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001102624-14-001312:8k_2_02:39]
1GAAP earnings per share is calculated using the diluted number of shares for all periods presented.

[0001102624-14-001312:8k_2_02:40]
2Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes  a non-GAAP tax provision based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Effective the first quarter of fiscal 2015, the non-GAAP tax provision also excludes, when applicable,  (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal R&D credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of share for all periods presented.  A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com.

[0001102624-14-001312:8k_2_02:41]
8

[0001102624-14-001312:8k_2_02:42]
NetApp Usage of Non-GAAP Financials

[0001102624-14-001312:8k_2_02:43]
The Company refers to the non-GAAP financial measures in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Effective the first quarter of fiscal 2015, the non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal R&D credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future.

[0001102624-14-001312:8k_2_02:44]
We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has limitations and they should not solely be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we provide both non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-14-001312:8k_2_02:45]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation.

[0001102624-14-001312:8k_2_02:46]
| NETAPP, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,564.2 |  |  | $ | 5,003.3 |  |
| Accounts receivable, net |  |  | 585.4 |  |  |  | 855.9 |  |
| Inventories |  |  | 104.2 |  |  |  | 122.4 |  |
| Other current assets |  |  | 494.3 |  |  |  | 489.7 |  |
| Total current assets |  |  | 6,748.1 |  |  |  | 6,471.3 |  |
| Property and equipment, net |  |  | 1,098.0 |  |  |  | 1,108.8 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,095.1 |  |  |  | 1,109.6 |  |
| Other non-current assets |  |  | 531.2 |  |  |  | 529.5 |  |
| Total assets |  | $ | 9,472.4 |  |  | $ | 9,219.2 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 183.1 |  |  | $ | 247.0 |  |
| Accrued compensation and other current liabilities |  |  | 561.4 |  |  |  | 793.8 |  |
| Short-term deferred revenue |  |  | 1,656.4 |  |  |  | 1,653.8 |  |
| Total current liabilities |  |  | 2,400.9 |  |  |  | 2,694.6 |  |
| Long-term debt |  |  | 1,494.1 |  |  |  | 995.5 |  |
| Other long-term liabilities |  |  | 320.8 |  |  |  | 296.2 |  |
| Long-term deferred revenue |  |  | 1,419.9 |  |  |  | 1,446.4 |  |
| Total liabilities |  |  | 5,635.7 |  |  |  | 5,432.7 |  |
| Stockholders' equity |  |  | 3,836.7 |  |  |  | 3,786.5 |  |
| Total liabilities and stockholders' equity |  | $ | 9,472.4 |  |  | $ | 9,219.2 |  |

[0001102624-14-001312:8k_2_02:47]
10

[0001102624-14-001312:8k_2_02:48]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Revenues: |  |  |  |  |  |  |
| Product |  | $ | 882.6 |  |  | $ | 930.8 |  |
| Software entitlements and maintenance |  |  | 221.3 |  |  |  | 228.5 |  |
| Service |  |  | 385.3 |  |  |  | 356.9 |  |
| Net revenues |  |  | 1,489.2 |  |  |  | 1,516.2 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 394.2 |  |  |  | 449.9 |  |
| Cost of software entitlements and maintenance |  |  | 8.2 |  |  |  | 7.5 |  |
| Cost of service |  |  | 148.7 |  |  |  | 149.2 |  |
| Total cost of revenues |  |  | 551.1 |  |  |  | 606.6 |  |
| Gross profit |  |  | 938.1 |  |  |  | 909.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 480.2 |  |  |  | 467.8 |  |
| Research and development |  |  | 228.0 |  |  |  | 228.1 |  |
| General and administrative |  |  | 70.0 |  |  |  | 68.4 |  |
| Restructuring and other charges |  |  | - |  |  |  | 48.4 |  |
| Total operating expenses |  |  | 778.2 |  |  |  | 812.7 |  |
| Income from operations |  |  | 159.9 |  |  |  | 96.9 |  |
| Other income/(expense), net: |  |  |  |  |  |  |  |  |
| Interest income |  |  | 8.3 |  |  |  | 10.0 |  |
| Interest expense |  |  | (9.0 | ) |  |  | (16.5 | ) |
| Other income, net |  |  | 0.5 |  |  |  | 1.9 |  |
| Total other income/(expense), net |  |  | (0.2 | ) |  |  | (4.6 | ) |
| Income before income taxes |  |  | 159.7 |  |  |  | 92.3 |  |
| Provision for income taxes |  |  | 71.3 |  |  |  | 10.7 |  |
| Net income |  | $ | 88.4 |  |  | $ | 81.6 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.27 |  |  | $ | 0.23 |  |
| Diluted |  | $ | 0.27 |  |  | $ | 0.23 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  | 323.5 |  |  |  | 350.9 |  |
| Diluted |  |  | 329.1 |  |  |  | 359.9 |  |
| Cash dividends declared per share |  | $ | 0.165 |  |  | $ | 0.150 |  |

[0001102624-14-001312:8k_2_02:49]
11

[0001102624-14-001312:8k_2_02:50]
| NETAPP, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |
| (In millions) |
| (Unaudited) |
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 88.4 |  |  | $ | 81.6 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 77.5 |  |  |  | 85.9 |  |
| Stock-based compensation |  |  | 62.3 |  |  |  | 66.3 |  |
| Accretion of discount and issuance costs on debt |  |  | 0.6 |  |  |  | 8.2 |  |
| Excess tax benefit from stock-based compensation |  |  | (42.6 | ) |  |  | (0.1 | ) |
| Other, net |  |  | 45.1 |  |  |  | (35.4 | ) |
| Changes in assets and liabilities, net of acquired businesses: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 271.5 |  |  |  | 265.2 |  |
| Inventories |  |  | 18.1 |  |  |  | 22.9 |  |
| Accounts payable |  |  | (62.3 | ) |  |  | (37.9 | ) |
| Accrued compensation and other current liabilities |  |  | (227.1 | ) |  |  | (175.4 | ) |
| Deferred revenue |  |  | (26.5 | ) |  |  | (54.3 | ) |
| Changes in other operating assets and liabilities, net |  |  | 10.5 |  |  |  | 58.8 |  |
| Net cash provided by operating activities |  |  | 215.5 |  |  |  | 285.8 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 191.2 |  |  |  | 390.0 |  |
| Purchases of property and equipment |  |  | (58.4 | ) |  |  | (65.3 | ) |
| Other investing activities, net |  |  | 0.2 |  |  |  | 1.2 |  |
| Net cash provided by investing activities |  |  | 133.0 |  |  |  | 325.9 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 28.4 |  |  |  | 71.5 |  |
| Repurchase of common stock and forward contract |  |  | (118.9 | ) |  |  | (849.5 | ) |
| Excess tax benefit from stock-based compensation |  |  | 42.6 |  |  |  | 0.1 |  |
| Repayment of debt |  |  | - |  |  |  | (1,264.9 | ) |
| Issuance of long-term debt, net |  |  | 494.7 |  |  |  | - |  |
| Dividends paid |  |  | (53.4 | ) |  |  | (51.4 | ) |
| Other financing activities, net |  |  | (1.8 | ) |  |  | 9.5 |  |
| Net cash provided by (used in) financing activities |  |  | 391.6 |  |  |  | (2,084.7 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 0.5 |  |  |  | (7.3 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 740.6 |  |  |  | (1,480.3 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,291.0 |  |  |  | 3,277.1 |  |
| End of period |  | $ | 3,031.6 |  |  | $ | 1,796.8 |  |

[0001102624-14-001312:8k_2_02:51]
12

[0001102624-14-001312:8k_2_02:52]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q1 FY’15 |  |  | Q4 FY’14 |  |  | Q1 FY’14 |  |
| Revenues |  |  |  |  |  |  |  |  |  |
| Product Revenue |  | $ | 882.6 |  |  | $ | 1,042.8 |  |  | $ | 930.8 |  |
| Software Entitlements & Maintenance Revenue (SEM) |  |  | 221.3 |  |  |  | 227.5 |  |  |  | 228.5 |  |
| Service Revenue: |  |  | 385.3 |  |  |  | 378.7 |  |  |  | 356.9 |  |
| Hardware Maintenance Support Contracts Revenue |  |  | 302.8 |  |  |  | 293.7 |  |  |  | 273.6 |  |
| Professional & Other Services Revenue |  |  | 82.5 |  |  |  | 85.0 |  |  |  | 83.2 |  |
| Net Revenues |  | $ | 1,489.2 |  |  | $ | 1,649.0 |  |  | $ | 1,516.2 |  |
| Branded and OEM Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY’15 |  |  | Q4 FY’14 |  |  | Q1 FY’14 |  |
| Branded Revenue |  | $ | 1,360.5 |  |  | $ | 1,539.2 |  |  | $ | 1,349.7 |  |
| OEM Revenue |  |  | 128.7 |  |  |  | 109.8 |  |  |  | 166.5 |  |
| Net Revenues |  | $ | 1,489.2 |  |  | $ | 1,649.0 |  |  | $ | 1,516.2 |  |
| Branded revenue includes revenue from all products and services sold directly by us or our partners under the NetApp brand, including NetApp branded E-Series products and solutions. |  |
| OEM revenue comprises revenue from the sale of our products by other companies under their brands and includes revenue from IBM, Fujitsu, and other E-Series OEM relationships. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'15 Revenue |  |  | % of Q4 FY’14 Revenue |  |  | % of Q1 FY’14 Revenue |  |
| Americas |  |  | 56 | % |  |  | 56 | % |  |  | 57 | % |
| Americas Commercial |  |  | 44 | % |  |  | 43 | % |  |  | 44 | % |
| U.S. Public Sector |  |  | 12 | % |  |  | 12 | % |  |  | 12 | % |
| EMEA |  |  | 30 | % |  |  | 31 | % |  |  | 30 | % |
| Asia Pacific |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'15 Revenue |  |  | % of Q4 FY’14 Revenue |  |  | % of Q1 FY’14 Revenue |  |
| Direct |  |  | 21 | % |  |  | 17 | % |  |  | 20 | % |
| Indirect |  |  | 79 | % |  |  | 83 | % |  |  | 80 | % |
| Direct revenues are those sold through our direct sales force. Indirect revenues include those sold through value-added resellers, system integrators, OEMs and distributors. |  |
| Indirect revenue mix reflects order fulfillment and is not reflective of who is responsible for the customer relationship. |  |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY’15 |  |  | Q4 FY’14 |  |  | Q1 FY’14 |  |
| Non-GAAP Gross Margin |  |  | 64.3 | % |  |  | 64.4 | % |  |  | 61.3 | % |
| Product |  |  | 57.1 | % |  |  | 58.0 | % |  |  | 53.3 | % |
| Software Entitlements & Maintenance (SEM) |  |  | 96.3 | % |  |  | 96.5 | % |  |  | 96.7 | % |
| Service |  |  | 62.7 | % |  |  | 62.7 | % |  |  | 59.5 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |
|  |  | Q1 FY’15 |  |  | Q4 FY’14 |  |  | Q1 FY’14 |  |
| Non-GAAP Income from Operations |  | $ | 236.7 |  |  | $ | 344.4 |  |  | $ | 226.5 |  |
| % of Net Revenue |  |  | 15.9 | % |  |  | 20.9 | % |  |  | 14.9 | % |
| Non-GAAP Income before Income Taxes |  | $ | 236.5 |  |  | $ | 347.2 |  |  | $ | 230.1 |  |
| Non-GAAP Effective Tax Rate |  |  | 16.5 | % |  |  | 18.1 | % |  |  | 16.6 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY’15 |  |  | Q4 FY’14 |  |  | Q1 FY’14 |  |
| Non-GAAP Net Income |  | $ | 197.5 |  |  | $ | 284.2 |  |  | $ | 191.9 |  |
| Weighted Average Common Shares Outstanding, Diluted |  |  | 329.1 |  |  |  | 336.4 |  |  |  | 359.9 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.60 |  |  | $ | 0.84 |  |  | $ | 0.53 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY’15 |  |  | Q4 FY’14 |  |  | Q1 FY’14 |  |
| Deferred Revenue |  | $ | 3,076.3 |  |  | $ | 3,100.2 |  |  | $ | 2,941.3 |  |
| DSO (days) |  |  | 36 |  |  |  | 47 |  |  |  | 32 |  |
| Inventory Turns |  |  | 20 |  |  |  | 19 |  |  |  | 20 |  |
| Days sales outstanding (DSO) is defined as accounts receivable, net divided by net revenue, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized non-GAAP cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY’15 |  |  | Q4 FY’14 |  |  | Q1 FY’14 |  |
| Net Cash Provided by Operating Activities |  | $ | 215.5 |  |  | $ | 369.5 |  |  | $ | 285.8 |  |
| Purchases of Property and Equipment |  | $ | 58.4 |  |  | $ | 56.0 |  |  | $ | 65.3 |  |
| Free Cash Flow |  | $ | 157.1 |  |  | $ | 313.5 |  |  | $ | 220.5 |  |
| Free Cash Flow as % of Total Revenue |  |  | 10.5 | % |  |  | 19.0 | % |  |  | 14.5 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |

[0001102624-14-001312:8k_2_02:53]
13

[0001102624-14-001312:8k_2_02:54]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY15 |  |  | Q4'FY14 |  |  | Q1'FY14 |  |
| NET INCOME |  | $ | 88.4 |  |  | $ | 197.0 |  |  | $ | 81.6 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.5 |  |  |  | 14.6 |  |  |  | 14.9 |  |
| Stock-based compensation |  |  | 62.3 |  |  |  | 67.2 |  |  |  | 66.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | 38.8 |  |  |  | 48.4 |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 8.2 |  |
| Income tax effect of non-GAAP adjustments |  |  | (15.1 | ) |  |  | (33.4 | ) |  |  | (27.5 | ) |
| Settlement of income tax audit |  |  | 47.4 |  |  |  | - |  |  |  | - |  |
| NON-GAAP NET INCOME |  | $ | 197.5 |  |  | $ | 284.2 |  |  | $ | 191.9 |  |
| COST OF REVENUES |  | $ | 551.1 |  |  | $ | 607.0 |  |  | $ | 606.6 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.3 | ) |  |  | (14.3 | ) |  |  | (14.3 | ) |
| Stock-based compensation |  |  | (5.9 | ) |  |  | (5.3 | ) |  |  | (5.3 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 530.9 |  |  | $ | 587.4 |  |  | $ | 587.0 |  |
| COST OF PRODUCT REVENUES |  | $ | 394.2 |  |  | $ | 453.2 |  |  | $ | 449.9 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13.7 | ) |  |  | (13.7 | ) |  |  | (13.7 | ) |
| Stock-based compensation |  |  | (1.5 | ) |  |  | (1.4 | ) |  |  | (1.3 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 379.0 |  |  | $ | 438.1 |  |  | $ | 434.9 |  |
| COST OF SERVICE REVENUES |  | $ | 148.7 |  |  | $ | 145.8 |  |  | $ | 149.2 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (0.6 | ) |
| Stock-based compensation |  |  | (4.4 | ) |  |  | (3.9 | ) |  |  | (4.0 | ) |
| NON-GAAP COST OF SERVICE REVENUES |  | $ | 143.7 |  |  | $ | 141.3 |  |  | $ | 144.6 |  |
| GROSS PROFIT |  | $ | 938.1 |  |  | $ | 1,042.0 |  |  | $ | 909.6 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.3 |  |  |  | 14.3 |  |  |  | 14.3 |  |
| Stock-based compensation |  |  | 5.9 |  |  |  | 5.3 |  |  |  | 5.3 |  |
| NON-GAAP GROSS PROFIT |  | $ | 958.3 |  |  | $ | 1,061.6 |  |  | $ | 929.2 |  |
| SALES AND MARKETING EXPENSES |  | $ | 480.2 |  |  | $ | 475.0 |  |  | $ | 467.8 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.2 | ) |  |  | (0.3 | ) |  |  | (0.6 | ) |
| Stock-based compensation |  |  | (27.0 | ) |  |  | (30.4 | ) |  |  | (30.5 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 453.0 |  |  | $ | 444.3 |  |  | $ | 436.7 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 228.0 |  |  | $ | 230.7 |  |  | $ | 228.1 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (21.5 | ) |  |  | (21.1 | ) |  |  | (21.4 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 206.5 |  |  | $ | 209.6 |  |  | $ | 206.7 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 70.0 |  |  | $ | 73.7 |  |  | $ | 68.4 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (7.9 | ) |  |  | (10.4 | ) |  |  | (9.1 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 62.1 |  |  | $ | 63.3 |  |  | $ | 59.3 |  |

[0001102624-14-001312:8k_2_02:55]
14

[0001102624-14-001312:8k_2_02:56]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP TO GAAP |
| INCOME STATEMENT INFORMATION |
| (In millions, except net income per share amounts) |
|  |  | Q1'FY15 |  |  | Q4'FY14 |  |  | Q1'FY14 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | 38.8 |  |  | $ | 48.4 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | - |  |  |  | (38.8 | ) |  |  | (48.4 | ) |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| OPERATING EXPENSES |  | $ | 778.2 |  |  | $ | 818.2 |  |  | $ | 812.7 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.2 | ) |  |  | (0.3 | ) |  |  | (0.6 | ) |
| Stock-based compensation |  |  | (56.4 | ) |  |  | (61.9 | ) |  |  | (61.0 | ) |
| Restructuring and other charges |  |  | - |  |  |  | (38.8 | ) |  |  | (48.4 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 721.6 |  |  | $ | 717.2 |  |  | $ | 702.7 |  |
| INCOME FROM OPERATIONS |  | $ | 159.9 |  |  | $ | 223.8 |  |  | $ | 96.9 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.5 |  |  |  | 14.6 |  |  |  | 14.9 |  |
| Stock-based compensation |  |  | 62.3 |  |  |  | 67.2 |  |  |  | 66.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | 38.8 |  |  |  | 48.4 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 236.7 |  |  | $ | 344.4 |  |  | $ | 226.5 |  |
| TOTAL OTHER INCOME (EXPENSE), NET |  | $ | (0.2 | ) |  | $ | 2.8 |  |  | $ | (4.6 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 8.2 |  |
| NON-GAAP TOTAL OTHER INCOME, NET |  | $ | (0.2 | ) |  | $ | 2.8 |  |  | $ | 3.6 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 159.7 |  |  | $ | 226.6 |  |  | $ | 92.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.5 |  |  |  | 14.6 |  |  |  | 14.9 |  |
| Stock-based compensation |  |  | 62.3 |  |  |  | 67.2 |  |  |  | 66.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | 38.8 |  |  |  | 48.4 |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 8.2 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 236.5 |  |  | $ | 347.2 |  |  | $ | 230.1 |  |
| PROVISION FOR INCOME TAXES |  | $ | 71.3 |  |  | $ | 29.6 |  |  | $ | 10.7 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 15.1 |  |  |  | 33.4 |  |  |  | 27.5 |  |
| Settlement of income tax audit |  |  | (47.4 | ) |  |  | - |  |  |  | - |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 39.0 |  |  | $ | 63.0 |  |  | $ | 38.2 |  |
| NET INCOME PER SHARE |  | $ | 0.27 |  |  | $ | 0.59 |  |  | $ | 0.23 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.04 |  |  |  | 0.04 |  |  |  | 0.04 |  |
| Stock-based compensation |  |  | 0.19 |  |  |  | 0.20 |  |  |  | 0.18 |  |
| Restructuring and other charges |  |  | - |  |  |  | 0.11 |  |  |  | 0.13 |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 0.02 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.04 | ) |  |  | (0.10 | ) |  |  | (0.08 | ) |
| Settlement of income tax audit |  |  | 0.14 |  |  |  | - |  |  |  | - |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.60 |  |  | $ | 0.84 |  |  | $ | 0.53 |  |

[0001102624-14-001312:8k_2_02:57]
15

[0001102624-14-001312:8k_2_02:58]
| RECONCILIATION OF NON-GAAP TO GAAP |
| GROSS MARGIN |
| ($ in millions) |  |
|  |  | Q1'FY15 |  |  | Q4'FY14 |  |  | Q1'FY14 |  |
| Gross margin-GAAP |  |  | 63.0 | % |  |  | 63.2 | % |  |  | 60.0 | % |
| Cost of revenues adjustments |  |  | 1.4 | % |  |  | 1.2 | % |  |  | 1.3 | % |
| Gross margin-Non-GAAP |  |  | 64.3 | % |  |  | 64.4 | % |  |  | 61.3 | % |
| GAAP cost of revenues |  | $ | 551.1 |  |  | $ | 607.0 |  |  | $ | 606.6 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.3 | ) |  |  | (14.3 | ) |  |  | (14.3 | ) |
| Stock-based compensation |  |  | (5.9 | ) |  |  | (5.3 | ) |  |  | (5.3 | ) |
| Non-GAAP cost of revenues |  | $ | 530.9 |  |  | $ | 587.4 |  |  | $ | 587.0 |  |
| Revenues |  | $ | 1,489.2 |  |  | $ | 1,649.0 |  |  | $ | 1,516.2 |  |
| RECONCILIATION OF NON-GAAP TO GAAP |
| PRODUCT GROSS MARGIN |
| ($ in millions) |
|  |  | Q1'FY15 |  |  | Q4'FY14 |  |  | Q1'FY14 |  |
| Product gross margin-GAAP |  |  | 55.3 | % |  |  | 56.5 | % |  |  | 51.7 | % |
| Cost of product revenues adjustments |  |  | 1.7 | % |  |  | 1.4 | % |  |  | 1.6 | % |
| Product gross margin-Non-GAAP |  |  | 57.1 | % |  |  | 58.0 | % |  |  | 53.3 | % |
| GAAP cost of product revenues |  | $ | 394.2 |  |  | $ | 453.2 |  |  | $ | 449.9 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13.7 | ) |  |  | (13.7 | ) |  |  | (13.7 | ) |
| Stock-based compensation |  |  | (1.5 | ) |  |  | (1.4 | ) |  |  | (1.3 | ) |
| Non-GAAP cost of product revenues |  | $ | 379.0 |  |  | $ | 438.1 |  |  | $ | 434.9 |  |
| Product revenues |  | $ | 882.6 |  |  | $ | 1,042.8 |  |  | $ | 930.8 |  |
| RECONCILIATION OF NON-GAAP TO GAAP |
| SERVICES GROSS MARGIN |
| ($ in millions) |
|  |  | Q1'FY15 |  |  | Q4'FY14 |  |  | Q1'FY14 |  |
| Services gross margin-GAAP |  |  | 61.4 | % |  |  | 61.5 | % |  |  | 58.2 | % |
| Cost of service revenues adjustments |  |  | 1.3 | % |  |  | 1.2 | % |  |  | 1.3 | % |
| Services gross margin-Non-GAAP |  |  | 62.7 | % |  |  | 62.7 | % |  |  | 59.5 | % |
| GAAP cost of service revenues |  | $ | 148.7 |  |  | $ | 145.8 |  |  | $ | 149.2 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (0.6 | ) |
| Stock-based compensation |  |  | (4.4 | ) |  |  | (3.9 | ) |  |  | (4.0 | ) |
| Non-GAAP cost of service revenues |  | $ | 143.7 |  |  | $ | 141.3 |  |  | $ | 144.6 |  |
| Service revenues |  | $ | 385.3 |  |  | $ | 378.7 |  |  | $ | 356.9 |  |

[0001102624-14-001312:8k_2_02:59]
16

[0001102624-14-001312:8k_2_02:60]
| RECONCILIATION OF NON-GAAP TO GAAP |
| EFFECTIVE TAX RATE |
|  |  | Q1'FY15 |  |  | Q4'FY14 |  |  | Q1'FY14 |  |
| GAAP effective tax rate |  |  | 44.6 | % |  |  | 13.1 | % |  |  | 11.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | (8.1 | %) |  |  | 5.1 | % |  |  | 5.0 | % |
| Settlement of income tax audit |  |  | (20.0 | %) |  |  | - |  |  |  | - |  |
| Non-GAAP effective tax rate |  |  | 16.5 | % |  |  | 18.1 | % |  |  | 16.6 | % |
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |
| TO FREE CASH FLOW (NON-GAAP) |
| (In millions) |
|  |  | Q1'FY15 |  |  | Q4'FY14 |  |  | Q1'FY14 |  |
| Net cash provided by operating activities |  | $ | 215.5 |  |  | $ | 369.5 |  |  | $ | 285.8 |  |
| Purchases of property and equipment |  |  | (58.4 | ) |  |  | (56.0 | ) |  |  | (65.3 | ) |
| Free cash flow |  | $ | 157.1 |  |  | $ | 313.5 |  |  | $ | 220.5 |  |
| INVENTORY TURNS AND RECONCILIATION OF NON-GAAP TO GAAP |
| COST OF REVENUES USED IN INVENTORY TURNS |
| (In millions, except annualized inventory turns) |
|  |  | Q1'FY15 |  |  | Q4'FY14 |  |  | Q1'FY14 |  |
| Annualized inventory turns- GAAP |  |  | 21 |  |  |  | 20 |  |  |  | 21 |  |
| Cost of revenues adjustments |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Annualized inventory turns-Non-GAAP |  |  | 20 |  |  |  | 19 |  |  |  | 20 |  |
| GAAP cost of revenues |  | $ | 551.1 |  |  | $ | 607.0 |  |  | $ | 606.6 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.3 | ) |  |  | (14.3 | ) |  |  | (14.3 | ) |
| Stock-based compensation |  |  | (5.9 | ) |  |  | (5.3 | ) |  |  | (5.3 | ) |
| Non-GAAP cost of revenues |  | $ | 530.9 |  |  | $ | 587.4 |  |  | $ | 587.0 |  |
| Inventory |  | $ | 104.2 |  |  | $ | 122.4 |  |  | $ | 116.5 |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |

[0001102624-14-001312:8k_2_02:61]
17

[0001102624-14-001312:8k_2_02:62]
|  | NETAPP, INC. |  |
|  | RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
|  | EXPRESSED AS EARNINGS PER SHARE |  |
|  | SECOND QUARTER FISCAL 2015 |  |
|  | Second Quarter |  |
|  | Fiscal 2015 |  |
| Non-GAAP Guidance - Net Income Per Share | $0.66 - $0.71 |  |
| Adjustments of Specific Items to |  |  |
| Net Income Per Share for the Second |  |  |
| Quarter Fiscal 2015: |  |  |
| Amortization of intangible assets | (0.05) |  |
| Stock-based compensation expense | (0.20) |  |
| Income tax effect of non-GAAP adjustments | 0.04 |  |
| Total Adjustments | (0.21) |  |
| GAAP Guidance - Net Income Per Share | $0.45 - $0.50 |  |

[0001102624-14-001312:8k_2_02:63]
18
