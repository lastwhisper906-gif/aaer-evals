# NTAP MD&A — 0000950170-21-005014


## mdna

[0000950170-21-005014:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.

[0000950170-21-005014:mdna:2]
[same as prior period, unchanged from 0001564590-21-046976:mdna:3]

[0000950170-21-005014:mdna:3]
[same as prior period, unchanged from 0001564590-21-046976:mdna:4]

[0000950170-21-005014:mdna:4]
[same as prior period, unchanged from 0001564590-21-046976:mdna:5]

[0000950170-21-005014:mdna:5]
As our products and solutions portfolios evolve, market dynamics change, and management continues to assess our largest opportunities, we periodically change how we manage our business. As of the end of our first quarter of fiscal 2022, our Chief Operating Decision Maker (CODM), who is our Chief Executive Officer, realigned internal reporting and began using financial information for components of our business, organized based on category of product/solution, to evaluate performance and allocate resources. This resulted in the creation of two reportable segments for financial reporting purposes: Public Cloud and Hybrid Cloud. Our CODM measures the performance of each segment based on segment revenue and segment gross profit.

[0000950170-21-005014:mdna:6]
[same as prior period, unchanged from 0001564590-21-046976:mdna:7]

[0000950170-21-005014:mdna:7]
[same as prior period, unchanged from 0001564590-21-046976:mdna:8]

[0000950170-21-005014:mdna:8]
[same as prior period, unchanged from 0001564590-21-046976:mdna:9]

[0000950170-21-005014:mdna:9]
[same as prior period, unchanged from 0001564590-21-046976:mdna:10]

[0000950170-21-005014:mdna:10]
During the first six months of fiscal 2022, due to the macroeconomic uncertainty caused by COVID-19, we continue to observe certain customers delaying purchases of our products and services, while other customers accelerate or place new orders to address the demands of remote working and digital business. We also experienced certain logistical challenges in delivering our products and services to customers in certain regions, and minor supply chain constraints. Given uncertainties that exist in the broader technology supply chain, we have begun to invest in inventory and certain longer-term commitments to help mitigate the risk of supply shortages. If supply chain challenges continue it could result in an increase in our cost of revenues.

[0000950170-21-005014:mdna:11]
[same as prior period, unchanged from 0001564590-21-046976:mdna:13]

[0000950170-21-005014:mdna:12]
[same as prior period, unchanged from 0001564590-21-046976:mdna:14]

[0000950170-21-005014:mdna:13]
During the first six months of fiscal 2022, we repurchased 2.7 million shares of our common stock at an average price of $84.88 per share, for an aggregate of $225 million. We also declared aggregate cash dividends of $1.00 per share in that period, for which we paid $224 million.

[0000950170-21-005014:mdna:14]
[same as prior period, unchanged from 0001564590-21-046976:mdna:18]

[0000950170-21-005014:mdna:15]
During the first six months of fiscal 2022, we executed a restructuring plan and recognized expenses totaling $29 million, of which $7 million were recorded in the second quarter of fiscal 2022, consisting primarily of lease termination fees, office relocation costs, and employee severance-related costs.

[0000950170-21-005014:mdna:16]
29

[0000950170-21-005014:mdna:17]
[same as prior period, unchanged from 0001564590-21-046976:mdna:20]

[0000950170-21-005014:mdna:18]
[same as prior period, unchanged from 0001564590-21-046976:mdna:21]

[0000950170-21-005014:mdna:19]
[same as prior period, unchanged from 0001564590-21-046976:mdna:22]

[0000950170-21-005014:mdna:20]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 52 | % |  |  | 53 | % |  |  | 51 | % |  |  | 51 | % |  |
| Services |  |  | 48 |  |  |  | 47 |  |  |  | 49 |  |  |  | 49 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 24 |  |  |  | 25 |  |  |  | 23 |  |  |  | 25 |  |  |
| Cost of services |  |  | 9 |  |  |  | 9 |  |  |  | 9 |  |  |  | 9 |  |  |
| Gross profit |  |  | 68 |  |  |  | 66 |  |  |  | 68 |  |  |  | 66 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 30 |  |  |  | 31 |  |  |  | 30 |  |  |  | 32 |  |  |
| Research and development |  |  | 14 |  |  |  | 15 |  |  |  | 14 |  |  |  | 16 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | — |  |  |  | 3 |  |  |  | 1 |  |  |  | 2 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 49 |  |  |  | 53 |  |  |  | 50 |  |  |  | 55 |  |  |
| Income from operations |  |  | 19 |  |  |  | 13 |  |  |  | 18 |  |  |  | 12 |  |  |
| Other expense, net |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |  |
| Income before income taxes |  |  | 18 |  |  |  | 12 |  |  |  | 17 |  |  |  | 10 |  |  |
| Provision for income taxes |  |  | 4 |  |  |  | 3 |  |  |  | 3 |  |  |  | 2 |  |  |
| Net income |  |  | 14 | % |  |  | 10 | % |  |  | 14 | % |  |  | 8 | % |  |

[0000950170-21-005014:mdna:21]
[same as prior period, unchanged from 0001564590-21-046976:mdna:24]

[0000950170-21-005014:mdna:22]
[same as prior period, unchanged from 0001564590-21-046976:mdna:25]

[0000950170-21-005014:mdna:23]
[same as prior period, unchanged from 0001564590-21-046976:mdna:26]

[0000950170-21-005014:mdna:24]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |
| Net revenues |  | $ | 1,566 |  |  | $ | 1,416 |  |  |  | 11 | % |  | $ | 3,024 |  |  | $ | 2,719 |  |  |  | 11 | % |

[0000950170-21-005014:mdna:25]
The increase in net revenues for the second quarter and first six months of fiscal 2022 compared to the corresponding periods of fiscal 2021 was due to an increase in both product revenues and services revenues. Product revenues as a percentage of net revenues decreased by approximately one percentage point and remained relatively flat in the second quarter and first six months of fiscal 2022, respectively, compared to the corresponding periods of fiscal 2021.

[0000950170-21-005014:mdna:26]
[same as prior period, unchanged from 0001564590-21-046976:mdna:29]

[0000950170-21-005014:mdna:27]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |
| Product revenues |  | $ | 814 |  |  | $ | 749 |  |  |  | 9 | % |  | $ | 1,544 |  |  | $ | 1,376 |  |  |  | 12 | % |
| Hardware (Non-GAAP) |  |  | 339 |  |  |  | 332 |  |  |  | 2 | % |  |  | 655 |  |  |  | 648 |  |  |  | 1 | % |
| Software (Non-GAAP) |  |  | 475 |  |  |  | 417 |  |  |  | 14 | % |  |  | 889 |  |  |  | 728 |  |  |  | 22 | % |

[0000950170-21-005014:mdna:28]
[same as prior period, unchanged from 0001564590-21-046976:mdna:31]

[0000950170-21-005014:mdna:29]
[same as prior period, unchanged from 0001564590-21-046976:mdna:44]

[0000950170-21-005014:mdna:30]
Product revenues are derived through the sale of our Hybrid Cloud solutions and consist of sales of configured all-flash array and hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, NetApp HCI, StorageGrid, OEM products and add-on optional software.

[0000950170-21-005014:mdna:31]
[same as prior period, unchanged from 0001564590-21-046976:mdna:33]

[0000950170-21-005014:mdna:32]
Total product revenues increased in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of the prior year, primarily driven by an increase in sales of all-flash array systems.

[0000950170-21-005014:mdna:33]
Revenues from the hardware component of product revenues represented 42% of product revenues in both the second quarter and first six months of fiscal 2022, compared to 44% and 47% of product revenues in the corresponding periods of the prior year. The software component of product revenues represented 58% of product revenues in both the second quarter and first six months of fiscal 2022, compared to 56% and 53% of product revenues in the corresponding periods of the prior year. The increase in the software component percentage of product revenues in the second quarter and first six months of fiscal 2022 is primarily due to the mix of systems sold, including a higher mix of all-flash array systems, which contain a higher proportion of software components than other Hybrid Cloud products.

[0000950170-21-005014:mdna:34]
[same as prior period, unchanged from 0001564590-21-046976:mdna:36]

[0000950170-21-005014:mdna:35]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |
| Services revenues |  | $ | 752 |  |  | $ | 667 |  |  |  | 13 | % |  | $ | 1,480 |  |  | $ | 1,343 |  |  |  | 10 | % |
| Support |  |  | 590 |  |  |  | 553 |  |  |  | 7 | % |  |  | 1,168 |  |  |  | 1,130 |  |  |  | 3 | % |
| Professional and other services |  |  | 75 |  |  |  | 67 |  |  |  | 12 | % |  |  | 146 |  |  |  | 135 |  |  |  | 8 | % |
| Public cloud |  |  | 87 |  |  |  | 47 |  |  |  | 85 | % |  |  | 166 |  |  |  | 78 |  |  |  | 113 | % |

[0000950170-21-005014:mdna:36]
[same as prior period, unchanged from 0001564590-21-046976:mdna:38]

[0000950170-21-005014:mdna:37]
[same as prior period, unchanged from 0001564590-21-046976:mdna:39]

[0000950170-21-005014:mdna:38]
Support revenues increased in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of the prior year, despite an extra week in the first quarter of fiscal 2021 that contributed approximately $40 million of revenues in that period. The increases are primarily due to an increase in our installed base and a higher mix of all-flash systems (which carry a higher support dollar content than our other products) in the current year.

[0000950170-21-005014:mdna:39]
Professional and other services revenues increased in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of the prior year primarily due to an increase in demand from increased product sales.

[0000950170-21-005014:mdna:40]
[same as prior period, unchanged from 0001564590-21-046976:mdna:41]

[0000950170-21-005014:mdna:41]
[same as prior period, unchanged from 0001564590-21-046976:mdna:42]

[0000950170-21-005014:mdna:42]
Public Cloud revenues increased in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of the prior year primarily due to strong customer demand for NetApp’s diversified cloud offerings, coupled with overall growth in the cloud market. The first six months of fiscal 2022 also benefitted from the acquisition of Spot, Inc. late in the first quarter of fiscal 2021.

[0000950170-21-005014:mdna:43]
[same as prior period, unchanged from 0001564590-21-046976:mdna:45]

[0000950170-21-005014:mdna:44]
[same as prior period, unchanged from 0001564590-21-046976:mdna:46]

[0000950170-21-005014:mdna:45]
[same as prior period, unchanged from 0001564590-21-046976:mdna:62]

[0000950170-21-005014:mdna:46]
[same as prior period, unchanged from 0001564590-21-046976:mdna:47]

[0000950170-21-005014:mdna:47]
[same as prior period, unchanged from 0001564590-21-046976:mdna:48]

[0000950170-21-005014:mdna:48]
[same as prior period, unchanged from 0001564590-21-046976:mdna:49]

[0000950170-21-005014:mdna:49]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |
| Cost of product revenues |  | $ | 372 |  |  | $ | 360 |  |  |  | 3 | % |  | $ | 701 |  |  | $ | 676 |  |  |  | 4 | % |
| Hybrid Cloud |  |  | 369 |  |  |  | 352 |  |  |  | 5 | % |  |  | 695 |  |  |  | 657 |  |  |  | 6 | % |
| Unallocated |  |  | 3 |  |  |  | 8 |  |  |  | (63 | )% |  |  | 6 |  |  |  | 19 |  |  |  | (68 | )% |

[0000950170-21-005014:mdna:50]
[same as prior period, unchanged from 0001564590-21-046976:mdna:51]

[0000950170-21-005014:mdna:51]
Cost of Hybrid Cloud product revenues represented 46% and 45% of product revenues for the second quarter and first six months of fiscal 2022, respectively, compared to 48% and 49% for the corresponding periods of fiscal 2021. Materials costs represented 92% and 91% of cost of Hybrid Cloud product revenues for the second quarter and first six months of fiscal 2022, respectively, compared to 89% and 88% in the corresponding periods of fiscal 2021.

[0000950170-21-005014:mdna:52]
Materials costs increased by approximately $22 million and $39 million in the second quarter and first six months of fiscal 2022  compared to the corresponding periods of the prior year, reflecting the increases in product revenues in the current year periods and the mix of systems sold in the respective periods.

[0000950170-21-005014:mdna:53]
Hybrid Cloud product gross margins increased by approximately two percentage points and three percentage points in the second quarter and first six months of fiscal 2022, respectively, compared to the corresponding periods of the prior year. The increases are primarily due to the mix of systems sold, including a higher mix of all-flash array systems which have higher margins than hybrid systems.

[0000950170-21-005014:mdna:54]
[same as prior period, unchanged from 0001564590-21-046976:mdna:55]

[0000950170-21-005014:mdna:55]
Unallocated cost of product revenues decreased in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of the prior year due to certain intangible assets becoming fully amortized in the second half of fiscal 2021.

[0000950170-21-005014:mdna:56]
[same as prior period, unchanged from 0001564590-21-046976:mdna:57]

[0000950170-21-005014:mdna:57]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |
| Cost of services revenues |  | $ | 135 |  |  | $ | 123 |  |  |  | 10 | % |  | $ | 265 |  |  | $ | 238 |  |  |  | 11 | % |
| Support |  |  | 48 |  |  |  | 50 |  |  |  | (4 | )% |  |  | 96 |  |  |  | 101 |  |  |  | (5 | )% |
| Professional and other services |  |  | 54 |  |  |  | 50 |  |  |  | 8 | % |  |  | 105 |  |  |  | 98 |  |  |  | 7 | % |
| Public cloud |  |  | 25 |  |  |  | 16 |  |  |  | 56 | % |  |  | 48 |  |  |  | 29 |  |  |  | 66 | % |
| Unallocated |  |  | 8 |  |  |  | 7 |  |  |  | 14 | % |  |  | 16 |  |  |  | 10 |  |  |  | 60 | % |

[0000950170-21-005014:mdna:58]
[same as prior period, unchanged from 0001564590-21-046976:mdna:59]

[0000950170-21-005014:mdna:59]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, was relatively flat in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of fiscal 2021. Cost of Hybrid Cloud services revenues represented 15% of Hybrid Cloud services revenues in the second quarter and first six months of fiscal 2022 and 16% of Hybrid Cloud services revenues in the corresponding periods of the prior year.

[0000950170-21-005014:mdna:60]
Hybrid Cloud support gross margins increased by one percentage point each in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of the prior year due to growth in support revenues achieved with a consistent cost base. Hybrid Cloud professional services gross margins increased by three percentage points and one percentage point in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of the prior year.

[0000950170-21-005014:mdna:61]
32

[0000950170-21-005014:mdna:62]
[same as prior period, unchanged from 0001564590-21-046976:mdna:61]

[0000950170-21-005014:mdna:63]
Cost of Public Cloud revenues increased in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of fiscal 2021 reflecting the increase in Public Cloud revenues. Public Cloud gross margins increased by five percentage points and eight percentage points in the second quarter and first six months of fiscal 2022, respectively, compared to the corresponding periods of fiscal 2021, reflecting efficiencies from scaling our Public Cloud segment.

[0000950170-21-005014:mdna:64]
[same as prior period, unchanged from 0001564590-21-046976:mdna:64]

[0000950170-21-005014:mdna:65]
Unallocated cost of services revenues was relatively flat in the second quarter of fiscal 2022 compared to the second quarter of fiscal 2021, while it increased in the first six months of fiscal 2022 compared to the corresponding period of fiscal 2021 due to our acquisition of Spot, Inc. in the first quarter of fiscal 2021 which resulted in higher amortization expense for certain intangible assets.

[0000950170-21-005014:mdna:66]
[same as prior period, unchanged from 0001564590-21-046976:mdna:66]

[0000950170-21-005014:mdna:67]
[same as prior period, unchanged from 0001564590-21-046976:mdna:67]

[0000950170-21-005014:mdna:68]
Sales and marketing, research and development, and general and administrative expenses for the second quarter and first six months of fiscal 2022 totaled $757 million, or 48% of net revenues, and $1,484 million, or 49% of net revenues, respectively, reflecting a decrease of two percentage points and four percentage points, respectively, compared to the corresponding periods of fiscal 2021.

[0000950170-21-005014:mdna:69]
[same as prior period, unchanged from 0001564590-21-046976:mdna:69]

[0000950170-21-005014:mdna:70]
Total compensation costs included in operating expenses increased by $38 million, or 9%, in the second quarter of fiscal 2022 compared to the corresponding period of the prior year, reflecting an increase of all components of compensation costs.

[0000950170-21-005014:mdna:71]
Total compensation costs included in operating expenses increased by $17 million, or 2%, in the first six months of fiscal 2022 compared to the corresponding period of the prior year, primarily due to higher salaries and stock-based compensation expenses. Total compensation costs for the first six months of fiscal 2021 includes the impact of an additional week in the first quarter of fiscal 2021.

[0000950170-21-005014:mdna:72]
[same as prior period, unchanged from 0001564590-21-046976:mdna:71]

[0000950170-21-005014:mdna:73]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 465 |  |  | $ | 432 |  |  |  | 8 | % |  | $ | 916 |  |  | $ | 861 |  |  |  | 6 | % |

[0000950170-21-005014:mdna:74]
[same as prior period, unchanged from 0001564590-21-046976:mdna:73]

[0000950170-21-005014:mdna:75]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2022 to Fiscal 2021 |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  | 6 |  |  |  | 3 |  |
| Commissions |  |  | 2 |  |  |  | 2 |  |
| Advertising and marketing promotional expense |  |  | — |  |  |  | 1 |  |
| Total change |  |  | 8 |  |  |  | 6 |  |

[0000950170-21-005014:mdna:76]
The increase in compensation costs for the second quarter and first six months of fiscal 2022 compared to the corresponding periods of the prior year reflected an increase in average headcount of approximately 4% and 5%, respectively. The expansion of our sales and marketing teams are expected to support our ability to execute on key market opportunities.

[0000950170-21-005014:mdna:77]
The increase in commissions expense for the second quarter and first six months of fiscal 2022 is primarily due to higher performance against sales goals.

[0000950170-21-005014:mdna:78]
Advertising and marketing promotional expense increased in the first six months of fiscal 2022 compared to the corresponding period of the prior year, primarily due to higher spending levels on certain projects executed during the first quarter of fiscal 2022.

[0000950170-21-005014:mdna:79]
[same as prior period, unchanged from 0001564590-21-046976:mdna:77]

[0000950170-21-005014:mdna:80]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |
| Research and development expenses |  | $ | 216 |  |  | $ | 212 |  |  |  | 2 | % |  | $ | 426 |  |  | $ | 445 |  |  |  | (4 | )% |

[0000950170-21-005014:mdna:81]
[same as prior period, unchanged from 0001564590-21-046976:mdna:79]

[0000950170-21-005014:mdna:82]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2022 to Fiscal 2021 |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  | 4 |  |  |  | (4 | ) |
| Other |  |  | (2 | ) |  |  | — |  |
| Total change |  |  | 2 |  |  |  | (4 | ) |

[0000950170-21-005014:mdna:83]
The increase in compensation costs for the second quarter of fiscal 2022 compared to the corresponding period in the prior year was primarily attributable to higher incentive compensation expense as a result of stronger company achievement against financial targets. The decrease in compensation costs for the six months of fiscal 2022 compared to the corresponding period in the prior year was attributable to a decrease in average headcount of 5%, primarily resulting from the restructuring plans we implemented in fiscal 2020 which were completed during the first half of fiscal 2021.

[0000950170-21-005014:mdna:84]
[same as prior period, unchanged from 0001564590-21-046976:mdna:82]

[0000950170-21-005014:mdna:85]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |
| General and administrative expenses |  | $ | 76 |  |  | $ | 67 |  |  |  | 13 | % |  | $ | 142 |  |  | $ | 128 |  |  |  | 11 | % |

[0000950170-21-005014:mdna:86]
[same as prior period, unchanged from 0001564590-21-046976:mdna:84]

[0000950170-21-005014:mdna:87]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2022 to Fiscal 2021 |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  | 10 |  |  |  | 4 |  |
| Professional and legal fees and outside services |  |  | 8 |  |  |  | 7 |  |
| Litigation settlement |  |  | (7 | ) |  |  | (4 | ) |
| Facilities and IT support costs |  |  | 1 |  |  |  | 1 |  |
| Other |  |  | 1 |  |  |  | 3 |  |
| Total change |  |  | 13 |  |  |  | 11 |  |

[0000950170-21-005014:mdna:88]
The increase in compensation costs in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of the prior year was primarily attributable to higher stock-based compensation expense. The increase in professional and legal fees and outside services expense in the second quarter and first six months of fiscal 2022 was primarily due to higher spending on business transformation projects and an increase in legal fees. During the second quarter of fiscal 2021, we incurred a litigation settlement charge of approximately $5 million.

[0000950170-21-005014:mdna:89]
[same as prior period, unchanged from 0001564590-21-046976:mdna:87]

[0000950170-21-005014:mdna:90]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |
| Restructuring charges |  | $ | 7 |  |  | $ | 37 |  |  | NM |  | $ | 29 |  |  | $ | 42 |  |  | NM |

[0000950170-21-005014:mdna:91]
[same as prior period, unchanged from 0001564590-21-046976:mdna:89]

[0000950170-21-005014:mdna:92]
In the second quarter and first six months of fiscal 2022, we recognized $7 million and $29 million, respectively, in restructuring costs, consisting primarily of lease termination fees, office relocation costs, and employee severance-related costs.

[0000950170-21-005014:mdna:93]
[same as prior period, unchanged from 0001564590-21-046976:mdna:91]

[0000950170-21-005014:mdna:94]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |
| Acquisition-related expense |  | $ | 1 |  |  | $ | 3 |  |  | NM |  | $ | 2 |  |  | $ | 11 |  |  | NM |

[0000950170-21-005014:mdna:95]
[same as prior period, unchanged from 0001564590-21-046976:mdna:93]

[0000950170-21-005014:mdna:96]
In the first six months of fiscal 2022, we incurred $2 million of acquisition-related costs, primarily legal and consulting fees.

[0000950170-21-005014:mdna:97]
[same as prior period, unchanged from 0001564590-21-046976:mdna:96]

[0000950170-21-005014:mdna:98]
[same as prior period, unchanged from 0001564590-21-046976:mdna:97]

[0000950170-21-005014:mdna:99]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |
| Interest income |  | $ | 1 |  |  | $ | 2 |  |  |  | (50 | )% |  | $ | 3 |  |  | $ | 5 |  |  |  | (40 | )% |
| Interest expense |  |  | (18 | ) |  |  | (18 | ) |  |  | — | % |  |  | (36 | ) |  |  | (36 | ) |  |  | — | % |
| Other income (expense), net |  |  | 3 |  |  |  | 9 |  |  |  | (67 | )% |  |  | 7 |  |  |  | (8 | ) |  |  | (188 | )% |
| Total |  | $ | (14 | ) |  | $ | (7 | ) |  |  | 100 | % |  | $ | (26 | ) |  | $ | (39 | ) |  |  | (33 | )% |

[0000950170-21-005014:mdna:100]
Interest income decreased in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of the prior year due to both a reduction in the size of our investment portfolio and lower yields earned on the investments. Interest expense remained flat in the second quarter and first six months of fiscal 2022 compared to the corresponding periods of fiscal 2021.

[0000950170-21-005014:mdna:101]
The differences in other income (expense), net for the second quarter and first six months of fiscal 2022 as compared to the corresponding periods of the prior year are partially due to foreign exchange gains and losses year-over-year. In the first six months of fiscal 2021, other income (expense), net includes a $14 million loss recognized from the extinguishment of our Senior Notes due June 2021.

[0000950170-21-005014:mdna:102]
[same as prior period, unchanged from 0001564590-21-046976:mdna:101]

[0000950170-21-005014:mdna:103]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | % Change |  |
| Provision for income taxes |  | $ | 56 |  |  | $ | 38 |  |  |  | 47 | % |  | $ | 91 |  |  | $ | 65 |  |  |  | 40 | % |

[0000950170-21-005014:mdna:104]
Our effective tax rate for the second quarter of fiscal 2022 was 20.0% compared to 21.7% for the second quarter of fiscal 2021. Our effective tax rate for the first six months of fiscal 2022 was 17.6% compared to 23.3% for the first six months of fiscal 2021. Our effective tax rates reflect the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate for the second quarter and first six months of fiscal 2022 decreased compared to the corresponding periods of the prior year due to discrete tax benefits for lapses of statute of limitations as well as increased benefits related to stock-based compensation. Additionally, the corresponding periods of the prior year included tax charges for the integration of acquired companies.

[0000950170-21-005014:mdna:105]
As of October 29, 2021, we had $214 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $110 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $111 million have been recorded in other long-term liabilities.

[0000950170-21-005014:mdna:106]
[same as prior period, unchanged from 0001564590-21-046976:mdna:105]

[0000950170-21-005014:mdna:107]
[same as prior period, unchanged from 0001564590-21-046976:mdna:106]

[0000950170-21-005014:mdna:108]
| (In millions, except percentages) |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Cash, cash equivalents and short-term investments |  | $ | 4,548 |  |  | $ | 4,596 |  |
| Principal amount of debt |  | $ | 2,650 |  |  | $ | 2,650 |  |

[0000950170-21-005014:mdna:109]
[same as prior period, unchanged from 0001564590-21-046976:mdna:108]

[0000950170-21-005014:mdna:110]
|  |  | Six Months Ended |  |
| (In millions) |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Net cash provided by operating activities |  | $ | 540 |  |  | $ | 401 |  |
| Net cash used in investing activities |  |  | (85 | ) |  |  | (321 | ) |
| Net cash (used in) provided by financing activities |  |  | (461 | ) |  |  | 746 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (13 | ) |  |  | 44 |  |
| Net change in cash, cash equivalents and restricted cash |  | $ | (19 | ) |  | $ | 870 |  |

[0000950170-21-005014:mdna:111]
[same as prior period, unchanged from 0001564590-21-046976:mdna:110]

[0000950170-21-005014:mdna:112]
As of October 29, 2021, our cash, cash equivalents and short-term investments were $4.5 billion, which represents a decrease of $48 million for the first six months of fiscal 2022. During the first six months of fiscal 2022, we generated $540 million of cash from operating activities, offset by $224 million used for the payment of dividends, $225 million used to repurchase shares of our common stock, $97 million in purchases of property and equipment, and $14 million, net of cash acquired, used for the acquisition of a privately-held company. Net working capital was $2.5 billion as of October 29, 2021, approximately flat when compared to April 30, 2021.

[0000950170-21-005014:mdna:113]
[same as prior period, unchanged from 0001564590-21-046976:mdna:112]

[0000950170-21-005014:mdna:114]
During the first six months of fiscal 2022, we generated cash from operating activities of $540 million, reflecting net income of $426 million, adjusted by non-cash depreciation and amortization of $92 million and non-cash stock-based compensation expense of $115 million, compared to $401 million of cash generated from operating activities during the first six months of fiscal 2021.

[0000950170-21-005014:mdna:115]
Significant changes in assets and liabilities in the first six months of fiscal 2022 included the following:

[0000950170-21-005014:mdna:116]

Accounts receivable decreased $292 million, reflecting more favorable shipping linearity and seasonally lower billings for the first six months of fiscal 2022 compared to the last six months of fiscal 2021.

[0000950170-21-005014:mdna:117]

Accrued expenses decreased by $206 million, primarily due to employee compensation payouts related to fiscal year 2021 commissions and incentive compensation plans.

[0000950170-21-005014:mdna:118]

Deferred revenue and financed unearned services revenue decreased by $97 million, primarily due to a decrease in deferred software and hardware maintenance contract revenues reflecting the seasonality of maintenance contract renewal activities.

[0000950170-21-005014:mdna:119]

Long-term taxes payables decreased by $65 million, primarily due to reclassification of transition taxes associated with U.S. tax reform from long-term taxes payable to current taxes payable.

[0000950170-21-005014:mdna:120]
[same as prior period, unchanged from 0001564590-21-046976:mdna:117]

[0000950170-21-005014:mdna:121]
[same as prior period, unchanged from 0001564590-21-046976:mdna:118]

[0000950170-21-005014:mdna:122]
During the first six months of fiscal 2022, we generated $26 million from maturities of investments, net of purchases, and paid $97 million for capital expenditures, while during the same period of fiscal 2021, we generated $107 million from maturities and sales of investments, net of purchases, and paid $92 million for capital expenditures. Additionally, during the first six months of fiscal 2022, we paid $14 million, net of cash acquired for a privately-held company, as compared to $350 million, net of cash acquired that we paid for two privately-held companies in the first six months of fiscal 2021.

[0000950170-21-005014:mdna:123]
[same as prior period, unchanged from 0001564590-21-046976:mdna:120]

[0000950170-21-005014:mdna:124]
During the first six months of fiscal 2022, cash flows used in financing activities totaled $461 million and include $225 million for the repurchase of approximately three million shares of common stock and $224 million for the payment of dividends. During the first six months of fiscal 2021, cash flows provided by financing activities totaled $746 million, and were primarily due to net cash proceeds of $2.0 billion from the issuance of Senior Notes, partially offset by the use of $513 million for the extinguishment of Senior Notes due June 2021 and $420 million for the net repayment of commercial paper notes with original maturities of three months or less, $214 million for the payment of dividends, and $176 million for the repayment of commercial paper notes with original maturities of greater than three months.

[0000950170-21-005014:mdna:125]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all. For further discussion of factors that could affect our cash flows and liquidity requirements, including the impact of the COVID-19 pandemic, see Part II, Item 1A. Risk Factors.

[0000950170-21-005014:mdna:126]
[same as prior period, unchanged from 0001564590-21-046976:mdna:123]

[0000950170-21-005014:mdna:127]
Our principal sources of liquidity as of October 29, 2021 consisted of cash and cash equivalents, short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-21-005014:mdna:128]
[same as prior period, unchanged from 0001564590-21-046976:mdna:126]

[0000950170-21-005014:mdna:129]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Cash and cash equivalents |  | $ | 4,509 |  |  | $ | 4,529 |  |
| Short-term investments |  |  | 39 |  |  |  | 67 |  |
| Total |  | $ | 4,548 |  |  | $ | 4,596 |  |

[0000950170-21-005014:mdna:130]
As of October 29, 2021 and April 30, 2021, $1.7 billion and $2.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $2.8 billion and $2.1 billion, respectively, were available in the U.S.

[0000950170-21-005014:mdna:131]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies through asset purchases and/or business acquisitions, service interest and principal payments on our debt, fund our stock repurchase program, and pay dividends, as and if declared. In the ordinary course of business, we engage in periodic reviews of opportunities to invest in or acquire companies or units in companies to expand our total addressable market, leverage technological synergies and establish new streams of revenue, particularly in our Public Cloud segment.

[0000950170-21-005014:mdna:132]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 29, 2021.

[0000950170-21-005014:mdna:133]
[same as prior period, unchanged from 0001564590-21-046976:mdna:131]

[0000950170-21-005014:mdna:134]
37

[0000950170-21-005014:mdna:135]
[same as prior period, unchanged from 0001564590-21-046976:mdna:132]

[0000950170-21-005014:mdna:136]
The following table summarizes the principal amount of our Senior Notes as of October 29, 2021 (in millions):

[0000950170-21-005014:mdna:137]
| 3.25% Senior Notes Due December 2022 |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,650 |  |

[0000950170-21-005014:mdna:138]
[same as prior period, unchanged from 0001564590-21-046976:mdna:135]

[0000950170-21-005014:mdna:139]
Commercial Paper Program and Credit Facility

[0000950170-21-005014:mdna:140]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of October 29, 2021.

[0000950170-21-005014:mdna:141]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 29, 2021, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-21-005014:mdna:142]
[same as prior period, unchanged from 0001564590-21-046976:mdna:139]

[0000950170-21-005014:mdna:143]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2022 to be between $100 million and $150 million.

[0000950170-21-005014:mdna:144]
[same as prior period, unchanged from 0001564590-21-046976:mdna:141]

[0000950170-21-005014:mdna:145]
On November 22, 2021, we declared a cash dividend of $0.50 per share of common stock, payable on January 26, 2022 to holders of record as of the close of business on January 7, 2022.

[0000950170-21-005014:mdna:146]
As of October 29, 2021, our Board of Directors has authorized the repurchase of up to $14.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through October 29, 2021, we repurchased a total of 343 million shares of our common stock at an average price of $39.37 per share, for an aggregate purchase price of $13.5 billion. As of October 29, 2021, the remaining authorized amount for stock repurchases under this program was $0.6 billion.

[0000950170-21-005014:mdna:147]
[same as prior period, unchanged from 0001564590-21-046976:mdna:144]

[0000950170-21-005014:mdna:148]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled $1,053 million at October 29, 2021.

[0000950170-21-005014:mdna:149]
[same as prior period, unchanged from 0001564590-21-046976:mdna:156]

[0000950170-21-005014:mdna:150]
[same as prior period, unchanged from 0001564590-21-046976:mdna:146]

[0000950170-21-005014:mdna:151]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $38 million and $26 million of receivables during the first six months of fiscal 2022 and fiscal 2021, respectively.

[0000950170-21-005014:mdna:152]
[same as prior period, unchanged from 0001564590-21-046976:mdna:148]

[0000950170-21-005014:mdna:153]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of October 29, 2021 and April 30, 2021, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-21-005014:mdna:154]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of October 29, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-21-005014:mdna:155]
Legal Contingencies

[0000950170-21-005014:mdna:156]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0000950170-21-005014:mdna:157]
[same as prior period, unchanged from 0001564590-21-046976:mdna:153]

[0000950170-21-005014:mdna:158]
[same as prior period, unchanged from 0001564590-21-046976:mdna:154]

[0000950170-21-005014:mdna:159]
The summary of our significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of our fiscal 2021 Form 10-K. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report.

[0000950170-21-005014:mdna:160]
39
