# NTAP note change history — 0001564590-21-046976 → 0000950170-21-005014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-12-02):
[0000950170-21-005014:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 29, 2021, we had $735 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 29, 2021 and April 30, 2021, such liability amounted to $14 million and $15 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2021-09-02, similarity 0.9888):
[0001564590-21-046976:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 30, 2021, we had $614 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 30, 2021 and April 30, 2021, such liability amounted to $13 million and $15 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2021-12-02):
[0000950170-21-005014:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 29, 2021, we had $318 million in other purchase obligations.
  (was, 2021-09-02, similarity 0.9825):
[0001564590-21-046976:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 30, 2021, we had $340 million in other purchase obligations.

- changed (2021-12-02):
[0000950170-21-005014:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $38 million and $26 million of receivables during the six months ended October 29, 2021 and October 30, 2020, respectively.
  (was, 2021-09-02, similarity 0.9713):
[0001564590-21-046976:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $17 million and $13 million of receivables during the three months ended July 30, 2021 and July 31, 2020, respectively.

- changed (2021-12-02):
[0000950170-21-005014:note_history:4]
Some of the leasing agreements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 29, 2021 and April 30, 2021, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2021-09-02, similarity 0.9915):
[0001564590-21-046976:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 30, 2021 and April 30, 2021, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- added (2021-12-02):
[0000950170-21-005014:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 29, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2021-12-02):
[0000950170-21-005014:note_history:6]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. The defendants' Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp and the other defendants. On March 26, 2021, Plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (“MOU”) providing for the settlement of the class action.  Pursuant to the terms of MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties subsequently executed a stipulation of settlement, which contains no admission of liability, wrongdoing or responsibility by any of the parties, and which provides that the class action will be dismissed with prejudice, with mutual releases by all parties, upon final court approval. On September 24, 2021, plaintiff filed an unopposed motion seeking court approval of the settlement, but no order has issued regarding that motion. The settlement remains subject to court approval.
  (was, 2021-09-02, similarity 0.8417):
[0001564590-21-046976:note_history:6]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. NetApp’s Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp. On March 26, 2021, Plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (“MOU”) providing for the settlement of the class action.  Pursuant to the terms of MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties further agreed to negotiate in good faith to execute definitive stipulations of settlement and related documents to be filed with the court, which will not contain any admission of liability, wrongdoing or responsibility by any of the parties and will provide that upon final approval of the settlement, the class action will be dismissed with prejudice, with mutual releases by all parties. The settlement is subject to court approval.

- changed (2021-12-02):
[0000950170-21-005014:note_history:7]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of October 29, 2021 related to such matters.
  (was, 2021-09-02, similarity 0.9938):
[0001564590-21-046976:note_history:7]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of July 30, 2021 related to such matters.

- removed (2021-12-02):
[0001564590-21-046976:note_history:8]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 30, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-12-02):
[0000950170-21-005014:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 30, 2021 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 29, 2021 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2021-09-02, similarity 0.8787):
[0001564590-21-046976:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 30, 2021 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 30, 2021 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-12-02):
[0000950170-21-005014:note_history:10]
|  |  | Effective Interest Rate |  | October 29, 2021 |  |  | April 30, 2021 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (16 | ) |  |  | (18 | ) |
| Total long-term debt |  |  |  | $ | 2,634 |  |  | $ | 2,632 |  |
  (was, 2021-09-02, similarity 0.9686):
[0001564590-21-046976:note_history:10]
|  |  | Effective Interest Rate |  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (17 | ) |  |  | (18 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,633 |  |  | $ | 2,632 |  |

- changed (2021-12-02):
[0000950170-21-005014:note_history:11]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 29, 2021, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2021-09-02, similarity 0.9915):
[0001564590-21-046976:note_history:11]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 30, 2021, we were in compliance with all covenants associated with the Senior Notes.

- changed (2021-12-02):
[0000950170-21-005014:note_history:12]
As of October 29, 2021, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2021-09-02, similarity 0.9405):
[0001564590-21-046976:note_history:12]
As of July 30, 2021, our aggregate future principal debt maturities are as follows (in millions):

- changed (2021-12-02):
[0000950170-21-005014:note_history:13]
| Fiscal Year |  | Amount |  |
| 2022 (remainder) |  | $ | — |  |
| 2023 |  |  | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |
  (was, 2021-09-02, similarity 0.9632):
[0001564590-21-046976:note_history:13]
| Fiscal Year |  | Amount |  |
| 2022 |  | $ | — |  |
| 2023 |  |  | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

- added (2021-12-02):
[0000950170-21-005014:note_history:14]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may

- added (2021-12-02):
[0000950170-21-005014:note_history:15]
be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of October 29, 2021 or April 30, 2021. During the first six months of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $176 million for the settlement, of commercial paper notes with original maturities greater than three months.

- changed (2021-12-02):
[0000950170-21-005014:note_history:16]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 29, 2021, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.
  (was, 2021-09-02, similarity 0.9931):
[0001564590-21-046976:note_history:16]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 30, 2021, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.

- removed (2021-12-02):
[0001564590-21-046976:note_history:17]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. While no commercial paper notes were outstanding as of July 30, 2021, we had commercial paper notes outstanding with an aggregate principal amount of $150 million, a weighted-average interest rate of 1.29%, and maturities primarily less than three months as of July 31, 2020. During the first three months of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $76 million for the settlement, of commercial paper notes with original maturities greater than three months.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-12-02):
[0000950170-21-005014:note_history:18]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 29, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- removed (2021-12-02):
[0001564590-21-046976:note_history:19]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 30, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-12-02):
[0000950170-21-005014:note_history:20]
|  |  | Effective Interest Rate |  | October 29, 2021 |  |  | April 30, 2021 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (16 | ) |  |  | (18 | ) |
| Total long-term debt |  |  |  | $ | 2,634 |  |  | $ | 2,632 |  |
  (was, 2021-09-02, similarity 0.9686):
[0001564590-21-046976:note_history:20]
|  |  | Effective Interest Rate |  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (17 | ) |  |  | (18 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,633 |  |  | $ | 2,632 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-12-02):
[0000950170-21-005014:note_history:21]
As of October 29, 2021, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2021-09-02, similarity 0.9405):
[0001564590-21-046976:note_history:21]
As of July 30, 2021, our aggregate future principal debt maturities are as follows (in millions):

- changed (2021-12-02):
[0000950170-21-005014:note_history:22]
| Fiscal Year |  | Amount |  |
| 2022 (remainder) |  | $ | — |  |
| 2023 |  |  | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |
  (was, 2021-09-02, similarity 0.9632):
[0001564590-21-046976:note_history:22]
| Fiscal Year |  | Amount |  |
| 2022 |  | $ | — |  |
| 2023 |  |  | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-12-02):
[0000950170-21-005014:note_history:23]
16. Subsequent Event

- added (2021-12-02):
[0000950170-21-005014:note_history:24]
On November 5, 2021, we acquired all the outstanding shares of privately-held CloudCheckr Inc., a leading cloud optimization platform that provides cloud visibility and insights to lower costs, maintain security and compliance, and optimize cloud resources.  We are in the process of completing the allocation of approximately $348 million of purchase price among the assets acquired and liabilities assumed.
