# NTAP notes — 0000950170-21-005014


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-21-005014:notes:1]
1. Description of Business and Significant Accounting Policies

[0000950170-21-005014:notes:2]
[same as prior period, unchanged from 0001564590-21-046976:notes:2]

[0000950170-21-005014:notes:3]
[same as prior period, unchanged from 0001564590-21-046976:notes:3]

[0000950170-21-005014:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2022, ending on April 29, 2022, is a 52-week year, with 13 weeks in each of its quarters. Fiscal year 2021, ended on April 30, 2021 was a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter.

[0000950170-21-005014:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 30, 2021 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 29, 2021 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0000950170-21-005014:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandemic.

[0000950170-21-005014:notes:7]
[same as prior period, unchanged from 0001564590-21-046976:notes:7]

[0000950170-21-005014:notes:8]
[same as prior period, unchanged from 0001564590-21-046976:notes:8]

[0000950170-21-005014:notes:9]
[same as prior period, unchanged from 0001564590-21-046976:notes:9]

[0000950170-21-005014:notes:10]
[same as prior period, unchanged from 0001564590-21-046976:notes:10]

[0000950170-21-005014:notes:11]
[same as prior period, unchanged from 0001564590-21-046976:notes:11]

[0000950170-21-005014:notes:12]
[same as prior period, unchanged from 0001564590-21-046976:notes:12]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-21-005014:notes:13]
2. Recent Accounting Pronouncements

[0000950170-21-005014:notes:14]
Although there are several new accounting pronouncements issued or proposed by the FASB that we have adopted or will adopt, as applicable, we do not believe any of these accounting pronouncements had or will have a material impact on our consolidated financial position, results of operations, cash flows or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-21-005014:notes:15]
[same as prior period, unchanged from 0001564590-21-046976:notes:15]

[0000950170-21-005014:notes:16]
Fiscal 2022 Acquisition

[0000950170-21-005014:notes:17]
[same as prior period, unchanged from 0001564590-21-046976:notes:16]

[0000950170-21-005014:notes:18]
[same as prior period, unchanged from 0001564590-21-046976:notes:17]

[0000950170-21-005014:notes:19]
[same as prior period, unchanged from 0001564590-21-046976:notes:18]

[0000950170-21-005014:notes:20]
[same as prior period, unchanged from 0001564590-21-046976:notes:19]

[0000950170-21-005014:notes:21]
The results of operations related to this acquisition have been included in our condensed consolidated statements of income from the acquisition date. Pro forma results of operations have not been presented because the impact from the acquisition is not material to our consolidated results of operations.

[0000950170-21-005014:notes:22]
Fiscal 2021 Acquisitions

[0000950170-21-005014:notes:23]
[same as prior period, unchanged from 0001564590-21-046976:notes:21]

[0000950170-21-005014:notes:24]
On April 28, 2020, we acquired all the outstanding shares of privately-held Cloud Jumper Corporation (Cloud Jumper), a provider of virtual desktop infrastructure and remote desktop services solutions based in North Carolina, for $34 million in cash.

[0000950170-21-005014:notes:25]
The acquisition date fair values of the assets acquired and liabilities assumed were as follows (in millions):

[0000950170-21-005014:notes:26]
[same as prior period, unchanged from 0001564590-21-046976:notes:24]

[0000950170-21-005014:notes:27]
[same as prior period, unchanged from 0001564590-21-046976:notes:25]

[0000950170-21-005014:notes:28]
On July 9, 2020, we acquired all the outstanding shares of privately-held Spot, Inc. (Spot), a provider of compute management cost optimization services on the public clouds based in Israel, for $340 million in cash.

[0000950170-21-005014:notes:29]
[same as prior period, unchanged from 0001564590-21-046976:notes:27]

[0000950170-21-005014:notes:30]
[same as prior period, unchanged from 0001564590-21-046976:notes:28]

[0000950170-21-005014:notes:31]
|  |  | Amount |  |  | Estimated useful life(years) |  |
| Developed technology |  | $ | 53 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 28 |  |  |  | 5 |  |
| Trade name |  |  | 3 |  |  |  | 3 |  |
| Total intangible assets |  | $ | 84 |  |  |  |  |

[0000950170-21-005014:notes:32]
[same as prior period, unchanged from 0001564590-21-046976:notes:30]

[0000950170-21-005014:notes:33]
The results of operations related to the acquisition of both Spot and Cloud Jumper have been included in our consolidated statements of income from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions was not material to our consolidated results of operations for the six months ended October 30, 2020.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-21-005014:notes:34]
4. Goodwill and Purchased Intangible Assets, Net

[0000950170-21-005014:notes:35]
[same as prior period, unchanged from 0001564590-21-046976:notes:33]

[0000950170-21-005014:notes:36]
|  |  | Amount |  |
| Balance as of April 30, 2021 |  | $ | 2,039 |  |
| Additions |  |  | 11 |  |
| Balance as of October 29, 2021 |  | $ | 2,050 |  |

[0000950170-21-005014:notes:37]
[same as prior period, unchanged from 0001564590-21-046976:notes:35]

[0000950170-21-005014:notes:38]
Goodwill by reportable segment as of October 29, 2021 is as follows (in millions):

[0000950170-21-005014:notes:39]
[same as prior period, unchanged from 0001564590-21-046976:notes:37]

[0000950170-21-005014:notes:40]
[same as prior period, unchanged from 0001564590-21-046976:notes:38]

[0000950170-21-005014:notes:41]
[same as prior period, unchanged from 0001564590-21-046976:notes:39]

[0000950170-21-005014:notes:42]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 106 |  |  | $ | (47 | ) |  | $ | 59 |  |  | $ | 215 |  |  | $ | (147 | ) |  | $ | 68 |  |
| Customer contracts/relationships |  |  | 38 |  |  |  | (11 | ) |  |  | 27 |  |  |  | 38 |  |  |  | (8 | ) |  |  | 30 |  |
| Other purchased intangibles |  |  | 3 |  |  |  | (2 | ) |  |  | 1 |  |  |  | 3 |  |  |  | — |  |  |  | 3 |  |
| Total purchased intangible assets |  | $ | 147 |  |  | $ | (60 | ) |  | $ | 87 |  |  | $ | 256 |  |  | $ | (155 | ) |  | $ | 101 |  |

[0000950170-21-005014:notes:43]
During fiscal 2022, we retired approximately $114 million of fully amortized developed technology intangible assets.

[0000950170-21-005014:notes:44]
[same as prior period, unchanged from 0001564590-21-046976:notes:41]

[0000950170-21-005014:notes:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Statements of |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | IncomeClassification |
| Developed technology |  | $ | 7 |  |  | $ | 12 |  |  | $ | 14 |  |  | $ | 22 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 2 |  |  |  | 3 |  |  |  | 3 |  |  |  | 3 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 1 |  |  |  | — |  |  |  | 2 |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 10 |  |  | $ | 15 |  |  | $ | 19 |  |  | $ | 25 |  |  |  |

[0000950170-21-005014:notes:46]
As of October 29, 2021, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-21-005014:notes:47]
| Fiscal Year |  | Amount |  |
| 2022 (remainder) |  | $ | 19 |  |
| 2023 |  |  | 30 |  |
| 2024 |  |  | 19 |  |
| 2025 |  |  | 16 |  |
| 2026 |  |  | 3 |  |
| Total |  | $ | 87 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-21-005014:notes:48]
5. Supplemental Financial Information

[0000950170-21-005014:notes:49]
[same as prior period, unchanged from 0001564590-21-046976:notes:46]

[0000950170-21-005014:notes:50]
[same as prior period, unchanged from 0001564590-21-046976:notes:47]

[0000950170-21-005014:notes:51]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Cash and cash equivalents |  | $ | 4,509 |  |  | $ | 4,529 |  |
| Restricted cash |  |  | 7 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 4,516 |  |  | $ | 4,535 |  |

[0000950170-21-005014:notes:52]
[same as prior period, unchanged from 0001564590-21-046976:notes:49]

[0000950170-21-005014:notes:53]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Purchased components |  | $ | 48 |  |  | $ | 22 |  |
| Finished goods |  |  | 107 |  |  |  | 92 |  |
| Inventories |  | $ | 155 |  |  | $ | 114 |  |

[0000950170-21-005014:notes:54]
[same as prior period, unchanged from 0001564590-21-046976:notes:51]

[0000950170-21-005014:notes:55]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 350 |  |  |  | 356 |  |
| Leasehold improvements |  |  | 77 |  |  |  | 83 |  |
| Computer, production, engineering and other equipment |  |  | 903 |  |  |  | 869 |  |
| Computer software |  |  | 305 |  |  |  | 305 |  |
| Furniture and fixtures |  |  | 76 |  |  |  | 93 |  |
| Construction-in-progress |  |  | 65 |  |  |  | 46 |  |
|  |  |  | 1,822 |  |  |  | 1,798 |  |
| Accumulated depreciation and amortization |  |  | (1,273 | ) |  |  | (1,273 | ) |
| Property and equipment, net |  | $ | 549 |  |  | $ | 525 |  |

[0000950170-21-005014:notes:56]
[same as prior period, unchanged from 0001564590-21-046976:notes:53]

[0000950170-21-005014:notes:57]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Deferred tax assets |  | $ | 249 |  |  | $ | 219 |  |
| Operating lease ROU assets |  |  | 263 |  |  |  | 114 |  |
| Other assets |  |  | 355 |  |  |  | 361 |  |
| Other non-current assets |  | $ | 867 |  |  | $ | 694 |  |

[0000950170-21-005014:notes:58]
Other non-current assets as of October 29, 2021 and April 30, 2021 include $75 million and $71 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited, a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019.

[0000950170-21-005014:notes:59]
[same as prior period, unchanged from 0001564590-21-046976:notes:56]

[0000950170-21-005014:notes:60]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Accrued compensation and benefits |  | $ | 400 |  |  | $ | 505 |  |
| Product warranty liabilities |  |  | 19 |  |  |  | 21 |  |
| Operating lease liabilities |  |  | 49 |  |  |  | 49 |  |
| Other current liabilities |  |  | 328 |  |  |  | 395 |  |
| Accrued expenses |  | $ | 796 |  |  | $ | 970 |  |

[0000950170-21-005014:notes:61]
[same as prior period, unchanged from 0001564590-21-046976:notes:58]

[0000950170-21-005014:notes:62]
[same as prior period, unchanged from 0001564590-21-046976:notes:59]

[0000950170-21-005014:notes:63]
[same as prior period, unchanged from 0001564590-21-046976:notes:60]

[0000950170-21-005014:notes:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Balance at beginning of period |  | $ | 31 |  |  | $ | 37 |  |  | $ | 32 |  |  | $ | 41 |  |
| Expense accrued during the period |  |  | 2 |  |  |  | 4 |  |  |  | 6 |  |  |  | 5 |  |
| Warranty costs incurred |  |  | (5 | ) |  |  | (6 | ) |  |  | (10 | ) |  |  | (11 | ) |
| Balance at end of period |  | $ | 28 |  |  | $ | 35 |  |  | $ | 28 |  |  | $ | 35 |  |

[0000950170-21-005014:notes:65]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Accrued expenses |  | $ | 19 |  |  | $ | 21 |  |
| Other long-term liabilities |  |  | 9 |  |  |  | 11 |  |
| Total warranty liabilities |  | $ | 28 |  |  | $ | 32 |  |

[0000950170-21-005014:notes:66]
[same as prior period, unchanged from 0001564590-21-046976:notes:63]

[0000950170-21-005014:notes:67]
[same as prior period, unchanged from 0001564590-21-046976:notes:64]

[0000950170-21-005014:notes:68]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Liability for uncertain tax positions |  | $ | 111 |  |  | $ | 127 |  |
| Income taxes payable |  |  | 303 |  |  |  | 351 |  |
| Product warranty liabilities |  |  | 9 |  |  |  | 11 |  |
| Operating lease liabilities |  |  | 224 |  |  |  | 71 |  |
| Other liabilities |  |  | 88 |  |  |  | 90 |  |
| Other long-term liabilities |  | $ | 735 |  |  | $ | 650 |  |

[0000950170-21-005014:notes:69]
[same as prior period, unchanged from 0001564590-21-046976:notes:66]

[0000950170-21-005014:notes:70]
[same as prior period, unchanged from 0001564590-21-046976:notes:67]

[0000950170-21-005014:notes:71]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Deferred product revenue |  | $ | 47 |  |  | $ | 59 |  |
| Deferred services revenue |  |  | 3,758 |  |  |  | 3,873 |  |
| Financed unearned services revenue |  |  | 61 |  |  |  | 71 |  |
| Total |  | $ | 3,866 |  |  | $ | 4,003 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 1,967 |  |  | $ | 2,062 |  |
| Long-term |  |  | 1,899 |  |  |  | 1,941 |  |
| Total |  | $ | 3,866 |  |  | $ | 4,003 |  |

[0000950170-21-005014:notes:72]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, Public Cloud, and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-21-005014:notes:73]
[same as prior period, unchanged from 0001564590-21-046976:notes:70]

[0000950170-21-005014:notes:74]
|  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Balance at beginning of period |  | $ | 4,003 |  |  | $ | 3,698 |  |
| Additions |  |  | 1,363 |  |  |  | 1,364 |  |
| Revenue recognized during the period |  |  | (1,500 | ) |  |  | (1,411 | ) |
| Balance at end of period |  | $ | 3,866 |  |  | $ | 3,651 |  |

[0000950170-21-005014:notes:75]
During the six months ended October 29, 2021 and October 30, 2020, we recognized $1,183 million and $1,207 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-21-005014:notes:76]
As of October 29, 2021, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied approximated our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 51% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 24% in the next 13 to 24 months, and the remainder thereafter.

[0000950170-21-005014:notes:77]
[same as prior period, unchanged from 0001564590-21-046976:notes:74]

[0000950170-21-005014:notes:78]
[same as prior period, unchanged from 0001564590-21-046976:notes:75]

[0000950170-21-005014:notes:79]
|  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Balance at beginning of period |  | $ | 197 |  |  | $ | 156 |  |
| Additions |  |  | 76 |  |  |  | 57 |  |
| Expense recognized during the period |  |  | (71 | ) |  |  | (45 | ) |
| Balance at end of period |  | $ | 202 |  |  | $ | 168 |  |

[0000950170-21-005014:notes:80]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Other current assets |  | $ | 86 |  |  | $ | 86 |  |
| Other non-current assets |  |  | 116 |  |  |  | 111 |  |
| Total deferred commissions |  | $ | 202 |  |  | $ | 197 |  |

[0000950170-21-005014:notes:81]
[same as prior period, unchanged from 0001564590-21-046976:notes:78]

[0000950170-21-005014:notes:82]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Interest income |  | $ | 1 |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | 5 |  |
| Interest expense |  |  | (18 | ) |  |  | (18 | ) |  |  | (36 | ) |  |  | (36 | ) |
| Other income (expense), net |  |  | 3 |  |  |  | 9 |  |  |  | 7 |  |  |  | (8 | ) |
| Total other expense, net |  | $ | (14 | ) |  | $ | (7 | ) |  | $ | (26 | ) |  | $ | (39 | ) |

[0000950170-21-005014:notes:83]
[same as prior period, unchanged from 0001564590-21-046976:notes:80]

[0000950170-21-005014:notes:84]
[same as prior period, unchanged from 0001564590-21-046976:notes:81]

[0000950170-21-005014:notes:85]
|  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 21 |  |  | $ | 9 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 232 |  |  | $ | 238 |  |
| Interest paid |  | $ | 34 |  |  | $ | 23 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-21-005014:notes:86]
6. Financial Instruments and Fair Value Measurements

[0000950170-21-005014:notes:87]
[same as prior period, unchanged from 0001564590-21-046976:notes:84]

[0000950170-21-005014:notes:88]
[same as prior period, unchanged from 0001564590-21-046976:notes:85]

[0000950170-21-005014:notes:89]
[same as prior period, unchanged from 0001564590-21-046976:notes:86]

[0000950170-21-005014:notes:90]
[same as prior period, unchanged from 0001564590-21-046976:notes:87]

[0000950170-21-005014:notes:91]
[same as prior period, unchanged from 0001564590-21-046976:notes:88]

[0000950170-21-005014:notes:92]
[same as prior period, unchanged from 0001564590-21-046976:notes:89]

[0000950170-21-005014:notes:93]
The following is a summary of our investments at their cost or amortized cost for the periods ended October 29, 2021 and April 30, 2021 (in millions):

[0000950170-21-005014:notes:94]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |  |
| Corporate bonds |  | $ | 31 |  |  | $ | 58 |  |  |
| U.S. Treasury and government debt securities |  |  | 7 |  |  |  | 8 |  |  |
| Certificates of deposit |  |  | 70 |  |  |  | 61 |  |  |
| Mutual funds |  |  | 43 |  |  |  | 40 |  |  |
| Total debt and equity securities |  | $ | 151 |  |  | $ | 167 |  |  |

[0000950170-21-005014:notes:95]
[same as prior period, unchanged from 0001564590-21-046976:notes:92]

[0000950170-21-005014:notes:96]
The following table presents the contractual maturities of our debt investments as of October 29, 2021 (in millions):

[0000950170-21-005014:notes:97]
|  |  | Amount |  |
| Due in one year or less |  | $ | 96 |  |
| Due after one year through five years |  |  | 12 |  |
|  |  | $ | 108 |  |

[0000950170-21-005014:notes:98]
[same as prior period, unchanged from 0001564590-21-046976:notes:95]

[0000950170-21-005014:notes:99]
[same as prior period, unchanged from 0001564590-21-046976:notes:96]

[0000950170-21-005014:notes:100]
[same as prior period, unchanged from 0001564590-21-046976:notes:97]

[0000950170-21-005014:notes:101]
|  |  | October 29. 2021 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 4,439 |  |  | $ | 4,439 |  |  | $ | — |  |
| Corporate bonds |  |  | 32 |  |  |  | — |  |  |  | 32 |  |
| U.S. Treasury and government debt securities |  |  | 7 |  |  |  | 3 |  |  |  | 4 |  |
| Certificates of deposit |  |  | 70 |  |  |  | — |  |  |  | 70 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,548 |  |  | $ | 4,442 |  |  | $ | 106 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 35 |  |  | $ | 35 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (8 | ) |  | $ | — |  |  | $ | (8 | ) |

[0000950170-21-005014:notes:102]
|  |  | April 30, 2021 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 4,468 |  |  | $ | 4,468 |  |  | $ | — |  |
| Corporate bonds |  |  | 59 |  |  |  | — |  |  |  | 59 |  |
| U.S. Treasury and government debt securities |  |  | 8 |  |  |  | 4 |  |  |  | 4 |  |
| Certificates of deposit |  |  | 61 |  |  |  | — |  |  |  | 61 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,596 |  |  | $ | 4,472 |  |  | $ | 124 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 32 |  |  | $ | 32 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0000950170-21-005014:notes:103]
(1)
Reported as other current assets in the condensed consolidated balance sheets

[0000950170-21-005014:notes:104]
(2)
Reported as other non-current assets in the condensed consolidated balance sheets

[0000950170-21-005014:notes:105]
(3)
Reported as accrued expenses in the condensed consolidated balance sheets

[0000950170-21-005014:notes:106]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt

[0000950170-21-005014:notes:107]
instruments. As of October 29, 2021 and April 30, 2021, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-21-005014:notes:108]
Fair Value of Debt 
As of October 29, 2021 and April 30, 2021, the fair value of our long-term debt was approximately $2,722 million and $2,736 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0000950170-21-005014:notes:109]
7. Financing Arrangements

[0000950170-21-005014:notes:110]
Long-Term Debt

[0000950170-21-005014:notes:111]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-21-005014:notes:112]
|  |  | Effective Interest Rate |  | October 29, 2021 |  |  | April 30, 2021 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (16 | ) |  |  | (18 | ) |
| Total long-term debt |  |  |  | $ | 2,634 |  |  | $ | 2,632 |  |

[0000950170-21-005014:notes:113]
Senior Notes

[0000950170-21-005014:notes:114]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were issued in June 2020. Interest on these Senior Notes is payable semi-annually in June and December.

[0000950170-21-005014:notes:115]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December.

[0000950170-21-005014:notes:116]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-21-005014:notes:117]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 29, 2021, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-21-005014:notes:118]
As of October 29, 2021, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-21-005014:notes:119]
| Fiscal Year |  | Amount |  |
| 2022 (remainder) |  | $ | — |  |
| 2023 |  |  | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

[0000950170-21-005014:notes:120]
Commercial Paper Program and Credit Facility

[0000950170-21-005014:notes:121]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may

[0000950170-21-005014:notes:122]
be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of October 29, 2021 or April 30, 2021. During the first six months of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $176 million for the settlement, of commercial paper notes with original maturities greater than three months.

[0000950170-21-005014:notes:123]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 29, 2021, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-21-005014:notes:124]
8. Leases

[0000950170-21-005014:notes:125]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of October 29, 2021, have remaining lease terms not exceeding 15 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of October 29, 2021, have remaining lease terms not exceeding 4 years. As of October 29, 2021, our automobile leases have remaining lease terms not exceeding 5 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-21-005014:notes:126]
[same as prior period, unchanged from 0001564590-21-046976:notes:122]

[0000950170-21-005014:notes:127]
In April 2021, we entered into a lease for our new corporate headquarters located in San Jose, California, which is comprised of approximately three hundred thousand square feet of office space and requires future minimum undiscounted payments of approximately $180 million over the initial 11-year lease term. The lease agreement also provides us two successive renewal options, each for five years. The lease commenced during the first quarter of fiscal 2022.

[0000950170-21-005014:notes:128]
[same as prior period, unchanged from 0001564590-21-046976:notes:124]

[0000950170-21-005014:notes:129]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Operating lease cost |  | $ | 16 |  |  | $ | 14 |  |  | $ | 31 |  |  | $ | 28 |  |
| Variable lease cost |  |  | 4 |  |  |  | 2 |  |  |  | 8 |  |  |  | 5 |  |
| Total lease cost |  | $ | 20 |  |  | $ | 16 |  |  | $ | 39 |  |  | $ | 33 |  |

[0000950170-21-005014:notes:130]
[same as prior period, unchanged from 0001564590-21-046976:notes:126]

[0000950170-21-005014:notes:131]
[same as prior period, unchanged from 0001564590-21-046976:notes:127]

[0000950170-21-005014:notes:132]
|  |  |  |  | Six Months Ended |  |
|  |  |  |  |  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  |  |  | $ | 28 |  |  | $ | 28 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  |  |  | $ | 178 |  |  | $ | 16 |  |

[0000950170-21-005014:notes:133]
[same as prior period, unchanged from 0001564590-21-046976:notes:129]

[0000950170-21-005014:notes:134]
|  |  |  |  |  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Other non-current assets |  |  |  |  |  | $ | 263 |  |  | $ | 114 |  |
| Total operating lease ROU assets |  |  |  |  |  | $ | 263 |  |  | $ | 114 |  |
| Accrued expenses |  |  |  |  |  | $ | 49 |  |  | $ | 49 |  |
| Other long-term liabilities |  |  |  |  |  |  | 224 |  |  |  | 71 |  |
| Total operating lease liabilities |  |  |  |  |  | $ | 273 |  |  | $ | 120 |  |
| Weighted Average Remaining Lease Term |  |  |  |  |  | 7.9 years |  |  | 3.4 years |  |
| Weighted Average Discount Rate |  |  |  |  |  |  | 2.7 | % |  |  | 2.9 | % |

[0000950170-21-005014:notes:135]
Future minimum operating lease payments as of October 29, 2021, which exclude the undiscounted payments for the build-to-suit lease located in Wichita, Kansas, expected to commence in the third quarter of fiscal year 2022, are as follows (in millions):

[0000950170-21-005014:notes:136]
| Fiscal Year |  |  |  |  |  | Operating Leases |  |
| 2022 (remainder) |  |  |  |  |  | $ | 29 |  |
| 2023 |  |  |  |  |  |  | 49 |  |
| 2024 |  |  |  |  |  |  | 41 |  |
| 2025 |  |  |  |  |  |  | 32 |  |
| 2026 |  |  |  |  |  |  | 29 |  |
| Thereafter |  |  |  |  |  |  | 123 |  |
| Total lease payments |  |  |  |  |  |  | 303 |  |
| Less: Interest |  |  |  |  |  |  | (30 | ) |
| Total |  |  |  |  |  | $ | 273 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-21-005014:notes:137]
9. Stockholders’ Equity

[0000950170-21-005014:notes:138]
[same as prior period, unchanged from 0001564590-21-046976:notes:134]

[0000950170-21-005014:notes:139]
As of October 29, 2021, we have certain equity incentive awards outstanding, which include stock options and restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs). Also outstanding are purchase rights under our Employee Stock Purchase Plan (ESPP).

[0000950170-21-005014:notes:140]
[same as prior period, unchanged from 0001564590-21-046976:notes:136]

[0000950170-21-005014:notes:141]
Less than 1 million options were outstanding as of October 29, 2021 and April 30, 2021.

[0000950170-21-005014:notes:142]
[same as prior period, unchanged from 0001564590-21-046976:notes:138]

[0000950170-21-005014:notes:143]
|  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Intrinsic value of exercises |  | $ | 8 |  |  | $ | 1 |  |
| Proceeds received from exercises |  | $ | 1 |  |  | $ | 2 |  |
| Fair value of options vested |  | $ | 2 |  |  | $ | 1 |  |

[0000950170-21-005014:notes:144]
[same as prior period, unchanged from 0001564590-21-046976:notes:140]

[0000950170-21-005014:notes:145]
In the six months ended October 29, 2021, we granted PBRSUs to certain of our executives. Each PBRSUs has performance-based vesting criteria, in addition to the service-based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate one, two or three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the first, second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle most of these PBRSUs at the end of the performance and service period will range from 0% to 200% of a target number of shares originally granted. For most of the PBRSUs granted in the six months ended October 29, 2021, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these TSR performance-based awards were fixed at grant date using a Monte Carlo simulation model. The aggregate grant date fair value of all PBRSUs granted in the current year was $43 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0000950170-21-005014:notes:146]
[same as prior period, unchanged from 0001564590-21-046976:notes:142]

[0000950170-21-005014:notes:147]
|  |  | Number ofShares |  |  | Weighted-AverageGrant Date Fair Value |  |
| Outstanding as of April 30, 2021 |  |  | 9 |  |  | $ | 47.75 |  |
| Granted |  |  | 4 |  |  | $ | 78.29 |  |
| Vested |  |  | (2 | ) |  | $ | 47.73 |  |
| Forfeited |  |  | (1 | ) |  | $ | 56.65 |  |
| Outstanding as of October 29, 2021 |  |  | 10 |  |  | $ | 60.61 |  |

[0000950170-21-005014:notes:148]
[same as prior period, unchanged from 0001564590-21-046976:notes:144]

[0000950170-21-005014:notes:149]
|  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 63 |  |  | $ | 34 |  |

[0000950170-21-005014:notes:150]
[same as prior period, unchanged from 0001564590-21-046976:notes:146]

[0000950170-21-005014:notes:151]
[same as prior period, unchanged from 0001564590-21-046976:notes:147]

[0000950170-21-005014:notes:152]
|  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Shares issued under the ESPP |  |  | 1 |  |  |  | 1 |  |
| Proceeds from issuance of shares |  | $ | 52 |  |  | $ | 47 |  |

[0000950170-21-005014:notes:153]
[same as prior period, unchanged from 0001564590-21-046976:notes:149]

[0000950170-21-005014:notes:154]
[same as prior period, unchanged from 0001564590-21-046976:notes:150]

[0000950170-21-005014:notes:155]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |
| Cost of services revenues |  |  | 4 |  |  |  | 2 |  |  |  | 6 |  |  |  | 5 |  |
| Sales and marketing |  |  | 29 |  |  |  | 24 |  |  |  | 55 |  |  |  | 49 |  |
| Research and development |  |  | 18 |  |  |  | 15 |  |  |  | 34 |  |  |  | 34 |  |
| General and administrative |  |  | 10 |  |  |  | 7 |  |  |  | 18 |  |  |  | 13 |  |
| Total stock-based compensation expense |  | $ | 62 |  |  | $ | 49 |  |  | $ | 115 |  |  | $ | 103 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 4 |  |  | $ | 8 |  |  | $ | 9 |  |  | $ | 12 |  |

[0000950170-21-005014:notes:156]
As of October 29, 2021, total unrecognized compensation expense related to our equity awards was $515 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.5 years.

[0000950170-21-005014:notes:157]
[same as prior period, unchanged from 0001564590-21-046976:notes:153]

[0000950170-21-005014:notes:158]
As of October 29, 2021, our Board of Directors has authorized the repurchase of up to $14.1 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-21-005014:notes:159]
The following table summarized activity related to the stock repurchase program for the six months ended October 29, 2021 (in millions, except for per share amounts):

[0000950170-21-005014:notes:160]
| Number of shares repurchased |  |  | 3 |  |
| Average price per share |  | $ | 84.88 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 6 |  |
| Stock repurchases allocated to retained earnings |  | $ | 219 |  |
| Remaining authorization at end of period |  | $ | 627 |  |

[0000950170-21-005014:notes:161]
Since the May 13, 2003 inception of our stock repurchase program through October 29, 2021, we repurchased a total of 343 million shares of our common stock at an average price of $39.37 per share, for an aggregate purchase price of $13.5 billion.

[0000950170-21-005014:notes:162]
[same as prior period, unchanged from 0001564590-21-046976:notes:158]

[0000950170-21-005014:notes:163]
[same as prior period, unchanged from 0001564590-21-046976:notes:159]

[0000950170-21-005014:notes:164]
|  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Dividends per share declared |  | $ | 1.00 |  |  | $ | 0.96 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | — |  |  | $ | 30 |  |
| Dividend payments allocated to retained earnings |  | $ | 224 |  |  | $ | 184 |  |

[0000950170-21-005014:notes:165]
On November 22, 2021, we declared a cash dividend of $0.50 per share of common stock, payable on January 26, 2022 to holders of record as of the close of business on January 7, 2022. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-21-005014:notes:166]
[same as prior period, unchanged from 0001564590-21-046976:notes:162]

[0000950170-21-005014:notes:167]
[same as prior period, unchanged from 0001564590-21-046976:notes:163]

[0000950170-21-005014:notes:168]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) on Available-for-SaleSecurities |  |  | UnrealizedGains(Losses) onDerivativeInstruments |  |  | Total |  |
| Balance as of April 30, 2021 |  | $ | (27 | ) |  | $ | (4 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (30 | ) |
| Other comprehensive income (loss), net of tax |  |  | (8 | ) |  |  | — |  |  |  | (1 | ) |  |  | 2 |  |  |  | (7 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| Total other comprehensive income (loss) |  |  | (8 | ) |  |  | — |  |  |  | (1 | ) |  |  | 1 |  |  |  | (8 | ) |
| Balance as of October 29, 2021 |  | $ | (35 | ) |  | $ | (4 | ) |  | $ | — |  |  | $ | 1 |  |  | $ | (38 | ) |

[0000950170-21-005014:notes:169]
[same as prior period, unchanged from 0001564590-21-046976:notes:165]

[0000950170-21-005014:notes:170]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | Statements ofIncome Classification |
| Realized (gains) losses on cash flow hedges |  | $ | (1 | ) |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 8 |  |  | Net revenues |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-21-005014:notes:171]
10. Derivatives and Hedging Activities

[0000950170-21-005014:notes:172]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of October 29, 2021 or April 30, 2021. All contracts have a maturity of less than 12 months.

[0000950170-21-005014:notes:173]
[same as prior period, unchanged from 0001564590-21-046976:notes:169]

[0000950170-21-005014:notes:174]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 153 |  |  | $ | 167 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 608 |  |  | $ | 497 |  |
| Forward contracts purchased |  | $ | 114 |  |  | $ | 117 |  |

[0000950170-21-005014:notes:175]
[same as prior period, unchanged from 0001564590-21-046976:notes:171]

[0000950170-21-005014:notes:176]
[same as prior period, unchanged from 0001564590-21-046976:notes:172]

[0000950170-21-005014:notes:177]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Foreign currency exchange contracts |  | $ | (17 | ) |  | $ | (6 | ) |  | $ | (26 | ) |  | $ | 17 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-21-005014:notes:178]
11. Restructuring Charges

[0000950170-21-005014:notes:179]
During the first six months of fiscal 2022, we executed a restructuring plan to reduce the amount of office space we currently occupy as we allow more employees to continue to work remotely. In connection with the plan, we also reduced our global workforce by approximately 1%. Charges related to the plan consisted primarily of office relocation costs, lease termination fees, and employee severance related costs. Substantially all activities under the plan have been completed.

[0000950170-21-005014:notes:180]
[same as prior period, unchanged from 0001564590-21-046976:notes:177]

[0000950170-21-005014:notes:181]
[same as prior period, unchanged from 0001564590-21-046976:notes:178]

[0000950170-21-005014:notes:182]
|  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Balance at beginning of period |  | $ | 1 |  |  | $ | 1 |  |
| Net charges |  |  | 29 |  |  |  | 42 |  |
| Cash payments |  |  | (28 | ) |  |  | (24 | ) |
| Balance at end of period |  | $ | 2 |  |  | $ | 19 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-21-005014:notes:183]
12. Income Taxes

[0000950170-21-005014:notes:184]
[same as prior period, unchanged from 0001564590-21-046976:notes:181]

[0000950170-21-005014:notes:185]
|  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Effective tax rates |  |  | 17.6 | % |  |  | 23.3 | % |

[0000950170-21-005014:notes:186]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the six months ended October 29, 2021 includes the impact of discrete tax benefits for lapses of statute of limitations as well as benefits related to stock-based compensation. The effective tax rate for the six months ended October 30, 2020 reflects the impact of taxes resulting from the integration of acquired companies and smaller benefits for stock-based compensation as compared to the current year.

[0000950170-21-005014:notes:187]
As of October 29, 2021, we had $214 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $110 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $111 million have been recorded in other long-term liabilities.

[0000950170-21-005014:notes:188]
[same as prior period, unchanged from 0001564590-21-046976:notes:185]

[0000950170-21-005014:notes:189]
[same as prior period, unchanged from 0001564590-21-046976:notes:186]

[0000950170-21-005014:notes:190]
[same as prior period, unchanged from 0001564590-21-046976:notes:187]


## us-gaap:EarningsPerShareTextBlock

[0000950170-21-005014:notes:191]
13. Net Income per Share

[0000950170-21-005014:notes:192]
[same as prior period, unchanged from 0001564590-21-046976:notes:189]

[0000950170-21-005014:notes:193]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 224 |  |  | $ | 137 |  |  | $ | 426 |  |  | $ | 214 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 223 |  |  |  | 222 |  |  |  | 223 |  |  |  | 222 |  |
| Dilutive impact of employee equity award plans |  |  | 6 |  |  |  | 2 |  |  |  | 6 |  |  |  | 1 |  |
| Shares used in diluted computation |  |  | 229 |  |  |  | 224 |  |  |  | 229 |  |  |  | 223 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.00 |  |  | $ | 0.62 |  |  | $ | 1.91 |  |  | $ | 0.96 |  |
| Diluted |  | $ | 0.98 |  |  | $ | 0.61 |  |  | $ | 1.86 |  |  | $ | 0.96 |  |

[0000950170-21-005014:notes:194]
No potential shares from outstanding employee awards were excluded from the diluted net income per share calculation for the three and six months ended October 29, 2021. Eight million and seven million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the three and six months ended October 30, 2020, respectively, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-21-005014:notes:195]
14. Segment, Geographic, and Significant Customer Information

[0000950170-21-005014:notes:196]
[same as prior period, unchanged from 0001564590-21-046976:notes:193]

[0000950170-21-005014:notes:197]
[same as prior period, unchanged from 0001564590-21-046976:notes:194]

[0000950170-21-005014:notes:198]
[same as prior period, unchanged from 0001564590-21-046976:notes:195]

[0000950170-21-005014:notes:199]
[same as prior period, unchanged from 0001564590-21-046976:notes:196]

[0000950170-21-005014:notes:200]
[same as prior period, unchanged from 0001564590-21-046976:notes:197]

[0000950170-21-005014:notes:201]
Financial information by segment is as follows (in millions, except percentages):

[0000950170-21-005014:notes:202]
|  | Three Months Ended October 29, 2021 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 814 |  |  | $ | — |  |  | $ | 814 |  |
| Support revenues |  | 590 |  |  |  | — |  |  |  | 590 |  |
| Professional and other services revenues |  | 75 |  |  |  | — |  |  |  | 75 |  |
| Public cloud revenues |  | — |  |  |  | 87 |  |  |  | 87 |  |
| Net revenues |  | 1,479 |  |  |  | 87 |  |  |  | 1,566 |  |
| Cost of product revenues |  | 369 |  |  |  | — |  |  |  | 369 |  |
| Cost of support revenues |  | 48 |  |  |  | — |  |  |  | 48 |  |
| Cost of professional and other services revenues |  | 54 |  |  |  | — |  |  |  | 54 |  |
| Cost of public cloud revenues |  | — |  |  |  | 25 |  |  |  | 25 |  |
| Segment cost of revenues |  | 471 |  |  |  | 25 |  |  |  | 496 |  |
| Segment gross profit | $ | 1,008 |  |  | $ | 62 |  |  | $ | 1,070 |  |
| Segment gross margin |  | 68.2 | % |  |  | 71.3 | % |  |  | 68.3 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 11 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,059 |  |
| Total gross margin |  |  |  |  |  |  |  | 67.6 | % |
| 1 Unallocated cost of revenues are composed of $4 million of stock-based compensation expense and $7 million of amortization of intangible assets. |  |

[0000950170-21-005014:notes:203]
|  | Three Months Ended October 30, 2020 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 749 |  |  | $ | — |  |  | $ | 749 |  |
| Support revenues |  | 553 |  |  |  | — |  |  |  | 553 |  |
| Professional and other services revenues |  | 67 |  |  |  | — |  |  |  | 67 |  |
| Public cloud revenues |  | — |  |  |  | 47 |  |  |  | 47 |  |
| Net revenues |  | 1,369 |  |  |  | 47 |  |  |  | 1,416 |  |
| Cost of product revenues |  | 352 |  |  |  | — |  |  |  | 352 |  |
| Cost of support revenues |  | 50 |  |  |  | — |  |  |  | 50 |  |
| Cost of professional and other services revenues |  | 50 |  |  |  | — |  |  |  | 50 |  |
| Cost of public cloud revenues |  | — |  |  |  | 16 |  |  |  | 16 |  |
| Segment cost of revenues |  | 452 |  |  |  | 16 |  |  |  | 468 |  |
| Segment gross profit | $ | 917 |  |  | $ | 31 |  |  | $ | 948 |  |
| Segment gross margin |  | 67.0 | % |  |  | 66.0 | % |  |  | 66.9 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 15 |  |
| Total gross profit |  |  |  |  |  |  | $ | 933 |  |
| Total gross margin |  |  |  |  |  |  |  | 65.9 | % |
| 1 Unallocated cost of revenues are composed of $3 million of stock-based compensation expense and $12 million of amortization of intangible assets. |  |

[0000950170-21-005014:notes:204]
|  | Six Months Ended October 29, 2021 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 1,544 |  |  | $ | — |  |  | $ | 1,544 |  |
| Support revenues |  | 1,168 |  |  |  | — |  |  |  | 1,168 |  |
| Professional and other services revenues |  | 146 |  |  |  | — |  |  |  | 146 |  |
| Public cloud revenues |  | — |  |  |  | 166 |  |  |  | 166 |  |
| Net revenues |  | 2,858 |  |  |  | 166 |  |  |  | 3,024 |  |
| Cost of product revenues |  | 695 |  |  |  | — |  |  |  | 695 |  |
| Cost of support revenues |  | 96 |  |  |  | — |  |  |  | 96 |  |
| Cost of professional and other services revenues |  | 105 |  |  |  | — |  |  |  | 105 |  |
| Cost of public cloud revenues |  | — |  |  |  | 48 |  |  |  | 48 |  |
| Segment cost of revenues |  | 896 |  |  |  | 48 |  |  |  | 944 |  |
| Segment gross profit | $ | 1,962 |  |  | $ | 118 |  |  | $ | 2,080 |  |
| Segment gross margin |  | 68.6 | % |  |  | 71.1 | % |  |  | 68.8 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 22 |  |
| Total gross profit |  |  |  |  |  |  | $ | 2,058 |  |
| Total gross margin |  |  |  |  |  |  |  | 68.1 | % |
| 1 Unallocated cost of revenues are composed of $8 million of stock-based compensation expense and $14 million of amortization of intangible assets. |  |

[0000950170-21-005014:notes:205]
|  | Six Months Ended October 30, 2020 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 1,376 |  |  | $ | — |  |  | $ | 1,376 |  |
| Support revenues |  | 1,130 |  |  |  | — |  |  |  | 1,130 |  |
| Professional and other services revenues |  | 135 |  |  |  | — |  |  |  | 135 |  |
| Public cloud revenues |  | — |  |  |  | 78 |  |  |  | 78 |  |
| Net revenues |  | 2,641 |  |  |  | 78 |  |  |  | 2,719 |  |
| Cost of product revenues |  | 657 |  |  |  | — |  |  |  | 657 |  |
| Cost of support revenues |  | 101 |  |  |  | — |  |  |  | 101 |  |
| Cost of professional and other services revenues |  | 98 |  |  |  | — |  |  |  | 98 |  |
| Cost of public cloud revenues |  | — |  |  |  | 29 |  |  |  | 29 |  |
| Segment cost of revenues |  | 856 |  |  |  | 29 |  |  |  | 885 |  |
| Segment gross profit | $ | 1,785 |  |  | $ | 49 |  |  | $ | 1,834 |  |
| Segment gross margin |  | 67.6 | % |  |  | 62.8 | % |  |  | 67.5 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 29 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,805 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.4 | % |
| 1 Unallocated cost of revenues are composed of $7 million of stock-based compensation expense and $22 million of amortization of intangible assets. |  |

[0000950170-21-005014:notes:206]
Geographical Revenues and Certain Assets

[0000950170-21-005014:notes:207]
[same as prior period, unchanged from 0001564590-21-046976:notes:201]

[0000950170-21-005014:notes:208]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| United States, Canada and Latin America (Americas) |  | $ | 868 |  |  | $ | 781 |  |  | $ | 1,654 |  |  | $ | 1,490 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 461 |  |  |  | 422 |  |  |  | 915 |  |  |  | 805 |  |
| Asia Pacific (APAC) |  |  | 237 |  |  |  | 213 |  |  |  | 455 |  |  |  | 424 |  |
| Net revenues |  | $ | 1,566 |  |  | $ | 1,416 |  |  | $ | 3,024 |  |  | $ | 2,719 |  |

[0000950170-21-005014:notes:209]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $773 million and $705 million during the three months ended October 29, 2021 and October 30, 2020, respectively, and were $1,469 million and $1,342 million during the six months ended October 29, 2021 and October 30, 2020, respectively.

[0000950170-21-005014:notes:210]
The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0000950170-21-005014:notes:211]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| U.S. |  | $ | 2,800 |  |  | $ | 2,098 |  |
| International |  |  | 1,748 |  |  |  | 2,498 |  |
| Total |  | $ | 4,548 |  |  | $ | 4,596 |  |

[0000950170-21-005014:notes:212]
[same as prior period, unchanged from 0001564590-21-046976:notes:206]

[0000950170-21-005014:notes:213]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| U.S. |  | $ | 351 |  |  | $ | 340 |  |
| International |  |  | 198 |  |  |  | 185 |  |
| Total |  | $ | 549 |  |  | $ | 525 |  |

[0000950170-21-005014:notes:214]
Significant Customers

[0000950170-21-005014:notes:215]
[same as prior period, unchanged from 0001564590-21-046976:notes:208]

[0000950170-21-005014:notes:216]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 25 | % |  |  | 24 | % |  |  | 24 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |

[0000950170-21-005014:notes:217]
[same as prior period, unchanged from 0001564590-21-046976:notes:210]

[0000950170-21-005014:notes:218]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| Arrow Electronics, Inc. |  |  | 10 | % |  |  | 10 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 21 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-21-005014:notes:219]
15. Commitments and Contingencies

[0000950170-21-005014:notes:220]
Purchase Orders and Other Commitments

[0000950170-21-005014:notes:221]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 29, 2021, we had $735 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 29, 2021 and April 30, 2021, such liability amounted to $14 million and $15 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-21-005014:notes:222]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 29, 2021, we had $318 million in other purchase obligations.

[0000950170-21-005014:notes:223]
Financing Guarantees

[0000950170-21-005014:notes:224]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $38 million and $26 million of receivables during the six months ended October 29, 2021 and October 30, 2020, respectively.

[0000950170-21-005014:notes:225]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-21-005014:notes:226]
Some of the leasing agreements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 29, 2021 and April 30, 2021, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-21-005014:notes:227]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 29, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-21-005014:notes:228]
Legal Contingencies

[0000950170-21-005014:notes:229]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-21-005014:notes:230]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. The defendants' Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp and the other defendants. On March 26, 2021, Plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (“MOU”) providing for the settlement of the class action.  Pursuant to the terms of MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties subsequently executed a stipulation of settlement, which contains no admission of liability, wrongdoing or responsibility by any of the parties, and which provides that the class action will be dismissed with prejudice, with mutual releases by all parties, upon final court approval. On September 24, 2021, plaintiff filed an unopposed motion seeking court approval of the settlement, but no order has issued regarding that motion. The settlement remains subject to court approval.

[0000950170-21-005014:notes:231]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-21-005014:notes:232]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of October 29, 2021 related to such matters.


## us-gaap:SubsequentEventsTextBlock

[0000950170-21-005014:notes:233]
16. Subsequent Event

[0000950170-21-005014:notes:234]
On November 5, 2021, we acquired all the outstanding shares of privately-held CloudCheckr Inc., a leading cloud optimization platform that provides cloud visibility and insights to lower costs, maintain security and compliance, and optimize cloud resources.  We are in the process of completing the allocation of approximately $348 million of purchase price among the assets acquired and liabilities assumed.
