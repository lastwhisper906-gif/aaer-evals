# NTAP 8-K — 0000950170-21-004947 filed 2021-11-30

## item codes, every 8-K on or before 2021-12-02

- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2021-12-02

- none on or before 2021-12-02

## item 2.02 — earnings release, exhibit 99.1

[0000950170-21-004947:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0000950170-21-004947:8k_2_02:2]
EX-99.1

[0000950170-21-004947:8k_2_02:3]
Exhibit 99.1

[0000950170-21-004947:8k_2_02:4]
NetApp reports second quarter of fiscal year 2022 results

[0000950170-21-004947:8k_2_02:5]
Net revenues for the second quarter grew 11% year-over-year to $1.57 billion;

[0000950170-21-004947:8k_2_02:6]
Expanded cloud partnerships and delivered substantial innovation across entire portfolio

[0000950170-21-004947:8k_2_02:7]

NetApp™ Public Cloud annualized revenue run rate (ARR)1 increased 80% year-over-year to $388 million

[0000950170-21-004947:8k_2_02:8]

All-flash array annualized net revenue run rate2 increased 22% year-over-year to $3.1 billion

[0000950170-21-004947:8k_2_02:9]

Product revenue grew 9% year-over-year to $814 million

[0000950170-21-004947:8k_2_02:10]

Billings3 increased 7% year-over-year to $1.55 billion

[0000950170-21-004947:8k_2_02:11]

$298 million in cash provided by operations; $252 million in free cash flow3

[0000950170-21-004947:8k_2_02:12]
SAN JOSE, Calif.—November 30, 2021—NetApp (NASDAQ: NTAP) today reported financial results for the second quarter of fiscal year 2022, which ended on October 29, 2021.

[0000950170-21-004947:8k_2_02:13]
“We delivered another strong quarter, with results all at the high end or above our guidance. Our performance reflects a strong demand environment, a clear vision, and exceptional execution by the NetApp team and gives the confidence to raise our full year guidance for revenue, EPS and Public Cloud ARR,” said George Kurian, chief executive officer. “We are gaining share in the key markets of all-flash and object storage, while rapidly scaling our public cloud business. Our industry-leading innovation and unique and deep cloud partnerships position us well to capitalize on significant opportunity ahead.”

[0000950170-21-004947:8k_2_02:14]
Second quarter of fiscal year 2022 financial results

[0000950170-21-004947:8k_2_02:15]

Net revenues: $1.57 billion, compared to $1.42 billion in the second quarter of fiscal year 2021

[0000950170-21-004947:8k_2_02:16]
o
Hybrid Cloud segment revenue: $1.48 billion, compared to $1.37 billion in the second quarter of fiscal year 2021

[0000950170-21-004947:8k_2_02:17]
o
Public Cloud segment revenue: $87 million, compared to $47 million in the second quarter of fiscal year 2021

[0000950170-21-004947:8k_2_02:18]

Net income: GAAP net income of $224 million, compared to $137 million in the second quarter of fiscal year 2021; non-GAAP net income4 of $292 million, compared to $236 million in the second quarter of fiscal year 2021

[0000950170-21-004947:8k_2_02:19]

Earnings per share: GAAP net income per share5 of $0.98, compared to $0.61 in the second quarter of fiscal year 2021; non-GAAP net income per share of $1.28, compared to $1.05 in the second quarter of fiscal year 2021

[0000950170-21-004947:8k_2_02:20]

Cash, cash equivalents and investments: $4.55 billion at the end of the second quarter of fiscal year 2022

[0000950170-21-004947:8k_2_02:21]

Cash provided by operations: $298 million, compared to $161 million in the second quarter of fiscal year 2021

[0000950170-21-004947:8k_2_02:22]

Share repurchase and dividends: Returned $237 million to shareholders through share repurchases and cash dividends

[0000950170-21-004947:8k_2_02:23]
Third quarter of fiscal year 2022 financial outlook

[0000950170-21-004947:8k_2_02:24]
The Company provided the following financial guidance for the third quarter of fiscal year 2022:

[0000950170-21-004947:8k_2_02:25]
| Net revenues are expected to be in the range of: | $1.525 billion to $1.675 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.93 - $1.03 | $1.21 - $1.31 |

[0000950170-21-004947:8k_2_02:26]
Full fiscal year 2022 financial outlook

[0000950170-21-004947:8k_2_02:27]
The Company provided an update to their financial guidance for the full fiscal year 2022:

[0000950170-21-004947:8k_2_02:28]
| Net revenues are expected to grow in the range of: | 9% to 10% |
| Public Cloud ARR is expected to exit the fiscal year in the range of: | $510 million to $540 million |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be: | ~67% | ~68% |
| Operating margins are expected to be: | 18% - 19% | 23% - 24% |
| Effective tax rate is expected to be: | ~21% | ~19% |
| Earnings per share is expected to be in the range of: | $3.80 - $4.00 | $4.90 - $5.10 |

[0000950170-21-004947:8k_2_02:29]
Dividend

[0000950170-21-004947:8k_2_02:30]
The next cash dividend of $0.50 per share is to be paid on January 26, 2022, to shareholders of record as of the close of business on January 7, 2022.

[0000950170-21-004947:8k_2_02:31]
Second quarter of fiscal year 2022 business highlights

[0000950170-21-004947:8k_2_02:32]
Expanding cloud partnerships

[0000950170-21-004947:8k_2_02:33]

AWS and NetApp announced the general availability of Amazon FSx for NetApp ONTAP, a native AWS managed service that’s powered by NetApp ONTAP software and is available around the world.

[0000950170-21-004947:8k_2_02:34]

Google Cloud announced that NetApp will serve as the primary data and storage vendor for its new Google Distributed Cloud Hosted offering and introduced the integration of Google Cloud VMware Engine with NetApp Cloud Volumes Service support for VM datastores, a fully managed service that helps organizations meet their need for virtual workload storage and disaster recovery.

[0000950170-21-004947:8k_2_02:35]

NetApp and Google Cloud launched NetApp Cloud Volumes Service for Google Cloud in Salt Lake City and Tokyo, with available Cloud Volumes Service regions now totaling 19 as demand continues to increase.

[0000950170-21-004947:8k_2_02:36]

NetApp announced expanded backup/restore and cross-region replication capabilities in Azure NetApp Files.

[0000950170-21-004947:8k_2_02:37]

NetApp announced that whitelisting has been removed from Azure NetApp Files, enabling customers to directly consume Azure NetApp Files from the Azure portal, CLI, API, or with the software development kit (SDK).

[0000950170-21-004947:8k_2_02:38]
Leading innovation

[0000950170-21-004947:8k_2_02:39]

NetApp announced an agreement to acquire CloudCheckr™ to expand the Spot by NetApp cloud operations (CloudOps) portfolio, enabling organizations to better optimize and secure multi-cloud infrastructures. The CloudCheckr acquisition closed on November 5, 2021.

[0000950170-21-004947:8k_2_02:40]

NetApp announced the latest release of NetApp ONTAP™ data management software, which offers autonomous ransomware protection against cyberattacks, increased performance for SAN and modern workloads with NVMe over TCP (NVMe/TCP) support, expanded object storage capabilities with NetAppSnapMirror™, and simplified storage management.

[0000950170-21-004947:8k_2_02:41]

NetApp introduced new digital wallet capabilities available in NetApp Cloud Managerfor greater mobility and more visibility into usage of data service licenses across a hybrid cloud, with prepayment of credits enabling streamlined deployment.

[0000950170-21-004947:8k_2_02:42]

NetApp introduced enhancements to NetApp Cloud Backup and Cloud Data Sense services. Enhancements include greater data protection and governance for ONTAP environments, simplified deployment of NetApp Cloud Volumes ONTAP with new customer-ready templates, and fully embedded NetApp Active IQ™ in Cloud Manager.

[0000950170-21-004947:8k_2_02:43]

NetApp announced Kubernetes enhancements and deeper ONTAP integrations with NetAppCloud Insights to support and manage Kubernetes workloads.

[0000950170-21-004947:8k_2_02:44]

NetApp announced a new freemium service tier for Cloud Volumes ONTAP. This service tier gives customers access to a full-featured, perpetual license to use ONTAP in the cloud for workloads that need less than 500GB of storage.

[0000950170-21-004947:8k_2_02:45]

NetApp previewed NetApp Astra™ Data Store, a Kubernetes-native shared file service for unified management of container-based storage and virtual machines (VMs) across a hybrid cloud.

[0000950170-21-004947:8k_2_02:46]

Spot by NetApp launched Spot Elastigroup by NetApp for Azure Stateful Groups, allowing companies to use Azure’s Spot VM technology to save up to 90% of infrastructure costs while running stateful applications.

[0000950170-21-004947:8k_2_02:47]

Spot by NetApp announced Spot Security, a new product to help safeguard cloud infrastructure with automated security monitoring, analysis, and remediation capabilities

[0000950170-21-004947:8k_2_02:48]

NetApp introduced new Support and Professional Services offerings, including the extension of NetApp SupportEdge Advisor and SupportEdge Protect for cloud services, as well as NetApp Flex Professional Services (FlexPS), which offers on-demand support for customers transitioning to hybrid cloud.

[0000950170-21-004947:8k_2_02:49]
NetApp recognition and awards

[0000950170-21-004947:8k_2_02:50]

NetApp was named a leader in the 2021 Gartner Magic Quadrant for Primary Storage.6 NetApp was also among this year’s top vendor solutions evaluated in the 2021 Gartner Critical Capabilities for Primary Storage7 across all use cases. In the Cloud IT Operations use case, the NetApp AFF A-Series family received the highest scores.

[0000950170-21-004947:8k_2_02:51]

NetApp AI won a 2021 Stratus Award for artificial intelligence from the Business Intelligence Group.

[0000950170-21-004947:8k_2_02:52]
Webcast and conference call information

[0000950170-21-004947:8k_2_02:53]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0000950170-21-004947:8k_2_02:54]
###

[0000950170-21-004947:8k_2_02:55]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-21-004947:8k_2_02:56]
Footnotes

[0000950170-21-004947:8k_2_02:57]
1Public Cloud annualized revenue run rate (ARR) is calculated as the annualized value of all Public Cloud customer commitments with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0000950170-21-004947:8k_2_02:58]
2All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-21-004947:8k_2_02:59]
3Refer to the NetApp Usage of Non-GAAP Financial Information section below for an explanation of billings and free cash flow.

[0000950170-21-004947:8k_2_02:60]
4Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, (j) COVID-19 charges and (k) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-21-004947:8k_2_02:61]
5GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-21-004947:8k_2_02:62]
6Gartner, “Magic Quadrant for Primary Storage, 2021,” Jeff Vogel, Roger W. Cox, Joseph Unsworth, Santhosh Rao, October 11, 2021.

[0000950170-21-004947:8k_2_02:63]
7Gartner, “Critical Capabilities for Primary Storage, 2021,” Santhosh Rao, Roger W. Cox, Joseph Unsworth, Jeff Vogel, October 11, 2021.

[0000950170-21-004947:8k_2_02:64]
NetApp usage of non-GAAP financial information

[0000950170-21-004947:8k_2_02:65]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-21-004947:8k_2_02:66]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0000950170-21-004947:8k_2_02:67]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful

[0000950170-21-004947:8k_2_02:68]
information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-21-004947:8k_2_02:69]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0000950170-21-004947:8k_2_02:70]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-21-004947:8k_2_02:71]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-21-004947:8k_2_02:72]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-21-004947:8k_2_02:73]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-21-004947:8k_2_02:74]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-21-004947:8k_2_02:75]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-21-004947:8k_2_02:76]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-21-004947:8k_2_02:77]
E. Restructuring charges.These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-21-004947:8k_2_02:78]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-21-004947:8k_2_02:79]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-21-004947:8k_2_02:80]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-21-004947:8k_2_02:81]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-21-004947:8k_2_02:82]
J. COVID-19 charges. NetApp has excluded certain non-recurring expenses incurred as a direct result of the COVID-19 pandemic. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-21-004947:8k_2_02:83]
K. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-21-004947:8k_2_02:84]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should

[0000950170-21-004947:8k_2_02:85]
only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0000950170-21-004947:8k_2_02:86]
About NetApp

[0000950170-21-004947:8k_2_02:87]
In a world full of generalists, NetApp is a specialist. We’re focused on one thing, helping your business get the most out of your data. NetApp brings the enterprise-grade data services you rely on into the cloud, and the simple flexibility of cloud into the data center. Our industry-leading solutions work across diverse customer environments and the world’s biggest public clouds. As a cloud-led, data-centric software company, only NetApp can help build your unique data fabric, simplify and connect your cloud, and securely deliver the right data, services, and applications to the right people—anytime, anywhere.

[0000950170-21-004947:8k_2_02:88]
NETAPP, INC.

[0000950170-21-004947:8k_2_02:89]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-21-004947:8k_2_02:90]
(In millions)

[0000950170-21-004947:8k_2_02:91]
(Unaudited)

[0000950170-21-004947:8k_2_02:92]
|  |  | October 29, 2021 |  |  | April 30, 2021 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,548 |  |  | $ | 4,596 |  |
| Accounts receivable |  |  | 647 |  |  |  | 945 |  |
| Inventories |  |  | 155 |  |  |  | 114 |  |
| Other current assets |  |  | 319 |  |  |  | 346 |  |
| Total current assets |  |  | 5,669 |  |  |  | 6,001 |  |
| Property and equipment, net |  |  | 549 |  |  |  | 525 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,137 |  |  |  | 2,140 |  |
| Other non-current assets |  |  | 867 |  |  |  | 694 |  |
| Total assets |  | $ | 9,222 |  |  | $ | 9,360 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 432 |  |  | $ | 420 |  |
| Accrued expenses |  |  | 796 |  |  |  | 970 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,967 |  |  |  | 2,062 |  |
| Total current liabilities |  |  | 3,195 |  |  |  | 3,452 |  |
| Long-term debt |  |  | 2,634 |  |  |  | 2,632 |  |
| Other long-term liabilities |  |  | 735 |  |  |  | 650 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,899 |  |  |  | 1,941 |  |
| Total liabilities |  |  | 8,463 |  |  |  | 8,675 |  |
| Stockholders' equity |  |  | 759 |  |  |  | 685 |  |
| Total liabilities and stockholders' equity |  | $ | 9,222 |  |  | $ | 9,360 |  |

[0000950170-21-004947:8k_2_02:93]
NETAPP, INC.

[0000950170-21-004947:8k_2_02:94]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-21-004947:8k_2_02:95]
(In millions, except per share amounts)

[0000950170-21-004947:8k_2_02:96]
(Unaudited)

[0000950170-21-004947:8k_2_02:97]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 814 |  |  | $ | 749 |  |  | $ | 1,544 |  |  | $ | 1,376 |  |
| Services |  |  | 752 |  |  |  | 667 |  |  |  | 1,480 |  |  |  | 1,343 |  |
| Net revenues |  |  | 1,566 |  |  |  | 1,416 |  |  |  | 3,024 |  |  |  | 2,719 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 372 |  |  |  | 360 |  |  |  | 701 |  |  |  | 676 |  |
| Cost of services |  |  | 135 |  |  |  | 123 |  |  |  | 265 |  |  |  | 238 |  |
| Total cost of revenues |  |  | 507 |  |  |  | 483 |  |  |  | 966 |  |  |  | 914 |  |
| Gross profit |  |  | 1,059 |  |  |  | 933 |  |  |  | 2,058 |  |  |  | 1,805 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 465 |  |  |  | 432 |  |  |  | 916 |  |  |  | 861 |  |
| Research and development |  |  | 216 |  |  |  | 212 |  |  |  | 426 |  |  |  | 445 |  |
| General and administrative |  |  | 76 |  |  |  | 67 |  |  |  | 142 |  |  |  | 128 |  |
| Restructuring charges |  |  | 7 |  |  |  | 37 |  |  |  | 29 |  |  |  | 42 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 3 |  |  |  | 2 |  |  |  | 11 |  |
| Total operating expenses |  |  | 765 |  |  |  | 751 |  |  |  | 1,515 |  |  |  | 1,487 |  |
| Income from operations |  |  | 294 |  |  |  | 182 |  |  |  | 543 |  |  |  | 318 |  |
| Other expense, net |  |  | (14 | ) |  |  | (7 | ) |  |  | (26 | ) |  |  | (39 | ) |
| Income before income taxes |  |  | 280 |  |  |  | 175 |  |  |  | 517 |  |  |  | 279 |  |
| Provision for income taxes |  |  | 56 |  |  |  | 38 |  |  |  | 91 |  |  |  | 65 |  |
| Net income |  | $ | 224 |  |  | $ | 137 |  |  | $ | 426 |  |  | $ | 214 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.00 |  |  | $ | 0.62 |  |  | $ | 1.91 |  |  | $ | 0.96 |  |
| Diluted |  | $ | 0.98 |  |  | $ | 0.61 |  |  | $ | 1.86 |  |  | $ | 0.96 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 223 |  |  |  | 222 |  |  |  | 223 |  |  |  | 222 |  |
| Diluted |  |  | 229 |  |  |  | 224 |  |  |  | 229 |  |  |  | 223 |  |

[0000950170-21-004947:8k_2_02:98]
NETAPP, INC.

[0000950170-21-004947:8k_2_02:99]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-21-004947:8k_2_02:100]
(In millions)

[0000950170-21-004947:8k_2_02:101]
(Unaudited)

[0000950170-21-004947:8k_2_02:102]
|  |  | Three Months Ended |  |  | Six Months Ended |
|  |  | October 29, 2021 |  |  | October 30, 2020 |  |  | October 29, 2021 |  |  | October 30, 2020 |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 224 |  |  | $ | 137 |  |  | $ | 426 |  |  | $ | 214 |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 46 |  |  |  | 56 |  |  |  | 92 |  |  |  | 105 |  |  |
| Non-cash operating lease cost |  |  | 15 |  |  |  | 13 |  |  |  | 28 |  |  |  | 26 |  |  |
| Stock-based compensation |  |  | 62 |  |  |  | 49 |  |  |  | 115 |  |  |  | 103 |  |  |
| Deferred income taxes |  |  | (17 | ) |  |  | — |  |  |  | (32 | ) |  |  | — |  |  |
| Other items, net |  |  | (16 | ) |  |  | 3 |  |  |  | (12 | ) |  |  | 28 |  |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 5 |  |  |  | (194 | ) |  |  | 292 |  |  |  | 197 |  |  |
| Inventories |  |  | (47 | ) |  |  | 20 |  |  |  | (41 | ) |  |  | 29 |  |  |
| Accounts payable |  |  | 62 |  |  |  | (30 | ) |  |  | 11 |  |  |  | (59 | ) |  |
| Accrued expenses |  |  | 36 |  |  |  | 117 |  |  |  | (206 | ) |  |  | (69 | ) |  |
| Deferred revenue and financed unearned services revenue |  |  | (15 | ) |  |  | 40 |  |  |  | (97 | ) |  |  | (118 | ) |  |
| Long-term taxes payable |  |  | (57 | ) |  |  | (52 | ) |  |  | (65 | ) |  |  | (46 | ) |  |
| Changes in other operating assets and liabilities, net |  |  | — |  |  |  | 2 |  |  |  | 29 |  |  |  | (9 | ) |  |
| Net cash provided by operating activities |  |  | 298 |  |  |  | 161 |  |  |  | 540 |  |  |  | 401 |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 15 |  |  |  | 22 |  |  |  | 26 |  |  |  | 107 |  |  |
| Purchases of property and equipment |  |  | (46 | ) |  |  | (40 | ) |  |  | (97 | ) |  |  | (92 | ) |  |
| Proceeds from sale of properties |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6 |  |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | — |  |  |  | (14 | ) |  |  | (350 | ) |  |
| Other investing activities, net |  |  | — |  |  |  | 8 |  |  |  | — |  |  |  | 8 |  |  |
| Net cash used in investing activities |  |  | (31 | ) |  |  | (10 | ) |  |  | (85 | ) |  |  | (321 | ) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | — |  |  |  | 1 |  |  |  | 53 |  |  |  | 49 |  |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (6 | ) |  |  | (1 | ) |  |  | (63 | ) |  |  | (34 | ) |  |
| Repurchase of common stock |  |  | (125 | ) |  |  | — |  |  |  | (225 | ) |  |  | — |  |  |
| Repayments of commercial paper notes, original maturities of three months or less, net |  |  | — |  |  |  | (50 | ) |  |  | — |  |  |  | (420 | ) |  |
| Issuance of debt, net of issuance costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2,057 |  |  |
| Repayments and extinguishment of debt |  |  | — |  |  |  | (100 | ) |  |  | — |  |  |  | (689 | ) |  |
| Dividends paid |  |  | (112 | ) |  |  | (107 | ) |  |  | (224 | ) |  |  | (214 | ) |  |
| Other financing activities, net |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | (3 | ) |  |
| Net cash (used in) provided by financing activities |  |  | (243 | ) |  |  | (257 | ) |  |  | (461 | ) |  |  | 746 |  |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (8 | ) |  |  | 1 |  |  |  | (13 | ) |  |  | 44 |  |  |
| Net change in cash, cash equivalents and restricted cash |  |  | 16 |  |  |  | (105 | ) |  |  | (19 | ) |  |  | 870 |  |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 4,500 |  |  |  | 3,641 |  |  |  | 4,535 |  |  |  | 2,666 |  |  |
| End of period |  | $ | 4,516 |  |  | $ | 3,536 |  |  | $ | 4,516 |  |  | $ | 3,536 |  |  |

[0000950170-21-004947:8k_2_02:103]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| In the first quarter of fiscal year 2022, the Company introduced two segments for financial reporting purposes: Hybrid Cloud and Public Cloud. Prior period disclosures have been revised for comparability. |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Product |  | $ | 814 |  |  | $ | 730 |  |  | $ | 749 |  |
| Support |  |  | 590 |  |  |  | 578 |  |  |  | 553 |  |
| Professional and Other Services |  |  | 75 |  |  |  | 71 |  |  |  | 67 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,479 |  |  |  | 1,379 |  |  |  | 1,369 |  |
| Public Cloud Segment Net Revenues |  |  | 87 |  |  |  | 79 |  |  |  | 47 |  |
| Net Revenues |  | $ | 1,566 |  |  | $ | 1,458 |  |  | $ | 1,416 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Product |  | $ | 445 |  |  | $ | 404 |  |  | $ | 397 |  |
| Support |  |  | 542 |  |  |  | 530 |  |  |  | 503 |  |
| Professional and Other Services |  |  | 21 |  |  |  | 20 |  |  |  | 17 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,008 |  |  |  | 954 |  |  |  | 917 |  |
| Public Cloud Segment Gross Profit |  |  | 62 |  |  |  | 56 |  |  |  | 31 |  |
| Total Segments Gross Profit |  |  | 1,070 |  |  |  | 1,010 |  |  |  | 948 |  |
| Amortization of Intangible Assets |  |  | (7 | ) |  |  | (7 | ) |  |  | (12 | ) |
| Stock-based Compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (3 | ) |
| Unallocated Cost of Revenues |  |  | (11 | ) |  |  | (11 | ) |  |  | (15 | ) |
| Gross Profit |  | $ | 1,059 |  |  | $ | 999 |  |  | $ | 933 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Product |  |  | 54.7 | % |  |  | 55.3 | % |  |  | 53.0 | % |
| Support |  |  | 91.9 | % |  |  | 91.7 | % |  |  | 91.0 | % |
| Professional and Other Services |  |  | 28.0 | % |  |  | 28.2 | % |  |  | 25.4 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 68.2 | % |  |  | 69.2 | % |  |  | 67.0 | % |
| Public Cloud Segment Gross Margin |  |  | 71.3 | % |  |  | 70.9 | % |  |  | 66.0 | % |
| Product Revenues |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Total |  | $ | 814 |  |  | $ | 730 |  |  | $ | 749 |  |
| Software* |  | $ | 475 |  |  | $ | 414 |  |  | $ | 417 |  |
| Hardware* |  | $ | 339 |  |  | $ | 316 |  |  | $ | 332 |  |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components to display the significance of software included in total product revenues. |  |
| Software and recurring support and public cloud revenue |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Product - Software |  | $ | 475 |  |  | $ | 414 |  |  | $ | 417 |  |
| Support |  |  | 590 |  |  |  | 578 |  |  |  | 553 |  |
| Public Cloud |  |  | 87 |  |  |  | 79 |  |  |  | 47 |  |
| Software and recurring support and public cloud revenue* |  | $ | 1,152 |  |  | $ | 1,071 |  |  | $ | 1,017 |  |

[0000950170-21-004947:8k_2_02:104]
| Software and recurring support and public cloud revenue as a percentage of net revenues |  |  | 74 | % |  |  | 73 | % |  |  | 72 | % |
| *Software and recurring support and public cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'22 |  |  | % of Q1 FY'22 |  |  | % of Q2 FY'21 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 55 | % |  |  | 54 | % |  |  | 55 | % |
| Americas Commercial |  |  | 43 | % |  |  | 43 | % |  |  | 40 | % |
| U.S. Public Sector |  |  | 12 | % |  |  | 11 | % |  |  | 15 | % |
| EMEA |  |  | 29 | % |  |  | 31 | % |  |  | 30 | % |
| Asia Pacific |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'22 |  |  | % of Q1 FY'22 |  |  | % of Q2 FY'21 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 24 | % |  |  | 23 | % |  |  | 25 | % |
| Indirect |  |  | 76 | % |  |  | 77 | % |  |  | 75 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Non-GAAP Income from Operations |  | $ | 374 |  |  | $ | 336 |  |  | $ | 291 |  |
| % of Net Revenues |  |  | 23.9 | % |  |  | 23.0 | % |  |  | 20.6 | % |
| Non-GAAP Income before Income Taxes |  | $ | 360 |  |  | $ | 324 |  |  | $ | 278 |  |
| Non-GAAP Effective Tax Rate |  |  | 18.9 | % |  |  | 18.8 | % |  |  | 15.1 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Non-GAAP Net Income |  | $ | 292 |  |  | $ | 263 |  |  | $ | 236 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 229 |  |  |  | 229 |  |  |  | 224 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.28 |  |  | $ | 1.15 |  |  | $ | 1.05 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,866 |  |  | $ | 3,904 |  |  | $ | 3,651 |  |
| DSO (days) |  |  | 38 |  |  |  | 41 |  |  |  | 51 |  |
| DPO (days) |  |  | 78 |  |  |  | 73 |  |  |  | 69 |  |
| Inventory Turns |  |  | 13 |  |  |  | 17 |  |  |  | 17 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Net Cash Provided by Operating Activities |  | $ | 298 |  |  | $ | 242 |  |  | $ | 161 |  |
| Purchases of Property and Equipment |  | $ | 46 |  |  | $ | 51 |  |  | $ | 40 |  |
| Free Cash Flow |  | $ | 252 |  |  | $ | 191 |  |  | $ | 121 |  |
| Free Cash Flow as % of Net Revenues |  |  | 16.1 | % |  |  | 13.1 | % |  |  | 8.5 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |

[0000950170-21-004947:8k_2_02:105]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| NET INCOME |  | $ | 224 |  |  | $ | 202 |  |  | $ | 137 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  |  | 9 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 62 |  |  |  | 53 |  |  |  | 49 |  |
| Litigation settlements |  |  | — |  |  |  | 2 |  |  |  | 5 |  |
| Restructuring charges |  |  | 7 |  |  |  | 22 |  |  |  | 37 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | (6 | ) |
| Income tax effects |  |  | (13 | ) |  |  | (26 | ) |  |  | (9 | ) |
| Income tax expenses from integration of acquired companies |  |  | 1 |  |  |  | — |  |  |  | 5 |  |
| NON-GAAP NET INCOME |  | $ | 292 |  |  | $ | 263 |  |  | $ | 236 |  |
| COST OF REVENUES |  | $ | 507 |  |  | $ | 459 |  |  | $ | 483 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (7 | ) |  |  | (12 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (3 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 496 |  |  | $ | 448 |  |  | $ | 468 |  |
| COST OF PRODUCT REVENUES |  | $ | 372 |  |  | $ | 329 |  |  | $ | 360 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (2 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 369 |  |  | $ | 326 |  |  | $ | 352 |  |
| COST OF SERVICES REVENUES |  | $ | 135 |  |  | $ | 130 |  |  | $ | 123 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (2 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 127 |  |  | $ | 122 |  |  | $ | 116 |  |
| GROSS PROFIT |  | $ | 1,059 |  |  | $ | 999 |  |  | $ | 933 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 7 |  |  |  | 7 |  |  |  | 12 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 4 |  |  |  | 3 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,070 |  |  | $ | 1,010 |  |  | $ | 948 |  |

[0000950170-21-004947:8k_2_02:106]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| SALES AND MARKETING EXPENSES |  | $ | 465 |  |  | $ | 451 |  |  | $ | 432 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |
| Stock-based compensation |  |  | (29 | ) |  |  | (26 | ) |  |  | (24 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 433 |  |  | $ | 423 |  |  | $ | 405 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 216 |  |  | $ | 210 |  |  | $ | 212 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (19 | ) |  |  | (15 | ) |  |  | (15 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 197 |  |  | $ | 195 |  |  | $ | 197 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 76 |  |  | $ | 66 |  |  | $ | 67 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (10 | ) |  |  | (8 | ) |  |  | (7 | ) |
| Litigation settlements |  |  | — |  |  |  | (2 | ) |  |  | (5 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 66 |  |  | $ | 56 |  |  | $ | 55 |  |
| RESTRUCTURING CHARGES |  | $ | 7 |  |  | $ | 22 |  |  | $ | 37 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (7 | ) |  |  | (22 | ) |  |  | (37 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 1 |  |  | $ | 1 |  |  | $ | 3 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (1 | ) |  |  | (1 | ) |  |  | (3 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 765 |  |  | $ | 750 |  |  | $ | 751 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |
| Stock-based compensation |  |  | (58 | ) |  |  | (49 | ) |  |  | (46 | ) |
| Litigation settlements |  |  | — |  |  |  | (2 | ) |  |  | (5 | ) |
| Restructuring charges |  |  | (7 | ) |  |  | (22 | ) |  |  | (37 | ) |
| Acquisition-related expense |  |  | (1 | ) |  |  | (1 | ) |  |  | (3 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 696 |  |  | $ | 674 |  |  | $ | 657 |  |

[0000950170-21-004947:8k_2_02:107]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| INCOME FROM OPERATIONS |  | $ | 294 |  |  | $ | 249 |  |  | $ | 182 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  |  | 9 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 62 |  |  |  | 53 |  |  |  | 49 |  |
| Litigation settlements |  |  | — |  |  |  | 2 |  |  |  | 5 |  |
| Restructuring charges |  |  | 7 |  |  |  | 22 |  |  |  | 37 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 374 |  |  | $ | 336 |  |  | $ | 291 |  |
| OTHER EXPENSE, NET |  | $ | (14 | ) |  | $ | (12 | ) |  | $ | (7 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | (6 | ) |
| NON-GAAP OTHER EXPENSE, NET |  | $ | (14 | ) |  | $ | (12 | ) |  | $ | (13 | ) |
| INCOME BEFORE INCOME TAXES |  | $ | 280 |  |  | $ | 237 |  |  | $ | 175 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  |  | 9 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 62 |  |  |  | 53 |  |  |  | 49 |  |
| Litigation settlements |  |  | — |  |  |  | 2 |  |  |  | 5 |  |
| Restructuring charges |  |  | 7 |  |  |  | 22 |  |  |  | 37 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | (6 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 360 |  |  | $ | 324 |  |  | $ | 278 |  |
| PROVISION FOR INCOME TAXES |  | $ | 56 |  |  | $ | 35 |  |  | $ | 38 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 13 |  |  |  | 26 |  |  |  | 9 |  |
| Income tax expenses from integration of acquired companies |  |  | (1 | ) |  |  | — |  |  |  | (5 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 68 |  |  | $ | 61 |  |  | $ | 42 |  |
| NET INCOME PER SHARE |  | $ | 0.98 |  |  | $ | 0.88 |  |  | $ | 0.61 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.04 |  |  |  | 0.04 |  |  |  | 0.07 |  |
| Stock-based compensation |  |  | 0.27 |  |  |  | 0.23 |  |  |  | 0.22 |  |
| Litigation settlements |  |  | — |  |  |  | 0.01 |  |  |  | 0.02 |  |
| Restructuring charges |  |  | 0.03 |  |  |  | 0.10 |  |  |  | 0.17 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 0.01 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | (0.03 | ) |
| Income tax effects |  |  | (0.06 | ) |  |  | (0.11 | ) |  |  | (0.04 | ) |
| Income tax expenses from integration of acquired companies |  |  | — |  |  | — |  |  |  | 0.02 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.28 |  |  | $ | 1.15 |  |  | $ | 1.05 |  |

[0000950170-21-004947:8k_2_02:108]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Gross margin-GAAP |  |  | 67.6 | % |  |  | 68.5 | % |  |  | 65.9 | % |
| Cost of revenues adjustments |  |  | 0.7 | % |  |  | 0.8 | % |  |  | 1.1 | % |
| Gross margin-Non-GAAP |  |  | 68.3 | % |  |  | 69.3 | % |  |  | 66.9 | % |
| GAAP cost of revenues |  | $ | 507 |  |  | $ | 459 |  |  | $ | 483 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (7 | ) |  |  | (12 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (3 | ) |
| Non-GAAP cost of revenues |  | $ | 496 |  |  | $ | 448 |  |  | $ | 468 |  |
| Net revenues |  | $ | 1,566 |  |  | $ | 1,458 |  |  | $ | 1,416 |  |

[0000950170-21-004947:8k_2_02:109]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Product gross margin-GAAP |  |  | 54.3 | % |  |  | 54.9 | % |  |  | 51.9 | % |
| Cost of product revenues adjustments |  |  | 0.4 | % |  |  | 0.4 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 54.7 | % |  |  | 55.3 | % |  |  | 53.0 | % |
| GAAP cost of product revenues |  | $ | 372 |  |  | $ | 329 |  |  | $ | 360 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (2 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 369 |  |  | $ | 326 |  |  | $ | 352 |  |
| Product revenues |  | $ | 814 |  |  | $ | 730 |  |  | $ | 749 |  |

[0000950170-21-004947:8k_2_02:110]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Services gross margin-GAAP |  |  | 82.0 | % |  |  | 82.1 | % |  |  | 81.6 | % |
| Cost of services revenues adjustment |  |  | 1.1 | % |  |  | 1.1 | % |  |  | 1.0 | % |
| Services gross margin-Non-GAAP |  |  | 83.1 | % |  |  | 83.2 | % |  |  | 82.6 | % |
| GAAP cost of services revenues |  | $ | 135 |  |  | $ | 130 |  |  | $ | 123 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (2 | ) |
| Non-GAAP cost of services revenues |  | $ | 127 |  |  | $ | 122 |  |  | $ | 116 |  |
| Services revenues |  | $ | 752 |  |  | $ | 728 |  |  | $ | 667 |  |

[0000950170-21-004947:8k_2_02:111]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| GAAP effective tax rate |  |  | 20.0 | % |  |  | 14.8 | % |  |  | 21.7 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (0.8 | )% |  |  | 4.1 | % |  |  | (3.8 | )% |
| Income tax expenses from integration of acquired companies |  |  | (0.4 | )% |  |  | — | % |  |  | (2.9 | )% |
| Non-GAAP effective tax rate |  |  | 18.9 | % |  |  | 18.8 | % |  |  | 15.1 | % |

[0000950170-21-004947:8k_2_02:112]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Net cash provided by operating activities |  | $ | 298 |  |  | $ | 242 |  |  | $ | 161 |  |
| Purchases of property and equipment |  |  | (46 | ) |  |  | (51 | ) |  |  | (40 | ) |
| Free cash flow |  | $ | 252 |  |  | $ | 191 |  |  | $ | 121 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY22 |  |  | Q1'FY22 |  |  | Q2'FY21 |  |
| Net revenues |  | $ | 1,566 |  |  | $ | 1,458 |  |  | $ | 1,416 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | (15 | ) |  |  | (82 | ) |  |  | 40 |  |
| Billings |  | $ | 1,551 |  |  | $ | 1,376 |  |  | $ | 1,456 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-21-004947:8k_2_02:113]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| THIRD QUARTER FISCAL 2022 |
|  |  | Third Quarter |
|  |  | Fiscal 2022 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.21 - $1.31 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Third Quarter Fiscal 2022: |  |  |
| Amortization of intangible assets |  | ($0.04) |
| Stock-based compensation expense |  | ($0.27) |
| Income tax effects |  | $0.03 |
| Total Adjustments |  | ($0.28) |
| GAAP Guidance - Net Income Per Share |  | $0.93 - $1.03 |

[0000950170-21-004947:8k_2_02:114]
Some items may not add or recalculate due to rounding.

[0000950170-21-004947:8k_2_02:115]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| FISCAL 2022 |
| (Unaudited) |
|  |  | GROSS MARGIN |
| Gross Margin - Non-GAAP Guidance |  | ~68% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | ~67% |
|  |  | OPERATING MARGIN |
| Operating Margin - Non-GAAP Guidance |  | 23% - 24% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (4)% |
| Operating Margin - GAAP Guidance |  | 18% - 19% |
|  |  | EFFECTIVE TAX RATE |
| Effective Tax Rate - Non-GAAP Guidance |  |  |
| Adjustment: |  | ~19% |
| Income tax effects |  | 2% |
| Effective Tax Rate - GAAP Guidance |  | ~21% |

[0000950170-21-004947:8k_2_02:116]
Some items may not add or recalculate due to rounding.

[0000950170-21-004947:8k_2_02:117]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FISCAL 2022 |
|  |  | Fiscal 2022 |
| Non-GAAP Guidance - Net Income Per Share |  | $4.90 - $5.10 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2022: |  |  |
| Amortization of intangible assets |  | ($0.17) |
| Stock-based compensation expense |  | ($1.06) |
| Income tax effects |  | $0.13 |
| Total Adjustments |  | ($1.10) |
| GAAP Guidance - Net Income Per Share |  | $3.80 - $4.00 |

[0000950170-21-004947:8k_2_02:118]
Some items may not add or recalculate due to rounding.

[0000950170-21-004947:8k_2_02:119]
Contacts:

[0000950170-21-004947:8k_2_02:120]
(Press)

[0000950170-21-004947:8k_2_02:121]
Chris Drago

[0000950170-21-004947:8k_2_02:122]
1 831 900 8889

[0000950170-21-004947:8k_2_02:123]
chris.drago@netapp.com

[0000950170-21-004947:8k_2_02:124]
(Investors)

[0000950170-21-004947:8k_2_02:125]
Lance Berger

[0000950170-21-004947:8k_2_02:126]
1 408 822 6628

[0000950170-21-004947:8k_2_02:127]
lance.berger@netapp.com
