# NTAP MD&A — 0000950170-24-071327


## mdna

[0000950170-24-071327:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000950170-24-071327:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and the accompanying notes set forth under Part II, Item 8. – Financial Statements and Supplementary Data. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and uncertainties. The Risk Factors set forth in Part I, Item 1A. – Risk Factors are hereby incorporated into the discussion by reference.

[0000950170-24-071327:mdna:3]
Executive Overview

[0000950170-24-071327:mdna:4]
Our Company

[0000950170-24-071327:mdna:5]
NetApp makes data infrastructure intelligent by combining unified data storage, integrated data services, and CloudOps solutions. We create silo-free infrastructure, and harness observability and artificial intelligence to enable seamless data management across environments to help our customers achieve their business priorities.  No matter the data type, workload, or environment, with NetApp customers can modernize their data infrastructure and better leverage their data to accelerate innovation, improve operations, and drive competitive advantage.

[0000950170-24-071327:mdna:6]
Our unified data storage delivers flexibility by enabling customers to store any data type and power any workload, simply and consistently on a single storage operating system, optimized for cloud and flash. As the only enterprise-grade storage service natively embedded in the world’s largest clouds, our data storage powers any data across AWS, Microsoft Azure, and Google Cloud. Our integrated data services enable active data management through superior data security, protection, governance, and sustainability. Our CloudOps solutions enable adaptive operations across infrastructure, applications, and teams.

[0000950170-24-071327:mdna:7]
Our operations are organized into two segments: Hybrid Cloud and Public Cloud.

[0000950170-24-071327:mdna:8]
Hybrid Cloud offers a unified data storage portfolio of storage management and infrastructure solutions that help customers modernize their data centers. With the power of on-premises, private cloud and public cloud capabilities to assist customers in modernizing applications with a single solution that supports file, block, and object storage, we deliver a data infrastructure solution for all environments and workloads. Our Hybrid Cloud portfolio supports structured and unstructured data with unified storage optimized for flash, disk, and cloud storage to handle data-intensive workloads and applications. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-24-071327:mdna:9]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and CloudOps services. As the only provider of enterprise-grade storage services natively embedded in the world’s largest public cloud providers, NetApp helps organizations harness the power of their data and applications. NetApp’s CloudOps solutions leverage AI to maximize productivity across infrastructure and applications, boost team productivity, and reduce operations costs. These solutions and services are generally available on the leading public clouds, including Amazon AWS, Microsoft Azure, and Google Cloud Platform.

[0000950170-24-071327:mdna:10]
Global Business Environment

[0000950170-24-071327:mdna:11]
Macroeconomic Conditions

[0000950170-24-071327:mdna:12]
Continuing economic uncertainty, political conditions and fiscal challenges in the U.S. and abroad have resulted and may continue to result in adverse macroeconomic conditions, including inflation, rising interest rates, foreign exchange volatility, slower growth and possibly a recession. In particular, in fiscal 2024, we continued to experience a weakened demand environment, characterized by cloud optimizations and increased budget scrutiny, which resulted in smaller deal sizes, longer selling cycles, and the delay of some deals.

[0000950170-24-071327:mdna:13]
If these macroeconomic uncertainties persist or worsen in fiscal 2025, we may observe a further reduction in customer demand for our offerings, which could impact our operating results.

[0000950170-24-071327:mdna:14]
Supply Chain

[0000950170-24-071327:mdna:15]
Supply chain constraints, which substantially began to impact us in the first half of fiscal 2023, led to elevated product component and freight costs during fiscal 2023. Comparatively, the supply chain substantially improved during fiscal 2024, resulting in lower costs.

[0000950170-24-071327:mdna:16]
Financial Results and Key Performance Metrics Overview

[0000950170-24-071327:mdna:17]
The following table provides an overview of key financial metrics for each of the last three fiscal years (in millions, except per share amounts and percentages):

[0000950170-24-071327:mdna:18]
|  |  | Year Ended |  |
|  |  | April 26, 2024 |  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Net revenues |  | $ | 6,268 |  |  | $ | 6,362 |  |  | $ | 6,318 |  |
| Gross profit |  | $ | 4,433 |  |  | $ | 4,209 |  |  | $ | 4,220 |  |
| Gross margin |  |  | 71 | % |  |  | 66 | % |  |  | 67 | % |
| Income from operations |  | $ | 1,214 |  |  | $ | 1,018 |  |  | $ | 1,157 |  |
| Income from operations as a percentage of net revenues |  |  | 19 | % |  |  | 16 | % |  |  | 18 | % |
| Provision (benefit) for income taxes |  | $ | 277 |  |  | $ | (208 | ) |  | $ | 158 |  |
| Net income |  | $ | 986 |  |  | $ | 1,274 |  |  | $ | 937 |  |
| Diluted net income per share |  | $ | 4.63 |  |  | $ | 5.79 |  |  | $ | 4.09 |  |
| Net cash provided by operating activities |  | $ | 1,685 |  |  | $ | 1,107 |  |  | $ | 1,211 |  |

[0000950170-24-071327:mdna:19]
|  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 4,234 |  |  | $ | 4,313 |  |

[0000950170-24-071327:mdna:20]
•
Net revenues: Our net revenues decreased approximately 1% in fiscal 2024 compared to fiscal 2023, due to a decrease in product revenues, partially offset by an increase in services revenues.

[0000950170-24-071327:mdna:21]
•
Gross margin: Our gross margin increased five percentage points in fiscal 2024 compared to fiscal 2023, due to the increase in gross margins on product revenues.

[0000950170-24-071327:mdna:22]
•
Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues increased by three percentage points in fiscal 2024 compared to fiscal 2023, primarily due to a higher gross margin.

[0000950170-24-071327:mdna:23]
•
Provision (benefit) for income taxes: We had a provision from income taxes in fiscal 2024, compared to a benefit from income taxes in fiscal 2023, due to a discrete tax benefit of $524 million in fiscal 2023 that resulted from an intra-entity asset transfer of certain intellectual property.

[0000950170-24-071327:mdna:24]
•
Net income and Diluted net income per share: The decrease in both net income and diluted net income per share in fiscal 2024 compared to fiscal 2023 reflect the factors discussed above. Lower net income in fiscal 2024 compared to fiscal 2023 unfavorably impacted diluted net income per share.

[0000950170-24-071327:mdna:25]
Stock Repurchase Program and Dividend Activity

[0000950170-24-071327:mdna:26]
During fiscal 2024, we repurchased approximately 12 million shares of our common stock at an average price of $77.87 per share, for an aggregate purchase price of $900 million. We also declared aggregate cash dividends of $2.00 per share in fiscal 2024, for which we paid a total of $416 million.

[0000950170-24-071327:mdna:27]
Restructuring Events

[0000950170-24-071327:mdna:28]
During fiscal 2024, we executed two restructuring plans and recognized expenses totaling $44 million consisting primarily of employee severance-related costs and lease termination costs.

[0000950170-24-071327:mdna:29]
37

[0000950170-24-071327:mdna:30]
Results of Operations

[0000950170-24-071327:mdna:31]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2024, 2023 and 2022, which ended on April 26, 2024, April 28, 2023 and April 29, 2022, respectively, are all 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to our fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0000950170-24-071327:mdna:32]
The following table sets forth certain Consolidated Statements of Income data as a percentage of net revenues for the periods indicated:

[0000950170-24-071327:mdna:33]
|  |  | Fiscal Year |  |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 45 | % |  |  | 48 | % |  |  | 52 | % |  |
| Services |  |  | 55 |  |  |  | 52 |  |  |  | 48 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 18 |  |  |  | 24 |  |  |  | 25 |  |  |
| Cost of services |  |  | 11 |  |  |  | 10 |  |  |  | 9 |  |  |
| Gross profit |  |  | 71 |  |  |  | 66 |  |  |  | 67 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29 |  |  |  | 29 |  |  |  | 29 |  |  |
| Research and development |  |  | 16 |  |  |  | 15 |  |  |  | 14 |  |  |
| General and administrative |  |  | 5 |  |  |  | 4 |  |  |  | 4 |  |  |
| Restructuring charges |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 51 |  |  |  | 50 |  |  |  | 48 |  |  |
| Income from operations |  |  | 19 |  |  |  | 16 |  |  |  | 18 |  |  |
| Other income (expense), net |  |  | 1 |  |  |  | 1 |  |  |  | (1 | ) |  |
| Income before income taxes |  |  | 20 |  |  |  | 17 |  |  |  | 17 |  |  |
| Provision (benefit) for income taxes |  |  | 4 |  |  |  | (3 | ) |  |  | 3 |  |  |
| Net income |  |  | 16 | % |  |  | 20 | % |  |  | 15 | % |  |

[0000950170-24-071327:mdna:34]
Percentages may not add due to rounding

[0000950170-24-071327:mdna:35]
Discussion and Analysis of Results of Operations

[0000950170-24-071327:mdna:36]
Net Revenues (in millions, except percentages):

[0000950170-24-071327:mdna:37]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| Net revenues |  |  | $ | 6,268 |  |  | $ | 6,362 |  |  |  | (1 | )% |  | $ | 6,318 |  |  |  | 1 | % |

[0000950170-24-071327:mdna:38]
The decrease in net revenues for fiscal 2024 compared to fiscal 2023 was due to a decrease in product revenues partially offset by an increase in services revenues. Product revenues as a percentage of net revenues decreased by approximately three percentage points in fiscal 2024 compared to fiscal 2023, while services revenues as a percentage of net revenues increased by approximately three percentage points.

[0000950170-24-071327:mdna:39]
The increase in net revenues for fiscal 2023 compared to fiscal 2022 was due to an increase in services revenue partially offset by a decrease in product revenues. Product revenues as a percentage of net revenues decreased by approximately four percentage points in fiscal 2023 compared to fiscal 2022, while services revenues as a percentage of net revenues increased by approximately four percentage points. Fluctuations in foreign currency exchange rates adversely impacted net revenues percent growth by approximately four percentage points in fiscal 2023 compared to fiscal 2022.

[0000950170-24-071327:mdna:40]
Sales through our indirect channels represented 76%, 78% and 77% of net revenues in fiscal 2024, 2023 and 2022, respectively.

[0000950170-24-071327:mdna:41]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0000950170-24-071327:mdna:42]
|  |  | Fiscal Year |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 24 | % |  |  | 24 | % |
| TD Synnex Corporation (previously presented as Tech Data Corporation) |  |  | 22 | % |  |  | 21 | % |  |  | 21 | % |

[0000950170-24-071327:mdna:43]
Product Revenues (in millions, except percentages):

[0000950170-24-071327:mdna:44]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| Product revenues |  |  | $ | 2,849 |  |  | $ | 3,049 |  |  |  | (7 | )% |  | $ | 3,284 |  |  |  | (7 | )% |
| Hardware (Non-GAAP) |  |  |  | 1,251 |  |  |  | 1,251 |  |  |  | — | % |  |  | 1,358 |  |  |  | (8 | )% |
| Software (Non-GAAP) |  |  |  | 1,598 |  |  |  | 1,798 |  |  |  | (11 | )% |  |  | 1,926 |  |  |  | (7 | )% |

[0000950170-24-071327:mdna:45]
Hybrid Cloud

[0000950170-24-071327:mdna:46]
Product revenues are derived through the sale of our Hybrid Cloud solutions and consist of sales of configured all-flash array systems (including All-Flash FAS A-Series and All-Flash FAS C-Series with capacity flash) and hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, StorageGrid, OEM products, NetApp HCI and add-on optional software.

[0000950170-24-071327:mdna:47]
In order to provide visibility into the value created by our software innovation and R&D investment, we disclose the software and hardware components of our product revenues. Software product revenues includes the OS software and optional add-on software solutions attached to our systems across our entire product set, while hardware product revenues include the non-software component of our systems across the entire set. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, the hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-24-071327:mdna:48]
Total product revenues decreased in fiscal 2024 compared to fiscal 2023, primarily due to lower sales of hybrid systems due to softening customer demand, partially offset by an increase in sales of C-Series all-flash array systems.

[0000950170-24-071327:mdna:49]
Total product revenues decreased in fiscal 2023 compared to fiscal 2022, primarily due to lower sales of A-Series all-flash array systems, as a result of softening customer demand. Product revenues were also unfavorably impacted by foreign exchange rate fluctuations. These decreases were partially offset by an increase in sales of hybrid systems.

[0000950170-24-071327:mdna:50]
Revenues from the hardware component of product revenues represented 44%, 41% and 41% of product revenues in fiscal 2024, 2023 and 2022, respectively. The software component of product revenues represented 56%, 59% and 59% of product revenues in fiscal 2024, 2023 and 2022, respectively. The decrease in the software component percentage of product revenues in fiscal 2024 as compared to fiscal 2023 was primarily due to the mix of systems sold. The software component percentage of product revenues remained relatively flat in fiscal 2023 as compared to fiscal 2022 despite the decrease in sales of A-Series all-flash array systems, which contain a higher proportion of software components than other Hybrid Cloud products, primarily due to the mix of other Hybrid Cloud products sold.

[0000950170-24-071327:mdna:51]
Services Revenues (in millions, except percentages):

[0000950170-24-071327:mdna:52]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| Services revenues |  |  | $ | 3,419 |  |  | $ | 3,313 |  |  |  | 3 | % |  | $ | 3,034 |  |  |  | 9 | % |
| Support |  |  |  | 2,488 |  |  |  | 2,419 |  |  |  | 3 | % |  |  | 2,344 |  |  |  | 3 | % |
| Professional and other services |  |  |  | 320 |  |  |  | 319 |  |  |  | — | % |  |  | 294 |  |  |  | 9 | % |
| Public cloud |  |  |  | 611 |  |  |  | 575 |  |  |  | 6 | % |  |  | 396 |  |  |  | 45 | % |

[0000950170-24-071327:mdna:53]
Hybrid Cloud

[0000950170-24-071327:mdna:54]
Hybrid Cloud services revenues are derived from the sale of: (1) support, which includes both hardware and software support contracts (the latter of which entitle customers to receive unspecified product upgrades and enhancements, bug fixes and patch releases), and (2) professional and other services, which include customer education and training.

[0000950170-24-071327:mdna:55]
Support revenues increased in fiscal 2024 compared to fiscal 2023 as a result of a higher aggregate support contract value for our installed base.

[0000950170-24-071327:mdna:56]
Support revenues increased in fiscal 2023 compared to fiscal 2022, despite the unfavorable impact from foreign exchange rate fluctuations, primarily due to a higher aggregate support contract value for our installed base during fiscal 2023.

[0000950170-24-071327:mdna:57]
Professional and other services revenues remained relatively flat in fiscal 2024 compared to fiscal 2023. The increase in fiscal 2023 compared to fiscal 2022 was primarily due to an increase in other services revenues.

[0000950170-24-071327:mdna:58]
Public Cloud

[0000950170-24-071327:mdna:59]
Public Cloud revenues are derived from the sale of public cloud offerings delivered primarily as-a-service, which include cloud storage and data services, and cloud operations services.

[0000950170-24-071327:mdna:60]
Public Cloud revenues increased in fiscal 2024 and fiscal 2023 compared to the respective prior years primarily due to growing customer demand for NetApp's diversified cloud offerings, coupled with overall growth in the cloud market. The acquisitions of Instaclustr early in the first quarter of fiscal 2023 and CloudCheckr, Inc. (CloudCheckr) in the third quarter of fiscal 2022 also contributed to the increase in Public Cloud revenues in fiscal 2023 compared to fiscal 2022.

[0000950170-24-071327:mdna:61]
Revenues by Geographic Area:

[0000950170-24-071327:mdna:62]
|  |  | Fiscal Year |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| United States, Canada and Latin America (Americas) |  |  | 51 | % |  |  | 51 | % |  |  | 53 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 34 | % |  |  | 34 | % |  |  | 32 | % |
| Asia Pacific (APAC) |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |

[0000950170-24-071327:mdna:63]
Percentages may not add due to rounding

[0000950170-24-071327:mdna:64]
Effective in fiscal 2024, management began evaluating revenues by geographic region based on the location to which products and services are delivered, rather than based on the location from which the customer relationship is managed. Prior year numbers have been recast to conform to the current year presentation.

[0000950170-24-071327:mdna:65]
Americas revenues consist of sales to Americas commercial and United States (U.S.) public sector markets. Demand across geographies was relatively consistent in fiscal 2024 compared to fiscal 2023.  Americas revenues were negatively impacted by adverse macroeconomic conditions which resulted in a weakened demand environment in fiscal 2023 compared to fiscal 2022, which continued into fiscal 2024.

[0000950170-24-071327:mdna:66]
Cost of Revenues

[0000950170-24-071327:mdna:67]
Our cost of revenues consists of:

[0000950170-24-071327:mdna:68]
(1) cost of product revenues, composed of (a) cost of Hybrid Cloud product revenues, which includes the costs of manufacturing and shipping our products, inventory write-downs, and warranty costs, and (b) unallocated cost of product revenues, which includes stock-based compensation and amortization of intangibles, and;

[0000950170-24-071327:mdna:69]
(2) cost of services revenues, composed of (a) cost of support revenues, which includes the costs of providing support activities for hardware and software support, global support partnership programs, and third party royalty costs, (b) cost of professional and other services revenues, (c) cost of public cloud revenues, constituting the cost of providing our Public Cloud offerings which includes depreciation and amortization expense and third party datacenter fees, and (d) unallocated cost of services revenues, which includes stock-based compensation and amortization of intangibles.

[0000950170-24-071327:mdna:70]
Cost of Product Revenues (in millions, except percentages):

[0000950170-24-071327:mdna:71]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| Cost of product revenues |  |  | $ | 1,137 |  |  | $ | 1,517 |  |  |  | (25 | )% |  | $ | 1,554 |  |  |  | (2 | )% |
| Hybrid Cloud |  |  |  | 1,131 |  |  |  | 1,511 |  |  |  | (25 | )% |  |  | 1,541 |  |  |  | (2 | )% |
| Unallocated |  |  |  | 6 |  |  |  | 6 |  |  |  | — | % |  |  | 13 |  |  |  | (54 | )% |

[0000950170-24-071327:mdna:72]
Hybrid Cloud

[0000950170-24-071327:mdna:73]
Cost of Hybrid Cloud product revenues represented 40%, 50% and 47% of Hybrid Cloud product revenues in fiscal 2024, 2023 and 2022, respectively. Materials costs represented 88%, 94% and 93% of cost of Hybrid Cloud product revenues in fiscal 2024, 2023 and 2022, respectively.

[0000950170-24-071327:mdna:74]
Materials costs decreased by approximately $418 million in fiscal 2024 compared to fiscal 2023 reflecting lower component and freight costs as a result of supply chain improvements. Materials costs were also impacted by the decrease in product revenues in fiscal 2024.

[0000950170-24-071327:mdna:75]
Hybrid Cloud gross margins increased by approximately ten percentage points in fiscal 2024 compared to fiscal 2023 primarily due to lower component and freight costs.

[0000950170-24-071327:mdna:76]
Materials costs were approximately flat in fiscal 2023 compared to fiscal 2022 reflecting the decrease in product revenues, offset by higher component and freight costs as a result of supply chain challenges.

[0000950170-24-071327:mdna:77]
Hybrid Cloud gross margins decreased by approximately three percentage points in fiscal 2023 compared to fiscal 2022 primarily due to higher component and freight costs and the adverse impacts of fluctuations in foreign currency exchange rates.

[0000950170-24-071327:mdna:78]
Unallocated

[0000950170-24-071327:mdna:79]
Unallocated cost of product revenues remained relatively flat in fiscal 2024 compared to fiscal 2023 while they decreased in fiscal 2023 compared to fiscal 2022 due to certain intangible assets becoming fully amortized.

[0000950170-24-071327:mdna:80]
Cost of Services Revenues (in millions, except percentages):

[0000950170-24-071327:mdna:81]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| Cost of services revenues |  |  | $ | 698 |  |  | $ | 636 |  |  |  | 10 | % |  | $ | 544 |  |  |  | 17 | % |
| Support |  |  |  | 195 |  |  |  | 181 |  |  |  | 8 | % |  |  | 184 |  |  |  | (2 | )% |
| Professional and other services |  |  |  | 243 |  |  |  | 211 |  |  |  | 15 | % |  |  | 205 |  |  |  | 3 | % |
| Public cloud |  |  |  | 203 |  |  |  | 184 |  |  |  | 10 | % |  |  | 118 |  |  |  | 56 | % |
| Unallocated |  |  |  | 57 |  |  |  | 60 |  |  |  | (5 | )% |  |  | 37 |  |  |  | 62 | % |

[0000950170-24-071327:mdna:82]
Hybrid Cloud

[0000950170-24-071327:mdna:83]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased  in fiscal 2024 and fiscal 2023 compared to the respective prior years reflecting the increase in Hybrid Cloud services revenues. Cost of Hybrid Cloud services revenues represented 16%, 14% and 15% of Hybrid Cloud services revenues in fiscal 2024, 2023 and 2022, respectively.

[0000950170-24-071327:mdna:84]
Hybrid Cloud support gross margins were similar in fiscal 2024, fiscal 2023 and fiscal 2022. Hybrid Cloud professional and other services gross margins decreased by approximately ten percentage points in fiscal 2024 compared to fiscal 2023 while they increased by approximately four percentage points in fiscal 2023 compared to fiscal 2022 primarily due to the mix of services provided.

[0000950170-24-071327:mdna:85]
Public Cloud

[0000950170-24-071327:mdna:86]
Cost of Public Cloud revenues increased in fiscal 2024 and in fiscal 2023 compared to the respective prior years, reflecting the increase in Public Cloud revenues in each period. Public Cloud gross margins decreased by one percentage point in fiscal 2024 and two percentage points in fiscal 2023 compared to the respective prior years primarily due to the mix of offerings provided.

[0000950170-24-071327:mdna:87]
Unallocated

[0000950170-24-071327:mdna:88]
Unallocated cost of services revenues decreased in fiscal 2024 compared to fiscal 2023 due to certain intangible assets becoming fully amortized during the first quarter of fiscal 2024. Unallocated cost of services revenues increased in fiscal 2023 compared to fiscal 2023 due to our acquisitions of Instaclustr early in the first quarter of fiscal 2023 and CloudCheckr in the third quarter of fiscal 2022, which resulted in higher amortization expense from acquired intangible assets.

[0000950170-24-071327:mdna:89]
Operating Expenses

[0000950170-24-071327:mdna:90]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0000950170-24-071327:mdna:91]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2024 totaled $3,165 million, or 50% of net revenues, representing an increase of two percentage points compared to fiscal 2023.

[0000950170-24-071327:mdna:92]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2023 totaled $3,050 million, or 48% of net revenues, relatively consistent with fiscal 2022. While fluctuations in foreign currency exchange rates adversely impacted net revenues in fiscal 2023 compared to fiscal 2022, they favorably impacted sales and marketing, research and development and general and administrative expenses by approximately 3% in fiscal 2023.

[0000950170-24-071327:mdna:93]
Compensation costs represent the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0000950170-24-071327:mdna:94]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses increased by $115 million, or 6%, during fiscal 2024 compared to fiscal 2023, primarily due to higher incentive compensation expense reflecting higher operating performance against goals. The increase was partially offset by lower salaries expense, reflecting a decrease in average headcount of 7%.

[0000950170-24-071327:mdna:95]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses increased by $101 million, or 6%, during fiscal 2023 compared to fiscal 2022, primarily due to higher salaries, benefits and stock-based compensation expense, reflecting an increase in average headcount of 8%. The increase was partially offset by lower incentive compensation expense.

[0000950170-24-071327:mdna:96]
Sales and Marketing (in millions, except percentages):

[0000950170-24-071327:mdna:97]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| Sales and marketing expenses |  |  | $ | 1,828 |  |  | $ | 1,829 |  |  |  | — | % |  | $ | 1,857 |  |  |  | (2 | )% |

[0000950170-24-071327:mdna:98]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, facilities and IT support costs, advertising and marketing promotional expense and travel and entertainment expense. The changes in sales and marketing expenses consisted of the following (in percentage points of the total change):

[0000950170-24-071327:mdna:99]
|  |  | Fiscal 2024 to Fiscal 2023 |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  | — |  |  |  | 2 |  |
| Commissions |  |  | — |  |  |  | (3 | ) |
| Advertising and marketing promotional expense |  |  | — |  |  |  | (2 | ) |
| Travel and entertainment |  |  | — |  |  |  | 1 |  |
| Total change |  |  | — |  |  |  | (2 | ) |

[0000950170-24-071327:mdna:100]
All primary components of sales and marketing expenses were relatively consistent in fiscal 2024 compared to fiscal 2023.

[0000950170-24-071327:mdna:101]
The increase in compensation costs for fiscal 2023 compared to fiscal 2022 reflected an increase in average headcount of approximately 6%. The impact of the increase in headcount was partially offset by lower incentive compensation expense and the impact of foreign exchange rate fluctuations.

[0000950170-24-071327:mdna:102]
The decrease in commissions expense for fiscal 2023 compared to fiscal 2022 was primarily due to lower performance against sales goals.

[0000950170-24-071327:mdna:103]
Advertising and marketing promotional expense decreased in fiscal 2023 compared to fiscal 2022, primarily due to lower spending on certain marketing programs.

[0000950170-24-071327:mdna:104]
Travel and entertainment expense increased in fiscal 2023 compared to fiscal 2022, as COVID-19 related travel restrictions eased.

[0000950170-24-071327:mdna:105]
Research and Development (in millions, except percentages):

[0000950170-24-071327:mdna:106]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| Research and development expenses |  |  | $ | 1,029 |  |  | $ | 956 |  |  |  | 8 | % |  | $ | 881 |  |  |  | 9 | % |

[0000950170-24-071327:mdna:107]
Research and development expenses consist primarily of compensation costs, facilities and IT support costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expenses consisted of the following (in percentage points of the total change):

[0000950170-24-071327:mdna:108]
|  |  | Fiscal 2024 to Fiscal 2023 |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  | 8 |  |  |  | 8 |  |
| Development projects and outside services |  |  | — |  |  |  | 1 |  |
| Total change |  |  | 8 |  |  |  | 9 |  |

[0000950170-24-071327:mdna:109]
The increase in compensation costs for fiscal 2024 compared to fiscal 2023 was due to higher incentive compensation expense and stock-based compensation expense, partially offset by lower salaries expense, reflecting a decrease in average headcount of 5%.

[0000950170-24-071327:mdna:110]
The increase in compensation costs for fiscal 2023 compared to fiscal 2022 was primarily attributable to an increase in average headcount of 11%. The impact of the increase in headcount was partially offset by lower incentive compensation expense and the impact of foreign exchange rate fluctuations. The increase in development projects and outside services for fiscal 2023 compared to fiscal 2022 was primarily due to the higher spending on certain engineering projects.

[0000950170-24-071327:mdna:111]
General and Administrative (in millions, except percentages):

[0000950170-24-071327:mdna:112]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| General and administrative expenses |  |  | $ | 308 |  |  | $ | 265 |  |  |  | 16 | % |  | $ | 279 |  |  |  | (5 | )% |

[0000950170-24-071327:mdna:113]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and facilities and IT support costs. Changes in general and administrative expense consisted of the following (in percentage points of the total change):

[0000950170-24-071327:mdna:114]
|  |  | Fiscal 2024 to Fiscal 2023 |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  | 14 |  |  |  | (1 | ) |
| Professional and legal fees and outside services |  |  | 1 |  |  |  | 1 |  |
| Facilities and IT support costs |  |  | — |  |  |  | (5 | ) |
| Other |  |  | 1 |  |  |  | — |  |
| Total change |  |  | 16 |  |  |  | (5 | ) |

[0000950170-24-071327:mdna:115]
The increase in compensation costs in fiscal 2024 compared to fiscal 2023 was attributable to increases in all components of compensation costs, but primarily incentive compensation expense. The increase in professional and legal fees and outside services expense in fiscal 2024 was primarily due to higher spending on certain business transformation projects.

[0000950170-24-071327:mdna:116]
The decrease in compensation costs in fiscal 2023 compared to fiscal 2022 was primarily attributable to lower incentive compensation expense, partially offset by the increase in salaries and stock-based compensation expenses. The increases in professional and legal fees and outside services expense in fiscal 2023 were primarily due to higher spending on certain business transformation projects. The decrease in facilities and IT support costs in fiscal 2023 was primarily related to lower spending for certain IT projects.

[0000950170-24-071327:mdna:117]
Restructuring Charges (in millions, except percentages):

[0000950170-24-071327:mdna:118]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| Restructuring charges |  |  | $ | 44 |  |  | $ | 120 |  |  |  | (63 | )% |  | $ | 33 |  |  |  | 264 | % |

[0000950170-24-071327:mdna:119]
In an effort to reduce our cost structure and redirect resources to our highest return activities, in fiscal 2024, 2023 and 2022, we initiated a number of business realignment plans designed to streamline our business and focus on key strategic opportunities. These plans resulted in aggregate reductions of our global workforce of approximately 2% in fiscal 2024, 9% in fiscal 2023, and 1% in fiscal 2022, and aggregate charges of $44 million, $120 million, and $33 million, respectively, consisting primarily of employee severance-related costs. Additionally, the aggregate charges for fiscal 2024 included optimization of our global office space for our hybrid work model, while the aggregate charges in fiscal 2023 and fiscal 2022 included legal and tax-related consulting fees associated with the establishment of an international headquarters in Cork, Ireland. See Note 12 – Restructuring Charges of the Notes to Consolidated Financial Statements included in Part II, Item 8 for more details regarding our restructuring plans.

[0000950170-24-071327:mdna:120]
Acquisition-related Expense (in millions, except percentages):

[0000950170-24-071327:mdna:121]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| Acquisition-related expense |  |  | $ | 10 |  |  | $ | 21 |  |  |  | (52 | )% |  | $ | 13 |  |  |  | 62 | % |

[0000950170-24-071327:mdna:122]
We incurred $10 million, $21 million and $13 million of acquisition-related expenses, primarily consisting of legal and consulting fees, in fiscal 2024, fiscal 2023 and fiscal 2022, respectively, associated with our acquisitions and subsequent integrations.

[0000950170-24-071327:mdna:123]
Other Income (Expense), Net (in millions, except percentages)

[0000950170-24-071327:mdna:124]
The components of other income (expense), net were as follows:

[0000950170-24-071327:mdna:125]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| Interest income |  |  | $ | 112 |  |  | $ | 69 |  |  |  | 62 | % |  | $ | 7 |  |  |  | 886 | % |
| Interest expense |  |  |  | (64 | ) |  |  | (67 | ) |  |  | (4 | )% |  |  | (73 | ) |  |  | (8 | )% |
| Other, net |  |  |  | 1 |  |  |  | 46 |  |  | NM |  |  |  | 4 |  |  | NM |  |
| Total |  |  | $ | 49 |  |  | $ | 48 |  |  | NM |  |  | $ | (62 | ) |  | NM |  |

[0000950170-24-071327:mdna:126]
NM - Not Meaningful

[0000950170-24-071327:mdna:127]
Interest income increased in fiscal 2024 and fiscal 2023 compared to previous years was primarily due to higher yields earned on our cash and investments.

[0000950170-24-071327:mdna:128]
Interest expense decreased in fiscal 2024 and fiscal 2023 compared to previous years due to the extinguishment of certain senior notes in the second quarter of fiscal 2023.

[0000950170-24-071327:mdna:129]
Other, net for fiscal 2023 includes $22 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. Other, net for fiscal 2023 also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million. The remaining differences in Other, net for fiscal 2024 compared to fiscal 2023, and for fiscal 2023 compared to fiscal 2022, are primarily due to differences in foreign exchange gains and losses in each fiscal year.

[0000950170-24-071327:mdna:130]
Provision (Benefit) for Income Taxes (in millions, except percentages):

[0000950170-24-071327:mdna:131]
|  |  |  | Fiscal Year |  |
|  |  |  | 2024 |  |  | 2023 |  |  | % Change |  |  | 2022 |  |  | % Change |  |
| Provision (benefit) for income taxes |  |  | $ | 277 |  |  | $ | (208 | ) |  |  | (233 | )% |  | $ | 158 |  |  |  | (232 | )% |

[0000950170-24-071327:mdna:132]
Our effective tax rate for fiscal 2024 was 21.9% compared to (19.5)% in fiscal 2023 and 14.4% in fiscal 2022. The differences in the effective tax rates between fiscal years were primarily due to fiscal 2023 benefits resulting from an intra-entity asset transfer of certain IP, partially offset by discrete tax expense recorded as a result of the Danish Supreme Court ruling received January 9, 2023.

[0000950170-24-071327:mdna:133]
During fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023. Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, earnings before interest and taxes, and a

[0000950170-24-071327:mdna:134]
44

[0000950170-24-071327:mdna:135]
discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly. Any Organisation for Economic Co-operation and Development’s (“OECD”) actions adopted internationally could impact our financial results in future periods. The impact of the transaction to net cash provided by or used in operating, investing and financing activities on the consolidated statements of cash flows during fiscal 2023 was not material.

[0000950170-24-071327:mdna:136]
During fiscal 2023, the Danish Supreme Court issued a non-appealable ruling on the distributions declared in 2005 and 2006. The Danish Supreme Court ruled the 2005 dividend was subject to at-source dividend withholding tax while the smaller 2006 distribution would not be subject to withholding tax. During fiscal 2023, we recorded $69 million of tax expense, which includes $23 million of withholding tax and $46 million of interest.

[0000950170-24-071327:mdna:137]
Liquidity, Capital Resources and Cash Requirements

[0000950170-24-071327:mdna:138]
| (In millions, except percentages) |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,252 |  |  | $ | 3,070 |  |
| Principal amount of debt |  | $ | 2,400 |  |  | $ | 2,400 |  |

[0000950170-24-071327:mdna:139]
The following is a summary of our cash flow activities:

[0000950170-24-071327:mdna:140]
|  |  | Fiscal Year |  |
| (In millions) |  | 2024 |  |  | 2023 |  |
| Net cash provided by operating activities |  | $ | 1,685 |  |  | $ | 1,107 |  |
| Net cash used in investing activities |  |  | (735 | ) |  |  | (1,390 | ) |
| Net cash used in financing activities |  |  | (1,344 | ) |  |  | (1,513 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (19 | ) |  |  | (1 | ) |
| Net change in cash, cash equivalents and restricted cash |  | $ | (413 | ) |  | $ | (1,797 | ) |

[0000950170-24-071327:mdna:141]
As of April 26, 2024, our cash, cash equivalents and short-term investments totaled $3.3 billion, reflecting an increase of $0.2 billion from April 28, 2023. The increase was primarily due to $1.7 billion of cash generated from operating activities, partially offset by $900 million used to repurchase shares of our common stock, $416 million used for the payment of dividends, and $155 million in purchases of property and equipment. Net working capital was $791 million as of April 26, 2024, a reduction of $422 million when compared to April 28, 2023, primarily due to the reclassification of $400 million principal amount of our senior notes from long-term to current liabilities.

[0000950170-24-071327:mdna:142]
Cash Flows from Operating Activities

[0000950170-24-071327:mdna:143]
During fiscal 2024, we generated cash from operating activities of $1.7 billion, reflecting net income of $1.0 billion which was increased for non-cash depreciation and amortization expense of $255 million and non-cash stock-based compensation expense of $357 million.

[0000950170-24-071327:mdna:144]
Significant changes in assets and liabilities during fiscal 2024 included the following:

[0000950170-24-071327:mdna:145]
•
Accounts payable increased by $123 million, primarily reflecting the timing of inventory purchases from, and payments to, our contract manufacturers.

[0000950170-24-071327:mdna:146]
•
Accrued expenses increased by $113 million, primarily due to higher employee compensation accruals as of the end of fiscal 2024 compared to fiscal 2023 related to incentive compensation and commissions plans.

[0000950170-24-071327:mdna:147]
During fiscal 2023, we generated cash from operating activities of $1.1 billion, reflecting net income of $1.3 billion which was reduced by $606 million for non-cash deferred tax benefits and increased for non-cash depreciation and amortization expense of $248 million and non-cash stock-based compensation expense of $312 million.

[0000950170-24-071327:mdna:148]
Significant changes in assets and liabilities during fiscal 2023 included the following:

[0000950170-24-071327:mdna:149]
•
Accounts receivable decreased $260 million, reflecting lower billing in the fourth quarter of fiscal 2023 compared to the fourth quarter of fiscal 2022.

[0000950170-24-071327:mdna:150]
45

[0000950170-24-071327:mdna:151]
•
Accounts payable decreased by $207 million, primarily reflecting lower inventory purchases, and the timing of those purchases from, and payments to, our contract manufacturers.

[0000950170-24-071327:mdna:152]
•
Accrued expenses decreased by $103 million, primarily due to employee compensation payments related to fiscal 2022 incentive compensation and commissions plans.

[0000950170-24-071327:mdna:153]
We expect that cash provided by operating activities may materially fluctuate in future periods due to a number of factors, including fluctuations in our operating results, shipping linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, and the timing and amount of compensation, income taxes and other payments.

[0000950170-24-071327:mdna:154]
Cash Flows from Investing Activities

[0000950170-24-071327:mdna:155]
During fiscal 2024, we used $580 million for the purchases of investments, net of maturities and sales, and $155 million for capital expenditures.

[0000950170-24-071327:mdna:156]
During fiscal 2023, we used $719 million for the purchases of investments, net of maturities and sales, paid $491 million, net of cash acquired, for a privately-held company and $239 million for capital expenditures. Additionally, we received proceeds of $59 million from the sale of one of our minority investments in fiscal 2023.

[0000950170-24-071327:mdna:157]
Cash Flows from Financing Activities

[0000950170-24-071327:mdna:158]
During fiscal 2024, cash flows used in financing activities totaled $1.3 billion and include $900 million for the repurchase of approximately 12 million shares of common stock, and $416 million for the payment of dividends.

[0000950170-24-071327:mdna:159]
During fiscal 2023, cash flows used in financing activities totaled $1.5 billion and include $850 million for the repurchase of approximately 13 million shares of common stock, $432 million for the payment of dividends and $250 million to redeem our Senior Notes due in December 2022.

[0000950170-24-071327:mdna:160]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash, cash equivalents and short-term investments, cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months and thereafter for the foreseeable future. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all. For further discussion of factors that could affect our cash flows and liquidity requirements, see Part I, Item 1A. Risk Factors.

[0000950170-24-071327:mdna:161]
Liquidity

[0000950170-24-071327:mdna:162]
Our principal sources of liquidity as of April 26, 2024 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-24-071327:mdna:163]
Cash, cash equivalents and short-term investments consisted of the following (in millions):

[0000950170-24-071327:mdna:164]
|  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Cash and cash equivalents |  | $ | 1,903 |  |  | $ | 2,316 |  |
| Short-term investments |  |  | 1,349 |  |  |  | 754 |  |
| Total |  | $ | 3,252 |  |  | $ | 3,070 |  |

[0000950170-24-071327:mdna:165]
As of April 26, 2024 and April 28, 2023, $2.1 billion and $2.2 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $1.2 billion and $0.9 billion, respectively, were available in the U.S.

[0000950170-24-071327:mdna:166]
46

[0000950170-24-071327:mdna:167]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies through asset purchases and/or business acquisitions, service interest and principal payments on our debt, fund our stock repurchase program, and pay dividends, as and if declared. In the ordinary course of business, we engage in periodic reviews of opportunities to invest in or acquire companies or units in companies to expand our total addressable market, leverage technological synergies and establish new streams of revenue, particularly in our Public Cloud segment.

[0000950170-24-071327:mdna:168]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of April 26, 2024.

[0000950170-24-071327:mdna:169]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. We also have an automatic shelf registration statement on file with the U.S. Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0000950170-24-071327:mdna:170]
Senior Notes

[0000950170-24-071327:mdna:171]
The following table summarizes the principal amount of our Senior Notes as of April 26, 2024 (in millions):

[0000950170-24-071327:mdna:172]
|  |  | Amount |  |
| 3.30% Senior Notes Due September 2024 |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-24-071327:mdna:173]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 8 – Financing Arrangements of the Notes to Consolidated Financial Statements included in Part II, Item 8.

[0000950170-24-071327:mdna:174]
Commercial Paper Program and Credit Facility

[0000950170-24-071327:mdna:175]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of April 26, 2024.

[0000950170-24-071327:mdna:176]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023 primarily to replace the London Interbank Offered Rate (LIBOR) with the Secured Overnight Financing Rate (SOFR) as the basis for establishing the interest rate applicable to certain borrowings under the agreement, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of April 26, 2024, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-24-071327:mdna:177]
Capital Expenditure Requirements

[0000950170-24-071327:mdna:178]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions

[0000950170-24-071327:mdna:179]
related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for fiscal 2025 to be between $150 million and $200 million.

[0000950170-24-071327:mdna:180]
Transition Tax Payments

[0000950170-24-071327:mdna:181]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of April 26, 2024, outstanding payments related to the transition tax are estimated to be approximately $215 million of which $115 million and $100 million are expected to be paid during fiscal 2025 and fiscal 2026, respectively. During fiscal 2024, transition tax payments totaled $88 million. Our estimates for future transition tax payments, however, could change with further guidance or review from U.S. federal and state tax authorities or other regulatory bodies.

[0000950170-24-071327:mdna:182]
Dividends and Stock Repurchase Program

[0000950170-24-071327:mdna:183]
On May 23, 2024, we declared a cash dividend of $0.52 per share of common stock, payable on July 24, 2024 to holders of record as of the close of business on July 5, 2024.

[0000950170-24-071327:mdna:184]
As of April 26, 2024, our Board of Directors had authorized the repurchase of up to $16.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through April 26, 2024, we repurchased a total of 372 million shares of our common stock at an average price of $42.04 per share, for an aggregate purchase price of $15.6 billion. As of April 26, 2024, the remaining authorized amount for stock repurchases under this program was $0.5 billion. On May 23, 2024 our Board of Directors authorized the repurchase of an additional $1.0 billion of our common stock.

[0000950170-24-071327:mdna:185]
Purchase Commitments

[0000950170-24-071327:mdna:186]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled $0.8 billion at April 26, 2024, of which $0.6 billion is due in fiscal 2025, with the remainder due thereafter.

[0000950170-24-071327:mdna:187]
Financing Guarantees

[0000950170-24-071327:mdna:188]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $67 million and $38 million of receivables during fiscal 2024 and 2023, respectively.

[0000950170-24-071327:mdna:189]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user.

[0000950170-24-071327:mdna:190]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of April 26, 2024 and April 28, 2023, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-24-071327:mdna:191]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of April 26, 2024, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make

[0000950170-24-071327:mdna:192]
48

[0000950170-24-071327:mdna:193]
payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0000950170-24-071327:mdna:194]
Legal Contingencies

[0000950170-24-071327:mdna:195]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 17 – Commitments and Contingencies of the Notes to Consolidated Financial Statements included in Part II, Item 8.

[0000950170-24-071327:mdna:196]
Critical Accounting Policies and Estimates

[0000950170-24-071327:mdna:197]
Our consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0000950170-24-071327:mdna:198]
The summary of significant accounting policies is included in Note 1 – Description of Business and Significant Accounting Policies of the Notes to Consolidated Financial Statements included in Part II, Item 8. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0000950170-24-071327:mdna:199]
Revenue Recognition

[0000950170-24-071327:mdna:200]
Our contracts with customers often include the transfer of multiple products and services to the customer. In determining the amount and timing of revenue recognition, we assess which products and services are distinct performance obligations and allocate the transaction price, which may include fixed and/or variable amounts, among each performance obligation on a relative standalone selling price (SSP) basis. The following are the key estimates and assumptions and corresponding uncertainties included in this approach:

[0000950170-24-071327:mdna:201]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | We evaluate whether products and services promised in our contracts with customers are distinct performance obligations that should be accounted for separately versus together. |  |  | In certain contracts, the determination of our distinct performance obligations requires significant judgment. As our business and offerings to customers change over time, the products and services we determine to be distinct performance obligations may change. Such changes may adversely impact the amount of revenue and gross margin we report in a particular period. |
|  | In determining the transaction price of our contracts, we estimate variable consideration based on the expected value, primarily relying on our history. In certain situations, we may also use the most likely amount as the basis of our estimate. |  |  | We may have insufficient relevant historical data or other information to arrive at an accurate estimate of variable consideration using either the “expected value” or “most likely amount” method. Additionally, changes in business practices, such as those related to sales returns or marketing programs, may introduce new forms of variable consideration, as well as more complexity and uncertainty in the estimation process. |
|  | In contracts with multiple performance obligations, we establish SSPs based on the price at which products and services are sold separately. If SSPs are not observable through past transactions, we estimate them by maximizing the use of observable inputs including pricing strategy, market data, internally-approved pricing guidelines related to the performance obligations and other observable inputs. |  |  | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of product and service offerings and/or changes in customer segmentation may result in a lack of consistency, making it difficult to establish and/or maintain SSPs. Changes in SSPs could result in different and unanticipated allocations of revenue in contracts with multiple performance obligations. These factors, among others, may adversely impact the amount of revenue and gross margin we report in a particular period. |

[0000950170-24-071327:mdna:202]
49

[0000950170-24-071327:mdna:203]
Inventory Valuation and Purchase Order Accruals

[0000950170-24-071327:mdna:204]
Inventories consist primarily of purchased components and finished goods and are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. A provision is recorded when inventory is determined to be in excess of anticipated demand or obsolete in order to adjust inventory to its estimated realizable value. The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our inventories:

[0000950170-24-071327:mdna:205]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | We periodically perform an excess and obsolete analysis of our inventory. Inventories are written down based on excess and obsolete reserves determined primarily on assumptions about future demand forecasts and market conditions. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. |  |  | Although we use our best estimates to forecast future product demand, any significant unanticipated changes in demand, including due to macroeconomic uncertainties, or obsolescence related to technological developments, new product introductions, customer requirements, competition or other factors could have a significant impact on the valuation of our inventory. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings that adversely impact gross margins may be required. If actual market conditions are more favorable, we may realize higher gross profits in the period when the written-down inventory is sold.We are subject to a variety of environmental laws relating to the manufacture of our products. If there are changes to the current regulations, we may be required to make product design changes which may result in excess or obsolete inventory, which could adversely impact our operating results. |
|  | We make commitments to our third-party contract manufacturers and other suppliers to manage lead times and meet product forecasts and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancelable purchase commitments when we believe it is probable that the components will not be utilized in future operations. |  |  | If the actual materials demand is significantly lower than our forecast, we may be required to increase our recorded liabilities for estimated losses on non-cancelable purchase commitments, including incremental commitments made in response to recent developments in the broader technology supply chain, which would adversely impact our operating results. |

[0000950170-24-071327:mdna:206]
Goodwill and Purchased Intangible Assets

[0000950170-24-071327:mdna:207]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair values of the assets acquired and liabilities assumed.

[0000950170-24-071327:mdna:208]
The carrying values of purchased intangible assets are reviewed whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of income.

[0000950170-24-071327:mdna:209]
We review goodwill for impairment annually and whenever events or changes in circumstances indicate the carrying amount of one of our reporting units may exceed its fair value. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. For our annual goodwill impairment test in the fourth quarter of fiscal 2024, we performed a qualitative assessment of goodwill impairment by evaluating relevant factors to determine whether it is more likely than not that the fair value of each of our reporting units is less than their carrying values. As a result of the qualitative assessment, we determined the quantitative test was not necessary and there was no impairment of goodwill.

[0000950170-24-071327:mdna:210]
50

[0000950170-24-071327:mdna:211]
The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our goodwill and purchased intangible assets:

[0000950170-24-071327:mdna:212]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets.The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  |  | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair values of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. Volatile macroeconomic and market conditions have increased the level of uncertainty and subjectivity of certain management assumptions and estimates. |
|  | Evaluations of possible goodwill and purchased intangible asset impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting units and assets. |  |  | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. Assumptions and estimates about expected future cash flows and the fair values of our reporting units and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions, and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0000950170-24-071327:mdna:213]
Income Taxes

[0000950170-24-071327:mdna:214]
We are subject to income taxes in the United States and numerous foreign jurisdictions. We compute our provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets or liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0000950170-24-071327:mdna:215]
The following are the key estimates and assumptions and corresponding uncertainties for our income taxes:

[0000950170-24-071327:mdna:216]
51

[0000950170-24-071327:mdna:217]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | Our income tax provision is based on existing tax law and advanced pricing agreements or letter rulings we have with various tax authorities. |  |  | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax agreements and rulings. |
|  | The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  |  | Our future profits could differ from current expectations resulting in a change to our determination as to the amount of deferred tax assets that are more likely than not to be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
|  | The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  |  | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |
