# NTAP note change history — 0001193125-14-325455 → 0001193125-14-425190


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-25):
[0001193125-14-425190:note_history:1]
We lease various equipment, vehicles and office space in the
 U.S. and internationally. As of October 24, 2014, future
 annual minimum lease payments under non-cancelable operating leases
 with an initial term in excess of one year totaled $206.5
 million.
  (was, 2014-08-28, similarity 0.9771):
[0001193125-14-325455:note_history:1]
We lease various equipment, vehicles and office space in the
 U.S. and internationally. As of July 25, 2014, future annual
 minimum lease payments under non-cancelable operating leases with
 an initial term in excess of one year totaled $213.6
 million.

- changed (2014-11-25):
[0001193125-14-425190:note_history:2]
In the ordinary course of business we make commitments to
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that product
 forecasts are not achieved, our commitments and associated accruals
 may change. As of October 24, 2014, we had $253.2 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product revenues. As of
 October 24, 2014 and April 25, 2014, such liability
 amounted to $8.7 million and $11.5 million, respectively, and is
 included in other current liabilities in our condensed consolidated
 balance sheets.
  (was, 2014-08-28, similarity 0.9896):
[0001193125-14-325455:note_history:2]
In the ordinary course of business we make commitments to
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that product
 forecasts are not achieved, our commitments and associated accruals
 may change. As of July 25, 2014, we had $239.3 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product revenues. As of
 July 25, 2014 and April 25, 2014, such liability amounted
 to $10.4 million and $11.5 million, respectively, and is included
 in other current liabilities in our condensed consolidated balance
 sheets.

- changed (2014-11-25):
[0001193125-14-425190:note_history:3]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course of business for
 which we have not received goods or services. As of
 October 24, 2014, we had $73.3 million in capital purchase
 commitments and $197.0 million in other purchase
 commitments.
  (was, 2014-08-28, similarity 0.9841):
[0001193125-14-325455:note_history:3]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course of business for
 which we have not received goods or services. As of July 25,
 2014, we had $36.4 million in capital purchase commitments and
 $180.2 million in other purchase commitments.

- changed (2014-11-25):
[0001193125-14-425190:note_history:4]
We generally provide customers a warranty on software of ninety
 days and a warranty on hardware of three years. The following
 tables summarize the activity related to product warranty
 liabilities and their balances as reported in our condensed
 consolidated balance sheets (in millions):
  (was, 2014-08-28, similarity 0.8427):
[0001193125-14-325455:note_history:4]
We generally provide customers a warranty on software of ninety
 days and a warranty on hardware of three years. The following table
 summarizes the activity related to product warranty liabilities (in
 millions):

- added (2014-11-25):
[0001193125-14-425190:note_history:5]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Balance at beginning of period |  | $ | 104.1 |  |  | $ | 119.8 |  |  | $ | 110.0 |  |  | $ | 117.2 |  |
| Expense accrued during the period |  |  | 8.3 |  |  |  | 14.3 |  |  |  | 18.8 |  |  |  | 38.3 |  |
| Warranty costs incurred |  |  | (15.8 | ) |  |  | (18.1 | ) |  |  | (32.2 | ) |  |  | (39.5 | ) |
| Balance at end of period |  | $ | 96.6 |  |  | $ | 116.0 |  |  | $ | 96.6 |  |  | $ | 116.0 |  |

- added (2014-11-25):
[0001193125-14-425190:note_history:6]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Other current liabilities |  | $ | 64.2 |  |  | $ | 73.0 |  |
| Other long-term liabilities |  |  | 32.4 |  |  |  | 37.0 |  |
| Total |  | $ | 96.6 |  |  | $ | 110.0 |  |

- added (2014-11-25):
[0001193125-14-425190:note_history:7]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Maximum guaranteed payment contingencies |  | $ | 214.1 |  |  | $ | 205.8 |  |
| Deferred revenue associated with financing guarantees |  |  | (197.4 | ) |  |  | (193.1 | ) |
| Net amount |  | $ | 16.7 |  |  | $ | 12.7 |  |

- changed (2014-11-25):
[0001193125-14-425190:note_history:8]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of October 24, 2014 related to such matters as
 they are not probable and/or reasonably estimable.
  (was, 2014-08-28, similarity 0.9753):
[0001193125-14-325455:note_history:8]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of July 25, 2014 related to such matters as they
 are not probable and/or reasonably estimable.

- removed (2014-11-25):
[0001193125-14-325455:note_history:9]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Balance at beginning of period |  | $ | 110.0 |  |  | $ | 117.2 |  |
| Expense accrued during the period |  |  | 10.5 |  |  |  | 24.0 |  |
| Warranty costs incurred |  |  | (16.4 | ) |  |  | (21.4 | ) |
| Balance at end of period |  | $ | 104.1 |  |  | $ | 119.8 |  |
| Product warranty liabilities were reported in our condensed consolidated balance sheets as follows (in millions): |  |
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Other current liabilities |  | $ | 68.8 |  |  | $ | 73.0 |  |
| Other long-term liabilities |  |  | 35.3 |  |  |  | 37.0 |  |
| Total |  | $ | 104.1 |  |  | $ | 110.0 |  |

- removed (2014-11-25):
[0001193125-14-325455:note_history:10]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Maximum guaranteed payment contingencies |  | $ | 213.2 |  |  | $ | 205.8 |  |
| Deferred revenue associated with financing guarantees |  |  | (196.8 | ) |  |  | (193.1 | ) |
| Net amount |  | $ | 16.4 |  |  | $ | 12.7 |  |


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-25):
[0001193125-14-425190:note_history:11]
|  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Balance at beginning of period |  | $ | 235.9 |  |  | $ | 189.6 |  |
| Additions based on tax positions related to the current year |  |  | 12.7 |  |  |  | 13.6 |  |
| Additions for tax positions of prior years |  |  | 98.8 |  |  |  | 1.0 |  |
| Decreases for tax positions of prior years |  |  | (18.6 | ) |  |  | (4.4 | ) |
| Settlements |  |  | (54.3 | ) |  |  | 0.0 |  |
| Balance at end of period |  | $ | 274.5 |  |  | $ | 199.8 |  |
  (was, 2014-08-28, similarity 0.9409):
[0001193125-14-325455:note_history:11]
|  |  | Three Months Ended |  |
|  |  | July 25, 2014 |  |  | July 26, 2013 |  |
| Balance at beginning of period |  | $ | 235.9 |  |  | $ | 189.6 |  |
| Additions based on tax positions related to the current year |  |  | 6.8 |  |  |  | 7.2 |  |
| Additions for tax positions of prior years |  |  | 98.7 |  |  |  | 1.0 |  |
| Decreases for tax positions of prior years |  |  | (18.6 | ) |  |  | (3.5 | ) |
| Settlements |  |  | (45.5 | ) |  |  | 0.0 |  |
| Balance at end of period |  | $ | 277.3 |  |  | $ | 194.3 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-25):
[0001193125-14-425190:note_history:12]
Our fiscal year is reported on a 52- or 53-week year ending on
 the last Friday in April. Each quarter of fiscal 2015 and 2014 is a
 13-week period.
  (was, 2014-08-28, similarity 0.9231):
[0001193125-14-325455:note_history:12]
Our
 fiscal year is reported on a 52- or 53-week year ending on the last
 Friday in April. The first quarters of fiscal 2015 and 2014 were
 each 13-week periods.

- changed (2014-11-25):
[0001193125-14-425190:note_history:13]
The accompanying unaudited condensed consolidated financial
 statements have been prepared by the Company, and reflect all
 adjustments, consisting only of normal recurring adjustments, that
 are, in the opinion of management, necessary for the fair
 presentation of our financial position, results of operations,
 comprehensive income and cash flows for the interim periods
 presented. The statements have been prepared in accordance with
 accounting principles generally accepted in the United States of
 America (GAAP) for interim financial information and in accordance
 with the instructions to Form 10-Q and Rule 10-01 of Regulation
 S-X. Accordingly, these statements do not include all information
 and footnotes required by GAAP for annual consolidated financial
 statements, and should be read in conjunction with our audited
 consolidated financial statements as of and for the fiscal year
 ended April 25, 2014 contained in our Annual Report on Form
 10-K filed with the Securities and Exchange Commission on
 June 17, 2014. The results of operations for the three and six
 months ended October 24, 2014 are not necessarily indicative
 of the operating results to be expected for the full fiscal year or
 future operating periods.
  (was, 2014-08-28, similarity 0.9019):
[0001193125-14-325455:note_history:13]
The
 accompanying unaudited condensed consolidated financial statements
 have been prepared by the Company, and reflect all adjustments,
 consisting only of normal recurring adjustments, that are, in the
 opinion of management, necessary for the fair presentation of our
 financial position, results of operations, comprehensive income and
 cash flows for the interim periods presented. The statements have
 been prepared in accordance with accounting principles generally
 accepted in the United States of America (GAAP) for interim
 financial information and in accordance with the instructions to
 Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these
 statements do not include all information and footnotes required by
 GAAP for annual consolidated financial statements, and should be
 read in conjunction with our audited consolidated financial
 statements as of and for the fiscal year ended April 25, 2014
 contained in our Annual Report on Form 10-K filed with the
 Securities and Exchange Commission on June 17, 2014. The
 results of operations for the three months ended July 25, 2014
 are not necessarily indicative of the operating results to be
 expected for the full fiscal year or future operating
 periods.

- changed (2014-11-25):
[0001193125-14-425190:note_history:14]
There have been no significant changes in our significant
 accounting policies as of and for the six months ended
 October 24, 2014, as compared to the significant accounting
 policies described in our Annual Report on Form 10-K for the fiscal
 year ended April 25, 2014.
  (was, 2014-08-28, similarity 0.9625):
[0001193125-14-325455:note_history:14]
There
 have been no significant changes in our significant accounting
 policies as of and for the three months ended July 25, 2014,
 as compared to the significant accounting policies described in our
 Annual Report on Form 10-K for the fiscal year ended April 25,
 2014.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-25):
[0001193125-14-425190:note_history:15]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.6 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,494.4 |  |  |  |  |  |  | $ | 995.5 |  |  |  |  |  |
  (was, 2014-08-28, similarity 0.9898):
[0001193125-14-325455:note_history:15]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.9 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,494.1 |  |  |  |  |  |  | $ | 995.5 |  |  |  |  |  |

- changed (2014-11-25):
[0001193125-14-425190:note_history:16]
We may redeem the Senior Notes in whole or in part at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of October 24,
 2014, we were in compliance with all covenants associated with the
 Senior Notes.
  (was, 2014-08-28, similarity 0.9923):
[0001193125-14-325455:note_history:16]
We may redeem the Senior Notes in whole or in part at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of July 25, 2014,
 we were in compliance with all covenants associated with the Senior
 Notes.

- changed (2014-11-25):
[0001193125-14-425190:note_history:17]
As of October 24, 2014, our aggregate future principal
 debt maturities are as follows (in millions):
  (was, 2014-08-28, similarity 0.9405):
[0001193125-14-325455:note_history:17]
As of July 25, 2014, our aggregate future principal debt
 maturities are as follows (in millions):

- changed (2014-11-25):
[0001193125-14-425190:note_history:18]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility contains financial covenants requiring us to maintain a
 maximum leverage ratio of not more than 3.0:1.0 and a minimum
 interest coverage ratio of not less than 3.5:1.0. The facility
 contains customary affirmative and negative covenants, including
 covenants that limit our ability to incur debt secured by liens on
 assets or indebtedness of our subsidiaries and to consolidate,
 merge or sell all or substantially all of our assets. As of
 October 24, 2014, no borrowings were outstanding under the
 facility and we were in compliance with all covenants associated
 with the facility.
  (was, 2014-08-28, similarity 0.9949):
[0001193125-14-325455:note_history:18]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility contains financial covenants requiring us to maintain a
 maximum leverage ratio of not more than 3.0:1.0 and a minimum
 interest coverage ratio of not less than 3.5:1.0. The facility
 contains customary affirmative and negative covenants, including
 covenants that limit our ability to incur debt secured by liens on
 assets or indebtedness of our subsidiaries and to consolidate,
 merge or sell all or substantially all of our assets. As of
 July 25, 2014, no borrowings were outstanding under the
 facility and we were in compliance with all covenants associated
 with the facility.

- changed (2014-11-25):
[0001193125-14-425190:note_history:19]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 21.8 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (9.5 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 12.3 |  |  | $ | 6.5 |  |
  (was, 2014-08-28, similarity 0.9775):
[0001193125-14-325455:note_history:19]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 14.3 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (7.1 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 7.2 |  |  | $ | 6.5 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-25):
[0001193125-14-425190:note_history:20]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 21.8 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (9.5 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 12.3 |  |  | $ | 6.5 |  |
  (was, 2014-08-28, similarity 0.9775):
[0001193125-14-325455:note_history:20]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 14.3 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (7.1 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 7.2 |  |  | $ | 6.5 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-25):
[0001193125-14-425190:note_history:21]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.6 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,494.4 |  |  |  |  |  |  | $ | 995.5 |  |  |  |  |  |
  (was, 2014-08-28, similarity 0.9898):
[0001193125-14-325455:note_history:21]
|  |  | July 25, 2014 |  |  | April 25, 2014 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.9 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,494.1 |  |  |  |  |  |  | $ | 995.5 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-25):
[0001193125-14-425190:note_history:22]
As of October 24, 2014, our aggregate future principal
 debt maturities are as follows (in millions):
  (was, 2014-08-28, similarity 0.9405):
[0001193125-14-325455:note_history:22]
As of July 25, 2014, our aggregate future principal debt
 maturities are as follows (in millions):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2014-11-25):
[0001193125-14-425190:note_history:23]
15.  Subsequent Event

- added (2014-11-25):
[0001193125-14-425190:note_history:24]
On October 27, 2014, we completed the acquisition of
 Riverbed Technology, Inc.’s SteelStore product line for
 approximately $80.0 million in cash. The SteelStore product line
 supports leading backup applications and cloud providers so that
 customers have a choice in how they extend their existing data
 protection infrastructure into the cloud. We are in the process of
 completing the purchase price allocation for this acquisition. Pro
 forma results of operations have not been presented because the
 acquisition was not material to our results of
 operations.
