# NTAP 8-K — 0001102624-14-001857 filed 2014-11-12

## item codes, every 8-K on or before 2014-11-25

- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2014-11-25

- none on or before 2014-11-25

## item 2.02 — earnings release, exhibit 99.1

[0001102624-14-001857:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-14-001857:8k_2_02:2]
exh99_1.htm

[0001102624-14-001857:8k_2_02:3]
Exhibit 99.1

[0001102624-14-001857:8k_2_02:4]
|  | Press Contact: | Investor Contact: |
|  | Meghan Fintland | Kris Newton |
|  | NetApp | NetApp |
|  | 408-822-1389 | 408-822-3312 |
|  | Meghan.Fintland@netapp.com | Kris.Newton@netapp.com |

[0001102624-14-001857:8k_2_02:5]
NETAPP REPORTS SECOND QUARTER FISCAL YEAR 2015 RESULTS

[0001102624-14-001857:8k_2_02:6]
Net Revenues of $1.54 Billion; Non-GAAP EPS of $0.70

[0001102624-14-001857:8k_2_02:7]
| · | Clustered Data ONTAP® nodes shipped more than tripled year-over-year |

[0001102624-14-001857:8k_2_02:8]
| · | Flash capacity shipped more than doubled year-over-year |

[0001102624-14-001857:8k_2_02:9]
| · | $652 million returned to shareholders in share repurchases and cash dividends |

[0001102624-14-001857:8k_2_02:10]
Sunnyvale, Calif.—November 12, 2014—NetApp (NASDAQ: NTAP) today reported financial results for the second quarter of fiscal year 2015, ended October 24, 2014.

[0001102624-14-001857:8k_2_02:11]
Second Quarter Financial Results

[0001102624-14-001857:8k_2_02:12]
Net revenues for the second quarter of fiscal year 2015 were $1.54 billion. GAAP net income for the second quarter of fiscal year 2015 was $160 million, or $0.49 per share,1 compared to GAAP net income of $167 million, or $0.48 per share, for the comparable period of the prior year. Non-GAAP net income for the second quarter of fiscal year 2015 was $226 million, or $0.70 per share,2 compared to non-GAAP net income of $232 million, or $0.66 per share, for the comparable period of the prior year.

[0001102624-14-001857:8k_2_02:13]
Cash, Cash Equivalents and Investments

[0001102624-14-001857:8k_2_02:14]
NetApp ended the second quarter of fiscal year 2015 with $5.27 billion of total cash, cash equivalents and investments and during the quarter generated $381 million in cash from operations. The company returned $652 million to shareholders during the quarter through share repurchases and a cash dividend. The next dividend in the amount of $0.165 per share will be paid on January 22, 2015, to shareholders of record as of the close of business on January 9, 2015.

[0001102624-14-001857:8k_2_02:15]
“We are pleased with our performance in the second quarter with revenue and non-GAAP EPS coming in above the mid-point of our guidance range,” said Tom Georgens, chairman and CEO. “We have dramatically expanded the NetApp portfolio at an unprecedented pace. Our best of breed solutions not only solve the challenges enterprises face today, but ensure a seamless path to the hybrid cloud that enables customers to effectively manage their data across multiple cloud resources.”

[0001102624-14-001857:8k_2_02:16]
6

[0001102624-14-001857:8k_2_02:17]
Q3 Fiscal Year 2015 Outlook

[0001102624-14-001857:8k_2_02:18]
The Company provided the following financial guidance for the third quarter of fiscal year 2015:

[0001102624-14-001857:8k_2_02:19]
| · | Net revenues are expected to be in the range of $1.56 billion to $1.66 billion |

[0001102624-14-001857:8k_2_02:20]
| · | GAAP earnings per share is expected to be in the range of $0.52 to $0.57 per share |

[0001102624-14-001857:8k_2_02:21]
| · | Non-GAAP earnings per share is expected to be in the range of $0.74 to $0.79 per share |

[0001102624-14-001857:8k_2_02:22]
Business Highlights

[0001102624-14-001857:8k_2_02:23]
| · | NetApp® Delivers New Products: |

[0001102624-14-001857:8k_2_02:24]
|  | - | First Shipments of FlashRay Systems. FlashRay™, the purpose-built all-flash storage array, is now shipping with the NetApp Mars™ operating system which improves the performance, efficiency and manageability of all-flash storage architectures used in enterprise application environments. |

[0001102624-14-001857:8k_2_02:25]
|  | - | Object Storage for the Hybrid Cloud. StorageGRID® Webscale object storage software helps organizations leverage the hybrid cloud and manage massive data-sets with reduced cost and secure data management. |

[0001102624-14-001857:8k_2_02:26]
|  | - | Software Defined Storage Accelerates and Improves Cloud Performance. New OnCommand® software enables improved monitoring of data center trends across environments. Flash-optimized FlexPod with VMware Horizon View for end-user computing helps reduce implementation risk and accelerate desktop deployments with a validated architecture. |

[0001102624-14-001857:8k_2_02:27]
| · | NetApp Strengthens Partnerships: |

[0001102624-14-001857:8k_2_02:28]
|  | - | Extends Alignment with VMware. NetApp and VMware continue their commitment to work together to accelerate hybrid cloud deployment and enables customers to better manage data across any cloud. |

[0001102624-14-001857:8k_2_02:29]
| · | NetApp Recognition and Awards: |

[0001102624-14-001857:8k_2_02:30]
|  | - | #3 World’s Best Multinational Workplace. Innovation and teamwork give NetApp a competitive differentiator that enables the company to meet customers’ most challenging storage and data management needs. |

[0001102624-14-001857:8k_2_02:31]
|  | - | Best of Show for Flash Innovation. NetApp was awarded Best of Show Most Innovative Flash Memory Customer Implementation for its EF-Series all-flash-array deployment at Diamond Light Source. NetApp was also selected by IT pros in the annual SSD survey as the Market Leader favorite for all-flash NAS SSD. |

[0001102624-14-001857:8k_2_02:32]
Webcast and Conference Call Information

[0001102624-14-001857:8k_2_02:33]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001102624-14-001857:8k_2_02:34]
7

[0001102624-14-001857:8k_2_02:35]
About NetApp

[0001102624-14-001857:8k_2_02:36]
Leading organizations worldwide count on NetApp for software, systems and services to manage and store their data. Customers value our teamwork, expertise and passion for helping them succeed now and into the future.

[0001102624-14-001857:8k_2_02:37]
###

[0001102624-14-001857:8k_2_02:38]
NetApp, the NetApp logo, Data ONTAP, FlashRay, FlexPod, Mars, OnCommand and StorageGRID are trademarks or registered trademarks of NetApp, Inc. in the United States and/or other countries. All other marks are the property of their respective owners.

[0001102624-14-001857:8k_2_02:39]
1GAAP earnings per share is calculated using the diluted number of shares for all periods presented.

[0001102624-14-001857:8k_2_02:40]
2Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Effective the first quarter of fiscal 2015, the non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of share for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com.

[0001102624-14-001857:8k_2_02:41]
8

[0001102624-14-001857:8k_2_02:42]
NetApp Usage of Non-GAAP Financials

[0001102624-14-001857:8k_2_02:43]
The Company refers to the non-GAAP financial measures in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Effective the first quarter of fiscal 2015, the non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future.

[0001102624-14-001857:8k_2_02:44]
We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has limitations and they should not solely be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we provide both non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-14-001857:8k_2_02:45]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation.

[0001102624-14-001857:8k_2_02:46]
9

[0001102624-14-001857:8k_2_02:47]
| NETAPP, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,269.4 |  |  | $ | 5,003.3 |  |
| Accounts receivable, net |  |  | 632.7 |  |  |  | 855.9 |  |
| Inventories |  |  | 107.6 |  |  |  | 122.4 |  |
| Other current assets |  |  | 479.4 |  |  |  | 489.7 |  |
| Total current assets |  |  | 6,489.1 |  |  |  | 6,471.3 |  |
| Property and equipment, net |  |  | 1,081.7 |  |  |  | 1,108.8 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,080.6 |  |  |  | 1,109.6 |  |
| Other non-current assets |  |  | 526.1 |  |  |  | 529.5 |  |
| Total assets |  | $ | 9,177.5 |  |  | $ | 9,219.2 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 210.3 |  |  | $ | 247.0 |  |
| Accrued compensation and other current liabilities |  |  | 648.6 |  |  |  | 793.8 |  |
| Short-term deferred revenue |  |  | 1,632.1 |  |  |  | 1,653.8 |  |
| Total current liabilities |  |  | 2,491.0 |  |  |  | 2,694.6 |  |
| Long-term debt |  |  | 1,494.4 |  |  |  | 995.5 |  |
| Other long-term liabilities |  |  | 315.9 |  |  |  | 296.2 |  |
| Long-term deferred revenue |  |  | 1,414.9 |  |  |  | 1,446.4 |  |
| Total liabilities |  |  | 5,716.2 |  |  |  | 5,432.7 |  |
| Stockholders' equity |  |  | 3,461.3 |  |  |  | 3,786.5 |  |
| Total liabilities and stockholders' equity |  | $ | 9,177.5 |  |  | $ | 9,219.2 |  |

[0001102624-14-001857:8k_2_02:48]
10

[0001102624-14-001857:8k_2_02:49]
| NETAPP, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In millions, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 929.1 |  |  | $ | 955.3 |  |  | $ | 1,811.7 |  |  | $ | 1,886.1 |  |
| Software entitlements and maintenance |  |  | 224.2 |  |  |  | 231.8 |  |  |  | 445.5 |  |  |  | 460.3 |  |
| Service |  |  | 389.2 |  |  |  | 362.8 |  |  |  | 774.5 |  |  |  | 719.7 |  |
| Net revenues |  |  | 1,542.5 |  |  |  | 1,549.9 |  |  |  | 3,031.7 |  |  |  | 3,066.1 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 401.8 |  |  |  | 423.3 |  |  |  | 796.0 |  |  |  | 873.2 |  |
| Cost of software entitlements and maintenance |  |  | 8.6 |  |  |  | 7.5 |  |  |  | 16.8 |  |  |  | 15.0 |  |
| Cost of service |  |  | 149.6 |  |  |  | 153.9 |  |  |  | 298.3 |  |  |  | 303.1 |  |
| Total cost of revenues |  |  | 560.0 |  |  |  | 584.7 |  |  |  | 1,111.1 |  |  |  | 1,191.3 |  |
| Gross profit |  |  | 982.5 |  |  |  | 965.2 |  |  |  | 1,920.6 |  |  |  | 1,874.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 488.0 |  |  |  | 479.5 |  |  |  | 968.2 |  |  |  | 947.3 |  |
| Research and development |  |  | 229.0 |  |  |  | 228.2 |  |  |  | 457.0 |  |  |  | 456.3 |  |
| General and administrative |  |  | 73.0 |  |  |  | 69.5 |  |  |  | 143.0 |  |  |  | 137.9 |  |
| Restructuring and other charges |  |  | - |  |  |  | 1.1 |  |  |  | - |  |  |  | 49.5 |  |
| Total operating expenses |  |  | 790.0 |  |  |  | 778.3 |  |  |  | 1,568.2 |  |  |  | 1,591.0 |  |
| Income from operations |  |  | 192.5 |  |  |  | 186.9 |  |  |  | 352.4 |  |  |  | 283.8 |  |
| Other income/(expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 8.1 |  |  |  | 8.5 |  |  |  | 16.4 |  |  |  | 18.5 |  |
| Interest expense |  |  | (10.9 | ) |  |  | (6.5 | ) |  |  | (19.9 | ) |  |  | (23.0 | ) |
| Other income (expense), net |  |  | (0.8 | ) |  |  | 3.3 |  |  |  | (0.3 | ) |  |  | 5.2 |  |
| Total other income/(expense), net |  |  | (3.6 | ) |  |  | 5.3 |  |  |  | (3.8 | ) |  |  | 0.7 |  |
| Income before income taxes |  |  | 188.9 |  |  |  | 192.2 |  |  |  | 348.6 |  |  |  | 284.5 |  |
| Provision for income taxes |  |  | 29.1 |  |  |  | 25.4 |  |  |  | 100.4 |  |  |  | 36.1 |  |
| Net income |  | $ | 159.8 |  |  | $ | 166.8 |  |  | $ | 248.2 |  |  | $ | 248.4 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | 0.49 |  |  | $ | 0.77 |  |  | $ | 0.72 |  |
| Diluted |  | $ | 0.49 |  |  | $ | 0.48 |  |  | $ | 0.76 |  |  | $ | 0.70 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 318.1 |  |  |  | 340.7 |  |  |  | 320.8 |  |  |  | 345.8 |  |
| Diluted |  |  | 323.5 |  |  |  | 349.1 |  |  |  | 326.3 |  |  |  | 354.5 |  |
| Cash dividends declared per share |  | $ | 0.165 |  |  | $ | 0.150 |  |  | $ | 0.330 |  |  | $ | 0.300 |  |

[0001102624-14-001857:8k_2_02:50]
11

[0001102624-14-001857:8k_2_02:51]
| NETAPP, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (In millions) |
| (Unaudited) |

[0001102624-14-001857:8k_2_02:52]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 159.8 |  |  | $ | 166.8 |  |  | $ | 248.2 |  |  | $ | 248.4 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 77.6 |  |  |  | 82.5 |  |  |  | 155.1 |  |  |  | 168.4 |  |
| Stock-based compensation |  |  | 67.8 |  |  |  | 67.6 |  |  |  | 130.1 |  |  |  | 133.9 |  |
| Excess tax benefit from stock-based compensation |  |  | (6.8 | ) |  |  | (9.4 | ) |  |  | (49.4 | ) |  |  | (9.5 | ) |
| Other, net |  |  | 4.2 |  |  |  | 11.1 |  |  |  | 49.9 |  |  |  | (16.1 | ) |
| Changes in assets and liabilities, net of acquired businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (49.1 | ) |  |  | (55.9 | ) |  |  | 222.4 |  |  |  | 209.3 |  |
| Inventories |  |  | (3.2 | ) |  |  | 0.7 |  |  |  | 14.9 |  |  |  | 23.6 |  |
| Accounts payable |  |  | 30.2 |  |  |  | (2.9 | ) |  |  | (32.1 | ) |  |  | (40.8 | ) |
| Accrued compensation and other current liabilities |  |  | 90.6 |  |  |  | 73.0 |  |  |  | (136.5 | ) |  |  | (102.4 | ) |
| Deferred revenue |  |  | (18.3 | ) |  |  | (13.3 | ) |  |  | (44.8 | ) |  |  | (67.6 | ) |
| Changes in other operating assets and liabilities, net |  |  | 28.6 |  |  |  | 42.3 |  |  |  | 39.1 |  |  |  | 101.1 |  |
| Net cash provided by operating activities |  |  | 381.4 |  |  |  | 362.5 |  |  |  | 596.9 |  |  |  | 648.3 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 169.9 |  |  |  | 282.1 |  |  |  | 361.1 |  |  |  | 672.1 |  |
| Purchases of property and equipment |  |  | (51.1 | ) |  |  | (42.2 | ) |  |  | (109.5 | ) |  |  | (107.5 | ) |
| Other investing activities, net |  |  | (1.1 | ) |  |  | 2.2 |  |  |  | (0.9 | ) |  |  | 3.4 |  |
| Net cash provided by investing activities |  |  | 117.7 |  |  |  | 242.1 |  |  |  | 250.7 |  |  |  | 568.0 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 42.8 |  |  |  | 52.4 |  |  |  | 71.2 |  |  |  | 123.9 |  |
| Repurchase of common stock and forward contract |  |  | (600.0 | ) |  |  | (150.5 | ) |  |  | (718.9 | ) |  |  | (1,000.0 | ) |
| Excess tax benefit from stock-based compensation |  |  | 6.8 |  |  |  | 9.4 |  |  |  | 49.4 |  |  |  | 9.5 |  |
| Repayment of debt |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,264.9 | ) |
| Issuance of long-term debt, net |  |  | - |  |  |  | - |  |  |  | 494.7 |  |  |  | - |  |
| Dividends paid |  |  | (52.1 | ) |  |  | (51.3 | ) |  |  | (105.5 | ) |  |  | (102.7 | ) |
| Other financing activities, net |  |  | (1.7 | ) |  |  | (15.2 | ) |  |  | (3.5 | ) |  |  | (5.7 | ) |
| Net cash used in financing activities |  |  | (604.2 | ) |  |  | (155.2 | ) |  |  | (212.6 | ) |  |  | (2,239.9 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (21.3 | ) |  |  | 14.3 |  |  |  | (20.8 | ) |  |  | 7.0 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | (126.4 | ) |  |  | 463.7 |  |  |  | 614.2 |  |  |  | (1,016.6 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 3,031.6 |  |  |  | 1,796.8 |  |  |  | 2,291.0 |  |  |  | 3,277.1 |  |
| End of period |  | $ | 2,905.2 |  |  | $ | 2,260.5 |  |  | $ | 2,905.2 |  |  | $ | 2,260.5 |  |

[0001102624-14-001857:8k_2_02:53]
12

[0001102624-14-001857:8k_2_02:54]
| NETAPP, INC. |
| SUPPLEMENTAL DATA |
| (In millions except net income per share, percentages, DSO and Inventory Turns) |
| (Unaudited) |
|  |  | Q2 FY’15 |  |  | Q1 FY’15 |  |  |  | Q2 FY’14 |  |
| Revenues |  |  |  |  |  |  |  |  |  |
| Product Revenue |  | $ | 929.1 |  |  | $ | 882.6 |  |  | $ | 955.3 |  |
| Software Entitlements & Maintenance Revenue (SEM) |  |  | 224.2 |  |  |  | 221.3 |  |  |  | 231.8 |  |
| Service Revenue: |  |  | 389.2 |  |  |  | 385.3 |  |  |  | 362.8 |  |
| Hardware Maintenance Support Contracts Revenue |  |  | 311.0 |  |  |  | 302.8 |  |  |  | 276.4 |  |
| Professional & Other Services Revenue |  |  | 78.2 |  |  |  | 82.5 |  |  |  | 86.4 |  |
| Net Revenues |  | $ | 1,542.5 |  |  | $ | 1,489.2 |  |  | $ | 1,549.9 |  |
| Branded and OEM Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY’15 |  |  | Q1 FY’15 |  |  |  | Q2 FY’14 |  |
| Branded Revenue |  | $ | 1,423.9 |  |  | $ | 1,360.5 |  |  | $ | 1,398.8 |  |
| OEM Revenue |  |  | 118.6 |  |  |  | 128.7 |  |  |  | 151.1 |  |
| Net Revenues |  | $ | 1,542.5 |  |  | $ | 1,489.2 |  |  | $ | 1,549.9 |  |
| Branded revenue includes revenue from all products and services sold directly by us or our partners under the NetApp brand, including NetApp branded E-Series products and solutions. |
| OEM revenue comprises revenue from the sale of our products by other companies under their brands and includes revenue from IBM, Fujitsu, and other E-Series OEM relationships. |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'15 Revenue |  |  | % of Q1 FY'15 Revenue |  |  |  | % of Q2 FY’14 Revenue |  |
| Americas |  |  | 59 | % |  |  | 56 | % |  |  | 58 | % |
| Americas Commercial |  |  | 42 | % |  |  | 44 | % |  |  | 42 | % |
| U.S. Public Sector |  |  | 17 | % |  |  | 12 | % |  |  | 16 | % |
| EMEA |  |  | 28 | % |  |  | 30 | % |  |  | 29 | % |
| Asia Pacific |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'15 Revenue |  |  | % of Q1 FY'15 Revenue |  |  |  | % of Q2 FY’14 Revenue |  |
| Direct |  |  | 20 | % |  |  | 21 | % |  |  | 17 | % |
| Indirect |  |  | 80 | % |  |  | 79 | % |  |  | 83 | % |
| Direct revenue are those sold through our direct sales force. Indirect revenues include those sold through value-added resellers, system integrators, OEMs and distributors. |
| Indirect revenue reflects order fulfillment and is not reflective of who is responsible for the customer relationship. |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY’15 |  |  | Q1 FY’15 |  |  |  | Q2 FY’14 |  |
| Non-GAAP Gross Margin |  |  | 65.0 | % |  |  | 64.3 | % |  |  | 63.6 | % |
| Product |  |  | 58.4 | % |  |  | 57.1 | % |  |  | 57.3 | % |
| Software Entitlements & Maintenance (SEM) |  |  | 96.2 | % |  |  | 96.3 | % |  |  | 96.8 | % |
| Service |  |  | 62.7 | % |  |  | 62.7 | % |  |  | 58.9 | % |

[0001102624-14-001857:8k_2_02:55]
13

[0001102624-14-001857:8k_2_02:56]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |
|  |  | Q2 FY’15 |  |  | Q1 FY’15 |  |  |  | Q2 FY’14 |  |
| Non-GAAP Income from Operations |  | $ | 274.8 |  |  | $ | 236.7 |  |  | $ | 270.5 |  |
| % of Net Revenue |  |  | 17.8 | % |  |  | 15.9 | % |  |  | 17.5 | % |
| Non-GAAP Income before Income Taxes |  | $ | 271.2 |  |  | $ | 236.5 |  |  | $ | 275.8 |  |
| Non-GAAP Effective Tax Rate |  |  | 16.5 | % |  |  | 16.5 | % |  |  | 16.1 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY’15 |  |  | Q1 FY’15 |  |  |  | Q2 FY’14 |  |
| Non-GAAP Net Income |  | $ | 226.4 |  |  | $ | 197.5 |  |  | $ | 231.5 |  |
| Weighted Average Common Shares Outstanding, Diluted |  |  | 323.5 |  |  |  | 329.1 |  |  |  | 349.1 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.70 |  |  | $ | 0.60 |  |  | $ | 0.66 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY’15 |  |  | Q1 FY’15 |  |  |  | Q2 FY’14 |  |
| Deferred Revenue |  | $ | 3,047.0 |  |  | $ | 3,076.3 |  |  | $ | 2,931.9 |  |
| DSO (days) |  |  | 37 |  |  |  | 36 |  |  |  | 35 |  |
| Inventory Turns |  |  | 20 |  |  |  | 20 |  |  |  | 20 |  |
| Days sales outstanding (DSO) is defined as accounts receivable, net divided by net revenues, multiplied by the number of days in the quarter. |
| Inventory turns is defined as annualized non-GAAP cost of revenues divided by net inventories. |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY’15 |  |  | Q1 FY’15 |  |  |  | Q2 FY’14 |  |
| Net Cash Provided by Operating Activities |  | $ | 381.4 |  |  | $ | 215.5 |  |  | $ | 362.5 |  |
| Purchases of Property and Equipment |  | $ | 51.1 |  |  | $ | 58.4 |  |  | $ | 42.2 |  |
| Free Cash Flow |  | $ | 330.3 |  |  | $ | 157.1 |  |  | $ | 320.3 |  |
| Free Cash Flow as % of Total Revenue |  |  | 21.4 | % |  |  | 10.5 | % |  |  | 20.7 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |

[0001102624-14-001857:8k_2_02:57]
14

[0001102624-14-001857:8k_2_02:58]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP TO GAAP |
| INCOME STATEMENT INFORMATION |
| (In millions, except net income per share amounts) |
|  |  | Q2'FY15 |  |  | Q1'FY15 |  |  | Q2'FY14 |  |
| NET INCOME |  | $ | 159.8 |  |  | $ | 88.4 |  |  | $ | 166.8 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.5 |  |  |  | 14.5 |  |  |  | 14.9 |  |
| Stock-based compensation |  |  | 67.8 |  |  |  | 62.3 |  |  |  | 67.6 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 1.1 |  |
| Income tax effect of non-GAAP adjustments |  |  | (15.7 | ) |  |  | (15.1 | ) |  |  | (18.9 | ) |
| Settlement of income tax audit |  |  | - |  |  |  | 47.4 |  |  |  | - |  |
| NON-GAAP NET INCOME |  | $ | 226.4 |  |  | $ | 197.5 |  |  | $ | 231.5 |  |
| COST OF REVENUES |  | $ | 560.0 |  |  | $ | 551.1 |  |  | $ | 584.7 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.2 | ) |  |  | (14.3 | ) |  |  | (14.3 | ) |
| Stock-based compensation |  |  | (5.6 | ) |  |  | (5.9 | ) |  |  | (5.6 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 540.2 |  |  | $ | 530.9 |  |  | $ | 564.8 |  |
| COST OF PRODUCT REVENUES |  | $ | 401.8 |  |  | $ | 394.2 |  |  | $ | 423.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13.7 | ) |  |  | (13.7 | ) |  |  | (13.8 | ) |
| Stock-based compensation |  |  | (1.6 | ) |  |  | (1.5 | ) |  |  | (1.4 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 386.5 |  |  | $ | 379.0 |  |  | $ | 408.1 |  |
| COST OF SERVICE REVENUES |  | $ | 149.6 |  |  | $ | 148.7 |  |  | $ | 153.9 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | (0.5 | ) |
| Stock-based compensation |  |  | (4.0 | ) |  |  | (4.4 | ) |  |  | (4.2 | ) |
| NON-GAAP COST OF SERVICE REVENUES |  | $ | 145.1 |  |  | $ | 143.7 |  |  | $ | 149.2 |  |
| GROSS PROFIT |  | $ | 982.5 |  |  | $ | 938.1 |  |  | $ | 965.2 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.2 |  |  |  | 14.3 |  |  |  | 14.3 |  |
| Stock-based compensation |  |  | 5.6 |  |  |  | 5.9 |  |  |  | 5.6 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,002.3 |  |  | $ | 958.3 |  |  | $ | 985.1 |  |
| SALES AND MARKETING EXPENSES |  | $ | 488.0 |  |  | $ | 480.2 |  |  | $ | 479.5 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.3 | ) |  |  | (0.2 | ) |  |  | (0.6 | ) |
| Stock-based compensation |  |  | (30.4 | ) |  |  | (27.0 | ) |  |  | (31.1 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 457.3 |  |  | $ | 453.0 |  |  | $ | 447.8 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 229.0 |  |  | $ | 228.0 |  |  | $ | 228.2 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (21.2 | ) |  |  | (21.5 | ) |  |  | (21.6 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 207.8 |  |  | $ | 206.5 |  |  | $ | 206.6 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 73.0 |  |  | $ | 70.0 |  |  | $ | 69.5 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (10.6 | ) |  |  | (7.9 | ) |  |  | (9.3 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 62.4 |  |  | $ | 62.1 |  |  | $ | 60.2 |  |

[0001102624-14-001857:8k_2_02:59]
15

[0001102624-14-001857:8k_2_02:60]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP TO GAAP |
| INCOME STATEMENT INFORMATION |
| (In millions, except net income per share amounts) |
|  |  | Q2'FY15 |  |  | Q1'FY15 |  |  | Q2'FY14 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | 1.1 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | (1.1 | ) |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| OPERATING EXPENSES |  | $ | 790.0 |  |  | $ | 778.2 |  |  | $ | 778.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.3 | ) |  |  | (0.2 | ) |  |  | (0.6 | ) |
| Stock-based compensation |  |  | (62.2 | ) |  |  | (56.4 | ) |  |  | (62.0 | ) |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | (1.1 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 727.5 |  |  | $ | 721.6 |  |  | $ | 714.6 |  |
| INCOME FROM OPERATIONS |  | $ | 192.5 |  |  | $ | 159.9 |  |  | $ | 186.9 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.5 |  |  |  | 14.5 |  |  |  | 14.9 |  |
| Stock-based compensation |  |  | 67.8 |  |  |  | 62.3 |  |  |  | 67.6 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 1.1 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 274.8 |  |  | $ | 236.7 |  |  | $ | 270.5 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 188.9 |  |  | $ | 159.7 |  |  | $ | 192.2 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.5 |  |  |  | 14.5 |  |  |  | 14.9 |  |
| Stock-based compensation |  |  | 67.8 |  |  |  | 62.3 |  |  |  | 67.6 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 1.1 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 271.2 |  |  | $ | 236.5 |  |  | $ | 275.8 |  |
| PROVISION FOR INCOME TAXES |  | $ | 29.1 |  |  | $ | 71.3 |  |  | $ | 25.4 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 15.7 |  |  |  | 15.1 |  |  |  | 18.9 |  |
| Settlement of income tax audit |  |  | - |  |  |  | (47.4 | ) |  |  | - |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 44.8 |  |  | $ | 39.0 |  |  | $ | 44.3 |  |
| NET INCOME PER SHARE |  | $ | 0.49 |  |  | $ | 0.27 |  |  | $ | 0.48 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.04 |  |  |  | 0.04 |  |  |  | 0.04 |  |
| Stock-based compensation |  |  | 0.21 |  |  |  | 0.19 |  |  |  | 0.19 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | - |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.05 | ) |  |  | (0.04 | ) |  |  | (0.05 | ) |
| Settlement of income tax audit |  |  | - |  |  |  | 0.14 |  |  |  | - |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.70 |  |  | $ | 0.60 |  |  | $ | 0.66 |  |

[0001102624-14-001857:8k_2_02:61]
16

[0001102624-14-001857:8k_2_02:62]
| RECONCILIATION OF NON-GAAP TO GAAP |
| GROSS MARGIN |
| ($ in millions) |
|  |  | Q2'FY15 |  |  | Q1'FY15 |  |  | Q2'FY14 |  |
| Gross margin-GAAP |  |  | 63.7 | % |  |  | 63.0 | % |  |  | 62.3 | % |
| Cost of revenues adjustments |  |  | 1.3 | % |  |  | 1.4 | % |  |  | 1.3 | % |
| Gross margin-Non-GAAP |  |  | 65.0 | % |  |  | 64.3 | % |  |  | 63.6 | % |
| GAAP cost of revenues |  | $ | 560.0 |  |  | $ | 551.1 |  |  | $ | 584.7 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.2 | ) |  |  | (14.3 | ) |  |  | (14.3 | ) |
| Stock-based compensation |  |  | (5.6 | ) |  |  | (5.9 | ) |  |  | (5.6 | ) |
| Non-GAAP cost of revenues |  | $ | 540.2 |  |  | $ | 530.9 |  |  | $ | 564.8 |  |
| Revenues |  | $ | 1,542.5 |  |  | $ | 1,489.2 |  |  | $ | 1,549.9 |  |
| RECONCILIATION OF NON-GAAP TO GAAP |
| PRODUCT GROSS MARGIN |
| ($ in millions) |
|  |  | Q2'FY15 |  |  | Q1'FY15 |  |  | Q2'FY14 |  |
| Product gross margin-GAAP |  |  | 56.8 | % |  |  | 55.3 | % |  |  | 55.7 | % |
| Cost of product revenues adjustments |  |  | 1.6 | % |  |  | 1.7 | % |  |  | 1.6 | % |
| Product gross margin-Non-GAAP |  |  | 58.4 | % |  |  | 57.1 | % |  |  | 57.3 | % |
| GAAP cost of product revenues |  | $ | 401.8 |  |  | $ | 394.2 |  |  | $ | 423.3 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13.7 | ) |  |  | (13.7 | ) |  |  | (13.8 | ) |
| Stock-based compensation |  |  | (1.6 | ) |  |  | (1.5 | ) |  |  | (1.4 | ) |
| Non-GAAP cost of product revenues |  | $ | 386.5 |  |  | $ | 379.0 |  |  | $ | 408.1 |  |
| Product revenues |  | $ | 929.1 |  |  | $ | 882.6 |  |  | $ | 955.3 |  |
| RECONCILIATION OF NON-GAAP TO GAAP |
| SERVICES GROSS MARGIN |
| ($ in millions) |  |
|  |  | Q2'FY15 |  |  | Q1'FY15 |  |  | Q2'FY14 |  |
| Services gross margin-GAAP |  |  | 61.6 | % |  |  | 61.4 | % |  |  | 57.6 | % |
| Cost of service revenues adjustments |  |  | 1.2 | % |  |  | 1.3 | % |  |  | 1.3 | % |
| Services gross margin-Non-GAAP |  |  | 62.7 | % |  |  | 62.7 | % |  |  | 58.9 | % |
| GAAP cost of service revenues |  | $ | 149.6 |  |  | $ | 148.7 |  |  | $ | 153.9 |  |
| Cost of service revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | (0.5 | ) |
| Stock-based compensation |  |  | (4.0 | ) |  |  | (4.4 | ) |  |  | (4.2 | ) |
| Non-GAAP cost of service revenues |  | $ | 145.1 |  |  | $ | 143.7 |  |  | $ | 149.2 |  |
| Service revenues |  | $ | 389.2 |  |  | $ | 385.3 |  |  | $ | 362.8 |  |

[0001102624-14-001857:8k_2_02:63]
17

[0001102624-14-001857:8k_2_02:64]
| RECONCILIATION OF NON-GAAP TO GAAP |
| EFFECTIVE TAX RATE |
|  |  | Q2'FY15 |  |  | Q1'FY15 |  |  | Q2'FY14 |  |
| GAAP effective tax rate |  |  | 15.4 | % |  |  | 44.6 | % |  |  | 13.2 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | 1.1 | % |  |  | (8.1 | %) |  |  | 2.8 | % |
| Settlement of income tax audit |  |  | - |  |  |  | (20.0 | %) |  |  | - |  |
| Non-GAAP effective tax rate |  |  | 16.5 | % |  |  | 16.5 | % |  |  | 16.1 | % |
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |
| TO FREE CASH FLOW (NON-GAAP) |
| (In millions) |
|  |  | Q2'FY15 |  |  | Q1'FY15 |  |  | Q2'FY14 |  |
| Net cash provided by operating activities |  | $ | 381.4 |  |  | $ | 215.5 |  |  | $ | 362.5 |  |
| Purchases of property and equipment |  |  | (51.1 | ) |  |  | (58.4 | ) |  |  | (42.2 | ) |
| Free cash flow |  | $ | 330.3 |  |  | $ | 157.1 |  |  | $ | 320.3 |  |
| INVENTORY TURNS AND RECONCILIATION OF NON-GAAP TO GAAP |
| COST OF REVENUES USED IN INVENTORY TURNS |
| (In millions, except annualized inventory turns) |
|  |  | Q2'FY15 |  |  | Q1'FY15 |  |  | Q2'FY14 |  |
| Annualized inventory turns- GAAP |  |  | 21 |  |  |  | 21 |  |  |  | 20 |  |
| Cost of revenues adjustments |  |  | (1 | ) |  |  | (1 | ) |  |  | - |  |
| Annualized inventory turns-Non-GAAP |  |  | 20 |  |  |  | 20 |  |  |  | 20 |  |
| GAAP cost of revenues |  | $ | 560.0 |  |  | $ | 551.1 |  |  | $ | 584.7 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.2 | ) |  |  | (14.3 | ) |  |  | (14.3 | ) |
| Stock-based compensation |  |  | (5.6 | ) |  |  | (5.9 | ) |  |  | (5.6 | ) |
| Non-GAAP cost of revenues |  | $ | 540.2 |  |  | $ | 530.9 |  |  | $ | 564.8 |  |
| Inventory |  | $ | 107.6 |  |  | $ | 104.2 |  |  | $ | 115.9 |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |

[0001102624-14-001857:8k_2_02:65]
18

[0001102624-14-001857:8k_2_02:66]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| THIRD QUARTER FISCAL 2015 |  |
|  |  | Third Quarter |  |
|  |  | Fiscal 2015 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $ | 0.74 - $0.79 |  |
| Adjustments of Specific Items to |  |  |  |  |
| Net Income Per Share for the Third |  |  |  |  |
| Quarter Fiscal 2015: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.22 | ) |
| Income tax effect of non-GAAP adjustments |  |  | 0.05 |  |
| Total Adjustments |  |  | (0.22 | ) |
| GAAP Guidance - Net Income Per Share |  | $ | 0.52 - $0.57 |  |

[0001102624-14-001857:8k_2_02:67]
19
